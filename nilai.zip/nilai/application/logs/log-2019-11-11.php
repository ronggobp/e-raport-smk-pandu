<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-11 06:15:47 --> Config Class Initialized
INFO - 2019-11-11 06:15:47 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:15:47 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:15:47 --> Utf8 Class Initialized
INFO - 2019-11-11 06:15:47 --> URI Class Initialized
DEBUG - 2019-11-11 06:15:47 --> No URI present. Default controller set.
INFO - 2019-11-11 06:15:47 --> Router Class Initialized
INFO - 2019-11-11 06:15:47 --> Output Class Initialized
INFO - 2019-11-11 06:15:47 --> Security Class Initialized
DEBUG - 2019-11-11 06:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:15:47 --> Input Class Initialized
INFO - 2019-11-11 06:15:47 --> Language Class Initialized
INFO - 2019-11-11 06:15:48 --> Language Class Initialized
INFO - 2019-11-11 06:15:48 --> Config Class Initialized
INFO - 2019-11-11 06:15:48 --> Loader Class Initialized
INFO - 2019-11-11 06:15:48 --> Helper loaded: url_helper
INFO - 2019-11-11 06:15:48 --> Helper loaded: file_helper
INFO - 2019-11-11 06:15:48 --> Helper loaded: form_helper
INFO - 2019-11-11 06:15:48 --> Helper loaded: my_helper
INFO - 2019-11-11 06:15:48 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:15:48 --> Controller Class Initialized
INFO - 2019-11-11 06:15:48 --> Config Class Initialized
INFO - 2019-11-11 06:15:48 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:15:48 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:15:48 --> Utf8 Class Initialized
INFO - 2019-11-11 06:15:48 --> URI Class Initialized
INFO - 2019-11-11 06:15:48 --> Router Class Initialized
INFO - 2019-11-11 06:15:48 --> Output Class Initialized
INFO - 2019-11-11 06:15:48 --> Security Class Initialized
DEBUG - 2019-11-11 06:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:15:48 --> Input Class Initialized
INFO - 2019-11-11 06:15:48 --> Language Class Initialized
INFO - 2019-11-11 06:15:48 --> Language Class Initialized
INFO - 2019-11-11 06:15:48 --> Config Class Initialized
INFO - 2019-11-11 06:15:48 --> Loader Class Initialized
INFO - 2019-11-11 06:15:48 --> Helper loaded: url_helper
INFO - 2019-11-11 06:15:48 --> Helper loaded: file_helper
INFO - 2019-11-11 06:15:48 --> Helper loaded: form_helper
INFO - 2019-11-11 06:15:48 --> Helper loaded: my_helper
INFO - 2019-11-11 06:15:48 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:15:48 --> Controller Class Initialized
DEBUG - 2019-11-11 06:15:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-11-11 06:15:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:15:48 --> Final output sent to browser
DEBUG - 2019-11-11 06:15:48 --> Total execution time: 0.1560
INFO - 2019-11-11 06:15:53 --> Config Class Initialized
INFO - 2019-11-11 06:15:53 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:15:53 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:15:53 --> Utf8 Class Initialized
INFO - 2019-11-11 06:15:53 --> URI Class Initialized
INFO - 2019-11-11 06:15:53 --> Router Class Initialized
INFO - 2019-11-11 06:15:53 --> Output Class Initialized
INFO - 2019-11-11 06:15:53 --> Security Class Initialized
DEBUG - 2019-11-11 06:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:15:53 --> Input Class Initialized
INFO - 2019-11-11 06:15:53 --> Language Class Initialized
INFO - 2019-11-11 06:15:53 --> Language Class Initialized
INFO - 2019-11-11 06:15:53 --> Config Class Initialized
INFO - 2019-11-11 06:15:53 --> Loader Class Initialized
INFO - 2019-11-11 06:15:53 --> Helper loaded: url_helper
INFO - 2019-11-11 06:15:53 --> Helper loaded: file_helper
INFO - 2019-11-11 06:15:53 --> Helper loaded: form_helper
INFO - 2019-11-11 06:15:53 --> Helper loaded: my_helper
INFO - 2019-11-11 06:15:53 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:15:53 --> Controller Class Initialized
INFO - 2019-11-11 06:15:53 --> Helper loaded: cookie_helper
INFO - 2019-11-11 06:15:53 --> Final output sent to browser
DEBUG - 2019-11-11 06:15:53 --> Total execution time: 0.1079
INFO - 2019-11-11 06:15:54 --> Config Class Initialized
INFO - 2019-11-11 06:15:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:15:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:15:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:15:54 --> URI Class Initialized
INFO - 2019-11-11 06:15:54 --> Router Class Initialized
INFO - 2019-11-11 06:15:54 --> Output Class Initialized
INFO - 2019-11-11 06:15:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:15:54 --> Input Class Initialized
INFO - 2019-11-11 06:15:54 --> Language Class Initialized
INFO - 2019-11-11 06:15:54 --> Language Class Initialized
INFO - 2019-11-11 06:15:54 --> Config Class Initialized
INFO - 2019-11-11 06:15:54 --> Loader Class Initialized
INFO - 2019-11-11 06:15:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:15:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:15:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:15:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:15:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:15:54 --> Controller Class Initialized
DEBUG - 2019-11-11 06:15:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-11-11 06:15:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:15:55 --> Final output sent to browser
DEBUG - 2019-11-11 06:15:55 --> Total execution time: 1.1648
INFO - 2019-11-11 06:15:59 --> Config Class Initialized
INFO - 2019-11-11 06:15:59 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:15:59 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:15:59 --> Utf8 Class Initialized
INFO - 2019-11-11 06:15:59 --> URI Class Initialized
INFO - 2019-11-11 06:15:59 --> Router Class Initialized
INFO - 2019-11-11 06:15:59 --> Output Class Initialized
INFO - 2019-11-11 06:15:59 --> Security Class Initialized
DEBUG - 2019-11-11 06:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:15:59 --> Input Class Initialized
INFO - 2019-11-11 06:15:59 --> Language Class Initialized
INFO - 2019-11-11 06:15:59 --> Language Class Initialized
INFO - 2019-11-11 06:15:59 --> Config Class Initialized
INFO - 2019-11-11 06:15:59 --> Loader Class Initialized
INFO - 2019-11-11 06:15:59 --> Helper loaded: url_helper
INFO - 2019-11-11 06:15:59 --> Helper loaded: file_helper
INFO - 2019-11-11 06:15:59 --> Helper loaded: form_helper
INFO - 2019-11-11 06:15:59 --> Helper loaded: my_helper
INFO - 2019-11-11 06:15:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:15:59 --> Controller Class Initialized
DEBUG - 2019-11-11 06:15:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2019-11-11 06:15:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:15:59 --> Final output sent to browser
DEBUG - 2019-11-11 06:15:59 --> Total execution time: 0.0916
INFO - 2019-11-11 06:15:59 --> Config Class Initialized
INFO - 2019-11-11 06:15:59 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:15:59 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:15:59 --> Utf8 Class Initialized
INFO - 2019-11-11 06:15:59 --> URI Class Initialized
INFO - 2019-11-11 06:15:59 --> Router Class Initialized
INFO - 2019-11-11 06:15:59 --> Output Class Initialized
INFO - 2019-11-11 06:15:59 --> Security Class Initialized
DEBUG - 2019-11-11 06:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:15:59 --> Input Class Initialized
INFO - 2019-11-11 06:15:59 --> Language Class Initialized
INFO - 2019-11-11 06:15:59 --> Language Class Initialized
INFO - 2019-11-11 06:15:59 --> Config Class Initialized
INFO - 2019-11-11 06:15:59 --> Loader Class Initialized
INFO - 2019-11-11 06:15:59 --> Helper loaded: url_helper
INFO - 2019-11-11 06:15:59 --> Helper loaded: file_helper
INFO - 2019-11-11 06:15:59 --> Helper loaded: form_helper
INFO - 2019-11-11 06:15:59 --> Helper loaded: my_helper
INFO - 2019-11-11 06:15:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:15:59 --> Controller Class Initialized
INFO - 2019-11-11 06:16:03 --> Config Class Initialized
INFO - 2019-11-11 06:16:03 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:16:03 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:16:03 --> Utf8 Class Initialized
INFO - 2019-11-11 06:16:03 --> URI Class Initialized
INFO - 2019-11-11 06:16:03 --> Router Class Initialized
INFO - 2019-11-11 06:16:03 --> Output Class Initialized
INFO - 2019-11-11 06:16:03 --> Security Class Initialized
DEBUG - 2019-11-11 06:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:16:03 --> Input Class Initialized
INFO - 2019-11-11 06:16:03 --> Language Class Initialized
INFO - 2019-11-11 06:16:03 --> Language Class Initialized
INFO - 2019-11-11 06:16:03 --> Config Class Initialized
INFO - 2019-11-11 06:16:03 --> Loader Class Initialized
INFO - 2019-11-11 06:16:03 --> Helper loaded: url_helper
INFO - 2019-11-11 06:16:03 --> Helper loaded: file_helper
INFO - 2019-11-11 06:16:03 --> Helper loaded: form_helper
INFO - 2019-11-11 06:16:03 --> Helper loaded: my_helper
INFO - 2019-11-11 06:16:03 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:16:03 --> Controller Class Initialized
INFO - 2019-11-11 06:16:03 --> Final output sent to browser
DEBUG - 2019-11-11 06:16:03 --> Total execution time: 0.0885
INFO - 2019-11-11 06:16:04 --> Config Class Initialized
INFO - 2019-11-11 06:16:04 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:16:04 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:16:04 --> Utf8 Class Initialized
INFO - 2019-11-11 06:16:04 --> URI Class Initialized
INFO - 2019-11-11 06:16:04 --> Router Class Initialized
INFO - 2019-11-11 06:16:04 --> Output Class Initialized
INFO - 2019-11-11 06:16:04 --> Security Class Initialized
DEBUG - 2019-11-11 06:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:16:04 --> Input Class Initialized
INFO - 2019-11-11 06:16:04 --> Language Class Initialized
INFO - 2019-11-11 06:16:04 --> Language Class Initialized
INFO - 2019-11-11 06:16:04 --> Config Class Initialized
INFO - 2019-11-11 06:16:04 --> Loader Class Initialized
INFO - 2019-11-11 06:16:04 --> Helper loaded: url_helper
INFO - 2019-11-11 06:16:04 --> Helper loaded: file_helper
INFO - 2019-11-11 06:16:04 --> Helper loaded: form_helper
INFO - 2019-11-11 06:16:04 --> Helper loaded: my_helper
INFO - 2019-11-11 06:16:04 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:16:04 --> Controller Class Initialized
INFO - 2019-11-11 06:17:49 --> Config Class Initialized
INFO - 2019-11-11 06:17:49 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:17:49 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:17:49 --> Utf8 Class Initialized
INFO - 2019-11-11 06:17:49 --> URI Class Initialized
INFO - 2019-11-11 06:17:49 --> Router Class Initialized
INFO - 2019-11-11 06:17:49 --> Output Class Initialized
INFO - 2019-11-11 06:17:49 --> Security Class Initialized
DEBUG - 2019-11-11 06:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:17:49 --> Input Class Initialized
INFO - 2019-11-11 06:17:49 --> Language Class Initialized
INFO - 2019-11-11 06:17:49 --> Language Class Initialized
INFO - 2019-11-11 06:17:49 --> Config Class Initialized
INFO - 2019-11-11 06:17:49 --> Loader Class Initialized
INFO - 2019-11-11 06:17:49 --> Helper loaded: url_helper
INFO - 2019-11-11 06:17:49 --> Helper loaded: file_helper
INFO - 2019-11-11 06:17:49 --> Helper loaded: form_helper
INFO - 2019-11-11 06:17:49 --> Helper loaded: my_helper
INFO - 2019-11-11 06:17:49 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:17:49 --> Controller Class Initialized
INFO - 2019-11-11 06:17:49 --> Helper loaded: cookie_helper
INFO - 2019-11-11 06:17:49 --> Config Class Initialized
INFO - 2019-11-11 06:17:49 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:17:49 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:17:49 --> Utf8 Class Initialized
INFO - 2019-11-11 06:17:49 --> URI Class Initialized
INFO - 2019-11-11 06:17:49 --> Router Class Initialized
INFO - 2019-11-11 06:17:49 --> Output Class Initialized
INFO - 2019-11-11 06:17:49 --> Security Class Initialized
DEBUG - 2019-11-11 06:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:17:49 --> Input Class Initialized
INFO - 2019-11-11 06:17:49 --> Language Class Initialized
INFO - 2019-11-11 06:17:49 --> Language Class Initialized
INFO - 2019-11-11 06:17:49 --> Config Class Initialized
INFO - 2019-11-11 06:17:49 --> Loader Class Initialized
INFO - 2019-11-11 06:17:49 --> Helper loaded: url_helper
INFO - 2019-11-11 06:17:49 --> Helper loaded: file_helper
INFO - 2019-11-11 06:17:49 --> Helper loaded: form_helper
INFO - 2019-11-11 06:17:49 --> Helper loaded: my_helper
INFO - 2019-11-11 06:17:49 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:17:49 --> Controller Class Initialized
DEBUG - 2019-11-11 06:17:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-11-11 06:17:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:17:49 --> Final output sent to browser
DEBUG - 2019-11-11 06:17:49 --> Total execution time: 0.0505
INFO - 2019-11-11 06:17:55 --> Config Class Initialized
INFO - 2019-11-11 06:17:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:17:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:17:55 --> Utf8 Class Initialized
INFO - 2019-11-11 06:17:55 --> URI Class Initialized
INFO - 2019-11-11 06:17:55 --> Router Class Initialized
INFO - 2019-11-11 06:17:55 --> Output Class Initialized
INFO - 2019-11-11 06:17:55 --> Security Class Initialized
DEBUG - 2019-11-11 06:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:17:55 --> Input Class Initialized
INFO - 2019-11-11 06:17:55 --> Language Class Initialized
INFO - 2019-11-11 06:17:55 --> Language Class Initialized
INFO - 2019-11-11 06:17:55 --> Config Class Initialized
INFO - 2019-11-11 06:17:55 --> Loader Class Initialized
INFO - 2019-11-11 06:17:55 --> Helper loaded: url_helper
INFO - 2019-11-11 06:17:55 --> Helper loaded: file_helper
INFO - 2019-11-11 06:17:55 --> Helper loaded: form_helper
INFO - 2019-11-11 06:17:55 --> Helper loaded: my_helper
INFO - 2019-11-11 06:17:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:17:55 --> Controller Class Initialized
INFO - 2019-11-11 06:17:55 --> Helper loaded: cookie_helper
INFO - 2019-11-11 06:17:55 --> Final output sent to browser
DEBUG - 2019-11-11 06:17:55 --> Total execution time: 0.0836
INFO - 2019-11-11 06:17:55 --> Config Class Initialized
INFO - 2019-11-11 06:17:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:17:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:17:55 --> Utf8 Class Initialized
INFO - 2019-11-11 06:17:55 --> URI Class Initialized
INFO - 2019-11-11 06:17:55 --> Router Class Initialized
INFO - 2019-11-11 06:17:55 --> Output Class Initialized
INFO - 2019-11-11 06:17:55 --> Security Class Initialized
DEBUG - 2019-11-11 06:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:17:55 --> Input Class Initialized
INFO - 2019-11-11 06:17:55 --> Language Class Initialized
INFO - 2019-11-11 06:17:55 --> Language Class Initialized
INFO - 2019-11-11 06:17:55 --> Config Class Initialized
INFO - 2019-11-11 06:17:55 --> Loader Class Initialized
INFO - 2019-11-11 06:17:55 --> Helper loaded: url_helper
INFO - 2019-11-11 06:17:55 --> Helper loaded: file_helper
INFO - 2019-11-11 06:17:55 --> Helper loaded: form_helper
INFO - 2019-11-11 06:17:55 --> Helper loaded: my_helper
INFO - 2019-11-11 06:17:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:17:55 --> Controller Class Initialized
DEBUG - 2019-11-11 06:17:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-11-11 06:17:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:17:55 --> Final output sent to browser
DEBUG - 2019-11-11 06:17:55 --> Total execution time: 0.1959
INFO - 2019-11-11 06:17:57 --> Config Class Initialized
INFO - 2019-11-11 06:17:57 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:17:57 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:17:57 --> Utf8 Class Initialized
INFO - 2019-11-11 06:17:57 --> URI Class Initialized
INFO - 2019-11-11 06:17:57 --> Router Class Initialized
INFO - 2019-11-11 06:17:57 --> Output Class Initialized
INFO - 2019-11-11 06:17:57 --> Security Class Initialized
DEBUG - 2019-11-11 06:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:17:57 --> Input Class Initialized
INFO - 2019-11-11 06:17:57 --> Language Class Initialized
INFO - 2019-11-11 06:17:58 --> Language Class Initialized
INFO - 2019-11-11 06:17:58 --> Config Class Initialized
INFO - 2019-11-11 06:17:58 --> Loader Class Initialized
INFO - 2019-11-11 06:17:58 --> Helper loaded: url_helper
INFO - 2019-11-11 06:17:58 --> Helper loaded: file_helper
INFO - 2019-11-11 06:17:58 --> Helper loaded: form_helper
INFO - 2019-11-11 06:17:58 --> Helper loaded: my_helper
INFO - 2019-11-11 06:17:58 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:17:58 --> Controller Class Initialized
DEBUG - 2019-11-11 06:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2019-11-11 06:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:17:58 --> Final output sent to browser
DEBUG - 2019-11-11 06:17:58 --> Total execution time: 0.1075
INFO - 2019-11-11 06:18:20 --> Config Class Initialized
INFO - 2019-11-11 06:18:20 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:20 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:20 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:20 --> URI Class Initialized
INFO - 2019-11-11 06:18:20 --> Router Class Initialized
INFO - 2019-11-11 06:18:20 --> Output Class Initialized
INFO - 2019-11-11 06:18:20 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:20 --> Input Class Initialized
INFO - 2019-11-11 06:18:21 --> Language Class Initialized
INFO - 2019-11-11 06:18:21 --> Language Class Initialized
INFO - 2019-11-11 06:18:21 --> Config Class Initialized
INFO - 2019-11-11 06:18:21 --> Loader Class Initialized
INFO - 2019-11-11 06:18:21 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:21 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:21 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:21 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:21 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:21 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:18:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:21 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:21 --> Total execution time: 0.1652
INFO - 2019-11-11 06:18:21 --> Config Class Initialized
INFO - 2019-11-11 06:18:21 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:21 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:21 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:21 --> URI Class Initialized
INFO - 2019-11-11 06:18:21 --> Router Class Initialized
INFO - 2019-11-11 06:18:21 --> Output Class Initialized
INFO - 2019-11-11 06:18:21 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:21 --> Input Class Initialized
INFO - 2019-11-11 06:18:21 --> Language Class Initialized
INFO - 2019-11-11 06:18:21 --> Language Class Initialized
INFO - 2019-11-11 06:18:21 --> Config Class Initialized
INFO - 2019-11-11 06:18:21 --> Loader Class Initialized
INFO - 2019-11-11 06:18:21 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:21 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:21 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:21 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:21 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:21 --> Controller Class Initialized
INFO - 2019-11-11 06:18:22 --> Config Class Initialized
INFO - 2019-11-11 06:18:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:22 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:22 --> URI Class Initialized
INFO - 2019-11-11 06:18:22 --> Router Class Initialized
INFO - 2019-11-11 06:18:22 --> Output Class Initialized
INFO - 2019-11-11 06:18:22 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:22 --> Input Class Initialized
INFO - 2019-11-11 06:18:22 --> Language Class Initialized
INFO - 2019-11-11 06:18:22 --> Language Class Initialized
INFO - 2019-11-11 06:18:22 --> Config Class Initialized
INFO - 2019-11-11 06:18:22 --> Loader Class Initialized
INFO - 2019-11-11 06:18:22 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:22 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:22 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:22 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:22 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:22 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:22 --> Total execution time: 0.1819
INFO - 2019-11-11 06:18:27 --> Config Class Initialized
INFO - 2019-11-11 06:18:27 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:27 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:27 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:27 --> URI Class Initialized
INFO - 2019-11-11 06:18:27 --> Router Class Initialized
INFO - 2019-11-11 06:18:27 --> Output Class Initialized
INFO - 2019-11-11 06:18:27 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:27 --> Input Class Initialized
INFO - 2019-11-11 06:18:27 --> Language Class Initialized
INFO - 2019-11-11 06:18:27 --> Language Class Initialized
INFO - 2019-11-11 06:18:27 --> Config Class Initialized
INFO - 2019-11-11 06:18:27 --> Loader Class Initialized
INFO - 2019-11-11 06:18:27 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:27 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:27 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:27 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:27 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:27 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:18:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:27 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:27 --> Total execution time: 0.0930
INFO - 2019-11-11 06:18:27 --> Config Class Initialized
INFO - 2019-11-11 06:18:27 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:27 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:27 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:27 --> URI Class Initialized
INFO - 2019-11-11 06:18:27 --> Router Class Initialized
INFO - 2019-11-11 06:18:27 --> Output Class Initialized
INFO - 2019-11-11 06:18:27 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:27 --> Input Class Initialized
INFO - 2019-11-11 06:18:27 --> Language Class Initialized
INFO - 2019-11-11 06:18:27 --> Language Class Initialized
INFO - 2019-11-11 06:18:27 --> Config Class Initialized
INFO - 2019-11-11 06:18:27 --> Loader Class Initialized
INFO - 2019-11-11 06:18:27 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:27 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:27 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:27 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:27 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:27 --> Controller Class Initialized
INFO - 2019-11-11 06:18:28 --> Config Class Initialized
INFO - 2019-11-11 06:18:28 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:28 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:28 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:28 --> URI Class Initialized
INFO - 2019-11-11 06:18:28 --> Router Class Initialized
INFO - 2019-11-11 06:18:28 --> Output Class Initialized
INFO - 2019-11-11 06:18:28 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:28 --> Input Class Initialized
INFO - 2019-11-11 06:18:28 --> Language Class Initialized
INFO - 2019-11-11 06:18:28 --> Language Class Initialized
INFO - 2019-11-11 06:18:28 --> Config Class Initialized
INFO - 2019-11-11 06:18:28 --> Loader Class Initialized
INFO - 2019-11-11 06:18:28 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:28 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:28 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:28 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:28 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:28 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:18:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:28 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:28 --> Total execution time: 0.0921
INFO - 2019-11-11 06:18:34 --> Config Class Initialized
INFO - 2019-11-11 06:18:34 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:34 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:34 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:34 --> URI Class Initialized
INFO - 2019-11-11 06:18:34 --> Router Class Initialized
INFO - 2019-11-11 06:18:34 --> Output Class Initialized
INFO - 2019-11-11 06:18:34 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:34 --> Input Class Initialized
INFO - 2019-11-11 06:18:34 --> Language Class Initialized
INFO - 2019-11-11 06:18:34 --> Language Class Initialized
INFO - 2019-11-11 06:18:34 --> Config Class Initialized
INFO - 2019-11-11 06:18:34 --> Loader Class Initialized
INFO - 2019-11-11 06:18:34 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:34 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:34 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:34 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:34 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:34 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:18:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:34 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:34 --> Total execution time: 0.0908
INFO - 2019-11-11 06:18:34 --> Config Class Initialized
INFO - 2019-11-11 06:18:34 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:34 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:34 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:34 --> URI Class Initialized
INFO - 2019-11-11 06:18:34 --> Router Class Initialized
INFO - 2019-11-11 06:18:34 --> Output Class Initialized
INFO - 2019-11-11 06:18:34 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:34 --> Input Class Initialized
INFO - 2019-11-11 06:18:34 --> Language Class Initialized
INFO - 2019-11-11 06:18:34 --> Language Class Initialized
INFO - 2019-11-11 06:18:34 --> Config Class Initialized
INFO - 2019-11-11 06:18:34 --> Loader Class Initialized
INFO - 2019-11-11 06:18:34 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:34 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:34 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:34 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:34 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:34 --> Controller Class Initialized
INFO - 2019-11-11 06:18:35 --> Config Class Initialized
INFO - 2019-11-11 06:18:35 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:35 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:35 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:35 --> URI Class Initialized
INFO - 2019-11-11 06:18:35 --> Router Class Initialized
INFO - 2019-11-11 06:18:35 --> Output Class Initialized
INFO - 2019-11-11 06:18:35 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:35 --> Input Class Initialized
INFO - 2019-11-11 06:18:35 --> Language Class Initialized
INFO - 2019-11-11 06:18:35 --> Language Class Initialized
INFO - 2019-11-11 06:18:35 --> Config Class Initialized
INFO - 2019-11-11 06:18:35 --> Loader Class Initialized
INFO - 2019-11-11 06:18:35 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:35 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:35 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:35 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:35 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:35 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:18:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:35 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:35 --> Total execution time: 0.1026
INFO - 2019-11-11 06:18:40 --> Config Class Initialized
INFO - 2019-11-11 06:18:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:40 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:40 --> URI Class Initialized
INFO - 2019-11-11 06:18:40 --> Router Class Initialized
INFO - 2019-11-11 06:18:40 --> Output Class Initialized
INFO - 2019-11-11 06:18:40 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:40 --> Input Class Initialized
INFO - 2019-11-11 06:18:40 --> Language Class Initialized
INFO - 2019-11-11 06:18:40 --> Language Class Initialized
INFO - 2019-11-11 06:18:40 --> Config Class Initialized
INFO - 2019-11-11 06:18:40 --> Loader Class Initialized
INFO - 2019-11-11 06:18:40 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:40 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:40 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:40 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:40 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:40 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:40 --> Total execution time: 0.1002
INFO - 2019-11-11 06:18:40 --> Config Class Initialized
INFO - 2019-11-11 06:18:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:40 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:40 --> URI Class Initialized
INFO - 2019-11-11 06:18:40 --> Router Class Initialized
INFO - 2019-11-11 06:18:40 --> Output Class Initialized
INFO - 2019-11-11 06:18:40 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:40 --> Input Class Initialized
INFO - 2019-11-11 06:18:40 --> Language Class Initialized
INFO - 2019-11-11 06:18:40 --> Language Class Initialized
INFO - 2019-11-11 06:18:40 --> Config Class Initialized
INFO - 2019-11-11 06:18:40 --> Loader Class Initialized
INFO - 2019-11-11 06:18:40 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:40 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:40 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:40 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:40 --> Controller Class Initialized
INFO - 2019-11-11 06:18:42 --> Config Class Initialized
INFO - 2019-11-11 06:18:42 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:42 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:42 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:42 --> URI Class Initialized
INFO - 2019-11-11 06:18:42 --> Router Class Initialized
INFO - 2019-11-11 06:18:42 --> Output Class Initialized
INFO - 2019-11-11 06:18:42 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:42 --> Input Class Initialized
INFO - 2019-11-11 06:18:42 --> Language Class Initialized
INFO - 2019-11-11 06:18:42 --> Language Class Initialized
INFO - 2019-11-11 06:18:42 --> Config Class Initialized
INFO - 2019-11-11 06:18:42 --> Loader Class Initialized
INFO - 2019-11-11 06:18:42 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:42 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:42 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:42 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:42 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:42 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:18:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:42 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:42 --> Total execution time: 0.0985
INFO - 2019-11-11 06:18:46 --> Config Class Initialized
INFO - 2019-11-11 06:18:46 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:46 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:46 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:46 --> URI Class Initialized
INFO - 2019-11-11 06:18:46 --> Router Class Initialized
INFO - 2019-11-11 06:18:46 --> Output Class Initialized
INFO - 2019-11-11 06:18:46 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:46 --> Input Class Initialized
INFO - 2019-11-11 06:18:46 --> Language Class Initialized
INFO - 2019-11-11 06:18:46 --> Language Class Initialized
INFO - 2019-11-11 06:18:46 --> Config Class Initialized
INFO - 2019-11-11 06:18:46 --> Loader Class Initialized
INFO - 2019-11-11 06:18:46 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:46 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:46 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:46 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:46 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:46 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:18:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:46 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:46 --> Total execution time: 0.0875
INFO - 2019-11-11 06:18:46 --> Config Class Initialized
INFO - 2019-11-11 06:18:46 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:46 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:46 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:46 --> URI Class Initialized
INFO - 2019-11-11 06:18:46 --> Router Class Initialized
INFO - 2019-11-11 06:18:46 --> Output Class Initialized
INFO - 2019-11-11 06:18:46 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:46 --> Input Class Initialized
INFO - 2019-11-11 06:18:46 --> Language Class Initialized
INFO - 2019-11-11 06:18:46 --> Language Class Initialized
INFO - 2019-11-11 06:18:46 --> Config Class Initialized
INFO - 2019-11-11 06:18:46 --> Loader Class Initialized
INFO - 2019-11-11 06:18:46 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:46 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:46 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:46 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:46 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:46 --> Controller Class Initialized
INFO - 2019-11-11 06:18:47 --> Config Class Initialized
INFO - 2019-11-11 06:18:47 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:18:47 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:18:47 --> Utf8 Class Initialized
INFO - 2019-11-11 06:18:47 --> URI Class Initialized
INFO - 2019-11-11 06:18:47 --> Router Class Initialized
INFO - 2019-11-11 06:18:47 --> Output Class Initialized
INFO - 2019-11-11 06:18:47 --> Security Class Initialized
DEBUG - 2019-11-11 06:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:18:47 --> Input Class Initialized
INFO - 2019-11-11 06:18:47 --> Language Class Initialized
INFO - 2019-11-11 06:18:47 --> Language Class Initialized
INFO - 2019-11-11 06:18:47 --> Config Class Initialized
INFO - 2019-11-11 06:18:47 --> Loader Class Initialized
INFO - 2019-11-11 06:18:47 --> Helper loaded: url_helper
INFO - 2019-11-11 06:18:47 --> Helper loaded: file_helper
INFO - 2019-11-11 06:18:47 --> Helper loaded: form_helper
INFO - 2019-11-11 06:18:47 --> Helper loaded: my_helper
INFO - 2019-11-11 06:18:47 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:18:47 --> Controller Class Initialized
DEBUG - 2019-11-11 06:18:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:18:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:18:47 --> Final output sent to browser
DEBUG - 2019-11-11 06:18:47 --> Total execution time: 0.0984
INFO - 2019-11-11 06:19:02 --> Config Class Initialized
INFO - 2019-11-11 06:19:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:02 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:02 --> URI Class Initialized
INFO - 2019-11-11 06:19:02 --> Router Class Initialized
INFO - 2019-11-11 06:19:02 --> Output Class Initialized
INFO - 2019-11-11 06:19:02 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:02 --> Input Class Initialized
INFO - 2019-11-11 06:19:02 --> Language Class Initialized
INFO - 2019-11-11 06:19:02 --> Language Class Initialized
INFO - 2019-11-11 06:19:02 --> Config Class Initialized
INFO - 2019-11-11 06:19:02 --> Loader Class Initialized
INFO - 2019-11-11 06:19:02 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:02 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:02 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:02 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:02 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:19:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:02 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:02 --> Total execution time: 0.0941
INFO - 2019-11-11 06:19:02 --> Config Class Initialized
INFO - 2019-11-11 06:19:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:02 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:02 --> URI Class Initialized
INFO - 2019-11-11 06:19:02 --> Router Class Initialized
INFO - 2019-11-11 06:19:02 --> Output Class Initialized
INFO - 2019-11-11 06:19:02 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:02 --> Input Class Initialized
INFO - 2019-11-11 06:19:02 --> Language Class Initialized
INFO - 2019-11-11 06:19:02 --> Language Class Initialized
INFO - 2019-11-11 06:19:02 --> Config Class Initialized
INFO - 2019-11-11 06:19:02 --> Loader Class Initialized
INFO - 2019-11-11 06:19:02 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:02 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:02 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:02 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:02 --> Controller Class Initialized
INFO - 2019-11-11 06:19:03 --> Config Class Initialized
INFO - 2019-11-11 06:19:03 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:03 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:03 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:03 --> URI Class Initialized
INFO - 2019-11-11 06:19:03 --> Router Class Initialized
INFO - 2019-11-11 06:19:03 --> Output Class Initialized
INFO - 2019-11-11 06:19:03 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:03 --> Input Class Initialized
INFO - 2019-11-11 06:19:03 --> Language Class Initialized
INFO - 2019-11-11 06:19:03 --> Language Class Initialized
INFO - 2019-11-11 06:19:03 --> Config Class Initialized
INFO - 2019-11-11 06:19:03 --> Loader Class Initialized
INFO - 2019-11-11 06:19:03 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:03 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:03 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:03 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:03 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:03 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:19:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:03 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:03 --> Total execution time: 0.0873
INFO - 2019-11-11 06:19:08 --> Config Class Initialized
INFO - 2019-11-11 06:19:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:08 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:08 --> URI Class Initialized
INFO - 2019-11-11 06:19:08 --> Router Class Initialized
INFO - 2019-11-11 06:19:08 --> Output Class Initialized
INFO - 2019-11-11 06:19:08 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:08 --> Input Class Initialized
INFO - 2019-11-11 06:19:08 --> Language Class Initialized
INFO - 2019-11-11 06:19:08 --> Language Class Initialized
INFO - 2019-11-11 06:19:08 --> Config Class Initialized
INFO - 2019-11-11 06:19:08 --> Loader Class Initialized
INFO - 2019-11-11 06:19:08 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:08 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:08 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:08 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:08 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:19:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:08 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:08 --> Total execution time: 0.0868
INFO - 2019-11-11 06:19:08 --> Config Class Initialized
INFO - 2019-11-11 06:19:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:08 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:08 --> URI Class Initialized
INFO - 2019-11-11 06:19:08 --> Router Class Initialized
INFO - 2019-11-11 06:19:08 --> Output Class Initialized
INFO - 2019-11-11 06:19:08 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:08 --> Input Class Initialized
INFO - 2019-11-11 06:19:08 --> Language Class Initialized
INFO - 2019-11-11 06:19:08 --> Language Class Initialized
INFO - 2019-11-11 06:19:08 --> Config Class Initialized
INFO - 2019-11-11 06:19:08 --> Loader Class Initialized
INFO - 2019-11-11 06:19:08 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:08 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:08 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:08 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:08 --> Controller Class Initialized
INFO - 2019-11-11 06:19:09 --> Config Class Initialized
INFO - 2019-11-11 06:19:09 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:09 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:09 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:09 --> URI Class Initialized
INFO - 2019-11-11 06:19:09 --> Router Class Initialized
INFO - 2019-11-11 06:19:09 --> Output Class Initialized
INFO - 2019-11-11 06:19:09 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:09 --> Input Class Initialized
INFO - 2019-11-11 06:19:09 --> Language Class Initialized
INFO - 2019-11-11 06:19:09 --> Language Class Initialized
INFO - 2019-11-11 06:19:09 --> Config Class Initialized
INFO - 2019-11-11 06:19:09 --> Loader Class Initialized
INFO - 2019-11-11 06:19:09 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:09 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:09 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:09 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:09 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:09 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:09 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:09 --> Total execution time: 0.0857
INFO - 2019-11-11 06:19:14 --> Config Class Initialized
INFO - 2019-11-11 06:19:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:14 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:14 --> URI Class Initialized
INFO - 2019-11-11 06:19:14 --> Router Class Initialized
INFO - 2019-11-11 06:19:14 --> Output Class Initialized
INFO - 2019-11-11 06:19:14 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:14 --> Input Class Initialized
INFO - 2019-11-11 06:19:14 --> Language Class Initialized
INFO - 2019-11-11 06:19:14 --> Language Class Initialized
INFO - 2019-11-11 06:19:14 --> Config Class Initialized
INFO - 2019-11-11 06:19:14 --> Loader Class Initialized
INFO - 2019-11-11 06:19:14 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:14 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:14 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:14 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:14 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:14 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:14 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:14 --> Total execution time: 0.0840
INFO - 2019-11-11 06:19:14 --> Config Class Initialized
INFO - 2019-11-11 06:19:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:14 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:14 --> URI Class Initialized
INFO - 2019-11-11 06:19:14 --> Router Class Initialized
INFO - 2019-11-11 06:19:14 --> Output Class Initialized
INFO - 2019-11-11 06:19:14 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:14 --> Input Class Initialized
INFO - 2019-11-11 06:19:14 --> Language Class Initialized
INFO - 2019-11-11 06:19:14 --> Language Class Initialized
INFO - 2019-11-11 06:19:14 --> Config Class Initialized
INFO - 2019-11-11 06:19:14 --> Loader Class Initialized
INFO - 2019-11-11 06:19:14 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:14 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:14 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:14 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:14 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:14 --> Controller Class Initialized
INFO - 2019-11-11 06:19:15 --> Config Class Initialized
INFO - 2019-11-11 06:19:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:15 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:15 --> URI Class Initialized
INFO - 2019-11-11 06:19:15 --> Router Class Initialized
INFO - 2019-11-11 06:19:15 --> Output Class Initialized
INFO - 2019-11-11 06:19:15 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:15 --> Input Class Initialized
INFO - 2019-11-11 06:19:15 --> Language Class Initialized
INFO - 2019-11-11 06:19:15 --> Language Class Initialized
INFO - 2019-11-11 06:19:15 --> Config Class Initialized
INFO - 2019-11-11 06:19:15 --> Loader Class Initialized
INFO - 2019-11-11 06:19:15 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:15 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:15 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:15 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:15 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:19:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:15 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:15 --> Total execution time: 0.1138
INFO - 2019-11-11 06:19:20 --> Config Class Initialized
INFO - 2019-11-11 06:19:20 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:20 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:20 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:20 --> URI Class Initialized
INFO - 2019-11-11 06:19:20 --> Router Class Initialized
INFO - 2019-11-11 06:19:20 --> Output Class Initialized
INFO - 2019-11-11 06:19:20 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:20 --> Input Class Initialized
INFO - 2019-11-11 06:19:20 --> Language Class Initialized
INFO - 2019-11-11 06:19:20 --> Language Class Initialized
INFO - 2019-11-11 06:19:20 --> Config Class Initialized
INFO - 2019-11-11 06:19:20 --> Loader Class Initialized
INFO - 2019-11-11 06:19:20 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:20 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:20 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:20 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:20 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:20 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:19:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:20 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:20 --> Total execution time: 0.0863
INFO - 2019-11-11 06:19:20 --> Config Class Initialized
INFO - 2019-11-11 06:19:20 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:20 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:20 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:20 --> URI Class Initialized
INFO - 2019-11-11 06:19:20 --> Router Class Initialized
INFO - 2019-11-11 06:19:20 --> Output Class Initialized
INFO - 2019-11-11 06:19:20 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:20 --> Input Class Initialized
INFO - 2019-11-11 06:19:20 --> Language Class Initialized
INFO - 2019-11-11 06:19:20 --> Language Class Initialized
INFO - 2019-11-11 06:19:20 --> Config Class Initialized
INFO - 2019-11-11 06:19:20 --> Loader Class Initialized
INFO - 2019-11-11 06:19:20 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:20 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:20 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:20 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:20 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:20 --> Controller Class Initialized
INFO - 2019-11-11 06:19:22 --> Config Class Initialized
INFO - 2019-11-11 06:19:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:22 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:22 --> URI Class Initialized
INFO - 2019-11-11 06:19:22 --> Router Class Initialized
INFO - 2019-11-11 06:19:22 --> Output Class Initialized
INFO - 2019-11-11 06:19:22 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:22 --> Input Class Initialized
INFO - 2019-11-11 06:19:22 --> Language Class Initialized
INFO - 2019-11-11 06:19:22 --> Language Class Initialized
INFO - 2019-11-11 06:19:22 --> Config Class Initialized
INFO - 2019-11-11 06:19:22 --> Loader Class Initialized
INFO - 2019-11-11 06:19:22 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:22 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:22 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:22 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:22 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:22 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:22 --> Total execution time: 0.0930
INFO - 2019-11-11 06:19:26 --> Config Class Initialized
INFO - 2019-11-11 06:19:26 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:26 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:26 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:26 --> URI Class Initialized
INFO - 2019-11-11 06:19:26 --> Router Class Initialized
INFO - 2019-11-11 06:19:26 --> Output Class Initialized
INFO - 2019-11-11 06:19:26 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:26 --> Input Class Initialized
INFO - 2019-11-11 06:19:26 --> Language Class Initialized
INFO - 2019-11-11 06:19:26 --> Language Class Initialized
INFO - 2019-11-11 06:19:26 --> Config Class Initialized
INFO - 2019-11-11 06:19:26 --> Loader Class Initialized
INFO - 2019-11-11 06:19:26 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:26 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:26 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:26 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:26 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:26 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:19:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:26 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:26 --> Total execution time: 0.0949
INFO - 2019-11-11 06:19:26 --> Config Class Initialized
INFO - 2019-11-11 06:19:26 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:26 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:26 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:26 --> URI Class Initialized
INFO - 2019-11-11 06:19:26 --> Router Class Initialized
INFO - 2019-11-11 06:19:26 --> Output Class Initialized
INFO - 2019-11-11 06:19:26 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:26 --> Input Class Initialized
INFO - 2019-11-11 06:19:26 --> Language Class Initialized
INFO - 2019-11-11 06:19:26 --> Language Class Initialized
INFO - 2019-11-11 06:19:26 --> Config Class Initialized
INFO - 2019-11-11 06:19:26 --> Loader Class Initialized
INFO - 2019-11-11 06:19:26 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:26 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:26 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:26 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:27 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:27 --> Controller Class Initialized
INFO - 2019-11-11 06:19:27 --> Config Class Initialized
INFO - 2019-11-11 06:19:27 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:27 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:27 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:27 --> URI Class Initialized
INFO - 2019-11-11 06:19:27 --> Router Class Initialized
INFO - 2019-11-11 06:19:27 --> Output Class Initialized
INFO - 2019-11-11 06:19:27 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:27 --> Input Class Initialized
INFO - 2019-11-11 06:19:27 --> Language Class Initialized
INFO - 2019-11-11 06:19:27 --> Language Class Initialized
INFO - 2019-11-11 06:19:27 --> Config Class Initialized
INFO - 2019-11-11 06:19:27 --> Loader Class Initialized
INFO - 2019-11-11 06:19:27 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:27 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:27 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:27 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:27 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:27 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:19:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:27 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:27 --> Total execution time: 0.0941
INFO - 2019-11-11 06:19:33 --> Config Class Initialized
INFO - 2019-11-11 06:19:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:33 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:33 --> URI Class Initialized
INFO - 2019-11-11 06:19:33 --> Router Class Initialized
INFO - 2019-11-11 06:19:33 --> Output Class Initialized
INFO - 2019-11-11 06:19:33 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:33 --> Input Class Initialized
INFO - 2019-11-11 06:19:33 --> Language Class Initialized
INFO - 2019-11-11 06:19:33 --> Language Class Initialized
INFO - 2019-11-11 06:19:33 --> Config Class Initialized
INFO - 2019-11-11 06:19:33 --> Loader Class Initialized
INFO - 2019-11-11 06:19:33 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:33 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:33 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:33 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:33 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:33 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:33 --> Total execution time: 0.0947
INFO - 2019-11-11 06:19:34 --> Config Class Initialized
INFO - 2019-11-11 06:19:34 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:34 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:34 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:34 --> URI Class Initialized
INFO - 2019-11-11 06:19:34 --> Router Class Initialized
INFO - 2019-11-11 06:19:34 --> Output Class Initialized
INFO - 2019-11-11 06:19:34 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:34 --> Input Class Initialized
INFO - 2019-11-11 06:19:34 --> Language Class Initialized
INFO - 2019-11-11 06:19:34 --> Language Class Initialized
INFO - 2019-11-11 06:19:34 --> Config Class Initialized
INFO - 2019-11-11 06:19:34 --> Loader Class Initialized
INFO - 2019-11-11 06:19:34 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:34 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:34 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:34 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:34 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:34 --> Controller Class Initialized
INFO - 2019-11-11 06:19:35 --> Config Class Initialized
INFO - 2019-11-11 06:19:35 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:35 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:35 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:35 --> URI Class Initialized
INFO - 2019-11-11 06:19:35 --> Router Class Initialized
INFO - 2019-11-11 06:19:35 --> Output Class Initialized
INFO - 2019-11-11 06:19:35 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:35 --> Input Class Initialized
INFO - 2019-11-11 06:19:35 --> Language Class Initialized
INFO - 2019-11-11 06:19:35 --> Language Class Initialized
INFO - 2019-11-11 06:19:35 --> Config Class Initialized
INFO - 2019-11-11 06:19:35 --> Loader Class Initialized
INFO - 2019-11-11 06:19:35 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:35 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:35 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:35 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:35 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:35 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:19:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:35 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:35 --> Total execution time: 0.0896
INFO - 2019-11-11 06:19:41 --> Config Class Initialized
INFO - 2019-11-11 06:19:41 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:41 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:41 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:41 --> URI Class Initialized
INFO - 2019-11-11 06:19:41 --> Router Class Initialized
INFO - 2019-11-11 06:19:41 --> Output Class Initialized
INFO - 2019-11-11 06:19:41 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:41 --> Input Class Initialized
INFO - 2019-11-11 06:19:41 --> Language Class Initialized
INFO - 2019-11-11 06:19:41 --> Language Class Initialized
INFO - 2019-11-11 06:19:41 --> Config Class Initialized
INFO - 2019-11-11 06:19:41 --> Loader Class Initialized
INFO - 2019-11-11 06:19:41 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:41 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:41 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:41 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:41 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:41 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:41 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:41 --> Total execution time: 0.0799
INFO - 2019-11-11 06:19:41 --> Config Class Initialized
INFO - 2019-11-11 06:19:41 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:41 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:41 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:41 --> URI Class Initialized
INFO - 2019-11-11 06:19:41 --> Router Class Initialized
INFO - 2019-11-11 06:19:41 --> Output Class Initialized
INFO - 2019-11-11 06:19:41 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:41 --> Input Class Initialized
INFO - 2019-11-11 06:19:41 --> Language Class Initialized
INFO - 2019-11-11 06:19:41 --> Language Class Initialized
INFO - 2019-11-11 06:19:41 --> Config Class Initialized
INFO - 2019-11-11 06:19:41 --> Loader Class Initialized
INFO - 2019-11-11 06:19:41 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:41 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:41 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:41 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:41 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:41 --> Controller Class Initialized
INFO - 2019-11-11 06:19:43 --> Config Class Initialized
INFO - 2019-11-11 06:19:43 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:43 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:43 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:43 --> URI Class Initialized
INFO - 2019-11-11 06:19:43 --> Router Class Initialized
INFO - 2019-11-11 06:19:43 --> Output Class Initialized
INFO - 2019-11-11 06:19:43 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:43 --> Input Class Initialized
INFO - 2019-11-11 06:19:43 --> Language Class Initialized
INFO - 2019-11-11 06:19:43 --> Language Class Initialized
INFO - 2019-11-11 06:19:43 --> Config Class Initialized
INFO - 2019-11-11 06:19:43 --> Loader Class Initialized
INFO - 2019-11-11 06:19:43 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:43 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:43 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:43 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:43 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:43 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:43 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:43 --> Total execution time: 0.0796
INFO - 2019-11-11 06:19:45 --> Config Class Initialized
INFO - 2019-11-11 06:19:45 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:45 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:45 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:45 --> URI Class Initialized
INFO - 2019-11-11 06:19:45 --> Router Class Initialized
INFO - 2019-11-11 06:19:45 --> Output Class Initialized
INFO - 2019-11-11 06:19:45 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:45 --> Input Class Initialized
INFO - 2019-11-11 06:19:45 --> Language Class Initialized
INFO - 2019-11-11 06:19:45 --> Language Class Initialized
INFO - 2019-11-11 06:19:45 --> Config Class Initialized
INFO - 2019-11-11 06:19:45 --> Loader Class Initialized
INFO - 2019-11-11 06:19:45 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:45 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:45 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:45 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:45 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:45 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:45 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:45 --> Total execution time: 0.0996
INFO - 2019-11-11 06:19:46 --> Config Class Initialized
INFO - 2019-11-11 06:19:46 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:46 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:46 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:46 --> URI Class Initialized
INFO - 2019-11-11 06:19:46 --> Router Class Initialized
INFO - 2019-11-11 06:19:46 --> Output Class Initialized
INFO - 2019-11-11 06:19:46 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:46 --> Input Class Initialized
INFO - 2019-11-11 06:19:46 --> Language Class Initialized
INFO - 2019-11-11 06:19:46 --> Language Class Initialized
INFO - 2019-11-11 06:19:46 --> Config Class Initialized
INFO - 2019-11-11 06:19:46 --> Loader Class Initialized
INFO - 2019-11-11 06:19:46 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:46 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:46 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:46 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:46 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:46 --> Controller Class Initialized
INFO - 2019-11-11 06:19:47 --> Config Class Initialized
INFO - 2019-11-11 06:19:47 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:47 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:47 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:47 --> URI Class Initialized
INFO - 2019-11-11 06:19:47 --> Router Class Initialized
INFO - 2019-11-11 06:19:47 --> Output Class Initialized
INFO - 2019-11-11 06:19:47 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:47 --> Input Class Initialized
INFO - 2019-11-11 06:19:47 --> Language Class Initialized
INFO - 2019-11-11 06:19:47 --> Language Class Initialized
INFO - 2019-11-11 06:19:47 --> Config Class Initialized
INFO - 2019-11-11 06:19:47 --> Loader Class Initialized
INFO - 2019-11-11 06:19:47 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:47 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:47 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:47 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:47 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:47 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:47 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:47 --> Total execution time: 0.0911
INFO - 2019-11-11 06:19:53 --> Config Class Initialized
INFO - 2019-11-11 06:19:53 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:53 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:53 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:53 --> URI Class Initialized
INFO - 2019-11-11 06:19:53 --> Router Class Initialized
INFO - 2019-11-11 06:19:53 --> Output Class Initialized
INFO - 2019-11-11 06:19:53 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:53 --> Input Class Initialized
INFO - 2019-11-11 06:19:53 --> Language Class Initialized
INFO - 2019-11-11 06:19:53 --> Language Class Initialized
INFO - 2019-11-11 06:19:53 --> Config Class Initialized
INFO - 2019-11-11 06:19:53 --> Loader Class Initialized
INFO - 2019-11-11 06:19:53 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:53 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:53 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:53 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:53 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:53 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:53 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:53 --> Total execution time: 0.0998
INFO - 2019-11-11 06:19:53 --> Config Class Initialized
INFO - 2019-11-11 06:19:53 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:53 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:53 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:53 --> URI Class Initialized
INFO - 2019-11-11 06:19:53 --> Router Class Initialized
INFO - 2019-11-11 06:19:53 --> Output Class Initialized
INFO - 2019-11-11 06:19:53 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:53 --> Input Class Initialized
INFO - 2019-11-11 06:19:53 --> Language Class Initialized
INFO - 2019-11-11 06:19:53 --> Language Class Initialized
INFO - 2019-11-11 06:19:53 --> Config Class Initialized
INFO - 2019-11-11 06:19:53 --> Loader Class Initialized
INFO - 2019-11-11 06:19:53 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:53 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:53 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:53 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:53 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:53 --> Controller Class Initialized
INFO - 2019-11-11 06:19:54 --> Config Class Initialized
INFO - 2019-11-11 06:19:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:19:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:19:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:19:54 --> URI Class Initialized
INFO - 2019-11-11 06:19:54 --> Router Class Initialized
INFO - 2019-11-11 06:19:54 --> Output Class Initialized
INFO - 2019-11-11 06:19:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:19:54 --> Input Class Initialized
INFO - 2019-11-11 06:19:54 --> Language Class Initialized
INFO - 2019-11-11 06:19:54 --> Language Class Initialized
INFO - 2019-11-11 06:19:54 --> Config Class Initialized
INFO - 2019-11-11 06:19:54 --> Loader Class Initialized
INFO - 2019-11-11 06:19:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:19:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:19:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:19:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:19:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:19:54 --> Controller Class Initialized
DEBUG - 2019-11-11 06:19:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:19:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:19:54 --> Final output sent to browser
DEBUG - 2019-11-11 06:19:54 --> Total execution time: 0.0894
INFO - 2019-11-11 06:20:00 --> Config Class Initialized
INFO - 2019-11-11 06:20:00 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:20:00 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:20:00 --> Utf8 Class Initialized
INFO - 2019-11-11 06:20:00 --> URI Class Initialized
INFO - 2019-11-11 06:20:00 --> Router Class Initialized
INFO - 2019-11-11 06:20:00 --> Output Class Initialized
INFO - 2019-11-11 06:20:00 --> Security Class Initialized
DEBUG - 2019-11-11 06:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:20:00 --> Input Class Initialized
INFO - 2019-11-11 06:20:00 --> Language Class Initialized
INFO - 2019-11-11 06:20:00 --> Language Class Initialized
INFO - 2019-11-11 06:20:00 --> Config Class Initialized
INFO - 2019-11-11 06:20:00 --> Loader Class Initialized
INFO - 2019-11-11 06:20:00 --> Helper loaded: url_helper
INFO - 2019-11-11 06:20:00 --> Helper loaded: file_helper
INFO - 2019-11-11 06:20:00 --> Helper loaded: form_helper
INFO - 2019-11-11 06:20:00 --> Helper loaded: my_helper
INFO - 2019-11-11 06:20:00 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:20:00 --> Controller Class Initialized
DEBUG - 2019-11-11 06:20:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:20:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:20:00 --> Final output sent to browser
DEBUG - 2019-11-11 06:20:00 --> Total execution time: 0.0702
INFO - 2019-11-11 06:20:00 --> Config Class Initialized
INFO - 2019-11-11 06:20:00 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:20:00 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:20:00 --> Utf8 Class Initialized
INFO - 2019-11-11 06:20:00 --> URI Class Initialized
INFO - 2019-11-11 06:20:00 --> Router Class Initialized
INFO - 2019-11-11 06:20:00 --> Output Class Initialized
INFO - 2019-11-11 06:20:00 --> Security Class Initialized
DEBUG - 2019-11-11 06:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:20:00 --> Input Class Initialized
INFO - 2019-11-11 06:20:01 --> Language Class Initialized
INFO - 2019-11-11 06:20:01 --> Language Class Initialized
INFO - 2019-11-11 06:20:01 --> Config Class Initialized
INFO - 2019-11-11 06:20:01 --> Loader Class Initialized
INFO - 2019-11-11 06:20:01 --> Helper loaded: url_helper
INFO - 2019-11-11 06:20:01 --> Helper loaded: file_helper
INFO - 2019-11-11 06:20:01 --> Helper loaded: form_helper
INFO - 2019-11-11 06:20:01 --> Helper loaded: my_helper
INFO - 2019-11-11 06:20:01 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:20:01 --> Controller Class Initialized
INFO - 2019-11-11 06:20:02 --> Config Class Initialized
INFO - 2019-11-11 06:20:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:20:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:20:02 --> Utf8 Class Initialized
INFO - 2019-11-11 06:20:02 --> URI Class Initialized
INFO - 2019-11-11 06:20:02 --> Router Class Initialized
INFO - 2019-11-11 06:20:02 --> Output Class Initialized
INFO - 2019-11-11 06:20:02 --> Security Class Initialized
DEBUG - 2019-11-11 06:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:20:02 --> Input Class Initialized
INFO - 2019-11-11 06:20:02 --> Language Class Initialized
INFO - 2019-11-11 06:20:02 --> Language Class Initialized
INFO - 2019-11-11 06:20:02 --> Config Class Initialized
INFO - 2019-11-11 06:20:02 --> Loader Class Initialized
INFO - 2019-11-11 06:20:02 --> Helper loaded: url_helper
INFO - 2019-11-11 06:20:02 --> Helper loaded: file_helper
INFO - 2019-11-11 06:20:02 --> Helper loaded: form_helper
INFO - 2019-11-11 06:20:02 --> Helper loaded: my_helper
INFO - 2019-11-11 06:20:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:20:02 --> Controller Class Initialized
DEBUG - 2019-11-11 06:20:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:20:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:20:02 --> Final output sent to browser
DEBUG - 2019-11-11 06:20:02 --> Total execution time: 0.0766
INFO - 2019-11-11 06:20:07 --> Config Class Initialized
INFO - 2019-11-11 06:20:07 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:20:07 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:20:07 --> Utf8 Class Initialized
INFO - 2019-11-11 06:20:07 --> URI Class Initialized
INFO - 2019-11-11 06:20:07 --> Router Class Initialized
INFO - 2019-11-11 06:20:07 --> Output Class Initialized
INFO - 2019-11-11 06:20:07 --> Security Class Initialized
DEBUG - 2019-11-11 06:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:20:07 --> Input Class Initialized
INFO - 2019-11-11 06:20:07 --> Language Class Initialized
INFO - 2019-11-11 06:20:07 --> Language Class Initialized
INFO - 2019-11-11 06:20:07 --> Config Class Initialized
INFO - 2019-11-11 06:20:07 --> Loader Class Initialized
INFO - 2019-11-11 06:20:07 --> Helper loaded: url_helper
INFO - 2019-11-11 06:20:07 --> Helper loaded: file_helper
INFO - 2019-11-11 06:20:07 --> Helper loaded: form_helper
INFO - 2019-11-11 06:20:08 --> Helper loaded: my_helper
INFO - 2019-11-11 06:20:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:20:08 --> Controller Class Initialized
DEBUG - 2019-11-11 06:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:20:08 --> Final output sent to browser
DEBUG - 2019-11-11 06:20:08 --> Total execution time: 0.1075
INFO - 2019-11-11 06:20:08 --> Config Class Initialized
INFO - 2019-11-11 06:20:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:20:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:20:08 --> Utf8 Class Initialized
INFO - 2019-11-11 06:20:08 --> URI Class Initialized
INFO - 2019-11-11 06:20:08 --> Router Class Initialized
INFO - 2019-11-11 06:20:08 --> Output Class Initialized
INFO - 2019-11-11 06:20:08 --> Security Class Initialized
DEBUG - 2019-11-11 06:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:20:08 --> Input Class Initialized
INFO - 2019-11-11 06:20:08 --> Language Class Initialized
INFO - 2019-11-11 06:20:08 --> Language Class Initialized
INFO - 2019-11-11 06:20:08 --> Config Class Initialized
INFO - 2019-11-11 06:20:08 --> Loader Class Initialized
INFO - 2019-11-11 06:20:08 --> Helper loaded: url_helper
INFO - 2019-11-11 06:20:08 --> Helper loaded: file_helper
INFO - 2019-11-11 06:20:08 --> Helper loaded: form_helper
INFO - 2019-11-11 06:20:08 --> Helper loaded: my_helper
INFO - 2019-11-11 06:20:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:20:08 --> Controller Class Initialized
INFO - 2019-11-11 06:20:09 --> Config Class Initialized
INFO - 2019-11-11 06:20:09 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:20:09 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:20:09 --> Utf8 Class Initialized
INFO - 2019-11-11 06:20:09 --> URI Class Initialized
INFO - 2019-11-11 06:20:09 --> Router Class Initialized
INFO - 2019-11-11 06:20:09 --> Output Class Initialized
INFO - 2019-11-11 06:20:09 --> Security Class Initialized
DEBUG - 2019-11-11 06:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:20:09 --> Input Class Initialized
INFO - 2019-11-11 06:20:09 --> Language Class Initialized
INFO - 2019-11-11 06:20:09 --> Language Class Initialized
INFO - 2019-11-11 06:20:09 --> Config Class Initialized
INFO - 2019-11-11 06:20:09 --> Loader Class Initialized
INFO - 2019-11-11 06:20:09 --> Helper loaded: url_helper
INFO - 2019-11-11 06:20:09 --> Helper loaded: file_helper
INFO - 2019-11-11 06:20:09 --> Helper loaded: form_helper
INFO - 2019-11-11 06:20:09 --> Helper loaded: my_helper
INFO - 2019-11-11 06:20:09 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:20:09 --> Controller Class Initialized
DEBUG - 2019-11-11 06:20:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:20:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:20:09 --> Final output sent to browser
DEBUG - 2019-11-11 06:20:09 --> Total execution time: 0.0759
INFO - 2019-11-11 06:20:32 --> Config Class Initialized
INFO - 2019-11-11 06:20:32 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:20:32 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:20:32 --> Utf8 Class Initialized
INFO - 2019-11-11 06:20:32 --> URI Class Initialized
INFO - 2019-11-11 06:20:32 --> Router Class Initialized
INFO - 2019-11-11 06:20:32 --> Output Class Initialized
INFO - 2019-11-11 06:20:32 --> Security Class Initialized
DEBUG - 2019-11-11 06:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:20:32 --> Input Class Initialized
INFO - 2019-11-11 06:20:32 --> Language Class Initialized
INFO - 2019-11-11 06:20:32 --> Language Class Initialized
INFO - 2019-11-11 06:20:32 --> Config Class Initialized
INFO - 2019-11-11 06:20:32 --> Loader Class Initialized
INFO - 2019-11-11 06:20:32 --> Helper loaded: url_helper
INFO - 2019-11-11 06:20:32 --> Helper loaded: file_helper
INFO - 2019-11-11 06:20:32 --> Helper loaded: form_helper
INFO - 2019-11-11 06:20:32 --> Helper loaded: my_helper
INFO - 2019-11-11 06:20:32 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:20:32 --> Controller Class Initialized
INFO - 2019-11-11 06:20:49 --> Config Class Initialized
INFO - 2019-11-11 06:20:49 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:20:49 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:20:49 --> Utf8 Class Initialized
INFO - 2019-11-11 06:20:49 --> URI Class Initialized
INFO - 2019-11-11 06:20:49 --> Router Class Initialized
INFO - 2019-11-11 06:20:49 --> Output Class Initialized
INFO - 2019-11-11 06:20:49 --> Security Class Initialized
DEBUG - 2019-11-11 06:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:20:49 --> Input Class Initialized
INFO - 2019-11-11 06:20:49 --> Language Class Initialized
INFO - 2019-11-11 06:20:49 --> Language Class Initialized
INFO - 2019-11-11 06:20:49 --> Config Class Initialized
INFO - 2019-11-11 06:20:49 --> Loader Class Initialized
INFO - 2019-11-11 06:20:49 --> Helper loaded: url_helper
INFO - 2019-11-11 06:20:49 --> Helper loaded: file_helper
INFO - 2019-11-11 06:20:49 --> Helper loaded: form_helper
INFO - 2019-11-11 06:20:49 --> Helper loaded: my_helper
INFO - 2019-11-11 06:20:49 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:20:49 --> Controller Class Initialized
INFO - 2019-11-11 06:20:57 --> Config Class Initialized
INFO - 2019-11-11 06:20:57 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:20:57 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:20:57 --> Utf8 Class Initialized
INFO - 2019-11-11 06:20:57 --> URI Class Initialized
INFO - 2019-11-11 06:20:57 --> Router Class Initialized
INFO - 2019-11-11 06:20:57 --> Output Class Initialized
INFO - 2019-11-11 06:20:57 --> Security Class Initialized
DEBUG - 2019-11-11 06:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:20:57 --> Input Class Initialized
INFO - 2019-11-11 06:20:57 --> Language Class Initialized
INFO - 2019-11-11 06:20:57 --> Language Class Initialized
INFO - 2019-11-11 06:20:57 --> Config Class Initialized
INFO - 2019-11-11 06:20:57 --> Loader Class Initialized
INFO - 2019-11-11 06:20:57 --> Helper loaded: url_helper
INFO - 2019-11-11 06:20:57 --> Helper loaded: file_helper
INFO - 2019-11-11 06:20:57 --> Helper loaded: form_helper
INFO - 2019-11-11 06:20:57 --> Helper loaded: my_helper
INFO - 2019-11-11 06:20:57 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:20:57 --> Controller Class Initialized
INFO - 2019-11-11 06:21:00 --> Config Class Initialized
INFO - 2019-11-11 06:21:00 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:00 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:00 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:00 --> URI Class Initialized
INFO - 2019-11-11 06:21:00 --> Router Class Initialized
INFO - 2019-11-11 06:21:00 --> Output Class Initialized
INFO - 2019-11-11 06:21:00 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:00 --> Input Class Initialized
INFO - 2019-11-11 06:21:00 --> Language Class Initialized
INFO - 2019-11-11 06:21:00 --> Language Class Initialized
INFO - 2019-11-11 06:21:00 --> Config Class Initialized
INFO - 2019-11-11 06:21:00 --> Loader Class Initialized
INFO - 2019-11-11 06:21:00 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:00 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:00 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:00 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:00 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:00 --> Controller Class Initialized
INFO - 2019-11-11 06:21:03 --> Config Class Initialized
INFO - 2019-11-11 06:21:03 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:03 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:03 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:03 --> URI Class Initialized
INFO - 2019-11-11 06:21:03 --> Router Class Initialized
INFO - 2019-11-11 06:21:03 --> Output Class Initialized
INFO - 2019-11-11 06:21:03 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:03 --> Input Class Initialized
INFO - 2019-11-11 06:21:03 --> Language Class Initialized
INFO - 2019-11-11 06:21:03 --> Language Class Initialized
INFO - 2019-11-11 06:21:03 --> Config Class Initialized
INFO - 2019-11-11 06:21:03 --> Loader Class Initialized
INFO - 2019-11-11 06:21:03 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:03 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:03 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:03 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:03 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:03 --> Controller Class Initialized
INFO - 2019-11-11 06:21:06 --> Config Class Initialized
INFO - 2019-11-11 06:21:06 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:06 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:06 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:06 --> URI Class Initialized
INFO - 2019-11-11 06:21:06 --> Router Class Initialized
INFO - 2019-11-11 06:21:06 --> Output Class Initialized
INFO - 2019-11-11 06:21:06 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:06 --> Input Class Initialized
INFO - 2019-11-11 06:21:06 --> Language Class Initialized
INFO - 2019-11-11 06:21:06 --> Language Class Initialized
INFO - 2019-11-11 06:21:06 --> Config Class Initialized
INFO - 2019-11-11 06:21:06 --> Loader Class Initialized
INFO - 2019-11-11 06:21:06 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:06 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:06 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:06 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:06 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:06 --> Controller Class Initialized
INFO - 2019-11-11 06:21:08 --> Config Class Initialized
INFO - 2019-11-11 06:21:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:08 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:08 --> URI Class Initialized
INFO - 2019-11-11 06:21:08 --> Router Class Initialized
INFO - 2019-11-11 06:21:08 --> Output Class Initialized
INFO - 2019-11-11 06:21:08 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:08 --> Input Class Initialized
INFO - 2019-11-11 06:21:08 --> Language Class Initialized
INFO - 2019-11-11 06:21:08 --> Language Class Initialized
INFO - 2019-11-11 06:21:08 --> Config Class Initialized
INFO - 2019-11-11 06:21:08 --> Loader Class Initialized
INFO - 2019-11-11 06:21:08 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:08 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:08 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:08 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:08 --> Controller Class Initialized
INFO - 2019-11-11 06:21:10 --> Config Class Initialized
INFO - 2019-11-11 06:21:10 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:10 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:10 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:10 --> URI Class Initialized
INFO - 2019-11-11 06:21:10 --> Router Class Initialized
INFO - 2019-11-11 06:21:10 --> Output Class Initialized
INFO - 2019-11-11 06:21:10 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:10 --> Input Class Initialized
INFO - 2019-11-11 06:21:10 --> Language Class Initialized
INFO - 2019-11-11 06:21:10 --> Language Class Initialized
INFO - 2019-11-11 06:21:10 --> Config Class Initialized
INFO - 2019-11-11 06:21:10 --> Loader Class Initialized
INFO - 2019-11-11 06:21:10 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:10 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:10 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:10 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:10 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:10 --> Controller Class Initialized
INFO - 2019-11-11 06:21:11 --> Config Class Initialized
INFO - 2019-11-11 06:21:11 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:11 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:11 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:11 --> URI Class Initialized
INFO - 2019-11-11 06:21:11 --> Router Class Initialized
INFO - 2019-11-11 06:21:11 --> Output Class Initialized
INFO - 2019-11-11 06:21:11 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:11 --> Input Class Initialized
INFO - 2019-11-11 06:21:11 --> Language Class Initialized
INFO - 2019-11-11 06:21:11 --> Language Class Initialized
INFO - 2019-11-11 06:21:11 --> Config Class Initialized
INFO - 2019-11-11 06:21:11 --> Loader Class Initialized
INFO - 2019-11-11 06:21:11 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:11 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:11 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:11 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:11 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:11 --> Controller Class Initialized
INFO - 2019-11-11 06:21:13 --> Config Class Initialized
INFO - 2019-11-11 06:21:13 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:13 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:13 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:13 --> URI Class Initialized
INFO - 2019-11-11 06:21:13 --> Router Class Initialized
INFO - 2019-11-11 06:21:13 --> Output Class Initialized
INFO - 2019-11-11 06:21:13 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:13 --> Input Class Initialized
INFO - 2019-11-11 06:21:13 --> Language Class Initialized
INFO - 2019-11-11 06:21:13 --> Language Class Initialized
INFO - 2019-11-11 06:21:13 --> Config Class Initialized
INFO - 2019-11-11 06:21:13 --> Loader Class Initialized
INFO - 2019-11-11 06:21:13 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:13 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:13 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:13 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:13 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:13 --> Controller Class Initialized
INFO - 2019-11-11 06:21:15 --> Config Class Initialized
INFO - 2019-11-11 06:21:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:15 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:15 --> URI Class Initialized
INFO - 2019-11-11 06:21:15 --> Router Class Initialized
INFO - 2019-11-11 06:21:15 --> Output Class Initialized
INFO - 2019-11-11 06:21:15 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:15 --> Input Class Initialized
INFO - 2019-11-11 06:21:15 --> Language Class Initialized
INFO - 2019-11-11 06:21:15 --> Language Class Initialized
INFO - 2019-11-11 06:21:15 --> Config Class Initialized
INFO - 2019-11-11 06:21:15 --> Loader Class Initialized
INFO - 2019-11-11 06:21:15 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:15 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:15 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:15 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:15 --> Controller Class Initialized
INFO - 2019-11-11 06:21:17 --> Config Class Initialized
INFO - 2019-11-11 06:21:17 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:17 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:17 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:17 --> URI Class Initialized
INFO - 2019-11-11 06:21:17 --> Router Class Initialized
INFO - 2019-11-11 06:21:17 --> Output Class Initialized
INFO - 2019-11-11 06:21:17 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:17 --> Input Class Initialized
INFO - 2019-11-11 06:21:17 --> Language Class Initialized
INFO - 2019-11-11 06:21:17 --> Language Class Initialized
INFO - 2019-11-11 06:21:17 --> Config Class Initialized
INFO - 2019-11-11 06:21:17 --> Loader Class Initialized
INFO - 2019-11-11 06:21:17 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:17 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:17 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:17 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:17 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:17 --> Controller Class Initialized
INFO - 2019-11-11 06:21:19 --> Config Class Initialized
INFO - 2019-11-11 06:21:19 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:19 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:19 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:19 --> URI Class Initialized
INFO - 2019-11-11 06:21:19 --> Router Class Initialized
INFO - 2019-11-11 06:21:19 --> Output Class Initialized
INFO - 2019-11-11 06:21:19 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:19 --> Input Class Initialized
INFO - 2019-11-11 06:21:19 --> Language Class Initialized
INFO - 2019-11-11 06:21:20 --> Language Class Initialized
INFO - 2019-11-11 06:21:20 --> Config Class Initialized
INFO - 2019-11-11 06:21:20 --> Loader Class Initialized
INFO - 2019-11-11 06:21:20 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:20 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:20 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:20 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:20 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:20 --> Controller Class Initialized
INFO - 2019-11-11 06:21:21 --> Config Class Initialized
INFO - 2019-11-11 06:21:21 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:21 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:21 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:21 --> URI Class Initialized
INFO - 2019-11-11 06:21:21 --> Router Class Initialized
INFO - 2019-11-11 06:21:21 --> Output Class Initialized
INFO - 2019-11-11 06:21:21 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:21 --> Input Class Initialized
INFO - 2019-11-11 06:21:21 --> Language Class Initialized
INFO - 2019-11-11 06:21:21 --> Language Class Initialized
INFO - 2019-11-11 06:21:21 --> Config Class Initialized
INFO - 2019-11-11 06:21:21 --> Loader Class Initialized
INFO - 2019-11-11 06:21:21 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:21 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:21 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:21 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:21 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:21 --> Controller Class Initialized
INFO - 2019-11-11 06:21:23 --> Config Class Initialized
INFO - 2019-11-11 06:21:23 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:23 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:23 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:23 --> URI Class Initialized
INFO - 2019-11-11 06:21:23 --> Router Class Initialized
INFO - 2019-11-11 06:21:23 --> Output Class Initialized
INFO - 2019-11-11 06:21:23 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:23 --> Input Class Initialized
INFO - 2019-11-11 06:21:23 --> Language Class Initialized
INFO - 2019-11-11 06:21:23 --> Language Class Initialized
INFO - 2019-11-11 06:21:23 --> Config Class Initialized
INFO - 2019-11-11 06:21:23 --> Loader Class Initialized
INFO - 2019-11-11 06:21:23 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:23 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:23 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:23 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:23 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:24 --> Controller Class Initialized
INFO - 2019-11-11 06:21:25 --> Config Class Initialized
INFO - 2019-11-11 06:21:25 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:25 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:25 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:25 --> URI Class Initialized
INFO - 2019-11-11 06:21:25 --> Router Class Initialized
INFO - 2019-11-11 06:21:25 --> Output Class Initialized
INFO - 2019-11-11 06:21:25 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:25 --> Input Class Initialized
INFO - 2019-11-11 06:21:25 --> Language Class Initialized
INFO - 2019-11-11 06:21:25 --> Language Class Initialized
INFO - 2019-11-11 06:21:25 --> Config Class Initialized
INFO - 2019-11-11 06:21:25 --> Loader Class Initialized
INFO - 2019-11-11 06:21:25 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:25 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:26 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:26 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:26 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:26 --> Controller Class Initialized
INFO - 2019-11-11 06:21:28 --> Config Class Initialized
INFO - 2019-11-11 06:21:28 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:28 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:28 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:28 --> URI Class Initialized
INFO - 2019-11-11 06:21:28 --> Router Class Initialized
INFO - 2019-11-11 06:21:28 --> Output Class Initialized
INFO - 2019-11-11 06:21:28 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:28 --> Input Class Initialized
INFO - 2019-11-11 06:21:28 --> Language Class Initialized
INFO - 2019-11-11 06:21:28 --> Language Class Initialized
INFO - 2019-11-11 06:21:28 --> Config Class Initialized
INFO - 2019-11-11 06:21:28 --> Loader Class Initialized
INFO - 2019-11-11 06:21:28 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:28 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:28 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:28 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:28 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:28 --> Controller Class Initialized
INFO - 2019-11-11 06:21:30 --> Config Class Initialized
INFO - 2019-11-11 06:21:30 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:30 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:30 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:30 --> URI Class Initialized
INFO - 2019-11-11 06:21:30 --> Router Class Initialized
INFO - 2019-11-11 06:21:30 --> Output Class Initialized
INFO - 2019-11-11 06:21:30 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:30 --> Input Class Initialized
INFO - 2019-11-11 06:21:30 --> Language Class Initialized
INFO - 2019-11-11 06:21:30 --> Language Class Initialized
INFO - 2019-11-11 06:21:30 --> Config Class Initialized
INFO - 2019-11-11 06:21:30 --> Loader Class Initialized
INFO - 2019-11-11 06:21:30 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:30 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:30 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:30 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:30 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:30 --> Controller Class Initialized
INFO - 2019-11-11 06:21:32 --> Config Class Initialized
INFO - 2019-11-11 06:21:32 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:32 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:32 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:32 --> URI Class Initialized
INFO - 2019-11-11 06:21:32 --> Router Class Initialized
INFO - 2019-11-11 06:21:32 --> Output Class Initialized
INFO - 2019-11-11 06:21:32 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:32 --> Input Class Initialized
INFO - 2019-11-11 06:21:32 --> Language Class Initialized
INFO - 2019-11-11 06:21:32 --> Language Class Initialized
INFO - 2019-11-11 06:21:32 --> Config Class Initialized
INFO - 2019-11-11 06:21:32 --> Loader Class Initialized
INFO - 2019-11-11 06:21:32 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:32 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:32 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:32 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:32 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:32 --> Controller Class Initialized
INFO - 2019-11-11 06:21:34 --> Config Class Initialized
INFO - 2019-11-11 06:21:34 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:34 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:34 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:34 --> URI Class Initialized
INFO - 2019-11-11 06:21:34 --> Router Class Initialized
INFO - 2019-11-11 06:21:34 --> Output Class Initialized
INFO - 2019-11-11 06:21:34 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:34 --> Input Class Initialized
INFO - 2019-11-11 06:21:34 --> Language Class Initialized
INFO - 2019-11-11 06:21:34 --> Language Class Initialized
INFO - 2019-11-11 06:21:34 --> Config Class Initialized
INFO - 2019-11-11 06:21:34 --> Loader Class Initialized
INFO - 2019-11-11 06:21:34 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:34 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:34 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:34 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:34 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:34 --> Controller Class Initialized
INFO - 2019-11-11 06:21:36 --> Config Class Initialized
INFO - 2019-11-11 06:21:36 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:36 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:36 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:36 --> URI Class Initialized
INFO - 2019-11-11 06:21:36 --> Router Class Initialized
INFO - 2019-11-11 06:21:36 --> Output Class Initialized
INFO - 2019-11-11 06:21:36 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:36 --> Input Class Initialized
INFO - 2019-11-11 06:21:36 --> Language Class Initialized
INFO - 2019-11-11 06:21:36 --> Language Class Initialized
INFO - 2019-11-11 06:21:36 --> Config Class Initialized
INFO - 2019-11-11 06:21:36 --> Loader Class Initialized
INFO - 2019-11-11 06:21:36 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:36 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:36 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:36 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:36 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:36 --> Controller Class Initialized
INFO - 2019-11-11 06:21:38 --> Config Class Initialized
INFO - 2019-11-11 06:21:38 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:38 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:38 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:38 --> URI Class Initialized
INFO - 2019-11-11 06:21:38 --> Router Class Initialized
INFO - 2019-11-11 06:21:38 --> Output Class Initialized
INFO - 2019-11-11 06:21:38 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:38 --> Input Class Initialized
INFO - 2019-11-11 06:21:38 --> Language Class Initialized
INFO - 2019-11-11 06:21:38 --> Language Class Initialized
INFO - 2019-11-11 06:21:38 --> Config Class Initialized
INFO - 2019-11-11 06:21:38 --> Loader Class Initialized
INFO - 2019-11-11 06:21:38 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:38 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:38 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:38 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:38 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:38 --> Controller Class Initialized
INFO - 2019-11-11 06:21:40 --> Config Class Initialized
INFO - 2019-11-11 06:21:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:40 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:40 --> URI Class Initialized
INFO - 2019-11-11 06:21:40 --> Router Class Initialized
INFO - 2019-11-11 06:21:40 --> Output Class Initialized
INFO - 2019-11-11 06:21:40 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:40 --> Input Class Initialized
INFO - 2019-11-11 06:21:40 --> Language Class Initialized
INFO - 2019-11-11 06:21:40 --> Language Class Initialized
INFO - 2019-11-11 06:21:40 --> Config Class Initialized
INFO - 2019-11-11 06:21:40 --> Loader Class Initialized
INFO - 2019-11-11 06:21:40 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:40 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:40 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:40 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:40 --> Controller Class Initialized
INFO - 2019-11-11 06:21:42 --> Config Class Initialized
INFO - 2019-11-11 06:21:42 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:42 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:42 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:42 --> URI Class Initialized
INFO - 2019-11-11 06:21:42 --> Router Class Initialized
INFO - 2019-11-11 06:21:42 --> Output Class Initialized
INFO - 2019-11-11 06:21:42 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:42 --> Input Class Initialized
INFO - 2019-11-11 06:21:42 --> Language Class Initialized
INFO - 2019-11-11 06:21:42 --> Language Class Initialized
INFO - 2019-11-11 06:21:42 --> Config Class Initialized
INFO - 2019-11-11 06:21:42 --> Loader Class Initialized
INFO - 2019-11-11 06:21:42 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:42 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:42 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:42 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:42 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:42 --> Controller Class Initialized
INFO - 2019-11-11 06:21:44 --> Config Class Initialized
INFO - 2019-11-11 06:21:44 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:44 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:44 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:44 --> URI Class Initialized
INFO - 2019-11-11 06:21:44 --> Router Class Initialized
INFO - 2019-11-11 06:21:44 --> Output Class Initialized
INFO - 2019-11-11 06:21:44 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:44 --> Input Class Initialized
INFO - 2019-11-11 06:21:44 --> Language Class Initialized
INFO - 2019-11-11 06:21:44 --> Language Class Initialized
INFO - 2019-11-11 06:21:44 --> Config Class Initialized
INFO - 2019-11-11 06:21:44 --> Loader Class Initialized
INFO - 2019-11-11 06:21:44 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:44 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:44 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:44 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:44 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:44 --> Controller Class Initialized
INFO - 2019-11-11 06:21:47 --> Config Class Initialized
INFO - 2019-11-11 06:21:47 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:47 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:47 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:47 --> URI Class Initialized
INFO - 2019-11-11 06:21:47 --> Router Class Initialized
INFO - 2019-11-11 06:21:47 --> Output Class Initialized
INFO - 2019-11-11 06:21:47 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:47 --> Input Class Initialized
INFO - 2019-11-11 06:21:47 --> Language Class Initialized
INFO - 2019-11-11 06:21:47 --> Language Class Initialized
INFO - 2019-11-11 06:21:47 --> Config Class Initialized
INFO - 2019-11-11 06:21:47 --> Loader Class Initialized
INFO - 2019-11-11 06:21:47 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:47 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:47 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:47 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:47 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:47 --> Controller Class Initialized
INFO - 2019-11-11 06:21:50 --> Config Class Initialized
INFO - 2019-11-11 06:21:50 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:50 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:50 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:50 --> URI Class Initialized
INFO - 2019-11-11 06:21:50 --> Router Class Initialized
INFO - 2019-11-11 06:21:50 --> Output Class Initialized
INFO - 2019-11-11 06:21:50 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:50 --> Input Class Initialized
INFO - 2019-11-11 06:21:50 --> Language Class Initialized
INFO - 2019-11-11 06:21:50 --> Language Class Initialized
INFO - 2019-11-11 06:21:50 --> Config Class Initialized
INFO - 2019-11-11 06:21:50 --> Loader Class Initialized
INFO - 2019-11-11 06:21:50 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:50 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:50 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:50 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:50 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:50 --> Controller Class Initialized
INFO - 2019-11-11 06:21:52 --> Config Class Initialized
INFO - 2019-11-11 06:21:52 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:52 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:52 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:52 --> URI Class Initialized
INFO - 2019-11-11 06:21:52 --> Router Class Initialized
INFO - 2019-11-11 06:21:52 --> Output Class Initialized
INFO - 2019-11-11 06:21:52 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:52 --> Input Class Initialized
INFO - 2019-11-11 06:21:52 --> Language Class Initialized
INFO - 2019-11-11 06:21:52 --> Language Class Initialized
INFO - 2019-11-11 06:21:52 --> Config Class Initialized
INFO - 2019-11-11 06:21:52 --> Loader Class Initialized
INFO - 2019-11-11 06:21:52 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:52 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:52 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:52 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:52 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:52 --> Controller Class Initialized
INFO - 2019-11-11 06:21:54 --> Config Class Initialized
INFO - 2019-11-11 06:21:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:54 --> URI Class Initialized
INFO - 2019-11-11 06:21:54 --> Router Class Initialized
INFO - 2019-11-11 06:21:54 --> Output Class Initialized
INFO - 2019-11-11 06:21:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:54 --> Input Class Initialized
INFO - 2019-11-11 06:21:54 --> Language Class Initialized
INFO - 2019-11-11 06:21:54 --> Language Class Initialized
INFO - 2019-11-11 06:21:54 --> Config Class Initialized
INFO - 2019-11-11 06:21:54 --> Loader Class Initialized
INFO - 2019-11-11 06:21:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:54 --> Controller Class Initialized
INFO - 2019-11-11 06:21:56 --> Config Class Initialized
INFO - 2019-11-11 06:21:56 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:56 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:56 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:56 --> URI Class Initialized
INFO - 2019-11-11 06:21:56 --> Router Class Initialized
INFO - 2019-11-11 06:21:56 --> Output Class Initialized
INFO - 2019-11-11 06:21:56 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:56 --> Input Class Initialized
INFO - 2019-11-11 06:21:56 --> Language Class Initialized
INFO - 2019-11-11 06:21:56 --> Language Class Initialized
INFO - 2019-11-11 06:21:56 --> Config Class Initialized
INFO - 2019-11-11 06:21:56 --> Loader Class Initialized
INFO - 2019-11-11 06:21:56 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:56 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:56 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:56 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:56 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:56 --> Controller Class Initialized
INFO - 2019-11-11 06:21:58 --> Config Class Initialized
INFO - 2019-11-11 06:21:58 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:21:58 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:21:58 --> Utf8 Class Initialized
INFO - 2019-11-11 06:21:58 --> URI Class Initialized
INFO - 2019-11-11 06:21:58 --> Router Class Initialized
INFO - 2019-11-11 06:21:58 --> Output Class Initialized
INFO - 2019-11-11 06:21:58 --> Security Class Initialized
DEBUG - 2019-11-11 06:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:21:58 --> Input Class Initialized
INFO - 2019-11-11 06:21:58 --> Language Class Initialized
INFO - 2019-11-11 06:21:58 --> Language Class Initialized
INFO - 2019-11-11 06:21:58 --> Config Class Initialized
INFO - 2019-11-11 06:21:58 --> Loader Class Initialized
INFO - 2019-11-11 06:21:58 --> Helper loaded: url_helper
INFO - 2019-11-11 06:21:58 --> Helper loaded: file_helper
INFO - 2019-11-11 06:21:58 --> Helper loaded: form_helper
INFO - 2019-11-11 06:21:58 --> Helper loaded: my_helper
INFO - 2019-11-11 06:21:58 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:21:58 --> Controller Class Initialized
INFO - 2019-11-11 06:22:01 --> Config Class Initialized
INFO - 2019-11-11 06:22:01 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:22:01 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:22:01 --> Utf8 Class Initialized
INFO - 2019-11-11 06:22:01 --> URI Class Initialized
INFO - 2019-11-11 06:22:01 --> Router Class Initialized
INFO - 2019-11-11 06:22:01 --> Output Class Initialized
INFO - 2019-11-11 06:22:01 --> Security Class Initialized
DEBUG - 2019-11-11 06:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:22:01 --> Input Class Initialized
INFO - 2019-11-11 06:22:01 --> Language Class Initialized
INFO - 2019-11-11 06:22:01 --> Language Class Initialized
INFO - 2019-11-11 06:22:01 --> Config Class Initialized
INFO - 2019-11-11 06:22:01 --> Loader Class Initialized
INFO - 2019-11-11 06:22:01 --> Helper loaded: url_helper
INFO - 2019-11-11 06:22:01 --> Helper loaded: file_helper
INFO - 2019-11-11 06:22:01 --> Helper loaded: form_helper
INFO - 2019-11-11 06:22:01 --> Helper loaded: my_helper
INFO - 2019-11-11 06:22:01 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:22:01 --> Controller Class Initialized
INFO - 2019-11-11 06:22:03 --> Config Class Initialized
INFO - 2019-11-11 06:22:03 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:22:03 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:22:03 --> Utf8 Class Initialized
INFO - 2019-11-11 06:22:03 --> URI Class Initialized
INFO - 2019-11-11 06:22:03 --> Router Class Initialized
INFO - 2019-11-11 06:22:03 --> Output Class Initialized
INFO - 2019-11-11 06:22:03 --> Security Class Initialized
DEBUG - 2019-11-11 06:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:22:03 --> Input Class Initialized
INFO - 2019-11-11 06:22:03 --> Language Class Initialized
INFO - 2019-11-11 06:22:03 --> Language Class Initialized
INFO - 2019-11-11 06:22:03 --> Config Class Initialized
INFO - 2019-11-11 06:22:03 --> Loader Class Initialized
INFO - 2019-11-11 06:22:03 --> Helper loaded: url_helper
INFO - 2019-11-11 06:22:03 --> Helper loaded: file_helper
INFO - 2019-11-11 06:22:03 --> Helper loaded: form_helper
INFO - 2019-11-11 06:22:03 --> Helper loaded: my_helper
INFO - 2019-11-11 06:22:03 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:22:03 --> Controller Class Initialized
INFO - 2019-11-11 06:22:05 --> Config Class Initialized
INFO - 2019-11-11 06:22:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:22:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:22:05 --> Utf8 Class Initialized
INFO - 2019-11-11 06:22:05 --> URI Class Initialized
INFO - 2019-11-11 06:22:05 --> Router Class Initialized
INFO - 2019-11-11 06:22:05 --> Output Class Initialized
INFO - 2019-11-11 06:22:05 --> Security Class Initialized
DEBUG - 2019-11-11 06:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:22:05 --> Input Class Initialized
INFO - 2019-11-11 06:22:05 --> Language Class Initialized
INFO - 2019-11-11 06:22:06 --> Language Class Initialized
INFO - 2019-11-11 06:22:06 --> Config Class Initialized
INFO - 2019-11-11 06:22:06 --> Loader Class Initialized
INFO - 2019-11-11 06:22:06 --> Helper loaded: url_helper
INFO - 2019-11-11 06:22:06 --> Helper loaded: file_helper
INFO - 2019-11-11 06:22:06 --> Helper loaded: form_helper
INFO - 2019-11-11 06:22:06 --> Helper loaded: my_helper
INFO - 2019-11-11 06:22:06 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:22:06 --> Controller Class Initialized
INFO - 2019-11-11 06:46:54 --> Config Class Initialized
INFO - 2019-11-11 06:46:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:46:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:46:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:46:54 --> URI Class Initialized
INFO - 2019-11-11 06:46:54 --> Router Class Initialized
INFO - 2019-11-11 06:46:54 --> Output Class Initialized
INFO - 2019-11-11 06:46:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:46:54 --> Input Class Initialized
INFO - 2019-11-11 06:46:54 --> Language Class Initialized
INFO - 2019-11-11 06:46:54 --> Language Class Initialized
INFO - 2019-11-11 06:46:54 --> Config Class Initialized
INFO - 2019-11-11 06:46:54 --> Loader Class Initialized
INFO - 2019-11-11 06:46:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:46:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:46:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:46:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:46:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:46:54 --> Controller Class Initialized
DEBUG - 2019-11-11 06:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:46:54 --> Final output sent to browser
DEBUG - 2019-11-11 06:46:54 --> Total execution time: 0.0850
INFO - 2019-11-11 06:47:18 --> Config Class Initialized
INFO - 2019-11-11 06:47:18 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:18 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:18 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:18 --> URI Class Initialized
INFO - 2019-11-11 06:47:18 --> Router Class Initialized
INFO - 2019-11-11 06:47:18 --> Output Class Initialized
INFO - 2019-11-11 06:47:18 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:18 --> Input Class Initialized
INFO - 2019-11-11 06:47:18 --> Language Class Initialized
INFO - 2019-11-11 06:47:18 --> Language Class Initialized
INFO - 2019-11-11 06:47:18 --> Config Class Initialized
INFO - 2019-11-11 06:47:18 --> Loader Class Initialized
INFO - 2019-11-11 06:47:18 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:18 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:18 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:18 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:18 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:18 --> Controller Class Initialized
INFO - 2019-11-11 06:47:18 --> Config Class Initialized
INFO - 2019-11-11 06:47:18 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:18 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:18 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:18 --> URI Class Initialized
INFO - 2019-11-11 06:47:18 --> Router Class Initialized
INFO - 2019-11-11 06:47:18 --> Output Class Initialized
INFO - 2019-11-11 06:47:18 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:18 --> Input Class Initialized
INFO - 2019-11-11 06:47:18 --> Language Class Initialized
INFO - 2019-11-11 06:47:18 --> Language Class Initialized
INFO - 2019-11-11 06:47:18 --> Config Class Initialized
INFO - 2019-11-11 06:47:18 --> Loader Class Initialized
INFO - 2019-11-11 06:47:18 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:18 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:18 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:18 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:18 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:18 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:47:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:18 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:18 --> Total execution time: 0.0667
INFO - 2019-11-11 06:47:18 --> Config Class Initialized
INFO - 2019-11-11 06:47:18 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:18 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:18 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:18 --> URI Class Initialized
INFO - 2019-11-11 06:47:18 --> Router Class Initialized
INFO - 2019-11-11 06:47:18 --> Output Class Initialized
INFO - 2019-11-11 06:47:18 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:18 --> Input Class Initialized
INFO - 2019-11-11 06:47:18 --> Language Class Initialized
INFO - 2019-11-11 06:47:18 --> Language Class Initialized
INFO - 2019-11-11 06:47:18 --> Config Class Initialized
INFO - 2019-11-11 06:47:18 --> Loader Class Initialized
INFO - 2019-11-11 06:47:18 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:18 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:18 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:18 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:18 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:18 --> Controller Class Initialized
INFO - 2019-11-11 06:47:21 --> Config Class Initialized
INFO - 2019-11-11 06:47:21 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:21 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:21 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:21 --> URI Class Initialized
INFO - 2019-11-11 06:47:21 --> Router Class Initialized
INFO - 2019-11-11 06:47:21 --> Output Class Initialized
INFO - 2019-11-11 06:47:21 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:21 --> Input Class Initialized
INFO - 2019-11-11 06:47:21 --> Language Class Initialized
INFO - 2019-11-11 06:47:21 --> Language Class Initialized
INFO - 2019-11-11 06:47:21 --> Config Class Initialized
INFO - 2019-11-11 06:47:21 --> Loader Class Initialized
INFO - 2019-11-11 06:47:21 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:21 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:21 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:21 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:21 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:21 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:21 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:21 --> Total execution time: 0.0914
INFO - 2019-11-11 06:47:26 --> Config Class Initialized
INFO - 2019-11-11 06:47:26 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:26 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:26 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:26 --> URI Class Initialized
INFO - 2019-11-11 06:47:26 --> Router Class Initialized
INFO - 2019-11-11 06:47:26 --> Output Class Initialized
INFO - 2019-11-11 06:47:26 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:26 --> Input Class Initialized
INFO - 2019-11-11 06:47:26 --> Language Class Initialized
INFO - 2019-11-11 06:47:26 --> Language Class Initialized
INFO - 2019-11-11 06:47:26 --> Config Class Initialized
INFO - 2019-11-11 06:47:26 --> Loader Class Initialized
INFO - 2019-11-11 06:47:26 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:26 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:26 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:26 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:26 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:26 --> Controller Class Initialized
INFO - 2019-11-11 06:47:26 --> Config Class Initialized
INFO - 2019-11-11 06:47:26 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:26 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:26 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:26 --> URI Class Initialized
INFO - 2019-11-11 06:47:26 --> Router Class Initialized
INFO - 2019-11-11 06:47:26 --> Output Class Initialized
INFO - 2019-11-11 06:47:26 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:26 --> Input Class Initialized
INFO - 2019-11-11 06:47:26 --> Language Class Initialized
INFO - 2019-11-11 06:47:26 --> Language Class Initialized
INFO - 2019-11-11 06:47:26 --> Config Class Initialized
INFO - 2019-11-11 06:47:26 --> Loader Class Initialized
INFO - 2019-11-11 06:47:26 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:26 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:26 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:26 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:26 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:26 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:47:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:26 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:26 --> Total execution time: 0.0466
INFO - 2019-11-11 06:47:30 --> Config Class Initialized
INFO - 2019-11-11 06:47:30 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:30 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:30 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:30 --> URI Class Initialized
INFO - 2019-11-11 06:47:30 --> Router Class Initialized
INFO - 2019-11-11 06:47:30 --> Output Class Initialized
INFO - 2019-11-11 06:47:30 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:30 --> Input Class Initialized
INFO - 2019-11-11 06:47:30 --> Language Class Initialized
INFO - 2019-11-11 06:47:30 --> Language Class Initialized
INFO - 2019-11-11 06:47:30 --> Config Class Initialized
INFO - 2019-11-11 06:47:30 --> Loader Class Initialized
INFO - 2019-11-11 06:47:30 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:30 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:30 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:30 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:30 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:30 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:30 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:30 --> Total execution time: 0.0897
INFO - 2019-11-11 06:47:34 --> Config Class Initialized
INFO - 2019-11-11 06:47:34 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:34 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:34 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:34 --> URI Class Initialized
INFO - 2019-11-11 06:47:34 --> Router Class Initialized
INFO - 2019-11-11 06:47:34 --> Output Class Initialized
INFO - 2019-11-11 06:47:34 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:34 --> Input Class Initialized
INFO - 2019-11-11 06:47:34 --> Language Class Initialized
INFO - 2019-11-11 06:47:34 --> Language Class Initialized
INFO - 2019-11-11 06:47:34 --> Config Class Initialized
INFO - 2019-11-11 06:47:34 --> Loader Class Initialized
INFO - 2019-11-11 06:47:34 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:34 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:34 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:34 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:34 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:34 --> Controller Class Initialized
INFO - 2019-11-11 06:47:35 --> Config Class Initialized
INFO - 2019-11-11 06:47:35 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:35 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:35 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:35 --> URI Class Initialized
INFO - 2019-11-11 06:47:35 --> Router Class Initialized
INFO - 2019-11-11 06:47:35 --> Output Class Initialized
INFO - 2019-11-11 06:47:35 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:35 --> Input Class Initialized
INFO - 2019-11-11 06:47:35 --> Language Class Initialized
INFO - 2019-11-11 06:47:35 --> Language Class Initialized
INFO - 2019-11-11 06:47:35 --> Config Class Initialized
INFO - 2019-11-11 06:47:35 --> Loader Class Initialized
INFO - 2019-11-11 06:47:35 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:35 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:35 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:35 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:35 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:35 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:35 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:35 --> Total execution time: 0.0644
INFO - 2019-11-11 06:47:35 --> Config Class Initialized
INFO - 2019-11-11 06:47:35 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:35 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:35 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:35 --> URI Class Initialized
INFO - 2019-11-11 06:47:35 --> Router Class Initialized
INFO - 2019-11-11 06:47:35 --> Output Class Initialized
INFO - 2019-11-11 06:47:35 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:35 --> Input Class Initialized
INFO - 2019-11-11 06:47:35 --> Language Class Initialized
INFO - 2019-11-11 06:47:35 --> Language Class Initialized
INFO - 2019-11-11 06:47:35 --> Config Class Initialized
INFO - 2019-11-11 06:47:35 --> Loader Class Initialized
INFO - 2019-11-11 06:47:35 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:35 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:35 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:35 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:35 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:35 --> Controller Class Initialized
INFO - 2019-11-11 06:47:37 --> Config Class Initialized
INFO - 2019-11-11 06:47:37 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:37 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:37 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:37 --> URI Class Initialized
INFO - 2019-11-11 06:47:37 --> Router Class Initialized
INFO - 2019-11-11 06:47:37 --> Output Class Initialized
INFO - 2019-11-11 06:47:37 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:37 --> Input Class Initialized
INFO - 2019-11-11 06:47:37 --> Language Class Initialized
INFO - 2019-11-11 06:47:37 --> Language Class Initialized
INFO - 2019-11-11 06:47:37 --> Config Class Initialized
INFO - 2019-11-11 06:47:37 --> Loader Class Initialized
INFO - 2019-11-11 06:47:37 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:37 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:37 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:37 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:37 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:37 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:47:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:37 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:37 --> Total execution time: 0.0904
INFO - 2019-11-11 06:47:41 --> Config Class Initialized
INFO - 2019-11-11 06:47:41 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:41 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:41 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:41 --> URI Class Initialized
INFO - 2019-11-11 06:47:41 --> Router Class Initialized
INFO - 2019-11-11 06:47:41 --> Output Class Initialized
INFO - 2019-11-11 06:47:41 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:41 --> Input Class Initialized
INFO - 2019-11-11 06:47:41 --> Language Class Initialized
INFO - 2019-11-11 06:47:42 --> Language Class Initialized
INFO - 2019-11-11 06:47:42 --> Config Class Initialized
INFO - 2019-11-11 06:47:42 --> Loader Class Initialized
INFO - 2019-11-11 06:47:42 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:42 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:42 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:42 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:42 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:42 --> Controller Class Initialized
INFO - 2019-11-11 06:47:42 --> Config Class Initialized
INFO - 2019-11-11 06:47:42 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:42 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:42 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:42 --> URI Class Initialized
INFO - 2019-11-11 06:47:42 --> Router Class Initialized
INFO - 2019-11-11 06:47:42 --> Output Class Initialized
INFO - 2019-11-11 06:47:42 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:42 --> Input Class Initialized
INFO - 2019-11-11 06:47:42 --> Language Class Initialized
INFO - 2019-11-11 06:47:42 --> Language Class Initialized
INFO - 2019-11-11 06:47:42 --> Config Class Initialized
INFO - 2019-11-11 06:47:42 --> Loader Class Initialized
INFO - 2019-11-11 06:47:42 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:42 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:42 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:42 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:42 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:42 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:47:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:42 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:42 --> Total execution time: 0.0659
INFO - 2019-11-11 06:47:44 --> Config Class Initialized
INFO - 2019-11-11 06:47:44 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:44 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:44 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:44 --> URI Class Initialized
INFO - 2019-11-11 06:47:44 --> Router Class Initialized
INFO - 2019-11-11 06:47:44 --> Output Class Initialized
INFO - 2019-11-11 06:47:44 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:44 --> Input Class Initialized
INFO - 2019-11-11 06:47:44 --> Language Class Initialized
INFO - 2019-11-11 06:47:44 --> Language Class Initialized
INFO - 2019-11-11 06:47:44 --> Config Class Initialized
INFO - 2019-11-11 06:47:44 --> Loader Class Initialized
INFO - 2019-11-11 06:47:44 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:44 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:44 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:44 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:44 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:44 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:47:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:44 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:44 --> Total execution time: 0.0967
INFO - 2019-11-11 06:47:54 --> Config Class Initialized
INFO - 2019-11-11 06:47:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:54 --> URI Class Initialized
INFO - 2019-11-11 06:47:54 --> Router Class Initialized
INFO - 2019-11-11 06:47:54 --> Output Class Initialized
INFO - 2019-11-11 06:47:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:54 --> Input Class Initialized
INFO - 2019-11-11 06:47:54 --> Language Class Initialized
INFO - 2019-11-11 06:47:54 --> Language Class Initialized
INFO - 2019-11-11 06:47:54 --> Config Class Initialized
INFO - 2019-11-11 06:47:54 --> Loader Class Initialized
INFO - 2019-11-11 06:47:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:54 --> Controller Class Initialized
INFO - 2019-11-11 06:47:54 --> Config Class Initialized
INFO - 2019-11-11 06:47:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:54 --> URI Class Initialized
INFO - 2019-11-11 06:47:54 --> Router Class Initialized
INFO - 2019-11-11 06:47:54 --> Output Class Initialized
INFO - 2019-11-11 06:47:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:54 --> Input Class Initialized
INFO - 2019-11-11 06:47:54 --> Language Class Initialized
INFO - 2019-11-11 06:47:54 --> Language Class Initialized
INFO - 2019-11-11 06:47:54 --> Config Class Initialized
INFO - 2019-11-11 06:47:54 --> Loader Class Initialized
INFO - 2019-11-11 06:47:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:54 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:54 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:54 --> Total execution time: 0.0520
INFO - 2019-11-11 06:47:54 --> Config Class Initialized
INFO - 2019-11-11 06:47:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:54 --> URI Class Initialized
INFO - 2019-11-11 06:47:54 --> Router Class Initialized
INFO - 2019-11-11 06:47:54 --> Output Class Initialized
INFO - 2019-11-11 06:47:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:54 --> Input Class Initialized
INFO - 2019-11-11 06:47:54 --> Language Class Initialized
INFO - 2019-11-11 06:47:54 --> Language Class Initialized
INFO - 2019-11-11 06:47:54 --> Config Class Initialized
INFO - 2019-11-11 06:47:54 --> Loader Class Initialized
INFO - 2019-11-11 06:47:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:54 --> Controller Class Initialized
INFO - 2019-11-11 06:47:56 --> Config Class Initialized
INFO - 2019-11-11 06:47:56 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:47:56 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:47:56 --> Utf8 Class Initialized
INFO - 2019-11-11 06:47:56 --> URI Class Initialized
INFO - 2019-11-11 06:47:56 --> Router Class Initialized
INFO - 2019-11-11 06:47:56 --> Output Class Initialized
INFO - 2019-11-11 06:47:56 --> Security Class Initialized
DEBUG - 2019-11-11 06:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:47:56 --> Input Class Initialized
INFO - 2019-11-11 06:47:56 --> Language Class Initialized
INFO - 2019-11-11 06:47:56 --> Language Class Initialized
INFO - 2019-11-11 06:47:56 --> Config Class Initialized
INFO - 2019-11-11 06:47:56 --> Loader Class Initialized
INFO - 2019-11-11 06:47:56 --> Helper loaded: url_helper
INFO - 2019-11-11 06:47:56 --> Helper loaded: file_helper
INFO - 2019-11-11 06:47:56 --> Helper loaded: form_helper
INFO - 2019-11-11 06:47:56 --> Helper loaded: my_helper
INFO - 2019-11-11 06:47:56 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:47:56 --> Controller Class Initialized
DEBUG - 2019-11-11 06:47:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:47:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:47:56 --> Final output sent to browser
DEBUG - 2019-11-11 06:47:56 --> Total execution time: 0.0951
INFO - 2019-11-11 06:48:03 --> Config Class Initialized
INFO - 2019-11-11 06:48:03 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:03 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:03 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:03 --> URI Class Initialized
INFO - 2019-11-11 06:48:03 --> Router Class Initialized
INFO - 2019-11-11 06:48:03 --> Output Class Initialized
INFO - 2019-11-11 06:48:03 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:03 --> Input Class Initialized
INFO - 2019-11-11 06:48:03 --> Language Class Initialized
INFO - 2019-11-11 06:48:03 --> Language Class Initialized
INFO - 2019-11-11 06:48:03 --> Config Class Initialized
INFO - 2019-11-11 06:48:03 --> Loader Class Initialized
INFO - 2019-11-11 06:48:03 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:03 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:03 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:03 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:03 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:03 --> Controller Class Initialized
INFO - 2019-11-11 06:48:03 --> Config Class Initialized
INFO - 2019-11-11 06:48:03 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:03 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:03 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:03 --> URI Class Initialized
INFO - 2019-11-11 06:48:03 --> Router Class Initialized
INFO - 2019-11-11 06:48:03 --> Output Class Initialized
INFO - 2019-11-11 06:48:03 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:03 --> Input Class Initialized
INFO - 2019-11-11 06:48:03 --> Language Class Initialized
INFO - 2019-11-11 06:48:03 --> Language Class Initialized
INFO - 2019-11-11 06:48:03 --> Config Class Initialized
INFO - 2019-11-11 06:48:03 --> Loader Class Initialized
INFO - 2019-11-11 06:48:03 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:03 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:03 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:03 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:03 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:03 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:48:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:03 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:03 --> Total execution time: 0.0876
INFO - 2019-11-11 06:48:05 --> Config Class Initialized
INFO - 2019-11-11 06:48:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:05 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:05 --> URI Class Initialized
INFO - 2019-11-11 06:48:05 --> Router Class Initialized
INFO - 2019-11-11 06:48:05 --> Output Class Initialized
INFO - 2019-11-11 06:48:05 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:05 --> Input Class Initialized
INFO - 2019-11-11 06:48:05 --> Language Class Initialized
INFO - 2019-11-11 06:48:05 --> Language Class Initialized
INFO - 2019-11-11 06:48:05 --> Config Class Initialized
INFO - 2019-11-11 06:48:05 --> Loader Class Initialized
INFO - 2019-11-11 06:48:05 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:05 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:05 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:05 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:05 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:05 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:05 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:05 --> Total execution time: 0.0709
INFO - 2019-11-11 06:48:10 --> Config Class Initialized
INFO - 2019-11-11 06:48:10 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:10 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:10 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:10 --> URI Class Initialized
INFO - 2019-11-11 06:48:10 --> Router Class Initialized
INFO - 2019-11-11 06:48:10 --> Output Class Initialized
INFO - 2019-11-11 06:48:10 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:10 --> Input Class Initialized
INFO - 2019-11-11 06:48:10 --> Language Class Initialized
INFO - 2019-11-11 06:48:10 --> Language Class Initialized
INFO - 2019-11-11 06:48:10 --> Config Class Initialized
INFO - 2019-11-11 06:48:10 --> Loader Class Initialized
INFO - 2019-11-11 06:48:10 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:10 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:10 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:10 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:10 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:10 --> Controller Class Initialized
INFO - 2019-11-11 06:48:10 --> Config Class Initialized
INFO - 2019-11-11 06:48:10 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:10 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:10 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:10 --> URI Class Initialized
INFO - 2019-11-11 06:48:10 --> Router Class Initialized
INFO - 2019-11-11 06:48:10 --> Output Class Initialized
INFO - 2019-11-11 06:48:10 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:10 --> Input Class Initialized
INFO - 2019-11-11 06:48:10 --> Language Class Initialized
INFO - 2019-11-11 06:48:10 --> Language Class Initialized
INFO - 2019-11-11 06:48:10 --> Config Class Initialized
INFO - 2019-11-11 06:48:10 --> Loader Class Initialized
INFO - 2019-11-11 06:48:10 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:10 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:10 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:10 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:10 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:10 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:48:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:10 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:10 --> Total execution time: 0.0599
INFO - 2019-11-11 06:48:10 --> Config Class Initialized
INFO - 2019-11-11 06:48:10 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:10 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:10 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:10 --> URI Class Initialized
INFO - 2019-11-11 06:48:10 --> Router Class Initialized
INFO - 2019-11-11 06:48:10 --> Output Class Initialized
INFO - 2019-11-11 06:48:10 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:10 --> Input Class Initialized
INFO - 2019-11-11 06:48:10 --> Language Class Initialized
INFO - 2019-11-11 06:48:10 --> Language Class Initialized
INFO - 2019-11-11 06:48:10 --> Config Class Initialized
INFO - 2019-11-11 06:48:10 --> Loader Class Initialized
INFO - 2019-11-11 06:48:10 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:10 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:10 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:10 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:10 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:10 --> Controller Class Initialized
INFO - 2019-11-11 06:48:12 --> Config Class Initialized
INFO - 2019-11-11 06:48:12 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:12 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:12 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:12 --> URI Class Initialized
INFO - 2019-11-11 06:48:12 --> Router Class Initialized
INFO - 2019-11-11 06:48:12 --> Output Class Initialized
INFO - 2019-11-11 06:48:12 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:12 --> Input Class Initialized
INFO - 2019-11-11 06:48:12 --> Language Class Initialized
INFO - 2019-11-11 06:48:12 --> Language Class Initialized
INFO - 2019-11-11 06:48:12 --> Config Class Initialized
INFO - 2019-11-11 06:48:12 --> Loader Class Initialized
INFO - 2019-11-11 06:48:12 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:12 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:12 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:12 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:12 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:12 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:48:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:12 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:12 --> Total execution time: 0.0869
INFO - 2019-11-11 06:48:17 --> Config Class Initialized
INFO - 2019-11-11 06:48:17 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:17 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:17 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:17 --> URI Class Initialized
INFO - 2019-11-11 06:48:17 --> Router Class Initialized
INFO - 2019-11-11 06:48:17 --> Output Class Initialized
INFO - 2019-11-11 06:48:17 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:17 --> Input Class Initialized
INFO - 2019-11-11 06:48:17 --> Language Class Initialized
INFO - 2019-11-11 06:48:17 --> Language Class Initialized
INFO - 2019-11-11 06:48:17 --> Config Class Initialized
INFO - 2019-11-11 06:48:17 --> Loader Class Initialized
INFO - 2019-11-11 06:48:17 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:17 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:17 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:17 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:17 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:17 --> Controller Class Initialized
INFO - 2019-11-11 06:48:17 --> Config Class Initialized
INFO - 2019-11-11 06:48:17 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:17 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:17 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:17 --> URI Class Initialized
INFO - 2019-11-11 06:48:17 --> Router Class Initialized
INFO - 2019-11-11 06:48:17 --> Output Class Initialized
INFO - 2019-11-11 06:48:17 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:17 --> Input Class Initialized
INFO - 2019-11-11 06:48:17 --> Language Class Initialized
INFO - 2019-11-11 06:48:17 --> Language Class Initialized
INFO - 2019-11-11 06:48:17 --> Config Class Initialized
INFO - 2019-11-11 06:48:17 --> Loader Class Initialized
INFO - 2019-11-11 06:48:17 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:17 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:17 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:17 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:17 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:17 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:48:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:17 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:17 --> Total execution time: 0.0456
INFO - 2019-11-11 06:48:21 --> Config Class Initialized
INFO - 2019-11-11 06:48:21 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:21 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:21 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:21 --> URI Class Initialized
INFO - 2019-11-11 06:48:21 --> Router Class Initialized
INFO - 2019-11-11 06:48:21 --> Output Class Initialized
INFO - 2019-11-11 06:48:21 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:21 --> Input Class Initialized
INFO - 2019-11-11 06:48:21 --> Language Class Initialized
INFO - 2019-11-11 06:48:21 --> Language Class Initialized
INFO - 2019-11-11 06:48:21 --> Config Class Initialized
INFO - 2019-11-11 06:48:22 --> Loader Class Initialized
INFO - 2019-11-11 06:48:22 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:22 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:22 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:22 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:22 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:22 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:22 --> Total execution time: 0.0776
INFO - 2019-11-11 06:48:29 --> Config Class Initialized
INFO - 2019-11-11 06:48:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:29 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:29 --> URI Class Initialized
INFO - 2019-11-11 06:48:29 --> Router Class Initialized
INFO - 2019-11-11 06:48:29 --> Output Class Initialized
INFO - 2019-11-11 06:48:29 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:29 --> Input Class Initialized
INFO - 2019-11-11 06:48:29 --> Language Class Initialized
INFO - 2019-11-11 06:48:29 --> Language Class Initialized
INFO - 2019-11-11 06:48:29 --> Config Class Initialized
INFO - 2019-11-11 06:48:29 --> Loader Class Initialized
INFO - 2019-11-11 06:48:29 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:29 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:29 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:29 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:29 --> Controller Class Initialized
INFO - 2019-11-11 06:48:29 --> Config Class Initialized
INFO - 2019-11-11 06:48:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:29 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:29 --> URI Class Initialized
INFO - 2019-11-11 06:48:29 --> Router Class Initialized
INFO - 2019-11-11 06:48:29 --> Output Class Initialized
INFO - 2019-11-11 06:48:29 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:29 --> Input Class Initialized
INFO - 2019-11-11 06:48:29 --> Language Class Initialized
INFO - 2019-11-11 06:48:29 --> Language Class Initialized
INFO - 2019-11-11 06:48:29 --> Config Class Initialized
INFO - 2019-11-11 06:48:29 --> Loader Class Initialized
INFO - 2019-11-11 06:48:29 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:29 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:29 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:29 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:29 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:29 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:29 --> Total execution time: 0.0894
INFO - 2019-11-11 06:48:29 --> Config Class Initialized
INFO - 2019-11-11 06:48:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:29 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:29 --> URI Class Initialized
INFO - 2019-11-11 06:48:29 --> Router Class Initialized
INFO - 2019-11-11 06:48:29 --> Output Class Initialized
INFO - 2019-11-11 06:48:29 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:29 --> Input Class Initialized
INFO - 2019-11-11 06:48:29 --> Language Class Initialized
INFO - 2019-11-11 06:48:29 --> Language Class Initialized
INFO - 2019-11-11 06:48:29 --> Config Class Initialized
INFO - 2019-11-11 06:48:29 --> Loader Class Initialized
INFO - 2019-11-11 06:48:29 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:29 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:29 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:29 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:29 --> Controller Class Initialized
INFO - 2019-11-11 06:48:32 --> Config Class Initialized
INFO - 2019-11-11 06:48:32 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:32 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:32 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:32 --> URI Class Initialized
INFO - 2019-11-11 06:48:32 --> Router Class Initialized
INFO - 2019-11-11 06:48:32 --> Output Class Initialized
INFO - 2019-11-11 06:48:32 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:32 --> Input Class Initialized
INFO - 2019-11-11 06:48:32 --> Language Class Initialized
INFO - 2019-11-11 06:48:32 --> Language Class Initialized
INFO - 2019-11-11 06:48:32 --> Config Class Initialized
INFO - 2019-11-11 06:48:32 --> Loader Class Initialized
INFO - 2019-11-11 06:48:32 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:32 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:32 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:32 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:32 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:32 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:48:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:32 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:32 --> Total execution time: 0.0954
INFO - 2019-11-11 06:48:36 --> Config Class Initialized
INFO - 2019-11-11 06:48:36 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:36 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:36 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:36 --> URI Class Initialized
INFO - 2019-11-11 06:48:36 --> Router Class Initialized
INFO - 2019-11-11 06:48:36 --> Output Class Initialized
INFO - 2019-11-11 06:48:36 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:36 --> Input Class Initialized
INFO - 2019-11-11 06:48:36 --> Language Class Initialized
INFO - 2019-11-11 06:48:36 --> Language Class Initialized
INFO - 2019-11-11 06:48:36 --> Config Class Initialized
INFO - 2019-11-11 06:48:36 --> Loader Class Initialized
INFO - 2019-11-11 06:48:36 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:36 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:36 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:36 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:36 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:36 --> Controller Class Initialized
INFO - 2019-11-11 06:48:36 --> Config Class Initialized
INFO - 2019-11-11 06:48:36 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:36 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:36 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:36 --> URI Class Initialized
INFO - 2019-11-11 06:48:36 --> Router Class Initialized
INFO - 2019-11-11 06:48:36 --> Output Class Initialized
INFO - 2019-11-11 06:48:36 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:36 --> Input Class Initialized
INFO - 2019-11-11 06:48:36 --> Language Class Initialized
INFO - 2019-11-11 06:48:36 --> Language Class Initialized
INFO - 2019-11-11 06:48:36 --> Config Class Initialized
INFO - 2019-11-11 06:48:36 --> Loader Class Initialized
INFO - 2019-11-11 06:48:36 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:36 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:36 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:36 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:36 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:36 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:48:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:36 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:36 --> Total execution time: 0.0648
INFO - 2019-11-11 06:48:40 --> Config Class Initialized
INFO - 2019-11-11 06:48:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:40 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:40 --> URI Class Initialized
INFO - 2019-11-11 06:48:40 --> Router Class Initialized
INFO - 2019-11-11 06:48:40 --> Output Class Initialized
INFO - 2019-11-11 06:48:40 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:40 --> Input Class Initialized
INFO - 2019-11-11 06:48:40 --> Language Class Initialized
INFO - 2019-11-11 06:48:40 --> Language Class Initialized
INFO - 2019-11-11 06:48:40 --> Config Class Initialized
INFO - 2019-11-11 06:48:40 --> Loader Class Initialized
INFO - 2019-11-11 06:48:40 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:40 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:40 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:40 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:40 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:40 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:40 --> Total execution time: 0.0752
INFO - 2019-11-11 06:48:45 --> Config Class Initialized
INFO - 2019-11-11 06:48:45 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:45 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:45 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:45 --> URI Class Initialized
INFO - 2019-11-11 06:48:45 --> Router Class Initialized
INFO - 2019-11-11 06:48:45 --> Output Class Initialized
INFO - 2019-11-11 06:48:45 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:45 --> Input Class Initialized
INFO - 2019-11-11 06:48:45 --> Language Class Initialized
INFO - 2019-11-11 06:48:45 --> Language Class Initialized
INFO - 2019-11-11 06:48:45 --> Config Class Initialized
INFO - 2019-11-11 06:48:45 --> Loader Class Initialized
INFO - 2019-11-11 06:48:45 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:45 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:45 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:45 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:45 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:45 --> Controller Class Initialized
INFO - 2019-11-11 06:48:45 --> Config Class Initialized
INFO - 2019-11-11 06:48:45 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:45 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:45 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:45 --> URI Class Initialized
INFO - 2019-11-11 06:48:45 --> Router Class Initialized
INFO - 2019-11-11 06:48:45 --> Output Class Initialized
INFO - 2019-11-11 06:48:45 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:45 --> Input Class Initialized
INFO - 2019-11-11 06:48:45 --> Language Class Initialized
INFO - 2019-11-11 06:48:45 --> Language Class Initialized
INFO - 2019-11-11 06:48:45 --> Config Class Initialized
INFO - 2019-11-11 06:48:45 --> Loader Class Initialized
INFO - 2019-11-11 06:48:45 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:45 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:45 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:45 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:45 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:45 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:48:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:45 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:45 --> Total execution time: 0.0658
INFO - 2019-11-11 06:48:45 --> Config Class Initialized
INFO - 2019-11-11 06:48:45 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:45 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:45 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:45 --> URI Class Initialized
INFO - 2019-11-11 06:48:45 --> Router Class Initialized
INFO - 2019-11-11 06:48:45 --> Output Class Initialized
INFO - 2019-11-11 06:48:45 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:45 --> Input Class Initialized
INFO - 2019-11-11 06:48:45 --> Language Class Initialized
INFO - 2019-11-11 06:48:45 --> Language Class Initialized
INFO - 2019-11-11 06:48:45 --> Config Class Initialized
INFO - 2019-11-11 06:48:45 --> Loader Class Initialized
INFO - 2019-11-11 06:48:45 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:45 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:45 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:45 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:45 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:45 --> Controller Class Initialized
INFO - 2019-11-11 06:48:47 --> Config Class Initialized
INFO - 2019-11-11 06:48:47 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:47 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:47 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:47 --> URI Class Initialized
INFO - 2019-11-11 06:48:47 --> Router Class Initialized
INFO - 2019-11-11 06:48:47 --> Output Class Initialized
INFO - 2019-11-11 06:48:47 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:47 --> Input Class Initialized
INFO - 2019-11-11 06:48:47 --> Language Class Initialized
INFO - 2019-11-11 06:48:47 --> Language Class Initialized
INFO - 2019-11-11 06:48:47 --> Config Class Initialized
INFO - 2019-11-11 06:48:47 --> Loader Class Initialized
INFO - 2019-11-11 06:48:47 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:47 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:47 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:47 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:47 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:47 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:48:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:47 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:47 --> Total execution time: 0.0836
INFO - 2019-11-11 06:48:52 --> Config Class Initialized
INFO - 2019-11-11 06:48:52 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:52 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:52 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:52 --> URI Class Initialized
INFO - 2019-11-11 06:48:52 --> Router Class Initialized
INFO - 2019-11-11 06:48:52 --> Output Class Initialized
INFO - 2019-11-11 06:48:52 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:52 --> Input Class Initialized
INFO - 2019-11-11 06:48:52 --> Language Class Initialized
INFO - 2019-11-11 06:48:52 --> Language Class Initialized
INFO - 2019-11-11 06:48:52 --> Config Class Initialized
INFO - 2019-11-11 06:48:52 --> Loader Class Initialized
INFO - 2019-11-11 06:48:52 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:52 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:52 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:52 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:52 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:52 --> Controller Class Initialized
INFO - 2019-11-11 06:48:52 --> Config Class Initialized
INFO - 2019-11-11 06:48:52 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:52 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:52 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:52 --> URI Class Initialized
INFO - 2019-11-11 06:48:52 --> Router Class Initialized
INFO - 2019-11-11 06:48:52 --> Output Class Initialized
INFO - 2019-11-11 06:48:52 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:52 --> Input Class Initialized
INFO - 2019-11-11 06:48:52 --> Language Class Initialized
INFO - 2019-11-11 06:48:52 --> Language Class Initialized
INFO - 2019-11-11 06:48:52 --> Config Class Initialized
INFO - 2019-11-11 06:48:52 --> Loader Class Initialized
INFO - 2019-11-11 06:48:52 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:52 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:52 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:52 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:52 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:52 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:52 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:52 --> Total execution time: 0.0633
INFO - 2019-11-11 06:48:54 --> Config Class Initialized
INFO - 2019-11-11 06:48:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:54 --> URI Class Initialized
INFO - 2019-11-11 06:48:54 --> Router Class Initialized
INFO - 2019-11-11 06:48:54 --> Output Class Initialized
INFO - 2019-11-11 06:48:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:54 --> Input Class Initialized
INFO - 2019-11-11 06:48:54 --> Language Class Initialized
INFO - 2019-11-11 06:48:54 --> Language Class Initialized
INFO - 2019-11-11 06:48:54 --> Config Class Initialized
INFO - 2019-11-11 06:48:54 --> Loader Class Initialized
INFO - 2019-11-11 06:48:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:54 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:48:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:54 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:54 --> Total execution time: 0.0954
INFO - 2019-11-11 06:48:58 --> Config Class Initialized
INFO - 2019-11-11 06:48:58 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:58 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:58 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:58 --> URI Class Initialized
INFO - 2019-11-11 06:48:58 --> Router Class Initialized
INFO - 2019-11-11 06:48:58 --> Output Class Initialized
INFO - 2019-11-11 06:48:58 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:58 --> Input Class Initialized
INFO - 2019-11-11 06:48:58 --> Language Class Initialized
INFO - 2019-11-11 06:48:58 --> Language Class Initialized
INFO - 2019-11-11 06:48:59 --> Config Class Initialized
INFO - 2019-11-11 06:48:59 --> Loader Class Initialized
INFO - 2019-11-11 06:48:59 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:59 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:59 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:59 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:59 --> Controller Class Initialized
INFO - 2019-11-11 06:48:59 --> Config Class Initialized
INFO - 2019-11-11 06:48:59 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:59 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:59 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:59 --> URI Class Initialized
INFO - 2019-11-11 06:48:59 --> Router Class Initialized
INFO - 2019-11-11 06:48:59 --> Output Class Initialized
INFO - 2019-11-11 06:48:59 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:59 --> Input Class Initialized
INFO - 2019-11-11 06:48:59 --> Language Class Initialized
INFO - 2019-11-11 06:48:59 --> Language Class Initialized
INFO - 2019-11-11 06:48:59 --> Config Class Initialized
INFO - 2019-11-11 06:48:59 --> Loader Class Initialized
INFO - 2019-11-11 06:48:59 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:59 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:59 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:59 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:59 --> Controller Class Initialized
DEBUG - 2019-11-11 06:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:48:59 --> Final output sent to browser
DEBUG - 2019-11-11 06:48:59 --> Total execution time: 0.0783
INFO - 2019-11-11 06:48:59 --> Config Class Initialized
INFO - 2019-11-11 06:48:59 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:48:59 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:48:59 --> Utf8 Class Initialized
INFO - 2019-11-11 06:48:59 --> URI Class Initialized
INFO - 2019-11-11 06:48:59 --> Router Class Initialized
INFO - 2019-11-11 06:48:59 --> Output Class Initialized
INFO - 2019-11-11 06:48:59 --> Security Class Initialized
DEBUG - 2019-11-11 06:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:48:59 --> Input Class Initialized
INFO - 2019-11-11 06:48:59 --> Language Class Initialized
INFO - 2019-11-11 06:48:59 --> Language Class Initialized
INFO - 2019-11-11 06:48:59 --> Config Class Initialized
INFO - 2019-11-11 06:48:59 --> Loader Class Initialized
INFO - 2019-11-11 06:48:59 --> Helper loaded: url_helper
INFO - 2019-11-11 06:48:59 --> Helper loaded: file_helper
INFO - 2019-11-11 06:48:59 --> Helper loaded: form_helper
INFO - 2019-11-11 06:48:59 --> Helper loaded: my_helper
INFO - 2019-11-11 06:48:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:48:59 --> Controller Class Initialized
INFO - 2019-11-11 06:49:01 --> Config Class Initialized
INFO - 2019-11-11 06:49:01 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:01 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:01 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:01 --> URI Class Initialized
INFO - 2019-11-11 06:49:01 --> Router Class Initialized
INFO - 2019-11-11 06:49:01 --> Output Class Initialized
INFO - 2019-11-11 06:49:01 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:01 --> Input Class Initialized
INFO - 2019-11-11 06:49:01 --> Language Class Initialized
INFO - 2019-11-11 06:49:01 --> Language Class Initialized
INFO - 2019-11-11 06:49:01 --> Config Class Initialized
INFO - 2019-11-11 06:49:01 --> Loader Class Initialized
INFO - 2019-11-11 06:49:01 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:01 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:01 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:01 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:01 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:01 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:01 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:01 --> Total execution time: 0.0871
INFO - 2019-11-11 06:49:07 --> Config Class Initialized
INFO - 2019-11-11 06:49:07 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:07 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:07 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:07 --> URI Class Initialized
INFO - 2019-11-11 06:49:07 --> Router Class Initialized
INFO - 2019-11-11 06:49:07 --> Output Class Initialized
INFO - 2019-11-11 06:49:07 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:07 --> Input Class Initialized
INFO - 2019-11-11 06:49:07 --> Language Class Initialized
INFO - 2019-11-11 06:49:07 --> Language Class Initialized
INFO - 2019-11-11 06:49:07 --> Config Class Initialized
INFO - 2019-11-11 06:49:07 --> Loader Class Initialized
INFO - 2019-11-11 06:49:07 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:07 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:07 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:07 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:07 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:07 --> Controller Class Initialized
INFO - 2019-11-11 06:49:07 --> Config Class Initialized
INFO - 2019-11-11 06:49:07 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:07 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:07 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:07 --> URI Class Initialized
INFO - 2019-11-11 06:49:07 --> Router Class Initialized
INFO - 2019-11-11 06:49:07 --> Output Class Initialized
INFO - 2019-11-11 06:49:07 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:07 --> Input Class Initialized
INFO - 2019-11-11 06:49:07 --> Language Class Initialized
INFO - 2019-11-11 06:49:07 --> Language Class Initialized
INFO - 2019-11-11 06:49:07 --> Config Class Initialized
INFO - 2019-11-11 06:49:07 --> Loader Class Initialized
INFO - 2019-11-11 06:49:07 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:07 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:07 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:07 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:07 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:07 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:49:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:07 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:07 --> Total execution time: 0.0765
INFO - 2019-11-11 06:49:10 --> Config Class Initialized
INFO - 2019-11-11 06:49:10 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:10 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:10 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:10 --> URI Class Initialized
INFO - 2019-11-11 06:49:10 --> Router Class Initialized
INFO - 2019-11-11 06:49:10 --> Output Class Initialized
INFO - 2019-11-11 06:49:10 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:10 --> Input Class Initialized
INFO - 2019-11-11 06:49:10 --> Language Class Initialized
INFO - 2019-11-11 06:49:10 --> Language Class Initialized
INFO - 2019-11-11 06:49:10 --> Config Class Initialized
INFO - 2019-11-11 06:49:10 --> Loader Class Initialized
INFO - 2019-11-11 06:49:10 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:10 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:10 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:10 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:10 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:10 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:49:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:10 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:10 --> Total execution time: 0.0956
INFO - 2019-11-11 06:49:14 --> Config Class Initialized
INFO - 2019-11-11 06:49:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:14 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:14 --> URI Class Initialized
INFO - 2019-11-11 06:49:14 --> Router Class Initialized
INFO - 2019-11-11 06:49:14 --> Output Class Initialized
INFO - 2019-11-11 06:49:14 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:14 --> Input Class Initialized
INFO - 2019-11-11 06:49:14 --> Language Class Initialized
INFO - 2019-11-11 06:49:14 --> Language Class Initialized
INFO - 2019-11-11 06:49:14 --> Config Class Initialized
INFO - 2019-11-11 06:49:14 --> Loader Class Initialized
INFO - 2019-11-11 06:49:14 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:14 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:14 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:14 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:14 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:14 --> Controller Class Initialized
INFO - 2019-11-11 06:49:14 --> Config Class Initialized
INFO - 2019-11-11 06:49:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:14 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:14 --> URI Class Initialized
INFO - 2019-11-11 06:49:14 --> Router Class Initialized
INFO - 2019-11-11 06:49:14 --> Output Class Initialized
INFO - 2019-11-11 06:49:14 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:14 --> Input Class Initialized
INFO - 2019-11-11 06:49:14 --> Language Class Initialized
INFO - 2019-11-11 06:49:14 --> Language Class Initialized
INFO - 2019-11-11 06:49:14 --> Config Class Initialized
INFO - 2019-11-11 06:49:14 --> Loader Class Initialized
INFO - 2019-11-11 06:49:14 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:14 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:14 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:14 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:15 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:49:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:15 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:15 --> Total execution time: 0.0732
INFO - 2019-11-11 06:49:15 --> Config Class Initialized
INFO - 2019-11-11 06:49:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:15 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:15 --> URI Class Initialized
INFO - 2019-11-11 06:49:15 --> Router Class Initialized
INFO - 2019-11-11 06:49:15 --> Output Class Initialized
INFO - 2019-11-11 06:49:15 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:15 --> Input Class Initialized
INFO - 2019-11-11 06:49:15 --> Language Class Initialized
INFO - 2019-11-11 06:49:15 --> Language Class Initialized
INFO - 2019-11-11 06:49:15 --> Config Class Initialized
INFO - 2019-11-11 06:49:15 --> Loader Class Initialized
INFO - 2019-11-11 06:49:15 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:15 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:15 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:15 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:15 --> Controller Class Initialized
INFO - 2019-11-11 06:49:17 --> Config Class Initialized
INFO - 2019-11-11 06:49:17 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:17 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:17 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:17 --> URI Class Initialized
INFO - 2019-11-11 06:49:17 --> Router Class Initialized
INFO - 2019-11-11 06:49:17 --> Output Class Initialized
INFO - 2019-11-11 06:49:17 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:17 --> Input Class Initialized
INFO - 2019-11-11 06:49:17 --> Language Class Initialized
INFO - 2019-11-11 06:49:17 --> Language Class Initialized
INFO - 2019-11-11 06:49:17 --> Config Class Initialized
INFO - 2019-11-11 06:49:17 --> Loader Class Initialized
INFO - 2019-11-11 06:49:17 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:17 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:17 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:17 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:17 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:17 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:17 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:17 --> Total execution time: 0.0675
INFO - 2019-11-11 06:49:22 --> Config Class Initialized
INFO - 2019-11-11 06:49:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:22 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:22 --> URI Class Initialized
INFO - 2019-11-11 06:49:22 --> Router Class Initialized
INFO - 2019-11-11 06:49:22 --> Output Class Initialized
INFO - 2019-11-11 06:49:22 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:22 --> Input Class Initialized
INFO - 2019-11-11 06:49:22 --> Language Class Initialized
INFO - 2019-11-11 06:49:22 --> Language Class Initialized
INFO - 2019-11-11 06:49:22 --> Config Class Initialized
INFO - 2019-11-11 06:49:22 --> Loader Class Initialized
INFO - 2019-11-11 06:49:22 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:22 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:22 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:22 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:22 --> Controller Class Initialized
INFO - 2019-11-11 06:49:22 --> Config Class Initialized
INFO - 2019-11-11 06:49:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:22 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:22 --> URI Class Initialized
INFO - 2019-11-11 06:49:22 --> Router Class Initialized
INFO - 2019-11-11 06:49:22 --> Output Class Initialized
INFO - 2019-11-11 06:49:22 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:22 --> Input Class Initialized
INFO - 2019-11-11 06:49:22 --> Language Class Initialized
INFO - 2019-11-11 06:49:22 --> Language Class Initialized
INFO - 2019-11-11 06:49:22 --> Config Class Initialized
INFO - 2019-11-11 06:49:22 --> Loader Class Initialized
INFO - 2019-11-11 06:49:22 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:22 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:22 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:22 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:22 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:49:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:22 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:22 --> Total execution time: 0.0541
INFO - 2019-11-11 06:49:24 --> Config Class Initialized
INFO - 2019-11-11 06:49:24 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:24 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:24 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:24 --> URI Class Initialized
INFO - 2019-11-11 06:49:24 --> Router Class Initialized
INFO - 2019-11-11 06:49:24 --> Output Class Initialized
INFO - 2019-11-11 06:49:24 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:24 --> Input Class Initialized
INFO - 2019-11-11 06:49:24 --> Language Class Initialized
INFO - 2019-11-11 06:49:24 --> Language Class Initialized
INFO - 2019-11-11 06:49:24 --> Config Class Initialized
INFO - 2019-11-11 06:49:24 --> Loader Class Initialized
INFO - 2019-11-11 06:49:24 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:24 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:24 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:24 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:24 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:24 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:49:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:24 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:24 --> Total execution time: 0.0974
INFO - 2019-11-11 06:49:29 --> Config Class Initialized
INFO - 2019-11-11 06:49:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:29 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:29 --> URI Class Initialized
INFO - 2019-11-11 06:49:29 --> Router Class Initialized
INFO - 2019-11-11 06:49:29 --> Output Class Initialized
INFO - 2019-11-11 06:49:29 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:29 --> Input Class Initialized
INFO - 2019-11-11 06:49:29 --> Language Class Initialized
INFO - 2019-11-11 06:49:29 --> Language Class Initialized
INFO - 2019-11-11 06:49:29 --> Config Class Initialized
INFO - 2019-11-11 06:49:29 --> Loader Class Initialized
INFO - 2019-11-11 06:49:29 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:29 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:29 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:29 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:29 --> Controller Class Initialized
INFO - 2019-11-11 06:49:29 --> Config Class Initialized
INFO - 2019-11-11 06:49:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:29 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:29 --> URI Class Initialized
INFO - 2019-11-11 06:49:29 --> Router Class Initialized
INFO - 2019-11-11 06:49:29 --> Output Class Initialized
INFO - 2019-11-11 06:49:29 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:29 --> Input Class Initialized
INFO - 2019-11-11 06:49:29 --> Language Class Initialized
INFO - 2019-11-11 06:49:29 --> Language Class Initialized
INFO - 2019-11-11 06:49:29 --> Config Class Initialized
INFO - 2019-11-11 06:49:29 --> Loader Class Initialized
INFO - 2019-11-11 06:49:29 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:29 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:29 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:29 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:29 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:49:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:29 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:29 --> Total execution time: 0.0671
INFO - 2019-11-11 06:49:29 --> Config Class Initialized
INFO - 2019-11-11 06:49:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:29 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:29 --> URI Class Initialized
INFO - 2019-11-11 06:49:29 --> Router Class Initialized
INFO - 2019-11-11 06:49:29 --> Output Class Initialized
INFO - 2019-11-11 06:49:29 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:29 --> Input Class Initialized
INFO - 2019-11-11 06:49:29 --> Language Class Initialized
INFO - 2019-11-11 06:49:29 --> Language Class Initialized
INFO - 2019-11-11 06:49:29 --> Config Class Initialized
INFO - 2019-11-11 06:49:29 --> Loader Class Initialized
INFO - 2019-11-11 06:49:29 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:29 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:29 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:29 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:29 --> Controller Class Initialized
INFO - 2019-11-11 06:49:32 --> Config Class Initialized
INFO - 2019-11-11 06:49:32 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:32 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:32 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:32 --> URI Class Initialized
INFO - 2019-11-11 06:49:32 --> Router Class Initialized
INFO - 2019-11-11 06:49:32 --> Output Class Initialized
INFO - 2019-11-11 06:49:32 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:32 --> Input Class Initialized
INFO - 2019-11-11 06:49:32 --> Language Class Initialized
INFO - 2019-11-11 06:49:32 --> Language Class Initialized
INFO - 2019-11-11 06:49:32 --> Config Class Initialized
INFO - 2019-11-11 06:49:32 --> Loader Class Initialized
INFO - 2019-11-11 06:49:32 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:32 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:32 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:32 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:32 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:32 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:32 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:32 --> Total execution time: 0.0980
INFO - 2019-11-11 06:49:38 --> Config Class Initialized
INFO - 2019-11-11 06:49:38 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:38 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:38 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:38 --> URI Class Initialized
INFO - 2019-11-11 06:49:38 --> Router Class Initialized
INFO - 2019-11-11 06:49:38 --> Output Class Initialized
INFO - 2019-11-11 06:49:38 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:38 --> Input Class Initialized
INFO - 2019-11-11 06:49:38 --> Language Class Initialized
INFO - 2019-11-11 06:49:38 --> Language Class Initialized
INFO - 2019-11-11 06:49:38 --> Config Class Initialized
INFO - 2019-11-11 06:49:38 --> Loader Class Initialized
INFO - 2019-11-11 06:49:38 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:38 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:38 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:38 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:38 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:38 --> Controller Class Initialized
INFO - 2019-11-11 06:49:38 --> Config Class Initialized
INFO - 2019-11-11 06:49:38 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:38 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:38 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:38 --> URI Class Initialized
INFO - 2019-11-11 06:49:38 --> Router Class Initialized
INFO - 2019-11-11 06:49:38 --> Output Class Initialized
INFO - 2019-11-11 06:49:38 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:38 --> Input Class Initialized
INFO - 2019-11-11 06:49:38 --> Language Class Initialized
INFO - 2019-11-11 06:49:38 --> Language Class Initialized
INFO - 2019-11-11 06:49:38 --> Config Class Initialized
INFO - 2019-11-11 06:49:38 --> Loader Class Initialized
INFO - 2019-11-11 06:49:38 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:38 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:38 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:38 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:38 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:38 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:49:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:38 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:38 --> Total execution time: 0.0859
INFO - 2019-11-11 06:49:40 --> Config Class Initialized
INFO - 2019-11-11 06:49:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:40 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:40 --> URI Class Initialized
INFO - 2019-11-11 06:49:40 --> Router Class Initialized
INFO - 2019-11-11 06:49:40 --> Output Class Initialized
INFO - 2019-11-11 06:49:40 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:40 --> Input Class Initialized
INFO - 2019-11-11 06:49:40 --> Language Class Initialized
INFO - 2019-11-11 06:49:40 --> Language Class Initialized
INFO - 2019-11-11 06:49:40 --> Config Class Initialized
INFO - 2019-11-11 06:49:40 --> Loader Class Initialized
INFO - 2019-11-11 06:49:40 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:40 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:40 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:40 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:40 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:40 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:40 --> Total execution time: 0.1013
INFO - 2019-11-11 06:49:45 --> Config Class Initialized
INFO - 2019-11-11 06:49:45 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:45 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:45 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:45 --> URI Class Initialized
INFO - 2019-11-11 06:49:45 --> Router Class Initialized
INFO - 2019-11-11 06:49:45 --> Output Class Initialized
INFO - 2019-11-11 06:49:45 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:45 --> Input Class Initialized
INFO - 2019-11-11 06:49:45 --> Language Class Initialized
INFO - 2019-11-11 06:49:45 --> Language Class Initialized
INFO - 2019-11-11 06:49:45 --> Config Class Initialized
INFO - 2019-11-11 06:49:45 --> Loader Class Initialized
INFO - 2019-11-11 06:49:45 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:45 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:45 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:45 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:45 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:45 --> Controller Class Initialized
INFO - 2019-11-11 06:49:45 --> Config Class Initialized
INFO - 2019-11-11 06:49:45 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:45 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:45 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:45 --> URI Class Initialized
INFO - 2019-11-11 06:49:45 --> Router Class Initialized
INFO - 2019-11-11 06:49:45 --> Output Class Initialized
INFO - 2019-11-11 06:49:45 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:45 --> Input Class Initialized
INFO - 2019-11-11 06:49:45 --> Language Class Initialized
INFO - 2019-11-11 06:49:45 --> Language Class Initialized
INFO - 2019-11-11 06:49:45 --> Config Class Initialized
INFO - 2019-11-11 06:49:45 --> Loader Class Initialized
INFO - 2019-11-11 06:49:45 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:45 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:45 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:45 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:45 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:45 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:49:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:45 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:45 --> Total execution time: 0.0676
INFO - 2019-11-11 06:49:45 --> Config Class Initialized
INFO - 2019-11-11 06:49:45 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:45 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:45 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:45 --> URI Class Initialized
INFO - 2019-11-11 06:49:45 --> Router Class Initialized
INFO - 2019-11-11 06:49:45 --> Output Class Initialized
INFO - 2019-11-11 06:49:45 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:45 --> Input Class Initialized
INFO - 2019-11-11 06:49:45 --> Language Class Initialized
INFO - 2019-11-11 06:49:45 --> Language Class Initialized
INFO - 2019-11-11 06:49:45 --> Config Class Initialized
INFO - 2019-11-11 06:49:45 --> Loader Class Initialized
INFO - 2019-11-11 06:49:45 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:45 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:45 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:45 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:45 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:45 --> Controller Class Initialized
INFO - 2019-11-11 06:49:47 --> Config Class Initialized
INFO - 2019-11-11 06:49:47 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:47 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:47 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:47 --> URI Class Initialized
INFO - 2019-11-11 06:49:47 --> Router Class Initialized
INFO - 2019-11-11 06:49:47 --> Output Class Initialized
INFO - 2019-11-11 06:49:47 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:47 --> Input Class Initialized
INFO - 2019-11-11 06:49:47 --> Language Class Initialized
INFO - 2019-11-11 06:49:47 --> Language Class Initialized
INFO - 2019-11-11 06:49:47 --> Config Class Initialized
INFO - 2019-11-11 06:49:47 --> Loader Class Initialized
INFO - 2019-11-11 06:49:47 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:47 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:47 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:47 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:47 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:47 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:49:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:47 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:47 --> Total execution time: 0.0906
INFO - 2019-11-11 06:49:53 --> Config Class Initialized
INFO - 2019-11-11 06:49:53 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:53 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:53 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:53 --> URI Class Initialized
INFO - 2019-11-11 06:49:53 --> Router Class Initialized
INFO - 2019-11-11 06:49:53 --> Output Class Initialized
INFO - 2019-11-11 06:49:53 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:53 --> Input Class Initialized
INFO - 2019-11-11 06:49:53 --> Language Class Initialized
INFO - 2019-11-11 06:49:53 --> Language Class Initialized
INFO - 2019-11-11 06:49:53 --> Config Class Initialized
INFO - 2019-11-11 06:49:53 --> Loader Class Initialized
INFO - 2019-11-11 06:49:53 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:53 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:53 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:53 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:53 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:53 --> Controller Class Initialized
INFO - 2019-11-11 06:49:53 --> Config Class Initialized
INFO - 2019-11-11 06:49:53 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:53 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:53 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:53 --> URI Class Initialized
INFO - 2019-11-11 06:49:53 --> Router Class Initialized
INFO - 2019-11-11 06:49:53 --> Output Class Initialized
INFO - 2019-11-11 06:49:53 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:53 --> Input Class Initialized
INFO - 2019-11-11 06:49:53 --> Language Class Initialized
INFO - 2019-11-11 06:49:53 --> Language Class Initialized
INFO - 2019-11-11 06:49:53 --> Config Class Initialized
INFO - 2019-11-11 06:49:53 --> Loader Class Initialized
INFO - 2019-11-11 06:49:53 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:53 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:53 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:53 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:53 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:53 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:53 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:53 --> Total execution time: 0.0763
INFO - 2019-11-11 06:49:56 --> Config Class Initialized
INFO - 2019-11-11 06:49:56 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:49:56 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:49:56 --> Utf8 Class Initialized
INFO - 2019-11-11 06:49:56 --> URI Class Initialized
INFO - 2019-11-11 06:49:56 --> Router Class Initialized
INFO - 2019-11-11 06:49:56 --> Output Class Initialized
INFO - 2019-11-11 06:49:56 --> Security Class Initialized
DEBUG - 2019-11-11 06:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:49:56 --> Input Class Initialized
INFO - 2019-11-11 06:49:56 --> Language Class Initialized
INFO - 2019-11-11 06:49:56 --> Language Class Initialized
INFO - 2019-11-11 06:49:56 --> Config Class Initialized
INFO - 2019-11-11 06:49:56 --> Loader Class Initialized
INFO - 2019-11-11 06:49:56 --> Helper loaded: url_helper
INFO - 2019-11-11 06:49:56 --> Helper loaded: file_helper
INFO - 2019-11-11 06:49:56 --> Helper loaded: form_helper
INFO - 2019-11-11 06:49:56 --> Helper loaded: my_helper
INFO - 2019-11-11 06:49:56 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:49:56 --> Controller Class Initialized
DEBUG - 2019-11-11 06:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:49:56 --> Final output sent to browser
DEBUG - 2019-11-11 06:49:56 --> Total execution time: 0.1021
INFO - 2019-11-11 06:50:05 --> Config Class Initialized
INFO - 2019-11-11 06:50:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:05 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:05 --> URI Class Initialized
INFO - 2019-11-11 06:50:05 --> Router Class Initialized
INFO - 2019-11-11 06:50:05 --> Output Class Initialized
INFO - 2019-11-11 06:50:05 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:05 --> Input Class Initialized
INFO - 2019-11-11 06:50:05 --> Language Class Initialized
INFO - 2019-11-11 06:50:05 --> Language Class Initialized
INFO - 2019-11-11 06:50:05 --> Config Class Initialized
INFO - 2019-11-11 06:50:05 --> Loader Class Initialized
INFO - 2019-11-11 06:50:05 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:05 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:05 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:05 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:05 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:05 --> Controller Class Initialized
INFO - 2019-11-11 06:50:05 --> Config Class Initialized
INFO - 2019-11-11 06:50:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:05 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:05 --> URI Class Initialized
INFO - 2019-11-11 06:50:05 --> Router Class Initialized
INFO - 2019-11-11 06:50:05 --> Output Class Initialized
INFO - 2019-11-11 06:50:05 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:05 --> Input Class Initialized
INFO - 2019-11-11 06:50:05 --> Language Class Initialized
INFO - 2019-11-11 06:50:05 --> Language Class Initialized
INFO - 2019-11-11 06:50:05 --> Config Class Initialized
INFO - 2019-11-11 06:50:05 --> Loader Class Initialized
INFO - 2019-11-11 06:50:05 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:05 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:05 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:05 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:05 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:05 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:05 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:05 --> Total execution time: 0.0543
INFO - 2019-11-11 06:50:05 --> Config Class Initialized
INFO - 2019-11-11 06:50:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:05 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:05 --> URI Class Initialized
INFO - 2019-11-11 06:50:05 --> Router Class Initialized
INFO - 2019-11-11 06:50:05 --> Output Class Initialized
INFO - 2019-11-11 06:50:05 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:05 --> Input Class Initialized
INFO - 2019-11-11 06:50:05 --> Language Class Initialized
INFO - 2019-11-11 06:50:05 --> Language Class Initialized
INFO - 2019-11-11 06:50:05 --> Config Class Initialized
INFO - 2019-11-11 06:50:05 --> Loader Class Initialized
INFO - 2019-11-11 06:50:05 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:05 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:05 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:05 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:05 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:05 --> Controller Class Initialized
INFO - 2019-11-11 06:50:08 --> Config Class Initialized
INFO - 2019-11-11 06:50:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:08 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:08 --> URI Class Initialized
INFO - 2019-11-11 06:50:08 --> Router Class Initialized
INFO - 2019-11-11 06:50:08 --> Output Class Initialized
INFO - 2019-11-11 06:50:08 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:08 --> Input Class Initialized
INFO - 2019-11-11 06:50:08 --> Language Class Initialized
INFO - 2019-11-11 06:50:08 --> Language Class Initialized
INFO - 2019-11-11 06:50:08 --> Config Class Initialized
INFO - 2019-11-11 06:50:08 --> Loader Class Initialized
INFO - 2019-11-11 06:50:08 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:08 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:08 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:08 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:08 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:08 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:08 --> Total execution time: 0.0963
INFO - 2019-11-11 06:50:14 --> Config Class Initialized
INFO - 2019-11-11 06:50:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:14 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:14 --> URI Class Initialized
INFO - 2019-11-11 06:50:14 --> Router Class Initialized
INFO - 2019-11-11 06:50:14 --> Output Class Initialized
INFO - 2019-11-11 06:50:14 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:14 --> Input Class Initialized
INFO - 2019-11-11 06:50:14 --> Language Class Initialized
INFO - 2019-11-11 06:50:14 --> Language Class Initialized
INFO - 2019-11-11 06:50:14 --> Config Class Initialized
INFO - 2019-11-11 06:50:14 --> Loader Class Initialized
INFO - 2019-11-11 06:50:14 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:14 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:14 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:14 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:14 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:14 --> Controller Class Initialized
INFO - 2019-11-11 06:50:14 --> Config Class Initialized
INFO - 2019-11-11 06:50:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:14 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:14 --> URI Class Initialized
INFO - 2019-11-11 06:50:14 --> Router Class Initialized
INFO - 2019-11-11 06:50:14 --> Output Class Initialized
INFO - 2019-11-11 06:50:14 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:14 --> Input Class Initialized
INFO - 2019-11-11 06:50:14 --> Language Class Initialized
INFO - 2019-11-11 06:50:14 --> Language Class Initialized
INFO - 2019-11-11 06:50:14 --> Config Class Initialized
INFO - 2019-11-11 06:50:14 --> Loader Class Initialized
INFO - 2019-11-11 06:50:14 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:14 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:14 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:14 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:14 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:14 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:50:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:14 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:14 --> Total execution time: 0.0597
INFO - 2019-11-11 06:50:16 --> Config Class Initialized
INFO - 2019-11-11 06:50:16 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:16 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:16 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:16 --> URI Class Initialized
INFO - 2019-11-11 06:50:16 --> Router Class Initialized
INFO - 2019-11-11 06:50:16 --> Output Class Initialized
INFO - 2019-11-11 06:50:16 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:16 --> Input Class Initialized
INFO - 2019-11-11 06:50:16 --> Language Class Initialized
INFO - 2019-11-11 06:50:16 --> Language Class Initialized
INFO - 2019-11-11 06:50:16 --> Config Class Initialized
INFO - 2019-11-11 06:50:16 --> Loader Class Initialized
INFO - 2019-11-11 06:50:16 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:16 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:16 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:16 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:16 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:16 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:50:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:16 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:16 --> Total execution time: 0.0704
INFO - 2019-11-11 06:50:22 --> Config Class Initialized
INFO - 2019-11-11 06:50:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:22 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:22 --> URI Class Initialized
INFO - 2019-11-11 06:50:22 --> Router Class Initialized
INFO - 2019-11-11 06:50:23 --> Output Class Initialized
INFO - 2019-11-11 06:50:23 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:23 --> Input Class Initialized
INFO - 2019-11-11 06:50:23 --> Language Class Initialized
INFO - 2019-11-11 06:50:23 --> Language Class Initialized
INFO - 2019-11-11 06:50:23 --> Config Class Initialized
INFO - 2019-11-11 06:50:23 --> Loader Class Initialized
INFO - 2019-11-11 06:50:23 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:23 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:23 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:23 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:23 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:23 --> Controller Class Initialized
INFO - 2019-11-11 06:50:23 --> Config Class Initialized
INFO - 2019-11-11 06:50:23 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:23 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:23 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:23 --> URI Class Initialized
INFO - 2019-11-11 06:50:23 --> Router Class Initialized
INFO - 2019-11-11 06:50:23 --> Output Class Initialized
INFO - 2019-11-11 06:50:23 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:23 --> Input Class Initialized
INFO - 2019-11-11 06:50:23 --> Language Class Initialized
INFO - 2019-11-11 06:50:23 --> Language Class Initialized
INFO - 2019-11-11 06:50:23 --> Config Class Initialized
INFO - 2019-11-11 06:50:23 --> Loader Class Initialized
INFO - 2019-11-11 06:50:23 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:23 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:23 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:23 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:23 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:23 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:50:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:23 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:23 --> Total execution time: 0.0532
INFO - 2019-11-11 06:50:23 --> Config Class Initialized
INFO - 2019-11-11 06:50:23 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:23 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:23 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:23 --> URI Class Initialized
INFO - 2019-11-11 06:50:23 --> Router Class Initialized
INFO - 2019-11-11 06:50:23 --> Output Class Initialized
INFO - 2019-11-11 06:50:23 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:23 --> Input Class Initialized
INFO - 2019-11-11 06:50:23 --> Language Class Initialized
INFO - 2019-11-11 06:50:23 --> Language Class Initialized
INFO - 2019-11-11 06:50:23 --> Config Class Initialized
INFO - 2019-11-11 06:50:23 --> Loader Class Initialized
INFO - 2019-11-11 06:50:23 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:23 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:23 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:23 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:23 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:23 --> Controller Class Initialized
INFO - 2019-11-11 06:50:28 --> Config Class Initialized
INFO - 2019-11-11 06:50:28 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:28 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:28 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:28 --> URI Class Initialized
INFO - 2019-11-11 06:50:28 --> Router Class Initialized
INFO - 2019-11-11 06:50:28 --> Output Class Initialized
INFO - 2019-11-11 06:50:28 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:28 --> Input Class Initialized
INFO - 2019-11-11 06:50:28 --> Language Class Initialized
INFO - 2019-11-11 06:50:28 --> Language Class Initialized
INFO - 2019-11-11 06:50:28 --> Config Class Initialized
INFO - 2019-11-11 06:50:28 --> Loader Class Initialized
INFO - 2019-11-11 06:50:28 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:28 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:28 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:28 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:28 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:28 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:50:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:28 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:28 --> Total execution time: 0.0841
INFO - 2019-11-11 06:50:33 --> Config Class Initialized
INFO - 2019-11-11 06:50:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:33 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:33 --> URI Class Initialized
INFO - 2019-11-11 06:50:33 --> Router Class Initialized
INFO - 2019-11-11 06:50:33 --> Output Class Initialized
INFO - 2019-11-11 06:50:33 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:33 --> Input Class Initialized
INFO - 2019-11-11 06:50:33 --> Language Class Initialized
INFO - 2019-11-11 06:50:33 --> Language Class Initialized
INFO - 2019-11-11 06:50:33 --> Config Class Initialized
INFO - 2019-11-11 06:50:33 --> Loader Class Initialized
INFO - 2019-11-11 06:50:33 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:33 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:33 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:33 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:33 --> Controller Class Initialized
INFO - 2019-11-11 06:50:33 --> Config Class Initialized
INFO - 2019-11-11 06:50:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:33 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:33 --> URI Class Initialized
INFO - 2019-11-11 06:50:33 --> Router Class Initialized
INFO - 2019-11-11 06:50:33 --> Output Class Initialized
INFO - 2019-11-11 06:50:33 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:33 --> Input Class Initialized
INFO - 2019-11-11 06:50:33 --> Language Class Initialized
INFO - 2019-11-11 06:50:33 --> Language Class Initialized
INFO - 2019-11-11 06:50:33 --> Config Class Initialized
INFO - 2019-11-11 06:50:33 --> Loader Class Initialized
INFO - 2019-11-11 06:50:33 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:33 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:33 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:33 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:33 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:50:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:33 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:33 --> Total execution time: 0.0519
INFO - 2019-11-11 06:50:33 --> Config Class Initialized
INFO - 2019-11-11 06:50:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:33 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:33 --> URI Class Initialized
INFO - 2019-11-11 06:50:33 --> Router Class Initialized
INFO - 2019-11-11 06:50:33 --> Output Class Initialized
INFO - 2019-11-11 06:50:33 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:33 --> Input Class Initialized
INFO - 2019-11-11 06:50:33 --> Language Class Initialized
INFO - 2019-11-11 06:50:33 --> Language Class Initialized
INFO - 2019-11-11 06:50:33 --> Config Class Initialized
INFO - 2019-11-11 06:50:33 --> Loader Class Initialized
INFO - 2019-11-11 06:50:33 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:33 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:33 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:33 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:33 --> Controller Class Initialized
INFO - 2019-11-11 06:50:35 --> Config Class Initialized
INFO - 2019-11-11 06:50:35 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:35 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:35 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:35 --> URI Class Initialized
INFO - 2019-11-11 06:50:35 --> Router Class Initialized
INFO - 2019-11-11 06:50:35 --> Output Class Initialized
INFO - 2019-11-11 06:50:35 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:35 --> Input Class Initialized
INFO - 2019-11-11 06:50:35 --> Language Class Initialized
INFO - 2019-11-11 06:50:35 --> Language Class Initialized
INFO - 2019-11-11 06:50:35 --> Config Class Initialized
INFO - 2019-11-11 06:50:35 --> Loader Class Initialized
INFO - 2019-11-11 06:50:35 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:35 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:35 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:35 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:35 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:35 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:50:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:35 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:35 --> Total execution time: 0.0895
INFO - 2019-11-11 06:50:41 --> Config Class Initialized
INFO - 2019-11-11 06:50:41 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:41 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:41 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:41 --> URI Class Initialized
INFO - 2019-11-11 06:50:41 --> Router Class Initialized
INFO - 2019-11-11 06:50:41 --> Output Class Initialized
INFO - 2019-11-11 06:50:41 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:41 --> Input Class Initialized
INFO - 2019-11-11 06:50:41 --> Language Class Initialized
INFO - 2019-11-11 06:50:41 --> Language Class Initialized
INFO - 2019-11-11 06:50:41 --> Config Class Initialized
INFO - 2019-11-11 06:50:41 --> Loader Class Initialized
INFO - 2019-11-11 06:50:41 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:41 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:41 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:41 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:41 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:41 --> Controller Class Initialized
INFO - 2019-11-11 06:50:41 --> Config Class Initialized
INFO - 2019-11-11 06:50:41 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:41 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:41 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:41 --> URI Class Initialized
INFO - 2019-11-11 06:50:41 --> Router Class Initialized
INFO - 2019-11-11 06:50:41 --> Output Class Initialized
INFO - 2019-11-11 06:50:41 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:41 --> Input Class Initialized
INFO - 2019-11-11 06:50:41 --> Language Class Initialized
INFO - 2019-11-11 06:50:41 --> Language Class Initialized
INFO - 2019-11-11 06:50:41 --> Config Class Initialized
INFO - 2019-11-11 06:50:41 --> Loader Class Initialized
INFO - 2019-11-11 06:50:41 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:41 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:41 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:41 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:41 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:41 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:50:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:41 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:41 --> Total execution time: 0.0511
INFO - 2019-11-11 06:50:43 --> Config Class Initialized
INFO - 2019-11-11 06:50:43 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:43 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:43 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:43 --> URI Class Initialized
INFO - 2019-11-11 06:50:43 --> Router Class Initialized
INFO - 2019-11-11 06:50:43 --> Output Class Initialized
INFO - 2019-11-11 06:50:43 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:43 --> Input Class Initialized
INFO - 2019-11-11 06:50:43 --> Language Class Initialized
INFO - 2019-11-11 06:50:43 --> Language Class Initialized
INFO - 2019-11-11 06:50:43 --> Config Class Initialized
INFO - 2019-11-11 06:50:43 --> Loader Class Initialized
INFO - 2019-11-11 06:50:43 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:43 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:43 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:43 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:43 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:43 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:43 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:43 --> Total execution time: 0.0909
INFO - 2019-11-11 06:50:49 --> Config Class Initialized
INFO - 2019-11-11 06:50:49 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:49 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:49 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:49 --> URI Class Initialized
INFO - 2019-11-11 06:50:49 --> Router Class Initialized
INFO - 2019-11-11 06:50:49 --> Output Class Initialized
INFO - 2019-11-11 06:50:49 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:49 --> Input Class Initialized
INFO - 2019-11-11 06:50:49 --> Language Class Initialized
INFO - 2019-11-11 06:50:49 --> Language Class Initialized
INFO - 2019-11-11 06:50:49 --> Config Class Initialized
INFO - 2019-11-11 06:50:49 --> Loader Class Initialized
INFO - 2019-11-11 06:50:49 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:49 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:49 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:49 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:49 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:49 --> Controller Class Initialized
INFO - 2019-11-11 06:50:49 --> Config Class Initialized
INFO - 2019-11-11 06:50:49 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:49 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:49 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:49 --> URI Class Initialized
INFO - 2019-11-11 06:50:49 --> Router Class Initialized
INFO - 2019-11-11 06:50:49 --> Output Class Initialized
INFO - 2019-11-11 06:50:49 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:49 --> Input Class Initialized
INFO - 2019-11-11 06:50:49 --> Language Class Initialized
INFO - 2019-11-11 06:50:49 --> Language Class Initialized
INFO - 2019-11-11 06:50:49 --> Config Class Initialized
INFO - 2019-11-11 06:50:49 --> Loader Class Initialized
INFO - 2019-11-11 06:50:49 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:49 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:49 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:49 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:49 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:49 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:49 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:49 --> Total execution time: 0.0623
INFO - 2019-11-11 06:50:49 --> Config Class Initialized
INFO - 2019-11-11 06:50:49 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:49 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:49 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:49 --> URI Class Initialized
INFO - 2019-11-11 06:50:49 --> Router Class Initialized
INFO - 2019-11-11 06:50:49 --> Output Class Initialized
INFO - 2019-11-11 06:50:49 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:49 --> Input Class Initialized
INFO - 2019-11-11 06:50:49 --> Language Class Initialized
INFO - 2019-11-11 06:50:49 --> Language Class Initialized
INFO - 2019-11-11 06:50:49 --> Config Class Initialized
INFO - 2019-11-11 06:50:49 --> Loader Class Initialized
INFO - 2019-11-11 06:50:49 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:49 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:49 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:49 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:49 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:49 --> Controller Class Initialized
INFO - 2019-11-11 06:50:50 --> Config Class Initialized
INFO - 2019-11-11 06:50:50 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:50 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:50 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:50 --> URI Class Initialized
INFO - 2019-11-11 06:50:50 --> Router Class Initialized
INFO - 2019-11-11 06:50:50 --> Output Class Initialized
INFO - 2019-11-11 06:50:50 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:50 --> Input Class Initialized
INFO - 2019-11-11 06:50:50 --> Language Class Initialized
INFO - 2019-11-11 06:50:50 --> Language Class Initialized
INFO - 2019-11-11 06:50:50 --> Config Class Initialized
INFO - 2019-11-11 06:50:50 --> Loader Class Initialized
INFO - 2019-11-11 06:50:50 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:50 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:50 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:50 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:50 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:50 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:50 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:50 --> Total execution time: 0.0818
INFO - 2019-11-11 06:50:55 --> Config Class Initialized
INFO - 2019-11-11 06:50:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:55 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:55 --> URI Class Initialized
INFO - 2019-11-11 06:50:55 --> Router Class Initialized
INFO - 2019-11-11 06:50:55 --> Output Class Initialized
INFO - 2019-11-11 06:50:55 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:55 --> Input Class Initialized
INFO - 2019-11-11 06:50:55 --> Language Class Initialized
INFO - 2019-11-11 06:50:55 --> Language Class Initialized
INFO - 2019-11-11 06:50:55 --> Config Class Initialized
INFO - 2019-11-11 06:50:55 --> Loader Class Initialized
INFO - 2019-11-11 06:50:55 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:55 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:55 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:55 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:55 --> Controller Class Initialized
INFO - 2019-11-11 06:50:56 --> Config Class Initialized
INFO - 2019-11-11 06:50:56 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:56 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:56 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:56 --> URI Class Initialized
INFO - 2019-11-11 06:50:56 --> Router Class Initialized
INFO - 2019-11-11 06:50:56 --> Output Class Initialized
INFO - 2019-11-11 06:50:56 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:56 --> Input Class Initialized
INFO - 2019-11-11 06:50:56 --> Language Class Initialized
INFO - 2019-11-11 06:50:56 --> Language Class Initialized
INFO - 2019-11-11 06:50:56 --> Config Class Initialized
INFO - 2019-11-11 06:50:56 --> Loader Class Initialized
INFO - 2019-11-11 06:50:56 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:56 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:56 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:56 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:56 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:56 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:56 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:56 --> Total execution time: 0.0824
INFO - 2019-11-11 06:50:57 --> Config Class Initialized
INFO - 2019-11-11 06:50:57 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:50:57 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:50:57 --> Utf8 Class Initialized
INFO - 2019-11-11 06:50:57 --> URI Class Initialized
INFO - 2019-11-11 06:50:57 --> Router Class Initialized
INFO - 2019-11-11 06:50:57 --> Output Class Initialized
INFO - 2019-11-11 06:50:57 --> Security Class Initialized
DEBUG - 2019-11-11 06:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:50:57 --> Input Class Initialized
INFO - 2019-11-11 06:50:57 --> Language Class Initialized
INFO - 2019-11-11 06:50:57 --> Language Class Initialized
INFO - 2019-11-11 06:50:57 --> Config Class Initialized
INFO - 2019-11-11 06:50:57 --> Loader Class Initialized
INFO - 2019-11-11 06:50:57 --> Helper loaded: url_helper
INFO - 2019-11-11 06:50:57 --> Helper loaded: file_helper
INFO - 2019-11-11 06:50:57 --> Helper loaded: form_helper
INFO - 2019-11-11 06:50:57 --> Helper loaded: my_helper
INFO - 2019-11-11 06:50:57 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:50:57 --> Controller Class Initialized
DEBUG - 2019-11-11 06:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:50:57 --> Final output sent to browser
DEBUG - 2019-11-11 06:50:57 --> Total execution time: 0.0872
INFO - 2019-11-11 06:51:02 --> Config Class Initialized
INFO - 2019-11-11 06:51:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:02 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:02 --> URI Class Initialized
INFO - 2019-11-11 06:51:02 --> Router Class Initialized
INFO - 2019-11-11 06:51:02 --> Output Class Initialized
INFO - 2019-11-11 06:51:02 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:02 --> Input Class Initialized
INFO - 2019-11-11 06:51:02 --> Language Class Initialized
INFO - 2019-11-11 06:51:02 --> Language Class Initialized
INFO - 2019-11-11 06:51:02 --> Config Class Initialized
INFO - 2019-11-11 06:51:02 --> Loader Class Initialized
INFO - 2019-11-11 06:51:02 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:02 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:02 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:02 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:02 --> Controller Class Initialized
INFO - 2019-11-11 06:51:02 --> Config Class Initialized
INFO - 2019-11-11 06:51:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:02 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:02 --> URI Class Initialized
INFO - 2019-11-11 06:51:02 --> Router Class Initialized
INFO - 2019-11-11 06:51:02 --> Output Class Initialized
INFO - 2019-11-11 06:51:02 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:02 --> Input Class Initialized
INFO - 2019-11-11 06:51:02 --> Language Class Initialized
INFO - 2019-11-11 06:51:02 --> Language Class Initialized
INFO - 2019-11-11 06:51:02 --> Config Class Initialized
INFO - 2019-11-11 06:51:02 --> Loader Class Initialized
INFO - 2019-11-11 06:51:02 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:02 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:02 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:02 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:02 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:02 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:02 --> Total execution time: 0.0804
INFO - 2019-11-11 06:51:02 --> Config Class Initialized
INFO - 2019-11-11 06:51:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:02 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:02 --> URI Class Initialized
INFO - 2019-11-11 06:51:02 --> Router Class Initialized
INFO - 2019-11-11 06:51:02 --> Output Class Initialized
INFO - 2019-11-11 06:51:02 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:02 --> Input Class Initialized
INFO - 2019-11-11 06:51:02 --> Language Class Initialized
INFO - 2019-11-11 06:51:02 --> Language Class Initialized
INFO - 2019-11-11 06:51:02 --> Config Class Initialized
INFO - 2019-11-11 06:51:02 --> Loader Class Initialized
INFO - 2019-11-11 06:51:02 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:02 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:02 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:02 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:02 --> Controller Class Initialized
INFO - 2019-11-11 06:51:04 --> Config Class Initialized
INFO - 2019-11-11 06:51:04 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:04 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:04 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:04 --> URI Class Initialized
INFO - 2019-11-11 06:51:04 --> Router Class Initialized
INFO - 2019-11-11 06:51:04 --> Output Class Initialized
INFO - 2019-11-11 06:51:04 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:04 --> Input Class Initialized
INFO - 2019-11-11 06:51:04 --> Language Class Initialized
INFO - 2019-11-11 06:51:04 --> Language Class Initialized
INFO - 2019-11-11 06:51:04 --> Config Class Initialized
INFO - 2019-11-11 06:51:04 --> Loader Class Initialized
INFO - 2019-11-11 06:51:04 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:04 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:04 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:04 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:04 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:04 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:51:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:04 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:04 --> Total execution time: 0.0881
INFO - 2019-11-11 06:51:08 --> Config Class Initialized
INFO - 2019-11-11 06:51:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:08 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:08 --> URI Class Initialized
INFO - 2019-11-11 06:51:08 --> Router Class Initialized
INFO - 2019-11-11 06:51:08 --> Output Class Initialized
INFO - 2019-11-11 06:51:08 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:08 --> Input Class Initialized
INFO - 2019-11-11 06:51:08 --> Language Class Initialized
INFO - 2019-11-11 06:51:08 --> Language Class Initialized
INFO - 2019-11-11 06:51:08 --> Config Class Initialized
INFO - 2019-11-11 06:51:08 --> Loader Class Initialized
INFO - 2019-11-11 06:51:08 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:08 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:08 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:08 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:08 --> Controller Class Initialized
INFO - 2019-11-11 06:51:08 --> Config Class Initialized
INFO - 2019-11-11 06:51:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:08 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:08 --> URI Class Initialized
INFO - 2019-11-11 06:51:09 --> Router Class Initialized
INFO - 2019-11-11 06:51:09 --> Output Class Initialized
INFO - 2019-11-11 06:51:09 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:09 --> Input Class Initialized
INFO - 2019-11-11 06:51:09 --> Language Class Initialized
INFO - 2019-11-11 06:51:09 --> Language Class Initialized
INFO - 2019-11-11 06:51:09 --> Config Class Initialized
INFO - 2019-11-11 06:51:09 --> Loader Class Initialized
INFO - 2019-11-11 06:51:09 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:09 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:09 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:09 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:09 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:09 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:09 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:09 --> Total execution time: 0.0677
INFO - 2019-11-11 06:51:10 --> Config Class Initialized
INFO - 2019-11-11 06:51:10 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:10 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:10 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:10 --> URI Class Initialized
INFO - 2019-11-11 06:51:10 --> Router Class Initialized
INFO - 2019-11-11 06:51:10 --> Output Class Initialized
INFO - 2019-11-11 06:51:10 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:10 --> Input Class Initialized
INFO - 2019-11-11 06:51:10 --> Language Class Initialized
INFO - 2019-11-11 06:51:10 --> Language Class Initialized
INFO - 2019-11-11 06:51:10 --> Config Class Initialized
INFO - 2019-11-11 06:51:10 --> Loader Class Initialized
INFO - 2019-11-11 06:51:10 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:10 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:10 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:10 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:10 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:10 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:10 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:10 --> Total execution time: 0.0848
INFO - 2019-11-11 06:51:15 --> Config Class Initialized
INFO - 2019-11-11 06:51:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:15 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:15 --> URI Class Initialized
INFO - 2019-11-11 06:51:15 --> Router Class Initialized
INFO - 2019-11-11 06:51:15 --> Output Class Initialized
INFO - 2019-11-11 06:51:15 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:15 --> Input Class Initialized
INFO - 2019-11-11 06:51:15 --> Language Class Initialized
INFO - 2019-11-11 06:51:15 --> Language Class Initialized
INFO - 2019-11-11 06:51:15 --> Config Class Initialized
INFO - 2019-11-11 06:51:15 --> Loader Class Initialized
INFO - 2019-11-11 06:51:15 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:15 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:15 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:15 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:15 --> Controller Class Initialized
INFO - 2019-11-11 06:51:15 --> Config Class Initialized
INFO - 2019-11-11 06:51:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:15 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:15 --> URI Class Initialized
INFO - 2019-11-11 06:51:15 --> Router Class Initialized
INFO - 2019-11-11 06:51:15 --> Output Class Initialized
INFO - 2019-11-11 06:51:15 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:15 --> Input Class Initialized
INFO - 2019-11-11 06:51:15 --> Language Class Initialized
INFO - 2019-11-11 06:51:15 --> Language Class Initialized
INFO - 2019-11-11 06:51:15 --> Config Class Initialized
INFO - 2019-11-11 06:51:15 --> Loader Class Initialized
INFO - 2019-11-11 06:51:15 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:15 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:15 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:15 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:15 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:51:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:15 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:15 --> Total execution time: 0.0574
INFO - 2019-11-11 06:51:16 --> Config Class Initialized
INFO - 2019-11-11 06:51:16 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:16 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:16 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:16 --> URI Class Initialized
INFO - 2019-11-11 06:51:16 --> Router Class Initialized
INFO - 2019-11-11 06:51:16 --> Output Class Initialized
INFO - 2019-11-11 06:51:16 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:16 --> Input Class Initialized
INFO - 2019-11-11 06:51:16 --> Language Class Initialized
INFO - 2019-11-11 06:51:16 --> Language Class Initialized
INFO - 2019-11-11 06:51:16 --> Config Class Initialized
INFO - 2019-11-11 06:51:16 --> Loader Class Initialized
INFO - 2019-11-11 06:51:16 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:16 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:16 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:16 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:16 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:16 --> Controller Class Initialized
INFO - 2019-11-11 06:51:17 --> Config Class Initialized
INFO - 2019-11-11 06:51:17 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:17 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:17 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:17 --> URI Class Initialized
INFO - 2019-11-11 06:51:17 --> Router Class Initialized
INFO - 2019-11-11 06:51:17 --> Output Class Initialized
INFO - 2019-11-11 06:51:17 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:17 --> Input Class Initialized
INFO - 2019-11-11 06:51:17 --> Language Class Initialized
INFO - 2019-11-11 06:51:17 --> Language Class Initialized
INFO - 2019-11-11 06:51:17 --> Config Class Initialized
INFO - 2019-11-11 06:51:17 --> Loader Class Initialized
INFO - 2019-11-11 06:51:17 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:17 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:17 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:17 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:17 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:17 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:17 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:17 --> Total execution time: 0.0682
INFO - 2019-11-11 06:51:23 --> Config Class Initialized
INFO - 2019-11-11 06:51:23 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:23 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:23 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:23 --> URI Class Initialized
INFO - 2019-11-11 06:51:23 --> Router Class Initialized
INFO - 2019-11-11 06:51:23 --> Output Class Initialized
INFO - 2019-11-11 06:51:23 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:23 --> Input Class Initialized
INFO - 2019-11-11 06:51:23 --> Language Class Initialized
INFO - 2019-11-11 06:51:23 --> Language Class Initialized
INFO - 2019-11-11 06:51:23 --> Config Class Initialized
INFO - 2019-11-11 06:51:23 --> Loader Class Initialized
INFO - 2019-11-11 06:51:23 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:23 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:23 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:23 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:23 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:23 --> Controller Class Initialized
INFO - 2019-11-11 06:51:23 --> Config Class Initialized
INFO - 2019-11-11 06:51:23 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:23 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:23 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:23 --> URI Class Initialized
INFO - 2019-11-11 06:51:23 --> Router Class Initialized
INFO - 2019-11-11 06:51:23 --> Output Class Initialized
INFO - 2019-11-11 06:51:23 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:23 --> Input Class Initialized
INFO - 2019-11-11 06:51:23 --> Language Class Initialized
INFO - 2019-11-11 06:51:23 --> Language Class Initialized
INFO - 2019-11-11 06:51:23 --> Config Class Initialized
INFO - 2019-11-11 06:51:23 --> Loader Class Initialized
INFO - 2019-11-11 06:51:23 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:23 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:23 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:23 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:23 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:23 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:51:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:23 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:23 --> Total execution time: 0.0708
INFO - 2019-11-11 06:51:26 --> Config Class Initialized
INFO - 2019-11-11 06:51:26 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:26 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:26 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:26 --> URI Class Initialized
INFO - 2019-11-11 06:51:26 --> Router Class Initialized
INFO - 2019-11-11 06:51:26 --> Output Class Initialized
INFO - 2019-11-11 06:51:26 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:26 --> Input Class Initialized
INFO - 2019-11-11 06:51:26 --> Language Class Initialized
INFO - 2019-11-11 06:51:26 --> Language Class Initialized
INFO - 2019-11-11 06:51:26 --> Config Class Initialized
INFO - 2019-11-11 06:51:26 --> Loader Class Initialized
INFO - 2019-11-11 06:51:26 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:26 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:26 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:26 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:26 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:26 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 06:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:26 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:26 --> Total execution time: 0.0723
INFO - 2019-11-11 06:51:33 --> Config Class Initialized
INFO - 2019-11-11 06:51:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:33 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:33 --> URI Class Initialized
INFO - 2019-11-11 06:51:33 --> Router Class Initialized
INFO - 2019-11-11 06:51:33 --> Output Class Initialized
INFO - 2019-11-11 06:51:33 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:33 --> Input Class Initialized
INFO - 2019-11-11 06:51:33 --> Language Class Initialized
INFO - 2019-11-11 06:51:33 --> Language Class Initialized
INFO - 2019-11-11 06:51:33 --> Config Class Initialized
INFO - 2019-11-11 06:51:33 --> Loader Class Initialized
INFO - 2019-11-11 06:51:33 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:33 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:33 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:33 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:33 --> Controller Class Initialized
INFO - 2019-11-11 06:51:33 --> Config Class Initialized
INFO - 2019-11-11 06:51:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:33 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:33 --> URI Class Initialized
INFO - 2019-11-11 06:51:33 --> Router Class Initialized
INFO - 2019-11-11 06:51:33 --> Output Class Initialized
INFO - 2019-11-11 06:51:33 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:33 --> Input Class Initialized
INFO - 2019-11-11 06:51:33 --> Language Class Initialized
INFO - 2019-11-11 06:51:33 --> Language Class Initialized
INFO - 2019-11-11 06:51:33 --> Config Class Initialized
INFO - 2019-11-11 06:51:33 --> Loader Class Initialized
INFO - 2019-11-11 06:51:33 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:33 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:33 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:33 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:33 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:33 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:33 --> Total execution time: 0.0719
INFO - 2019-11-11 06:51:33 --> Config Class Initialized
INFO - 2019-11-11 06:51:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:33 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:33 --> URI Class Initialized
INFO - 2019-11-11 06:51:33 --> Router Class Initialized
INFO - 2019-11-11 06:51:33 --> Output Class Initialized
INFO - 2019-11-11 06:51:33 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:33 --> Input Class Initialized
INFO - 2019-11-11 06:51:34 --> Language Class Initialized
INFO - 2019-11-11 06:51:34 --> Language Class Initialized
INFO - 2019-11-11 06:51:34 --> Config Class Initialized
INFO - 2019-11-11 06:51:34 --> Loader Class Initialized
INFO - 2019-11-11 06:51:34 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:34 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:34 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:34 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:34 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:34 --> Controller Class Initialized
INFO - 2019-11-11 06:51:35 --> Config Class Initialized
INFO - 2019-11-11 06:51:35 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:35 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:35 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:35 --> URI Class Initialized
INFO - 2019-11-11 06:51:35 --> Router Class Initialized
INFO - 2019-11-11 06:51:35 --> Output Class Initialized
INFO - 2019-11-11 06:51:35 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:35 --> Input Class Initialized
INFO - 2019-11-11 06:51:35 --> Language Class Initialized
INFO - 2019-11-11 06:51:35 --> Language Class Initialized
INFO - 2019-11-11 06:51:35 --> Config Class Initialized
INFO - 2019-11-11 06:51:35 --> Loader Class Initialized
INFO - 2019-11-11 06:51:35 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:35 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:35 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:35 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:35 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:35 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 06:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:35 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:35 --> Total execution time: 0.0983
INFO - 2019-11-11 06:51:40 --> Config Class Initialized
INFO - 2019-11-11 06:51:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:40 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:40 --> URI Class Initialized
INFO - 2019-11-11 06:51:40 --> Router Class Initialized
INFO - 2019-11-11 06:51:40 --> Output Class Initialized
INFO - 2019-11-11 06:51:40 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:40 --> Input Class Initialized
INFO - 2019-11-11 06:51:40 --> Language Class Initialized
INFO - 2019-11-11 06:51:40 --> Language Class Initialized
INFO - 2019-11-11 06:51:40 --> Config Class Initialized
INFO - 2019-11-11 06:51:40 --> Loader Class Initialized
INFO - 2019-11-11 06:51:40 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:40 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:40 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:40 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:40 --> Controller Class Initialized
INFO - 2019-11-11 06:51:40 --> Config Class Initialized
INFO - 2019-11-11 06:51:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:51:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:51:40 --> Utf8 Class Initialized
INFO - 2019-11-11 06:51:40 --> URI Class Initialized
INFO - 2019-11-11 06:51:40 --> Router Class Initialized
INFO - 2019-11-11 06:51:40 --> Output Class Initialized
INFO - 2019-11-11 06:51:40 --> Security Class Initialized
DEBUG - 2019-11-11 06:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:51:40 --> Input Class Initialized
INFO - 2019-11-11 06:51:40 --> Language Class Initialized
INFO - 2019-11-11 06:51:40 --> Language Class Initialized
INFO - 2019-11-11 06:51:40 --> Config Class Initialized
INFO - 2019-11-11 06:51:40 --> Loader Class Initialized
INFO - 2019-11-11 06:51:40 --> Helper loaded: url_helper
INFO - 2019-11-11 06:51:40 --> Helper loaded: file_helper
INFO - 2019-11-11 06:51:40 --> Helper loaded: form_helper
INFO - 2019-11-11 06:51:40 --> Helper loaded: my_helper
INFO - 2019-11-11 06:51:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:51:40 --> Controller Class Initialized
DEBUG - 2019-11-11 06:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:51:40 --> Final output sent to browser
DEBUG - 2019-11-11 06:51:40 --> Total execution time: 0.0633
INFO - 2019-11-11 06:52:55 --> Config Class Initialized
INFO - 2019-11-11 06:52:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:52:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:52:55 --> Utf8 Class Initialized
INFO - 2019-11-11 06:52:55 --> URI Class Initialized
INFO - 2019-11-11 06:52:55 --> Router Class Initialized
INFO - 2019-11-11 06:52:55 --> Output Class Initialized
INFO - 2019-11-11 06:52:55 --> Security Class Initialized
DEBUG - 2019-11-11 06:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:52:55 --> Input Class Initialized
INFO - 2019-11-11 06:52:55 --> Language Class Initialized
INFO - 2019-11-11 06:52:55 --> Language Class Initialized
INFO - 2019-11-11 06:52:55 --> Config Class Initialized
INFO - 2019-11-11 06:52:55 --> Loader Class Initialized
INFO - 2019-11-11 06:52:55 --> Helper loaded: url_helper
INFO - 2019-11-11 06:52:55 --> Helper loaded: file_helper
INFO - 2019-11-11 06:52:55 --> Helper loaded: form_helper
INFO - 2019-11-11 06:52:55 --> Helper loaded: my_helper
INFO - 2019-11-11 06:52:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:52:55 --> Controller Class Initialized
DEBUG - 2019-11-11 06:52:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:52:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:52:55 --> Final output sent to browser
DEBUG - 2019-11-11 06:52:55 --> Total execution time: 0.1133
INFO - 2019-11-11 06:52:55 --> Config Class Initialized
INFO - 2019-11-11 06:52:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:52:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:52:55 --> Utf8 Class Initialized
INFO - 2019-11-11 06:52:55 --> URI Class Initialized
INFO - 2019-11-11 06:52:55 --> Router Class Initialized
INFO - 2019-11-11 06:52:55 --> Output Class Initialized
INFO - 2019-11-11 06:52:55 --> Security Class Initialized
DEBUG - 2019-11-11 06:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:52:55 --> Input Class Initialized
INFO - 2019-11-11 06:52:55 --> Language Class Initialized
INFO - 2019-11-11 06:52:55 --> Language Class Initialized
INFO - 2019-11-11 06:52:55 --> Config Class Initialized
INFO - 2019-11-11 06:52:55 --> Loader Class Initialized
INFO - 2019-11-11 06:52:55 --> Helper loaded: url_helper
INFO - 2019-11-11 06:52:55 --> Helper loaded: file_helper
INFO - 2019-11-11 06:52:55 --> Helper loaded: form_helper
INFO - 2019-11-11 06:52:55 --> Helper loaded: my_helper
INFO - 2019-11-11 06:52:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:52:55 --> Controller Class Initialized
INFO - 2019-11-11 06:52:56 --> Config Class Initialized
INFO - 2019-11-11 06:52:56 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:52:56 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:52:56 --> Utf8 Class Initialized
INFO - 2019-11-11 06:52:56 --> URI Class Initialized
INFO - 2019-11-11 06:52:56 --> Router Class Initialized
INFO - 2019-11-11 06:52:56 --> Output Class Initialized
INFO - 2019-11-11 06:52:56 --> Security Class Initialized
DEBUG - 2019-11-11 06:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:52:56 --> Input Class Initialized
INFO - 2019-11-11 06:52:56 --> Language Class Initialized
INFO - 2019-11-11 06:52:56 --> Language Class Initialized
INFO - 2019-11-11 06:52:56 --> Config Class Initialized
INFO - 2019-11-11 06:52:56 --> Loader Class Initialized
INFO - 2019-11-11 06:52:56 --> Helper loaded: url_helper
INFO - 2019-11-11 06:52:56 --> Helper loaded: file_helper
INFO - 2019-11-11 06:52:56 --> Helper loaded: form_helper
INFO - 2019-11-11 06:52:56 --> Helper loaded: my_helper
INFO - 2019-11-11 06:52:56 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:52:56 --> Controller Class Initialized
DEBUG - 2019-11-11 06:52:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:52:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:52:56 --> Final output sent to browser
DEBUG - 2019-11-11 06:52:56 --> Total execution time: 0.1146
INFO - 2019-11-11 06:53:02 --> Config Class Initialized
INFO - 2019-11-11 06:53:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:02 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:02 --> URI Class Initialized
INFO - 2019-11-11 06:53:02 --> Router Class Initialized
INFO - 2019-11-11 06:53:02 --> Output Class Initialized
INFO - 2019-11-11 06:53:02 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:02 --> Input Class Initialized
INFO - 2019-11-11 06:53:02 --> Language Class Initialized
INFO - 2019-11-11 06:53:02 --> Language Class Initialized
INFO - 2019-11-11 06:53:02 --> Config Class Initialized
INFO - 2019-11-11 06:53:02 --> Loader Class Initialized
INFO - 2019-11-11 06:53:02 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:02 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:02 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:02 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:02 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:02 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:02 --> Total execution time: 0.1088
INFO - 2019-11-11 06:53:02 --> Config Class Initialized
INFO - 2019-11-11 06:53:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:02 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:02 --> URI Class Initialized
INFO - 2019-11-11 06:53:02 --> Router Class Initialized
INFO - 2019-11-11 06:53:02 --> Output Class Initialized
INFO - 2019-11-11 06:53:02 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:02 --> Input Class Initialized
INFO - 2019-11-11 06:53:02 --> Language Class Initialized
INFO - 2019-11-11 06:53:02 --> Language Class Initialized
INFO - 2019-11-11 06:53:02 --> Config Class Initialized
INFO - 2019-11-11 06:53:02 --> Loader Class Initialized
INFO - 2019-11-11 06:53:02 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:02 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:02 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:02 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:02 --> Controller Class Initialized
INFO - 2019-11-11 06:53:03 --> Config Class Initialized
INFO - 2019-11-11 06:53:03 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:03 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:03 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:03 --> URI Class Initialized
INFO - 2019-11-11 06:53:03 --> Router Class Initialized
INFO - 2019-11-11 06:53:03 --> Output Class Initialized
INFO - 2019-11-11 06:53:03 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:03 --> Input Class Initialized
INFO - 2019-11-11 06:53:03 --> Language Class Initialized
INFO - 2019-11-11 06:53:03 --> Language Class Initialized
INFO - 2019-11-11 06:53:03 --> Config Class Initialized
INFO - 2019-11-11 06:53:03 --> Loader Class Initialized
INFO - 2019-11-11 06:53:03 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:03 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:03 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:03 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:03 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:03 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:53:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:03 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:03 --> Total execution time: 0.1056
INFO - 2019-11-11 06:53:06 --> Config Class Initialized
INFO - 2019-11-11 06:53:06 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:06 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:06 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:06 --> URI Class Initialized
INFO - 2019-11-11 06:53:06 --> Router Class Initialized
INFO - 2019-11-11 06:53:06 --> Output Class Initialized
INFO - 2019-11-11 06:53:06 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:06 --> Input Class Initialized
INFO - 2019-11-11 06:53:06 --> Language Class Initialized
INFO - 2019-11-11 06:53:06 --> Language Class Initialized
INFO - 2019-11-11 06:53:06 --> Config Class Initialized
INFO - 2019-11-11 06:53:06 --> Loader Class Initialized
INFO - 2019-11-11 06:53:06 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:06 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:06 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:06 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:06 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:06 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:06 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:06 --> Total execution time: 0.0938
INFO - 2019-11-11 06:53:06 --> Config Class Initialized
INFO - 2019-11-11 06:53:06 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:06 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:06 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:06 --> URI Class Initialized
INFO - 2019-11-11 06:53:06 --> Router Class Initialized
INFO - 2019-11-11 06:53:06 --> Output Class Initialized
INFO - 2019-11-11 06:53:06 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:06 --> Input Class Initialized
INFO - 2019-11-11 06:53:06 --> Language Class Initialized
INFO - 2019-11-11 06:53:06 --> Language Class Initialized
INFO - 2019-11-11 06:53:06 --> Config Class Initialized
INFO - 2019-11-11 06:53:06 --> Loader Class Initialized
INFO - 2019-11-11 06:53:06 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:06 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:06 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:06 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:06 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:06 --> Controller Class Initialized
INFO - 2019-11-11 06:53:07 --> Config Class Initialized
INFO - 2019-11-11 06:53:07 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:07 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:07 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:07 --> URI Class Initialized
INFO - 2019-11-11 06:53:07 --> Router Class Initialized
INFO - 2019-11-11 06:53:07 --> Output Class Initialized
INFO - 2019-11-11 06:53:07 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:07 --> Input Class Initialized
INFO - 2019-11-11 06:53:07 --> Language Class Initialized
INFO - 2019-11-11 06:53:07 --> Language Class Initialized
INFO - 2019-11-11 06:53:07 --> Config Class Initialized
INFO - 2019-11-11 06:53:07 --> Loader Class Initialized
INFO - 2019-11-11 06:53:07 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:07 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:07 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:07 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:07 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:07 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:07 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:07 --> Total execution time: 0.0955
INFO - 2019-11-11 06:53:10 --> Config Class Initialized
INFO - 2019-11-11 06:53:10 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:10 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:10 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:10 --> URI Class Initialized
INFO - 2019-11-11 06:53:10 --> Router Class Initialized
INFO - 2019-11-11 06:53:10 --> Output Class Initialized
INFO - 2019-11-11 06:53:10 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:10 --> Input Class Initialized
INFO - 2019-11-11 06:53:10 --> Language Class Initialized
INFO - 2019-11-11 06:53:10 --> Language Class Initialized
INFO - 2019-11-11 06:53:10 --> Config Class Initialized
INFO - 2019-11-11 06:53:10 --> Loader Class Initialized
INFO - 2019-11-11 06:53:10 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:10 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:10 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:10 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:10 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:10 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:10 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:10 --> Total execution time: 0.0972
INFO - 2019-11-11 06:53:11 --> Config Class Initialized
INFO - 2019-11-11 06:53:11 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:11 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:11 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:11 --> URI Class Initialized
INFO - 2019-11-11 06:53:11 --> Router Class Initialized
INFO - 2019-11-11 06:53:11 --> Output Class Initialized
INFO - 2019-11-11 06:53:11 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:11 --> Input Class Initialized
INFO - 2019-11-11 06:53:11 --> Language Class Initialized
INFO - 2019-11-11 06:53:11 --> Language Class Initialized
INFO - 2019-11-11 06:53:11 --> Config Class Initialized
INFO - 2019-11-11 06:53:11 --> Loader Class Initialized
INFO - 2019-11-11 06:53:11 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:11 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:11 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:11 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:11 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:11 --> Controller Class Initialized
INFO - 2019-11-11 06:53:12 --> Config Class Initialized
INFO - 2019-11-11 06:53:12 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:12 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:12 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:12 --> URI Class Initialized
INFO - 2019-11-11 06:53:12 --> Router Class Initialized
INFO - 2019-11-11 06:53:12 --> Output Class Initialized
INFO - 2019-11-11 06:53:12 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:12 --> Input Class Initialized
INFO - 2019-11-11 06:53:12 --> Language Class Initialized
INFO - 2019-11-11 06:53:12 --> Language Class Initialized
INFO - 2019-11-11 06:53:12 --> Config Class Initialized
INFO - 2019-11-11 06:53:12 --> Loader Class Initialized
INFO - 2019-11-11 06:53:12 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:12 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:12 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:12 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:12 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:12 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:53:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:12 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:12 --> Total execution time: 0.0991
INFO - 2019-11-11 06:53:15 --> Config Class Initialized
INFO - 2019-11-11 06:53:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:15 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:15 --> URI Class Initialized
INFO - 2019-11-11 06:53:15 --> Router Class Initialized
INFO - 2019-11-11 06:53:15 --> Output Class Initialized
INFO - 2019-11-11 06:53:15 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:15 --> Input Class Initialized
INFO - 2019-11-11 06:53:15 --> Language Class Initialized
INFO - 2019-11-11 06:53:15 --> Language Class Initialized
INFO - 2019-11-11 06:53:15 --> Config Class Initialized
INFO - 2019-11-11 06:53:15 --> Loader Class Initialized
INFO - 2019-11-11 06:53:15 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:15 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:15 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:15 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:15 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:15 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:15 --> Total execution time: 0.1020
INFO - 2019-11-11 06:53:15 --> Config Class Initialized
INFO - 2019-11-11 06:53:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:15 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:15 --> URI Class Initialized
INFO - 2019-11-11 06:53:15 --> Router Class Initialized
INFO - 2019-11-11 06:53:15 --> Output Class Initialized
INFO - 2019-11-11 06:53:15 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:15 --> Input Class Initialized
INFO - 2019-11-11 06:53:15 --> Language Class Initialized
INFO - 2019-11-11 06:53:15 --> Language Class Initialized
INFO - 2019-11-11 06:53:15 --> Config Class Initialized
INFO - 2019-11-11 06:53:15 --> Loader Class Initialized
INFO - 2019-11-11 06:53:15 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:15 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:15 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:15 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:15 --> Controller Class Initialized
INFO - 2019-11-11 06:53:17 --> Config Class Initialized
INFO - 2019-11-11 06:53:17 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:17 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:17 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:17 --> URI Class Initialized
INFO - 2019-11-11 06:53:17 --> Router Class Initialized
INFO - 2019-11-11 06:53:17 --> Output Class Initialized
INFO - 2019-11-11 06:53:17 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:17 --> Input Class Initialized
INFO - 2019-11-11 06:53:17 --> Language Class Initialized
INFO - 2019-11-11 06:53:17 --> Language Class Initialized
INFO - 2019-11-11 06:53:17 --> Config Class Initialized
INFO - 2019-11-11 06:53:17 --> Loader Class Initialized
INFO - 2019-11-11 06:53:17 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:17 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:17 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:17 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:17 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:17 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:17 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:17 --> Total execution time: 0.1046
INFO - 2019-11-11 06:53:20 --> Config Class Initialized
INFO - 2019-11-11 06:53:20 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:20 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:20 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:20 --> URI Class Initialized
INFO - 2019-11-11 06:53:20 --> Router Class Initialized
INFO - 2019-11-11 06:53:20 --> Output Class Initialized
INFO - 2019-11-11 06:53:20 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:20 --> Input Class Initialized
INFO - 2019-11-11 06:53:20 --> Language Class Initialized
INFO - 2019-11-11 06:53:20 --> Language Class Initialized
INFO - 2019-11-11 06:53:20 --> Config Class Initialized
INFO - 2019-11-11 06:53:20 --> Loader Class Initialized
INFO - 2019-11-11 06:53:20 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:20 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:20 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:20 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:20 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:20 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:20 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:20 --> Total execution time: 0.1076
INFO - 2019-11-11 06:53:21 --> Config Class Initialized
INFO - 2019-11-11 06:53:21 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:21 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:21 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:21 --> URI Class Initialized
INFO - 2019-11-11 06:53:21 --> Router Class Initialized
INFO - 2019-11-11 06:53:21 --> Output Class Initialized
INFO - 2019-11-11 06:53:21 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:21 --> Input Class Initialized
INFO - 2019-11-11 06:53:21 --> Language Class Initialized
INFO - 2019-11-11 06:53:21 --> Language Class Initialized
INFO - 2019-11-11 06:53:21 --> Config Class Initialized
INFO - 2019-11-11 06:53:21 --> Loader Class Initialized
INFO - 2019-11-11 06:53:21 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:21 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:21 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:21 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:21 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:21 --> Controller Class Initialized
INFO - 2019-11-11 06:53:22 --> Config Class Initialized
INFO - 2019-11-11 06:53:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:22 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:22 --> URI Class Initialized
INFO - 2019-11-11 06:53:22 --> Router Class Initialized
INFO - 2019-11-11 06:53:22 --> Output Class Initialized
INFO - 2019-11-11 06:53:22 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:22 --> Input Class Initialized
INFO - 2019-11-11 06:53:22 --> Language Class Initialized
INFO - 2019-11-11 06:53:22 --> Language Class Initialized
INFO - 2019-11-11 06:53:22 --> Config Class Initialized
INFO - 2019-11-11 06:53:22 --> Loader Class Initialized
INFO - 2019-11-11 06:53:22 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:22 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:22 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:22 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:22 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:22 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:22 --> Total execution time: 0.0936
INFO - 2019-11-11 06:53:25 --> Config Class Initialized
INFO - 2019-11-11 06:53:25 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:25 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:25 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:25 --> URI Class Initialized
INFO - 2019-11-11 06:53:25 --> Router Class Initialized
INFO - 2019-11-11 06:53:25 --> Output Class Initialized
INFO - 2019-11-11 06:53:25 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:25 --> Input Class Initialized
INFO - 2019-11-11 06:53:25 --> Language Class Initialized
INFO - 2019-11-11 06:53:25 --> Language Class Initialized
INFO - 2019-11-11 06:53:25 --> Config Class Initialized
INFO - 2019-11-11 06:53:25 --> Loader Class Initialized
INFO - 2019-11-11 06:53:25 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:25 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:25 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:25 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:25 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:25 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:25 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:25 --> Total execution time: 0.1038
INFO - 2019-11-11 06:53:25 --> Config Class Initialized
INFO - 2019-11-11 06:53:25 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:25 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:25 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:25 --> URI Class Initialized
INFO - 2019-11-11 06:53:25 --> Router Class Initialized
INFO - 2019-11-11 06:53:25 --> Output Class Initialized
INFO - 2019-11-11 06:53:25 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:25 --> Input Class Initialized
INFO - 2019-11-11 06:53:25 --> Language Class Initialized
INFO - 2019-11-11 06:53:25 --> Language Class Initialized
INFO - 2019-11-11 06:53:25 --> Config Class Initialized
INFO - 2019-11-11 06:53:25 --> Loader Class Initialized
INFO - 2019-11-11 06:53:25 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:25 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:25 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:25 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:25 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:25 --> Controller Class Initialized
INFO - 2019-11-11 06:53:26 --> Config Class Initialized
INFO - 2019-11-11 06:53:26 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:26 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:26 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:26 --> URI Class Initialized
INFO - 2019-11-11 06:53:26 --> Router Class Initialized
INFO - 2019-11-11 06:53:26 --> Output Class Initialized
INFO - 2019-11-11 06:53:26 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:26 --> Input Class Initialized
INFO - 2019-11-11 06:53:26 --> Language Class Initialized
INFO - 2019-11-11 06:53:26 --> Language Class Initialized
INFO - 2019-11-11 06:53:26 --> Config Class Initialized
INFO - 2019-11-11 06:53:26 --> Loader Class Initialized
INFO - 2019-11-11 06:53:26 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:26 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:26 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:26 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:26 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:26 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:53:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:26 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:26 --> Total execution time: 0.0867
INFO - 2019-11-11 06:53:38 --> Config Class Initialized
INFO - 2019-11-11 06:53:38 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:38 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:38 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:38 --> URI Class Initialized
INFO - 2019-11-11 06:53:38 --> Router Class Initialized
INFO - 2019-11-11 06:53:38 --> Output Class Initialized
INFO - 2019-11-11 06:53:38 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:38 --> Input Class Initialized
INFO - 2019-11-11 06:53:38 --> Language Class Initialized
INFO - 2019-11-11 06:53:38 --> Language Class Initialized
INFO - 2019-11-11 06:53:38 --> Config Class Initialized
INFO - 2019-11-11 06:53:38 --> Loader Class Initialized
INFO - 2019-11-11 06:53:38 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:38 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:38 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:38 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:38 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:38 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:38 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:38 --> Total execution time: 0.0885
INFO - 2019-11-11 06:53:38 --> Config Class Initialized
INFO - 2019-11-11 06:53:38 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:38 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:38 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:38 --> URI Class Initialized
INFO - 2019-11-11 06:53:38 --> Router Class Initialized
INFO - 2019-11-11 06:53:38 --> Output Class Initialized
INFO - 2019-11-11 06:53:38 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:38 --> Input Class Initialized
INFO - 2019-11-11 06:53:38 --> Language Class Initialized
INFO - 2019-11-11 06:53:38 --> Language Class Initialized
INFO - 2019-11-11 06:53:38 --> Config Class Initialized
INFO - 2019-11-11 06:53:38 --> Loader Class Initialized
INFO - 2019-11-11 06:53:38 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:38 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:38 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:38 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:38 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:38 --> Controller Class Initialized
INFO - 2019-11-11 06:53:39 --> Config Class Initialized
INFO - 2019-11-11 06:53:39 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:39 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:39 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:39 --> URI Class Initialized
INFO - 2019-11-11 06:53:39 --> Router Class Initialized
INFO - 2019-11-11 06:53:39 --> Output Class Initialized
INFO - 2019-11-11 06:53:39 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:39 --> Input Class Initialized
INFO - 2019-11-11 06:53:39 --> Language Class Initialized
INFO - 2019-11-11 06:53:39 --> Language Class Initialized
INFO - 2019-11-11 06:53:39 --> Config Class Initialized
INFO - 2019-11-11 06:53:39 --> Loader Class Initialized
INFO - 2019-11-11 06:53:39 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:39 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:39 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:39 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:39 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:39 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:53:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:39 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:39 --> Total execution time: 0.0977
INFO - 2019-11-11 06:53:51 --> Config Class Initialized
INFO - 2019-11-11 06:53:51 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:51 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:51 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:51 --> URI Class Initialized
INFO - 2019-11-11 06:53:51 --> Router Class Initialized
INFO - 2019-11-11 06:53:51 --> Output Class Initialized
INFO - 2019-11-11 06:53:51 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:51 --> Input Class Initialized
INFO - 2019-11-11 06:53:51 --> Language Class Initialized
INFO - 2019-11-11 06:53:51 --> Language Class Initialized
INFO - 2019-11-11 06:53:51 --> Config Class Initialized
INFO - 2019-11-11 06:53:51 --> Loader Class Initialized
INFO - 2019-11-11 06:53:51 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:51 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:51 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:51 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:51 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:51 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:51 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:51 --> Total execution time: 0.1118
INFO - 2019-11-11 06:53:51 --> Config Class Initialized
INFO - 2019-11-11 06:53:51 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:51 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:51 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:51 --> URI Class Initialized
INFO - 2019-11-11 06:53:51 --> Router Class Initialized
INFO - 2019-11-11 06:53:51 --> Output Class Initialized
INFO - 2019-11-11 06:53:51 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:51 --> Input Class Initialized
INFO - 2019-11-11 06:53:51 --> Language Class Initialized
INFO - 2019-11-11 06:53:51 --> Language Class Initialized
INFO - 2019-11-11 06:53:51 --> Config Class Initialized
INFO - 2019-11-11 06:53:51 --> Loader Class Initialized
INFO - 2019-11-11 06:53:51 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:51 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:51 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:51 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:51 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:51 --> Controller Class Initialized
INFO - 2019-11-11 06:53:52 --> Config Class Initialized
INFO - 2019-11-11 06:53:52 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:52 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:52 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:52 --> URI Class Initialized
INFO - 2019-11-11 06:53:52 --> Router Class Initialized
INFO - 2019-11-11 06:53:52 --> Output Class Initialized
INFO - 2019-11-11 06:53:52 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:52 --> Input Class Initialized
INFO - 2019-11-11 06:53:52 --> Language Class Initialized
INFO - 2019-11-11 06:53:52 --> Language Class Initialized
INFO - 2019-11-11 06:53:52 --> Config Class Initialized
INFO - 2019-11-11 06:53:52 --> Loader Class Initialized
INFO - 2019-11-11 06:53:52 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:52 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:52 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:52 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:52 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:52 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:53:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:52 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:52 --> Total execution time: 0.0895
INFO - 2019-11-11 06:53:54 --> Config Class Initialized
INFO - 2019-11-11 06:53:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:54 --> URI Class Initialized
INFO - 2019-11-11 06:53:54 --> Router Class Initialized
INFO - 2019-11-11 06:53:54 --> Output Class Initialized
INFO - 2019-11-11 06:53:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:54 --> Input Class Initialized
INFO - 2019-11-11 06:53:54 --> Language Class Initialized
INFO - 2019-11-11 06:53:54 --> Language Class Initialized
INFO - 2019-11-11 06:53:54 --> Config Class Initialized
INFO - 2019-11-11 06:53:54 --> Loader Class Initialized
INFO - 2019-11-11 06:53:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:54 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:54 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:54 --> Total execution time: 0.0843
INFO - 2019-11-11 06:53:54 --> Config Class Initialized
INFO - 2019-11-11 06:53:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:54 --> URI Class Initialized
INFO - 2019-11-11 06:53:54 --> Router Class Initialized
INFO - 2019-11-11 06:53:54 --> Output Class Initialized
INFO - 2019-11-11 06:53:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:54 --> Input Class Initialized
INFO - 2019-11-11 06:53:54 --> Language Class Initialized
INFO - 2019-11-11 06:53:54 --> Language Class Initialized
INFO - 2019-11-11 06:53:54 --> Config Class Initialized
INFO - 2019-11-11 06:53:54 --> Loader Class Initialized
INFO - 2019-11-11 06:53:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:54 --> Controller Class Initialized
INFO - 2019-11-11 06:53:55 --> Config Class Initialized
INFO - 2019-11-11 06:53:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:55 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:55 --> URI Class Initialized
INFO - 2019-11-11 06:53:55 --> Router Class Initialized
INFO - 2019-11-11 06:53:55 --> Output Class Initialized
INFO - 2019-11-11 06:53:55 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:55 --> Input Class Initialized
INFO - 2019-11-11 06:53:55 --> Language Class Initialized
INFO - 2019-11-11 06:53:55 --> Language Class Initialized
INFO - 2019-11-11 06:53:55 --> Config Class Initialized
INFO - 2019-11-11 06:53:55 --> Loader Class Initialized
INFO - 2019-11-11 06:53:55 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:55 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:55 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:55 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:55 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:55 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:55 --> Total execution time: 0.0835
INFO - 2019-11-11 06:53:59 --> Config Class Initialized
INFO - 2019-11-11 06:53:59 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:59 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:59 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:59 --> URI Class Initialized
INFO - 2019-11-11 06:53:59 --> Router Class Initialized
INFO - 2019-11-11 06:53:59 --> Output Class Initialized
INFO - 2019-11-11 06:53:59 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:59 --> Input Class Initialized
INFO - 2019-11-11 06:53:59 --> Language Class Initialized
INFO - 2019-11-11 06:53:59 --> Language Class Initialized
INFO - 2019-11-11 06:53:59 --> Config Class Initialized
INFO - 2019-11-11 06:53:59 --> Loader Class Initialized
INFO - 2019-11-11 06:53:59 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:59 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:59 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:59 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:53:59 --> Controller Class Initialized
DEBUG - 2019-11-11 06:53:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:53:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:53:59 --> Final output sent to browser
DEBUG - 2019-11-11 06:53:59 --> Total execution time: 0.0839
INFO - 2019-11-11 06:53:59 --> Config Class Initialized
INFO - 2019-11-11 06:53:59 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:53:59 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:53:59 --> Utf8 Class Initialized
INFO - 2019-11-11 06:53:59 --> URI Class Initialized
INFO - 2019-11-11 06:53:59 --> Router Class Initialized
INFO - 2019-11-11 06:53:59 --> Output Class Initialized
INFO - 2019-11-11 06:53:59 --> Security Class Initialized
DEBUG - 2019-11-11 06:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:53:59 --> Input Class Initialized
INFO - 2019-11-11 06:53:59 --> Language Class Initialized
INFO - 2019-11-11 06:53:59 --> Language Class Initialized
INFO - 2019-11-11 06:53:59 --> Config Class Initialized
INFO - 2019-11-11 06:53:59 --> Loader Class Initialized
INFO - 2019-11-11 06:53:59 --> Helper loaded: url_helper
INFO - 2019-11-11 06:53:59 --> Helper loaded: file_helper
INFO - 2019-11-11 06:53:59 --> Helper loaded: form_helper
INFO - 2019-11-11 06:53:59 --> Helper loaded: my_helper
INFO - 2019-11-11 06:53:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:00 --> Controller Class Initialized
INFO - 2019-11-11 06:54:01 --> Config Class Initialized
INFO - 2019-11-11 06:54:01 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:01 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:01 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:01 --> URI Class Initialized
INFO - 2019-11-11 06:54:01 --> Router Class Initialized
INFO - 2019-11-11 06:54:01 --> Output Class Initialized
INFO - 2019-11-11 06:54:01 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:01 --> Input Class Initialized
INFO - 2019-11-11 06:54:01 --> Language Class Initialized
INFO - 2019-11-11 06:54:01 --> Language Class Initialized
INFO - 2019-11-11 06:54:01 --> Config Class Initialized
INFO - 2019-11-11 06:54:01 --> Loader Class Initialized
INFO - 2019-11-11 06:54:01 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:01 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:01 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:01 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:01 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:01 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:54:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:01 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:01 --> Total execution time: 0.0880
INFO - 2019-11-11 06:54:05 --> Config Class Initialized
INFO - 2019-11-11 06:54:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:05 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:05 --> URI Class Initialized
INFO - 2019-11-11 06:54:05 --> Router Class Initialized
INFO - 2019-11-11 06:54:05 --> Output Class Initialized
INFO - 2019-11-11 06:54:05 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:05 --> Input Class Initialized
INFO - 2019-11-11 06:54:05 --> Language Class Initialized
INFO - 2019-11-11 06:54:05 --> Language Class Initialized
INFO - 2019-11-11 06:54:05 --> Config Class Initialized
INFO - 2019-11-11 06:54:05 --> Loader Class Initialized
INFO - 2019-11-11 06:54:05 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:05 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:05 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:05 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:05 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:05 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:54:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:05 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:05 --> Total execution time: 0.0748
INFO - 2019-11-11 06:54:05 --> Config Class Initialized
INFO - 2019-11-11 06:54:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:05 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:05 --> URI Class Initialized
INFO - 2019-11-11 06:54:05 --> Router Class Initialized
INFO - 2019-11-11 06:54:05 --> Output Class Initialized
INFO - 2019-11-11 06:54:05 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:05 --> Input Class Initialized
INFO - 2019-11-11 06:54:05 --> Language Class Initialized
INFO - 2019-11-11 06:54:05 --> Language Class Initialized
INFO - 2019-11-11 06:54:05 --> Config Class Initialized
INFO - 2019-11-11 06:54:05 --> Loader Class Initialized
INFO - 2019-11-11 06:54:05 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:05 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:05 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:05 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:05 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:05 --> Controller Class Initialized
INFO - 2019-11-11 06:54:06 --> Config Class Initialized
INFO - 2019-11-11 06:54:06 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:06 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:06 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:06 --> URI Class Initialized
INFO - 2019-11-11 06:54:06 --> Router Class Initialized
INFO - 2019-11-11 06:54:06 --> Output Class Initialized
INFO - 2019-11-11 06:54:06 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:06 --> Input Class Initialized
INFO - 2019-11-11 06:54:06 --> Language Class Initialized
INFO - 2019-11-11 06:54:06 --> Language Class Initialized
INFO - 2019-11-11 06:54:06 --> Config Class Initialized
INFO - 2019-11-11 06:54:06 --> Loader Class Initialized
INFO - 2019-11-11 06:54:06 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:06 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:06 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:06 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:06 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:06 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:06 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:06 --> Total execution time: 0.0913
INFO - 2019-11-11 06:54:10 --> Config Class Initialized
INFO - 2019-11-11 06:54:10 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:10 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:10 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:10 --> URI Class Initialized
INFO - 2019-11-11 06:54:10 --> Router Class Initialized
INFO - 2019-11-11 06:54:10 --> Output Class Initialized
INFO - 2019-11-11 06:54:10 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:10 --> Input Class Initialized
INFO - 2019-11-11 06:54:10 --> Language Class Initialized
INFO - 2019-11-11 06:54:10 --> Language Class Initialized
INFO - 2019-11-11 06:54:10 --> Config Class Initialized
INFO - 2019-11-11 06:54:10 --> Loader Class Initialized
INFO - 2019-11-11 06:54:10 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:10 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:10 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:10 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:10 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:10 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:54:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:10 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:10 --> Total execution time: 0.1018
INFO - 2019-11-11 06:54:10 --> Config Class Initialized
INFO - 2019-11-11 06:54:10 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:10 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:10 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:10 --> URI Class Initialized
INFO - 2019-11-11 06:54:10 --> Router Class Initialized
INFO - 2019-11-11 06:54:10 --> Output Class Initialized
INFO - 2019-11-11 06:54:10 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:10 --> Input Class Initialized
INFO - 2019-11-11 06:54:10 --> Language Class Initialized
INFO - 2019-11-11 06:54:10 --> Language Class Initialized
INFO - 2019-11-11 06:54:10 --> Config Class Initialized
INFO - 2019-11-11 06:54:10 --> Loader Class Initialized
INFO - 2019-11-11 06:54:10 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:10 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:10 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:10 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:10 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:10 --> Controller Class Initialized
INFO - 2019-11-11 06:54:11 --> Config Class Initialized
INFO - 2019-11-11 06:54:11 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:11 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:11 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:11 --> URI Class Initialized
INFO - 2019-11-11 06:54:11 --> Router Class Initialized
INFO - 2019-11-11 06:54:11 --> Output Class Initialized
INFO - 2019-11-11 06:54:11 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:11 --> Input Class Initialized
INFO - 2019-11-11 06:54:11 --> Language Class Initialized
INFO - 2019-11-11 06:54:11 --> Language Class Initialized
INFO - 2019-11-11 06:54:11 --> Config Class Initialized
INFO - 2019-11-11 06:54:11 --> Loader Class Initialized
INFO - 2019-11-11 06:54:11 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:11 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:11 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:11 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:11 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:11 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:54:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:11 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:11 --> Total execution time: 0.0875
INFO - 2019-11-11 06:54:15 --> Config Class Initialized
INFO - 2019-11-11 06:54:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:15 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:15 --> URI Class Initialized
INFO - 2019-11-11 06:54:15 --> Router Class Initialized
INFO - 2019-11-11 06:54:15 --> Output Class Initialized
INFO - 2019-11-11 06:54:15 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:15 --> Input Class Initialized
INFO - 2019-11-11 06:54:15 --> Language Class Initialized
INFO - 2019-11-11 06:54:15 --> Language Class Initialized
INFO - 2019-11-11 06:54:15 --> Config Class Initialized
INFO - 2019-11-11 06:54:15 --> Loader Class Initialized
INFO - 2019-11-11 06:54:15 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:15 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:15 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:15 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:15 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:54:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:15 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:15 --> Total execution time: 0.0906
INFO - 2019-11-11 06:54:15 --> Config Class Initialized
INFO - 2019-11-11 06:54:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:15 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:15 --> URI Class Initialized
INFO - 2019-11-11 06:54:15 --> Router Class Initialized
INFO - 2019-11-11 06:54:15 --> Output Class Initialized
INFO - 2019-11-11 06:54:15 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:15 --> Input Class Initialized
INFO - 2019-11-11 06:54:15 --> Language Class Initialized
INFO - 2019-11-11 06:54:15 --> Language Class Initialized
INFO - 2019-11-11 06:54:15 --> Config Class Initialized
INFO - 2019-11-11 06:54:15 --> Loader Class Initialized
INFO - 2019-11-11 06:54:15 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:15 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:15 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:15 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:15 --> Controller Class Initialized
INFO - 2019-11-11 06:54:16 --> Config Class Initialized
INFO - 2019-11-11 06:54:16 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:16 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:16 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:16 --> URI Class Initialized
INFO - 2019-11-11 06:54:16 --> Router Class Initialized
INFO - 2019-11-11 06:54:16 --> Output Class Initialized
INFO - 2019-11-11 06:54:16 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:16 --> Input Class Initialized
INFO - 2019-11-11 06:54:16 --> Language Class Initialized
INFO - 2019-11-11 06:54:16 --> Language Class Initialized
INFO - 2019-11-11 06:54:16 --> Config Class Initialized
INFO - 2019-11-11 06:54:16 --> Loader Class Initialized
INFO - 2019-11-11 06:54:16 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:16 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:16 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:16 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:16 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:16 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:54:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:16 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:16 --> Total execution time: 0.0850
INFO - 2019-11-11 06:54:20 --> Config Class Initialized
INFO - 2019-11-11 06:54:20 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:20 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:20 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:20 --> URI Class Initialized
INFO - 2019-11-11 06:54:20 --> Router Class Initialized
INFO - 2019-11-11 06:54:20 --> Output Class Initialized
INFO - 2019-11-11 06:54:20 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:20 --> Input Class Initialized
INFO - 2019-11-11 06:54:20 --> Language Class Initialized
INFO - 2019-11-11 06:54:20 --> Language Class Initialized
INFO - 2019-11-11 06:54:20 --> Config Class Initialized
INFO - 2019-11-11 06:54:20 --> Loader Class Initialized
INFO - 2019-11-11 06:54:20 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:20 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:20 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:20 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:20 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:20 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:54:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:20 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:20 --> Total execution time: 0.0769
INFO - 2019-11-11 06:54:20 --> Config Class Initialized
INFO - 2019-11-11 06:54:20 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:20 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:20 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:20 --> URI Class Initialized
INFO - 2019-11-11 06:54:20 --> Router Class Initialized
INFO - 2019-11-11 06:54:20 --> Output Class Initialized
INFO - 2019-11-11 06:54:20 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:20 --> Input Class Initialized
INFO - 2019-11-11 06:54:20 --> Language Class Initialized
INFO - 2019-11-11 06:54:20 --> Language Class Initialized
INFO - 2019-11-11 06:54:20 --> Config Class Initialized
INFO - 2019-11-11 06:54:20 --> Loader Class Initialized
INFO - 2019-11-11 06:54:20 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:20 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:20 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:20 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:20 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:20 --> Controller Class Initialized
INFO - 2019-11-11 06:54:21 --> Config Class Initialized
INFO - 2019-11-11 06:54:21 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:21 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:21 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:21 --> URI Class Initialized
INFO - 2019-11-11 06:54:21 --> Router Class Initialized
INFO - 2019-11-11 06:54:21 --> Output Class Initialized
INFO - 2019-11-11 06:54:21 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:21 --> Input Class Initialized
INFO - 2019-11-11 06:54:21 --> Language Class Initialized
INFO - 2019-11-11 06:54:21 --> Language Class Initialized
INFO - 2019-11-11 06:54:21 --> Config Class Initialized
INFO - 2019-11-11 06:54:21 --> Loader Class Initialized
INFO - 2019-11-11 06:54:21 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:21 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:21 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:21 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:21 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:21 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:21 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:21 --> Total execution time: 0.0816
INFO - 2019-11-11 06:54:24 --> Config Class Initialized
INFO - 2019-11-11 06:54:24 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:24 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:24 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:24 --> URI Class Initialized
INFO - 2019-11-11 06:54:24 --> Router Class Initialized
INFO - 2019-11-11 06:54:24 --> Output Class Initialized
INFO - 2019-11-11 06:54:24 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:24 --> Input Class Initialized
INFO - 2019-11-11 06:54:24 --> Language Class Initialized
INFO - 2019-11-11 06:54:24 --> Language Class Initialized
INFO - 2019-11-11 06:54:24 --> Config Class Initialized
INFO - 2019-11-11 06:54:24 --> Loader Class Initialized
INFO - 2019-11-11 06:54:24 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:24 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:24 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:24 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:24 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:24 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 06:54:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:24 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:24 --> Total execution time: 0.0987
INFO - 2019-11-11 06:54:25 --> Config Class Initialized
INFO - 2019-11-11 06:54:25 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:25 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:25 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:25 --> URI Class Initialized
INFO - 2019-11-11 06:54:25 --> Router Class Initialized
INFO - 2019-11-11 06:54:25 --> Output Class Initialized
INFO - 2019-11-11 06:54:25 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:25 --> Input Class Initialized
INFO - 2019-11-11 06:54:25 --> Language Class Initialized
INFO - 2019-11-11 06:54:25 --> Language Class Initialized
INFO - 2019-11-11 06:54:25 --> Config Class Initialized
INFO - 2019-11-11 06:54:25 --> Loader Class Initialized
INFO - 2019-11-11 06:54:25 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:25 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:25 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:25 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:25 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:25 --> Controller Class Initialized
INFO - 2019-11-11 06:54:25 --> Config Class Initialized
INFO - 2019-11-11 06:54:25 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:25 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:25 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:25 --> URI Class Initialized
INFO - 2019-11-11 06:54:25 --> Router Class Initialized
INFO - 2019-11-11 06:54:25 --> Output Class Initialized
INFO - 2019-11-11 06:54:25 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:25 --> Input Class Initialized
INFO - 2019-11-11 06:54:25 --> Language Class Initialized
INFO - 2019-11-11 06:54:25 --> Language Class Initialized
INFO - 2019-11-11 06:54:25 --> Config Class Initialized
INFO - 2019-11-11 06:54:25 --> Loader Class Initialized
INFO - 2019-11-11 06:54:25 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:25 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:25 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:25 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:25 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:26 --> Controller Class Initialized
DEBUG - 2019-11-11 06:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 06:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 06:54:26 --> Final output sent to browser
DEBUG - 2019-11-11 06:54:26 --> Total execution time: 0.1077
INFO - 2019-11-11 06:54:37 --> Config Class Initialized
INFO - 2019-11-11 06:54:37 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:37 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:37 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:37 --> URI Class Initialized
INFO - 2019-11-11 06:54:37 --> Router Class Initialized
INFO - 2019-11-11 06:54:37 --> Output Class Initialized
INFO - 2019-11-11 06:54:37 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:37 --> Input Class Initialized
INFO - 2019-11-11 06:54:37 --> Language Class Initialized
INFO - 2019-11-11 06:54:37 --> Language Class Initialized
INFO - 2019-11-11 06:54:37 --> Config Class Initialized
INFO - 2019-11-11 06:54:37 --> Loader Class Initialized
INFO - 2019-11-11 06:54:37 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:37 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:37 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:37 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:38 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:38 --> Controller Class Initialized
INFO - 2019-11-11 06:54:41 --> Config Class Initialized
INFO - 2019-11-11 06:54:41 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:41 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:41 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:41 --> URI Class Initialized
INFO - 2019-11-11 06:54:41 --> Router Class Initialized
INFO - 2019-11-11 06:54:41 --> Output Class Initialized
INFO - 2019-11-11 06:54:41 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:41 --> Input Class Initialized
INFO - 2019-11-11 06:54:41 --> Language Class Initialized
INFO - 2019-11-11 06:54:41 --> Language Class Initialized
INFO - 2019-11-11 06:54:41 --> Config Class Initialized
INFO - 2019-11-11 06:54:41 --> Loader Class Initialized
INFO - 2019-11-11 06:54:41 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:41 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:41 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:41 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:41 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:41 --> Controller Class Initialized
INFO - 2019-11-11 06:54:44 --> Config Class Initialized
INFO - 2019-11-11 06:54:44 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:44 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:44 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:44 --> URI Class Initialized
INFO - 2019-11-11 06:54:44 --> Router Class Initialized
INFO - 2019-11-11 06:54:44 --> Output Class Initialized
INFO - 2019-11-11 06:54:44 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:44 --> Input Class Initialized
INFO - 2019-11-11 06:54:44 --> Language Class Initialized
INFO - 2019-11-11 06:54:44 --> Language Class Initialized
INFO - 2019-11-11 06:54:44 --> Config Class Initialized
INFO - 2019-11-11 06:54:44 --> Loader Class Initialized
INFO - 2019-11-11 06:54:44 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:44 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:44 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:44 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:44 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:44 --> Controller Class Initialized
INFO - 2019-11-11 06:54:46 --> Config Class Initialized
INFO - 2019-11-11 06:54:46 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:46 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:46 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:46 --> URI Class Initialized
INFO - 2019-11-11 06:54:46 --> Router Class Initialized
INFO - 2019-11-11 06:54:46 --> Output Class Initialized
INFO - 2019-11-11 06:54:46 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:46 --> Input Class Initialized
INFO - 2019-11-11 06:54:46 --> Language Class Initialized
INFO - 2019-11-11 06:54:46 --> Language Class Initialized
INFO - 2019-11-11 06:54:46 --> Config Class Initialized
INFO - 2019-11-11 06:54:46 --> Loader Class Initialized
INFO - 2019-11-11 06:54:46 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:46 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:46 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:46 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:46 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:46 --> Controller Class Initialized
INFO - 2019-11-11 06:54:51 --> Config Class Initialized
INFO - 2019-11-11 06:54:51 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:51 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:51 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:51 --> URI Class Initialized
INFO - 2019-11-11 06:54:51 --> Router Class Initialized
INFO - 2019-11-11 06:54:51 --> Output Class Initialized
INFO - 2019-11-11 06:54:51 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:51 --> Input Class Initialized
INFO - 2019-11-11 06:54:51 --> Language Class Initialized
INFO - 2019-11-11 06:54:51 --> Language Class Initialized
INFO - 2019-11-11 06:54:51 --> Config Class Initialized
INFO - 2019-11-11 06:54:51 --> Loader Class Initialized
INFO - 2019-11-11 06:54:51 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:51 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:51 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:51 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:51 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:51 --> Controller Class Initialized
INFO - 2019-11-11 06:54:53 --> Config Class Initialized
INFO - 2019-11-11 06:54:53 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:53 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:53 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:53 --> URI Class Initialized
INFO - 2019-11-11 06:54:53 --> Router Class Initialized
INFO - 2019-11-11 06:54:53 --> Output Class Initialized
INFO - 2019-11-11 06:54:53 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:53 --> Input Class Initialized
INFO - 2019-11-11 06:54:53 --> Language Class Initialized
INFO - 2019-11-11 06:54:53 --> Language Class Initialized
INFO - 2019-11-11 06:54:53 --> Config Class Initialized
INFO - 2019-11-11 06:54:53 --> Loader Class Initialized
INFO - 2019-11-11 06:54:53 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:53 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:53 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:53 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:53 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:53 --> Controller Class Initialized
INFO - 2019-11-11 06:54:54 --> Config Class Initialized
INFO - 2019-11-11 06:54:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:54 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:54 --> URI Class Initialized
INFO - 2019-11-11 06:54:54 --> Router Class Initialized
INFO - 2019-11-11 06:54:54 --> Output Class Initialized
INFO - 2019-11-11 06:54:54 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:54 --> Input Class Initialized
INFO - 2019-11-11 06:54:54 --> Language Class Initialized
INFO - 2019-11-11 06:54:54 --> Language Class Initialized
INFO - 2019-11-11 06:54:54 --> Config Class Initialized
INFO - 2019-11-11 06:54:54 --> Loader Class Initialized
INFO - 2019-11-11 06:54:54 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:54 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:54 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:54 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:54 --> Controller Class Initialized
INFO - 2019-11-11 06:54:56 --> Config Class Initialized
INFO - 2019-11-11 06:54:56 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:56 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:56 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:56 --> URI Class Initialized
INFO - 2019-11-11 06:54:56 --> Router Class Initialized
INFO - 2019-11-11 06:54:56 --> Output Class Initialized
INFO - 2019-11-11 06:54:56 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:56 --> Input Class Initialized
INFO - 2019-11-11 06:54:56 --> Language Class Initialized
INFO - 2019-11-11 06:54:56 --> Language Class Initialized
INFO - 2019-11-11 06:54:56 --> Config Class Initialized
INFO - 2019-11-11 06:54:56 --> Loader Class Initialized
INFO - 2019-11-11 06:54:56 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:56 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:56 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:56 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:56 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:56 --> Controller Class Initialized
INFO - 2019-11-11 06:54:58 --> Config Class Initialized
INFO - 2019-11-11 06:54:58 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:58 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:58 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:58 --> URI Class Initialized
INFO - 2019-11-11 06:54:58 --> Router Class Initialized
INFO - 2019-11-11 06:54:58 --> Output Class Initialized
INFO - 2019-11-11 06:54:58 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:58 --> Input Class Initialized
INFO - 2019-11-11 06:54:58 --> Language Class Initialized
INFO - 2019-11-11 06:54:58 --> Language Class Initialized
INFO - 2019-11-11 06:54:58 --> Config Class Initialized
INFO - 2019-11-11 06:54:58 --> Loader Class Initialized
INFO - 2019-11-11 06:54:58 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:58 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:58 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:58 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:58 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:58 --> Controller Class Initialized
INFO - 2019-11-11 06:54:59 --> Config Class Initialized
INFO - 2019-11-11 06:54:59 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:54:59 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:54:59 --> Utf8 Class Initialized
INFO - 2019-11-11 06:54:59 --> URI Class Initialized
INFO - 2019-11-11 06:54:59 --> Router Class Initialized
INFO - 2019-11-11 06:54:59 --> Output Class Initialized
INFO - 2019-11-11 06:54:59 --> Security Class Initialized
DEBUG - 2019-11-11 06:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:54:59 --> Input Class Initialized
INFO - 2019-11-11 06:54:59 --> Language Class Initialized
INFO - 2019-11-11 06:54:59 --> Language Class Initialized
INFO - 2019-11-11 06:54:59 --> Config Class Initialized
INFO - 2019-11-11 06:54:59 --> Loader Class Initialized
INFO - 2019-11-11 06:54:59 --> Helper loaded: url_helper
INFO - 2019-11-11 06:54:59 --> Helper loaded: file_helper
INFO - 2019-11-11 06:54:59 --> Helper loaded: form_helper
INFO - 2019-11-11 06:54:59 --> Helper loaded: my_helper
INFO - 2019-11-11 06:54:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:54:59 --> Controller Class Initialized
INFO - 2019-11-11 06:55:01 --> Config Class Initialized
INFO - 2019-11-11 06:55:01 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:01 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:01 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:01 --> URI Class Initialized
INFO - 2019-11-11 06:55:01 --> Router Class Initialized
INFO - 2019-11-11 06:55:01 --> Output Class Initialized
INFO - 2019-11-11 06:55:01 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:01 --> Input Class Initialized
INFO - 2019-11-11 06:55:01 --> Language Class Initialized
INFO - 2019-11-11 06:55:01 --> Language Class Initialized
INFO - 2019-11-11 06:55:01 --> Config Class Initialized
INFO - 2019-11-11 06:55:01 --> Loader Class Initialized
INFO - 2019-11-11 06:55:01 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:01 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:01 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:01 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:01 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:01 --> Controller Class Initialized
INFO - 2019-11-11 06:55:03 --> Config Class Initialized
INFO - 2019-11-11 06:55:03 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:03 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:03 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:03 --> URI Class Initialized
INFO - 2019-11-11 06:55:03 --> Router Class Initialized
INFO - 2019-11-11 06:55:03 --> Output Class Initialized
INFO - 2019-11-11 06:55:03 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:03 --> Input Class Initialized
INFO - 2019-11-11 06:55:03 --> Language Class Initialized
INFO - 2019-11-11 06:55:03 --> Language Class Initialized
INFO - 2019-11-11 06:55:03 --> Config Class Initialized
INFO - 2019-11-11 06:55:03 --> Loader Class Initialized
INFO - 2019-11-11 06:55:03 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:03 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:03 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:03 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:03 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:03 --> Controller Class Initialized
INFO - 2019-11-11 06:55:04 --> Config Class Initialized
INFO - 2019-11-11 06:55:04 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:04 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:04 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:04 --> URI Class Initialized
INFO - 2019-11-11 06:55:04 --> Router Class Initialized
INFO - 2019-11-11 06:55:04 --> Output Class Initialized
INFO - 2019-11-11 06:55:04 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:04 --> Input Class Initialized
INFO - 2019-11-11 06:55:04 --> Language Class Initialized
INFO - 2019-11-11 06:55:04 --> Language Class Initialized
INFO - 2019-11-11 06:55:04 --> Config Class Initialized
INFO - 2019-11-11 06:55:04 --> Loader Class Initialized
INFO - 2019-11-11 06:55:04 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:04 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:04 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:04 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:04 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:04 --> Controller Class Initialized
INFO - 2019-11-11 06:55:06 --> Config Class Initialized
INFO - 2019-11-11 06:55:06 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:06 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:06 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:06 --> URI Class Initialized
INFO - 2019-11-11 06:55:06 --> Router Class Initialized
INFO - 2019-11-11 06:55:06 --> Output Class Initialized
INFO - 2019-11-11 06:55:06 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:06 --> Input Class Initialized
INFO - 2019-11-11 06:55:06 --> Language Class Initialized
INFO - 2019-11-11 06:55:06 --> Language Class Initialized
INFO - 2019-11-11 06:55:06 --> Config Class Initialized
INFO - 2019-11-11 06:55:06 --> Loader Class Initialized
INFO - 2019-11-11 06:55:06 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:06 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:06 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:06 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:06 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:06 --> Controller Class Initialized
INFO - 2019-11-11 06:55:07 --> Config Class Initialized
INFO - 2019-11-11 06:55:07 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:07 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:07 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:07 --> URI Class Initialized
INFO - 2019-11-11 06:55:07 --> Router Class Initialized
INFO - 2019-11-11 06:55:07 --> Output Class Initialized
INFO - 2019-11-11 06:55:07 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:07 --> Input Class Initialized
INFO - 2019-11-11 06:55:07 --> Language Class Initialized
INFO - 2019-11-11 06:55:07 --> Language Class Initialized
INFO - 2019-11-11 06:55:07 --> Config Class Initialized
INFO - 2019-11-11 06:55:07 --> Loader Class Initialized
INFO - 2019-11-11 06:55:07 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:07 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:07 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:07 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:07 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:07 --> Controller Class Initialized
INFO - 2019-11-11 06:55:09 --> Config Class Initialized
INFO - 2019-11-11 06:55:09 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:09 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:09 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:09 --> URI Class Initialized
INFO - 2019-11-11 06:55:09 --> Router Class Initialized
INFO - 2019-11-11 06:55:09 --> Output Class Initialized
INFO - 2019-11-11 06:55:09 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:09 --> Input Class Initialized
INFO - 2019-11-11 06:55:09 --> Language Class Initialized
INFO - 2019-11-11 06:55:09 --> Language Class Initialized
INFO - 2019-11-11 06:55:09 --> Config Class Initialized
INFO - 2019-11-11 06:55:09 --> Loader Class Initialized
INFO - 2019-11-11 06:55:09 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:09 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:09 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:09 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:09 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:09 --> Controller Class Initialized
INFO - 2019-11-11 06:55:12 --> Config Class Initialized
INFO - 2019-11-11 06:55:12 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:12 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:12 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:12 --> URI Class Initialized
INFO - 2019-11-11 06:55:12 --> Router Class Initialized
INFO - 2019-11-11 06:55:12 --> Output Class Initialized
INFO - 2019-11-11 06:55:12 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:12 --> Input Class Initialized
INFO - 2019-11-11 06:55:12 --> Language Class Initialized
INFO - 2019-11-11 06:55:12 --> Language Class Initialized
INFO - 2019-11-11 06:55:12 --> Config Class Initialized
INFO - 2019-11-11 06:55:12 --> Loader Class Initialized
INFO - 2019-11-11 06:55:12 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:12 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:12 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:12 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:12 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:12 --> Controller Class Initialized
INFO - 2019-11-11 06:55:14 --> Config Class Initialized
INFO - 2019-11-11 06:55:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:14 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:14 --> URI Class Initialized
INFO - 2019-11-11 06:55:14 --> Router Class Initialized
INFO - 2019-11-11 06:55:14 --> Output Class Initialized
INFO - 2019-11-11 06:55:14 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:14 --> Input Class Initialized
INFO - 2019-11-11 06:55:14 --> Language Class Initialized
INFO - 2019-11-11 06:55:14 --> Language Class Initialized
INFO - 2019-11-11 06:55:14 --> Config Class Initialized
INFO - 2019-11-11 06:55:14 --> Loader Class Initialized
INFO - 2019-11-11 06:55:14 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:14 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:14 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:14 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:14 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:14 --> Controller Class Initialized
INFO - 2019-11-11 06:55:16 --> Config Class Initialized
INFO - 2019-11-11 06:55:16 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:16 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:16 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:16 --> URI Class Initialized
INFO - 2019-11-11 06:55:16 --> Router Class Initialized
INFO - 2019-11-11 06:55:16 --> Output Class Initialized
INFO - 2019-11-11 06:55:16 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:16 --> Input Class Initialized
INFO - 2019-11-11 06:55:16 --> Language Class Initialized
INFO - 2019-11-11 06:55:16 --> Language Class Initialized
INFO - 2019-11-11 06:55:16 --> Config Class Initialized
INFO - 2019-11-11 06:55:16 --> Loader Class Initialized
INFO - 2019-11-11 06:55:16 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:16 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:16 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:16 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:16 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:16 --> Controller Class Initialized
INFO - 2019-11-11 06:55:18 --> Config Class Initialized
INFO - 2019-11-11 06:55:18 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:18 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:18 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:18 --> URI Class Initialized
INFO - 2019-11-11 06:55:18 --> Router Class Initialized
INFO - 2019-11-11 06:55:18 --> Output Class Initialized
INFO - 2019-11-11 06:55:18 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:18 --> Input Class Initialized
INFO - 2019-11-11 06:55:18 --> Language Class Initialized
INFO - 2019-11-11 06:55:18 --> Language Class Initialized
INFO - 2019-11-11 06:55:18 --> Config Class Initialized
INFO - 2019-11-11 06:55:18 --> Loader Class Initialized
INFO - 2019-11-11 06:55:18 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:18 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:18 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:18 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:18 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:18 --> Controller Class Initialized
INFO - 2019-11-11 06:55:20 --> Config Class Initialized
INFO - 2019-11-11 06:55:20 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:20 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:20 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:20 --> URI Class Initialized
INFO - 2019-11-11 06:55:20 --> Router Class Initialized
INFO - 2019-11-11 06:55:20 --> Output Class Initialized
INFO - 2019-11-11 06:55:20 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:20 --> Input Class Initialized
INFO - 2019-11-11 06:55:20 --> Language Class Initialized
INFO - 2019-11-11 06:55:20 --> Language Class Initialized
INFO - 2019-11-11 06:55:20 --> Config Class Initialized
INFO - 2019-11-11 06:55:20 --> Loader Class Initialized
INFO - 2019-11-11 06:55:20 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:20 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:20 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:20 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:20 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:20 --> Controller Class Initialized
INFO - 2019-11-11 06:55:22 --> Config Class Initialized
INFO - 2019-11-11 06:55:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:22 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:22 --> URI Class Initialized
INFO - 2019-11-11 06:55:22 --> Router Class Initialized
INFO - 2019-11-11 06:55:22 --> Output Class Initialized
INFO - 2019-11-11 06:55:22 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:22 --> Input Class Initialized
INFO - 2019-11-11 06:55:22 --> Language Class Initialized
INFO - 2019-11-11 06:55:22 --> Language Class Initialized
INFO - 2019-11-11 06:55:22 --> Config Class Initialized
INFO - 2019-11-11 06:55:22 --> Loader Class Initialized
INFO - 2019-11-11 06:55:22 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:22 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:22 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:22 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:22 --> Controller Class Initialized
INFO - 2019-11-11 06:55:23 --> Config Class Initialized
INFO - 2019-11-11 06:55:23 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:23 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:23 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:23 --> URI Class Initialized
INFO - 2019-11-11 06:55:23 --> Router Class Initialized
INFO - 2019-11-11 06:55:23 --> Output Class Initialized
INFO - 2019-11-11 06:55:23 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:23 --> Input Class Initialized
INFO - 2019-11-11 06:55:23 --> Language Class Initialized
INFO - 2019-11-11 06:55:23 --> Language Class Initialized
INFO - 2019-11-11 06:55:23 --> Config Class Initialized
INFO - 2019-11-11 06:55:23 --> Loader Class Initialized
INFO - 2019-11-11 06:55:23 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:23 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:23 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:23 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:23 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:23 --> Controller Class Initialized
INFO - 2019-11-11 06:55:26 --> Config Class Initialized
INFO - 2019-11-11 06:55:26 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:26 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:26 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:26 --> URI Class Initialized
INFO - 2019-11-11 06:55:26 --> Router Class Initialized
INFO - 2019-11-11 06:55:26 --> Output Class Initialized
INFO - 2019-11-11 06:55:26 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:26 --> Input Class Initialized
INFO - 2019-11-11 06:55:26 --> Language Class Initialized
INFO - 2019-11-11 06:55:26 --> Language Class Initialized
INFO - 2019-11-11 06:55:26 --> Config Class Initialized
INFO - 2019-11-11 06:55:26 --> Loader Class Initialized
INFO - 2019-11-11 06:55:26 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:26 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:26 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:26 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:26 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:26 --> Controller Class Initialized
INFO - 2019-11-11 06:55:27 --> Config Class Initialized
INFO - 2019-11-11 06:55:27 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:27 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:27 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:27 --> URI Class Initialized
INFO - 2019-11-11 06:55:27 --> Router Class Initialized
INFO - 2019-11-11 06:55:27 --> Output Class Initialized
INFO - 2019-11-11 06:55:27 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:27 --> Input Class Initialized
INFO - 2019-11-11 06:55:27 --> Language Class Initialized
INFO - 2019-11-11 06:55:27 --> Language Class Initialized
INFO - 2019-11-11 06:55:27 --> Config Class Initialized
INFO - 2019-11-11 06:55:27 --> Loader Class Initialized
INFO - 2019-11-11 06:55:27 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:27 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:27 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:27 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:27 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:27 --> Controller Class Initialized
INFO - 2019-11-11 06:55:29 --> Config Class Initialized
INFO - 2019-11-11 06:55:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:29 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:29 --> URI Class Initialized
INFO - 2019-11-11 06:55:29 --> Router Class Initialized
INFO - 2019-11-11 06:55:29 --> Output Class Initialized
INFO - 2019-11-11 06:55:29 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:29 --> Input Class Initialized
INFO - 2019-11-11 06:55:29 --> Language Class Initialized
INFO - 2019-11-11 06:55:29 --> Language Class Initialized
INFO - 2019-11-11 06:55:29 --> Config Class Initialized
INFO - 2019-11-11 06:55:29 --> Loader Class Initialized
INFO - 2019-11-11 06:55:29 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:29 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:29 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:29 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:29 --> Controller Class Initialized
INFO - 2019-11-11 06:55:31 --> Config Class Initialized
INFO - 2019-11-11 06:55:31 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:31 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:31 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:31 --> URI Class Initialized
INFO - 2019-11-11 06:55:31 --> Router Class Initialized
INFO - 2019-11-11 06:55:31 --> Output Class Initialized
INFO - 2019-11-11 06:55:31 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:31 --> Input Class Initialized
INFO - 2019-11-11 06:55:31 --> Language Class Initialized
INFO - 2019-11-11 06:55:31 --> Language Class Initialized
INFO - 2019-11-11 06:55:31 --> Config Class Initialized
INFO - 2019-11-11 06:55:31 --> Loader Class Initialized
INFO - 2019-11-11 06:55:31 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:31 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:31 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:31 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:31 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:31 --> Controller Class Initialized
INFO - 2019-11-11 06:55:33 --> Config Class Initialized
INFO - 2019-11-11 06:55:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:33 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:33 --> URI Class Initialized
INFO - 2019-11-11 06:55:33 --> Router Class Initialized
INFO - 2019-11-11 06:55:33 --> Output Class Initialized
INFO - 2019-11-11 06:55:33 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:33 --> Input Class Initialized
INFO - 2019-11-11 06:55:33 --> Language Class Initialized
INFO - 2019-11-11 06:55:33 --> Language Class Initialized
INFO - 2019-11-11 06:55:33 --> Config Class Initialized
INFO - 2019-11-11 06:55:33 --> Loader Class Initialized
INFO - 2019-11-11 06:55:33 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:33 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:33 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:33 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:33 --> Controller Class Initialized
INFO - 2019-11-11 06:55:35 --> Config Class Initialized
INFO - 2019-11-11 06:55:35 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:35 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:35 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:35 --> URI Class Initialized
INFO - 2019-11-11 06:55:35 --> Router Class Initialized
INFO - 2019-11-11 06:55:35 --> Output Class Initialized
INFO - 2019-11-11 06:55:36 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:36 --> Input Class Initialized
INFO - 2019-11-11 06:55:36 --> Language Class Initialized
INFO - 2019-11-11 06:55:36 --> Language Class Initialized
INFO - 2019-11-11 06:55:36 --> Config Class Initialized
INFO - 2019-11-11 06:55:36 --> Loader Class Initialized
INFO - 2019-11-11 06:55:36 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:36 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:36 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:36 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:36 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:36 --> Controller Class Initialized
INFO - 2019-11-11 06:55:37 --> Config Class Initialized
INFO - 2019-11-11 06:55:37 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:37 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:37 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:37 --> URI Class Initialized
INFO - 2019-11-11 06:55:37 --> Router Class Initialized
INFO - 2019-11-11 06:55:37 --> Output Class Initialized
INFO - 2019-11-11 06:55:38 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:38 --> Input Class Initialized
INFO - 2019-11-11 06:55:38 --> Language Class Initialized
INFO - 2019-11-11 06:55:38 --> Language Class Initialized
INFO - 2019-11-11 06:55:38 --> Config Class Initialized
INFO - 2019-11-11 06:55:38 --> Loader Class Initialized
INFO - 2019-11-11 06:55:38 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:38 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:38 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:38 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:38 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:38 --> Controller Class Initialized
INFO - 2019-11-11 06:55:40 --> Config Class Initialized
INFO - 2019-11-11 06:55:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:40 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:40 --> URI Class Initialized
INFO - 2019-11-11 06:55:40 --> Router Class Initialized
INFO - 2019-11-11 06:55:40 --> Output Class Initialized
INFO - 2019-11-11 06:55:40 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:40 --> Input Class Initialized
INFO - 2019-11-11 06:55:40 --> Language Class Initialized
INFO - 2019-11-11 06:55:40 --> Language Class Initialized
INFO - 2019-11-11 06:55:40 --> Config Class Initialized
INFO - 2019-11-11 06:55:40 --> Loader Class Initialized
INFO - 2019-11-11 06:55:40 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:40 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:40 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:40 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:40 --> Controller Class Initialized
INFO - 2019-11-11 06:55:42 --> Config Class Initialized
INFO - 2019-11-11 06:55:42 --> Hooks Class Initialized
DEBUG - 2019-11-11 06:55:42 --> UTF-8 Support Enabled
INFO - 2019-11-11 06:55:42 --> Utf8 Class Initialized
INFO - 2019-11-11 06:55:42 --> URI Class Initialized
INFO - 2019-11-11 06:55:42 --> Router Class Initialized
INFO - 2019-11-11 06:55:42 --> Output Class Initialized
INFO - 2019-11-11 06:55:42 --> Security Class Initialized
DEBUG - 2019-11-11 06:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 06:55:42 --> Input Class Initialized
INFO - 2019-11-11 06:55:42 --> Language Class Initialized
INFO - 2019-11-11 06:55:42 --> Language Class Initialized
INFO - 2019-11-11 06:55:42 --> Config Class Initialized
INFO - 2019-11-11 06:55:42 --> Loader Class Initialized
INFO - 2019-11-11 06:55:42 --> Helper loaded: url_helper
INFO - 2019-11-11 06:55:42 --> Helper loaded: file_helper
INFO - 2019-11-11 06:55:42 --> Helper loaded: form_helper
INFO - 2019-11-11 06:55:42 --> Helper loaded: my_helper
INFO - 2019-11-11 06:55:42 --> Database Driver Class Initialized
DEBUG - 2019-11-11 06:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 06:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 06:55:42 --> Controller Class Initialized
INFO - 2019-11-11 07:28:27 --> Config Class Initialized
INFO - 2019-11-11 07:28:27 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:27 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:27 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:27 --> URI Class Initialized
INFO - 2019-11-11 07:28:27 --> Router Class Initialized
INFO - 2019-11-11 07:28:27 --> Output Class Initialized
INFO - 2019-11-11 07:28:27 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:27 --> Input Class Initialized
INFO - 2019-11-11 07:28:27 --> Language Class Initialized
INFO - 2019-11-11 07:28:27 --> Language Class Initialized
INFO - 2019-11-11 07:28:27 --> Config Class Initialized
INFO - 2019-11-11 07:28:27 --> Loader Class Initialized
INFO - 2019-11-11 07:28:27 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:27 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:27 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:27 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:27 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:27 --> Controller Class Initialized
DEBUG - 2019-11-11 07:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:28:27 --> Final output sent to browser
DEBUG - 2019-11-11 07:28:27 --> Total execution time: 0.0892
INFO - 2019-11-11 07:28:44 --> Config Class Initialized
INFO - 2019-11-11 07:28:44 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:44 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:44 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:44 --> URI Class Initialized
INFO - 2019-11-11 07:28:44 --> Router Class Initialized
INFO - 2019-11-11 07:28:44 --> Output Class Initialized
INFO - 2019-11-11 07:28:44 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:44 --> Input Class Initialized
INFO - 2019-11-11 07:28:44 --> Language Class Initialized
INFO - 2019-11-11 07:28:44 --> Language Class Initialized
INFO - 2019-11-11 07:28:44 --> Config Class Initialized
INFO - 2019-11-11 07:28:44 --> Loader Class Initialized
INFO - 2019-11-11 07:28:44 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:44 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:44 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:44 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:44 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:44 --> Controller Class Initialized
INFO - 2019-11-11 07:28:44 --> Config Class Initialized
INFO - 2019-11-11 07:28:44 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:44 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:44 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:44 --> URI Class Initialized
INFO - 2019-11-11 07:28:44 --> Router Class Initialized
INFO - 2019-11-11 07:28:44 --> Output Class Initialized
INFO - 2019-11-11 07:28:44 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:44 --> Input Class Initialized
INFO - 2019-11-11 07:28:44 --> Language Class Initialized
INFO - 2019-11-11 07:28:44 --> Language Class Initialized
INFO - 2019-11-11 07:28:44 --> Config Class Initialized
INFO - 2019-11-11 07:28:44 --> Loader Class Initialized
INFO - 2019-11-11 07:28:44 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:44 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:44 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:44 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:44 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:44 --> Controller Class Initialized
DEBUG - 2019-11-11 07:28:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:28:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:28:44 --> Final output sent to browser
DEBUG - 2019-11-11 07:28:44 --> Total execution time: 0.1132
INFO - 2019-11-11 07:28:44 --> Config Class Initialized
INFO - 2019-11-11 07:28:44 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:44 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:44 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:44 --> URI Class Initialized
INFO - 2019-11-11 07:28:44 --> Router Class Initialized
INFO - 2019-11-11 07:28:44 --> Output Class Initialized
INFO - 2019-11-11 07:28:44 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:44 --> Input Class Initialized
INFO - 2019-11-11 07:28:44 --> Language Class Initialized
INFO - 2019-11-11 07:28:44 --> Language Class Initialized
INFO - 2019-11-11 07:28:44 --> Config Class Initialized
INFO - 2019-11-11 07:28:44 --> Loader Class Initialized
INFO - 2019-11-11 07:28:44 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:44 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:44 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:44 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:44 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:44 --> Controller Class Initialized
INFO - 2019-11-11 07:28:46 --> Config Class Initialized
INFO - 2019-11-11 07:28:46 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:46 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:46 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:46 --> URI Class Initialized
INFO - 2019-11-11 07:28:46 --> Router Class Initialized
INFO - 2019-11-11 07:28:46 --> Output Class Initialized
INFO - 2019-11-11 07:28:46 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:46 --> Input Class Initialized
INFO - 2019-11-11 07:28:46 --> Language Class Initialized
INFO - 2019-11-11 07:28:46 --> Language Class Initialized
INFO - 2019-11-11 07:28:46 --> Config Class Initialized
INFO - 2019-11-11 07:28:46 --> Loader Class Initialized
INFO - 2019-11-11 07:28:46 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:46 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:46 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:46 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:46 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:46 --> Controller Class Initialized
DEBUG - 2019-11-11 07:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:28:46 --> Final output sent to browser
DEBUG - 2019-11-11 07:28:46 --> Total execution time: 0.0959
INFO - 2019-11-11 07:28:51 --> Config Class Initialized
INFO - 2019-11-11 07:28:51 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:51 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:51 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:51 --> URI Class Initialized
INFO - 2019-11-11 07:28:51 --> Router Class Initialized
INFO - 2019-11-11 07:28:51 --> Output Class Initialized
INFO - 2019-11-11 07:28:51 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:51 --> Input Class Initialized
INFO - 2019-11-11 07:28:51 --> Language Class Initialized
INFO - 2019-11-11 07:28:51 --> Language Class Initialized
INFO - 2019-11-11 07:28:51 --> Config Class Initialized
INFO - 2019-11-11 07:28:51 --> Loader Class Initialized
INFO - 2019-11-11 07:28:51 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:51 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:51 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:51 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:51 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:51 --> Controller Class Initialized
INFO - 2019-11-11 07:28:51 --> Config Class Initialized
INFO - 2019-11-11 07:28:51 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:51 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:51 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:51 --> URI Class Initialized
INFO - 2019-11-11 07:28:51 --> Router Class Initialized
INFO - 2019-11-11 07:28:51 --> Output Class Initialized
INFO - 2019-11-11 07:28:51 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:51 --> Input Class Initialized
INFO - 2019-11-11 07:28:51 --> Language Class Initialized
INFO - 2019-11-11 07:28:51 --> Language Class Initialized
INFO - 2019-11-11 07:28:51 --> Config Class Initialized
INFO - 2019-11-11 07:28:51 --> Loader Class Initialized
INFO - 2019-11-11 07:28:51 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:51 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:51 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:51 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:51 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:51 --> Controller Class Initialized
DEBUG - 2019-11-11 07:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:28:51 --> Final output sent to browser
DEBUG - 2019-11-11 07:28:51 --> Total execution time: 0.0736
INFO - 2019-11-11 07:28:54 --> Config Class Initialized
INFO - 2019-11-11 07:28:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:54 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:54 --> URI Class Initialized
INFO - 2019-11-11 07:28:54 --> Router Class Initialized
INFO - 2019-11-11 07:28:54 --> Output Class Initialized
INFO - 2019-11-11 07:28:54 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:54 --> Input Class Initialized
INFO - 2019-11-11 07:28:54 --> Language Class Initialized
INFO - 2019-11-11 07:28:54 --> Language Class Initialized
INFO - 2019-11-11 07:28:54 --> Config Class Initialized
INFO - 2019-11-11 07:28:54 --> Loader Class Initialized
INFO - 2019-11-11 07:28:54 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:54 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:54 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:54 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:54 --> Controller Class Initialized
DEBUG - 2019-11-11 07:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:28:54 --> Final output sent to browser
DEBUG - 2019-11-11 07:28:54 --> Total execution time: 0.0859
INFO - 2019-11-11 07:28:58 --> Config Class Initialized
INFO - 2019-11-11 07:28:58 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:58 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:58 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:58 --> URI Class Initialized
INFO - 2019-11-11 07:28:58 --> Router Class Initialized
INFO - 2019-11-11 07:28:58 --> Output Class Initialized
INFO - 2019-11-11 07:28:58 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:58 --> Input Class Initialized
INFO - 2019-11-11 07:28:58 --> Language Class Initialized
INFO - 2019-11-11 07:28:58 --> Language Class Initialized
INFO - 2019-11-11 07:28:58 --> Config Class Initialized
INFO - 2019-11-11 07:28:58 --> Loader Class Initialized
INFO - 2019-11-11 07:28:58 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:58 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:58 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:58 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:58 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:58 --> Controller Class Initialized
INFO - 2019-11-11 07:28:58 --> Config Class Initialized
INFO - 2019-11-11 07:28:58 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:58 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:58 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:58 --> URI Class Initialized
INFO - 2019-11-11 07:28:58 --> Router Class Initialized
INFO - 2019-11-11 07:28:58 --> Output Class Initialized
INFO - 2019-11-11 07:28:58 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:58 --> Input Class Initialized
INFO - 2019-11-11 07:28:58 --> Language Class Initialized
INFO - 2019-11-11 07:28:58 --> Language Class Initialized
INFO - 2019-11-11 07:28:58 --> Config Class Initialized
INFO - 2019-11-11 07:28:58 --> Loader Class Initialized
INFO - 2019-11-11 07:28:58 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:58 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:58 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:58 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:58 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:58 --> Controller Class Initialized
DEBUG - 2019-11-11 07:28:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:28:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:28:58 --> Final output sent to browser
DEBUG - 2019-11-11 07:28:58 --> Total execution time: 0.0858
INFO - 2019-11-11 07:28:58 --> Config Class Initialized
INFO - 2019-11-11 07:28:58 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:28:58 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:28:58 --> Utf8 Class Initialized
INFO - 2019-11-11 07:28:58 --> URI Class Initialized
INFO - 2019-11-11 07:28:58 --> Router Class Initialized
INFO - 2019-11-11 07:28:58 --> Output Class Initialized
INFO - 2019-11-11 07:28:58 --> Security Class Initialized
DEBUG - 2019-11-11 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:28:58 --> Input Class Initialized
INFO - 2019-11-11 07:28:58 --> Language Class Initialized
INFO - 2019-11-11 07:28:59 --> Language Class Initialized
INFO - 2019-11-11 07:28:59 --> Config Class Initialized
INFO - 2019-11-11 07:28:59 --> Loader Class Initialized
INFO - 2019-11-11 07:28:59 --> Helper loaded: url_helper
INFO - 2019-11-11 07:28:59 --> Helper loaded: file_helper
INFO - 2019-11-11 07:28:59 --> Helper loaded: form_helper
INFO - 2019-11-11 07:28:59 --> Helper loaded: my_helper
INFO - 2019-11-11 07:28:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:28:59 --> Controller Class Initialized
INFO - 2019-11-11 07:29:00 --> Config Class Initialized
INFO - 2019-11-11 07:29:00 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:00 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:00 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:00 --> URI Class Initialized
INFO - 2019-11-11 07:29:00 --> Router Class Initialized
INFO - 2019-11-11 07:29:00 --> Output Class Initialized
INFO - 2019-11-11 07:29:00 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:00 --> Input Class Initialized
INFO - 2019-11-11 07:29:00 --> Language Class Initialized
INFO - 2019-11-11 07:29:00 --> Language Class Initialized
INFO - 2019-11-11 07:29:00 --> Config Class Initialized
INFO - 2019-11-11 07:29:00 --> Loader Class Initialized
INFO - 2019-11-11 07:29:00 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:00 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:00 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:00 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:00 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:00 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:29:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:00 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:00 --> Total execution time: 0.0806
INFO - 2019-11-11 07:29:05 --> Config Class Initialized
INFO - 2019-11-11 07:29:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:05 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:05 --> URI Class Initialized
INFO - 2019-11-11 07:29:05 --> Router Class Initialized
INFO - 2019-11-11 07:29:05 --> Output Class Initialized
INFO - 2019-11-11 07:29:05 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:05 --> Input Class Initialized
INFO - 2019-11-11 07:29:05 --> Language Class Initialized
INFO - 2019-11-11 07:29:05 --> Language Class Initialized
INFO - 2019-11-11 07:29:05 --> Config Class Initialized
INFO - 2019-11-11 07:29:05 --> Loader Class Initialized
INFO - 2019-11-11 07:29:05 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:05 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:05 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:05 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:05 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:05 --> Controller Class Initialized
INFO - 2019-11-11 07:29:05 --> Config Class Initialized
INFO - 2019-11-11 07:29:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:05 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:05 --> URI Class Initialized
INFO - 2019-11-11 07:29:05 --> Router Class Initialized
INFO - 2019-11-11 07:29:05 --> Output Class Initialized
INFO - 2019-11-11 07:29:05 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:05 --> Input Class Initialized
INFO - 2019-11-11 07:29:05 --> Language Class Initialized
INFO - 2019-11-11 07:29:05 --> Language Class Initialized
INFO - 2019-11-11 07:29:05 --> Config Class Initialized
INFO - 2019-11-11 07:29:05 --> Loader Class Initialized
INFO - 2019-11-11 07:29:05 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:05 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:05 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:05 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:05 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:05 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:29:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:05 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:05 --> Total execution time: 0.0636
INFO - 2019-11-11 07:29:07 --> Config Class Initialized
INFO - 2019-11-11 07:29:07 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:07 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:07 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:07 --> URI Class Initialized
INFO - 2019-11-11 07:29:07 --> Router Class Initialized
INFO - 2019-11-11 07:29:07 --> Output Class Initialized
INFO - 2019-11-11 07:29:07 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:07 --> Input Class Initialized
INFO - 2019-11-11 07:29:07 --> Language Class Initialized
INFO - 2019-11-11 07:29:07 --> Language Class Initialized
INFO - 2019-11-11 07:29:07 --> Config Class Initialized
INFO - 2019-11-11 07:29:07 --> Loader Class Initialized
INFO - 2019-11-11 07:29:08 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:08 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:08 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:08 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:08 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:08 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:08 --> Total execution time: 0.0912
INFO - 2019-11-11 07:29:12 --> Config Class Initialized
INFO - 2019-11-11 07:29:12 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:12 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:12 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:12 --> URI Class Initialized
INFO - 2019-11-11 07:29:12 --> Router Class Initialized
INFO - 2019-11-11 07:29:12 --> Output Class Initialized
INFO - 2019-11-11 07:29:12 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:12 --> Input Class Initialized
INFO - 2019-11-11 07:29:12 --> Language Class Initialized
INFO - 2019-11-11 07:29:12 --> Language Class Initialized
INFO - 2019-11-11 07:29:12 --> Config Class Initialized
INFO - 2019-11-11 07:29:12 --> Loader Class Initialized
INFO - 2019-11-11 07:29:12 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:12 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:12 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:12 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:12 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:12 --> Controller Class Initialized
INFO - 2019-11-11 07:29:12 --> Config Class Initialized
INFO - 2019-11-11 07:29:12 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:12 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:12 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:12 --> URI Class Initialized
INFO - 2019-11-11 07:29:12 --> Router Class Initialized
INFO - 2019-11-11 07:29:12 --> Output Class Initialized
INFO - 2019-11-11 07:29:12 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:12 --> Input Class Initialized
INFO - 2019-11-11 07:29:12 --> Language Class Initialized
INFO - 2019-11-11 07:29:12 --> Language Class Initialized
INFO - 2019-11-11 07:29:12 --> Config Class Initialized
INFO - 2019-11-11 07:29:12 --> Loader Class Initialized
INFO - 2019-11-11 07:29:12 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:12 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:12 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:12 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:12 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:12 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:12 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:12 --> Total execution time: 0.0448
INFO - 2019-11-11 07:29:12 --> Config Class Initialized
INFO - 2019-11-11 07:29:12 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:12 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:12 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:12 --> URI Class Initialized
INFO - 2019-11-11 07:29:12 --> Router Class Initialized
INFO - 2019-11-11 07:29:12 --> Output Class Initialized
INFO - 2019-11-11 07:29:12 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:12 --> Input Class Initialized
INFO - 2019-11-11 07:29:12 --> Language Class Initialized
INFO - 2019-11-11 07:29:12 --> Language Class Initialized
INFO - 2019-11-11 07:29:12 --> Config Class Initialized
INFO - 2019-11-11 07:29:12 --> Loader Class Initialized
INFO - 2019-11-11 07:29:12 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:12 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:12 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:12 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:12 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:12 --> Controller Class Initialized
INFO - 2019-11-11 07:29:14 --> Config Class Initialized
INFO - 2019-11-11 07:29:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:14 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:14 --> URI Class Initialized
INFO - 2019-11-11 07:29:14 --> Router Class Initialized
INFO - 2019-11-11 07:29:14 --> Output Class Initialized
INFO - 2019-11-11 07:29:14 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:14 --> Input Class Initialized
INFO - 2019-11-11 07:29:14 --> Language Class Initialized
INFO - 2019-11-11 07:29:14 --> Language Class Initialized
INFO - 2019-11-11 07:29:14 --> Config Class Initialized
INFO - 2019-11-11 07:29:14 --> Loader Class Initialized
INFO - 2019-11-11 07:29:14 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:14 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:14 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:14 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:14 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:14 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:29:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:14 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:14 --> Total execution time: 0.0776
INFO - 2019-11-11 07:29:19 --> Config Class Initialized
INFO - 2019-11-11 07:29:19 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:19 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:19 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:19 --> URI Class Initialized
INFO - 2019-11-11 07:29:19 --> Router Class Initialized
INFO - 2019-11-11 07:29:19 --> Output Class Initialized
INFO - 2019-11-11 07:29:19 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:19 --> Input Class Initialized
INFO - 2019-11-11 07:29:19 --> Language Class Initialized
INFO - 2019-11-11 07:29:19 --> Language Class Initialized
INFO - 2019-11-11 07:29:19 --> Config Class Initialized
INFO - 2019-11-11 07:29:19 --> Loader Class Initialized
INFO - 2019-11-11 07:29:19 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:19 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:19 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:19 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:19 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:19 --> Controller Class Initialized
INFO - 2019-11-11 07:29:19 --> Config Class Initialized
INFO - 2019-11-11 07:29:19 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:19 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:19 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:19 --> URI Class Initialized
INFO - 2019-11-11 07:29:19 --> Router Class Initialized
INFO - 2019-11-11 07:29:19 --> Output Class Initialized
INFO - 2019-11-11 07:29:19 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:19 --> Input Class Initialized
INFO - 2019-11-11 07:29:19 --> Language Class Initialized
INFO - 2019-11-11 07:29:19 --> Language Class Initialized
INFO - 2019-11-11 07:29:19 --> Config Class Initialized
INFO - 2019-11-11 07:29:19 --> Loader Class Initialized
INFO - 2019-11-11 07:29:19 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:19 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:19 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:19 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:19 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:19 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:19 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:19 --> Total execution time: 0.0760
INFO - 2019-11-11 07:29:22 --> Config Class Initialized
INFO - 2019-11-11 07:29:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:22 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:22 --> URI Class Initialized
INFO - 2019-11-11 07:29:22 --> Router Class Initialized
INFO - 2019-11-11 07:29:22 --> Output Class Initialized
INFO - 2019-11-11 07:29:22 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:22 --> Input Class Initialized
INFO - 2019-11-11 07:29:22 --> Language Class Initialized
INFO - 2019-11-11 07:29:22 --> Language Class Initialized
INFO - 2019-11-11 07:29:22 --> Config Class Initialized
INFO - 2019-11-11 07:29:22 --> Loader Class Initialized
INFO - 2019-11-11 07:29:22 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:22 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:22 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:22 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:22 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:29:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:22 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:22 --> Total execution time: 0.0934
INFO - 2019-11-11 07:29:27 --> Config Class Initialized
INFO - 2019-11-11 07:29:27 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:27 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:27 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:27 --> URI Class Initialized
INFO - 2019-11-11 07:29:27 --> Router Class Initialized
INFO - 2019-11-11 07:29:27 --> Output Class Initialized
INFO - 2019-11-11 07:29:27 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:27 --> Input Class Initialized
INFO - 2019-11-11 07:29:27 --> Language Class Initialized
INFO - 2019-11-11 07:29:27 --> Language Class Initialized
INFO - 2019-11-11 07:29:27 --> Config Class Initialized
INFO - 2019-11-11 07:29:27 --> Loader Class Initialized
INFO - 2019-11-11 07:29:27 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:27 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:27 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:27 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:27 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:27 --> Controller Class Initialized
INFO - 2019-11-11 07:29:27 --> Config Class Initialized
INFO - 2019-11-11 07:29:27 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:27 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:27 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:27 --> URI Class Initialized
INFO - 2019-11-11 07:29:27 --> Router Class Initialized
INFO - 2019-11-11 07:29:27 --> Output Class Initialized
INFO - 2019-11-11 07:29:27 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:27 --> Input Class Initialized
INFO - 2019-11-11 07:29:27 --> Language Class Initialized
INFO - 2019-11-11 07:29:27 --> Language Class Initialized
INFO - 2019-11-11 07:29:27 --> Config Class Initialized
INFO - 2019-11-11 07:29:27 --> Loader Class Initialized
INFO - 2019-11-11 07:29:27 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:27 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:27 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:27 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:27 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:27 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:27 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:27 --> Total execution time: 0.0702
INFO - 2019-11-11 07:29:27 --> Config Class Initialized
INFO - 2019-11-11 07:29:27 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:27 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:27 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:27 --> URI Class Initialized
INFO - 2019-11-11 07:29:27 --> Router Class Initialized
INFO - 2019-11-11 07:29:27 --> Output Class Initialized
INFO - 2019-11-11 07:29:27 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:27 --> Input Class Initialized
INFO - 2019-11-11 07:29:27 --> Language Class Initialized
INFO - 2019-11-11 07:29:27 --> Language Class Initialized
INFO - 2019-11-11 07:29:27 --> Config Class Initialized
INFO - 2019-11-11 07:29:27 --> Loader Class Initialized
INFO - 2019-11-11 07:29:27 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:27 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:27 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:27 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:27 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:27 --> Controller Class Initialized
INFO - 2019-11-11 07:29:29 --> Config Class Initialized
INFO - 2019-11-11 07:29:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:29 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:29 --> URI Class Initialized
INFO - 2019-11-11 07:29:29 --> Router Class Initialized
INFO - 2019-11-11 07:29:29 --> Output Class Initialized
INFO - 2019-11-11 07:29:29 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:29 --> Input Class Initialized
INFO - 2019-11-11 07:29:29 --> Language Class Initialized
INFO - 2019-11-11 07:29:29 --> Language Class Initialized
INFO - 2019-11-11 07:29:29 --> Config Class Initialized
INFO - 2019-11-11 07:29:29 --> Loader Class Initialized
INFO - 2019-11-11 07:29:29 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:29 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:29 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:29 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:29 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:29 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:29 --> Total execution time: 0.0736
INFO - 2019-11-11 07:29:33 --> Config Class Initialized
INFO - 2019-11-11 07:29:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:33 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:33 --> URI Class Initialized
INFO - 2019-11-11 07:29:33 --> Router Class Initialized
INFO - 2019-11-11 07:29:33 --> Output Class Initialized
INFO - 2019-11-11 07:29:33 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:33 --> Input Class Initialized
INFO - 2019-11-11 07:29:33 --> Language Class Initialized
INFO - 2019-11-11 07:29:33 --> Language Class Initialized
INFO - 2019-11-11 07:29:33 --> Config Class Initialized
INFO - 2019-11-11 07:29:33 --> Loader Class Initialized
INFO - 2019-11-11 07:29:33 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:33 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:33 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:33 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:33 --> Controller Class Initialized
INFO - 2019-11-11 07:29:34 --> Config Class Initialized
INFO - 2019-11-11 07:29:34 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:34 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:34 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:34 --> URI Class Initialized
INFO - 2019-11-11 07:29:34 --> Router Class Initialized
INFO - 2019-11-11 07:29:34 --> Output Class Initialized
INFO - 2019-11-11 07:29:34 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:34 --> Input Class Initialized
INFO - 2019-11-11 07:29:34 --> Language Class Initialized
INFO - 2019-11-11 07:29:34 --> Language Class Initialized
INFO - 2019-11-11 07:29:34 --> Config Class Initialized
INFO - 2019-11-11 07:29:34 --> Loader Class Initialized
INFO - 2019-11-11 07:29:34 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:34 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:34 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:34 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:34 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:34 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:29:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:34 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:34 --> Total execution time: 0.0675
INFO - 2019-11-11 07:29:36 --> Config Class Initialized
INFO - 2019-11-11 07:29:36 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:36 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:36 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:36 --> URI Class Initialized
INFO - 2019-11-11 07:29:36 --> Router Class Initialized
INFO - 2019-11-11 07:29:36 --> Output Class Initialized
INFO - 2019-11-11 07:29:36 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:36 --> Input Class Initialized
INFO - 2019-11-11 07:29:36 --> Language Class Initialized
INFO - 2019-11-11 07:29:36 --> Language Class Initialized
INFO - 2019-11-11 07:29:36 --> Config Class Initialized
INFO - 2019-11-11 07:29:36 --> Loader Class Initialized
INFO - 2019-11-11 07:29:36 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:36 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:36 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:36 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:36 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:36 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:29:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:36 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:36 --> Total execution time: 0.0810
INFO - 2019-11-11 07:29:40 --> Config Class Initialized
INFO - 2019-11-11 07:29:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:40 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:40 --> URI Class Initialized
INFO - 2019-11-11 07:29:40 --> Router Class Initialized
INFO - 2019-11-11 07:29:40 --> Output Class Initialized
INFO - 2019-11-11 07:29:40 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:40 --> Input Class Initialized
INFO - 2019-11-11 07:29:40 --> Language Class Initialized
INFO - 2019-11-11 07:29:40 --> Language Class Initialized
INFO - 2019-11-11 07:29:40 --> Config Class Initialized
INFO - 2019-11-11 07:29:40 --> Loader Class Initialized
INFO - 2019-11-11 07:29:40 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:40 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:40 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:40 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:41 --> Controller Class Initialized
INFO - 2019-11-11 07:29:41 --> Config Class Initialized
INFO - 2019-11-11 07:29:41 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:41 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:41 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:41 --> URI Class Initialized
INFO - 2019-11-11 07:29:41 --> Router Class Initialized
INFO - 2019-11-11 07:29:41 --> Output Class Initialized
INFO - 2019-11-11 07:29:41 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:41 --> Input Class Initialized
INFO - 2019-11-11 07:29:41 --> Language Class Initialized
INFO - 2019-11-11 07:29:41 --> Language Class Initialized
INFO - 2019-11-11 07:29:41 --> Config Class Initialized
INFO - 2019-11-11 07:29:41 --> Loader Class Initialized
INFO - 2019-11-11 07:29:41 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:41 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:41 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:41 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:41 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:41 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:41 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:41 --> Total execution time: 0.0568
INFO - 2019-11-11 07:29:41 --> Config Class Initialized
INFO - 2019-11-11 07:29:41 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:41 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:41 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:41 --> URI Class Initialized
INFO - 2019-11-11 07:29:41 --> Router Class Initialized
INFO - 2019-11-11 07:29:41 --> Output Class Initialized
INFO - 2019-11-11 07:29:41 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:41 --> Input Class Initialized
INFO - 2019-11-11 07:29:41 --> Language Class Initialized
INFO - 2019-11-11 07:29:41 --> Language Class Initialized
INFO - 2019-11-11 07:29:41 --> Config Class Initialized
INFO - 2019-11-11 07:29:41 --> Loader Class Initialized
INFO - 2019-11-11 07:29:41 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:41 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:41 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:41 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:41 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:41 --> Controller Class Initialized
INFO - 2019-11-11 07:29:42 --> Config Class Initialized
INFO - 2019-11-11 07:29:42 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:42 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:42 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:42 --> URI Class Initialized
INFO - 2019-11-11 07:29:42 --> Router Class Initialized
INFO - 2019-11-11 07:29:42 --> Output Class Initialized
INFO - 2019-11-11 07:29:42 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:42 --> Input Class Initialized
INFO - 2019-11-11 07:29:42 --> Language Class Initialized
INFO - 2019-11-11 07:29:42 --> Language Class Initialized
INFO - 2019-11-11 07:29:42 --> Config Class Initialized
INFO - 2019-11-11 07:29:42 --> Loader Class Initialized
INFO - 2019-11-11 07:29:42 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:42 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:42 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:42 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:42 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:42 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:29:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:42 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:42 --> Total execution time: 0.0949
INFO - 2019-11-11 07:29:47 --> Config Class Initialized
INFO - 2019-11-11 07:29:47 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:47 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:47 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:47 --> URI Class Initialized
INFO - 2019-11-11 07:29:47 --> Router Class Initialized
INFO - 2019-11-11 07:29:47 --> Output Class Initialized
INFO - 2019-11-11 07:29:47 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:47 --> Input Class Initialized
INFO - 2019-11-11 07:29:47 --> Language Class Initialized
INFO - 2019-11-11 07:29:47 --> Language Class Initialized
INFO - 2019-11-11 07:29:47 --> Config Class Initialized
INFO - 2019-11-11 07:29:47 --> Loader Class Initialized
INFO - 2019-11-11 07:29:47 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:47 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:47 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:47 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:47 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:48 --> Controller Class Initialized
INFO - 2019-11-11 07:29:48 --> Config Class Initialized
INFO - 2019-11-11 07:29:48 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:48 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:48 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:48 --> URI Class Initialized
INFO - 2019-11-11 07:29:48 --> Router Class Initialized
INFO - 2019-11-11 07:29:48 --> Output Class Initialized
INFO - 2019-11-11 07:29:48 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:48 --> Input Class Initialized
INFO - 2019-11-11 07:29:48 --> Language Class Initialized
INFO - 2019-11-11 07:29:48 --> Language Class Initialized
INFO - 2019-11-11 07:29:48 --> Config Class Initialized
INFO - 2019-11-11 07:29:48 --> Loader Class Initialized
INFO - 2019-11-11 07:29:48 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:48 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:48 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:48 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:48 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:48 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:48 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:48 --> Total execution time: 0.0594
INFO - 2019-11-11 07:29:50 --> Config Class Initialized
INFO - 2019-11-11 07:29:50 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:50 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:50 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:50 --> URI Class Initialized
INFO - 2019-11-11 07:29:50 --> Router Class Initialized
INFO - 2019-11-11 07:29:50 --> Output Class Initialized
INFO - 2019-11-11 07:29:50 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:50 --> Input Class Initialized
INFO - 2019-11-11 07:29:50 --> Language Class Initialized
INFO - 2019-11-11 07:29:50 --> Language Class Initialized
INFO - 2019-11-11 07:29:50 --> Config Class Initialized
INFO - 2019-11-11 07:29:50 --> Loader Class Initialized
INFO - 2019-11-11 07:29:50 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:50 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:50 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:50 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:50 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:50 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:29:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:50 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:50 --> Total execution time: 0.0903
INFO - 2019-11-11 07:29:55 --> Config Class Initialized
INFO - 2019-11-11 07:29:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:55 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:55 --> URI Class Initialized
INFO - 2019-11-11 07:29:55 --> Router Class Initialized
INFO - 2019-11-11 07:29:55 --> Output Class Initialized
INFO - 2019-11-11 07:29:55 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:55 --> Input Class Initialized
INFO - 2019-11-11 07:29:55 --> Language Class Initialized
INFO - 2019-11-11 07:29:55 --> Language Class Initialized
INFO - 2019-11-11 07:29:55 --> Config Class Initialized
INFO - 2019-11-11 07:29:55 --> Loader Class Initialized
INFO - 2019-11-11 07:29:55 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:55 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:55 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:55 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:55 --> Controller Class Initialized
INFO - 2019-11-11 07:29:55 --> Config Class Initialized
INFO - 2019-11-11 07:29:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:55 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:55 --> URI Class Initialized
INFO - 2019-11-11 07:29:55 --> Router Class Initialized
INFO - 2019-11-11 07:29:55 --> Output Class Initialized
INFO - 2019-11-11 07:29:55 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:55 --> Input Class Initialized
INFO - 2019-11-11 07:29:55 --> Language Class Initialized
INFO - 2019-11-11 07:29:55 --> Language Class Initialized
INFO - 2019-11-11 07:29:55 --> Config Class Initialized
INFO - 2019-11-11 07:29:55 --> Loader Class Initialized
INFO - 2019-11-11 07:29:55 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:55 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:55 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:55 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:55 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:29:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:55 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:55 --> Total execution time: 0.0757
INFO - 2019-11-11 07:29:55 --> Config Class Initialized
INFO - 2019-11-11 07:29:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:55 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:55 --> URI Class Initialized
INFO - 2019-11-11 07:29:55 --> Router Class Initialized
INFO - 2019-11-11 07:29:55 --> Output Class Initialized
INFO - 2019-11-11 07:29:55 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:55 --> Input Class Initialized
INFO - 2019-11-11 07:29:55 --> Language Class Initialized
INFO - 2019-11-11 07:29:55 --> Language Class Initialized
INFO - 2019-11-11 07:29:55 --> Config Class Initialized
INFO - 2019-11-11 07:29:55 --> Loader Class Initialized
INFO - 2019-11-11 07:29:55 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:55 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:55 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:55 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:55 --> Controller Class Initialized
INFO - 2019-11-11 07:29:57 --> Config Class Initialized
INFO - 2019-11-11 07:29:57 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:29:57 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:29:57 --> Utf8 Class Initialized
INFO - 2019-11-11 07:29:57 --> URI Class Initialized
INFO - 2019-11-11 07:29:57 --> Router Class Initialized
INFO - 2019-11-11 07:29:57 --> Output Class Initialized
INFO - 2019-11-11 07:29:57 --> Security Class Initialized
DEBUG - 2019-11-11 07:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:29:57 --> Input Class Initialized
INFO - 2019-11-11 07:29:57 --> Language Class Initialized
INFO - 2019-11-11 07:29:57 --> Language Class Initialized
INFO - 2019-11-11 07:29:57 --> Config Class Initialized
INFO - 2019-11-11 07:29:57 --> Loader Class Initialized
INFO - 2019-11-11 07:29:57 --> Helper loaded: url_helper
INFO - 2019-11-11 07:29:57 --> Helper loaded: file_helper
INFO - 2019-11-11 07:29:57 --> Helper loaded: form_helper
INFO - 2019-11-11 07:29:57 --> Helper loaded: my_helper
INFO - 2019-11-11 07:29:57 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:29:57 --> Controller Class Initialized
DEBUG - 2019-11-11 07:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:29:57 --> Final output sent to browser
DEBUG - 2019-11-11 07:29:57 --> Total execution time: 0.0841
INFO - 2019-11-11 07:30:02 --> Config Class Initialized
INFO - 2019-11-11 07:30:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:02 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:02 --> URI Class Initialized
INFO - 2019-11-11 07:30:02 --> Router Class Initialized
INFO - 2019-11-11 07:30:02 --> Output Class Initialized
INFO - 2019-11-11 07:30:02 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:02 --> Input Class Initialized
INFO - 2019-11-11 07:30:02 --> Language Class Initialized
INFO - 2019-11-11 07:30:02 --> Language Class Initialized
INFO - 2019-11-11 07:30:02 --> Config Class Initialized
INFO - 2019-11-11 07:30:02 --> Loader Class Initialized
INFO - 2019-11-11 07:30:02 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:02 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:02 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:02 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:02 --> Controller Class Initialized
INFO - 2019-11-11 07:30:03 --> Config Class Initialized
INFO - 2019-11-11 07:30:03 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:03 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:03 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:03 --> URI Class Initialized
INFO - 2019-11-11 07:30:03 --> Router Class Initialized
INFO - 2019-11-11 07:30:03 --> Output Class Initialized
INFO - 2019-11-11 07:30:03 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:03 --> Input Class Initialized
INFO - 2019-11-11 07:30:03 --> Language Class Initialized
INFO - 2019-11-11 07:30:03 --> Language Class Initialized
INFO - 2019-11-11 07:30:03 --> Config Class Initialized
INFO - 2019-11-11 07:30:03 --> Loader Class Initialized
INFO - 2019-11-11 07:30:03 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:03 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:03 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:03 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:03 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:03 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:30:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:03 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:03 --> Total execution time: 0.0755
INFO - 2019-11-11 07:30:06 --> Config Class Initialized
INFO - 2019-11-11 07:30:06 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:06 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:06 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:06 --> URI Class Initialized
INFO - 2019-11-11 07:30:06 --> Router Class Initialized
INFO - 2019-11-11 07:30:06 --> Output Class Initialized
INFO - 2019-11-11 07:30:06 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:06 --> Input Class Initialized
INFO - 2019-11-11 07:30:06 --> Language Class Initialized
INFO - 2019-11-11 07:30:06 --> Language Class Initialized
INFO - 2019-11-11 07:30:06 --> Config Class Initialized
INFO - 2019-11-11 07:30:06 --> Loader Class Initialized
INFO - 2019-11-11 07:30:06 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:06 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:06 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:06 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:06 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:06 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:06 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:06 --> Total execution time: 0.0740
INFO - 2019-11-11 07:30:11 --> Config Class Initialized
INFO - 2019-11-11 07:30:11 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:11 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:11 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:11 --> URI Class Initialized
INFO - 2019-11-11 07:30:11 --> Router Class Initialized
INFO - 2019-11-11 07:30:11 --> Output Class Initialized
INFO - 2019-11-11 07:30:11 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:11 --> Input Class Initialized
INFO - 2019-11-11 07:30:11 --> Language Class Initialized
INFO - 2019-11-11 07:30:11 --> Language Class Initialized
INFO - 2019-11-11 07:30:11 --> Config Class Initialized
INFO - 2019-11-11 07:30:11 --> Loader Class Initialized
INFO - 2019-11-11 07:30:11 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:11 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:11 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:11 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:11 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:11 --> Controller Class Initialized
INFO - 2019-11-11 07:30:11 --> Config Class Initialized
INFO - 2019-11-11 07:30:11 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:11 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:11 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:11 --> URI Class Initialized
INFO - 2019-11-11 07:30:11 --> Router Class Initialized
INFO - 2019-11-11 07:30:11 --> Output Class Initialized
INFO - 2019-11-11 07:30:11 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:11 --> Input Class Initialized
INFO - 2019-11-11 07:30:11 --> Language Class Initialized
INFO - 2019-11-11 07:30:11 --> Language Class Initialized
INFO - 2019-11-11 07:30:11 --> Config Class Initialized
INFO - 2019-11-11 07:30:11 --> Loader Class Initialized
INFO - 2019-11-11 07:30:11 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:11 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:11 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:11 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:11 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:11 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:11 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:11 --> Total execution time: 0.0630
INFO - 2019-11-11 07:30:12 --> Config Class Initialized
INFO - 2019-11-11 07:30:12 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:12 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:12 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:12 --> URI Class Initialized
INFO - 2019-11-11 07:30:12 --> Router Class Initialized
INFO - 2019-11-11 07:30:12 --> Output Class Initialized
INFO - 2019-11-11 07:30:12 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:12 --> Input Class Initialized
INFO - 2019-11-11 07:30:12 --> Language Class Initialized
INFO - 2019-11-11 07:30:12 --> Language Class Initialized
INFO - 2019-11-11 07:30:12 --> Config Class Initialized
INFO - 2019-11-11 07:30:12 --> Loader Class Initialized
INFO - 2019-11-11 07:30:12 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:12 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:12 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:12 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:12 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:12 --> Controller Class Initialized
INFO - 2019-11-11 07:30:15 --> Config Class Initialized
INFO - 2019-11-11 07:30:15 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:15 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:15 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:15 --> URI Class Initialized
INFO - 2019-11-11 07:30:15 --> Router Class Initialized
INFO - 2019-11-11 07:30:15 --> Output Class Initialized
INFO - 2019-11-11 07:30:15 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:15 --> Input Class Initialized
INFO - 2019-11-11 07:30:15 --> Language Class Initialized
INFO - 2019-11-11 07:30:15 --> Language Class Initialized
INFO - 2019-11-11 07:30:15 --> Config Class Initialized
INFO - 2019-11-11 07:30:15 --> Loader Class Initialized
INFO - 2019-11-11 07:30:15 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:15 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:15 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:15 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:15 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:15 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:15 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:15 --> Total execution time: 0.0818
INFO - 2019-11-11 07:30:24 --> Config Class Initialized
INFO - 2019-11-11 07:30:24 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:24 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:24 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:24 --> URI Class Initialized
INFO - 2019-11-11 07:30:24 --> Router Class Initialized
INFO - 2019-11-11 07:30:24 --> Output Class Initialized
INFO - 2019-11-11 07:30:24 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:24 --> Input Class Initialized
INFO - 2019-11-11 07:30:24 --> Language Class Initialized
INFO - 2019-11-11 07:30:24 --> Language Class Initialized
INFO - 2019-11-11 07:30:24 --> Config Class Initialized
INFO - 2019-11-11 07:30:24 --> Loader Class Initialized
INFO - 2019-11-11 07:30:24 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:24 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:24 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:24 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:24 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:24 --> Controller Class Initialized
INFO - 2019-11-11 07:30:24 --> Config Class Initialized
INFO - 2019-11-11 07:30:24 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:24 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:24 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:24 --> URI Class Initialized
INFO - 2019-11-11 07:30:24 --> Router Class Initialized
INFO - 2019-11-11 07:30:24 --> Output Class Initialized
INFO - 2019-11-11 07:30:24 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:24 --> Input Class Initialized
INFO - 2019-11-11 07:30:24 --> Language Class Initialized
INFO - 2019-11-11 07:30:24 --> Language Class Initialized
INFO - 2019-11-11 07:30:24 --> Config Class Initialized
INFO - 2019-11-11 07:30:24 --> Loader Class Initialized
INFO - 2019-11-11 07:30:24 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:24 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:24 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:24 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:24 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:25 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:30:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:25 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:25 --> Total execution time: 0.0880
INFO - 2019-11-11 07:30:26 --> Config Class Initialized
INFO - 2019-11-11 07:30:26 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:26 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:26 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:26 --> URI Class Initialized
INFO - 2019-11-11 07:30:26 --> Router Class Initialized
INFO - 2019-11-11 07:30:26 --> Output Class Initialized
INFO - 2019-11-11 07:30:26 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:26 --> Input Class Initialized
INFO - 2019-11-11 07:30:26 --> Language Class Initialized
INFO - 2019-11-11 07:30:26 --> Language Class Initialized
INFO - 2019-11-11 07:30:26 --> Config Class Initialized
INFO - 2019-11-11 07:30:26 --> Loader Class Initialized
INFO - 2019-11-11 07:30:26 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:26 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:26 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:26 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:26 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:26 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:30:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:26 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:26 --> Total execution time: 0.0792
INFO - 2019-11-11 07:30:32 --> Config Class Initialized
INFO - 2019-11-11 07:30:32 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:32 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:32 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:32 --> URI Class Initialized
INFO - 2019-11-11 07:30:32 --> Router Class Initialized
INFO - 2019-11-11 07:30:32 --> Output Class Initialized
INFO - 2019-11-11 07:30:32 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:32 --> Input Class Initialized
INFO - 2019-11-11 07:30:32 --> Language Class Initialized
INFO - 2019-11-11 07:30:32 --> Language Class Initialized
INFO - 2019-11-11 07:30:32 --> Config Class Initialized
INFO - 2019-11-11 07:30:32 --> Loader Class Initialized
INFO - 2019-11-11 07:30:32 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:32 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:32 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:32 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:32 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:32 --> Controller Class Initialized
INFO - 2019-11-11 07:30:32 --> Config Class Initialized
INFO - 2019-11-11 07:30:32 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:32 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:32 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:32 --> URI Class Initialized
INFO - 2019-11-11 07:30:32 --> Router Class Initialized
INFO - 2019-11-11 07:30:32 --> Output Class Initialized
INFO - 2019-11-11 07:30:32 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:32 --> Input Class Initialized
INFO - 2019-11-11 07:30:32 --> Language Class Initialized
INFO - 2019-11-11 07:30:32 --> Language Class Initialized
INFO - 2019-11-11 07:30:32 --> Config Class Initialized
INFO - 2019-11-11 07:30:32 --> Loader Class Initialized
INFO - 2019-11-11 07:30:32 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:32 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:32 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:32 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:33 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:30:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:33 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:33 --> Total execution time: 0.0658
INFO - 2019-11-11 07:30:33 --> Config Class Initialized
INFO - 2019-11-11 07:30:33 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:33 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:33 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:33 --> URI Class Initialized
INFO - 2019-11-11 07:30:33 --> Router Class Initialized
INFO - 2019-11-11 07:30:33 --> Output Class Initialized
INFO - 2019-11-11 07:30:33 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:33 --> Input Class Initialized
INFO - 2019-11-11 07:30:33 --> Language Class Initialized
INFO - 2019-11-11 07:30:33 --> Language Class Initialized
INFO - 2019-11-11 07:30:33 --> Config Class Initialized
INFO - 2019-11-11 07:30:33 --> Loader Class Initialized
INFO - 2019-11-11 07:30:33 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:33 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:33 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:33 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:33 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:33 --> Controller Class Initialized
INFO - 2019-11-11 07:30:34 --> Config Class Initialized
INFO - 2019-11-11 07:30:34 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:34 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:34 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:34 --> URI Class Initialized
INFO - 2019-11-11 07:30:34 --> Router Class Initialized
INFO - 2019-11-11 07:30:34 --> Output Class Initialized
INFO - 2019-11-11 07:30:34 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:34 --> Input Class Initialized
INFO - 2019-11-11 07:30:34 --> Language Class Initialized
INFO - 2019-11-11 07:30:34 --> Language Class Initialized
INFO - 2019-11-11 07:30:34 --> Config Class Initialized
INFO - 2019-11-11 07:30:34 --> Loader Class Initialized
INFO - 2019-11-11 07:30:34 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:34 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:34 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:34 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:34 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:34 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:34 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:34 --> Total execution time: 0.0963
INFO - 2019-11-11 07:30:39 --> Config Class Initialized
INFO - 2019-11-11 07:30:39 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:39 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:39 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:39 --> URI Class Initialized
INFO - 2019-11-11 07:30:39 --> Router Class Initialized
INFO - 2019-11-11 07:30:39 --> Output Class Initialized
INFO - 2019-11-11 07:30:39 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:39 --> Input Class Initialized
INFO - 2019-11-11 07:30:39 --> Language Class Initialized
INFO - 2019-11-11 07:30:39 --> Language Class Initialized
INFO - 2019-11-11 07:30:39 --> Config Class Initialized
INFO - 2019-11-11 07:30:39 --> Loader Class Initialized
INFO - 2019-11-11 07:30:39 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:39 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:39 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:39 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:39 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:39 --> Controller Class Initialized
INFO - 2019-11-11 07:30:39 --> Config Class Initialized
INFO - 2019-11-11 07:30:39 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:39 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:39 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:39 --> URI Class Initialized
INFO - 2019-11-11 07:30:39 --> Router Class Initialized
INFO - 2019-11-11 07:30:39 --> Output Class Initialized
INFO - 2019-11-11 07:30:39 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:39 --> Input Class Initialized
INFO - 2019-11-11 07:30:39 --> Language Class Initialized
INFO - 2019-11-11 07:30:39 --> Language Class Initialized
INFO - 2019-11-11 07:30:39 --> Config Class Initialized
INFO - 2019-11-11 07:30:39 --> Loader Class Initialized
INFO - 2019-11-11 07:30:39 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:39 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:39 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:39 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:39 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:39 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:30:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:39 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:39 --> Total execution time: 0.0524
INFO - 2019-11-11 07:30:41 --> Config Class Initialized
INFO - 2019-11-11 07:30:41 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:41 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:41 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:41 --> URI Class Initialized
INFO - 2019-11-11 07:30:41 --> Router Class Initialized
INFO - 2019-11-11 07:30:41 --> Output Class Initialized
INFO - 2019-11-11 07:30:42 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:42 --> Input Class Initialized
INFO - 2019-11-11 07:30:42 --> Language Class Initialized
INFO - 2019-11-11 07:30:42 --> Language Class Initialized
INFO - 2019-11-11 07:30:42 --> Config Class Initialized
INFO - 2019-11-11 07:30:42 --> Loader Class Initialized
INFO - 2019-11-11 07:30:42 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:42 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:42 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:42 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:42 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:42 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:42 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:42 --> Total execution time: 0.0944
INFO - 2019-11-11 07:30:52 --> Config Class Initialized
INFO - 2019-11-11 07:30:52 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:52 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:52 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:52 --> URI Class Initialized
INFO - 2019-11-11 07:30:52 --> Router Class Initialized
INFO - 2019-11-11 07:30:52 --> Output Class Initialized
INFO - 2019-11-11 07:30:52 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:52 --> Input Class Initialized
INFO - 2019-11-11 07:30:52 --> Language Class Initialized
INFO - 2019-11-11 07:30:52 --> Language Class Initialized
INFO - 2019-11-11 07:30:52 --> Config Class Initialized
INFO - 2019-11-11 07:30:52 --> Loader Class Initialized
INFO - 2019-11-11 07:30:52 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:52 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:52 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:52 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:52 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:52 --> Controller Class Initialized
INFO - 2019-11-11 07:30:52 --> Config Class Initialized
INFO - 2019-11-11 07:30:52 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:52 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:52 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:52 --> URI Class Initialized
INFO - 2019-11-11 07:30:52 --> Router Class Initialized
INFO - 2019-11-11 07:30:52 --> Output Class Initialized
INFO - 2019-11-11 07:30:52 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:52 --> Input Class Initialized
INFO - 2019-11-11 07:30:52 --> Language Class Initialized
INFO - 2019-11-11 07:30:52 --> Language Class Initialized
INFO - 2019-11-11 07:30:52 --> Config Class Initialized
INFO - 2019-11-11 07:30:52 --> Loader Class Initialized
INFO - 2019-11-11 07:30:52 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:52 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:52 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:52 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:52 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:52 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:30:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:52 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:52 --> Total execution time: 0.0665
INFO - 2019-11-11 07:30:52 --> Config Class Initialized
INFO - 2019-11-11 07:30:52 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:52 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:52 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:52 --> URI Class Initialized
INFO - 2019-11-11 07:30:52 --> Router Class Initialized
INFO - 2019-11-11 07:30:52 --> Output Class Initialized
INFO - 2019-11-11 07:30:52 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:52 --> Input Class Initialized
INFO - 2019-11-11 07:30:52 --> Language Class Initialized
INFO - 2019-11-11 07:30:52 --> Language Class Initialized
INFO - 2019-11-11 07:30:52 --> Config Class Initialized
INFO - 2019-11-11 07:30:52 --> Loader Class Initialized
INFO - 2019-11-11 07:30:52 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:52 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:52 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:52 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:52 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:52 --> Controller Class Initialized
INFO - 2019-11-11 07:30:55 --> Config Class Initialized
INFO - 2019-11-11 07:30:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:30:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:30:55 --> Utf8 Class Initialized
INFO - 2019-11-11 07:30:55 --> URI Class Initialized
INFO - 2019-11-11 07:30:55 --> Router Class Initialized
INFO - 2019-11-11 07:30:55 --> Output Class Initialized
INFO - 2019-11-11 07:30:55 --> Security Class Initialized
DEBUG - 2019-11-11 07:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:30:55 --> Input Class Initialized
INFO - 2019-11-11 07:30:55 --> Language Class Initialized
INFO - 2019-11-11 07:30:55 --> Language Class Initialized
INFO - 2019-11-11 07:30:55 --> Config Class Initialized
INFO - 2019-11-11 07:30:55 --> Loader Class Initialized
INFO - 2019-11-11 07:30:55 --> Helper loaded: url_helper
INFO - 2019-11-11 07:30:55 --> Helper loaded: file_helper
INFO - 2019-11-11 07:30:55 --> Helper loaded: form_helper
INFO - 2019-11-11 07:30:55 --> Helper loaded: my_helper
INFO - 2019-11-11 07:30:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:30:55 --> Controller Class Initialized
DEBUG - 2019-11-11 07:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:30:55 --> Final output sent to browser
DEBUG - 2019-11-11 07:30:55 --> Total execution time: 0.0723
INFO - 2019-11-11 07:31:00 --> Config Class Initialized
INFO - 2019-11-11 07:31:00 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:00 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:00 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:00 --> URI Class Initialized
INFO - 2019-11-11 07:31:00 --> Router Class Initialized
INFO - 2019-11-11 07:31:00 --> Output Class Initialized
INFO - 2019-11-11 07:31:00 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:00 --> Input Class Initialized
INFO - 2019-11-11 07:31:00 --> Language Class Initialized
INFO - 2019-11-11 07:31:00 --> Language Class Initialized
INFO - 2019-11-11 07:31:00 --> Config Class Initialized
INFO - 2019-11-11 07:31:00 --> Loader Class Initialized
INFO - 2019-11-11 07:31:00 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:00 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:00 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:00 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:00 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:00 --> Controller Class Initialized
INFO - 2019-11-11 07:31:00 --> Config Class Initialized
INFO - 2019-11-11 07:31:00 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:00 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:00 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:00 --> URI Class Initialized
INFO - 2019-11-11 07:31:00 --> Router Class Initialized
INFO - 2019-11-11 07:31:00 --> Output Class Initialized
INFO - 2019-11-11 07:31:00 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:00 --> Input Class Initialized
INFO - 2019-11-11 07:31:00 --> Language Class Initialized
INFO - 2019-11-11 07:31:00 --> Language Class Initialized
INFO - 2019-11-11 07:31:00 --> Config Class Initialized
INFO - 2019-11-11 07:31:00 --> Loader Class Initialized
INFO - 2019-11-11 07:31:00 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:00 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:00 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:00 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:00 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:00 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:31:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:00 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:00 --> Total execution time: 0.0800
INFO - 2019-11-11 07:31:02 --> Config Class Initialized
INFO - 2019-11-11 07:31:02 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:02 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:02 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:02 --> URI Class Initialized
INFO - 2019-11-11 07:31:02 --> Router Class Initialized
INFO - 2019-11-11 07:31:02 --> Output Class Initialized
INFO - 2019-11-11 07:31:02 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:02 --> Input Class Initialized
INFO - 2019-11-11 07:31:02 --> Language Class Initialized
INFO - 2019-11-11 07:31:02 --> Language Class Initialized
INFO - 2019-11-11 07:31:02 --> Config Class Initialized
INFO - 2019-11-11 07:31:02 --> Loader Class Initialized
INFO - 2019-11-11 07:31:02 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:02 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:02 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:02 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:02 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:02 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:02 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:02 --> Total execution time: 0.0913
INFO - 2019-11-11 07:31:08 --> Config Class Initialized
INFO - 2019-11-11 07:31:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:08 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:08 --> URI Class Initialized
INFO - 2019-11-11 07:31:08 --> Router Class Initialized
INFO - 2019-11-11 07:31:08 --> Output Class Initialized
INFO - 2019-11-11 07:31:08 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:08 --> Input Class Initialized
INFO - 2019-11-11 07:31:08 --> Language Class Initialized
INFO - 2019-11-11 07:31:08 --> Language Class Initialized
INFO - 2019-11-11 07:31:08 --> Config Class Initialized
INFO - 2019-11-11 07:31:08 --> Loader Class Initialized
INFO - 2019-11-11 07:31:08 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:08 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:08 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:08 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:08 --> Controller Class Initialized
INFO - 2019-11-11 07:31:08 --> Config Class Initialized
INFO - 2019-11-11 07:31:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:08 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:08 --> URI Class Initialized
INFO - 2019-11-11 07:31:08 --> Router Class Initialized
INFO - 2019-11-11 07:31:08 --> Output Class Initialized
INFO - 2019-11-11 07:31:08 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:08 --> Input Class Initialized
INFO - 2019-11-11 07:31:08 --> Language Class Initialized
INFO - 2019-11-11 07:31:08 --> Language Class Initialized
INFO - 2019-11-11 07:31:08 --> Config Class Initialized
INFO - 2019-11-11 07:31:08 --> Loader Class Initialized
INFO - 2019-11-11 07:31:08 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:08 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:08 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:08 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:08 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:08 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:08 --> Total execution time: 0.0783
INFO - 2019-11-11 07:31:08 --> Config Class Initialized
INFO - 2019-11-11 07:31:08 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:08 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:08 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:08 --> URI Class Initialized
INFO - 2019-11-11 07:31:08 --> Router Class Initialized
INFO - 2019-11-11 07:31:08 --> Output Class Initialized
INFO - 2019-11-11 07:31:08 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:08 --> Input Class Initialized
INFO - 2019-11-11 07:31:08 --> Language Class Initialized
INFO - 2019-11-11 07:31:08 --> Language Class Initialized
INFO - 2019-11-11 07:31:08 --> Config Class Initialized
INFO - 2019-11-11 07:31:08 --> Loader Class Initialized
INFO - 2019-11-11 07:31:08 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:08 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:08 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:08 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:08 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:08 --> Controller Class Initialized
INFO - 2019-11-11 07:31:11 --> Config Class Initialized
INFO - 2019-11-11 07:31:11 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:11 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:11 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:11 --> URI Class Initialized
INFO - 2019-11-11 07:31:11 --> Router Class Initialized
INFO - 2019-11-11 07:31:11 --> Output Class Initialized
INFO - 2019-11-11 07:31:11 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:11 --> Input Class Initialized
INFO - 2019-11-11 07:31:11 --> Language Class Initialized
INFO - 2019-11-11 07:31:11 --> Language Class Initialized
INFO - 2019-11-11 07:31:11 --> Config Class Initialized
INFO - 2019-11-11 07:31:11 --> Loader Class Initialized
INFO - 2019-11-11 07:31:11 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:11 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:11 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:11 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:11 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:11 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:31:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:11 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:11 --> Total execution time: 0.0668
INFO - 2019-11-11 07:31:17 --> Config Class Initialized
INFO - 2019-11-11 07:31:17 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:17 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:17 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:17 --> URI Class Initialized
INFO - 2019-11-11 07:31:17 --> Router Class Initialized
INFO - 2019-11-11 07:31:17 --> Output Class Initialized
INFO - 2019-11-11 07:31:17 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:17 --> Input Class Initialized
INFO - 2019-11-11 07:31:17 --> Language Class Initialized
INFO - 2019-11-11 07:31:17 --> Language Class Initialized
INFO - 2019-11-11 07:31:17 --> Config Class Initialized
INFO - 2019-11-11 07:31:17 --> Loader Class Initialized
INFO - 2019-11-11 07:31:17 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:17 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:17 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:17 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:17 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:17 --> Controller Class Initialized
INFO - 2019-11-11 07:31:17 --> Config Class Initialized
INFO - 2019-11-11 07:31:17 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:17 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:17 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:17 --> URI Class Initialized
INFO - 2019-11-11 07:31:17 --> Router Class Initialized
INFO - 2019-11-11 07:31:17 --> Output Class Initialized
INFO - 2019-11-11 07:31:17 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:17 --> Input Class Initialized
INFO - 2019-11-11 07:31:17 --> Language Class Initialized
INFO - 2019-11-11 07:31:17 --> Language Class Initialized
INFO - 2019-11-11 07:31:17 --> Config Class Initialized
INFO - 2019-11-11 07:31:17 --> Loader Class Initialized
INFO - 2019-11-11 07:31:17 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:17 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:17 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:17 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:17 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:17 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:31:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:17 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:17 --> Total execution time: 0.0832
INFO - 2019-11-11 07:31:23 --> Config Class Initialized
INFO - 2019-11-11 07:31:23 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:23 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:23 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:23 --> URI Class Initialized
INFO - 2019-11-11 07:31:23 --> Router Class Initialized
INFO - 2019-11-11 07:31:23 --> Output Class Initialized
INFO - 2019-11-11 07:31:23 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:23 --> Input Class Initialized
INFO - 2019-11-11 07:31:23 --> Language Class Initialized
INFO - 2019-11-11 07:31:23 --> Language Class Initialized
INFO - 2019-11-11 07:31:23 --> Config Class Initialized
INFO - 2019-11-11 07:31:23 --> Loader Class Initialized
INFO - 2019-11-11 07:31:23 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:23 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:23 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:23 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:23 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:23 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:23 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:23 --> Total execution time: 0.0832
INFO - 2019-11-11 07:31:30 --> Config Class Initialized
INFO - 2019-11-11 07:31:30 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:30 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:30 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:30 --> URI Class Initialized
INFO - 2019-11-11 07:31:30 --> Router Class Initialized
INFO - 2019-11-11 07:31:30 --> Output Class Initialized
INFO - 2019-11-11 07:31:30 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:30 --> Input Class Initialized
INFO - 2019-11-11 07:31:30 --> Language Class Initialized
INFO - 2019-11-11 07:31:30 --> Language Class Initialized
INFO - 2019-11-11 07:31:30 --> Config Class Initialized
INFO - 2019-11-11 07:31:30 --> Loader Class Initialized
INFO - 2019-11-11 07:31:30 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:30 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:30 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:30 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:30 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:30 --> Controller Class Initialized
INFO - 2019-11-11 07:31:30 --> Config Class Initialized
INFO - 2019-11-11 07:31:30 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:30 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:30 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:30 --> URI Class Initialized
INFO - 2019-11-11 07:31:30 --> Router Class Initialized
INFO - 2019-11-11 07:31:30 --> Output Class Initialized
INFO - 2019-11-11 07:31:30 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:30 --> Input Class Initialized
INFO - 2019-11-11 07:31:30 --> Language Class Initialized
INFO - 2019-11-11 07:31:30 --> Language Class Initialized
INFO - 2019-11-11 07:31:30 --> Config Class Initialized
INFO - 2019-11-11 07:31:30 --> Loader Class Initialized
INFO - 2019-11-11 07:31:30 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:30 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:30 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:30 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:30 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:30 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:30 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:30 --> Total execution time: 0.0656
INFO - 2019-11-11 07:31:30 --> Config Class Initialized
INFO - 2019-11-11 07:31:30 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:30 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:30 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:30 --> URI Class Initialized
INFO - 2019-11-11 07:31:30 --> Router Class Initialized
INFO - 2019-11-11 07:31:30 --> Output Class Initialized
INFO - 2019-11-11 07:31:30 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:30 --> Input Class Initialized
INFO - 2019-11-11 07:31:30 --> Language Class Initialized
INFO - 2019-11-11 07:31:30 --> Language Class Initialized
INFO - 2019-11-11 07:31:30 --> Config Class Initialized
INFO - 2019-11-11 07:31:30 --> Loader Class Initialized
INFO - 2019-11-11 07:31:30 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:30 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:30 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:30 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:30 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:30 --> Controller Class Initialized
INFO - 2019-11-11 07:31:32 --> Config Class Initialized
INFO - 2019-11-11 07:31:32 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:32 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:32 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:32 --> URI Class Initialized
INFO - 2019-11-11 07:31:32 --> Router Class Initialized
INFO - 2019-11-11 07:31:32 --> Output Class Initialized
INFO - 2019-11-11 07:31:32 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:32 --> Input Class Initialized
INFO - 2019-11-11 07:31:32 --> Language Class Initialized
INFO - 2019-11-11 07:31:32 --> Language Class Initialized
INFO - 2019-11-11 07:31:32 --> Config Class Initialized
INFO - 2019-11-11 07:31:32 --> Loader Class Initialized
INFO - 2019-11-11 07:31:32 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:32 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:32 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:32 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:32 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:32 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:32 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:32 --> Total execution time: 0.0883
INFO - 2019-11-11 07:31:38 --> Config Class Initialized
INFO - 2019-11-11 07:31:38 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:38 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:38 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:38 --> URI Class Initialized
INFO - 2019-11-11 07:31:38 --> Router Class Initialized
INFO - 2019-11-11 07:31:38 --> Output Class Initialized
INFO - 2019-11-11 07:31:38 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:38 --> Input Class Initialized
INFO - 2019-11-11 07:31:38 --> Language Class Initialized
INFO - 2019-11-11 07:31:38 --> Language Class Initialized
INFO - 2019-11-11 07:31:38 --> Config Class Initialized
INFO - 2019-11-11 07:31:38 --> Loader Class Initialized
INFO - 2019-11-11 07:31:38 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:38 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:38 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:38 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:38 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:38 --> Controller Class Initialized
INFO - 2019-11-11 07:31:38 --> Config Class Initialized
INFO - 2019-11-11 07:31:38 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:38 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:38 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:38 --> URI Class Initialized
INFO - 2019-11-11 07:31:38 --> Router Class Initialized
INFO - 2019-11-11 07:31:38 --> Output Class Initialized
INFO - 2019-11-11 07:31:38 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:38 --> Input Class Initialized
INFO - 2019-11-11 07:31:38 --> Language Class Initialized
INFO - 2019-11-11 07:31:38 --> Language Class Initialized
INFO - 2019-11-11 07:31:38 --> Config Class Initialized
INFO - 2019-11-11 07:31:38 --> Loader Class Initialized
INFO - 2019-11-11 07:31:38 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:38 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:38 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:38 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:38 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:38 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:38 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:38 --> Total execution time: 0.0706
INFO - 2019-11-11 07:31:40 --> Config Class Initialized
INFO - 2019-11-11 07:31:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:40 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:40 --> URI Class Initialized
INFO - 2019-11-11 07:31:40 --> Router Class Initialized
INFO - 2019-11-11 07:31:40 --> Output Class Initialized
INFO - 2019-11-11 07:31:40 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:40 --> Input Class Initialized
INFO - 2019-11-11 07:31:40 --> Language Class Initialized
INFO - 2019-11-11 07:31:40 --> Language Class Initialized
INFO - 2019-11-11 07:31:40 --> Config Class Initialized
INFO - 2019-11-11 07:31:40 --> Loader Class Initialized
INFO - 2019-11-11 07:31:40 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:40 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:40 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:40 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:40 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:31:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:40 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:40 --> Total execution time: 0.0860
INFO - 2019-11-11 07:31:46 --> Config Class Initialized
INFO - 2019-11-11 07:31:46 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:46 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:46 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:46 --> URI Class Initialized
INFO - 2019-11-11 07:31:46 --> Router Class Initialized
INFO - 2019-11-11 07:31:46 --> Output Class Initialized
INFO - 2019-11-11 07:31:46 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:46 --> Input Class Initialized
INFO - 2019-11-11 07:31:46 --> Language Class Initialized
INFO - 2019-11-11 07:31:46 --> Language Class Initialized
INFO - 2019-11-11 07:31:46 --> Config Class Initialized
INFO - 2019-11-11 07:31:46 --> Loader Class Initialized
INFO - 2019-11-11 07:31:46 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:46 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:46 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:46 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:46 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:46 --> Controller Class Initialized
INFO - 2019-11-11 07:31:47 --> Config Class Initialized
INFO - 2019-11-11 07:31:47 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:47 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:47 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:47 --> URI Class Initialized
INFO - 2019-11-11 07:31:47 --> Router Class Initialized
INFO - 2019-11-11 07:31:47 --> Output Class Initialized
INFO - 2019-11-11 07:31:47 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:47 --> Input Class Initialized
INFO - 2019-11-11 07:31:47 --> Language Class Initialized
INFO - 2019-11-11 07:31:47 --> Language Class Initialized
INFO - 2019-11-11 07:31:47 --> Config Class Initialized
INFO - 2019-11-11 07:31:47 --> Loader Class Initialized
INFO - 2019-11-11 07:31:47 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:47 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:47 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:47 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:47 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:47 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:31:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:47 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:47 --> Total execution time: 0.0535
INFO - 2019-11-11 07:31:47 --> Config Class Initialized
INFO - 2019-11-11 07:31:47 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:47 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:47 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:47 --> URI Class Initialized
INFO - 2019-11-11 07:31:47 --> Router Class Initialized
INFO - 2019-11-11 07:31:47 --> Output Class Initialized
INFO - 2019-11-11 07:31:47 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:47 --> Input Class Initialized
INFO - 2019-11-11 07:31:47 --> Language Class Initialized
INFO - 2019-11-11 07:31:47 --> Language Class Initialized
INFO - 2019-11-11 07:31:47 --> Config Class Initialized
INFO - 2019-11-11 07:31:47 --> Loader Class Initialized
INFO - 2019-11-11 07:31:47 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:47 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:47 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:47 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:47 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:47 --> Controller Class Initialized
INFO - 2019-11-11 07:31:48 --> Config Class Initialized
INFO - 2019-11-11 07:31:48 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:48 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:48 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:48 --> URI Class Initialized
INFO - 2019-11-11 07:31:48 --> Router Class Initialized
INFO - 2019-11-11 07:31:48 --> Output Class Initialized
INFO - 2019-11-11 07:31:48 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:48 --> Input Class Initialized
INFO - 2019-11-11 07:31:48 --> Language Class Initialized
INFO - 2019-11-11 07:31:48 --> Language Class Initialized
INFO - 2019-11-11 07:31:48 --> Config Class Initialized
INFO - 2019-11-11 07:31:48 --> Loader Class Initialized
INFO - 2019-11-11 07:31:48 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:48 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:48 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:48 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:48 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:48 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:49 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:49 --> Total execution time: 0.0934
INFO - 2019-11-11 07:31:54 --> Config Class Initialized
INFO - 2019-11-11 07:31:54 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:54 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:54 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:54 --> URI Class Initialized
INFO - 2019-11-11 07:31:54 --> Router Class Initialized
INFO - 2019-11-11 07:31:54 --> Output Class Initialized
INFO - 2019-11-11 07:31:54 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:54 --> Input Class Initialized
INFO - 2019-11-11 07:31:54 --> Language Class Initialized
INFO - 2019-11-11 07:31:54 --> Language Class Initialized
INFO - 2019-11-11 07:31:54 --> Config Class Initialized
INFO - 2019-11-11 07:31:54 --> Loader Class Initialized
INFO - 2019-11-11 07:31:54 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:54 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:54 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:54 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:54 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:54 --> Controller Class Initialized
INFO - 2019-11-11 07:31:55 --> Config Class Initialized
INFO - 2019-11-11 07:31:55 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:55 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:55 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:55 --> URI Class Initialized
INFO - 2019-11-11 07:31:55 --> Router Class Initialized
INFO - 2019-11-11 07:31:55 --> Output Class Initialized
INFO - 2019-11-11 07:31:55 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:55 --> Input Class Initialized
INFO - 2019-11-11 07:31:55 --> Language Class Initialized
INFO - 2019-11-11 07:31:55 --> Language Class Initialized
INFO - 2019-11-11 07:31:55 --> Config Class Initialized
INFO - 2019-11-11 07:31:55 --> Loader Class Initialized
INFO - 2019-11-11 07:31:55 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:55 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:55 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:55 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:55 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:55 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:31:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:55 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:55 --> Total execution time: 0.0644
INFO - 2019-11-11 07:31:57 --> Config Class Initialized
INFO - 2019-11-11 07:31:57 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:31:57 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:31:57 --> Utf8 Class Initialized
INFO - 2019-11-11 07:31:57 --> URI Class Initialized
INFO - 2019-11-11 07:31:57 --> Router Class Initialized
INFO - 2019-11-11 07:31:57 --> Output Class Initialized
INFO - 2019-11-11 07:31:57 --> Security Class Initialized
DEBUG - 2019-11-11 07:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:31:57 --> Input Class Initialized
INFO - 2019-11-11 07:31:57 --> Language Class Initialized
INFO - 2019-11-11 07:31:57 --> Language Class Initialized
INFO - 2019-11-11 07:31:57 --> Config Class Initialized
INFO - 2019-11-11 07:31:57 --> Loader Class Initialized
INFO - 2019-11-11 07:31:57 --> Helper loaded: url_helper
INFO - 2019-11-11 07:31:57 --> Helper loaded: file_helper
INFO - 2019-11-11 07:31:57 --> Helper loaded: form_helper
INFO - 2019-11-11 07:31:57 --> Helper loaded: my_helper
INFO - 2019-11-11 07:31:57 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:31:57 --> Controller Class Initialized
DEBUG - 2019-11-11 07:31:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:31:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:31:57 --> Final output sent to browser
DEBUG - 2019-11-11 07:31:57 --> Total execution time: 0.0847
INFO - 2019-11-11 07:32:07 --> Config Class Initialized
INFO - 2019-11-11 07:32:07 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:07 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:07 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:07 --> URI Class Initialized
INFO - 2019-11-11 07:32:07 --> Router Class Initialized
INFO - 2019-11-11 07:32:07 --> Output Class Initialized
INFO - 2019-11-11 07:32:07 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:07 --> Input Class Initialized
INFO - 2019-11-11 07:32:07 --> Language Class Initialized
INFO - 2019-11-11 07:32:07 --> Language Class Initialized
INFO - 2019-11-11 07:32:07 --> Config Class Initialized
INFO - 2019-11-11 07:32:07 --> Loader Class Initialized
INFO - 2019-11-11 07:32:07 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:07 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:07 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:07 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:07 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:07 --> Controller Class Initialized
INFO - 2019-11-11 07:32:07 --> Config Class Initialized
INFO - 2019-11-11 07:32:07 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:07 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:07 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:07 --> URI Class Initialized
INFO - 2019-11-11 07:32:07 --> Router Class Initialized
INFO - 2019-11-11 07:32:07 --> Output Class Initialized
INFO - 2019-11-11 07:32:07 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:07 --> Input Class Initialized
INFO - 2019-11-11 07:32:07 --> Language Class Initialized
INFO - 2019-11-11 07:32:07 --> Language Class Initialized
INFO - 2019-11-11 07:32:07 --> Config Class Initialized
INFO - 2019-11-11 07:32:07 --> Loader Class Initialized
INFO - 2019-11-11 07:32:07 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:07 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:07 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:07 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:07 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:07 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:32:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:07 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:07 --> Total execution time: 0.0773
INFO - 2019-11-11 07:32:07 --> Config Class Initialized
INFO - 2019-11-11 07:32:07 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:07 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:07 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:07 --> URI Class Initialized
INFO - 2019-11-11 07:32:07 --> Router Class Initialized
INFO - 2019-11-11 07:32:07 --> Output Class Initialized
INFO - 2019-11-11 07:32:07 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:07 --> Input Class Initialized
INFO - 2019-11-11 07:32:07 --> Language Class Initialized
INFO - 2019-11-11 07:32:07 --> Language Class Initialized
INFO - 2019-11-11 07:32:07 --> Config Class Initialized
INFO - 2019-11-11 07:32:07 --> Loader Class Initialized
INFO - 2019-11-11 07:32:07 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:07 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:07 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:07 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:07 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:07 --> Controller Class Initialized
INFO - 2019-11-11 07:32:09 --> Config Class Initialized
INFO - 2019-11-11 07:32:09 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:09 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:09 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:09 --> URI Class Initialized
INFO - 2019-11-11 07:32:09 --> Router Class Initialized
INFO - 2019-11-11 07:32:09 --> Output Class Initialized
INFO - 2019-11-11 07:32:09 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:09 --> Input Class Initialized
INFO - 2019-11-11 07:32:09 --> Language Class Initialized
INFO - 2019-11-11 07:32:09 --> Language Class Initialized
INFO - 2019-11-11 07:32:09 --> Config Class Initialized
INFO - 2019-11-11 07:32:09 --> Loader Class Initialized
INFO - 2019-11-11 07:32:09 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:09 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:09 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:09 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:09 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:09 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:09 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:09 --> Total execution time: 0.0951
INFO - 2019-11-11 07:32:14 --> Config Class Initialized
INFO - 2019-11-11 07:32:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:14 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:14 --> URI Class Initialized
INFO - 2019-11-11 07:32:14 --> Router Class Initialized
INFO - 2019-11-11 07:32:14 --> Output Class Initialized
INFO - 2019-11-11 07:32:14 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:14 --> Input Class Initialized
INFO - 2019-11-11 07:32:14 --> Language Class Initialized
INFO - 2019-11-11 07:32:14 --> Language Class Initialized
INFO - 2019-11-11 07:32:14 --> Config Class Initialized
INFO - 2019-11-11 07:32:14 --> Loader Class Initialized
INFO - 2019-11-11 07:32:14 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:14 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:14 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:14 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:14 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:14 --> Controller Class Initialized
INFO - 2019-11-11 07:32:14 --> Config Class Initialized
INFO - 2019-11-11 07:32:14 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:14 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:14 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:14 --> URI Class Initialized
INFO - 2019-11-11 07:32:14 --> Router Class Initialized
INFO - 2019-11-11 07:32:14 --> Output Class Initialized
INFO - 2019-11-11 07:32:14 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:14 --> Input Class Initialized
INFO - 2019-11-11 07:32:14 --> Language Class Initialized
INFO - 2019-11-11 07:32:14 --> Language Class Initialized
INFO - 2019-11-11 07:32:14 --> Config Class Initialized
INFO - 2019-11-11 07:32:14 --> Loader Class Initialized
INFO - 2019-11-11 07:32:14 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:14 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:14 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:14 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:14 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:14 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:32:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:14 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:14 --> Total execution time: 0.0521
INFO - 2019-11-11 07:32:16 --> Config Class Initialized
INFO - 2019-11-11 07:32:16 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:16 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:16 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:16 --> URI Class Initialized
INFO - 2019-11-11 07:32:16 --> Router Class Initialized
INFO - 2019-11-11 07:32:16 --> Output Class Initialized
INFO - 2019-11-11 07:32:16 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:16 --> Input Class Initialized
INFO - 2019-11-11 07:32:16 --> Language Class Initialized
INFO - 2019-11-11 07:32:16 --> Language Class Initialized
INFO - 2019-11-11 07:32:16 --> Config Class Initialized
INFO - 2019-11-11 07:32:16 --> Loader Class Initialized
INFO - 2019-11-11 07:32:16 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:16 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:16 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:16 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:16 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:16 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:32:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:16 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:16 --> Total execution time: 0.0812
INFO - 2019-11-11 07:32:22 --> Config Class Initialized
INFO - 2019-11-11 07:32:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:22 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:22 --> URI Class Initialized
INFO - 2019-11-11 07:32:22 --> Router Class Initialized
INFO - 2019-11-11 07:32:22 --> Output Class Initialized
INFO - 2019-11-11 07:32:22 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:22 --> Input Class Initialized
INFO - 2019-11-11 07:32:22 --> Language Class Initialized
INFO - 2019-11-11 07:32:22 --> Language Class Initialized
INFO - 2019-11-11 07:32:22 --> Config Class Initialized
INFO - 2019-11-11 07:32:22 --> Loader Class Initialized
INFO - 2019-11-11 07:32:22 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:22 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:22 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:22 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:22 --> Controller Class Initialized
INFO - 2019-11-11 07:32:22 --> Config Class Initialized
INFO - 2019-11-11 07:32:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:22 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:22 --> URI Class Initialized
INFO - 2019-11-11 07:32:22 --> Router Class Initialized
INFO - 2019-11-11 07:32:22 --> Output Class Initialized
INFO - 2019-11-11 07:32:22 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:22 --> Input Class Initialized
INFO - 2019-11-11 07:32:22 --> Language Class Initialized
INFO - 2019-11-11 07:32:22 --> Language Class Initialized
INFO - 2019-11-11 07:32:22 --> Config Class Initialized
INFO - 2019-11-11 07:32:22 --> Loader Class Initialized
INFO - 2019-11-11 07:32:22 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:22 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:22 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:22 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:22 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:32:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:22 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:22 --> Total execution time: 0.0770
INFO - 2019-11-11 07:32:22 --> Config Class Initialized
INFO - 2019-11-11 07:32:22 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:22 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:22 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:22 --> URI Class Initialized
INFO - 2019-11-11 07:32:22 --> Router Class Initialized
INFO - 2019-11-11 07:32:22 --> Output Class Initialized
INFO - 2019-11-11 07:32:22 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:22 --> Input Class Initialized
INFO - 2019-11-11 07:32:22 --> Language Class Initialized
INFO - 2019-11-11 07:32:22 --> Language Class Initialized
INFO - 2019-11-11 07:32:22 --> Config Class Initialized
INFO - 2019-11-11 07:32:22 --> Loader Class Initialized
INFO - 2019-11-11 07:32:22 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:22 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:22 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:22 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:22 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:22 --> Controller Class Initialized
INFO - 2019-11-11 07:32:24 --> Config Class Initialized
INFO - 2019-11-11 07:32:24 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:24 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:24 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:24 --> URI Class Initialized
INFO - 2019-11-11 07:32:24 --> Router Class Initialized
INFO - 2019-11-11 07:32:24 --> Output Class Initialized
INFO - 2019-11-11 07:32:24 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:24 --> Input Class Initialized
INFO - 2019-11-11 07:32:24 --> Language Class Initialized
INFO - 2019-11-11 07:32:24 --> Language Class Initialized
INFO - 2019-11-11 07:32:24 --> Config Class Initialized
INFO - 2019-11-11 07:32:24 --> Loader Class Initialized
INFO - 2019-11-11 07:32:24 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:24 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:24 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:24 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:24 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:24 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:24 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:24 --> Total execution time: 0.0954
INFO - 2019-11-11 07:32:29 --> Config Class Initialized
INFO - 2019-11-11 07:32:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:29 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:29 --> URI Class Initialized
INFO - 2019-11-11 07:32:29 --> Router Class Initialized
INFO - 2019-11-11 07:32:29 --> Output Class Initialized
INFO - 2019-11-11 07:32:29 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:29 --> Input Class Initialized
INFO - 2019-11-11 07:32:29 --> Language Class Initialized
INFO - 2019-11-11 07:32:29 --> Language Class Initialized
INFO - 2019-11-11 07:32:29 --> Config Class Initialized
INFO - 2019-11-11 07:32:29 --> Loader Class Initialized
INFO - 2019-11-11 07:32:29 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:29 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:29 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:29 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:29 --> Controller Class Initialized
INFO - 2019-11-11 07:32:29 --> Config Class Initialized
INFO - 2019-11-11 07:32:29 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:29 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:29 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:29 --> URI Class Initialized
INFO - 2019-11-11 07:32:29 --> Router Class Initialized
INFO - 2019-11-11 07:32:29 --> Output Class Initialized
INFO - 2019-11-11 07:32:29 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:29 --> Input Class Initialized
INFO - 2019-11-11 07:32:29 --> Language Class Initialized
INFO - 2019-11-11 07:32:29 --> Language Class Initialized
INFO - 2019-11-11 07:32:29 --> Config Class Initialized
INFO - 2019-11-11 07:32:29 --> Loader Class Initialized
INFO - 2019-11-11 07:32:29 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:29 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:29 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:29 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:29 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:29 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:32:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:29 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:29 --> Total execution time: 0.0528
INFO - 2019-11-11 07:32:34 --> Config Class Initialized
INFO - 2019-11-11 07:32:34 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:34 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:34 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:34 --> URI Class Initialized
INFO - 2019-11-11 07:32:34 --> Router Class Initialized
INFO - 2019-11-11 07:32:34 --> Output Class Initialized
INFO - 2019-11-11 07:32:34 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:34 --> Input Class Initialized
INFO - 2019-11-11 07:32:34 --> Language Class Initialized
INFO - 2019-11-11 07:32:34 --> Language Class Initialized
INFO - 2019-11-11 07:32:34 --> Config Class Initialized
INFO - 2019-11-11 07:32:34 --> Loader Class Initialized
INFO - 2019-11-11 07:32:34 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:34 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:34 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:34 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:34 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:34 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:32:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:34 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:34 --> Total execution time: 0.0851
INFO - 2019-11-11 07:32:39 --> Config Class Initialized
INFO - 2019-11-11 07:32:39 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:39 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:39 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:39 --> URI Class Initialized
INFO - 2019-11-11 07:32:39 --> Router Class Initialized
INFO - 2019-11-11 07:32:39 --> Output Class Initialized
INFO - 2019-11-11 07:32:39 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:39 --> Input Class Initialized
INFO - 2019-11-11 07:32:39 --> Language Class Initialized
INFO - 2019-11-11 07:32:39 --> Language Class Initialized
INFO - 2019-11-11 07:32:39 --> Config Class Initialized
INFO - 2019-11-11 07:32:39 --> Loader Class Initialized
INFO - 2019-11-11 07:32:39 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:39 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:39 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:39 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:39 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:39 --> Controller Class Initialized
INFO - 2019-11-11 07:32:40 --> Config Class Initialized
INFO - 2019-11-11 07:32:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:40 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:40 --> URI Class Initialized
INFO - 2019-11-11 07:32:40 --> Router Class Initialized
INFO - 2019-11-11 07:32:40 --> Output Class Initialized
INFO - 2019-11-11 07:32:40 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:40 --> Input Class Initialized
INFO - 2019-11-11 07:32:40 --> Language Class Initialized
INFO - 2019-11-11 07:32:40 --> Language Class Initialized
INFO - 2019-11-11 07:32:40 --> Config Class Initialized
INFO - 2019-11-11 07:32:40 --> Loader Class Initialized
INFO - 2019-11-11 07:32:40 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:40 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:40 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:40 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:40 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:40 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:40 --> Total execution time: 0.0864
INFO - 2019-11-11 07:32:40 --> Config Class Initialized
INFO - 2019-11-11 07:32:40 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:40 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:40 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:40 --> URI Class Initialized
INFO - 2019-11-11 07:32:40 --> Router Class Initialized
INFO - 2019-11-11 07:32:40 --> Output Class Initialized
INFO - 2019-11-11 07:32:40 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:40 --> Input Class Initialized
INFO - 2019-11-11 07:32:40 --> Language Class Initialized
INFO - 2019-11-11 07:32:40 --> Language Class Initialized
INFO - 2019-11-11 07:32:40 --> Config Class Initialized
INFO - 2019-11-11 07:32:40 --> Loader Class Initialized
INFO - 2019-11-11 07:32:40 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:40 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:40 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:40 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:40 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:40 --> Controller Class Initialized
INFO - 2019-11-11 07:32:43 --> Config Class Initialized
INFO - 2019-11-11 07:32:43 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:43 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:43 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:43 --> URI Class Initialized
INFO - 2019-11-11 07:32:43 --> Router Class Initialized
INFO - 2019-11-11 07:32:43 --> Output Class Initialized
INFO - 2019-11-11 07:32:43 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:43 --> Input Class Initialized
INFO - 2019-11-11 07:32:43 --> Language Class Initialized
INFO - 2019-11-11 07:32:43 --> Language Class Initialized
INFO - 2019-11-11 07:32:43 --> Config Class Initialized
INFO - 2019-11-11 07:32:43 --> Loader Class Initialized
INFO - 2019-11-11 07:32:43 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:43 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:43 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:43 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:43 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:43 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:32:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:43 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:43 --> Total execution time: 0.0888
INFO - 2019-11-11 07:32:48 --> Config Class Initialized
INFO - 2019-11-11 07:32:48 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:48 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:48 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:48 --> URI Class Initialized
INFO - 2019-11-11 07:32:48 --> Router Class Initialized
INFO - 2019-11-11 07:32:48 --> Output Class Initialized
INFO - 2019-11-11 07:32:48 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:48 --> Input Class Initialized
INFO - 2019-11-11 07:32:48 --> Language Class Initialized
INFO - 2019-11-11 07:32:48 --> Language Class Initialized
INFO - 2019-11-11 07:32:48 --> Config Class Initialized
INFO - 2019-11-11 07:32:48 --> Loader Class Initialized
INFO - 2019-11-11 07:32:48 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:48 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:48 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:48 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:48 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:48 --> Controller Class Initialized
INFO - 2019-11-11 07:32:48 --> Config Class Initialized
INFO - 2019-11-11 07:32:48 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:48 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:48 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:48 --> URI Class Initialized
INFO - 2019-11-11 07:32:48 --> Router Class Initialized
INFO - 2019-11-11 07:32:48 --> Output Class Initialized
INFO - 2019-11-11 07:32:48 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:48 --> Input Class Initialized
INFO - 2019-11-11 07:32:48 --> Language Class Initialized
INFO - 2019-11-11 07:32:48 --> Language Class Initialized
INFO - 2019-11-11 07:32:48 --> Config Class Initialized
INFO - 2019-11-11 07:32:48 --> Loader Class Initialized
INFO - 2019-11-11 07:32:48 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:48 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:48 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:48 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:48 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:48 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:48 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:48 --> Total execution time: 0.0859
INFO - 2019-11-11 07:32:51 --> Config Class Initialized
INFO - 2019-11-11 07:32:51 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:51 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:51 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:51 --> URI Class Initialized
INFO - 2019-11-11 07:32:51 --> Router Class Initialized
INFO - 2019-11-11 07:32:51 --> Output Class Initialized
INFO - 2019-11-11 07:32:51 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:51 --> Input Class Initialized
INFO - 2019-11-11 07:32:51 --> Language Class Initialized
INFO - 2019-11-11 07:32:51 --> Language Class Initialized
INFO - 2019-11-11 07:32:51 --> Config Class Initialized
INFO - 2019-11-11 07:32:51 --> Loader Class Initialized
INFO - 2019-11-11 07:32:51 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:51 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:51 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:51 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:51 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:51 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2019-11-11 07:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:51 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:51 --> Total execution time: 0.0954
INFO - 2019-11-11 07:32:56 --> Config Class Initialized
INFO - 2019-11-11 07:32:56 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:56 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:56 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:56 --> URI Class Initialized
INFO - 2019-11-11 07:32:56 --> Router Class Initialized
INFO - 2019-11-11 07:32:56 --> Output Class Initialized
INFO - 2019-11-11 07:32:56 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:56 --> Input Class Initialized
INFO - 2019-11-11 07:32:56 --> Language Class Initialized
INFO - 2019-11-11 07:32:56 --> Language Class Initialized
INFO - 2019-11-11 07:32:56 --> Config Class Initialized
INFO - 2019-11-11 07:32:56 --> Loader Class Initialized
INFO - 2019-11-11 07:32:56 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:56 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:56 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:56 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:56 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:56 --> Controller Class Initialized
INFO - 2019-11-11 07:32:56 --> Config Class Initialized
INFO - 2019-11-11 07:32:56 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:56 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:56 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:56 --> URI Class Initialized
INFO - 2019-11-11 07:32:56 --> Router Class Initialized
INFO - 2019-11-11 07:32:56 --> Output Class Initialized
INFO - 2019-11-11 07:32:56 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:56 --> Input Class Initialized
INFO - 2019-11-11 07:32:56 --> Language Class Initialized
INFO - 2019-11-11 07:32:56 --> Language Class Initialized
INFO - 2019-11-11 07:32:56 --> Config Class Initialized
INFO - 2019-11-11 07:32:56 --> Loader Class Initialized
INFO - 2019-11-11 07:32:56 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:56 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:56 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:56 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:56 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:56 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2019-11-11 07:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:56 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:56 --> Total execution time: 0.0875
INFO - 2019-11-11 07:32:56 --> Config Class Initialized
INFO - 2019-11-11 07:32:56 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:56 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:56 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:56 --> URI Class Initialized
INFO - 2019-11-11 07:32:56 --> Router Class Initialized
INFO - 2019-11-11 07:32:56 --> Output Class Initialized
INFO - 2019-11-11 07:32:56 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:56 --> Input Class Initialized
INFO - 2019-11-11 07:32:56 --> Language Class Initialized
INFO - 2019-11-11 07:32:56 --> Language Class Initialized
INFO - 2019-11-11 07:32:56 --> Config Class Initialized
INFO - 2019-11-11 07:32:56 --> Loader Class Initialized
INFO - 2019-11-11 07:32:56 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:56 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:56 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:56 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:56 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:56 --> Controller Class Initialized
INFO - 2019-11-11 07:32:59 --> Config Class Initialized
INFO - 2019-11-11 07:32:59 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:32:59 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:32:59 --> Utf8 Class Initialized
INFO - 2019-11-11 07:32:59 --> URI Class Initialized
INFO - 2019-11-11 07:32:59 --> Router Class Initialized
INFO - 2019-11-11 07:32:59 --> Output Class Initialized
INFO - 2019-11-11 07:32:59 --> Security Class Initialized
DEBUG - 2019-11-11 07:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:32:59 --> Input Class Initialized
INFO - 2019-11-11 07:32:59 --> Language Class Initialized
INFO - 2019-11-11 07:32:59 --> Language Class Initialized
INFO - 2019-11-11 07:32:59 --> Config Class Initialized
INFO - 2019-11-11 07:32:59 --> Loader Class Initialized
INFO - 2019-11-11 07:32:59 --> Helper loaded: url_helper
INFO - 2019-11-11 07:32:59 --> Helper loaded: file_helper
INFO - 2019-11-11 07:32:59 --> Helper loaded: form_helper
INFO - 2019-11-11 07:32:59 --> Helper loaded: my_helper
INFO - 2019-11-11 07:32:59 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:32:59 --> Controller Class Initialized
DEBUG - 2019-11-11 07:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2019-11-11 07:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:32:59 --> Final output sent to browser
DEBUG - 2019-11-11 07:32:59 --> Total execution time: 0.1031
INFO - 2019-11-11 07:33:05 --> Config Class Initialized
INFO - 2019-11-11 07:33:05 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:05 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:05 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:05 --> URI Class Initialized
INFO - 2019-11-11 07:33:05 --> Router Class Initialized
INFO - 2019-11-11 07:33:05 --> Output Class Initialized
INFO - 2019-11-11 07:33:05 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:05 --> Input Class Initialized
INFO - 2019-11-11 07:33:05 --> Language Class Initialized
INFO - 2019-11-11 07:33:05 --> Language Class Initialized
INFO - 2019-11-11 07:33:05 --> Config Class Initialized
INFO - 2019-11-11 07:33:05 --> Loader Class Initialized
INFO - 2019-11-11 07:33:05 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:05 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:05 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:05 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:05 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:05 --> Controller Class Initialized
INFO - 2019-11-11 07:33:06 --> Config Class Initialized
INFO - 2019-11-11 07:33:06 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:06 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:06 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:06 --> URI Class Initialized
INFO - 2019-11-11 07:33:06 --> Router Class Initialized
INFO - 2019-11-11 07:33:06 --> Output Class Initialized
INFO - 2019-11-11 07:33:06 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:06 --> Input Class Initialized
INFO - 2019-11-11 07:33:06 --> Language Class Initialized
INFO - 2019-11-11 07:33:06 --> Language Class Initialized
INFO - 2019-11-11 07:33:06 --> Config Class Initialized
INFO - 2019-11-11 07:33:06 --> Loader Class Initialized
INFO - 2019-11-11 07:33:06 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:06 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:06 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:06 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:06 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:06 --> Controller Class Initialized
DEBUG - 2019-11-11 07:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2019-11-11 07:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:33:06 --> Final output sent to browser
DEBUG - 2019-11-11 07:33:06 --> Total execution time: 0.0858
INFO - 2019-11-11 07:33:11 --> Config Class Initialized
INFO - 2019-11-11 07:33:11 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:11 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:11 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:11 --> URI Class Initialized
INFO - 2019-11-11 07:33:11 --> Router Class Initialized
INFO - 2019-11-11 07:33:11 --> Output Class Initialized
INFO - 2019-11-11 07:33:11 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:11 --> Input Class Initialized
INFO - 2019-11-11 07:33:11 --> Language Class Initialized
INFO - 2019-11-11 07:33:11 --> Language Class Initialized
INFO - 2019-11-11 07:33:11 --> Config Class Initialized
INFO - 2019-11-11 07:33:11 --> Loader Class Initialized
INFO - 2019-11-11 07:33:11 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:11 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:11 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:11 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:11 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:11 --> Controller Class Initialized
INFO - 2019-11-11 07:33:11 --> Helper loaded: cookie_helper
INFO - 2019-11-11 07:33:11 --> Config Class Initialized
INFO - 2019-11-11 07:33:11 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:11 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:11 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:11 --> URI Class Initialized
INFO - 2019-11-11 07:33:11 --> Router Class Initialized
INFO - 2019-11-11 07:33:11 --> Output Class Initialized
INFO - 2019-11-11 07:33:11 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:11 --> Input Class Initialized
INFO - 2019-11-11 07:33:11 --> Language Class Initialized
INFO - 2019-11-11 07:33:11 --> Language Class Initialized
INFO - 2019-11-11 07:33:11 --> Config Class Initialized
INFO - 2019-11-11 07:33:11 --> Loader Class Initialized
INFO - 2019-11-11 07:33:11 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:11 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:11 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:11 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:11 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:11 --> Controller Class Initialized
DEBUG - 2019-11-11 07:33:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-11-11 07:33:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:33:11 --> Final output sent to browser
DEBUG - 2019-11-11 07:33:11 --> Total execution time: 0.0484
INFO - 2019-11-11 07:33:16 --> Config Class Initialized
INFO - 2019-11-11 07:33:16 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:16 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:16 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:16 --> URI Class Initialized
INFO - 2019-11-11 07:33:16 --> Router Class Initialized
INFO - 2019-11-11 07:33:16 --> Output Class Initialized
INFO - 2019-11-11 07:33:16 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:16 --> Input Class Initialized
INFO - 2019-11-11 07:33:16 --> Language Class Initialized
INFO - 2019-11-11 07:33:16 --> Language Class Initialized
INFO - 2019-11-11 07:33:16 --> Config Class Initialized
INFO - 2019-11-11 07:33:16 --> Loader Class Initialized
INFO - 2019-11-11 07:33:16 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:16 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:16 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:16 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:16 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:16 --> Controller Class Initialized
INFO - 2019-11-11 07:33:16 --> Helper loaded: cookie_helper
INFO - 2019-11-11 07:33:16 --> Final output sent to browser
DEBUG - 2019-11-11 07:33:16 --> Total execution time: 0.0859
INFO - 2019-11-11 07:33:16 --> Config Class Initialized
INFO - 2019-11-11 07:33:16 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:16 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:16 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:16 --> URI Class Initialized
INFO - 2019-11-11 07:33:16 --> Router Class Initialized
INFO - 2019-11-11 07:33:16 --> Output Class Initialized
INFO - 2019-11-11 07:33:16 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:16 --> Input Class Initialized
INFO - 2019-11-11 07:33:16 --> Language Class Initialized
INFO - 2019-11-11 07:33:16 --> Language Class Initialized
INFO - 2019-11-11 07:33:16 --> Config Class Initialized
INFO - 2019-11-11 07:33:16 --> Loader Class Initialized
INFO - 2019-11-11 07:33:16 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:16 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:16 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:16 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:16 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:16 --> Controller Class Initialized
DEBUG - 2019-11-11 07:33:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-11-11 07:33:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:33:17 --> Final output sent to browser
DEBUG - 2019-11-11 07:33:17 --> Total execution time: 0.2325
INFO - 2019-11-11 07:33:19 --> Config Class Initialized
INFO - 2019-11-11 07:33:19 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:19 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:19 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:19 --> URI Class Initialized
INFO - 2019-11-11 07:33:19 --> Router Class Initialized
INFO - 2019-11-11 07:33:19 --> Output Class Initialized
INFO - 2019-11-11 07:33:19 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:19 --> Input Class Initialized
INFO - 2019-11-11 07:33:19 --> Language Class Initialized
INFO - 2019-11-11 07:33:19 --> Language Class Initialized
INFO - 2019-11-11 07:33:19 --> Config Class Initialized
INFO - 2019-11-11 07:33:19 --> Loader Class Initialized
INFO - 2019-11-11 07:33:19 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:19 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:19 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:19 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:19 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:19 --> Controller Class Initialized
DEBUG - 2019-11-11 07:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2019-11-11 07:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-11-11 07:33:19 --> Final output sent to browser
DEBUG - 2019-11-11 07:33:19 --> Total execution time: 0.0704
INFO - 2019-11-11 07:33:19 --> Config Class Initialized
INFO - 2019-11-11 07:33:19 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:19 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:19 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:19 --> URI Class Initialized
INFO - 2019-11-11 07:33:19 --> Router Class Initialized
INFO - 2019-11-11 07:33:19 --> Output Class Initialized
INFO - 2019-11-11 07:33:19 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:19 --> Input Class Initialized
INFO - 2019-11-11 07:33:19 --> Language Class Initialized
INFO - 2019-11-11 07:33:19 --> Language Class Initialized
INFO - 2019-11-11 07:33:19 --> Config Class Initialized
INFO - 2019-11-11 07:33:19 --> Loader Class Initialized
INFO - 2019-11-11 07:33:19 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:19 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:19 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:19 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:19 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:19 --> Controller Class Initialized
INFO - 2019-11-11 07:33:20 --> Config Class Initialized
INFO - 2019-11-11 07:33:20 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:20 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:20 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:20 --> URI Class Initialized
INFO - 2019-11-11 07:33:20 --> Router Class Initialized
INFO - 2019-11-11 07:33:20 --> Output Class Initialized
INFO - 2019-11-11 07:33:20 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:20 --> Input Class Initialized
INFO - 2019-11-11 07:33:20 --> Language Class Initialized
INFO - 2019-11-11 07:33:20 --> Language Class Initialized
INFO - 2019-11-11 07:33:20 --> Config Class Initialized
INFO - 2019-11-11 07:33:20 --> Loader Class Initialized
INFO - 2019-11-11 07:33:20 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:20 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:20 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:20 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:20 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:20 --> Controller Class Initialized
INFO - 2019-11-11 07:33:20 --> Final output sent to browser
DEBUG - 2019-11-11 07:33:20 --> Total execution time: 0.0903
INFO - 2019-11-11 07:33:20 --> Config Class Initialized
INFO - 2019-11-11 07:33:20 --> Hooks Class Initialized
DEBUG - 2019-11-11 07:33:20 --> UTF-8 Support Enabled
INFO - 2019-11-11 07:33:20 --> Utf8 Class Initialized
INFO - 2019-11-11 07:33:20 --> URI Class Initialized
INFO - 2019-11-11 07:33:20 --> Router Class Initialized
INFO - 2019-11-11 07:33:20 --> Output Class Initialized
INFO - 2019-11-11 07:33:20 --> Security Class Initialized
DEBUG - 2019-11-11 07:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-11 07:33:20 --> Input Class Initialized
INFO - 2019-11-11 07:33:20 --> Language Class Initialized
INFO - 2019-11-11 07:33:20 --> Language Class Initialized
INFO - 2019-11-11 07:33:20 --> Config Class Initialized
INFO - 2019-11-11 07:33:20 --> Loader Class Initialized
INFO - 2019-11-11 07:33:20 --> Helper loaded: url_helper
INFO - 2019-11-11 07:33:20 --> Helper loaded: file_helper
INFO - 2019-11-11 07:33:20 --> Helper loaded: form_helper
INFO - 2019-11-11 07:33:20 --> Helper loaded: my_helper
INFO - 2019-11-11 07:33:20 --> Database Driver Class Initialized
DEBUG - 2019-11-11 07:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-11 07:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-11 07:33:20 --> Controller Class Initialized
