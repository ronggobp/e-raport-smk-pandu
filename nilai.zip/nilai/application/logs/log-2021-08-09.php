<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-09 07:32:40 --> Config Class Initialized
INFO - 2021-08-09 07:32:40 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:32:40 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:32:40 --> Utf8 Class Initialized
INFO - 2021-08-09 07:32:40 --> URI Class Initialized
INFO - 2021-08-09 07:32:41 --> Router Class Initialized
INFO - 2021-08-09 07:32:41 --> Output Class Initialized
INFO - 2021-08-09 07:32:41 --> Security Class Initialized
DEBUG - 2021-08-09 07:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:32:41 --> Input Class Initialized
INFO - 2021-08-09 07:32:41 --> Language Class Initialized
INFO - 2021-08-09 07:32:41 --> Language Class Initialized
INFO - 2021-08-09 07:32:41 --> Config Class Initialized
INFO - 2021-08-09 07:32:41 --> Loader Class Initialized
INFO - 2021-08-09 07:32:41 --> Helper loaded: url_helper
INFO - 2021-08-09 07:32:41 --> Helper loaded: file_helper
INFO - 2021-08-09 07:32:41 --> Helper loaded: form_helper
INFO - 2021-08-09 07:32:41 --> Helper loaded: my_helper
INFO - 2021-08-09 07:32:41 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:32:41 --> Controller Class Initialized
DEBUG - 2021-08-09 07:32:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-09 07:32:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:32:41 --> Final output sent to browser
DEBUG - 2021-08-09 07:32:41 --> Total execution time: 0.7097
INFO - 2021-08-09 07:32:47 --> Config Class Initialized
INFO - 2021-08-09 07:32:47 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:32:47 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:32:47 --> Utf8 Class Initialized
INFO - 2021-08-09 07:32:47 --> URI Class Initialized
INFO - 2021-08-09 07:32:47 --> Router Class Initialized
INFO - 2021-08-09 07:32:47 --> Output Class Initialized
INFO - 2021-08-09 07:32:47 --> Security Class Initialized
DEBUG - 2021-08-09 07:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:32:47 --> Input Class Initialized
INFO - 2021-08-09 07:32:47 --> Language Class Initialized
INFO - 2021-08-09 07:32:47 --> Language Class Initialized
INFO - 2021-08-09 07:32:47 --> Config Class Initialized
INFO - 2021-08-09 07:32:47 --> Loader Class Initialized
INFO - 2021-08-09 07:32:47 --> Helper loaded: url_helper
INFO - 2021-08-09 07:32:47 --> Helper loaded: file_helper
INFO - 2021-08-09 07:32:47 --> Helper loaded: form_helper
INFO - 2021-08-09 07:32:47 --> Helper loaded: my_helper
INFO - 2021-08-09 07:32:47 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:32:47 --> Controller Class Initialized
INFO - 2021-08-09 07:32:47 --> Helper loaded: cookie_helper
INFO - 2021-08-09 07:32:47 --> Final output sent to browser
DEBUG - 2021-08-09 07:32:47 --> Total execution time: 0.1035
INFO - 2021-08-09 07:32:48 --> Config Class Initialized
INFO - 2021-08-09 07:32:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:32:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:32:48 --> Utf8 Class Initialized
INFO - 2021-08-09 07:32:48 --> URI Class Initialized
INFO - 2021-08-09 07:32:48 --> Router Class Initialized
INFO - 2021-08-09 07:32:48 --> Output Class Initialized
INFO - 2021-08-09 07:32:48 --> Security Class Initialized
DEBUG - 2021-08-09 07:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:32:48 --> Input Class Initialized
INFO - 2021-08-09 07:32:48 --> Language Class Initialized
INFO - 2021-08-09 07:32:48 --> Language Class Initialized
INFO - 2021-08-09 07:32:48 --> Config Class Initialized
INFO - 2021-08-09 07:32:48 --> Loader Class Initialized
INFO - 2021-08-09 07:32:48 --> Helper loaded: url_helper
INFO - 2021-08-09 07:32:48 --> Helper loaded: file_helper
INFO - 2021-08-09 07:32:48 --> Helper loaded: form_helper
INFO - 2021-08-09 07:32:48 --> Helper loaded: my_helper
INFO - 2021-08-09 07:32:48 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:32:48 --> Controller Class Initialized
DEBUG - 2021-08-09 07:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-09 07:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:32:48 --> Final output sent to browser
DEBUG - 2021-08-09 07:32:48 --> Total execution time: 0.8431
INFO - 2021-08-09 07:32:51 --> Config Class Initialized
INFO - 2021-08-09 07:32:51 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:32:51 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:32:51 --> Utf8 Class Initialized
INFO - 2021-08-09 07:32:51 --> URI Class Initialized
INFO - 2021-08-09 07:32:51 --> Router Class Initialized
INFO - 2021-08-09 07:32:51 --> Output Class Initialized
INFO - 2021-08-09 07:32:51 --> Security Class Initialized
DEBUG - 2021-08-09 07:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:32:51 --> Input Class Initialized
INFO - 2021-08-09 07:32:51 --> Language Class Initialized
INFO - 2021-08-09 07:32:52 --> Language Class Initialized
INFO - 2021-08-09 07:32:52 --> Config Class Initialized
INFO - 2021-08-09 07:32:52 --> Loader Class Initialized
INFO - 2021-08-09 07:32:52 --> Helper loaded: url_helper
INFO - 2021-08-09 07:32:52 --> Helper loaded: file_helper
INFO - 2021-08-09 07:32:52 --> Helper loaded: form_helper
INFO - 2021-08-09 07:32:52 --> Helper loaded: my_helper
INFO - 2021-08-09 07:32:52 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:32:52 --> Controller Class Initialized
DEBUG - 2021-08-09 07:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-09 07:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:32:52 --> Final output sent to browser
DEBUG - 2021-08-09 07:32:52 --> Total execution time: 0.0857
INFO - 2021-08-09 07:32:53 --> Config Class Initialized
INFO - 2021-08-09 07:32:53 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:32:53 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:32:53 --> Utf8 Class Initialized
INFO - 2021-08-09 07:32:53 --> URI Class Initialized
DEBUG - 2021-08-09 07:32:53 --> No URI present. Default controller set.
INFO - 2021-08-09 07:32:53 --> Router Class Initialized
INFO - 2021-08-09 07:32:53 --> Output Class Initialized
INFO - 2021-08-09 07:32:53 --> Security Class Initialized
DEBUG - 2021-08-09 07:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:32:53 --> Input Class Initialized
INFO - 2021-08-09 07:32:53 --> Language Class Initialized
INFO - 2021-08-09 07:32:53 --> Language Class Initialized
INFO - 2021-08-09 07:32:53 --> Config Class Initialized
INFO - 2021-08-09 07:32:53 --> Loader Class Initialized
INFO - 2021-08-09 07:32:53 --> Helper loaded: url_helper
INFO - 2021-08-09 07:32:53 --> Helper loaded: file_helper
INFO - 2021-08-09 07:32:53 --> Helper loaded: form_helper
INFO - 2021-08-09 07:32:53 --> Helper loaded: my_helper
INFO - 2021-08-09 07:32:53 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:32:53 --> Controller Class Initialized
DEBUG - 2021-08-09 07:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-09 07:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:32:54 --> Final output sent to browser
DEBUG - 2021-08-09 07:32:54 --> Total execution time: 0.6276
INFO - 2021-08-09 07:32:58 --> Config Class Initialized
INFO - 2021-08-09 07:32:58 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:32:58 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:32:58 --> Utf8 Class Initialized
INFO - 2021-08-09 07:32:58 --> URI Class Initialized
INFO - 2021-08-09 07:32:58 --> Router Class Initialized
INFO - 2021-08-09 07:32:58 --> Output Class Initialized
INFO - 2021-08-09 07:32:58 --> Security Class Initialized
DEBUG - 2021-08-09 07:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:32:58 --> Input Class Initialized
INFO - 2021-08-09 07:32:58 --> Language Class Initialized
INFO - 2021-08-09 07:32:58 --> Language Class Initialized
INFO - 2021-08-09 07:32:58 --> Config Class Initialized
INFO - 2021-08-09 07:32:58 --> Loader Class Initialized
INFO - 2021-08-09 07:32:58 --> Helper loaded: url_helper
INFO - 2021-08-09 07:32:58 --> Helper loaded: file_helper
INFO - 2021-08-09 07:32:58 --> Helper loaded: form_helper
INFO - 2021-08-09 07:32:58 --> Helper loaded: my_helper
INFO - 2021-08-09 07:32:58 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:32:58 --> Controller Class Initialized
DEBUG - 2021-08-09 07:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-09 07:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:32:58 --> Final output sent to browser
DEBUG - 2021-08-09 07:32:58 --> Total execution time: 0.1452
INFO - 2021-08-09 07:32:59 --> Config Class Initialized
INFO - 2021-08-09 07:32:59 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:32:59 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:32:59 --> Utf8 Class Initialized
INFO - 2021-08-09 07:32:59 --> URI Class Initialized
INFO - 2021-08-09 07:32:59 --> Router Class Initialized
INFO - 2021-08-09 07:32:59 --> Output Class Initialized
INFO - 2021-08-09 07:32:59 --> Security Class Initialized
DEBUG - 2021-08-09 07:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:32:59 --> Input Class Initialized
INFO - 2021-08-09 07:32:59 --> Language Class Initialized
INFO - 2021-08-09 07:32:59 --> Language Class Initialized
INFO - 2021-08-09 07:32:59 --> Config Class Initialized
INFO - 2021-08-09 07:32:59 --> Loader Class Initialized
INFO - 2021-08-09 07:32:59 --> Helper loaded: url_helper
INFO - 2021-08-09 07:32:59 --> Helper loaded: file_helper
INFO - 2021-08-09 07:32:59 --> Helper loaded: form_helper
INFO - 2021-08-09 07:32:59 --> Helper loaded: my_helper
INFO - 2021-08-09 07:32:59 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:32:59 --> Controller Class Initialized
DEBUG - 2021-08-09 07:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-09 07:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:32:59 --> Final output sent to browser
DEBUG - 2021-08-09 07:32:59 --> Total execution time: 0.0733
INFO - 2021-08-09 07:33:03 --> Config Class Initialized
INFO - 2021-08-09 07:33:03 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:33:03 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:33:03 --> Utf8 Class Initialized
INFO - 2021-08-09 07:33:03 --> URI Class Initialized
INFO - 2021-08-09 07:33:03 --> Router Class Initialized
INFO - 2021-08-09 07:33:03 --> Output Class Initialized
INFO - 2021-08-09 07:33:03 --> Security Class Initialized
DEBUG - 2021-08-09 07:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:33:03 --> Input Class Initialized
INFO - 2021-08-09 07:33:03 --> Language Class Initialized
INFO - 2021-08-09 07:33:03 --> Language Class Initialized
INFO - 2021-08-09 07:33:03 --> Config Class Initialized
INFO - 2021-08-09 07:33:03 --> Loader Class Initialized
INFO - 2021-08-09 07:33:03 --> Helper loaded: url_helper
INFO - 2021-08-09 07:33:03 --> Helper loaded: file_helper
INFO - 2021-08-09 07:33:03 --> Helper loaded: form_helper
INFO - 2021-08-09 07:33:03 --> Helper loaded: my_helper
INFO - 2021-08-09 07:33:03 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:33:03 --> Controller Class Initialized
DEBUG - 2021-08-09 07:33:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xi.php
INFO - 2021-08-09 07:33:03 --> Final output sent to browser
DEBUG - 2021-08-09 07:33:03 --> Total execution time: 0.2350
INFO - 2021-08-09 07:33:05 --> Config Class Initialized
INFO - 2021-08-09 07:33:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:33:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:33:05 --> Utf8 Class Initialized
INFO - 2021-08-09 07:33:05 --> URI Class Initialized
INFO - 2021-08-09 07:33:05 --> Router Class Initialized
INFO - 2021-08-09 07:33:05 --> Output Class Initialized
INFO - 2021-08-09 07:33:05 --> Security Class Initialized
DEBUG - 2021-08-09 07:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:33:05 --> Input Class Initialized
INFO - 2021-08-09 07:33:05 --> Language Class Initialized
INFO - 2021-08-09 07:33:05 --> Language Class Initialized
INFO - 2021-08-09 07:33:05 --> Config Class Initialized
INFO - 2021-08-09 07:33:05 --> Loader Class Initialized
INFO - 2021-08-09 07:33:05 --> Helper loaded: url_helper
INFO - 2021-08-09 07:33:05 --> Helper loaded: file_helper
INFO - 2021-08-09 07:33:05 --> Helper loaded: form_helper
INFO - 2021-08-09 07:33:05 --> Helper loaded: my_helper
INFO - 2021-08-09 07:33:05 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:33:05 --> Controller Class Initialized
INFO - 2021-08-09 07:33:05 --> Helper loaded: cookie_helper
INFO - 2021-08-09 07:33:05 --> Config Class Initialized
INFO - 2021-08-09 07:33:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:33:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:33:05 --> Utf8 Class Initialized
INFO - 2021-08-09 07:33:05 --> URI Class Initialized
INFO - 2021-08-09 07:33:05 --> Router Class Initialized
INFO - 2021-08-09 07:33:05 --> Output Class Initialized
INFO - 2021-08-09 07:33:05 --> Security Class Initialized
DEBUG - 2021-08-09 07:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:33:05 --> Input Class Initialized
INFO - 2021-08-09 07:33:05 --> Language Class Initialized
INFO - 2021-08-09 07:33:05 --> Language Class Initialized
INFO - 2021-08-09 07:33:05 --> Config Class Initialized
INFO - 2021-08-09 07:33:05 --> Loader Class Initialized
INFO - 2021-08-09 07:33:05 --> Helper loaded: url_helper
INFO - 2021-08-09 07:33:05 --> Helper loaded: file_helper
INFO - 2021-08-09 07:33:05 --> Helper loaded: form_helper
INFO - 2021-08-09 07:33:05 --> Helper loaded: my_helper
INFO - 2021-08-09 07:33:05 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:33:05 --> Controller Class Initialized
DEBUG - 2021-08-09 07:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-09 07:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:33:05 --> Final output sent to browser
DEBUG - 2021-08-09 07:33:05 --> Total execution time: 0.0416
INFO - 2021-08-09 07:33:09 --> Config Class Initialized
INFO - 2021-08-09 07:33:09 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:33:09 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:33:09 --> Utf8 Class Initialized
INFO - 2021-08-09 07:33:09 --> URI Class Initialized
INFO - 2021-08-09 07:33:09 --> Router Class Initialized
INFO - 2021-08-09 07:33:09 --> Output Class Initialized
INFO - 2021-08-09 07:33:09 --> Security Class Initialized
DEBUG - 2021-08-09 07:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:33:09 --> Input Class Initialized
INFO - 2021-08-09 07:33:09 --> Language Class Initialized
INFO - 2021-08-09 07:33:09 --> Language Class Initialized
INFO - 2021-08-09 07:33:09 --> Config Class Initialized
INFO - 2021-08-09 07:33:09 --> Loader Class Initialized
INFO - 2021-08-09 07:33:09 --> Helper loaded: url_helper
INFO - 2021-08-09 07:33:09 --> Helper loaded: file_helper
INFO - 2021-08-09 07:33:09 --> Helper loaded: form_helper
INFO - 2021-08-09 07:33:09 --> Helper loaded: my_helper
INFO - 2021-08-09 07:33:09 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:33:09 --> Controller Class Initialized
INFO - 2021-08-09 07:33:09 --> Helper loaded: cookie_helper
INFO - 2021-08-09 07:33:09 --> Final output sent to browser
DEBUG - 2021-08-09 07:33:09 --> Total execution time: 0.0469
INFO - 2021-08-09 07:33:09 --> Config Class Initialized
INFO - 2021-08-09 07:33:09 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:33:09 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:33:09 --> Utf8 Class Initialized
INFO - 2021-08-09 07:33:09 --> URI Class Initialized
INFO - 2021-08-09 07:33:09 --> Router Class Initialized
INFO - 2021-08-09 07:33:09 --> Output Class Initialized
INFO - 2021-08-09 07:33:10 --> Security Class Initialized
DEBUG - 2021-08-09 07:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:33:10 --> Input Class Initialized
INFO - 2021-08-09 07:33:10 --> Language Class Initialized
INFO - 2021-08-09 07:33:10 --> Language Class Initialized
INFO - 2021-08-09 07:33:10 --> Config Class Initialized
INFO - 2021-08-09 07:33:10 --> Loader Class Initialized
INFO - 2021-08-09 07:33:10 --> Helper loaded: url_helper
INFO - 2021-08-09 07:33:10 --> Helper loaded: file_helper
INFO - 2021-08-09 07:33:10 --> Helper loaded: form_helper
INFO - 2021-08-09 07:33:10 --> Helper loaded: my_helper
INFO - 2021-08-09 07:33:10 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:33:10 --> Controller Class Initialized
DEBUG - 2021-08-09 07:33:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-09 07:33:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:33:10 --> Final output sent to browser
DEBUG - 2021-08-09 07:33:10 --> Total execution time: 0.7148
INFO - 2021-08-09 07:34:48 --> Config Class Initialized
INFO - 2021-08-09 07:34:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:34:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:34:48 --> Utf8 Class Initialized
INFO - 2021-08-09 07:34:48 --> URI Class Initialized
INFO - 2021-08-09 07:34:48 --> Router Class Initialized
INFO - 2021-08-09 07:34:48 --> Output Class Initialized
INFO - 2021-08-09 07:34:48 --> Security Class Initialized
DEBUG - 2021-08-09 07:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:34:48 --> Input Class Initialized
INFO - 2021-08-09 07:34:48 --> Language Class Initialized
INFO - 2021-08-09 07:34:48 --> Language Class Initialized
INFO - 2021-08-09 07:34:48 --> Config Class Initialized
INFO - 2021-08-09 07:34:48 --> Loader Class Initialized
INFO - 2021-08-09 07:34:48 --> Helper loaded: url_helper
INFO - 2021-08-09 07:34:48 --> Helper loaded: file_helper
INFO - 2021-08-09 07:34:48 --> Helper loaded: form_helper
INFO - 2021-08-09 07:34:48 --> Helper loaded: my_helper
INFO - 2021-08-09 07:34:48 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:34:48 --> Controller Class Initialized
DEBUG - 2021-08-09 07:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-09 07:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:34:48 --> Final output sent to browser
DEBUG - 2021-08-09 07:34:48 --> Total execution time: 0.0633
INFO - 2021-08-09 07:34:51 --> Config Class Initialized
INFO - 2021-08-09 07:34:51 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:34:51 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:34:51 --> Utf8 Class Initialized
INFO - 2021-08-09 07:34:51 --> URI Class Initialized
INFO - 2021-08-09 07:34:51 --> Router Class Initialized
INFO - 2021-08-09 07:34:51 --> Output Class Initialized
INFO - 2021-08-09 07:34:51 --> Security Class Initialized
DEBUG - 2021-08-09 07:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:34:51 --> Input Class Initialized
INFO - 2021-08-09 07:34:51 --> Language Class Initialized
INFO - 2021-08-09 07:34:51 --> Language Class Initialized
INFO - 2021-08-09 07:34:51 --> Config Class Initialized
INFO - 2021-08-09 07:34:51 --> Loader Class Initialized
INFO - 2021-08-09 07:34:51 --> Helper loaded: url_helper
INFO - 2021-08-09 07:34:51 --> Helper loaded: file_helper
INFO - 2021-08-09 07:34:51 --> Helper loaded: form_helper
INFO - 2021-08-09 07:34:51 --> Helper loaded: my_helper
INFO - 2021-08-09 07:34:51 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:34:51 --> Controller Class Initialized
DEBUG - 2021-08-09 07:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2021-08-09 07:34:51 --> Final output sent to browser
DEBUG - 2021-08-09 07:34:51 --> Total execution time: 0.2322
INFO - 2021-08-09 07:35:31 --> Config Class Initialized
INFO - 2021-08-09 07:35:31 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:35:31 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:35:31 --> Utf8 Class Initialized
INFO - 2021-08-09 07:35:31 --> URI Class Initialized
INFO - 2021-08-09 07:35:31 --> Router Class Initialized
INFO - 2021-08-09 07:35:31 --> Output Class Initialized
INFO - 2021-08-09 07:35:31 --> Security Class Initialized
DEBUG - 2021-08-09 07:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:35:31 --> Input Class Initialized
INFO - 2021-08-09 07:35:31 --> Language Class Initialized
INFO - 2021-08-09 07:35:31 --> Language Class Initialized
INFO - 2021-08-09 07:35:31 --> Config Class Initialized
INFO - 2021-08-09 07:35:31 --> Loader Class Initialized
INFO - 2021-08-09 07:35:31 --> Helper loaded: url_helper
INFO - 2021-08-09 07:35:31 --> Helper loaded: file_helper
INFO - 2021-08-09 07:35:31 --> Helper loaded: form_helper
INFO - 2021-08-09 07:35:31 --> Helper loaded: my_helper
INFO - 2021-08-09 07:35:31 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:35:31 --> Controller Class Initialized
INFO - 2021-08-09 07:35:31 --> Helper loaded: cookie_helper
INFO - 2021-08-09 07:35:31 --> Config Class Initialized
INFO - 2021-08-09 07:35:31 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:35:31 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:35:31 --> Utf8 Class Initialized
INFO - 2021-08-09 07:35:31 --> URI Class Initialized
INFO - 2021-08-09 07:35:31 --> Router Class Initialized
INFO - 2021-08-09 07:35:31 --> Output Class Initialized
INFO - 2021-08-09 07:35:31 --> Security Class Initialized
DEBUG - 2021-08-09 07:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:35:31 --> Input Class Initialized
INFO - 2021-08-09 07:35:31 --> Language Class Initialized
INFO - 2021-08-09 07:35:31 --> Language Class Initialized
INFO - 2021-08-09 07:35:31 --> Config Class Initialized
INFO - 2021-08-09 07:35:31 --> Loader Class Initialized
INFO - 2021-08-09 07:35:31 --> Helper loaded: url_helper
INFO - 2021-08-09 07:35:31 --> Helper loaded: file_helper
INFO - 2021-08-09 07:35:31 --> Helper loaded: form_helper
INFO - 2021-08-09 07:35:31 --> Helper loaded: my_helper
INFO - 2021-08-09 07:35:31 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:35:31 --> Controller Class Initialized
DEBUG - 2021-08-09 07:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-09 07:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:35:31 --> Final output sent to browser
DEBUG - 2021-08-09 07:35:31 --> Total execution time: 0.0551
INFO - 2021-08-09 07:35:36 --> Config Class Initialized
INFO - 2021-08-09 07:35:36 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:35:36 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:35:36 --> Utf8 Class Initialized
INFO - 2021-08-09 07:35:36 --> URI Class Initialized
INFO - 2021-08-09 07:35:36 --> Router Class Initialized
INFO - 2021-08-09 07:35:36 --> Output Class Initialized
INFO - 2021-08-09 07:35:36 --> Security Class Initialized
DEBUG - 2021-08-09 07:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:35:36 --> Input Class Initialized
INFO - 2021-08-09 07:35:36 --> Language Class Initialized
INFO - 2021-08-09 07:35:36 --> Language Class Initialized
INFO - 2021-08-09 07:35:36 --> Config Class Initialized
INFO - 2021-08-09 07:35:36 --> Loader Class Initialized
INFO - 2021-08-09 07:35:36 --> Helper loaded: url_helper
INFO - 2021-08-09 07:35:36 --> Helper loaded: file_helper
INFO - 2021-08-09 07:35:36 --> Helper loaded: form_helper
INFO - 2021-08-09 07:35:36 --> Helper loaded: my_helper
INFO - 2021-08-09 07:35:36 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:35:36 --> Controller Class Initialized
INFO - 2021-08-09 07:35:36 --> Helper loaded: cookie_helper
INFO - 2021-08-09 07:35:36 --> Final output sent to browser
DEBUG - 2021-08-09 07:35:36 --> Total execution time: 0.0516
INFO - 2021-08-09 07:35:37 --> Config Class Initialized
INFO - 2021-08-09 07:35:37 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:35:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:35:37 --> Utf8 Class Initialized
INFO - 2021-08-09 07:35:37 --> URI Class Initialized
INFO - 2021-08-09 07:35:37 --> Router Class Initialized
INFO - 2021-08-09 07:35:37 --> Output Class Initialized
INFO - 2021-08-09 07:35:37 --> Security Class Initialized
DEBUG - 2021-08-09 07:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:35:37 --> Input Class Initialized
INFO - 2021-08-09 07:35:37 --> Language Class Initialized
INFO - 2021-08-09 07:35:37 --> Language Class Initialized
INFO - 2021-08-09 07:35:37 --> Config Class Initialized
INFO - 2021-08-09 07:35:37 --> Loader Class Initialized
INFO - 2021-08-09 07:35:37 --> Helper loaded: url_helper
INFO - 2021-08-09 07:35:37 --> Helper loaded: file_helper
INFO - 2021-08-09 07:35:37 --> Helper loaded: form_helper
INFO - 2021-08-09 07:35:37 --> Helper loaded: my_helper
INFO - 2021-08-09 07:35:37 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:35:37 --> Controller Class Initialized
DEBUG - 2021-08-09 07:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-09 07:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:35:37 --> Final output sent to browser
DEBUG - 2021-08-09 07:35:37 --> Total execution time: 0.7044
INFO - 2021-08-09 07:35:39 --> Config Class Initialized
INFO - 2021-08-09 07:35:39 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:35:39 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:35:39 --> Utf8 Class Initialized
INFO - 2021-08-09 07:35:39 --> URI Class Initialized
INFO - 2021-08-09 07:35:39 --> Router Class Initialized
INFO - 2021-08-09 07:35:39 --> Output Class Initialized
INFO - 2021-08-09 07:35:39 --> Security Class Initialized
DEBUG - 2021-08-09 07:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:35:39 --> Input Class Initialized
INFO - 2021-08-09 07:35:39 --> Language Class Initialized
INFO - 2021-08-09 07:35:39 --> Language Class Initialized
INFO - 2021-08-09 07:35:39 --> Config Class Initialized
INFO - 2021-08-09 07:35:39 --> Loader Class Initialized
INFO - 2021-08-09 07:35:39 --> Helper loaded: url_helper
INFO - 2021-08-09 07:35:39 --> Helper loaded: file_helper
INFO - 2021-08-09 07:35:39 --> Helper loaded: form_helper
INFO - 2021-08-09 07:35:39 --> Helper loaded: my_helper
INFO - 2021-08-09 07:35:39 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:35:39 --> Controller Class Initialized
DEBUG - 2021-08-09 07:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-09 07:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:35:39 --> Final output sent to browser
DEBUG - 2021-08-09 07:35:39 --> Total execution time: 0.0647
INFO - 2021-08-09 07:35:41 --> Config Class Initialized
INFO - 2021-08-09 07:35:41 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:35:41 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:35:41 --> Utf8 Class Initialized
INFO - 2021-08-09 07:35:41 --> URI Class Initialized
INFO - 2021-08-09 07:35:41 --> Router Class Initialized
INFO - 2021-08-09 07:35:41 --> Output Class Initialized
INFO - 2021-08-09 07:35:41 --> Security Class Initialized
DEBUG - 2021-08-09 07:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:35:41 --> Input Class Initialized
INFO - 2021-08-09 07:35:41 --> Language Class Initialized
INFO - 2021-08-09 07:35:41 --> Language Class Initialized
INFO - 2021-08-09 07:35:41 --> Config Class Initialized
INFO - 2021-08-09 07:35:41 --> Loader Class Initialized
INFO - 2021-08-09 07:35:41 --> Helper loaded: url_helper
INFO - 2021-08-09 07:35:41 --> Helper loaded: file_helper
INFO - 2021-08-09 07:35:41 --> Helper loaded: form_helper
INFO - 2021-08-09 07:35:41 --> Helper loaded: my_helper
INFO - 2021-08-09 07:35:41 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:35:41 --> Controller Class Initialized
DEBUG - 2021-08-09 07:35:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-09 07:35:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:35:41 --> Final output sent to browser
DEBUG - 2021-08-09 07:35:41 --> Total execution time: 0.0643
INFO - 2021-08-09 07:35:44 --> Config Class Initialized
INFO - 2021-08-09 07:35:44 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:35:44 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:35:44 --> Utf8 Class Initialized
INFO - 2021-08-09 07:35:44 --> URI Class Initialized
INFO - 2021-08-09 07:35:44 --> Router Class Initialized
INFO - 2021-08-09 07:35:44 --> Output Class Initialized
INFO - 2021-08-09 07:35:44 --> Security Class Initialized
DEBUG - 2021-08-09 07:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:35:44 --> Input Class Initialized
INFO - 2021-08-09 07:35:44 --> Language Class Initialized
INFO - 2021-08-09 07:35:44 --> Language Class Initialized
INFO - 2021-08-09 07:35:44 --> Config Class Initialized
INFO - 2021-08-09 07:35:44 --> Loader Class Initialized
INFO - 2021-08-09 07:35:44 --> Helper loaded: url_helper
INFO - 2021-08-09 07:35:44 --> Helper loaded: file_helper
INFO - 2021-08-09 07:35:44 --> Helper loaded: form_helper
INFO - 2021-08-09 07:35:44 --> Helper loaded: my_helper
INFO - 2021-08-09 07:35:44 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:35:44 --> Controller Class Initialized
DEBUG - 2021-08-09 07:35:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2021-08-09 07:35:44 --> Final output sent to browser
DEBUG - 2021-08-09 07:35:44 --> Total execution time: 0.2538
INFO - 2021-08-09 07:35:45 --> Config Class Initialized
INFO - 2021-08-09 07:35:45 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:35:45 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:35:45 --> Utf8 Class Initialized
INFO - 2021-08-09 07:35:45 --> URI Class Initialized
DEBUG - 2021-08-09 07:35:45 --> No URI present. Default controller set.
INFO - 2021-08-09 07:35:45 --> Router Class Initialized
INFO - 2021-08-09 07:35:45 --> Output Class Initialized
INFO - 2021-08-09 07:35:45 --> Security Class Initialized
DEBUG - 2021-08-09 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:35:45 --> Input Class Initialized
INFO - 2021-08-09 07:35:45 --> Language Class Initialized
INFO - 2021-08-09 07:35:45 --> Language Class Initialized
INFO - 2021-08-09 07:35:45 --> Config Class Initialized
INFO - 2021-08-09 07:35:45 --> Loader Class Initialized
INFO - 2021-08-09 07:35:45 --> Helper loaded: url_helper
INFO - 2021-08-09 07:35:45 --> Helper loaded: file_helper
INFO - 2021-08-09 07:35:45 --> Helper loaded: form_helper
INFO - 2021-08-09 07:35:45 --> Helper loaded: my_helper
INFO - 2021-08-09 07:35:45 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:35:45 --> Controller Class Initialized
DEBUG - 2021-08-09 07:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-09 07:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:35:46 --> Final output sent to browser
DEBUG - 2021-08-09 07:35:46 --> Total execution time: 0.7214
INFO - 2021-08-09 07:36:49 --> Config Class Initialized
INFO - 2021-08-09 07:36:49 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:36:49 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:36:49 --> Utf8 Class Initialized
INFO - 2021-08-09 07:36:49 --> URI Class Initialized
INFO - 2021-08-09 07:36:49 --> Router Class Initialized
INFO - 2021-08-09 07:36:49 --> Output Class Initialized
INFO - 2021-08-09 07:36:49 --> Security Class Initialized
DEBUG - 2021-08-09 07:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:36:49 --> Input Class Initialized
INFO - 2021-08-09 07:36:49 --> Language Class Initialized
INFO - 2021-08-09 07:36:49 --> Language Class Initialized
INFO - 2021-08-09 07:36:49 --> Config Class Initialized
INFO - 2021-08-09 07:36:49 --> Loader Class Initialized
INFO - 2021-08-09 07:36:49 --> Helper loaded: url_helper
INFO - 2021-08-09 07:36:49 --> Helper loaded: file_helper
INFO - 2021-08-09 07:36:49 --> Helper loaded: form_helper
INFO - 2021-08-09 07:36:49 --> Helper loaded: my_helper
INFO - 2021-08-09 07:36:49 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:36:49 --> Controller Class Initialized
INFO - 2021-08-09 07:36:49 --> Helper loaded: cookie_helper
INFO - 2021-08-09 07:36:49 --> Config Class Initialized
INFO - 2021-08-09 07:36:49 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:36:49 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:36:49 --> Utf8 Class Initialized
INFO - 2021-08-09 07:36:49 --> URI Class Initialized
INFO - 2021-08-09 07:36:49 --> Router Class Initialized
INFO - 2021-08-09 07:36:49 --> Output Class Initialized
INFO - 2021-08-09 07:36:49 --> Security Class Initialized
DEBUG - 2021-08-09 07:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:36:49 --> Input Class Initialized
INFO - 2021-08-09 07:36:49 --> Language Class Initialized
INFO - 2021-08-09 07:36:49 --> Language Class Initialized
INFO - 2021-08-09 07:36:49 --> Config Class Initialized
INFO - 2021-08-09 07:36:49 --> Loader Class Initialized
INFO - 2021-08-09 07:36:49 --> Helper loaded: url_helper
INFO - 2021-08-09 07:36:49 --> Helper loaded: file_helper
INFO - 2021-08-09 07:36:49 --> Helper loaded: form_helper
INFO - 2021-08-09 07:36:49 --> Helper loaded: my_helper
INFO - 2021-08-09 07:36:49 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:36:49 --> Controller Class Initialized
DEBUG - 2021-08-09 07:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-09 07:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:36:49 --> Final output sent to browser
DEBUG - 2021-08-09 07:36:49 --> Total execution time: 0.0533
INFO - 2021-08-09 07:44:05 --> Config Class Initialized
INFO - 2021-08-09 07:44:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:44:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:44:05 --> Utf8 Class Initialized
INFO - 2021-08-09 07:44:05 --> URI Class Initialized
INFO - 2021-08-09 07:44:05 --> Router Class Initialized
INFO - 2021-08-09 07:44:05 --> Output Class Initialized
INFO - 2021-08-09 07:44:05 --> Security Class Initialized
DEBUG - 2021-08-09 07:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:44:05 --> Input Class Initialized
INFO - 2021-08-09 07:44:05 --> Language Class Initialized
INFO - 2021-08-09 07:44:05 --> Language Class Initialized
INFO - 2021-08-09 07:44:05 --> Config Class Initialized
INFO - 2021-08-09 07:44:05 --> Loader Class Initialized
INFO - 2021-08-09 07:44:05 --> Helper loaded: url_helper
INFO - 2021-08-09 07:44:05 --> Helper loaded: file_helper
INFO - 2021-08-09 07:44:05 --> Helper loaded: form_helper
INFO - 2021-08-09 07:44:05 --> Helper loaded: my_helper
INFO - 2021-08-09 07:44:05 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:44:05 --> Controller Class Initialized
DEBUG - 2021-08-09 07:44:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-09 07:44:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:44:05 --> Final output sent to browser
DEBUG - 2021-08-09 07:44:05 --> Total execution time: 0.6904
INFO - 2021-08-09 07:59:18 --> Config Class Initialized
INFO - 2021-08-09 07:59:18 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:59:18 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:59:18 --> Utf8 Class Initialized
INFO - 2021-08-09 07:59:18 --> URI Class Initialized
INFO - 2021-08-09 07:59:18 --> Router Class Initialized
INFO - 2021-08-09 07:59:18 --> Output Class Initialized
INFO - 2021-08-09 07:59:18 --> Security Class Initialized
DEBUG - 2021-08-09 07:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:59:18 --> Input Class Initialized
INFO - 2021-08-09 07:59:18 --> Language Class Initialized
INFO - 2021-08-09 07:59:18 --> Language Class Initialized
INFO - 2021-08-09 07:59:18 --> Config Class Initialized
INFO - 2021-08-09 07:59:18 --> Loader Class Initialized
INFO - 2021-08-09 07:59:18 --> Helper loaded: url_helper
INFO - 2021-08-09 07:59:18 --> Helper loaded: file_helper
INFO - 2021-08-09 07:59:18 --> Helper loaded: form_helper
INFO - 2021-08-09 07:59:18 --> Helper loaded: my_helper
INFO - 2021-08-09 07:59:18 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:59:18 --> Controller Class Initialized
INFO - 2021-08-09 07:59:19 --> Helper loaded: cookie_helper
INFO - 2021-08-09 07:59:19 --> Final output sent to browser
DEBUG - 2021-08-09 07:59:19 --> Total execution time: 0.9832
INFO - 2021-08-09 07:59:26 --> Config Class Initialized
INFO - 2021-08-09 07:59:26 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:59:26 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:59:26 --> Utf8 Class Initialized
INFO - 2021-08-09 07:59:26 --> URI Class Initialized
INFO - 2021-08-09 07:59:26 --> Router Class Initialized
INFO - 2021-08-09 07:59:26 --> Output Class Initialized
INFO - 2021-08-09 07:59:26 --> Security Class Initialized
DEBUG - 2021-08-09 07:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:59:26 --> Input Class Initialized
INFO - 2021-08-09 07:59:26 --> Language Class Initialized
INFO - 2021-08-09 07:59:26 --> Language Class Initialized
INFO - 2021-08-09 07:59:26 --> Config Class Initialized
INFO - 2021-08-09 07:59:26 --> Loader Class Initialized
INFO - 2021-08-09 07:59:26 --> Helper loaded: url_helper
INFO - 2021-08-09 07:59:26 --> Helper loaded: file_helper
INFO - 2021-08-09 07:59:26 --> Helper loaded: form_helper
INFO - 2021-08-09 07:59:26 --> Helper loaded: my_helper
INFO - 2021-08-09 07:59:26 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:59:26 --> Controller Class Initialized
DEBUG - 2021-08-09 07:59:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-09 07:59:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:59:27 --> Final output sent to browser
DEBUG - 2021-08-09 07:59:27 --> Total execution time: 0.8256
INFO - 2021-08-09 07:59:43 --> Config Class Initialized
INFO - 2021-08-09 07:59:43 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:59:43 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:59:43 --> Utf8 Class Initialized
INFO - 2021-08-09 07:59:43 --> URI Class Initialized
INFO - 2021-08-09 07:59:43 --> Router Class Initialized
INFO - 2021-08-09 07:59:43 --> Output Class Initialized
INFO - 2021-08-09 07:59:43 --> Security Class Initialized
DEBUG - 2021-08-09 07:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:59:43 --> Input Class Initialized
INFO - 2021-08-09 07:59:43 --> Language Class Initialized
INFO - 2021-08-09 07:59:43 --> Language Class Initialized
INFO - 2021-08-09 07:59:43 --> Config Class Initialized
INFO - 2021-08-09 07:59:43 --> Loader Class Initialized
INFO - 2021-08-09 07:59:43 --> Helper loaded: url_helper
INFO - 2021-08-09 07:59:43 --> Helper loaded: file_helper
INFO - 2021-08-09 07:59:43 --> Helper loaded: form_helper
INFO - 2021-08-09 07:59:43 --> Helper loaded: my_helper
INFO - 2021-08-09 07:59:43 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:59:43 --> Controller Class Initialized
DEBUG - 2021-08-09 07:59:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-08-09 07:59:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:59:43 --> Final output sent to browser
DEBUG - 2021-08-09 07:59:43 --> Total execution time: 0.1407
INFO - 2021-08-09 08:03:11 --> Config Class Initialized
INFO - 2021-08-09 08:03:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:03:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:03:11 --> Utf8 Class Initialized
INFO - 2021-08-09 08:03:11 --> URI Class Initialized
INFO - 2021-08-09 08:03:11 --> Router Class Initialized
INFO - 2021-08-09 08:03:11 --> Output Class Initialized
INFO - 2021-08-09 08:03:11 --> Security Class Initialized
DEBUG - 2021-08-09 08:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:03:11 --> Input Class Initialized
INFO - 2021-08-09 08:03:11 --> Language Class Initialized
INFO - 2021-08-09 08:03:11 --> Language Class Initialized
INFO - 2021-08-09 08:03:11 --> Config Class Initialized
INFO - 2021-08-09 08:03:11 --> Loader Class Initialized
INFO - 2021-08-09 08:03:11 --> Helper loaded: url_helper
INFO - 2021-08-09 08:03:11 --> Helper loaded: file_helper
INFO - 2021-08-09 08:03:11 --> Helper loaded: form_helper
INFO - 2021-08-09 08:03:11 --> Helper loaded: my_helper
INFO - 2021-08-09 08:03:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:03:11 --> Controller Class Initialized
INFO - 2021-08-09 08:03:11 --> Final output sent to browser
DEBUG - 2021-08-09 08:03:11 --> Total execution time: 0.2224
INFO - 2021-08-09 08:06:02 --> Config Class Initialized
INFO - 2021-08-09 08:06:02 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:06:02 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:06:02 --> Utf8 Class Initialized
INFO - 2021-08-09 08:06:02 --> URI Class Initialized
INFO - 2021-08-09 08:06:02 --> Router Class Initialized
INFO - 2021-08-09 08:06:02 --> Output Class Initialized
INFO - 2021-08-09 08:06:02 --> Security Class Initialized
DEBUG - 2021-08-09 08:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:06:02 --> Input Class Initialized
INFO - 2021-08-09 08:06:02 --> Language Class Initialized
INFO - 2021-08-09 08:06:02 --> Language Class Initialized
INFO - 2021-08-09 08:06:02 --> Config Class Initialized
INFO - 2021-08-09 08:06:02 --> Loader Class Initialized
INFO - 2021-08-09 08:06:02 --> Helper loaded: url_helper
INFO - 2021-08-09 08:06:02 --> Helper loaded: file_helper
INFO - 2021-08-09 08:06:02 --> Helper loaded: form_helper
INFO - 2021-08-09 08:06:02 --> Helper loaded: my_helper
INFO - 2021-08-09 08:06:02 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:06:02 --> Controller Class Initialized
DEBUG - 2021-08-09 08:06:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-08-09 08:06:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 08:06:02 --> Final output sent to browser
DEBUG - 2021-08-09 08:06:02 --> Total execution time: 0.0740
INFO - 2021-08-09 08:06:13 --> Config Class Initialized
INFO - 2021-08-09 08:06:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:06:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:06:13 --> Utf8 Class Initialized
INFO - 2021-08-09 08:06:13 --> URI Class Initialized
INFO - 2021-08-09 08:06:13 --> Router Class Initialized
INFO - 2021-08-09 08:06:13 --> Output Class Initialized
INFO - 2021-08-09 08:06:13 --> Security Class Initialized
DEBUG - 2021-08-09 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:06:13 --> Input Class Initialized
INFO - 2021-08-09 08:06:13 --> Language Class Initialized
INFO - 2021-08-09 08:06:13 --> Language Class Initialized
INFO - 2021-08-09 08:06:13 --> Config Class Initialized
INFO - 2021-08-09 08:06:13 --> Loader Class Initialized
INFO - 2021-08-09 08:06:13 --> Helper loaded: url_helper
INFO - 2021-08-09 08:06:13 --> Helper loaded: file_helper
INFO - 2021-08-09 08:06:13 --> Helper loaded: form_helper
INFO - 2021-08-09 08:06:13 --> Helper loaded: my_helper
INFO - 2021-08-09 08:06:13 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:06:13 --> Controller Class Initialized
DEBUG - 2021-08-09 08:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-09 08:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 08:06:13 --> Final output sent to browser
DEBUG - 2021-08-09 08:06:13 --> Total execution time: 0.1370
INFO - 2021-08-09 08:06:32 --> Config Class Initialized
INFO - 2021-08-09 08:06:32 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:06:32 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:06:32 --> Utf8 Class Initialized
INFO - 2021-08-09 08:06:32 --> URI Class Initialized
INFO - 2021-08-09 08:06:32 --> Router Class Initialized
INFO - 2021-08-09 08:06:32 --> Output Class Initialized
INFO - 2021-08-09 08:06:32 --> Security Class Initialized
DEBUG - 2021-08-09 08:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:06:32 --> Input Class Initialized
INFO - 2021-08-09 08:06:32 --> Language Class Initialized
INFO - 2021-08-09 08:06:32 --> Language Class Initialized
INFO - 2021-08-09 08:06:32 --> Config Class Initialized
INFO - 2021-08-09 08:06:32 --> Loader Class Initialized
INFO - 2021-08-09 08:06:32 --> Helper loaded: url_helper
INFO - 2021-08-09 08:06:32 --> Helper loaded: file_helper
INFO - 2021-08-09 08:06:32 --> Helper loaded: form_helper
INFO - 2021-08-09 08:06:32 --> Helper loaded: my_helper
INFO - 2021-08-09 08:06:32 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:06:32 --> Controller Class Initialized
DEBUG - 2021-08-09 08:06:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-08-09 08:06:32 --> Final output sent to browser
DEBUG - 2021-08-09 08:06:32 --> Total execution time: 0.2781
INFO - 2021-08-09 08:06:57 --> Config Class Initialized
INFO - 2021-08-09 08:06:57 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:06:57 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:06:57 --> Utf8 Class Initialized
INFO - 2021-08-09 08:06:57 --> URI Class Initialized
INFO - 2021-08-09 08:06:57 --> Router Class Initialized
INFO - 2021-08-09 08:06:57 --> Output Class Initialized
INFO - 2021-08-09 08:06:57 --> Security Class Initialized
DEBUG - 2021-08-09 08:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:06:57 --> Input Class Initialized
INFO - 2021-08-09 08:06:57 --> Language Class Initialized
INFO - 2021-08-09 08:06:57 --> Language Class Initialized
INFO - 2021-08-09 08:06:57 --> Config Class Initialized
INFO - 2021-08-09 08:06:57 --> Loader Class Initialized
INFO - 2021-08-09 08:06:57 --> Helper loaded: url_helper
INFO - 2021-08-09 08:06:57 --> Helper loaded: file_helper
INFO - 2021-08-09 08:06:57 --> Helper loaded: form_helper
INFO - 2021-08-09 08:06:57 --> Helper loaded: my_helper
INFO - 2021-08-09 08:06:57 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:06:57 --> Controller Class Initialized
DEBUG - 2021-08-09 08:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-08-09 08:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 08:06:57 --> Final output sent to browser
DEBUG - 2021-08-09 08:06:57 --> Total execution time: 0.0754
INFO - 2021-08-09 08:08:57 --> Config Class Initialized
INFO - 2021-08-09 08:08:57 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:08:57 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:08:57 --> Utf8 Class Initialized
INFO - 2021-08-09 08:08:57 --> URI Class Initialized
INFO - 2021-08-09 08:08:57 --> Router Class Initialized
INFO - 2021-08-09 08:08:57 --> Output Class Initialized
INFO - 2021-08-09 08:08:57 --> Security Class Initialized
DEBUG - 2021-08-09 08:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:08:57 --> Input Class Initialized
INFO - 2021-08-09 08:08:57 --> Language Class Initialized
INFO - 2021-08-09 08:08:57 --> Language Class Initialized
INFO - 2021-08-09 08:08:57 --> Config Class Initialized
INFO - 2021-08-09 08:08:57 --> Loader Class Initialized
INFO - 2021-08-09 08:08:57 --> Helper loaded: url_helper
INFO - 2021-08-09 08:08:57 --> Helper loaded: file_helper
INFO - 2021-08-09 08:08:57 --> Helper loaded: form_helper
INFO - 2021-08-09 08:08:57 --> Helper loaded: my_helper
INFO - 2021-08-09 08:08:57 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:08:57 --> Controller Class Initialized
INFO - 2021-08-09 08:08:58 --> Final output sent to browser
DEBUG - 2021-08-09 08:08:58 --> Total execution time: 0.2368
INFO - 2021-08-09 08:10:19 --> Config Class Initialized
INFO - 2021-08-09 08:10:19 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:10:19 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:10:19 --> Utf8 Class Initialized
INFO - 2021-08-09 08:10:19 --> URI Class Initialized
INFO - 2021-08-09 08:10:19 --> Router Class Initialized
INFO - 2021-08-09 08:10:19 --> Output Class Initialized
INFO - 2021-08-09 08:10:19 --> Security Class Initialized
DEBUG - 2021-08-09 08:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:10:19 --> Input Class Initialized
INFO - 2021-08-09 08:10:19 --> Language Class Initialized
INFO - 2021-08-09 08:10:19 --> Language Class Initialized
INFO - 2021-08-09 08:10:19 --> Config Class Initialized
INFO - 2021-08-09 08:10:19 --> Loader Class Initialized
INFO - 2021-08-09 08:10:19 --> Helper loaded: url_helper
INFO - 2021-08-09 08:10:19 --> Helper loaded: file_helper
INFO - 2021-08-09 08:10:19 --> Helper loaded: form_helper
INFO - 2021-08-09 08:10:19 --> Helper loaded: my_helper
INFO - 2021-08-09 08:10:19 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:10:19 --> Controller Class Initialized
INFO - 2021-08-09 08:10:19 --> Final output sent to browser
DEBUG - 2021-08-09 08:10:19 --> Total execution time: 0.1805
INFO - 2021-08-09 08:10:48 --> Config Class Initialized
INFO - 2021-08-09 08:10:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:10:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:10:48 --> Utf8 Class Initialized
INFO - 2021-08-09 08:10:48 --> URI Class Initialized
INFO - 2021-08-09 08:10:48 --> Router Class Initialized
INFO - 2021-08-09 08:10:48 --> Output Class Initialized
INFO - 2021-08-09 08:10:48 --> Security Class Initialized
DEBUG - 2021-08-09 08:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:10:48 --> Input Class Initialized
INFO - 2021-08-09 08:10:48 --> Language Class Initialized
INFO - 2021-08-09 08:10:48 --> Language Class Initialized
INFO - 2021-08-09 08:10:48 --> Config Class Initialized
INFO - 2021-08-09 08:10:48 --> Loader Class Initialized
INFO - 2021-08-09 08:10:48 --> Helper loaded: url_helper
INFO - 2021-08-09 08:10:48 --> Helper loaded: file_helper
INFO - 2021-08-09 08:10:48 --> Helper loaded: form_helper
INFO - 2021-08-09 08:10:48 --> Helper loaded: my_helper
INFO - 2021-08-09 08:10:48 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:10:48 --> Controller Class Initialized
INFO - 2021-08-09 08:10:48 --> Helper loaded: cookie_helper
INFO - 2021-08-09 08:10:48 --> Config Class Initialized
INFO - 2021-08-09 08:10:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:10:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:10:48 --> Utf8 Class Initialized
INFO - 2021-08-09 08:10:48 --> URI Class Initialized
INFO - 2021-08-09 08:10:48 --> Router Class Initialized
INFO - 2021-08-09 08:10:48 --> Output Class Initialized
INFO - 2021-08-09 08:10:48 --> Security Class Initialized
DEBUG - 2021-08-09 08:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:10:48 --> Input Class Initialized
INFO - 2021-08-09 08:10:48 --> Language Class Initialized
INFO - 2021-08-09 08:10:48 --> Language Class Initialized
INFO - 2021-08-09 08:10:48 --> Config Class Initialized
INFO - 2021-08-09 08:10:48 --> Loader Class Initialized
INFO - 2021-08-09 08:10:48 --> Helper loaded: url_helper
INFO - 2021-08-09 08:10:48 --> Helper loaded: file_helper
INFO - 2021-08-09 08:10:48 --> Helper loaded: form_helper
INFO - 2021-08-09 08:10:48 --> Helper loaded: my_helper
INFO - 2021-08-09 08:10:48 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:10:48 --> Controller Class Initialized
DEBUG - 2021-08-09 08:10:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-09 08:10:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 08:10:48 --> Final output sent to browser
DEBUG - 2021-08-09 08:10:48 --> Total execution time: 0.0424
INFO - 2021-08-09 08:11:06 --> Config Class Initialized
INFO - 2021-08-09 08:11:06 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:11:06 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:11:06 --> Utf8 Class Initialized
INFO - 2021-08-09 08:11:06 --> URI Class Initialized
INFO - 2021-08-09 08:11:06 --> Router Class Initialized
INFO - 2021-08-09 08:11:06 --> Output Class Initialized
INFO - 2021-08-09 08:11:06 --> Security Class Initialized
DEBUG - 2021-08-09 08:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:11:06 --> Input Class Initialized
INFO - 2021-08-09 08:11:06 --> Language Class Initialized
INFO - 2021-08-09 08:11:06 --> Language Class Initialized
INFO - 2021-08-09 08:11:06 --> Config Class Initialized
INFO - 2021-08-09 08:11:06 --> Loader Class Initialized
INFO - 2021-08-09 08:11:06 --> Helper loaded: url_helper
INFO - 2021-08-09 08:11:06 --> Helper loaded: file_helper
INFO - 2021-08-09 08:11:06 --> Helper loaded: form_helper
INFO - 2021-08-09 08:11:06 --> Helper loaded: my_helper
INFO - 2021-08-09 08:11:06 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:11:06 --> Controller Class Initialized
INFO - 2021-08-09 08:11:06 --> Final output sent to browser
DEBUG - 2021-08-09 08:11:06 --> Total execution time: 0.0572
INFO - 2021-08-09 08:11:20 --> Config Class Initialized
INFO - 2021-08-09 08:11:20 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:11:20 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:11:20 --> Utf8 Class Initialized
INFO - 2021-08-09 08:11:20 --> URI Class Initialized
INFO - 2021-08-09 08:11:20 --> Router Class Initialized
INFO - 2021-08-09 08:11:20 --> Output Class Initialized
INFO - 2021-08-09 08:11:20 --> Security Class Initialized
DEBUG - 2021-08-09 08:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:11:20 --> Input Class Initialized
INFO - 2021-08-09 08:11:20 --> Language Class Initialized
INFO - 2021-08-09 08:11:20 --> Language Class Initialized
INFO - 2021-08-09 08:11:20 --> Config Class Initialized
INFO - 2021-08-09 08:11:20 --> Loader Class Initialized
INFO - 2021-08-09 08:11:20 --> Helper loaded: url_helper
INFO - 2021-08-09 08:11:20 --> Helper loaded: file_helper
INFO - 2021-08-09 08:11:20 --> Helper loaded: form_helper
INFO - 2021-08-09 08:11:20 --> Helper loaded: my_helper
INFO - 2021-08-09 08:11:20 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:11:20 --> Controller Class Initialized
INFO - 2021-08-09 08:11:20 --> Helper loaded: cookie_helper
INFO - 2021-08-09 08:11:20 --> Final output sent to browser
DEBUG - 2021-08-09 08:11:20 --> Total execution time: 0.0466
INFO - 2021-08-09 08:11:39 --> Config Class Initialized
INFO - 2021-08-09 08:11:39 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:11:39 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:11:39 --> Utf8 Class Initialized
INFO - 2021-08-09 08:11:39 --> URI Class Initialized
INFO - 2021-08-09 08:11:39 --> Router Class Initialized
INFO - 2021-08-09 08:11:39 --> Output Class Initialized
INFO - 2021-08-09 08:11:39 --> Security Class Initialized
DEBUG - 2021-08-09 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:11:39 --> Input Class Initialized
INFO - 2021-08-09 08:11:39 --> Language Class Initialized
INFO - 2021-08-09 08:11:39 --> Language Class Initialized
INFO - 2021-08-09 08:11:39 --> Config Class Initialized
INFO - 2021-08-09 08:11:39 --> Loader Class Initialized
INFO - 2021-08-09 08:11:39 --> Helper loaded: url_helper
INFO - 2021-08-09 08:11:39 --> Helper loaded: file_helper
INFO - 2021-08-09 08:11:39 --> Helper loaded: form_helper
INFO - 2021-08-09 08:11:39 --> Helper loaded: my_helper
INFO - 2021-08-09 08:11:39 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:11:39 --> Controller Class Initialized
DEBUG - 2021-08-09 08:11:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-09 08:11:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 08:11:40 --> Final output sent to browser
DEBUG - 2021-08-09 08:11:40 --> Total execution time: 0.7243
INFO - 2021-08-09 08:11:45 --> Config Class Initialized
INFO - 2021-08-09 08:11:45 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:11:45 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:11:45 --> Utf8 Class Initialized
INFO - 2021-08-09 08:11:45 --> URI Class Initialized
INFO - 2021-08-09 08:11:45 --> Router Class Initialized
INFO - 2021-08-09 08:11:45 --> Output Class Initialized
INFO - 2021-08-09 08:11:45 --> Security Class Initialized
DEBUG - 2021-08-09 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:11:45 --> Input Class Initialized
INFO - 2021-08-09 08:11:45 --> Language Class Initialized
INFO - 2021-08-09 08:11:45 --> Language Class Initialized
INFO - 2021-08-09 08:11:45 --> Config Class Initialized
INFO - 2021-08-09 08:11:45 --> Loader Class Initialized
INFO - 2021-08-09 08:11:45 --> Helper loaded: url_helper
INFO - 2021-08-09 08:11:45 --> Helper loaded: file_helper
INFO - 2021-08-09 08:11:45 --> Helper loaded: form_helper
INFO - 2021-08-09 08:11:45 --> Helper loaded: my_helper
INFO - 2021-08-09 08:11:45 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:11:45 --> Controller Class Initialized
DEBUG - 2021-08-09 08:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-09 08:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 08:11:45 --> Final output sent to browser
DEBUG - 2021-08-09 08:11:45 --> Total execution time: 0.0716
INFO - 2021-08-09 08:11:52 --> Config Class Initialized
INFO - 2021-08-09 08:11:52 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:11:52 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:11:52 --> Utf8 Class Initialized
INFO - 2021-08-09 08:11:52 --> URI Class Initialized
INFO - 2021-08-09 08:11:52 --> Router Class Initialized
INFO - 2021-08-09 08:11:52 --> Output Class Initialized
INFO - 2021-08-09 08:11:52 --> Security Class Initialized
DEBUG - 2021-08-09 08:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:11:52 --> Input Class Initialized
INFO - 2021-08-09 08:11:52 --> Language Class Initialized
INFO - 2021-08-09 08:11:52 --> Language Class Initialized
INFO - 2021-08-09 08:11:52 --> Config Class Initialized
INFO - 2021-08-09 08:11:52 --> Loader Class Initialized
INFO - 2021-08-09 08:11:52 --> Helper loaded: url_helper
INFO - 2021-08-09 08:11:52 --> Helper loaded: file_helper
INFO - 2021-08-09 08:11:52 --> Helper loaded: form_helper
INFO - 2021-08-09 08:11:52 --> Helper loaded: my_helper
INFO - 2021-08-09 08:11:52 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:11:52 --> Controller Class Initialized
DEBUG - 2021-08-09 08:11:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-08-09 08:11:52 --> Final output sent to browser
DEBUG - 2021-08-09 08:11:52 --> Total execution time: 0.1806
INFO - 2021-08-09 08:12:06 --> Config Class Initialized
INFO - 2021-08-09 08:12:06 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:12:06 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:12:06 --> Utf8 Class Initialized
INFO - 2021-08-09 08:12:06 --> URI Class Initialized
INFO - 2021-08-09 08:12:06 --> Router Class Initialized
INFO - 2021-08-09 08:12:06 --> Output Class Initialized
INFO - 2021-08-09 08:12:06 --> Security Class Initialized
DEBUG - 2021-08-09 08:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:12:06 --> Input Class Initialized
INFO - 2021-08-09 08:12:06 --> Language Class Initialized
INFO - 2021-08-09 08:12:06 --> Language Class Initialized
INFO - 2021-08-09 08:12:06 --> Config Class Initialized
INFO - 2021-08-09 08:12:06 --> Loader Class Initialized
INFO - 2021-08-09 08:12:06 --> Helper loaded: url_helper
INFO - 2021-08-09 08:12:06 --> Helper loaded: file_helper
INFO - 2021-08-09 08:12:06 --> Helper loaded: form_helper
INFO - 2021-08-09 08:12:06 --> Helper loaded: my_helper
INFO - 2021-08-09 08:12:06 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:12:06 --> Controller Class Initialized
DEBUG - 2021-08-09 08:12:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-08-09 08:12:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 08:12:06 --> Final output sent to browser
DEBUG - 2021-08-09 08:12:06 --> Total execution time: 0.0780
INFO - 2021-08-09 08:13:52 --> Config Class Initialized
INFO - 2021-08-09 08:13:52 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:13:52 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:13:52 --> Utf8 Class Initialized
INFO - 2021-08-09 08:13:52 --> URI Class Initialized
INFO - 2021-08-09 08:13:52 --> Router Class Initialized
INFO - 2021-08-09 08:13:52 --> Output Class Initialized
INFO - 2021-08-09 08:13:52 --> Security Class Initialized
DEBUG - 2021-08-09 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:13:52 --> Input Class Initialized
INFO - 2021-08-09 08:13:52 --> Language Class Initialized
INFO - 2021-08-09 08:13:52 --> Language Class Initialized
INFO - 2021-08-09 08:13:52 --> Config Class Initialized
INFO - 2021-08-09 08:13:52 --> Loader Class Initialized
INFO - 2021-08-09 08:13:52 --> Helper loaded: url_helper
INFO - 2021-08-09 08:13:52 --> Helper loaded: file_helper
INFO - 2021-08-09 08:13:52 --> Helper loaded: form_helper
INFO - 2021-08-09 08:13:52 --> Helper loaded: my_helper
INFO - 2021-08-09 08:13:52 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:13:52 --> Controller Class Initialized
INFO - 2021-08-09 08:13:52 --> Final output sent to browser
DEBUG - 2021-08-09 08:13:52 --> Total execution time: 0.2095
INFO - 2021-08-09 08:14:01 --> Config Class Initialized
INFO - 2021-08-09 08:14:01 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:14:01 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:14:01 --> Utf8 Class Initialized
INFO - 2021-08-09 08:14:01 --> URI Class Initialized
INFO - 2021-08-09 08:14:01 --> Router Class Initialized
INFO - 2021-08-09 08:14:01 --> Output Class Initialized
INFO - 2021-08-09 08:14:01 --> Security Class Initialized
DEBUG - 2021-08-09 08:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:14:01 --> Input Class Initialized
INFO - 2021-08-09 08:14:01 --> Language Class Initialized
INFO - 2021-08-09 08:14:01 --> Language Class Initialized
INFO - 2021-08-09 08:14:01 --> Config Class Initialized
INFO - 2021-08-09 08:14:01 --> Loader Class Initialized
INFO - 2021-08-09 08:14:01 --> Helper loaded: url_helper
INFO - 2021-08-09 08:14:01 --> Helper loaded: file_helper
INFO - 2021-08-09 08:14:01 --> Helper loaded: form_helper
INFO - 2021-08-09 08:14:01 --> Helper loaded: my_helper
INFO - 2021-08-09 08:14:01 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:14:01 --> Controller Class Initialized
INFO - 2021-08-09 08:14:01 --> Final output sent to browser
DEBUG - 2021-08-09 08:14:01 --> Total execution time: 0.1788
INFO - 2021-08-09 08:15:00 --> Config Class Initialized
INFO - 2021-08-09 08:15:00 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:15:00 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:15:00 --> Utf8 Class Initialized
INFO - 2021-08-09 08:15:00 --> URI Class Initialized
INFO - 2021-08-09 08:15:00 --> Router Class Initialized
INFO - 2021-08-09 08:15:00 --> Output Class Initialized
INFO - 2021-08-09 08:15:00 --> Security Class Initialized
DEBUG - 2021-08-09 08:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:15:00 --> Input Class Initialized
INFO - 2021-08-09 08:15:00 --> Language Class Initialized
INFO - 2021-08-09 08:15:00 --> Language Class Initialized
INFO - 2021-08-09 08:15:00 --> Config Class Initialized
INFO - 2021-08-09 08:15:00 --> Loader Class Initialized
INFO - 2021-08-09 08:15:00 --> Helper loaded: url_helper
INFO - 2021-08-09 08:15:00 --> Helper loaded: file_helper
INFO - 2021-08-09 08:15:00 --> Helper loaded: form_helper
INFO - 2021-08-09 08:15:00 --> Helper loaded: my_helper
INFO - 2021-08-09 08:15:00 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:15:00 --> Controller Class Initialized
INFO - 2021-08-09 08:15:00 --> Final output sent to browser
DEBUG - 2021-08-09 08:15:00 --> Total execution time: 0.1653
INFO - 2021-08-09 08:17:02 --> Config Class Initialized
INFO - 2021-08-09 08:17:02 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:17:02 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:17:02 --> Utf8 Class Initialized
INFO - 2021-08-09 08:17:02 --> URI Class Initialized
INFO - 2021-08-09 08:17:02 --> Router Class Initialized
INFO - 2021-08-09 08:17:02 --> Output Class Initialized
INFO - 2021-08-09 08:17:02 --> Security Class Initialized
DEBUG - 2021-08-09 08:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:17:02 --> Input Class Initialized
INFO - 2021-08-09 08:17:02 --> Language Class Initialized
INFO - 2021-08-09 08:17:02 --> Language Class Initialized
INFO - 2021-08-09 08:17:02 --> Config Class Initialized
INFO - 2021-08-09 08:17:02 --> Loader Class Initialized
INFO - 2021-08-09 08:17:02 --> Helper loaded: url_helper
INFO - 2021-08-09 08:17:02 --> Helper loaded: file_helper
INFO - 2021-08-09 08:17:02 --> Helper loaded: form_helper
INFO - 2021-08-09 08:17:02 --> Helper loaded: my_helper
INFO - 2021-08-09 08:17:02 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:17:02 --> Controller Class Initialized
INFO - 2021-08-09 08:17:02 --> Final output sent to browser
DEBUG - 2021-08-09 08:17:02 --> Total execution time: 0.1777
INFO - 2021-08-09 08:17:05 --> Config Class Initialized
INFO - 2021-08-09 08:17:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:17:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:17:05 --> Utf8 Class Initialized
INFO - 2021-08-09 08:17:05 --> URI Class Initialized
INFO - 2021-08-09 08:17:05 --> Router Class Initialized
INFO - 2021-08-09 08:17:05 --> Output Class Initialized
INFO - 2021-08-09 08:17:05 --> Security Class Initialized
DEBUG - 2021-08-09 08:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:17:05 --> Input Class Initialized
INFO - 2021-08-09 08:17:05 --> Language Class Initialized
INFO - 2021-08-09 08:17:05 --> Language Class Initialized
INFO - 2021-08-09 08:17:05 --> Config Class Initialized
INFO - 2021-08-09 08:17:05 --> Loader Class Initialized
INFO - 2021-08-09 08:17:05 --> Helper loaded: url_helper
INFO - 2021-08-09 08:17:05 --> Helper loaded: file_helper
INFO - 2021-08-09 08:17:05 --> Helper loaded: form_helper
INFO - 2021-08-09 08:17:05 --> Helper loaded: my_helper
INFO - 2021-08-09 08:17:05 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:17:06 --> Controller Class Initialized
INFO - 2021-08-09 08:17:06 --> Final output sent to browser
DEBUG - 2021-08-09 08:17:06 --> Total execution time: 0.1638
INFO - 2021-08-09 08:18:33 --> Config Class Initialized
INFO - 2021-08-09 08:18:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:18:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:18:33 --> Utf8 Class Initialized
INFO - 2021-08-09 08:18:33 --> URI Class Initialized
INFO - 2021-08-09 08:18:33 --> Router Class Initialized
INFO - 2021-08-09 08:18:33 --> Output Class Initialized
INFO - 2021-08-09 08:18:33 --> Security Class Initialized
DEBUG - 2021-08-09 08:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:18:33 --> Input Class Initialized
INFO - 2021-08-09 08:18:33 --> Language Class Initialized
INFO - 2021-08-09 08:18:33 --> Language Class Initialized
INFO - 2021-08-09 08:18:33 --> Config Class Initialized
INFO - 2021-08-09 08:18:33 --> Loader Class Initialized
INFO - 2021-08-09 08:18:33 --> Helper loaded: url_helper
INFO - 2021-08-09 08:18:33 --> Helper loaded: file_helper
INFO - 2021-08-09 08:18:33 --> Helper loaded: form_helper
INFO - 2021-08-09 08:18:33 --> Helper loaded: my_helper
INFO - 2021-08-09 08:18:33 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:18:33 --> Controller Class Initialized
INFO - 2021-08-09 08:18:33 --> Final output sent to browser
DEBUG - 2021-08-09 08:18:33 --> Total execution time: 0.1730
INFO - 2021-08-09 08:18:36 --> Config Class Initialized
INFO - 2021-08-09 08:18:36 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:18:36 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:18:36 --> Utf8 Class Initialized
INFO - 2021-08-09 08:18:36 --> URI Class Initialized
INFO - 2021-08-09 08:18:36 --> Router Class Initialized
INFO - 2021-08-09 08:18:36 --> Output Class Initialized
INFO - 2021-08-09 08:18:36 --> Security Class Initialized
DEBUG - 2021-08-09 08:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:18:36 --> Input Class Initialized
INFO - 2021-08-09 08:18:36 --> Language Class Initialized
INFO - 2021-08-09 08:18:36 --> Language Class Initialized
INFO - 2021-08-09 08:18:36 --> Config Class Initialized
INFO - 2021-08-09 08:18:36 --> Loader Class Initialized
INFO - 2021-08-09 08:18:36 --> Helper loaded: url_helper
INFO - 2021-08-09 08:18:36 --> Helper loaded: file_helper
INFO - 2021-08-09 08:18:36 --> Helper loaded: form_helper
INFO - 2021-08-09 08:18:36 --> Helper loaded: my_helper
INFO - 2021-08-09 08:18:36 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:18:36 --> Controller Class Initialized
DEBUG - 2021-08-09 08:18:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-09 08:18:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 08:18:36 --> Final output sent to browser
DEBUG - 2021-08-09 08:18:36 --> Total execution time: 0.0510
INFO - 2021-08-09 08:18:40 --> Config Class Initialized
INFO - 2021-08-09 08:18:40 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:18:40 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:18:40 --> Utf8 Class Initialized
INFO - 2021-08-09 08:18:40 --> URI Class Initialized
INFO - 2021-08-09 08:18:40 --> Router Class Initialized
INFO - 2021-08-09 08:18:40 --> Output Class Initialized
INFO - 2021-08-09 08:18:40 --> Security Class Initialized
DEBUG - 2021-08-09 08:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:18:40 --> Input Class Initialized
INFO - 2021-08-09 08:18:40 --> Language Class Initialized
INFO - 2021-08-09 08:18:40 --> Language Class Initialized
INFO - 2021-08-09 08:18:40 --> Config Class Initialized
INFO - 2021-08-09 08:18:40 --> Loader Class Initialized
INFO - 2021-08-09 08:18:40 --> Helper loaded: url_helper
INFO - 2021-08-09 08:18:40 --> Helper loaded: file_helper
INFO - 2021-08-09 08:18:40 --> Helper loaded: form_helper
INFO - 2021-08-09 08:18:40 --> Helper loaded: my_helper
INFO - 2021-08-09 08:18:40 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:18:40 --> Controller Class Initialized
DEBUG - 2021-08-09 08:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-08-09 08:18:40 --> Final output sent to browser
DEBUG - 2021-08-09 08:18:40 --> Total execution time: 0.1790
INFO - 2021-08-09 08:19:17 --> Config Class Initialized
INFO - 2021-08-09 08:19:17 --> Hooks Class Initialized
DEBUG - 2021-08-09 08:19:17 --> UTF-8 Support Enabled
INFO - 2021-08-09 08:19:17 --> Utf8 Class Initialized
INFO - 2021-08-09 08:19:17 --> URI Class Initialized
INFO - 2021-08-09 08:19:17 --> Router Class Initialized
INFO - 2021-08-09 08:19:17 --> Output Class Initialized
INFO - 2021-08-09 08:19:17 --> Security Class Initialized
DEBUG - 2021-08-09 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 08:19:17 --> Input Class Initialized
INFO - 2021-08-09 08:19:17 --> Language Class Initialized
INFO - 2021-08-09 08:19:17 --> Language Class Initialized
INFO - 2021-08-09 08:19:17 --> Config Class Initialized
INFO - 2021-08-09 08:19:17 --> Loader Class Initialized
INFO - 2021-08-09 08:19:17 --> Helper loaded: url_helper
INFO - 2021-08-09 08:19:17 --> Helper loaded: file_helper
INFO - 2021-08-09 08:19:17 --> Helper loaded: form_helper
INFO - 2021-08-09 08:19:17 --> Helper loaded: my_helper
INFO - 2021-08-09 08:19:17 --> Database Driver Class Initialized
DEBUG - 2021-08-09 08:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 08:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 08:19:17 --> Controller Class Initialized
DEBUG - 2021-08-09 08:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-08-09 08:19:17 --> Final output sent to browser
DEBUG - 2021-08-09 08:19:17 --> Total execution time: 0.1319
INFO - 2021-08-09 10:17:59 --> Config Class Initialized
INFO - 2021-08-09 10:17:59 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:17:59 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:17:59 --> Utf8 Class Initialized
INFO - 2021-08-09 10:17:59 --> URI Class Initialized
INFO - 2021-08-09 10:17:59 --> Router Class Initialized
INFO - 2021-08-09 10:17:59 --> Output Class Initialized
INFO - 2021-08-09 10:17:59 --> Security Class Initialized
DEBUG - 2021-08-09 10:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:17:59 --> Input Class Initialized
INFO - 2021-08-09 10:17:59 --> Language Class Initialized
INFO - 2021-08-09 10:17:59 --> Language Class Initialized
INFO - 2021-08-09 10:17:59 --> Config Class Initialized
INFO - 2021-08-09 10:17:59 --> Loader Class Initialized
INFO - 2021-08-09 10:17:59 --> Helper loaded: url_helper
INFO - 2021-08-09 10:17:59 --> Helper loaded: file_helper
INFO - 2021-08-09 10:17:59 --> Helper loaded: form_helper
INFO - 2021-08-09 10:17:59 --> Helper loaded: my_helper
INFO - 2021-08-09 10:17:59 --> Database Driver Class Initialized
DEBUG - 2021-08-09 10:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:17:59 --> Controller Class Initialized
DEBUG - 2021-08-09 10:18:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-09 10:18:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 10:18:00 --> Final output sent to browser
DEBUG - 2021-08-09 10:18:00 --> Total execution time: 0.6626
INFO - 2021-08-09 10:18:00 --> Config Class Initialized
INFO - 2021-08-09 10:18:00 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:18:00 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:18:00 --> Utf8 Class Initialized
INFO - 2021-08-09 10:18:00 --> URI Class Initialized
INFO - 2021-08-09 10:18:00 --> Router Class Initialized
INFO - 2021-08-09 10:18:00 --> Output Class Initialized
INFO - 2021-08-09 10:18:00 --> Security Class Initialized
DEBUG - 2021-08-09 10:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:18:00 --> Input Class Initialized
INFO - 2021-08-09 10:18:00 --> Language Class Initialized
INFO - 2021-08-09 10:18:00 --> Language Class Initialized
INFO - 2021-08-09 10:18:00 --> Config Class Initialized
INFO - 2021-08-09 10:18:00 --> Loader Class Initialized
INFO - 2021-08-09 10:18:00 --> Helper loaded: url_helper
INFO - 2021-08-09 10:18:00 --> Helper loaded: file_helper
INFO - 2021-08-09 10:18:00 --> Helper loaded: form_helper
INFO - 2021-08-09 10:18:00 --> Helper loaded: my_helper
INFO - 2021-08-09 10:18:00 --> Database Driver Class Initialized
DEBUG - 2021-08-09 10:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:18:00 --> Controller Class Initialized
DEBUG - 2021-08-09 10:18:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-09 10:18:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 10:18:00 --> Final output sent to browser
DEBUG - 2021-08-09 10:18:00 --> Total execution time: 0.0425
INFO - 2021-08-09 10:18:05 --> Config Class Initialized
INFO - 2021-08-09 10:18:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:18:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:18:05 --> Utf8 Class Initialized
INFO - 2021-08-09 10:18:05 --> URI Class Initialized
INFO - 2021-08-09 10:18:05 --> Router Class Initialized
INFO - 2021-08-09 10:18:05 --> Output Class Initialized
INFO - 2021-08-09 10:18:05 --> Security Class Initialized
DEBUG - 2021-08-09 10:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:18:05 --> Input Class Initialized
INFO - 2021-08-09 10:18:05 --> Language Class Initialized
INFO - 2021-08-09 10:18:05 --> Language Class Initialized
INFO - 2021-08-09 10:18:05 --> Config Class Initialized
INFO - 2021-08-09 10:18:05 --> Loader Class Initialized
INFO - 2021-08-09 10:18:05 --> Helper loaded: url_helper
INFO - 2021-08-09 10:18:05 --> Helper loaded: file_helper
INFO - 2021-08-09 10:18:05 --> Helper loaded: form_helper
INFO - 2021-08-09 10:18:05 --> Helper loaded: my_helper
INFO - 2021-08-09 10:18:05 --> Database Driver Class Initialized
DEBUG - 2021-08-09 10:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:18:05 --> Controller Class Initialized
INFO - 2021-08-09 10:18:05 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:18:05 --> Final output sent to browser
DEBUG - 2021-08-09 10:18:05 --> Total execution time: 0.0912
INFO - 2021-08-09 10:18:06 --> Config Class Initialized
INFO - 2021-08-09 10:18:06 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:18:06 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:18:06 --> Utf8 Class Initialized
INFO - 2021-08-09 10:18:06 --> URI Class Initialized
INFO - 2021-08-09 10:18:06 --> Router Class Initialized
INFO - 2021-08-09 10:18:06 --> Output Class Initialized
INFO - 2021-08-09 10:18:06 --> Security Class Initialized
DEBUG - 2021-08-09 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:18:06 --> Input Class Initialized
INFO - 2021-08-09 10:18:06 --> Language Class Initialized
INFO - 2021-08-09 10:18:06 --> Language Class Initialized
INFO - 2021-08-09 10:18:06 --> Config Class Initialized
INFO - 2021-08-09 10:18:06 --> Loader Class Initialized
INFO - 2021-08-09 10:18:06 --> Helper loaded: url_helper
INFO - 2021-08-09 10:18:06 --> Helper loaded: file_helper
INFO - 2021-08-09 10:18:06 --> Helper loaded: form_helper
INFO - 2021-08-09 10:18:06 --> Helper loaded: my_helper
INFO - 2021-08-09 10:18:06 --> Database Driver Class Initialized
DEBUG - 2021-08-09 10:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:18:06 --> Controller Class Initialized
DEBUG - 2021-08-09 10:18:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-09 10:18:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 10:18:07 --> Final output sent to browser
DEBUG - 2021-08-09 10:18:07 --> Total execution time: 0.8437
INFO - 2021-08-09 10:18:11 --> Config Class Initialized
INFO - 2021-08-09 10:18:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:18:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:18:11 --> Utf8 Class Initialized
INFO - 2021-08-09 10:18:11 --> URI Class Initialized
INFO - 2021-08-09 10:18:11 --> Router Class Initialized
INFO - 2021-08-09 10:18:11 --> Output Class Initialized
INFO - 2021-08-09 10:18:11 --> Security Class Initialized
DEBUG - 2021-08-09 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:18:11 --> Input Class Initialized
INFO - 2021-08-09 10:18:11 --> Language Class Initialized
INFO - 2021-08-09 10:18:11 --> Language Class Initialized
INFO - 2021-08-09 10:18:11 --> Config Class Initialized
INFO - 2021-08-09 10:18:11 --> Loader Class Initialized
INFO - 2021-08-09 10:18:11 --> Helper loaded: url_helper
INFO - 2021-08-09 10:18:11 --> Helper loaded: file_helper
INFO - 2021-08-09 10:18:11 --> Helper loaded: form_helper
INFO - 2021-08-09 10:18:11 --> Helper loaded: my_helper
INFO - 2021-08-09 10:18:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 10:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:18:11 --> Controller Class Initialized
DEBUG - 2021-08-09 10:18:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-09 10:18:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 10:18:11 --> Final output sent to browser
DEBUG - 2021-08-09 10:18:11 --> Total execution time: 0.1001
INFO - 2021-08-09 10:18:13 --> Config Class Initialized
INFO - 2021-08-09 10:18:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:18:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:18:13 --> Utf8 Class Initialized
INFO - 2021-08-09 10:18:13 --> URI Class Initialized
INFO - 2021-08-09 10:18:13 --> Router Class Initialized
INFO - 2021-08-09 10:18:13 --> Output Class Initialized
INFO - 2021-08-09 10:18:13 --> Security Class Initialized
DEBUG - 2021-08-09 10:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:18:13 --> Input Class Initialized
INFO - 2021-08-09 10:18:13 --> Language Class Initialized
INFO - 2021-08-09 10:18:13 --> Language Class Initialized
INFO - 2021-08-09 10:18:13 --> Config Class Initialized
INFO - 2021-08-09 10:18:13 --> Loader Class Initialized
INFO - 2021-08-09 10:18:13 --> Helper loaded: url_helper
INFO - 2021-08-09 10:18:13 --> Helper loaded: file_helper
INFO - 2021-08-09 10:18:13 --> Helper loaded: form_helper
INFO - 2021-08-09 10:18:13 --> Helper loaded: my_helper
INFO - 2021-08-09 10:18:13 --> Database Driver Class Initialized
DEBUG - 2021-08-09 10:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:18:13 --> Controller Class Initialized
DEBUG - 2021-08-09 10:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xi.php
INFO - 2021-08-09 10:18:13 --> Final output sent to browser
DEBUG - 2021-08-09 10:18:13 --> Total execution time: 0.2589
INFO - 2021-08-09 03:41:55 --> Config Class Initialized
INFO - 2021-08-09 03:41:55 --> Hooks Class Initialized
DEBUG - 2021-08-09 03:41:55 --> UTF-8 Support Enabled
INFO - 2021-08-09 03:41:55 --> Utf8 Class Initialized
INFO - 2021-08-09 03:41:55 --> URI Class Initialized
INFO - 2021-08-09 03:41:55 --> Router Class Initialized
INFO - 2021-08-09 03:41:55 --> Output Class Initialized
INFO - 2021-08-09 03:41:55 --> Security Class Initialized
DEBUG - 2021-08-09 03:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 03:41:55 --> Input Class Initialized
INFO - 2021-08-09 03:41:55 --> Language Class Initialized
INFO - 2021-08-09 03:41:55 --> Language Class Initialized
INFO - 2021-08-09 03:41:55 --> Config Class Initialized
INFO - 2021-08-09 03:41:55 --> Loader Class Initialized
INFO - 2021-08-09 03:41:55 --> Helper loaded: url_helper
INFO - 2021-08-09 03:41:55 --> Helper loaded: file_helper
INFO - 2021-08-09 03:41:55 --> Helper loaded: form_helper
INFO - 2021-08-09 03:41:55 --> Helper loaded: my_helper
INFO - 2021-08-09 03:41:55 --> Database Driver Class Initialized
DEBUG - 2021-08-09 03:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 03:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 03:41:55 --> Controller Class Initialized
DEBUG - 2021-08-09 03:41:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 03:41:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 03:41:55 --> Final output sent to browser
DEBUG - 2021-08-09 03:41:55 --> Total execution time: 0.0626
INFO - 2021-08-09 03:41:56 --> Config Class Initialized
INFO - 2021-08-09 03:41:56 --> Hooks Class Initialized
DEBUG - 2021-08-09 03:41:56 --> UTF-8 Support Enabled
INFO - 2021-08-09 03:41:56 --> Utf8 Class Initialized
INFO - 2021-08-09 03:41:56 --> URI Class Initialized
INFO - 2021-08-09 03:41:56 --> Router Class Initialized
INFO - 2021-08-09 03:41:56 --> Output Class Initialized
INFO - 2021-08-09 03:41:56 --> Security Class Initialized
DEBUG - 2021-08-09 03:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 03:41:56 --> Input Class Initialized
INFO - 2021-08-09 03:41:56 --> Language Class Initialized
INFO - 2021-08-09 03:41:56 --> Language Class Initialized
INFO - 2021-08-09 03:41:56 --> Config Class Initialized
INFO - 2021-08-09 03:41:56 --> Loader Class Initialized
INFO - 2021-08-09 03:41:56 --> Helper loaded: url_helper
INFO - 2021-08-09 03:41:56 --> Helper loaded: file_helper
INFO - 2021-08-09 03:41:56 --> Helper loaded: form_helper
INFO - 2021-08-09 03:41:56 --> Helper loaded: my_helper
INFO - 2021-08-09 03:41:56 --> Database Driver Class Initialized
DEBUG - 2021-08-09 03:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 03:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 03:41:56 --> Controller Class Initialized
DEBUG - 2021-08-09 03:41:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 03:41:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 03:41:56 --> Final output sent to browser
DEBUG - 2021-08-09 03:41:56 --> Total execution time: 0.0643
INFO - 2021-08-09 03:53:15 --> Config Class Initialized
INFO - 2021-08-09 03:53:15 --> Hooks Class Initialized
DEBUG - 2021-08-09 03:53:15 --> UTF-8 Support Enabled
INFO - 2021-08-09 03:53:15 --> Utf8 Class Initialized
INFO - 2021-08-09 03:53:15 --> URI Class Initialized
INFO - 2021-08-09 03:53:15 --> Router Class Initialized
INFO - 2021-08-09 03:53:15 --> Output Class Initialized
INFO - 2021-08-09 03:53:15 --> Security Class Initialized
DEBUG - 2021-08-09 03:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 03:53:15 --> Input Class Initialized
INFO - 2021-08-09 03:53:15 --> Language Class Initialized
INFO - 2021-08-09 03:53:15 --> Language Class Initialized
INFO - 2021-08-09 03:53:15 --> Config Class Initialized
INFO - 2021-08-09 03:53:15 --> Loader Class Initialized
INFO - 2021-08-09 03:53:15 --> Helper loaded: url_helper
INFO - 2021-08-09 03:53:15 --> Helper loaded: file_helper
INFO - 2021-08-09 03:53:15 --> Helper loaded: form_helper
INFO - 2021-08-09 03:53:15 --> Helper loaded: my_helper
INFO - 2021-08-09 03:53:15 --> Database Driver Class Initialized
DEBUG - 2021-08-09 03:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 03:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 03:53:15 --> Controller Class Initialized
INFO - 2021-08-09 03:53:15 --> Config Class Initialized
INFO - 2021-08-09 03:53:15 --> Hooks Class Initialized
DEBUG - 2021-08-09 03:53:15 --> UTF-8 Support Enabled
INFO - 2021-08-09 03:53:15 --> Utf8 Class Initialized
INFO - 2021-08-09 03:53:15 --> URI Class Initialized
INFO - 2021-08-09 03:53:15 --> Router Class Initialized
INFO - 2021-08-09 03:53:15 --> Output Class Initialized
INFO - 2021-08-09 03:53:15 --> Security Class Initialized
DEBUG - 2021-08-09 03:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 03:53:15 --> Input Class Initialized
INFO - 2021-08-09 03:53:15 --> Language Class Initialized
INFO - 2021-08-09 03:53:15 --> Language Class Initialized
INFO - 2021-08-09 03:53:15 --> Config Class Initialized
INFO - 2021-08-09 03:53:15 --> Loader Class Initialized
INFO - 2021-08-09 03:53:15 --> Helper loaded: url_helper
INFO - 2021-08-09 03:53:15 --> Helper loaded: file_helper
INFO - 2021-08-09 03:53:15 --> Helper loaded: form_helper
INFO - 2021-08-09 03:53:15 --> Helper loaded: my_helper
INFO - 2021-08-09 03:53:15 --> Database Driver Class Initialized
DEBUG - 2021-08-09 03:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 03:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 03:53:15 --> Controller Class Initialized
DEBUG - 2021-08-09 03:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 03:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 03:53:15 --> Final output sent to browser
DEBUG - 2021-08-09 03:53:15 --> Total execution time: 0.0687
INFO - 2021-08-09 03:55:02 --> Config Class Initialized
INFO - 2021-08-09 03:55:02 --> Hooks Class Initialized
DEBUG - 2021-08-09 03:55:02 --> UTF-8 Support Enabled
INFO - 2021-08-09 03:55:02 --> Utf8 Class Initialized
INFO - 2021-08-09 03:55:02 --> URI Class Initialized
INFO - 2021-08-09 03:55:02 --> Router Class Initialized
INFO - 2021-08-09 03:55:02 --> Output Class Initialized
INFO - 2021-08-09 03:55:02 --> Security Class Initialized
DEBUG - 2021-08-09 03:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 03:55:02 --> Input Class Initialized
INFO - 2021-08-09 03:55:02 --> Language Class Initialized
INFO - 2021-08-09 03:55:02 --> Language Class Initialized
INFO - 2021-08-09 03:55:02 --> Config Class Initialized
INFO - 2021-08-09 03:55:02 --> Loader Class Initialized
INFO - 2021-08-09 03:55:02 --> Helper loaded: url_helper
INFO - 2021-08-09 03:55:02 --> Helper loaded: file_helper
INFO - 2021-08-09 03:55:02 --> Helper loaded: form_helper
INFO - 2021-08-09 03:55:02 --> Helper loaded: my_helper
INFO - 2021-08-09 03:55:02 --> Database Driver Class Initialized
DEBUG - 2021-08-09 03:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 03:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 03:55:02 --> Controller Class Initialized
DEBUG - 2021-08-09 03:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 03:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 03:55:02 --> Final output sent to browser
DEBUG - 2021-08-09 03:55:02 --> Total execution time: 0.0882
INFO - 2021-08-09 03:55:16 --> Config Class Initialized
INFO - 2021-08-09 03:55:16 --> Hooks Class Initialized
DEBUG - 2021-08-09 03:55:16 --> UTF-8 Support Enabled
INFO - 2021-08-09 03:55:16 --> Utf8 Class Initialized
INFO - 2021-08-09 03:55:16 --> URI Class Initialized
INFO - 2021-08-09 03:55:16 --> Router Class Initialized
INFO - 2021-08-09 03:55:16 --> Output Class Initialized
INFO - 2021-08-09 03:55:16 --> Security Class Initialized
DEBUG - 2021-08-09 03:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 03:55:16 --> Input Class Initialized
INFO - 2021-08-09 03:55:16 --> Language Class Initialized
INFO - 2021-08-09 03:55:16 --> Language Class Initialized
INFO - 2021-08-09 03:55:16 --> Config Class Initialized
INFO - 2021-08-09 03:55:16 --> Loader Class Initialized
INFO - 2021-08-09 03:55:16 --> Helper loaded: url_helper
INFO - 2021-08-09 03:55:16 --> Helper loaded: file_helper
INFO - 2021-08-09 03:55:16 --> Helper loaded: form_helper
INFO - 2021-08-09 03:55:16 --> Helper loaded: my_helper
INFO - 2021-08-09 03:55:16 --> Database Driver Class Initialized
DEBUG - 2021-08-09 03:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 03:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 03:55:16 --> Controller Class Initialized
INFO - 2021-08-09 03:55:16 --> Config Class Initialized
INFO - 2021-08-09 03:55:16 --> Hooks Class Initialized
DEBUG - 2021-08-09 03:55:16 --> UTF-8 Support Enabled
INFO - 2021-08-09 03:55:16 --> Utf8 Class Initialized
INFO - 2021-08-09 03:55:16 --> URI Class Initialized
INFO - 2021-08-09 03:55:16 --> Router Class Initialized
INFO - 2021-08-09 03:55:16 --> Output Class Initialized
INFO - 2021-08-09 03:55:16 --> Security Class Initialized
DEBUG - 2021-08-09 03:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 03:55:16 --> Input Class Initialized
INFO - 2021-08-09 03:55:16 --> Language Class Initialized
INFO - 2021-08-09 03:55:16 --> Language Class Initialized
INFO - 2021-08-09 03:55:16 --> Config Class Initialized
INFO - 2021-08-09 03:55:16 --> Loader Class Initialized
INFO - 2021-08-09 03:55:16 --> Helper loaded: url_helper
INFO - 2021-08-09 03:55:16 --> Helper loaded: file_helper
INFO - 2021-08-09 03:55:16 --> Helper loaded: form_helper
INFO - 2021-08-09 03:55:16 --> Helper loaded: my_helper
INFO - 2021-08-09 03:55:16 --> Database Driver Class Initialized
DEBUG - 2021-08-09 03:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 03:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 03:55:16 --> Controller Class Initialized
DEBUG - 2021-08-09 03:55:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 03:55:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 03:55:16 --> Final output sent to browser
DEBUG - 2021-08-09 03:55:16 --> Total execution time: 0.0698
INFO - 2021-08-09 03:55:57 --> Config Class Initialized
INFO - 2021-08-09 03:55:57 --> Hooks Class Initialized
DEBUG - 2021-08-09 03:55:57 --> UTF-8 Support Enabled
INFO - 2021-08-09 03:55:57 --> Utf8 Class Initialized
INFO - 2021-08-09 03:55:57 --> URI Class Initialized
INFO - 2021-08-09 03:55:57 --> Router Class Initialized
INFO - 2021-08-09 03:55:57 --> Output Class Initialized
INFO - 2021-08-09 03:55:57 --> Security Class Initialized
DEBUG - 2021-08-09 03:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 03:55:57 --> Input Class Initialized
INFO - 2021-08-09 03:55:57 --> Language Class Initialized
INFO - 2021-08-09 03:55:57 --> Language Class Initialized
INFO - 2021-08-09 03:55:57 --> Config Class Initialized
INFO - 2021-08-09 03:55:57 --> Loader Class Initialized
INFO - 2021-08-09 03:55:57 --> Helper loaded: url_helper
INFO - 2021-08-09 03:55:57 --> Helper loaded: file_helper
INFO - 2021-08-09 03:55:57 --> Helper loaded: form_helper
INFO - 2021-08-09 03:55:57 --> Helper loaded: my_helper
INFO - 2021-08-09 03:55:57 --> Database Driver Class Initialized
DEBUG - 2021-08-09 03:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 03:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 03:55:57 --> Controller Class Initialized
DEBUG - 2021-08-09 03:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 03:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 03:55:57 --> Final output sent to browser
DEBUG - 2021-08-09 03:55:57 --> Total execution time: 0.0782
INFO - 2021-08-09 04:14:33 --> Config Class Initialized
INFO - 2021-08-09 04:14:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:14:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:14:33 --> Utf8 Class Initialized
INFO - 2021-08-09 04:14:33 --> URI Class Initialized
INFO - 2021-08-09 04:14:33 --> Router Class Initialized
INFO - 2021-08-09 04:14:33 --> Output Class Initialized
INFO - 2021-08-09 04:14:33 --> Security Class Initialized
DEBUG - 2021-08-09 04:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:14:33 --> Input Class Initialized
INFO - 2021-08-09 04:14:33 --> Language Class Initialized
INFO - 2021-08-09 04:14:33 --> Language Class Initialized
INFO - 2021-08-09 04:14:33 --> Config Class Initialized
INFO - 2021-08-09 04:14:33 --> Loader Class Initialized
INFO - 2021-08-09 04:14:33 --> Helper loaded: url_helper
INFO - 2021-08-09 04:14:33 --> Helper loaded: file_helper
INFO - 2021-08-09 04:14:33 --> Helper loaded: form_helper
INFO - 2021-08-09 04:14:33 --> Helper loaded: my_helper
INFO - 2021-08-09 04:14:33 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:14:33 --> Controller Class Initialized
INFO - 2021-08-09 04:14:33 --> Config Class Initialized
INFO - 2021-08-09 04:14:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:14:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:14:33 --> Utf8 Class Initialized
INFO - 2021-08-09 04:14:33 --> URI Class Initialized
INFO - 2021-08-09 04:14:33 --> Router Class Initialized
INFO - 2021-08-09 04:14:33 --> Output Class Initialized
INFO - 2021-08-09 04:14:33 --> Security Class Initialized
DEBUG - 2021-08-09 04:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:14:33 --> Input Class Initialized
INFO - 2021-08-09 04:14:33 --> Language Class Initialized
INFO - 2021-08-09 04:14:33 --> Language Class Initialized
INFO - 2021-08-09 04:14:33 --> Config Class Initialized
INFO - 2021-08-09 04:14:33 --> Loader Class Initialized
INFO - 2021-08-09 04:14:33 --> Helper loaded: url_helper
INFO - 2021-08-09 04:14:33 --> Helper loaded: file_helper
INFO - 2021-08-09 04:14:33 --> Helper loaded: form_helper
INFO - 2021-08-09 04:14:33 --> Helper loaded: my_helper
INFO - 2021-08-09 04:14:33 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:14:33 --> Controller Class Initialized
DEBUG - 2021-08-09 04:14:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 04:14:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:14:33 --> Final output sent to browser
DEBUG - 2021-08-09 04:14:33 --> Total execution time: 0.0665
INFO - 2021-08-09 04:15:20 --> Config Class Initialized
INFO - 2021-08-09 04:15:20 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:20 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:20 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:20 --> URI Class Initialized
INFO - 2021-08-09 04:15:20 --> Router Class Initialized
INFO - 2021-08-09 04:15:20 --> Output Class Initialized
INFO - 2021-08-09 04:15:20 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:20 --> Input Class Initialized
INFO - 2021-08-09 04:15:20 --> Language Class Initialized
INFO - 2021-08-09 04:15:20 --> Language Class Initialized
INFO - 2021-08-09 04:15:20 --> Config Class Initialized
INFO - 2021-08-09 04:15:21 --> Loader Class Initialized
INFO - 2021-08-09 04:15:21 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:21 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:21 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:21 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:21 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:21 --> Controller Class Initialized
ERROR - 2021-08-09 04:15:21 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '63' AND tasm = '20212'
INFO - 2021-08-09 04:15:21 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 04:15:23 --> Config Class Initialized
INFO - 2021-08-09 04:15:23 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:23 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:23 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:23 --> URI Class Initialized
INFO - 2021-08-09 04:15:23 --> Router Class Initialized
INFO - 2021-08-09 04:15:23 --> Output Class Initialized
INFO - 2021-08-09 04:15:23 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:23 --> Input Class Initialized
INFO - 2021-08-09 04:15:23 --> Language Class Initialized
INFO - 2021-08-09 04:15:23 --> Language Class Initialized
INFO - 2021-08-09 04:15:23 --> Config Class Initialized
INFO - 2021-08-09 04:15:23 --> Loader Class Initialized
INFO - 2021-08-09 04:15:23 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:23 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:23 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:23 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:23 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:23 --> Controller Class Initialized
ERROR - 2021-08-09 04:15:23 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '62' AND tasm = '20212'
INFO - 2021-08-09 04:15:23 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 04:15:25 --> Config Class Initialized
INFO - 2021-08-09 04:15:25 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:25 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:25 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:25 --> URI Class Initialized
INFO - 2021-08-09 04:15:25 --> Router Class Initialized
INFO - 2021-08-09 04:15:25 --> Output Class Initialized
INFO - 2021-08-09 04:15:25 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:25 --> Input Class Initialized
INFO - 2021-08-09 04:15:25 --> Language Class Initialized
INFO - 2021-08-09 04:15:25 --> Language Class Initialized
INFO - 2021-08-09 04:15:25 --> Config Class Initialized
INFO - 2021-08-09 04:15:25 --> Loader Class Initialized
INFO - 2021-08-09 04:15:25 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:25 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:25 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:25 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:25 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:25 --> Controller Class Initialized
ERROR - 2021-08-09 04:15:25 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '64' AND tasm = '20212'
INFO - 2021-08-09 04:15:25 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 04:15:27 --> Config Class Initialized
INFO - 2021-08-09 04:15:27 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:27 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:27 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:27 --> URI Class Initialized
INFO - 2021-08-09 04:15:27 --> Router Class Initialized
INFO - 2021-08-09 04:15:27 --> Output Class Initialized
INFO - 2021-08-09 04:15:27 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:27 --> Input Class Initialized
INFO - 2021-08-09 04:15:27 --> Language Class Initialized
INFO - 2021-08-09 04:15:27 --> Language Class Initialized
INFO - 2021-08-09 04:15:27 --> Config Class Initialized
INFO - 2021-08-09 04:15:27 --> Loader Class Initialized
INFO - 2021-08-09 04:15:27 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:27 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:27 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:27 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:27 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:27 --> Controller Class Initialized
ERROR - 2021-08-09 04:15:27 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '65' AND tasm = '20212'
INFO - 2021-08-09 04:15:27 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 04:15:28 --> Config Class Initialized
INFO - 2021-08-09 04:15:28 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:28 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:28 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:28 --> URI Class Initialized
INFO - 2021-08-09 04:15:28 --> Router Class Initialized
INFO - 2021-08-09 04:15:28 --> Output Class Initialized
INFO - 2021-08-09 04:15:28 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:28 --> Input Class Initialized
INFO - 2021-08-09 04:15:28 --> Language Class Initialized
INFO - 2021-08-09 04:15:28 --> Language Class Initialized
INFO - 2021-08-09 04:15:28 --> Config Class Initialized
INFO - 2021-08-09 04:15:28 --> Loader Class Initialized
INFO - 2021-08-09 04:15:28 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:28 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:28 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:28 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:28 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:28 --> Controller Class Initialized
ERROR - 2021-08-09 04:15:28 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '66' AND tasm = '20212'
INFO - 2021-08-09 04:15:28 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 04:15:30 --> Config Class Initialized
INFO - 2021-08-09 04:15:30 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:30 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:30 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:30 --> URI Class Initialized
INFO - 2021-08-09 04:15:30 --> Router Class Initialized
INFO - 2021-08-09 04:15:30 --> Output Class Initialized
INFO - 2021-08-09 04:15:30 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:30 --> Input Class Initialized
INFO - 2021-08-09 04:15:30 --> Language Class Initialized
INFO - 2021-08-09 04:15:30 --> Language Class Initialized
INFO - 2021-08-09 04:15:30 --> Config Class Initialized
INFO - 2021-08-09 04:15:30 --> Loader Class Initialized
INFO - 2021-08-09 04:15:30 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:30 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:30 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:30 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:30 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:30 --> Controller Class Initialized
ERROR - 2021-08-09 04:15:30 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '67' AND tasm = '20212'
INFO - 2021-08-09 04:15:30 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 04:15:32 --> Config Class Initialized
INFO - 2021-08-09 04:15:32 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:32 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:32 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:32 --> URI Class Initialized
INFO - 2021-08-09 04:15:32 --> Router Class Initialized
INFO - 2021-08-09 04:15:33 --> Output Class Initialized
INFO - 2021-08-09 04:15:33 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:33 --> Input Class Initialized
INFO - 2021-08-09 04:15:33 --> Language Class Initialized
INFO - 2021-08-09 04:15:33 --> Language Class Initialized
INFO - 2021-08-09 04:15:33 --> Config Class Initialized
INFO - 2021-08-09 04:15:33 --> Loader Class Initialized
INFO - 2021-08-09 04:15:33 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:33 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:33 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:33 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:33 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:33 --> Controller Class Initialized
ERROR - 2021-08-09 04:15:33 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '68' AND tasm = '20212'
INFO - 2021-08-09 04:15:33 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 04:15:34 --> Config Class Initialized
INFO - 2021-08-09 04:15:34 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:34 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:34 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:34 --> URI Class Initialized
INFO - 2021-08-09 04:15:34 --> Router Class Initialized
INFO - 2021-08-09 04:15:34 --> Output Class Initialized
INFO - 2021-08-09 04:15:34 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:34 --> Input Class Initialized
INFO - 2021-08-09 04:15:34 --> Language Class Initialized
INFO - 2021-08-09 04:15:34 --> Language Class Initialized
INFO - 2021-08-09 04:15:34 --> Config Class Initialized
INFO - 2021-08-09 04:15:34 --> Loader Class Initialized
INFO - 2021-08-09 04:15:34 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:34 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:34 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:34 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:34 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:34 --> Controller Class Initialized
ERROR - 2021-08-09 04:15:34 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '69' AND tasm = '20212'
INFO - 2021-08-09 04:15:34 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 04:15:36 --> Config Class Initialized
INFO - 2021-08-09 04:15:36 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:36 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:36 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:36 --> URI Class Initialized
INFO - 2021-08-09 04:15:36 --> Router Class Initialized
INFO - 2021-08-09 04:15:36 --> Output Class Initialized
INFO - 2021-08-09 04:15:36 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:36 --> Input Class Initialized
INFO - 2021-08-09 04:15:36 --> Language Class Initialized
INFO - 2021-08-09 04:15:36 --> Language Class Initialized
INFO - 2021-08-09 04:15:36 --> Config Class Initialized
INFO - 2021-08-09 04:15:36 --> Loader Class Initialized
INFO - 2021-08-09 04:15:36 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:36 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:36 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:36 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:36 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:36 --> Controller Class Initialized
DEBUG - 2021-08-09 04:15:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 04:15:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:15:36 --> Final output sent to browser
DEBUG - 2021-08-09 04:15:36 --> Total execution time: 0.0756
INFO - 2021-08-09 04:15:38 --> Config Class Initialized
INFO - 2021-08-09 04:15:38 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:15:38 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:15:38 --> Utf8 Class Initialized
INFO - 2021-08-09 04:15:38 --> URI Class Initialized
INFO - 2021-08-09 04:15:38 --> Router Class Initialized
INFO - 2021-08-09 04:15:38 --> Output Class Initialized
INFO - 2021-08-09 04:15:38 --> Security Class Initialized
DEBUG - 2021-08-09 04:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:15:38 --> Input Class Initialized
INFO - 2021-08-09 04:15:38 --> Language Class Initialized
INFO - 2021-08-09 04:15:38 --> Language Class Initialized
INFO - 2021-08-09 04:15:38 --> Config Class Initialized
INFO - 2021-08-09 04:15:38 --> Loader Class Initialized
INFO - 2021-08-09 04:15:38 --> Helper loaded: url_helper
INFO - 2021-08-09 04:15:38 --> Helper loaded: file_helper
INFO - 2021-08-09 04:15:38 --> Helper loaded: form_helper
INFO - 2021-08-09 04:15:38 --> Helper loaded: my_helper
INFO - 2021-08-09 04:15:38 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:15:38 --> Controller Class Initialized
DEBUG - 2021-08-09 04:15:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 04:15:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:15:38 --> Final output sent to browser
DEBUG - 2021-08-09 04:15:38 --> Total execution time: 0.0769
INFO - 2021-08-09 04:23:11 --> Config Class Initialized
INFO - 2021-08-09 04:23:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:23:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:23:11 --> Utf8 Class Initialized
INFO - 2021-08-09 04:23:11 --> URI Class Initialized
INFO - 2021-08-09 04:23:11 --> Router Class Initialized
INFO - 2021-08-09 04:23:11 --> Output Class Initialized
INFO - 2021-08-09 04:23:11 --> Security Class Initialized
DEBUG - 2021-08-09 04:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:23:11 --> Input Class Initialized
INFO - 2021-08-09 04:23:11 --> Language Class Initialized
INFO - 2021-08-09 04:23:11 --> Language Class Initialized
INFO - 2021-08-09 04:23:11 --> Config Class Initialized
INFO - 2021-08-09 04:23:11 --> Loader Class Initialized
INFO - 2021-08-09 04:23:11 --> Helper loaded: url_helper
INFO - 2021-08-09 04:23:11 --> Helper loaded: file_helper
INFO - 2021-08-09 04:23:11 --> Helper loaded: form_helper
INFO - 2021-08-09 04:23:11 --> Helper loaded: my_helper
INFO - 2021-08-09 04:23:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:23:11 --> Controller Class Initialized
INFO - 2021-08-09 04:23:11 --> Config Class Initialized
INFO - 2021-08-09 04:23:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:23:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:23:11 --> Utf8 Class Initialized
INFO - 2021-08-09 04:23:11 --> URI Class Initialized
INFO - 2021-08-09 04:23:11 --> Router Class Initialized
INFO - 2021-08-09 04:23:11 --> Output Class Initialized
INFO - 2021-08-09 04:23:11 --> Security Class Initialized
DEBUG - 2021-08-09 04:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:23:11 --> Input Class Initialized
INFO - 2021-08-09 04:23:11 --> Language Class Initialized
INFO - 2021-08-09 04:23:11 --> Language Class Initialized
INFO - 2021-08-09 04:23:11 --> Config Class Initialized
INFO - 2021-08-09 04:23:11 --> Loader Class Initialized
INFO - 2021-08-09 04:23:11 --> Helper loaded: url_helper
INFO - 2021-08-09 04:23:11 --> Helper loaded: file_helper
INFO - 2021-08-09 04:23:11 --> Helper loaded: form_helper
INFO - 2021-08-09 04:23:11 --> Helper loaded: my_helper
INFO - 2021-08-09 04:23:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:23:11 --> Controller Class Initialized
DEBUG - 2021-08-09 04:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 04:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:23:11 --> Final output sent to browser
DEBUG - 2021-08-09 04:23:11 --> Total execution time: 0.0645
INFO - 2021-08-09 04:23:34 --> Config Class Initialized
INFO - 2021-08-09 04:23:34 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:23:34 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:23:34 --> Utf8 Class Initialized
INFO - 2021-08-09 04:23:34 --> URI Class Initialized
INFO - 2021-08-09 04:23:34 --> Router Class Initialized
INFO - 2021-08-09 04:23:34 --> Output Class Initialized
INFO - 2021-08-09 04:23:34 --> Security Class Initialized
DEBUG - 2021-08-09 04:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:23:34 --> Input Class Initialized
INFO - 2021-08-09 04:23:34 --> Language Class Initialized
INFO - 2021-08-09 04:23:34 --> Language Class Initialized
INFO - 2021-08-09 04:23:34 --> Config Class Initialized
INFO - 2021-08-09 04:23:34 --> Loader Class Initialized
INFO - 2021-08-09 04:23:34 --> Helper loaded: url_helper
INFO - 2021-08-09 04:23:34 --> Helper loaded: file_helper
INFO - 2021-08-09 04:23:34 --> Helper loaded: form_helper
INFO - 2021-08-09 04:23:34 --> Helper loaded: my_helper
INFO - 2021-08-09 04:23:34 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:23:34 --> Controller Class Initialized
DEBUG - 2021-08-09 04:23:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 04:23:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:23:34 --> Final output sent to browser
DEBUG - 2021-08-09 04:23:34 --> Total execution time: 0.0795
INFO - 2021-08-09 04:24:12 --> Config Class Initialized
INFO - 2021-08-09 04:24:12 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:24:12 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:24:12 --> Utf8 Class Initialized
INFO - 2021-08-09 04:24:12 --> URI Class Initialized
INFO - 2021-08-09 04:24:12 --> Router Class Initialized
INFO - 2021-08-09 04:24:12 --> Output Class Initialized
INFO - 2021-08-09 04:24:12 --> Security Class Initialized
DEBUG - 2021-08-09 04:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:24:12 --> Input Class Initialized
INFO - 2021-08-09 04:24:12 --> Language Class Initialized
INFO - 2021-08-09 04:24:12 --> Language Class Initialized
INFO - 2021-08-09 04:24:12 --> Config Class Initialized
INFO - 2021-08-09 04:24:12 --> Loader Class Initialized
INFO - 2021-08-09 04:24:12 --> Helper loaded: url_helper
INFO - 2021-08-09 04:24:12 --> Helper loaded: file_helper
INFO - 2021-08-09 04:24:12 --> Helper loaded: form_helper
INFO - 2021-08-09 04:24:12 --> Helper loaded: my_helper
INFO - 2021-08-09 04:24:12 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:24:12 --> Controller Class Initialized
DEBUG - 2021-08-09 04:24:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 04:24:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:24:12 --> Final output sent to browser
DEBUG - 2021-08-09 04:24:12 --> Total execution time: 0.0989
INFO - 2021-08-09 04:44:43 --> Config Class Initialized
INFO - 2021-08-09 04:44:43 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:44:43 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:44:43 --> Utf8 Class Initialized
INFO - 2021-08-09 04:44:43 --> URI Class Initialized
INFO - 2021-08-09 04:44:43 --> Router Class Initialized
INFO - 2021-08-09 04:44:43 --> Output Class Initialized
INFO - 2021-08-09 04:44:43 --> Security Class Initialized
DEBUG - 2021-08-09 04:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:44:43 --> Input Class Initialized
INFO - 2021-08-09 04:44:43 --> Language Class Initialized
INFO - 2021-08-09 04:44:43 --> Language Class Initialized
INFO - 2021-08-09 04:44:43 --> Config Class Initialized
INFO - 2021-08-09 04:44:43 --> Loader Class Initialized
INFO - 2021-08-09 04:44:43 --> Helper loaded: url_helper
INFO - 2021-08-09 04:44:43 --> Helper loaded: file_helper
INFO - 2021-08-09 04:44:43 --> Helper loaded: form_helper
INFO - 2021-08-09 04:44:43 --> Helper loaded: my_helper
INFO - 2021-08-09 04:44:43 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:44:43 --> Controller Class Initialized
DEBUG - 2021-08-09 04:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 04:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:44:43 --> Final output sent to browser
DEBUG - 2021-08-09 04:44:43 --> Total execution time: 0.0827
INFO - 2021-08-09 04:57:58 --> Config Class Initialized
INFO - 2021-08-09 04:57:58 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:57:58 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:57:58 --> Utf8 Class Initialized
INFO - 2021-08-09 04:57:58 --> URI Class Initialized
INFO - 2021-08-09 04:57:58 --> Router Class Initialized
INFO - 2021-08-09 04:57:58 --> Output Class Initialized
INFO - 2021-08-09 04:57:58 --> Security Class Initialized
DEBUG - 2021-08-09 04:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:57:58 --> Input Class Initialized
INFO - 2021-08-09 04:57:58 --> Language Class Initialized
INFO - 2021-08-09 04:57:58 --> Language Class Initialized
INFO - 2021-08-09 04:57:58 --> Config Class Initialized
INFO - 2021-08-09 04:57:58 --> Loader Class Initialized
INFO - 2021-08-09 04:57:58 --> Helper loaded: url_helper
INFO - 2021-08-09 04:57:58 --> Helper loaded: file_helper
INFO - 2021-08-09 04:57:58 --> Helper loaded: form_helper
INFO - 2021-08-09 04:57:58 --> Helper loaded: my_helper
INFO - 2021-08-09 04:57:58 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:57:58 --> Controller Class Initialized
INFO - 2021-08-09 04:57:58 --> Config Class Initialized
INFO - 2021-08-09 04:57:58 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:57:58 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:57:58 --> Utf8 Class Initialized
INFO - 2021-08-09 04:57:58 --> URI Class Initialized
INFO - 2021-08-09 04:57:58 --> Router Class Initialized
INFO - 2021-08-09 04:57:58 --> Output Class Initialized
INFO - 2021-08-09 04:57:58 --> Security Class Initialized
DEBUG - 2021-08-09 04:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:57:58 --> Input Class Initialized
INFO - 2021-08-09 04:57:58 --> Language Class Initialized
INFO - 2021-08-09 04:57:58 --> Language Class Initialized
INFO - 2021-08-09 04:57:58 --> Config Class Initialized
INFO - 2021-08-09 04:57:58 --> Loader Class Initialized
INFO - 2021-08-09 04:57:58 --> Helper loaded: url_helper
INFO - 2021-08-09 04:57:58 --> Helper loaded: file_helper
INFO - 2021-08-09 04:57:58 --> Helper loaded: form_helper
INFO - 2021-08-09 04:57:58 --> Helper loaded: my_helper
INFO - 2021-08-09 04:57:58 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:57:58 --> Controller Class Initialized
DEBUG - 2021-08-09 04:57:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 04:57:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:57:58 --> Final output sent to browser
DEBUG - 2021-08-09 04:57:58 --> Total execution time: 0.0792
INFO - 2021-08-09 04:58:11 --> Config Class Initialized
INFO - 2021-08-09 04:58:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:58:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:58:11 --> Utf8 Class Initialized
INFO - 2021-08-09 04:58:11 --> URI Class Initialized
INFO - 2021-08-09 04:58:11 --> Router Class Initialized
INFO - 2021-08-09 04:58:11 --> Output Class Initialized
INFO - 2021-08-09 04:58:11 --> Security Class Initialized
DEBUG - 2021-08-09 04:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:58:11 --> Input Class Initialized
INFO - 2021-08-09 04:58:11 --> Language Class Initialized
INFO - 2021-08-09 04:58:11 --> Language Class Initialized
INFO - 2021-08-09 04:58:11 --> Config Class Initialized
INFO - 2021-08-09 04:58:11 --> Loader Class Initialized
INFO - 2021-08-09 04:58:11 --> Helper loaded: url_helper
INFO - 2021-08-09 04:58:11 --> Helper loaded: file_helper
INFO - 2021-08-09 04:58:11 --> Helper loaded: form_helper
INFO - 2021-08-09 04:58:11 --> Helper loaded: my_helper
INFO - 2021-08-09 04:58:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:58:11 --> Controller Class Initialized
DEBUG - 2021-08-09 04:58:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 04:58:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:58:11 --> Final output sent to browser
DEBUG - 2021-08-09 04:58:11 --> Total execution time: 0.0675
INFO - 2021-08-09 04:58:41 --> Config Class Initialized
INFO - 2021-08-09 04:58:41 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:58:41 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:58:41 --> Utf8 Class Initialized
INFO - 2021-08-09 04:58:41 --> URI Class Initialized
INFO - 2021-08-09 04:58:41 --> Router Class Initialized
INFO - 2021-08-09 04:58:41 --> Output Class Initialized
INFO - 2021-08-09 04:58:41 --> Security Class Initialized
DEBUG - 2021-08-09 04:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:58:41 --> Input Class Initialized
INFO - 2021-08-09 04:58:41 --> Language Class Initialized
INFO - 2021-08-09 04:58:41 --> Language Class Initialized
INFO - 2021-08-09 04:58:41 --> Config Class Initialized
INFO - 2021-08-09 04:58:41 --> Loader Class Initialized
INFO - 2021-08-09 04:58:41 --> Helper loaded: url_helper
INFO - 2021-08-09 04:58:41 --> Helper loaded: file_helper
INFO - 2021-08-09 04:58:41 --> Helper loaded: form_helper
INFO - 2021-08-09 04:58:41 --> Helper loaded: my_helper
INFO - 2021-08-09 04:58:41 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:58:41 --> Controller Class Initialized
INFO - 2021-08-09 04:58:41 --> Config Class Initialized
INFO - 2021-08-09 04:58:41 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:58:41 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:58:41 --> Utf8 Class Initialized
INFO - 2021-08-09 04:58:41 --> URI Class Initialized
INFO - 2021-08-09 04:58:41 --> Router Class Initialized
INFO - 2021-08-09 04:58:41 --> Output Class Initialized
INFO - 2021-08-09 04:58:41 --> Security Class Initialized
DEBUG - 2021-08-09 04:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:58:41 --> Input Class Initialized
INFO - 2021-08-09 04:58:41 --> Language Class Initialized
INFO - 2021-08-09 04:58:41 --> Language Class Initialized
INFO - 2021-08-09 04:58:42 --> Config Class Initialized
INFO - 2021-08-09 04:58:42 --> Loader Class Initialized
INFO - 2021-08-09 04:58:42 --> Helper loaded: url_helper
INFO - 2021-08-09 04:58:42 --> Helper loaded: file_helper
INFO - 2021-08-09 04:58:42 --> Helper loaded: form_helper
INFO - 2021-08-09 04:58:42 --> Helper loaded: my_helper
INFO - 2021-08-09 04:58:42 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:58:42 --> Controller Class Initialized
DEBUG - 2021-08-09 04:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 04:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:58:42 --> Final output sent to browser
DEBUG - 2021-08-09 04:58:42 --> Total execution time: 0.0721
INFO - 2021-08-09 04:59:34 --> Config Class Initialized
INFO - 2021-08-09 04:59:34 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:59:34 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:59:34 --> Utf8 Class Initialized
INFO - 2021-08-09 04:59:34 --> URI Class Initialized
INFO - 2021-08-09 04:59:34 --> Router Class Initialized
INFO - 2021-08-09 04:59:34 --> Output Class Initialized
INFO - 2021-08-09 04:59:34 --> Security Class Initialized
DEBUG - 2021-08-09 04:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:59:35 --> Input Class Initialized
INFO - 2021-08-09 04:59:35 --> Language Class Initialized
INFO - 2021-08-09 04:59:35 --> Language Class Initialized
INFO - 2021-08-09 04:59:35 --> Config Class Initialized
INFO - 2021-08-09 04:59:35 --> Loader Class Initialized
INFO - 2021-08-09 04:59:35 --> Helper loaded: url_helper
INFO - 2021-08-09 04:59:35 --> Helper loaded: file_helper
INFO - 2021-08-09 04:59:35 --> Helper loaded: form_helper
INFO - 2021-08-09 04:59:35 --> Helper loaded: my_helper
INFO - 2021-08-09 04:59:35 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:59:35 --> Controller Class Initialized
DEBUG - 2021-08-09 04:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 04:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 04:59:35 --> Final output sent to browser
DEBUG - 2021-08-09 04:59:35 --> Total execution time: 0.0712
INFO - 2021-08-09 04:59:59 --> Config Class Initialized
INFO - 2021-08-09 04:59:59 --> Hooks Class Initialized
DEBUG - 2021-08-09 04:59:59 --> UTF-8 Support Enabled
INFO - 2021-08-09 04:59:59 --> Utf8 Class Initialized
INFO - 2021-08-09 04:59:59 --> URI Class Initialized
INFO - 2021-08-09 04:59:59 --> Router Class Initialized
INFO - 2021-08-09 04:59:59 --> Output Class Initialized
INFO - 2021-08-09 04:59:59 --> Security Class Initialized
DEBUG - 2021-08-09 04:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 04:59:59 --> Input Class Initialized
INFO - 2021-08-09 04:59:59 --> Language Class Initialized
INFO - 2021-08-09 04:59:59 --> Language Class Initialized
INFO - 2021-08-09 04:59:59 --> Config Class Initialized
INFO - 2021-08-09 04:59:59 --> Loader Class Initialized
INFO - 2021-08-09 04:59:59 --> Helper loaded: url_helper
INFO - 2021-08-09 04:59:59 --> Helper loaded: file_helper
INFO - 2021-08-09 04:59:59 --> Helper loaded: form_helper
INFO - 2021-08-09 04:59:59 --> Helper loaded: my_helper
INFO - 2021-08-09 04:59:59 --> Database Driver Class Initialized
DEBUG - 2021-08-09 04:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 04:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 04:59:59 --> Controller Class Initialized
INFO - 2021-08-09 05:00:00 --> Config Class Initialized
INFO - 2021-08-09 05:00:00 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:00:00 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:00:00 --> Utf8 Class Initialized
INFO - 2021-08-09 05:00:00 --> URI Class Initialized
INFO - 2021-08-09 05:00:00 --> Router Class Initialized
INFO - 2021-08-09 05:00:00 --> Output Class Initialized
INFO - 2021-08-09 05:00:00 --> Security Class Initialized
DEBUG - 2021-08-09 05:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:00:00 --> Input Class Initialized
INFO - 2021-08-09 05:00:00 --> Language Class Initialized
INFO - 2021-08-09 05:00:00 --> Language Class Initialized
INFO - 2021-08-09 05:00:00 --> Config Class Initialized
INFO - 2021-08-09 05:00:00 --> Loader Class Initialized
INFO - 2021-08-09 05:00:00 --> Helper loaded: url_helper
INFO - 2021-08-09 05:00:00 --> Helper loaded: file_helper
INFO - 2021-08-09 05:00:00 --> Helper loaded: form_helper
INFO - 2021-08-09 05:00:00 --> Helper loaded: my_helper
INFO - 2021-08-09 05:00:00 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:00:00 --> Controller Class Initialized
DEBUG - 2021-08-09 05:00:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:00:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:00:00 --> Final output sent to browser
DEBUG - 2021-08-09 05:00:00 --> Total execution time: 0.0752
INFO - 2021-08-09 05:00:07 --> Config Class Initialized
INFO - 2021-08-09 05:00:07 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:00:07 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:00:07 --> Utf8 Class Initialized
INFO - 2021-08-09 05:00:07 --> URI Class Initialized
INFO - 2021-08-09 05:00:07 --> Router Class Initialized
INFO - 2021-08-09 05:00:07 --> Output Class Initialized
INFO - 2021-08-09 05:00:07 --> Security Class Initialized
DEBUG - 2021-08-09 05:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:00:07 --> Input Class Initialized
INFO - 2021-08-09 05:00:07 --> Language Class Initialized
INFO - 2021-08-09 05:00:07 --> Language Class Initialized
INFO - 2021-08-09 05:00:07 --> Config Class Initialized
INFO - 2021-08-09 05:00:07 --> Loader Class Initialized
INFO - 2021-08-09 05:00:07 --> Helper loaded: url_helper
INFO - 2021-08-09 05:00:07 --> Helper loaded: file_helper
INFO - 2021-08-09 05:00:07 --> Helper loaded: form_helper
INFO - 2021-08-09 05:00:07 --> Helper loaded: my_helper
INFO - 2021-08-09 05:00:07 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:00:07 --> Controller Class Initialized
DEBUG - 2021-08-09 05:00:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:00:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:00:07 --> Final output sent to browser
DEBUG - 2021-08-09 05:00:07 --> Total execution time: 0.0822
INFO - 2021-08-09 05:00:19 --> Config Class Initialized
INFO - 2021-08-09 05:00:19 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:00:19 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:00:19 --> Utf8 Class Initialized
INFO - 2021-08-09 05:00:19 --> URI Class Initialized
INFO - 2021-08-09 05:00:19 --> Router Class Initialized
INFO - 2021-08-09 05:00:19 --> Output Class Initialized
INFO - 2021-08-09 05:00:19 --> Security Class Initialized
DEBUG - 2021-08-09 05:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:00:19 --> Input Class Initialized
INFO - 2021-08-09 05:00:19 --> Language Class Initialized
INFO - 2021-08-09 05:00:19 --> Language Class Initialized
INFO - 2021-08-09 05:00:19 --> Config Class Initialized
INFO - 2021-08-09 05:00:19 --> Loader Class Initialized
INFO - 2021-08-09 05:00:19 --> Helper loaded: url_helper
INFO - 2021-08-09 05:00:19 --> Helper loaded: file_helper
INFO - 2021-08-09 05:00:19 --> Helper loaded: form_helper
INFO - 2021-08-09 05:00:19 --> Helper loaded: my_helper
INFO - 2021-08-09 05:00:19 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:00:19 --> Controller Class Initialized
INFO - 2021-08-09 05:00:19 --> Config Class Initialized
INFO - 2021-08-09 05:00:19 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:00:19 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:00:19 --> Utf8 Class Initialized
INFO - 2021-08-09 05:00:19 --> URI Class Initialized
INFO - 2021-08-09 05:00:19 --> Router Class Initialized
INFO - 2021-08-09 05:00:19 --> Output Class Initialized
INFO - 2021-08-09 05:00:19 --> Security Class Initialized
DEBUG - 2021-08-09 05:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:00:19 --> Input Class Initialized
INFO - 2021-08-09 05:00:19 --> Language Class Initialized
INFO - 2021-08-09 05:00:19 --> Language Class Initialized
INFO - 2021-08-09 05:00:19 --> Config Class Initialized
INFO - 2021-08-09 05:00:19 --> Loader Class Initialized
INFO - 2021-08-09 05:00:19 --> Helper loaded: url_helper
INFO - 2021-08-09 05:00:19 --> Helper loaded: file_helper
INFO - 2021-08-09 05:00:19 --> Helper loaded: form_helper
INFO - 2021-08-09 05:00:19 --> Helper loaded: my_helper
INFO - 2021-08-09 05:00:19 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:00:19 --> Controller Class Initialized
DEBUG - 2021-08-09 05:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:00:19 --> Final output sent to browser
DEBUG - 2021-08-09 05:00:19 --> Total execution time: 0.0633
INFO - 2021-08-09 05:00:37 --> Config Class Initialized
INFO - 2021-08-09 05:00:37 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:00:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:00:37 --> Utf8 Class Initialized
INFO - 2021-08-09 05:00:37 --> URI Class Initialized
INFO - 2021-08-09 05:00:37 --> Router Class Initialized
INFO - 2021-08-09 05:00:37 --> Output Class Initialized
INFO - 2021-08-09 05:00:37 --> Security Class Initialized
DEBUG - 2021-08-09 05:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:00:37 --> Input Class Initialized
INFO - 2021-08-09 05:00:37 --> Language Class Initialized
INFO - 2021-08-09 05:00:37 --> Language Class Initialized
INFO - 2021-08-09 05:00:37 --> Config Class Initialized
INFO - 2021-08-09 05:00:37 --> Loader Class Initialized
INFO - 2021-08-09 05:00:37 --> Helper loaded: url_helper
INFO - 2021-08-09 05:00:37 --> Helper loaded: file_helper
INFO - 2021-08-09 05:00:37 --> Helper loaded: form_helper
INFO - 2021-08-09 05:00:37 --> Helper loaded: my_helper
INFO - 2021-08-09 05:00:37 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:00:37 --> Controller Class Initialized
DEBUG - 2021-08-09 05:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:00:37 --> Final output sent to browser
DEBUG - 2021-08-09 05:00:37 --> Total execution time: 0.0649
INFO - 2021-08-09 05:00:48 --> Config Class Initialized
INFO - 2021-08-09 05:00:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:00:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:00:48 --> Utf8 Class Initialized
INFO - 2021-08-09 05:00:48 --> URI Class Initialized
INFO - 2021-08-09 05:00:48 --> Router Class Initialized
INFO - 2021-08-09 05:00:48 --> Output Class Initialized
INFO - 2021-08-09 05:00:48 --> Security Class Initialized
DEBUG - 2021-08-09 05:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:00:48 --> Input Class Initialized
INFO - 2021-08-09 05:00:48 --> Language Class Initialized
INFO - 2021-08-09 05:00:48 --> Language Class Initialized
INFO - 2021-08-09 05:00:48 --> Config Class Initialized
INFO - 2021-08-09 05:00:48 --> Loader Class Initialized
INFO - 2021-08-09 05:00:48 --> Helper loaded: url_helper
INFO - 2021-08-09 05:00:48 --> Helper loaded: file_helper
INFO - 2021-08-09 05:00:48 --> Helper loaded: form_helper
INFO - 2021-08-09 05:00:48 --> Helper loaded: my_helper
INFO - 2021-08-09 05:00:48 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:00:48 --> Controller Class Initialized
INFO - 2021-08-09 05:00:48 --> Config Class Initialized
INFO - 2021-08-09 05:00:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:00:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:00:48 --> Utf8 Class Initialized
INFO - 2021-08-09 05:00:48 --> URI Class Initialized
INFO - 2021-08-09 05:00:48 --> Router Class Initialized
INFO - 2021-08-09 05:00:48 --> Output Class Initialized
INFO - 2021-08-09 05:00:48 --> Security Class Initialized
DEBUG - 2021-08-09 05:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:00:48 --> Input Class Initialized
INFO - 2021-08-09 05:00:48 --> Language Class Initialized
INFO - 2021-08-09 05:00:48 --> Language Class Initialized
INFO - 2021-08-09 05:00:48 --> Config Class Initialized
INFO - 2021-08-09 05:00:48 --> Loader Class Initialized
INFO - 2021-08-09 05:00:48 --> Helper loaded: url_helper
INFO - 2021-08-09 05:00:48 --> Helper loaded: file_helper
INFO - 2021-08-09 05:00:48 --> Helper loaded: form_helper
INFO - 2021-08-09 05:00:48 --> Helper loaded: my_helper
INFO - 2021-08-09 05:00:48 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:00:48 --> Controller Class Initialized
DEBUG - 2021-08-09 05:00:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:00:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:00:48 --> Final output sent to browser
DEBUG - 2021-08-09 05:00:48 --> Total execution time: 0.0804
INFO - 2021-08-09 05:01:51 --> Config Class Initialized
INFO - 2021-08-09 05:01:51 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:01:51 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:01:51 --> Utf8 Class Initialized
INFO - 2021-08-09 05:01:51 --> URI Class Initialized
INFO - 2021-08-09 05:01:51 --> Router Class Initialized
INFO - 2021-08-09 05:01:51 --> Output Class Initialized
INFO - 2021-08-09 05:01:51 --> Security Class Initialized
DEBUG - 2021-08-09 05:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:01:51 --> Input Class Initialized
INFO - 2021-08-09 05:01:51 --> Language Class Initialized
INFO - 2021-08-09 05:01:51 --> Language Class Initialized
INFO - 2021-08-09 05:01:51 --> Config Class Initialized
INFO - 2021-08-09 05:01:51 --> Loader Class Initialized
INFO - 2021-08-09 05:01:51 --> Helper loaded: url_helper
INFO - 2021-08-09 05:01:51 --> Helper loaded: file_helper
INFO - 2021-08-09 05:01:51 --> Helper loaded: form_helper
INFO - 2021-08-09 05:01:51 --> Helper loaded: my_helper
INFO - 2021-08-09 05:01:51 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:01:51 --> Controller Class Initialized
DEBUG - 2021-08-09 05:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:01:51 --> Final output sent to browser
DEBUG - 2021-08-09 05:01:51 --> Total execution time: 0.0723
INFO - 2021-08-09 05:02:05 --> Config Class Initialized
INFO - 2021-08-09 05:02:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:02:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:02:05 --> Utf8 Class Initialized
INFO - 2021-08-09 05:02:05 --> URI Class Initialized
INFO - 2021-08-09 05:02:05 --> Router Class Initialized
INFO - 2021-08-09 05:02:05 --> Output Class Initialized
INFO - 2021-08-09 05:02:05 --> Security Class Initialized
DEBUG - 2021-08-09 05:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:02:05 --> Input Class Initialized
INFO - 2021-08-09 05:02:05 --> Language Class Initialized
INFO - 2021-08-09 05:02:05 --> Language Class Initialized
INFO - 2021-08-09 05:02:05 --> Config Class Initialized
INFO - 2021-08-09 05:02:05 --> Loader Class Initialized
INFO - 2021-08-09 05:02:05 --> Helper loaded: url_helper
INFO - 2021-08-09 05:02:05 --> Helper loaded: file_helper
INFO - 2021-08-09 05:02:05 --> Helper loaded: form_helper
INFO - 2021-08-09 05:02:05 --> Helper loaded: my_helper
INFO - 2021-08-09 05:02:05 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:02:05 --> Controller Class Initialized
INFO - 2021-08-09 05:02:05 --> Config Class Initialized
INFO - 2021-08-09 05:02:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:02:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:02:05 --> Utf8 Class Initialized
INFO - 2021-08-09 05:02:05 --> URI Class Initialized
INFO - 2021-08-09 05:02:05 --> Router Class Initialized
INFO - 2021-08-09 05:02:05 --> Output Class Initialized
INFO - 2021-08-09 05:02:05 --> Security Class Initialized
DEBUG - 2021-08-09 05:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:02:05 --> Input Class Initialized
INFO - 2021-08-09 05:02:05 --> Language Class Initialized
INFO - 2021-08-09 05:02:05 --> Language Class Initialized
INFO - 2021-08-09 05:02:05 --> Config Class Initialized
INFO - 2021-08-09 05:02:05 --> Loader Class Initialized
INFO - 2021-08-09 05:02:05 --> Helper loaded: url_helper
INFO - 2021-08-09 05:02:05 --> Helper loaded: file_helper
INFO - 2021-08-09 05:02:05 --> Helper loaded: form_helper
INFO - 2021-08-09 05:02:05 --> Helper loaded: my_helper
INFO - 2021-08-09 05:02:05 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:02:05 --> Controller Class Initialized
DEBUG - 2021-08-09 05:02:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:02:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:02:05 --> Final output sent to browser
DEBUG - 2021-08-09 05:02:05 --> Total execution time: 0.0621
INFO - 2021-08-09 05:04:53 --> Config Class Initialized
INFO - 2021-08-09 05:04:53 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:04:53 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:04:53 --> Utf8 Class Initialized
INFO - 2021-08-09 05:04:53 --> URI Class Initialized
INFO - 2021-08-09 05:04:53 --> Router Class Initialized
INFO - 2021-08-09 05:04:53 --> Output Class Initialized
INFO - 2021-08-09 05:04:53 --> Security Class Initialized
DEBUG - 2021-08-09 05:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:04:53 --> Input Class Initialized
INFO - 2021-08-09 05:04:53 --> Language Class Initialized
INFO - 2021-08-09 05:04:53 --> Language Class Initialized
INFO - 2021-08-09 05:04:53 --> Config Class Initialized
INFO - 2021-08-09 05:04:54 --> Loader Class Initialized
INFO - 2021-08-09 05:04:54 --> Helper loaded: url_helper
INFO - 2021-08-09 05:04:54 --> Helper loaded: file_helper
INFO - 2021-08-09 05:04:54 --> Helper loaded: form_helper
INFO - 2021-08-09 05:04:54 --> Helper loaded: my_helper
INFO - 2021-08-09 05:04:54 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:04:54 --> Controller Class Initialized
DEBUG - 2021-08-09 05:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:04:54 --> Final output sent to browser
DEBUG - 2021-08-09 05:04:54 --> Total execution time: 0.0630
INFO - 2021-08-09 05:05:01 --> Config Class Initialized
INFO - 2021-08-09 05:05:01 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:05:01 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:05:01 --> Utf8 Class Initialized
INFO - 2021-08-09 05:05:01 --> URI Class Initialized
INFO - 2021-08-09 05:05:01 --> Router Class Initialized
INFO - 2021-08-09 05:05:01 --> Output Class Initialized
INFO - 2021-08-09 05:05:01 --> Security Class Initialized
DEBUG - 2021-08-09 05:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:05:01 --> Input Class Initialized
INFO - 2021-08-09 05:05:01 --> Language Class Initialized
INFO - 2021-08-09 05:05:01 --> Language Class Initialized
INFO - 2021-08-09 05:05:01 --> Config Class Initialized
INFO - 2021-08-09 05:05:01 --> Loader Class Initialized
INFO - 2021-08-09 05:05:01 --> Helper loaded: url_helper
INFO - 2021-08-09 05:05:01 --> Helper loaded: file_helper
INFO - 2021-08-09 05:05:01 --> Helper loaded: form_helper
INFO - 2021-08-09 05:05:01 --> Helper loaded: my_helper
INFO - 2021-08-09 05:05:01 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:05:01 --> Controller Class Initialized
INFO - 2021-08-09 05:05:01 --> Config Class Initialized
INFO - 2021-08-09 05:05:01 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:05:01 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:05:01 --> Utf8 Class Initialized
INFO - 2021-08-09 05:05:01 --> URI Class Initialized
INFO - 2021-08-09 05:05:01 --> Router Class Initialized
INFO - 2021-08-09 05:05:01 --> Output Class Initialized
INFO - 2021-08-09 05:05:01 --> Security Class Initialized
DEBUG - 2021-08-09 05:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:05:01 --> Input Class Initialized
INFO - 2021-08-09 05:05:01 --> Language Class Initialized
INFO - 2021-08-09 05:05:01 --> Language Class Initialized
INFO - 2021-08-09 05:05:01 --> Config Class Initialized
INFO - 2021-08-09 05:05:01 --> Loader Class Initialized
INFO - 2021-08-09 05:05:01 --> Helper loaded: url_helper
INFO - 2021-08-09 05:05:01 --> Helper loaded: file_helper
INFO - 2021-08-09 05:05:01 --> Helper loaded: form_helper
INFO - 2021-08-09 05:05:01 --> Helper loaded: my_helper
INFO - 2021-08-09 05:05:01 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:05:01 --> Controller Class Initialized
DEBUG - 2021-08-09 05:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:05:01 --> Final output sent to browser
DEBUG - 2021-08-09 05:05:01 --> Total execution time: 0.0579
INFO - 2021-08-09 05:05:03 --> Config Class Initialized
INFO - 2021-08-09 05:05:03 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:05:03 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:05:03 --> Utf8 Class Initialized
INFO - 2021-08-09 05:05:03 --> URI Class Initialized
INFO - 2021-08-09 05:05:03 --> Router Class Initialized
INFO - 2021-08-09 05:05:03 --> Output Class Initialized
INFO - 2021-08-09 05:05:03 --> Security Class Initialized
DEBUG - 2021-08-09 05:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:05:03 --> Input Class Initialized
INFO - 2021-08-09 05:05:03 --> Language Class Initialized
INFO - 2021-08-09 05:05:04 --> Language Class Initialized
INFO - 2021-08-09 05:05:04 --> Config Class Initialized
INFO - 2021-08-09 05:05:04 --> Loader Class Initialized
INFO - 2021-08-09 05:05:04 --> Helper loaded: url_helper
INFO - 2021-08-09 05:05:04 --> Helper loaded: file_helper
INFO - 2021-08-09 05:05:04 --> Helper loaded: form_helper
INFO - 2021-08-09 05:05:04 --> Helper loaded: my_helper
INFO - 2021-08-09 05:05:04 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:05:04 --> Controller Class Initialized
DEBUG - 2021-08-09 05:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:05:04 --> Final output sent to browser
DEBUG - 2021-08-09 05:05:04 --> Total execution time: 0.0619
INFO - 2021-08-09 05:05:18 --> Config Class Initialized
INFO - 2021-08-09 05:05:18 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:05:18 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:05:18 --> Utf8 Class Initialized
INFO - 2021-08-09 05:05:18 --> URI Class Initialized
INFO - 2021-08-09 05:05:18 --> Router Class Initialized
INFO - 2021-08-09 05:05:18 --> Output Class Initialized
INFO - 2021-08-09 05:05:18 --> Security Class Initialized
DEBUG - 2021-08-09 05:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:05:18 --> Input Class Initialized
INFO - 2021-08-09 05:05:18 --> Language Class Initialized
INFO - 2021-08-09 05:05:18 --> Language Class Initialized
INFO - 2021-08-09 05:05:18 --> Config Class Initialized
INFO - 2021-08-09 05:05:18 --> Loader Class Initialized
INFO - 2021-08-09 05:05:18 --> Helper loaded: url_helper
INFO - 2021-08-09 05:05:18 --> Helper loaded: file_helper
INFO - 2021-08-09 05:05:18 --> Helper loaded: form_helper
INFO - 2021-08-09 05:05:18 --> Helper loaded: my_helper
INFO - 2021-08-09 05:05:18 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:05:18 --> Controller Class Initialized
INFO - 2021-08-09 05:05:18 --> Config Class Initialized
INFO - 2021-08-09 05:05:18 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:05:18 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:05:18 --> Utf8 Class Initialized
INFO - 2021-08-09 05:05:18 --> URI Class Initialized
INFO - 2021-08-09 05:05:18 --> Router Class Initialized
INFO - 2021-08-09 05:05:18 --> Output Class Initialized
INFO - 2021-08-09 05:05:18 --> Security Class Initialized
DEBUG - 2021-08-09 05:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:05:18 --> Input Class Initialized
INFO - 2021-08-09 05:05:18 --> Language Class Initialized
INFO - 2021-08-09 05:05:18 --> Language Class Initialized
INFO - 2021-08-09 05:05:18 --> Config Class Initialized
INFO - 2021-08-09 05:05:18 --> Loader Class Initialized
INFO - 2021-08-09 05:05:18 --> Helper loaded: url_helper
INFO - 2021-08-09 05:05:18 --> Helper loaded: file_helper
INFO - 2021-08-09 05:05:18 --> Helper loaded: form_helper
INFO - 2021-08-09 05:05:18 --> Helper loaded: my_helper
INFO - 2021-08-09 05:05:18 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:05:18 --> Controller Class Initialized
DEBUG - 2021-08-09 05:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:05:18 --> Final output sent to browser
DEBUG - 2021-08-09 05:05:18 --> Total execution time: 0.0665
INFO - 2021-08-09 05:05:22 --> Config Class Initialized
INFO - 2021-08-09 05:05:22 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:05:22 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:05:22 --> Utf8 Class Initialized
INFO - 2021-08-09 05:05:22 --> URI Class Initialized
INFO - 2021-08-09 05:05:22 --> Router Class Initialized
INFO - 2021-08-09 05:05:22 --> Output Class Initialized
INFO - 2021-08-09 05:05:22 --> Security Class Initialized
DEBUG - 2021-08-09 05:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:05:22 --> Input Class Initialized
INFO - 2021-08-09 05:05:22 --> Language Class Initialized
INFO - 2021-08-09 05:05:22 --> Language Class Initialized
INFO - 2021-08-09 05:05:22 --> Config Class Initialized
INFO - 2021-08-09 05:05:22 --> Loader Class Initialized
INFO - 2021-08-09 05:05:22 --> Helper loaded: url_helper
INFO - 2021-08-09 05:05:22 --> Helper loaded: file_helper
INFO - 2021-08-09 05:05:22 --> Helper loaded: form_helper
INFO - 2021-08-09 05:05:22 --> Helper loaded: my_helper
INFO - 2021-08-09 05:05:22 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:05:22 --> Controller Class Initialized
DEBUG - 2021-08-09 05:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:05:22 --> Final output sent to browser
DEBUG - 2021-08-09 05:05:22 --> Total execution time: 0.0614
INFO - 2021-08-09 05:05:45 --> Config Class Initialized
INFO - 2021-08-09 05:05:45 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:05:45 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:05:45 --> Utf8 Class Initialized
INFO - 2021-08-09 05:05:45 --> URI Class Initialized
INFO - 2021-08-09 05:05:45 --> Router Class Initialized
INFO - 2021-08-09 05:05:45 --> Output Class Initialized
INFO - 2021-08-09 05:05:45 --> Security Class Initialized
DEBUG - 2021-08-09 05:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:05:45 --> Input Class Initialized
INFO - 2021-08-09 05:05:45 --> Language Class Initialized
INFO - 2021-08-09 05:05:45 --> Language Class Initialized
INFO - 2021-08-09 05:05:45 --> Config Class Initialized
INFO - 2021-08-09 05:05:45 --> Loader Class Initialized
INFO - 2021-08-09 05:05:45 --> Helper loaded: url_helper
INFO - 2021-08-09 05:05:45 --> Helper loaded: file_helper
INFO - 2021-08-09 05:05:45 --> Helper loaded: form_helper
INFO - 2021-08-09 05:05:45 --> Helper loaded: my_helper
INFO - 2021-08-09 05:05:45 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:05:45 --> Controller Class Initialized
INFO - 2021-08-09 05:05:45 --> Config Class Initialized
INFO - 2021-08-09 05:05:45 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:05:45 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:05:45 --> Utf8 Class Initialized
INFO - 2021-08-09 05:05:45 --> URI Class Initialized
INFO - 2021-08-09 05:05:45 --> Router Class Initialized
INFO - 2021-08-09 05:05:45 --> Output Class Initialized
INFO - 2021-08-09 05:05:45 --> Security Class Initialized
DEBUG - 2021-08-09 05:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:05:45 --> Input Class Initialized
INFO - 2021-08-09 05:05:45 --> Language Class Initialized
INFO - 2021-08-09 05:05:45 --> Language Class Initialized
INFO - 2021-08-09 05:05:45 --> Config Class Initialized
INFO - 2021-08-09 05:05:45 --> Loader Class Initialized
INFO - 2021-08-09 05:05:45 --> Helper loaded: url_helper
INFO - 2021-08-09 05:05:45 --> Helper loaded: file_helper
INFO - 2021-08-09 05:05:45 --> Helper loaded: form_helper
INFO - 2021-08-09 05:05:45 --> Helper loaded: my_helper
INFO - 2021-08-09 05:05:45 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:05:45 --> Controller Class Initialized
DEBUG - 2021-08-09 05:05:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:05:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:05:45 --> Final output sent to browser
DEBUG - 2021-08-09 05:05:45 --> Total execution time: 0.0748
INFO - 2021-08-09 05:05:46 --> Config Class Initialized
INFO - 2021-08-09 05:05:46 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:05:46 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:05:46 --> Utf8 Class Initialized
INFO - 2021-08-09 05:05:46 --> URI Class Initialized
INFO - 2021-08-09 05:05:46 --> Router Class Initialized
INFO - 2021-08-09 05:05:46 --> Output Class Initialized
INFO - 2021-08-09 05:05:46 --> Security Class Initialized
DEBUG - 2021-08-09 05:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:05:46 --> Input Class Initialized
INFO - 2021-08-09 05:05:46 --> Language Class Initialized
INFO - 2021-08-09 05:05:46 --> Language Class Initialized
INFO - 2021-08-09 05:05:46 --> Config Class Initialized
INFO - 2021-08-09 05:05:46 --> Loader Class Initialized
INFO - 2021-08-09 05:05:46 --> Helper loaded: url_helper
INFO - 2021-08-09 05:05:46 --> Helper loaded: file_helper
INFO - 2021-08-09 05:05:46 --> Helper loaded: form_helper
INFO - 2021-08-09 05:05:46 --> Helper loaded: my_helper
INFO - 2021-08-09 05:05:46 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:05:46 --> Controller Class Initialized
DEBUG - 2021-08-09 05:05:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:05:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:05:46 --> Final output sent to browser
DEBUG - 2021-08-09 05:05:46 --> Total execution time: 0.0824
INFO - 2021-08-09 05:06:04 --> Config Class Initialized
INFO - 2021-08-09 05:06:04 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:06:04 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:06:04 --> Utf8 Class Initialized
INFO - 2021-08-09 05:06:04 --> URI Class Initialized
INFO - 2021-08-09 05:06:04 --> Router Class Initialized
INFO - 2021-08-09 05:06:04 --> Output Class Initialized
INFO - 2021-08-09 05:06:04 --> Security Class Initialized
DEBUG - 2021-08-09 05:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:06:04 --> Input Class Initialized
INFO - 2021-08-09 05:06:04 --> Language Class Initialized
INFO - 2021-08-09 05:06:04 --> Language Class Initialized
INFO - 2021-08-09 05:06:04 --> Config Class Initialized
INFO - 2021-08-09 05:06:04 --> Loader Class Initialized
INFO - 2021-08-09 05:06:04 --> Helper loaded: url_helper
INFO - 2021-08-09 05:06:04 --> Helper loaded: file_helper
INFO - 2021-08-09 05:06:04 --> Helper loaded: form_helper
INFO - 2021-08-09 05:06:04 --> Helper loaded: my_helper
INFO - 2021-08-09 05:06:04 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:06:04 --> Controller Class Initialized
INFO - 2021-08-09 05:06:04 --> Config Class Initialized
INFO - 2021-08-09 05:06:04 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:06:04 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:06:04 --> Utf8 Class Initialized
INFO - 2021-08-09 05:06:04 --> URI Class Initialized
INFO - 2021-08-09 05:06:04 --> Router Class Initialized
INFO - 2021-08-09 05:06:04 --> Output Class Initialized
INFO - 2021-08-09 05:06:04 --> Security Class Initialized
DEBUG - 2021-08-09 05:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:06:04 --> Input Class Initialized
INFO - 2021-08-09 05:06:04 --> Language Class Initialized
INFO - 2021-08-09 05:06:04 --> Language Class Initialized
INFO - 2021-08-09 05:06:04 --> Config Class Initialized
INFO - 2021-08-09 05:06:04 --> Loader Class Initialized
INFO - 2021-08-09 05:06:04 --> Helper loaded: url_helper
INFO - 2021-08-09 05:06:04 --> Helper loaded: file_helper
INFO - 2021-08-09 05:06:04 --> Helper loaded: form_helper
INFO - 2021-08-09 05:06:04 --> Helper loaded: my_helper
INFO - 2021-08-09 05:06:04 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:06:04 --> Controller Class Initialized
DEBUG - 2021-08-09 05:06:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:06:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:06:04 --> Final output sent to browser
DEBUG - 2021-08-09 05:06:04 --> Total execution time: 0.0767
INFO - 2021-08-09 05:06:05 --> Config Class Initialized
INFO - 2021-08-09 05:06:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:06:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:06:05 --> Utf8 Class Initialized
INFO - 2021-08-09 05:06:05 --> URI Class Initialized
INFO - 2021-08-09 05:06:05 --> Router Class Initialized
INFO - 2021-08-09 05:06:05 --> Output Class Initialized
INFO - 2021-08-09 05:06:05 --> Security Class Initialized
DEBUG - 2021-08-09 05:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:06:05 --> Input Class Initialized
INFO - 2021-08-09 05:06:05 --> Language Class Initialized
INFO - 2021-08-09 05:06:05 --> Language Class Initialized
INFO - 2021-08-09 05:06:05 --> Config Class Initialized
INFO - 2021-08-09 05:06:05 --> Loader Class Initialized
INFO - 2021-08-09 05:06:05 --> Helper loaded: url_helper
INFO - 2021-08-09 05:06:05 --> Helper loaded: file_helper
INFO - 2021-08-09 05:06:05 --> Helper loaded: form_helper
INFO - 2021-08-09 05:06:05 --> Helper loaded: my_helper
INFO - 2021-08-09 05:06:05 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:06:05 --> Controller Class Initialized
DEBUG - 2021-08-09 05:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:06:05 --> Final output sent to browser
DEBUG - 2021-08-09 05:06:05 --> Total execution time: 0.0629
INFO - 2021-08-09 05:08:38 --> Config Class Initialized
INFO - 2021-08-09 05:08:38 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:08:38 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:08:38 --> Utf8 Class Initialized
INFO - 2021-08-09 05:08:38 --> URI Class Initialized
INFO - 2021-08-09 05:08:38 --> Router Class Initialized
INFO - 2021-08-09 05:08:38 --> Output Class Initialized
INFO - 2021-08-09 05:08:38 --> Security Class Initialized
DEBUG - 2021-08-09 05:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:08:38 --> Input Class Initialized
INFO - 2021-08-09 05:08:38 --> Language Class Initialized
INFO - 2021-08-09 05:08:38 --> Language Class Initialized
INFO - 2021-08-09 05:08:38 --> Config Class Initialized
INFO - 2021-08-09 05:08:38 --> Loader Class Initialized
INFO - 2021-08-09 05:08:38 --> Helper loaded: url_helper
INFO - 2021-08-09 05:08:38 --> Helper loaded: file_helper
INFO - 2021-08-09 05:08:38 --> Helper loaded: form_helper
INFO - 2021-08-09 05:08:38 --> Helper loaded: my_helper
INFO - 2021-08-09 05:08:38 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:08:38 --> Controller Class Initialized
DEBUG - 2021-08-09 05:08:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:08:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:08:38 --> Final output sent to browser
DEBUG - 2021-08-09 05:08:38 --> Total execution time: 0.0868
INFO - 2021-08-09 05:08:42 --> Config Class Initialized
INFO - 2021-08-09 05:08:42 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:08:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:08:42 --> Utf8 Class Initialized
INFO - 2021-08-09 05:08:42 --> URI Class Initialized
INFO - 2021-08-09 05:08:42 --> Router Class Initialized
INFO - 2021-08-09 05:08:42 --> Output Class Initialized
INFO - 2021-08-09 05:08:42 --> Security Class Initialized
DEBUG - 2021-08-09 05:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:08:42 --> Input Class Initialized
INFO - 2021-08-09 05:08:42 --> Language Class Initialized
INFO - 2021-08-09 05:08:42 --> Language Class Initialized
INFO - 2021-08-09 05:08:42 --> Config Class Initialized
INFO - 2021-08-09 05:08:42 --> Loader Class Initialized
INFO - 2021-08-09 05:08:42 --> Helper loaded: url_helper
INFO - 2021-08-09 05:08:42 --> Helper loaded: file_helper
INFO - 2021-08-09 05:08:42 --> Helper loaded: form_helper
INFO - 2021-08-09 05:08:42 --> Helper loaded: my_helper
INFO - 2021-08-09 05:08:42 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:08:42 --> Controller Class Initialized
ERROR - 2021-08-09 05:08:42 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '99' AND tasm = '20212'
INFO - 2021-08-09 05:08:42 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 05:08:44 --> Config Class Initialized
INFO - 2021-08-09 05:08:44 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:08:44 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:08:44 --> Utf8 Class Initialized
INFO - 2021-08-09 05:08:44 --> URI Class Initialized
INFO - 2021-08-09 05:08:44 --> Router Class Initialized
INFO - 2021-08-09 05:08:44 --> Output Class Initialized
INFO - 2021-08-09 05:08:44 --> Security Class Initialized
DEBUG - 2021-08-09 05:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:08:44 --> Input Class Initialized
INFO - 2021-08-09 05:08:44 --> Language Class Initialized
INFO - 2021-08-09 05:08:44 --> Language Class Initialized
INFO - 2021-08-09 05:08:44 --> Config Class Initialized
INFO - 2021-08-09 05:08:44 --> Loader Class Initialized
INFO - 2021-08-09 05:08:44 --> Helper loaded: url_helper
INFO - 2021-08-09 05:08:44 --> Helper loaded: file_helper
INFO - 2021-08-09 05:08:44 --> Helper loaded: form_helper
INFO - 2021-08-09 05:08:44 --> Helper loaded: my_helper
INFO - 2021-08-09 05:08:44 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:08:44 --> Controller Class Initialized
DEBUG - 2021-08-09 05:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:08:44 --> Final output sent to browser
DEBUG - 2021-08-09 05:08:44 --> Total execution time: 0.0759
INFO - 2021-08-09 05:08:53 --> Config Class Initialized
INFO - 2021-08-09 05:08:53 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:08:53 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:08:53 --> Utf8 Class Initialized
INFO - 2021-08-09 05:08:53 --> URI Class Initialized
INFO - 2021-08-09 05:08:53 --> Router Class Initialized
INFO - 2021-08-09 05:08:53 --> Output Class Initialized
INFO - 2021-08-09 05:08:53 --> Security Class Initialized
DEBUG - 2021-08-09 05:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:08:53 --> Input Class Initialized
INFO - 2021-08-09 05:08:53 --> Language Class Initialized
INFO - 2021-08-09 05:08:53 --> Language Class Initialized
INFO - 2021-08-09 05:08:53 --> Config Class Initialized
INFO - 2021-08-09 05:08:53 --> Loader Class Initialized
INFO - 2021-08-09 05:08:53 --> Helper loaded: url_helper
INFO - 2021-08-09 05:08:53 --> Helper loaded: file_helper
INFO - 2021-08-09 05:08:53 --> Helper loaded: form_helper
INFO - 2021-08-09 05:08:53 --> Helper loaded: my_helper
INFO - 2021-08-09 05:08:53 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:08:53 --> Controller Class Initialized
DEBUG - 2021-08-09 05:08:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:08:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:08:53 --> Final output sent to browser
DEBUG - 2021-08-09 05:08:53 --> Total execution time: 0.0750
INFO - 2021-08-09 05:09:11 --> Config Class Initialized
INFO - 2021-08-09 05:09:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:09:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:09:11 --> Utf8 Class Initialized
INFO - 2021-08-09 05:09:11 --> URI Class Initialized
INFO - 2021-08-09 05:09:11 --> Router Class Initialized
INFO - 2021-08-09 05:09:11 --> Output Class Initialized
INFO - 2021-08-09 05:09:11 --> Security Class Initialized
DEBUG - 2021-08-09 05:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:09:11 --> Input Class Initialized
INFO - 2021-08-09 05:09:11 --> Language Class Initialized
INFO - 2021-08-09 05:09:11 --> Language Class Initialized
INFO - 2021-08-09 05:09:11 --> Config Class Initialized
INFO - 2021-08-09 05:09:11 --> Loader Class Initialized
INFO - 2021-08-09 05:09:11 --> Helper loaded: url_helper
INFO - 2021-08-09 05:09:11 --> Helper loaded: file_helper
INFO - 2021-08-09 05:09:11 --> Helper loaded: form_helper
INFO - 2021-08-09 05:09:11 --> Helper loaded: my_helper
INFO - 2021-08-09 05:09:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:09:11 --> Controller Class Initialized
INFO - 2021-08-09 05:09:11 --> Config Class Initialized
INFO - 2021-08-09 05:09:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:09:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:09:11 --> Utf8 Class Initialized
INFO - 2021-08-09 05:09:11 --> URI Class Initialized
INFO - 2021-08-09 05:09:11 --> Router Class Initialized
INFO - 2021-08-09 05:09:11 --> Output Class Initialized
INFO - 2021-08-09 05:09:11 --> Security Class Initialized
DEBUG - 2021-08-09 05:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:09:11 --> Input Class Initialized
INFO - 2021-08-09 05:09:11 --> Language Class Initialized
INFO - 2021-08-09 05:09:11 --> Language Class Initialized
INFO - 2021-08-09 05:09:11 --> Config Class Initialized
INFO - 2021-08-09 05:09:11 --> Loader Class Initialized
INFO - 2021-08-09 05:09:11 --> Helper loaded: url_helper
INFO - 2021-08-09 05:09:11 --> Helper loaded: file_helper
INFO - 2021-08-09 05:09:11 --> Helper loaded: form_helper
INFO - 2021-08-09 05:09:11 --> Helper loaded: my_helper
INFO - 2021-08-09 05:09:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:09:11 --> Controller Class Initialized
DEBUG - 2021-08-09 05:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:09:11 --> Final output sent to browser
DEBUG - 2021-08-09 05:09:11 --> Total execution time: 0.0672
INFO - 2021-08-09 05:09:40 --> Config Class Initialized
INFO - 2021-08-09 05:09:40 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:09:40 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:09:40 --> Utf8 Class Initialized
INFO - 2021-08-09 05:09:40 --> URI Class Initialized
INFO - 2021-08-09 05:09:40 --> Router Class Initialized
INFO - 2021-08-09 05:09:40 --> Output Class Initialized
INFO - 2021-08-09 05:09:40 --> Security Class Initialized
DEBUG - 2021-08-09 05:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:09:40 --> Input Class Initialized
INFO - 2021-08-09 05:09:40 --> Language Class Initialized
INFO - 2021-08-09 05:09:40 --> Language Class Initialized
INFO - 2021-08-09 05:09:40 --> Config Class Initialized
INFO - 2021-08-09 05:09:40 --> Loader Class Initialized
INFO - 2021-08-09 05:09:40 --> Helper loaded: url_helper
INFO - 2021-08-09 05:09:40 --> Helper loaded: file_helper
INFO - 2021-08-09 05:09:40 --> Helper loaded: form_helper
INFO - 2021-08-09 05:09:40 --> Helper loaded: my_helper
INFO - 2021-08-09 05:09:40 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:09:40 --> Controller Class Initialized
DEBUG - 2021-08-09 05:09:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:09:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:09:40 --> Final output sent to browser
DEBUG - 2021-08-09 05:09:40 --> Total execution time: 0.0835
INFO - 2021-08-09 05:09:54 --> Config Class Initialized
INFO - 2021-08-09 05:09:54 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:09:54 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:09:54 --> Utf8 Class Initialized
INFO - 2021-08-09 05:09:54 --> URI Class Initialized
INFO - 2021-08-09 05:09:54 --> Router Class Initialized
INFO - 2021-08-09 05:09:54 --> Output Class Initialized
INFO - 2021-08-09 05:09:54 --> Security Class Initialized
DEBUG - 2021-08-09 05:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:09:54 --> Input Class Initialized
INFO - 2021-08-09 05:09:54 --> Language Class Initialized
INFO - 2021-08-09 05:09:54 --> Language Class Initialized
INFO - 2021-08-09 05:09:54 --> Config Class Initialized
INFO - 2021-08-09 05:09:54 --> Loader Class Initialized
INFO - 2021-08-09 05:09:54 --> Helper loaded: url_helper
INFO - 2021-08-09 05:09:54 --> Helper loaded: file_helper
INFO - 2021-08-09 05:09:54 --> Helper loaded: form_helper
INFO - 2021-08-09 05:09:54 --> Helper loaded: my_helper
INFO - 2021-08-09 05:09:54 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:09:54 --> Controller Class Initialized
INFO - 2021-08-09 05:09:54 --> Config Class Initialized
INFO - 2021-08-09 05:09:54 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:09:54 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:09:54 --> Utf8 Class Initialized
INFO - 2021-08-09 05:09:54 --> URI Class Initialized
INFO - 2021-08-09 05:09:54 --> Router Class Initialized
INFO - 2021-08-09 05:09:54 --> Output Class Initialized
INFO - 2021-08-09 05:09:54 --> Security Class Initialized
DEBUG - 2021-08-09 05:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:09:54 --> Input Class Initialized
INFO - 2021-08-09 05:09:54 --> Language Class Initialized
INFO - 2021-08-09 05:09:54 --> Language Class Initialized
INFO - 2021-08-09 05:09:54 --> Config Class Initialized
INFO - 2021-08-09 05:09:54 --> Loader Class Initialized
INFO - 2021-08-09 05:09:54 --> Helper loaded: url_helper
INFO - 2021-08-09 05:09:54 --> Helper loaded: file_helper
INFO - 2021-08-09 05:09:54 --> Helper loaded: form_helper
INFO - 2021-08-09 05:09:54 --> Helper loaded: my_helper
INFO - 2021-08-09 05:09:54 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:09:54 --> Controller Class Initialized
DEBUG - 2021-08-09 05:09:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:09:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:09:54 --> Final output sent to browser
DEBUG - 2021-08-09 05:09:54 --> Total execution time: 0.0976
INFO - 2021-08-09 05:10:11 --> Config Class Initialized
INFO - 2021-08-09 05:10:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:10:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:10:11 --> Utf8 Class Initialized
INFO - 2021-08-09 05:10:11 --> URI Class Initialized
INFO - 2021-08-09 05:10:11 --> Router Class Initialized
INFO - 2021-08-09 05:10:11 --> Output Class Initialized
INFO - 2021-08-09 05:10:11 --> Security Class Initialized
DEBUG - 2021-08-09 05:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:10:11 --> Input Class Initialized
INFO - 2021-08-09 05:10:11 --> Language Class Initialized
INFO - 2021-08-09 05:10:11 --> Language Class Initialized
INFO - 2021-08-09 05:10:11 --> Config Class Initialized
INFO - 2021-08-09 05:10:11 --> Loader Class Initialized
INFO - 2021-08-09 05:10:11 --> Helper loaded: url_helper
INFO - 2021-08-09 05:10:11 --> Helper loaded: file_helper
INFO - 2021-08-09 05:10:11 --> Helper loaded: form_helper
INFO - 2021-08-09 05:10:11 --> Helper loaded: my_helper
INFO - 2021-08-09 05:10:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:10:11 --> Controller Class Initialized
DEBUG - 2021-08-09 05:10:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 05:10:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:10:11 --> Final output sent to browser
DEBUG - 2021-08-09 05:10:11 --> Total execution time: 0.0779
INFO - 2021-08-09 05:29:38 --> Config Class Initialized
INFO - 2021-08-09 05:29:38 --> Hooks Class Initialized
DEBUG - 2021-08-09 05:29:38 --> UTF-8 Support Enabled
INFO - 2021-08-09 05:29:38 --> Utf8 Class Initialized
INFO - 2021-08-09 05:29:38 --> URI Class Initialized
INFO - 2021-08-09 05:29:38 --> Router Class Initialized
INFO - 2021-08-09 05:29:38 --> Output Class Initialized
INFO - 2021-08-09 05:29:38 --> Security Class Initialized
DEBUG - 2021-08-09 05:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 05:29:38 --> Input Class Initialized
INFO - 2021-08-09 05:29:38 --> Language Class Initialized
INFO - 2021-08-09 05:29:38 --> Language Class Initialized
INFO - 2021-08-09 05:29:38 --> Config Class Initialized
INFO - 2021-08-09 05:29:38 --> Loader Class Initialized
INFO - 2021-08-09 05:29:38 --> Helper loaded: url_helper
INFO - 2021-08-09 05:29:38 --> Helper loaded: file_helper
INFO - 2021-08-09 05:29:38 --> Helper loaded: form_helper
INFO - 2021-08-09 05:29:38 --> Helper loaded: my_helper
INFO - 2021-08-09 05:29:38 --> Database Driver Class Initialized
DEBUG - 2021-08-09 05:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 05:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 05:29:38 --> Controller Class Initialized
DEBUG - 2021-08-09 05:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 05:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 05:29:38 --> Final output sent to browser
DEBUG - 2021-08-09 05:29:38 --> Total execution time: 0.0693
INFO - 2021-08-09 06:25:02 --> Config Class Initialized
INFO - 2021-08-09 06:25:02 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:25:02 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:25:02 --> Utf8 Class Initialized
INFO - 2021-08-09 06:25:02 --> URI Class Initialized
INFO - 2021-08-09 06:25:02 --> Router Class Initialized
INFO - 2021-08-09 06:25:02 --> Output Class Initialized
INFO - 2021-08-09 06:25:02 --> Security Class Initialized
DEBUG - 2021-08-09 06:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:25:02 --> Input Class Initialized
INFO - 2021-08-09 06:25:02 --> Language Class Initialized
INFO - 2021-08-09 06:25:02 --> Language Class Initialized
INFO - 2021-08-09 06:25:02 --> Config Class Initialized
INFO - 2021-08-09 06:25:02 --> Loader Class Initialized
INFO - 2021-08-09 06:25:02 --> Helper loaded: url_helper
INFO - 2021-08-09 06:25:02 --> Helper loaded: file_helper
INFO - 2021-08-09 06:25:02 --> Helper loaded: form_helper
INFO - 2021-08-09 06:25:02 --> Helper loaded: my_helper
INFO - 2021-08-09 06:25:02 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:25:02 --> Controller Class Initialized
DEBUG - 2021-08-09 06:25:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:25:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:25:02 --> Final output sent to browser
DEBUG - 2021-08-09 06:25:02 --> Total execution time: 0.0829
INFO - 2021-08-09 06:25:31 --> Config Class Initialized
INFO - 2021-08-09 06:25:31 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:25:31 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:25:31 --> Utf8 Class Initialized
INFO - 2021-08-09 06:25:31 --> URI Class Initialized
INFO - 2021-08-09 06:25:31 --> Router Class Initialized
INFO - 2021-08-09 06:25:31 --> Output Class Initialized
INFO - 2021-08-09 06:25:31 --> Security Class Initialized
DEBUG - 2021-08-09 06:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:25:31 --> Input Class Initialized
INFO - 2021-08-09 06:25:31 --> Language Class Initialized
INFO - 2021-08-09 06:25:31 --> Language Class Initialized
INFO - 2021-08-09 06:25:31 --> Config Class Initialized
INFO - 2021-08-09 06:25:31 --> Loader Class Initialized
INFO - 2021-08-09 06:25:31 --> Helper loaded: url_helper
INFO - 2021-08-09 06:25:31 --> Helper loaded: file_helper
INFO - 2021-08-09 06:25:31 --> Helper loaded: form_helper
INFO - 2021-08-09 06:25:31 --> Helper loaded: my_helper
INFO - 2021-08-09 06:25:31 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:25:31 --> Controller Class Initialized
DEBUG - 2021-08-09 06:25:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:25:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:25:31 --> Final output sent to browser
DEBUG - 2021-08-09 06:25:31 --> Total execution time: 0.0780
INFO - 2021-08-09 06:25:59 --> Config Class Initialized
INFO - 2021-08-09 06:25:59 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:25:59 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:25:59 --> Utf8 Class Initialized
INFO - 2021-08-09 06:25:59 --> URI Class Initialized
INFO - 2021-08-09 06:25:59 --> Router Class Initialized
INFO - 2021-08-09 06:25:59 --> Output Class Initialized
INFO - 2021-08-09 06:25:59 --> Security Class Initialized
DEBUG - 2021-08-09 06:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:25:59 --> Input Class Initialized
INFO - 2021-08-09 06:25:59 --> Language Class Initialized
INFO - 2021-08-09 06:25:59 --> Language Class Initialized
INFO - 2021-08-09 06:25:59 --> Config Class Initialized
INFO - 2021-08-09 06:25:59 --> Loader Class Initialized
INFO - 2021-08-09 06:25:59 --> Helper loaded: url_helper
INFO - 2021-08-09 06:25:59 --> Helper loaded: file_helper
INFO - 2021-08-09 06:25:59 --> Helper loaded: form_helper
INFO - 2021-08-09 06:25:59 --> Helper loaded: my_helper
INFO - 2021-08-09 06:25:59 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:25:59 --> Controller Class Initialized
DEBUG - 2021-08-09 06:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:25:59 --> Final output sent to browser
DEBUG - 2021-08-09 06:25:59 --> Total execution time: 0.0785
INFO - 2021-08-09 06:26:09 --> Config Class Initialized
INFO - 2021-08-09 06:26:09 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:26:09 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:26:09 --> Utf8 Class Initialized
INFO - 2021-08-09 06:26:09 --> URI Class Initialized
INFO - 2021-08-09 06:26:09 --> Router Class Initialized
INFO - 2021-08-09 06:26:09 --> Output Class Initialized
INFO - 2021-08-09 06:26:09 --> Security Class Initialized
DEBUG - 2021-08-09 06:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:26:09 --> Input Class Initialized
INFO - 2021-08-09 06:26:09 --> Language Class Initialized
INFO - 2021-08-09 06:26:09 --> Language Class Initialized
INFO - 2021-08-09 06:26:09 --> Config Class Initialized
INFO - 2021-08-09 06:26:09 --> Loader Class Initialized
INFO - 2021-08-09 06:26:09 --> Helper loaded: url_helper
INFO - 2021-08-09 06:26:09 --> Helper loaded: file_helper
INFO - 2021-08-09 06:26:09 --> Helper loaded: form_helper
INFO - 2021-08-09 06:26:09 --> Helper loaded: my_helper
INFO - 2021-08-09 06:26:09 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:26:09 --> Controller Class Initialized
INFO - 2021-08-09 06:26:09 --> Config Class Initialized
INFO - 2021-08-09 06:26:09 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:26:09 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:26:09 --> Utf8 Class Initialized
INFO - 2021-08-09 06:26:09 --> URI Class Initialized
INFO - 2021-08-09 06:26:09 --> Router Class Initialized
INFO - 2021-08-09 06:26:09 --> Output Class Initialized
INFO - 2021-08-09 06:26:09 --> Security Class Initialized
DEBUG - 2021-08-09 06:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:26:09 --> Input Class Initialized
INFO - 2021-08-09 06:26:09 --> Language Class Initialized
INFO - 2021-08-09 06:26:09 --> Language Class Initialized
INFO - 2021-08-09 06:26:09 --> Config Class Initialized
INFO - 2021-08-09 06:26:09 --> Loader Class Initialized
INFO - 2021-08-09 06:26:09 --> Helper loaded: url_helper
INFO - 2021-08-09 06:26:09 --> Helper loaded: file_helper
INFO - 2021-08-09 06:26:09 --> Helper loaded: form_helper
INFO - 2021-08-09 06:26:09 --> Helper loaded: my_helper
INFO - 2021-08-09 06:26:09 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:26:10 --> Controller Class Initialized
DEBUG - 2021-08-09 06:26:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:26:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:26:10 --> Final output sent to browser
DEBUG - 2021-08-09 06:26:10 --> Total execution time: 0.0752
INFO - 2021-08-09 06:26:14 --> Config Class Initialized
INFO - 2021-08-09 06:26:14 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:26:14 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:26:14 --> Utf8 Class Initialized
INFO - 2021-08-09 06:26:14 --> URI Class Initialized
INFO - 2021-08-09 06:26:14 --> Router Class Initialized
INFO - 2021-08-09 06:26:14 --> Output Class Initialized
INFO - 2021-08-09 06:26:14 --> Security Class Initialized
DEBUG - 2021-08-09 06:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:26:14 --> Input Class Initialized
INFO - 2021-08-09 06:26:14 --> Language Class Initialized
INFO - 2021-08-09 06:26:14 --> Language Class Initialized
INFO - 2021-08-09 06:26:14 --> Config Class Initialized
INFO - 2021-08-09 06:26:14 --> Loader Class Initialized
INFO - 2021-08-09 06:26:14 --> Helper loaded: url_helper
INFO - 2021-08-09 06:26:14 --> Helper loaded: file_helper
INFO - 2021-08-09 06:26:14 --> Helper loaded: form_helper
INFO - 2021-08-09 06:26:14 --> Helper loaded: my_helper
INFO - 2021-08-09 06:26:14 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:26:14 --> Controller Class Initialized
DEBUG - 2021-08-09 06:26:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:26:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:26:14 --> Final output sent to browser
DEBUG - 2021-08-09 06:26:14 --> Total execution time: 0.0880
INFO - 2021-08-09 06:26:33 --> Config Class Initialized
INFO - 2021-08-09 06:26:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:26:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:26:33 --> Utf8 Class Initialized
INFO - 2021-08-09 06:26:33 --> URI Class Initialized
INFO - 2021-08-09 06:26:33 --> Router Class Initialized
INFO - 2021-08-09 06:26:33 --> Output Class Initialized
INFO - 2021-08-09 06:26:33 --> Security Class Initialized
DEBUG - 2021-08-09 06:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:26:33 --> Input Class Initialized
INFO - 2021-08-09 06:26:33 --> Language Class Initialized
INFO - 2021-08-09 06:26:33 --> Language Class Initialized
INFO - 2021-08-09 06:26:33 --> Config Class Initialized
INFO - 2021-08-09 06:26:33 --> Loader Class Initialized
INFO - 2021-08-09 06:26:33 --> Helper loaded: url_helper
INFO - 2021-08-09 06:26:33 --> Helper loaded: file_helper
INFO - 2021-08-09 06:26:33 --> Helper loaded: form_helper
INFO - 2021-08-09 06:26:33 --> Helper loaded: my_helper
INFO - 2021-08-09 06:26:33 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:26:33 --> Controller Class Initialized
INFO - 2021-08-09 06:26:33 --> Config Class Initialized
INFO - 2021-08-09 06:26:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:26:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:26:33 --> Utf8 Class Initialized
INFO - 2021-08-09 06:26:33 --> URI Class Initialized
INFO - 2021-08-09 06:26:33 --> Router Class Initialized
INFO - 2021-08-09 06:26:33 --> Output Class Initialized
INFO - 2021-08-09 06:26:33 --> Security Class Initialized
DEBUG - 2021-08-09 06:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:26:33 --> Input Class Initialized
INFO - 2021-08-09 06:26:33 --> Language Class Initialized
INFO - 2021-08-09 06:26:33 --> Language Class Initialized
INFO - 2021-08-09 06:26:33 --> Config Class Initialized
INFO - 2021-08-09 06:26:33 --> Loader Class Initialized
INFO - 2021-08-09 06:26:33 --> Helper loaded: url_helper
INFO - 2021-08-09 06:26:33 --> Helper loaded: file_helper
INFO - 2021-08-09 06:26:33 --> Helper loaded: form_helper
INFO - 2021-08-09 06:26:33 --> Helper loaded: my_helper
INFO - 2021-08-09 06:26:33 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:26:33 --> Controller Class Initialized
DEBUG - 2021-08-09 06:26:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:26:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:26:33 --> Final output sent to browser
DEBUG - 2021-08-09 06:26:33 --> Total execution time: 0.1037
INFO - 2021-08-09 06:26:36 --> Config Class Initialized
INFO - 2021-08-09 06:26:36 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:26:36 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:26:36 --> Utf8 Class Initialized
INFO - 2021-08-09 06:26:36 --> URI Class Initialized
INFO - 2021-08-09 06:26:36 --> Router Class Initialized
INFO - 2021-08-09 06:26:36 --> Output Class Initialized
INFO - 2021-08-09 06:26:36 --> Security Class Initialized
DEBUG - 2021-08-09 06:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:26:36 --> Input Class Initialized
INFO - 2021-08-09 06:26:36 --> Language Class Initialized
INFO - 2021-08-09 06:26:36 --> Language Class Initialized
INFO - 2021-08-09 06:26:36 --> Config Class Initialized
INFO - 2021-08-09 06:26:36 --> Loader Class Initialized
INFO - 2021-08-09 06:26:36 --> Helper loaded: url_helper
INFO - 2021-08-09 06:26:36 --> Helper loaded: file_helper
INFO - 2021-08-09 06:26:36 --> Helper loaded: form_helper
INFO - 2021-08-09 06:26:36 --> Helper loaded: my_helper
INFO - 2021-08-09 06:26:36 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:26:37 --> Controller Class Initialized
DEBUG - 2021-08-09 06:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:26:37 --> Final output sent to browser
DEBUG - 2021-08-09 06:26:37 --> Total execution time: 0.0846
INFO - 2021-08-09 06:26:40 --> Config Class Initialized
INFO - 2021-08-09 06:26:40 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:26:40 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:26:40 --> Utf8 Class Initialized
INFO - 2021-08-09 06:26:40 --> URI Class Initialized
INFO - 2021-08-09 06:26:40 --> Router Class Initialized
INFO - 2021-08-09 06:26:40 --> Output Class Initialized
INFO - 2021-08-09 06:26:40 --> Security Class Initialized
DEBUG - 2021-08-09 06:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:26:40 --> Input Class Initialized
INFO - 2021-08-09 06:26:40 --> Language Class Initialized
INFO - 2021-08-09 06:26:40 --> Language Class Initialized
INFO - 2021-08-09 06:26:40 --> Config Class Initialized
INFO - 2021-08-09 06:26:40 --> Loader Class Initialized
INFO - 2021-08-09 06:26:40 --> Helper loaded: url_helper
INFO - 2021-08-09 06:26:40 --> Helper loaded: file_helper
INFO - 2021-08-09 06:26:40 --> Helper loaded: form_helper
INFO - 2021-08-09 06:26:40 --> Helper loaded: my_helper
INFO - 2021-08-09 06:26:40 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:26:40 --> Controller Class Initialized
DEBUG - 2021-08-09 06:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:26:40 --> Final output sent to browser
DEBUG - 2021-08-09 06:26:40 --> Total execution time: 0.1030
INFO - 2021-08-09 06:26:43 --> Config Class Initialized
INFO - 2021-08-09 06:26:43 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:26:43 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:26:43 --> Utf8 Class Initialized
INFO - 2021-08-09 06:26:43 --> URI Class Initialized
INFO - 2021-08-09 06:26:43 --> Router Class Initialized
INFO - 2021-08-09 06:26:43 --> Output Class Initialized
INFO - 2021-08-09 06:26:43 --> Security Class Initialized
DEBUG - 2021-08-09 06:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:26:43 --> Input Class Initialized
INFO - 2021-08-09 06:26:43 --> Language Class Initialized
INFO - 2021-08-09 06:26:43 --> Language Class Initialized
INFO - 2021-08-09 06:26:43 --> Config Class Initialized
INFO - 2021-08-09 06:26:43 --> Loader Class Initialized
INFO - 2021-08-09 06:26:43 --> Helper loaded: url_helper
INFO - 2021-08-09 06:26:43 --> Helper loaded: file_helper
INFO - 2021-08-09 06:26:43 --> Helper loaded: form_helper
INFO - 2021-08-09 06:26:43 --> Helper loaded: my_helper
INFO - 2021-08-09 06:26:43 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:26:43 --> Controller Class Initialized
DEBUG - 2021-08-09 06:26:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:26:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:26:43 --> Final output sent to browser
DEBUG - 2021-08-09 06:26:43 --> Total execution time: 0.0717
INFO - 2021-08-09 06:26:55 --> Config Class Initialized
INFO - 2021-08-09 06:26:55 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:26:55 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:26:55 --> Utf8 Class Initialized
INFO - 2021-08-09 06:26:55 --> URI Class Initialized
INFO - 2021-08-09 06:26:55 --> Router Class Initialized
INFO - 2021-08-09 06:26:55 --> Output Class Initialized
INFO - 2021-08-09 06:26:55 --> Security Class Initialized
DEBUG - 2021-08-09 06:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:26:55 --> Input Class Initialized
INFO - 2021-08-09 06:26:55 --> Language Class Initialized
INFO - 2021-08-09 06:26:55 --> Language Class Initialized
INFO - 2021-08-09 06:26:55 --> Config Class Initialized
INFO - 2021-08-09 06:26:55 --> Loader Class Initialized
INFO - 2021-08-09 06:26:55 --> Helper loaded: url_helper
INFO - 2021-08-09 06:26:55 --> Helper loaded: file_helper
INFO - 2021-08-09 06:26:55 --> Helper loaded: form_helper
INFO - 2021-08-09 06:26:55 --> Helper loaded: my_helper
INFO - 2021-08-09 06:26:55 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:26:55 --> Controller Class Initialized
DEBUG - 2021-08-09 06:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:26:55 --> Final output sent to browser
DEBUG - 2021-08-09 06:26:55 --> Total execution time: 0.0819
INFO - 2021-08-09 06:27:13 --> Config Class Initialized
INFO - 2021-08-09 06:27:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:27:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:27:13 --> Utf8 Class Initialized
INFO - 2021-08-09 06:27:13 --> URI Class Initialized
INFO - 2021-08-09 06:27:13 --> Router Class Initialized
INFO - 2021-08-09 06:27:13 --> Output Class Initialized
INFO - 2021-08-09 06:27:13 --> Security Class Initialized
DEBUG - 2021-08-09 06:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:27:13 --> Input Class Initialized
INFO - 2021-08-09 06:27:13 --> Language Class Initialized
INFO - 2021-08-09 06:27:13 --> Language Class Initialized
INFO - 2021-08-09 06:27:13 --> Config Class Initialized
INFO - 2021-08-09 06:27:13 --> Loader Class Initialized
INFO - 2021-08-09 06:27:13 --> Helper loaded: url_helper
INFO - 2021-08-09 06:27:13 --> Helper loaded: file_helper
INFO - 2021-08-09 06:27:13 --> Helper loaded: form_helper
INFO - 2021-08-09 06:27:13 --> Helper loaded: my_helper
INFO - 2021-08-09 06:27:13 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:27:13 --> Controller Class Initialized
DEBUG - 2021-08-09 06:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:27:13 --> Final output sent to browser
DEBUG - 2021-08-09 06:27:13 --> Total execution time: 0.0806
INFO - 2021-08-09 06:27:57 --> Config Class Initialized
INFO - 2021-08-09 06:27:57 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:27:57 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:27:57 --> Utf8 Class Initialized
INFO - 2021-08-09 06:27:57 --> URI Class Initialized
INFO - 2021-08-09 06:27:57 --> Router Class Initialized
INFO - 2021-08-09 06:27:57 --> Output Class Initialized
INFO - 2021-08-09 06:27:57 --> Security Class Initialized
DEBUG - 2021-08-09 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:27:57 --> Input Class Initialized
INFO - 2021-08-09 06:27:57 --> Language Class Initialized
INFO - 2021-08-09 06:27:57 --> Language Class Initialized
INFO - 2021-08-09 06:27:57 --> Config Class Initialized
INFO - 2021-08-09 06:27:57 --> Loader Class Initialized
INFO - 2021-08-09 06:27:57 --> Helper loaded: url_helper
INFO - 2021-08-09 06:27:57 --> Helper loaded: file_helper
INFO - 2021-08-09 06:27:57 --> Helper loaded: form_helper
INFO - 2021-08-09 06:27:57 --> Helper loaded: my_helper
INFO - 2021-08-09 06:27:57 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:27:57 --> Controller Class Initialized
DEBUG - 2021-08-09 06:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:27:57 --> Final output sent to browser
DEBUG - 2021-08-09 06:27:57 --> Total execution time: 0.0825
INFO - 2021-08-09 06:28:10 --> Config Class Initialized
INFO - 2021-08-09 06:28:10 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:28:10 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:28:10 --> Utf8 Class Initialized
INFO - 2021-08-09 06:28:10 --> URI Class Initialized
INFO - 2021-08-09 06:28:10 --> Router Class Initialized
INFO - 2021-08-09 06:28:10 --> Output Class Initialized
INFO - 2021-08-09 06:28:10 --> Security Class Initialized
DEBUG - 2021-08-09 06:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:28:10 --> Input Class Initialized
INFO - 2021-08-09 06:28:10 --> Language Class Initialized
INFO - 2021-08-09 06:28:10 --> Language Class Initialized
INFO - 2021-08-09 06:28:10 --> Config Class Initialized
INFO - 2021-08-09 06:28:10 --> Loader Class Initialized
INFO - 2021-08-09 06:28:10 --> Helper loaded: url_helper
INFO - 2021-08-09 06:28:10 --> Helper loaded: file_helper
INFO - 2021-08-09 06:28:10 --> Helper loaded: form_helper
INFO - 2021-08-09 06:28:10 --> Helper loaded: my_helper
INFO - 2021-08-09 06:28:10 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:28:10 --> Controller Class Initialized
DEBUG - 2021-08-09 06:28:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:28:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:28:10 --> Final output sent to browser
DEBUG - 2021-08-09 06:28:10 --> Total execution time: 0.0861
INFO - 2021-08-09 06:28:27 --> Config Class Initialized
INFO - 2021-08-09 06:28:27 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:28:27 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:28:27 --> Utf8 Class Initialized
INFO - 2021-08-09 06:28:27 --> URI Class Initialized
INFO - 2021-08-09 06:28:27 --> Router Class Initialized
INFO - 2021-08-09 06:28:27 --> Output Class Initialized
INFO - 2021-08-09 06:28:27 --> Security Class Initialized
DEBUG - 2021-08-09 06:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:28:27 --> Input Class Initialized
INFO - 2021-08-09 06:28:27 --> Language Class Initialized
INFO - 2021-08-09 06:28:27 --> Language Class Initialized
INFO - 2021-08-09 06:28:27 --> Config Class Initialized
INFO - 2021-08-09 06:28:27 --> Loader Class Initialized
INFO - 2021-08-09 06:28:27 --> Helper loaded: url_helper
INFO - 2021-08-09 06:28:27 --> Helper loaded: file_helper
INFO - 2021-08-09 06:28:27 --> Helper loaded: form_helper
INFO - 2021-08-09 06:28:27 --> Helper loaded: my_helper
INFO - 2021-08-09 06:28:27 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:28:27 --> Controller Class Initialized
INFO - 2021-08-09 06:28:27 --> Config Class Initialized
INFO - 2021-08-09 06:28:27 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:28:27 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:28:27 --> Utf8 Class Initialized
INFO - 2021-08-09 06:28:27 --> URI Class Initialized
INFO - 2021-08-09 06:28:27 --> Router Class Initialized
INFO - 2021-08-09 06:28:27 --> Output Class Initialized
INFO - 2021-08-09 06:28:27 --> Security Class Initialized
DEBUG - 2021-08-09 06:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:28:27 --> Input Class Initialized
INFO - 2021-08-09 06:28:27 --> Language Class Initialized
INFO - 2021-08-09 06:28:27 --> Language Class Initialized
INFO - 2021-08-09 06:28:27 --> Config Class Initialized
INFO - 2021-08-09 06:28:27 --> Loader Class Initialized
INFO - 2021-08-09 06:28:27 --> Helper loaded: url_helper
INFO - 2021-08-09 06:28:27 --> Helper loaded: file_helper
INFO - 2021-08-09 06:28:27 --> Helper loaded: form_helper
INFO - 2021-08-09 06:28:27 --> Helper loaded: my_helper
INFO - 2021-08-09 06:28:27 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:28:27 --> Controller Class Initialized
DEBUG - 2021-08-09 06:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:28:27 --> Final output sent to browser
DEBUG - 2021-08-09 06:28:27 --> Total execution time: 0.0716
INFO - 2021-08-09 06:28:35 --> Config Class Initialized
INFO - 2021-08-09 06:28:35 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:28:35 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:28:35 --> Utf8 Class Initialized
INFO - 2021-08-09 06:28:35 --> URI Class Initialized
INFO - 2021-08-09 06:28:35 --> Router Class Initialized
INFO - 2021-08-09 06:28:35 --> Output Class Initialized
INFO - 2021-08-09 06:28:35 --> Security Class Initialized
DEBUG - 2021-08-09 06:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:28:35 --> Input Class Initialized
INFO - 2021-08-09 06:28:35 --> Language Class Initialized
INFO - 2021-08-09 06:28:35 --> Language Class Initialized
INFO - 2021-08-09 06:28:35 --> Config Class Initialized
INFO - 2021-08-09 06:28:35 --> Loader Class Initialized
INFO - 2021-08-09 06:28:35 --> Helper loaded: url_helper
INFO - 2021-08-09 06:28:35 --> Helper loaded: file_helper
INFO - 2021-08-09 06:28:35 --> Helper loaded: form_helper
INFO - 2021-08-09 06:28:35 --> Helper loaded: my_helper
INFO - 2021-08-09 06:28:35 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:28:35 --> Controller Class Initialized
DEBUG - 2021-08-09 06:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:28:35 --> Final output sent to browser
DEBUG - 2021-08-09 06:28:35 --> Total execution time: 0.0853
INFO - 2021-08-09 06:28:55 --> Config Class Initialized
INFO - 2021-08-09 06:28:55 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:28:55 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:28:55 --> Utf8 Class Initialized
INFO - 2021-08-09 06:28:55 --> URI Class Initialized
INFO - 2021-08-09 06:28:55 --> Router Class Initialized
INFO - 2021-08-09 06:28:55 --> Output Class Initialized
INFO - 2021-08-09 06:28:55 --> Security Class Initialized
DEBUG - 2021-08-09 06:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:28:55 --> Input Class Initialized
INFO - 2021-08-09 06:28:55 --> Language Class Initialized
INFO - 2021-08-09 06:28:55 --> Language Class Initialized
INFO - 2021-08-09 06:28:55 --> Config Class Initialized
INFO - 2021-08-09 06:28:55 --> Loader Class Initialized
INFO - 2021-08-09 06:28:55 --> Helper loaded: url_helper
INFO - 2021-08-09 06:28:55 --> Helper loaded: file_helper
INFO - 2021-08-09 06:28:55 --> Helper loaded: form_helper
INFO - 2021-08-09 06:28:55 --> Helper loaded: my_helper
INFO - 2021-08-09 06:28:55 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:28:55 --> Controller Class Initialized
INFO - 2021-08-09 06:28:55 --> Config Class Initialized
INFO - 2021-08-09 06:28:55 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:28:55 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:28:55 --> Utf8 Class Initialized
INFO - 2021-08-09 06:28:55 --> URI Class Initialized
INFO - 2021-08-09 06:28:55 --> Router Class Initialized
INFO - 2021-08-09 06:28:55 --> Output Class Initialized
INFO - 2021-08-09 06:28:55 --> Security Class Initialized
DEBUG - 2021-08-09 06:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:28:55 --> Input Class Initialized
INFO - 2021-08-09 06:28:55 --> Language Class Initialized
INFO - 2021-08-09 06:28:55 --> Language Class Initialized
INFO - 2021-08-09 06:28:55 --> Config Class Initialized
INFO - 2021-08-09 06:28:55 --> Loader Class Initialized
INFO - 2021-08-09 06:28:55 --> Helper loaded: url_helper
INFO - 2021-08-09 06:28:55 --> Helper loaded: file_helper
INFO - 2021-08-09 06:28:55 --> Helper loaded: form_helper
INFO - 2021-08-09 06:28:55 --> Helper loaded: my_helper
INFO - 2021-08-09 06:28:55 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:28:55 --> Controller Class Initialized
DEBUG - 2021-08-09 06:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:28:55 --> Final output sent to browser
DEBUG - 2021-08-09 06:28:55 --> Total execution time: 0.0859
INFO - 2021-08-09 06:29:04 --> Config Class Initialized
INFO - 2021-08-09 06:29:04 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:29:04 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:29:04 --> Utf8 Class Initialized
INFO - 2021-08-09 06:29:04 --> URI Class Initialized
INFO - 2021-08-09 06:29:04 --> Router Class Initialized
INFO - 2021-08-09 06:29:04 --> Output Class Initialized
INFO - 2021-08-09 06:29:04 --> Security Class Initialized
DEBUG - 2021-08-09 06:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:29:04 --> Input Class Initialized
INFO - 2021-08-09 06:29:04 --> Language Class Initialized
INFO - 2021-08-09 06:29:04 --> Language Class Initialized
INFO - 2021-08-09 06:29:04 --> Config Class Initialized
INFO - 2021-08-09 06:29:04 --> Loader Class Initialized
INFO - 2021-08-09 06:29:04 --> Helper loaded: url_helper
INFO - 2021-08-09 06:29:04 --> Helper loaded: file_helper
INFO - 2021-08-09 06:29:04 --> Helper loaded: form_helper
INFO - 2021-08-09 06:29:04 --> Helper loaded: my_helper
INFO - 2021-08-09 06:29:04 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:29:04 --> Controller Class Initialized
DEBUG - 2021-08-09 06:29:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:29:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:29:04 --> Final output sent to browser
DEBUG - 2021-08-09 06:29:04 --> Total execution time: 0.0864
INFO - 2021-08-09 06:29:38 --> Config Class Initialized
INFO - 2021-08-09 06:29:38 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:29:38 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:29:38 --> Utf8 Class Initialized
INFO - 2021-08-09 06:29:38 --> URI Class Initialized
INFO - 2021-08-09 06:29:38 --> Router Class Initialized
INFO - 2021-08-09 06:29:38 --> Output Class Initialized
INFO - 2021-08-09 06:29:38 --> Security Class Initialized
DEBUG - 2021-08-09 06:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:29:38 --> Input Class Initialized
INFO - 2021-08-09 06:29:38 --> Language Class Initialized
INFO - 2021-08-09 06:29:38 --> Language Class Initialized
INFO - 2021-08-09 06:29:38 --> Config Class Initialized
INFO - 2021-08-09 06:29:38 --> Loader Class Initialized
INFO - 2021-08-09 06:29:38 --> Helper loaded: url_helper
INFO - 2021-08-09 06:29:38 --> Helper loaded: file_helper
INFO - 2021-08-09 06:29:38 --> Helper loaded: form_helper
INFO - 2021-08-09 06:29:38 --> Helper loaded: my_helper
INFO - 2021-08-09 06:29:38 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:29:38 --> Controller Class Initialized
DEBUG - 2021-08-09 06:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:29:38 --> Final output sent to browser
DEBUG - 2021-08-09 06:29:38 --> Total execution time: 0.0803
INFO - 2021-08-09 06:29:51 --> Config Class Initialized
INFO - 2021-08-09 06:29:51 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:29:51 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:29:51 --> Utf8 Class Initialized
INFO - 2021-08-09 06:29:51 --> URI Class Initialized
INFO - 2021-08-09 06:29:51 --> Router Class Initialized
INFO - 2021-08-09 06:29:51 --> Output Class Initialized
INFO - 2021-08-09 06:29:51 --> Security Class Initialized
DEBUG - 2021-08-09 06:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:29:51 --> Input Class Initialized
INFO - 2021-08-09 06:29:51 --> Language Class Initialized
INFO - 2021-08-09 06:29:51 --> Language Class Initialized
INFO - 2021-08-09 06:29:51 --> Config Class Initialized
INFO - 2021-08-09 06:29:51 --> Loader Class Initialized
INFO - 2021-08-09 06:29:51 --> Helper loaded: url_helper
INFO - 2021-08-09 06:29:51 --> Helper loaded: file_helper
INFO - 2021-08-09 06:29:51 --> Helper loaded: form_helper
INFO - 2021-08-09 06:29:51 --> Helper loaded: my_helper
INFO - 2021-08-09 06:29:51 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:29:51 --> Controller Class Initialized
DEBUG - 2021-08-09 06:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:29:51 --> Final output sent to browser
DEBUG - 2021-08-09 06:29:51 --> Total execution time: 0.0853
INFO - 2021-08-09 06:30:06 --> Config Class Initialized
INFO - 2021-08-09 06:30:06 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:30:06 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:30:06 --> Utf8 Class Initialized
INFO - 2021-08-09 06:30:06 --> URI Class Initialized
INFO - 2021-08-09 06:30:06 --> Router Class Initialized
INFO - 2021-08-09 06:30:06 --> Output Class Initialized
INFO - 2021-08-09 06:30:06 --> Security Class Initialized
DEBUG - 2021-08-09 06:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:30:06 --> Input Class Initialized
INFO - 2021-08-09 06:30:06 --> Language Class Initialized
INFO - 2021-08-09 06:30:06 --> Language Class Initialized
INFO - 2021-08-09 06:30:06 --> Config Class Initialized
INFO - 2021-08-09 06:30:06 --> Loader Class Initialized
INFO - 2021-08-09 06:30:06 --> Helper loaded: url_helper
INFO - 2021-08-09 06:30:06 --> Helper loaded: file_helper
INFO - 2021-08-09 06:30:06 --> Helper loaded: form_helper
INFO - 2021-08-09 06:30:06 --> Helper loaded: my_helper
INFO - 2021-08-09 06:30:06 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:30:06 --> Controller Class Initialized
INFO - 2021-08-09 06:30:06 --> Config Class Initialized
INFO - 2021-08-09 06:30:06 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:30:06 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:30:06 --> Utf8 Class Initialized
INFO - 2021-08-09 06:30:06 --> URI Class Initialized
INFO - 2021-08-09 06:30:06 --> Router Class Initialized
INFO - 2021-08-09 06:30:06 --> Output Class Initialized
INFO - 2021-08-09 06:30:06 --> Security Class Initialized
DEBUG - 2021-08-09 06:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:30:06 --> Input Class Initialized
INFO - 2021-08-09 06:30:06 --> Language Class Initialized
INFO - 2021-08-09 06:30:06 --> Language Class Initialized
INFO - 2021-08-09 06:30:06 --> Config Class Initialized
INFO - 2021-08-09 06:30:06 --> Loader Class Initialized
INFO - 2021-08-09 06:30:06 --> Helper loaded: url_helper
INFO - 2021-08-09 06:30:06 --> Helper loaded: file_helper
INFO - 2021-08-09 06:30:06 --> Helper loaded: form_helper
INFO - 2021-08-09 06:30:06 --> Helper loaded: my_helper
INFO - 2021-08-09 06:30:06 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:30:06 --> Controller Class Initialized
DEBUG - 2021-08-09 06:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:30:06 --> Final output sent to browser
DEBUG - 2021-08-09 06:30:06 --> Total execution time: 0.0620
INFO - 2021-08-09 06:30:10 --> Config Class Initialized
INFO - 2021-08-09 06:30:10 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:30:10 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:30:10 --> Utf8 Class Initialized
INFO - 2021-08-09 06:30:10 --> URI Class Initialized
INFO - 2021-08-09 06:30:10 --> Router Class Initialized
INFO - 2021-08-09 06:30:10 --> Output Class Initialized
INFO - 2021-08-09 06:30:10 --> Security Class Initialized
DEBUG - 2021-08-09 06:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:30:10 --> Input Class Initialized
INFO - 2021-08-09 06:30:10 --> Language Class Initialized
INFO - 2021-08-09 06:30:10 --> Language Class Initialized
INFO - 2021-08-09 06:30:10 --> Config Class Initialized
INFO - 2021-08-09 06:30:10 --> Loader Class Initialized
INFO - 2021-08-09 06:30:10 --> Helper loaded: url_helper
INFO - 2021-08-09 06:30:10 --> Helper loaded: file_helper
INFO - 2021-08-09 06:30:10 --> Helper loaded: form_helper
INFO - 2021-08-09 06:30:10 --> Helper loaded: my_helper
INFO - 2021-08-09 06:30:10 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:30:10 --> Controller Class Initialized
DEBUG - 2021-08-09 06:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:30:10 --> Final output sent to browser
DEBUG - 2021-08-09 06:30:10 --> Total execution time: 0.0868
INFO - 2021-08-09 06:30:42 --> Config Class Initialized
INFO - 2021-08-09 06:30:42 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:30:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:30:42 --> Utf8 Class Initialized
INFO - 2021-08-09 06:30:42 --> URI Class Initialized
INFO - 2021-08-09 06:30:42 --> Router Class Initialized
INFO - 2021-08-09 06:30:42 --> Output Class Initialized
INFO - 2021-08-09 06:30:42 --> Security Class Initialized
DEBUG - 2021-08-09 06:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:30:42 --> Input Class Initialized
INFO - 2021-08-09 06:30:42 --> Language Class Initialized
INFO - 2021-08-09 06:30:42 --> Language Class Initialized
INFO - 2021-08-09 06:30:42 --> Config Class Initialized
INFO - 2021-08-09 06:30:42 --> Loader Class Initialized
INFO - 2021-08-09 06:30:42 --> Helper loaded: url_helper
INFO - 2021-08-09 06:30:42 --> Helper loaded: file_helper
INFO - 2021-08-09 06:30:42 --> Helper loaded: form_helper
INFO - 2021-08-09 06:30:42 --> Helper loaded: my_helper
INFO - 2021-08-09 06:30:42 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:30:42 --> Controller Class Initialized
INFO - 2021-08-09 06:30:42 --> Config Class Initialized
INFO - 2021-08-09 06:30:42 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:30:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:30:42 --> Utf8 Class Initialized
INFO - 2021-08-09 06:30:42 --> URI Class Initialized
INFO - 2021-08-09 06:30:42 --> Router Class Initialized
INFO - 2021-08-09 06:30:42 --> Output Class Initialized
INFO - 2021-08-09 06:30:42 --> Security Class Initialized
DEBUG - 2021-08-09 06:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:30:42 --> Input Class Initialized
INFO - 2021-08-09 06:30:42 --> Language Class Initialized
INFO - 2021-08-09 06:30:42 --> Language Class Initialized
INFO - 2021-08-09 06:30:42 --> Config Class Initialized
INFO - 2021-08-09 06:30:42 --> Loader Class Initialized
INFO - 2021-08-09 06:30:42 --> Helper loaded: url_helper
INFO - 2021-08-09 06:30:42 --> Helper loaded: file_helper
INFO - 2021-08-09 06:30:42 --> Helper loaded: form_helper
INFO - 2021-08-09 06:30:42 --> Helper loaded: my_helper
INFO - 2021-08-09 06:30:42 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:30:42 --> Controller Class Initialized
DEBUG - 2021-08-09 06:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:30:42 --> Final output sent to browser
DEBUG - 2021-08-09 06:30:42 --> Total execution time: 0.0881
INFO - 2021-08-09 06:30:49 --> Config Class Initialized
INFO - 2021-08-09 06:30:49 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:30:49 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:30:49 --> Utf8 Class Initialized
INFO - 2021-08-09 06:30:49 --> URI Class Initialized
INFO - 2021-08-09 06:30:50 --> Router Class Initialized
INFO - 2021-08-09 06:30:50 --> Output Class Initialized
INFO - 2021-08-09 06:30:50 --> Security Class Initialized
DEBUG - 2021-08-09 06:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:30:50 --> Input Class Initialized
INFO - 2021-08-09 06:30:50 --> Language Class Initialized
INFO - 2021-08-09 06:30:50 --> Language Class Initialized
INFO - 2021-08-09 06:30:50 --> Config Class Initialized
INFO - 2021-08-09 06:30:50 --> Loader Class Initialized
INFO - 2021-08-09 06:30:50 --> Helper loaded: url_helper
INFO - 2021-08-09 06:30:50 --> Helper loaded: file_helper
INFO - 2021-08-09 06:30:50 --> Helper loaded: form_helper
INFO - 2021-08-09 06:30:50 --> Helper loaded: my_helper
INFO - 2021-08-09 06:30:50 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:30:50 --> Controller Class Initialized
DEBUG - 2021-08-09 06:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:30:50 --> Final output sent to browser
DEBUG - 2021-08-09 06:30:50 --> Total execution time: 0.0618
INFO - 2021-08-09 06:31:06 --> Config Class Initialized
INFO - 2021-08-09 06:31:06 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:31:06 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:31:06 --> Utf8 Class Initialized
INFO - 2021-08-09 06:31:06 --> URI Class Initialized
INFO - 2021-08-09 06:31:06 --> Router Class Initialized
INFO - 2021-08-09 06:31:06 --> Output Class Initialized
INFO - 2021-08-09 06:31:06 --> Security Class Initialized
DEBUG - 2021-08-09 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:31:06 --> Input Class Initialized
INFO - 2021-08-09 06:31:06 --> Language Class Initialized
INFO - 2021-08-09 06:31:06 --> Language Class Initialized
INFO - 2021-08-09 06:31:06 --> Config Class Initialized
INFO - 2021-08-09 06:31:06 --> Loader Class Initialized
INFO - 2021-08-09 06:31:06 --> Helper loaded: url_helper
INFO - 2021-08-09 06:31:06 --> Helper loaded: file_helper
INFO - 2021-08-09 06:31:06 --> Helper loaded: form_helper
INFO - 2021-08-09 06:31:06 --> Helper loaded: my_helper
INFO - 2021-08-09 06:31:06 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:31:06 --> Controller Class Initialized
INFO - 2021-08-09 06:31:06 --> Config Class Initialized
INFO - 2021-08-09 06:31:06 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:31:06 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:31:06 --> Utf8 Class Initialized
INFO - 2021-08-09 06:31:06 --> URI Class Initialized
INFO - 2021-08-09 06:31:06 --> Router Class Initialized
INFO - 2021-08-09 06:31:06 --> Output Class Initialized
INFO - 2021-08-09 06:31:06 --> Security Class Initialized
DEBUG - 2021-08-09 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:31:06 --> Input Class Initialized
INFO - 2021-08-09 06:31:06 --> Language Class Initialized
INFO - 2021-08-09 06:31:06 --> Language Class Initialized
INFO - 2021-08-09 06:31:06 --> Config Class Initialized
INFO - 2021-08-09 06:31:06 --> Loader Class Initialized
INFO - 2021-08-09 06:31:06 --> Helper loaded: url_helper
INFO - 2021-08-09 06:31:06 --> Helper loaded: file_helper
INFO - 2021-08-09 06:31:06 --> Helper loaded: form_helper
INFO - 2021-08-09 06:31:06 --> Helper loaded: my_helper
INFO - 2021-08-09 06:31:06 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:31:06 --> Controller Class Initialized
DEBUG - 2021-08-09 06:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:31:06 --> Final output sent to browser
DEBUG - 2021-08-09 06:31:06 --> Total execution time: 0.0659
INFO - 2021-08-09 06:31:14 --> Config Class Initialized
INFO - 2021-08-09 06:31:14 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:31:14 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:31:14 --> Utf8 Class Initialized
INFO - 2021-08-09 06:31:14 --> URI Class Initialized
INFO - 2021-08-09 06:31:14 --> Router Class Initialized
INFO - 2021-08-09 06:31:14 --> Output Class Initialized
INFO - 2021-08-09 06:31:14 --> Security Class Initialized
DEBUG - 2021-08-09 06:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:31:14 --> Input Class Initialized
INFO - 2021-08-09 06:31:14 --> Language Class Initialized
INFO - 2021-08-09 06:31:14 --> Language Class Initialized
INFO - 2021-08-09 06:31:14 --> Config Class Initialized
INFO - 2021-08-09 06:31:14 --> Loader Class Initialized
INFO - 2021-08-09 06:31:14 --> Helper loaded: url_helper
INFO - 2021-08-09 06:31:14 --> Helper loaded: file_helper
INFO - 2021-08-09 06:31:14 --> Helper loaded: form_helper
INFO - 2021-08-09 06:31:14 --> Helper loaded: my_helper
INFO - 2021-08-09 06:31:14 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:31:14 --> Controller Class Initialized
DEBUG - 2021-08-09 06:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-09 06:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:31:14 --> Final output sent to browser
DEBUG - 2021-08-09 06:31:14 --> Total execution time: 0.0796
INFO - 2021-08-09 06:31:38 --> Config Class Initialized
INFO - 2021-08-09 06:31:38 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:31:38 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:31:38 --> Utf8 Class Initialized
INFO - 2021-08-09 06:31:38 --> URI Class Initialized
INFO - 2021-08-09 06:31:38 --> Router Class Initialized
INFO - 2021-08-09 06:31:38 --> Output Class Initialized
INFO - 2021-08-09 06:31:38 --> Security Class Initialized
DEBUG - 2021-08-09 06:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:31:38 --> Input Class Initialized
INFO - 2021-08-09 06:31:38 --> Language Class Initialized
INFO - 2021-08-09 06:31:38 --> Language Class Initialized
INFO - 2021-08-09 06:31:38 --> Config Class Initialized
INFO - 2021-08-09 06:31:38 --> Loader Class Initialized
INFO - 2021-08-09 06:31:38 --> Helper loaded: url_helper
INFO - 2021-08-09 06:31:38 --> Helper loaded: file_helper
INFO - 2021-08-09 06:31:38 --> Helper loaded: form_helper
INFO - 2021-08-09 06:31:38 --> Helper loaded: my_helper
INFO - 2021-08-09 06:31:38 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:31:38 --> Controller Class Initialized
DEBUG - 2021-08-09 06:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:31:38 --> Final output sent to browser
DEBUG - 2021-08-09 06:31:38 --> Total execution time: 0.0851
INFO - 2021-08-09 06:42:12 --> Config Class Initialized
INFO - 2021-08-09 06:42:12 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:42:12 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:42:12 --> Utf8 Class Initialized
INFO - 2021-08-09 06:42:12 --> URI Class Initialized
INFO - 2021-08-09 06:42:12 --> Router Class Initialized
INFO - 2021-08-09 06:42:12 --> Output Class Initialized
INFO - 2021-08-09 06:42:12 --> Security Class Initialized
DEBUG - 2021-08-09 06:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:42:12 --> Input Class Initialized
INFO - 2021-08-09 06:42:12 --> Language Class Initialized
INFO - 2021-08-09 06:42:12 --> Language Class Initialized
INFO - 2021-08-09 06:42:12 --> Config Class Initialized
INFO - 2021-08-09 06:42:12 --> Loader Class Initialized
INFO - 2021-08-09 06:42:12 --> Helper loaded: url_helper
INFO - 2021-08-09 06:42:12 --> Helper loaded: file_helper
INFO - 2021-08-09 06:42:12 --> Helper loaded: form_helper
INFO - 2021-08-09 06:42:12 --> Helper loaded: my_helper
INFO - 2021-08-09 06:42:12 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:42:12 --> Controller Class Initialized
DEBUG - 2021-08-09 06:42:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:42:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:42:12 --> Final output sent to browser
DEBUG - 2021-08-09 06:42:12 --> Total execution time: 0.0597
INFO - 2021-08-09 06:42:17 --> Config Class Initialized
INFO - 2021-08-09 06:42:17 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:42:17 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:42:17 --> Utf8 Class Initialized
INFO - 2021-08-09 06:42:17 --> URI Class Initialized
INFO - 2021-08-09 06:42:17 --> Router Class Initialized
INFO - 2021-08-09 06:42:17 --> Output Class Initialized
INFO - 2021-08-09 06:42:17 --> Security Class Initialized
DEBUG - 2021-08-09 06:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:42:17 --> Input Class Initialized
INFO - 2021-08-09 06:42:17 --> Language Class Initialized
INFO - 2021-08-09 06:42:17 --> Language Class Initialized
INFO - 2021-08-09 06:42:17 --> Config Class Initialized
INFO - 2021-08-09 06:42:17 --> Loader Class Initialized
INFO - 2021-08-09 06:42:17 --> Helper loaded: url_helper
INFO - 2021-08-09 06:42:17 --> Helper loaded: file_helper
INFO - 2021-08-09 06:42:17 --> Helper loaded: form_helper
INFO - 2021-08-09 06:42:17 --> Helper loaded: my_helper
INFO - 2021-08-09 06:42:17 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:42:17 --> Controller Class Initialized
ERROR - 2021-08-09 06:42:17 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '354' AND tasm = '20212'
INFO - 2021-08-09 06:42:17 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:42:25 --> Config Class Initialized
INFO - 2021-08-09 06:42:25 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:42:25 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:42:25 --> Utf8 Class Initialized
INFO - 2021-08-09 06:42:25 --> URI Class Initialized
INFO - 2021-08-09 06:42:25 --> Router Class Initialized
INFO - 2021-08-09 06:42:25 --> Output Class Initialized
INFO - 2021-08-09 06:42:25 --> Security Class Initialized
DEBUG - 2021-08-09 06:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:42:25 --> Input Class Initialized
INFO - 2021-08-09 06:42:25 --> Language Class Initialized
INFO - 2021-08-09 06:42:25 --> Language Class Initialized
INFO - 2021-08-09 06:42:25 --> Config Class Initialized
INFO - 2021-08-09 06:42:25 --> Loader Class Initialized
INFO - 2021-08-09 06:42:25 --> Helper loaded: url_helper
INFO - 2021-08-09 06:42:25 --> Helper loaded: file_helper
INFO - 2021-08-09 06:42:25 --> Helper loaded: form_helper
INFO - 2021-08-09 06:42:25 --> Helper loaded: my_helper
INFO - 2021-08-09 06:42:25 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:42:25 --> Controller Class Initialized
ERROR - 2021-08-09 06:42:25 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '356' AND tasm = '20212'
INFO - 2021-08-09 06:42:25 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:42:32 --> Config Class Initialized
INFO - 2021-08-09 06:42:32 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:42:32 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:42:32 --> Utf8 Class Initialized
INFO - 2021-08-09 06:42:32 --> URI Class Initialized
INFO - 2021-08-09 06:42:32 --> Router Class Initialized
INFO - 2021-08-09 06:42:32 --> Output Class Initialized
INFO - 2021-08-09 06:42:32 --> Security Class Initialized
DEBUG - 2021-08-09 06:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:42:32 --> Input Class Initialized
INFO - 2021-08-09 06:42:32 --> Language Class Initialized
INFO - 2021-08-09 06:42:32 --> Language Class Initialized
INFO - 2021-08-09 06:42:32 --> Config Class Initialized
INFO - 2021-08-09 06:42:32 --> Loader Class Initialized
INFO - 2021-08-09 06:42:32 --> Helper loaded: url_helper
INFO - 2021-08-09 06:42:32 --> Helper loaded: file_helper
INFO - 2021-08-09 06:42:32 --> Helper loaded: form_helper
INFO - 2021-08-09 06:42:32 --> Helper loaded: my_helper
INFO - 2021-08-09 06:42:32 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:42:32 --> Controller Class Initialized
ERROR - 2021-08-09 06:42:32 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '358' AND tasm = '20212'
INFO - 2021-08-09 06:42:32 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:42:44 --> Config Class Initialized
INFO - 2021-08-09 06:42:44 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:42:44 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:42:44 --> Utf8 Class Initialized
INFO - 2021-08-09 06:42:44 --> URI Class Initialized
INFO - 2021-08-09 06:42:44 --> Router Class Initialized
INFO - 2021-08-09 06:42:44 --> Output Class Initialized
INFO - 2021-08-09 06:42:44 --> Security Class Initialized
DEBUG - 2021-08-09 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:42:44 --> Input Class Initialized
INFO - 2021-08-09 06:42:44 --> Language Class Initialized
INFO - 2021-08-09 06:42:44 --> Language Class Initialized
INFO - 2021-08-09 06:42:44 --> Config Class Initialized
INFO - 2021-08-09 06:42:44 --> Loader Class Initialized
INFO - 2021-08-09 06:42:44 --> Helper loaded: url_helper
INFO - 2021-08-09 06:42:44 --> Helper loaded: file_helper
INFO - 2021-08-09 06:42:44 --> Helper loaded: form_helper
INFO - 2021-08-09 06:42:44 --> Helper loaded: my_helper
INFO - 2021-08-09 06:42:44 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:42:44 --> Controller Class Initialized
ERROR - 2021-08-09 06:42:44 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '360' AND tasm = '20212'
INFO - 2021-08-09 06:42:44 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:43:07 --> Config Class Initialized
INFO - 2021-08-09 06:43:07 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:43:07 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:43:07 --> Utf8 Class Initialized
INFO - 2021-08-09 06:43:07 --> URI Class Initialized
INFO - 2021-08-09 06:43:07 --> Router Class Initialized
INFO - 2021-08-09 06:43:07 --> Output Class Initialized
INFO - 2021-08-09 06:43:07 --> Security Class Initialized
DEBUG - 2021-08-09 06:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:43:07 --> Input Class Initialized
INFO - 2021-08-09 06:43:07 --> Language Class Initialized
INFO - 2021-08-09 06:43:07 --> Language Class Initialized
INFO - 2021-08-09 06:43:07 --> Config Class Initialized
INFO - 2021-08-09 06:43:07 --> Loader Class Initialized
INFO - 2021-08-09 06:43:07 --> Helper loaded: url_helper
INFO - 2021-08-09 06:43:07 --> Helper loaded: file_helper
INFO - 2021-08-09 06:43:07 --> Helper loaded: form_helper
INFO - 2021-08-09 06:43:07 --> Helper loaded: my_helper
INFO - 2021-08-09 06:43:07 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:43:07 --> Controller Class Initialized
ERROR - 2021-08-09 06:43:07 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '362' AND tasm = '20212'
INFO - 2021-08-09 06:43:07 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:43:10 --> Config Class Initialized
INFO - 2021-08-09 06:43:10 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:43:10 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:43:10 --> Utf8 Class Initialized
INFO - 2021-08-09 06:43:10 --> URI Class Initialized
INFO - 2021-08-09 06:43:10 --> Router Class Initialized
INFO - 2021-08-09 06:43:10 --> Output Class Initialized
INFO - 2021-08-09 06:43:10 --> Security Class Initialized
DEBUG - 2021-08-09 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:43:10 --> Input Class Initialized
INFO - 2021-08-09 06:43:10 --> Language Class Initialized
INFO - 2021-08-09 06:43:10 --> Language Class Initialized
INFO - 2021-08-09 06:43:10 --> Config Class Initialized
INFO - 2021-08-09 06:43:10 --> Loader Class Initialized
INFO - 2021-08-09 06:43:10 --> Helper loaded: url_helper
INFO - 2021-08-09 06:43:10 --> Helper loaded: file_helper
INFO - 2021-08-09 06:43:10 --> Helper loaded: form_helper
INFO - 2021-08-09 06:43:10 --> Helper loaded: my_helper
INFO - 2021-08-09 06:43:10 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:43:10 --> Controller Class Initialized
ERROR - 2021-08-09 06:43:10 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '363' AND tasm = '20212'
INFO - 2021-08-09 06:43:10 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:43:12 --> Config Class Initialized
INFO - 2021-08-09 06:43:12 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:43:12 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:43:12 --> Utf8 Class Initialized
INFO - 2021-08-09 06:43:12 --> URI Class Initialized
INFO - 2021-08-09 06:43:12 --> Router Class Initialized
INFO - 2021-08-09 06:43:12 --> Output Class Initialized
INFO - 2021-08-09 06:43:12 --> Security Class Initialized
DEBUG - 2021-08-09 06:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:43:12 --> Input Class Initialized
INFO - 2021-08-09 06:43:12 --> Language Class Initialized
INFO - 2021-08-09 06:43:12 --> Language Class Initialized
INFO - 2021-08-09 06:43:12 --> Config Class Initialized
INFO - 2021-08-09 06:43:12 --> Loader Class Initialized
INFO - 2021-08-09 06:43:12 --> Helper loaded: url_helper
INFO - 2021-08-09 06:43:12 --> Helper loaded: file_helper
INFO - 2021-08-09 06:43:12 --> Helper loaded: form_helper
INFO - 2021-08-09 06:43:12 --> Helper loaded: my_helper
INFO - 2021-08-09 06:43:12 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:43:12 --> Controller Class Initialized
ERROR - 2021-08-09 06:43:12 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '364' AND tasm = '20212'
INFO - 2021-08-09 06:43:12 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:43:19 --> Config Class Initialized
INFO - 2021-08-09 06:43:19 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:43:19 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:43:19 --> Utf8 Class Initialized
INFO - 2021-08-09 06:43:19 --> URI Class Initialized
INFO - 2021-08-09 06:43:19 --> Router Class Initialized
INFO - 2021-08-09 06:43:19 --> Output Class Initialized
INFO - 2021-08-09 06:43:19 --> Security Class Initialized
DEBUG - 2021-08-09 06:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:43:19 --> Input Class Initialized
INFO - 2021-08-09 06:43:19 --> Language Class Initialized
INFO - 2021-08-09 06:43:19 --> Language Class Initialized
INFO - 2021-08-09 06:43:19 --> Config Class Initialized
INFO - 2021-08-09 06:43:19 --> Loader Class Initialized
INFO - 2021-08-09 06:43:19 --> Helper loaded: url_helper
INFO - 2021-08-09 06:43:19 --> Helper loaded: file_helper
INFO - 2021-08-09 06:43:19 --> Helper loaded: form_helper
INFO - 2021-08-09 06:43:19 --> Helper loaded: my_helper
INFO - 2021-08-09 06:43:19 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:43:19 --> Controller Class Initialized
DEBUG - 2021-08-09 06:43:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:43:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:43:19 --> Final output sent to browser
DEBUG - 2021-08-09 06:43:19 --> Total execution time: 0.0553
INFO - 2021-08-09 06:43:33 --> Config Class Initialized
INFO - 2021-08-09 06:43:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:43:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:43:33 --> Utf8 Class Initialized
INFO - 2021-08-09 06:43:33 --> URI Class Initialized
INFO - 2021-08-09 06:43:33 --> Router Class Initialized
INFO - 2021-08-09 06:43:33 --> Output Class Initialized
INFO - 2021-08-09 06:43:33 --> Security Class Initialized
DEBUG - 2021-08-09 06:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:43:33 --> Input Class Initialized
INFO - 2021-08-09 06:43:33 --> Language Class Initialized
INFO - 2021-08-09 06:43:33 --> Language Class Initialized
INFO - 2021-08-09 06:43:33 --> Config Class Initialized
INFO - 2021-08-09 06:43:33 --> Loader Class Initialized
INFO - 2021-08-09 06:43:33 --> Helper loaded: url_helper
INFO - 2021-08-09 06:43:33 --> Helper loaded: file_helper
INFO - 2021-08-09 06:43:33 --> Helper loaded: form_helper
INFO - 2021-08-09 06:43:33 --> Helper loaded: my_helper
INFO - 2021-08-09 06:43:33 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:43:33 --> Controller Class Initialized
ERROR - 2021-08-09 06:43:33 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '366' AND tasm = '20212'
INFO - 2021-08-09 06:43:33 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:43:35 --> Config Class Initialized
INFO - 2021-08-09 06:43:35 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:43:35 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:43:35 --> Utf8 Class Initialized
INFO - 2021-08-09 06:43:35 --> URI Class Initialized
INFO - 2021-08-09 06:43:35 --> Router Class Initialized
INFO - 2021-08-09 06:43:35 --> Output Class Initialized
INFO - 2021-08-09 06:43:35 --> Security Class Initialized
DEBUG - 2021-08-09 06:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:43:35 --> Input Class Initialized
INFO - 2021-08-09 06:43:35 --> Language Class Initialized
INFO - 2021-08-09 06:43:35 --> Language Class Initialized
INFO - 2021-08-09 06:43:35 --> Config Class Initialized
INFO - 2021-08-09 06:43:35 --> Loader Class Initialized
INFO - 2021-08-09 06:43:35 --> Helper loaded: url_helper
INFO - 2021-08-09 06:43:35 --> Helper loaded: file_helper
INFO - 2021-08-09 06:43:35 --> Helper loaded: form_helper
INFO - 2021-08-09 06:43:35 --> Helper loaded: my_helper
INFO - 2021-08-09 06:43:35 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:43:35 --> Controller Class Initialized
ERROR - 2021-08-09 06:43:35 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '367' AND tasm = '20212'
INFO - 2021-08-09 06:43:35 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:44:10 --> Config Class Initialized
INFO - 2021-08-09 06:44:10 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:44:10 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:44:10 --> Utf8 Class Initialized
INFO - 2021-08-09 06:44:10 --> URI Class Initialized
INFO - 2021-08-09 06:44:10 --> Router Class Initialized
INFO - 2021-08-09 06:44:10 --> Output Class Initialized
INFO - 2021-08-09 06:44:10 --> Security Class Initialized
DEBUG - 2021-08-09 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:44:10 --> Input Class Initialized
INFO - 2021-08-09 06:44:10 --> Language Class Initialized
INFO - 2021-08-09 06:44:10 --> Language Class Initialized
INFO - 2021-08-09 06:44:10 --> Config Class Initialized
INFO - 2021-08-09 06:44:10 --> Loader Class Initialized
INFO - 2021-08-09 06:44:10 --> Helper loaded: url_helper
INFO - 2021-08-09 06:44:10 --> Helper loaded: file_helper
INFO - 2021-08-09 06:44:10 --> Helper loaded: form_helper
INFO - 2021-08-09 06:44:10 --> Helper loaded: my_helper
INFO - 2021-08-09 06:44:10 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:44:10 --> Controller Class Initialized
ERROR - 2021-08-09 06:44:10 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '374' AND tasm = '20212'
INFO - 2021-08-09 06:44:10 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:44:12 --> Config Class Initialized
INFO - 2021-08-09 06:44:12 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:44:12 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:44:12 --> Utf8 Class Initialized
INFO - 2021-08-09 06:44:12 --> URI Class Initialized
INFO - 2021-08-09 06:44:12 --> Router Class Initialized
INFO - 2021-08-09 06:44:12 --> Output Class Initialized
INFO - 2021-08-09 06:44:12 --> Security Class Initialized
DEBUG - 2021-08-09 06:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:44:12 --> Input Class Initialized
INFO - 2021-08-09 06:44:12 --> Language Class Initialized
INFO - 2021-08-09 06:44:12 --> Language Class Initialized
INFO - 2021-08-09 06:44:12 --> Config Class Initialized
INFO - 2021-08-09 06:44:12 --> Loader Class Initialized
INFO - 2021-08-09 06:44:12 --> Helper loaded: url_helper
INFO - 2021-08-09 06:44:12 --> Helper loaded: file_helper
INFO - 2021-08-09 06:44:12 --> Helper loaded: form_helper
INFO - 2021-08-09 06:44:12 --> Helper loaded: my_helper
INFO - 2021-08-09 06:44:12 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:44:12 --> Controller Class Initialized
ERROR - 2021-08-09 06:44:12 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '375' AND tasm = '20212'
INFO - 2021-08-09 06:44:12 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:44:28 --> Config Class Initialized
INFO - 2021-08-09 06:44:28 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:44:28 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:44:28 --> Utf8 Class Initialized
INFO - 2021-08-09 06:44:28 --> URI Class Initialized
INFO - 2021-08-09 06:44:28 --> Router Class Initialized
INFO - 2021-08-09 06:44:28 --> Output Class Initialized
INFO - 2021-08-09 06:44:28 --> Security Class Initialized
DEBUG - 2021-08-09 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:44:28 --> Input Class Initialized
INFO - 2021-08-09 06:44:28 --> Language Class Initialized
INFO - 2021-08-09 06:44:28 --> Language Class Initialized
INFO - 2021-08-09 06:44:28 --> Config Class Initialized
INFO - 2021-08-09 06:44:28 --> Loader Class Initialized
INFO - 2021-08-09 06:44:28 --> Helper loaded: url_helper
INFO - 2021-08-09 06:44:28 --> Helper loaded: file_helper
INFO - 2021-08-09 06:44:28 --> Helper loaded: form_helper
INFO - 2021-08-09 06:44:28 --> Helper loaded: my_helper
INFO - 2021-08-09 06:44:28 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:44:28 --> Controller Class Initialized
ERROR - 2021-08-09 06:44:28 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '378' AND tasm = '20212'
INFO - 2021-08-09 06:44:28 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:44:30 --> Config Class Initialized
INFO - 2021-08-09 06:44:30 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:44:30 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:44:30 --> Utf8 Class Initialized
INFO - 2021-08-09 06:44:30 --> URI Class Initialized
INFO - 2021-08-09 06:44:30 --> Router Class Initialized
INFO - 2021-08-09 06:44:30 --> Output Class Initialized
INFO - 2021-08-09 06:44:30 --> Security Class Initialized
DEBUG - 2021-08-09 06:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:44:30 --> Input Class Initialized
INFO - 2021-08-09 06:44:30 --> Language Class Initialized
INFO - 2021-08-09 06:44:30 --> Language Class Initialized
INFO - 2021-08-09 06:44:30 --> Config Class Initialized
INFO - 2021-08-09 06:44:30 --> Loader Class Initialized
INFO - 2021-08-09 06:44:30 --> Helper loaded: url_helper
INFO - 2021-08-09 06:44:30 --> Helper loaded: file_helper
INFO - 2021-08-09 06:44:30 --> Helper loaded: form_helper
INFO - 2021-08-09 06:44:30 --> Helper loaded: my_helper
INFO - 2021-08-09 06:44:30 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:44:30 --> Controller Class Initialized
ERROR - 2021-08-09 06:44:30 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '379' AND tasm = '20212'
INFO - 2021-08-09 06:44:30 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:44:32 --> Config Class Initialized
INFO - 2021-08-09 06:44:32 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:44:32 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:44:32 --> Utf8 Class Initialized
INFO - 2021-08-09 06:44:32 --> URI Class Initialized
INFO - 2021-08-09 06:44:32 --> Router Class Initialized
INFO - 2021-08-09 06:44:32 --> Output Class Initialized
INFO - 2021-08-09 06:44:32 --> Security Class Initialized
DEBUG - 2021-08-09 06:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:44:32 --> Input Class Initialized
INFO - 2021-08-09 06:44:32 --> Language Class Initialized
INFO - 2021-08-09 06:44:32 --> Language Class Initialized
INFO - 2021-08-09 06:44:32 --> Config Class Initialized
INFO - 2021-08-09 06:44:32 --> Loader Class Initialized
INFO - 2021-08-09 06:44:32 --> Helper loaded: url_helper
INFO - 2021-08-09 06:44:32 --> Helper loaded: file_helper
INFO - 2021-08-09 06:44:32 --> Helper loaded: form_helper
INFO - 2021-08-09 06:44:32 --> Helper loaded: my_helper
INFO - 2021-08-09 06:44:32 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:44:32 --> Controller Class Initialized
DEBUG - 2021-08-09 06:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:44:32 --> Final output sent to browser
DEBUG - 2021-08-09 06:44:32 --> Total execution time: 0.0601
INFO - 2021-08-09 06:47:24 --> Config Class Initialized
INFO - 2021-08-09 06:47:24 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:47:24 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:47:24 --> Utf8 Class Initialized
INFO - 2021-08-09 06:47:24 --> URI Class Initialized
INFO - 2021-08-09 06:47:24 --> Router Class Initialized
INFO - 2021-08-09 06:47:24 --> Output Class Initialized
INFO - 2021-08-09 06:47:24 --> Security Class Initialized
DEBUG - 2021-08-09 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:47:24 --> Input Class Initialized
INFO - 2021-08-09 06:47:24 --> Language Class Initialized
INFO - 2021-08-09 06:47:24 --> Language Class Initialized
INFO - 2021-08-09 06:47:24 --> Config Class Initialized
INFO - 2021-08-09 06:47:24 --> Loader Class Initialized
INFO - 2021-08-09 06:47:24 --> Helper loaded: url_helper
INFO - 2021-08-09 06:47:24 --> Helper loaded: file_helper
INFO - 2021-08-09 06:47:24 --> Helper loaded: form_helper
INFO - 2021-08-09 06:47:24 --> Helper loaded: my_helper
INFO - 2021-08-09 06:47:24 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:47:24 --> Controller Class Initialized
ERROR - 2021-08-09 06:47:24 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '382' AND tasm = '20212'
INFO - 2021-08-09 06:47:24 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:47:25 --> Config Class Initialized
INFO - 2021-08-09 06:47:25 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:47:25 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:47:25 --> Utf8 Class Initialized
INFO - 2021-08-09 06:47:25 --> URI Class Initialized
INFO - 2021-08-09 06:47:25 --> Router Class Initialized
INFO - 2021-08-09 06:47:25 --> Output Class Initialized
INFO - 2021-08-09 06:47:25 --> Security Class Initialized
DEBUG - 2021-08-09 06:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:47:25 --> Input Class Initialized
INFO - 2021-08-09 06:47:25 --> Language Class Initialized
INFO - 2021-08-09 06:47:25 --> Language Class Initialized
INFO - 2021-08-09 06:47:25 --> Config Class Initialized
INFO - 2021-08-09 06:47:25 --> Loader Class Initialized
INFO - 2021-08-09 06:47:25 --> Helper loaded: url_helper
INFO - 2021-08-09 06:47:25 --> Helper loaded: file_helper
INFO - 2021-08-09 06:47:25 --> Helper loaded: form_helper
INFO - 2021-08-09 06:47:25 --> Helper loaded: my_helper
INFO - 2021-08-09 06:47:25 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:47:25 --> Controller Class Initialized
ERROR - 2021-08-09 06:47:25 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '383' AND tasm = '20212'
INFO - 2021-08-09 06:47:25 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:47:34 --> Config Class Initialized
INFO - 2021-08-09 06:47:34 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:47:34 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:47:34 --> Utf8 Class Initialized
INFO - 2021-08-09 06:47:34 --> URI Class Initialized
INFO - 2021-08-09 06:47:34 --> Router Class Initialized
INFO - 2021-08-09 06:47:34 --> Output Class Initialized
INFO - 2021-08-09 06:47:34 --> Security Class Initialized
DEBUG - 2021-08-09 06:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:47:34 --> Input Class Initialized
INFO - 2021-08-09 06:47:34 --> Language Class Initialized
INFO - 2021-08-09 06:47:34 --> Language Class Initialized
INFO - 2021-08-09 06:47:34 --> Config Class Initialized
INFO - 2021-08-09 06:47:34 --> Loader Class Initialized
INFO - 2021-08-09 06:47:34 --> Helper loaded: url_helper
INFO - 2021-08-09 06:47:34 --> Helper loaded: file_helper
INFO - 2021-08-09 06:47:34 --> Helper loaded: form_helper
INFO - 2021-08-09 06:47:34 --> Helper loaded: my_helper
INFO - 2021-08-09 06:47:34 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:47:34 --> Controller Class Initialized
ERROR - 2021-08-09 06:47:34 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '385' AND tasm = '20212'
INFO - 2021-08-09 06:47:34 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:47:37 --> Config Class Initialized
INFO - 2021-08-09 06:47:37 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:47:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:47:37 --> Utf8 Class Initialized
INFO - 2021-08-09 06:47:37 --> URI Class Initialized
INFO - 2021-08-09 06:47:37 --> Router Class Initialized
INFO - 2021-08-09 06:47:37 --> Output Class Initialized
INFO - 2021-08-09 06:47:37 --> Security Class Initialized
DEBUG - 2021-08-09 06:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:47:37 --> Input Class Initialized
INFO - 2021-08-09 06:47:37 --> Language Class Initialized
INFO - 2021-08-09 06:47:37 --> Language Class Initialized
INFO - 2021-08-09 06:47:37 --> Config Class Initialized
INFO - 2021-08-09 06:47:37 --> Loader Class Initialized
INFO - 2021-08-09 06:47:37 --> Helper loaded: url_helper
INFO - 2021-08-09 06:47:37 --> Helper loaded: file_helper
INFO - 2021-08-09 06:47:37 --> Helper loaded: form_helper
INFO - 2021-08-09 06:47:37 --> Helper loaded: my_helper
INFO - 2021-08-09 06:47:37 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:47:37 --> Controller Class Initialized
ERROR - 2021-08-09 06:47:37 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '386' AND tasm = '20212'
INFO - 2021-08-09 06:47:37 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:47:41 --> Config Class Initialized
INFO - 2021-08-09 06:47:41 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:47:41 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:47:41 --> Utf8 Class Initialized
INFO - 2021-08-09 06:47:41 --> URI Class Initialized
INFO - 2021-08-09 06:47:41 --> Router Class Initialized
INFO - 2021-08-09 06:47:41 --> Output Class Initialized
INFO - 2021-08-09 06:47:41 --> Security Class Initialized
DEBUG - 2021-08-09 06:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:47:41 --> Input Class Initialized
INFO - 2021-08-09 06:47:41 --> Language Class Initialized
INFO - 2021-08-09 06:47:41 --> Language Class Initialized
INFO - 2021-08-09 06:47:41 --> Config Class Initialized
INFO - 2021-08-09 06:47:41 --> Loader Class Initialized
INFO - 2021-08-09 06:47:41 --> Helper loaded: url_helper
INFO - 2021-08-09 06:47:41 --> Helper loaded: file_helper
INFO - 2021-08-09 06:47:41 --> Helper loaded: form_helper
INFO - 2021-08-09 06:47:41 --> Helper loaded: my_helper
INFO - 2021-08-09 06:47:41 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:47:41 --> Controller Class Initialized
ERROR - 2021-08-09 06:47:41 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '387' AND tasm = '20212'
INFO - 2021-08-09 06:47:41 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:47:44 --> Config Class Initialized
INFO - 2021-08-09 06:47:44 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:47:44 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:47:44 --> Utf8 Class Initialized
INFO - 2021-08-09 06:47:44 --> URI Class Initialized
INFO - 2021-08-09 06:47:44 --> Router Class Initialized
INFO - 2021-08-09 06:47:44 --> Output Class Initialized
INFO - 2021-08-09 06:47:44 --> Security Class Initialized
DEBUG - 2021-08-09 06:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:47:44 --> Input Class Initialized
INFO - 2021-08-09 06:47:44 --> Language Class Initialized
INFO - 2021-08-09 06:47:44 --> Language Class Initialized
INFO - 2021-08-09 06:47:44 --> Config Class Initialized
INFO - 2021-08-09 06:47:44 --> Loader Class Initialized
INFO - 2021-08-09 06:47:44 --> Helper loaded: url_helper
INFO - 2021-08-09 06:47:44 --> Helper loaded: file_helper
INFO - 2021-08-09 06:47:44 --> Helper loaded: form_helper
INFO - 2021-08-09 06:47:44 --> Helper loaded: my_helper
INFO - 2021-08-09 06:47:44 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:47:44 --> Controller Class Initialized
ERROR - 2021-08-09 06:47:44 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '388' AND tasm = '20212'
INFO - 2021-08-09 06:47:44 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:47:48 --> Config Class Initialized
INFO - 2021-08-09 06:47:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:47:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:47:48 --> Utf8 Class Initialized
INFO - 2021-08-09 06:47:48 --> URI Class Initialized
INFO - 2021-08-09 06:47:48 --> Router Class Initialized
INFO - 2021-08-09 06:47:48 --> Output Class Initialized
INFO - 2021-08-09 06:47:48 --> Security Class Initialized
DEBUG - 2021-08-09 06:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:47:48 --> Input Class Initialized
INFO - 2021-08-09 06:47:48 --> Language Class Initialized
INFO - 2021-08-09 06:47:48 --> Language Class Initialized
INFO - 2021-08-09 06:47:48 --> Config Class Initialized
INFO - 2021-08-09 06:47:48 --> Loader Class Initialized
INFO - 2021-08-09 06:47:48 --> Helper loaded: url_helper
INFO - 2021-08-09 06:47:48 --> Helper loaded: file_helper
INFO - 2021-08-09 06:47:48 --> Helper loaded: form_helper
INFO - 2021-08-09 06:47:48 --> Helper loaded: my_helper
INFO - 2021-08-09 06:47:48 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:47:48 --> Controller Class Initialized
ERROR - 2021-08-09 06:47:48 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '389' AND tasm = '20212'
INFO - 2021-08-09 06:47:48 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:48:13 --> Config Class Initialized
INFO - 2021-08-09 06:48:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:48:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:48:13 --> Utf8 Class Initialized
INFO - 2021-08-09 06:48:13 --> URI Class Initialized
INFO - 2021-08-09 06:48:13 --> Router Class Initialized
INFO - 2021-08-09 06:48:13 --> Output Class Initialized
INFO - 2021-08-09 06:48:13 --> Security Class Initialized
DEBUG - 2021-08-09 06:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:48:13 --> Input Class Initialized
INFO - 2021-08-09 06:48:13 --> Language Class Initialized
INFO - 2021-08-09 06:48:13 --> Language Class Initialized
INFO - 2021-08-09 06:48:13 --> Config Class Initialized
INFO - 2021-08-09 06:48:13 --> Loader Class Initialized
INFO - 2021-08-09 06:48:13 --> Helper loaded: url_helper
INFO - 2021-08-09 06:48:13 --> Helper loaded: file_helper
INFO - 2021-08-09 06:48:13 --> Helper loaded: form_helper
INFO - 2021-08-09 06:48:13 --> Helper loaded: my_helper
INFO - 2021-08-09 06:48:13 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:48:13 --> Controller Class Initialized
ERROR - 2021-08-09 06:48:13 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '392' AND tasm = '20212'
INFO - 2021-08-09 06:48:13 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:48:15 --> Config Class Initialized
INFO - 2021-08-09 06:48:15 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:48:15 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:48:15 --> Utf8 Class Initialized
INFO - 2021-08-09 06:48:15 --> URI Class Initialized
INFO - 2021-08-09 06:48:15 --> Router Class Initialized
INFO - 2021-08-09 06:48:15 --> Output Class Initialized
INFO - 2021-08-09 06:48:15 --> Security Class Initialized
DEBUG - 2021-08-09 06:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:48:15 --> Input Class Initialized
INFO - 2021-08-09 06:48:15 --> Language Class Initialized
INFO - 2021-08-09 06:48:15 --> Language Class Initialized
INFO - 2021-08-09 06:48:15 --> Config Class Initialized
INFO - 2021-08-09 06:48:15 --> Loader Class Initialized
INFO - 2021-08-09 06:48:15 --> Helper loaded: url_helper
INFO - 2021-08-09 06:48:15 --> Helper loaded: file_helper
INFO - 2021-08-09 06:48:15 --> Helper loaded: form_helper
INFO - 2021-08-09 06:48:15 --> Helper loaded: my_helper
INFO - 2021-08-09 06:48:15 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:48:15 --> Controller Class Initialized
ERROR - 2021-08-09 06:48:15 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '393' AND tasm = '20212'
INFO - 2021-08-09 06:48:15 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:48:24 --> Config Class Initialized
INFO - 2021-08-09 06:48:24 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:48:24 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:48:24 --> Utf8 Class Initialized
INFO - 2021-08-09 06:48:24 --> URI Class Initialized
INFO - 2021-08-09 06:48:24 --> Router Class Initialized
INFO - 2021-08-09 06:48:24 --> Output Class Initialized
INFO - 2021-08-09 06:48:24 --> Security Class Initialized
DEBUG - 2021-08-09 06:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:48:24 --> Input Class Initialized
INFO - 2021-08-09 06:48:24 --> Language Class Initialized
INFO - 2021-08-09 06:48:24 --> Language Class Initialized
INFO - 2021-08-09 06:48:24 --> Config Class Initialized
INFO - 2021-08-09 06:48:24 --> Loader Class Initialized
INFO - 2021-08-09 06:48:24 --> Helper loaded: url_helper
INFO - 2021-08-09 06:48:24 --> Helper loaded: file_helper
INFO - 2021-08-09 06:48:24 --> Helper loaded: form_helper
INFO - 2021-08-09 06:48:24 --> Helper loaded: my_helper
INFO - 2021-08-09 06:48:24 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:48:24 --> Controller Class Initialized
ERROR - 2021-08-09 06:48:24 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '394' AND tasm = '20212'
INFO - 2021-08-09 06:48:24 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:48:27 --> Config Class Initialized
INFO - 2021-08-09 06:48:27 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:48:27 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:48:27 --> Utf8 Class Initialized
INFO - 2021-08-09 06:48:27 --> URI Class Initialized
INFO - 2021-08-09 06:48:27 --> Router Class Initialized
INFO - 2021-08-09 06:48:27 --> Output Class Initialized
INFO - 2021-08-09 06:48:27 --> Security Class Initialized
DEBUG - 2021-08-09 06:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:48:27 --> Input Class Initialized
INFO - 2021-08-09 06:48:27 --> Language Class Initialized
INFO - 2021-08-09 06:48:27 --> Language Class Initialized
INFO - 2021-08-09 06:48:27 --> Config Class Initialized
INFO - 2021-08-09 06:48:27 --> Loader Class Initialized
INFO - 2021-08-09 06:48:27 --> Helper loaded: url_helper
INFO - 2021-08-09 06:48:27 --> Helper loaded: file_helper
INFO - 2021-08-09 06:48:27 --> Helper loaded: form_helper
INFO - 2021-08-09 06:48:27 --> Helper loaded: my_helper
INFO - 2021-08-09 06:48:27 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:48:27 --> Controller Class Initialized
ERROR - 2021-08-09 06:48:27 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '395' AND tasm = '20212'
INFO - 2021-08-09 06:48:27 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:48:29 --> Config Class Initialized
INFO - 2021-08-09 06:48:29 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:48:29 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:48:29 --> Utf8 Class Initialized
INFO - 2021-08-09 06:48:29 --> URI Class Initialized
INFO - 2021-08-09 06:48:29 --> Router Class Initialized
INFO - 2021-08-09 06:48:29 --> Output Class Initialized
INFO - 2021-08-09 06:48:29 --> Security Class Initialized
DEBUG - 2021-08-09 06:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:48:29 --> Input Class Initialized
INFO - 2021-08-09 06:48:29 --> Language Class Initialized
INFO - 2021-08-09 06:48:29 --> Language Class Initialized
INFO - 2021-08-09 06:48:29 --> Config Class Initialized
INFO - 2021-08-09 06:48:29 --> Loader Class Initialized
INFO - 2021-08-09 06:48:29 --> Helper loaded: url_helper
INFO - 2021-08-09 06:48:29 --> Helper loaded: file_helper
INFO - 2021-08-09 06:48:29 --> Helper loaded: form_helper
INFO - 2021-08-09 06:48:29 --> Helper loaded: my_helper
INFO - 2021-08-09 06:48:29 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:48:29 --> Controller Class Initialized
ERROR - 2021-08-09 06:48:29 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '396' AND tasm = '20212'
INFO - 2021-08-09 06:48:29 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:48:47 --> Config Class Initialized
INFO - 2021-08-09 06:48:47 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:48:47 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:48:47 --> Utf8 Class Initialized
INFO - 2021-08-09 06:48:47 --> URI Class Initialized
INFO - 2021-08-09 06:48:47 --> Router Class Initialized
INFO - 2021-08-09 06:48:47 --> Output Class Initialized
INFO - 2021-08-09 06:48:47 --> Security Class Initialized
DEBUG - 2021-08-09 06:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:48:47 --> Input Class Initialized
INFO - 2021-08-09 06:48:47 --> Language Class Initialized
INFO - 2021-08-09 06:48:47 --> Language Class Initialized
INFO - 2021-08-09 06:48:47 --> Config Class Initialized
INFO - 2021-08-09 06:48:47 --> Loader Class Initialized
INFO - 2021-08-09 06:48:47 --> Helper loaded: url_helper
INFO - 2021-08-09 06:48:47 --> Helper loaded: file_helper
INFO - 2021-08-09 06:48:47 --> Helper loaded: form_helper
INFO - 2021-08-09 06:48:47 --> Helper loaded: my_helper
INFO - 2021-08-09 06:48:47 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:48:47 --> Controller Class Initialized
ERROR - 2021-08-09 06:48:47 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '399' AND tasm = '20212'
INFO - 2021-08-09 06:48:47 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:48:48 --> Config Class Initialized
INFO - 2021-08-09 06:48:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:48:49 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:48:49 --> Utf8 Class Initialized
INFO - 2021-08-09 06:48:49 --> URI Class Initialized
INFO - 2021-08-09 06:48:49 --> Router Class Initialized
INFO - 2021-08-09 06:48:49 --> Output Class Initialized
INFO - 2021-08-09 06:48:49 --> Security Class Initialized
DEBUG - 2021-08-09 06:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:48:49 --> Input Class Initialized
INFO - 2021-08-09 06:48:49 --> Language Class Initialized
INFO - 2021-08-09 06:48:49 --> Language Class Initialized
INFO - 2021-08-09 06:48:49 --> Config Class Initialized
INFO - 2021-08-09 06:48:49 --> Loader Class Initialized
INFO - 2021-08-09 06:48:49 --> Helper loaded: url_helper
INFO - 2021-08-09 06:48:49 --> Helper loaded: file_helper
INFO - 2021-08-09 06:48:49 --> Helper loaded: form_helper
INFO - 2021-08-09 06:48:49 --> Helper loaded: my_helper
INFO - 2021-08-09 06:48:49 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:48:49 --> Controller Class Initialized
ERROR - 2021-08-09 06:48:49 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '400' AND tasm = '20212'
INFO - 2021-08-09 06:48:49 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:48:57 --> Config Class Initialized
INFO - 2021-08-09 06:48:57 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:48:57 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:48:57 --> Utf8 Class Initialized
INFO - 2021-08-09 06:48:57 --> URI Class Initialized
INFO - 2021-08-09 06:48:57 --> Router Class Initialized
INFO - 2021-08-09 06:48:57 --> Output Class Initialized
INFO - 2021-08-09 06:48:57 --> Security Class Initialized
DEBUG - 2021-08-09 06:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:48:57 --> Input Class Initialized
INFO - 2021-08-09 06:48:57 --> Language Class Initialized
INFO - 2021-08-09 06:48:57 --> Language Class Initialized
INFO - 2021-08-09 06:48:57 --> Config Class Initialized
INFO - 2021-08-09 06:48:57 --> Loader Class Initialized
INFO - 2021-08-09 06:48:57 --> Helper loaded: url_helper
INFO - 2021-08-09 06:48:57 --> Helper loaded: file_helper
INFO - 2021-08-09 06:48:57 --> Helper loaded: form_helper
INFO - 2021-08-09 06:48:57 --> Helper loaded: my_helper
INFO - 2021-08-09 06:48:57 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:48:57 --> Controller Class Initialized
ERROR - 2021-08-09 06:48:57 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '402' AND tasm = '20212'
INFO - 2021-08-09 06:48:57 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:48:58 --> Config Class Initialized
INFO - 2021-08-09 06:48:58 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:48:58 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:48:58 --> Utf8 Class Initialized
INFO - 2021-08-09 06:48:58 --> URI Class Initialized
INFO - 2021-08-09 06:48:58 --> Router Class Initialized
INFO - 2021-08-09 06:48:58 --> Output Class Initialized
INFO - 2021-08-09 06:48:58 --> Security Class Initialized
DEBUG - 2021-08-09 06:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:48:58 --> Input Class Initialized
INFO - 2021-08-09 06:48:58 --> Language Class Initialized
INFO - 2021-08-09 06:48:58 --> Language Class Initialized
INFO - 2021-08-09 06:48:58 --> Config Class Initialized
INFO - 2021-08-09 06:48:58 --> Loader Class Initialized
INFO - 2021-08-09 06:48:58 --> Helper loaded: url_helper
INFO - 2021-08-09 06:48:58 --> Helper loaded: file_helper
INFO - 2021-08-09 06:48:58 --> Helper loaded: form_helper
INFO - 2021-08-09 06:48:58 --> Helper loaded: my_helper
INFO - 2021-08-09 06:48:59 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:48:59 --> Controller Class Initialized
ERROR - 2021-08-09 06:48:59 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '403' AND tasm = '20212'
INFO - 2021-08-09 06:48:59 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:49:05 --> Config Class Initialized
INFO - 2021-08-09 06:49:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:49:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:49:05 --> Utf8 Class Initialized
INFO - 2021-08-09 06:49:05 --> URI Class Initialized
INFO - 2021-08-09 06:49:05 --> Router Class Initialized
INFO - 2021-08-09 06:49:05 --> Output Class Initialized
INFO - 2021-08-09 06:49:05 --> Security Class Initialized
DEBUG - 2021-08-09 06:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:49:05 --> Input Class Initialized
INFO - 2021-08-09 06:49:05 --> Language Class Initialized
INFO - 2021-08-09 06:49:05 --> Language Class Initialized
INFO - 2021-08-09 06:49:05 --> Config Class Initialized
INFO - 2021-08-09 06:49:05 --> Loader Class Initialized
INFO - 2021-08-09 06:49:05 --> Helper loaded: url_helper
INFO - 2021-08-09 06:49:05 --> Helper loaded: file_helper
INFO - 2021-08-09 06:49:05 --> Helper loaded: form_helper
INFO - 2021-08-09 06:49:05 --> Helper loaded: my_helper
INFO - 2021-08-09 06:49:05 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:49:05 --> Controller Class Initialized
ERROR - 2021-08-09 06:49:05 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '405' AND tasm = '20212'
INFO - 2021-08-09 06:49:06 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:49:07 --> Config Class Initialized
INFO - 2021-08-09 06:49:07 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:49:07 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:49:07 --> Utf8 Class Initialized
INFO - 2021-08-09 06:49:07 --> URI Class Initialized
INFO - 2021-08-09 06:49:07 --> Router Class Initialized
INFO - 2021-08-09 06:49:07 --> Output Class Initialized
INFO - 2021-08-09 06:49:07 --> Security Class Initialized
DEBUG - 2021-08-09 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:49:07 --> Input Class Initialized
INFO - 2021-08-09 06:49:07 --> Language Class Initialized
INFO - 2021-08-09 06:49:07 --> Language Class Initialized
INFO - 2021-08-09 06:49:07 --> Config Class Initialized
INFO - 2021-08-09 06:49:07 --> Loader Class Initialized
INFO - 2021-08-09 06:49:07 --> Helper loaded: url_helper
INFO - 2021-08-09 06:49:07 --> Helper loaded: file_helper
INFO - 2021-08-09 06:49:07 --> Helper loaded: form_helper
INFO - 2021-08-09 06:49:07 --> Helper loaded: my_helper
INFO - 2021-08-09 06:49:07 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:49:07 --> Controller Class Initialized
ERROR - 2021-08-09 06:49:07 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '406' AND tasm = '20212'
INFO - 2021-08-09 06:49:07 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:49:09 --> Config Class Initialized
INFO - 2021-08-09 06:49:09 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:49:09 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:49:09 --> Utf8 Class Initialized
INFO - 2021-08-09 06:49:09 --> URI Class Initialized
INFO - 2021-08-09 06:49:09 --> Router Class Initialized
INFO - 2021-08-09 06:49:09 --> Output Class Initialized
INFO - 2021-08-09 06:49:09 --> Security Class Initialized
DEBUG - 2021-08-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:49:09 --> Input Class Initialized
INFO - 2021-08-09 06:49:09 --> Language Class Initialized
INFO - 2021-08-09 06:49:09 --> Language Class Initialized
INFO - 2021-08-09 06:49:09 --> Config Class Initialized
INFO - 2021-08-09 06:49:09 --> Loader Class Initialized
INFO - 2021-08-09 06:49:09 --> Helper loaded: url_helper
INFO - 2021-08-09 06:49:09 --> Helper loaded: file_helper
INFO - 2021-08-09 06:49:09 --> Helper loaded: form_helper
INFO - 2021-08-09 06:49:09 --> Helper loaded: my_helper
INFO - 2021-08-09 06:49:09 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:49:09 --> Controller Class Initialized
ERROR - 2021-08-09 06:49:09 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '407' AND tasm = '20212'
INFO - 2021-08-09 06:49:09 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:49:11 --> Config Class Initialized
INFO - 2021-08-09 06:49:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:49:12 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:49:12 --> Utf8 Class Initialized
INFO - 2021-08-09 06:49:12 --> URI Class Initialized
INFO - 2021-08-09 06:49:12 --> Router Class Initialized
INFO - 2021-08-09 06:49:12 --> Output Class Initialized
INFO - 2021-08-09 06:49:12 --> Security Class Initialized
DEBUG - 2021-08-09 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:49:12 --> Input Class Initialized
INFO - 2021-08-09 06:49:12 --> Language Class Initialized
INFO - 2021-08-09 06:49:12 --> Language Class Initialized
INFO - 2021-08-09 06:49:12 --> Config Class Initialized
INFO - 2021-08-09 06:49:12 --> Loader Class Initialized
INFO - 2021-08-09 06:49:12 --> Helper loaded: url_helper
INFO - 2021-08-09 06:49:12 --> Helper loaded: file_helper
INFO - 2021-08-09 06:49:12 --> Helper loaded: form_helper
INFO - 2021-08-09 06:49:12 --> Helper loaded: my_helper
INFO - 2021-08-09 06:49:12 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:49:12 --> Controller Class Initialized
ERROR - 2021-08-09 06:49:12 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '408' AND tasm = '20212'
INFO - 2021-08-09 06:49:12 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:49:15 --> Config Class Initialized
INFO - 2021-08-09 06:49:15 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:49:15 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:49:15 --> Utf8 Class Initialized
INFO - 2021-08-09 06:49:15 --> URI Class Initialized
INFO - 2021-08-09 06:49:15 --> Router Class Initialized
INFO - 2021-08-09 06:49:15 --> Output Class Initialized
INFO - 2021-08-09 06:49:15 --> Security Class Initialized
DEBUG - 2021-08-09 06:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:49:15 --> Input Class Initialized
INFO - 2021-08-09 06:49:15 --> Language Class Initialized
INFO - 2021-08-09 06:49:15 --> Language Class Initialized
INFO - 2021-08-09 06:49:15 --> Config Class Initialized
INFO - 2021-08-09 06:49:15 --> Loader Class Initialized
INFO - 2021-08-09 06:49:15 --> Helper loaded: url_helper
INFO - 2021-08-09 06:49:15 --> Helper loaded: file_helper
INFO - 2021-08-09 06:49:15 --> Helper loaded: form_helper
INFO - 2021-08-09 06:49:15 --> Helper loaded: my_helper
INFO - 2021-08-09 06:49:15 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:49:15 --> Controller Class Initialized
ERROR - 2021-08-09 06:49:15 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '410' AND tasm = '20212'
INFO - 2021-08-09 06:49:15 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 06:49:16 --> Config Class Initialized
INFO - 2021-08-09 06:49:16 --> Hooks Class Initialized
DEBUG - 2021-08-09 06:49:16 --> UTF-8 Support Enabled
INFO - 2021-08-09 06:49:16 --> Utf8 Class Initialized
INFO - 2021-08-09 06:49:16 --> URI Class Initialized
INFO - 2021-08-09 06:49:16 --> Router Class Initialized
INFO - 2021-08-09 06:49:16 --> Output Class Initialized
INFO - 2021-08-09 06:49:16 --> Security Class Initialized
DEBUG - 2021-08-09 06:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 06:49:16 --> Input Class Initialized
INFO - 2021-08-09 06:49:16 --> Language Class Initialized
INFO - 2021-08-09 06:49:16 --> Language Class Initialized
INFO - 2021-08-09 06:49:16 --> Config Class Initialized
INFO - 2021-08-09 06:49:16 --> Loader Class Initialized
INFO - 2021-08-09 06:49:16 --> Helper loaded: url_helper
INFO - 2021-08-09 06:49:16 --> Helper loaded: file_helper
INFO - 2021-08-09 06:49:16 --> Helper loaded: form_helper
INFO - 2021-08-09 06:49:16 --> Helper loaded: my_helper
INFO - 2021-08-09 06:49:16 --> Database Driver Class Initialized
DEBUG - 2021-08-09 06:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 06:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 06:49:16 --> Controller Class Initialized
DEBUG - 2021-08-09 06:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 06:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 06:49:16 --> Final output sent to browser
DEBUG - 2021-08-09 06:49:16 --> Total execution time: 0.0558
INFO - 2021-08-09 07:05:34 --> Config Class Initialized
INFO - 2021-08-09 07:05:34 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:05:34 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:05:34 --> Utf8 Class Initialized
INFO - 2021-08-09 07:05:34 --> URI Class Initialized
INFO - 2021-08-09 07:05:34 --> Router Class Initialized
INFO - 2021-08-09 07:05:34 --> Output Class Initialized
INFO - 2021-08-09 07:05:34 --> Security Class Initialized
DEBUG - 2021-08-09 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:05:34 --> Input Class Initialized
INFO - 2021-08-09 07:05:34 --> Language Class Initialized
INFO - 2021-08-09 07:05:34 --> Language Class Initialized
INFO - 2021-08-09 07:05:34 --> Config Class Initialized
INFO - 2021-08-09 07:05:34 --> Loader Class Initialized
INFO - 2021-08-09 07:05:34 --> Helper loaded: url_helper
INFO - 2021-08-09 07:05:34 --> Helper loaded: file_helper
INFO - 2021-08-09 07:05:34 --> Helper loaded: form_helper
INFO - 2021-08-09 07:05:34 --> Helper loaded: my_helper
INFO - 2021-08-09 07:05:34 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:05:34 --> Controller Class Initialized
ERROR - 2021-08-09 07:05:34 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '480' AND tasm = '20212'
INFO - 2021-08-09 07:05:34 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 07:05:41 --> Config Class Initialized
INFO - 2021-08-09 07:05:41 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:05:41 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:05:41 --> Utf8 Class Initialized
INFO - 2021-08-09 07:05:41 --> URI Class Initialized
INFO - 2021-08-09 07:05:41 --> Router Class Initialized
INFO - 2021-08-09 07:05:41 --> Output Class Initialized
INFO - 2021-08-09 07:05:41 --> Security Class Initialized
DEBUG - 2021-08-09 07:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:05:41 --> Input Class Initialized
INFO - 2021-08-09 07:05:41 --> Language Class Initialized
INFO - 2021-08-09 07:05:41 --> Language Class Initialized
INFO - 2021-08-09 07:05:41 --> Config Class Initialized
INFO - 2021-08-09 07:05:41 --> Loader Class Initialized
INFO - 2021-08-09 07:05:41 --> Helper loaded: url_helper
INFO - 2021-08-09 07:05:41 --> Helper loaded: file_helper
INFO - 2021-08-09 07:05:41 --> Helper loaded: form_helper
INFO - 2021-08-09 07:05:41 --> Helper loaded: my_helper
INFO - 2021-08-09 07:05:41 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:05:41 --> Controller Class Initialized
ERROR - 2021-08-09 07:05:41 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '481' AND tasm = '20212'
INFO - 2021-08-09 07:05:41 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 07:06:16 --> Config Class Initialized
INFO - 2021-08-09 07:06:16 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:06:16 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:06:16 --> Utf8 Class Initialized
INFO - 2021-08-09 07:06:16 --> URI Class Initialized
INFO - 2021-08-09 07:06:16 --> Router Class Initialized
INFO - 2021-08-09 07:06:16 --> Output Class Initialized
INFO - 2021-08-09 07:06:16 --> Security Class Initialized
DEBUG - 2021-08-09 07:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:06:16 --> Input Class Initialized
INFO - 2021-08-09 07:06:16 --> Language Class Initialized
INFO - 2021-08-09 07:06:16 --> Language Class Initialized
INFO - 2021-08-09 07:06:16 --> Config Class Initialized
INFO - 2021-08-09 07:06:16 --> Loader Class Initialized
INFO - 2021-08-09 07:06:16 --> Helper loaded: url_helper
INFO - 2021-08-09 07:06:16 --> Helper loaded: file_helper
INFO - 2021-08-09 07:06:16 --> Helper loaded: form_helper
INFO - 2021-08-09 07:06:16 --> Helper loaded: my_helper
INFO - 2021-08-09 07:06:16 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:06:16 --> Controller Class Initialized
ERROR - 2021-08-09 07:06:16 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '484' AND tasm = '20212'
INFO - 2021-08-09 07:06:16 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 07:06:55 --> Config Class Initialized
INFO - 2021-08-09 07:06:55 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:06:55 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:06:55 --> Utf8 Class Initialized
INFO - 2021-08-09 07:06:56 --> URI Class Initialized
INFO - 2021-08-09 07:06:56 --> Router Class Initialized
INFO - 2021-08-09 07:06:56 --> Output Class Initialized
INFO - 2021-08-09 07:06:56 --> Security Class Initialized
DEBUG - 2021-08-09 07:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:06:56 --> Input Class Initialized
INFO - 2021-08-09 07:06:56 --> Language Class Initialized
INFO - 2021-08-09 07:06:56 --> Language Class Initialized
INFO - 2021-08-09 07:06:56 --> Config Class Initialized
INFO - 2021-08-09 07:06:56 --> Loader Class Initialized
INFO - 2021-08-09 07:06:56 --> Helper loaded: url_helper
INFO - 2021-08-09 07:06:56 --> Helper loaded: file_helper
INFO - 2021-08-09 07:06:56 --> Helper loaded: form_helper
INFO - 2021-08-09 07:06:56 --> Helper loaded: my_helper
INFO - 2021-08-09 07:06:56 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:06:56 --> Controller Class Initialized
ERROR - 2021-08-09 07:06:56 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '489' AND tasm = '20212'
INFO - 2021-08-09 07:06:56 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 07:07:12 --> Config Class Initialized
INFO - 2021-08-09 07:07:12 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:07:12 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:07:12 --> Utf8 Class Initialized
INFO - 2021-08-09 07:07:12 --> URI Class Initialized
INFO - 2021-08-09 07:07:12 --> Router Class Initialized
INFO - 2021-08-09 07:07:12 --> Output Class Initialized
INFO - 2021-08-09 07:07:12 --> Security Class Initialized
DEBUG - 2021-08-09 07:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:07:12 --> Input Class Initialized
INFO - 2021-08-09 07:07:12 --> Language Class Initialized
INFO - 2021-08-09 07:07:12 --> Language Class Initialized
INFO - 2021-08-09 07:07:12 --> Config Class Initialized
INFO - 2021-08-09 07:07:12 --> Loader Class Initialized
INFO - 2021-08-09 07:07:12 --> Helper loaded: url_helper
INFO - 2021-08-09 07:07:12 --> Helper loaded: file_helper
INFO - 2021-08-09 07:07:12 --> Helper loaded: form_helper
INFO - 2021-08-09 07:07:12 --> Helper loaded: my_helper
INFO - 2021-08-09 07:07:12 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:07:12 --> Controller Class Initialized
ERROR - 2021-08-09 07:07:12 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: DELETE FROM t_nilai_ekstra WHERE id_siswa = '491' AND tasm = '20212'
INFO - 2021-08-09 07:07:12 --> Language file loaded: language/english/db_lang.php
INFO - 2021-08-09 07:07:14 --> Config Class Initialized
INFO - 2021-08-09 07:07:14 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:07:14 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:07:14 --> Utf8 Class Initialized
INFO - 2021-08-09 07:07:14 --> URI Class Initialized
INFO - 2021-08-09 07:07:14 --> Router Class Initialized
INFO - 2021-08-09 07:07:14 --> Output Class Initialized
INFO - 2021-08-09 07:07:14 --> Security Class Initialized
DEBUG - 2021-08-09 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:07:14 --> Input Class Initialized
INFO - 2021-08-09 07:07:14 --> Language Class Initialized
INFO - 2021-08-09 07:07:14 --> Language Class Initialized
INFO - 2021-08-09 07:07:14 --> Config Class Initialized
INFO - 2021-08-09 07:07:14 --> Loader Class Initialized
INFO - 2021-08-09 07:07:14 --> Helper loaded: url_helper
INFO - 2021-08-09 07:07:14 --> Helper loaded: file_helper
INFO - 2021-08-09 07:07:14 --> Helper loaded: form_helper
INFO - 2021-08-09 07:07:14 --> Helper loaded: my_helper
INFO - 2021-08-09 07:07:14 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:07:14 --> Controller Class Initialized
DEBUG - 2021-08-09 07:07:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-09 07:07:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:07:14 --> Final output sent to browser
DEBUG - 2021-08-09 07:07:14 --> Total execution time: 0.0675
INFO - 2021-08-09 07:36:11 --> Config Class Initialized
INFO - 2021-08-09 07:36:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:36:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:36:11 --> Utf8 Class Initialized
INFO - 2021-08-09 07:36:11 --> URI Class Initialized
INFO - 2021-08-09 07:36:11 --> Router Class Initialized
INFO - 2021-08-09 07:36:11 --> Output Class Initialized
INFO - 2021-08-09 07:36:11 --> Security Class Initialized
DEBUG - 2021-08-09 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:36:11 --> Input Class Initialized
INFO - 2021-08-09 07:36:11 --> Language Class Initialized
INFO - 2021-08-09 07:36:11 --> Language Class Initialized
INFO - 2021-08-09 07:36:11 --> Config Class Initialized
INFO - 2021-08-09 07:36:11 --> Loader Class Initialized
INFO - 2021-08-09 07:36:11 --> Helper loaded: url_helper
INFO - 2021-08-09 07:36:11 --> Helper loaded: file_helper
INFO - 2021-08-09 07:36:11 --> Helper loaded: form_helper
INFO - 2021-08-09 07:36:11 --> Helper loaded: my_helper
INFO - 2021-08-09 07:36:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:36:11 --> Controller Class Initialized
DEBUG - 2021-08-09 07:36:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-08-09 07:36:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:36:11 --> Final output sent to browser
DEBUG - 2021-08-09 07:36:11 --> Total execution time: 0.0858
INFO - 2021-08-09 07:36:11 --> Config Class Initialized
INFO - 2021-08-09 07:36:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:36:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:36:11 --> Utf8 Class Initialized
INFO - 2021-08-09 07:36:11 --> URI Class Initialized
INFO - 2021-08-09 07:36:11 --> Router Class Initialized
INFO - 2021-08-09 07:36:11 --> Output Class Initialized
INFO - 2021-08-09 07:36:11 --> Security Class Initialized
DEBUG - 2021-08-09 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:36:11 --> Input Class Initialized
INFO - 2021-08-09 07:36:11 --> Language Class Initialized
INFO - 2021-08-09 07:36:11 --> Language Class Initialized
INFO - 2021-08-09 07:36:11 --> Config Class Initialized
INFO - 2021-08-09 07:36:11 --> Loader Class Initialized
INFO - 2021-08-09 07:36:11 --> Helper loaded: url_helper
INFO - 2021-08-09 07:36:11 --> Helper loaded: file_helper
INFO - 2021-08-09 07:36:11 --> Helper loaded: form_helper
INFO - 2021-08-09 07:36:11 --> Helper loaded: my_helper
INFO - 2021-08-09 07:36:11 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:36:11 --> Controller Class Initialized
INFO - 2021-08-09 07:36:13 --> Config Class Initialized
INFO - 2021-08-09 07:36:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:36:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:36:13 --> Utf8 Class Initialized
INFO - 2021-08-09 07:36:13 --> URI Class Initialized
INFO - 2021-08-09 07:36:13 --> Router Class Initialized
INFO - 2021-08-09 07:36:13 --> Output Class Initialized
INFO - 2021-08-09 07:36:13 --> Security Class Initialized
DEBUG - 2021-08-09 07:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:36:13 --> Input Class Initialized
INFO - 2021-08-09 07:36:13 --> Language Class Initialized
INFO - 2021-08-09 07:36:13 --> Language Class Initialized
INFO - 2021-08-09 07:36:13 --> Config Class Initialized
INFO - 2021-08-09 07:36:13 --> Loader Class Initialized
INFO - 2021-08-09 07:36:13 --> Helper loaded: url_helper
INFO - 2021-08-09 07:36:13 --> Helper loaded: file_helper
INFO - 2021-08-09 07:36:13 --> Helper loaded: form_helper
INFO - 2021-08-09 07:36:13 --> Helper loaded: my_helper
INFO - 2021-08-09 07:36:13 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:36:13 --> Controller Class Initialized
ERROR - 2021-08-09 07:36:13 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-08-09 07:36:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-08-09 07:36:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:36:13 --> Final output sent to browser
DEBUG - 2021-08-09 07:36:13 --> Total execution time: 0.0660
INFO - 2021-08-09 07:36:17 --> Config Class Initialized
INFO - 2021-08-09 07:36:17 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:36:17 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:36:17 --> Utf8 Class Initialized
INFO - 2021-08-09 07:36:17 --> URI Class Initialized
INFO - 2021-08-09 07:36:17 --> Router Class Initialized
INFO - 2021-08-09 07:36:17 --> Output Class Initialized
INFO - 2021-08-09 07:36:17 --> Security Class Initialized
DEBUG - 2021-08-09 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:36:17 --> Input Class Initialized
INFO - 2021-08-09 07:36:17 --> Language Class Initialized
INFO - 2021-08-09 07:36:17 --> Language Class Initialized
INFO - 2021-08-09 07:36:17 --> Config Class Initialized
INFO - 2021-08-09 07:36:17 --> Loader Class Initialized
INFO - 2021-08-09 07:36:17 --> Helper loaded: url_helper
INFO - 2021-08-09 07:36:17 --> Helper loaded: file_helper
INFO - 2021-08-09 07:36:17 --> Helper loaded: form_helper
INFO - 2021-08-09 07:36:17 --> Helper loaded: my_helper
INFO - 2021-08-09 07:36:17 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:36:17 --> Controller Class Initialized
DEBUG - 2021-08-09 07:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-08-09 07:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-09 07:36:17 --> Final output sent to browser
DEBUG - 2021-08-09 07:36:17 --> Total execution time: 0.0595
INFO - 2021-08-09 07:36:17 --> Config Class Initialized
INFO - 2021-08-09 07:36:17 --> Hooks Class Initialized
DEBUG - 2021-08-09 07:36:17 --> UTF-8 Support Enabled
INFO - 2021-08-09 07:36:17 --> Utf8 Class Initialized
INFO - 2021-08-09 07:36:17 --> URI Class Initialized
INFO - 2021-08-09 07:36:17 --> Router Class Initialized
INFO - 2021-08-09 07:36:17 --> Output Class Initialized
INFO - 2021-08-09 07:36:17 --> Security Class Initialized
DEBUG - 2021-08-09 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 07:36:17 --> Input Class Initialized
INFO - 2021-08-09 07:36:17 --> Language Class Initialized
INFO - 2021-08-09 07:36:17 --> Language Class Initialized
INFO - 2021-08-09 07:36:17 --> Config Class Initialized
INFO - 2021-08-09 07:36:17 --> Loader Class Initialized
INFO - 2021-08-09 07:36:17 --> Helper loaded: url_helper
INFO - 2021-08-09 07:36:17 --> Helper loaded: file_helper
INFO - 2021-08-09 07:36:17 --> Helper loaded: form_helper
INFO - 2021-08-09 07:36:17 --> Helper loaded: my_helper
INFO - 2021-08-09 07:36:17 --> Database Driver Class Initialized
DEBUG - 2021-08-09 07:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 07:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 07:36:17 --> Controller Class Initialized
