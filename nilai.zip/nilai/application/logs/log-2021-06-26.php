<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-26 02:50:18 --> Config Class Initialized
INFO - 2021-06-26 02:50:18 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:50:18 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:50:18 --> Utf8 Class Initialized
INFO - 2021-06-26 02:50:18 --> URI Class Initialized
DEBUG - 2021-06-26 02:50:19 --> No URI present. Default controller set.
INFO - 2021-06-26 02:50:19 --> Router Class Initialized
INFO - 2021-06-26 02:50:19 --> Output Class Initialized
INFO - 2021-06-26 02:50:19 --> Security Class Initialized
DEBUG - 2021-06-26 02:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:50:19 --> Input Class Initialized
INFO - 2021-06-26 02:50:19 --> Language Class Initialized
INFO - 2021-06-26 02:50:19 --> Language Class Initialized
INFO - 2021-06-26 02:50:19 --> Config Class Initialized
INFO - 2021-06-26 02:50:19 --> Loader Class Initialized
INFO - 2021-06-26 02:50:19 --> Helper loaded: url_helper
INFO - 2021-06-26 02:50:19 --> Helper loaded: file_helper
INFO - 2021-06-26 02:50:19 --> Helper loaded: form_helper
INFO - 2021-06-26 02:50:19 --> Helper loaded: my_helper
INFO - 2021-06-26 02:50:19 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:50:19 --> Controller Class Initialized
INFO - 2021-06-26 02:50:19 --> Config Class Initialized
INFO - 2021-06-26 02:50:19 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:50:19 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:50:19 --> Utf8 Class Initialized
INFO - 2021-06-26 02:50:19 --> URI Class Initialized
INFO - 2021-06-26 02:50:19 --> Router Class Initialized
INFO - 2021-06-26 02:50:19 --> Output Class Initialized
INFO - 2021-06-26 02:50:19 --> Security Class Initialized
DEBUG - 2021-06-26 02:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:50:19 --> Input Class Initialized
INFO - 2021-06-26 02:50:19 --> Language Class Initialized
INFO - 2021-06-26 02:50:19 --> Language Class Initialized
INFO - 2021-06-26 02:50:19 --> Config Class Initialized
INFO - 2021-06-26 02:50:19 --> Loader Class Initialized
INFO - 2021-06-26 02:50:19 --> Helper loaded: url_helper
INFO - 2021-06-26 02:50:19 --> Helper loaded: file_helper
INFO - 2021-06-26 02:50:19 --> Helper loaded: form_helper
INFO - 2021-06-26 02:50:19 --> Helper loaded: my_helper
INFO - 2021-06-26 02:50:19 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:50:19 --> Controller Class Initialized
DEBUG - 2021-06-26 02:50:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 02:50:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 02:50:19 --> Final output sent to browser
DEBUG - 2021-06-26 02:50:19 --> Total execution time: 0.0898
INFO - 2021-06-26 02:50:26 --> Config Class Initialized
INFO - 2021-06-26 02:50:26 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:50:26 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:50:26 --> Utf8 Class Initialized
INFO - 2021-06-26 02:50:26 --> URI Class Initialized
INFO - 2021-06-26 02:50:26 --> Router Class Initialized
INFO - 2021-06-26 02:50:26 --> Output Class Initialized
INFO - 2021-06-26 02:50:26 --> Security Class Initialized
DEBUG - 2021-06-26 02:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:50:26 --> Input Class Initialized
INFO - 2021-06-26 02:50:26 --> Language Class Initialized
INFO - 2021-06-26 02:50:26 --> Language Class Initialized
INFO - 2021-06-26 02:50:26 --> Config Class Initialized
INFO - 2021-06-26 02:50:26 --> Loader Class Initialized
INFO - 2021-06-26 02:50:26 --> Helper loaded: url_helper
INFO - 2021-06-26 02:50:26 --> Helper loaded: file_helper
INFO - 2021-06-26 02:50:26 --> Helper loaded: form_helper
INFO - 2021-06-26 02:50:26 --> Helper loaded: my_helper
INFO - 2021-06-26 02:50:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:50:26 --> Controller Class Initialized
INFO - 2021-06-26 02:50:26 --> Helper loaded: cookie_helper
INFO - 2021-06-26 02:50:26 --> Final output sent to browser
DEBUG - 2021-06-26 02:50:26 --> Total execution time: 0.0913
INFO - 2021-06-26 02:50:26 --> Config Class Initialized
INFO - 2021-06-26 02:50:26 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:50:26 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:50:26 --> Utf8 Class Initialized
INFO - 2021-06-26 02:50:26 --> URI Class Initialized
INFO - 2021-06-26 02:50:26 --> Router Class Initialized
INFO - 2021-06-26 02:50:26 --> Output Class Initialized
INFO - 2021-06-26 02:50:26 --> Security Class Initialized
DEBUG - 2021-06-26 02:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:50:26 --> Input Class Initialized
INFO - 2021-06-26 02:50:26 --> Language Class Initialized
INFO - 2021-06-26 02:50:26 --> Language Class Initialized
INFO - 2021-06-26 02:50:26 --> Config Class Initialized
INFO - 2021-06-26 02:50:26 --> Loader Class Initialized
INFO - 2021-06-26 02:50:26 --> Helper loaded: url_helper
INFO - 2021-06-26 02:50:26 --> Helper loaded: file_helper
INFO - 2021-06-26 02:50:26 --> Helper loaded: form_helper
INFO - 2021-06-26 02:50:26 --> Helper loaded: my_helper
INFO - 2021-06-26 02:50:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:50:26 --> Controller Class Initialized
DEBUG - 2021-06-26 02:50:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 02:50:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 02:50:27 --> Final output sent to browser
DEBUG - 2021-06-26 02:50:27 --> Total execution time: 0.7041
INFO - 2021-06-26 02:52:06 --> Config Class Initialized
INFO - 2021-06-26 02:52:06 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:52:06 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:52:06 --> Utf8 Class Initialized
INFO - 2021-06-26 02:52:06 --> URI Class Initialized
INFO - 2021-06-26 02:52:06 --> Router Class Initialized
INFO - 2021-06-26 02:52:06 --> Output Class Initialized
INFO - 2021-06-26 02:52:06 --> Security Class Initialized
DEBUG - 2021-06-26 02:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:52:06 --> Input Class Initialized
INFO - 2021-06-26 02:52:06 --> Language Class Initialized
INFO - 2021-06-26 02:52:06 --> Language Class Initialized
INFO - 2021-06-26 02:52:06 --> Config Class Initialized
INFO - 2021-06-26 02:52:06 --> Loader Class Initialized
INFO - 2021-06-26 02:52:06 --> Helper loaded: url_helper
INFO - 2021-06-26 02:52:06 --> Helper loaded: file_helper
INFO - 2021-06-26 02:52:06 --> Helper loaded: form_helper
INFO - 2021-06-26 02:52:06 --> Helper loaded: my_helper
INFO - 2021-06-26 02:52:06 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:52:07 --> Controller Class Initialized
DEBUG - 2021-06-26 02:52:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 02:52:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 02:52:07 --> Final output sent to browser
DEBUG - 2021-06-26 02:52:07 --> Total execution time: 0.1412
INFO - 2021-06-26 02:52:08 --> Config Class Initialized
INFO - 2021-06-26 02:52:08 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:52:08 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:52:08 --> Utf8 Class Initialized
INFO - 2021-06-26 02:52:08 --> URI Class Initialized
INFO - 2021-06-26 02:52:08 --> Router Class Initialized
INFO - 2021-06-26 02:52:08 --> Output Class Initialized
INFO - 2021-06-26 02:52:08 --> Security Class Initialized
DEBUG - 2021-06-26 02:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:52:08 --> Input Class Initialized
INFO - 2021-06-26 02:52:08 --> Language Class Initialized
INFO - 2021-06-26 02:52:08 --> Language Class Initialized
INFO - 2021-06-26 02:52:08 --> Config Class Initialized
INFO - 2021-06-26 02:52:08 --> Loader Class Initialized
INFO - 2021-06-26 02:52:08 --> Helper loaded: url_helper
INFO - 2021-06-26 02:52:08 --> Helper loaded: file_helper
INFO - 2021-06-26 02:52:08 --> Helper loaded: form_helper
INFO - 2021-06-26 02:52:08 --> Helper loaded: my_helper
INFO - 2021-06-26 02:52:08 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:52:08 --> Controller Class Initialized
DEBUG - 2021-06-26 02:52:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-26 02:52:08 --> Final output sent to browser
DEBUG - 2021-06-26 02:52:08 --> Total execution time: 0.0461
INFO - 2021-06-26 02:52:31 --> Config Class Initialized
INFO - 2021-06-26 02:52:31 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:52:31 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:52:31 --> Utf8 Class Initialized
INFO - 2021-06-26 02:52:31 --> URI Class Initialized
INFO - 2021-06-26 02:52:31 --> Router Class Initialized
INFO - 2021-06-26 02:52:31 --> Output Class Initialized
INFO - 2021-06-26 02:52:31 --> Security Class Initialized
DEBUG - 2021-06-26 02:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:52:31 --> Input Class Initialized
INFO - 2021-06-26 02:52:31 --> Language Class Initialized
INFO - 2021-06-26 02:52:31 --> Language Class Initialized
INFO - 2021-06-26 02:52:31 --> Config Class Initialized
INFO - 2021-06-26 02:52:31 --> Loader Class Initialized
INFO - 2021-06-26 02:52:31 --> Helper loaded: url_helper
INFO - 2021-06-26 02:52:31 --> Helper loaded: file_helper
INFO - 2021-06-26 02:52:31 --> Helper loaded: form_helper
INFO - 2021-06-26 02:52:31 --> Helper loaded: my_helper
INFO - 2021-06-26 02:52:31 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:52:31 --> Controller Class Initialized
DEBUG - 2021-06-26 02:52:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-26 02:52:31 --> Final output sent to browser
DEBUG - 2021-06-26 02:52:31 --> Total execution time: 0.0446
INFO - 2021-06-26 02:52:40 --> Config Class Initialized
INFO - 2021-06-26 02:52:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:52:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:52:40 --> Utf8 Class Initialized
INFO - 2021-06-26 02:52:40 --> URI Class Initialized
INFO - 2021-06-26 02:52:40 --> Router Class Initialized
INFO - 2021-06-26 02:52:40 --> Output Class Initialized
INFO - 2021-06-26 02:52:40 --> Security Class Initialized
DEBUG - 2021-06-26 02:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:52:40 --> Input Class Initialized
INFO - 2021-06-26 02:52:40 --> Language Class Initialized
INFO - 2021-06-26 02:52:40 --> Language Class Initialized
INFO - 2021-06-26 02:52:40 --> Config Class Initialized
INFO - 2021-06-26 02:52:40 --> Loader Class Initialized
INFO - 2021-06-26 02:52:40 --> Helper loaded: url_helper
INFO - 2021-06-26 02:52:40 --> Helper loaded: file_helper
INFO - 2021-06-26 02:52:40 --> Helper loaded: form_helper
INFO - 2021-06-26 02:52:40 --> Helper loaded: my_helper
INFO - 2021-06-26 02:52:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:52:40 --> Controller Class Initialized
DEBUG - 2021-06-26 02:52:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 02:52:40 --> Final output sent to browser
DEBUG - 2021-06-26 02:52:40 --> Total execution time: 0.0452
INFO - 2021-06-26 02:53:05 --> Config Class Initialized
INFO - 2021-06-26 02:53:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:53:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:53:05 --> Utf8 Class Initialized
INFO - 2021-06-26 02:53:05 --> URI Class Initialized
INFO - 2021-06-26 02:53:05 --> Router Class Initialized
INFO - 2021-06-26 02:53:05 --> Output Class Initialized
INFO - 2021-06-26 02:53:05 --> Security Class Initialized
DEBUG - 2021-06-26 02:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:53:05 --> Input Class Initialized
INFO - 2021-06-26 02:53:05 --> Language Class Initialized
INFO - 2021-06-26 02:53:05 --> Language Class Initialized
INFO - 2021-06-26 02:53:05 --> Config Class Initialized
INFO - 2021-06-26 02:53:05 --> Loader Class Initialized
INFO - 2021-06-26 02:53:05 --> Helper loaded: url_helper
INFO - 2021-06-26 02:53:05 --> Helper loaded: file_helper
INFO - 2021-06-26 02:53:05 --> Helper loaded: form_helper
INFO - 2021-06-26 02:53:05 --> Helper loaded: my_helper
INFO - 2021-06-26 02:53:05 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:53:05 --> Controller Class Initialized
DEBUG - 2021-06-26 02:53:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-26 02:53:05 --> Final output sent to browser
DEBUG - 2021-06-26 02:53:05 --> Total execution time: 0.0442
INFO - 2021-06-26 02:54:03 --> Config Class Initialized
INFO - 2021-06-26 02:54:03 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:54:03 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:54:03 --> Utf8 Class Initialized
INFO - 2021-06-26 02:54:03 --> URI Class Initialized
INFO - 2021-06-26 02:54:03 --> Router Class Initialized
INFO - 2021-06-26 02:54:03 --> Output Class Initialized
INFO - 2021-06-26 02:54:03 --> Security Class Initialized
DEBUG - 2021-06-26 02:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:54:03 --> Input Class Initialized
INFO - 2021-06-26 02:54:03 --> Language Class Initialized
INFO - 2021-06-26 02:54:03 --> Language Class Initialized
INFO - 2021-06-26 02:54:03 --> Config Class Initialized
INFO - 2021-06-26 02:54:03 --> Loader Class Initialized
INFO - 2021-06-26 02:54:03 --> Helper loaded: url_helper
INFO - 2021-06-26 02:54:03 --> Helper loaded: file_helper
INFO - 2021-06-26 02:54:03 --> Helper loaded: form_helper
INFO - 2021-06-26 02:54:03 --> Helper loaded: my_helper
INFO - 2021-06-26 02:54:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:54:03 --> Controller Class Initialized
DEBUG - 2021-06-26 02:54:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 02:54:03 --> Final output sent to browser
DEBUG - 2021-06-26 02:54:03 --> Total execution time: 0.0464
INFO - 2021-06-26 02:54:23 --> Config Class Initialized
INFO - 2021-06-26 02:54:23 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:54:23 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:54:23 --> Utf8 Class Initialized
INFO - 2021-06-26 02:54:23 --> URI Class Initialized
INFO - 2021-06-26 02:54:23 --> Router Class Initialized
INFO - 2021-06-26 02:54:23 --> Output Class Initialized
INFO - 2021-06-26 02:54:23 --> Security Class Initialized
DEBUG - 2021-06-26 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:54:23 --> Input Class Initialized
INFO - 2021-06-26 02:54:23 --> Language Class Initialized
INFO - 2021-06-26 02:54:23 --> Language Class Initialized
INFO - 2021-06-26 02:54:23 --> Config Class Initialized
INFO - 2021-06-26 02:54:23 --> Loader Class Initialized
INFO - 2021-06-26 02:54:23 --> Helper loaded: url_helper
INFO - 2021-06-26 02:54:23 --> Helper loaded: file_helper
INFO - 2021-06-26 02:54:23 --> Helper loaded: form_helper
INFO - 2021-06-26 02:54:23 --> Helper loaded: my_helper
INFO - 2021-06-26 02:54:23 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:54:23 --> Controller Class Initialized
DEBUG - 2021-06-26 02:54:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 02:54:23 --> Final output sent to browser
DEBUG - 2021-06-26 02:54:23 --> Total execution time: 0.0544
INFO - 2021-06-26 02:54:56 --> Config Class Initialized
INFO - 2021-06-26 02:54:56 --> Hooks Class Initialized
DEBUG - 2021-06-26 02:54:56 --> UTF-8 Support Enabled
INFO - 2021-06-26 02:54:56 --> Utf8 Class Initialized
INFO - 2021-06-26 02:54:56 --> URI Class Initialized
INFO - 2021-06-26 02:54:56 --> Router Class Initialized
INFO - 2021-06-26 02:54:56 --> Output Class Initialized
INFO - 2021-06-26 02:54:56 --> Security Class Initialized
DEBUG - 2021-06-26 02:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 02:54:56 --> Input Class Initialized
INFO - 2021-06-26 02:54:56 --> Language Class Initialized
INFO - 2021-06-26 02:54:56 --> Language Class Initialized
INFO - 2021-06-26 02:54:56 --> Config Class Initialized
INFO - 2021-06-26 02:54:56 --> Loader Class Initialized
INFO - 2021-06-26 02:54:56 --> Helper loaded: url_helper
INFO - 2021-06-26 02:54:56 --> Helper loaded: file_helper
INFO - 2021-06-26 02:54:56 --> Helper loaded: form_helper
INFO - 2021-06-26 02:54:56 --> Helper loaded: my_helper
INFO - 2021-06-26 02:54:56 --> Database Driver Class Initialized
DEBUG - 2021-06-26 02:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 02:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 02:54:56 --> Controller Class Initialized
DEBUG - 2021-06-26 02:54:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 02:54:56 --> Final output sent to browser
DEBUG - 2021-06-26 02:54:56 --> Total execution time: 0.0531
INFO - 2021-06-26 03:02:16 --> Config Class Initialized
INFO - 2021-06-26 03:02:16 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:02:16 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:02:16 --> Utf8 Class Initialized
INFO - 2021-06-26 03:02:16 --> URI Class Initialized
INFO - 2021-06-26 03:02:16 --> Router Class Initialized
INFO - 2021-06-26 03:02:16 --> Output Class Initialized
INFO - 2021-06-26 03:02:16 --> Security Class Initialized
DEBUG - 2021-06-26 03:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:02:16 --> Input Class Initialized
INFO - 2021-06-26 03:02:16 --> Language Class Initialized
INFO - 2021-06-26 03:02:16 --> Language Class Initialized
INFO - 2021-06-26 03:02:16 --> Config Class Initialized
INFO - 2021-06-26 03:02:16 --> Loader Class Initialized
INFO - 2021-06-26 03:02:16 --> Helper loaded: url_helper
INFO - 2021-06-26 03:02:16 --> Helper loaded: file_helper
INFO - 2021-06-26 03:02:16 --> Helper loaded: form_helper
INFO - 2021-06-26 03:02:16 --> Helper loaded: my_helper
INFO - 2021-06-26 03:02:16 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:02:16 --> Controller Class Initialized
DEBUG - 2021-06-26 03:02:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:02:16 --> Final output sent to browser
DEBUG - 2021-06-26 03:02:16 --> Total execution time: 0.0472
INFO - 2021-06-26 03:02:37 --> Config Class Initialized
INFO - 2021-06-26 03:02:37 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:02:37 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:02:37 --> Utf8 Class Initialized
INFO - 2021-06-26 03:02:37 --> URI Class Initialized
INFO - 2021-06-26 03:02:37 --> Router Class Initialized
INFO - 2021-06-26 03:02:37 --> Output Class Initialized
INFO - 2021-06-26 03:02:37 --> Security Class Initialized
DEBUG - 2021-06-26 03:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:02:37 --> Input Class Initialized
INFO - 2021-06-26 03:02:37 --> Language Class Initialized
INFO - 2021-06-26 03:02:37 --> Language Class Initialized
INFO - 2021-06-26 03:02:37 --> Config Class Initialized
INFO - 2021-06-26 03:02:37 --> Loader Class Initialized
INFO - 2021-06-26 03:02:37 --> Helper loaded: url_helper
INFO - 2021-06-26 03:02:37 --> Helper loaded: file_helper
INFO - 2021-06-26 03:02:37 --> Helper loaded: form_helper
INFO - 2021-06-26 03:02:37 --> Helper loaded: my_helper
INFO - 2021-06-26 03:02:37 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:02:37 --> Controller Class Initialized
DEBUG - 2021-06-26 03:02:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:02:37 --> Final output sent to browser
DEBUG - 2021-06-26 03:02:37 --> Total execution time: 0.0566
INFO - 2021-06-26 03:02:47 --> Config Class Initialized
INFO - 2021-06-26 03:02:47 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:02:47 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:02:47 --> Utf8 Class Initialized
INFO - 2021-06-26 03:02:47 --> URI Class Initialized
INFO - 2021-06-26 03:02:47 --> Router Class Initialized
INFO - 2021-06-26 03:02:47 --> Output Class Initialized
INFO - 2021-06-26 03:02:47 --> Security Class Initialized
DEBUG - 2021-06-26 03:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:02:47 --> Input Class Initialized
INFO - 2021-06-26 03:02:47 --> Language Class Initialized
INFO - 2021-06-26 03:02:47 --> Language Class Initialized
INFO - 2021-06-26 03:02:47 --> Config Class Initialized
INFO - 2021-06-26 03:02:47 --> Loader Class Initialized
INFO - 2021-06-26 03:02:47 --> Helper loaded: url_helper
INFO - 2021-06-26 03:02:47 --> Helper loaded: file_helper
INFO - 2021-06-26 03:02:47 --> Helper loaded: form_helper
INFO - 2021-06-26 03:02:47 --> Helper loaded: my_helper
INFO - 2021-06-26 03:02:47 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:02:47 --> Controller Class Initialized
DEBUG - 2021-06-26 03:02:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:02:47 --> Final output sent to browser
DEBUG - 2021-06-26 03:02:47 --> Total execution time: 0.0462
INFO - 2021-06-26 03:04:07 --> Config Class Initialized
INFO - 2021-06-26 03:04:07 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:04:07 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:04:07 --> Utf8 Class Initialized
INFO - 2021-06-26 03:04:07 --> URI Class Initialized
INFO - 2021-06-26 03:04:07 --> Router Class Initialized
INFO - 2021-06-26 03:04:07 --> Output Class Initialized
INFO - 2021-06-26 03:04:07 --> Security Class Initialized
DEBUG - 2021-06-26 03:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:04:07 --> Input Class Initialized
INFO - 2021-06-26 03:04:07 --> Language Class Initialized
INFO - 2021-06-26 03:04:07 --> Language Class Initialized
INFO - 2021-06-26 03:04:07 --> Config Class Initialized
INFO - 2021-06-26 03:04:07 --> Loader Class Initialized
INFO - 2021-06-26 03:04:07 --> Helper loaded: url_helper
INFO - 2021-06-26 03:04:07 --> Helper loaded: file_helper
INFO - 2021-06-26 03:04:07 --> Helper loaded: form_helper
INFO - 2021-06-26 03:04:07 --> Helper loaded: my_helper
INFO - 2021-06-26 03:04:07 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:04:07 --> Controller Class Initialized
DEBUG - 2021-06-26 03:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:04:07 --> Final output sent to browser
DEBUG - 2021-06-26 03:04:07 --> Total execution time: 0.0557
INFO - 2021-06-26 03:04:34 --> Config Class Initialized
INFO - 2021-06-26 03:04:34 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:04:34 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:04:34 --> Utf8 Class Initialized
INFO - 2021-06-26 03:04:34 --> URI Class Initialized
INFO - 2021-06-26 03:04:34 --> Router Class Initialized
INFO - 2021-06-26 03:04:34 --> Output Class Initialized
INFO - 2021-06-26 03:04:34 --> Security Class Initialized
DEBUG - 2021-06-26 03:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:04:34 --> Input Class Initialized
INFO - 2021-06-26 03:04:34 --> Language Class Initialized
INFO - 2021-06-26 03:04:34 --> Language Class Initialized
INFO - 2021-06-26 03:04:34 --> Config Class Initialized
INFO - 2021-06-26 03:04:34 --> Loader Class Initialized
INFO - 2021-06-26 03:04:34 --> Helper loaded: url_helper
INFO - 2021-06-26 03:04:34 --> Helper loaded: file_helper
INFO - 2021-06-26 03:04:34 --> Helper loaded: form_helper
INFO - 2021-06-26 03:04:34 --> Helper loaded: my_helper
INFO - 2021-06-26 03:04:34 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:04:34 --> Controller Class Initialized
DEBUG - 2021-06-26 03:04:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:04:34 --> Final output sent to browser
DEBUG - 2021-06-26 03:04:34 --> Total execution time: 0.0444
INFO - 2021-06-26 03:07:31 --> Config Class Initialized
INFO - 2021-06-26 03:07:31 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:07:31 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:07:31 --> Utf8 Class Initialized
INFO - 2021-06-26 03:07:31 --> URI Class Initialized
INFO - 2021-06-26 03:07:31 --> Router Class Initialized
INFO - 2021-06-26 03:07:31 --> Output Class Initialized
INFO - 2021-06-26 03:07:31 --> Security Class Initialized
DEBUG - 2021-06-26 03:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:07:31 --> Input Class Initialized
INFO - 2021-06-26 03:07:31 --> Language Class Initialized
INFO - 2021-06-26 03:07:31 --> Language Class Initialized
INFO - 2021-06-26 03:07:31 --> Config Class Initialized
INFO - 2021-06-26 03:07:31 --> Loader Class Initialized
INFO - 2021-06-26 03:07:31 --> Helper loaded: url_helper
INFO - 2021-06-26 03:07:31 --> Helper loaded: file_helper
INFO - 2021-06-26 03:07:31 --> Helper loaded: form_helper
INFO - 2021-06-26 03:07:31 --> Helper loaded: my_helper
INFO - 2021-06-26 03:07:31 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:07:31 --> Controller Class Initialized
DEBUG - 2021-06-26 03:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:07:31 --> Final output sent to browser
DEBUG - 2021-06-26 03:07:31 --> Total execution time: 0.0446
INFO - 2021-06-26 03:10:11 --> Config Class Initialized
INFO - 2021-06-26 03:10:11 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:10:11 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:10:11 --> Utf8 Class Initialized
INFO - 2021-06-26 03:10:11 --> URI Class Initialized
INFO - 2021-06-26 03:10:11 --> Router Class Initialized
INFO - 2021-06-26 03:10:11 --> Output Class Initialized
INFO - 2021-06-26 03:10:11 --> Security Class Initialized
DEBUG - 2021-06-26 03:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:10:11 --> Input Class Initialized
INFO - 2021-06-26 03:10:11 --> Language Class Initialized
INFO - 2021-06-26 03:10:11 --> Language Class Initialized
INFO - 2021-06-26 03:10:11 --> Config Class Initialized
INFO - 2021-06-26 03:10:11 --> Loader Class Initialized
INFO - 2021-06-26 03:10:11 --> Helper loaded: url_helper
INFO - 2021-06-26 03:10:11 --> Helper loaded: file_helper
INFO - 2021-06-26 03:10:11 --> Helper loaded: form_helper
INFO - 2021-06-26 03:10:11 --> Helper loaded: my_helper
INFO - 2021-06-26 03:10:11 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:10:11 --> Controller Class Initialized
DEBUG - 2021-06-26 03:10:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:10:11 --> Final output sent to browser
DEBUG - 2021-06-26 03:10:11 --> Total execution time: 0.0574
INFO - 2021-06-26 03:12:25 --> Config Class Initialized
INFO - 2021-06-26 03:12:25 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:12:25 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:12:25 --> Utf8 Class Initialized
INFO - 2021-06-26 03:12:25 --> URI Class Initialized
INFO - 2021-06-26 03:12:25 --> Router Class Initialized
INFO - 2021-06-26 03:12:25 --> Output Class Initialized
INFO - 2021-06-26 03:12:25 --> Security Class Initialized
DEBUG - 2021-06-26 03:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:12:25 --> Input Class Initialized
INFO - 2021-06-26 03:12:25 --> Language Class Initialized
INFO - 2021-06-26 03:12:25 --> Language Class Initialized
INFO - 2021-06-26 03:12:25 --> Config Class Initialized
INFO - 2021-06-26 03:12:25 --> Loader Class Initialized
INFO - 2021-06-26 03:12:25 --> Helper loaded: url_helper
INFO - 2021-06-26 03:12:25 --> Helper loaded: file_helper
INFO - 2021-06-26 03:12:25 --> Helper loaded: form_helper
INFO - 2021-06-26 03:12:25 --> Helper loaded: my_helper
INFO - 2021-06-26 03:12:25 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:12:25 --> Controller Class Initialized
DEBUG - 2021-06-26 03:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:12:25 --> Final output sent to browser
DEBUG - 2021-06-26 03:12:25 --> Total execution time: 0.0563
INFO - 2021-06-26 03:12:54 --> Config Class Initialized
INFO - 2021-06-26 03:12:54 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:12:54 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:12:54 --> Utf8 Class Initialized
INFO - 2021-06-26 03:12:54 --> URI Class Initialized
INFO - 2021-06-26 03:12:54 --> Router Class Initialized
INFO - 2021-06-26 03:12:54 --> Output Class Initialized
INFO - 2021-06-26 03:12:54 --> Security Class Initialized
DEBUG - 2021-06-26 03:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:12:54 --> Input Class Initialized
INFO - 2021-06-26 03:12:54 --> Language Class Initialized
INFO - 2021-06-26 03:12:54 --> Language Class Initialized
INFO - 2021-06-26 03:12:54 --> Config Class Initialized
INFO - 2021-06-26 03:12:54 --> Loader Class Initialized
INFO - 2021-06-26 03:12:54 --> Helper loaded: url_helper
INFO - 2021-06-26 03:12:54 --> Helper loaded: file_helper
INFO - 2021-06-26 03:12:54 --> Helper loaded: form_helper
INFO - 2021-06-26 03:12:54 --> Helper loaded: my_helper
INFO - 2021-06-26 03:12:54 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:12:54 --> Controller Class Initialized
DEBUG - 2021-06-26 03:12:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:12:54 --> Final output sent to browser
DEBUG - 2021-06-26 03:12:54 --> Total execution time: 0.0460
INFO - 2021-06-26 03:14:04 --> Config Class Initialized
INFO - 2021-06-26 03:14:04 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:14:04 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:14:04 --> Utf8 Class Initialized
INFO - 2021-06-26 03:14:04 --> URI Class Initialized
INFO - 2021-06-26 03:14:04 --> Router Class Initialized
INFO - 2021-06-26 03:14:04 --> Output Class Initialized
INFO - 2021-06-26 03:14:04 --> Security Class Initialized
DEBUG - 2021-06-26 03:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:14:04 --> Input Class Initialized
INFO - 2021-06-26 03:14:04 --> Language Class Initialized
INFO - 2021-06-26 03:14:04 --> Language Class Initialized
INFO - 2021-06-26 03:14:04 --> Config Class Initialized
INFO - 2021-06-26 03:14:04 --> Loader Class Initialized
INFO - 2021-06-26 03:14:04 --> Helper loaded: url_helper
INFO - 2021-06-26 03:14:04 --> Helper loaded: file_helper
INFO - 2021-06-26 03:14:04 --> Helper loaded: form_helper
INFO - 2021-06-26 03:14:04 --> Helper loaded: my_helper
INFO - 2021-06-26 03:14:04 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:14:04 --> Controller Class Initialized
DEBUG - 2021-06-26 03:14:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:14:04 --> Final output sent to browser
DEBUG - 2021-06-26 03:14:04 --> Total execution time: 0.0464
INFO - 2021-06-26 03:16:42 --> Config Class Initialized
INFO - 2021-06-26 03:16:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:16:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:16:42 --> Utf8 Class Initialized
INFO - 2021-06-26 03:16:42 --> URI Class Initialized
INFO - 2021-06-26 03:16:42 --> Router Class Initialized
INFO - 2021-06-26 03:16:42 --> Output Class Initialized
INFO - 2021-06-26 03:16:42 --> Security Class Initialized
DEBUG - 2021-06-26 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:16:42 --> Input Class Initialized
INFO - 2021-06-26 03:16:42 --> Language Class Initialized
INFO - 2021-06-26 03:16:42 --> Language Class Initialized
INFO - 2021-06-26 03:16:42 --> Config Class Initialized
INFO - 2021-06-26 03:16:42 --> Loader Class Initialized
INFO - 2021-06-26 03:16:42 --> Helper loaded: url_helper
INFO - 2021-06-26 03:16:42 --> Helper loaded: file_helper
INFO - 2021-06-26 03:16:42 --> Helper loaded: form_helper
INFO - 2021-06-26 03:16:42 --> Helper loaded: my_helper
INFO - 2021-06-26 03:16:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:16:42 --> Controller Class Initialized
DEBUG - 2021-06-26 03:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:16:42 --> Final output sent to browser
DEBUG - 2021-06-26 03:16:42 --> Total execution time: 0.0459
INFO - 2021-06-26 03:18:31 --> Config Class Initialized
INFO - 2021-06-26 03:18:31 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:18:31 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:18:31 --> Utf8 Class Initialized
INFO - 2021-06-26 03:18:31 --> URI Class Initialized
INFO - 2021-06-26 03:18:31 --> Router Class Initialized
INFO - 2021-06-26 03:18:31 --> Output Class Initialized
INFO - 2021-06-26 03:18:31 --> Security Class Initialized
DEBUG - 2021-06-26 03:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:18:31 --> Input Class Initialized
INFO - 2021-06-26 03:18:31 --> Language Class Initialized
INFO - 2021-06-26 03:18:31 --> Language Class Initialized
INFO - 2021-06-26 03:18:31 --> Config Class Initialized
INFO - 2021-06-26 03:18:31 --> Loader Class Initialized
INFO - 2021-06-26 03:18:31 --> Helper loaded: url_helper
INFO - 2021-06-26 03:18:31 --> Helper loaded: file_helper
INFO - 2021-06-26 03:18:31 --> Helper loaded: form_helper
INFO - 2021-06-26 03:18:31 --> Helper loaded: my_helper
INFO - 2021-06-26 03:18:31 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:18:31 --> Controller Class Initialized
DEBUG - 2021-06-26 03:18:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:18:31 --> Final output sent to browser
DEBUG - 2021-06-26 03:18:31 --> Total execution time: 0.0564
INFO - 2021-06-26 03:20:36 --> Config Class Initialized
INFO - 2021-06-26 03:20:36 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:20:36 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:20:36 --> Utf8 Class Initialized
INFO - 2021-06-26 03:20:36 --> URI Class Initialized
INFO - 2021-06-26 03:20:36 --> Router Class Initialized
INFO - 2021-06-26 03:20:36 --> Output Class Initialized
INFO - 2021-06-26 03:20:36 --> Security Class Initialized
DEBUG - 2021-06-26 03:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:20:36 --> Input Class Initialized
INFO - 2021-06-26 03:20:36 --> Language Class Initialized
INFO - 2021-06-26 03:20:36 --> Language Class Initialized
INFO - 2021-06-26 03:20:36 --> Config Class Initialized
INFO - 2021-06-26 03:20:36 --> Loader Class Initialized
INFO - 2021-06-26 03:20:36 --> Helper loaded: url_helper
INFO - 2021-06-26 03:20:36 --> Helper loaded: file_helper
INFO - 2021-06-26 03:20:36 --> Helper loaded: form_helper
INFO - 2021-06-26 03:20:36 --> Helper loaded: my_helper
INFO - 2021-06-26 03:20:36 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:20:36 --> Controller Class Initialized
DEBUG - 2021-06-26 03:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:20:36 --> Final output sent to browser
DEBUG - 2021-06-26 03:20:36 --> Total execution time: 0.0549
INFO - 2021-06-26 03:20:47 --> Config Class Initialized
INFO - 2021-06-26 03:20:47 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:20:47 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:20:47 --> Utf8 Class Initialized
INFO - 2021-06-26 03:20:47 --> URI Class Initialized
INFO - 2021-06-26 03:20:47 --> Router Class Initialized
INFO - 2021-06-26 03:20:47 --> Output Class Initialized
INFO - 2021-06-26 03:20:47 --> Security Class Initialized
DEBUG - 2021-06-26 03:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:20:47 --> Input Class Initialized
INFO - 2021-06-26 03:20:47 --> Language Class Initialized
INFO - 2021-06-26 03:20:47 --> Language Class Initialized
INFO - 2021-06-26 03:20:47 --> Config Class Initialized
INFO - 2021-06-26 03:20:47 --> Loader Class Initialized
INFO - 2021-06-26 03:20:48 --> Helper loaded: url_helper
INFO - 2021-06-26 03:20:48 --> Helper loaded: file_helper
INFO - 2021-06-26 03:20:48 --> Helper loaded: form_helper
INFO - 2021-06-26 03:20:48 --> Helper loaded: my_helper
INFO - 2021-06-26 03:20:48 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:20:48 --> Controller Class Initialized
DEBUG - 2021-06-26 03:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:20:48 --> Final output sent to browser
DEBUG - 2021-06-26 03:20:48 --> Total execution time: 0.0551
INFO - 2021-06-26 03:20:58 --> Config Class Initialized
INFO - 2021-06-26 03:20:58 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:20:58 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:20:58 --> Utf8 Class Initialized
INFO - 2021-06-26 03:20:58 --> URI Class Initialized
INFO - 2021-06-26 03:20:58 --> Router Class Initialized
INFO - 2021-06-26 03:20:58 --> Output Class Initialized
INFO - 2021-06-26 03:20:58 --> Security Class Initialized
DEBUG - 2021-06-26 03:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:20:59 --> Input Class Initialized
INFO - 2021-06-26 03:20:59 --> Language Class Initialized
INFO - 2021-06-26 03:20:59 --> Language Class Initialized
INFO - 2021-06-26 03:20:59 --> Config Class Initialized
INFO - 2021-06-26 03:20:59 --> Loader Class Initialized
INFO - 2021-06-26 03:20:59 --> Helper loaded: url_helper
INFO - 2021-06-26 03:20:59 --> Helper loaded: file_helper
INFO - 2021-06-26 03:20:59 --> Helper loaded: form_helper
INFO - 2021-06-26 03:20:59 --> Helper loaded: my_helper
INFO - 2021-06-26 03:20:59 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:20:59 --> Controller Class Initialized
DEBUG - 2021-06-26 03:20:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:20:59 --> Final output sent to browser
DEBUG - 2021-06-26 03:20:59 --> Total execution time: 0.0564
INFO - 2021-06-26 03:21:27 --> Config Class Initialized
INFO - 2021-06-26 03:21:27 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:21:27 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:21:27 --> Utf8 Class Initialized
INFO - 2021-06-26 03:21:27 --> URI Class Initialized
INFO - 2021-06-26 03:21:27 --> Router Class Initialized
INFO - 2021-06-26 03:21:27 --> Output Class Initialized
INFO - 2021-06-26 03:21:27 --> Security Class Initialized
DEBUG - 2021-06-26 03:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:21:27 --> Input Class Initialized
INFO - 2021-06-26 03:21:27 --> Language Class Initialized
INFO - 2021-06-26 03:21:27 --> Language Class Initialized
INFO - 2021-06-26 03:21:27 --> Config Class Initialized
INFO - 2021-06-26 03:21:27 --> Loader Class Initialized
INFO - 2021-06-26 03:21:27 --> Helper loaded: url_helper
INFO - 2021-06-26 03:21:27 --> Helper loaded: file_helper
INFO - 2021-06-26 03:21:27 --> Helper loaded: form_helper
INFO - 2021-06-26 03:21:27 --> Helper loaded: my_helper
INFO - 2021-06-26 03:21:27 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:21:27 --> Controller Class Initialized
DEBUG - 2021-06-26 03:21:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:21:27 --> Final output sent to browser
DEBUG - 2021-06-26 03:21:27 --> Total execution time: 0.0451
INFO - 2021-06-26 03:22:21 --> Config Class Initialized
INFO - 2021-06-26 03:22:21 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:22:21 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:22:21 --> Utf8 Class Initialized
INFO - 2021-06-26 03:22:21 --> URI Class Initialized
INFO - 2021-06-26 03:22:21 --> Router Class Initialized
INFO - 2021-06-26 03:22:21 --> Output Class Initialized
INFO - 2021-06-26 03:22:21 --> Security Class Initialized
DEBUG - 2021-06-26 03:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:22:21 --> Input Class Initialized
INFO - 2021-06-26 03:22:21 --> Language Class Initialized
INFO - 2021-06-26 03:22:21 --> Language Class Initialized
INFO - 2021-06-26 03:22:21 --> Config Class Initialized
INFO - 2021-06-26 03:22:21 --> Loader Class Initialized
INFO - 2021-06-26 03:22:21 --> Helper loaded: url_helper
INFO - 2021-06-26 03:22:21 --> Helper loaded: file_helper
INFO - 2021-06-26 03:22:21 --> Helper loaded: form_helper
INFO - 2021-06-26 03:22:21 --> Helper loaded: my_helper
INFO - 2021-06-26 03:22:21 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:22:21 --> Controller Class Initialized
DEBUG - 2021-06-26 03:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-26 03:22:21 --> Final output sent to browser
DEBUG - 2021-06-26 03:22:21 --> Total execution time: 0.3342
INFO - 2021-06-26 03:25:07 --> Config Class Initialized
INFO - 2021-06-26 03:25:07 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:25:07 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:25:07 --> Utf8 Class Initialized
INFO - 2021-06-26 03:25:07 --> URI Class Initialized
INFO - 2021-06-26 03:25:07 --> Router Class Initialized
INFO - 2021-06-26 03:25:07 --> Output Class Initialized
INFO - 2021-06-26 03:25:07 --> Security Class Initialized
DEBUG - 2021-06-26 03:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:25:07 --> Input Class Initialized
INFO - 2021-06-26 03:25:07 --> Language Class Initialized
INFO - 2021-06-26 03:25:07 --> Language Class Initialized
INFO - 2021-06-26 03:25:07 --> Config Class Initialized
INFO - 2021-06-26 03:25:07 --> Loader Class Initialized
INFO - 2021-06-26 03:25:07 --> Helper loaded: url_helper
INFO - 2021-06-26 03:25:07 --> Helper loaded: file_helper
INFO - 2021-06-26 03:25:07 --> Helper loaded: form_helper
INFO - 2021-06-26 03:25:07 --> Helper loaded: my_helper
INFO - 2021-06-26 03:25:07 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:25:07 --> Controller Class Initialized
DEBUG - 2021-06-26 03:25:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:25:07 --> Final output sent to browser
DEBUG - 2021-06-26 03:25:07 --> Total execution time: 0.0584
INFO - 2021-06-26 03:25:30 --> Config Class Initialized
INFO - 2021-06-26 03:25:30 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:25:30 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:25:30 --> Utf8 Class Initialized
INFO - 2021-06-26 03:25:30 --> URI Class Initialized
INFO - 2021-06-26 03:25:30 --> Router Class Initialized
INFO - 2021-06-26 03:25:30 --> Output Class Initialized
INFO - 2021-06-26 03:25:30 --> Security Class Initialized
DEBUG - 2021-06-26 03:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:25:30 --> Input Class Initialized
INFO - 2021-06-26 03:25:30 --> Language Class Initialized
INFO - 2021-06-26 03:25:30 --> Language Class Initialized
INFO - 2021-06-26 03:25:30 --> Config Class Initialized
INFO - 2021-06-26 03:25:30 --> Loader Class Initialized
INFO - 2021-06-26 03:25:30 --> Helper loaded: url_helper
INFO - 2021-06-26 03:25:30 --> Helper loaded: file_helper
INFO - 2021-06-26 03:25:30 --> Helper loaded: form_helper
INFO - 2021-06-26 03:25:30 --> Helper loaded: my_helper
INFO - 2021-06-26 03:25:30 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:25:30 --> Controller Class Initialized
DEBUG - 2021-06-26 03:25:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:25:30 --> Final output sent to browser
DEBUG - 2021-06-26 03:25:30 --> Total execution time: 0.0569
INFO - 2021-06-26 03:25:42 --> Config Class Initialized
INFO - 2021-06-26 03:25:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:25:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:25:42 --> Utf8 Class Initialized
INFO - 2021-06-26 03:25:42 --> URI Class Initialized
INFO - 2021-06-26 03:25:42 --> Router Class Initialized
INFO - 2021-06-26 03:25:42 --> Output Class Initialized
INFO - 2021-06-26 03:25:42 --> Security Class Initialized
DEBUG - 2021-06-26 03:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:25:42 --> Input Class Initialized
INFO - 2021-06-26 03:25:42 --> Language Class Initialized
INFO - 2021-06-26 03:25:42 --> Language Class Initialized
INFO - 2021-06-26 03:25:42 --> Config Class Initialized
INFO - 2021-06-26 03:25:42 --> Loader Class Initialized
INFO - 2021-06-26 03:25:42 --> Helper loaded: url_helper
INFO - 2021-06-26 03:25:42 --> Helper loaded: file_helper
INFO - 2021-06-26 03:25:42 --> Helper loaded: form_helper
INFO - 2021-06-26 03:25:42 --> Helper loaded: my_helper
INFO - 2021-06-26 03:25:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:25:42 --> Controller Class Initialized
DEBUG - 2021-06-26 03:25:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:25:42 --> Final output sent to browser
DEBUG - 2021-06-26 03:25:42 --> Total execution time: 0.0546
INFO - 2021-06-26 03:25:57 --> Config Class Initialized
INFO - 2021-06-26 03:25:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:25:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:25:57 --> Utf8 Class Initialized
INFO - 2021-06-26 03:25:57 --> URI Class Initialized
INFO - 2021-06-26 03:25:57 --> Router Class Initialized
INFO - 2021-06-26 03:25:57 --> Output Class Initialized
INFO - 2021-06-26 03:25:57 --> Security Class Initialized
DEBUG - 2021-06-26 03:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:25:57 --> Input Class Initialized
INFO - 2021-06-26 03:25:57 --> Language Class Initialized
INFO - 2021-06-26 03:25:57 --> Language Class Initialized
INFO - 2021-06-26 03:25:57 --> Config Class Initialized
INFO - 2021-06-26 03:25:57 --> Loader Class Initialized
INFO - 2021-06-26 03:25:57 --> Helper loaded: url_helper
INFO - 2021-06-26 03:25:57 --> Helper loaded: file_helper
INFO - 2021-06-26 03:25:57 --> Helper loaded: form_helper
INFO - 2021-06-26 03:25:57 --> Helper loaded: my_helper
INFO - 2021-06-26 03:25:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:25:57 --> Controller Class Initialized
DEBUG - 2021-06-26 03:25:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:25:57 --> Final output sent to browser
DEBUG - 2021-06-26 03:25:57 --> Total execution time: 0.0554
INFO - 2021-06-26 03:26:08 --> Config Class Initialized
INFO - 2021-06-26 03:26:08 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:26:08 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:26:08 --> Utf8 Class Initialized
INFO - 2021-06-26 03:26:08 --> URI Class Initialized
INFO - 2021-06-26 03:26:08 --> Router Class Initialized
INFO - 2021-06-26 03:26:08 --> Output Class Initialized
INFO - 2021-06-26 03:26:08 --> Security Class Initialized
DEBUG - 2021-06-26 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:26:08 --> Input Class Initialized
INFO - 2021-06-26 03:26:08 --> Language Class Initialized
INFO - 2021-06-26 03:26:08 --> Language Class Initialized
INFO - 2021-06-26 03:26:08 --> Config Class Initialized
INFO - 2021-06-26 03:26:08 --> Loader Class Initialized
INFO - 2021-06-26 03:26:08 --> Helper loaded: url_helper
INFO - 2021-06-26 03:26:08 --> Helper loaded: file_helper
INFO - 2021-06-26 03:26:08 --> Helper loaded: form_helper
INFO - 2021-06-26 03:26:08 --> Helper loaded: my_helper
INFO - 2021-06-26 03:26:08 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:26:08 --> Controller Class Initialized
DEBUG - 2021-06-26 03:26:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:26:08 --> Final output sent to browser
DEBUG - 2021-06-26 03:26:08 --> Total execution time: 0.0549
INFO - 2021-06-26 03:26:18 --> Config Class Initialized
INFO - 2021-06-26 03:26:18 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:26:18 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:26:18 --> Utf8 Class Initialized
INFO - 2021-06-26 03:26:18 --> URI Class Initialized
INFO - 2021-06-26 03:26:18 --> Router Class Initialized
INFO - 2021-06-26 03:26:18 --> Output Class Initialized
INFO - 2021-06-26 03:26:18 --> Security Class Initialized
DEBUG - 2021-06-26 03:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:26:18 --> Input Class Initialized
INFO - 2021-06-26 03:26:18 --> Language Class Initialized
INFO - 2021-06-26 03:26:18 --> Language Class Initialized
INFO - 2021-06-26 03:26:18 --> Config Class Initialized
INFO - 2021-06-26 03:26:18 --> Loader Class Initialized
INFO - 2021-06-26 03:26:18 --> Helper loaded: url_helper
INFO - 2021-06-26 03:26:18 --> Helper loaded: file_helper
INFO - 2021-06-26 03:26:18 --> Helper loaded: form_helper
INFO - 2021-06-26 03:26:18 --> Helper loaded: my_helper
INFO - 2021-06-26 03:26:18 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:26:18 --> Controller Class Initialized
DEBUG - 2021-06-26 03:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:26:18 --> Final output sent to browser
DEBUG - 2021-06-26 03:26:18 --> Total execution time: 0.0453
INFO - 2021-06-26 03:27:10 --> Config Class Initialized
INFO - 2021-06-26 03:27:10 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:27:10 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:27:10 --> Utf8 Class Initialized
INFO - 2021-06-26 03:27:10 --> URI Class Initialized
INFO - 2021-06-26 03:27:10 --> Router Class Initialized
INFO - 2021-06-26 03:27:10 --> Output Class Initialized
INFO - 2021-06-26 03:27:10 --> Security Class Initialized
DEBUG - 2021-06-26 03:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:27:10 --> Input Class Initialized
INFO - 2021-06-26 03:27:10 --> Language Class Initialized
INFO - 2021-06-26 03:27:10 --> Language Class Initialized
INFO - 2021-06-26 03:27:10 --> Config Class Initialized
INFO - 2021-06-26 03:27:10 --> Loader Class Initialized
INFO - 2021-06-26 03:27:10 --> Helper loaded: url_helper
INFO - 2021-06-26 03:27:10 --> Helper loaded: file_helper
INFO - 2021-06-26 03:27:10 --> Helper loaded: form_helper
INFO - 2021-06-26 03:27:10 --> Helper loaded: my_helper
INFO - 2021-06-26 03:27:10 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:27:10 --> Controller Class Initialized
DEBUG - 2021-06-26 03:27:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:27:10 --> Final output sent to browser
DEBUG - 2021-06-26 03:27:10 --> Total execution time: 0.0461
INFO - 2021-06-26 03:27:20 --> Config Class Initialized
INFO - 2021-06-26 03:27:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:27:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:27:20 --> Utf8 Class Initialized
INFO - 2021-06-26 03:27:20 --> URI Class Initialized
INFO - 2021-06-26 03:27:20 --> Router Class Initialized
INFO - 2021-06-26 03:27:20 --> Output Class Initialized
INFO - 2021-06-26 03:27:20 --> Security Class Initialized
DEBUG - 2021-06-26 03:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:27:20 --> Input Class Initialized
INFO - 2021-06-26 03:27:20 --> Language Class Initialized
INFO - 2021-06-26 03:27:20 --> Language Class Initialized
INFO - 2021-06-26 03:27:20 --> Config Class Initialized
INFO - 2021-06-26 03:27:20 --> Loader Class Initialized
INFO - 2021-06-26 03:27:20 --> Helper loaded: url_helper
INFO - 2021-06-26 03:27:20 --> Helper loaded: file_helper
INFO - 2021-06-26 03:27:20 --> Helper loaded: form_helper
INFO - 2021-06-26 03:27:20 --> Helper loaded: my_helper
INFO - 2021-06-26 03:27:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:27:21 --> Controller Class Initialized
DEBUG - 2021-06-26 03:27:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:27:21 --> Final output sent to browser
DEBUG - 2021-06-26 03:27:21 --> Total execution time: 0.0572
INFO - 2021-06-26 03:27:43 --> Config Class Initialized
INFO - 2021-06-26 03:27:43 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:27:43 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:27:43 --> Utf8 Class Initialized
INFO - 2021-06-26 03:27:43 --> URI Class Initialized
INFO - 2021-06-26 03:27:43 --> Router Class Initialized
INFO - 2021-06-26 03:27:43 --> Output Class Initialized
INFO - 2021-06-26 03:27:43 --> Security Class Initialized
DEBUG - 2021-06-26 03:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:27:43 --> Input Class Initialized
INFO - 2021-06-26 03:27:43 --> Language Class Initialized
INFO - 2021-06-26 03:27:43 --> Language Class Initialized
INFO - 2021-06-26 03:27:43 --> Config Class Initialized
INFO - 2021-06-26 03:27:43 --> Loader Class Initialized
INFO - 2021-06-26 03:27:43 --> Helper loaded: url_helper
INFO - 2021-06-26 03:27:43 --> Helper loaded: file_helper
INFO - 2021-06-26 03:27:43 --> Helper loaded: form_helper
INFO - 2021-06-26 03:27:43 --> Helper loaded: my_helper
INFO - 2021-06-26 03:27:43 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:27:43 --> Controller Class Initialized
DEBUG - 2021-06-26 03:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:27:43 --> Final output sent to browser
DEBUG - 2021-06-26 03:27:43 --> Total execution time: 0.0551
INFO - 2021-06-26 03:28:06 --> Config Class Initialized
INFO - 2021-06-26 03:28:06 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:28:06 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:28:06 --> Utf8 Class Initialized
INFO - 2021-06-26 03:28:06 --> URI Class Initialized
INFO - 2021-06-26 03:28:06 --> Router Class Initialized
INFO - 2021-06-26 03:28:06 --> Output Class Initialized
INFO - 2021-06-26 03:28:06 --> Security Class Initialized
DEBUG - 2021-06-26 03:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:28:06 --> Input Class Initialized
INFO - 2021-06-26 03:28:06 --> Language Class Initialized
INFO - 2021-06-26 03:28:06 --> Language Class Initialized
INFO - 2021-06-26 03:28:06 --> Config Class Initialized
INFO - 2021-06-26 03:28:06 --> Loader Class Initialized
INFO - 2021-06-26 03:28:06 --> Helper loaded: url_helper
INFO - 2021-06-26 03:28:06 --> Helper loaded: file_helper
INFO - 2021-06-26 03:28:06 --> Helper loaded: form_helper
INFO - 2021-06-26 03:28:06 --> Helper loaded: my_helper
INFO - 2021-06-26 03:28:06 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:28:06 --> Controller Class Initialized
DEBUG - 2021-06-26 03:28:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:28:06 --> Final output sent to browser
DEBUG - 2021-06-26 03:28:06 --> Total execution time: 0.0568
INFO - 2021-06-26 03:28:07 --> Config Class Initialized
INFO - 2021-06-26 03:28:07 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:28:07 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:28:07 --> Utf8 Class Initialized
INFO - 2021-06-26 03:28:07 --> URI Class Initialized
INFO - 2021-06-26 03:28:07 --> Router Class Initialized
INFO - 2021-06-26 03:28:07 --> Output Class Initialized
INFO - 2021-06-26 03:28:07 --> Security Class Initialized
DEBUG - 2021-06-26 03:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:28:07 --> Input Class Initialized
INFO - 2021-06-26 03:28:07 --> Language Class Initialized
INFO - 2021-06-26 03:28:07 --> Language Class Initialized
INFO - 2021-06-26 03:28:07 --> Config Class Initialized
INFO - 2021-06-26 03:28:07 --> Loader Class Initialized
INFO - 2021-06-26 03:28:07 --> Helper loaded: url_helper
INFO - 2021-06-26 03:28:07 --> Helper loaded: file_helper
INFO - 2021-06-26 03:28:07 --> Helper loaded: form_helper
INFO - 2021-06-26 03:28:07 --> Helper loaded: my_helper
INFO - 2021-06-26 03:28:07 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:28:07 --> Controller Class Initialized
DEBUG - 2021-06-26 03:28:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:28:07 --> Final output sent to browser
DEBUG - 2021-06-26 03:28:07 --> Total execution time: 0.0560
INFO - 2021-06-26 03:32:35 --> Config Class Initialized
INFO - 2021-06-26 03:32:35 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:32:35 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:32:35 --> Utf8 Class Initialized
INFO - 2021-06-26 03:32:35 --> URI Class Initialized
INFO - 2021-06-26 03:32:35 --> Router Class Initialized
INFO - 2021-06-26 03:32:35 --> Output Class Initialized
INFO - 2021-06-26 03:32:35 --> Security Class Initialized
DEBUG - 2021-06-26 03:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:32:35 --> Input Class Initialized
INFO - 2021-06-26 03:32:35 --> Language Class Initialized
INFO - 2021-06-26 03:32:35 --> Language Class Initialized
INFO - 2021-06-26 03:32:35 --> Config Class Initialized
INFO - 2021-06-26 03:32:35 --> Loader Class Initialized
INFO - 2021-06-26 03:32:35 --> Helper loaded: url_helper
INFO - 2021-06-26 03:32:35 --> Helper loaded: file_helper
INFO - 2021-06-26 03:32:35 --> Helper loaded: form_helper
INFO - 2021-06-26 03:32:35 --> Helper loaded: my_helper
INFO - 2021-06-26 03:32:35 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:32:35 --> Controller Class Initialized
DEBUG - 2021-06-26 03:32:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:32:35 --> Final output sent to browser
DEBUG - 2021-06-26 03:32:35 --> Total execution time: 0.0555
INFO - 2021-06-26 03:33:14 --> Config Class Initialized
INFO - 2021-06-26 03:33:14 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:33:14 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:33:14 --> Utf8 Class Initialized
INFO - 2021-06-26 03:33:14 --> URI Class Initialized
INFO - 2021-06-26 03:33:14 --> Router Class Initialized
INFO - 2021-06-26 03:33:14 --> Output Class Initialized
INFO - 2021-06-26 03:33:14 --> Security Class Initialized
DEBUG - 2021-06-26 03:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:33:14 --> Input Class Initialized
INFO - 2021-06-26 03:33:14 --> Language Class Initialized
INFO - 2021-06-26 03:33:14 --> Language Class Initialized
INFO - 2021-06-26 03:33:14 --> Config Class Initialized
INFO - 2021-06-26 03:33:14 --> Loader Class Initialized
INFO - 2021-06-26 03:33:14 --> Helper loaded: url_helper
INFO - 2021-06-26 03:33:14 --> Helper loaded: file_helper
INFO - 2021-06-26 03:33:14 --> Helper loaded: form_helper
INFO - 2021-06-26 03:33:14 --> Helper loaded: my_helper
INFO - 2021-06-26 03:33:14 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:33:14 --> Controller Class Initialized
DEBUG - 2021-06-26 03:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:33:14 --> Final output sent to browser
DEBUG - 2021-06-26 03:33:14 --> Total execution time: 0.0564
INFO - 2021-06-26 03:33:34 --> Config Class Initialized
INFO - 2021-06-26 03:33:34 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:33:34 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:33:34 --> Utf8 Class Initialized
INFO - 2021-06-26 03:33:34 --> URI Class Initialized
INFO - 2021-06-26 03:33:34 --> Router Class Initialized
INFO - 2021-06-26 03:33:34 --> Output Class Initialized
INFO - 2021-06-26 03:33:34 --> Security Class Initialized
DEBUG - 2021-06-26 03:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:33:34 --> Input Class Initialized
INFO - 2021-06-26 03:33:34 --> Language Class Initialized
INFO - 2021-06-26 03:33:34 --> Language Class Initialized
INFO - 2021-06-26 03:33:34 --> Config Class Initialized
INFO - 2021-06-26 03:33:34 --> Loader Class Initialized
INFO - 2021-06-26 03:33:34 --> Helper loaded: url_helper
INFO - 2021-06-26 03:33:34 --> Helper loaded: file_helper
INFO - 2021-06-26 03:33:34 --> Helper loaded: form_helper
INFO - 2021-06-26 03:33:34 --> Helper loaded: my_helper
INFO - 2021-06-26 03:33:34 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:33:34 --> Controller Class Initialized
DEBUG - 2021-06-26 03:33:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:33:34 --> Final output sent to browser
DEBUG - 2021-06-26 03:33:34 --> Total execution time: 0.0463
INFO - 2021-06-26 03:33:42 --> Config Class Initialized
INFO - 2021-06-26 03:33:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:33:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:33:42 --> Utf8 Class Initialized
INFO - 2021-06-26 03:33:42 --> URI Class Initialized
INFO - 2021-06-26 03:33:42 --> Router Class Initialized
INFO - 2021-06-26 03:33:42 --> Output Class Initialized
INFO - 2021-06-26 03:33:42 --> Security Class Initialized
DEBUG - 2021-06-26 03:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:33:42 --> Input Class Initialized
INFO - 2021-06-26 03:33:42 --> Language Class Initialized
INFO - 2021-06-26 03:33:42 --> Language Class Initialized
INFO - 2021-06-26 03:33:42 --> Config Class Initialized
INFO - 2021-06-26 03:33:42 --> Loader Class Initialized
INFO - 2021-06-26 03:33:42 --> Helper loaded: url_helper
INFO - 2021-06-26 03:33:42 --> Helper loaded: file_helper
INFO - 2021-06-26 03:33:42 --> Helper loaded: form_helper
INFO - 2021-06-26 03:33:42 --> Helper loaded: my_helper
INFO - 2021-06-26 03:33:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:33:42 --> Controller Class Initialized
DEBUG - 2021-06-26 03:33:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:33:42 --> Final output sent to browser
DEBUG - 2021-06-26 03:33:42 --> Total execution time: 0.0554
INFO - 2021-06-26 03:34:54 --> Config Class Initialized
INFO - 2021-06-26 03:34:54 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:34:54 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:34:54 --> Utf8 Class Initialized
INFO - 2021-06-26 03:34:54 --> URI Class Initialized
INFO - 2021-06-26 03:34:54 --> Router Class Initialized
INFO - 2021-06-26 03:34:54 --> Output Class Initialized
INFO - 2021-06-26 03:34:54 --> Security Class Initialized
DEBUG - 2021-06-26 03:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:34:54 --> Input Class Initialized
INFO - 2021-06-26 03:34:54 --> Language Class Initialized
INFO - 2021-06-26 03:34:54 --> Language Class Initialized
INFO - 2021-06-26 03:34:54 --> Config Class Initialized
INFO - 2021-06-26 03:34:54 --> Loader Class Initialized
INFO - 2021-06-26 03:34:55 --> Helper loaded: url_helper
INFO - 2021-06-26 03:34:55 --> Helper loaded: file_helper
INFO - 2021-06-26 03:34:55 --> Helper loaded: form_helper
INFO - 2021-06-26 03:34:55 --> Helper loaded: my_helper
INFO - 2021-06-26 03:34:55 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:34:55 --> Controller Class Initialized
DEBUG - 2021-06-26 03:34:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:34:55 --> Final output sent to browser
DEBUG - 2021-06-26 03:34:55 --> Total execution time: 0.0559
INFO - 2021-06-26 03:35:08 --> Config Class Initialized
INFO - 2021-06-26 03:35:08 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:35:08 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:35:08 --> Utf8 Class Initialized
INFO - 2021-06-26 03:35:08 --> URI Class Initialized
INFO - 2021-06-26 03:35:08 --> Router Class Initialized
INFO - 2021-06-26 03:35:08 --> Output Class Initialized
INFO - 2021-06-26 03:35:08 --> Security Class Initialized
DEBUG - 2021-06-26 03:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:35:08 --> Input Class Initialized
INFO - 2021-06-26 03:35:08 --> Language Class Initialized
INFO - 2021-06-26 03:35:08 --> Language Class Initialized
INFO - 2021-06-26 03:35:08 --> Config Class Initialized
INFO - 2021-06-26 03:35:08 --> Loader Class Initialized
INFO - 2021-06-26 03:35:08 --> Helper loaded: url_helper
INFO - 2021-06-26 03:35:08 --> Helper loaded: file_helper
INFO - 2021-06-26 03:35:08 --> Helper loaded: form_helper
INFO - 2021-06-26 03:35:08 --> Helper loaded: my_helper
INFO - 2021-06-26 03:35:08 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:35:08 --> Controller Class Initialized
DEBUG - 2021-06-26 03:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:35:08 --> Final output sent to browser
DEBUG - 2021-06-26 03:35:08 --> Total execution time: 0.0555
INFO - 2021-06-26 03:35:24 --> Config Class Initialized
INFO - 2021-06-26 03:35:24 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:35:24 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:35:24 --> Utf8 Class Initialized
INFO - 2021-06-26 03:35:24 --> URI Class Initialized
INFO - 2021-06-26 03:35:24 --> Router Class Initialized
INFO - 2021-06-26 03:35:24 --> Output Class Initialized
INFO - 2021-06-26 03:35:24 --> Security Class Initialized
DEBUG - 2021-06-26 03:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:35:24 --> Input Class Initialized
INFO - 2021-06-26 03:35:24 --> Language Class Initialized
INFO - 2021-06-26 03:35:24 --> Language Class Initialized
INFO - 2021-06-26 03:35:24 --> Config Class Initialized
INFO - 2021-06-26 03:35:24 --> Loader Class Initialized
INFO - 2021-06-26 03:35:24 --> Helper loaded: url_helper
INFO - 2021-06-26 03:35:24 --> Helper loaded: file_helper
INFO - 2021-06-26 03:35:24 --> Helper loaded: form_helper
INFO - 2021-06-26 03:35:24 --> Helper loaded: my_helper
INFO - 2021-06-26 03:35:24 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:35:24 --> Controller Class Initialized
DEBUG - 2021-06-26 03:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:35:24 --> Final output sent to browser
DEBUG - 2021-06-26 03:35:24 --> Total execution time: 0.0572
INFO - 2021-06-26 03:35:45 --> Config Class Initialized
INFO - 2021-06-26 03:35:45 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:35:45 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:35:45 --> Utf8 Class Initialized
INFO - 2021-06-26 03:35:45 --> URI Class Initialized
INFO - 2021-06-26 03:35:45 --> Router Class Initialized
INFO - 2021-06-26 03:35:45 --> Output Class Initialized
INFO - 2021-06-26 03:35:45 --> Security Class Initialized
DEBUG - 2021-06-26 03:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:35:45 --> Input Class Initialized
INFO - 2021-06-26 03:35:45 --> Language Class Initialized
INFO - 2021-06-26 03:35:45 --> Language Class Initialized
INFO - 2021-06-26 03:35:45 --> Config Class Initialized
INFO - 2021-06-26 03:35:45 --> Loader Class Initialized
INFO - 2021-06-26 03:35:45 --> Helper loaded: url_helper
INFO - 2021-06-26 03:35:45 --> Helper loaded: file_helper
INFO - 2021-06-26 03:35:45 --> Helper loaded: form_helper
INFO - 2021-06-26 03:35:45 --> Helper loaded: my_helper
INFO - 2021-06-26 03:35:45 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:35:45 --> Controller Class Initialized
DEBUG - 2021-06-26 03:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:35:45 --> Final output sent to browser
DEBUG - 2021-06-26 03:35:45 --> Total execution time: 0.0573
INFO - 2021-06-26 03:35:52 --> Config Class Initialized
INFO - 2021-06-26 03:35:52 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:35:52 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:35:52 --> Utf8 Class Initialized
INFO - 2021-06-26 03:35:52 --> URI Class Initialized
INFO - 2021-06-26 03:35:52 --> Router Class Initialized
INFO - 2021-06-26 03:35:52 --> Output Class Initialized
INFO - 2021-06-26 03:35:52 --> Security Class Initialized
DEBUG - 2021-06-26 03:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:35:52 --> Input Class Initialized
INFO - 2021-06-26 03:35:52 --> Language Class Initialized
INFO - 2021-06-26 03:35:52 --> Language Class Initialized
INFO - 2021-06-26 03:35:52 --> Config Class Initialized
INFO - 2021-06-26 03:35:52 --> Loader Class Initialized
INFO - 2021-06-26 03:35:52 --> Helper loaded: url_helper
INFO - 2021-06-26 03:35:52 --> Helper loaded: file_helper
INFO - 2021-06-26 03:35:52 --> Helper loaded: form_helper
INFO - 2021-06-26 03:35:52 --> Helper loaded: my_helper
INFO - 2021-06-26 03:35:52 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:35:52 --> Controller Class Initialized
DEBUG - 2021-06-26 03:35:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:35:52 --> Final output sent to browser
DEBUG - 2021-06-26 03:35:52 --> Total execution time: 0.0464
INFO - 2021-06-26 03:35:59 --> Config Class Initialized
INFO - 2021-06-26 03:35:59 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:35:59 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:35:59 --> Utf8 Class Initialized
INFO - 2021-06-26 03:35:59 --> URI Class Initialized
INFO - 2021-06-26 03:35:59 --> Router Class Initialized
INFO - 2021-06-26 03:35:59 --> Output Class Initialized
INFO - 2021-06-26 03:35:59 --> Security Class Initialized
DEBUG - 2021-06-26 03:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:35:59 --> Input Class Initialized
INFO - 2021-06-26 03:35:59 --> Language Class Initialized
INFO - 2021-06-26 03:35:59 --> Language Class Initialized
INFO - 2021-06-26 03:35:59 --> Config Class Initialized
INFO - 2021-06-26 03:35:59 --> Loader Class Initialized
INFO - 2021-06-26 03:35:59 --> Helper loaded: url_helper
INFO - 2021-06-26 03:35:59 --> Helper loaded: file_helper
INFO - 2021-06-26 03:35:59 --> Helper loaded: form_helper
INFO - 2021-06-26 03:35:59 --> Helper loaded: my_helper
INFO - 2021-06-26 03:35:59 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:35:59 --> Controller Class Initialized
DEBUG - 2021-06-26 03:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:35:59 --> Final output sent to browser
DEBUG - 2021-06-26 03:35:59 --> Total execution time: 0.0559
INFO - 2021-06-26 03:36:10 --> Config Class Initialized
INFO - 2021-06-26 03:36:10 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:36:10 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:36:10 --> Utf8 Class Initialized
INFO - 2021-06-26 03:36:10 --> URI Class Initialized
INFO - 2021-06-26 03:36:10 --> Router Class Initialized
INFO - 2021-06-26 03:36:10 --> Output Class Initialized
INFO - 2021-06-26 03:36:10 --> Security Class Initialized
DEBUG - 2021-06-26 03:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:36:10 --> Input Class Initialized
INFO - 2021-06-26 03:36:10 --> Language Class Initialized
INFO - 2021-06-26 03:36:10 --> Language Class Initialized
INFO - 2021-06-26 03:36:10 --> Config Class Initialized
INFO - 2021-06-26 03:36:10 --> Loader Class Initialized
INFO - 2021-06-26 03:36:10 --> Helper loaded: url_helper
INFO - 2021-06-26 03:36:10 --> Helper loaded: file_helper
INFO - 2021-06-26 03:36:10 --> Helper loaded: form_helper
INFO - 2021-06-26 03:36:10 --> Helper loaded: my_helper
INFO - 2021-06-26 03:36:10 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:36:10 --> Controller Class Initialized
DEBUG - 2021-06-26 03:36:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:36:10 --> Final output sent to browser
DEBUG - 2021-06-26 03:36:10 --> Total execution time: 0.0463
INFO - 2021-06-26 03:36:32 --> Config Class Initialized
INFO - 2021-06-26 03:36:32 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:36:32 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:36:32 --> Utf8 Class Initialized
INFO - 2021-06-26 03:36:32 --> URI Class Initialized
INFO - 2021-06-26 03:36:32 --> Router Class Initialized
INFO - 2021-06-26 03:36:32 --> Output Class Initialized
INFO - 2021-06-26 03:36:32 --> Security Class Initialized
DEBUG - 2021-06-26 03:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:36:32 --> Input Class Initialized
INFO - 2021-06-26 03:36:32 --> Language Class Initialized
INFO - 2021-06-26 03:36:32 --> Language Class Initialized
INFO - 2021-06-26 03:36:32 --> Config Class Initialized
INFO - 2021-06-26 03:36:32 --> Loader Class Initialized
INFO - 2021-06-26 03:36:32 --> Helper loaded: url_helper
INFO - 2021-06-26 03:36:32 --> Helper loaded: file_helper
INFO - 2021-06-26 03:36:32 --> Helper loaded: form_helper
INFO - 2021-06-26 03:36:32 --> Helper loaded: my_helper
INFO - 2021-06-26 03:36:32 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:36:32 --> Controller Class Initialized
DEBUG - 2021-06-26 03:36:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:36:32 --> Final output sent to browser
DEBUG - 2021-06-26 03:36:32 --> Total execution time: 0.0579
INFO - 2021-06-26 03:36:42 --> Config Class Initialized
INFO - 2021-06-26 03:36:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:36:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:36:42 --> Utf8 Class Initialized
INFO - 2021-06-26 03:36:42 --> URI Class Initialized
INFO - 2021-06-26 03:36:42 --> Router Class Initialized
INFO - 2021-06-26 03:36:42 --> Output Class Initialized
INFO - 2021-06-26 03:36:42 --> Security Class Initialized
DEBUG - 2021-06-26 03:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:36:42 --> Input Class Initialized
INFO - 2021-06-26 03:36:42 --> Language Class Initialized
INFO - 2021-06-26 03:36:42 --> Language Class Initialized
INFO - 2021-06-26 03:36:42 --> Config Class Initialized
INFO - 2021-06-26 03:36:42 --> Loader Class Initialized
INFO - 2021-06-26 03:36:42 --> Helper loaded: url_helper
INFO - 2021-06-26 03:36:42 --> Helper loaded: file_helper
INFO - 2021-06-26 03:36:42 --> Helper loaded: form_helper
INFO - 2021-06-26 03:36:42 --> Helper loaded: my_helper
INFO - 2021-06-26 03:36:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:36:42 --> Controller Class Initialized
DEBUG - 2021-06-26 03:36:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:36:42 --> Final output sent to browser
DEBUG - 2021-06-26 03:36:42 --> Total execution time: 0.0557
INFO - 2021-06-26 03:38:23 --> Config Class Initialized
INFO - 2021-06-26 03:38:23 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:38:23 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:38:23 --> Utf8 Class Initialized
INFO - 2021-06-26 03:38:23 --> URI Class Initialized
INFO - 2021-06-26 03:38:23 --> Router Class Initialized
INFO - 2021-06-26 03:38:23 --> Output Class Initialized
INFO - 2021-06-26 03:38:23 --> Security Class Initialized
DEBUG - 2021-06-26 03:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:38:23 --> Input Class Initialized
INFO - 2021-06-26 03:38:23 --> Language Class Initialized
INFO - 2021-06-26 03:38:23 --> Language Class Initialized
INFO - 2021-06-26 03:38:23 --> Config Class Initialized
INFO - 2021-06-26 03:38:23 --> Loader Class Initialized
INFO - 2021-06-26 03:38:23 --> Helper loaded: url_helper
INFO - 2021-06-26 03:38:23 --> Helper loaded: file_helper
INFO - 2021-06-26 03:38:23 --> Helper loaded: form_helper
INFO - 2021-06-26 03:38:23 --> Helper loaded: my_helper
INFO - 2021-06-26 03:38:23 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:38:23 --> Controller Class Initialized
DEBUG - 2021-06-26 03:38:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:38:23 --> Final output sent to browser
DEBUG - 2021-06-26 03:38:23 --> Total execution time: 0.0462
INFO - 2021-06-26 03:38:38 --> Config Class Initialized
INFO - 2021-06-26 03:38:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:38:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:38:38 --> Utf8 Class Initialized
INFO - 2021-06-26 03:38:38 --> URI Class Initialized
INFO - 2021-06-26 03:38:38 --> Router Class Initialized
INFO - 2021-06-26 03:38:38 --> Output Class Initialized
INFO - 2021-06-26 03:38:38 --> Security Class Initialized
DEBUG - 2021-06-26 03:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:38:38 --> Input Class Initialized
INFO - 2021-06-26 03:38:38 --> Language Class Initialized
INFO - 2021-06-26 03:38:38 --> Language Class Initialized
INFO - 2021-06-26 03:38:38 --> Config Class Initialized
INFO - 2021-06-26 03:38:38 --> Loader Class Initialized
INFO - 2021-06-26 03:38:38 --> Helper loaded: url_helper
INFO - 2021-06-26 03:38:38 --> Helper loaded: file_helper
INFO - 2021-06-26 03:38:38 --> Helper loaded: form_helper
INFO - 2021-06-26 03:38:38 --> Helper loaded: my_helper
INFO - 2021-06-26 03:38:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:38:38 --> Controller Class Initialized
DEBUG - 2021-06-26 03:38:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:38:38 --> Final output sent to browser
DEBUG - 2021-06-26 03:38:38 --> Total execution time: 0.0560
INFO - 2021-06-26 03:38:40 --> Config Class Initialized
INFO - 2021-06-26 03:38:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:38:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:38:40 --> Utf8 Class Initialized
INFO - 2021-06-26 03:38:40 --> URI Class Initialized
INFO - 2021-06-26 03:38:40 --> Router Class Initialized
INFO - 2021-06-26 03:38:40 --> Output Class Initialized
INFO - 2021-06-26 03:38:40 --> Security Class Initialized
DEBUG - 2021-06-26 03:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:38:40 --> Input Class Initialized
INFO - 2021-06-26 03:38:40 --> Language Class Initialized
INFO - 2021-06-26 03:38:40 --> Language Class Initialized
INFO - 2021-06-26 03:38:40 --> Config Class Initialized
INFO - 2021-06-26 03:38:40 --> Loader Class Initialized
INFO - 2021-06-26 03:38:40 --> Helper loaded: url_helper
INFO - 2021-06-26 03:38:40 --> Helper loaded: file_helper
INFO - 2021-06-26 03:38:40 --> Helper loaded: form_helper
INFO - 2021-06-26 03:38:40 --> Helper loaded: my_helper
INFO - 2021-06-26 03:38:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:38:40 --> Controller Class Initialized
DEBUG - 2021-06-26 03:38:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:38:40 --> Final output sent to browser
DEBUG - 2021-06-26 03:38:40 --> Total execution time: 0.0554
INFO - 2021-06-26 03:38:46 --> Config Class Initialized
INFO - 2021-06-26 03:38:46 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:38:46 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:38:46 --> Utf8 Class Initialized
INFO - 2021-06-26 03:38:46 --> URI Class Initialized
INFO - 2021-06-26 03:38:46 --> Router Class Initialized
INFO - 2021-06-26 03:38:46 --> Output Class Initialized
INFO - 2021-06-26 03:38:46 --> Security Class Initialized
DEBUG - 2021-06-26 03:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:38:46 --> Input Class Initialized
INFO - 2021-06-26 03:38:46 --> Language Class Initialized
INFO - 2021-06-26 03:38:46 --> Language Class Initialized
INFO - 2021-06-26 03:38:46 --> Config Class Initialized
INFO - 2021-06-26 03:38:46 --> Loader Class Initialized
INFO - 2021-06-26 03:38:46 --> Helper loaded: url_helper
INFO - 2021-06-26 03:38:46 --> Helper loaded: file_helper
INFO - 2021-06-26 03:38:46 --> Helper loaded: form_helper
INFO - 2021-06-26 03:38:46 --> Helper loaded: my_helper
INFO - 2021-06-26 03:38:46 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:38:46 --> Controller Class Initialized
DEBUG - 2021-06-26 03:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:38:46 --> Final output sent to browser
DEBUG - 2021-06-26 03:38:46 --> Total execution time: 0.0573
INFO - 2021-06-26 03:38:46 --> Config Class Initialized
INFO - 2021-06-26 03:38:46 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:38:46 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:38:46 --> Utf8 Class Initialized
INFO - 2021-06-26 03:38:46 --> URI Class Initialized
INFO - 2021-06-26 03:38:46 --> Router Class Initialized
INFO - 2021-06-26 03:38:46 --> Output Class Initialized
INFO - 2021-06-26 03:38:46 --> Security Class Initialized
DEBUG - 2021-06-26 03:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:38:46 --> Input Class Initialized
INFO - 2021-06-26 03:38:46 --> Language Class Initialized
INFO - 2021-06-26 03:38:46 --> Language Class Initialized
INFO - 2021-06-26 03:38:46 --> Config Class Initialized
INFO - 2021-06-26 03:38:46 --> Loader Class Initialized
INFO - 2021-06-26 03:38:46 --> Helper loaded: url_helper
INFO - 2021-06-26 03:38:46 --> Helper loaded: file_helper
INFO - 2021-06-26 03:38:46 --> Helper loaded: form_helper
INFO - 2021-06-26 03:38:46 --> Helper loaded: my_helper
INFO - 2021-06-26 03:38:46 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:38:46 --> Controller Class Initialized
DEBUG - 2021-06-26 03:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:38:46 --> Final output sent to browser
DEBUG - 2021-06-26 03:38:46 --> Total execution time: 0.0551
INFO - 2021-06-26 03:38:53 --> Config Class Initialized
INFO - 2021-06-26 03:38:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:38:53 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:38:53 --> Utf8 Class Initialized
INFO - 2021-06-26 03:38:53 --> URI Class Initialized
INFO - 2021-06-26 03:38:53 --> Router Class Initialized
INFO - 2021-06-26 03:38:53 --> Output Class Initialized
INFO - 2021-06-26 03:38:53 --> Security Class Initialized
DEBUG - 2021-06-26 03:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:38:53 --> Input Class Initialized
INFO - 2021-06-26 03:38:53 --> Language Class Initialized
INFO - 2021-06-26 03:38:53 --> Language Class Initialized
INFO - 2021-06-26 03:38:53 --> Config Class Initialized
INFO - 2021-06-26 03:38:53 --> Loader Class Initialized
INFO - 2021-06-26 03:38:53 --> Helper loaded: url_helper
INFO - 2021-06-26 03:38:53 --> Helper loaded: file_helper
INFO - 2021-06-26 03:38:53 --> Helper loaded: form_helper
INFO - 2021-06-26 03:38:53 --> Helper loaded: my_helper
INFO - 2021-06-26 03:38:53 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:38:53 --> Controller Class Initialized
DEBUG - 2021-06-26 03:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:38:53 --> Final output sent to browser
DEBUG - 2021-06-26 03:38:53 --> Total execution time: 0.0448
INFO - 2021-06-26 03:39:05 --> Config Class Initialized
INFO - 2021-06-26 03:39:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:39:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:39:05 --> Utf8 Class Initialized
INFO - 2021-06-26 03:39:05 --> URI Class Initialized
INFO - 2021-06-26 03:39:05 --> Router Class Initialized
INFO - 2021-06-26 03:39:05 --> Output Class Initialized
INFO - 2021-06-26 03:39:05 --> Security Class Initialized
DEBUG - 2021-06-26 03:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:39:05 --> Input Class Initialized
INFO - 2021-06-26 03:39:05 --> Language Class Initialized
INFO - 2021-06-26 03:39:05 --> Language Class Initialized
INFO - 2021-06-26 03:39:05 --> Config Class Initialized
INFO - 2021-06-26 03:39:05 --> Loader Class Initialized
INFO - 2021-06-26 03:39:05 --> Helper loaded: url_helper
INFO - 2021-06-26 03:39:05 --> Helper loaded: file_helper
INFO - 2021-06-26 03:39:05 --> Helper loaded: form_helper
INFO - 2021-06-26 03:39:05 --> Helper loaded: my_helper
INFO - 2021-06-26 03:39:05 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:39:05 --> Controller Class Initialized
DEBUG - 2021-06-26 03:39:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:39:05 --> Final output sent to browser
DEBUG - 2021-06-26 03:39:05 --> Total execution time: 0.0570
INFO - 2021-06-26 03:39:29 --> Config Class Initialized
INFO - 2021-06-26 03:39:29 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:39:29 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:39:29 --> Utf8 Class Initialized
INFO - 2021-06-26 03:39:29 --> URI Class Initialized
INFO - 2021-06-26 03:39:29 --> Router Class Initialized
INFO - 2021-06-26 03:39:29 --> Output Class Initialized
INFO - 2021-06-26 03:39:29 --> Security Class Initialized
DEBUG - 2021-06-26 03:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:39:29 --> Input Class Initialized
INFO - 2021-06-26 03:39:29 --> Language Class Initialized
INFO - 2021-06-26 03:39:29 --> Language Class Initialized
INFO - 2021-06-26 03:39:29 --> Config Class Initialized
INFO - 2021-06-26 03:39:29 --> Loader Class Initialized
INFO - 2021-06-26 03:39:29 --> Helper loaded: url_helper
INFO - 2021-06-26 03:39:29 --> Helper loaded: file_helper
INFO - 2021-06-26 03:39:29 --> Helper loaded: form_helper
INFO - 2021-06-26 03:39:29 --> Helper loaded: my_helper
INFO - 2021-06-26 03:39:29 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:39:29 --> Controller Class Initialized
DEBUG - 2021-06-26 03:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:39:29 --> Final output sent to browser
DEBUG - 2021-06-26 03:39:29 --> Total execution time: 0.0457
INFO - 2021-06-26 03:39:51 --> Config Class Initialized
INFO - 2021-06-26 03:39:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:39:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:39:51 --> Utf8 Class Initialized
INFO - 2021-06-26 03:39:51 --> URI Class Initialized
INFO - 2021-06-26 03:39:51 --> Router Class Initialized
INFO - 2021-06-26 03:39:51 --> Output Class Initialized
INFO - 2021-06-26 03:39:51 --> Security Class Initialized
DEBUG - 2021-06-26 03:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:39:51 --> Input Class Initialized
INFO - 2021-06-26 03:39:51 --> Language Class Initialized
INFO - 2021-06-26 03:39:51 --> Language Class Initialized
INFO - 2021-06-26 03:39:51 --> Config Class Initialized
INFO - 2021-06-26 03:39:51 --> Loader Class Initialized
INFO - 2021-06-26 03:39:51 --> Helper loaded: url_helper
INFO - 2021-06-26 03:39:51 --> Helper loaded: file_helper
INFO - 2021-06-26 03:39:51 --> Helper loaded: form_helper
INFO - 2021-06-26 03:39:51 --> Helper loaded: my_helper
INFO - 2021-06-26 03:39:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:39:51 --> Controller Class Initialized
DEBUG - 2021-06-26 03:39:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:39:51 --> Final output sent to browser
DEBUG - 2021-06-26 03:39:51 --> Total execution time: 0.0551
INFO - 2021-06-26 03:39:52 --> Config Class Initialized
INFO - 2021-06-26 03:39:52 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:39:52 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:39:52 --> Utf8 Class Initialized
INFO - 2021-06-26 03:39:52 --> URI Class Initialized
INFO - 2021-06-26 03:39:52 --> Router Class Initialized
INFO - 2021-06-26 03:39:52 --> Output Class Initialized
INFO - 2021-06-26 03:39:52 --> Security Class Initialized
DEBUG - 2021-06-26 03:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:39:52 --> Input Class Initialized
INFO - 2021-06-26 03:39:52 --> Language Class Initialized
INFO - 2021-06-26 03:39:52 --> Language Class Initialized
INFO - 2021-06-26 03:39:52 --> Config Class Initialized
INFO - 2021-06-26 03:39:52 --> Loader Class Initialized
INFO - 2021-06-26 03:39:52 --> Helper loaded: url_helper
INFO - 2021-06-26 03:39:52 --> Helper loaded: file_helper
INFO - 2021-06-26 03:39:52 --> Helper loaded: form_helper
INFO - 2021-06-26 03:39:52 --> Helper loaded: my_helper
INFO - 2021-06-26 03:39:52 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:39:52 --> Controller Class Initialized
DEBUG - 2021-06-26 03:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:39:52 --> Final output sent to browser
DEBUG - 2021-06-26 03:39:52 --> Total execution time: 0.0544
INFO - 2021-06-26 03:40:03 --> Config Class Initialized
INFO - 2021-06-26 03:40:03 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:40:03 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:40:03 --> Utf8 Class Initialized
INFO - 2021-06-26 03:40:03 --> URI Class Initialized
INFO - 2021-06-26 03:40:03 --> Router Class Initialized
INFO - 2021-06-26 03:40:03 --> Output Class Initialized
INFO - 2021-06-26 03:40:03 --> Security Class Initialized
DEBUG - 2021-06-26 03:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:40:03 --> Input Class Initialized
INFO - 2021-06-26 03:40:03 --> Language Class Initialized
INFO - 2021-06-26 03:40:03 --> Language Class Initialized
INFO - 2021-06-26 03:40:03 --> Config Class Initialized
INFO - 2021-06-26 03:40:03 --> Loader Class Initialized
INFO - 2021-06-26 03:40:03 --> Helper loaded: url_helper
INFO - 2021-06-26 03:40:03 --> Helper loaded: file_helper
INFO - 2021-06-26 03:40:03 --> Helper loaded: form_helper
INFO - 2021-06-26 03:40:03 --> Helper loaded: my_helper
INFO - 2021-06-26 03:40:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:40:03 --> Controller Class Initialized
DEBUG - 2021-06-26 03:40:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:40:03 --> Final output sent to browser
DEBUG - 2021-06-26 03:40:03 --> Total execution time: 0.0575
INFO - 2021-06-26 03:40:20 --> Config Class Initialized
INFO - 2021-06-26 03:40:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:40:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:40:20 --> Utf8 Class Initialized
INFO - 2021-06-26 03:40:20 --> URI Class Initialized
INFO - 2021-06-26 03:40:20 --> Router Class Initialized
INFO - 2021-06-26 03:40:20 --> Output Class Initialized
INFO - 2021-06-26 03:40:20 --> Security Class Initialized
DEBUG - 2021-06-26 03:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:40:20 --> Input Class Initialized
INFO - 2021-06-26 03:40:20 --> Language Class Initialized
INFO - 2021-06-26 03:40:20 --> Language Class Initialized
INFO - 2021-06-26 03:40:20 --> Config Class Initialized
INFO - 2021-06-26 03:40:20 --> Loader Class Initialized
INFO - 2021-06-26 03:40:20 --> Helper loaded: url_helper
INFO - 2021-06-26 03:40:20 --> Helper loaded: file_helper
INFO - 2021-06-26 03:40:20 --> Helper loaded: form_helper
INFO - 2021-06-26 03:40:20 --> Helper loaded: my_helper
INFO - 2021-06-26 03:40:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:40:20 --> Controller Class Initialized
DEBUG - 2021-06-26 03:40:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:40:20 --> Final output sent to browser
DEBUG - 2021-06-26 03:40:20 --> Total execution time: 0.0466
INFO - 2021-06-26 03:41:15 --> Config Class Initialized
INFO - 2021-06-26 03:41:15 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:41:15 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:41:15 --> Utf8 Class Initialized
INFO - 2021-06-26 03:41:15 --> URI Class Initialized
INFO - 2021-06-26 03:41:15 --> Router Class Initialized
INFO - 2021-06-26 03:41:15 --> Output Class Initialized
INFO - 2021-06-26 03:41:15 --> Security Class Initialized
DEBUG - 2021-06-26 03:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:41:15 --> Input Class Initialized
INFO - 2021-06-26 03:41:15 --> Language Class Initialized
INFO - 2021-06-26 03:41:15 --> Language Class Initialized
INFO - 2021-06-26 03:41:15 --> Config Class Initialized
INFO - 2021-06-26 03:41:15 --> Loader Class Initialized
INFO - 2021-06-26 03:41:15 --> Helper loaded: url_helper
INFO - 2021-06-26 03:41:15 --> Helper loaded: file_helper
INFO - 2021-06-26 03:41:15 --> Helper loaded: form_helper
INFO - 2021-06-26 03:41:15 --> Helper loaded: my_helper
INFO - 2021-06-26 03:41:15 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:41:15 --> Controller Class Initialized
DEBUG - 2021-06-26 03:41:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:41:15 --> Final output sent to browser
DEBUG - 2021-06-26 03:41:15 --> Total execution time: 0.0563
INFO - 2021-06-26 03:41:27 --> Config Class Initialized
INFO - 2021-06-26 03:41:27 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:41:27 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:41:27 --> Utf8 Class Initialized
INFO - 2021-06-26 03:41:27 --> URI Class Initialized
INFO - 2021-06-26 03:41:27 --> Router Class Initialized
INFO - 2021-06-26 03:41:27 --> Output Class Initialized
INFO - 2021-06-26 03:41:27 --> Security Class Initialized
DEBUG - 2021-06-26 03:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:41:27 --> Input Class Initialized
INFO - 2021-06-26 03:41:27 --> Language Class Initialized
INFO - 2021-06-26 03:41:27 --> Language Class Initialized
INFO - 2021-06-26 03:41:27 --> Config Class Initialized
INFO - 2021-06-26 03:41:27 --> Loader Class Initialized
INFO - 2021-06-26 03:41:27 --> Helper loaded: url_helper
INFO - 2021-06-26 03:41:27 --> Helper loaded: file_helper
INFO - 2021-06-26 03:41:27 --> Helper loaded: form_helper
INFO - 2021-06-26 03:41:27 --> Helper loaded: my_helper
INFO - 2021-06-26 03:41:27 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:41:27 --> Controller Class Initialized
DEBUG - 2021-06-26 03:41:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:41:27 --> Final output sent to browser
DEBUG - 2021-06-26 03:41:27 --> Total execution time: 0.0572
INFO - 2021-06-26 03:41:43 --> Config Class Initialized
INFO - 2021-06-26 03:41:43 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:41:43 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:41:43 --> Utf8 Class Initialized
INFO - 2021-06-26 03:41:43 --> URI Class Initialized
INFO - 2021-06-26 03:41:43 --> Router Class Initialized
INFO - 2021-06-26 03:41:43 --> Output Class Initialized
INFO - 2021-06-26 03:41:43 --> Security Class Initialized
DEBUG - 2021-06-26 03:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:41:43 --> Input Class Initialized
INFO - 2021-06-26 03:41:43 --> Language Class Initialized
INFO - 2021-06-26 03:41:43 --> Language Class Initialized
INFO - 2021-06-26 03:41:43 --> Config Class Initialized
INFO - 2021-06-26 03:41:43 --> Loader Class Initialized
INFO - 2021-06-26 03:41:43 --> Helper loaded: url_helper
INFO - 2021-06-26 03:41:43 --> Helper loaded: file_helper
INFO - 2021-06-26 03:41:43 --> Helper loaded: form_helper
INFO - 2021-06-26 03:41:43 --> Helper loaded: my_helper
INFO - 2021-06-26 03:41:43 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:41:43 --> Controller Class Initialized
DEBUG - 2021-06-26 03:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 03:41:43 --> Final output sent to browser
DEBUG - 2021-06-26 03:41:43 --> Total execution time: 0.0454
INFO - 2021-06-26 03:44:13 --> Config Class Initialized
INFO - 2021-06-26 03:44:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:44:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:44:13 --> Utf8 Class Initialized
INFO - 2021-06-26 03:44:13 --> URI Class Initialized
INFO - 2021-06-26 03:44:13 --> Router Class Initialized
INFO - 2021-06-26 03:44:13 --> Output Class Initialized
INFO - 2021-06-26 03:44:13 --> Security Class Initialized
DEBUG - 2021-06-26 03:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:44:13 --> Input Class Initialized
INFO - 2021-06-26 03:44:13 --> Language Class Initialized
INFO - 2021-06-26 03:44:13 --> Language Class Initialized
INFO - 2021-06-26 03:44:13 --> Config Class Initialized
INFO - 2021-06-26 03:44:13 --> Loader Class Initialized
INFO - 2021-06-26 03:44:13 --> Helper loaded: url_helper
INFO - 2021-06-26 03:44:13 --> Helper loaded: file_helper
INFO - 2021-06-26 03:44:13 --> Helper loaded: form_helper
INFO - 2021-06-26 03:44:13 --> Helper loaded: my_helper
INFO - 2021-06-26 03:44:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:44:13 --> Controller Class Initialized
INFO - 2021-06-26 03:44:13 --> Helper loaded: cookie_helper
INFO - 2021-06-26 03:44:13 --> Config Class Initialized
INFO - 2021-06-26 03:44:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:44:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:44:13 --> Utf8 Class Initialized
INFO - 2021-06-26 03:44:13 --> URI Class Initialized
INFO - 2021-06-26 03:44:13 --> Router Class Initialized
INFO - 2021-06-26 03:44:13 --> Output Class Initialized
INFO - 2021-06-26 03:44:13 --> Security Class Initialized
DEBUG - 2021-06-26 03:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:44:13 --> Input Class Initialized
INFO - 2021-06-26 03:44:13 --> Language Class Initialized
INFO - 2021-06-26 03:44:13 --> Language Class Initialized
INFO - 2021-06-26 03:44:13 --> Config Class Initialized
INFO - 2021-06-26 03:44:13 --> Loader Class Initialized
INFO - 2021-06-26 03:44:13 --> Helper loaded: url_helper
INFO - 2021-06-26 03:44:13 --> Helper loaded: file_helper
INFO - 2021-06-26 03:44:13 --> Helper loaded: form_helper
INFO - 2021-06-26 03:44:13 --> Helper loaded: my_helper
INFO - 2021-06-26 03:44:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:44:14 --> Controller Class Initialized
DEBUG - 2021-06-26 03:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 03:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:44:14 --> Final output sent to browser
DEBUG - 2021-06-26 03:44:14 --> Total execution time: 0.0500
INFO - 2021-06-26 03:44:22 --> Config Class Initialized
INFO - 2021-06-26 03:44:22 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:44:22 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:44:22 --> Utf8 Class Initialized
INFO - 2021-06-26 03:44:22 --> URI Class Initialized
INFO - 2021-06-26 03:44:22 --> Router Class Initialized
INFO - 2021-06-26 03:44:22 --> Output Class Initialized
INFO - 2021-06-26 03:44:22 --> Security Class Initialized
DEBUG - 2021-06-26 03:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:44:22 --> Input Class Initialized
INFO - 2021-06-26 03:44:22 --> Language Class Initialized
INFO - 2021-06-26 03:44:22 --> Language Class Initialized
INFO - 2021-06-26 03:44:22 --> Config Class Initialized
INFO - 2021-06-26 03:44:22 --> Loader Class Initialized
INFO - 2021-06-26 03:44:22 --> Helper loaded: url_helper
INFO - 2021-06-26 03:44:22 --> Helper loaded: file_helper
INFO - 2021-06-26 03:44:22 --> Helper loaded: form_helper
INFO - 2021-06-26 03:44:22 --> Helper loaded: my_helper
INFO - 2021-06-26 03:44:22 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:44:23 --> Controller Class Initialized
INFO - 2021-06-26 03:44:23 --> Helper loaded: cookie_helper
INFO - 2021-06-26 03:44:23 --> Final output sent to browser
DEBUG - 2021-06-26 03:44:23 --> Total execution time: 0.0448
INFO - 2021-06-26 03:44:23 --> Config Class Initialized
INFO - 2021-06-26 03:44:23 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:44:23 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:44:23 --> Utf8 Class Initialized
INFO - 2021-06-26 03:44:23 --> URI Class Initialized
INFO - 2021-06-26 03:44:23 --> Router Class Initialized
INFO - 2021-06-26 03:44:23 --> Output Class Initialized
INFO - 2021-06-26 03:44:23 --> Security Class Initialized
DEBUG - 2021-06-26 03:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:44:23 --> Input Class Initialized
INFO - 2021-06-26 03:44:23 --> Language Class Initialized
INFO - 2021-06-26 03:44:23 --> Language Class Initialized
INFO - 2021-06-26 03:44:23 --> Config Class Initialized
INFO - 2021-06-26 03:44:23 --> Loader Class Initialized
INFO - 2021-06-26 03:44:23 --> Helper loaded: url_helper
INFO - 2021-06-26 03:44:23 --> Helper loaded: file_helper
INFO - 2021-06-26 03:44:23 --> Helper loaded: form_helper
INFO - 2021-06-26 03:44:23 --> Helper loaded: my_helper
INFO - 2021-06-26 03:44:23 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:44:23 --> Controller Class Initialized
DEBUG - 2021-06-26 03:44:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 03:44:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:44:24 --> Final output sent to browser
DEBUG - 2021-06-26 03:44:24 --> Total execution time: 0.6482
INFO - 2021-06-26 03:44:26 --> Config Class Initialized
INFO - 2021-06-26 03:44:26 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:44:26 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:44:26 --> Utf8 Class Initialized
INFO - 2021-06-26 03:44:26 --> URI Class Initialized
INFO - 2021-06-26 03:44:26 --> Router Class Initialized
INFO - 2021-06-26 03:44:26 --> Output Class Initialized
INFO - 2021-06-26 03:44:26 --> Security Class Initialized
DEBUG - 2021-06-26 03:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:44:26 --> Input Class Initialized
INFO - 2021-06-26 03:44:26 --> Language Class Initialized
INFO - 2021-06-26 03:44:26 --> Language Class Initialized
INFO - 2021-06-26 03:44:26 --> Config Class Initialized
INFO - 2021-06-26 03:44:26 --> Loader Class Initialized
INFO - 2021-06-26 03:44:26 --> Helper loaded: url_helper
INFO - 2021-06-26 03:44:26 --> Helper loaded: file_helper
INFO - 2021-06-26 03:44:26 --> Helper loaded: form_helper
INFO - 2021-06-26 03:44:26 --> Helper loaded: my_helper
INFO - 2021-06-26 03:44:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:44:26 --> Controller Class Initialized
DEBUG - 2021-06-26 03:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-26 03:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:44:26 --> Final output sent to browser
DEBUG - 2021-06-26 03:44:26 --> Total execution time: 0.1734
INFO - 2021-06-26 03:49:31 --> Config Class Initialized
INFO - 2021-06-26 03:49:31 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:49:31 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:49:31 --> Utf8 Class Initialized
INFO - 2021-06-26 03:49:31 --> URI Class Initialized
INFO - 2021-06-26 03:49:31 --> Router Class Initialized
INFO - 2021-06-26 03:49:31 --> Output Class Initialized
INFO - 2021-06-26 03:49:31 --> Security Class Initialized
DEBUG - 2021-06-26 03:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:49:31 --> Input Class Initialized
INFO - 2021-06-26 03:49:31 --> Language Class Initialized
INFO - 2021-06-26 03:49:31 --> Language Class Initialized
INFO - 2021-06-26 03:49:31 --> Config Class Initialized
INFO - 2021-06-26 03:49:31 --> Loader Class Initialized
INFO - 2021-06-26 03:49:31 --> Helper loaded: url_helper
INFO - 2021-06-26 03:49:31 --> Helper loaded: file_helper
INFO - 2021-06-26 03:49:31 --> Helper loaded: form_helper
INFO - 2021-06-26 03:49:31 --> Helper loaded: my_helper
INFO - 2021-06-26 03:49:31 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:49:31 --> Controller Class Initialized
INFO - 2021-06-26 03:49:31 --> Final output sent to browser
DEBUG - 2021-06-26 03:49:31 --> Total execution time: 0.2396
INFO - 2021-06-26 03:50:22 --> Config Class Initialized
INFO - 2021-06-26 03:50:22 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:50:22 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:50:22 --> Utf8 Class Initialized
INFO - 2021-06-26 03:50:22 --> URI Class Initialized
INFO - 2021-06-26 03:50:22 --> Router Class Initialized
INFO - 2021-06-26 03:50:22 --> Output Class Initialized
INFO - 2021-06-26 03:50:22 --> Security Class Initialized
DEBUG - 2021-06-26 03:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:50:22 --> Input Class Initialized
INFO - 2021-06-26 03:50:22 --> Language Class Initialized
INFO - 2021-06-26 03:50:22 --> Language Class Initialized
INFO - 2021-06-26 03:50:22 --> Config Class Initialized
INFO - 2021-06-26 03:50:22 --> Loader Class Initialized
INFO - 2021-06-26 03:50:22 --> Helper loaded: url_helper
INFO - 2021-06-26 03:50:22 --> Helper loaded: file_helper
INFO - 2021-06-26 03:50:22 --> Helper loaded: form_helper
INFO - 2021-06-26 03:50:22 --> Helper loaded: my_helper
INFO - 2021-06-26 03:50:22 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:50:22 --> Controller Class Initialized
INFO - 2021-06-26 03:50:22 --> Final output sent to browser
DEBUG - 2021-06-26 03:50:22 --> Total execution time: 0.1333
INFO - 2021-06-26 03:50:36 --> Config Class Initialized
INFO - 2021-06-26 03:50:36 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:50:36 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:50:36 --> Utf8 Class Initialized
INFO - 2021-06-26 03:50:36 --> URI Class Initialized
INFO - 2021-06-26 03:50:36 --> Router Class Initialized
INFO - 2021-06-26 03:50:36 --> Output Class Initialized
INFO - 2021-06-26 03:50:36 --> Security Class Initialized
DEBUG - 2021-06-26 03:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:50:36 --> Input Class Initialized
INFO - 2021-06-26 03:50:36 --> Language Class Initialized
INFO - 2021-06-26 03:50:36 --> Language Class Initialized
INFO - 2021-06-26 03:50:36 --> Config Class Initialized
INFO - 2021-06-26 03:50:36 --> Loader Class Initialized
INFO - 2021-06-26 03:50:36 --> Helper loaded: url_helper
INFO - 2021-06-26 03:50:36 --> Helper loaded: file_helper
INFO - 2021-06-26 03:50:36 --> Helper loaded: form_helper
INFO - 2021-06-26 03:50:36 --> Helper loaded: my_helper
INFO - 2021-06-26 03:50:36 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:50:36 --> Controller Class Initialized
DEBUG - 2021-06-26 03:50:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-26 03:50:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:50:36 --> Final output sent to browser
DEBUG - 2021-06-26 03:50:36 --> Total execution time: 0.0888
INFO - 2021-06-26 03:50:38 --> Config Class Initialized
INFO - 2021-06-26 03:50:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:50:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:50:38 --> Utf8 Class Initialized
INFO - 2021-06-26 03:50:38 --> URI Class Initialized
INFO - 2021-06-26 03:50:38 --> Router Class Initialized
INFO - 2021-06-26 03:50:38 --> Output Class Initialized
INFO - 2021-06-26 03:50:38 --> Security Class Initialized
DEBUG - 2021-06-26 03:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:50:38 --> Input Class Initialized
INFO - 2021-06-26 03:50:38 --> Language Class Initialized
INFO - 2021-06-26 03:50:38 --> Language Class Initialized
INFO - 2021-06-26 03:50:38 --> Config Class Initialized
INFO - 2021-06-26 03:50:38 --> Loader Class Initialized
INFO - 2021-06-26 03:50:38 --> Helper loaded: url_helper
INFO - 2021-06-26 03:50:38 --> Helper loaded: file_helper
INFO - 2021-06-26 03:50:38 --> Helper loaded: form_helper
INFO - 2021-06-26 03:50:38 --> Helper loaded: my_helper
INFO - 2021-06-26 03:50:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:50:38 --> Controller Class Initialized
DEBUG - 2021-06-26 03:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-06-26 03:50:38 --> Final output sent to browser
DEBUG - 2021-06-26 03:50:38 --> Total execution time: 0.3567
INFO - 2021-06-26 03:51:07 --> Config Class Initialized
INFO - 2021-06-26 03:51:07 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:51:07 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:51:07 --> Utf8 Class Initialized
INFO - 2021-06-26 03:51:07 --> URI Class Initialized
DEBUG - 2021-06-26 03:51:07 --> No URI present. Default controller set.
INFO - 2021-06-26 03:51:07 --> Router Class Initialized
INFO - 2021-06-26 03:51:07 --> Output Class Initialized
INFO - 2021-06-26 03:51:07 --> Security Class Initialized
DEBUG - 2021-06-26 03:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:51:07 --> Input Class Initialized
INFO - 2021-06-26 03:51:07 --> Language Class Initialized
INFO - 2021-06-26 03:51:07 --> Language Class Initialized
INFO - 2021-06-26 03:51:07 --> Config Class Initialized
INFO - 2021-06-26 03:51:07 --> Loader Class Initialized
INFO - 2021-06-26 03:51:07 --> Helper loaded: url_helper
INFO - 2021-06-26 03:51:07 --> Helper loaded: file_helper
INFO - 2021-06-26 03:51:07 --> Helper loaded: form_helper
INFO - 2021-06-26 03:51:07 --> Helper loaded: my_helper
INFO - 2021-06-26 03:51:07 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:51:07 --> Controller Class Initialized
DEBUG - 2021-06-26 03:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 03:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:51:08 --> Final output sent to browser
DEBUG - 2021-06-26 03:51:08 --> Total execution time: 0.6557
INFO - 2021-06-26 03:51:14 --> Config Class Initialized
INFO - 2021-06-26 03:51:14 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:51:14 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:51:14 --> Utf8 Class Initialized
INFO - 2021-06-26 03:51:14 --> URI Class Initialized
INFO - 2021-06-26 03:51:14 --> Router Class Initialized
INFO - 2021-06-26 03:51:14 --> Output Class Initialized
INFO - 2021-06-26 03:51:14 --> Security Class Initialized
DEBUG - 2021-06-26 03:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:51:14 --> Input Class Initialized
INFO - 2021-06-26 03:51:14 --> Language Class Initialized
INFO - 2021-06-26 03:51:14 --> Language Class Initialized
INFO - 2021-06-26 03:51:14 --> Config Class Initialized
INFO - 2021-06-26 03:51:14 --> Loader Class Initialized
INFO - 2021-06-26 03:51:14 --> Helper loaded: url_helper
INFO - 2021-06-26 03:51:14 --> Helper loaded: file_helper
INFO - 2021-06-26 03:51:14 --> Helper loaded: form_helper
INFO - 2021-06-26 03:51:14 --> Helper loaded: my_helper
INFO - 2021-06-26 03:51:14 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:51:14 --> Controller Class Initialized
DEBUG - 2021-06-26 03:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 03:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:51:14 --> Final output sent to browser
DEBUG - 2021-06-26 03:51:14 --> Total execution time: 0.0591
INFO - 2021-06-26 03:51:45 --> Config Class Initialized
INFO - 2021-06-26 03:51:45 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:51:45 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:51:45 --> Utf8 Class Initialized
INFO - 2021-06-26 03:51:45 --> URI Class Initialized
INFO - 2021-06-26 03:51:45 --> Router Class Initialized
INFO - 2021-06-26 03:51:45 --> Output Class Initialized
INFO - 2021-06-26 03:51:45 --> Security Class Initialized
DEBUG - 2021-06-26 03:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:51:45 --> Input Class Initialized
INFO - 2021-06-26 03:51:45 --> Language Class Initialized
INFO - 2021-06-26 03:51:45 --> Language Class Initialized
INFO - 2021-06-26 03:51:45 --> Config Class Initialized
INFO - 2021-06-26 03:51:45 --> Loader Class Initialized
INFO - 2021-06-26 03:51:45 --> Helper loaded: url_helper
INFO - 2021-06-26 03:51:45 --> Helper loaded: file_helper
INFO - 2021-06-26 03:51:45 --> Helper loaded: form_helper
INFO - 2021-06-26 03:51:45 --> Helper loaded: my_helper
INFO - 2021-06-26 03:51:45 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:51:45 --> Controller Class Initialized
DEBUG - 2021-06-26 03:51:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 03:51:45 --> Final output sent to browser
DEBUG - 2021-06-26 03:51:45 --> Total execution time: 0.3142
INFO - 2021-06-26 03:53:18 --> Config Class Initialized
INFO - 2021-06-26 03:53:18 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:53:18 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:53:18 --> Utf8 Class Initialized
INFO - 2021-06-26 03:53:18 --> URI Class Initialized
INFO - 2021-06-26 03:53:18 --> Router Class Initialized
INFO - 2021-06-26 03:53:18 --> Output Class Initialized
INFO - 2021-06-26 03:53:18 --> Security Class Initialized
DEBUG - 2021-06-26 03:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:53:18 --> Input Class Initialized
INFO - 2021-06-26 03:53:18 --> Language Class Initialized
INFO - 2021-06-26 03:53:18 --> Language Class Initialized
INFO - 2021-06-26 03:53:18 --> Config Class Initialized
INFO - 2021-06-26 03:53:18 --> Loader Class Initialized
INFO - 2021-06-26 03:53:18 --> Helper loaded: url_helper
INFO - 2021-06-26 03:53:18 --> Helper loaded: file_helper
INFO - 2021-06-26 03:53:18 --> Helper loaded: form_helper
INFO - 2021-06-26 03:53:18 --> Helper loaded: my_helper
INFO - 2021-06-26 03:53:18 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:53:18 --> Controller Class Initialized
DEBUG - 2021-06-26 03:53:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 03:53:18 --> Final output sent to browser
DEBUG - 2021-06-26 03:53:18 --> Total execution time: 0.1885
INFO - 2021-06-26 03:53:27 --> Config Class Initialized
INFO - 2021-06-26 03:53:27 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:53:27 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:53:27 --> Utf8 Class Initialized
INFO - 2021-06-26 03:53:27 --> URI Class Initialized
INFO - 2021-06-26 03:53:27 --> Router Class Initialized
INFO - 2021-06-26 03:53:27 --> Output Class Initialized
INFO - 2021-06-26 03:53:27 --> Security Class Initialized
DEBUG - 2021-06-26 03:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:53:27 --> Input Class Initialized
INFO - 2021-06-26 03:53:27 --> Language Class Initialized
INFO - 2021-06-26 03:53:27 --> Language Class Initialized
INFO - 2021-06-26 03:53:27 --> Config Class Initialized
INFO - 2021-06-26 03:53:27 --> Loader Class Initialized
INFO - 2021-06-26 03:53:27 --> Helper loaded: url_helper
INFO - 2021-06-26 03:53:27 --> Helper loaded: file_helper
INFO - 2021-06-26 03:53:27 --> Helper loaded: form_helper
INFO - 2021-06-26 03:53:27 --> Helper loaded: my_helper
INFO - 2021-06-26 03:53:27 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:53:27 --> Controller Class Initialized
DEBUG - 2021-06-26 03:53:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 03:53:27 --> Final output sent to browser
DEBUG - 2021-06-26 03:53:27 --> Total execution time: 0.2058
INFO - 2021-06-26 03:54:20 --> Config Class Initialized
INFO - 2021-06-26 03:54:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:54:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:54:20 --> Utf8 Class Initialized
INFO - 2021-06-26 03:54:20 --> URI Class Initialized
INFO - 2021-06-26 03:54:20 --> Router Class Initialized
INFO - 2021-06-26 03:54:20 --> Output Class Initialized
INFO - 2021-06-26 03:54:20 --> Security Class Initialized
DEBUG - 2021-06-26 03:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:54:20 --> Input Class Initialized
INFO - 2021-06-26 03:54:20 --> Language Class Initialized
INFO - 2021-06-26 03:54:20 --> Language Class Initialized
INFO - 2021-06-26 03:54:20 --> Config Class Initialized
INFO - 2021-06-26 03:54:20 --> Loader Class Initialized
INFO - 2021-06-26 03:54:20 --> Helper loaded: url_helper
INFO - 2021-06-26 03:54:20 --> Helper loaded: file_helper
INFO - 2021-06-26 03:54:20 --> Helper loaded: form_helper
INFO - 2021-06-26 03:54:20 --> Helper loaded: my_helper
INFO - 2021-06-26 03:54:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:54:20 --> Controller Class Initialized
DEBUG - 2021-06-26 03:54:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 03:54:20 --> Final output sent to browser
DEBUG - 2021-06-26 03:54:20 --> Total execution time: 0.1806
INFO - 2021-06-26 03:54:31 --> Config Class Initialized
INFO - 2021-06-26 03:54:31 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:54:31 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:54:31 --> Utf8 Class Initialized
INFO - 2021-06-26 03:54:31 --> URI Class Initialized
INFO - 2021-06-26 03:54:31 --> Router Class Initialized
INFO - 2021-06-26 03:54:31 --> Output Class Initialized
INFO - 2021-06-26 03:54:31 --> Security Class Initialized
DEBUG - 2021-06-26 03:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:54:31 --> Input Class Initialized
INFO - 2021-06-26 03:54:31 --> Language Class Initialized
INFO - 2021-06-26 03:54:31 --> Language Class Initialized
INFO - 2021-06-26 03:54:31 --> Config Class Initialized
INFO - 2021-06-26 03:54:31 --> Loader Class Initialized
INFO - 2021-06-26 03:54:31 --> Helper loaded: url_helper
INFO - 2021-06-26 03:54:31 --> Helper loaded: file_helper
INFO - 2021-06-26 03:54:31 --> Helper loaded: form_helper
INFO - 2021-06-26 03:54:31 --> Helper loaded: my_helper
INFO - 2021-06-26 03:54:31 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:54:31 --> Controller Class Initialized
DEBUG - 2021-06-26 03:54:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 03:54:31 --> Final output sent to browser
DEBUG - 2021-06-26 03:54:31 --> Total execution time: 0.1856
INFO - 2021-06-26 03:54:52 --> Config Class Initialized
INFO - 2021-06-26 03:54:52 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:54:52 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:54:52 --> Utf8 Class Initialized
INFO - 2021-06-26 03:54:52 --> URI Class Initialized
INFO - 2021-06-26 03:54:52 --> Router Class Initialized
INFO - 2021-06-26 03:54:52 --> Output Class Initialized
INFO - 2021-06-26 03:54:52 --> Security Class Initialized
DEBUG - 2021-06-26 03:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:54:52 --> Input Class Initialized
INFO - 2021-06-26 03:54:52 --> Language Class Initialized
INFO - 2021-06-26 03:54:52 --> Language Class Initialized
INFO - 2021-06-26 03:54:52 --> Config Class Initialized
INFO - 2021-06-26 03:54:52 --> Loader Class Initialized
INFO - 2021-06-26 03:54:52 --> Helper loaded: url_helper
INFO - 2021-06-26 03:54:52 --> Helper loaded: file_helper
INFO - 2021-06-26 03:54:52 --> Helper loaded: form_helper
INFO - 2021-06-26 03:54:52 --> Helper loaded: my_helper
INFO - 2021-06-26 03:54:52 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:54:52 --> Controller Class Initialized
DEBUG - 2021-06-26 03:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-26 03:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:54:52 --> Final output sent to browser
DEBUG - 2021-06-26 03:54:52 --> Total execution time: 0.1009
INFO - 2021-06-26 03:57:12 --> Config Class Initialized
INFO - 2021-06-26 03:57:12 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:57:12 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:57:12 --> Utf8 Class Initialized
INFO - 2021-06-26 03:57:12 --> URI Class Initialized
INFO - 2021-06-26 03:57:12 --> Router Class Initialized
INFO - 2021-06-26 03:57:12 --> Output Class Initialized
INFO - 2021-06-26 03:57:12 --> Security Class Initialized
DEBUG - 2021-06-26 03:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:57:12 --> Input Class Initialized
INFO - 2021-06-26 03:57:12 --> Language Class Initialized
INFO - 2021-06-26 03:57:12 --> Language Class Initialized
INFO - 2021-06-26 03:57:12 --> Config Class Initialized
INFO - 2021-06-26 03:57:12 --> Loader Class Initialized
INFO - 2021-06-26 03:57:12 --> Helper loaded: url_helper
INFO - 2021-06-26 03:57:12 --> Helper loaded: file_helper
INFO - 2021-06-26 03:57:12 --> Helper loaded: form_helper
INFO - 2021-06-26 03:57:12 --> Helper loaded: my_helper
INFO - 2021-06-26 03:57:12 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:57:12 --> Controller Class Initialized
INFO - 2021-06-26 03:57:12 --> Final output sent to browser
DEBUG - 2021-06-26 03:57:12 --> Total execution time: 0.0986
INFO - 2021-06-26 03:57:19 --> Config Class Initialized
INFO - 2021-06-26 03:57:19 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:57:19 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:57:19 --> Utf8 Class Initialized
INFO - 2021-06-26 03:57:19 --> URI Class Initialized
INFO - 2021-06-26 03:57:19 --> Router Class Initialized
INFO - 2021-06-26 03:57:19 --> Output Class Initialized
INFO - 2021-06-26 03:57:19 --> Security Class Initialized
DEBUG - 2021-06-26 03:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:57:19 --> Input Class Initialized
INFO - 2021-06-26 03:57:19 --> Language Class Initialized
INFO - 2021-06-26 03:57:19 --> Language Class Initialized
INFO - 2021-06-26 03:57:19 --> Config Class Initialized
INFO - 2021-06-26 03:57:19 --> Loader Class Initialized
INFO - 2021-06-26 03:57:19 --> Helper loaded: url_helper
INFO - 2021-06-26 03:57:19 --> Helper loaded: file_helper
INFO - 2021-06-26 03:57:19 --> Helper loaded: form_helper
INFO - 2021-06-26 03:57:19 --> Helper loaded: my_helper
INFO - 2021-06-26 03:57:19 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:57:19 --> Controller Class Initialized
DEBUG - 2021-06-26 03:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 03:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:57:19 --> Final output sent to browser
DEBUG - 2021-06-26 03:57:19 --> Total execution time: 0.0583
INFO - 2021-06-26 03:57:26 --> Config Class Initialized
INFO - 2021-06-26 03:57:26 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:57:26 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:57:26 --> Utf8 Class Initialized
INFO - 2021-06-26 03:57:26 --> URI Class Initialized
INFO - 2021-06-26 03:57:26 --> Router Class Initialized
INFO - 2021-06-26 03:57:26 --> Output Class Initialized
INFO - 2021-06-26 03:57:26 --> Security Class Initialized
DEBUG - 2021-06-26 03:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:57:26 --> Input Class Initialized
INFO - 2021-06-26 03:57:26 --> Language Class Initialized
INFO - 2021-06-26 03:57:26 --> Language Class Initialized
INFO - 2021-06-26 03:57:26 --> Config Class Initialized
INFO - 2021-06-26 03:57:26 --> Loader Class Initialized
INFO - 2021-06-26 03:57:26 --> Helper loaded: url_helper
INFO - 2021-06-26 03:57:26 --> Helper loaded: file_helper
INFO - 2021-06-26 03:57:26 --> Helper loaded: form_helper
INFO - 2021-06-26 03:57:26 --> Helper loaded: my_helper
INFO - 2021-06-26 03:57:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:57:26 --> Controller Class Initialized
DEBUG - 2021-06-26 03:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-26 03:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:57:26 --> Final output sent to browser
DEBUG - 2021-06-26 03:57:26 --> Total execution time: 0.1109
INFO - 2021-06-26 03:58:53 --> Config Class Initialized
INFO - 2021-06-26 03:58:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:58:53 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:58:53 --> Utf8 Class Initialized
INFO - 2021-06-26 03:58:53 --> URI Class Initialized
INFO - 2021-06-26 03:58:53 --> Router Class Initialized
INFO - 2021-06-26 03:58:53 --> Output Class Initialized
INFO - 2021-06-26 03:58:53 --> Security Class Initialized
DEBUG - 2021-06-26 03:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:58:53 --> Input Class Initialized
INFO - 2021-06-26 03:58:53 --> Language Class Initialized
INFO - 2021-06-26 03:58:53 --> Language Class Initialized
INFO - 2021-06-26 03:58:53 --> Config Class Initialized
INFO - 2021-06-26 03:58:53 --> Loader Class Initialized
INFO - 2021-06-26 03:58:53 --> Helper loaded: url_helper
INFO - 2021-06-26 03:58:53 --> Helper loaded: file_helper
INFO - 2021-06-26 03:58:53 --> Helper loaded: form_helper
INFO - 2021-06-26 03:58:53 --> Helper loaded: my_helper
INFO - 2021-06-26 03:58:53 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:58:53 --> Controller Class Initialized
INFO - 2021-06-26 03:58:53 --> Final output sent to browser
DEBUG - 2021-06-26 03:58:53 --> Total execution time: 0.1138
INFO - 2021-06-26 03:59:00 --> Config Class Initialized
INFO - 2021-06-26 03:59:00 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:59:00 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:59:00 --> Utf8 Class Initialized
INFO - 2021-06-26 03:59:00 --> URI Class Initialized
INFO - 2021-06-26 03:59:00 --> Router Class Initialized
INFO - 2021-06-26 03:59:00 --> Output Class Initialized
INFO - 2021-06-26 03:59:00 --> Security Class Initialized
DEBUG - 2021-06-26 03:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:59:00 --> Input Class Initialized
INFO - 2021-06-26 03:59:00 --> Language Class Initialized
INFO - 2021-06-26 03:59:00 --> Language Class Initialized
INFO - 2021-06-26 03:59:00 --> Config Class Initialized
INFO - 2021-06-26 03:59:00 --> Loader Class Initialized
INFO - 2021-06-26 03:59:00 --> Helper loaded: url_helper
INFO - 2021-06-26 03:59:00 --> Helper loaded: file_helper
INFO - 2021-06-26 03:59:00 --> Helper loaded: form_helper
INFO - 2021-06-26 03:59:00 --> Helper loaded: my_helper
INFO - 2021-06-26 03:59:00 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:59:00 --> Controller Class Initialized
DEBUG - 2021-06-26 03:59:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-26 03:59:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:59:00 --> Final output sent to browser
DEBUG - 2021-06-26 03:59:00 --> Total execution time: 0.1057
INFO - 2021-06-26 03:59:02 --> Config Class Initialized
INFO - 2021-06-26 03:59:02 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:59:02 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:59:02 --> Utf8 Class Initialized
INFO - 2021-06-26 03:59:02 --> URI Class Initialized
INFO - 2021-06-26 03:59:02 --> Router Class Initialized
INFO - 2021-06-26 03:59:02 --> Output Class Initialized
INFO - 2021-06-26 03:59:02 --> Security Class Initialized
DEBUG - 2021-06-26 03:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:59:02 --> Input Class Initialized
INFO - 2021-06-26 03:59:02 --> Language Class Initialized
INFO - 2021-06-26 03:59:03 --> Language Class Initialized
INFO - 2021-06-26 03:59:03 --> Config Class Initialized
INFO - 2021-06-26 03:59:03 --> Loader Class Initialized
INFO - 2021-06-26 03:59:03 --> Helper loaded: url_helper
INFO - 2021-06-26 03:59:03 --> Helper loaded: file_helper
INFO - 2021-06-26 03:59:03 --> Helper loaded: form_helper
INFO - 2021-06-26 03:59:03 --> Helper loaded: my_helper
INFO - 2021-06-26 03:59:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:59:03 --> Controller Class Initialized
DEBUG - 2021-06-26 03:59:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-26 03:59:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:59:03 --> Final output sent to browser
DEBUG - 2021-06-26 03:59:03 --> Total execution time: 0.0806
INFO - 2021-06-26 03:59:11 --> Config Class Initialized
INFO - 2021-06-26 03:59:11 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:59:11 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:59:11 --> Utf8 Class Initialized
INFO - 2021-06-26 03:59:11 --> URI Class Initialized
INFO - 2021-06-26 03:59:11 --> Router Class Initialized
INFO - 2021-06-26 03:59:11 --> Output Class Initialized
INFO - 2021-06-26 03:59:11 --> Security Class Initialized
DEBUG - 2021-06-26 03:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:59:11 --> Input Class Initialized
INFO - 2021-06-26 03:59:11 --> Language Class Initialized
INFO - 2021-06-26 03:59:11 --> Language Class Initialized
INFO - 2021-06-26 03:59:11 --> Config Class Initialized
INFO - 2021-06-26 03:59:11 --> Loader Class Initialized
INFO - 2021-06-26 03:59:11 --> Helper loaded: url_helper
INFO - 2021-06-26 03:59:11 --> Helper loaded: file_helper
INFO - 2021-06-26 03:59:11 --> Helper loaded: form_helper
INFO - 2021-06-26 03:59:11 --> Helper loaded: my_helper
INFO - 2021-06-26 03:59:11 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:59:11 --> Controller Class Initialized
DEBUG - 2021-06-26 03:59:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-26 03:59:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:59:11 --> Final output sent to browser
DEBUG - 2021-06-26 03:59:11 --> Total execution time: 0.0653
INFO - 2021-06-26 03:59:14 --> Config Class Initialized
INFO - 2021-06-26 03:59:14 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:59:14 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:59:14 --> Utf8 Class Initialized
INFO - 2021-06-26 03:59:14 --> URI Class Initialized
INFO - 2021-06-26 03:59:14 --> Router Class Initialized
INFO - 2021-06-26 03:59:14 --> Output Class Initialized
INFO - 2021-06-26 03:59:14 --> Security Class Initialized
DEBUG - 2021-06-26 03:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:59:14 --> Input Class Initialized
INFO - 2021-06-26 03:59:14 --> Language Class Initialized
INFO - 2021-06-26 03:59:14 --> Language Class Initialized
INFO - 2021-06-26 03:59:14 --> Config Class Initialized
INFO - 2021-06-26 03:59:14 --> Loader Class Initialized
INFO - 2021-06-26 03:59:14 --> Helper loaded: url_helper
INFO - 2021-06-26 03:59:14 --> Helper loaded: file_helper
INFO - 2021-06-26 03:59:14 --> Helper loaded: form_helper
INFO - 2021-06-26 03:59:14 --> Helper loaded: my_helper
INFO - 2021-06-26 03:59:14 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:59:14 --> Controller Class Initialized
DEBUG - 2021-06-26 03:59:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-26 03:59:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 03:59:14 --> Final output sent to browser
DEBUG - 2021-06-26 03:59:14 --> Total execution time: 0.0938
INFO - 2021-06-26 03:59:18 --> Config Class Initialized
INFO - 2021-06-26 03:59:18 --> Hooks Class Initialized
DEBUG - 2021-06-26 03:59:18 --> UTF-8 Support Enabled
INFO - 2021-06-26 03:59:18 --> Utf8 Class Initialized
INFO - 2021-06-26 03:59:18 --> URI Class Initialized
INFO - 2021-06-26 03:59:18 --> Router Class Initialized
INFO - 2021-06-26 03:59:18 --> Output Class Initialized
INFO - 2021-06-26 03:59:18 --> Security Class Initialized
DEBUG - 2021-06-26 03:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 03:59:18 --> Input Class Initialized
INFO - 2021-06-26 03:59:18 --> Language Class Initialized
INFO - 2021-06-26 03:59:18 --> Language Class Initialized
INFO - 2021-06-26 03:59:18 --> Config Class Initialized
INFO - 2021-06-26 03:59:18 --> Loader Class Initialized
INFO - 2021-06-26 03:59:18 --> Helper loaded: url_helper
INFO - 2021-06-26 03:59:18 --> Helper loaded: file_helper
INFO - 2021-06-26 03:59:18 --> Helper loaded: form_helper
INFO - 2021-06-26 03:59:18 --> Helper loaded: my_helper
INFO - 2021-06-26 03:59:18 --> Database Driver Class Initialized
DEBUG - 2021-06-26 03:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 03:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 03:59:18 --> Controller Class Initialized
INFO - 2021-06-26 03:59:18 --> Final output sent to browser
DEBUG - 2021-06-26 03:59:18 --> Total execution time: 0.0492
INFO - 2021-06-26 04:01:06 --> Config Class Initialized
INFO - 2021-06-26 04:01:06 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:06 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:06 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:06 --> URI Class Initialized
INFO - 2021-06-26 04:01:06 --> Router Class Initialized
INFO - 2021-06-26 04:01:06 --> Output Class Initialized
INFO - 2021-06-26 04:01:06 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:06 --> Input Class Initialized
INFO - 2021-06-26 04:01:06 --> Language Class Initialized
INFO - 2021-06-26 04:01:06 --> Language Class Initialized
INFO - 2021-06-26 04:01:06 --> Config Class Initialized
INFO - 2021-06-26 04:01:06 --> Loader Class Initialized
INFO - 2021-06-26 04:01:06 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:06 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:06 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:06 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:06 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:06 --> Controller Class Initialized
INFO - 2021-06-26 04:01:06 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:06 --> Total execution time: 0.0914
INFO - 2021-06-26 04:01:28 --> Config Class Initialized
INFO - 2021-06-26 04:01:28 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:28 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:28 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:28 --> URI Class Initialized
INFO - 2021-06-26 04:01:28 --> Router Class Initialized
INFO - 2021-06-26 04:01:28 --> Output Class Initialized
INFO - 2021-06-26 04:01:28 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:28 --> Input Class Initialized
INFO - 2021-06-26 04:01:28 --> Language Class Initialized
INFO - 2021-06-26 04:01:28 --> Language Class Initialized
INFO - 2021-06-26 04:01:28 --> Config Class Initialized
INFO - 2021-06-26 04:01:28 --> Loader Class Initialized
INFO - 2021-06-26 04:01:28 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:28 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:28 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:28 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:28 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:28 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-26 04:01:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:28 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:28 --> Total execution time: 0.0637
INFO - 2021-06-26 04:01:34 --> Config Class Initialized
INFO - 2021-06-26 04:01:34 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:34 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:34 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:34 --> URI Class Initialized
INFO - 2021-06-26 04:01:34 --> Router Class Initialized
INFO - 2021-06-26 04:01:34 --> Output Class Initialized
INFO - 2021-06-26 04:01:34 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:34 --> Input Class Initialized
INFO - 2021-06-26 04:01:34 --> Language Class Initialized
INFO - 2021-06-26 04:01:34 --> Language Class Initialized
INFO - 2021-06-26 04:01:34 --> Config Class Initialized
INFO - 2021-06-26 04:01:34 --> Loader Class Initialized
INFO - 2021-06-26 04:01:34 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:34 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:34 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:34 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:34 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:34 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-26 04:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:34 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:34 --> Total execution time: 0.0394
INFO - 2021-06-26 04:01:37 --> Config Class Initialized
INFO - 2021-06-26 04:01:37 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:37 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:37 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:37 --> URI Class Initialized
INFO - 2021-06-26 04:01:37 --> Router Class Initialized
INFO - 2021-06-26 04:01:37 --> Output Class Initialized
INFO - 2021-06-26 04:01:37 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:37 --> Input Class Initialized
INFO - 2021-06-26 04:01:37 --> Language Class Initialized
INFO - 2021-06-26 04:01:37 --> Language Class Initialized
INFO - 2021-06-26 04:01:37 --> Config Class Initialized
INFO - 2021-06-26 04:01:37 --> Loader Class Initialized
INFO - 2021-06-26 04:01:37 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:37 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:37 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:37 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:37 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:37 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-26 04:01:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:37 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:37 --> Total execution time: 0.0998
INFO - 2021-06-26 04:01:38 --> Config Class Initialized
INFO - 2021-06-26 04:01:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:38 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:38 --> URI Class Initialized
INFO - 2021-06-26 04:01:38 --> Router Class Initialized
INFO - 2021-06-26 04:01:38 --> Output Class Initialized
INFO - 2021-06-26 04:01:38 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:38 --> Input Class Initialized
INFO - 2021-06-26 04:01:38 --> Language Class Initialized
INFO - 2021-06-26 04:01:38 --> Language Class Initialized
INFO - 2021-06-26 04:01:38 --> Config Class Initialized
INFO - 2021-06-26 04:01:38 --> Loader Class Initialized
INFO - 2021-06-26 04:01:38 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:38 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:38 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:38 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:38 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-26 04:01:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:38 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:38 --> Total execution time: 0.0525
INFO - 2021-06-26 04:01:39 --> Config Class Initialized
INFO - 2021-06-26 04:01:39 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:39 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:39 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:39 --> URI Class Initialized
INFO - 2021-06-26 04:01:39 --> Router Class Initialized
INFO - 2021-06-26 04:01:39 --> Output Class Initialized
INFO - 2021-06-26 04:01:39 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:39 --> Input Class Initialized
INFO - 2021-06-26 04:01:39 --> Language Class Initialized
INFO - 2021-06-26 04:01:39 --> Language Class Initialized
INFO - 2021-06-26 04:01:39 --> Config Class Initialized
INFO - 2021-06-26 04:01:39 --> Loader Class Initialized
INFO - 2021-06-26 04:01:39 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:39 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:39 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:39 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:39 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:39 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-26 04:01:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:39 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:39 --> Total execution time: 0.0500
INFO - 2021-06-26 04:01:40 --> Config Class Initialized
INFO - 2021-06-26 04:01:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:40 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:40 --> URI Class Initialized
INFO - 2021-06-26 04:01:40 --> Router Class Initialized
INFO - 2021-06-26 04:01:40 --> Output Class Initialized
INFO - 2021-06-26 04:01:40 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:40 --> Input Class Initialized
INFO - 2021-06-26 04:01:40 --> Language Class Initialized
INFO - 2021-06-26 04:01:40 --> Language Class Initialized
INFO - 2021-06-26 04:01:40 --> Config Class Initialized
INFO - 2021-06-26 04:01:40 --> Loader Class Initialized
INFO - 2021-06-26 04:01:40 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:40 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:40 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:40 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:40 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-26 04:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:40 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:40 --> Total execution time: 0.0518
INFO - 2021-06-26 04:01:42 --> Config Class Initialized
INFO - 2021-06-26 04:01:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:42 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:42 --> URI Class Initialized
INFO - 2021-06-26 04:01:42 --> Router Class Initialized
INFO - 2021-06-26 04:01:42 --> Output Class Initialized
INFO - 2021-06-26 04:01:42 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:42 --> Input Class Initialized
INFO - 2021-06-26 04:01:42 --> Language Class Initialized
INFO - 2021-06-26 04:01:42 --> Language Class Initialized
INFO - 2021-06-26 04:01:42 --> Config Class Initialized
INFO - 2021-06-26 04:01:42 --> Loader Class Initialized
INFO - 2021-06-26 04:01:42 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:42 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:42 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:42 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:42 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-26 04:01:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:42 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:42 --> Total execution time: 0.1020
INFO - 2021-06-26 04:01:44 --> Config Class Initialized
INFO - 2021-06-26 04:01:44 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:44 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:44 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:44 --> URI Class Initialized
INFO - 2021-06-26 04:01:44 --> Router Class Initialized
INFO - 2021-06-26 04:01:44 --> Output Class Initialized
INFO - 2021-06-26 04:01:44 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:44 --> Input Class Initialized
INFO - 2021-06-26 04:01:44 --> Language Class Initialized
INFO - 2021-06-26 04:01:44 --> Language Class Initialized
INFO - 2021-06-26 04:01:44 --> Config Class Initialized
INFO - 2021-06-26 04:01:44 --> Loader Class Initialized
INFO - 2021-06-26 04:01:44 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:44 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:44 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:44 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:44 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-26 04:01:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:44 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:44 --> Total execution time: 0.0550
INFO - 2021-06-26 04:01:46 --> Config Class Initialized
INFO - 2021-06-26 04:01:46 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:46 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:46 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:46 --> URI Class Initialized
INFO - 2021-06-26 04:01:46 --> Router Class Initialized
INFO - 2021-06-26 04:01:46 --> Output Class Initialized
INFO - 2021-06-26 04:01:46 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:46 --> Input Class Initialized
INFO - 2021-06-26 04:01:46 --> Language Class Initialized
INFO - 2021-06-26 04:01:46 --> Language Class Initialized
INFO - 2021-06-26 04:01:46 --> Config Class Initialized
INFO - 2021-06-26 04:01:46 --> Loader Class Initialized
INFO - 2021-06-26 04:01:46 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:46 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:46 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:46 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:46 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:46 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 04:01:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:46 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:46 --> Total execution time: 0.0573
INFO - 2021-06-26 04:01:51 --> Config Class Initialized
INFO - 2021-06-26 04:01:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:51 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:51 --> URI Class Initialized
INFO - 2021-06-26 04:01:51 --> Router Class Initialized
INFO - 2021-06-26 04:01:51 --> Output Class Initialized
INFO - 2021-06-26 04:01:51 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:51 --> Input Class Initialized
INFO - 2021-06-26 04:01:51 --> Language Class Initialized
INFO - 2021-06-26 04:01:51 --> Language Class Initialized
INFO - 2021-06-26 04:01:51 --> Config Class Initialized
INFO - 2021-06-26 04:01:51 --> Loader Class Initialized
INFO - 2021-06-26 04:01:51 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:51 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:51 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:51 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:51 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 04:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:01:51 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:51 --> Total execution time: 0.0571
INFO - 2021-06-26 04:01:55 --> Config Class Initialized
INFO - 2021-06-26 04:01:55 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:01:55 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:01:55 --> Utf8 Class Initialized
INFO - 2021-06-26 04:01:55 --> URI Class Initialized
INFO - 2021-06-26 04:01:55 --> Router Class Initialized
INFO - 2021-06-26 04:01:55 --> Output Class Initialized
INFO - 2021-06-26 04:01:55 --> Security Class Initialized
DEBUG - 2021-06-26 04:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:01:55 --> Input Class Initialized
INFO - 2021-06-26 04:01:55 --> Language Class Initialized
INFO - 2021-06-26 04:01:55 --> Language Class Initialized
INFO - 2021-06-26 04:01:55 --> Config Class Initialized
INFO - 2021-06-26 04:01:55 --> Loader Class Initialized
INFO - 2021-06-26 04:01:55 --> Helper loaded: url_helper
INFO - 2021-06-26 04:01:55 --> Helper loaded: file_helper
INFO - 2021-06-26 04:01:55 --> Helper loaded: form_helper
INFO - 2021-06-26 04:01:55 --> Helper loaded: my_helper
INFO - 2021-06-26 04:01:55 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:01:55 --> Controller Class Initialized
DEBUG - 2021-06-26 04:01:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:01:55 --> Final output sent to browser
DEBUG - 2021-06-26 04:01:55 --> Total execution time: 0.2482
INFO - 2021-06-26 04:02:59 --> Config Class Initialized
INFO - 2021-06-26 04:02:59 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:02:59 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:02:59 --> Utf8 Class Initialized
INFO - 2021-06-26 04:02:59 --> URI Class Initialized
INFO - 2021-06-26 04:02:59 --> Router Class Initialized
INFO - 2021-06-26 04:02:59 --> Output Class Initialized
INFO - 2021-06-26 04:02:59 --> Security Class Initialized
DEBUG - 2021-06-26 04:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:02:59 --> Input Class Initialized
INFO - 2021-06-26 04:02:59 --> Language Class Initialized
INFO - 2021-06-26 04:02:59 --> Language Class Initialized
INFO - 2021-06-26 04:02:59 --> Config Class Initialized
INFO - 2021-06-26 04:02:59 --> Loader Class Initialized
INFO - 2021-06-26 04:02:59 --> Helper loaded: url_helper
INFO - 2021-06-26 04:02:59 --> Helper loaded: file_helper
INFO - 2021-06-26 04:02:59 --> Helper loaded: form_helper
INFO - 2021-06-26 04:02:59 --> Helper loaded: my_helper
INFO - 2021-06-26 04:02:59 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:02:59 --> Controller Class Initialized
DEBUG - 2021-06-26 04:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:02:59 --> Final output sent to browser
DEBUG - 2021-06-26 04:02:59 --> Total execution time: 0.1849
INFO - 2021-06-26 04:04:25 --> Config Class Initialized
INFO - 2021-06-26 04:04:25 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:25 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:25 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:25 --> URI Class Initialized
INFO - 2021-06-26 04:04:25 --> Router Class Initialized
INFO - 2021-06-26 04:04:25 --> Output Class Initialized
INFO - 2021-06-26 04:04:25 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:25 --> Input Class Initialized
INFO - 2021-06-26 04:04:25 --> Language Class Initialized
INFO - 2021-06-26 04:04:25 --> Language Class Initialized
INFO - 2021-06-26 04:04:25 --> Config Class Initialized
INFO - 2021-06-26 04:04:25 --> Loader Class Initialized
INFO - 2021-06-26 04:04:25 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:25 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:25 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:25 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:25 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:25 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:26 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:26 --> Total execution time: 0.1867
INFO - 2021-06-26 04:04:36 --> Config Class Initialized
INFO - 2021-06-26 04:04:36 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:36 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:36 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:36 --> URI Class Initialized
INFO - 2021-06-26 04:04:36 --> Router Class Initialized
INFO - 2021-06-26 04:04:36 --> Output Class Initialized
INFO - 2021-06-26 04:04:36 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:36 --> Input Class Initialized
INFO - 2021-06-26 04:04:36 --> Language Class Initialized
INFO - 2021-06-26 04:04:36 --> Language Class Initialized
INFO - 2021-06-26 04:04:36 --> Config Class Initialized
INFO - 2021-06-26 04:04:36 --> Loader Class Initialized
INFO - 2021-06-26 04:04:36 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:36 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:36 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:36 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:36 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:36 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:36 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:36 --> Total execution time: 0.1894
INFO - 2021-06-26 04:04:37 --> Config Class Initialized
INFO - 2021-06-26 04:04:37 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:37 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:37 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:37 --> URI Class Initialized
INFO - 2021-06-26 04:04:37 --> Router Class Initialized
INFO - 2021-06-26 04:04:37 --> Output Class Initialized
INFO - 2021-06-26 04:04:37 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:37 --> Input Class Initialized
INFO - 2021-06-26 04:04:37 --> Language Class Initialized
INFO - 2021-06-26 04:04:37 --> Language Class Initialized
INFO - 2021-06-26 04:04:37 --> Config Class Initialized
INFO - 2021-06-26 04:04:37 --> Loader Class Initialized
INFO - 2021-06-26 04:04:37 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:37 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:37 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:37 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:37 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:37 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:37 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:37 --> Total execution time: 0.2375
INFO - 2021-06-26 04:04:39 --> Config Class Initialized
INFO - 2021-06-26 04:04:39 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:39 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:39 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:39 --> URI Class Initialized
INFO - 2021-06-26 04:04:39 --> Router Class Initialized
INFO - 2021-06-26 04:04:39 --> Output Class Initialized
INFO - 2021-06-26 04:04:39 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:39 --> Input Class Initialized
INFO - 2021-06-26 04:04:39 --> Language Class Initialized
INFO - 2021-06-26 04:04:39 --> Language Class Initialized
INFO - 2021-06-26 04:04:39 --> Config Class Initialized
INFO - 2021-06-26 04:04:39 --> Loader Class Initialized
INFO - 2021-06-26 04:04:39 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:39 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:39 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:39 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:39 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:39 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:39 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:39 --> Total execution time: 0.1845
INFO - 2021-06-26 04:04:40 --> Config Class Initialized
INFO - 2021-06-26 04:04:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:40 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:40 --> URI Class Initialized
INFO - 2021-06-26 04:04:40 --> Router Class Initialized
INFO - 2021-06-26 04:04:40 --> Output Class Initialized
INFO - 2021-06-26 04:04:40 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:40 --> Input Class Initialized
INFO - 2021-06-26 04:04:40 --> Language Class Initialized
INFO - 2021-06-26 04:04:40 --> Language Class Initialized
INFO - 2021-06-26 04:04:40 --> Config Class Initialized
INFO - 2021-06-26 04:04:40 --> Loader Class Initialized
INFO - 2021-06-26 04:04:40 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:40 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:40 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:40 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:40 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:40 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:40 --> Total execution time: 0.1882
INFO - 2021-06-26 04:04:42 --> Config Class Initialized
INFO - 2021-06-26 04:04:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:42 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:42 --> URI Class Initialized
INFO - 2021-06-26 04:04:42 --> Router Class Initialized
INFO - 2021-06-26 04:04:42 --> Output Class Initialized
INFO - 2021-06-26 04:04:42 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:42 --> Input Class Initialized
INFO - 2021-06-26 04:04:42 --> Language Class Initialized
INFO - 2021-06-26 04:04:42 --> Language Class Initialized
INFO - 2021-06-26 04:04:42 --> Config Class Initialized
INFO - 2021-06-26 04:04:42 --> Loader Class Initialized
INFO - 2021-06-26 04:04:42 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:42 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:42 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:42 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:42 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:42 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:43 --> Total execution time: 0.1889
INFO - 2021-06-26 04:04:44 --> Config Class Initialized
INFO - 2021-06-26 04:04:44 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:44 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:44 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:44 --> URI Class Initialized
INFO - 2021-06-26 04:04:44 --> Router Class Initialized
INFO - 2021-06-26 04:04:44 --> Output Class Initialized
INFO - 2021-06-26 04:04:44 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:44 --> Input Class Initialized
INFO - 2021-06-26 04:04:44 --> Language Class Initialized
INFO - 2021-06-26 04:04:44 --> Language Class Initialized
INFO - 2021-06-26 04:04:44 --> Config Class Initialized
INFO - 2021-06-26 04:04:44 --> Loader Class Initialized
INFO - 2021-06-26 04:04:44 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:44 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:44 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:44 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:44 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:44 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:44 --> Total execution time: 0.1973
INFO - 2021-06-26 04:04:45 --> Config Class Initialized
INFO - 2021-06-26 04:04:45 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:45 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:45 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:45 --> URI Class Initialized
INFO - 2021-06-26 04:04:45 --> Router Class Initialized
INFO - 2021-06-26 04:04:45 --> Output Class Initialized
INFO - 2021-06-26 04:04:45 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:45 --> Input Class Initialized
INFO - 2021-06-26 04:04:45 --> Language Class Initialized
INFO - 2021-06-26 04:04:45 --> Language Class Initialized
INFO - 2021-06-26 04:04:45 --> Config Class Initialized
INFO - 2021-06-26 04:04:45 --> Loader Class Initialized
INFO - 2021-06-26 04:04:45 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:45 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:45 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:45 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:45 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:45 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:45 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:45 --> Total execution time: 0.1870
INFO - 2021-06-26 04:04:46 --> Config Class Initialized
INFO - 2021-06-26 04:04:46 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:46 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:46 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:46 --> URI Class Initialized
INFO - 2021-06-26 04:04:46 --> Router Class Initialized
INFO - 2021-06-26 04:04:46 --> Output Class Initialized
INFO - 2021-06-26 04:04:46 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:46 --> Input Class Initialized
INFO - 2021-06-26 04:04:46 --> Language Class Initialized
INFO - 2021-06-26 04:04:46 --> Language Class Initialized
INFO - 2021-06-26 04:04:46 --> Config Class Initialized
INFO - 2021-06-26 04:04:46 --> Loader Class Initialized
INFO - 2021-06-26 04:04:46 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:46 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:46 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:46 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:46 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:46 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:47 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:47 --> Total execution time: 0.2846
INFO - 2021-06-26 04:04:48 --> Config Class Initialized
INFO - 2021-06-26 04:04:48 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:48 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:48 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:48 --> URI Class Initialized
INFO - 2021-06-26 04:04:48 --> Router Class Initialized
INFO - 2021-06-26 04:04:48 --> Output Class Initialized
INFO - 2021-06-26 04:04:48 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:48 --> Input Class Initialized
INFO - 2021-06-26 04:04:48 --> Language Class Initialized
INFO - 2021-06-26 04:04:48 --> Language Class Initialized
INFO - 2021-06-26 04:04:48 --> Config Class Initialized
INFO - 2021-06-26 04:04:48 --> Loader Class Initialized
INFO - 2021-06-26 04:04:48 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:48 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:48 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:48 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:48 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:48 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:48 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:48 --> Total execution time: 0.1940
INFO - 2021-06-26 04:04:50 --> Config Class Initialized
INFO - 2021-06-26 04:04:50 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:50 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:50 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:50 --> URI Class Initialized
INFO - 2021-06-26 04:04:50 --> Router Class Initialized
INFO - 2021-06-26 04:04:50 --> Output Class Initialized
INFO - 2021-06-26 04:04:50 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:50 --> Input Class Initialized
INFO - 2021-06-26 04:04:50 --> Language Class Initialized
INFO - 2021-06-26 04:04:50 --> Language Class Initialized
INFO - 2021-06-26 04:04:50 --> Config Class Initialized
INFO - 2021-06-26 04:04:50 --> Loader Class Initialized
INFO - 2021-06-26 04:04:50 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:50 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:50 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:50 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:50 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:50 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:50 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:50 --> Total execution time: 0.1930
INFO - 2021-06-26 04:04:52 --> Config Class Initialized
INFO - 2021-06-26 04:04:52 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:52 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:52 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:52 --> URI Class Initialized
INFO - 2021-06-26 04:04:52 --> Router Class Initialized
INFO - 2021-06-26 04:04:52 --> Output Class Initialized
INFO - 2021-06-26 04:04:52 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:52 --> Input Class Initialized
INFO - 2021-06-26 04:04:52 --> Language Class Initialized
INFO - 2021-06-26 04:04:52 --> Language Class Initialized
INFO - 2021-06-26 04:04:52 --> Config Class Initialized
INFO - 2021-06-26 04:04:52 --> Loader Class Initialized
INFO - 2021-06-26 04:04:52 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:52 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:52 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:52 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:52 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:52 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:52 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:52 --> Total execution time: 0.1889
INFO - 2021-06-26 04:04:53 --> Config Class Initialized
INFO - 2021-06-26 04:04:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:54 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:54 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:54 --> URI Class Initialized
INFO - 2021-06-26 04:04:54 --> Router Class Initialized
INFO - 2021-06-26 04:04:54 --> Output Class Initialized
INFO - 2021-06-26 04:04:54 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:54 --> Input Class Initialized
INFO - 2021-06-26 04:04:54 --> Language Class Initialized
INFO - 2021-06-26 04:04:54 --> Language Class Initialized
INFO - 2021-06-26 04:04:54 --> Config Class Initialized
INFO - 2021-06-26 04:04:54 --> Loader Class Initialized
INFO - 2021-06-26 04:04:54 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:54 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:54 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:54 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:54 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:54 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:54 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:54 --> Total execution time: 0.2542
INFO - 2021-06-26 04:04:55 --> Config Class Initialized
INFO - 2021-06-26 04:04:55 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:55 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:55 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:55 --> URI Class Initialized
INFO - 2021-06-26 04:04:55 --> Router Class Initialized
INFO - 2021-06-26 04:04:55 --> Output Class Initialized
INFO - 2021-06-26 04:04:55 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:55 --> Input Class Initialized
INFO - 2021-06-26 04:04:55 --> Language Class Initialized
INFO - 2021-06-26 04:04:55 --> Language Class Initialized
INFO - 2021-06-26 04:04:55 --> Config Class Initialized
INFO - 2021-06-26 04:04:55 --> Loader Class Initialized
INFO - 2021-06-26 04:04:55 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:55 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:55 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:55 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:55 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:55 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:55 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:55 --> Total execution time: 0.1861
INFO - 2021-06-26 04:04:57 --> Config Class Initialized
INFO - 2021-06-26 04:04:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:57 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:57 --> URI Class Initialized
INFO - 2021-06-26 04:04:57 --> Router Class Initialized
INFO - 2021-06-26 04:04:57 --> Output Class Initialized
INFO - 2021-06-26 04:04:57 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:57 --> Input Class Initialized
INFO - 2021-06-26 04:04:57 --> Language Class Initialized
INFO - 2021-06-26 04:04:57 --> Language Class Initialized
INFO - 2021-06-26 04:04:57 --> Config Class Initialized
INFO - 2021-06-26 04:04:57 --> Loader Class Initialized
INFO - 2021-06-26 04:04:57 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:57 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:57 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:57 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:57 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:57 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:57 --> Total execution time: 0.2177
INFO - 2021-06-26 04:04:58 --> Config Class Initialized
INFO - 2021-06-26 04:04:58 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:58 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:58 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:58 --> URI Class Initialized
INFO - 2021-06-26 04:04:58 --> Router Class Initialized
INFO - 2021-06-26 04:04:58 --> Output Class Initialized
INFO - 2021-06-26 04:04:58 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:58 --> Input Class Initialized
INFO - 2021-06-26 04:04:58 --> Language Class Initialized
INFO - 2021-06-26 04:04:58 --> Language Class Initialized
INFO - 2021-06-26 04:04:58 --> Config Class Initialized
INFO - 2021-06-26 04:04:58 --> Loader Class Initialized
INFO - 2021-06-26 04:04:58 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:58 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:58 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:58 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:58 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:58 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:58 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:58 --> Total execution time: 0.1868
INFO - 2021-06-26 04:04:59 --> Config Class Initialized
INFO - 2021-06-26 04:04:59 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:04:59 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:04:59 --> Utf8 Class Initialized
INFO - 2021-06-26 04:04:59 --> URI Class Initialized
INFO - 2021-06-26 04:04:59 --> Router Class Initialized
INFO - 2021-06-26 04:04:59 --> Output Class Initialized
INFO - 2021-06-26 04:04:59 --> Security Class Initialized
DEBUG - 2021-06-26 04:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:04:59 --> Input Class Initialized
INFO - 2021-06-26 04:04:59 --> Language Class Initialized
INFO - 2021-06-26 04:04:59 --> Language Class Initialized
INFO - 2021-06-26 04:04:59 --> Config Class Initialized
INFO - 2021-06-26 04:04:59 --> Loader Class Initialized
INFO - 2021-06-26 04:04:59 --> Helper loaded: url_helper
INFO - 2021-06-26 04:04:59 --> Helper loaded: file_helper
INFO - 2021-06-26 04:04:59 --> Helper loaded: form_helper
INFO - 2021-06-26 04:04:59 --> Helper loaded: my_helper
INFO - 2021-06-26 04:04:59 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:04:59 --> Controller Class Initialized
DEBUG - 2021-06-26 04:04:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:04:59 --> Final output sent to browser
DEBUG - 2021-06-26 04:04:59 --> Total execution time: 0.1901
INFO - 2021-06-26 04:05:01 --> Config Class Initialized
INFO - 2021-06-26 04:05:01 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:01 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:01 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:01 --> URI Class Initialized
INFO - 2021-06-26 04:05:01 --> Router Class Initialized
INFO - 2021-06-26 04:05:01 --> Output Class Initialized
INFO - 2021-06-26 04:05:01 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:01 --> Input Class Initialized
INFO - 2021-06-26 04:05:01 --> Language Class Initialized
INFO - 2021-06-26 04:05:01 --> Language Class Initialized
INFO - 2021-06-26 04:05:01 --> Config Class Initialized
INFO - 2021-06-26 04:05:01 --> Loader Class Initialized
INFO - 2021-06-26 04:05:01 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:01 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:01 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:01 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:01 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:01 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:01 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:01 --> Total execution time: 0.1905
INFO - 2021-06-26 04:05:02 --> Config Class Initialized
INFO - 2021-06-26 04:05:02 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:02 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:02 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:02 --> URI Class Initialized
INFO - 2021-06-26 04:05:02 --> Router Class Initialized
INFO - 2021-06-26 04:05:02 --> Output Class Initialized
INFO - 2021-06-26 04:05:02 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:02 --> Input Class Initialized
INFO - 2021-06-26 04:05:02 --> Language Class Initialized
INFO - 2021-06-26 04:05:02 --> Language Class Initialized
INFO - 2021-06-26 04:05:02 --> Config Class Initialized
INFO - 2021-06-26 04:05:02 --> Loader Class Initialized
INFO - 2021-06-26 04:05:02 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:02 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:02 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:02 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:02 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:02 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:02 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:02 --> Total execution time: 0.1839
INFO - 2021-06-26 04:05:04 --> Config Class Initialized
INFO - 2021-06-26 04:05:04 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:04 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:04 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:04 --> URI Class Initialized
INFO - 2021-06-26 04:05:04 --> Router Class Initialized
INFO - 2021-06-26 04:05:04 --> Output Class Initialized
INFO - 2021-06-26 04:05:04 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:04 --> Input Class Initialized
INFO - 2021-06-26 04:05:04 --> Language Class Initialized
INFO - 2021-06-26 04:05:04 --> Language Class Initialized
INFO - 2021-06-26 04:05:04 --> Config Class Initialized
INFO - 2021-06-26 04:05:04 --> Loader Class Initialized
INFO - 2021-06-26 04:05:04 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:04 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:04 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:04 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:04 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:04 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:04 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:04 --> Total execution time: 0.1905
INFO - 2021-06-26 04:05:05 --> Config Class Initialized
INFO - 2021-06-26 04:05:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:05 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:05 --> URI Class Initialized
INFO - 2021-06-26 04:05:05 --> Router Class Initialized
INFO - 2021-06-26 04:05:05 --> Output Class Initialized
INFO - 2021-06-26 04:05:05 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:05 --> Input Class Initialized
INFO - 2021-06-26 04:05:05 --> Language Class Initialized
INFO - 2021-06-26 04:05:05 --> Language Class Initialized
INFO - 2021-06-26 04:05:05 --> Config Class Initialized
INFO - 2021-06-26 04:05:05 --> Loader Class Initialized
INFO - 2021-06-26 04:05:05 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:05 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:05 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:05 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:05 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:05 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:05 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:05 --> Total execution time: 0.1817
INFO - 2021-06-26 04:05:07 --> Config Class Initialized
INFO - 2021-06-26 04:05:07 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:07 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:07 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:07 --> URI Class Initialized
INFO - 2021-06-26 04:05:07 --> Router Class Initialized
INFO - 2021-06-26 04:05:07 --> Output Class Initialized
INFO - 2021-06-26 04:05:07 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:07 --> Input Class Initialized
INFO - 2021-06-26 04:05:07 --> Language Class Initialized
INFO - 2021-06-26 04:05:07 --> Language Class Initialized
INFO - 2021-06-26 04:05:07 --> Config Class Initialized
INFO - 2021-06-26 04:05:07 --> Loader Class Initialized
INFO - 2021-06-26 04:05:07 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:07 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:07 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:07 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:07 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:07 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:07 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:07 --> Total execution time: 0.1933
INFO - 2021-06-26 04:05:08 --> Config Class Initialized
INFO - 2021-06-26 04:05:08 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:08 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:08 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:08 --> URI Class Initialized
INFO - 2021-06-26 04:05:08 --> Router Class Initialized
INFO - 2021-06-26 04:05:08 --> Output Class Initialized
INFO - 2021-06-26 04:05:08 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:08 --> Input Class Initialized
INFO - 2021-06-26 04:05:08 --> Language Class Initialized
INFO - 2021-06-26 04:05:08 --> Language Class Initialized
INFO - 2021-06-26 04:05:08 --> Config Class Initialized
INFO - 2021-06-26 04:05:08 --> Loader Class Initialized
INFO - 2021-06-26 04:05:08 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:08 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:08 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:08 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:08 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:08 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:08 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:08 --> Total execution time: 0.1832
INFO - 2021-06-26 04:05:10 --> Config Class Initialized
INFO - 2021-06-26 04:05:10 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:10 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:10 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:10 --> URI Class Initialized
INFO - 2021-06-26 04:05:10 --> Router Class Initialized
INFO - 2021-06-26 04:05:10 --> Output Class Initialized
INFO - 2021-06-26 04:05:10 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:10 --> Input Class Initialized
INFO - 2021-06-26 04:05:10 --> Language Class Initialized
INFO - 2021-06-26 04:05:10 --> Language Class Initialized
INFO - 2021-06-26 04:05:10 --> Config Class Initialized
INFO - 2021-06-26 04:05:10 --> Loader Class Initialized
INFO - 2021-06-26 04:05:10 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:10 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:10 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:10 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:10 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:10 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:10 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:10 --> Total execution time: 0.1942
INFO - 2021-06-26 04:05:11 --> Config Class Initialized
INFO - 2021-06-26 04:05:11 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:11 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:11 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:11 --> URI Class Initialized
INFO - 2021-06-26 04:05:11 --> Router Class Initialized
INFO - 2021-06-26 04:05:11 --> Output Class Initialized
INFO - 2021-06-26 04:05:11 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:11 --> Input Class Initialized
INFO - 2021-06-26 04:05:11 --> Language Class Initialized
INFO - 2021-06-26 04:05:11 --> Language Class Initialized
INFO - 2021-06-26 04:05:11 --> Config Class Initialized
INFO - 2021-06-26 04:05:11 --> Loader Class Initialized
INFO - 2021-06-26 04:05:11 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:11 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:11 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:11 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:11 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:11 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:12 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:12 --> Total execution time: 0.2931
INFO - 2021-06-26 04:05:13 --> Config Class Initialized
INFO - 2021-06-26 04:05:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:13 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:13 --> URI Class Initialized
INFO - 2021-06-26 04:05:13 --> Router Class Initialized
INFO - 2021-06-26 04:05:13 --> Output Class Initialized
INFO - 2021-06-26 04:05:13 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:13 --> Input Class Initialized
INFO - 2021-06-26 04:05:13 --> Language Class Initialized
INFO - 2021-06-26 04:05:13 --> Language Class Initialized
INFO - 2021-06-26 04:05:13 --> Config Class Initialized
INFO - 2021-06-26 04:05:13 --> Loader Class Initialized
INFO - 2021-06-26 04:05:13 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:13 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:13 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:13 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:13 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:13 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:13 --> Total execution time: 0.2020
INFO - 2021-06-26 04:05:14 --> Config Class Initialized
INFO - 2021-06-26 04:05:14 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:14 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:14 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:14 --> URI Class Initialized
INFO - 2021-06-26 04:05:14 --> Router Class Initialized
INFO - 2021-06-26 04:05:14 --> Output Class Initialized
INFO - 2021-06-26 04:05:14 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:14 --> Input Class Initialized
INFO - 2021-06-26 04:05:14 --> Language Class Initialized
INFO - 2021-06-26 04:05:14 --> Language Class Initialized
INFO - 2021-06-26 04:05:14 --> Config Class Initialized
INFO - 2021-06-26 04:05:14 --> Loader Class Initialized
INFO - 2021-06-26 04:05:15 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:15 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:15 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:15 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:15 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:15 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:15 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:15 --> Total execution time: 0.3147
INFO - 2021-06-26 04:05:16 --> Config Class Initialized
INFO - 2021-06-26 04:05:16 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:05:16 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:05:16 --> Utf8 Class Initialized
INFO - 2021-06-26 04:05:16 --> URI Class Initialized
INFO - 2021-06-26 04:05:16 --> Router Class Initialized
INFO - 2021-06-26 04:05:16 --> Output Class Initialized
INFO - 2021-06-26 04:05:16 --> Security Class Initialized
DEBUG - 2021-06-26 04:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:05:16 --> Input Class Initialized
INFO - 2021-06-26 04:05:16 --> Language Class Initialized
INFO - 2021-06-26 04:05:16 --> Language Class Initialized
INFO - 2021-06-26 04:05:16 --> Config Class Initialized
INFO - 2021-06-26 04:05:16 --> Loader Class Initialized
INFO - 2021-06-26 04:05:16 --> Helper loaded: url_helper
INFO - 2021-06-26 04:05:16 --> Helper loaded: file_helper
INFO - 2021-06-26 04:05:16 --> Helper loaded: form_helper
INFO - 2021-06-26 04:05:16 --> Helper loaded: my_helper
INFO - 2021-06-26 04:05:16 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:05:16 --> Controller Class Initialized
DEBUG - 2021-06-26 04:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:05:17 --> Final output sent to browser
DEBUG - 2021-06-26 04:05:17 --> Total execution time: 0.2710
INFO - 2021-06-26 04:06:04 --> Config Class Initialized
INFO - 2021-06-26 04:06:04 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:06:04 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:06:04 --> Utf8 Class Initialized
INFO - 2021-06-26 04:06:04 --> URI Class Initialized
INFO - 2021-06-26 04:06:04 --> Router Class Initialized
INFO - 2021-06-26 04:06:04 --> Output Class Initialized
INFO - 2021-06-26 04:06:04 --> Security Class Initialized
DEBUG - 2021-06-26 04:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:06:04 --> Input Class Initialized
INFO - 2021-06-26 04:06:04 --> Language Class Initialized
INFO - 2021-06-26 04:06:04 --> Language Class Initialized
INFO - 2021-06-26 04:06:04 --> Config Class Initialized
INFO - 2021-06-26 04:06:04 --> Loader Class Initialized
INFO - 2021-06-26 04:06:04 --> Helper loaded: url_helper
INFO - 2021-06-26 04:06:04 --> Helper loaded: file_helper
INFO - 2021-06-26 04:06:04 --> Helper loaded: form_helper
INFO - 2021-06-26 04:06:04 --> Helper loaded: my_helper
INFO - 2021-06-26 04:06:04 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:06:04 --> Controller Class Initialized
DEBUG - 2021-06-26 04:06:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:06:04 --> Final output sent to browser
DEBUG - 2021-06-26 04:06:04 --> Total execution time: 0.2728
INFO - 2021-06-26 04:14:00 --> Config Class Initialized
INFO - 2021-06-26 04:14:00 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:14:00 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:14:00 --> Utf8 Class Initialized
INFO - 2021-06-26 04:14:00 --> URI Class Initialized
INFO - 2021-06-26 04:14:00 --> Router Class Initialized
INFO - 2021-06-26 04:14:00 --> Output Class Initialized
INFO - 2021-06-26 04:14:00 --> Security Class Initialized
DEBUG - 2021-06-26 04:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:14:00 --> Input Class Initialized
INFO - 2021-06-26 04:14:00 --> Language Class Initialized
INFO - 2021-06-26 04:14:00 --> Language Class Initialized
INFO - 2021-06-26 04:14:00 --> Config Class Initialized
INFO - 2021-06-26 04:14:00 --> Loader Class Initialized
INFO - 2021-06-26 04:14:00 --> Helper loaded: url_helper
INFO - 2021-06-26 04:14:00 --> Helper loaded: file_helper
INFO - 2021-06-26 04:14:00 --> Helper loaded: form_helper
INFO - 2021-06-26 04:14:00 --> Helper loaded: my_helper
INFO - 2021-06-26 04:14:00 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:14:00 --> Controller Class Initialized
DEBUG - 2021-06-26 04:14:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-26 04:14:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:14:00 --> Final output sent to browser
DEBUG - 2021-06-26 04:14:00 --> Total execution time: 0.0427
INFO - 2021-06-26 04:14:02 --> Config Class Initialized
INFO - 2021-06-26 04:14:02 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:14:02 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:14:02 --> Utf8 Class Initialized
INFO - 2021-06-26 04:14:02 --> URI Class Initialized
INFO - 2021-06-26 04:14:02 --> Router Class Initialized
INFO - 2021-06-26 04:14:02 --> Output Class Initialized
INFO - 2021-06-26 04:14:02 --> Security Class Initialized
DEBUG - 2021-06-26 04:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:14:02 --> Input Class Initialized
INFO - 2021-06-26 04:14:02 --> Language Class Initialized
INFO - 2021-06-26 04:14:02 --> Language Class Initialized
INFO - 2021-06-26 04:14:02 --> Config Class Initialized
INFO - 2021-06-26 04:14:02 --> Loader Class Initialized
INFO - 2021-06-26 04:14:02 --> Helper loaded: url_helper
INFO - 2021-06-26 04:14:02 --> Helper loaded: file_helper
INFO - 2021-06-26 04:14:02 --> Helper loaded: form_helper
INFO - 2021-06-26 04:14:02 --> Helper loaded: my_helper
INFO - 2021-06-26 04:14:02 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:14:02 --> Controller Class Initialized
INFO - 2021-06-26 04:14:02 --> Final output sent to browser
DEBUG - 2021-06-26 04:14:02 --> Total execution time: 0.0427
INFO - 2021-06-26 04:14:48 --> Config Class Initialized
INFO - 2021-06-26 04:14:48 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:14:48 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:14:48 --> Utf8 Class Initialized
INFO - 2021-06-26 04:14:48 --> URI Class Initialized
INFO - 2021-06-26 04:14:48 --> Router Class Initialized
INFO - 2021-06-26 04:14:48 --> Output Class Initialized
INFO - 2021-06-26 04:14:48 --> Security Class Initialized
DEBUG - 2021-06-26 04:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:14:48 --> Input Class Initialized
INFO - 2021-06-26 04:14:48 --> Language Class Initialized
INFO - 2021-06-26 04:14:48 --> Language Class Initialized
INFO - 2021-06-26 04:14:48 --> Config Class Initialized
INFO - 2021-06-26 04:14:48 --> Loader Class Initialized
INFO - 2021-06-26 04:14:48 --> Helper loaded: url_helper
INFO - 2021-06-26 04:14:48 --> Helper loaded: file_helper
INFO - 2021-06-26 04:14:48 --> Helper loaded: form_helper
INFO - 2021-06-26 04:14:48 --> Helper loaded: my_helper
INFO - 2021-06-26 04:14:48 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:14:48 --> Controller Class Initialized
INFO - 2021-06-26 04:14:48 --> Final output sent to browser
DEBUG - 2021-06-26 04:14:48 --> Total execution time: 0.1043
INFO - 2021-06-26 04:14:54 --> Config Class Initialized
INFO - 2021-06-26 04:14:54 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:14:54 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:14:54 --> Utf8 Class Initialized
INFO - 2021-06-26 04:14:54 --> URI Class Initialized
INFO - 2021-06-26 04:14:54 --> Router Class Initialized
INFO - 2021-06-26 04:14:54 --> Output Class Initialized
INFO - 2021-06-26 04:14:54 --> Security Class Initialized
DEBUG - 2021-06-26 04:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:14:54 --> Input Class Initialized
INFO - 2021-06-26 04:14:54 --> Language Class Initialized
INFO - 2021-06-26 04:14:54 --> Language Class Initialized
INFO - 2021-06-26 04:14:54 --> Config Class Initialized
INFO - 2021-06-26 04:14:54 --> Loader Class Initialized
INFO - 2021-06-26 04:14:54 --> Helper loaded: url_helper
INFO - 2021-06-26 04:14:54 --> Helper loaded: file_helper
INFO - 2021-06-26 04:14:54 --> Helper loaded: form_helper
INFO - 2021-06-26 04:14:54 --> Helper loaded: my_helper
INFO - 2021-06-26 04:14:54 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:14:54 --> Controller Class Initialized
DEBUG - 2021-06-26 04:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 04:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 04:14:54 --> Final output sent to browser
DEBUG - 2021-06-26 04:14:54 --> Total execution time: 0.0584
INFO - 2021-06-26 04:15:18 --> Config Class Initialized
INFO - 2021-06-26 04:15:18 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:18 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:18 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:18 --> URI Class Initialized
INFO - 2021-06-26 04:15:18 --> Router Class Initialized
INFO - 2021-06-26 04:15:18 --> Output Class Initialized
INFO - 2021-06-26 04:15:18 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:18 --> Input Class Initialized
INFO - 2021-06-26 04:15:18 --> Language Class Initialized
INFO - 2021-06-26 04:15:18 --> Language Class Initialized
INFO - 2021-06-26 04:15:18 --> Config Class Initialized
INFO - 2021-06-26 04:15:18 --> Loader Class Initialized
INFO - 2021-06-26 04:15:18 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:18 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:18 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:18 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:18 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:18 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:19 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:19 --> Total execution time: 0.2667
INFO - 2021-06-26 04:15:20 --> Config Class Initialized
INFO - 2021-06-26 04:15:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:20 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:20 --> URI Class Initialized
INFO - 2021-06-26 04:15:20 --> Router Class Initialized
INFO - 2021-06-26 04:15:20 --> Output Class Initialized
INFO - 2021-06-26 04:15:20 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:20 --> Input Class Initialized
INFO - 2021-06-26 04:15:20 --> Language Class Initialized
INFO - 2021-06-26 04:15:20 --> Language Class Initialized
INFO - 2021-06-26 04:15:20 --> Config Class Initialized
INFO - 2021-06-26 04:15:20 --> Loader Class Initialized
INFO - 2021-06-26 04:15:20 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:20 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:20 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:20 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:20 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:20 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:20 --> Total execution time: 0.1878
INFO - 2021-06-26 04:15:22 --> Config Class Initialized
INFO - 2021-06-26 04:15:22 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:22 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:22 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:22 --> URI Class Initialized
INFO - 2021-06-26 04:15:22 --> Router Class Initialized
INFO - 2021-06-26 04:15:22 --> Output Class Initialized
INFO - 2021-06-26 04:15:22 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:22 --> Input Class Initialized
INFO - 2021-06-26 04:15:22 --> Language Class Initialized
INFO - 2021-06-26 04:15:22 --> Language Class Initialized
INFO - 2021-06-26 04:15:22 --> Config Class Initialized
INFO - 2021-06-26 04:15:22 --> Loader Class Initialized
INFO - 2021-06-26 04:15:22 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:22 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:22 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:22 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:22 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:22 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:22 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:22 --> Total execution time: 0.1948
INFO - 2021-06-26 04:15:23 --> Config Class Initialized
INFO - 2021-06-26 04:15:23 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:23 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:23 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:23 --> URI Class Initialized
INFO - 2021-06-26 04:15:23 --> Router Class Initialized
INFO - 2021-06-26 04:15:23 --> Output Class Initialized
INFO - 2021-06-26 04:15:23 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:23 --> Input Class Initialized
INFO - 2021-06-26 04:15:23 --> Language Class Initialized
INFO - 2021-06-26 04:15:23 --> Language Class Initialized
INFO - 2021-06-26 04:15:23 --> Config Class Initialized
INFO - 2021-06-26 04:15:23 --> Loader Class Initialized
INFO - 2021-06-26 04:15:23 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:23 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:23 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:23 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:23 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:23 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:24 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:24 --> Total execution time: 0.1889
INFO - 2021-06-26 04:15:26 --> Config Class Initialized
INFO - 2021-06-26 04:15:26 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:26 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:26 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:26 --> URI Class Initialized
INFO - 2021-06-26 04:15:26 --> Router Class Initialized
INFO - 2021-06-26 04:15:26 --> Output Class Initialized
INFO - 2021-06-26 04:15:26 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:26 --> Input Class Initialized
INFO - 2021-06-26 04:15:26 --> Language Class Initialized
INFO - 2021-06-26 04:15:26 --> Language Class Initialized
INFO - 2021-06-26 04:15:26 --> Config Class Initialized
INFO - 2021-06-26 04:15:26 --> Loader Class Initialized
INFO - 2021-06-26 04:15:26 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:26 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:26 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:26 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:26 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:26 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:26 --> Total execution time: 0.1885
INFO - 2021-06-26 04:15:27 --> Config Class Initialized
INFO - 2021-06-26 04:15:27 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:27 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:27 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:27 --> URI Class Initialized
INFO - 2021-06-26 04:15:27 --> Router Class Initialized
INFO - 2021-06-26 04:15:27 --> Output Class Initialized
INFO - 2021-06-26 04:15:27 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:27 --> Input Class Initialized
INFO - 2021-06-26 04:15:27 --> Language Class Initialized
INFO - 2021-06-26 04:15:27 --> Language Class Initialized
INFO - 2021-06-26 04:15:27 --> Config Class Initialized
INFO - 2021-06-26 04:15:27 --> Loader Class Initialized
INFO - 2021-06-26 04:15:27 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:27 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:27 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:27 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:27 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:27 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:27 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:27 --> Total execution time: 0.2908
INFO - 2021-06-26 04:15:28 --> Config Class Initialized
INFO - 2021-06-26 04:15:28 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:28 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:28 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:28 --> URI Class Initialized
INFO - 2021-06-26 04:15:28 --> Router Class Initialized
INFO - 2021-06-26 04:15:28 --> Output Class Initialized
INFO - 2021-06-26 04:15:28 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:28 --> Input Class Initialized
INFO - 2021-06-26 04:15:28 --> Language Class Initialized
INFO - 2021-06-26 04:15:28 --> Language Class Initialized
INFO - 2021-06-26 04:15:28 --> Config Class Initialized
INFO - 2021-06-26 04:15:28 --> Loader Class Initialized
INFO - 2021-06-26 04:15:28 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:28 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:28 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:28 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:28 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:28 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:29 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:29 --> Total execution time: 0.1916
INFO - 2021-06-26 04:15:31 --> Config Class Initialized
INFO - 2021-06-26 04:15:31 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:31 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:31 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:31 --> URI Class Initialized
INFO - 2021-06-26 04:15:31 --> Router Class Initialized
INFO - 2021-06-26 04:15:31 --> Output Class Initialized
INFO - 2021-06-26 04:15:31 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:31 --> Input Class Initialized
INFO - 2021-06-26 04:15:31 --> Language Class Initialized
INFO - 2021-06-26 04:15:31 --> Language Class Initialized
INFO - 2021-06-26 04:15:31 --> Config Class Initialized
INFO - 2021-06-26 04:15:31 --> Loader Class Initialized
INFO - 2021-06-26 04:15:31 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:31 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:31 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:31 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:31 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:31 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:31 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:31 --> Total execution time: 0.1910
INFO - 2021-06-26 04:15:32 --> Config Class Initialized
INFO - 2021-06-26 04:15:32 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:32 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:32 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:32 --> URI Class Initialized
INFO - 2021-06-26 04:15:32 --> Router Class Initialized
INFO - 2021-06-26 04:15:32 --> Output Class Initialized
INFO - 2021-06-26 04:15:32 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:32 --> Input Class Initialized
INFO - 2021-06-26 04:15:32 --> Language Class Initialized
INFO - 2021-06-26 04:15:32 --> Language Class Initialized
INFO - 2021-06-26 04:15:32 --> Config Class Initialized
INFO - 2021-06-26 04:15:32 --> Loader Class Initialized
INFO - 2021-06-26 04:15:32 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:32 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:32 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:32 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:32 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:32 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:33 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:33 --> Total execution time: 0.1872
INFO - 2021-06-26 04:15:34 --> Config Class Initialized
INFO - 2021-06-26 04:15:34 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:34 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:34 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:34 --> URI Class Initialized
INFO - 2021-06-26 04:15:34 --> Router Class Initialized
INFO - 2021-06-26 04:15:34 --> Output Class Initialized
INFO - 2021-06-26 04:15:34 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:34 --> Input Class Initialized
INFO - 2021-06-26 04:15:34 --> Language Class Initialized
INFO - 2021-06-26 04:15:34 --> Language Class Initialized
INFO - 2021-06-26 04:15:34 --> Config Class Initialized
INFO - 2021-06-26 04:15:34 --> Loader Class Initialized
INFO - 2021-06-26 04:15:34 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:34 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:34 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:34 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:34 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:34 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:35 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:35 --> Total execution time: 0.1884
INFO - 2021-06-26 04:15:36 --> Config Class Initialized
INFO - 2021-06-26 04:15:36 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:36 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:36 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:36 --> URI Class Initialized
INFO - 2021-06-26 04:15:36 --> Router Class Initialized
INFO - 2021-06-26 04:15:36 --> Output Class Initialized
INFO - 2021-06-26 04:15:36 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:36 --> Input Class Initialized
INFO - 2021-06-26 04:15:36 --> Language Class Initialized
INFO - 2021-06-26 04:15:36 --> Language Class Initialized
INFO - 2021-06-26 04:15:36 --> Config Class Initialized
INFO - 2021-06-26 04:15:36 --> Loader Class Initialized
INFO - 2021-06-26 04:15:36 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:36 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:36 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:36 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:36 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:36 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:36 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:36 --> Total execution time: 0.2145
INFO - 2021-06-26 04:15:38 --> Config Class Initialized
INFO - 2021-06-26 04:15:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:38 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:38 --> URI Class Initialized
INFO - 2021-06-26 04:15:38 --> Router Class Initialized
INFO - 2021-06-26 04:15:38 --> Output Class Initialized
INFO - 2021-06-26 04:15:38 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:38 --> Input Class Initialized
INFO - 2021-06-26 04:15:38 --> Language Class Initialized
INFO - 2021-06-26 04:15:38 --> Language Class Initialized
INFO - 2021-06-26 04:15:38 --> Config Class Initialized
INFO - 2021-06-26 04:15:38 --> Loader Class Initialized
INFO - 2021-06-26 04:15:38 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:38 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:38 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:38 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:38 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:38 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:38 --> Total execution time: 0.2720
INFO - 2021-06-26 04:15:39 --> Config Class Initialized
INFO - 2021-06-26 04:15:39 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:39 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:39 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:39 --> URI Class Initialized
INFO - 2021-06-26 04:15:39 --> Router Class Initialized
INFO - 2021-06-26 04:15:39 --> Output Class Initialized
INFO - 2021-06-26 04:15:39 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:39 --> Input Class Initialized
INFO - 2021-06-26 04:15:39 --> Language Class Initialized
INFO - 2021-06-26 04:15:39 --> Language Class Initialized
INFO - 2021-06-26 04:15:39 --> Config Class Initialized
INFO - 2021-06-26 04:15:39 --> Loader Class Initialized
INFO - 2021-06-26 04:15:39 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:39 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:39 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:39 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:39 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:39 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:39 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:39 --> Total execution time: 0.1942
INFO - 2021-06-26 04:15:41 --> Config Class Initialized
INFO - 2021-06-26 04:15:41 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:41 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:41 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:41 --> URI Class Initialized
INFO - 2021-06-26 04:15:41 --> Router Class Initialized
INFO - 2021-06-26 04:15:41 --> Output Class Initialized
INFO - 2021-06-26 04:15:41 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:41 --> Input Class Initialized
INFO - 2021-06-26 04:15:41 --> Language Class Initialized
INFO - 2021-06-26 04:15:41 --> Language Class Initialized
INFO - 2021-06-26 04:15:41 --> Config Class Initialized
INFO - 2021-06-26 04:15:41 --> Loader Class Initialized
INFO - 2021-06-26 04:15:41 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:41 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:41 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:41 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:41 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:41 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:41 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:41 --> Total execution time: 0.1901
INFO - 2021-06-26 04:15:43 --> Config Class Initialized
INFO - 2021-06-26 04:15:43 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:43 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:43 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:43 --> URI Class Initialized
INFO - 2021-06-26 04:15:43 --> Router Class Initialized
INFO - 2021-06-26 04:15:43 --> Output Class Initialized
INFO - 2021-06-26 04:15:43 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:43 --> Input Class Initialized
INFO - 2021-06-26 04:15:43 --> Language Class Initialized
INFO - 2021-06-26 04:15:43 --> Language Class Initialized
INFO - 2021-06-26 04:15:43 --> Config Class Initialized
INFO - 2021-06-26 04:15:43 --> Loader Class Initialized
INFO - 2021-06-26 04:15:43 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:43 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:43 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:43 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:43 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:43 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:43 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:43 --> Total execution time: 0.2522
INFO - 2021-06-26 04:15:44 --> Config Class Initialized
INFO - 2021-06-26 04:15:44 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:44 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:44 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:44 --> URI Class Initialized
INFO - 2021-06-26 04:15:44 --> Router Class Initialized
INFO - 2021-06-26 04:15:44 --> Output Class Initialized
INFO - 2021-06-26 04:15:44 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:44 --> Input Class Initialized
INFO - 2021-06-26 04:15:44 --> Language Class Initialized
INFO - 2021-06-26 04:15:44 --> Language Class Initialized
INFO - 2021-06-26 04:15:44 --> Config Class Initialized
INFO - 2021-06-26 04:15:44 --> Loader Class Initialized
INFO - 2021-06-26 04:15:44 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:44 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:44 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:44 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:44 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:44 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:44 --> Total execution time: 0.1865
INFO - 2021-06-26 04:15:46 --> Config Class Initialized
INFO - 2021-06-26 04:15:46 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:46 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:46 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:46 --> URI Class Initialized
INFO - 2021-06-26 04:15:46 --> Router Class Initialized
INFO - 2021-06-26 04:15:46 --> Output Class Initialized
INFO - 2021-06-26 04:15:46 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:46 --> Input Class Initialized
INFO - 2021-06-26 04:15:46 --> Language Class Initialized
INFO - 2021-06-26 04:15:46 --> Language Class Initialized
INFO - 2021-06-26 04:15:46 --> Config Class Initialized
INFO - 2021-06-26 04:15:46 --> Loader Class Initialized
INFO - 2021-06-26 04:15:46 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:46 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:46 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:46 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:46 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:46 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:46 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:46 --> Total execution time: 0.1908
INFO - 2021-06-26 04:15:48 --> Config Class Initialized
INFO - 2021-06-26 04:15:48 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:48 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:48 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:48 --> URI Class Initialized
INFO - 2021-06-26 04:15:48 --> Router Class Initialized
INFO - 2021-06-26 04:15:48 --> Output Class Initialized
INFO - 2021-06-26 04:15:48 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:48 --> Input Class Initialized
INFO - 2021-06-26 04:15:48 --> Language Class Initialized
INFO - 2021-06-26 04:15:48 --> Language Class Initialized
INFO - 2021-06-26 04:15:48 --> Config Class Initialized
INFO - 2021-06-26 04:15:48 --> Loader Class Initialized
INFO - 2021-06-26 04:15:48 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:48 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:48 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:48 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:48 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:48 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:48 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:48 --> Total execution time: 0.2767
INFO - 2021-06-26 04:15:49 --> Config Class Initialized
INFO - 2021-06-26 04:15:49 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:49 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:49 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:49 --> URI Class Initialized
INFO - 2021-06-26 04:15:49 --> Router Class Initialized
INFO - 2021-06-26 04:15:49 --> Output Class Initialized
INFO - 2021-06-26 04:15:49 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:49 --> Input Class Initialized
INFO - 2021-06-26 04:15:49 --> Language Class Initialized
INFO - 2021-06-26 04:15:49 --> Language Class Initialized
INFO - 2021-06-26 04:15:49 --> Config Class Initialized
INFO - 2021-06-26 04:15:49 --> Loader Class Initialized
INFO - 2021-06-26 04:15:49 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:49 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:49 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:49 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:49 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:49 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:49 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:49 --> Total execution time: 0.1863
INFO - 2021-06-26 04:15:51 --> Config Class Initialized
INFO - 2021-06-26 04:15:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:51 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:51 --> URI Class Initialized
INFO - 2021-06-26 04:15:51 --> Router Class Initialized
INFO - 2021-06-26 04:15:51 --> Output Class Initialized
INFO - 2021-06-26 04:15:51 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:51 --> Input Class Initialized
INFO - 2021-06-26 04:15:51 --> Language Class Initialized
INFO - 2021-06-26 04:15:51 --> Language Class Initialized
INFO - 2021-06-26 04:15:51 --> Config Class Initialized
INFO - 2021-06-26 04:15:51 --> Loader Class Initialized
INFO - 2021-06-26 04:15:51 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:51 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:51 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:51 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:51 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:51 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:51 --> Total execution time: 0.1949
INFO - 2021-06-26 04:15:52 --> Config Class Initialized
INFO - 2021-06-26 04:15:52 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:52 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:52 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:52 --> URI Class Initialized
INFO - 2021-06-26 04:15:52 --> Router Class Initialized
INFO - 2021-06-26 04:15:52 --> Output Class Initialized
INFO - 2021-06-26 04:15:52 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:52 --> Input Class Initialized
INFO - 2021-06-26 04:15:52 --> Language Class Initialized
INFO - 2021-06-26 04:15:52 --> Language Class Initialized
INFO - 2021-06-26 04:15:52 --> Config Class Initialized
INFO - 2021-06-26 04:15:52 --> Loader Class Initialized
INFO - 2021-06-26 04:15:52 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:52 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:52 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:52 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:52 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:52 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:52 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:52 --> Total execution time: 0.1906
INFO - 2021-06-26 04:15:54 --> Config Class Initialized
INFO - 2021-06-26 04:15:54 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:54 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:54 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:54 --> URI Class Initialized
INFO - 2021-06-26 04:15:54 --> Router Class Initialized
INFO - 2021-06-26 04:15:54 --> Output Class Initialized
INFO - 2021-06-26 04:15:54 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:54 --> Input Class Initialized
INFO - 2021-06-26 04:15:54 --> Language Class Initialized
INFO - 2021-06-26 04:15:54 --> Language Class Initialized
INFO - 2021-06-26 04:15:54 --> Config Class Initialized
INFO - 2021-06-26 04:15:54 --> Loader Class Initialized
INFO - 2021-06-26 04:15:54 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:54 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:54 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:54 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:54 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:54 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:54 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:54 --> Total execution time: 0.1955
INFO - 2021-06-26 04:15:55 --> Config Class Initialized
INFO - 2021-06-26 04:15:55 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:55 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:55 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:55 --> URI Class Initialized
INFO - 2021-06-26 04:15:55 --> Router Class Initialized
INFO - 2021-06-26 04:15:55 --> Output Class Initialized
INFO - 2021-06-26 04:15:55 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:55 --> Input Class Initialized
INFO - 2021-06-26 04:15:55 --> Language Class Initialized
INFO - 2021-06-26 04:15:55 --> Language Class Initialized
INFO - 2021-06-26 04:15:55 --> Config Class Initialized
INFO - 2021-06-26 04:15:55 --> Loader Class Initialized
INFO - 2021-06-26 04:15:55 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:55 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:55 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:55 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:55 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:55 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:55 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:55 --> Total execution time: 0.1974
INFO - 2021-06-26 04:15:57 --> Config Class Initialized
INFO - 2021-06-26 04:15:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:57 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:57 --> URI Class Initialized
INFO - 2021-06-26 04:15:57 --> Router Class Initialized
INFO - 2021-06-26 04:15:57 --> Output Class Initialized
INFO - 2021-06-26 04:15:57 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:57 --> Input Class Initialized
INFO - 2021-06-26 04:15:57 --> Language Class Initialized
INFO - 2021-06-26 04:15:57 --> Language Class Initialized
INFO - 2021-06-26 04:15:57 --> Config Class Initialized
INFO - 2021-06-26 04:15:57 --> Loader Class Initialized
INFO - 2021-06-26 04:15:57 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:57 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:57 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:57 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:57 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:57 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:57 --> Total execution time: 0.1864
INFO - 2021-06-26 04:15:59 --> Config Class Initialized
INFO - 2021-06-26 04:15:59 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:15:59 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:15:59 --> Utf8 Class Initialized
INFO - 2021-06-26 04:15:59 --> URI Class Initialized
INFO - 2021-06-26 04:15:59 --> Router Class Initialized
INFO - 2021-06-26 04:15:59 --> Output Class Initialized
INFO - 2021-06-26 04:15:59 --> Security Class Initialized
DEBUG - 2021-06-26 04:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:15:59 --> Input Class Initialized
INFO - 2021-06-26 04:15:59 --> Language Class Initialized
INFO - 2021-06-26 04:15:59 --> Language Class Initialized
INFO - 2021-06-26 04:15:59 --> Config Class Initialized
INFO - 2021-06-26 04:15:59 --> Loader Class Initialized
INFO - 2021-06-26 04:15:59 --> Helper loaded: url_helper
INFO - 2021-06-26 04:15:59 --> Helper loaded: file_helper
INFO - 2021-06-26 04:15:59 --> Helper loaded: form_helper
INFO - 2021-06-26 04:15:59 --> Helper loaded: my_helper
INFO - 2021-06-26 04:15:59 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:15:59 --> Controller Class Initialized
DEBUG - 2021-06-26 04:15:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:15:59 --> Final output sent to browser
DEBUG - 2021-06-26 04:15:59 --> Total execution time: 0.1893
INFO - 2021-06-26 04:16:00 --> Config Class Initialized
INFO - 2021-06-26 04:16:00 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:16:00 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:16:00 --> Utf8 Class Initialized
INFO - 2021-06-26 04:16:00 --> URI Class Initialized
INFO - 2021-06-26 04:16:00 --> Router Class Initialized
INFO - 2021-06-26 04:16:00 --> Output Class Initialized
INFO - 2021-06-26 04:16:00 --> Security Class Initialized
DEBUG - 2021-06-26 04:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:16:00 --> Input Class Initialized
INFO - 2021-06-26 04:16:00 --> Language Class Initialized
INFO - 2021-06-26 04:16:00 --> Language Class Initialized
INFO - 2021-06-26 04:16:00 --> Config Class Initialized
INFO - 2021-06-26 04:16:00 --> Loader Class Initialized
INFO - 2021-06-26 04:16:00 --> Helper loaded: url_helper
INFO - 2021-06-26 04:16:00 --> Helper loaded: file_helper
INFO - 2021-06-26 04:16:00 --> Helper loaded: form_helper
INFO - 2021-06-26 04:16:00 --> Helper loaded: my_helper
INFO - 2021-06-26 04:16:00 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:16:00 --> Controller Class Initialized
DEBUG - 2021-06-26 04:16:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:16:00 --> Final output sent to browser
DEBUG - 2021-06-26 04:16:00 --> Total execution time: 0.1859
INFO - 2021-06-26 04:16:02 --> Config Class Initialized
INFO - 2021-06-26 04:16:02 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:16:02 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:16:02 --> Utf8 Class Initialized
INFO - 2021-06-26 04:16:02 --> URI Class Initialized
INFO - 2021-06-26 04:16:02 --> Router Class Initialized
INFO - 2021-06-26 04:16:02 --> Output Class Initialized
INFO - 2021-06-26 04:16:02 --> Security Class Initialized
DEBUG - 2021-06-26 04:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:16:02 --> Input Class Initialized
INFO - 2021-06-26 04:16:02 --> Language Class Initialized
INFO - 2021-06-26 04:16:02 --> Language Class Initialized
INFO - 2021-06-26 04:16:02 --> Config Class Initialized
INFO - 2021-06-26 04:16:02 --> Loader Class Initialized
INFO - 2021-06-26 04:16:02 --> Helper loaded: url_helper
INFO - 2021-06-26 04:16:02 --> Helper loaded: file_helper
INFO - 2021-06-26 04:16:02 --> Helper loaded: form_helper
INFO - 2021-06-26 04:16:02 --> Helper loaded: my_helper
INFO - 2021-06-26 04:16:02 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:16:02 --> Controller Class Initialized
DEBUG - 2021-06-26 04:16:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:16:02 --> Final output sent to browser
DEBUG - 2021-06-26 04:16:02 --> Total execution time: 0.1911
INFO - 2021-06-26 04:16:05 --> Config Class Initialized
INFO - 2021-06-26 04:16:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 04:16:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 04:16:05 --> Utf8 Class Initialized
INFO - 2021-06-26 04:16:05 --> URI Class Initialized
INFO - 2021-06-26 04:16:05 --> Router Class Initialized
INFO - 2021-06-26 04:16:05 --> Output Class Initialized
INFO - 2021-06-26 04:16:05 --> Security Class Initialized
DEBUG - 2021-06-26 04:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 04:16:05 --> Input Class Initialized
INFO - 2021-06-26 04:16:05 --> Language Class Initialized
INFO - 2021-06-26 04:16:05 --> Language Class Initialized
INFO - 2021-06-26 04:16:05 --> Config Class Initialized
INFO - 2021-06-26 04:16:05 --> Loader Class Initialized
INFO - 2021-06-26 04:16:05 --> Helper loaded: url_helper
INFO - 2021-06-26 04:16:05 --> Helper loaded: file_helper
INFO - 2021-06-26 04:16:05 --> Helper loaded: form_helper
INFO - 2021-06-26 04:16:05 --> Helper loaded: my_helper
INFO - 2021-06-26 04:16:05 --> Database Driver Class Initialized
DEBUG - 2021-06-26 04:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 04:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 04:16:05 --> Controller Class Initialized
DEBUG - 2021-06-26 04:16:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 04:16:05 --> Final output sent to browser
DEBUG - 2021-06-26 04:16:05 --> Total execution time: 0.1836
INFO - 2021-06-26 08:19:39 --> Config Class Initialized
INFO - 2021-06-26 08:19:39 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:19:39 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:19:39 --> Utf8 Class Initialized
INFO - 2021-06-26 08:19:39 --> URI Class Initialized
DEBUG - 2021-06-26 08:19:39 --> No URI present. Default controller set.
INFO - 2021-06-26 08:19:39 --> Router Class Initialized
INFO - 2021-06-26 08:19:39 --> Output Class Initialized
INFO - 2021-06-26 08:19:39 --> Security Class Initialized
DEBUG - 2021-06-26 08:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:19:39 --> Input Class Initialized
INFO - 2021-06-26 08:19:39 --> Language Class Initialized
INFO - 2021-06-26 08:19:39 --> Language Class Initialized
INFO - 2021-06-26 08:19:39 --> Config Class Initialized
INFO - 2021-06-26 08:19:39 --> Loader Class Initialized
INFO - 2021-06-26 08:19:39 --> Helper loaded: url_helper
INFO - 2021-06-26 08:19:39 --> Helper loaded: file_helper
INFO - 2021-06-26 08:19:39 --> Helper loaded: form_helper
INFO - 2021-06-26 08:19:39 --> Helper loaded: my_helper
INFO - 2021-06-26 08:19:39 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:19:39 --> Controller Class Initialized
INFO - 2021-06-26 08:19:39 --> Config Class Initialized
INFO - 2021-06-26 08:19:39 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:19:39 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:19:39 --> Utf8 Class Initialized
INFO - 2021-06-26 08:19:39 --> URI Class Initialized
INFO - 2021-06-26 08:19:39 --> Router Class Initialized
INFO - 2021-06-26 08:19:39 --> Output Class Initialized
INFO - 2021-06-26 08:19:39 --> Security Class Initialized
DEBUG - 2021-06-26 08:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:19:39 --> Input Class Initialized
INFO - 2021-06-26 08:19:39 --> Language Class Initialized
INFO - 2021-06-26 08:19:39 --> Language Class Initialized
INFO - 2021-06-26 08:19:39 --> Config Class Initialized
INFO - 2021-06-26 08:19:39 --> Loader Class Initialized
INFO - 2021-06-26 08:19:39 --> Helper loaded: url_helper
INFO - 2021-06-26 08:19:39 --> Helper loaded: file_helper
INFO - 2021-06-26 08:19:39 --> Helper loaded: form_helper
INFO - 2021-06-26 08:19:39 --> Helper loaded: my_helper
INFO - 2021-06-26 08:19:39 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:19:39 --> Controller Class Initialized
DEBUG - 2021-06-26 08:19:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 08:19:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 08:19:39 --> Final output sent to browser
DEBUG - 2021-06-26 08:19:39 --> Total execution time: 0.0408
INFO - 2021-06-26 08:19:44 --> Config Class Initialized
INFO - 2021-06-26 08:19:44 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:19:44 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:19:44 --> Utf8 Class Initialized
INFO - 2021-06-26 08:19:44 --> URI Class Initialized
INFO - 2021-06-26 08:19:44 --> Router Class Initialized
INFO - 2021-06-26 08:19:44 --> Output Class Initialized
INFO - 2021-06-26 08:19:44 --> Security Class Initialized
DEBUG - 2021-06-26 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:19:44 --> Input Class Initialized
INFO - 2021-06-26 08:19:44 --> Language Class Initialized
INFO - 2021-06-26 08:19:44 --> Language Class Initialized
INFO - 2021-06-26 08:19:44 --> Config Class Initialized
INFO - 2021-06-26 08:19:44 --> Loader Class Initialized
INFO - 2021-06-26 08:19:44 --> Helper loaded: url_helper
INFO - 2021-06-26 08:19:44 --> Helper loaded: file_helper
INFO - 2021-06-26 08:19:44 --> Helper loaded: form_helper
INFO - 2021-06-26 08:19:44 --> Helper loaded: my_helper
INFO - 2021-06-26 08:19:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:19:44 --> Controller Class Initialized
INFO - 2021-06-26 08:19:44 --> Helper loaded: cookie_helper
INFO - 2021-06-26 08:19:44 --> Final output sent to browser
DEBUG - 2021-06-26 08:19:44 --> Total execution time: 0.0471
INFO - 2021-06-26 08:19:44 --> Config Class Initialized
INFO - 2021-06-26 08:19:44 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:19:44 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:19:44 --> Utf8 Class Initialized
INFO - 2021-06-26 08:19:44 --> URI Class Initialized
INFO - 2021-06-26 08:19:44 --> Router Class Initialized
INFO - 2021-06-26 08:19:44 --> Output Class Initialized
INFO - 2021-06-26 08:19:44 --> Security Class Initialized
DEBUG - 2021-06-26 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:19:44 --> Input Class Initialized
INFO - 2021-06-26 08:19:44 --> Language Class Initialized
INFO - 2021-06-26 08:19:44 --> Language Class Initialized
INFO - 2021-06-26 08:19:44 --> Config Class Initialized
INFO - 2021-06-26 08:19:44 --> Loader Class Initialized
INFO - 2021-06-26 08:19:44 --> Helper loaded: url_helper
INFO - 2021-06-26 08:19:44 --> Helper loaded: file_helper
INFO - 2021-06-26 08:19:44 --> Helper loaded: form_helper
INFO - 2021-06-26 08:19:44 --> Helper loaded: my_helper
INFO - 2021-06-26 08:19:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:19:44 --> Controller Class Initialized
DEBUG - 2021-06-26 08:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 08:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 08:19:45 --> Final output sent to browser
DEBUG - 2021-06-26 08:19:45 --> Total execution time: 0.6596
INFO - 2021-06-26 08:19:57 --> Config Class Initialized
INFO - 2021-06-26 08:19:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:19:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:19:57 --> Utf8 Class Initialized
INFO - 2021-06-26 08:19:57 --> URI Class Initialized
INFO - 2021-06-26 08:19:57 --> Router Class Initialized
INFO - 2021-06-26 08:19:57 --> Output Class Initialized
INFO - 2021-06-26 08:19:57 --> Security Class Initialized
DEBUG - 2021-06-26 08:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:19:57 --> Input Class Initialized
INFO - 2021-06-26 08:19:57 --> Language Class Initialized
INFO - 2021-06-26 08:19:57 --> Language Class Initialized
INFO - 2021-06-26 08:19:57 --> Config Class Initialized
INFO - 2021-06-26 08:19:57 --> Loader Class Initialized
INFO - 2021-06-26 08:19:57 --> Helper loaded: url_helper
INFO - 2021-06-26 08:19:57 --> Helper loaded: file_helper
INFO - 2021-06-26 08:19:57 --> Helper loaded: form_helper
INFO - 2021-06-26 08:19:57 --> Helper loaded: my_helper
INFO - 2021-06-26 08:19:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:19:57 --> Controller Class Initialized
DEBUG - 2021-06-26 08:19:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 08:19:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 08:19:57 --> Final output sent to browser
DEBUG - 2021-06-26 08:19:57 --> Total execution time: 0.0620
INFO - 2021-06-26 08:19:58 --> Config Class Initialized
INFO - 2021-06-26 08:19:58 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:19:58 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:19:58 --> Utf8 Class Initialized
INFO - 2021-06-26 08:19:58 --> URI Class Initialized
INFO - 2021-06-26 08:19:58 --> Router Class Initialized
INFO - 2021-06-26 08:19:58 --> Output Class Initialized
INFO - 2021-06-26 08:19:58 --> Security Class Initialized
DEBUG - 2021-06-26 08:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:19:58 --> Input Class Initialized
INFO - 2021-06-26 08:19:58 --> Language Class Initialized
INFO - 2021-06-26 08:19:58 --> Language Class Initialized
INFO - 2021-06-26 08:19:58 --> Config Class Initialized
INFO - 2021-06-26 08:19:58 --> Loader Class Initialized
INFO - 2021-06-26 08:19:58 --> Helper loaded: url_helper
INFO - 2021-06-26 08:19:58 --> Helper loaded: file_helper
INFO - 2021-06-26 08:19:58 --> Helper loaded: form_helper
INFO - 2021-06-26 08:19:58 --> Helper loaded: my_helper
INFO - 2021-06-26 08:19:58 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:19:58 --> Controller Class Initialized
DEBUG - 2021-06-26 08:19:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:19:58 --> Final output sent to browser
DEBUG - 2021-06-26 08:19:58 --> Total execution time: 0.0458
INFO - 2021-06-26 08:22:51 --> Config Class Initialized
INFO - 2021-06-26 08:22:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:22:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:22:51 --> Utf8 Class Initialized
INFO - 2021-06-26 08:22:51 --> URI Class Initialized
INFO - 2021-06-26 08:22:51 --> Router Class Initialized
INFO - 2021-06-26 08:22:51 --> Output Class Initialized
INFO - 2021-06-26 08:22:51 --> Security Class Initialized
DEBUG - 2021-06-26 08:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:22:51 --> Input Class Initialized
INFO - 2021-06-26 08:22:51 --> Language Class Initialized
INFO - 2021-06-26 08:22:51 --> Language Class Initialized
INFO - 2021-06-26 08:22:51 --> Config Class Initialized
INFO - 2021-06-26 08:22:51 --> Loader Class Initialized
INFO - 2021-06-26 08:22:51 --> Helper loaded: url_helper
INFO - 2021-06-26 08:22:51 --> Helper loaded: file_helper
INFO - 2021-06-26 08:22:51 --> Helper loaded: form_helper
INFO - 2021-06-26 08:22:51 --> Helper loaded: my_helper
INFO - 2021-06-26 08:22:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:22:51 --> Controller Class Initialized
DEBUG - 2021-06-26 08:22:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:22:51 --> Final output sent to browser
DEBUG - 2021-06-26 08:22:51 --> Total execution time: 0.0546
INFO - 2021-06-26 08:31:23 --> Config Class Initialized
INFO - 2021-06-26 08:31:23 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:31:23 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:31:23 --> Utf8 Class Initialized
INFO - 2021-06-26 08:31:23 --> URI Class Initialized
INFO - 2021-06-26 08:31:23 --> Router Class Initialized
INFO - 2021-06-26 08:31:23 --> Output Class Initialized
INFO - 2021-06-26 08:31:23 --> Security Class Initialized
DEBUG - 2021-06-26 08:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:31:23 --> Input Class Initialized
INFO - 2021-06-26 08:31:23 --> Language Class Initialized
INFO - 2021-06-26 08:31:23 --> Language Class Initialized
INFO - 2021-06-26 08:31:23 --> Config Class Initialized
INFO - 2021-06-26 08:31:23 --> Loader Class Initialized
INFO - 2021-06-26 08:31:23 --> Helper loaded: url_helper
INFO - 2021-06-26 08:31:23 --> Helper loaded: file_helper
INFO - 2021-06-26 08:31:23 --> Helper loaded: form_helper
INFO - 2021-06-26 08:31:23 --> Helper loaded: my_helper
INFO - 2021-06-26 08:31:23 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:31:23 --> Controller Class Initialized
DEBUG - 2021-06-26 08:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:31:23 --> Final output sent to browser
DEBUG - 2021-06-26 08:31:23 --> Total execution time: 0.0461
INFO - 2021-06-26 08:31:39 --> Config Class Initialized
INFO - 2021-06-26 08:31:39 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:31:39 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:31:39 --> Utf8 Class Initialized
INFO - 2021-06-26 08:31:39 --> URI Class Initialized
INFO - 2021-06-26 08:31:39 --> Router Class Initialized
INFO - 2021-06-26 08:31:39 --> Output Class Initialized
INFO - 2021-06-26 08:31:39 --> Security Class Initialized
DEBUG - 2021-06-26 08:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:31:39 --> Input Class Initialized
INFO - 2021-06-26 08:31:39 --> Language Class Initialized
INFO - 2021-06-26 08:31:39 --> Language Class Initialized
INFO - 2021-06-26 08:31:39 --> Config Class Initialized
INFO - 2021-06-26 08:31:39 --> Loader Class Initialized
INFO - 2021-06-26 08:31:39 --> Helper loaded: url_helper
INFO - 2021-06-26 08:31:39 --> Helper loaded: file_helper
INFO - 2021-06-26 08:31:39 --> Helper loaded: form_helper
INFO - 2021-06-26 08:31:39 --> Helper loaded: my_helper
INFO - 2021-06-26 08:31:39 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:31:39 --> Controller Class Initialized
DEBUG - 2021-06-26 08:31:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:31:39 --> Final output sent to browser
DEBUG - 2021-06-26 08:31:39 --> Total execution time: 0.0549
INFO - 2021-06-26 08:32:10 --> Config Class Initialized
INFO - 2021-06-26 08:32:10 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:32:10 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:32:10 --> Utf8 Class Initialized
INFO - 2021-06-26 08:32:10 --> URI Class Initialized
INFO - 2021-06-26 08:32:10 --> Router Class Initialized
INFO - 2021-06-26 08:32:10 --> Output Class Initialized
INFO - 2021-06-26 08:32:10 --> Security Class Initialized
DEBUG - 2021-06-26 08:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:32:10 --> Input Class Initialized
INFO - 2021-06-26 08:32:10 --> Language Class Initialized
INFO - 2021-06-26 08:32:10 --> Language Class Initialized
INFO - 2021-06-26 08:32:10 --> Config Class Initialized
INFO - 2021-06-26 08:32:10 --> Loader Class Initialized
INFO - 2021-06-26 08:32:10 --> Helper loaded: url_helper
INFO - 2021-06-26 08:32:10 --> Helper loaded: file_helper
INFO - 2021-06-26 08:32:10 --> Helper loaded: form_helper
INFO - 2021-06-26 08:32:10 --> Helper loaded: my_helper
INFO - 2021-06-26 08:32:10 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:32:10 --> Controller Class Initialized
DEBUG - 2021-06-26 08:32:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:32:10 --> Final output sent to browser
DEBUG - 2021-06-26 08:32:10 --> Total execution time: 0.0461
INFO - 2021-06-26 08:34:06 --> Config Class Initialized
INFO - 2021-06-26 08:34:06 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:34:06 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:34:06 --> Utf8 Class Initialized
INFO - 2021-06-26 08:34:06 --> URI Class Initialized
INFO - 2021-06-26 08:34:06 --> Router Class Initialized
INFO - 2021-06-26 08:34:06 --> Output Class Initialized
INFO - 2021-06-26 08:34:06 --> Security Class Initialized
DEBUG - 2021-06-26 08:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:34:06 --> Input Class Initialized
INFO - 2021-06-26 08:34:06 --> Language Class Initialized
INFO - 2021-06-26 08:34:06 --> Language Class Initialized
INFO - 2021-06-26 08:34:06 --> Config Class Initialized
INFO - 2021-06-26 08:34:06 --> Loader Class Initialized
INFO - 2021-06-26 08:34:06 --> Helper loaded: url_helper
INFO - 2021-06-26 08:34:06 --> Helper loaded: file_helper
INFO - 2021-06-26 08:34:06 --> Helper loaded: form_helper
INFO - 2021-06-26 08:34:06 --> Helper loaded: my_helper
INFO - 2021-06-26 08:34:06 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:34:06 --> Controller Class Initialized
DEBUG - 2021-06-26 08:34:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:34:06 --> Final output sent to browser
DEBUG - 2021-06-26 08:34:06 --> Total execution time: 0.0545
INFO - 2021-06-26 08:34:20 --> Config Class Initialized
INFO - 2021-06-26 08:34:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:34:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:34:20 --> Utf8 Class Initialized
INFO - 2021-06-26 08:34:20 --> URI Class Initialized
INFO - 2021-06-26 08:34:20 --> Router Class Initialized
INFO - 2021-06-26 08:34:20 --> Output Class Initialized
INFO - 2021-06-26 08:34:20 --> Security Class Initialized
DEBUG - 2021-06-26 08:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:34:20 --> Input Class Initialized
INFO - 2021-06-26 08:34:20 --> Language Class Initialized
INFO - 2021-06-26 08:34:20 --> Language Class Initialized
INFO - 2021-06-26 08:34:20 --> Config Class Initialized
INFO - 2021-06-26 08:34:20 --> Loader Class Initialized
INFO - 2021-06-26 08:34:20 --> Helper loaded: url_helper
INFO - 2021-06-26 08:34:20 --> Helper loaded: file_helper
INFO - 2021-06-26 08:34:20 --> Helper loaded: form_helper
INFO - 2021-06-26 08:34:20 --> Helper loaded: my_helper
INFO - 2021-06-26 08:34:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:34:20 --> Controller Class Initialized
DEBUG - 2021-06-26 08:34:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:34:20 --> Final output sent to browser
DEBUG - 2021-06-26 08:34:20 --> Total execution time: 0.0542
INFO - 2021-06-26 08:34:30 --> Config Class Initialized
INFO - 2021-06-26 08:34:30 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:34:30 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:34:30 --> Utf8 Class Initialized
INFO - 2021-06-26 08:34:30 --> URI Class Initialized
INFO - 2021-06-26 08:34:30 --> Router Class Initialized
INFO - 2021-06-26 08:34:30 --> Output Class Initialized
INFO - 2021-06-26 08:34:30 --> Security Class Initialized
DEBUG - 2021-06-26 08:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:34:30 --> Input Class Initialized
INFO - 2021-06-26 08:34:30 --> Language Class Initialized
INFO - 2021-06-26 08:34:30 --> Language Class Initialized
INFO - 2021-06-26 08:34:30 --> Config Class Initialized
INFO - 2021-06-26 08:34:30 --> Loader Class Initialized
INFO - 2021-06-26 08:34:30 --> Helper loaded: url_helper
INFO - 2021-06-26 08:34:30 --> Helper loaded: file_helper
INFO - 2021-06-26 08:34:30 --> Helper loaded: form_helper
INFO - 2021-06-26 08:34:30 --> Helper loaded: my_helper
INFO - 2021-06-26 08:34:30 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:34:30 --> Controller Class Initialized
DEBUG - 2021-06-26 08:34:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:34:30 --> Final output sent to browser
DEBUG - 2021-06-26 08:34:30 --> Total execution time: 0.0540
INFO - 2021-06-26 08:34:50 --> Config Class Initialized
INFO - 2021-06-26 08:34:50 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:34:50 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:34:50 --> Utf8 Class Initialized
INFO - 2021-06-26 08:34:50 --> URI Class Initialized
INFO - 2021-06-26 08:34:50 --> Router Class Initialized
INFO - 2021-06-26 08:34:50 --> Output Class Initialized
INFO - 2021-06-26 08:34:50 --> Security Class Initialized
DEBUG - 2021-06-26 08:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:34:50 --> Input Class Initialized
INFO - 2021-06-26 08:34:50 --> Language Class Initialized
INFO - 2021-06-26 08:34:50 --> Language Class Initialized
INFO - 2021-06-26 08:34:50 --> Config Class Initialized
INFO - 2021-06-26 08:34:50 --> Loader Class Initialized
INFO - 2021-06-26 08:34:50 --> Helper loaded: url_helper
INFO - 2021-06-26 08:34:50 --> Helper loaded: file_helper
INFO - 2021-06-26 08:34:50 --> Helper loaded: form_helper
INFO - 2021-06-26 08:34:50 --> Helper loaded: my_helper
INFO - 2021-06-26 08:34:50 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:34:50 --> Controller Class Initialized
DEBUG - 2021-06-26 08:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:34:50 --> Final output sent to browser
DEBUG - 2021-06-26 08:34:50 --> Total execution time: 0.0554
INFO - 2021-06-26 08:35:06 --> Config Class Initialized
INFO - 2021-06-26 08:35:06 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:35:06 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:35:06 --> Utf8 Class Initialized
INFO - 2021-06-26 08:35:06 --> URI Class Initialized
INFO - 2021-06-26 08:35:06 --> Router Class Initialized
INFO - 2021-06-26 08:35:06 --> Output Class Initialized
INFO - 2021-06-26 08:35:06 --> Security Class Initialized
DEBUG - 2021-06-26 08:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:35:06 --> Input Class Initialized
INFO - 2021-06-26 08:35:06 --> Language Class Initialized
INFO - 2021-06-26 08:35:06 --> Language Class Initialized
INFO - 2021-06-26 08:35:06 --> Config Class Initialized
INFO - 2021-06-26 08:35:06 --> Loader Class Initialized
INFO - 2021-06-26 08:35:06 --> Helper loaded: url_helper
INFO - 2021-06-26 08:35:06 --> Helper loaded: file_helper
INFO - 2021-06-26 08:35:06 --> Helper loaded: form_helper
INFO - 2021-06-26 08:35:06 --> Helper loaded: my_helper
INFO - 2021-06-26 08:35:06 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:35:06 --> Controller Class Initialized
DEBUG - 2021-06-26 08:35:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:35:06 --> Final output sent to browser
DEBUG - 2021-06-26 08:35:06 --> Total execution time: 0.0450
INFO - 2021-06-26 08:35:13 --> Config Class Initialized
INFO - 2021-06-26 08:35:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:35:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:35:13 --> Utf8 Class Initialized
INFO - 2021-06-26 08:35:13 --> URI Class Initialized
INFO - 2021-06-26 08:35:13 --> Router Class Initialized
INFO - 2021-06-26 08:35:13 --> Output Class Initialized
INFO - 2021-06-26 08:35:13 --> Security Class Initialized
DEBUG - 2021-06-26 08:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:35:13 --> Input Class Initialized
INFO - 2021-06-26 08:35:13 --> Language Class Initialized
INFO - 2021-06-26 08:35:13 --> Language Class Initialized
INFO - 2021-06-26 08:35:13 --> Config Class Initialized
INFO - 2021-06-26 08:35:13 --> Loader Class Initialized
INFO - 2021-06-26 08:35:13 --> Helper loaded: url_helper
INFO - 2021-06-26 08:35:13 --> Helper loaded: file_helper
INFO - 2021-06-26 08:35:13 --> Helper loaded: form_helper
INFO - 2021-06-26 08:35:13 --> Helper loaded: my_helper
INFO - 2021-06-26 08:35:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:35:13 --> Controller Class Initialized
DEBUG - 2021-06-26 08:35:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:35:13 --> Final output sent to browser
DEBUG - 2021-06-26 08:35:13 --> Total execution time: 0.0553
INFO - 2021-06-26 08:35:38 --> Config Class Initialized
INFO - 2021-06-26 08:35:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:35:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:35:38 --> Utf8 Class Initialized
INFO - 2021-06-26 08:35:38 --> URI Class Initialized
INFO - 2021-06-26 08:35:38 --> Router Class Initialized
INFO - 2021-06-26 08:35:38 --> Output Class Initialized
INFO - 2021-06-26 08:35:38 --> Security Class Initialized
DEBUG - 2021-06-26 08:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:35:38 --> Input Class Initialized
INFO - 2021-06-26 08:35:38 --> Language Class Initialized
INFO - 2021-06-26 08:35:38 --> Language Class Initialized
INFO - 2021-06-26 08:35:38 --> Config Class Initialized
INFO - 2021-06-26 08:35:38 --> Loader Class Initialized
INFO - 2021-06-26 08:35:38 --> Helper loaded: url_helper
INFO - 2021-06-26 08:35:38 --> Helper loaded: file_helper
INFO - 2021-06-26 08:35:38 --> Helper loaded: form_helper
INFO - 2021-06-26 08:35:38 --> Helper loaded: my_helper
INFO - 2021-06-26 08:35:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:35:38 --> Controller Class Initialized
DEBUG - 2021-06-26 08:35:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:35:38 --> Final output sent to browser
DEBUG - 2021-06-26 08:35:38 --> Total execution time: 0.0563
INFO - 2021-06-26 08:36:29 --> Config Class Initialized
INFO - 2021-06-26 08:36:29 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:36:29 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:36:29 --> Utf8 Class Initialized
INFO - 2021-06-26 08:36:29 --> URI Class Initialized
INFO - 2021-06-26 08:36:29 --> Router Class Initialized
INFO - 2021-06-26 08:36:29 --> Output Class Initialized
INFO - 2021-06-26 08:36:29 --> Security Class Initialized
DEBUG - 2021-06-26 08:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:36:29 --> Input Class Initialized
INFO - 2021-06-26 08:36:29 --> Language Class Initialized
INFO - 2021-06-26 08:36:29 --> Language Class Initialized
INFO - 2021-06-26 08:36:29 --> Config Class Initialized
INFO - 2021-06-26 08:36:29 --> Loader Class Initialized
INFO - 2021-06-26 08:36:29 --> Helper loaded: url_helper
INFO - 2021-06-26 08:36:29 --> Helper loaded: file_helper
INFO - 2021-06-26 08:36:29 --> Helper loaded: form_helper
INFO - 2021-06-26 08:36:29 --> Helper loaded: my_helper
INFO - 2021-06-26 08:36:29 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:36:29 --> Controller Class Initialized
DEBUG - 2021-06-26 08:36:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:36:29 --> Final output sent to browser
DEBUG - 2021-06-26 08:36:29 --> Total execution time: 0.0545
INFO - 2021-06-26 08:36:59 --> Config Class Initialized
INFO - 2021-06-26 08:36:59 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:36:59 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:36:59 --> Utf8 Class Initialized
INFO - 2021-06-26 08:36:59 --> URI Class Initialized
INFO - 2021-06-26 08:36:59 --> Router Class Initialized
INFO - 2021-06-26 08:36:59 --> Output Class Initialized
INFO - 2021-06-26 08:36:59 --> Security Class Initialized
DEBUG - 2021-06-26 08:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:36:59 --> Input Class Initialized
INFO - 2021-06-26 08:36:59 --> Language Class Initialized
INFO - 2021-06-26 08:36:59 --> Language Class Initialized
INFO - 2021-06-26 08:36:59 --> Config Class Initialized
INFO - 2021-06-26 08:36:59 --> Loader Class Initialized
INFO - 2021-06-26 08:36:59 --> Helper loaded: url_helper
INFO - 2021-06-26 08:36:59 --> Helper loaded: file_helper
INFO - 2021-06-26 08:36:59 --> Helper loaded: form_helper
INFO - 2021-06-26 08:36:59 --> Helper loaded: my_helper
INFO - 2021-06-26 08:36:59 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:36:59 --> Controller Class Initialized
DEBUG - 2021-06-26 08:36:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:36:59 --> Final output sent to browser
DEBUG - 2021-06-26 08:36:59 --> Total execution time: 0.0458
INFO - 2021-06-26 08:37:17 --> Config Class Initialized
INFO - 2021-06-26 08:37:17 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:37:17 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:37:17 --> Utf8 Class Initialized
INFO - 2021-06-26 08:37:17 --> URI Class Initialized
INFO - 2021-06-26 08:37:17 --> Router Class Initialized
INFO - 2021-06-26 08:37:17 --> Output Class Initialized
INFO - 2021-06-26 08:37:17 --> Security Class Initialized
DEBUG - 2021-06-26 08:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:37:17 --> Input Class Initialized
INFO - 2021-06-26 08:37:17 --> Language Class Initialized
INFO - 2021-06-26 08:37:17 --> Language Class Initialized
INFO - 2021-06-26 08:37:17 --> Config Class Initialized
INFO - 2021-06-26 08:37:17 --> Loader Class Initialized
INFO - 2021-06-26 08:37:17 --> Helper loaded: url_helper
INFO - 2021-06-26 08:37:17 --> Helper loaded: file_helper
INFO - 2021-06-26 08:37:17 --> Helper loaded: form_helper
INFO - 2021-06-26 08:37:17 --> Helper loaded: my_helper
INFO - 2021-06-26 08:37:17 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:37:17 --> Controller Class Initialized
DEBUG - 2021-06-26 08:37:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:37:17 --> Final output sent to browser
DEBUG - 2021-06-26 08:37:17 --> Total execution time: 0.0551
INFO - 2021-06-26 08:37:36 --> Config Class Initialized
INFO - 2021-06-26 08:37:36 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:37:36 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:37:36 --> Utf8 Class Initialized
INFO - 2021-06-26 08:37:36 --> URI Class Initialized
INFO - 2021-06-26 08:37:36 --> Router Class Initialized
INFO - 2021-06-26 08:37:36 --> Output Class Initialized
INFO - 2021-06-26 08:37:36 --> Security Class Initialized
DEBUG - 2021-06-26 08:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:37:36 --> Input Class Initialized
INFO - 2021-06-26 08:37:36 --> Language Class Initialized
INFO - 2021-06-26 08:37:36 --> Language Class Initialized
INFO - 2021-06-26 08:37:36 --> Config Class Initialized
INFO - 2021-06-26 08:37:36 --> Loader Class Initialized
INFO - 2021-06-26 08:37:36 --> Helper loaded: url_helper
INFO - 2021-06-26 08:37:36 --> Helper loaded: file_helper
INFO - 2021-06-26 08:37:36 --> Helper loaded: form_helper
INFO - 2021-06-26 08:37:36 --> Helper loaded: my_helper
INFO - 2021-06-26 08:37:36 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:37:36 --> Controller Class Initialized
DEBUG - 2021-06-26 08:37:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:37:36 --> Final output sent to browser
DEBUG - 2021-06-26 08:37:36 --> Total execution time: 0.0542
INFO - 2021-06-26 08:38:03 --> Config Class Initialized
INFO - 2021-06-26 08:38:03 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:38:03 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:38:03 --> Utf8 Class Initialized
INFO - 2021-06-26 08:38:03 --> URI Class Initialized
INFO - 2021-06-26 08:38:03 --> Router Class Initialized
INFO - 2021-06-26 08:38:03 --> Output Class Initialized
INFO - 2021-06-26 08:38:03 --> Security Class Initialized
DEBUG - 2021-06-26 08:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:38:03 --> Input Class Initialized
INFO - 2021-06-26 08:38:03 --> Language Class Initialized
INFO - 2021-06-26 08:38:03 --> Language Class Initialized
INFO - 2021-06-26 08:38:03 --> Config Class Initialized
INFO - 2021-06-26 08:38:03 --> Loader Class Initialized
INFO - 2021-06-26 08:38:03 --> Helper loaded: url_helper
INFO - 2021-06-26 08:38:03 --> Helper loaded: file_helper
INFO - 2021-06-26 08:38:03 --> Helper loaded: form_helper
INFO - 2021-06-26 08:38:03 --> Helper loaded: my_helper
INFO - 2021-06-26 08:38:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:38:03 --> Controller Class Initialized
DEBUG - 2021-06-26 08:38:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:38:03 --> Final output sent to browser
DEBUG - 2021-06-26 08:38:03 --> Total execution time: 0.0479
INFO - 2021-06-26 08:38:04 --> Config Class Initialized
INFO - 2021-06-26 08:38:04 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:38:04 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:38:04 --> Utf8 Class Initialized
INFO - 2021-06-26 08:38:04 --> URI Class Initialized
INFO - 2021-06-26 08:38:04 --> Router Class Initialized
INFO - 2021-06-26 08:38:04 --> Output Class Initialized
INFO - 2021-06-26 08:38:04 --> Security Class Initialized
DEBUG - 2021-06-26 08:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:38:04 --> Input Class Initialized
INFO - 2021-06-26 08:38:04 --> Language Class Initialized
INFO - 2021-06-26 08:38:04 --> Language Class Initialized
INFO - 2021-06-26 08:38:04 --> Config Class Initialized
INFO - 2021-06-26 08:38:04 --> Loader Class Initialized
INFO - 2021-06-26 08:38:04 --> Helper loaded: url_helper
INFO - 2021-06-26 08:38:04 --> Helper loaded: file_helper
INFO - 2021-06-26 08:38:04 --> Helper loaded: form_helper
INFO - 2021-06-26 08:38:04 --> Helper loaded: my_helper
INFO - 2021-06-26 08:38:04 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:38:04 --> Controller Class Initialized
DEBUG - 2021-06-26 08:38:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:38:04 --> Final output sent to browser
DEBUG - 2021-06-26 08:38:04 --> Total execution time: 0.0536
INFO - 2021-06-26 08:38:13 --> Config Class Initialized
INFO - 2021-06-26 08:38:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:38:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:38:13 --> Utf8 Class Initialized
INFO - 2021-06-26 08:38:13 --> URI Class Initialized
INFO - 2021-06-26 08:38:13 --> Router Class Initialized
INFO - 2021-06-26 08:38:13 --> Output Class Initialized
INFO - 2021-06-26 08:38:13 --> Security Class Initialized
DEBUG - 2021-06-26 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:38:13 --> Input Class Initialized
INFO - 2021-06-26 08:38:13 --> Language Class Initialized
INFO - 2021-06-26 08:38:13 --> Language Class Initialized
INFO - 2021-06-26 08:38:13 --> Config Class Initialized
INFO - 2021-06-26 08:38:13 --> Loader Class Initialized
INFO - 2021-06-26 08:38:13 --> Helper loaded: url_helper
INFO - 2021-06-26 08:38:13 --> Helper loaded: file_helper
INFO - 2021-06-26 08:38:13 --> Helper loaded: form_helper
INFO - 2021-06-26 08:38:13 --> Helper loaded: my_helper
INFO - 2021-06-26 08:38:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:38:13 --> Controller Class Initialized
DEBUG - 2021-06-26 08:38:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:38:13 --> Final output sent to browser
DEBUG - 2021-06-26 08:38:13 --> Total execution time: 0.0461
INFO - 2021-06-26 08:38:31 --> Config Class Initialized
INFO - 2021-06-26 08:38:31 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:38:31 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:38:31 --> Utf8 Class Initialized
INFO - 2021-06-26 08:38:31 --> URI Class Initialized
INFO - 2021-06-26 08:38:31 --> Router Class Initialized
INFO - 2021-06-26 08:38:31 --> Output Class Initialized
INFO - 2021-06-26 08:38:31 --> Security Class Initialized
DEBUG - 2021-06-26 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:38:31 --> Input Class Initialized
INFO - 2021-06-26 08:38:31 --> Language Class Initialized
INFO - 2021-06-26 08:38:31 --> Language Class Initialized
INFO - 2021-06-26 08:38:31 --> Config Class Initialized
INFO - 2021-06-26 08:38:31 --> Loader Class Initialized
INFO - 2021-06-26 08:38:31 --> Helper loaded: url_helper
INFO - 2021-06-26 08:38:31 --> Helper loaded: file_helper
INFO - 2021-06-26 08:38:31 --> Helper loaded: form_helper
INFO - 2021-06-26 08:38:31 --> Helper loaded: my_helper
INFO - 2021-06-26 08:38:31 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:38:31 --> Controller Class Initialized
DEBUG - 2021-06-26 08:38:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:38:31 --> Final output sent to browser
DEBUG - 2021-06-26 08:38:31 --> Total execution time: 0.0451
INFO - 2021-06-26 08:38:40 --> Config Class Initialized
INFO - 2021-06-26 08:38:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:38:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:38:40 --> Utf8 Class Initialized
INFO - 2021-06-26 08:38:40 --> URI Class Initialized
INFO - 2021-06-26 08:38:40 --> Router Class Initialized
INFO - 2021-06-26 08:38:40 --> Output Class Initialized
INFO - 2021-06-26 08:38:40 --> Security Class Initialized
DEBUG - 2021-06-26 08:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:38:40 --> Input Class Initialized
INFO - 2021-06-26 08:38:40 --> Language Class Initialized
INFO - 2021-06-26 08:38:40 --> Language Class Initialized
INFO - 2021-06-26 08:38:40 --> Config Class Initialized
INFO - 2021-06-26 08:38:40 --> Loader Class Initialized
INFO - 2021-06-26 08:38:40 --> Helper loaded: url_helper
INFO - 2021-06-26 08:38:40 --> Helper loaded: file_helper
INFO - 2021-06-26 08:38:40 --> Helper loaded: form_helper
INFO - 2021-06-26 08:38:40 --> Helper loaded: my_helper
INFO - 2021-06-26 08:38:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:38:40 --> Controller Class Initialized
DEBUG - 2021-06-26 08:38:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:38:40 --> Final output sent to browser
DEBUG - 2021-06-26 08:38:40 --> Total execution time: 0.0543
INFO - 2021-06-26 08:39:07 --> Config Class Initialized
INFO - 2021-06-26 08:39:07 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:39:07 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:39:07 --> Utf8 Class Initialized
INFO - 2021-06-26 08:39:07 --> URI Class Initialized
INFO - 2021-06-26 08:39:07 --> Router Class Initialized
INFO - 2021-06-26 08:39:07 --> Output Class Initialized
INFO - 2021-06-26 08:39:07 --> Security Class Initialized
DEBUG - 2021-06-26 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:39:07 --> Input Class Initialized
INFO - 2021-06-26 08:39:07 --> Language Class Initialized
INFO - 2021-06-26 08:39:07 --> Language Class Initialized
INFO - 2021-06-26 08:39:07 --> Config Class Initialized
INFO - 2021-06-26 08:39:07 --> Loader Class Initialized
INFO - 2021-06-26 08:39:07 --> Helper loaded: url_helper
INFO - 2021-06-26 08:39:07 --> Helper loaded: file_helper
INFO - 2021-06-26 08:39:07 --> Helper loaded: form_helper
INFO - 2021-06-26 08:39:07 --> Helper loaded: my_helper
INFO - 2021-06-26 08:39:07 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:39:07 --> Controller Class Initialized
DEBUG - 2021-06-26 08:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:39:07 --> Final output sent to browser
DEBUG - 2021-06-26 08:39:07 --> Total execution time: 0.0449
INFO - 2021-06-26 08:39:17 --> Config Class Initialized
INFO - 2021-06-26 08:39:17 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:39:17 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:39:17 --> Utf8 Class Initialized
INFO - 2021-06-26 08:39:17 --> URI Class Initialized
INFO - 2021-06-26 08:39:17 --> Router Class Initialized
INFO - 2021-06-26 08:39:17 --> Output Class Initialized
INFO - 2021-06-26 08:39:17 --> Security Class Initialized
DEBUG - 2021-06-26 08:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:39:17 --> Input Class Initialized
INFO - 2021-06-26 08:39:17 --> Language Class Initialized
INFO - 2021-06-26 08:39:17 --> Language Class Initialized
INFO - 2021-06-26 08:39:17 --> Config Class Initialized
INFO - 2021-06-26 08:39:17 --> Loader Class Initialized
INFO - 2021-06-26 08:39:17 --> Helper loaded: url_helper
INFO - 2021-06-26 08:39:17 --> Helper loaded: file_helper
INFO - 2021-06-26 08:39:17 --> Helper loaded: form_helper
INFO - 2021-06-26 08:39:17 --> Helper loaded: my_helper
INFO - 2021-06-26 08:39:17 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:39:17 --> Controller Class Initialized
DEBUG - 2021-06-26 08:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:39:17 --> Final output sent to browser
DEBUG - 2021-06-26 08:39:17 --> Total execution time: 0.0546
INFO - 2021-06-26 08:39:58 --> Config Class Initialized
INFO - 2021-06-26 08:39:58 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:39:58 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:39:58 --> Utf8 Class Initialized
INFO - 2021-06-26 08:39:58 --> URI Class Initialized
INFO - 2021-06-26 08:39:58 --> Router Class Initialized
INFO - 2021-06-26 08:39:58 --> Output Class Initialized
INFO - 2021-06-26 08:39:58 --> Security Class Initialized
DEBUG - 2021-06-26 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:39:58 --> Input Class Initialized
INFO - 2021-06-26 08:39:58 --> Language Class Initialized
INFO - 2021-06-26 08:39:58 --> Language Class Initialized
INFO - 2021-06-26 08:39:58 --> Config Class Initialized
INFO - 2021-06-26 08:39:58 --> Loader Class Initialized
INFO - 2021-06-26 08:39:58 --> Helper loaded: url_helper
INFO - 2021-06-26 08:39:58 --> Helper loaded: file_helper
INFO - 2021-06-26 08:39:58 --> Helper loaded: form_helper
INFO - 2021-06-26 08:39:58 --> Helper loaded: my_helper
INFO - 2021-06-26 08:39:58 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:39:58 --> Controller Class Initialized
DEBUG - 2021-06-26 08:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:39:58 --> Final output sent to browser
DEBUG - 2021-06-26 08:39:58 --> Total execution time: 0.0559
INFO - 2021-06-26 08:40:05 --> Config Class Initialized
INFO - 2021-06-26 08:40:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:40:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:40:05 --> Utf8 Class Initialized
INFO - 2021-06-26 08:40:05 --> URI Class Initialized
INFO - 2021-06-26 08:40:05 --> Router Class Initialized
INFO - 2021-06-26 08:40:05 --> Output Class Initialized
INFO - 2021-06-26 08:40:05 --> Security Class Initialized
DEBUG - 2021-06-26 08:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:40:05 --> Input Class Initialized
INFO - 2021-06-26 08:40:05 --> Language Class Initialized
INFO - 2021-06-26 08:40:06 --> Language Class Initialized
INFO - 2021-06-26 08:40:06 --> Config Class Initialized
INFO - 2021-06-26 08:40:06 --> Loader Class Initialized
INFO - 2021-06-26 08:40:06 --> Helper loaded: url_helper
INFO - 2021-06-26 08:40:06 --> Helper loaded: file_helper
INFO - 2021-06-26 08:40:06 --> Helper loaded: form_helper
INFO - 2021-06-26 08:40:06 --> Helper loaded: my_helper
INFO - 2021-06-26 08:40:06 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:40:06 --> Controller Class Initialized
DEBUG - 2021-06-26 08:40:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:40:06 --> Final output sent to browser
DEBUG - 2021-06-26 08:40:06 --> Total execution time: 0.0457
INFO - 2021-06-26 08:40:13 --> Config Class Initialized
INFO - 2021-06-26 08:40:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:40:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:40:13 --> Utf8 Class Initialized
INFO - 2021-06-26 08:40:13 --> URI Class Initialized
INFO - 2021-06-26 08:40:13 --> Router Class Initialized
INFO - 2021-06-26 08:40:13 --> Output Class Initialized
INFO - 2021-06-26 08:40:13 --> Security Class Initialized
DEBUG - 2021-06-26 08:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:40:13 --> Input Class Initialized
INFO - 2021-06-26 08:40:13 --> Language Class Initialized
INFO - 2021-06-26 08:40:13 --> Language Class Initialized
INFO - 2021-06-26 08:40:13 --> Config Class Initialized
INFO - 2021-06-26 08:40:13 --> Loader Class Initialized
INFO - 2021-06-26 08:40:13 --> Helper loaded: url_helper
INFO - 2021-06-26 08:40:13 --> Helper loaded: file_helper
INFO - 2021-06-26 08:40:13 --> Helper loaded: form_helper
INFO - 2021-06-26 08:40:13 --> Helper loaded: my_helper
INFO - 2021-06-26 08:40:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:40:13 --> Controller Class Initialized
DEBUG - 2021-06-26 08:40:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:40:13 --> Final output sent to browser
DEBUG - 2021-06-26 08:40:13 --> Total execution time: 0.0453
INFO - 2021-06-26 08:40:44 --> Config Class Initialized
INFO - 2021-06-26 08:40:44 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:40:44 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:40:44 --> Utf8 Class Initialized
INFO - 2021-06-26 08:40:44 --> URI Class Initialized
INFO - 2021-06-26 08:40:44 --> Router Class Initialized
INFO - 2021-06-26 08:40:44 --> Output Class Initialized
INFO - 2021-06-26 08:40:44 --> Security Class Initialized
DEBUG - 2021-06-26 08:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:40:44 --> Input Class Initialized
INFO - 2021-06-26 08:40:44 --> Language Class Initialized
INFO - 2021-06-26 08:40:44 --> Language Class Initialized
INFO - 2021-06-26 08:40:44 --> Config Class Initialized
INFO - 2021-06-26 08:40:44 --> Loader Class Initialized
INFO - 2021-06-26 08:40:44 --> Helper loaded: url_helper
INFO - 2021-06-26 08:40:44 --> Helper loaded: file_helper
INFO - 2021-06-26 08:40:44 --> Helper loaded: form_helper
INFO - 2021-06-26 08:40:44 --> Helper loaded: my_helper
INFO - 2021-06-26 08:40:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:40:44 --> Controller Class Initialized
DEBUG - 2021-06-26 08:40:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 08:40:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 08:40:44 --> Final output sent to browser
DEBUG - 2021-06-26 08:40:44 --> Total execution time: 0.0451
INFO - 2021-06-26 08:40:49 --> Config Class Initialized
INFO - 2021-06-26 08:40:49 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:40:49 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:40:49 --> Utf8 Class Initialized
INFO - 2021-06-26 08:40:49 --> URI Class Initialized
INFO - 2021-06-26 08:40:49 --> Router Class Initialized
INFO - 2021-06-26 08:40:49 --> Output Class Initialized
INFO - 2021-06-26 08:40:49 --> Security Class Initialized
DEBUG - 2021-06-26 08:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:40:49 --> Input Class Initialized
INFO - 2021-06-26 08:40:49 --> Language Class Initialized
INFO - 2021-06-26 08:40:49 --> Language Class Initialized
INFO - 2021-06-26 08:40:49 --> Config Class Initialized
INFO - 2021-06-26 08:40:49 --> Loader Class Initialized
INFO - 2021-06-26 08:40:49 --> Helper loaded: url_helper
INFO - 2021-06-26 08:40:49 --> Helper loaded: file_helper
INFO - 2021-06-26 08:40:49 --> Helper loaded: form_helper
INFO - 2021-06-26 08:40:49 --> Helper loaded: my_helper
INFO - 2021-06-26 08:40:49 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:40:49 --> Controller Class Initialized
INFO - 2021-06-26 08:40:49 --> Helper loaded: cookie_helper
INFO - 2021-06-26 08:40:49 --> Final output sent to browser
DEBUG - 2021-06-26 08:40:49 --> Total execution time: 0.0503
INFO - 2021-06-26 08:40:49 --> Config Class Initialized
INFO - 2021-06-26 08:40:49 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:40:49 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:40:49 --> Utf8 Class Initialized
INFO - 2021-06-26 08:40:49 --> URI Class Initialized
INFO - 2021-06-26 08:40:49 --> Router Class Initialized
INFO - 2021-06-26 08:40:49 --> Output Class Initialized
INFO - 2021-06-26 08:40:49 --> Security Class Initialized
DEBUG - 2021-06-26 08:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:40:49 --> Input Class Initialized
INFO - 2021-06-26 08:40:49 --> Language Class Initialized
INFO - 2021-06-26 08:40:49 --> Language Class Initialized
INFO - 2021-06-26 08:40:49 --> Config Class Initialized
INFO - 2021-06-26 08:40:49 --> Loader Class Initialized
INFO - 2021-06-26 08:40:49 --> Helper loaded: url_helper
INFO - 2021-06-26 08:40:49 --> Helper loaded: file_helper
INFO - 2021-06-26 08:40:49 --> Helper loaded: form_helper
INFO - 2021-06-26 08:40:49 --> Helper loaded: my_helper
INFO - 2021-06-26 08:40:49 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:40:49 --> Controller Class Initialized
DEBUG - 2021-06-26 08:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 08:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 08:40:49 --> Final output sent to browser
DEBUG - 2021-06-26 08:40:49 --> Total execution time: 0.6093
INFO - 2021-06-26 08:40:51 --> Config Class Initialized
INFO - 2021-06-26 08:40:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:40:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:40:51 --> Utf8 Class Initialized
INFO - 2021-06-26 08:40:51 --> URI Class Initialized
INFO - 2021-06-26 08:40:51 --> Router Class Initialized
INFO - 2021-06-26 08:40:51 --> Output Class Initialized
INFO - 2021-06-26 08:40:51 --> Security Class Initialized
DEBUG - 2021-06-26 08:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:40:51 --> Input Class Initialized
INFO - 2021-06-26 08:40:51 --> Language Class Initialized
INFO - 2021-06-26 08:40:51 --> Language Class Initialized
INFO - 2021-06-26 08:40:51 --> Config Class Initialized
INFO - 2021-06-26 08:40:51 --> Loader Class Initialized
INFO - 2021-06-26 08:40:51 --> Helper loaded: url_helper
INFO - 2021-06-26 08:40:51 --> Helper loaded: file_helper
INFO - 2021-06-26 08:40:51 --> Helper loaded: form_helper
INFO - 2021-06-26 08:40:51 --> Helper loaded: my_helper
INFO - 2021-06-26 08:40:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:40:51 --> Controller Class Initialized
DEBUG - 2021-06-26 08:40:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 08:40:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 08:40:51 --> Final output sent to browser
DEBUG - 2021-06-26 08:40:51 --> Total execution time: 0.0483
INFO - 2021-06-26 08:40:52 --> Config Class Initialized
INFO - 2021-06-26 08:40:52 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:40:52 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:40:52 --> Utf8 Class Initialized
INFO - 2021-06-26 08:40:52 --> URI Class Initialized
INFO - 2021-06-26 08:40:52 --> Router Class Initialized
INFO - 2021-06-26 08:40:52 --> Output Class Initialized
INFO - 2021-06-26 08:40:52 --> Security Class Initialized
DEBUG - 2021-06-26 08:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:40:52 --> Input Class Initialized
INFO - 2021-06-26 08:40:52 --> Language Class Initialized
INFO - 2021-06-26 08:40:52 --> Language Class Initialized
INFO - 2021-06-26 08:40:52 --> Config Class Initialized
INFO - 2021-06-26 08:40:52 --> Loader Class Initialized
INFO - 2021-06-26 08:40:52 --> Helper loaded: url_helper
INFO - 2021-06-26 08:40:52 --> Helper loaded: file_helper
INFO - 2021-06-26 08:40:52 --> Helper loaded: form_helper
INFO - 2021-06-26 08:40:52 --> Helper loaded: my_helper
INFO - 2021-06-26 08:40:52 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:40:52 --> Controller Class Initialized
DEBUG - 2021-06-26 08:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:40:52 --> Final output sent to browser
DEBUG - 2021-06-26 08:40:52 --> Total execution time: 0.0457
INFO - 2021-06-26 08:41:09 --> Config Class Initialized
INFO - 2021-06-26 08:41:09 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:41:09 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:41:09 --> Utf8 Class Initialized
INFO - 2021-06-26 08:41:09 --> URI Class Initialized
INFO - 2021-06-26 08:41:09 --> Router Class Initialized
INFO - 2021-06-26 08:41:09 --> Output Class Initialized
INFO - 2021-06-26 08:41:09 --> Security Class Initialized
DEBUG - 2021-06-26 08:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:41:09 --> Input Class Initialized
INFO - 2021-06-26 08:41:09 --> Language Class Initialized
INFO - 2021-06-26 08:41:09 --> Language Class Initialized
INFO - 2021-06-26 08:41:09 --> Config Class Initialized
INFO - 2021-06-26 08:41:09 --> Loader Class Initialized
INFO - 2021-06-26 08:41:09 --> Helper loaded: url_helper
INFO - 2021-06-26 08:41:09 --> Helper loaded: file_helper
INFO - 2021-06-26 08:41:09 --> Helper loaded: form_helper
INFO - 2021-06-26 08:41:09 --> Helper loaded: my_helper
INFO - 2021-06-26 08:41:09 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:41:09 --> Controller Class Initialized
DEBUG - 2021-06-26 08:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:41:09 --> Final output sent to browser
DEBUG - 2021-06-26 08:41:09 --> Total execution time: 0.0541
INFO - 2021-06-26 08:41:27 --> Config Class Initialized
INFO - 2021-06-26 08:41:27 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:41:27 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:41:27 --> Utf8 Class Initialized
INFO - 2021-06-26 08:41:27 --> URI Class Initialized
INFO - 2021-06-26 08:41:27 --> Router Class Initialized
INFO - 2021-06-26 08:41:27 --> Output Class Initialized
INFO - 2021-06-26 08:41:27 --> Security Class Initialized
DEBUG - 2021-06-26 08:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:41:27 --> Input Class Initialized
INFO - 2021-06-26 08:41:27 --> Language Class Initialized
INFO - 2021-06-26 08:41:27 --> Language Class Initialized
INFO - 2021-06-26 08:41:27 --> Config Class Initialized
INFO - 2021-06-26 08:41:27 --> Loader Class Initialized
INFO - 2021-06-26 08:41:27 --> Helper loaded: url_helper
INFO - 2021-06-26 08:41:27 --> Helper loaded: file_helper
INFO - 2021-06-26 08:41:27 --> Helper loaded: form_helper
INFO - 2021-06-26 08:41:27 --> Helper loaded: my_helper
INFO - 2021-06-26 08:41:27 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:41:27 --> Controller Class Initialized
DEBUG - 2021-06-26 08:41:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:41:27 --> Final output sent to browser
DEBUG - 2021-06-26 08:41:27 --> Total execution time: 0.0539
INFO - 2021-06-26 08:41:37 --> Config Class Initialized
INFO - 2021-06-26 08:41:37 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:41:37 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:41:37 --> Utf8 Class Initialized
INFO - 2021-06-26 08:41:37 --> URI Class Initialized
INFO - 2021-06-26 08:41:37 --> Router Class Initialized
INFO - 2021-06-26 08:41:37 --> Output Class Initialized
INFO - 2021-06-26 08:41:37 --> Security Class Initialized
DEBUG - 2021-06-26 08:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:41:37 --> Input Class Initialized
INFO - 2021-06-26 08:41:37 --> Language Class Initialized
INFO - 2021-06-26 08:41:37 --> Language Class Initialized
INFO - 2021-06-26 08:41:37 --> Config Class Initialized
INFO - 2021-06-26 08:41:37 --> Loader Class Initialized
INFO - 2021-06-26 08:41:37 --> Helper loaded: url_helper
INFO - 2021-06-26 08:41:37 --> Helper loaded: file_helper
INFO - 2021-06-26 08:41:37 --> Helper loaded: form_helper
INFO - 2021-06-26 08:41:37 --> Helper loaded: my_helper
INFO - 2021-06-26 08:41:37 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:41:37 --> Controller Class Initialized
DEBUG - 2021-06-26 08:41:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:41:37 --> Final output sent to browser
DEBUG - 2021-06-26 08:41:37 --> Total execution time: 0.0540
INFO - 2021-06-26 08:42:30 --> Config Class Initialized
INFO - 2021-06-26 08:42:30 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:42:30 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:42:30 --> Utf8 Class Initialized
INFO - 2021-06-26 08:42:30 --> URI Class Initialized
INFO - 2021-06-26 08:42:30 --> Router Class Initialized
INFO - 2021-06-26 08:42:30 --> Output Class Initialized
INFO - 2021-06-26 08:42:30 --> Security Class Initialized
DEBUG - 2021-06-26 08:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:42:30 --> Input Class Initialized
INFO - 2021-06-26 08:42:30 --> Language Class Initialized
INFO - 2021-06-26 08:42:30 --> Language Class Initialized
INFO - 2021-06-26 08:42:30 --> Config Class Initialized
INFO - 2021-06-26 08:42:30 --> Loader Class Initialized
INFO - 2021-06-26 08:42:30 --> Helper loaded: url_helper
INFO - 2021-06-26 08:42:30 --> Helper loaded: file_helper
INFO - 2021-06-26 08:42:30 --> Helper loaded: form_helper
INFO - 2021-06-26 08:42:30 --> Helper loaded: my_helper
INFO - 2021-06-26 08:42:30 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:42:30 --> Controller Class Initialized
DEBUG - 2021-06-26 08:42:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:42:30 --> Final output sent to browser
DEBUG - 2021-06-26 08:42:30 --> Total execution time: 0.0537
INFO - 2021-06-26 08:43:15 --> Config Class Initialized
INFO - 2021-06-26 08:43:15 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:43:15 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:43:15 --> Utf8 Class Initialized
INFO - 2021-06-26 08:43:15 --> URI Class Initialized
INFO - 2021-06-26 08:43:15 --> Router Class Initialized
INFO - 2021-06-26 08:43:15 --> Output Class Initialized
INFO - 2021-06-26 08:43:15 --> Security Class Initialized
DEBUG - 2021-06-26 08:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:43:15 --> Input Class Initialized
INFO - 2021-06-26 08:43:15 --> Language Class Initialized
INFO - 2021-06-26 08:43:15 --> Language Class Initialized
INFO - 2021-06-26 08:43:15 --> Config Class Initialized
INFO - 2021-06-26 08:43:15 --> Loader Class Initialized
INFO - 2021-06-26 08:43:15 --> Helper loaded: url_helper
INFO - 2021-06-26 08:43:15 --> Helper loaded: file_helper
INFO - 2021-06-26 08:43:15 --> Helper loaded: form_helper
INFO - 2021-06-26 08:43:15 --> Helper loaded: my_helper
INFO - 2021-06-26 08:43:15 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:43:15 --> Controller Class Initialized
DEBUG - 2021-06-26 08:43:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:43:15 --> Final output sent to browser
DEBUG - 2021-06-26 08:43:15 --> Total execution time: 0.0453
INFO - 2021-06-26 08:44:37 --> Config Class Initialized
INFO - 2021-06-26 08:44:37 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:44:37 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:44:37 --> Utf8 Class Initialized
INFO - 2021-06-26 08:44:37 --> URI Class Initialized
INFO - 2021-06-26 08:44:37 --> Router Class Initialized
INFO - 2021-06-26 08:44:37 --> Output Class Initialized
INFO - 2021-06-26 08:44:37 --> Security Class Initialized
DEBUG - 2021-06-26 08:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:44:37 --> Input Class Initialized
INFO - 2021-06-26 08:44:37 --> Language Class Initialized
INFO - 2021-06-26 08:44:37 --> Language Class Initialized
INFO - 2021-06-26 08:44:37 --> Config Class Initialized
INFO - 2021-06-26 08:44:37 --> Loader Class Initialized
INFO - 2021-06-26 08:44:37 --> Helper loaded: url_helper
INFO - 2021-06-26 08:44:37 --> Helper loaded: file_helper
INFO - 2021-06-26 08:44:37 --> Helper loaded: form_helper
INFO - 2021-06-26 08:44:37 --> Helper loaded: my_helper
INFO - 2021-06-26 08:44:37 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:44:37 --> Controller Class Initialized
DEBUG - 2021-06-26 08:44:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:44:37 --> Final output sent to browser
DEBUG - 2021-06-26 08:44:37 --> Total execution time: 0.0536
INFO - 2021-06-26 08:45:03 --> Config Class Initialized
INFO - 2021-06-26 08:45:03 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:45:03 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:45:03 --> Utf8 Class Initialized
INFO - 2021-06-26 08:45:03 --> URI Class Initialized
INFO - 2021-06-26 08:45:03 --> Router Class Initialized
INFO - 2021-06-26 08:45:03 --> Output Class Initialized
INFO - 2021-06-26 08:45:03 --> Security Class Initialized
DEBUG - 2021-06-26 08:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:45:03 --> Input Class Initialized
INFO - 2021-06-26 08:45:03 --> Language Class Initialized
INFO - 2021-06-26 08:45:03 --> Language Class Initialized
INFO - 2021-06-26 08:45:03 --> Config Class Initialized
INFO - 2021-06-26 08:45:03 --> Loader Class Initialized
INFO - 2021-06-26 08:45:03 --> Helper loaded: url_helper
INFO - 2021-06-26 08:45:03 --> Helper loaded: file_helper
INFO - 2021-06-26 08:45:03 --> Helper loaded: form_helper
INFO - 2021-06-26 08:45:03 --> Helper loaded: my_helper
INFO - 2021-06-26 08:45:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:45:03 --> Controller Class Initialized
DEBUG - 2021-06-26 08:45:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:45:03 --> Final output sent to browser
DEBUG - 2021-06-26 08:45:03 --> Total execution time: 0.0444
INFO - 2021-06-26 08:45:24 --> Config Class Initialized
INFO - 2021-06-26 08:45:24 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:45:24 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:45:24 --> Utf8 Class Initialized
INFO - 2021-06-26 08:45:24 --> URI Class Initialized
INFO - 2021-06-26 08:45:24 --> Router Class Initialized
INFO - 2021-06-26 08:45:24 --> Output Class Initialized
INFO - 2021-06-26 08:45:24 --> Security Class Initialized
DEBUG - 2021-06-26 08:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:45:24 --> Input Class Initialized
INFO - 2021-06-26 08:45:24 --> Language Class Initialized
INFO - 2021-06-26 08:45:24 --> Language Class Initialized
INFO - 2021-06-26 08:45:24 --> Config Class Initialized
INFO - 2021-06-26 08:45:24 --> Loader Class Initialized
INFO - 2021-06-26 08:45:24 --> Helper loaded: url_helper
INFO - 2021-06-26 08:45:24 --> Helper loaded: file_helper
INFO - 2021-06-26 08:45:24 --> Helper loaded: form_helper
INFO - 2021-06-26 08:45:24 --> Helper loaded: my_helper
INFO - 2021-06-26 08:45:24 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:45:24 --> Controller Class Initialized
DEBUG - 2021-06-26 08:45:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:45:24 --> Final output sent to browser
DEBUG - 2021-06-26 08:45:24 --> Total execution time: 0.0562
INFO - 2021-06-26 08:45:40 --> Config Class Initialized
INFO - 2021-06-26 08:45:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:45:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:45:40 --> Utf8 Class Initialized
INFO - 2021-06-26 08:45:40 --> URI Class Initialized
INFO - 2021-06-26 08:45:40 --> Router Class Initialized
INFO - 2021-06-26 08:45:40 --> Output Class Initialized
INFO - 2021-06-26 08:45:40 --> Security Class Initialized
DEBUG - 2021-06-26 08:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:45:40 --> Input Class Initialized
INFO - 2021-06-26 08:45:40 --> Language Class Initialized
INFO - 2021-06-26 08:45:40 --> Language Class Initialized
INFO - 2021-06-26 08:45:40 --> Config Class Initialized
INFO - 2021-06-26 08:45:40 --> Loader Class Initialized
INFO - 2021-06-26 08:45:40 --> Helper loaded: url_helper
INFO - 2021-06-26 08:45:40 --> Helper loaded: file_helper
INFO - 2021-06-26 08:45:40 --> Helper loaded: form_helper
INFO - 2021-06-26 08:45:40 --> Helper loaded: my_helper
INFO - 2021-06-26 08:45:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:45:40 --> Controller Class Initialized
DEBUG - 2021-06-26 08:45:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:45:40 --> Final output sent to browser
DEBUG - 2021-06-26 08:45:40 --> Total execution time: 0.0537
INFO - 2021-06-26 08:46:23 --> Config Class Initialized
INFO - 2021-06-26 08:46:23 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:46:23 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:46:23 --> Utf8 Class Initialized
INFO - 2021-06-26 08:46:23 --> URI Class Initialized
INFO - 2021-06-26 08:46:23 --> Router Class Initialized
INFO - 2021-06-26 08:46:23 --> Output Class Initialized
INFO - 2021-06-26 08:46:23 --> Security Class Initialized
DEBUG - 2021-06-26 08:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:46:23 --> Input Class Initialized
INFO - 2021-06-26 08:46:23 --> Language Class Initialized
INFO - 2021-06-26 08:46:23 --> Language Class Initialized
INFO - 2021-06-26 08:46:23 --> Config Class Initialized
INFO - 2021-06-26 08:46:23 --> Loader Class Initialized
INFO - 2021-06-26 08:46:23 --> Helper loaded: url_helper
INFO - 2021-06-26 08:46:23 --> Helper loaded: file_helper
INFO - 2021-06-26 08:46:23 --> Helper loaded: form_helper
INFO - 2021-06-26 08:46:23 --> Helper loaded: my_helper
INFO - 2021-06-26 08:46:23 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:46:23 --> Controller Class Initialized
DEBUG - 2021-06-26 08:46:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-06-26 08:46:23 --> Final output sent to browser
DEBUG - 2021-06-26 08:46:23 --> Total execution time: 0.0583
INFO - 2021-06-26 08:46:57 --> Config Class Initialized
INFO - 2021-06-26 08:46:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 08:46:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 08:46:57 --> Utf8 Class Initialized
INFO - 2021-06-26 08:46:57 --> URI Class Initialized
INFO - 2021-06-26 08:46:57 --> Router Class Initialized
INFO - 2021-06-26 08:46:57 --> Output Class Initialized
INFO - 2021-06-26 08:46:57 --> Security Class Initialized
DEBUG - 2021-06-26 08:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 08:46:57 --> Input Class Initialized
INFO - 2021-06-26 08:46:57 --> Language Class Initialized
INFO - 2021-06-26 08:46:57 --> Language Class Initialized
INFO - 2021-06-26 08:46:57 --> Config Class Initialized
INFO - 2021-06-26 08:46:57 --> Loader Class Initialized
INFO - 2021-06-26 08:46:57 --> Helper loaded: url_helper
INFO - 2021-06-26 08:46:57 --> Helper loaded: file_helper
INFO - 2021-06-26 08:46:57 --> Helper loaded: form_helper
INFO - 2021-06-26 08:46:57 --> Helper loaded: my_helper
INFO - 2021-06-26 08:46:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 08:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 08:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 08:46:57 --> Controller Class Initialized
DEBUG - 2021-06-26 08:46:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-06-26 08:46:57 --> Final output sent to browser
DEBUG - 2021-06-26 08:46:57 --> Total execution time: 0.0454
INFO - 2021-06-26 11:22:12 --> Config Class Initialized
INFO - 2021-06-26 11:22:12 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:22:12 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:22:12 --> Utf8 Class Initialized
INFO - 2021-06-26 11:22:12 --> URI Class Initialized
DEBUG - 2021-06-26 11:22:12 --> No URI present. Default controller set.
INFO - 2021-06-26 11:22:12 --> Router Class Initialized
INFO - 2021-06-26 11:22:12 --> Output Class Initialized
INFO - 2021-06-26 11:22:12 --> Security Class Initialized
DEBUG - 2021-06-26 11:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:22:12 --> Input Class Initialized
INFO - 2021-06-26 11:22:12 --> Language Class Initialized
INFO - 2021-06-26 11:22:12 --> Language Class Initialized
INFO - 2021-06-26 11:22:12 --> Config Class Initialized
INFO - 2021-06-26 11:22:12 --> Loader Class Initialized
INFO - 2021-06-26 11:22:12 --> Helper loaded: url_helper
INFO - 2021-06-26 11:22:12 --> Helper loaded: file_helper
INFO - 2021-06-26 11:22:12 --> Helper loaded: form_helper
INFO - 2021-06-26 11:22:12 --> Helper loaded: my_helper
INFO - 2021-06-26 11:22:12 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:22:12 --> Controller Class Initialized
INFO - 2021-06-26 11:22:12 --> Config Class Initialized
INFO - 2021-06-26 11:22:12 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:22:12 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:22:12 --> Utf8 Class Initialized
INFO - 2021-06-26 11:22:12 --> URI Class Initialized
INFO - 2021-06-26 11:22:12 --> Router Class Initialized
INFO - 2021-06-26 11:22:12 --> Output Class Initialized
INFO - 2021-06-26 11:22:12 --> Security Class Initialized
DEBUG - 2021-06-26 11:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:22:12 --> Input Class Initialized
INFO - 2021-06-26 11:22:12 --> Language Class Initialized
INFO - 2021-06-26 11:22:12 --> Language Class Initialized
INFO - 2021-06-26 11:22:12 --> Config Class Initialized
INFO - 2021-06-26 11:22:12 --> Loader Class Initialized
INFO - 2021-06-26 11:22:12 --> Helper loaded: url_helper
INFO - 2021-06-26 11:22:12 --> Helper loaded: file_helper
INFO - 2021-06-26 11:22:12 --> Helper loaded: form_helper
INFO - 2021-06-26 11:22:12 --> Helper loaded: my_helper
INFO - 2021-06-26 11:22:12 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:22:12 --> Controller Class Initialized
DEBUG - 2021-06-26 11:22:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 11:22:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:22:12 --> Final output sent to browser
DEBUG - 2021-06-26 11:22:12 --> Total execution time: 0.0417
INFO - 2021-06-26 11:22:18 --> Config Class Initialized
INFO - 2021-06-26 11:22:18 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:22:18 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:22:18 --> Utf8 Class Initialized
INFO - 2021-06-26 11:22:18 --> URI Class Initialized
INFO - 2021-06-26 11:22:18 --> Router Class Initialized
INFO - 2021-06-26 11:22:18 --> Output Class Initialized
INFO - 2021-06-26 11:22:18 --> Security Class Initialized
DEBUG - 2021-06-26 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:22:18 --> Input Class Initialized
INFO - 2021-06-26 11:22:18 --> Language Class Initialized
INFO - 2021-06-26 11:22:18 --> Language Class Initialized
INFO - 2021-06-26 11:22:18 --> Config Class Initialized
INFO - 2021-06-26 11:22:18 --> Loader Class Initialized
INFO - 2021-06-26 11:22:18 --> Helper loaded: url_helper
INFO - 2021-06-26 11:22:18 --> Helper loaded: file_helper
INFO - 2021-06-26 11:22:18 --> Helper loaded: form_helper
INFO - 2021-06-26 11:22:18 --> Helper loaded: my_helper
INFO - 2021-06-26 11:22:18 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:22:18 --> Controller Class Initialized
INFO - 2021-06-26 11:22:18 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:22:18 --> Final output sent to browser
DEBUG - 2021-06-26 11:22:18 --> Total execution time: 0.0501
INFO - 2021-06-26 11:22:19 --> Config Class Initialized
INFO - 2021-06-26 11:22:19 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:22:19 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:22:19 --> Utf8 Class Initialized
INFO - 2021-06-26 11:22:19 --> URI Class Initialized
INFO - 2021-06-26 11:22:19 --> Router Class Initialized
INFO - 2021-06-26 11:22:19 --> Output Class Initialized
INFO - 2021-06-26 11:22:19 --> Security Class Initialized
DEBUG - 2021-06-26 11:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:22:19 --> Input Class Initialized
INFO - 2021-06-26 11:22:19 --> Language Class Initialized
INFO - 2021-06-26 11:22:19 --> Language Class Initialized
INFO - 2021-06-26 11:22:19 --> Config Class Initialized
INFO - 2021-06-26 11:22:19 --> Loader Class Initialized
INFO - 2021-06-26 11:22:19 --> Helper loaded: url_helper
INFO - 2021-06-26 11:22:19 --> Helper loaded: file_helper
INFO - 2021-06-26 11:22:19 --> Helper loaded: form_helper
INFO - 2021-06-26 11:22:19 --> Helper loaded: my_helper
INFO - 2021-06-26 11:22:19 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:22:19 --> Controller Class Initialized
DEBUG - 2021-06-26 11:22:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 11:22:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:22:20 --> Final output sent to browser
DEBUG - 2021-06-26 11:22:20 --> Total execution time: 0.7105
INFO - 2021-06-26 11:22:45 --> Config Class Initialized
INFO - 2021-06-26 11:22:45 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:22:45 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:22:45 --> Utf8 Class Initialized
INFO - 2021-06-26 11:22:45 --> URI Class Initialized
INFO - 2021-06-26 11:22:45 --> Router Class Initialized
INFO - 2021-06-26 11:22:45 --> Output Class Initialized
INFO - 2021-06-26 11:22:45 --> Security Class Initialized
DEBUG - 2021-06-26 11:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:22:45 --> Input Class Initialized
INFO - 2021-06-26 11:22:45 --> Language Class Initialized
INFO - 2021-06-26 11:22:45 --> Language Class Initialized
INFO - 2021-06-26 11:22:45 --> Config Class Initialized
INFO - 2021-06-26 11:22:45 --> Loader Class Initialized
INFO - 2021-06-26 11:22:45 --> Helper loaded: url_helper
INFO - 2021-06-26 11:22:45 --> Helper loaded: file_helper
INFO - 2021-06-26 11:22:45 --> Helper loaded: form_helper
INFO - 2021-06-26 11:22:45 --> Helper loaded: my_helper
INFO - 2021-06-26 11:22:45 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:22:45 --> Controller Class Initialized
DEBUG - 2021-06-26 11:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-26 11:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:22:45 --> Final output sent to browser
DEBUG - 2021-06-26 11:22:45 --> Total execution time: 0.0920
INFO - 2021-06-26 11:22:49 --> Config Class Initialized
INFO - 2021-06-26 11:22:49 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:22:49 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:22:49 --> Utf8 Class Initialized
INFO - 2021-06-26 11:22:49 --> URI Class Initialized
INFO - 2021-06-26 11:22:49 --> Router Class Initialized
INFO - 2021-06-26 11:22:49 --> Output Class Initialized
INFO - 2021-06-26 11:22:49 --> Security Class Initialized
DEBUG - 2021-06-26 11:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:22:49 --> Input Class Initialized
INFO - 2021-06-26 11:22:49 --> Language Class Initialized
INFO - 2021-06-26 11:22:49 --> Language Class Initialized
INFO - 2021-06-26 11:22:49 --> Config Class Initialized
INFO - 2021-06-26 11:22:49 --> Loader Class Initialized
INFO - 2021-06-26 11:22:49 --> Helper loaded: url_helper
INFO - 2021-06-26 11:22:49 --> Helper loaded: file_helper
INFO - 2021-06-26 11:22:49 --> Helper loaded: form_helper
INFO - 2021-06-26 11:22:49 --> Helper loaded: my_helper
INFO - 2021-06-26 11:22:49 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:22:49 --> Controller Class Initialized
DEBUG - 2021-06-26 11:22:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:22:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:22:49 --> Final output sent to browser
DEBUG - 2021-06-26 11:22:49 --> Total execution time: 0.1052
INFO - 2021-06-26 11:22:50 --> Config Class Initialized
INFO - 2021-06-26 11:22:50 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:22:50 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:22:50 --> Utf8 Class Initialized
INFO - 2021-06-26 11:22:50 --> URI Class Initialized
INFO - 2021-06-26 11:22:50 --> Router Class Initialized
INFO - 2021-06-26 11:22:50 --> Output Class Initialized
INFO - 2021-06-26 11:22:50 --> Security Class Initialized
DEBUG - 2021-06-26 11:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:22:50 --> Input Class Initialized
INFO - 2021-06-26 11:22:50 --> Language Class Initialized
INFO - 2021-06-26 11:22:50 --> Language Class Initialized
INFO - 2021-06-26 11:22:50 --> Config Class Initialized
INFO - 2021-06-26 11:22:50 --> Loader Class Initialized
INFO - 2021-06-26 11:22:50 --> Helper loaded: url_helper
INFO - 2021-06-26 11:22:50 --> Helper loaded: file_helper
INFO - 2021-06-26 11:22:50 --> Helper loaded: form_helper
INFO - 2021-06-26 11:22:50 --> Helper loaded: my_helper
INFO - 2021-06-26 11:22:50 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:22:50 --> Controller Class Initialized
INFO - 2021-06-26 11:22:53 --> Config Class Initialized
INFO - 2021-06-26 11:22:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:22:53 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:22:53 --> Utf8 Class Initialized
INFO - 2021-06-26 11:22:53 --> URI Class Initialized
INFO - 2021-06-26 11:22:53 --> Router Class Initialized
INFO - 2021-06-26 11:22:53 --> Output Class Initialized
INFO - 2021-06-26 11:22:53 --> Security Class Initialized
DEBUG - 2021-06-26 11:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:22:53 --> Input Class Initialized
INFO - 2021-06-26 11:22:53 --> Language Class Initialized
INFO - 2021-06-26 11:22:53 --> Language Class Initialized
INFO - 2021-06-26 11:22:53 --> Config Class Initialized
INFO - 2021-06-26 11:22:53 --> Loader Class Initialized
INFO - 2021-06-26 11:22:53 --> Helper loaded: url_helper
INFO - 2021-06-26 11:22:53 --> Helper loaded: file_helper
INFO - 2021-06-26 11:22:53 --> Helper loaded: form_helper
INFO - 2021-06-26 11:22:53 --> Helper loaded: my_helper
INFO - 2021-06-26 11:22:53 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:22:53 --> Controller Class Initialized
INFO - 2021-06-26 11:22:54 --> Final output sent to browser
DEBUG - 2021-06-26 11:22:54 --> Total execution time: 0.1181
INFO - 2021-06-26 11:23:03 --> Config Class Initialized
INFO - 2021-06-26 11:23:03 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:03 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:03 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:03 --> URI Class Initialized
INFO - 2021-06-26 11:23:03 --> Router Class Initialized
INFO - 2021-06-26 11:23:03 --> Output Class Initialized
INFO - 2021-06-26 11:23:03 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:03 --> Input Class Initialized
INFO - 2021-06-26 11:23:03 --> Language Class Initialized
INFO - 2021-06-26 11:23:03 --> Language Class Initialized
INFO - 2021-06-26 11:23:03 --> Config Class Initialized
INFO - 2021-06-26 11:23:03 --> Loader Class Initialized
INFO - 2021-06-26 11:23:03 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:03 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:03 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:03 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:03 --> Controller Class Initialized
DEBUG - 2021-06-26 11:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:23:03 --> Final output sent to browser
DEBUG - 2021-06-26 11:23:03 --> Total execution time: 0.0465
INFO - 2021-06-26 11:23:03 --> Config Class Initialized
INFO - 2021-06-26 11:23:03 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:03 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:03 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:03 --> URI Class Initialized
INFO - 2021-06-26 11:23:03 --> Router Class Initialized
INFO - 2021-06-26 11:23:03 --> Output Class Initialized
INFO - 2021-06-26 11:23:03 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:03 --> Input Class Initialized
INFO - 2021-06-26 11:23:03 --> Language Class Initialized
INFO - 2021-06-26 11:23:03 --> Language Class Initialized
INFO - 2021-06-26 11:23:03 --> Config Class Initialized
INFO - 2021-06-26 11:23:03 --> Loader Class Initialized
INFO - 2021-06-26 11:23:03 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:03 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:03 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:03 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:03 --> Controller Class Initialized
INFO - 2021-06-26 11:23:04 --> Config Class Initialized
INFO - 2021-06-26 11:23:04 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:04 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:04 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:04 --> URI Class Initialized
INFO - 2021-06-26 11:23:04 --> Router Class Initialized
INFO - 2021-06-26 11:23:04 --> Output Class Initialized
INFO - 2021-06-26 11:23:04 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:04 --> Input Class Initialized
INFO - 2021-06-26 11:23:04 --> Language Class Initialized
INFO - 2021-06-26 11:23:04 --> Language Class Initialized
INFO - 2021-06-26 11:23:04 --> Config Class Initialized
INFO - 2021-06-26 11:23:04 --> Loader Class Initialized
INFO - 2021-06-26 11:23:04 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:04 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:04 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:04 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:04 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:04 --> Controller Class Initialized
INFO - 2021-06-26 11:23:04 --> Final output sent to browser
DEBUG - 2021-06-26 11:23:04 --> Total execution time: 0.0525
INFO - 2021-06-26 11:23:20 --> Config Class Initialized
INFO - 2021-06-26 11:23:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:20 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:20 --> URI Class Initialized
INFO - 2021-06-26 11:23:20 --> Router Class Initialized
INFO - 2021-06-26 11:23:20 --> Output Class Initialized
INFO - 2021-06-26 11:23:20 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:20 --> Input Class Initialized
INFO - 2021-06-26 11:23:20 --> Language Class Initialized
INFO - 2021-06-26 11:23:20 --> Language Class Initialized
INFO - 2021-06-26 11:23:20 --> Config Class Initialized
INFO - 2021-06-26 11:23:20 --> Loader Class Initialized
INFO - 2021-06-26 11:23:20 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:20 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:20 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:20 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:20 --> Controller Class Initialized
DEBUG - 2021-06-26 11:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:23:20 --> Final output sent to browser
DEBUG - 2021-06-26 11:23:20 --> Total execution time: 0.0449
INFO - 2021-06-26 11:23:20 --> Config Class Initialized
INFO - 2021-06-26 11:23:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:20 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:20 --> URI Class Initialized
INFO - 2021-06-26 11:23:20 --> Router Class Initialized
INFO - 2021-06-26 11:23:20 --> Output Class Initialized
INFO - 2021-06-26 11:23:20 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:20 --> Input Class Initialized
INFO - 2021-06-26 11:23:20 --> Language Class Initialized
INFO - 2021-06-26 11:23:20 --> Language Class Initialized
INFO - 2021-06-26 11:23:20 --> Config Class Initialized
INFO - 2021-06-26 11:23:20 --> Loader Class Initialized
INFO - 2021-06-26 11:23:20 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:20 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:20 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:20 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:20 --> Controller Class Initialized
INFO - 2021-06-26 11:23:25 --> Config Class Initialized
INFO - 2021-06-26 11:23:25 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:25 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:25 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:25 --> URI Class Initialized
INFO - 2021-06-26 11:23:25 --> Router Class Initialized
INFO - 2021-06-26 11:23:25 --> Output Class Initialized
INFO - 2021-06-26 11:23:25 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:25 --> Input Class Initialized
INFO - 2021-06-26 11:23:25 --> Language Class Initialized
INFO - 2021-06-26 11:23:25 --> Language Class Initialized
INFO - 2021-06-26 11:23:25 --> Config Class Initialized
INFO - 2021-06-26 11:23:25 --> Loader Class Initialized
INFO - 2021-06-26 11:23:25 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:25 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:25 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:25 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:25 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:25 --> Controller Class Initialized
INFO - 2021-06-26 11:23:25 --> Final output sent to browser
DEBUG - 2021-06-26 11:23:25 --> Total execution time: 0.0518
INFO - 2021-06-26 11:23:37 --> Config Class Initialized
INFO - 2021-06-26 11:23:37 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:37 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:37 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:37 --> URI Class Initialized
INFO - 2021-06-26 11:23:37 --> Router Class Initialized
INFO - 2021-06-26 11:23:37 --> Output Class Initialized
INFO - 2021-06-26 11:23:37 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:37 --> Input Class Initialized
INFO - 2021-06-26 11:23:37 --> Language Class Initialized
INFO - 2021-06-26 11:23:37 --> Language Class Initialized
INFO - 2021-06-26 11:23:37 --> Config Class Initialized
INFO - 2021-06-26 11:23:37 --> Loader Class Initialized
INFO - 2021-06-26 11:23:37 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:37 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:37 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:37 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:37 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:37 --> Controller Class Initialized
DEBUG - 2021-06-26 11:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:23:37 --> Final output sent to browser
DEBUG - 2021-06-26 11:23:37 --> Total execution time: 0.0445
INFO - 2021-06-26 11:23:37 --> Config Class Initialized
INFO - 2021-06-26 11:23:37 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:37 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:37 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:37 --> URI Class Initialized
INFO - 2021-06-26 11:23:37 --> Router Class Initialized
INFO - 2021-06-26 11:23:37 --> Output Class Initialized
INFO - 2021-06-26 11:23:37 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:37 --> Input Class Initialized
INFO - 2021-06-26 11:23:37 --> Language Class Initialized
INFO - 2021-06-26 11:23:37 --> Language Class Initialized
INFO - 2021-06-26 11:23:37 --> Config Class Initialized
INFO - 2021-06-26 11:23:37 --> Loader Class Initialized
INFO - 2021-06-26 11:23:37 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:37 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:37 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:37 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:37 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:37 --> Controller Class Initialized
INFO - 2021-06-26 11:23:41 --> Config Class Initialized
INFO - 2021-06-26 11:23:41 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:41 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:41 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:41 --> URI Class Initialized
INFO - 2021-06-26 11:23:41 --> Router Class Initialized
INFO - 2021-06-26 11:23:41 --> Output Class Initialized
INFO - 2021-06-26 11:23:41 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:41 --> Input Class Initialized
INFO - 2021-06-26 11:23:41 --> Language Class Initialized
INFO - 2021-06-26 11:23:41 --> Language Class Initialized
INFO - 2021-06-26 11:23:41 --> Config Class Initialized
INFO - 2021-06-26 11:23:41 --> Loader Class Initialized
INFO - 2021-06-26 11:23:41 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:41 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:41 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:41 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:41 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:41 --> Controller Class Initialized
INFO - 2021-06-26 11:23:41 --> Final output sent to browser
DEBUG - 2021-06-26 11:23:41 --> Total execution time: 0.0526
INFO - 2021-06-26 11:23:55 --> Config Class Initialized
INFO - 2021-06-26 11:23:55 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:23:55 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:23:55 --> Utf8 Class Initialized
INFO - 2021-06-26 11:23:55 --> URI Class Initialized
INFO - 2021-06-26 11:23:55 --> Router Class Initialized
INFO - 2021-06-26 11:23:55 --> Output Class Initialized
INFO - 2021-06-26 11:23:55 --> Security Class Initialized
DEBUG - 2021-06-26 11:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:23:55 --> Input Class Initialized
INFO - 2021-06-26 11:23:55 --> Language Class Initialized
INFO - 2021-06-26 11:23:55 --> Language Class Initialized
INFO - 2021-06-26 11:23:55 --> Config Class Initialized
INFO - 2021-06-26 11:23:55 --> Loader Class Initialized
INFO - 2021-06-26 11:23:55 --> Helper loaded: url_helper
INFO - 2021-06-26 11:23:55 --> Helper loaded: file_helper
INFO - 2021-06-26 11:23:55 --> Helper loaded: form_helper
INFO - 2021-06-26 11:23:55 --> Helper loaded: my_helper
INFO - 2021-06-26 11:23:55 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:23:55 --> Controller Class Initialized
DEBUG - 2021-06-26 11:23:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:23:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:23:55 --> Final output sent to browser
DEBUG - 2021-06-26 11:23:55 --> Total execution time: 0.1054
INFO - 2021-06-26 11:24:00 --> Config Class Initialized
INFO - 2021-06-26 11:24:00 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:24:00 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:24:00 --> Utf8 Class Initialized
INFO - 2021-06-26 11:24:00 --> URI Class Initialized
INFO - 2021-06-26 11:24:00 --> Router Class Initialized
INFO - 2021-06-26 11:24:00 --> Output Class Initialized
INFO - 2021-06-26 11:24:00 --> Security Class Initialized
DEBUG - 2021-06-26 11:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:24:00 --> Input Class Initialized
INFO - 2021-06-26 11:24:00 --> Language Class Initialized
INFO - 2021-06-26 11:24:00 --> Language Class Initialized
INFO - 2021-06-26 11:24:00 --> Config Class Initialized
INFO - 2021-06-26 11:24:00 --> Loader Class Initialized
INFO - 2021-06-26 11:24:00 --> Helper loaded: url_helper
INFO - 2021-06-26 11:24:00 --> Helper loaded: file_helper
INFO - 2021-06-26 11:24:00 --> Helper loaded: form_helper
INFO - 2021-06-26 11:24:00 --> Helper loaded: my_helper
INFO - 2021-06-26 11:24:00 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:24:00 --> Controller Class Initialized
INFO - 2021-06-26 11:24:00 --> Final output sent to browser
DEBUG - 2021-06-26 11:24:00 --> Total execution time: 0.1010
INFO - 2021-06-26 11:24:08 --> Config Class Initialized
INFO - 2021-06-26 11:24:08 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:24:08 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:24:08 --> Utf8 Class Initialized
INFO - 2021-06-26 11:24:08 --> URI Class Initialized
INFO - 2021-06-26 11:24:08 --> Router Class Initialized
INFO - 2021-06-26 11:24:08 --> Output Class Initialized
INFO - 2021-06-26 11:24:08 --> Security Class Initialized
DEBUG - 2021-06-26 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:24:08 --> Input Class Initialized
INFO - 2021-06-26 11:24:08 --> Language Class Initialized
INFO - 2021-06-26 11:24:08 --> Language Class Initialized
INFO - 2021-06-26 11:24:08 --> Config Class Initialized
INFO - 2021-06-26 11:24:08 --> Loader Class Initialized
INFO - 2021-06-26 11:24:08 --> Helper loaded: url_helper
INFO - 2021-06-26 11:24:08 --> Helper loaded: file_helper
INFO - 2021-06-26 11:24:08 --> Helper loaded: form_helper
INFO - 2021-06-26 11:24:08 --> Helper loaded: my_helper
INFO - 2021-06-26 11:24:08 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:24:08 --> Controller Class Initialized
INFO - 2021-06-26 11:24:10 --> Config Class Initialized
INFO - 2021-06-26 11:24:10 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:24:10 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:24:10 --> Utf8 Class Initialized
INFO - 2021-06-26 11:24:10 --> URI Class Initialized
INFO - 2021-06-26 11:24:10 --> Router Class Initialized
INFO - 2021-06-26 11:24:10 --> Output Class Initialized
INFO - 2021-06-26 11:24:10 --> Security Class Initialized
DEBUG - 2021-06-26 11:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:24:10 --> Input Class Initialized
INFO - 2021-06-26 11:24:10 --> Language Class Initialized
INFO - 2021-06-26 11:24:10 --> Language Class Initialized
INFO - 2021-06-26 11:24:10 --> Config Class Initialized
INFO - 2021-06-26 11:24:10 --> Loader Class Initialized
INFO - 2021-06-26 11:24:10 --> Helper loaded: url_helper
INFO - 2021-06-26 11:24:10 --> Helper loaded: file_helper
INFO - 2021-06-26 11:24:10 --> Helper loaded: form_helper
INFO - 2021-06-26 11:24:10 --> Helper loaded: my_helper
INFO - 2021-06-26 11:24:10 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:24:10 --> Controller Class Initialized
INFO - 2021-06-26 11:25:16 --> Config Class Initialized
INFO - 2021-06-26 11:25:16 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:16 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:16 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:16 --> URI Class Initialized
INFO - 2021-06-26 11:25:16 --> Router Class Initialized
INFO - 2021-06-26 11:25:16 --> Output Class Initialized
INFO - 2021-06-26 11:25:16 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:16 --> Input Class Initialized
INFO - 2021-06-26 11:25:16 --> Language Class Initialized
INFO - 2021-06-26 11:25:16 --> Language Class Initialized
INFO - 2021-06-26 11:25:16 --> Config Class Initialized
INFO - 2021-06-26 11:25:16 --> Loader Class Initialized
INFO - 2021-06-26 11:25:16 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:16 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:16 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:16 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:16 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:16 --> Controller Class Initialized
DEBUG - 2021-06-26 11:25:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-26 11:25:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:25:16 --> Final output sent to browser
DEBUG - 2021-06-26 11:25:16 --> Total execution time: 0.0682
INFO - 2021-06-26 11:25:20 --> Config Class Initialized
INFO - 2021-06-26 11:25:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:20 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:20 --> URI Class Initialized
INFO - 2021-06-26 11:25:20 --> Router Class Initialized
INFO - 2021-06-26 11:25:20 --> Output Class Initialized
INFO - 2021-06-26 11:25:20 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:20 --> Input Class Initialized
INFO - 2021-06-26 11:25:20 --> Language Class Initialized
INFO - 2021-06-26 11:25:20 --> Language Class Initialized
INFO - 2021-06-26 11:25:20 --> Config Class Initialized
INFO - 2021-06-26 11:25:20 --> Loader Class Initialized
INFO - 2021-06-26 11:25:20 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:20 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:20 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:20 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:20 --> Controller Class Initialized
INFO - 2021-06-26 11:25:20 --> Config Class Initialized
INFO - 2021-06-26 11:25:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:20 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:20 --> URI Class Initialized
INFO - 2021-06-26 11:25:20 --> Router Class Initialized
INFO - 2021-06-26 11:25:20 --> Output Class Initialized
INFO - 2021-06-26 11:25:20 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:20 --> Input Class Initialized
INFO - 2021-06-26 11:25:20 --> Language Class Initialized
INFO - 2021-06-26 11:25:20 --> Language Class Initialized
INFO - 2021-06-26 11:25:20 --> Config Class Initialized
INFO - 2021-06-26 11:25:20 --> Loader Class Initialized
INFO - 2021-06-26 11:25:20 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:20 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:20 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:20 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:20 --> Controller Class Initialized
DEBUG - 2021-06-26 11:25:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:25:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:25:20 --> Final output sent to browser
DEBUG - 2021-06-26 11:25:20 --> Total execution time: 0.0527
INFO - 2021-06-26 11:25:20 --> Config Class Initialized
INFO - 2021-06-26 11:25:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:20 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:20 --> URI Class Initialized
INFO - 2021-06-26 11:25:20 --> Router Class Initialized
INFO - 2021-06-26 11:25:20 --> Output Class Initialized
INFO - 2021-06-26 11:25:20 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:20 --> Input Class Initialized
INFO - 2021-06-26 11:25:20 --> Language Class Initialized
INFO - 2021-06-26 11:25:20 --> Language Class Initialized
INFO - 2021-06-26 11:25:20 --> Config Class Initialized
INFO - 2021-06-26 11:25:20 --> Loader Class Initialized
INFO - 2021-06-26 11:25:20 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:20 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:20 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:20 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:20 --> Controller Class Initialized
INFO - 2021-06-26 11:25:22 --> Config Class Initialized
INFO - 2021-06-26 11:25:22 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:22 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:22 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:22 --> URI Class Initialized
INFO - 2021-06-26 11:25:22 --> Router Class Initialized
INFO - 2021-06-26 11:25:22 --> Output Class Initialized
INFO - 2021-06-26 11:25:22 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:22 --> Input Class Initialized
INFO - 2021-06-26 11:25:22 --> Language Class Initialized
INFO - 2021-06-26 11:25:22 --> Language Class Initialized
INFO - 2021-06-26 11:25:22 --> Config Class Initialized
INFO - 2021-06-26 11:25:22 --> Loader Class Initialized
INFO - 2021-06-26 11:25:22 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:22 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:22 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:22 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:22 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:22 --> Controller Class Initialized
DEBUG - 2021-06-26 11:25:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-26 11:25:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:25:22 --> Final output sent to browser
DEBUG - 2021-06-26 11:25:22 --> Total execution time: 0.0659
INFO - 2021-06-26 11:25:25 --> Config Class Initialized
INFO - 2021-06-26 11:25:25 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:25 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:25 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:25 --> URI Class Initialized
INFO - 2021-06-26 11:25:25 --> Router Class Initialized
INFO - 2021-06-26 11:25:25 --> Output Class Initialized
INFO - 2021-06-26 11:25:25 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:25 --> Input Class Initialized
INFO - 2021-06-26 11:25:25 --> Language Class Initialized
INFO - 2021-06-26 11:25:25 --> Language Class Initialized
INFO - 2021-06-26 11:25:25 --> Config Class Initialized
INFO - 2021-06-26 11:25:25 --> Loader Class Initialized
INFO - 2021-06-26 11:25:25 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:25 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:25 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:25 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:25 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:25 --> Controller Class Initialized
INFO - 2021-06-26 11:25:25 --> Config Class Initialized
INFO - 2021-06-26 11:25:25 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:25 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:25 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:25 --> URI Class Initialized
INFO - 2021-06-26 11:25:25 --> Router Class Initialized
INFO - 2021-06-26 11:25:26 --> Output Class Initialized
INFO - 2021-06-26 11:25:26 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:26 --> Input Class Initialized
INFO - 2021-06-26 11:25:26 --> Language Class Initialized
INFO - 2021-06-26 11:25:26 --> Language Class Initialized
INFO - 2021-06-26 11:25:26 --> Config Class Initialized
INFO - 2021-06-26 11:25:26 --> Loader Class Initialized
INFO - 2021-06-26 11:25:26 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:26 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:26 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:26 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:26 --> Controller Class Initialized
DEBUG - 2021-06-26 11:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:25:26 --> Final output sent to browser
DEBUG - 2021-06-26 11:25:26 --> Total execution time: 0.0466
INFO - 2021-06-26 11:25:34 --> Config Class Initialized
INFO - 2021-06-26 11:25:34 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:34 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:34 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:34 --> URI Class Initialized
INFO - 2021-06-26 11:25:34 --> Router Class Initialized
INFO - 2021-06-26 11:25:34 --> Output Class Initialized
INFO - 2021-06-26 11:25:34 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:34 --> Input Class Initialized
INFO - 2021-06-26 11:25:34 --> Language Class Initialized
INFO - 2021-06-26 11:25:34 --> Language Class Initialized
INFO - 2021-06-26 11:25:34 --> Config Class Initialized
INFO - 2021-06-26 11:25:34 --> Loader Class Initialized
INFO - 2021-06-26 11:25:34 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:34 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:34 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:34 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:34 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:34 --> Controller Class Initialized
DEBUG - 2021-06-26 11:25:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:25:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:25:34 --> Final output sent to browser
DEBUG - 2021-06-26 11:25:34 --> Total execution time: 0.0447
INFO - 2021-06-26 11:25:34 --> Config Class Initialized
INFO - 2021-06-26 11:25:34 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:34 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:34 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:34 --> URI Class Initialized
INFO - 2021-06-26 11:25:34 --> Router Class Initialized
INFO - 2021-06-26 11:25:34 --> Output Class Initialized
INFO - 2021-06-26 11:25:34 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:34 --> Input Class Initialized
INFO - 2021-06-26 11:25:34 --> Language Class Initialized
INFO - 2021-06-26 11:25:34 --> Language Class Initialized
INFO - 2021-06-26 11:25:34 --> Config Class Initialized
INFO - 2021-06-26 11:25:34 --> Loader Class Initialized
INFO - 2021-06-26 11:25:34 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:34 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:34 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:34 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:34 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:34 --> Controller Class Initialized
INFO - 2021-06-26 11:25:35 --> Config Class Initialized
INFO - 2021-06-26 11:25:35 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:35 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:35 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:35 --> URI Class Initialized
INFO - 2021-06-26 11:25:35 --> Router Class Initialized
INFO - 2021-06-26 11:25:35 --> Output Class Initialized
INFO - 2021-06-26 11:25:35 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:35 --> Input Class Initialized
INFO - 2021-06-26 11:25:35 --> Language Class Initialized
INFO - 2021-06-26 11:25:35 --> Language Class Initialized
INFO - 2021-06-26 11:25:35 --> Config Class Initialized
INFO - 2021-06-26 11:25:35 --> Loader Class Initialized
INFO - 2021-06-26 11:25:35 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:35 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:35 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:35 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:35 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:35 --> Controller Class Initialized
DEBUG - 2021-06-26 11:25:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:25:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:25:35 --> Final output sent to browser
DEBUG - 2021-06-26 11:25:35 --> Total execution time: 0.0442
INFO - 2021-06-26 11:25:38 --> Config Class Initialized
INFO - 2021-06-26 11:25:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:38 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:38 --> URI Class Initialized
INFO - 2021-06-26 11:25:38 --> Router Class Initialized
INFO - 2021-06-26 11:25:38 --> Output Class Initialized
INFO - 2021-06-26 11:25:38 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:38 --> Input Class Initialized
INFO - 2021-06-26 11:25:38 --> Language Class Initialized
INFO - 2021-06-26 11:25:38 --> Language Class Initialized
INFO - 2021-06-26 11:25:38 --> Config Class Initialized
INFO - 2021-06-26 11:25:38 --> Loader Class Initialized
INFO - 2021-06-26 11:25:38 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:38 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:38 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:38 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:38 --> Controller Class Initialized
INFO - 2021-06-26 11:25:40 --> Config Class Initialized
INFO - 2021-06-26 11:25:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:25:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:25:40 --> Utf8 Class Initialized
INFO - 2021-06-26 11:25:40 --> URI Class Initialized
INFO - 2021-06-26 11:25:40 --> Router Class Initialized
INFO - 2021-06-26 11:25:40 --> Output Class Initialized
INFO - 2021-06-26 11:25:40 --> Security Class Initialized
DEBUG - 2021-06-26 11:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:25:40 --> Input Class Initialized
INFO - 2021-06-26 11:25:40 --> Language Class Initialized
INFO - 2021-06-26 11:25:40 --> Language Class Initialized
INFO - 2021-06-26 11:25:40 --> Config Class Initialized
INFO - 2021-06-26 11:25:40 --> Loader Class Initialized
INFO - 2021-06-26 11:25:40 --> Helper loaded: url_helper
INFO - 2021-06-26 11:25:40 --> Helper loaded: file_helper
INFO - 2021-06-26 11:25:40 --> Helper loaded: form_helper
INFO - 2021-06-26 11:25:40 --> Helper loaded: my_helper
INFO - 2021-06-26 11:25:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:25:40 --> Controller Class Initialized
INFO - 2021-06-26 11:26:36 --> Config Class Initialized
INFO - 2021-06-26 11:26:36 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:26:36 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:26:36 --> Utf8 Class Initialized
INFO - 2021-06-26 11:26:36 --> URI Class Initialized
INFO - 2021-06-26 11:26:36 --> Router Class Initialized
INFO - 2021-06-26 11:26:36 --> Output Class Initialized
INFO - 2021-06-26 11:26:36 --> Security Class Initialized
DEBUG - 2021-06-26 11:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:26:36 --> Input Class Initialized
INFO - 2021-06-26 11:26:36 --> Language Class Initialized
INFO - 2021-06-26 11:26:36 --> Language Class Initialized
INFO - 2021-06-26 11:26:36 --> Config Class Initialized
INFO - 2021-06-26 11:26:36 --> Loader Class Initialized
INFO - 2021-06-26 11:26:36 --> Helper loaded: url_helper
INFO - 2021-06-26 11:26:36 --> Helper loaded: file_helper
INFO - 2021-06-26 11:26:36 --> Helper loaded: form_helper
INFO - 2021-06-26 11:26:36 --> Helper loaded: my_helper
INFO - 2021-06-26 11:26:36 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:26:36 --> Controller Class Initialized
DEBUG - 2021-06-26 11:26:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-26 11:26:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:26:36 --> Final output sent to browser
DEBUG - 2021-06-26 11:26:36 --> Total execution time: 0.0538
INFO - 2021-06-26 11:26:40 --> Config Class Initialized
INFO - 2021-06-26 11:26:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:26:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:26:40 --> Utf8 Class Initialized
INFO - 2021-06-26 11:26:40 --> URI Class Initialized
INFO - 2021-06-26 11:26:40 --> Router Class Initialized
INFO - 2021-06-26 11:26:40 --> Output Class Initialized
INFO - 2021-06-26 11:26:40 --> Security Class Initialized
DEBUG - 2021-06-26 11:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:26:40 --> Input Class Initialized
INFO - 2021-06-26 11:26:40 --> Language Class Initialized
INFO - 2021-06-26 11:26:40 --> Language Class Initialized
INFO - 2021-06-26 11:26:40 --> Config Class Initialized
INFO - 2021-06-26 11:26:40 --> Loader Class Initialized
INFO - 2021-06-26 11:26:40 --> Helper loaded: url_helper
INFO - 2021-06-26 11:26:40 --> Helper loaded: file_helper
INFO - 2021-06-26 11:26:40 --> Helper loaded: form_helper
INFO - 2021-06-26 11:26:40 --> Helper loaded: my_helper
INFO - 2021-06-26 11:26:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:26:40 --> Controller Class Initialized
INFO - 2021-06-26 11:26:40 --> Config Class Initialized
INFO - 2021-06-26 11:26:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:26:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:26:40 --> Utf8 Class Initialized
INFO - 2021-06-26 11:26:40 --> URI Class Initialized
INFO - 2021-06-26 11:26:40 --> Router Class Initialized
INFO - 2021-06-26 11:26:40 --> Output Class Initialized
INFO - 2021-06-26 11:26:40 --> Security Class Initialized
DEBUG - 2021-06-26 11:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:26:40 --> Input Class Initialized
INFO - 2021-06-26 11:26:40 --> Language Class Initialized
INFO - 2021-06-26 11:26:40 --> Language Class Initialized
INFO - 2021-06-26 11:26:40 --> Config Class Initialized
INFO - 2021-06-26 11:26:40 --> Loader Class Initialized
INFO - 2021-06-26 11:26:40 --> Helper loaded: url_helper
INFO - 2021-06-26 11:26:40 --> Helper loaded: file_helper
INFO - 2021-06-26 11:26:40 --> Helper loaded: form_helper
INFO - 2021-06-26 11:26:40 --> Helper loaded: my_helper
INFO - 2021-06-26 11:26:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:26:40 --> Controller Class Initialized
DEBUG - 2021-06-26 11:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:26:40 --> Final output sent to browser
DEBUG - 2021-06-26 11:26:40 --> Total execution time: 0.0530
INFO - 2021-06-26 11:26:40 --> Config Class Initialized
INFO - 2021-06-26 11:26:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:26:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:26:40 --> Utf8 Class Initialized
INFO - 2021-06-26 11:26:40 --> URI Class Initialized
INFO - 2021-06-26 11:26:40 --> Router Class Initialized
INFO - 2021-06-26 11:26:40 --> Output Class Initialized
INFO - 2021-06-26 11:26:40 --> Security Class Initialized
DEBUG - 2021-06-26 11:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:26:40 --> Input Class Initialized
INFO - 2021-06-26 11:26:40 --> Language Class Initialized
INFO - 2021-06-26 11:26:40 --> Language Class Initialized
INFO - 2021-06-26 11:26:40 --> Config Class Initialized
INFO - 2021-06-26 11:26:40 --> Loader Class Initialized
INFO - 2021-06-26 11:26:40 --> Helper loaded: url_helper
INFO - 2021-06-26 11:26:40 --> Helper loaded: file_helper
INFO - 2021-06-26 11:26:40 --> Helper loaded: form_helper
INFO - 2021-06-26 11:26:40 --> Helper loaded: my_helper
INFO - 2021-06-26 11:26:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:26:40 --> Controller Class Initialized
INFO - 2021-06-26 11:26:44 --> Config Class Initialized
INFO - 2021-06-26 11:26:44 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:26:44 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:26:44 --> Utf8 Class Initialized
INFO - 2021-06-26 11:26:44 --> URI Class Initialized
INFO - 2021-06-26 11:26:44 --> Router Class Initialized
INFO - 2021-06-26 11:26:44 --> Output Class Initialized
INFO - 2021-06-26 11:26:44 --> Security Class Initialized
DEBUG - 2021-06-26 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:26:44 --> Input Class Initialized
INFO - 2021-06-26 11:26:44 --> Language Class Initialized
INFO - 2021-06-26 11:26:44 --> Language Class Initialized
INFO - 2021-06-26 11:26:44 --> Config Class Initialized
INFO - 2021-06-26 11:26:44 --> Loader Class Initialized
INFO - 2021-06-26 11:26:44 --> Helper loaded: url_helper
INFO - 2021-06-26 11:26:44 --> Helper loaded: file_helper
INFO - 2021-06-26 11:26:44 --> Helper loaded: form_helper
INFO - 2021-06-26 11:26:44 --> Helper loaded: my_helper
INFO - 2021-06-26 11:26:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:26:44 --> Controller Class Initialized
DEBUG - 2021-06-26 11:26:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-26 11:26:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:26:44 --> Final output sent to browser
DEBUG - 2021-06-26 11:26:44 --> Total execution time: 0.0511
INFO - 2021-06-26 11:26:47 --> Config Class Initialized
INFO - 2021-06-26 11:26:47 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:26:47 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:26:47 --> Utf8 Class Initialized
INFO - 2021-06-26 11:26:47 --> URI Class Initialized
INFO - 2021-06-26 11:26:47 --> Router Class Initialized
INFO - 2021-06-26 11:26:47 --> Output Class Initialized
INFO - 2021-06-26 11:26:47 --> Security Class Initialized
DEBUG - 2021-06-26 11:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:26:47 --> Input Class Initialized
INFO - 2021-06-26 11:26:47 --> Language Class Initialized
INFO - 2021-06-26 11:26:47 --> Language Class Initialized
INFO - 2021-06-26 11:26:47 --> Config Class Initialized
INFO - 2021-06-26 11:26:47 --> Loader Class Initialized
INFO - 2021-06-26 11:26:47 --> Helper loaded: url_helper
INFO - 2021-06-26 11:26:47 --> Helper loaded: file_helper
INFO - 2021-06-26 11:26:47 --> Helper loaded: form_helper
INFO - 2021-06-26 11:26:47 --> Helper loaded: my_helper
INFO - 2021-06-26 11:26:47 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:26:47 --> Controller Class Initialized
INFO - 2021-06-26 11:26:47 --> Config Class Initialized
INFO - 2021-06-26 11:26:47 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:26:47 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:26:47 --> Utf8 Class Initialized
INFO - 2021-06-26 11:26:47 --> URI Class Initialized
INFO - 2021-06-26 11:26:47 --> Router Class Initialized
INFO - 2021-06-26 11:26:47 --> Output Class Initialized
INFO - 2021-06-26 11:26:47 --> Security Class Initialized
DEBUG - 2021-06-26 11:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:26:47 --> Input Class Initialized
INFO - 2021-06-26 11:26:47 --> Language Class Initialized
INFO - 2021-06-26 11:26:47 --> Language Class Initialized
INFO - 2021-06-26 11:26:47 --> Config Class Initialized
INFO - 2021-06-26 11:26:47 --> Loader Class Initialized
INFO - 2021-06-26 11:26:47 --> Helper loaded: url_helper
INFO - 2021-06-26 11:26:47 --> Helper loaded: file_helper
INFO - 2021-06-26 11:26:47 --> Helper loaded: form_helper
INFO - 2021-06-26 11:26:47 --> Helper loaded: my_helper
INFO - 2021-06-26 11:26:47 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:26:47 --> Controller Class Initialized
DEBUG - 2021-06-26 11:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:26:47 --> Final output sent to browser
DEBUG - 2021-06-26 11:26:47 --> Total execution time: 0.0519
INFO - 2021-06-26 11:26:57 --> Config Class Initialized
INFO - 2021-06-26 11:26:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:26:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:26:57 --> Utf8 Class Initialized
INFO - 2021-06-26 11:26:57 --> URI Class Initialized
INFO - 2021-06-26 11:26:57 --> Router Class Initialized
INFO - 2021-06-26 11:26:57 --> Output Class Initialized
INFO - 2021-06-26 11:26:57 --> Security Class Initialized
DEBUG - 2021-06-26 11:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:26:57 --> Input Class Initialized
INFO - 2021-06-26 11:26:57 --> Language Class Initialized
INFO - 2021-06-26 11:26:57 --> Language Class Initialized
INFO - 2021-06-26 11:26:57 --> Config Class Initialized
INFO - 2021-06-26 11:26:57 --> Loader Class Initialized
INFO - 2021-06-26 11:26:57 --> Helper loaded: url_helper
INFO - 2021-06-26 11:26:57 --> Helper loaded: file_helper
INFO - 2021-06-26 11:26:57 --> Helper loaded: form_helper
INFO - 2021-06-26 11:26:57 --> Helper loaded: my_helper
INFO - 2021-06-26 11:26:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:26:57 --> Controller Class Initialized
INFO - 2021-06-26 11:26:57 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:26:57 --> Config Class Initialized
INFO - 2021-06-26 11:26:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:26:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:26:57 --> Utf8 Class Initialized
INFO - 2021-06-26 11:26:57 --> URI Class Initialized
INFO - 2021-06-26 11:26:57 --> Router Class Initialized
INFO - 2021-06-26 11:26:57 --> Output Class Initialized
INFO - 2021-06-26 11:26:57 --> Security Class Initialized
DEBUG - 2021-06-26 11:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:26:57 --> Input Class Initialized
INFO - 2021-06-26 11:26:57 --> Language Class Initialized
INFO - 2021-06-26 11:26:57 --> Language Class Initialized
INFO - 2021-06-26 11:26:57 --> Config Class Initialized
INFO - 2021-06-26 11:26:57 --> Loader Class Initialized
INFO - 2021-06-26 11:26:57 --> Helper loaded: url_helper
INFO - 2021-06-26 11:26:57 --> Helper loaded: file_helper
INFO - 2021-06-26 11:26:57 --> Helper loaded: form_helper
INFO - 2021-06-26 11:26:57 --> Helper loaded: my_helper
INFO - 2021-06-26 11:26:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:26:57 --> Controller Class Initialized
DEBUG - 2021-06-26 11:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 11:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:26:57 --> Final output sent to browser
DEBUG - 2021-06-26 11:26:57 --> Total execution time: 0.0436
INFO - 2021-06-26 11:27:02 --> Config Class Initialized
INFO - 2021-06-26 11:27:02 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:27:02 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:27:02 --> Utf8 Class Initialized
INFO - 2021-06-26 11:27:02 --> URI Class Initialized
INFO - 2021-06-26 11:27:02 --> Router Class Initialized
INFO - 2021-06-26 11:27:02 --> Output Class Initialized
INFO - 2021-06-26 11:27:02 --> Security Class Initialized
DEBUG - 2021-06-26 11:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:27:02 --> Input Class Initialized
INFO - 2021-06-26 11:27:02 --> Language Class Initialized
INFO - 2021-06-26 11:27:02 --> Language Class Initialized
INFO - 2021-06-26 11:27:02 --> Config Class Initialized
INFO - 2021-06-26 11:27:02 --> Loader Class Initialized
INFO - 2021-06-26 11:27:02 --> Helper loaded: url_helper
INFO - 2021-06-26 11:27:02 --> Helper loaded: file_helper
INFO - 2021-06-26 11:27:02 --> Helper loaded: form_helper
INFO - 2021-06-26 11:27:02 --> Helper loaded: my_helper
INFO - 2021-06-26 11:27:02 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:27:02 --> Controller Class Initialized
INFO - 2021-06-26 11:27:02 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:27:02 --> Final output sent to browser
DEBUG - 2021-06-26 11:27:02 --> Total execution time: 0.0438
INFO - 2021-06-26 11:27:02 --> Config Class Initialized
INFO - 2021-06-26 11:27:02 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:27:02 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:27:02 --> Utf8 Class Initialized
INFO - 2021-06-26 11:27:02 --> URI Class Initialized
INFO - 2021-06-26 11:27:02 --> Router Class Initialized
INFO - 2021-06-26 11:27:02 --> Output Class Initialized
INFO - 2021-06-26 11:27:02 --> Security Class Initialized
DEBUG - 2021-06-26 11:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:27:02 --> Input Class Initialized
INFO - 2021-06-26 11:27:02 --> Language Class Initialized
INFO - 2021-06-26 11:27:02 --> Language Class Initialized
INFO - 2021-06-26 11:27:02 --> Config Class Initialized
INFO - 2021-06-26 11:27:02 --> Loader Class Initialized
INFO - 2021-06-26 11:27:02 --> Helper loaded: url_helper
INFO - 2021-06-26 11:27:02 --> Helper loaded: file_helper
INFO - 2021-06-26 11:27:02 --> Helper loaded: form_helper
INFO - 2021-06-26 11:27:02 --> Helper loaded: my_helper
INFO - 2021-06-26 11:27:02 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:27:02 --> Controller Class Initialized
DEBUG - 2021-06-26 11:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 11:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:27:03 --> Final output sent to browser
DEBUG - 2021-06-26 11:27:03 --> Total execution time: 0.6381
INFO - 2021-06-26 11:27:10 --> Config Class Initialized
INFO - 2021-06-26 11:27:10 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:27:10 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:27:10 --> Utf8 Class Initialized
INFO - 2021-06-26 11:27:10 --> URI Class Initialized
INFO - 2021-06-26 11:27:10 --> Router Class Initialized
INFO - 2021-06-26 11:27:10 --> Output Class Initialized
INFO - 2021-06-26 11:27:10 --> Security Class Initialized
DEBUG - 2021-06-26 11:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:27:10 --> Input Class Initialized
INFO - 2021-06-26 11:27:10 --> Language Class Initialized
INFO - 2021-06-26 11:27:10 --> Language Class Initialized
INFO - 2021-06-26 11:27:10 --> Config Class Initialized
INFO - 2021-06-26 11:27:10 --> Loader Class Initialized
INFO - 2021-06-26 11:27:10 --> Helper loaded: url_helper
INFO - 2021-06-26 11:27:10 --> Helper loaded: file_helper
INFO - 2021-06-26 11:27:10 --> Helper loaded: form_helper
INFO - 2021-06-26 11:27:10 --> Helper loaded: my_helper
INFO - 2021-06-26 11:27:10 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:27:10 --> Controller Class Initialized
DEBUG - 2021-06-26 11:27:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-26 11:27:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:27:10 --> Final output sent to browser
DEBUG - 2021-06-26 11:27:10 --> Total execution time: 0.0527
INFO - 2021-06-26 11:27:13 --> Config Class Initialized
INFO - 2021-06-26 11:27:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:27:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:27:13 --> Utf8 Class Initialized
INFO - 2021-06-26 11:27:13 --> URI Class Initialized
INFO - 2021-06-26 11:27:13 --> Router Class Initialized
INFO - 2021-06-26 11:27:13 --> Output Class Initialized
INFO - 2021-06-26 11:27:13 --> Security Class Initialized
DEBUG - 2021-06-26 11:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:27:13 --> Input Class Initialized
INFO - 2021-06-26 11:27:13 --> Language Class Initialized
INFO - 2021-06-26 11:27:13 --> Language Class Initialized
INFO - 2021-06-26 11:27:13 --> Config Class Initialized
INFO - 2021-06-26 11:27:13 --> Loader Class Initialized
INFO - 2021-06-26 11:27:13 --> Helper loaded: url_helper
INFO - 2021-06-26 11:27:13 --> Helper loaded: file_helper
INFO - 2021-06-26 11:27:13 --> Helper loaded: form_helper
INFO - 2021-06-26 11:27:13 --> Helper loaded: my_helper
INFO - 2021-06-26 11:27:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:27:13 --> Controller Class Initialized
DEBUG - 2021-06-26 11:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:27:13 --> Final output sent to browser
DEBUG - 2021-06-26 11:27:13 --> Total execution time: 0.0453
INFO - 2021-06-26 11:27:13 --> Config Class Initialized
INFO - 2021-06-26 11:27:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:27:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:27:13 --> Utf8 Class Initialized
INFO - 2021-06-26 11:27:13 --> URI Class Initialized
INFO - 2021-06-26 11:27:13 --> Router Class Initialized
INFO - 2021-06-26 11:27:13 --> Output Class Initialized
INFO - 2021-06-26 11:27:13 --> Security Class Initialized
DEBUG - 2021-06-26 11:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:27:13 --> Input Class Initialized
INFO - 2021-06-26 11:27:13 --> Language Class Initialized
INFO - 2021-06-26 11:27:13 --> Language Class Initialized
INFO - 2021-06-26 11:27:13 --> Config Class Initialized
INFO - 2021-06-26 11:27:13 --> Loader Class Initialized
INFO - 2021-06-26 11:27:13 --> Helper loaded: url_helper
INFO - 2021-06-26 11:27:13 --> Helper loaded: file_helper
INFO - 2021-06-26 11:27:13 --> Helper loaded: form_helper
INFO - 2021-06-26 11:27:13 --> Helper loaded: my_helper
INFO - 2021-06-26 11:27:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:27:13 --> Controller Class Initialized
INFO - 2021-06-26 11:27:14 --> Config Class Initialized
INFO - 2021-06-26 11:27:14 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:27:14 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:27:14 --> Utf8 Class Initialized
INFO - 2021-06-26 11:27:14 --> URI Class Initialized
INFO - 2021-06-26 11:27:14 --> Router Class Initialized
INFO - 2021-06-26 11:27:14 --> Output Class Initialized
INFO - 2021-06-26 11:27:14 --> Security Class Initialized
DEBUG - 2021-06-26 11:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:27:14 --> Input Class Initialized
INFO - 2021-06-26 11:27:14 --> Language Class Initialized
INFO - 2021-06-26 11:27:14 --> Language Class Initialized
INFO - 2021-06-26 11:27:14 --> Config Class Initialized
INFO - 2021-06-26 11:27:14 --> Loader Class Initialized
INFO - 2021-06-26 11:27:14 --> Helper loaded: url_helper
INFO - 2021-06-26 11:27:14 --> Helper loaded: file_helper
INFO - 2021-06-26 11:27:14 --> Helper loaded: form_helper
INFO - 2021-06-26 11:27:14 --> Helper loaded: my_helper
INFO - 2021-06-26 11:27:14 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:27:14 --> Controller Class Initialized
DEBUG - 2021-06-26 11:27:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:27:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:27:14 --> Final output sent to browser
DEBUG - 2021-06-26 11:27:14 --> Total execution time: 0.0458
INFO - 2021-06-26 11:27:17 --> Config Class Initialized
INFO - 2021-06-26 11:27:17 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:27:17 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:27:17 --> Utf8 Class Initialized
INFO - 2021-06-26 11:27:17 --> URI Class Initialized
INFO - 2021-06-26 11:27:17 --> Router Class Initialized
INFO - 2021-06-26 11:27:17 --> Output Class Initialized
INFO - 2021-06-26 11:27:17 --> Security Class Initialized
DEBUG - 2021-06-26 11:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:27:17 --> Input Class Initialized
INFO - 2021-06-26 11:27:17 --> Language Class Initialized
INFO - 2021-06-26 11:27:17 --> Language Class Initialized
INFO - 2021-06-26 11:27:17 --> Config Class Initialized
INFO - 2021-06-26 11:27:17 --> Loader Class Initialized
INFO - 2021-06-26 11:27:17 --> Helper loaded: url_helper
INFO - 2021-06-26 11:27:17 --> Helper loaded: file_helper
INFO - 2021-06-26 11:27:17 --> Helper loaded: form_helper
INFO - 2021-06-26 11:27:17 --> Helper loaded: my_helper
INFO - 2021-06-26 11:27:17 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:27:17 --> Controller Class Initialized
INFO - 2021-06-26 11:27:19 --> Config Class Initialized
INFO - 2021-06-26 11:27:19 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:27:19 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:27:19 --> Utf8 Class Initialized
INFO - 2021-06-26 11:27:19 --> URI Class Initialized
INFO - 2021-06-26 11:27:19 --> Router Class Initialized
INFO - 2021-06-26 11:27:19 --> Output Class Initialized
INFO - 2021-06-26 11:27:19 --> Security Class Initialized
DEBUG - 2021-06-26 11:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:27:19 --> Input Class Initialized
INFO - 2021-06-26 11:27:19 --> Language Class Initialized
INFO - 2021-06-26 11:27:19 --> Language Class Initialized
INFO - 2021-06-26 11:27:19 --> Config Class Initialized
INFO - 2021-06-26 11:27:19 --> Loader Class Initialized
INFO - 2021-06-26 11:27:19 --> Helper loaded: url_helper
INFO - 2021-06-26 11:27:19 --> Helper loaded: file_helper
INFO - 2021-06-26 11:27:19 --> Helper loaded: form_helper
INFO - 2021-06-26 11:27:19 --> Helper loaded: my_helper
INFO - 2021-06-26 11:27:19 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:27:19 --> Controller Class Initialized
INFO - 2021-06-26 11:28:12 --> Config Class Initialized
INFO - 2021-06-26 11:28:12 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:12 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:12 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:12 --> URI Class Initialized
INFO - 2021-06-26 11:28:12 --> Router Class Initialized
INFO - 2021-06-26 11:28:12 --> Output Class Initialized
INFO - 2021-06-26 11:28:12 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:12 --> Input Class Initialized
INFO - 2021-06-26 11:28:12 --> Language Class Initialized
INFO - 2021-06-26 11:28:12 --> Language Class Initialized
INFO - 2021-06-26 11:28:12 --> Config Class Initialized
INFO - 2021-06-26 11:28:12 --> Loader Class Initialized
INFO - 2021-06-26 11:28:12 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:12 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:12 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:12 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:12 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:12 --> Controller Class Initialized
DEBUG - 2021-06-26 11:28:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-26 11:28:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:28:12 --> Final output sent to browser
DEBUG - 2021-06-26 11:28:12 --> Total execution time: 0.0536
INFO - 2021-06-26 11:28:16 --> Config Class Initialized
INFO - 2021-06-26 11:28:16 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:16 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:16 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:16 --> URI Class Initialized
INFO - 2021-06-26 11:28:16 --> Router Class Initialized
INFO - 2021-06-26 11:28:16 --> Output Class Initialized
INFO - 2021-06-26 11:28:16 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:16 --> Input Class Initialized
INFO - 2021-06-26 11:28:16 --> Language Class Initialized
INFO - 2021-06-26 11:28:16 --> Language Class Initialized
INFO - 2021-06-26 11:28:16 --> Config Class Initialized
INFO - 2021-06-26 11:28:16 --> Loader Class Initialized
INFO - 2021-06-26 11:28:16 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:16 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:16 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:16 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:16 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:16 --> Controller Class Initialized
INFO - 2021-06-26 11:28:16 --> Config Class Initialized
INFO - 2021-06-26 11:28:16 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:16 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:16 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:16 --> URI Class Initialized
INFO - 2021-06-26 11:28:16 --> Router Class Initialized
INFO - 2021-06-26 11:28:16 --> Output Class Initialized
INFO - 2021-06-26 11:28:16 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:16 --> Input Class Initialized
INFO - 2021-06-26 11:28:16 --> Language Class Initialized
INFO - 2021-06-26 11:28:16 --> Language Class Initialized
INFO - 2021-06-26 11:28:16 --> Config Class Initialized
INFO - 2021-06-26 11:28:16 --> Loader Class Initialized
INFO - 2021-06-26 11:28:16 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:16 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:16 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:16 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:16 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:16 --> Controller Class Initialized
DEBUG - 2021-06-26 11:28:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:28:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:28:16 --> Final output sent to browser
DEBUG - 2021-06-26 11:28:16 --> Total execution time: 0.0527
INFO - 2021-06-26 11:28:16 --> Config Class Initialized
INFO - 2021-06-26 11:28:16 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:16 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:16 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:16 --> URI Class Initialized
INFO - 2021-06-26 11:28:17 --> Router Class Initialized
INFO - 2021-06-26 11:28:17 --> Output Class Initialized
INFO - 2021-06-26 11:28:17 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:17 --> Input Class Initialized
INFO - 2021-06-26 11:28:17 --> Language Class Initialized
INFO - 2021-06-26 11:28:17 --> Language Class Initialized
INFO - 2021-06-26 11:28:17 --> Config Class Initialized
INFO - 2021-06-26 11:28:17 --> Loader Class Initialized
INFO - 2021-06-26 11:28:17 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:17 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:17 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:17 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:17 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:17 --> Controller Class Initialized
INFO - 2021-06-26 11:28:18 --> Config Class Initialized
INFO - 2021-06-26 11:28:18 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:18 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:18 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:18 --> URI Class Initialized
INFO - 2021-06-26 11:28:18 --> Router Class Initialized
INFO - 2021-06-26 11:28:18 --> Output Class Initialized
INFO - 2021-06-26 11:28:18 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:18 --> Input Class Initialized
INFO - 2021-06-26 11:28:18 --> Language Class Initialized
INFO - 2021-06-26 11:28:18 --> Language Class Initialized
INFO - 2021-06-26 11:28:18 --> Config Class Initialized
INFO - 2021-06-26 11:28:18 --> Loader Class Initialized
INFO - 2021-06-26 11:28:18 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:18 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:18 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:18 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:18 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:18 --> Controller Class Initialized
DEBUG - 2021-06-26 11:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-26 11:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:28:18 --> Final output sent to browser
DEBUG - 2021-06-26 11:28:18 --> Total execution time: 0.0517
INFO - 2021-06-26 11:28:21 --> Config Class Initialized
INFO - 2021-06-26 11:28:21 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:21 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:21 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:21 --> URI Class Initialized
INFO - 2021-06-26 11:28:21 --> Router Class Initialized
INFO - 2021-06-26 11:28:21 --> Output Class Initialized
INFO - 2021-06-26 11:28:21 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:21 --> Input Class Initialized
INFO - 2021-06-26 11:28:21 --> Language Class Initialized
INFO - 2021-06-26 11:28:21 --> Language Class Initialized
INFO - 2021-06-26 11:28:21 --> Config Class Initialized
INFO - 2021-06-26 11:28:21 --> Loader Class Initialized
INFO - 2021-06-26 11:28:21 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:21 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:21 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:21 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:21 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:21 --> Controller Class Initialized
INFO - 2021-06-26 11:28:21 --> Config Class Initialized
INFO - 2021-06-26 11:28:21 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:21 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:21 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:21 --> URI Class Initialized
INFO - 2021-06-26 11:28:21 --> Router Class Initialized
INFO - 2021-06-26 11:28:21 --> Output Class Initialized
INFO - 2021-06-26 11:28:21 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:21 --> Input Class Initialized
INFO - 2021-06-26 11:28:21 --> Language Class Initialized
INFO - 2021-06-26 11:28:21 --> Language Class Initialized
INFO - 2021-06-26 11:28:21 --> Config Class Initialized
INFO - 2021-06-26 11:28:21 --> Loader Class Initialized
INFO - 2021-06-26 11:28:21 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:21 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:21 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:21 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:21 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:21 --> Controller Class Initialized
DEBUG - 2021-06-26 11:28:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:28:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:28:21 --> Final output sent to browser
DEBUG - 2021-06-26 11:28:21 --> Total execution time: 0.0517
INFO - 2021-06-26 11:28:26 --> Config Class Initialized
INFO - 2021-06-26 11:28:26 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:26 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:26 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:26 --> URI Class Initialized
INFO - 2021-06-26 11:28:26 --> Router Class Initialized
INFO - 2021-06-26 11:28:26 --> Output Class Initialized
INFO - 2021-06-26 11:28:26 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:26 --> Input Class Initialized
INFO - 2021-06-26 11:28:26 --> Language Class Initialized
INFO - 2021-06-26 11:28:26 --> Language Class Initialized
INFO - 2021-06-26 11:28:26 --> Config Class Initialized
INFO - 2021-06-26 11:28:26 --> Loader Class Initialized
INFO - 2021-06-26 11:28:26 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:26 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:26 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:26 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:26 --> Controller Class Initialized
DEBUG - 2021-06-26 11:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:28:26 --> Final output sent to browser
DEBUG - 2021-06-26 11:28:26 --> Total execution time: 0.0449
INFO - 2021-06-26 11:28:26 --> Config Class Initialized
INFO - 2021-06-26 11:28:26 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:26 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:26 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:26 --> URI Class Initialized
INFO - 2021-06-26 11:28:26 --> Router Class Initialized
INFO - 2021-06-26 11:28:26 --> Output Class Initialized
INFO - 2021-06-26 11:28:26 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:26 --> Input Class Initialized
INFO - 2021-06-26 11:28:26 --> Language Class Initialized
INFO - 2021-06-26 11:28:26 --> Language Class Initialized
INFO - 2021-06-26 11:28:26 --> Config Class Initialized
INFO - 2021-06-26 11:28:26 --> Loader Class Initialized
INFO - 2021-06-26 11:28:26 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:26 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:26 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:26 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:26 --> Controller Class Initialized
INFO - 2021-06-26 11:28:27 --> Config Class Initialized
INFO - 2021-06-26 11:28:27 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:27 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:27 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:27 --> URI Class Initialized
INFO - 2021-06-26 11:28:27 --> Router Class Initialized
INFO - 2021-06-26 11:28:27 --> Output Class Initialized
INFO - 2021-06-26 11:28:27 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:27 --> Input Class Initialized
INFO - 2021-06-26 11:28:27 --> Language Class Initialized
INFO - 2021-06-26 11:28:27 --> Language Class Initialized
INFO - 2021-06-26 11:28:27 --> Config Class Initialized
INFO - 2021-06-26 11:28:27 --> Loader Class Initialized
INFO - 2021-06-26 11:28:27 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:27 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:27 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:27 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:27 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:27 --> Controller Class Initialized
DEBUG - 2021-06-26 11:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:28:27 --> Final output sent to browser
DEBUG - 2021-06-26 11:28:27 --> Total execution time: 0.0451
INFO - 2021-06-26 11:28:29 --> Config Class Initialized
INFO - 2021-06-26 11:28:29 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:29 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:29 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:29 --> URI Class Initialized
INFO - 2021-06-26 11:28:29 --> Router Class Initialized
INFO - 2021-06-26 11:28:29 --> Output Class Initialized
INFO - 2021-06-26 11:28:29 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:29 --> Input Class Initialized
INFO - 2021-06-26 11:28:29 --> Language Class Initialized
INFO - 2021-06-26 11:28:29 --> Language Class Initialized
INFO - 2021-06-26 11:28:29 --> Config Class Initialized
INFO - 2021-06-26 11:28:29 --> Loader Class Initialized
INFO - 2021-06-26 11:28:29 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:29 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:29 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:29 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:29 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:29 --> Controller Class Initialized
INFO - 2021-06-26 11:28:29 --> Final output sent to browser
DEBUG - 2021-06-26 11:28:29 --> Total execution time: 0.1039
INFO - 2021-06-26 11:28:36 --> Config Class Initialized
INFO - 2021-06-26 11:28:36 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:36 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:36 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:36 --> URI Class Initialized
INFO - 2021-06-26 11:28:36 --> Router Class Initialized
INFO - 2021-06-26 11:28:36 --> Output Class Initialized
INFO - 2021-06-26 11:28:36 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:36 --> Input Class Initialized
INFO - 2021-06-26 11:28:36 --> Language Class Initialized
INFO - 2021-06-26 11:28:36 --> Language Class Initialized
INFO - 2021-06-26 11:28:36 --> Config Class Initialized
INFO - 2021-06-26 11:28:36 --> Loader Class Initialized
INFO - 2021-06-26 11:28:36 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:36 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:36 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:36 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:36 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:36 --> Controller Class Initialized
INFO - 2021-06-26 11:28:38 --> Config Class Initialized
INFO - 2021-06-26 11:28:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:28:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:28:38 --> Utf8 Class Initialized
INFO - 2021-06-26 11:28:38 --> URI Class Initialized
INFO - 2021-06-26 11:28:38 --> Router Class Initialized
INFO - 2021-06-26 11:28:38 --> Output Class Initialized
INFO - 2021-06-26 11:28:38 --> Security Class Initialized
DEBUG - 2021-06-26 11:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:28:38 --> Input Class Initialized
INFO - 2021-06-26 11:28:38 --> Language Class Initialized
INFO - 2021-06-26 11:28:38 --> Language Class Initialized
INFO - 2021-06-26 11:28:38 --> Config Class Initialized
INFO - 2021-06-26 11:28:38 --> Loader Class Initialized
INFO - 2021-06-26 11:28:38 --> Helper loaded: url_helper
INFO - 2021-06-26 11:28:38 --> Helper loaded: file_helper
INFO - 2021-06-26 11:28:38 --> Helper loaded: form_helper
INFO - 2021-06-26 11:28:38 --> Helper loaded: my_helper
INFO - 2021-06-26 11:28:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:28:38 --> Controller Class Initialized
INFO - 2021-06-26 11:29:35 --> Config Class Initialized
INFO - 2021-06-26 11:29:35 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:29:35 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:29:35 --> Utf8 Class Initialized
INFO - 2021-06-26 11:29:35 --> URI Class Initialized
INFO - 2021-06-26 11:29:35 --> Router Class Initialized
INFO - 2021-06-26 11:29:35 --> Output Class Initialized
INFO - 2021-06-26 11:29:35 --> Security Class Initialized
DEBUG - 2021-06-26 11:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:29:35 --> Input Class Initialized
INFO - 2021-06-26 11:29:35 --> Language Class Initialized
INFO - 2021-06-26 11:29:35 --> Language Class Initialized
INFO - 2021-06-26 11:29:35 --> Config Class Initialized
INFO - 2021-06-26 11:29:35 --> Loader Class Initialized
INFO - 2021-06-26 11:29:35 --> Helper loaded: url_helper
INFO - 2021-06-26 11:29:35 --> Helper loaded: file_helper
INFO - 2021-06-26 11:29:35 --> Helper loaded: form_helper
INFO - 2021-06-26 11:29:35 --> Helper loaded: my_helper
INFO - 2021-06-26 11:29:35 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:29:35 --> Controller Class Initialized
DEBUG - 2021-06-26 11:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-26 11:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:29:35 --> Final output sent to browser
DEBUG - 2021-06-26 11:29:35 --> Total execution time: 0.0534
INFO - 2021-06-26 11:29:38 --> Config Class Initialized
INFO - 2021-06-26 11:29:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:29:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:29:38 --> Utf8 Class Initialized
INFO - 2021-06-26 11:29:38 --> URI Class Initialized
INFO - 2021-06-26 11:29:38 --> Router Class Initialized
INFO - 2021-06-26 11:29:38 --> Output Class Initialized
INFO - 2021-06-26 11:29:38 --> Security Class Initialized
DEBUG - 2021-06-26 11:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:29:38 --> Input Class Initialized
INFO - 2021-06-26 11:29:38 --> Language Class Initialized
INFO - 2021-06-26 11:29:38 --> Language Class Initialized
INFO - 2021-06-26 11:29:38 --> Config Class Initialized
INFO - 2021-06-26 11:29:38 --> Loader Class Initialized
INFO - 2021-06-26 11:29:38 --> Helper loaded: url_helper
INFO - 2021-06-26 11:29:38 --> Helper loaded: file_helper
INFO - 2021-06-26 11:29:38 --> Helper loaded: form_helper
INFO - 2021-06-26 11:29:38 --> Helper loaded: my_helper
INFO - 2021-06-26 11:29:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:29:38 --> Controller Class Initialized
INFO - 2021-06-26 11:29:38 --> Config Class Initialized
INFO - 2021-06-26 11:29:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:29:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:29:38 --> Utf8 Class Initialized
INFO - 2021-06-26 11:29:38 --> URI Class Initialized
INFO - 2021-06-26 11:29:38 --> Router Class Initialized
INFO - 2021-06-26 11:29:38 --> Output Class Initialized
INFO - 2021-06-26 11:29:38 --> Security Class Initialized
DEBUG - 2021-06-26 11:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:29:38 --> Input Class Initialized
INFO - 2021-06-26 11:29:38 --> Language Class Initialized
INFO - 2021-06-26 11:29:38 --> Language Class Initialized
INFO - 2021-06-26 11:29:38 --> Config Class Initialized
INFO - 2021-06-26 11:29:38 --> Loader Class Initialized
INFO - 2021-06-26 11:29:38 --> Helper loaded: url_helper
INFO - 2021-06-26 11:29:38 --> Helper loaded: file_helper
INFO - 2021-06-26 11:29:38 --> Helper loaded: form_helper
INFO - 2021-06-26 11:29:38 --> Helper loaded: my_helper
INFO - 2021-06-26 11:29:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:29:38 --> Controller Class Initialized
DEBUG - 2021-06-26 11:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:29:38 --> Final output sent to browser
DEBUG - 2021-06-26 11:29:38 --> Total execution time: 0.0434
INFO - 2021-06-26 11:29:38 --> Config Class Initialized
INFO - 2021-06-26 11:29:38 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:29:38 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:29:38 --> Utf8 Class Initialized
INFO - 2021-06-26 11:29:38 --> URI Class Initialized
INFO - 2021-06-26 11:29:38 --> Router Class Initialized
INFO - 2021-06-26 11:29:38 --> Output Class Initialized
INFO - 2021-06-26 11:29:38 --> Security Class Initialized
DEBUG - 2021-06-26 11:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:29:38 --> Input Class Initialized
INFO - 2021-06-26 11:29:38 --> Language Class Initialized
INFO - 2021-06-26 11:29:38 --> Language Class Initialized
INFO - 2021-06-26 11:29:38 --> Config Class Initialized
INFO - 2021-06-26 11:29:38 --> Loader Class Initialized
INFO - 2021-06-26 11:29:38 --> Helper loaded: url_helper
INFO - 2021-06-26 11:29:38 --> Helper loaded: file_helper
INFO - 2021-06-26 11:29:38 --> Helper loaded: form_helper
INFO - 2021-06-26 11:29:38 --> Helper loaded: my_helper
INFO - 2021-06-26 11:29:38 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:29:38 --> Controller Class Initialized
INFO - 2021-06-26 11:29:40 --> Config Class Initialized
INFO - 2021-06-26 11:29:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:29:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:29:40 --> Utf8 Class Initialized
INFO - 2021-06-26 11:29:40 --> URI Class Initialized
INFO - 2021-06-26 11:29:40 --> Router Class Initialized
INFO - 2021-06-26 11:29:40 --> Output Class Initialized
INFO - 2021-06-26 11:29:40 --> Security Class Initialized
DEBUG - 2021-06-26 11:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:29:40 --> Input Class Initialized
INFO - 2021-06-26 11:29:40 --> Language Class Initialized
INFO - 2021-06-26 11:29:40 --> Language Class Initialized
INFO - 2021-06-26 11:29:40 --> Config Class Initialized
INFO - 2021-06-26 11:29:40 --> Loader Class Initialized
INFO - 2021-06-26 11:29:40 --> Helper loaded: url_helper
INFO - 2021-06-26 11:29:40 --> Helper loaded: file_helper
INFO - 2021-06-26 11:29:40 --> Helper loaded: form_helper
INFO - 2021-06-26 11:29:40 --> Helper loaded: my_helper
INFO - 2021-06-26 11:29:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:29:40 --> Controller Class Initialized
DEBUG - 2021-06-26 11:29:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-26 11:29:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:29:40 --> Final output sent to browser
DEBUG - 2021-06-26 11:29:40 --> Total execution time: 0.0506
INFO - 2021-06-26 11:29:42 --> Config Class Initialized
INFO - 2021-06-26 11:29:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:29:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:29:42 --> Utf8 Class Initialized
INFO - 2021-06-26 11:29:42 --> URI Class Initialized
INFO - 2021-06-26 11:29:42 --> Router Class Initialized
INFO - 2021-06-26 11:29:42 --> Output Class Initialized
INFO - 2021-06-26 11:29:42 --> Security Class Initialized
DEBUG - 2021-06-26 11:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:29:42 --> Input Class Initialized
INFO - 2021-06-26 11:29:42 --> Language Class Initialized
INFO - 2021-06-26 11:29:42 --> Language Class Initialized
INFO - 2021-06-26 11:29:42 --> Config Class Initialized
INFO - 2021-06-26 11:29:42 --> Loader Class Initialized
INFO - 2021-06-26 11:29:42 --> Helper loaded: url_helper
INFO - 2021-06-26 11:29:42 --> Helper loaded: file_helper
INFO - 2021-06-26 11:29:42 --> Helper loaded: form_helper
INFO - 2021-06-26 11:29:42 --> Helper loaded: my_helper
INFO - 2021-06-26 11:29:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:29:42 --> Controller Class Initialized
INFO - 2021-06-26 11:29:42 --> Config Class Initialized
INFO - 2021-06-26 11:29:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:29:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:29:42 --> Utf8 Class Initialized
INFO - 2021-06-26 11:29:42 --> URI Class Initialized
INFO - 2021-06-26 11:29:42 --> Router Class Initialized
INFO - 2021-06-26 11:29:42 --> Output Class Initialized
INFO - 2021-06-26 11:29:42 --> Security Class Initialized
DEBUG - 2021-06-26 11:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:29:42 --> Input Class Initialized
INFO - 2021-06-26 11:29:42 --> Language Class Initialized
INFO - 2021-06-26 11:29:42 --> Language Class Initialized
INFO - 2021-06-26 11:29:42 --> Config Class Initialized
INFO - 2021-06-26 11:29:42 --> Loader Class Initialized
INFO - 2021-06-26 11:29:42 --> Helper loaded: url_helper
INFO - 2021-06-26 11:29:42 --> Helper loaded: file_helper
INFO - 2021-06-26 11:29:42 --> Helper loaded: form_helper
INFO - 2021-06-26 11:29:42 --> Helper loaded: my_helper
INFO - 2021-06-26 11:29:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:29:42 --> Controller Class Initialized
DEBUG - 2021-06-26 11:29:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:29:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:29:42 --> Final output sent to browser
DEBUG - 2021-06-26 11:29:42 --> Total execution time: 0.0456
INFO - 2021-06-26 11:29:47 --> Config Class Initialized
INFO - 2021-06-26 11:29:47 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:29:47 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:29:47 --> Utf8 Class Initialized
INFO - 2021-06-26 11:29:47 --> URI Class Initialized
INFO - 2021-06-26 11:29:47 --> Router Class Initialized
INFO - 2021-06-26 11:29:47 --> Output Class Initialized
INFO - 2021-06-26 11:29:47 --> Security Class Initialized
DEBUG - 2021-06-26 11:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:29:47 --> Input Class Initialized
INFO - 2021-06-26 11:29:47 --> Language Class Initialized
INFO - 2021-06-26 11:29:47 --> Language Class Initialized
INFO - 2021-06-26 11:29:47 --> Config Class Initialized
INFO - 2021-06-26 11:29:47 --> Loader Class Initialized
INFO - 2021-06-26 11:29:47 --> Helper loaded: url_helper
INFO - 2021-06-26 11:29:47 --> Helper loaded: file_helper
INFO - 2021-06-26 11:29:47 --> Helper loaded: form_helper
INFO - 2021-06-26 11:29:47 --> Helper loaded: my_helper
INFO - 2021-06-26 11:29:47 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:29:47 --> Controller Class Initialized
INFO - 2021-06-26 11:29:47 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:29:47 --> Config Class Initialized
INFO - 2021-06-26 11:29:47 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:29:47 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:29:47 --> Utf8 Class Initialized
INFO - 2021-06-26 11:29:47 --> URI Class Initialized
INFO - 2021-06-26 11:29:47 --> Router Class Initialized
INFO - 2021-06-26 11:29:47 --> Output Class Initialized
INFO - 2021-06-26 11:29:47 --> Security Class Initialized
DEBUG - 2021-06-26 11:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:29:47 --> Input Class Initialized
INFO - 2021-06-26 11:29:47 --> Language Class Initialized
INFO - 2021-06-26 11:29:47 --> Language Class Initialized
INFO - 2021-06-26 11:29:47 --> Config Class Initialized
INFO - 2021-06-26 11:29:47 --> Loader Class Initialized
INFO - 2021-06-26 11:29:47 --> Helper loaded: url_helper
INFO - 2021-06-26 11:29:47 --> Helper loaded: file_helper
INFO - 2021-06-26 11:29:47 --> Helper loaded: form_helper
INFO - 2021-06-26 11:29:47 --> Helper loaded: my_helper
INFO - 2021-06-26 11:29:47 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:29:47 --> Controller Class Initialized
DEBUG - 2021-06-26 11:29:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 11:29:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:29:47 --> Final output sent to browser
DEBUG - 2021-06-26 11:29:47 --> Total execution time: 0.0481
INFO - 2021-06-26 11:30:04 --> Config Class Initialized
INFO - 2021-06-26 11:30:04 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:30:04 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:30:04 --> Utf8 Class Initialized
INFO - 2021-06-26 11:30:04 --> URI Class Initialized
INFO - 2021-06-26 11:30:04 --> Router Class Initialized
INFO - 2021-06-26 11:30:04 --> Output Class Initialized
INFO - 2021-06-26 11:30:04 --> Security Class Initialized
DEBUG - 2021-06-26 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:30:04 --> Input Class Initialized
INFO - 2021-06-26 11:30:04 --> Language Class Initialized
INFO - 2021-06-26 11:30:04 --> Language Class Initialized
INFO - 2021-06-26 11:30:04 --> Config Class Initialized
INFO - 2021-06-26 11:30:04 --> Loader Class Initialized
INFO - 2021-06-26 11:30:04 --> Helper loaded: url_helper
INFO - 2021-06-26 11:30:04 --> Helper loaded: file_helper
INFO - 2021-06-26 11:30:04 --> Helper loaded: form_helper
INFO - 2021-06-26 11:30:04 --> Helper loaded: my_helper
INFO - 2021-06-26 11:30:04 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:30:04 --> Controller Class Initialized
INFO - 2021-06-26 11:30:04 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:30:04 --> Final output sent to browser
DEBUG - 2021-06-26 11:30:04 --> Total execution time: 0.0434
INFO - 2021-06-26 11:30:04 --> Config Class Initialized
INFO - 2021-06-26 11:30:04 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:30:04 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:30:04 --> Utf8 Class Initialized
INFO - 2021-06-26 11:30:04 --> URI Class Initialized
INFO - 2021-06-26 11:30:04 --> Router Class Initialized
INFO - 2021-06-26 11:30:04 --> Output Class Initialized
INFO - 2021-06-26 11:30:04 --> Security Class Initialized
DEBUG - 2021-06-26 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:30:04 --> Input Class Initialized
INFO - 2021-06-26 11:30:04 --> Language Class Initialized
INFO - 2021-06-26 11:30:04 --> Language Class Initialized
INFO - 2021-06-26 11:30:04 --> Config Class Initialized
INFO - 2021-06-26 11:30:04 --> Loader Class Initialized
INFO - 2021-06-26 11:30:04 --> Helper loaded: url_helper
INFO - 2021-06-26 11:30:04 --> Helper loaded: file_helper
INFO - 2021-06-26 11:30:04 --> Helper loaded: form_helper
INFO - 2021-06-26 11:30:04 --> Helper loaded: my_helper
INFO - 2021-06-26 11:30:04 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:30:04 --> Controller Class Initialized
DEBUG - 2021-06-26 11:30:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 11:30:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:30:05 --> Final output sent to browser
DEBUG - 2021-06-26 11:30:05 --> Total execution time: 0.6287
INFO - 2021-06-26 11:30:11 --> Config Class Initialized
INFO - 2021-06-26 11:30:11 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:30:11 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:30:11 --> Utf8 Class Initialized
INFO - 2021-06-26 11:30:11 --> URI Class Initialized
INFO - 2021-06-26 11:30:11 --> Router Class Initialized
INFO - 2021-06-26 11:30:11 --> Output Class Initialized
INFO - 2021-06-26 11:30:11 --> Security Class Initialized
DEBUG - 2021-06-26 11:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:30:11 --> Input Class Initialized
INFO - 2021-06-26 11:30:11 --> Language Class Initialized
INFO - 2021-06-26 11:30:12 --> Language Class Initialized
INFO - 2021-06-26 11:30:12 --> Config Class Initialized
INFO - 2021-06-26 11:30:12 --> Loader Class Initialized
INFO - 2021-06-26 11:30:12 --> Helper loaded: url_helper
INFO - 2021-06-26 11:30:12 --> Helper loaded: file_helper
INFO - 2021-06-26 11:30:12 --> Helper loaded: form_helper
INFO - 2021-06-26 11:30:12 --> Helper loaded: my_helper
INFO - 2021-06-26 11:30:12 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:30:12 --> Controller Class Initialized
DEBUG - 2021-06-26 11:30:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-26 11:30:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:30:12 --> Final output sent to browser
DEBUG - 2021-06-26 11:30:12 --> Total execution time: 0.0518
INFO - 2021-06-26 11:30:13 --> Config Class Initialized
INFO - 2021-06-26 11:30:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:30:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:30:13 --> Utf8 Class Initialized
INFO - 2021-06-26 11:30:13 --> URI Class Initialized
INFO - 2021-06-26 11:30:13 --> Router Class Initialized
INFO - 2021-06-26 11:30:13 --> Output Class Initialized
INFO - 2021-06-26 11:30:13 --> Security Class Initialized
DEBUG - 2021-06-26 11:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:30:13 --> Input Class Initialized
INFO - 2021-06-26 11:30:13 --> Language Class Initialized
INFO - 2021-06-26 11:30:13 --> Language Class Initialized
INFO - 2021-06-26 11:30:13 --> Config Class Initialized
INFO - 2021-06-26 11:30:13 --> Loader Class Initialized
INFO - 2021-06-26 11:30:13 --> Helper loaded: url_helper
INFO - 2021-06-26 11:30:13 --> Helper loaded: file_helper
INFO - 2021-06-26 11:30:13 --> Helper loaded: form_helper
INFO - 2021-06-26 11:30:13 --> Helper loaded: my_helper
INFO - 2021-06-26 11:30:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:30:13 --> Controller Class Initialized
DEBUG - 2021-06-26 11:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-26 11:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:30:13 --> Final output sent to browser
DEBUG - 2021-06-26 11:30:13 --> Total execution time: 0.0506
INFO - 2021-06-26 11:30:15 --> Config Class Initialized
INFO - 2021-06-26 11:30:15 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:30:15 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:30:15 --> Utf8 Class Initialized
INFO - 2021-06-26 11:30:15 --> URI Class Initialized
INFO - 2021-06-26 11:30:15 --> Router Class Initialized
INFO - 2021-06-26 11:30:15 --> Output Class Initialized
INFO - 2021-06-26 11:30:15 --> Security Class Initialized
DEBUG - 2021-06-26 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:30:15 --> Input Class Initialized
INFO - 2021-06-26 11:30:15 --> Language Class Initialized
INFO - 2021-06-26 11:30:15 --> Language Class Initialized
INFO - 2021-06-26 11:30:15 --> Config Class Initialized
INFO - 2021-06-26 11:30:15 --> Loader Class Initialized
INFO - 2021-06-26 11:30:15 --> Helper loaded: url_helper
INFO - 2021-06-26 11:30:15 --> Helper loaded: file_helper
INFO - 2021-06-26 11:30:15 --> Helper loaded: form_helper
INFO - 2021-06-26 11:30:15 --> Helper loaded: my_helper
INFO - 2021-06-26 11:30:15 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:30:15 --> Controller Class Initialized
DEBUG - 2021-06-26 11:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:30:15 --> Final output sent to browser
DEBUG - 2021-06-26 11:30:15 --> Total execution time: 0.0456
INFO - 2021-06-26 11:30:15 --> Config Class Initialized
INFO - 2021-06-26 11:30:15 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:30:15 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:30:15 --> Utf8 Class Initialized
INFO - 2021-06-26 11:30:15 --> URI Class Initialized
INFO - 2021-06-26 11:30:15 --> Router Class Initialized
INFO - 2021-06-26 11:30:15 --> Output Class Initialized
INFO - 2021-06-26 11:30:15 --> Security Class Initialized
DEBUG - 2021-06-26 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:30:15 --> Input Class Initialized
INFO - 2021-06-26 11:30:15 --> Language Class Initialized
INFO - 2021-06-26 11:30:15 --> Language Class Initialized
INFO - 2021-06-26 11:30:15 --> Config Class Initialized
INFO - 2021-06-26 11:30:15 --> Loader Class Initialized
INFO - 2021-06-26 11:30:15 --> Helper loaded: url_helper
INFO - 2021-06-26 11:30:15 --> Helper loaded: file_helper
INFO - 2021-06-26 11:30:15 --> Helper loaded: form_helper
INFO - 2021-06-26 11:30:15 --> Helper loaded: my_helper
INFO - 2021-06-26 11:30:15 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:30:15 --> Controller Class Initialized
INFO - 2021-06-26 11:30:16 --> Config Class Initialized
INFO - 2021-06-26 11:30:16 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:30:16 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:30:16 --> Utf8 Class Initialized
INFO - 2021-06-26 11:30:16 --> URI Class Initialized
INFO - 2021-06-26 11:30:16 --> Router Class Initialized
INFO - 2021-06-26 11:30:16 --> Output Class Initialized
INFO - 2021-06-26 11:30:16 --> Security Class Initialized
DEBUG - 2021-06-26 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:30:16 --> Input Class Initialized
INFO - 2021-06-26 11:30:16 --> Language Class Initialized
INFO - 2021-06-26 11:30:16 --> Language Class Initialized
INFO - 2021-06-26 11:30:16 --> Config Class Initialized
INFO - 2021-06-26 11:30:16 --> Loader Class Initialized
INFO - 2021-06-26 11:30:16 --> Helper loaded: url_helper
INFO - 2021-06-26 11:30:16 --> Helper loaded: file_helper
INFO - 2021-06-26 11:30:16 --> Helper loaded: form_helper
INFO - 2021-06-26 11:30:16 --> Helper loaded: my_helper
INFO - 2021-06-26 11:30:16 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:30:16 --> Controller Class Initialized
DEBUG - 2021-06-26 11:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:30:16 --> Final output sent to browser
DEBUG - 2021-06-26 11:30:16 --> Total execution time: 0.0444
INFO - 2021-06-26 11:30:17 --> Config Class Initialized
INFO - 2021-06-26 11:30:17 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:30:17 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:30:17 --> Utf8 Class Initialized
INFO - 2021-06-26 11:30:17 --> URI Class Initialized
INFO - 2021-06-26 11:30:17 --> Router Class Initialized
INFO - 2021-06-26 11:30:17 --> Output Class Initialized
INFO - 2021-06-26 11:30:17 --> Security Class Initialized
DEBUG - 2021-06-26 11:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:30:17 --> Input Class Initialized
INFO - 2021-06-26 11:30:17 --> Language Class Initialized
INFO - 2021-06-26 11:30:17 --> Language Class Initialized
INFO - 2021-06-26 11:30:17 --> Config Class Initialized
INFO - 2021-06-26 11:30:17 --> Loader Class Initialized
INFO - 2021-06-26 11:30:17 --> Helper loaded: url_helper
INFO - 2021-06-26 11:30:17 --> Helper loaded: file_helper
INFO - 2021-06-26 11:30:17 --> Helper loaded: form_helper
INFO - 2021-06-26 11:30:17 --> Helper loaded: my_helper
INFO - 2021-06-26 11:30:17 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:30:17 --> Controller Class Initialized
INFO - 2021-06-26 11:30:19 --> Config Class Initialized
INFO - 2021-06-26 11:30:19 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:30:19 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:30:19 --> Utf8 Class Initialized
INFO - 2021-06-26 11:30:19 --> URI Class Initialized
INFO - 2021-06-26 11:30:19 --> Router Class Initialized
INFO - 2021-06-26 11:30:19 --> Output Class Initialized
INFO - 2021-06-26 11:30:19 --> Security Class Initialized
DEBUG - 2021-06-26 11:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:30:19 --> Input Class Initialized
INFO - 2021-06-26 11:30:19 --> Language Class Initialized
INFO - 2021-06-26 11:30:19 --> Language Class Initialized
INFO - 2021-06-26 11:30:19 --> Config Class Initialized
INFO - 2021-06-26 11:30:19 --> Loader Class Initialized
INFO - 2021-06-26 11:30:19 --> Helper loaded: url_helper
INFO - 2021-06-26 11:30:19 --> Helper loaded: file_helper
INFO - 2021-06-26 11:30:19 --> Helper loaded: form_helper
INFO - 2021-06-26 11:30:19 --> Helper loaded: my_helper
INFO - 2021-06-26 11:30:19 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:30:19 --> Controller Class Initialized
INFO - 2021-06-26 11:31:22 --> Config Class Initialized
INFO - 2021-06-26 11:31:22 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:22 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:22 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:22 --> URI Class Initialized
INFO - 2021-06-26 11:31:22 --> Router Class Initialized
INFO - 2021-06-26 11:31:22 --> Output Class Initialized
INFO - 2021-06-26 11:31:22 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:22 --> Input Class Initialized
INFO - 2021-06-26 11:31:22 --> Language Class Initialized
INFO - 2021-06-26 11:31:22 --> Language Class Initialized
INFO - 2021-06-26 11:31:22 --> Config Class Initialized
INFO - 2021-06-26 11:31:22 --> Loader Class Initialized
INFO - 2021-06-26 11:31:22 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:22 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:22 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:22 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:22 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:22 --> Controller Class Initialized
DEBUG - 2021-06-26 11:31:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-26 11:31:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:31:22 --> Final output sent to browser
DEBUG - 2021-06-26 11:31:22 --> Total execution time: 0.0441
INFO - 2021-06-26 11:31:25 --> Config Class Initialized
INFO - 2021-06-26 11:31:25 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:25 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:25 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:25 --> URI Class Initialized
INFO - 2021-06-26 11:31:25 --> Router Class Initialized
INFO - 2021-06-26 11:31:25 --> Output Class Initialized
INFO - 2021-06-26 11:31:25 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:25 --> Input Class Initialized
INFO - 2021-06-26 11:31:25 --> Language Class Initialized
INFO - 2021-06-26 11:31:25 --> Language Class Initialized
INFO - 2021-06-26 11:31:25 --> Config Class Initialized
INFO - 2021-06-26 11:31:25 --> Loader Class Initialized
INFO - 2021-06-26 11:31:25 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:25 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:25 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:25 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:25 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:25 --> Controller Class Initialized
INFO - 2021-06-26 11:31:25 --> Config Class Initialized
INFO - 2021-06-26 11:31:25 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:25 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:25 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:25 --> URI Class Initialized
INFO - 2021-06-26 11:31:25 --> Router Class Initialized
INFO - 2021-06-26 11:31:25 --> Output Class Initialized
INFO - 2021-06-26 11:31:25 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:25 --> Input Class Initialized
INFO - 2021-06-26 11:31:25 --> Language Class Initialized
INFO - 2021-06-26 11:31:25 --> Language Class Initialized
INFO - 2021-06-26 11:31:25 --> Config Class Initialized
INFO - 2021-06-26 11:31:25 --> Loader Class Initialized
INFO - 2021-06-26 11:31:25 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:25 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:25 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:25 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:25 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:25 --> Controller Class Initialized
DEBUG - 2021-06-26 11:31:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:31:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:31:25 --> Final output sent to browser
DEBUG - 2021-06-26 11:31:25 --> Total execution time: 0.0546
INFO - 2021-06-26 11:31:25 --> Config Class Initialized
INFO - 2021-06-26 11:31:25 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:25 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:25 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:25 --> URI Class Initialized
INFO - 2021-06-26 11:31:25 --> Router Class Initialized
INFO - 2021-06-26 11:31:25 --> Output Class Initialized
INFO - 2021-06-26 11:31:25 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:25 --> Input Class Initialized
INFO - 2021-06-26 11:31:25 --> Language Class Initialized
INFO - 2021-06-26 11:31:25 --> Language Class Initialized
INFO - 2021-06-26 11:31:25 --> Config Class Initialized
INFO - 2021-06-26 11:31:25 --> Loader Class Initialized
INFO - 2021-06-26 11:31:25 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:25 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:25 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:25 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:25 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:25 --> Controller Class Initialized
INFO - 2021-06-26 11:31:27 --> Config Class Initialized
INFO - 2021-06-26 11:31:27 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:27 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:27 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:27 --> URI Class Initialized
INFO - 2021-06-26 11:31:27 --> Router Class Initialized
INFO - 2021-06-26 11:31:27 --> Output Class Initialized
INFO - 2021-06-26 11:31:27 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:27 --> Input Class Initialized
INFO - 2021-06-26 11:31:27 --> Language Class Initialized
INFO - 2021-06-26 11:31:27 --> Language Class Initialized
INFO - 2021-06-26 11:31:27 --> Config Class Initialized
INFO - 2021-06-26 11:31:27 --> Loader Class Initialized
INFO - 2021-06-26 11:31:27 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:27 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:27 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:27 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:27 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:27 --> Controller Class Initialized
DEBUG - 2021-06-26 11:31:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-26 11:31:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:31:27 --> Final output sent to browser
DEBUG - 2021-06-26 11:31:27 --> Total execution time: 0.0433
INFO - 2021-06-26 11:31:29 --> Config Class Initialized
INFO - 2021-06-26 11:31:29 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:29 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:29 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:29 --> URI Class Initialized
INFO - 2021-06-26 11:31:29 --> Router Class Initialized
INFO - 2021-06-26 11:31:29 --> Output Class Initialized
INFO - 2021-06-26 11:31:29 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:29 --> Input Class Initialized
INFO - 2021-06-26 11:31:29 --> Language Class Initialized
INFO - 2021-06-26 11:31:29 --> Language Class Initialized
INFO - 2021-06-26 11:31:29 --> Config Class Initialized
INFO - 2021-06-26 11:31:29 --> Loader Class Initialized
INFO - 2021-06-26 11:31:29 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:29 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:29 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:29 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:29 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:29 --> Controller Class Initialized
INFO - 2021-06-26 11:31:29 --> Config Class Initialized
INFO - 2021-06-26 11:31:29 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:30 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:30 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:30 --> URI Class Initialized
INFO - 2021-06-26 11:31:30 --> Router Class Initialized
INFO - 2021-06-26 11:31:30 --> Output Class Initialized
INFO - 2021-06-26 11:31:30 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:30 --> Input Class Initialized
INFO - 2021-06-26 11:31:30 --> Language Class Initialized
INFO - 2021-06-26 11:31:30 --> Language Class Initialized
INFO - 2021-06-26 11:31:30 --> Config Class Initialized
INFO - 2021-06-26 11:31:30 --> Loader Class Initialized
INFO - 2021-06-26 11:31:30 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:30 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:30 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:30 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:30 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:30 --> Controller Class Initialized
DEBUG - 2021-06-26 11:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:31:30 --> Final output sent to browser
DEBUG - 2021-06-26 11:31:30 --> Total execution time: 0.0545
INFO - 2021-06-26 11:31:33 --> Config Class Initialized
INFO - 2021-06-26 11:31:33 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:33 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:33 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:33 --> URI Class Initialized
INFO - 2021-06-26 11:31:33 --> Router Class Initialized
INFO - 2021-06-26 11:31:33 --> Output Class Initialized
INFO - 2021-06-26 11:31:33 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:33 --> Input Class Initialized
INFO - 2021-06-26 11:31:33 --> Language Class Initialized
INFO - 2021-06-26 11:31:33 --> Language Class Initialized
INFO - 2021-06-26 11:31:33 --> Config Class Initialized
INFO - 2021-06-26 11:31:33 --> Loader Class Initialized
INFO - 2021-06-26 11:31:33 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:33 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:33 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:33 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:33 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:33 --> Controller Class Initialized
DEBUG - 2021-06-26 11:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:31:33 --> Final output sent to browser
DEBUG - 2021-06-26 11:31:33 --> Total execution time: 0.0446
INFO - 2021-06-26 11:31:33 --> Config Class Initialized
INFO - 2021-06-26 11:31:33 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:33 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:33 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:33 --> URI Class Initialized
INFO - 2021-06-26 11:31:33 --> Router Class Initialized
INFO - 2021-06-26 11:31:33 --> Output Class Initialized
INFO - 2021-06-26 11:31:33 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:33 --> Input Class Initialized
INFO - 2021-06-26 11:31:33 --> Language Class Initialized
INFO - 2021-06-26 11:31:33 --> Language Class Initialized
INFO - 2021-06-26 11:31:33 --> Config Class Initialized
INFO - 2021-06-26 11:31:33 --> Loader Class Initialized
INFO - 2021-06-26 11:31:33 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:33 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:33 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:33 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:33 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:33 --> Controller Class Initialized
INFO - 2021-06-26 11:31:35 --> Config Class Initialized
INFO - 2021-06-26 11:31:35 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:35 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:35 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:35 --> URI Class Initialized
INFO - 2021-06-26 11:31:35 --> Router Class Initialized
INFO - 2021-06-26 11:31:35 --> Output Class Initialized
INFO - 2021-06-26 11:31:35 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:35 --> Input Class Initialized
INFO - 2021-06-26 11:31:35 --> Language Class Initialized
INFO - 2021-06-26 11:31:35 --> Language Class Initialized
INFO - 2021-06-26 11:31:35 --> Config Class Initialized
INFO - 2021-06-26 11:31:35 --> Loader Class Initialized
INFO - 2021-06-26 11:31:35 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:35 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:35 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:35 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:35 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:35 --> Controller Class Initialized
DEBUG - 2021-06-26 11:31:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:31:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:31:35 --> Final output sent to browser
DEBUG - 2021-06-26 11:31:35 --> Total execution time: 0.0449
INFO - 2021-06-26 11:31:42 --> Config Class Initialized
INFO - 2021-06-26 11:31:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:42 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:42 --> URI Class Initialized
INFO - 2021-06-26 11:31:42 --> Router Class Initialized
INFO - 2021-06-26 11:31:42 --> Output Class Initialized
INFO - 2021-06-26 11:31:42 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:42 --> Input Class Initialized
INFO - 2021-06-26 11:31:42 --> Language Class Initialized
INFO - 2021-06-26 11:31:42 --> Language Class Initialized
INFO - 2021-06-26 11:31:42 --> Config Class Initialized
INFO - 2021-06-26 11:31:42 --> Loader Class Initialized
INFO - 2021-06-26 11:31:42 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:42 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:42 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:42 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:42 --> Controller Class Initialized
INFO - 2021-06-26 11:31:44 --> Config Class Initialized
INFO - 2021-06-26 11:31:44 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:31:44 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:31:44 --> Utf8 Class Initialized
INFO - 2021-06-26 11:31:44 --> URI Class Initialized
INFO - 2021-06-26 11:31:44 --> Router Class Initialized
INFO - 2021-06-26 11:31:44 --> Output Class Initialized
INFO - 2021-06-26 11:31:44 --> Security Class Initialized
DEBUG - 2021-06-26 11:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:31:44 --> Input Class Initialized
INFO - 2021-06-26 11:31:44 --> Language Class Initialized
INFO - 2021-06-26 11:31:44 --> Language Class Initialized
INFO - 2021-06-26 11:31:44 --> Config Class Initialized
INFO - 2021-06-26 11:31:44 --> Loader Class Initialized
INFO - 2021-06-26 11:31:44 --> Helper loaded: url_helper
INFO - 2021-06-26 11:31:44 --> Helper loaded: file_helper
INFO - 2021-06-26 11:31:44 --> Helper loaded: form_helper
INFO - 2021-06-26 11:31:44 --> Helper loaded: my_helper
INFO - 2021-06-26 11:31:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:31:44 --> Controller Class Initialized
INFO - 2021-06-26 11:32:53 --> Config Class Initialized
INFO - 2021-06-26 11:32:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:32:53 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:32:53 --> Utf8 Class Initialized
INFO - 2021-06-26 11:32:53 --> URI Class Initialized
INFO - 2021-06-26 11:32:53 --> Router Class Initialized
INFO - 2021-06-26 11:32:53 --> Output Class Initialized
INFO - 2021-06-26 11:32:53 --> Security Class Initialized
DEBUG - 2021-06-26 11:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:32:53 --> Input Class Initialized
INFO - 2021-06-26 11:32:53 --> Language Class Initialized
INFO - 2021-06-26 11:32:53 --> Language Class Initialized
INFO - 2021-06-26 11:32:53 --> Config Class Initialized
INFO - 2021-06-26 11:32:53 --> Loader Class Initialized
INFO - 2021-06-26 11:32:53 --> Helper loaded: url_helper
INFO - 2021-06-26 11:32:53 --> Helper loaded: file_helper
INFO - 2021-06-26 11:32:53 --> Helper loaded: form_helper
INFO - 2021-06-26 11:32:53 --> Helper loaded: my_helper
INFO - 2021-06-26 11:32:53 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:32:53 --> Controller Class Initialized
DEBUG - 2021-06-26 11:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-26 11:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:32:53 --> Final output sent to browser
DEBUG - 2021-06-26 11:32:53 --> Total execution time: 0.0531
INFO - 2021-06-26 11:32:56 --> Config Class Initialized
INFO - 2021-06-26 11:32:56 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:32:56 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:32:56 --> Utf8 Class Initialized
INFO - 2021-06-26 11:32:56 --> URI Class Initialized
INFO - 2021-06-26 11:32:56 --> Router Class Initialized
INFO - 2021-06-26 11:32:56 --> Output Class Initialized
INFO - 2021-06-26 11:32:56 --> Security Class Initialized
DEBUG - 2021-06-26 11:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:32:56 --> Input Class Initialized
INFO - 2021-06-26 11:32:56 --> Language Class Initialized
INFO - 2021-06-26 11:32:56 --> Language Class Initialized
INFO - 2021-06-26 11:32:56 --> Config Class Initialized
INFO - 2021-06-26 11:32:56 --> Loader Class Initialized
INFO - 2021-06-26 11:32:56 --> Helper loaded: url_helper
INFO - 2021-06-26 11:32:56 --> Helper loaded: file_helper
INFO - 2021-06-26 11:32:56 --> Helper loaded: form_helper
INFO - 2021-06-26 11:32:56 --> Helper loaded: my_helper
INFO - 2021-06-26 11:32:56 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:32:56 --> Controller Class Initialized
INFO - 2021-06-26 11:32:57 --> Config Class Initialized
INFO - 2021-06-26 11:32:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:32:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:32:57 --> Utf8 Class Initialized
INFO - 2021-06-26 11:32:57 --> URI Class Initialized
INFO - 2021-06-26 11:32:57 --> Router Class Initialized
INFO - 2021-06-26 11:32:57 --> Output Class Initialized
INFO - 2021-06-26 11:32:57 --> Security Class Initialized
DEBUG - 2021-06-26 11:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:32:57 --> Input Class Initialized
INFO - 2021-06-26 11:32:57 --> Language Class Initialized
INFO - 2021-06-26 11:32:57 --> Language Class Initialized
INFO - 2021-06-26 11:32:57 --> Config Class Initialized
INFO - 2021-06-26 11:32:57 --> Loader Class Initialized
INFO - 2021-06-26 11:32:57 --> Helper loaded: url_helper
INFO - 2021-06-26 11:32:57 --> Helper loaded: file_helper
INFO - 2021-06-26 11:32:57 --> Helper loaded: form_helper
INFO - 2021-06-26 11:32:57 --> Helper loaded: my_helper
INFO - 2021-06-26 11:32:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:32:57 --> Controller Class Initialized
DEBUG - 2021-06-26 11:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:32:57 --> Final output sent to browser
DEBUG - 2021-06-26 11:32:57 --> Total execution time: 0.0542
INFO - 2021-06-26 11:32:57 --> Config Class Initialized
INFO - 2021-06-26 11:32:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:32:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:32:57 --> Utf8 Class Initialized
INFO - 2021-06-26 11:32:57 --> URI Class Initialized
INFO - 2021-06-26 11:32:57 --> Router Class Initialized
INFO - 2021-06-26 11:32:57 --> Output Class Initialized
INFO - 2021-06-26 11:32:57 --> Security Class Initialized
DEBUG - 2021-06-26 11:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:32:57 --> Input Class Initialized
INFO - 2021-06-26 11:32:57 --> Language Class Initialized
INFO - 2021-06-26 11:32:57 --> Language Class Initialized
INFO - 2021-06-26 11:32:57 --> Config Class Initialized
INFO - 2021-06-26 11:32:57 --> Loader Class Initialized
INFO - 2021-06-26 11:32:57 --> Helper loaded: url_helper
INFO - 2021-06-26 11:32:57 --> Helper loaded: file_helper
INFO - 2021-06-26 11:32:57 --> Helper loaded: form_helper
INFO - 2021-06-26 11:32:57 --> Helper loaded: my_helper
INFO - 2021-06-26 11:32:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:32:57 --> Controller Class Initialized
INFO - 2021-06-26 11:32:58 --> Config Class Initialized
INFO - 2021-06-26 11:32:58 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:32:58 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:32:58 --> Utf8 Class Initialized
INFO - 2021-06-26 11:32:58 --> URI Class Initialized
INFO - 2021-06-26 11:32:58 --> Router Class Initialized
INFO - 2021-06-26 11:32:58 --> Output Class Initialized
INFO - 2021-06-26 11:32:58 --> Security Class Initialized
DEBUG - 2021-06-26 11:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:32:58 --> Input Class Initialized
INFO - 2021-06-26 11:32:58 --> Language Class Initialized
INFO - 2021-06-26 11:32:58 --> Language Class Initialized
INFO - 2021-06-26 11:32:58 --> Config Class Initialized
INFO - 2021-06-26 11:32:58 --> Loader Class Initialized
INFO - 2021-06-26 11:32:58 --> Helper loaded: url_helper
INFO - 2021-06-26 11:32:58 --> Helper loaded: file_helper
INFO - 2021-06-26 11:32:58 --> Helper loaded: form_helper
INFO - 2021-06-26 11:32:58 --> Helper loaded: my_helper
INFO - 2021-06-26 11:32:58 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:32:58 --> Controller Class Initialized
DEBUG - 2021-06-26 11:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-26 11:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:32:58 --> Final output sent to browser
DEBUG - 2021-06-26 11:32:58 --> Total execution time: 0.0512
INFO - 2021-06-26 11:33:01 --> Config Class Initialized
INFO - 2021-06-26 11:33:01 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:01 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:01 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:01 --> URI Class Initialized
INFO - 2021-06-26 11:33:01 --> Router Class Initialized
INFO - 2021-06-26 11:33:01 --> Output Class Initialized
INFO - 2021-06-26 11:33:01 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:01 --> Input Class Initialized
INFO - 2021-06-26 11:33:01 --> Language Class Initialized
INFO - 2021-06-26 11:33:01 --> Language Class Initialized
INFO - 2021-06-26 11:33:01 --> Config Class Initialized
INFO - 2021-06-26 11:33:01 --> Loader Class Initialized
INFO - 2021-06-26 11:33:01 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:01 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:01 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:01 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:01 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:01 --> Controller Class Initialized
INFO - 2021-06-26 11:33:01 --> Config Class Initialized
INFO - 2021-06-26 11:33:01 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:01 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:01 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:01 --> URI Class Initialized
INFO - 2021-06-26 11:33:01 --> Router Class Initialized
INFO - 2021-06-26 11:33:01 --> Output Class Initialized
INFO - 2021-06-26 11:33:01 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:01 --> Input Class Initialized
INFO - 2021-06-26 11:33:01 --> Language Class Initialized
INFO - 2021-06-26 11:33:01 --> Language Class Initialized
INFO - 2021-06-26 11:33:01 --> Config Class Initialized
INFO - 2021-06-26 11:33:01 --> Loader Class Initialized
INFO - 2021-06-26 11:33:01 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:01 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:01 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:01 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:01 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:01 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:01 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:01 --> Total execution time: 0.0432
INFO - 2021-06-26 11:33:08 --> Config Class Initialized
INFO - 2021-06-26 11:33:08 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:08 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:08 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:08 --> URI Class Initialized
INFO - 2021-06-26 11:33:08 --> Router Class Initialized
INFO - 2021-06-26 11:33:08 --> Output Class Initialized
INFO - 2021-06-26 11:33:08 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:08 --> Input Class Initialized
INFO - 2021-06-26 11:33:08 --> Language Class Initialized
INFO - 2021-06-26 11:33:08 --> Language Class Initialized
INFO - 2021-06-26 11:33:08 --> Config Class Initialized
INFO - 2021-06-26 11:33:08 --> Loader Class Initialized
INFO - 2021-06-26 11:33:08 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:08 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:08 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:08 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:08 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:08 --> Controller Class Initialized
INFO - 2021-06-26 11:33:08 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:33:08 --> Config Class Initialized
INFO - 2021-06-26 11:33:08 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:08 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:08 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:08 --> URI Class Initialized
INFO - 2021-06-26 11:33:08 --> Router Class Initialized
INFO - 2021-06-26 11:33:08 --> Output Class Initialized
INFO - 2021-06-26 11:33:08 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:08 --> Input Class Initialized
INFO - 2021-06-26 11:33:08 --> Language Class Initialized
INFO - 2021-06-26 11:33:08 --> Language Class Initialized
INFO - 2021-06-26 11:33:08 --> Config Class Initialized
INFO - 2021-06-26 11:33:08 --> Loader Class Initialized
INFO - 2021-06-26 11:33:08 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:08 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:08 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:08 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:08 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:08 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 11:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:08 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:08 --> Total execution time: 0.0483
INFO - 2021-06-26 11:33:23 --> Config Class Initialized
INFO - 2021-06-26 11:33:23 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:23 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:23 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:23 --> URI Class Initialized
INFO - 2021-06-26 11:33:23 --> Router Class Initialized
INFO - 2021-06-26 11:33:23 --> Output Class Initialized
INFO - 2021-06-26 11:33:23 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:23 --> Input Class Initialized
INFO - 2021-06-26 11:33:23 --> Language Class Initialized
INFO - 2021-06-26 11:33:23 --> Language Class Initialized
INFO - 2021-06-26 11:33:23 --> Config Class Initialized
INFO - 2021-06-26 11:33:23 --> Loader Class Initialized
INFO - 2021-06-26 11:33:23 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:23 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:23 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:23 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:23 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:23 --> Controller Class Initialized
INFO - 2021-06-26 11:33:23 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:33:23 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:23 --> Total execution time: 0.0529
INFO - 2021-06-26 11:33:24 --> Config Class Initialized
INFO - 2021-06-26 11:33:24 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:24 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:24 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:24 --> URI Class Initialized
INFO - 2021-06-26 11:33:24 --> Router Class Initialized
INFO - 2021-06-26 11:33:24 --> Output Class Initialized
INFO - 2021-06-26 11:33:24 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:24 --> Input Class Initialized
INFO - 2021-06-26 11:33:24 --> Language Class Initialized
INFO - 2021-06-26 11:33:24 --> Language Class Initialized
INFO - 2021-06-26 11:33:24 --> Config Class Initialized
INFO - 2021-06-26 11:33:24 --> Loader Class Initialized
INFO - 2021-06-26 11:33:24 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:24 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:24 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:24 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:24 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:24 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 11:33:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:24 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:24 --> Total execution time: 0.6396
INFO - 2021-06-26 11:33:26 --> Config Class Initialized
INFO - 2021-06-26 11:33:26 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:26 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:26 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:26 --> URI Class Initialized
INFO - 2021-06-26 11:33:26 --> Router Class Initialized
INFO - 2021-06-26 11:33:26 --> Output Class Initialized
INFO - 2021-06-26 11:33:26 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:26 --> Input Class Initialized
INFO - 2021-06-26 11:33:26 --> Language Class Initialized
INFO - 2021-06-26 11:33:26 --> Language Class Initialized
INFO - 2021-06-26 11:33:26 --> Config Class Initialized
INFO - 2021-06-26 11:33:26 --> Loader Class Initialized
INFO - 2021-06-26 11:33:26 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:26 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:26 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:26 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:26 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-26 11:33:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:26 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:26 --> Total execution time: 0.0520
INFO - 2021-06-26 11:33:28 --> Config Class Initialized
INFO - 2021-06-26 11:33:28 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:28 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:28 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:28 --> URI Class Initialized
INFO - 2021-06-26 11:33:28 --> Router Class Initialized
INFO - 2021-06-26 11:33:28 --> Output Class Initialized
INFO - 2021-06-26 11:33:28 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:28 --> Input Class Initialized
INFO - 2021-06-26 11:33:28 --> Language Class Initialized
INFO - 2021-06-26 11:33:28 --> Language Class Initialized
INFO - 2021-06-26 11:33:28 --> Config Class Initialized
INFO - 2021-06-26 11:33:28 --> Loader Class Initialized
INFO - 2021-06-26 11:33:28 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:28 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:28 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:28 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:28 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:28 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:33:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:28 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:28 --> Total execution time: 0.0468
INFO - 2021-06-26 11:33:28 --> Config Class Initialized
INFO - 2021-06-26 11:33:28 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:28 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:28 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:28 --> URI Class Initialized
INFO - 2021-06-26 11:33:28 --> Router Class Initialized
INFO - 2021-06-26 11:33:28 --> Output Class Initialized
INFO - 2021-06-26 11:33:28 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:28 --> Input Class Initialized
INFO - 2021-06-26 11:33:28 --> Language Class Initialized
INFO - 2021-06-26 11:33:28 --> Language Class Initialized
INFO - 2021-06-26 11:33:28 --> Config Class Initialized
INFO - 2021-06-26 11:33:28 --> Loader Class Initialized
INFO - 2021-06-26 11:33:28 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:28 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:28 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:28 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:28 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:28 --> Controller Class Initialized
INFO - 2021-06-26 11:33:29 --> Config Class Initialized
INFO - 2021-06-26 11:33:29 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:29 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:29 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:29 --> URI Class Initialized
INFO - 2021-06-26 11:33:29 --> Router Class Initialized
INFO - 2021-06-26 11:33:29 --> Output Class Initialized
INFO - 2021-06-26 11:33:29 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:29 --> Input Class Initialized
INFO - 2021-06-26 11:33:29 --> Language Class Initialized
INFO - 2021-06-26 11:33:29 --> Language Class Initialized
INFO - 2021-06-26 11:33:29 --> Config Class Initialized
INFO - 2021-06-26 11:33:29 --> Loader Class Initialized
INFO - 2021-06-26 11:33:29 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:29 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:29 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:29 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:29 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:29 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:29 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:29 --> Total execution time: 0.0459
INFO - 2021-06-26 11:33:31 --> Config Class Initialized
INFO - 2021-06-26 11:33:31 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:31 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:31 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:31 --> URI Class Initialized
INFO - 2021-06-26 11:33:31 --> Router Class Initialized
INFO - 2021-06-26 11:33:31 --> Output Class Initialized
INFO - 2021-06-26 11:33:31 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:31 --> Input Class Initialized
INFO - 2021-06-26 11:33:31 --> Language Class Initialized
INFO - 2021-06-26 11:33:31 --> Language Class Initialized
INFO - 2021-06-26 11:33:31 --> Config Class Initialized
INFO - 2021-06-26 11:33:31 --> Loader Class Initialized
INFO - 2021-06-26 11:33:31 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:31 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:31 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:31 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:31 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:31 --> Controller Class Initialized
INFO - 2021-06-26 11:33:33 --> Config Class Initialized
INFO - 2021-06-26 11:33:33 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:33 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:33 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:33 --> URI Class Initialized
INFO - 2021-06-26 11:33:33 --> Router Class Initialized
INFO - 2021-06-26 11:33:33 --> Output Class Initialized
INFO - 2021-06-26 11:33:33 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:33 --> Input Class Initialized
INFO - 2021-06-26 11:33:33 --> Language Class Initialized
INFO - 2021-06-26 11:33:33 --> Language Class Initialized
INFO - 2021-06-26 11:33:33 --> Config Class Initialized
INFO - 2021-06-26 11:33:33 --> Loader Class Initialized
INFO - 2021-06-26 11:33:33 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:33 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:33 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:33 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:33 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:33 --> Controller Class Initialized
INFO - 2021-06-26 11:33:43 --> Config Class Initialized
INFO - 2021-06-26 11:33:43 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:43 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:43 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:43 --> URI Class Initialized
INFO - 2021-06-26 11:33:43 --> Router Class Initialized
INFO - 2021-06-26 11:33:43 --> Output Class Initialized
INFO - 2021-06-26 11:33:43 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:43 --> Input Class Initialized
INFO - 2021-06-26 11:33:43 --> Language Class Initialized
INFO - 2021-06-26 11:33:44 --> Language Class Initialized
INFO - 2021-06-26 11:33:44 --> Config Class Initialized
INFO - 2021-06-26 11:33:44 --> Loader Class Initialized
INFO - 2021-06-26 11:33:44 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:44 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:44 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:44 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:44 --> Controller Class Initialized
INFO - 2021-06-26 11:33:44 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:33:44 --> Config Class Initialized
INFO - 2021-06-26 11:33:44 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:44 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:44 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:44 --> URI Class Initialized
INFO - 2021-06-26 11:33:44 --> Router Class Initialized
INFO - 2021-06-26 11:33:44 --> Output Class Initialized
INFO - 2021-06-26 11:33:44 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:44 --> Input Class Initialized
INFO - 2021-06-26 11:33:44 --> Language Class Initialized
INFO - 2021-06-26 11:33:44 --> Language Class Initialized
INFO - 2021-06-26 11:33:44 --> Config Class Initialized
INFO - 2021-06-26 11:33:44 --> Loader Class Initialized
INFO - 2021-06-26 11:33:44 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:44 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:44 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:44 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:44 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:44 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 11:33:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:44 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:44 --> Total execution time: 0.0475
INFO - 2021-06-26 11:33:50 --> Config Class Initialized
INFO - 2021-06-26 11:33:50 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:50 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:50 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:50 --> URI Class Initialized
INFO - 2021-06-26 11:33:50 --> Router Class Initialized
INFO - 2021-06-26 11:33:50 --> Output Class Initialized
INFO - 2021-06-26 11:33:50 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:50 --> Input Class Initialized
INFO - 2021-06-26 11:33:50 --> Language Class Initialized
INFO - 2021-06-26 11:33:50 --> Language Class Initialized
INFO - 2021-06-26 11:33:50 --> Config Class Initialized
INFO - 2021-06-26 11:33:50 --> Loader Class Initialized
INFO - 2021-06-26 11:33:50 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:50 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:50 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:50 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:50 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:50 --> Controller Class Initialized
INFO - 2021-06-26 11:33:50 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:33:50 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:50 --> Total execution time: 0.0434
INFO - 2021-06-26 11:33:51 --> Config Class Initialized
INFO - 2021-06-26 11:33:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:51 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:51 --> URI Class Initialized
INFO - 2021-06-26 11:33:51 --> Router Class Initialized
INFO - 2021-06-26 11:33:51 --> Output Class Initialized
INFO - 2021-06-26 11:33:51 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:51 --> Input Class Initialized
INFO - 2021-06-26 11:33:51 --> Language Class Initialized
INFO - 2021-06-26 11:33:51 --> Language Class Initialized
INFO - 2021-06-26 11:33:51 --> Config Class Initialized
INFO - 2021-06-26 11:33:51 --> Loader Class Initialized
INFO - 2021-06-26 11:33:51 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:51 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:51 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:51 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:51 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 11:33:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:51 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:51 --> Total execution time: 0.6403
INFO - 2021-06-26 11:33:53 --> Config Class Initialized
INFO - 2021-06-26 11:33:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:53 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:53 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:53 --> URI Class Initialized
INFO - 2021-06-26 11:33:53 --> Router Class Initialized
INFO - 2021-06-26 11:33:53 --> Output Class Initialized
INFO - 2021-06-26 11:33:53 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:53 --> Input Class Initialized
INFO - 2021-06-26 11:33:53 --> Language Class Initialized
INFO - 2021-06-26 11:33:53 --> Language Class Initialized
INFO - 2021-06-26 11:33:53 --> Config Class Initialized
INFO - 2021-06-26 11:33:53 --> Loader Class Initialized
INFO - 2021-06-26 11:33:53 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:53 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:53 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:53 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:53 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:53 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-26 11:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:53 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:53 --> Total execution time: 0.0537
INFO - 2021-06-26 11:33:55 --> Config Class Initialized
INFO - 2021-06-26 11:33:55 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:55 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:55 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:55 --> URI Class Initialized
INFO - 2021-06-26 11:33:55 --> Router Class Initialized
INFO - 2021-06-26 11:33:55 --> Output Class Initialized
INFO - 2021-06-26 11:33:55 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:55 --> Input Class Initialized
INFO - 2021-06-26 11:33:55 --> Language Class Initialized
INFO - 2021-06-26 11:33:55 --> Language Class Initialized
INFO - 2021-06-26 11:33:55 --> Config Class Initialized
INFO - 2021-06-26 11:33:55 --> Loader Class Initialized
INFO - 2021-06-26 11:33:55 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:55 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:55 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:55 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:55 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:55 --> Controller Class Initialized
DEBUG - 2021-06-26 11:33:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:33:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:33:55 --> Final output sent to browser
DEBUG - 2021-06-26 11:33:55 --> Total execution time: 0.0490
INFO - 2021-06-26 11:33:55 --> Config Class Initialized
INFO - 2021-06-26 11:33:55 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:33:55 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:33:55 --> Utf8 Class Initialized
INFO - 2021-06-26 11:33:55 --> URI Class Initialized
INFO - 2021-06-26 11:33:55 --> Router Class Initialized
INFO - 2021-06-26 11:33:55 --> Output Class Initialized
INFO - 2021-06-26 11:33:55 --> Security Class Initialized
DEBUG - 2021-06-26 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:33:55 --> Input Class Initialized
INFO - 2021-06-26 11:33:55 --> Language Class Initialized
INFO - 2021-06-26 11:33:55 --> Language Class Initialized
INFO - 2021-06-26 11:33:55 --> Config Class Initialized
INFO - 2021-06-26 11:33:55 --> Loader Class Initialized
INFO - 2021-06-26 11:33:55 --> Helper loaded: url_helper
INFO - 2021-06-26 11:33:55 --> Helper loaded: file_helper
INFO - 2021-06-26 11:33:55 --> Helper loaded: form_helper
INFO - 2021-06-26 11:33:55 --> Helper loaded: my_helper
INFO - 2021-06-26 11:33:55 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:33:55 --> Controller Class Initialized
INFO - 2021-06-26 11:34:03 --> Config Class Initialized
INFO - 2021-06-26 11:34:03 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:03 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:03 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:03 --> URI Class Initialized
INFO - 2021-06-26 11:34:03 --> Router Class Initialized
INFO - 2021-06-26 11:34:03 --> Output Class Initialized
INFO - 2021-06-26 11:34:03 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:03 --> Input Class Initialized
INFO - 2021-06-26 11:34:03 --> Language Class Initialized
INFO - 2021-06-26 11:34:03 --> Language Class Initialized
INFO - 2021-06-26 11:34:03 --> Config Class Initialized
INFO - 2021-06-26 11:34:03 --> Loader Class Initialized
INFO - 2021-06-26 11:34:03 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:03 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:03 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:03 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:03 --> Controller Class Initialized
DEBUG - 2021-06-26 11:34:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:34:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:34:03 --> Final output sent to browser
DEBUG - 2021-06-26 11:34:03 --> Total execution time: 0.0442
INFO - 2021-06-26 11:34:05 --> Config Class Initialized
INFO - 2021-06-26 11:34:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:05 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:05 --> URI Class Initialized
INFO - 2021-06-26 11:34:05 --> Router Class Initialized
INFO - 2021-06-26 11:34:05 --> Output Class Initialized
INFO - 2021-06-26 11:34:05 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:05 --> Input Class Initialized
INFO - 2021-06-26 11:34:05 --> Language Class Initialized
INFO - 2021-06-26 11:34:05 --> Language Class Initialized
INFO - 2021-06-26 11:34:05 --> Config Class Initialized
INFO - 2021-06-26 11:34:05 --> Loader Class Initialized
INFO - 2021-06-26 11:34:05 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:05 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:05 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:05 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:05 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:05 --> Controller Class Initialized
INFO - 2021-06-26 11:34:07 --> Config Class Initialized
INFO - 2021-06-26 11:34:07 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:07 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:07 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:07 --> URI Class Initialized
INFO - 2021-06-26 11:34:07 --> Router Class Initialized
INFO - 2021-06-26 11:34:07 --> Output Class Initialized
INFO - 2021-06-26 11:34:07 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:07 --> Input Class Initialized
INFO - 2021-06-26 11:34:07 --> Language Class Initialized
INFO - 2021-06-26 11:34:07 --> Language Class Initialized
INFO - 2021-06-26 11:34:07 --> Config Class Initialized
INFO - 2021-06-26 11:34:07 --> Loader Class Initialized
INFO - 2021-06-26 11:34:07 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:07 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:07 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:07 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:07 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:07 --> Controller Class Initialized
INFO - 2021-06-26 11:34:48 --> Config Class Initialized
INFO - 2021-06-26 11:34:48 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:48 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:48 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:48 --> URI Class Initialized
INFO - 2021-06-26 11:34:48 --> Router Class Initialized
INFO - 2021-06-26 11:34:48 --> Output Class Initialized
INFO - 2021-06-26 11:34:48 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:48 --> Input Class Initialized
INFO - 2021-06-26 11:34:48 --> Language Class Initialized
INFO - 2021-06-26 11:34:48 --> Language Class Initialized
INFO - 2021-06-26 11:34:48 --> Config Class Initialized
INFO - 2021-06-26 11:34:48 --> Loader Class Initialized
INFO - 2021-06-26 11:34:48 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:48 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:48 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:48 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:48 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:48 --> Controller Class Initialized
DEBUG - 2021-06-26 11:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-26 11:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:34:48 --> Final output sent to browser
DEBUG - 2021-06-26 11:34:48 --> Total execution time: 0.0533
INFO - 2021-06-26 11:34:51 --> Config Class Initialized
INFO - 2021-06-26 11:34:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:51 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:51 --> URI Class Initialized
INFO - 2021-06-26 11:34:51 --> Router Class Initialized
INFO - 2021-06-26 11:34:51 --> Output Class Initialized
INFO - 2021-06-26 11:34:51 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:51 --> Input Class Initialized
INFO - 2021-06-26 11:34:51 --> Language Class Initialized
INFO - 2021-06-26 11:34:51 --> Language Class Initialized
INFO - 2021-06-26 11:34:51 --> Config Class Initialized
INFO - 2021-06-26 11:34:51 --> Loader Class Initialized
INFO - 2021-06-26 11:34:51 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:51 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:51 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:51 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:51 --> Controller Class Initialized
INFO - 2021-06-26 11:34:51 --> Config Class Initialized
INFO - 2021-06-26 11:34:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:51 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:51 --> URI Class Initialized
INFO - 2021-06-26 11:34:51 --> Router Class Initialized
INFO - 2021-06-26 11:34:51 --> Output Class Initialized
INFO - 2021-06-26 11:34:51 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:51 --> Input Class Initialized
INFO - 2021-06-26 11:34:51 --> Language Class Initialized
INFO - 2021-06-26 11:34:51 --> Language Class Initialized
INFO - 2021-06-26 11:34:51 --> Config Class Initialized
INFO - 2021-06-26 11:34:51 --> Loader Class Initialized
INFO - 2021-06-26 11:34:51 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:51 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:51 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:51 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:51 --> Controller Class Initialized
DEBUG - 2021-06-26 11:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:34:51 --> Final output sent to browser
DEBUG - 2021-06-26 11:34:51 --> Total execution time: 0.0438
INFO - 2021-06-26 11:34:51 --> Config Class Initialized
INFO - 2021-06-26 11:34:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:51 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:51 --> URI Class Initialized
INFO - 2021-06-26 11:34:51 --> Router Class Initialized
INFO - 2021-06-26 11:34:51 --> Output Class Initialized
INFO - 2021-06-26 11:34:51 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:51 --> Input Class Initialized
INFO - 2021-06-26 11:34:51 --> Language Class Initialized
INFO - 2021-06-26 11:34:51 --> Language Class Initialized
INFO - 2021-06-26 11:34:51 --> Config Class Initialized
INFO - 2021-06-26 11:34:51 --> Loader Class Initialized
INFO - 2021-06-26 11:34:51 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:51 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:51 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:51 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:51 --> Controller Class Initialized
INFO - 2021-06-26 11:34:53 --> Config Class Initialized
INFO - 2021-06-26 11:34:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:53 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:53 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:53 --> URI Class Initialized
INFO - 2021-06-26 11:34:53 --> Router Class Initialized
INFO - 2021-06-26 11:34:53 --> Output Class Initialized
INFO - 2021-06-26 11:34:53 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:53 --> Input Class Initialized
INFO - 2021-06-26 11:34:53 --> Language Class Initialized
INFO - 2021-06-26 11:34:53 --> Language Class Initialized
INFO - 2021-06-26 11:34:53 --> Config Class Initialized
INFO - 2021-06-26 11:34:53 --> Loader Class Initialized
INFO - 2021-06-26 11:34:53 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:53 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:53 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:53 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:53 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:53 --> Controller Class Initialized
DEBUG - 2021-06-26 11:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-26 11:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:34:53 --> Final output sent to browser
DEBUG - 2021-06-26 11:34:53 --> Total execution time: 0.0511
INFO - 2021-06-26 11:34:55 --> Config Class Initialized
INFO - 2021-06-26 11:34:55 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:55 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:55 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:55 --> URI Class Initialized
INFO - 2021-06-26 11:34:55 --> Router Class Initialized
INFO - 2021-06-26 11:34:55 --> Output Class Initialized
INFO - 2021-06-26 11:34:55 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:55 --> Input Class Initialized
INFO - 2021-06-26 11:34:55 --> Language Class Initialized
INFO - 2021-06-26 11:34:55 --> Language Class Initialized
INFO - 2021-06-26 11:34:55 --> Config Class Initialized
INFO - 2021-06-26 11:34:55 --> Loader Class Initialized
INFO - 2021-06-26 11:34:55 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:55 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:55 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:55 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:55 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:55 --> Controller Class Initialized
INFO - 2021-06-26 11:34:56 --> Config Class Initialized
INFO - 2021-06-26 11:34:56 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:34:56 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:34:56 --> Utf8 Class Initialized
INFO - 2021-06-26 11:34:56 --> URI Class Initialized
INFO - 2021-06-26 11:34:56 --> Router Class Initialized
INFO - 2021-06-26 11:34:56 --> Output Class Initialized
INFO - 2021-06-26 11:34:56 --> Security Class Initialized
DEBUG - 2021-06-26 11:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:34:56 --> Input Class Initialized
INFO - 2021-06-26 11:34:56 --> Language Class Initialized
INFO - 2021-06-26 11:34:56 --> Language Class Initialized
INFO - 2021-06-26 11:34:56 --> Config Class Initialized
INFO - 2021-06-26 11:34:56 --> Loader Class Initialized
INFO - 2021-06-26 11:34:56 --> Helper loaded: url_helper
INFO - 2021-06-26 11:34:56 --> Helper loaded: file_helper
INFO - 2021-06-26 11:34:56 --> Helper loaded: form_helper
INFO - 2021-06-26 11:34:56 --> Helper loaded: my_helper
INFO - 2021-06-26 11:34:56 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:34:56 --> Controller Class Initialized
DEBUG - 2021-06-26 11:34:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:34:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:34:56 --> Final output sent to browser
DEBUG - 2021-06-26 11:34:56 --> Total execution time: 0.0460
INFO - 2021-06-26 11:35:00 --> Config Class Initialized
INFO - 2021-06-26 11:35:00 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:00 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:00 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:00 --> URI Class Initialized
INFO - 2021-06-26 11:35:00 --> Router Class Initialized
INFO - 2021-06-26 11:35:00 --> Output Class Initialized
INFO - 2021-06-26 11:35:00 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:00 --> Input Class Initialized
INFO - 2021-06-26 11:35:00 --> Language Class Initialized
INFO - 2021-06-26 11:35:00 --> Language Class Initialized
INFO - 2021-06-26 11:35:00 --> Config Class Initialized
INFO - 2021-06-26 11:35:00 --> Loader Class Initialized
INFO - 2021-06-26 11:35:00 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:00 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:00 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:00 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:00 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:00 --> Controller Class Initialized
DEBUG - 2021-06-26 11:35:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:35:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:35:00 --> Final output sent to browser
DEBUG - 2021-06-26 11:35:00 --> Total execution time: 0.0446
INFO - 2021-06-26 11:35:00 --> Config Class Initialized
INFO - 2021-06-26 11:35:00 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:00 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:00 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:00 --> URI Class Initialized
INFO - 2021-06-26 11:35:00 --> Router Class Initialized
INFO - 2021-06-26 11:35:00 --> Output Class Initialized
INFO - 2021-06-26 11:35:00 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:00 --> Input Class Initialized
INFO - 2021-06-26 11:35:00 --> Language Class Initialized
INFO - 2021-06-26 11:35:00 --> Language Class Initialized
INFO - 2021-06-26 11:35:00 --> Config Class Initialized
INFO - 2021-06-26 11:35:00 --> Loader Class Initialized
INFO - 2021-06-26 11:35:00 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:00 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:00 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:00 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:00 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:00 --> Controller Class Initialized
INFO - 2021-06-26 11:35:01 --> Config Class Initialized
INFO - 2021-06-26 11:35:01 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:01 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:01 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:01 --> URI Class Initialized
INFO - 2021-06-26 11:35:01 --> Router Class Initialized
INFO - 2021-06-26 11:35:01 --> Output Class Initialized
INFO - 2021-06-26 11:35:01 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:01 --> Input Class Initialized
INFO - 2021-06-26 11:35:01 --> Language Class Initialized
INFO - 2021-06-26 11:35:01 --> Language Class Initialized
INFO - 2021-06-26 11:35:01 --> Config Class Initialized
INFO - 2021-06-26 11:35:01 --> Loader Class Initialized
INFO - 2021-06-26 11:35:01 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:01 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:01 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:01 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:01 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:01 --> Controller Class Initialized
DEBUG - 2021-06-26 11:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:35:01 --> Final output sent to browser
DEBUG - 2021-06-26 11:35:01 --> Total execution time: 0.0450
INFO - 2021-06-26 11:35:03 --> Config Class Initialized
INFO - 2021-06-26 11:35:03 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:03 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:03 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:03 --> URI Class Initialized
INFO - 2021-06-26 11:35:03 --> Router Class Initialized
INFO - 2021-06-26 11:35:03 --> Output Class Initialized
INFO - 2021-06-26 11:35:03 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:03 --> Input Class Initialized
INFO - 2021-06-26 11:35:03 --> Language Class Initialized
INFO - 2021-06-26 11:35:03 --> Language Class Initialized
INFO - 2021-06-26 11:35:03 --> Config Class Initialized
INFO - 2021-06-26 11:35:03 --> Loader Class Initialized
INFO - 2021-06-26 11:35:03 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:03 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:03 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:03 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:03 --> Controller Class Initialized
INFO - 2021-06-26 11:35:05 --> Config Class Initialized
INFO - 2021-06-26 11:35:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:05 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:05 --> URI Class Initialized
INFO - 2021-06-26 11:35:05 --> Router Class Initialized
INFO - 2021-06-26 11:35:05 --> Output Class Initialized
INFO - 2021-06-26 11:35:05 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:05 --> Input Class Initialized
INFO - 2021-06-26 11:35:05 --> Language Class Initialized
INFO - 2021-06-26 11:35:05 --> Language Class Initialized
INFO - 2021-06-26 11:35:05 --> Config Class Initialized
INFO - 2021-06-26 11:35:05 --> Loader Class Initialized
INFO - 2021-06-26 11:35:05 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:05 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:05 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:05 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:05 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:05 --> Controller Class Initialized
INFO - 2021-06-26 11:35:42 --> Config Class Initialized
INFO - 2021-06-26 11:35:42 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:42 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:42 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:42 --> URI Class Initialized
INFO - 2021-06-26 11:35:42 --> Router Class Initialized
INFO - 2021-06-26 11:35:42 --> Output Class Initialized
INFO - 2021-06-26 11:35:42 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:42 --> Input Class Initialized
INFO - 2021-06-26 11:35:42 --> Language Class Initialized
INFO - 2021-06-26 11:35:42 --> Language Class Initialized
INFO - 2021-06-26 11:35:42 --> Config Class Initialized
INFO - 2021-06-26 11:35:42 --> Loader Class Initialized
INFO - 2021-06-26 11:35:42 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:42 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:42 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:42 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:42 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:42 --> Controller Class Initialized
DEBUG - 2021-06-26 11:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-26 11:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:35:42 --> Final output sent to browser
DEBUG - 2021-06-26 11:35:42 --> Total execution time: 0.0531
INFO - 2021-06-26 11:35:45 --> Config Class Initialized
INFO - 2021-06-26 11:35:45 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:45 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:45 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:45 --> URI Class Initialized
INFO - 2021-06-26 11:35:45 --> Router Class Initialized
INFO - 2021-06-26 11:35:45 --> Output Class Initialized
INFO - 2021-06-26 11:35:45 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:45 --> Input Class Initialized
INFO - 2021-06-26 11:35:45 --> Language Class Initialized
INFO - 2021-06-26 11:35:45 --> Language Class Initialized
INFO - 2021-06-26 11:35:45 --> Config Class Initialized
INFO - 2021-06-26 11:35:45 --> Loader Class Initialized
INFO - 2021-06-26 11:35:45 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:45 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:45 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:45 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:45 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:45 --> Controller Class Initialized
INFO - 2021-06-26 11:35:45 --> Config Class Initialized
INFO - 2021-06-26 11:35:45 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:45 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:45 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:45 --> URI Class Initialized
INFO - 2021-06-26 11:35:45 --> Router Class Initialized
INFO - 2021-06-26 11:35:45 --> Output Class Initialized
INFO - 2021-06-26 11:35:45 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:45 --> Input Class Initialized
INFO - 2021-06-26 11:35:45 --> Language Class Initialized
INFO - 2021-06-26 11:35:45 --> Language Class Initialized
INFO - 2021-06-26 11:35:45 --> Config Class Initialized
INFO - 2021-06-26 11:35:45 --> Loader Class Initialized
INFO - 2021-06-26 11:35:45 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:45 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:45 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:45 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:45 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:45 --> Controller Class Initialized
DEBUG - 2021-06-26 11:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:35:45 --> Final output sent to browser
DEBUG - 2021-06-26 11:35:45 --> Total execution time: 0.0546
INFO - 2021-06-26 11:35:45 --> Config Class Initialized
INFO - 2021-06-26 11:35:45 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:45 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:45 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:45 --> URI Class Initialized
INFO - 2021-06-26 11:35:45 --> Router Class Initialized
INFO - 2021-06-26 11:35:45 --> Output Class Initialized
INFO - 2021-06-26 11:35:45 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:45 --> Input Class Initialized
INFO - 2021-06-26 11:35:45 --> Language Class Initialized
INFO - 2021-06-26 11:35:45 --> Language Class Initialized
INFO - 2021-06-26 11:35:45 --> Config Class Initialized
INFO - 2021-06-26 11:35:45 --> Loader Class Initialized
INFO - 2021-06-26 11:35:45 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:45 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:45 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:45 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:45 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:45 --> Controller Class Initialized
INFO - 2021-06-26 11:35:46 --> Config Class Initialized
INFO - 2021-06-26 11:35:46 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:46 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:46 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:46 --> URI Class Initialized
INFO - 2021-06-26 11:35:46 --> Router Class Initialized
INFO - 2021-06-26 11:35:46 --> Output Class Initialized
INFO - 2021-06-26 11:35:46 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:46 --> Input Class Initialized
INFO - 2021-06-26 11:35:46 --> Language Class Initialized
INFO - 2021-06-26 11:35:46 --> Language Class Initialized
INFO - 2021-06-26 11:35:46 --> Config Class Initialized
INFO - 2021-06-26 11:35:46 --> Loader Class Initialized
INFO - 2021-06-26 11:35:46 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:46 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:46 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:46 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:46 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:46 --> Controller Class Initialized
DEBUG - 2021-06-26 11:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-26 11:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:35:46 --> Final output sent to browser
DEBUG - 2021-06-26 11:35:46 --> Total execution time: 0.0511
INFO - 2021-06-26 11:35:49 --> Config Class Initialized
INFO - 2021-06-26 11:35:49 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:49 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:49 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:49 --> URI Class Initialized
INFO - 2021-06-26 11:35:49 --> Router Class Initialized
INFO - 2021-06-26 11:35:49 --> Output Class Initialized
INFO - 2021-06-26 11:35:49 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:49 --> Input Class Initialized
INFO - 2021-06-26 11:35:49 --> Language Class Initialized
INFO - 2021-06-26 11:35:49 --> Language Class Initialized
INFO - 2021-06-26 11:35:49 --> Config Class Initialized
INFO - 2021-06-26 11:35:49 --> Loader Class Initialized
INFO - 2021-06-26 11:35:49 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:49 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:49 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:49 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:49 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:49 --> Controller Class Initialized
INFO - 2021-06-26 11:35:49 --> Config Class Initialized
INFO - 2021-06-26 11:35:49 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:49 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:49 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:49 --> URI Class Initialized
INFO - 2021-06-26 11:35:49 --> Router Class Initialized
INFO - 2021-06-26 11:35:49 --> Output Class Initialized
INFO - 2021-06-26 11:35:49 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:49 --> Input Class Initialized
INFO - 2021-06-26 11:35:49 --> Language Class Initialized
INFO - 2021-06-26 11:35:49 --> Language Class Initialized
INFO - 2021-06-26 11:35:49 --> Config Class Initialized
INFO - 2021-06-26 11:35:49 --> Loader Class Initialized
INFO - 2021-06-26 11:35:49 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:49 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:49 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:49 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:49 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:49 --> Controller Class Initialized
DEBUG - 2021-06-26 11:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:35:49 --> Final output sent to browser
DEBUG - 2021-06-26 11:35:49 --> Total execution time: 0.0433
INFO - 2021-06-26 11:35:53 --> Config Class Initialized
INFO - 2021-06-26 11:35:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:53 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:53 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:53 --> URI Class Initialized
INFO - 2021-06-26 11:35:53 --> Router Class Initialized
INFO - 2021-06-26 11:35:53 --> Output Class Initialized
INFO - 2021-06-26 11:35:53 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:53 --> Input Class Initialized
INFO - 2021-06-26 11:35:53 --> Language Class Initialized
INFO - 2021-06-26 11:35:53 --> Language Class Initialized
INFO - 2021-06-26 11:35:53 --> Config Class Initialized
INFO - 2021-06-26 11:35:53 --> Loader Class Initialized
INFO - 2021-06-26 11:35:53 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:53 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:53 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:53 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:53 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:53 --> Controller Class Initialized
INFO - 2021-06-26 11:35:53 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:35:53 --> Config Class Initialized
INFO - 2021-06-26 11:35:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:53 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:53 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:53 --> URI Class Initialized
INFO - 2021-06-26 11:35:53 --> Router Class Initialized
INFO - 2021-06-26 11:35:53 --> Output Class Initialized
INFO - 2021-06-26 11:35:53 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:53 --> Input Class Initialized
INFO - 2021-06-26 11:35:53 --> Language Class Initialized
INFO - 2021-06-26 11:35:53 --> Language Class Initialized
INFO - 2021-06-26 11:35:53 --> Config Class Initialized
INFO - 2021-06-26 11:35:53 --> Loader Class Initialized
INFO - 2021-06-26 11:35:53 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:53 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:53 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:53 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:53 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:53 --> Controller Class Initialized
DEBUG - 2021-06-26 11:35:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 11:35:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:35:53 --> Final output sent to browser
DEBUG - 2021-06-26 11:35:53 --> Total execution time: 0.0477
INFO - 2021-06-26 11:35:57 --> Config Class Initialized
INFO - 2021-06-26 11:35:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:57 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:57 --> URI Class Initialized
INFO - 2021-06-26 11:35:57 --> Router Class Initialized
INFO - 2021-06-26 11:35:57 --> Output Class Initialized
INFO - 2021-06-26 11:35:57 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:57 --> Input Class Initialized
INFO - 2021-06-26 11:35:57 --> Language Class Initialized
INFO - 2021-06-26 11:35:57 --> Language Class Initialized
INFO - 2021-06-26 11:35:57 --> Config Class Initialized
INFO - 2021-06-26 11:35:57 --> Loader Class Initialized
INFO - 2021-06-26 11:35:57 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:57 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:57 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:57 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:57 --> Controller Class Initialized
INFO - 2021-06-26 11:35:57 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:35:57 --> Final output sent to browser
DEBUG - 2021-06-26 11:35:57 --> Total execution time: 0.0537
INFO - 2021-06-26 11:35:58 --> Config Class Initialized
INFO - 2021-06-26 11:35:58 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:35:58 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:35:58 --> Utf8 Class Initialized
INFO - 2021-06-26 11:35:58 --> URI Class Initialized
INFO - 2021-06-26 11:35:58 --> Router Class Initialized
INFO - 2021-06-26 11:35:58 --> Output Class Initialized
INFO - 2021-06-26 11:35:58 --> Security Class Initialized
DEBUG - 2021-06-26 11:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:35:58 --> Input Class Initialized
INFO - 2021-06-26 11:35:58 --> Language Class Initialized
INFO - 2021-06-26 11:35:58 --> Language Class Initialized
INFO - 2021-06-26 11:35:58 --> Config Class Initialized
INFO - 2021-06-26 11:35:58 --> Loader Class Initialized
INFO - 2021-06-26 11:35:58 --> Helper loaded: url_helper
INFO - 2021-06-26 11:35:58 --> Helper loaded: file_helper
INFO - 2021-06-26 11:35:58 --> Helper loaded: form_helper
INFO - 2021-06-26 11:35:58 --> Helper loaded: my_helper
INFO - 2021-06-26 11:35:58 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:35:58 --> Controller Class Initialized
DEBUG - 2021-06-26 11:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 11:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:35:59 --> Final output sent to browser
DEBUG - 2021-06-26 11:35:59 --> Total execution time: 0.6523
INFO - 2021-06-26 11:36:05 --> Config Class Initialized
INFO - 2021-06-26 11:36:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:05 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:05 --> URI Class Initialized
INFO - 2021-06-26 11:36:05 --> Router Class Initialized
INFO - 2021-06-26 11:36:05 --> Output Class Initialized
INFO - 2021-06-26 11:36:05 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:05 --> Input Class Initialized
INFO - 2021-06-26 11:36:05 --> Language Class Initialized
INFO - 2021-06-26 11:36:05 --> Language Class Initialized
INFO - 2021-06-26 11:36:05 --> Config Class Initialized
INFO - 2021-06-26 11:36:05 --> Loader Class Initialized
INFO - 2021-06-26 11:36:05 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:05 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:05 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:05 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:05 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:05 --> Controller Class Initialized
DEBUG - 2021-06-26 11:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-26 11:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:36:05 --> Final output sent to browser
DEBUG - 2021-06-26 11:36:05 --> Total execution time: 0.0534
INFO - 2021-06-26 11:36:06 --> Config Class Initialized
INFO - 2021-06-26 11:36:06 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:06 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:06 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:06 --> URI Class Initialized
INFO - 2021-06-26 11:36:06 --> Router Class Initialized
INFO - 2021-06-26 11:36:06 --> Output Class Initialized
INFO - 2021-06-26 11:36:06 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:06 --> Input Class Initialized
INFO - 2021-06-26 11:36:06 --> Language Class Initialized
INFO - 2021-06-26 11:36:06 --> Language Class Initialized
INFO - 2021-06-26 11:36:06 --> Config Class Initialized
INFO - 2021-06-26 11:36:06 --> Loader Class Initialized
INFO - 2021-06-26 11:36:06 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:06 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:06 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:06 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:06 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:06 --> Controller Class Initialized
DEBUG - 2021-06-26 11:36:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:36:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:36:06 --> Final output sent to browser
DEBUG - 2021-06-26 11:36:06 --> Total execution time: 0.0452
INFO - 2021-06-26 11:36:07 --> Config Class Initialized
INFO - 2021-06-26 11:36:07 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:07 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:07 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:07 --> URI Class Initialized
INFO - 2021-06-26 11:36:07 --> Router Class Initialized
INFO - 2021-06-26 11:36:07 --> Output Class Initialized
INFO - 2021-06-26 11:36:07 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:07 --> Input Class Initialized
INFO - 2021-06-26 11:36:07 --> Language Class Initialized
INFO - 2021-06-26 11:36:07 --> Language Class Initialized
INFO - 2021-06-26 11:36:07 --> Config Class Initialized
INFO - 2021-06-26 11:36:07 --> Loader Class Initialized
INFO - 2021-06-26 11:36:07 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:07 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:07 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:07 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:07 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:07 --> Controller Class Initialized
INFO - 2021-06-26 11:36:08 --> Config Class Initialized
INFO - 2021-06-26 11:36:08 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:08 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:08 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:08 --> URI Class Initialized
INFO - 2021-06-26 11:36:08 --> Router Class Initialized
INFO - 2021-06-26 11:36:08 --> Output Class Initialized
INFO - 2021-06-26 11:36:08 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:08 --> Input Class Initialized
INFO - 2021-06-26 11:36:08 --> Language Class Initialized
INFO - 2021-06-26 11:36:08 --> Language Class Initialized
INFO - 2021-06-26 11:36:08 --> Config Class Initialized
INFO - 2021-06-26 11:36:08 --> Loader Class Initialized
INFO - 2021-06-26 11:36:08 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:08 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:08 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:08 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:08 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:08 --> Controller Class Initialized
DEBUG - 2021-06-26 11:36:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:36:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:36:08 --> Final output sent to browser
DEBUG - 2021-06-26 11:36:08 --> Total execution time: 0.0447
INFO - 2021-06-26 11:36:09 --> Config Class Initialized
INFO - 2021-06-26 11:36:09 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:09 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:09 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:09 --> URI Class Initialized
INFO - 2021-06-26 11:36:09 --> Router Class Initialized
INFO - 2021-06-26 11:36:09 --> Output Class Initialized
INFO - 2021-06-26 11:36:09 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:09 --> Input Class Initialized
INFO - 2021-06-26 11:36:09 --> Language Class Initialized
INFO - 2021-06-26 11:36:09 --> Language Class Initialized
INFO - 2021-06-26 11:36:09 --> Config Class Initialized
INFO - 2021-06-26 11:36:09 --> Loader Class Initialized
INFO - 2021-06-26 11:36:09 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:09 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:09 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:09 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:09 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:09 --> Controller Class Initialized
INFO - 2021-06-26 11:36:11 --> Config Class Initialized
INFO - 2021-06-26 11:36:11 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:11 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:11 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:11 --> URI Class Initialized
INFO - 2021-06-26 11:36:11 --> Router Class Initialized
INFO - 2021-06-26 11:36:11 --> Output Class Initialized
INFO - 2021-06-26 11:36:11 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:11 --> Input Class Initialized
INFO - 2021-06-26 11:36:11 --> Language Class Initialized
INFO - 2021-06-26 11:36:11 --> Language Class Initialized
INFO - 2021-06-26 11:36:11 --> Config Class Initialized
INFO - 2021-06-26 11:36:11 --> Loader Class Initialized
INFO - 2021-06-26 11:36:11 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:11 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:11 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:11 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:11 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:11 --> Controller Class Initialized
INFO - 2021-06-26 11:36:49 --> Config Class Initialized
INFO - 2021-06-26 11:36:49 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:49 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:49 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:49 --> URI Class Initialized
INFO - 2021-06-26 11:36:49 --> Router Class Initialized
INFO - 2021-06-26 11:36:49 --> Output Class Initialized
INFO - 2021-06-26 11:36:49 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:49 --> Input Class Initialized
INFO - 2021-06-26 11:36:49 --> Language Class Initialized
INFO - 2021-06-26 11:36:49 --> Language Class Initialized
INFO - 2021-06-26 11:36:49 --> Config Class Initialized
INFO - 2021-06-26 11:36:49 --> Loader Class Initialized
INFO - 2021-06-26 11:36:49 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:49 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:49 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:49 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:49 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:49 --> Controller Class Initialized
DEBUG - 2021-06-26 11:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-26 11:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:36:49 --> Final output sent to browser
DEBUG - 2021-06-26 11:36:49 --> Total execution time: 0.0441
INFO - 2021-06-26 11:36:52 --> Config Class Initialized
INFO - 2021-06-26 11:36:52 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:52 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:52 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:52 --> URI Class Initialized
INFO - 2021-06-26 11:36:52 --> Router Class Initialized
INFO - 2021-06-26 11:36:52 --> Output Class Initialized
INFO - 2021-06-26 11:36:52 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:52 --> Input Class Initialized
INFO - 2021-06-26 11:36:52 --> Language Class Initialized
INFO - 2021-06-26 11:36:52 --> Language Class Initialized
INFO - 2021-06-26 11:36:52 --> Config Class Initialized
INFO - 2021-06-26 11:36:52 --> Loader Class Initialized
INFO - 2021-06-26 11:36:52 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:52 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:52 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:52 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:52 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:52 --> Controller Class Initialized
INFO - 2021-06-26 11:36:52 --> Config Class Initialized
INFO - 2021-06-26 11:36:52 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:52 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:52 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:52 --> URI Class Initialized
INFO - 2021-06-26 11:36:52 --> Router Class Initialized
INFO - 2021-06-26 11:36:52 --> Output Class Initialized
INFO - 2021-06-26 11:36:52 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:52 --> Input Class Initialized
INFO - 2021-06-26 11:36:52 --> Language Class Initialized
INFO - 2021-06-26 11:36:52 --> Language Class Initialized
INFO - 2021-06-26 11:36:52 --> Config Class Initialized
INFO - 2021-06-26 11:36:52 --> Loader Class Initialized
INFO - 2021-06-26 11:36:52 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:52 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:52 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:52 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:52 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:52 --> Controller Class Initialized
DEBUG - 2021-06-26 11:36:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-26 11:36:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:36:52 --> Final output sent to browser
DEBUG - 2021-06-26 11:36:52 --> Total execution time: 0.0432
INFO - 2021-06-26 11:36:52 --> Config Class Initialized
INFO - 2021-06-26 11:36:52 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:52 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:52 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:52 --> URI Class Initialized
INFO - 2021-06-26 11:36:52 --> Router Class Initialized
INFO - 2021-06-26 11:36:52 --> Output Class Initialized
INFO - 2021-06-26 11:36:52 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:52 --> Input Class Initialized
INFO - 2021-06-26 11:36:52 --> Language Class Initialized
INFO - 2021-06-26 11:36:52 --> Language Class Initialized
INFO - 2021-06-26 11:36:52 --> Config Class Initialized
INFO - 2021-06-26 11:36:52 --> Loader Class Initialized
INFO - 2021-06-26 11:36:52 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:52 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:52 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:52 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:52 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:52 --> Controller Class Initialized
INFO - 2021-06-26 11:36:54 --> Config Class Initialized
INFO - 2021-06-26 11:36:54 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:54 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:54 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:54 --> URI Class Initialized
INFO - 2021-06-26 11:36:54 --> Router Class Initialized
INFO - 2021-06-26 11:36:54 --> Output Class Initialized
INFO - 2021-06-26 11:36:54 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:54 --> Input Class Initialized
INFO - 2021-06-26 11:36:54 --> Language Class Initialized
INFO - 2021-06-26 11:36:54 --> Language Class Initialized
INFO - 2021-06-26 11:36:54 --> Config Class Initialized
INFO - 2021-06-26 11:36:54 --> Loader Class Initialized
INFO - 2021-06-26 11:36:54 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:54 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:54 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:54 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:54 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:54 --> Controller Class Initialized
DEBUG - 2021-06-26 11:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-26 11:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:36:54 --> Final output sent to browser
DEBUG - 2021-06-26 11:36:54 --> Total execution time: 0.0512
INFO - 2021-06-26 11:36:57 --> Config Class Initialized
INFO - 2021-06-26 11:36:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:57 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:57 --> URI Class Initialized
INFO - 2021-06-26 11:36:57 --> Router Class Initialized
INFO - 2021-06-26 11:36:57 --> Output Class Initialized
INFO - 2021-06-26 11:36:57 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:57 --> Input Class Initialized
INFO - 2021-06-26 11:36:57 --> Language Class Initialized
INFO - 2021-06-26 11:36:57 --> Language Class Initialized
INFO - 2021-06-26 11:36:57 --> Config Class Initialized
INFO - 2021-06-26 11:36:57 --> Loader Class Initialized
INFO - 2021-06-26 11:36:57 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:57 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:57 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:57 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:57 --> Controller Class Initialized
INFO - 2021-06-26 11:36:57 --> Config Class Initialized
INFO - 2021-06-26 11:36:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:36:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:36:57 --> Utf8 Class Initialized
INFO - 2021-06-26 11:36:57 --> URI Class Initialized
INFO - 2021-06-26 11:36:57 --> Router Class Initialized
INFO - 2021-06-26 11:36:57 --> Output Class Initialized
INFO - 2021-06-26 11:36:57 --> Security Class Initialized
DEBUG - 2021-06-26 11:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:36:57 --> Input Class Initialized
INFO - 2021-06-26 11:36:57 --> Language Class Initialized
INFO - 2021-06-26 11:36:57 --> Language Class Initialized
INFO - 2021-06-26 11:36:57 --> Config Class Initialized
INFO - 2021-06-26 11:36:57 --> Loader Class Initialized
INFO - 2021-06-26 11:36:57 --> Helper loaded: url_helper
INFO - 2021-06-26 11:36:57 --> Helper loaded: file_helper
INFO - 2021-06-26 11:36:57 --> Helper loaded: form_helper
INFO - 2021-06-26 11:36:57 --> Helper loaded: my_helper
INFO - 2021-06-26 11:36:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:36:57 --> Controller Class Initialized
DEBUG - 2021-06-26 11:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-26 11:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:36:57 --> Final output sent to browser
DEBUG - 2021-06-26 11:36:57 --> Total execution time: 0.0548
INFO - 2021-06-26 11:37:09 --> Config Class Initialized
INFO - 2021-06-26 11:37:09 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:37:09 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:37:09 --> Utf8 Class Initialized
INFO - 2021-06-26 11:37:09 --> URI Class Initialized
INFO - 2021-06-26 11:37:09 --> Router Class Initialized
INFO - 2021-06-26 11:37:09 --> Output Class Initialized
INFO - 2021-06-26 11:37:09 --> Security Class Initialized
DEBUG - 2021-06-26 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:37:09 --> Input Class Initialized
INFO - 2021-06-26 11:37:09 --> Language Class Initialized
INFO - 2021-06-26 11:37:09 --> Language Class Initialized
INFO - 2021-06-26 11:37:09 --> Config Class Initialized
INFO - 2021-06-26 11:37:09 --> Loader Class Initialized
INFO - 2021-06-26 11:37:09 --> Helper loaded: url_helper
INFO - 2021-06-26 11:37:09 --> Helper loaded: file_helper
INFO - 2021-06-26 11:37:09 --> Helper loaded: form_helper
INFO - 2021-06-26 11:37:09 --> Helper loaded: my_helper
INFO - 2021-06-26 11:37:09 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:37:09 --> Controller Class Initialized
INFO - 2021-06-26 11:37:09 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:37:09 --> Config Class Initialized
INFO - 2021-06-26 11:37:09 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:37:09 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:37:09 --> Utf8 Class Initialized
INFO - 2021-06-26 11:37:09 --> URI Class Initialized
INFO - 2021-06-26 11:37:09 --> Router Class Initialized
INFO - 2021-06-26 11:37:09 --> Output Class Initialized
INFO - 2021-06-26 11:37:09 --> Security Class Initialized
DEBUG - 2021-06-26 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:37:09 --> Input Class Initialized
INFO - 2021-06-26 11:37:09 --> Language Class Initialized
INFO - 2021-06-26 11:37:09 --> Language Class Initialized
INFO - 2021-06-26 11:37:09 --> Config Class Initialized
INFO - 2021-06-26 11:37:09 --> Loader Class Initialized
INFO - 2021-06-26 11:37:09 --> Helper loaded: url_helper
INFO - 2021-06-26 11:37:09 --> Helper loaded: file_helper
INFO - 2021-06-26 11:37:09 --> Helper loaded: form_helper
INFO - 2021-06-26 11:37:09 --> Helper loaded: my_helper
INFO - 2021-06-26 11:37:09 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:37:09 --> Controller Class Initialized
DEBUG - 2021-06-26 11:37:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 11:37:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:37:09 --> Final output sent to browser
DEBUG - 2021-06-26 11:37:09 --> Total execution time: 0.0489
INFO - 2021-06-26 11:37:17 --> Config Class Initialized
INFO - 2021-06-26 11:37:17 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:37:17 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:37:17 --> Utf8 Class Initialized
INFO - 2021-06-26 11:37:17 --> URI Class Initialized
INFO - 2021-06-26 11:37:17 --> Router Class Initialized
INFO - 2021-06-26 11:37:17 --> Output Class Initialized
INFO - 2021-06-26 11:37:17 --> Security Class Initialized
DEBUG - 2021-06-26 11:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:37:17 --> Input Class Initialized
INFO - 2021-06-26 11:37:17 --> Language Class Initialized
INFO - 2021-06-26 11:37:17 --> Language Class Initialized
INFO - 2021-06-26 11:37:17 --> Config Class Initialized
INFO - 2021-06-26 11:37:17 --> Loader Class Initialized
INFO - 2021-06-26 11:37:17 --> Helper loaded: url_helper
INFO - 2021-06-26 11:37:17 --> Helper loaded: file_helper
INFO - 2021-06-26 11:37:17 --> Helper loaded: form_helper
INFO - 2021-06-26 11:37:17 --> Helper loaded: my_helper
INFO - 2021-06-26 11:37:17 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:37:17 --> Controller Class Initialized
INFO - 2021-06-26 11:37:17 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:37:17 --> Final output sent to browser
DEBUG - 2021-06-26 11:37:17 --> Total execution time: 0.0434
INFO - 2021-06-26 11:37:18 --> Config Class Initialized
INFO - 2021-06-26 11:37:18 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:37:18 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:37:18 --> Utf8 Class Initialized
INFO - 2021-06-26 11:37:18 --> URI Class Initialized
INFO - 2021-06-26 11:37:18 --> Router Class Initialized
INFO - 2021-06-26 11:37:18 --> Output Class Initialized
INFO - 2021-06-26 11:37:18 --> Security Class Initialized
DEBUG - 2021-06-26 11:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:37:18 --> Input Class Initialized
INFO - 2021-06-26 11:37:18 --> Language Class Initialized
INFO - 2021-06-26 11:37:18 --> Language Class Initialized
INFO - 2021-06-26 11:37:18 --> Config Class Initialized
INFO - 2021-06-26 11:37:18 --> Loader Class Initialized
INFO - 2021-06-26 11:37:18 --> Helper loaded: url_helper
INFO - 2021-06-26 11:37:18 --> Helper loaded: file_helper
INFO - 2021-06-26 11:37:18 --> Helper loaded: form_helper
INFO - 2021-06-26 11:37:18 --> Helper loaded: my_helper
INFO - 2021-06-26 11:37:18 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:37:18 --> Controller Class Initialized
DEBUG - 2021-06-26 11:37:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 11:37:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:37:18 --> Final output sent to browser
DEBUG - 2021-06-26 11:37:18 --> Total execution time: 0.6397
INFO - 2021-06-26 11:37:26 --> Config Class Initialized
INFO - 2021-06-26 11:37:26 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:37:26 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:37:26 --> Utf8 Class Initialized
INFO - 2021-06-26 11:37:26 --> URI Class Initialized
INFO - 2021-06-26 11:37:26 --> Router Class Initialized
INFO - 2021-06-26 11:37:26 --> Output Class Initialized
INFO - 2021-06-26 11:37:26 --> Security Class Initialized
DEBUG - 2021-06-26 11:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:37:26 --> Input Class Initialized
INFO - 2021-06-26 11:37:26 --> Language Class Initialized
INFO - 2021-06-26 11:37:26 --> Language Class Initialized
INFO - 2021-06-26 11:37:26 --> Config Class Initialized
INFO - 2021-06-26 11:37:26 --> Loader Class Initialized
INFO - 2021-06-26 11:37:26 --> Helper loaded: url_helper
INFO - 2021-06-26 11:37:26 --> Helper loaded: file_helper
INFO - 2021-06-26 11:37:26 --> Helper loaded: form_helper
INFO - 2021-06-26 11:37:26 --> Helper loaded: my_helper
INFO - 2021-06-26 11:37:26 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:37:26 --> Controller Class Initialized
DEBUG - 2021-06-26 11:37:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-26 11:37:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:37:26 --> Final output sent to browser
DEBUG - 2021-06-26 11:37:26 --> Total execution time: 0.0632
INFO - 2021-06-26 11:37:28 --> Config Class Initialized
INFO - 2021-06-26 11:37:28 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:37:28 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:37:28 --> Utf8 Class Initialized
INFO - 2021-06-26 11:37:28 --> URI Class Initialized
INFO - 2021-06-26 11:37:28 --> Router Class Initialized
INFO - 2021-06-26 11:37:28 --> Output Class Initialized
INFO - 2021-06-26 11:37:28 --> Security Class Initialized
DEBUG - 2021-06-26 11:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:37:28 --> Input Class Initialized
INFO - 2021-06-26 11:37:28 --> Language Class Initialized
INFO - 2021-06-26 11:37:28 --> Language Class Initialized
INFO - 2021-06-26 11:37:28 --> Config Class Initialized
INFO - 2021-06-26 11:37:28 --> Loader Class Initialized
INFO - 2021-06-26 11:37:28 --> Helper loaded: url_helper
INFO - 2021-06-26 11:37:28 --> Helper loaded: file_helper
INFO - 2021-06-26 11:37:28 --> Helper loaded: form_helper
INFO - 2021-06-26 11:37:28 --> Helper loaded: my_helper
INFO - 2021-06-26 11:37:28 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:37:28 --> Controller Class Initialized
DEBUG - 2021-06-26 11:37:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-06-26 11:37:28 --> Final output sent to browser
DEBUG - 2021-06-26 11:37:28 --> Total execution time: 0.3401
INFO - 2021-06-26 11:38:29 --> Config Class Initialized
INFO - 2021-06-26 11:38:29 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:38:29 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:38:29 --> Utf8 Class Initialized
INFO - 2021-06-26 11:38:29 --> URI Class Initialized
INFO - 2021-06-26 11:38:29 --> Router Class Initialized
INFO - 2021-06-26 11:38:29 --> Output Class Initialized
INFO - 2021-06-26 11:38:29 --> Security Class Initialized
DEBUG - 2021-06-26 11:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:38:29 --> Input Class Initialized
INFO - 2021-06-26 11:38:29 --> Language Class Initialized
INFO - 2021-06-26 11:38:29 --> Language Class Initialized
INFO - 2021-06-26 11:38:29 --> Config Class Initialized
INFO - 2021-06-26 11:38:29 --> Loader Class Initialized
INFO - 2021-06-26 11:38:29 --> Helper loaded: url_helper
INFO - 2021-06-26 11:38:29 --> Helper loaded: file_helper
INFO - 2021-06-26 11:38:29 --> Helper loaded: form_helper
INFO - 2021-06-26 11:38:29 --> Helper loaded: my_helper
INFO - 2021-06-26 11:38:29 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:38:29 --> Controller Class Initialized
DEBUG - 2021-06-26 11:38:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 11:38:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:38:29 --> Final output sent to browser
DEBUG - 2021-06-26 11:38:29 --> Total execution time: 0.0572
INFO - 2021-06-26 11:38:34 --> Config Class Initialized
INFO - 2021-06-26 11:38:34 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:38:34 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:38:34 --> Utf8 Class Initialized
INFO - 2021-06-26 11:38:34 --> URI Class Initialized
INFO - 2021-06-26 11:38:34 --> Router Class Initialized
INFO - 2021-06-26 11:38:34 --> Output Class Initialized
INFO - 2021-06-26 11:38:34 --> Security Class Initialized
DEBUG - 2021-06-26 11:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:38:34 --> Input Class Initialized
INFO - 2021-06-26 11:38:34 --> Language Class Initialized
INFO - 2021-06-26 11:38:34 --> Language Class Initialized
INFO - 2021-06-26 11:38:34 --> Config Class Initialized
INFO - 2021-06-26 11:38:34 --> Loader Class Initialized
INFO - 2021-06-26 11:38:34 --> Helper loaded: url_helper
INFO - 2021-06-26 11:38:34 --> Helper loaded: file_helper
INFO - 2021-06-26 11:38:34 --> Helper loaded: form_helper
INFO - 2021-06-26 11:38:34 --> Helper loaded: my_helper
INFO - 2021-06-26 11:38:34 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:38:34 --> Controller Class Initialized
DEBUG - 2021-06-26 11:38:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:38:34 --> Final output sent to browser
DEBUG - 2021-06-26 11:38:34 --> Total execution time: 0.2086
INFO - 2021-06-26 11:38:45 --> Config Class Initialized
INFO - 2021-06-26 11:38:45 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:38:45 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:38:45 --> Utf8 Class Initialized
INFO - 2021-06-26 11:38:45 --> URI Class Initialized
INFO - 2021-06-26 11:38:45 --> Router Class Initialized
INFO - 2021-06-26 11:38:45 --> Output Class Initialized
INFO - 2021-06-26 11:38:45 --> Security Class Initialized
DEBUG - 2021-06-26 11:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:38:45 --> Input Class Initialized
INFO - 2021-06-26 11:38:45 --> Language Class Initialized
INFO - 2021-06-26 11:38:45 --> Language Class Initialized
INFO - 2021-06-26 11:38:45 --> Config Class Initialized
INFO - 2021-06-26 11:38:45 --> Loader Class Initialized
INFO - 2021-06-26 11:38:45 --> Helper loaded: url_helper
INFO - 2021-06-26 11:38:45 --> Helper loaded: file_helper
INFO - 2021-06-26 11:38:45 --> Helper loaded: form_helper
INFO - 2021-06-26 11:38:45 --> Helper loaded: my_helper
INFO - 2021-06-26 11:38:45 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:38:45 --> Controller Class Initialized
DEBUG - 2021-06-26 11:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:38:46 --> Final output sent to browser
DEBUG - 2021-06-26 11:38:46 --> Total execution time: 0.2070
INFO - 2021-06-26 11:38:47 --> Config Class Initialized
INFO - 2021-06-26 11:38:47 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:38:47 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:38:47 --> Utf8 Class Initialized
INFO - 2021-06-26 11:38:47 --> URI Class Initialized
INFO - 2021-06-26 11:38:47 --> Router Class Initialized
INFO - 2021-06-26 11:38:47 --> Output Class Initialized
INFO - 2021-06-26 11:38:47 --> Security Class Initialized
DEBUG - 2021-06-26 11:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:38:47 --> Input Class Initialized
INFO - 2021-06-26 11:38:47 --> Language Class Initialized
INFO - 2021-06-26 11:38:47 --> Language Class Initialized
INFO - 2021-06-26 11:38:47 --> Config Class Initialized
INFO - 2021-06-26 11:38:47 --> Loader Class Initialized
INFO - 2021-06-26 11:38:47 --> Helper loaded: url_helper
INFO - 2021-06-26 11:38:47 --> Helper loaded: file_helper
INFO - 2021-06-26 11:38:47 --> Helper loaded: form_helper
INFO - 2021-06-26 11:38:47 --> Helper loaded: my_helper
INFO - 2021-06-26 11:38:47 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:38:47 --> Controller Class Initialized
DEBUG - 2021-06-26 11:38:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:38:47 --> Final output sent to browser
DEBUG - 2021-06-26 11:38:47 --> Total execution time: 0.1966
INFO - 2021-06-26 11:38:48 --> Config Class Initialized
INFO - 2021-06-26 11:38:48 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:38:48 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:38:48 --> Utf8 Class Initialized
INFO - 2021-06-26 11:38:48 --> URI Class Initialized
INFO - 2021-06-26 11:38:48 --> Router Class Initialized
INFO - 2021-06-26 11:38:48 --> Output Class Initialized
INFO - 2021-06-26 11:38:48 --> Security Class Initialized
DEBUG - 2021-06-26 11:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:38:48 --> Input Class Initialized
INFO - 2021-06-26 11:38:48 --> Language Class Initialized
INFO - 2021-06-26 11:38:48 --> Language Class Initialized
INFO - 2021-06-26 11:38:48 --> Config Class Initialized
INFO - 2021-06-26 11:38:48 --> Loader Class Initialized
INFO - 2021-06-26 11:38:48 --> Helper loaded: url_helper
INFO - 2021-06-26 11:38:48 --> Helper loaded: file_helper
INFO - 2021-06-26 11:38:48 --> Helper loaded: form_helper
INFO - 2021-06-26 11:38:48 --> Helper loaded: my_helper
INFO - 2021-06-26 11:38:48 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:38:48 --> Controller Class Initialized
DEBUG - 2021-06-26 11:38:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:38:49 --> Final output sent to browser
DEBUG - 2021-06-26 11:38:49 --> Total execution time: 0.1952
INFO - 2021-06-26 11:38:50 --> Config Class Initialized
INFO - 2021-06-26 11:38:50 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:38:50 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:38:50 --> Utf8 Class Initialized
INFO - 2021-06-26 11:38:50 --> URI Class Initialized
INFO - 2021-06-26 11:38:50 --> Router Class Initialized
INFO - 2021-06-26 11:38:50 --> Output Class Initialized
INFO - 2021-06-26 11:38:50 --> Security Class Initialized
DEBUG - 2021-06-26 11:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:38:50 --> Input Class Initialized
INFO - 2021-06-26 11:38:50 --> Language Class Initialized
INFO - 2021-06-26 11:38:50 --> Language Class Initialized
INFO - 2021-06-26 11:38:50 --> Config Class Initialized
INFO - 2021-06-26 11:38:50 --> Loader Class Initialized
INFO - 2021-06-26 11:38:50 --> Helper loaded: url_helper
INFO - 2021-06-26 11:38:50 --> Helper loaded: file_helper
INFO - 2021-06-26 11:38:50 --> Helper loaded: form_helper
INFO - 2021-06-26 11:38:50 --> Helper loaded: my_helper
INFO - 2021-06-26 11:38:50 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:38:50 --> Controller Class Initialized
DEBUG - 2021-06-26 11:38:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:38:50 --> Final output sent to browser
DEBUG - 2021-06-26 11:38:50 --> Total execution time: 0.1936
INFO - 2021-06-26 11:38:51 --> Config Class Initialized
INFO - 2021-06-26 11:38:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:38:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:38:51 --> Utf8 Class Initialized
INFO - 2021-06-26 11:38:51 --> URI Class Initialized
INFO - 2021-06-26 11:38:51 --> Router Class Initialized
INFO - 2021-06-26 11:38:51 --> Output Class Initialized
INFO - 2021-06-26 11:38:51 --> Security Class Initialized
DEBUG - 2021-06-26 11:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:38:51 --> Input Class Initialized
INFO - 2021-06-26 11:38:51 --> Language Class Initialized
INFO - 2021-06-26 11:38:51 --> Language Class Initialized
INFO - 2021-06-26 11:38:51 --> Config Class Initialized
INFO - 2021-06-26 11:38:51 --> Loader Class Initialized
INFO - 2021-06-26 11:38:51 --> Helper loaded: url_helper
INFO - 2021-06-26 11:38:51 --> Helper loaded: file_helper
INFO - 2021-06-26 11:38:51 --> Helper loaded: form_helper
INFO - 2021-06-26 11:38:51 --> Helper loaded: my_helper
INFO - 2021-06-26 11:38:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:38:51 --> Controller Class Initialized
DEBUG - 2021-06-26 11:38:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:38:52 --> Final output sent to browser
DEBUG - 2021-06-26 11:38:52 --> Total execution time: 0.1892
INFO - 2021-06-26 11:38:53 --> Config Class Initialized
INFO - 2021-06-26 11:38:53 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:38:53 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:38:53 --> Utf8 Class Initialized
INFO - 2021-06-26 11:38:53 --> URI Class Initialized
INFO - 2021-06-26 11:38:53 --> Router Class Initialized
INFO - 2021-06-26 11:38:53 --> Output Class Initialized
INFO - 2021-06-26 11:38:53 --> Security Class Initialized
DEBUG - 2021-06-26 11:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:38:53 --> Input Class Initialized
INFO - 2021-06-26 11:38:53 --> Language Class Initialized
INFO - 2021-06-26 11:38:53 --> Language Class Initialized
INFO - 2021-06-26 11:38:53 --> Config Class Initialized
INFO - 2021-06-26 11:38:53 --> Loader Class Initialized
INFO - 2021-06-26 11:38:53 --> Helper loaded: url_helper
INFO - 2021-06-26 11:38:53 --> Helper loaded: file_helper
INFO - 2021-06-26 11:38:53 --> Helper loaded: form_helper
INFO - 2021-06-26 11:38:53 --> Helper loaded: my_helper
INFO - 2021-06-26 11:38:53 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:38:53 --> Controller Class Initialized
DEBUG - 2021-06-26 11:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:38:53 --> Final output sent to browser
DEBUG - 2021-06-26 11:38:53 --> Total execution time: 0.1878
INFO - 2021-06-26 11:38:54 --> Config Class Initialized
INFO - 2021-06-26 11:38:54 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:38:54 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:38:54 --> Utf8 Class Initialized
INFO - 2021-06-26 11:38:54 --> URI Class Initialized
INFO - 2021-06-26 11:38:54 --> Router Class Initialized
INFO - 2021-06-26 11:38:54 --> Output Class Initialized
INFO - 2021-06-26 11:38:54 --> Security Class Initialized
DEBUG - 2021-06-26 11:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:38:54 --> Input Class Initialized
INFO - 2021-06-26 11:38:54 --> Language Class Initialized
INFO - 2021-06-26 11:38:54 --> Language Class Initialized
INFO - 2021-06-26 11:38:54 --> Config Class Initialized
INFO - 2021-06-26 11:38:54 --> Loader Class Initialized
INFO - 2021-06-26 11:38:54 --> Helper loaded: url_helper
INFO - 2021-06-26 11:38:54 --> Helper loaded: file_helper
INFO - 2021-06-26 11:38:54 --> Helper loaded: form_helper
INFO - 2021-06-26 11:38:54 --> Helper loaded: my_helper
INFO - 2021-06-26 11:38:54 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:38:54 --> Controller Class Initialized
DEBUG - 2021-06-26 11:38:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:38:55 --> Final output sent to browser
DEBUG - 2021-06-26 11:38:55 --> Total execution time: 0.1932
INFO - 2021-06-26 11:39:03 --> Config Class Initialized
INFO - 2021-06-26 11:39:03 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:03 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:03 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:03 --> URI Class Initialized
INFO - 2021-06-26 11:39:03 --> Router Class Initialized
INFO - 2021-06-26 11:39:03 --> Output Class Initialized
INFO - 2021-06-26 11:39:03 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:03 --> Input Class Initialized
INFO - 2021-06-26 11:39:03 --> Language Class Initialized
INFO - 2021-06-26 11:39:03 --> Language Class Initialized
INFO - 2021-06-26 11:39:03 --> Config Class Initialized
INFO - 2021-06-26 11:39:03 --> Loader Class Initialized
INFO - 2021-06-26 11:39:03 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:03 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:03 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:03 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:03 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:03 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:03 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:03 --> Total execution time: 0.2833
INFO - 2021-06-26 11:39:05 --> Config Class Initialized
INFO - 2021-06-26 11:39:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:05 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:05 --> URI Class Initialized
INFO - 2021-06-26 11:39:05 --> Router Class Initialized
INFO - 2021-06-26 11:39:05 --> Output Class Initialized
INFO - 2021-06-26 11:39:05 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:05 --> Input Class Initialized
INFO - 2021-06-26 11:39:05 --> Language Class Initialized
INFO - 2021-06-26 11:39:05 --> Language Class Initialized
INFO - 2021-06-26 11:39:05 --> Config Class Initialized
INFO - 2021-06-26 11:39:05 --> Loader Class Initialized
INFO - 2021-06-26 11:39:05 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:05 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:05 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:05 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:05 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:05 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:05 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:05 --> Total execution time: 0.1939
INFO - 2021-06-26 11:39:07 --> Config Class Initialized
INFO - 2021-06-26 11:39:07 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:07 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:07 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:07 --> URI Class Initialized
INFO - 2021-06-26 11:39:07 --> Router Class Initialized
INFO - 2021-06-26 11:39:07 --> Output Class Initialized
INFO - 2021-06-26 11:39:07 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:07 --> Input Class Initialized
INFO - 2021-06-26 11:39:07 --> Language Class Initialized
INFO - 2021-06-26 11:39:07 --> Language Class Initialized
INFO - 2021-06-26 11:39:07 --> Config Class Initialized
INFO - 2021-06-26 11:39:07 --> Loader Class Initialized
INFO - 2021-06-26 11:39:07 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:07 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:07 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:07 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:07 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:07 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:07 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:07 --> Total execution time: 0.1998
INFO - 2021-06-26 11:39:08 --> Config Class Initialized
INFO - 2021-06-26 11:39:08 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:08 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:08 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:08 --> URI Class Initialized
INFO - 2021-06-26 11:39:08 --> Router Class Initialized
INFO - 2021-06-26 11:39:08 --> Output Class Initialized
INFO - 2021-06-26 11:39:08 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:08 --> Input Class Initialized
INFO - 2021-06-26 11:39:08 --> Language Class Initialized
INFO - 2021-06-26 11:39:08 --> Language Class Initialized
INFO - 2021-06-26 11:39:08 --> Config Class Initialized
INFO - 2021-06-26 11:39:08 --> Loader Class Initialized
INFO - 2021-06-26 11:39:08 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:08 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:08 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:08 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:08 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:08 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:08 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:08 --> Total execution time: 0.1916
INFO - 2021-06-26 11:39:10 --> Config Class Initialized
INFO - 2021-06-26 11:39:10 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:10 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:10 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:10 --> URI Class Initialized
INFO - 2021-06-26 11:39:10 --> Router Class Initialized
INFO - 2021-06-26 11:39:10 --> Output Class Initialized
INFO - 2021-06-26 11:39:10 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:10 --> Input Class Initialized
INFO - 2021-06-26 11:39:10 --> Language Class Initialized
INFO - 2021-06-26 11:39:10 --> Language Class Initialized
INFO - 2021-06-26 11:39:10 --> Config Class Initialized
INFO - 2021-06-26 11:39:10 --> Loader Class Initialized
INFO - 2021-06-26 11:39:10 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:10 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:10 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:10 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:10 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:10 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:10 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:10 --> Total execution time: 0.1931
INFO - 2021-06-26 11:39:11 --> Config Class Initialized
INFO - 2021-06-26 11:39:11 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:11 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:11 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:11 --> URI Class Initialized
INFO - 2021-06-26 11:39:11 --> Router Class Initialized
INFO - 2021-06-26 11:39:11 --> Output Class Initialized
INFO - 2021-06-26 11:39:11 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:11 --> Input Class Initialized
INFO - 2021-06-26 11:39:11 --> Language Class Initialized
INFO - 2021-06-26 11:39:11 --> Language Class Initialized
INFO - 2021-06-26 11:39:11 --> Config Class Initialized
INFO - 2021-06-26 11:39:11 --> Loader Class Initialized
INFO - 2021-06-26 11:39:11 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:11 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:11 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:11 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:11 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:11 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:11 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:11 --> Total execution time: 0.1921
INFO - 2021-06-26 11:39:13 --> Config Class Initialized
INFO - 2021-06-26 11:39:13 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:13 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:13 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:13 --> URI Class Initialized
INFO - 2021-06-26 11:39:13 --> Router Class Initialized
INFO - 2021-06-26 11:39:13 --> Output Class Initialized
INFO - 2021-06-26 11:39:13 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:13 --> Input Class Initialized
INFO - 2021-06-26 11:39:13 --> Language Class Initialized
INFO - 2021-06-26 11:39:13 --> Language Class Initialized
INFO - 2021-06-26 11:39:13 --> Config Class Initialized
INFO - 2021-06-26 11:39:13 --> Loader Class Initialized
INFO - 2021-06-26 11:39:13 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:13 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:13 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:13 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:13 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:13 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:13 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:13 --> Total execution time: 0.1929
INFO - 2021-06-26 11:39:14 --> Config Class Initialized
INFO - 2021-06-26 11:39:14 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:14 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:14 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:14 --> URI Class Initialized
INFO - 2021-06-26 11:39:14 --> Router Class Initialized
INFO - 2021-06-26 11:39:14 --> Output Class Initialized
INFO - 2021-06-26 11:39:14 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:14 --> Input Class Initialized
INFO - 2021-06-26 11:39:14 --> Language Class Initialized
INFO - 2021-06-26 11:39:14 --> Language Class Initialized
INFO - 2021-06-26 11:39:14 --> Config Class Initialized
INFO - 2021-06-26 11:39:14 --> Loader Class Initialized
INFO - 2021-06-26 11:39:14 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:14 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:14 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:14 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:14 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:14 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:14 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:14 --> Total execution time: 0.1946
INFO - 2021-06-26 11:39:16 --> Config Class Initialized
INFO - 2021-06-26 11:39:16 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:16 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:16 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:16 --> URI Class Initialized
INFO - 2021-06-26 11:39:16 --> Router Class Initialized
INFO - 2021-06-26 11:39:16 --> Output Class Initialized
INFO - 2021-06-26 11:39:16 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:16 --> Input Class Initialized
INFO - 2021-06-26 11:39:16 --> Language Class Initialized
INFO - 2021-06-26 11:39:16 --> Language Class Initialized
INFO - 2021-06-26 11:39:16 --> Config Class Initialized
INFO - 2021-06-26 11:39:16 --> Loader Class Initialized
INFO - 2021-06-26 11:39:16 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:16 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:16 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:16 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:16 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:16 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:16 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:16 --> Total execution time: 0.1947
INFO - 2021-06-26 11:39:17 --> Config Class Initialized
INFO - 2021-06-26 11:39:17 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:17 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:17 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:17 --> URI Class Initialized
INFO - 2021-06-26 11:39:17 --> Router Class Initialized
INFO - 2021-06-26 11:39:17 --> Output Class Initialized
INFO - 2021-06-26 11:39:17 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:17 --> Input Class Initialized
INFO - 2021-06-26 11:39:17 --> Language Class Initialized
INFO - 2021-06-26 11:39:17 --> Language Class Initialized
INFO - 2021-06-26 11:39:17 --> Config Class Initialized
INFO - 2021-06-26 11:39:17 --> Loader Class Initialized
INFO - 2021-06-26 11:39:17 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:17 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:17 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:17 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:17 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:17 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:17 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:17 --> Total execution time: 0.1910
INFO - 2021-06-26 11:39:19 --> Config Class Initialized
INFO - 2021-06-26 11:39:19 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:19 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:19 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:19 --> URI Class Initialized
INFO - 2021-06-26 11:39:19 --> Router Class Initialized
INFO - 2021-06-26 11:39:19 --> Output Class Initialized
INFO - 2021-06-26 11:39:19 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:19 --> Input Class Initialized
INFO - 2021-06-26 11:39:19 --> Language Class Initialized
INFO - 2021-06-26 11:39:19 --> Language Class Initialized
INFO - 2021-06-26 11:39:19 --> Config Class Initialized
INFO - 2021-06-26 11:39:19 --> Loader Class Initialized
INFO - 2021-06-26 11:39:19 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:19 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:19 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:19 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:19 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:19 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:19 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:19 --> Total execution time: 0.1943
INFO - 2021-06-26 11:39:20 --> Config Class Initialized
INFO - 2021-06-26 11:39:20 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:20 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:20 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:20 --> URI Class Initialized
INFO - 2021-06-26 11:39:20 --> Router Class Initialized
INFO - 2021-06-26 11:39:20 --> Output Class Initialized
INFO - 2021-06-26 11:39:20 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:20 --> Input Class Initialized
INFO - 2021-06-26 11:39:20 --> Language Class Initialized
INFO - 2021-06-26 11:39:20 --> Language Class Initialized
INFO - 2021-06-26 11:39:20 --> Config Class Initialized
INFO - 2021-06-26 11:39:20 --> Loader Class Initialized
INFO - 2021-06-26 11:39:20 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:20 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:20 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:20 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:20 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:20 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:21 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:21 --> Total execution time: 0.1909
INFO - 2021-06-26 11:39:23 --> Config Class Initialized
INFO - 2021-06-26 11:39:23 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:23 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:23 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:23 --> URI Class Initialized
INFO - 2021-06-26 11:39:23 --> Router Class Initialized
INFO - 2021-06-26 11:39:23 --> Output Class Initialized
INFO - 2021-06-26 11:39:23 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:23 --> Input Class Initialized
INFO - 2021-06-26 11:39:23 --> Language Class Initialized
INFO - 2021-06-26 11:39:23 --> Language Class Initialized
INFO - 2021-06-26 11:39:23 --> Config Class Initialized
INFO - 2021-06-26 11:39:23 --> Loader Class Initialized
INFO - 2021-06-26 11:39:23 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:23 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:23 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:23 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:23 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:23 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:23 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:23 --> Total execution time: 0.1921
INFO - 2021-06-26 11:39:24 --> Config Class Initialized
INFO - 2021-06-26 11:39:24 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:24 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:24 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:24 --> URI Class Initialized
INFO - 2021-06-26 11:39:24 --> Router Class Initialized
INFO - 2021-06-26 11:39:24 --> Output Class Initialized
INFO - 2021-06-26 11:39:24 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:24 --> Input Class Initialized
INFO - 2021-06-26 11:39:24 --> Language Class Initialized
INFO - 2021-06-26 11:39:24 --> Language Class Initialized
INFO - 2021-06-26 11:39:24 --> Config Class Initialized
INFO - 2021-06-26 11:39:24 --> Loader Class Initialized
INFO - 2021-06-26 11:39:24 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:24 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:24 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:24 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:24 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:24 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:24 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:24 --> Total execution time: 0.1934
INFO - 2021-06-26 11:39:25 --> Config Class Initialized
INFO - 2021-06-26 11:39:25 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:25 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:25 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:25 --> URI Class Initialized
INFO - 2021-06-26 11:39:25 --> Router Class Initialized
INFO - 2021-06-26 11:39:25 --> Output Class Initialized
INFO - 2021-06-26 11:39:25 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:25 --> Input Class Initialized
INFO - 2021-06-26 11:39:25 --> Language Class Initialized
INFO - 2021-06-26 11:39:25 --> Language Class Initialized
INFO - 2021-06-26 11:39:25 --> Config Class Initialized
INFO - 2021-06-26 11:39:25 --> Loader Class Initialized
INFO - 2021-06-26 11:39:25 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:25 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:25 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:25 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:25 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:25 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:26 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:26 --> Total execution time: 0.1916
INFO - 2021-06-26 11:39:27 --> Config Class Initialized
INFO - 2021-06-26 11:39:27 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:27 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:27 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:27 --> URI Class Initialized
INFO - 2021-06-26 11:39:27 --> Router Class Initialized
INFO - 2021-06-26 11:39:27 --> Output Class Initialized
INFO - 2021-06-26 11:39:27 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:27 --> Input Class Initialized
INFO - 2021-06-26 11:39:27 --> Language Class Initialized
INFO - 2021-06-26 11:39:27 --> Language Class Initialized
INFO - 2021-06-26 11:39:27 --> Config Class Initialized
INFO - 2021-06-26 11:39:27 --> Loader Class Initialized
INFO - 2021-06-26 11:39:27 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:27 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:27 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:27 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:27 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:27 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:27 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:27 --> Total execution time: 0.2611
INFO - 2021-06-26 11:39:29 --> Config Class Initialized
INFO - 2021-06-26 11:39:29 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:39:29 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:39:29 --> Utf8 Class Initialized
INFO - 2021-06-26 11:39:29 --> URI Class Initialized
INFO - 2021-06-26 11:39:29 --> Router Class Initialized
INFO - 2021-06-26 11:39:29 --> Output Class Initialized
INFO - 2021-06-26 11:39:29 --> Security Class Initialized
DEBUG - 2021-06-26 11:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:39:29 --> Input Class Initialized
INFO - 2021-06-26 11:39:29 --> Language Class Initialized
INFO - 2021-06-26 11:39:29 --> Language Class Initialized
INFO - 2021-06-26 11:39:29 --> Config Class Initialized
INFO - 2021-06-26 11:39:29 --> Loader Class Initialized
INFO - 2021-06-26 11:39:29 --> Helper loaded: url_helper
INFO - 2021-06-26 11:39:29 --> Helper loaded: file_helper
INFO - 2021-06-26 11:39:29 --> Helper loaded: form_helper
INFO - 2021-06-26 11:39:29 --> Helper loaded: my_helper
INFO - 2021-06-26 11:39:29 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:39:29 --> Controller Class Initialized
DEBUG - 2021-06-26 11:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:39:29 --> Final output sent to browser
DEBUG - 2021-06-26 11:39:29 --> Total execution time: 0.1900
INFO - 2021-06-26 11:42:51 --> Config Class Initialized
INFO - 2021-06-26 11:42:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:42:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:42:51 --> Utf8 Class Initialized
INFO - 2021-06-26 11:42:51 --> URI Class Initialized
INFO - 2021-06-26 11:42:51 --> Router Class Initialized
INFO - 2021-06-26 11:42:51 --> Output Class Initialized
INFO - 2021-06-26 11:42:51 --> Security Class Initialized
DEBUG - 2021-06-26 11:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:42:51 --> Input Class Initialized
INFO - 2021-06-26 11:42:51 --> Language Class Initialized
INFO - 2021-06-26 11:42:51 --> Language Class Initialized
INFO - 2021-06-26 11:42:51 --> Config Class Initialized
INFO - 2021-06-26 11:42:51 --> Loader Class Initialized
INFO - 2021-06-26 11:42:51 --> Helper loaded: url_helper
INFO - 2021-06-26 11:42:51 --> Helper loaded: file_helper
INFO - 2021-06-26 11:42:51 --> Helper loaded: form_helper
INFO - 2021-06-26 11:42:51 --> Helper loaded: my_helper
INFO - 2021-06-26 11:42:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:42:51 --> Controller Class Initialized
INFO - 2021-06-26 11:42:51 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:42:51 --> Config Class Initialized
INFO - 2021-06-26 11:42:51 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:42:51 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:42:51 --> Utf8 Class Initialized
INFO - 2021-06-26 11:42:51 --> URI Class Initialized
INFO - 2021-06-26 11:42:51 --> Router Class Initialized
INFO - 2021-06-26 11:42:51 --> Output Class Initialized
INFO - 2021-06-26 11:42:51 --> Security Class Initialized
DEBUG - 2021-06-26 11:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:42:51 --> Input Class Initialized
INFO - 2021-06-26 11:42:51 --> Language Class Initialized
INFO - 2021-06-26 11:42:51 --> Language Class Initialized
INFO - 2021-06-26 11:42:51 --> Config Class Initialized
INFO - 2021-06-26 11:42:51 --> Loader Class Initialized
INFO - 2021-06-26 11:42:51 --> Helper loaded: url_helper
INFO - 2021-06-26 11:42:51 --> Helper loaded: file_helper
INFO - 2021-06-26 11:42:51 --> Helper loaded: form_helper
INFO - 2021-06-26 11:42:51 --> Helper loaded: my_helper
INFO - 2021-06-26 11:42:51 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:42:51 --> Controller Class Initialized
DEBUG - 2021-06-26 11:42:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 11:42:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:42:51 --> Final output sent to browser
DEBUG - 2021-06-26 11:42:51 --> Total execution time: 0.0867
INFO - 2021-06-26 11:42:56 --> Config Class Initialized
INFO - 2021-06-26 11:42:56 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:42:56 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:42:56 --> Utf8 Class Initialized
INFO - 2021-06-26 11:42:56 --> URI Class Initialized
INFO - 2021-06-26 11:42:56 --> Router Class Initialized
INFO - 2021-06-26 11:42:56 --> Output Class Initialized
INFO - 2021-06-26 11:42:56 --> Security Class Initialized
DEBUG - 2021-06-26 11:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:42:56 --> Input Class Initialized
INFO - 2021-06-26 11:42:56 --> Language Class Initialized
INFO - 2021-06-26 11:42:56 --> Language Class Initialized
INFO - 2021-06-26 11:42:56 --> Config Class Initialized
INFO - 2021-06-26 11:42:56 --> Loader Class Initialized
INFO - 2021-06-26 11:42:56 --> Helper loaded: url_helper
INFO - 2021-06-26 11:42:56 --> Helper loaded: file_helper
INFO - 2021-06-26 11:42:56 --> Helper loaded: form_helper
INFO - 2021-06-26 11:42:56 --> Helper loaded: my_helper
INFO - 2021-06-26 11:42:56 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:42:56 --> Controller Class Initialized
INFO - 2021-06-26 11:42:56 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:42:56 --> Final output sent to browser
DEBUG - 2021-06-26 11:42:56 --> Total execution time: 0.0442
INFO - 2021-06-26 11:42:57 --> Config Class Initialized
INFO - 2021-06-26 11:42:57 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:42:57 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:42:57 --> Utf8 Class Initialized
INFO - 2021-06-26 11:42:57 --> URI Class Initialized
INFO - 2021-06-26 11:42:57 --> Router Class Initialized
INFO - 2021-06-26 11:42:57 --> Output Class Initialized
INFO - 2021-06-26 11:42:57 --> Security Class Initialized
DEBUG - 2021-06-26 11:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:42:57 --> Input Class Initialized
INFO - 2021-06-26 11:42:57 --> Language Class Initialized
INFO - 2021-06-26 11:42:57 --> Language Class Initialized
INFO - 2021-06-26 11:42:57 --> Config Class Initialized
INFO - 2021-06-26 11:42:57 --> Loader Class Initialized
INFO - 2021-06-26 11:42:57 --> Helper loaded: url_helper
INFO - 2021-06-26 11:42:57 --> Helper loaded: file_helper
INFO - 2021-06-26 11:42:57 --> Helper loaded: form_helper
INFO - 2021-06-26 11:42:57 --> Helper loaded: my_helper
INFO - 2021-06-26 11:42:57 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:42:57 --> Controller Class Initialized
DEBUG - 2021-06-26 11:42:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-26 11:42:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:42:57 --> Final output sent to browser
DEBUG - 2021-06-26 11:42:57 --> Total execution time: 0.7066
INFO - 2021-06-26 11:43:00 --> Config Class Initialized
INFO - 2021-06-26 11:43:00 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:43:00 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:43:00 --> Utf8 Class Initialized
INFO - 2021-06-26 11:43:00 --> URI Class Initialized
INFO - 2021-06-26 11:43:00 --> Router Class Initialized
INFO - 2021-06-26 11:43:00 --> Output Class Initialized
INFO - 2021-06-26 11:43:00 --> Security Class Initialized
DEBUG - 2021-06-26 11:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:43:00 --> Input Class Initialized
INFO - 2021-06-26 11:43:00 --> Language Class Initialized
INFO - 2021-06-26 11:43:00 --> Language Class Initialized
INFO - 2021-06-26 11:43:00 --> Config Class Initialized
INFO - 2021-06-26 11:43:00 --> Loader Class Initialized
INFO - 2021-06-26 11:43:00 --> Helper loaded: url_helper
INFO - 2021-06-26 11:43:00 --> Helper loaded: file_helper
INFO - 2021-06-26 11:43:00 --> Helper loaded: form_helper
INFO - 2021-06-26 11:43:00 --> Helper loaded: my_helper
INFO - 2021-06-26 11:43:00 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:43:00 --> Controller Class Initialized
DEBUG - 2021-06-26 11:43:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-26 11:43:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:43:00 --> Final output sent to browser
DEBUG - 2021-06-26 11:43:00 --> Total execution time: 0.0729
INFO - 2021-06-26 11:43:05 --> Config Class Initialized
INFO - 2021-06-26 11:43:05 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:43:05 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:43:05 --> Utf8 Class Initialized
INFO - 2021-06-26 11:43:05 --> URI Class Initialized
INFO - 2021-06-26 11:43:05 --> Router Class Initialized
INFO - 2021-06-26 11:43:05 --> Output Class Initialized
INFO - 2021-06-26 11:43:05 --> Security Class Initialized
DEBUG - 2021-06-26 11:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:43:05 --> Input Class Initialized
INFO - 2021-06-26 11:43:05 --> Language Class Initialized
INFO - 2021-06-26 11:43:05 --> Language Class Initialized
INFO - 2021-06-26 11:43:05 --> Config Class Initialized
INFO - 2021-06-26 11:43:05 --> Loader Class Initialized
INFO - 2021-06-26 11:43:05 --> Helper loaded: url_helper
INFO - 2021-06-26 11:43:05 --> Helper loaded: file_helper
INFO - 2021-06-26 11:43:05 --> Helper loaded: form_helper
INFO - 2021-06-26 11:43:05 --> Helper loaded: my_helper
INFO - 2021-06-26 11:43:05 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:43:05 --> Controller Class Initialized
DEBUG - 2021-06-26 11:43:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-06-26 11:43:06 --> Final output sent to browser
DEBUG - 2021-06-26 11:43:06 --> Total execution time: 0.3458
INFO - 2021-06-26 11:43:22 --> Config Class Initialized
INFO - 2021-06-26 11:43:22 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:43:22 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:43:22 --> Utf8 Class Initialized
INFO - 2021-06-26 11:43:22 --> URI Class Initialized
INFO - 2021-06-26 11:43:22 --> Router Class Initialized
INFO - 2021-06-26 11:43:22 --> Output Class Initialized
INFO - 2021-06-26 11:43:22 --> Security Class Initialized
DEBUG - 2021-06-26 11:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:43:22 --> Input Class Initialized
INFO - 2021-06-26 11:43:22 --> Language Class Initialized
INFO - 2021-06-26 11:43:22 --> Language Class Initialized
INFO - 2021-06-26 11:43:22 --> Config Class Initialized
INFO - 2021-06-26 11:43:22 --> Loader Class Initialized
INFO - 2021-06-26 11:43:22 --> Helper loaded: url_helper
INFO - 2021-06-26 11:43:22 --> Helper loaded: file_helper
INFO - 2021-06-26 11:43:22 --> Helper loaded: form_helper
INFO - 2021-06-26 11:43:22 --> Helper loaded: my_helper
INFO - 2021-06-26 11:43:22 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:43:22 --> Controller Class Initialized
DEBUG - 2021-06-26 11:43:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-26 11:43:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:43:22 --> Final output sent to browser
DEBUG - 2021-06-26 11:43:22 --> Total execution time: 0.1278
INFO - 2021-06-26 11:43:24 --> Config Class Initialized
INFO - 2021-06-26 11:43:24 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:43:24 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:43:24 --> Utf8 Class Initialized
INFO - 2021-06-26 11:43:24 --> URI Class Initialized
INFO - 2021-06-26 11:43:24 --> Router Class Initialized
INFO - 2021-06-26 11:43:24 --> Output Class Initialized
INFO - 2021-06-26 11:43:24 --> Security Class Initialized
DEBUG - 2021-06-26 11:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:43:24 --> Input Class Initialized
INFO - 2021-06-26 11:43:24 --> Language Class Initialized
INFO - 2021-06-26 11:43:24 --> Language Class Initialized
INFO - 2021-06-26 11:43:24 --> Config Class Initialized
INFO - 2021-06-26 11:43:24 --> Loader Class Initialized
INFO - 2021-06-26 11:43:24 --> Helper loaded: url_helper
INFO - 2021-06-26 11:43:24 --> Helper loaded: file_helper
INFO - 2021-06-26 11:43:24 --> Helper loaded: form_helper
INFO - 2021-06-26 11:43:24 --> Helper loaded: my_helper
INFO - 2021-06-26 11:43:24 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:43:24 --> Controller Class Initialized
DEBUG - 2021-06-26 11:43:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:43:25 --> Final output sent to browser
DEBUG - 2021-06-26 11:43:25 --> Total execution time: 0.2701
INFO - 2021-06-26 11:43:32 --> Config Class Initialized
INFO - 2021-06-26 11:43:32 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:43:32 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:43:32 --> Utf8 Class Initialized
INFO - 2021-06-26 11:43:32 --> URI Class Initialized
INFO - 2021-06-26 11:43:32 --> Router Class Initialized
INFO - 2021-06-26 11:43:32 --> Output Class Initialized
INFO - 2021-06-26 11:43:32 --> Security Class Initialized
DEBUG - 2021-06-26 11:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:43:32 --> Input Class Initialized
INFO - 2021-06-26 11:43:32 --> Language Class Initialized
INFO - 2021-06-26 11:43:32 --> Language Class Initialized
INFO - 2021-06-26 11:43:32 --> Config Class Initialized
INFO - 2021-06-26 11:43:32 --> Loader Class Initialized
INFO - 2021-06-26 11:43:32 --> Helper loaded: url_helper
INFO - 2021-06-26 11:43:32 --> Helper loaded: file_helper
INFO - 2021-06-26 11:43:32 --> Helper loaded: form_helper
INFO - 2021-06-26 11:43:32 --> Helper loaded: my_helper
INFO - 2021-06-26 11:43:32 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:43:32 --> Controller Class Initialized
DEBUG - 2021-06-26 11:43:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:43:32 --> Final output sent to browser
DEBUG - 2021-06-26 11:43:32 --> Total execution time: 0.1966
INFO - 2021-06-26 11:43:40 --> Config Class Initialized
INFO - 2021-06-26 11:43:40 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:43:40 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:43:40 --> Utf8 Class Initialized
INFO - 2021-06-26 11:43:40 --> URI Class Initialized
INFO - 2021-06-26 11:43:40 --> Router Class Initialized
INFO - 2021-06-26 11:43:40 --> Output Class Initialized
INFO - 2021-06-26 11:43:40 --> Security Class Initialized
DEBUG - 2021-06-26 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:43:40 --> Input Class Initialized
INFO - 2021-06-26 11:43:40 --> Language Class Initialized
INFO - 2021-06-26 11:43:40 --> Language Class Initialized
INFO - 2021-06-26 11:43:40 --> Config Class Initialized
INFO - 2021-06-26 11:43:40 --> Loader Class Initialized
INFO - 2021-06-26 11:43:40 --> Helper loaded: url_helper
INFO - 2021-06-26 11:43:40 --> Helper loaded: file_helper
INFO - 2021-06-26 11:43:40 --> Helper loaded: form_helper
INFO - 2021-06-26 11:43:40 --> Helper loaded: my_helper
INFO - 2021-06-26 11:43:40 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:43:40 --> Controller Class Initialized
DEBUG - 2021-06-26 11:43:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:43:40 --> Final output sent to browser
DEBUG - 2021-06-26 11:43:40 --> Total execution time: 0.1933
INFO - 2021-06-26 11:43:59 --> Config Class Initialized
INFO - 2021-06-26 11:43:59 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:43:59 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:43:59 --> Utf8 Class Initialized
INFO - 2021-06-26 11:43:59 --> URI Class Initialized
INFO - 2021-06-26 11:43:59 --> Router Class Initialized
INFO - 2021-06-26 11:43:59 --> Output Class Initialized
INFO - 2021-06-26 11:43:59 --> Security Class Initialized
DEBUG - 2021-06-26 11:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:43:59 --> Input Class Initialized
INFO - 2021-06-26 11:43:59 --> Language Class Initialized
INFO - 2021-06-26 11:43:59 --> Language Class Initialized
INFO - 2021-06-26 11:43:59 --> Config Class Initialized
INFO - 2021-06-26 11:43:59 --> Loader Class Initialized
INFO - 2021-06-26 11:43:59 --> Helper loaded: url_helper
INFO - 2021-06-26 11:43:59 --> Helper loaded: file_helper
INFO - 2021-06-26 11:43:59 --> Helper loaded: form_helper
INFO - 2021-06-26 11:43:59 --> Helper loaded: my_helper
INFO - 2021-06-26 11:43:59 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:43:59 --> Controller Class Initialized
DEBUG - 2021-06-26 11:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:43:59 --> Final output sent to browser
DEBUG - 2021-06-26 11:43:59 --> Total execution time: 0.1933
INFO - 2021-06-26 11:44:00 --> Config Class Initialized
INFO - 2021-06-26 11:44:00 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:44:00 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:44:00 --> Utf8 Class Initialized
INFO - 2021-06-26 11:44:00 --> URI Class Initialized
INFO - 2021-06-26 11:44:00 --> Router Class Initialized
INFO - 2021-06-26 11:44:00 --> Output Class Initialized
INFO - 2021-06-26 11:44:00 --> Security Class Initialized
DEBUG - 2021-06-26 11:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:44:00 --> Input Class Initialized
INFO - 2021-06-26 11:44:00 --> Language Class Initialized
INFO - 2021-06-26 11:44:00 --> Language Class Initialized
INFO - 2021-06-26 11:44:00 --> Config Class Initialized
INFO - 2021-06-26 11:44:00 --> Loader Class Initialized
INFO - 2021-06-26 11:44:00 --> Helper loaded: url_helper
INFO - 2021-06-26 11:44:00 --> Helper loaded: file_helper
INFO - 2021-06-26 11:44:00 --> Helper loaded: form_helper
INFO - 2021-06-26 11:44:00 --> Helper loaded: my_helper
INFO - 2021-06-26 11:44:00 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:44:00 --> Controller Class Initialized
DEBUG - 2021-06-26 11:44:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-26 11:44:00 --> Final output sent to browser
DEBUG - 2021-06-26 11:44:00 --> Total execution time: 0.1908
INFO - 2021-06-26 11:44:56 --> Config Class Initialized
INFO - 2021-06-26 11:44:56 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:44:56 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:44:56 --> Utf8 Class Initialized
INFO - 2021-06-26 11:44:56 --> URI Class Initialized
INFO - 2021-06-26 11:44:56 --> Router Class Initialized
INFO - 2021-06-26 11:44:56 --> Output Class Initialized
INFO - 2021-06-26 11:44:56 --> Security Class Initialized
DEBUG - 2021-06-26 11:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:44:56 --> Input Class Initialized
INFO - 2021-06-26 11:44:56 --> Language Class Initialized
INFO - 2021-06-26 11:44:56 --> Language Class Initialized
INFO - 2021-06-26 11:44:56 --> Config Class Initialized
INFO - 2021-06-26 11:44:56 --> Loader Class Initialized
INFO - 2021-06-26 11:44:56 --> Helper loaded: url_helper
INFO - 2021-06-26 11:44:56 --> Helper loaded: file_helper
INFO - 2021-06-26 11:44:56 --> Helper loaded: form_helper
INFO - 2021-06-26 11:44:56 --> Helper loaded: my_helper
INFO - 2021-06-26 11:44:56 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:44:56 --> Controller Class Initialized
INFO - 2021-06-26 11:44:56 --> Helper loaded: cookie_helper
INFO - 2021-06-26 11:44:56 --> Config Class Initialized
INFO - 2021-06-26 11:44:56 --> Hooks Class Initialized
DEBUG - 2021-06-26 11:44:56 --> UTF-8 Support Enabled
INFO - 2021-06-26 11:44:56 --> Utf8 Class Initialized
INFO - 2021-06-26 11:44:56 --> URI Class Initialized
INFO - 2021-06-26 11:44:56 --> Router Class Initialized
INFO - 2021-06-26 11:44:56 --> Output Class Initialized
INFO - 2021-06-26 11:44:56 --> Security Class Initialized
DEBUG - 2021-06-26 11:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-26 11:44:56 --> Input Class Initialized
INFO - 2021-06-26 11:44:56 --> Language Class Initialized
INFO - 2021-06-26 11:44:56 --> Language Class Initialized
INFO - 2021-06-26 11:44:56 --> Config Class Initialized
INFO - 2021-06-26 11:44:56 --> Loader Class Initialized
INFO - 2021-06-26 11:44:56 --> Helper loaded: url_helper
INFO - 2021-06-26 11:44:56 --> Helper loaded: file_helper
INFO - 2021-06-26 11:44:56 --> Helper loaded: form_helper
INFO - 2021-06-26 11:44:56 --> Helper loaded: my_helper
INFO - 2021-06-26 11:44:56 --> Database Driver Class Initialized
DEBUG - 2021-06-26 11:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-26 11:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-26 11:44:56 --> Controller Class Initialized
DEBUG - 2021-06-26 11:44:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-26 11:44:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-26 11:44:56 --> Final output sent to browser
DEBUG - 2021-06-26 11:44:56 --> Total execution time: 0.0497
