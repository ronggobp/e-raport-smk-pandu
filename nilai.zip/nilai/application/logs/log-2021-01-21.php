<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-21 02:15:57 --> Config Class Initialized
INFO - 2021-01-21 02:15:57 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:15:57 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:15:57 --> Utf8 Class Initialized
INFO - 2021-01-21 02:15:57 --> URI Class Initialized
DEBUG - 2021-01-21 02:15:57 --> No URI present. Default controller set.
INFO - 2021-01-21 02:15:57 --> Router Class Initialized
INFO - 2021-01-21 02:15:57 --> Output Class Initialized
INFO - 2021-01-21 02:15:57 --> Security Class Initialized
DEBUG - 2021-01-21 02:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:15:57 --> Input Class Initialized
INFO - 2021-01-21 02:15:57 --> Language Class Initialized
INFO - 2021-01-21 02:15:57 --> Language Class Initialized
INFO - 2021-01-21 02:15:57 --> Config Class Initialized
INFO - 2021-01-21 02:15:57 --> Loader Class Initialized
INFO - 2021-01-21 02:15:57 --> Helper loaded: url_helper
INFO - 2021-01-21 02:15:57 --> Helper loaded: file_helper
INFO - 2021-01-21 02:15:57 --> Helper loaded: form_helper
INFO - 2021-01-21 02:15:57 --> Helper loaded: my_helper
INFO - 2021-01-21 02:15:57 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:15:57 --> Controller Class Initialized
INFO - 2021-01-21 02:15:57 --> Config Class Initialized
INFO - 2021-01-21 02:15:57 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:15:57 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:15:57 --> Utf8 Class Initialized
INFO - 2021-01-21 02:15:57 --> URI Class Initialized
INFO - 2021-01-21 02:15:57 --> Router Class Initialized
INFO - 2021-01-21 02:15:57 --> Output Class Initialized
INFO - 2021-01-21 02:15:57 --> Security Class Initialized
DEBUG - 2021-01-21 02:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:15:57 --> Input Class Initialized
INFO - 2021-01-21 02:15:57 --> Language Class Initialized
INFO - 2021-01-21 02:15:57 --> Language Class Initialized
INFO - 2021-01-21 02:15:57 --> Config Class Initialized
INFO - 2021-01-21 02:15:58 --> Loader Class Initialized
INFO - 2021-01-21 02:15:58 --> Helper loaded: url_helper
INFO - 2021-01-21 02:15:58 --> Helper loaded: file_helper
INFO - 2021-01-21 02:15:58 --> Helper loaded: form_helper
INFO - 2021-01-21 02:15:58 --> Helper loaded: my_helper
INFO - 2021-01-21 02:15:58 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:15:58 --> Controller Class Initialized
DEBUG - 2021-01-21 02:15:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 02:15:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:15:58 --> Final output sent to browser
DEBUG - 2021-01-21 02:15:58 --> Total execution time: 0.4181
INFO - 2021-01-21 02:16:56 --> Config Class Initialized
INFO - 2021-01-21 02:16:56 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:16:56 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:16:56 --> Utf8 Class Initialized
INFO - 2021-01-21 02:16:56 --> URI Class Initialized
INFO - 2021-01-21 02:16:56 --> Router Class Initialized
INFO - 2021-01-21 02:16:56 --> Output Class Initialized
INFO - 2021-01-21 02:16:56 --> Security Class Initialized
DEBUG - 2021-01-21 02:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:16:56 --> Input Class Initialized
INFO - 2021-01-21 02:16:56 --> Language Class Initialized
INFO - 2021-01-21 02:16:56 --> Language Class Initialized
INFO - 2021-01-21 02:16:56 --> Config Class Initialized
INFO - 2021-01-21 02:16:56 --> Loader Class Initialized
INFO - 2021-01-21 02:16:56 --> Helper loaded: url_helper
INFO - 2021-01-21 02:16:56 --> Helper loaded: file_helper
INFO - 2021-01-21 02:16:56 --> Helper loaded: form_helper
INFO - 2021-01-21 02:16:56 --> Helper loaded: my_helper
INFO - 2021-01-21 02:16:56 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:16:56 --> Controller Class Initialized
INFO - 2021-01-21 02:16:56 --> Helper loaded: cookie_helper
INFO - 2021-01-21 02:16:56 --> Final output sent to browser
DEBUG - 2021-01-21 02:16:56 --> Total execution time: 0.9204
INFO - 2021-01-21 02:16:57 --> Config Class Initialized
INFO - 2021-01-21 02:16:57 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:16:57 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:16:57 --> Utf8 Class Initialized
INFO - 2021-01-21 02:16:57 --> URI Class Initialized
INFO - 2021-01-21 02:16:57 --> Router Class Initialized
INFO - 2021-01-21 02:16:57 --> Output Class Initialized
INFO - 2021-01-21 02:16:57 --> Security Class Initialized
DEBUG - 2021-01-21 02:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:16:57 --> Input Class Initialized
INFO - 2021-01-21 02:16:57 --> Language Class Initialized
INFO - 2021-01-21 02:16:58 --> Language Class Initialized
INFO - 2021-01-21 02:16:58 --> Config Class Initialized
INFO - 2021-01-21 02:16:58 --> Loader Class Initialized
INFO - 2021-01-21 02:16:58 --> Helper loaded: url_helper
INFO - 2021-01-21 02:16:58 --> Helper loaded: file_helper
INFO - 2021-01-21 02:16:58 --> Helper loaded: form_helper
INFO - 2021-01-21 02:16:58 --> Helper loaded: my_helper
INFO - 2021-01-21 02:16:58 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:16:58 --> Controller Class Initialized
DEBUG - 2021-01-21 02:16:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 02:16:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:16:58 --> Final output sent to browser
DEBUG - 2021-01-21 02:16:58 --> Total execution time: 1.0898
INFO - 2021-01-21 02:17:39 --> Config Class Initialized
INFO - 2021-01-21 02:17:39 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:17:39 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:17:39 --> Utf8 Class Initialized
INFO - 2021-01-21 02:17:39 --> URI Class Initialized
INFO - 2021-01-21 02:17:39 --> Router Class Initialized
INFO - 2021-01-21 02:17:39 --> Output Class Initialized
INFO - 2021-01-21 02:17:39 --> Security Class Initialized
DEBUG - 2021-01-21 02:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:17:39 --> Input Class Initialized
INFO - 2021-01-21 02:17:39 --> Language Class Initialized
INFO - 2021-01-21 02:17:39 --> Language Class Initialized
INFO - 2021-01-21 02:17:39 --> Config Class Initialized
INFO - 2021-01-21 02:17:39 --> Loader Class Initialized
INFO - 2021-01-21 02:17:39 --> Helper loaded: url_helper
INFO - 2021-01-21 02:17:40 --> Helper loaded: file_helper
INFO - 2021-01-21 02:17:40 --> Helper loaded: form_helper
INFO - 2021-01-21 02:17:40 --> Helper loaded: my_helper
INFO - 2021-01-21 02:17:40 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:17:40 --> Controller Class Initialized
DEBUG - 2021-01-21 02:17:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 02:17:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:17:40 --> Final output sent to browser
DEBUG - 2021-01-21 02:17:40 --> Total execution time: 0.9826
INFO - 2021-01-21 02:17:41 --> Config Class Initialized
INFO - 2021-01-21 02:17:41 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:17:41 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:17:41 --> Utf8 Class Initialized
INFO - 2021-01-21 02:17:41 --> URI Class Initialized
INFO - 2021-01-21 02:17:41 --> Router Class Initialized
INFO - 2021-01-21 02:17:41 --> Output Class Initialized
INFO - 2021-01-21 02:17:41 --> Security Class Initialized
DEBUG - 2021-01-21 02:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:17:41 --> Input Class Initialized
INFO - 2021-01-21 02:17:41 --> Language Class Initialized
INFO - 2021-01-21 02:17:41 --> Language Class Initialized
INFO - 2021-01-21 02:17:41 --> Config Class Initialized
INFO - 2021-01-21 02:17:41 --> Loader Class Initialized
INFO - 2021-01-21 02:17:41 --> Helper loaded: url_helper
INFO - 2021-01-21 02:17:41 --> Helper loaded: file_helper
INFO - 2021-01-21 02:17:41 --> Helper loaded: form_helper
INFO - 2021-01-21 02:17:41 --> Helper loaded: my_helper
INFO - 2021-01-21 02:17:41 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:17:41 --> Controller Class Initialized
DEBUG - 2021-01-21 02:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-21 02:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:17:42 --> Final output sent to browser
DEBUG - 2021-01-21 02:17:42 --> Total execution time: 0.7327
INFO - 2021-01-21 02:18:06 --> Config Class Initialized
INFO - 2021-01-21 02:18:06 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:18:06 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:18:06 --> Utf8 Class Initialized
INFO - 2021-01-21 02:18:06 --> URI Class Initialized
INFO - 2021-01-21 02:18:06 --> Router Class Initialized
INFO - 2021-01-21 02:18:06 --> Output Class Initialized
INFO - 2021-01-21 02:18:06 --> Security Class Initialized
DEBUG - 2021-01-21 02:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:18:06 --> Input Class Initialized
INFO - 2021-01-21 02:18:06 --> Language Class Initialized
INFO - 2021-01-21 02:18:06 --> Language Class Initialized
INFO - 2021-01-21 02:18:06 --> Config Class Initialized
INFO - 2021-01-21 02:18:06 --> Loader Class Initialized
INFO - 2021-01-21 02:18:06 --> Helper loaded: url_helper
INFO - 2021-01-21 02:18:06 --> Helper loaded: file_helper
INFO - 2021-01-21 02:18:06 --> Helper loaded: form_helper
INFO - 2021-01-21 02:18:06 --> Helper loaded: my_helper
INFO - 2021-01-21 02:18:06 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:18:06 --> Controller Class Initialized
DEBUG - 2021-01-21 02:18:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:18:07 --> Final output sent to browser
DEBUG - 2021-01-21 02:18:07 --> Total execution time: 0.6742
INFO - 2021-01-21 02:18:30 --> Config Class Initialized
INFO - 2021-01-21 02:18:30 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:18:30 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:18:30 --> Utf8 Class Initialized
INFO - 2021-01-21 02:18:30 --> URI Class Initialized
INFO - 2021-01-21 02:18:30 --> Router Class Initialized
INFO - 2021-01-21 02:18:30 --> Output Class Initialized
INFO - 2021-01-21 02:18:30 --> Security Class Initialized
DEBUG - 2021-01-21 02:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:18:30 --> Input Class Initialized
INFO - 2021-01-21 02:18:30 --> Language Class Initialized
INFO - 2021-01-21 02:18:30 --> Language Class Initialized
INFO - 2021-01-21 02:18:30 --> Config Class Initialized
INFO - 2021-01-21 02:18:30 --> Loader Class Initialized
INFO - 2021-01-21 02:18:30 --> Helper loaded: url_helper
INFO - 2021-01-21 02:18:30 --> Helper loaded: file_helper
INFO - 2021-01-21 02:18:30 --> Helper loaded: form_helper
INFO - 2021-01-21 02:18:30 --> Helper loaded: my_helper
INFO - 2021-01-21 02:18:30 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:18:30 --> Controller Class Initialized
DEBUG - 2021-01-21 02:18:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:18:30 --> Final output sent to browser
DEBUG - 2021-01-21 02:18:30 --> Total execution time: 0.7812
INFO - 2021-01-21 02:18:34 --> Config Class Initialized
INFO - 2021-01-21 02:18:34 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:18:35 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:18:35 --> Utf8 Class Initialized
INFO - 2021-01-21 02:18:35 --> URI Class Initialized
INFO - 2021-01-21 02:18:35 --> Router Class Initialized
INFO - 2021-01-21 02:18:35 --> Output Class Initialized
INFO - 2021-01-21 02:18:35 --> Security Class Initialized
DEBUG - 2021-01-21 02:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:18:35 --> Input Class Initialized
INFO - 2021-01-21 02:18:35 --> Language Class Initialized
INFO - 2021-01-21 02:18:35 --> Language Class Initialized
INFO - 2021-01-21 02:18:35 --> Config Class Initialized
INFO - 2021-01-21 02:18:35 --> Loader Class Initialized
INFO - 2021-01-21 02:18:35 --> Helper loaded: url_helper
INFO - 2021-01-21 02:18:35 --> Helper loaded: file_helper
INFO - 2021-01-21 02:18:35 --> Helper loaded: form_helper
INFO - 2021-01-21 02:18:35 --> Helper loaded: my_helper
INFO - 2021-01-21 02:18:35 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:18:35 --> Controller Class Initialized
DEBUG - 2021-01-21 02:18:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:18:35 --> Final output sent to browser
DEBUG - 2021-01-21 02:18:35 --> Total execution time: 0.8970
INFO - 2021-01-21 02:19:16 --> Config Class Initialized
INFO - 2021-01-21 02:19:17 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:19:17 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:19:17 --> Utf8 Class Initialized
INFO - 2021-01-21 02:19:17 --> URI Class Initialized
INFO - 2021-01-21 02:19:17 --> Router Class Initialized
INFO - 2021-01-21 02:19:17 --> Output Class Initialized
INFO - 2021-01-21 02:19:17 --> Security Class Initialized
DEBUG - 2021-01-21 02:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:19:17 --> Input Class Initialized
INFO - 2021-01-21 02:19:17 --> Language Class Initialized
INFO - 2021-01-21 02:19:17 --> Language Class Initialized
INFO - 2021-01-21 02:19:17 --> Config Class Initialized
INFO - 2021-01-21 02:19:17 --> Loader Class Initialized
INFO - 2021-01-21 02:19:17 --> Helper loaded: url_helper
INFO - 2021-01-21 02:19:17 --> Helper loaded: file_helper
INFO - 2021-01-21 02:19:17 --> Helper loaded: form_helper
INFO - 2021-01-21 02:19:17 --> Helper loaded: my_helper
INFO - 2021-01-21 02:19:17 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:19:17 --> Controller Class Initialized
DEBUG - 2021-01-21 02:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:19:17 --> Final output sent to browser
DEBUG - 2021-01-21 02:19:18 --> Total execution time: 0.9661
INFO - 2021-01-21 02:21:48 --> Config Class Initialized
INFO - 2021-01-21 02:21:48 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:21:48 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:21:48 --> Utf8 Class Initialized
INFO - 2021-01-21 02:21:48 --> URI Class Initialized
INFO - 2021-01-21 02:21:48 --> Router Class Initialized
INFO - 2021-01-21 02:21:48 --> Output Class Initialized
INFO - 2021-01-21 02:21:48 --> Security Class Initialized
DEBUG - 2021-01-21 02:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:21:48 --> Input Class Initialized
INFO - 2021-01-21 02:21:48 --> Language Class Initialized
INFO - 2021-01-21 02:21:48 --> Language Class Initialized
INFO - 2021-01-21 02:21:48 --> Config Class Initialized
INFO - 2021-01-21 02:21:48 --> Loader Class Initialized
INFO - 2021-01-21 02:21:48 --> Helper loaded: url_helper
INFO - 2021-01-21 02:21:48 --> Helper loaded: file_helper
INFO - 2021-01-21 02:21:48 --> Helper loaded: form_helper
INFO - 2021-01-21 02:21:48 --> Helper loaded: my_helper
INFO - 2021-01-21 02:21:48 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:21:48 --> Controller Class Initialized
DEBUG - 2021-01-21 02:21:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:21:49 --> Final output sent to browser
DEBUG - 2021-01-21 02:21:49 --> Total execution time: 0.9380
INFO - 2021-01-21 02:21:51 --> Config Class Initialized
INFO - 2021-01-21 02:21:51 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:21:51 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:21:51 --> Utf8 Class Initialized
INFO - 2021-01-21 02:21:51 --> URI Class Initialized
INFO - 2021-01-21 02:21:51 --> Router Class Initialized
INFO - 2021-01-21 02:21:51 --> Output Class Initialized
INFO - 2021-01-21 02:21:52 --> Security Class Initialized
DEBUG - 2021-01-21 02:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:21:52 --> Input Class Initialized
INFO - 2021-01-21 02:21:52 --> Language Class Initialized
INFO - 2021-01-21 02:21:52 --> Language Class Initialized
INFO - 2021-01-21 02:21:52 --> Config Class Initialized
INFO - 2021-01-21 02:21:52 --> Loader Class Initialized
INFO - 2021-01-21 02:21:52 --> Helper loaded: url_helper
INFO - 2021-01-21 02:21:52 --> Helper loaded: file_helper
INFO - 2021-01-21 02:21:52 --> Helper loaded: form_helper
INFO - 2021-01-21 02:21:52 --> Helper loaded: my_helper
INFO - 2021-01-21 02:21:52 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:21:52 --> Controller Class Initialized
INFO - 2021-01-21 02:21:52 --> Helper loaded: cookie_helper
INFO - 2021-01-21 02:21:52 --> Config Class Initialized
INFO - 2021-01-21 02:21:52 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:21:52 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:21:52 --> Utf8 Class Initialized
INFO - 2021-01-21 02:21:52 --> URI Class Initialized
INFO - 2021-01-21 02:21:52 --> Router Class Initialized
INFO - 2021-01-21 02:21:52 --> Output Class Initialized
INFO - 2021-01-21 02:21:53 --> Security Class Initialized
DEBUG - 2021-01-21 02:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:21:53 --> Input Class Initialized
INFO - 2021-01-21 02:21:53 --> Language Class Initialized
INFO - 2021-01-21 02:21:53 --> Language Class Initialized
INFO - 2021-01-21 02:21:53 --> Config Class Initialized
INFO - 2021-01-21 02:21:53 --> Loader Class Initialized
INFO - 2021-01-21 02:21:53 --> Helper loaded: url_helper
INFO - 2021-01-21 02:21:53 --> Helper loaded: file_helper
INFO - 2021-01-21 02:21:53 --> Helper loaded: form_helper
INFO - 2021-01-21 02:21:53 --> Helper loaded: my_helper
INFO - 2021-01-21 02:21:53 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:21:53 --> Controller Class Initialized
DEBUG - 2021-01-21 02:21:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 02:21:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:21:53 --> Final output sent to browser
DEBUG - 2021-01-21 02:21:53 --> Total execution time: 0.9976
INFO - 2021-01-21 02:22:02 --> Config Class Initialized
INFO - 2021-01-21 02:22:02 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:22:02 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:22:02 --> Utf8 Class Initialized
INFO - 2021-01-21 02:22:02 --> URI Class Initialized
INFO - 2021-01-21 02:22:02 --> Router Class Initialized
INFO - 2021-01-21 02:22:02 --> Output Class Initialized
INFO - 2021-01-21 02:22:02 --> Security Class Initialized
DEBUG - 2021-01-21 02:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:22:02 --> Input Class Initialized
INFO - 2021-01-21 02:22:02 --> Language Class Initialized
INFO - 2021-01-21 02:22:02 --> Language Class Initialized
INFO - 2021-01-21 02:22:02 --> Config Class Initialized
INFO - 2021-01-21 02:22:02 --> Loader Class Initialized
INFO - 2021-01-21 02:22:02 --> Helper loaded: url_helper
INFO - 2021-01-21 02:22:03 --> Helper loaded: file_helper
INFO - 2021-01-21 02:22:03 --> Helper loaded: form_helper
INFO - 2021-01-21 02:22:03 --> Helper loaded: my_helper
INFO - 2021-01-21 02:22:03 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:22:03 --> Controller Class Initialized
INFO - 2021-01-21 02:22:03 --> Helper loaded: cookie_helper
INFO - 2021-01-21 02:22:03 --> Final output sent to browser
DEBUG - 2021-01-21 02:22:03 --> Total execution time: 1.1201
INFO - 2021-01-21 02:22:05 --> Config Class Initialized
INFO - 2021-01-21 02:22:05 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:22:05 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:22:05 --> Utf8 Class Initialized
INFO - 2021-01-21 02:22:05 --> URI Class Initialized
INFO - 2021-01-21 02:22:05 --> Router Class Initialized
INFO - 2021-01-21 02:22:05 --> Output Class Initialized
INFO - 2021-01-21 02:22:05 --> Security Class Initialized
DEBUG - 2021-01-21 02:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:22:05 --> Input Class Initialized
INFO - 2021-01-21 02:22:05 --> Language Class Initialized
INFO - 2021-01-21 02:22:05 --> Language Class Initialized
INFO - 2021-01-21 02:22:06 --> Config Class Initialized
INFO - 2021-01-21 02:22:06 --> Loader Class Initialized
INFO - 2021-01-21 02:22:06 --> Helper loaded: url_helper
INFO - 2021-01-21 02:22:06 --> Helper loaded: file_helper
INFO - 2021-01-21 02:22:06 --> Helper loaded: form_helper
INFO - 2021-01-21 02:22:06 --> Helper loaded: my_helper
INFO - 2021-01-21 02:22:06 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:22:06 --> Controller Class Initialized
DEBUG - 2021-01-21 02:22:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 02:22:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:22:06 --> Final output sent to browser
DEBUG - 2021-01-21 02:22:06 --> Total execution time: 1.1267
INFO - 2021-01-21 02:22:10 --> Config Class Initialized
INFO - 2021-01-21 02:22:10 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:22:10 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:22:10 --> Utf8 Class Initialized
INFO - 2021-01-21 02:22:10 --> URI Class Initialized
INFO - 2021-01-21 02:22:10 --> Router Class Initialized
INFO - 2021-01-21 02:22:10 --> Output Class Initialized
INFO - 2021-01-21 02:22:10 --> Security Class Initialized
DEBUG - 2021-01-21 02:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:22:10 --> Input Class Initialized
INFO - 2021-01-21 02:22:10 --> Language Class Initialized
INFO - 2021-01-21 02:22:10 --> Language Class Initialized
INFO - 2021-01-21 02:22:10 --> Config Class Initialized
INFO - 2021-01-21 02:22:11 --> Loader Class Initialized
INFO - 2021-01-21 02:22:11 --> Helper loaded: url_helper
INFO - 2021-01-21 02:22:11 --> Helper loaded: file_helper
INFO - 2021-01-21 02:22:11 --> Helper loaded: form_helper
INFO - 2021-01-21 02:22:11 --> Helper loaded: my_helper
INFO - 2021-01-21 02:22:11 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:22:11 --> Controller Class Initialized
DEBUG - 2021-01-21 02:22:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-21 02:22:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:22:11 --> Final output sent to browser
DEBUG - 2021-01-21 02:22:11 --> Total execution time: 0.9461
INFO - 2021-01-21 02:22:14 --> Config Class Initialized
INFO - 2021-01-21 02:22:14 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:22:14 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:22:14 --> Utf8 Class Initialized
INFO - 2021-01-21 02:22:14 --> URI Class Initialized
INFO - 2021-01-21 02:22:14 --> Router Class Initialized
INFO - 2021-01-21 02:22:14 --> Output Class Initialized
INFO - 2021-01-21 02:22:14 --> Security Class Initialized
DEBUG - 2021-01-21 02:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:22:14 --> Input Class Initialized
INFO - 2021-01-21 02:22:14 --> Language Class Initialized
INFO - 2021-01-21 02:22:14 --> Language Class Initialized
INFO - 2021-01-21 02:22:14 --> Config Class Initialized
INFO - 2021-01-21 02:22:14 --> Loader Class Initialized
INFO - 2021-01-21 02:22:14 --> Helper loaded: url_helper
INFO - 2021-01-21 02:22:14 --> Helper loaded: file_helper
INFO - 2021-01-21 02:22:14 --> Helper loaded: form_helper
INFO - 2021-01-21 02:22:14 --> Helper loaded: my_helper
INFO - 2021-01-21 02:22:14 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:22:14 --> Controller Class Initialized
DEBUG - 2021-01-21 02:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-01-21 02:22:14 --> Final output sent to browser
DEBUG - 2021-01-21 02:22:14 --> Total execution time: 0.8594
INFO - 2021-01-21 02:23:55 --> Config Class Initialized
INFO - 2021-01-21 02:23:55 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:23:55 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:23:55 --> Utf8 Class Initialized
INFO - 2021-01-21 02:23:55 --> URI Class Initialized
INFO - 2021-01-21 02:23:56 --> Router Class Initialized
INFO - 2021-01-21 02:23:56 --> Output Class Initialized
INFO - 2021-01-21 02:23:56 --> Security Class Initialized
DEBUG - 2021-01-21 02:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:23:56 --> Input Class Initialized
INFO - 2021-01-21 02:23:56 --> Language Class Initialized
INFO - 2021-01-21 02:23:56 --> Language Class Initialized
INFO - 2021-01-21 02:23:56 --> Config Class Initialized
INFO - 2021-01-21 02:23:56 --> Loader Class Initialized
INFO - 2021-01-21 02:23:56 --> Helper loaded: url_helper
INFO - 2021-01-21 02:23:56 --> Helper loaded: file_helper
INFO - 2021-01-21 02:23:56 --> Helper loaded: form_helper
INFO - 2021-01-21 02:23:56 --> Helper loaded: my_helper
INFO - 2021-01-21 02:23:56 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:23:56 --> Controller Class Initialized
DEBUG - 2021-01-21 02:23:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-21 02:23:56 --> Final output sent to browser
DEBUG - 2021-01-21 02:23:56 --> Total execution time: 0.8066
INFO - 2021-01-21 02:24:02 --> Config Class Initialized
INFO - 2021-01-21 02:24:02 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:24:03 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:24:03 --> Utf8 Class Initialized
INFO - 2021-01-21 02:24:03 --> URI Class Initialized
INFO - 2021-01-21 02:24:03 --> Router Class Initialized
INFO - 2021-01-21 02:24:03 --> Output Class Initialized
INFO - 2021-01-21 02:24:03 --> Security Class Initialized
DEBUG - 2021-01-21 02:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:24:03 --> Input Class Initialized
INFO - 2021-01-21 02:24:03 --> Language Class Initialized
INFO - 2021-01-21 02:24:03 --> Language Class Initialized
INFO - 2021-01-21 02:24:03 --> Config Class Initialized
INFO - 2021-01-21 02:24:03 --> Loader Class Initialized
INFO - 2021-01-21 02:24:03 --> Helper loaded: url_helper
INFO - 2021-01-21 02:24:03 --> Helper loaded: file_helper
INFO - 2021-01-21 02:24:03 --> Helper loaded: form_helper
INFO - 2021-01-21 02:24:03 --> Helper loaded: my_helper
INFO - 2021-01-21 02:24:03 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:24:03 --> Controller Class Initialized
DEBUG - 2021-01-21 02:24:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-21 02:24:03 --> Final output sent to browser
DEBUG - 2021-01-21 02:24:03 --> Total execution time: 0.7810
INFO - 2021-01-21 02:24:05 --> Config Class Initialized
INFO - 2021-01-21 02:24:05 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:24:06 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:24:06 --> Utf8 Class Initialized
INFO - 2021-01-21 02:24:06 --> URI Class Initialized
INFO - 2021-01-21 02:24:06 --> Router Class Initialized
INFO - 2021-01-21 02:24:06 --> Output Class Initialized
INFO - 2021-01-21 02:24:06 --> Security Class Initialized
DEBUG - 2021-01-21 02:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:24:06 --> Input Class Initialized
INFO - 2021-01-21 02:24:06 --> Language Class Initialized
INFO - 2021-01-21 02:24:06 --> Language Class Initialized
INFO - 2021-01-21 02:24:06 --> Config Class Initialized
INFO - 2021-01-21 02:24:06 --> Loader Class Initialized
INFO - 2021-01-21 02:24:06 --> Helper loaded: url_helper
INFO - 2021-01-21 02:24:06 --> Helper loaded: file_helper
INFO - 2021-01-21 02:24:06 --> Helper loaded: form_helper
INFO - 2021-01-21 02:24:06 --> Helper loaded: my_helper
INFO - 2021-01-21 02:24:06 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:24:06 --> Controller Class Initialized
DEBUG - 2021-01-21 02:24:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-01-21 02:24:06 --> Final output sent to browser
DEBUG - 2021-01-21 02:24:06 --> Total execution time: 0.9578
INFO - 2021-01-21 02:31:31 --> Config Class Initialized
INFO - 2021-01-21 02:31:31 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:31:31 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:31:31 --> Utf8 Class Initialized
INFO - 2021-01-21 02:31:31 --> URI Class Initialized
INFO - 2021-01-21 02:31:31 --> Router Class Initialized
INFO - 2021-01-21 02:31:31 --> Output Class Initialized
INFO - 2021-01-21 02:31:31 --> Security Class Initialized
DEBUG - 2021-01-21 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:31:31 --> Input Class Initialized
INFO - 2021-01-21 02:31:32 --> Language Class Initialized
INFO - 2021-01-21 02:31:32 --> Language Class Initialized
INFO - 2021-01-21 02:31:32 --> Config Class Initialized
INFO - 2021-01-21 02:31:32 --> Loader Class Initialized
INFO - 2021-01-21 02:31:32 --> Helper loaded: url_helper
INFO - 2021-01-21 02:31:32 --> Helper loaded: file_helper
INFO - 2021-01-21 02:31:32 --> Helper loaded: form_helper
INFO - 2021-01-21 02:31:32 --> Helper loaded: my_helper
INFO - 2021-01-21 02:31:32 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:31:32 --> Controller Class Initialized
INFO - 2021-01-21 02:31:32 --> Helper loaded: cookie_helper
INFO - 2021-01-21 02:31:32 --> Config Class Initialized
INFO - 2021-01-21 02:31:32 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:31:32 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:31:32 --> Utf8 Class Initialized
INFO - 2021-01-21 02:31:32 --> URI Class Initialized
INFO - 2021-01-21 02:31:32 --> Router Class Initialized
INFO - 2021-01-21 02:31:32 --> Output Class Initialized
INFO - 2021-01-21 02:31:32 --> Security Class Initialized
DEBUG - 2021-01-21 02:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:31:32 --> Input Class Initialized
INFO - 2021-01-21 02:31:33 --> Language Class Initialized
INFO - 2021-01-21 02:31:33 --> Language Class Initialized
INFO - 2021-01-21 02:31:33 --> Config Class Initialized
INFO - 2021-01-21 02:31:33 --> Loader Class Initialized
INFO - 2021-01-21 02:31:33 --> Helper loaded: url_helper
INFO - 2021-01-21 02:31:33 --> Helper loaded: file_helper
INFO - 2021-01-21 02:31:33 --> Helper loaded: form_helper
INFO - 2021-01-21 02:31:33 --> Helper loaded: my_helper
INFO - 2021-01-21 02:31:33 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:31:33 --> Controller Class Initialized
DEBUG - 2021-01-21 02:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 02:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:31:33 --> Final output sent to browser
DEBUG - 2021-01-21 02:31:33 --> Total execution time: 0.8593
INFO - 2021-01-21 02:31:42 --> Config Class Initialized
INFO - 2021-01-21 02:31:42 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:31:42 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:31:42 --> Utf8 Class Initialized
INFO - 2021-01-21 02:31:42 --> URI Class Initialized
INFO - 2021-01-21 02:31:42 --> Router Class Initialized
INFO - 2021-01-21 02:31:42 --> Output Class Initialized
INFO - 2021-01-21 02:31:42 --> Security Class Initialized
DEBUG - 2021-01-21 02:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:31:42 --> Input Class Initialized
INFO - 2021-01-21 02:31:42 --> Language Class Initialized
INFO - 2021-01-21 02:31:43 --> Language Class Initialized
INFO - 2021-01-21 02:31:43 --> Config Class Initialized
INFO - 2021-01-21 02:31:43 --> Loader Class Initialized
INFO - 2021-01-21 02:31:43 --> Helper loaded: url_helper
INFO - 2021-01-21 02:31:43 --> Helper loaded: file_helper
INFO - 2021-01-21 02:31:43 --> Helper loaded: form_helper
INFO - 2021-01-21 02:31:43 --> Helper loaded: my_helper
INFO - 2021-01-21 02:31:43 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:31:43 --> Controller Class Initialized
INFO - 2021-01-21 02:31:43 --> Helper loaded: cookie_helper
INFO - 2021-01-21 02:31:43 --> Final output sent to browser
DEBUG - 2021-01-21 02:31:43 --> Total execution time: 0.9425
INFO - 2021-01-21 02:31:44 --> Config Class Initialized
INFO - 2021-01-21 02:31:44 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:31:44 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:31:44 --> Utf8 Class Initialized
INFO - 2021-01-21 02:31:44 --> URI Class Initialized
INFO - 2021-01-21 02:31:44 --> Router Class Initialized
INFO - 2021-01-21 02:31:44 --> Output Class Initialized
INFO - 2021-01-21 02:31:44 --> Security Class Initialized
DEBUG - 2021-01-21 02:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:31:44 --> Input Class Initialized
INFO - 2021-01-21 02:31:44 --> Language Class Initialized
INFO - 2021-01-21 02:31:44 --> Language Class Initialized
INFO - 2021-01-21 02:31:44 --> Config Class Initialized
INFO - 2021-01-21 02:31:44 --> Loader Class Initialized
INFO - 2021-01-21 02:31:44 --> Helper loaded: url_helper
INFO - 2021-01-21 02:31:44 --> Helper loaded: file_helper
INFO - 2021-01-21 02:31:44 --> Helper loaded: form_helper
INFO - 2021-01-21 02:31:44 --> Helper loaded: my_helper
INFO - 2021-01-21 02:31:44 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:31:44 --> Controller Class Initialized
DEBUG - 2021-01-21 02:31:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 02:31:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:31:44 --> Final output sent to browser
DEBUG - 2021-01-21 02:31:45 --> Total execution time: 0.9517
INFO - 2021-01-21 02:31:47 --> Config Class Initialized
INFO - 2021-01-21 02:31:47 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:31:47 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:31:47 --> Utf8 Class Initialized
INFO - 2021-01-21 02:31:47 --> URI Class Initialized
INFO - 2021-01-21 02:31:47 --> Router Class Initialized
INFO - 2021-01-21 02:31:47 --> Output Class Initialized
INFO - 2021-01-21 02:31:47 --> Security Class Initialized
DEBUG - 2021-01-21 02:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:31:47 --> Input Class Initialized
INFO - 2021-01-21 02:31:47 --> Language Class Initialized
INFO - 2021-01-21 02:31:47 --> Language Class Initialized
INFO - 2021-01-21 02:31:47 --> Config Class Initialized
INFO - 2021-01-21 02:31:47 --> Loader Class Initialized
INFO - 2021-01-21 02:31:47 --> Helper loaded: url_helper
INFO - 2021-01-21 02:31:47 --> Helper loaded: file_helper
INFO - 2021-01-21 02:31:48 --> Helper loaded: form_helper
INFO - 2021-01-21 02:31:48 --> Helper loaded: my_helper
INFO - 2021-01-21 02:31:48 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:31:48 --> Controller Class Initialized
DEBUG - 2021-01-21 02:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-21 02:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:31:48 --> Final output sent to browser
DEBUG - 2021-01-21 02:31:48 --> Total execution time: 0.8186
INFO - 2021-01-21 02:31:49 --> Config Class Initialized
INFO - 2021-01-21 02:31:49 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:31:49 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:31:49 --> Utf8 Class Initialized
INFO - 2021-01-21 02:31:49 --> URI Class Initialized
INFO - 2021-01-21 02:31:49 --> Router Class Initialized
INFO - 2021-01-21 02:31:49 --> Output Class Initialized
INFO - 2021-01-21 02:31:49 --> Security Class Initialized
DEBUG - 2021-01-21 02:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:31:49 --> Input Class Initialized
INFO - 2021-01-21 02:31:49 --> Language Class Initialized
INFO - 2021-01-21 02:31:49 --> Language Class Initialized
INFO - 2021-01-21 02:31:49 --> Config Class Initialized
INFO - 2021-01-21 02:31:49 --> Loader Class Initialized
INFO - 2021-01-21 02:31:49 --> Helper loaded: url_helper
INFO - 2021-01-21 02:31:49 --> Helper loaded: file_helper
INFO - 2021-01-21 02:31:49 --> Helper loaded: form_helper
INFO - 2021-01-21 02:31:49 --> Helper loaded: my_helper
INFO - 2021-01-21 02:31:49 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:31:50 --> Controller Class Initialized
DEBUG - 2021-01-21 02:31:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:31:50 --> Final output sent to browser
DEBUG - 2021-01-21 02:31:50 --> Total execution time: 0.7295
INFO - 2021-01-21 02:32:08 --> Config Class Initialized
INFO - 2021-01-21 02:32:08 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:32:08 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:32:08 --> Utf8 Class Initialized
INFO - 2021-01-21 02:32:08 --> URI Class Initialized
INFO - 2021-01-21 02:32:08 --> Router Class Initialized
INFO - 2021-01-21 02:32:08 --> Output Class Initialized
INFO - 2021-01-21 02:32:08 --> Security Class Initialized
DEBUG - 2021-01-21 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:32:08 --> Input Class Initialized
INFO - 2021-01-21 02:32:08 --> Language Class Initialized
INFO - 2021-01-21 02:32:09 --> Language Class Initialized
INFO - 2021-01-21 02:32:09 --> Config Class Initialized
INFO - 2021-01-21 02:32:09 --> Loader Class Initialized
INFO - 2021-01-21 02:32:09 --> Helper loaded: url_helper
INFO - 2021-01-21 02:32:09 --> Helper loaded: file_helper
INFO - 2021-01-21 02:32:09 --> Helper loaded: form_helper
INFO - 2021-01-21 02:32:09 --> Helper loaded: my_helper
INFO - 2021-01-21 02:32:09 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:32:09 --> Controller Class Initialized
DEBUG - 2021-01-21 02:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:32:09 --> Final output sent to browser
DEBUG - 2021-01-21 02:32:09 --> Total execution time: 0.9486
INFO - 2021-01-21 02:32:25 --> Config Class Initialized
INFO - 2021-01-21 02:32:25 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:32:25 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:32:25 --> Utf8 Class Initialized
INFO - 2021-01-21 02:32:25 --> URI Class Initialized
INFO - 2021-01-21 02:32:25 --> Router Class Initialized
INFO - 2021-01-21 02:32:25 --> Output Class Initialized
INFO - 2021-01-21 02:32:25 --> Security Class Initialized
DEBUG - 2021-01-21 02:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:32:25 --> Input Class Initialized
INFO - 2021-01-21 02:32:25 --> Language Class Initialized
INFO - 2021-01-21 02:32:25 --> Language Class Initialized
INFO - 2021-01-21 02:32:25 --> Config Class Initialized
INFO - 2021-01-21 02:32:25 --> Loader Class Initialized
INFO - 2021-01-21 02:32:25 --> Helper loaded: url_helper
INFO - 2021-01-21 02:32:25 --> Helper loaded: file_helper
INFO - 2021-01-21 02:32:25 --> Helper loaded: form_helper
INFO - 2021-01-21 02:32:25 --> Helper loaded: my_helper
INFO - 2021-01-21 02:32:25 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:32:25 --> Controller Class Initialized
DEBUG - 2021-01-21 02:32:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:32:26 --> Final output sent to browser
DEBUG - 2021-01-21 02:32:26 --> Total execution time: 0.9199
INFO - 2021-01-21 02:32:39 --> Config Class Initialized
INFO - 2021-01-21 02:32:39 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:32:39 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:32:39 --> Utf8 Class Initialized
INFO - 2021-01-21 02:32:39 --> URI Class Initialized
INFO - 2021-01-21 02:32:39 --> Router Class Initialized
INFO - 2021-01-21 02:32:39 --> Output Class Initialized
INFO - 2021-01-21 02:32:39 --> Security Class Initialized
DEBUG - 2021-01-21 02:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:32:40 --> Input Class Initialized
INFO - 2021-01-21 02:32:40 --> Language Class Initialized
INFO - 2021-01-21 02:32:40 --> Language Class Initialized
INFO - 2021-01-21 02:32:40 --> Config Class Initialized
INFO - 2021-01-21 02:32:40 --> Loader Class Initialized
INFO - 2021-01-21 02:32:40 --> Helper loaded: url_helper
INFO - 2021-01-21 02:32:40 --> Helper loaded: file_helper
INFO - 2021-01-21 02:32:40 --> Helper loaded: form_helper
INFO - 2021-01-21 02:32:40 --> Helper loaded: my_helper
INFO - 2021-01-21 02:32:40 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:32:40 --> Controller Class Initialized
DEBUG - 2021-01-21 02:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:32:40 --> Final output sent to browser
DEBUG - 2021-01-21 02:32:40 --> Total execution time: 0.9205
INFO - 2021-01-21 02:35:57 --> Config Class Initialized
INFO - 2021-01-21 02:35:57 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:35:57 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:35:57 --> Utf8 Class Initialized
INFO - 2021-01-21 02:35:57 --> URI Class Initialized
INFO - 2021-01-21 02:35:57 --> Router Class Initialized
INFO - 2021-01-21 02:35:57 --> Output Class Initialized
INFO - 2021-01-21 02:35:57 --> Security Class Initialized
DEBUG - 2021-01-21 02:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:35:57 --> Input Class Initialized
INFO - 2021-01-21 02:35:57 --> Language Class Initialized
INFO - 2021-01-21 02:35:57 --> Language Class Initialized
INFO - 2021-01-21 02:35:57 --> Config Class Initialized
INFO - 2021-01-21 02:35:57 --> Loader Class Initialized
INFO - 2021-01-21 02:35:57 --> Helper loaded: url_helper
INFO - 2021-01-21 02:35:57 --> Helper loaded: file_helper
INFO - 2021-01-21 02:35:57 --> Helper loaded: form_helper
INFO - 2021-01-21 02:35:57 --> Helper loaded: my_helper
INFO - 2021-01-21 02:35:57 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:35:57 --> Controller Class Initialized
DEBUG - 2021-01-21 02:35:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:35:58 --> Final output sent to browser
DEBUG - 2021-01-21 02:35:58 --> Total execution time: 0.8527
INFO - 2021-01-21 02:40:29 --> Config Class Initialized
INFO - 2021-01-21 02:40:29 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:40:29 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:40:29 --> Utf8 Class Initialized
INFO - 2021-01-21 02:40:29 --> URI Class Initialized
INFO - 2021-01-21 02:40:29 --> Router Class Initialized
INFO - 2021-01-21 02:40:29 --> Output Class Initialized
INFO - 2021-01-21 02:40:29 --> Security Class Initialized
DEBUG - 2021-01-21 02:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:40:29 --> Input Class Initialized
INFO - 2021-01-21 02:40:29 --> Language Class Initialized
INFO - 2021-01-21 02:40:29 --> Language Class Initialized
INFO - 2021-01-21 02:40:29 --> Config Class Initialized
INFO - 2021-01-21 02:40:29 --> Loader Class Initialized
INFO - 2021-01-21 02:40:30 --> Helper loaded: url_helper
INFO - 2021-01-21 02:40:30 --> Helper loaded: file_helper
INFO - 2021-01-21 02:40:30 --> Helper loaded: form_helper
INFO - 2021-01-21 02:40:30 --> Helper loaded: my_helper
INFO - 2021-01-21 02:40:30 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:40:30 --> Controller Class Initialized
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: queri_np1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4442
ERROR - 2021-01-21 02:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4442
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: queri_np2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4450
ERROR - 2021-01-21 02:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4450
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:30 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
ERROR - 2021-01-21 02:40:31 --> Severity: Notice --> Undefined variable: s1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4542
DEBUG - 2021-01-21 02:40:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:40:31 --> Final output sent to browser
DEBUG - 2021-01-21 02:40:31 --> Total execution time: 2.1619
INFO - 2021-01-21 02:41:07 --> Config Class Initialized
INFO - 2021-01-21 02:41:07 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:41:07 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:41:07 --> Utf8 Class Initialized
INFO - 2021-01-21 02:41:07 --> URI Class Initialized
INFO - 2021-01-21 02:41:07 --> Router Class Initialized
INFO - 2021-01-21 02:41:07 --> Output Class Initialized
INFO - 2021-01-21 02:41:07 --> Security Class Initialized
DEBUG - 2021-01-21 02:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:41:07 --> Input Class Initialized
INFO - 2021-01-21 02:41:07 --> Language Class Initialized
INFO - 2021-01-21 02:41:07 --> Language Class Initialized
INFO - 2021-01-21 02:41:07 --> Config Class Initialized
INFO - 2021-01-21 02:41:07 --> Loader Class Initialized
INFO - 2021-01-21 02:41:07 --> Helper loaded: url_helper
INFO - 2021-01-21 02:41:07 --> Helper loaded: file_helper
INFO - 2021-01-21 02:41:07 --> Helper loaded: form_helper
INFO - 2021-01-21 02:41:07 --> Helper loaded: my_helper
INFO - 2021-01-21 02:41:07 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:41:08 --> Controller Class Initialized
DEBUG - 2021-01-21 02:41:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:41:08 --> Final output sent to browser
DEBUG - 2021-01-21 02:41:08 --> Total execution time: 0.8715
INFO - 2021-01-21 02:46:48 --> Config Class Initialized
INFO - 2021-01-21 02:46:48 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:46:48 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:46:48 --> Utf8 Class Initialized
INFO - 2021-01-21 02:46:48 --> URI Class Initialized
INFO - 2021-01-21 02:46:48 --> Router Class Initialized
INFO - 2021-01-21 02:46:48 --> Output Class Initialized
INFO - 2021-01-21 02:46:48 --> Security Class Initialized
DEBUG - 2021-01-21 02:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:46:48 --> Input Class Initialized
INFO - 2021-01-21 02:46:48 --> Language Class Initialized
INFO - 2021-01-21 02:46:49 --> Language Class Initialized
INFO - 2021-01-21 02:46:49 --> Config Class Initialized
INFO - 2021-01-21 02:46:49 --> Loader Class Initialized
INFO - 2021-01-21 02:46:49 --> Helper loaded: url_helper
INFO - 2021-01-21 02:46:49 --> Helper loaded: file_helper
INFO - 2021-01-21 02:46:49 --> Helper loaded: form_helper
INFO - 2021-01-21 02:46:49 --> Helper loaded: my_helper
INFO - 2021-01-21 02:46:49 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:46:49 --> Controller Class Initialized
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:49 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:46:50 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
DEBUG - 2021-01-21 02:46:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:46:50 --> Final output sent to browser
DEBUG - 2021-01-21 02:46:50 --> Total execution time: 1.9207
INFO - 2021-01-21 02:47:56 --> Config Class Initialized
INFO - 2021-01-21 02:47:56 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:47:56 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:47:56 --> Utf8 Class Initialized
INFO - 2021-01-21 02:47:56 --> URI Class Initialized
INFO - 2021-01-21 02:47:56 --> Router Class Initialized
INFO - 2021-01-21 02:47:56 --> Output Class Initialized
INFO - 2021-01-21 02:47:56 --> Security Class Initialized
DEBUG - 2021-01-21 02:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:47:56 --> Input Class Initialized
INFO - 2021-01-21 02:47:56 --> Language Class Initialized
INFO - 2021-01-21 02:47:56 --> Language Class Initialized
INFO - 2021-01-21 02:47:56 --> Config Class Initialized
INFO - 2021-01-21 02:47:56 --> Loader Class Initialized
INFO - 2021-01-21 02:47:56 --> Helper loaded: url_helper
INFO - 2021-01-21 02:47:56 --> Helper loaded: file_helper
INFO - 2021-01-21 02:47:57 --> Helper loaded: form_helper
INFO - 2021-01-21 02:47:57 --> Helper loaded: my_helper
INFO - 2021-01-21 02:47:57 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:47:57 --> Controller Class Initialized
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:57 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:58 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:47:59 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: queri_mapel C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4475
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4509
ERROR - 2021-01-21 02:48:00 --> Severity: Notice --> Undefined variable: queri_mapel2 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
ERROR - 2021-01-21 02:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4539
DEBUG - 2021-01-21 02:48:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:48:00 --> Final output sent to browser
DEBUG - 2021-01-21 02:48:00 --> Total execution time: 4.1245
INFO - 2021-01-21 02:48:28 --> Config Class Initialized
INFO - 2021-01-21 02:48:28 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:48:28 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:48:28 --> Utf8 Class Initialized
INFO - 2021-01-21 02:48:28 --> URI Class Initialized
INFO - 2021-01-21 02:48:28 --> Router Class Initialized
INFO - 2021-01-21 02:48:28 --> Output Class Initialized
INFO - 2021-01-21 02:48:28 --> Security Class Initialized
DEBUG - 2021-01-21 02:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:48:28 --> Input Class Initialized
INFO - 2021-01-21 02:48:28 --> Language Class Initialized
INFO - 2021-01-21 02:48:28 --> Language Class Initialized
INFO - 2021-01-21 02:48:29 --> Config Class Initialized
INFO - 2021-01-21 02:48:29 --> Loader Class Initialized
INFO - 2021-01-21 02:48:29 --> Helper loaded: url_helper
INFO - 2021-01-21 02:48:29 --> Helper loaded: file_helper
INFO - 2021-01-21 02:48:29 --> Helper loaded: form_helper
INFO - 2021-01-21 02:48:29 --> Helper loaded: my_helper
INFO - 2021-01-21 02:48:29 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:48:29 --> Controller Class Initialized
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:29 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
ERROR - 2021-01-21 02:48:30 --> Severity: Notice --> Undefined variable: m C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 4477
DEBUG - 2021-01-21 02:48:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:48:30 --> Final output sent to browser
DEBUG - 2021-01-21 02:48:30 --> Total execution time: 2.1842
INFO - 2021-01-21 02:48:54 --> Config Class Initialized
INFO - 2021-01-21 02:48:54 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:48:54 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:48:54 --> Utf8 Class Initialized
INFO - 2021-01-21 02:48:54 --> URI Class Initialized
INFO - 2021-01-21 02:48:54 --> Router Class Initialized
INFO - 2021-01-21 02:48:54 --> Output Class Initialized
INFO - 2021-01-21 02:48:54 --> Security Class Initialized
DEBUG - 2021-01-21 02:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:48:54 --> Input Class Initialized
INFO - 2021-01-21 02:48:54 --> Language Class Initialized
INFO - 2021-01-21 02:48:54 --> Language Class Initialized
INFO - 2021-01-21 02:48:54 --> Config Class Initialized
INFO - 2021-01-21 02:48:54 --> Loader Class Initialized
INFO - 2021-01-21 02:48:54 --> Helper loaded: url_helper
INFO - 2021-01-21 02:48:55 --> Helper loaded: file_helper
INFO - 2021-01-21 02:48:55 --> Helper loaded: form_helper
INFO - 2021-01-21 02:48:55 --> Helper loaded: my_helper
INFO - 2021-01-21 02:48:55 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:48:55 --> Controller Class Initialized
DEBUG - 2021-01-21 02:48:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:48:55 --> Final output sent to browser
DEBUG - 2021-01-21 02:48:55 --> Total execution time: 0.8941
INFO - 2021-01-21 02:49:03 --> Config Class Initialized
INFO - 2021-01-21 02:49:03 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:03 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:03 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:04 --> URI Class Initialized
INFO - 2021-01-21 02:49:04 --> Router Class Initialized
INFO - 2021-01-21 02:49:04 --> Output Class Initialized
INFO - 2021-01-21 02:49:04 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:04 --> Input Class Initialized
INFO - 2021-01-21 02:49:04 --> Language Class Initialized
INFO - 2021-01-21 02:49:04 --> Language Class Initialized
INFO - 2021-01-21 02:49:04 --> Config Class Initialized
INFO - 2021-01-21 02:49:04 --> Loader Class Initialized
INFO - 2021-01-21 02:49:04 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:04 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:04 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:04 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:04 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:04 --> Controller Class Initialized
DEBUG - 2021-01-21 02:49:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-21 02:49:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:49:05 --> Final output sent to browser
DEBUG - 2021-01-21 02:49:05 --> Total execution time: 1.1762
INFO - 2021-01-21 02:49:29 --> Config Class Initialized
INFO - 2021-01-21 02:49:29 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:29 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:29 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:30 --> URI Class Initialized
INFO - 2021-01-21 02:49:30 --> Router Class Initialized
INFO - 2021-01-21 02:49:30 --> Output Class Initialized
INFO - 2021-01-21 02:49:30 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:30 --> Input Class Initialized
INFO - 2021-01-21 02:49:30 --> Language Class Initialized
INFO - 2021-01-21 02:49:30 --> Language Class Initialized
INFO - 2021-01-21 02:49:30 --> Config Class Initialized
INFO - 2021-01-21 02:49:30 --> Loader Class Initialized
INFO - 2021-01-21 02:49:30 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:30 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:30 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:30 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:30 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:30 --> Controller Class Initialized
INFO - 2021-01-21 02:49:30 --> Helper loaded: cookie_helper
INFO - 2021-01-21 02:49:30 --> Config Class Initialized
INFO - 2021-01-21 02:49:30 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:30 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:30 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:30 --> URI Class Initialized
INFO - 2021-01-21 02:49:31 --> Router Class Initialized
INFO - 2021-01-21 02:49:31 --> Output Class Initialized
INFO - 2021-01-21 02:49:31 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:31 --> Input Class Initialized
INFO - 2021-01-21 02:49:31 --> Language Class Initialized
INFO - 2021-01-21 02:49:31 --> Language Class Initialized
INFO - 2021-01-21 02:49:31 --> Config Class Initialized
INFO - 2021-01-21 02:49:31 --> Loader Class Initialized
INFO - 2021-01-21 02:49:31 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:31 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:31 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:31 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:31 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:31 --> Controller Class Initialized
DEBUG - 2021-01-21 02:49:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 02:49:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:49:31 --> Final output sent to browser
DEBUG - 2021-01-21 02:49:31 --> Total execution time: 0.8558
INFO - 2021-01-21 02:49:36 --> Config Class Initialized
INFO - 2021-01-21 02:49:36 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:36 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:36 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:36 --> URI Class Initialized
INFO - 2021-01-21 02:49:36 --> Router Class Initialized
INFO - 2021-01-21 02:49:36 --> Output Class Initialized
INFO - 2021-01-21 02:49:36 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:36 --> Input Class Initialized
INFO - 2021-01-21 02:49:36 --> Language Class Initialized
INFO - 2021-01-21 02:49:36 --> Language Class Initialized
INFO - 2021-01-21 02:49:36 --> Config Class Initialized
INFO - 2021-01-21 02:49:36 --> Loader Class Initialized
INFO - 2021-01-21 02:49:36 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:36 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:36 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:37 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:37 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:37 --> Controller Class Initialized
INFO - 2021-01-21 02:49:37 --> Helper loaded: cookie_helper
INFO - 2021-01-21 02:49:37 --> Final output sent to browser
DEBUG - 2021-01-21 02:49:37 --> Total execution time: 0.8783
INFO - 2021-01-21 02:49:37 --> Config Class Initialized
INFO - 2021-01-21 02:49:37 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:37 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:37 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:37 --> URI Class Initialized
INFO - 2021-01-21 02:49:37 --> Router Class Initialized
INFO - 2021-01-21 02:49:37 --> Output Class Initialized
INFO - 2021-01-21 02:49:38 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:38 --> Input Class Initialized
INFO - 2021-01-21 02:49:38 --> Language Class Initialized
INFO - 2021-01-21 02:49:38 --> Language Class Initialized
INFO - 2021-01-21 02:49:38 --> Config Class Initialized
INFO - 2021-01-21 02:49:38 --> Loader Class Initialized
INFO - 2021-01-21 02:49:38 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:38 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:38 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:38 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:38 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:38 --> Controller Class Initialized
DEBUG - 2021-01-21 02:49:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 02:49:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:49:38 --> Final output sent to browser
DEBUG - 2021-01-21 02:49:38 --> Total execution time: 0.9588
INFO - 2021-01-21 02:49:41 --> Config Class Initialized
INFO - 2021-01-21 02:49:41 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:41 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:41 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:41 --> URI Class Initialized
INFO - 2021-01-21 02:49:41 --> Router Class Initialized
INFO - 2021-01-21 02:49:41 --> Output Class Initialized
INFO - 2021-01-21 02:49:41 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:41 --> Input Class Initialized
INFO - 2021-01-21 02:49:41 --> Language Class Initialized
INFO - 2021-01-21 02:49:41 --> Language Class Initialized
INFO - 2021-01-21 02:49:41 --> Config Class Initialized
INFO - 2021-01-21 02:49:41 --> Loader Class Initialized
INFO - 2021-01-21 02:49:42 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:42 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:42 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:42 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:42 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:42 --> Controller Class Initialized
DEBUG - 2021-01-21 02:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-21 02:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:49:42 --> Final output sent to browser
DEBUG - 2021-01-21 02:49:42 --> Total execution time: 0.9435
INFO - 2021-01-21 02:49:42 --> Config Class Initialized
INFO - 2021-01-21 02:49:42 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:42 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:42 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:42 --> URI Class Initialized
INFO - 2021-01-21 02:49:42 --> Router Class Initialized
INFO - 2021-01-21 02:49:42 --> Output Class Initialized
INFO - 2021-01-21 02:49:42 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:42 --> Input Class Initialized
INFO - 2021-01-21 02:49:42 --> Language Class Initialized
INFO - 2021-01-21 02:49:43 --> Language Class Initialized
INFO - 2021-01-21 02:49:43 --> Config Class Initialized
INFO - 2021-01-21 02:49:43 --> Loader Class Initialized
INFO - 2021-01-21 02:49:43 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:43 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:43 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:43 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:43 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:43 --> Controller Class Initialized
INFO - 2021-01-21 02:49:45 --> Config Class Initialized
INFO - 2021-01-21 02:49:45 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:45 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:45 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:45 --> URI Class Initialized
INFO - 2021-01-21 02:49:45 --> Router Class Initialized
INFO - 2021-01-21 02:49:45 --> Output Class Initialized
INFO - 2021-01-21 02:49:45 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:45 --> Input Class Initialized
INFO - 2021-01-21 02:49:45 --> Language Class Initialized
INFO - 2021-01-21 02:49:45 --> Language Class Initialized
INFO - 2021-01-21 02:49:45 --> Config Class Initialized
INFO - 2021-01-21 02:49:46 --> Loader Class Initialized
INFO - 2021-01-21 02:49:46 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:46 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:46 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:46 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:46 --> Controller Class Initialized
INFO - 2021-01-21 02:49:47 --> Config Class Initialized
INFO - 2021-01-21 02:49:47 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:47 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:47 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:47 --> URI Class Initialized
INFO - 2021-01-21 02:49:47 --> Router Class Initialized
INFO - 2021-01-21 02:49:48 --> Output Class Initialized
INFO - 2021-01-21 02:49:48 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:48 --> Input Class Initialized
INFO - 2021-01-21 02:49:48 --> Language Class Initialized
INFO - 2021-01-21 02:49:48 --> Language Class Initialized
INFO - 2021-01-21 02:49:48 --> Config Class Initialized
INFO - 2021-01-21 02:49:48 --> Loader Class Initialized
INFO - 2021-01-21 02:49:48 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:48 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:48 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:48 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:48 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:48 --> Controller Class Initialized
INFO - 2021-01-21 02:49:51 --> Config Class Initialized
INFO - 2021-01-21 02:49:51 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:51 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:51 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:51 --> URI Class Initialized
INFO - 2021-01-21 02:49:51 --> Router Class Initialized
INFO - 2021-01-21 02:49:51 --> Output Class Initialized
INFO - 2021-01-21 02:49:51 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:51 --> Input Class Initialized
INFO - 2021-01-21 02:49:51 --> Language Class Initialized
INFO - 2021-01-21 02:49:51 --> Language Class Initialized
INFO - 2021-01-21 02:49:51 --> Config Class Initialized
INFO - 2021-01-21 02:49:51 --> Loader Class Initialized
INFO - 2021-01-21 02:49:51 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:51 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:51 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:52 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:52 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:52 --> Controller Class Initialized
INFO - 2021-01-21 02:49:52 --> Config Class Initialized
INFO - 2021-01-21 02:49:52 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:52 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:52 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:52 --> URI Class Initialized
INFO - 2021-01-21 02:49:52 --> Router Class Initialized
INFO - 2021-01-21 02:49:52 --> Output Class Initialized
INFO - 2021-01-21 02:49:52 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:52 --> Input Class Initialized
INFO - 2021-01-21 02:49:52 --> Language Class Initialized
INFO - 2021-01-21 02:49:52 --> Language Class Initialized
INFO - 2021-01-21 02:49:52 --> Config Class Initialized
INFO - 2021-01-21 02:49:52 --> Loader Class Initialized
INFO - 2021-01-21 02:49:52 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:52 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:52 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:52 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:52 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:52 --> Controller Class Initialized
INFO - 2021-01-21 02:49:54 --> Config Class Initialized
INFO - 2021-01-21 02:49:54 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:54 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:54 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:54 --> URI Class Initialized
INFO - 2021-01-21 02:49:54 --> Router Class Initialized
INFO - 2021-01-21 02:49:54 --> Output Class Initialized
INFO - 2021-01-21 02:49:54 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:54 --> Input Class Initialized
INFO - 2021-01-21 02:49:54 --> Language Class Initialized
INFO - 2021-01-21 02:49:54 --> Language Class Initialized
INFO - 2021-01-21 02:49:54 --> Config Class Initialized
INFO - 2021-01-21 02:49:54 --> Loader Class Initialized
INFO - 2021-01-21 02:49:54 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:54 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:54 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:54 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:54 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:55 --> Controller Class Initialized
INFO - 2021-01-21 02:49:55 --> Config Class Initialized
INFO - 2021-01-21 02:49:55 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:55 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:55 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:55 --> URI Class Initialized
INFO - 2021-01-21 02:49:55 --> Router Class Initialized
INFO - 2021-01-21 02:49:55 --> Output Class Initialized
INFO - 2021-01-21 02:49:55 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:55 --> Input Class Initialized
INFO - 2021-01-21 02:49:55 --> Language Class Initialized
INFO - 2021-01-21 02:49:55 --> Language Class Initialized
INFO - 2021-01-21 02:49:55 --> Config Class Initialized
INFO - 2021-01-21 02:49:55 --> Loader Class Initialized
INFO - 2021-01-21 02:49:55 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:55 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:55 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:55 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:55 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:56 --> Controller Class Initialized
INFO - 2021-01-21 02:49:56 --> Config Class Initialized
INFO - 2021-01-21 02:49:56 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:49:56 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:49:56 --> Utf8 Class Initialized
INFO - 2021-01-21 02:49:56 --> URI Class Initialized
INFO - 2021-01-21 02:49:56 --> Router Class Initialized
INFO - 2021-01-21 02:49:56 --> Output Class Initialized
INFO - 2021-01-21 02:49:56 --> Security Class Initialized
DEBUG - 2021-01-21 02:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:49:56 --> Input Class Initialized
INFO - 2021-01-21 02:49:56 --> Language Class Initialized
INFO - 2021-01-21 02:49:56 --> Language Class Initialized
INFO - 2021-01-21 02:49:56 --> Config Class Initialized
INFO - 2021-01-21 02:49:56 --> Loader Class Initialized
INFO - 2021-01-21 02:49:56 --> Helper loaded: url_helper
INFO - 2021-01-21 02:49:56 --> Helper loaded: file_helper
INFO - 2021-01-21 02:49:56 --> Helper loaded: form_helper
INFO - 2021-01-21 02:49:56 --> Helper loaded: my_helper
INFO - 2021-01-21 02:49:56 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:49:56 --> Controller Class Initialized
DEBUG - 2021-01-21 02:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-21 02:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:49:57 --> Final output sent to browser
DEBUG - 2021-01-21 02:49:57 --> Total execution time: 1.0875
INFO - 2021-01-21 02:50:15 --> Config Class Initialized
INFO - 2021-01-21 02:50:15 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:15 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:15 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:15 --> URI Class Initialized
INFO - 2021-01-21 02:50:15 --> Router Class Initialized
INFO - 2021-01-21 02:50:15 --> Output Class Initialized
INFO - 2021-01-21 02:50:15 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:15 --> Input Class Initialized
INFO - 2021-01-21 02:50:15 --> Language Class Initialized
INFO - 2021-01-21 02:50:15 --> Language Class Initialized
INFO - 2021-01-21 02:50:15 --> Config Class Initialized
INFO - 2021-01-21 02:50:15 --> Loader Class Initialized
INFO - 2021-01-21 02:50:15 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:15 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:15 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:15 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:15 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:15 --> Controller Class Initialized
INFO - 2021-01-21 02:50:15 --> Config Class Initialized
INFO - 2021-01-21 02:50:16 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:16 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:16 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:16 --> URI Class Initialized
INFO - 2021-01-21 02:50:16 --> Router Class Initialized
INFO - 2021-01-21 02:50:16 --> Output Class Initialized
INFO - 2021-01-21 02:50:16 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:16 --> Input Class Initialized
INFO - 2021-01-21 02:50:16 --> Language Class Initialized
INFO - 2021-01-21 02:50:16 --> Language Class Initialized
INFO - 2021-01-21 02:50:16 --> Config Class Initialized
INFO - 2021-01-21 02:50:16 --> Loader Class Initialized
INFO - 2021-01-21 02:50:16 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:16 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:16 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:16 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:16 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:16 --> Controller Class Initialized
DEBUG - 2021-01-21 02:50:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-21 02:50:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:50:16 --> Final output sent to browser
DEBUG - 2021-01-21 02:50:17 --> Total execution time: 0.9777
INFO - 2021-01-21 02:50:17 --> Config Class Initialized
INFO - 2021-01-21 02:50:17 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:17 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:17 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:17 --> URI Class Initialized
INFO - 2021-01-21 02:50:17 --> Router Class Initialized
INFO - 2021-01-21 02:50:17 --> Output Class Initialized
INFO - 2021-01-21 02:50:17 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:17 --> Input Class Initialized
INFO - 2021-01-21 02:50:17 --> Language Class Initialized
INFO - 2021-01-21 02:50:17 --> Language Class Initialized
INFO - 2021-01-21 02:50:17 --> Config Class Initialized
INFO - 2021-01-21 02:50:17 --> Loader Class Initialized
INFO - 2021-01-21 02:50:17 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:17 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:17 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:17 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:17 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:17 --> Controller Class Initialized
INFO - 2021-01-21 02:50:18 --> Config Class Initialized
INFO - 2021-01-21 02:50:18 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:18 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:18 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:18 --> URI Class Initialized
INFO - 2021-01-21 02:50:18 --> Router Class Initialized
INFO - 2021-01-21 02:50:18 --> Output Class Initialized
INFO - 2021-01-21 02:50:18 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:19 --> Input Class Initialized
INFO - 2021-01-21 02:50:19 --> Language Class Initialized
INFO - 2021-01-21 02:50:19 --> Language Class Initialized
INFO - 2021-01-21 02:50:19 --> Config Class Initialized
INFO - 2021-01-21 02:50:19 --> Loader Class Initialized
INFO - 2021-01-21 02:50:19 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:19 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:19 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:19 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:19 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:19 --> Controller Class Initialized
DEBUG - 2021-01-21 02:50:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-21 02:50:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:50:19 --> Final output sent to browser
DEBUG - 2021-01-21 02:50:19 --> Total execution time: 1.0006
INFO - 2021-01-21 02:50:30 --> Config Class Initialized
INFO - 2021-01-21 02:50:30 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:30 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:30 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:30 --> URI Class Initialized
INFO - 2021-01-21 02:50:30 --> Router Class Initialized
INFO - 2021-01-21 02:50:30 --> Output Class Initialized
INFO - 2021-01-21 02:50:30 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:30 --> Input Class Initialized
INFO - 2021-01-21 02:50:30 --> Language Class Initialized
INFO - 2021-01-21 02:50:30 --> Language Class Initialized
INFO - 2021-01-21 02:50:30 --> Config Class Initialized
INFO - 2021-01-21 02:50:30 --> Loader Class Initialized
INFO - 2021-01-21 02:50:30 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:30 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:30 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:30 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:30 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:31 --> Controller Class Initialized
INFO - 2021-01-21 02:50:31 --> Config Class Initialized
INFO - 2021-01-21 02:50:31 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:31 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:31 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:31 --> URI Class Initialized
INFO - 2021-01-21 02:50:31 --> Router Class Initialized
INFO - 2021-01-21 02:50:31 --> Output Class Initialized
INFO - 2021-01-21 02:50:31 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:31 --> Input Class Initialized
INFO - 2021-01-21 02:50:31 --> Language Class Initialized
INFO - 2021-01-21 02:50:31 --> Language Class Initialized
INFO - 2021-01-21 02:50:31 --> Config Class Initialized
INFO - 2021-01-21 02:50:31 --> Loader Class Initialized
INFO - 2021-01-21 02:50:31 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:31 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:31 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:31 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:31 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:32 --> Controller Class Initialized
DEBUG - 2021-01-21 02:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-21 02:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:50:32 --> Final output sent to browser
DEBUG - 2021-01-21 02:50:32 --> Total execution time: 1.0280
INFO - 2021-01-21 02:50:32 --> Config Class Initialized
INFO - 2021-01-21 02:50:32 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:32 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:32 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:32 --> URI Class Initialized
INFO - 2021-01-21 02:50:32 --> Router Class Initialized
INFO - 2021-01-21 02:50:32 --> Output Class Initialized
INFO - 2021-01-21 02:50:32 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:32 --> Input Class Initialized
INFO - 2021-01-21 02:50:32 --> Language Class Initialized
INFO - 2021-01-21 02:50:32 --> Language Class Initialized
INFO - 2021-01-21 02:50:32 --> Config Class Initialized
INFO - 2021-01-21 02:50:32 --> Loader Class Initialized
INFO - 2021-01-21 02:50:32 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:32 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:32 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:33 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:33 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:33 --> Controller Class Initialized
INFO - 2021-01-21 02:50:33 --> Config Class Initialized
INFO - 2021-01-21 02:50:33 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:33 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:33 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:33 --> URI Class Initialized
INFO - 2021-01-21 02:50:33 --> Router Class Initialized
INFO - 2021-01-21 02:50:33 --> Output Class Initialized
INFO - 2021-01-21 02:50:34 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:34 --> Input Class Initialized
INFO - 2021-01-21 02:50:34 --> Language Class Initialized
INFO - 2021-01-21 02:50:34 --> Language Class Initialized
INFO - 2021-01-21 02:50:34 --> Config Class Initialized
INFO - 2021-01-21 02:50:34 --> Loader Class Initialized
INFO - 2021-01-21 02:50:34 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:34 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:34 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:34 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:34 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:34 --> Controller Class Initialized
INFO - 2021-01-21 02:50:34 --> Helper loaded: cookie_helper
INFO - 2021-01-21 02:50:34 --> Config Class Initialized
INFO - 2021-01-21 02:50:34 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:34 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:34 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:34 --> URI Class Initialized
INFO - 2021-01-21 02:50:34 --> Router Class Initialized
INFO - 2021-01-21 02:50:35 --> Output Class Initialized
INFO - 2021-01-21 02:50:35 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:35 --> Input Class Initialized
INFO - 2021-01-21 02:50:35 --> Language Class Initialized
INFO - 2021-01-21 02:50:35 --> Language Class Initialized
INFO - 2021-01-21 02:50:35 --> Config Class Initialized
INFO - 2021-01-21 02:50:35 --> Loader Class Initialized
INFO - 2021-01-21 02:50:35 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:35 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:35 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:35 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:35 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:35 --> Controller Class Initialized
DEBUG - 2021-01-21 02:50:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 02:50:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:50:35 --> Final output sent to browser
DEBUG - 2021-01-21 02:50:35 --> Total execution time: 1.0094
INFO - 2021-01-21 02:50:40 --> Config Class Initialized
INFO - 2021-01-21 02:50:40 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:40 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:40 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:40 --> URI Class Initialized
INFO - 2021-01-21 02:50:40 --> Router Class Initialized
INFO - 2021-01-21 02:50:40 --> Output Class Initialized
INFO - 2021-01-21 02:50:40 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:40 --> Input Class Initialized
INFO - 2021-01-21 02:50:40 --> Language Class Initialized
INFO - 2021-01-21 02:50:40 --> Language Class Initialized
INFO - 2021-01-21 02:50:40 --> Config Class Initialized
INFO - 2021-01-21 02:50:40 --> Loader Class Initialized
INFO - 2021-01-21 02:50:40 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:40 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:41 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:41 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:41 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:41 --> Controller Class Initialized
INFO - 2021-01-21 02:50:41 --> Helper loaded: cookie_helper
INFO - 2021-01-21 02:50:41 --> Final output sent to browser
DEBUG - 2021-01-21 02:50:41 --> Total execution time: 0.9045
INFO - 2021-01-21 02:50:42 --> Config Class Initialized
INFO - 2021-01-21 02:50:42 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:42 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:42 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:42 --> URI Class Initialized
INFO - 2021-01-21 02:50:42 --> Router Class Initialized
INFO - 2021-01-21 02:50:42 --> Output Class Initialized
INFO - 2021-01-21 02:50:42 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:42 --> Input Class Initialized
INFO - 2021-01-21 02:50:42 --> Language Class Initialized
INFO - 2021-01-21 02:50:42 --> Language Class Initialized
INFO - 2021-01-21 02:50:42 --> Config Class Initialized
INFO - 2021-01-21 02:50:42 --> Loader Class Initialized
INFO - 2021-01-21 02:50:42 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:42 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:42 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:42 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:42 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:42 --> Controller Class Initialized
DEBUG - 2021-01-21 02:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 02:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:50:43 --> Final output sent to browser
DEBUG - 2021-01-21 02:50:43 --> Total execution time: 0.9867
INFO - 2021-01-21 02:50:49 --> Config Class Initialized
INFO - 2021-01-21 02:50:49 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:49 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:49 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:49 --> URI Class Initialized
INFO - 2021-01-21 02:50:49 --> Router Class Initialized
INFO - 2021-01-21 02:50:49 --> Output Class Initialized
INFO - 2021-01-21 02:50:49 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:49 --> Input Class Initialized
INFO - 2021-01-21 02:50:49 --> Language Class Initialized
INFO - 2021-01-21 02:50:49 --> Language Class Initialized
INFO - 2021-01-21 02:50:49 --> Config Class Initialized
INFO - 2021-01-21 02:50:49 --> Loader Class Initialized
INFO - 2021-01-21 02:50:49 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:49 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:49 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:49 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:49 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:49 --> Controller Class Initialized
DEBUG - 2021-01-21 02:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-21 02:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:50:50 --> Final output sent to browser
DEBUG - 2021-01-21 02:50:50 --> Total execution time: 0.6611
INFO - 2021-01-21 02:50:53 --> Config Class Initialized
INFO - 2021-01-21 02:50:53 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:53 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:53 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:53 --> URI Class Initialized
INFO - 2021-01-21 02:50:53 --> Router Class Initialized
INFO - 2021-01-21 02:50:53 --> Output Class Initialized
INFO - 2021-01-21 02:50:53 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:53 --> Input Class Initialized
INFO - 2021-01-21 02:50:53 --> Language Class Initialized
INFO - 2021-01-21 02:50:53 --> Language Class Initialized
INFO - 2021-01-21 02:50:53 --> Config Class Initialized
INFO - 2021-01-21 02:50:53 --> Loader Class Initialized
INFO - 2021-01-21 02:50:53 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:53 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:53 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:53 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:53 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:53 --> Controller Class Initialized
DEBUG - 2021-01-21 02:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-21 02:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:50:54 --> Final output sent to browser
DEBUG - 2021-01-21 02:50:54 --> Total execution time: 1.0839
INFO - 2021-01-21 02:50:54 --> Config Class Initialized
INFO - 2021-01-21 02:50:54 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:54 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:54 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:54 --> URI Class Initialized
INFO - 2021-01-21 02:50:54 --> Router Class Initialized
INFO - 2021-01-21 02:50:54 --> Output Class Initialized
INFO - 2021-01-21 02:50:54 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:54 --> Input Class Initialized
INFO - 2021-01-21 02:50:54 --> Language Class Initialized
INFO - 2021-01-21 02:50:54 --> Language Class Initialized
INFO - 2021-01-21 02:50:54 --> Config Class Initialized
INFO - 2021-01-21 02:50:54 --> Loader Class Initialized
INFO - 2021-01-21 02:50:54 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:54 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:54 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:54 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:54 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:55 --> Controller Class Initialized
INFO - 2021-01-21 02:50:55 --> Config Class Initialized
INFO - 2021-01-21 02:50:55 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:50:55 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:50:55 --> Utf8 Class Initialized
INFO - 2021-01-21 02:50:56 --> URI Class Initialized
INFO - 2021-01-21 02:50:56 --> Router Class Initialized
INFO - 2021-01-21 02:50:56 --> Output Class Initialized
INFO - 2021-01-21 02:50:56 --> Security Class Initialized
DEBUG - 2021-01-21 02:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:50:56 --> Input Class Initialized
INFO - 2021-01-21 02:50:56 --> Language Class Initialized
INFO - 2021-01-21 02:50:56 --> Language Class Initialized
INFO - 2021-01-21 02:50:56 --> Config Class Initialized
INFO - 2021-01-21 02:50:56 --> Loader Class Initialized
INFO - 2021-01-21 02:50:56 --> Helper loaded: url_helper
INFO - 2021-01-21 02:50:56 --> Helper loaded: file_helper
INFO - 2021-01-21 02:50:56 --> Helper loaded: form_helper
INFO - 2021-01-21 02:50:56 --> Helper loaded: my_helper
INFO - 2021-01-21 02:50:56 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:50:56 --> Controller Class Initialized
INFO - 2021-01-21 02:50:56 --> Final output sent to browser
DEBUG - 2021-01-21 02:50:56 --> Total execution time: 0.7915
INFO - 2021-01-21 02:51:21 --> Config Class Initialized
INFO - 2021-01-21 02:51:21 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:51:21 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:51:21 --> Utf8 Class Initialized
INFO - 2021-01-21 02:51:21 --> URI Class Initialized
INFO - 2021-01-21 02:51:21 --> Router Class Initialized
INFO - 2021-01-21 02:51:21 --> Output Class Initialized
INFO - 2021-01-21 02:51:21 --> Security Class Initialized
DEBUG - 2021-01-21 02:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:51:22 --> Input Class Initialized
INFO - 2021-01-21 02:51:22 --> Language Class Initialized
INFO - 2021-01-21 02:51:22 --> Language Class Initialized
INFO - 2021-01-21 02:51:22 --> Config Class Initialized
INFO - 2021-01-21 02:51:22 --> Loader Class Initialized
INFO - 2021-01-21 02:51:22 --> Helper loaded: url_helper
INFO - 2021-01-21 02:51:22 --> Helper loaded: file_helper
INFO - 2021-01-21 02:51:22 --> Helper loaded: form_helper
INFO - 2021-01-21 02:51:22 --> Helper loaded: my_helper
INFO - 2021-01-21 02:51:22 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:51:22 --> Controller Class Initialized
INFO - 2021-01-21 02:51:22 --> Final output sent to browser
DEBUG - 2021-01-21 02:51:22 --> Total execution time: 0.9383
INFO - 2021-01-21 02:51:42 --> Config Class Initialized
INFO - 2021-01-21 02:51:42 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:51:42 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:51:42 --> Utf8 Class Initialized
INFO - 2021-01-21 02:51:42 --> URI Class Initialized
INFO - 2021-01-21 02:51:42 --> Router Class Initialized
INFO - 2021-01-21 02:51:42 --> Output Class Initialized
INFO - 2021-01-21 02:51:42 --> Security Class Initialized
DEBUG - 2021-01-21 02:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:51:42 --> Input Class Initialized
INFO - 2021-01-21 02:51:42 --> Language Class Initialized
INFO - 2021-01-21 02:51:42 --> Language Class Initialized
INFO - 2021-01-21 02:51:42 --> Config Class Initialized
INFO - 2021-01-21 02:51:43 --> Loader Class Initialized
INFO - 2021-01-21 02:51:43 --> Helper loaded: url_helper
INFO - 2021-01-21 02:51:43 --> Helper loaded: file_helper
INFO - 2021-01-21 02:51:43 --> Helper loaded: form_helper
INFO - 2021-01-21 02:51:43 --> Helper loaded: my_helper
INFO - 2021-01-21 02:51:43 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:51:43 --> Controller Class Initialized
INFO - 2021-01-21 02:51:43 --> Final output sent to browser
DEBUG - 2021-01-21 02:51:43 --> Total execution time: 0.8584
INFO - 2021-01-21 02:51:43 --> Config Class Initialized
INFO - 2021-01-21 02:51:43 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:51:43 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:51:43 --> Utf8 Class Initialized
INFO - 2021-01-21 02:51:43 --> URI Class Initialized
INFO - 2021-01-21 02:51:43 --> Router Class Initialized
INFO - 2021-01-21 02:51:43 --> Output Class Initialized
INFO - 2021-01-21 02:51:43 --> Security Class Initialized
DEBUG - 2021-01-21 02:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:51:44 --> Input Class Initialized
INFO - 2021-01-21 02:51:44 --> Language Class Initialized
INFO - 2021-01-21 02:51:44 --> Language Class Initialized
INFO - 2021-01-21 02:51:44 --> Config Class Initialized
INFO - 2021-01-21 02:51:44 --> Loader Class Initialized
INFO - 2021-01-21 02:51:44 --> Helper loaded: url_helper
INFO - 2021-01-21 02:51:44 --> Helper loaded: file_helper
INFO - 2021-01-21 02:51:44 --> Helper loaded: form_helper
INFO - 2021-01-21 02:51:44 --> Helper loaded: my_helper
INFO - 2021-01-21 02:51:44 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:51:44 --> Controller Class Initialized
INFO - 2021-01-21 02:51:47 --> Config Class Initialized
INFO - 2021-01-21 02:51:47 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:51:47 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:51:47 --> Utf8 Class Initialized
INFO - 2021-01-21 02:51:47 --> URI Class Initialized
INFO - 2021-01-21 02:51:47 --> Router Class Initialized
INFO - 2021-01-21 02:51:47 --> Output Class Initialized
INFO - 2021-01-21 02:51:47 --> Security Class Initialized
DEBUG - 2021-01-21 02:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:51:47 --> Input Class Initialized
INFO - 2021-01-21 02:51:47 --> Language Class Initialized
INFO - 2021-01-21 02:51:47 --> Language Class Initialized
INFO - 2021-01-21 02:51:47 --> Config Class Initialized
INFO - 2021-01-21 02:51:47 --> Loader Class Initialized
INFO - 2021-01-21 02:51:47 --> Helper loaded: url_helper
INFO - 2021-01-21 02:51:47 --> Helper loaded: file_helper
INFO - 2021-01-21 02:51:47 --> Helper loaded: form_helper
INFO - 2021-01-21 02:51:47 --> Helper loaded: my_helper
INFO - 2021-01-21 02:51:47 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:51:47 --> Controller Class Initialized
INFO - 2021-01-21 02:51:47 --> Final output sent to browser
DEBUG - 2021-01-21 02:51:47 --> Total execution time: 0.8882
INFO - 2021-01-21 02:51:53 --> Config Class Initialized
INFO - 2021-01-21 02:51:53 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:51:53 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:51:53 --> Utf8 Class Initialized
INFO - 2021-01-21 02:51:53 --> URI Class Initialized
INFO - 2021-01-21 02:51:53 --> Router Class Initialized
INFO - 2021-01-21 02:51:53 --> Output Class Initialized
INFO - 2021-01-21 02:51:53 --> Security Class Initialized
DEBUG - 2021-01-21 02:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:51:53 --> Input Class Initialized
INFO - 2021-01-21 02:51:53 --> Language Class Initialized
INFO - 2021-01-21 02:51:53 --> Language Class Initialized
INFO - 2021-01-21 02:51:53 --> Config Class Initialized
INFO - 2021-01-21 02:51:53 --> Loader Class Initialized
INFO - 2021-01-21 02:51:53 --> Helper loaded: url_helper
INFO - 2021-01-21 02:51:53 --> Helper loaded: file_helper
INFO - 2021-01-21 02:51:53 --> Helper loaded: form_helper
INFO - 2021-01-21 02:51:53 --> Helper loaded: my_helper
INFO - 2021-01-21 02:51:53 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:51:54 --> Controller Class Initialized
INFO - 2021-01-21 02:51:54 --> Final output sent to browser
DEBUG - 2021-01-21 02:51:54 --> Total execution time: 0.8613
INFO - 2021-01-21 02:51:56 --> Config Class Initialized
INFO - 2021-01-21 02:51:56 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:51:56 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:51:56 --> Utf8 Class Initialized
INFO - 2021-01-21 02:51:56 --> URI Class Initialized
INFO - 2021-01-21 02:51:56 --> Router Class Initialized
INFO - 2021-01-21 02:51:56 --> Output Class Initialized
INFO - 2021-01-21 02:51:56 --> Security Class Initialized
DEBUG - 2021-01-21 02:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:51:56 --> Input Class Initialized
INFO - 2021-01-21 02:51:56 --> Language Class Initialized
INFO - 2021-01-21 02:51:56 --> Language Class Initialized
INFO - 2021-01-21 02:51:56 --> Config Class Initialized
INFO - 2021-01-21 02:51:56 --> Loader Class Initialized
INFO - 2021-01-21 02:51:56 --> Helper loaded: url_helper
INFO - 2021-01-21 02:51:56 --> Helper loaded: file_helper
INFO - 2021-01-21 02:51:56 --> Helper loaded: form_helper
INFO - 2021-01-21 02:51:57 --> Helper loaded: my_helper
INFO - 2021-01-21 02:51:57 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:51:57 --> Controller Class Initialized
INFO - 2021-01-21 02:51:57 --> Final output sent to browser
DEBUG - 2021-01-21 02:51:57 --> Total execution time: 0.8371
INFO - 2021-01-21 02:51:59 --> Config Class Initialized
INFO - 2021-01-21 02:51:59 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:51:59 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:51:59 --> Utf8 Class Initialized
INFO - 2021-01-21 02:51:59 --> URI Class Initialized
INFO - 2021-01-21 02:51:59 --> Router Class Initialized
INFO - 2021-01-21 02:51:59 --> Output Class Initialized
INFO - 2021-01-21 02:51:59 --> Security Class Initialized
DEBUG - 2021-01-21 02:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:51:59 --> Input Class Initialized
INFO - 2021-01-21 02:52:00 --> Language Class Initialized
INFO - 2021-01-21 02:52:00 --> Language Class Initialized
INFO - 2021-01-21 02:52:00 --> Config Class Initialized
INFO - 2021-01-21 02:52:00 --> Loader Class Initialized
INFO - 2021-01-21 02:52:00 --> Helper loaded: url_helper
INFO - 2021-01-21 02:52:00 --> Helper loaded: file_helper
INFO - 2021-01-21 02:52:00 --> Helper loaded: form_helper
INFO - 2021-01-21 02:52:00 --> Helper loaded: my_helper
INFO - 2021-01-21 02:52:00 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:52:00 --> Controller Class Initialized
INFO - 2021-01-21 02:52:00 --> Final output sent to browser
DEBUG - 2021-01-21 02:52:00 --> Total execution time: 0.8455
INFO - 2021-01-21 02:52:02 --> Config Class Initialized
INFO - 2021-01-21 02:52:02 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:52:02 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:52:02 --> Utf8 Class Initialized
INFO - 2021-01-21 02:52:02 --> URI Class Initialized
INFO - 2021-01-21 02:52:02 --> Router Class Initialized
INFO - 2021-01-21 02:52:02 --> Output Class Initialized
INFO - 2021-01-21 02:52:02 --> Security Class Initialized
DEBUG - 2021-01-21 02:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:52:02 --> Input Class Initialized
INFO - 2021-01-21 02:52:02 --> Language Class Initialized
INFO - 2021-01-21 02:52:02 --> Language Class Initialized
INFO - 2021-01-21 02:52:02 --> Config Class Initialized
INFO - 2021-01-21 02:52:02 --> Loader Class Initialized
INFO - 2021-01-21 02:52:02 --> Helper loaded: url_helper
INFO - 2021-01-21 02:52:02 --> Helper loaded: file_helper
INFO - 2021-01-21 02:52:02 --> Helper loaded: form_helper
INFO - 2021-01-21 02:52:02 --> Helper loaded: my_helper
INFO - 2021-01-21 02:52:03 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:52:03 --> Controller Class Initialized
INFO - 2021-01-21 02:52:03 --> Final output sent to browser
DEBUG - 2021-01-21 02:52:03 --> Total execution time: 0.9386
INFO - 2021-01-21 02:52:06 --> Config Class Initialized
INFO - 2021-01-21 02:52:06 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:52:06 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:52:06 --> Utf8 Class Initialized
INFO - 2021-01-21 02:52:06 --> URI Class Initialized
INFO - 2021-01-21 02:52:06 --> Router Class Initialized
INFO - 2021-01-21 02:52:06 --> Output Class Initialized
INFO - 2021-01-21 02:52:06 --> Security Class Initialized
DEBUG - 2021-01-21 02:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:52:06 --> Input Class Initialized
INFO - 2021-01-21 02:52:06 --> Language Class Initialized
INFO - 2021-01-21 02:52:06 --> Language Class Initialized
INFO - 2021-01-21 02:52:06 --> Config Class Initialized
INFO - 2021-01-21 02:52:06 --> Loader Class Initialized
INFO - 2021-01-21 02:52:06 --> Helper loaded: url_helper
INFO - 2021-01-21 02:52:06 --> Helper loaded: file_helper
INFO - 2021-01-21 02:52:06 --> Helper loaded: form_helper
INFO - 2021-01-21 02:52:06 --> Helper loaded: my_helper
INFO - 2021-01-21 02:52:06 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:52:06 --> Controller Class Initialized
INFO - 2021-01-21 02:52:07 --> Final output sent to browser
DEBUG - 2021-01-21 02:52:07 --> Total execution time: 0.9320
INFO - 2021-01-21 02:52:12 --> Config Class Initialized
INFO - 2021-01-21 02:52:12 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:52:12 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:52:12 --> Utf8 Class Initialized
INFO - 2021-01-21 02:52:12 --> URI Class Initialized
INFO - 2021-01-21 02:52:12 --> Router Class Initialized
INFO - 2021-01-21 02:52:12 --> Output Class Initialized
INFO - 2021-01-21 02:52:12 --> Security Class Initialized
DEBUG - 2021-01-21 02:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:52:12 --> Input Class Initialized
INFO - 2021-01-21 02:52:12 --> Language Class Initialized
INFO - 2021-01-21 02:52:12 --> Language Class Initialized
INFO - 2021-01-21 02:52:12 --> Config Class Initialized
INFO - 2021-01-21 02:52:12 --> Loader Class Initialized
INFO - 2021-01-21 02:52:12 --> Helper loaded: url_helper
INFO - 2021-01-21 02:52:12 --> Helper loaded: file_helper
INFO - 2021-01-21 02:52:12 --> Helper loaded: form_helper
INFO - 2021-01-21 02:52:12 --> Helper loaded: my_helper
INFO - 2021-01-21 02:52:12 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:52:12 --> Controller Class Initialized
DEBUG - 2021-01-21 02:52:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-21 02:52:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:52:13 --> Final output sent to browser
DEBUG - 2021-01-21 02:52:13 --> Total execution time: 0.8427
INFO - 2021-01-21 02:52:15 --> Config Class Initialized
INFO - 2021-01-21 02:52:15 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:52:15 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:52:15 --> Utf8 Class Initialized
INFO - 2021-01-21 02:52:15 --> URI Class Initialized
INFO - 2021-01-21 02:52:15 --> Router Class Initialized
INFO - 2021-01-21 02:52:15 --> Output Class Initialized
INFO - 2021-01-21 02:52:15 --> Security Class Initialized
DEBUG - 2021-01-21 02:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:52:15 --> Input Class Initialized
INFO - 2021-01-21 02:52:15 --> Language Class Initialized
INFO - 2021-01-21 02:52:15 --> Language Class Initialized
INFO - 2021-01-21 02:52:15 --> Config Class Initialized
INFO - 2021-01-21 02:52:15 --> Loader Class Initialized
INFO - 2021-01-21 02:52:16 --> Helper loaded: url_helper
INFO - 2021-01-21 02:52:16 --> Helper loaded: file_helper
INFO - 2021-01-21 02:52:16 --> Helper loaded: form_helper
INFO - 2021-01-21 02:52:16 --> Helper loaded: my_helper
INFO - 2021-01-21 02:52:16 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:52:16 --> Controller Class Initialized
DEBUG - 2021-01-21 02:52:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-21 02:52:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:52:16 --> Final output sent to browser
DEBUG - 2021-01-21 02:52:16 --> Total execution time: 1.2599
INFO - 2021-01-21 02:52:18 --> Config Class Initialized
INFO - 2021-01-21 02:52:18 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:52:18 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:52:18 --> Utf8 Class Initialized
INFO - 2021-01-21 02:52:18 --> URI Class Initialized
INFO - 2021-01-21 02:52:18 --> Router Class Initialized
INFO - 2021-01-21 02:52:18 --> Output Class Initialized
INFO - 2021-01-21 02:52:18 --> Security Class Initialized
DEBUG - 2021-01-21 02:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:52:18 --> Input Class Initialized
INFO - 2021-01-21 02:52:18 --> Language Class Initialized
INFO - 2021-01-21 02:52:18 --> Language Class Initialized
INFO - 2021-01-21 02:52:18 --> Config Class Initialized
INFO - 2021-01-21 02:52:18 --> Loader Class Initialized
INFO - 2021-01-21 02:52:18 --> Helper loaded: url_helper
INFO - 2021-01-21 02:52:18 --> Helper loaded: file_helper
INFO - 2021-01-21 02:52:18 --> Helper loaded: form_helper
INFO - 2021-01-21 02:52:18 --> Helper loaded: my_helper
INFO - 2021-01-21 02:52:18 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:52:19 --> Controller Class Initialized
INFO - 2021-01-21 02:52:19 --> Final output sent to browser
DEBUG - 2021-01-21 02:52:19 --> Total execution time: 0.7991
INFO - 2021-01-21 02:53:10 --> Config Class Initialized
INFO - 2021-01-21 02:53:10 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:53:10 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:53:10 --> Utf8 Class Initialized
INFO - 2021-01-21 02:53:10 --> URI Class Initialized
INFO - 2021-01-21 02:53:10 --> Router Class Initialized
INFO - 2021-01-21 02:53:10 --> Output Class Initialized
INFO - 2021-01-21 02:53:10 --> Security Class Initialized
DEBUG - 2021-01-21 02:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:53:10 --> Input Class Initialized
INFO - 2021-01-21 02:53:10 --> Language Class Initialized
INFO - 2021-01-21 02:53:10 --> Language Class Initialized
INFO - 2021-01-21 02:53:10 --> Config Class Initialized
INFO - 2021-01-21 02:53:10 --> Loader Class Initialized
INFO - 2021-01-21 02:53:10 --> Helper loaded: url_helper
INFO - 2021-01-21 02:53:10 --> Helper loaded: file_helper
INFO - 2021-01-21 02:53:10 --> Helper loaded: form_helper
INFO - 2021-01-21 02:53:10 --> Helper loaded: my_helper
INFO - 2021-01-21 02:53:10 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:53:11 --> Controller Class Initialized
INFO - 2021-01-21 02:53:11 --> Final output sent to browser
DEBUG - 2021-01-21 02:53:11 --> Total execution time: 0.9510
INFO - 2021-01-21 02:53:11 --> Config Class Initialized
INFO - 2021-01-21 02:53:11 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:53:11 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:53:11 --> Utf8 Class Initialized
INFO - 2021-01-21 02:53:11 --> URI Class Initialized
INFO - 2021-01-21 02:53:11 --> Router Class Initialized
INFO - 2021-01-21 02:53:11 --> Output Class Initialized
INFO - 2021-01-21 02:53:11 --> Security Class Initialized
DEBUG - 2021-01-21 02:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:53:11 --> Input Class Initialized
INFO - 2021-01-21 02:53:11 --> Language Class Initialized
INFO - 2021-01-21 02:53:11 --> Language Class Initialized
INFO - 2021-01-21 02:53:11 --> Config Class Initialized
INFO - 2021-01-21 02:53:11 --> Loader Class Initialized
INFO - 2021-01-21 02:53:11 --> Helper loaded: url_helper
INFO - 2021-01-21 02:53:11 --> Helper loaded: file_helper
INFO - 2021-01-21 02:53:11 --> Helper loaded: form_helper
INFO - 2021-01-21 02:53:11 --> Helper loaded: my_helper
INFO - 2021-01-21 02:53:11 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:53:12 --> Controller Class Initialized
DEBUG - 2021-01-21 02:53:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-21 02:53:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 02:53:12 --> Final output sent to browser
DEBUG - 2021-01-21 02:53:12 --> Total execution time: 0.8848
INFO - 2021-01-21 02:53:13 --> Config Class Initialized
INFO - 2021-01-21 02:53:13 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:53:13 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:53:13 --> Utf8 Class Initialized
INFO - 2021-01-21 02:53:13 --> URI Class Initialized
INFO - 2021-01-21 02:53:13 --> Router Class Initialized
INFO - 2021-01-21 02:53:13 --> Output Class Initialized
INFO - 2021-01-21 02:53:13 --> Security Class Initialized
DEBUG - 2021-01-21 02:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:53:13 --> Input Class Initialized
INFO - 2021-01-21 02:53:13 --> Language Class Initialized
INFO - 2021-01-21 02:53:13 --> Language Class Initialized
INFO - 2021-01-21 02:53:13 --> Config Class Initialized
INFO - 2021-01-21 02:53:13 --> Loader Class Initialized
INFO - 2021-01-21 02:53:13 --> Helper loaded: url_helper
INFO - 2021-01-21 02:53:13 --> Helper loaded: file_helper
INFO - 2021-01-21 02:53:13 --> Helper loaded: form_helper
INFO - 2021-01-21 02:53:13 --> Helper loaded: my_helper
INFO - 2021-01-21 02:53:13 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:53:13 --> Controller Class Initialized
INFO - 2021-01-21 02:53:14 --> Final output sent to browser
DEBUG - 2021-01-21 02:53:14 --> Total execution time: 0.8733
INFO - 2021-01-21 02:53:20 --> Config Class Initialized
INFO - 2021-01-21 02:53:20 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:53:20 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:53:20 --> Utf8 Class Initialized
INFO - 2021-01-21 02:53:21 --> URI Class Initialized
INFO - 2021-01-21 02:53:21 --> Router Class Initialized
INFO - 2021-01-21 02:53:21 --> Output Class Initialized
INFO - 2021-01-21 02:53:21 --> Security Class Initialized
DEBUG - 2021-01-21 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:53:21 --> Input Class Initialized
INFO - 2021-01-21 02:53:21 --> Language Class Initialized
INFO - 2021-01-21 02:53:21 --> Language Class Initialized
INFO - 2021-01-21 02:53:21 --> Config Class Initialized
INFO - 2021-01-21 02:53:21 --> Loader Class Initialized
INFO - 2021-01-21 02:53:21 --> Helper loaded: url_helper
INFO - 2021-01-21 02:53:21 --> Helper loaded: file_helper
INFO - 2021-01-21 02:53:21 --> Helper loaded: form_helper
INFO - 2021-01-21 02:53:21 --> Helper loaded: my_helper
INFO - 2021-01-21 02:53:21 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:53:21 --> Controller Class Initialized
INFO - 2021-01-21 02:53:21 --> Final output sent to browser
DEBUG - 2021-01-21 02:53:21 --> Total execution time: 0.9237
INFO - 2021-01-21 02:53:24 --> Config Class Initialized
INFO - 2021-01-21 02:53:24 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:53:24 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:53:24 --> Utf8 Class Initialized
INFO - 2021-01-21 02:53:24 --> URI Class Initialized
INFO - 2021-01-21 02:53:24 --> Router Class Initialized
INFO - 2021-01-21 02:53:24 --> Output Class Initialized
INFO - 2021-01-21 02:53:24 --> Security Class Initialized
DEBUG - 2021-01-21 02:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:53:24 --> Input Class Initialized
INFO - 2021-01-21 02:53:24 --> Language Class Initialized
INFO - 2021-01-21 02:53:24 --> Language Class Initialized
INFO - 2021-01-21 02:53:24 --> Config Class Initialized
INFO - 2021-01-21 02:53:24 --> Loader Class Initialized
INFO - 2021-01-21 02:53:24 --> Helper loaded: url_helper
INFO - 2021-01-21 02:53:24 --> Helper loaded: file_helper
INFO - 2021-01-21 02:53:24 --> Helper loaded: form_helper
INFO - 2021-01-21 02:53:24 --> Helper loaded: my_helper
INFO - 2021-01-21 02:53:25 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:53:25 --> Controller Class Initialized
DEBUG - 2021-01-21 02:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:53:25 --> Final output sent to browser
DEBUG - 2021-01-21 02:53:25 --> Total execution time: 0.8411
INFO - 2021-01-21 02:54:18 --> Config Class Initialized
INFO - 2021-01-21 02:54:18 --> Hooks Class Initialized
DEBUG - 2021-01-21 02:54:18 --> UTF-8 Support Enabled
INFO - 2021-01-21 02:54:18 --> Utf8 Class Initialized
INFO - 2021-01-21 02:54:19 --> URI Class Initialized
INFO - 2021-01-21 02:54:19 --> Router Class Initialized
INFO - 2021-01-21 02:54:19 --> Output Class Initialized
INFO - 2021-01-21 02:54:19 --> Security Class Initialized
DEBUG - 2021-01-21 02:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 02:54:19 --> Input Class Initialized
INFO - 2021-01-21 02:54:19 --> Language Class Initialized
INFO - 2021-01-21 02:54:19 --> Language Class Initialized
INFO - 2021-01-21 02:54:19 --> Config Class Initialized
INFO - 2021-01-21 02:54:19 --> Loader Class Initialized
INFO - 2021-01-21 02:54:19 --> Helper loaded: url_helper
INFO - 2021-01-21 02:54:19 --> Helper loaded: file_helper
INFO - 2021-01-21 02:54:19 --> Helper loaded: form_helper
INFO - 2021-01-21 02:54:19 --> Helper loaded: my_helper
INFO - 2021-01-21 02:54:19 --> Database Driver Class Initialized
DEBUG - 2021-01-21 02:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 02:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 02:54:19 --> Controller Class Initialized
DEBUG - 2021-01-21 02:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 02:54:19 --> Final output sent to browser
DEBUG - 2021-01-21 02:54:19 --> Total execution time: 0.9229
INFO - 2021-01-21 03:01:02 --> Config Class Initialized
INFO - 2021-01-21 03:01:02 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:01:02 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:01:02 --> Utf8 Class Initialized
INFO - 2021-01-21 03:01:02 --> URI Class Initialized
INFO - 2021-01-21 03:01:02 --> Router Class Initialized
INFO - 2021-01-21 03:01:02 --> Output Class Initialized
INFO - 2021-01-21 03:01:02 --> Security Class Initialized
DEBUG - 2021-01-21 03:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:01:02 --> Input Class Initialized
INFO - 2021-01-21 03:01:02 --> Language Class Initialized
INFO - 2021-01-21 03:01:02 --> Language Class Initialized
INFO - 2021-01-21 03:01:02 --> Config Class Initialized
INFO - 2021-01-21 03:01:02 --> Loader Class Initialized
INFO - 2021-01-21 03:01:02 --> Helper loaded: url_helper
INFO - 2021-01-21 03:01:02 --> Helper loaded: file_helper
INFO - 2021-01-21 03:01:02 --> Helper loaded: form_helper
INFO - 2021-01-21 03:01:02 --> Helper loaded: my_helper
INFO - 2021-01-21 03:01:02 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:01:03 --> Controller Class Initialized
DEBUG - 2021-01-21 03:01:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 03:01:03 --> Final output sent to browser
DEBUG - 2021-01-21 03:01:03 --> Total execution time: 0.9554
INFO - 2021-01-21 03:01:50 --> Config Class Initialized
INFO - 2021-01-21 03:01:50 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:01:50 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:01:50 --> Utf8 Class Initialized
INFO - 2021-01-21 03:01:50 --> URI Class Initialized
INFO - 2021-01-21 03:01:50 --> Router Class Initialized
INFO - 2021-01-21 03:01:50 --> Output Class Initialized
INFO - 2021-01-21 03:01:50 --> Security Class Initialized
DEBUG - 2021-01-21 03:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:01:50 --> Input Class Initialized
INFO - 2021-01-21 03:01:50 --> Language Class Initialized
INFO - 2021-01-21 03:01:50 --> Language Class Initialized
INFO - 2021-01-21 03:01:50 --> Config Class Initialized
INFO - 2021-01-21 03:01:50 --> Loader Class Initialized
INFO - 2021-01-21 03:01:50 --> Helper loaded: url_helper
INFO - 2021-01-21 03:01:50 --> Helper loaded: file_helper
INFO - 2021-01-21 03:01:50 --> Helper loaded: form_helper
INFO - 2021-01-21 03:01:50 --> Helper loaded: my_helper
INFO - 2021-01-21 03:01:50 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:01:51 --> Controller Class Initialized
DEBUG - 2021-01-21 03:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 03:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:01:51 --> Final output sent to browser
DEBUG - 2021-01-21 03:01:51 --> Total execution time: 1.0202
INFO - 2021-01-21 03:01:54 --> Config Class Initialized
INFO - 2021-01-21 03:01:54 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:01:54 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:01:54 --> Utf8 Class Initialized
INFO - 2021-01-21 03:01:54 --> URI Class Initialized
INFO - 2021-01-21 03:01:54 --> Router Class Initialized
INFO - 2021-01-21 03:01:54 --> Output Class Initialized
INFO - 2021-01-21 03:01:54 --> Security Class Initialized
DEBUG - 2021-01-21 03:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:01:54 --> Input Class Initialized
INFO - 2021-01-21 03:01:54 --> Language Class Initialized
INFO - 2021-01-21 03:01:54 --> Language Class Initialized
INFO - 2021-01-21 03:01:54 --> Config Class Initialized
INFO - 2021-01-21 03:01:54 --> Loader Class Initialized
INFO - 2021-01-21 03:01:54 --> Helper loaded: url_helper
INFO - 2021-01-21 03:01:54 --> Helper loaded: file_helper
INFO - 2021-01-21 03:01:54 --> Helper loaded: form_helper
INFO - 2021-01-21 03:01:54 --> Helper loaded: my_helper
INFO - 2021-01-21 03:01:54 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:01:54 --> Controller Class Initialized
DEBUG - 2021-01-21 03:01:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:01:55 --> Final output sent to browser
DEBUG - 2021-01-21 03:01:55 --> Total execution time: 0.8849
INFO - 2021-01-21 03:01:59 --> Config Class Initialized
INFO - 2021-01-21 03:01:59 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:01:59 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:01:59 --> Utf8 Class Initialized
INFO - 2021-01-21 03:01:59 --> URI Class Initialized
INFO - 2021-01-21 03:01:59 --> Router Class Initialized
INFO - 2021-01-21 03:02:00 --> Output Class Initialized
INFO - 2021-01-21 03:02:00 --> Security Class Initialized
DEBUG - 2021-01-21 03:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:02:00 --> Input Class Initialized
INFO - 2021-01-21 03:02:00 --> Language Class Initialized
INFO - 2021-01-21 03:02:00 --> Language Class Initialized
INFO - 2021-01-21 03:02:00 --> Config Class Initialized
INFO - 2021-01-21 03:02:00 --> Loader Class Initialized
INFO - 2021-01-21 03:02:00 --> Helper loaded: url_helper
INFO - 2021-01-21 03:02:00 --> Helper loaded: file_helper
INFO - 2021-01-21 03:02:00 --> Helper loaded: form_helper
INFO - 2021-01-21 03:02:00 --> Helper loaded: my_helper
INFO - 2021-01-21 03:02:00 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:02:00 --> Controller Class Initialized
DEBUG - 2021-01-21 03:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-21 03:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:02:01 --> Final output sent to browser
DEBUG - 2021-01-21 03:02:01 --> Total execution time: 1.1461
INFO - 2021-01-21 03:02:01 --> Config Class Initialized
INFO - 2021-01-21 03:02:01 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:02:01 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:02:01 --> Utf8 Class Initialized
INFO - 2021-01-21 03:02:01 --> URI Class Initialized
INFO - 2021-01-21 03:02:02 --> Router Class Initialized
INFO - 2021-01-21 03:02:02 --> Output Class Initialized
INFO - 2021-01-21 03:02:02 --> Security Class Initialized
DEBUG - 2021-01-21 03:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:02:02 --> Input Class Initialized
INFO - 2021-01-21 03:02:02 --> Language Class Initialized
INFO - 2021-01-21 03:02:02 --> Language Class Initialized
INFO - 2021-01-21 03:02:02 --> Config Class Initialized
INFO - 2021-01-21 03:02:02 --> Loader Class Initialized
INFO - 2021-01-21 03:02:02 --> Helper loaded: url_helper
INFO - 2021-01-21 03:02:02 --> Helper loaded: file_helper
INFO - 2021-01-21 03:02:02 --> Helper loaded: form_helper
INFO - 2021-01-21 03:02:02 --> Helper loaded: my_helper
INFO - 2021-01-21 03:02:02 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:02:02 --> Controller Class Initialized
DEBUG - 2021-01-21 03:02:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 03:02:02 --> Final output sent to browser
DEBUG - 2021-01-21 03:02:02 --> Total execution time: 0.9081
INFO - 2021-01-21 03:02:08 --> Config Class Initialized
INFO - 2021-01-21 03:02:08 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:02:08 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:02:08 --> Utf8 Class Initialized
INFO - 2021-01-21 03:02:08 --> URI Class Initialized
INFO - 2021-01-21 03:02:08 --> Router Class Initialized
INFO - 2021-01-21 03:02:08 --> Output Class Initialized
INFO - 2021-01-21 03:02:08 --> Security Class Initialized
DEBUG - 2021-01-21 03:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:02:08 --> Input Class Initialized
INFO - 2021-01-21 03:02:08 --> Language Class Initialized
INFO - 2021-01-21 03:02:08 --> Language Class Initialized
INFO - 2021-01-21 03:02:08 --> Config Class Initialized
INFO - 2021-01-21 03:02:08 --> Loader Class Initialized
INFO - 2021-01-21 03:02:08 --> Helper loaded: url_helper
INFO - 2021-01-21 03:02:08 --> Helper loaded: file_helper
INFO - 2021-01-21 03:02:08 --> Helper loaded: form_helper
INFO - 2021-01-21 03:02:08 --> Helper loaded: my_helper
INFO - 2021-01-21 03:02:08 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:02:09 --> Controller Class Initialized
DEBUG - 2021-01-21 03:02:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 03:02:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:02:09 --> Final output sent to browser
DEBUG - 2021-01-21 03:02:09 --> Total execution time: 1.1729
INFO - 2021-01-21 03:16:27 --> Config Class Initialized
INFO - 2021-01-21 03:16:27 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:27 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:27 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:27 --> URI Class Initialized
INFO - 2021-01-21 03:16:27 --> Router Class Initialized
INFO - 2021-01-21 03:16:27 --> Output Class Initialized
INFO - 2021-01-21 03:16:27 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:27 --> Input Class Initialized
INFO - 2021-01-21 03:16:27 --> Language Class Initialized
INFO - 2021-01-21 03:16:27 --> Language Class Initialized
INFO - 2021-01-21 03:16:27 --> Config Class Initialized
INFO - 2021-01-21 03:16:27 --> Loader Class Initialized
INFO - 2021-01-21 03:16:27 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:27 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:27 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:27 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:27 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:27 --> Controller Class Initialized
INFO - 2021-01-21 03:16:27 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:16:27 --> Config Class Initialized
INFO - 2021-01-21 03:16:27 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:27 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:27 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:27 --> URI Class Initialized
INFO - 2021-01-21 03:16:27 --> Router Class Initialized
INFO - 2021-01-21 03:16:27 --> Output Class Initialized
INFO - 2021-01-21 03:16:27 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:27 --> Input Class Initialized
INFO - 2021-01-21 03:16:28 --> Language Class Initialized
INFO - 2021-01-21 03:16:28 --> Language Class Initialized
INFO - 2021-01-21 03:16:28 --> Config Class Initialized
INFO - 2021-01-21 03:16:28 --> Loader Class Initialized
INFO - 2021-01-21 03:16:28 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:28 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:28 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:28 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:28 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:28 --> Controller Class Initialized
DEBUG - 2021-01-21 03:16:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 03:16:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:16:28 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:28 --> Total execution time: 0.3615
INFO - 2021-01-21 03:16:32 --> Config Class Initialized
INFO - 2021-01-21 03:16:32 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:32 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:32 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:32 --> URI Class Initialized
INFO - 2021-01-21 03:16:32 --> Router Class Initialized
INFO - 2021-01-21 03:16:32 --> Output Class Initialized
INFO - 2021-01-21 03:16:32 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:32 --> Input Class Initialized
INFO - 2021-01-21 03:16:32 --> Language Class Initialized
INFO - 2021-01-21 03:16:32 --> Language Class Initialized
INFO - 2021-01-21 03:16:32 --> Config Class Initialized
INFO - 2021-01-21 03:16:32 --> Loader Class Initialized
INFO - 2021-01-21 03:16:32 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:32 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:32 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:32 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:32 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:32 --> Controller Class Initialized
INFO - 2021-01-21 03:16:32 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:32 --> Total execution time: 0.4107
INFO - 2021-01-21 03:16:36 --> Config Class Initialized
INFO - 2021-01-21 03:16:36 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:36 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:36 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:36 --> URI Class Initialized
INFO - 2021-01-21 03:16:36 --> Router Class Initialized
INFO - 2021-01-21 03:16:36 --> Output Class Initialized
INFO - 2021-01-21 03:16:36 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:36 --> Input Class Initialized
INFO - 2021-01-21 03:16:36 --> Language Class Initialized
INFO - 2021-01-21 03:16:36 --> Language Class Initialized
INFO - 2021-01-21 03:16:36 --> Config Class Initialized
INFO - 2021-01-21 03:16:36 --> Loader Class Initialized
INFO - 2021-01-21 03:16:36 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:36 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:36 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:36 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:37 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:37 --> Controller Class Initialized
INFO - 2021-01-21 03:16:37 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:16:37 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:37 --> Total execution time: 0.4894
INFO - 2021-01-21 03:16:37 --> Config Class Initialized
INFO - 2021-01-21 03:16:37 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:37 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:37 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:37 --> URI Class Initialized
INFO - 2021-01-21 03:16:37 --> Router Class Initialized
INFO - 2021-01-21 03:16:37 --> Output Class Initialized
INFO - 2021-01-21 03:16:37 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:37 --> Input Class Initialized
INFO - 2021-01-21 03:16:37 --> Language Class Initialized
INFO - 2021-01-21 03:16:37 --> Language Class Initialized
INFO - 2021-01-21 03:16:37 --> Config Class Initialized
INFO - 2021-01-21 03:16:37 --> Loader Class Initialized
INFO - 2021-01-21 03:16:37 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:37 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:37 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:37 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:37 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:37 --> Controller Class Initialized
DEBUG - 2021-01-21 03:16:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 03:16:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:16:37 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:37 --> Total execution time: 0.5681
INFO - 2021-01-21 03:16:41 --> Config Class Initialized
INFO - 2021-01-21 03:16:41 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:41 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:41 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:41 --> URI Class Initialized
INFO - 2021-01-21 03:16:41 --> Router Class Initialized
INFO - 2021-01-21 03:16:41 --> Output Class Initialized
INFO - 2021-01-21 03:16:41 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:41 --> Input Class Initialized
INFO - 2021-01-21 03:16:41 --> Language Class Initialized
INFO - 2021-01-21 03:16:41 --> Language Class Initialized
INFO - 2021-01-21 03:16:41 --> Config Class Initialized
INFO - 2021-01-21 03:16:41 --> Loader Class Initialized
INFO - 2021-01-21 03:16:41 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:41 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:41 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:41 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:41 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:41 --> Controller Class Initialized
DEBUG - 2021-01-21 03:16:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-01-21 03:16:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:16:41 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:41 --> Total execution time: 0.4591
INFO - 2021-01-21 03:16:42 --> Config Class Initialized
INFO - 2021-01-21 03:16:42 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:42 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:42 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:42 --> URI Class Initialized
INFO - 2021-01-21 03:16:42 --> Router Class Initialized
INFO - 2021-01-21 03:16:42 --> Output Class Initialized
INFO - 2021-01-21 03:16:42 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:42 --> Input Class Initialized
INFO - 2021-01-21 03:16:42 --> Language Class Initialized
INFO - 2021-01-21 03:16:42 --> Language Class Initialized
INFO - 2021-01-21 03:16:42 --> Config Class Initialized
INFO - 2021-01-21 03:16:42 --> Loader Class Initialized
INFO - 2021-01-21 03:16:42 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:42 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:42 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:42 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:42 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:42 --> Controller Class Initialized
INFO - 2021-01-21 03:16:45 --> Config Class Initialized
INFO - 2021-01-21 03:16:45 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:45 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:45 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:45 --> URI Class Initialized
INFO - 2021-01-21 03:16:45 --> Router Class Initialized
INFO - 2021-01-21 03:16:45 --> Output Class Initialized
INFO - 2021-01-21 03:16:45 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:45 --> Input Class Initialized
INFO - 2021-01-21 03:16:45 --> Language Class Initialized
INFO - 2021-01-21 03:16:45 --> Language Class Initialized
INFO - 2021-01-21 03:16:45 --> Config Class Initialized
INFO - 2021-01-21 03:16:45 --> Loader Class Initialized
INFO - 2021-01-21 03:16:45 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:45 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:45 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:45 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:45 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:45 --> Controller Class Initialized
INFO - 2021-01-21 03:16:45 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:45 --> Total execution time: 0.3502
INFO - 2021-01-21 03:16:45 --> Config Class Initialized
INFO - 2021-01-21 03:16:45 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:45 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:45 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:45 --> URI Class Initialized
INFO - 2021-01-21 03:16:45 --> Router Class Initialized
INFO - 2021-01-21 03:16:45 --> Output Class Initialized
INFO - 2021-01-21 03:16:45 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:45 --> Input Class Initialized
INFO - 2021-01-21 03:16:45 --> Language Class Initialized
INFO - 2021-01-21 03:16:45 --> Language Class Initialized
INFO - 2021-01-21 03:16:45 --> Config Class Initialized
INFO - 2021-01-21 03:16:45 --> Loader Class Initialized
INFO - 2021-01-21 03:16:45 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:45 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:45 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:45 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:46 --> Controller Class Initialized
INFO - 2021-01-21 03:16:48 --> Config Class Initialized
INFO - 2021-01-21 03:16:48 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:48 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:48 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:48 --> URI Class Initialized
INFO - 2021-01-21 03:16:48 --> Router Class Initialized
INFO - 2021-01-21 03:16:48 --> Output Class Initialized
INFO - 2021-01-21 03:16:48 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:48 --> Input Class Initialized
INFO - 2021-01-21 03:16:48 --> Language Class Initialized
INFO - 2021-01-21 03:16:48 --> Language Class Initialized
INFO - 2021-01-21 03:16:48 --> Config Class Initialized
INFO - 2021-01-21 03:16:48 --> Loader Class Initialized
INFO - 2021-01-21 03:16:48 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:48 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:48 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:48 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:48 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:48 --> Controller Class Initialized
INFO - 2021-01-21 03:16:48 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:16:48 --> Config Class Initialized
INFO - 2021-01-21 03:16:48 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:48 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:48 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:48 --> URI Class Initialized
INFO - 2021-01-21 03:16:48 --> Router Class Initialized
INFO - 2021-01-21 03:16:48 --> Output Class Initialized
INFO - 2021-01-21 03:16:48 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:48 --> Input Class Initialized
INFO - 2021-01-21 03:16:48 --> Language Class Initialized
INFO - 2021-01-21 03:16:48 --> Language Class Initialized
INFO - 2021-01-21 03:16:48 --> Config Class Initialized
INFO - 2021-01-21 03:16:48 --> Loader Class Initialized
INFO - 2021-01-21 03:16:48 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:48 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:48 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:48 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:48 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:48 --> Controller Class Initialized
DEBUG - 2021-01-21 03:16:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 03:16:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:16:48 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:48 --> Total execution time: 0.3852
INFO - 2021-01-21 03:16:52 --> Config Class Initialized
INFO - 2021-01-21 03:16:52 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:52 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:52 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:52 --> URI Class Initialized
INFO - 2021-01-21 03:16:52 --> Router Class Initialized
INFO - 2021-01-21 03:16:52 --> Output Class Initialized
INFO - 2021-01-21 03:16:52 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:52 --> Input Class Initialized
INFO - 2021-01-21 03:16:52 --> Language Class Initialized
INFO - 2021-01-21 03:16:52 --> Language Class Initialized
INFO - 2021-01-21 03:16:52 --> Config Class Initialized
INFO - 2021-01-21 03:16:52 --> Loader Class Initialized
INFO - 2021-01-21 03:16:52 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:52 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:52 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:52 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:52 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:53 --> Controller Class Initialized
INFO - 2021-01-21 03:16:53 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:16:53 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:53 --> Total execution time: 0.4364
INFO - 2021-01-21 03:16:53 --> Config Class Initialized
INFO - 2021-01-21 03:16:53 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:53 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:53 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:53 --> URI Class Initialized
INFO - 2021-01-21 03:16:53 --> Router Class Initialized
INFO - 2021-01-21 03:16:53 --> Output Class Initialized
INFO - 2021-01-21 03:16:53 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:53 --> Input Class Initialized
INFO - 2021-01-21 03:16:53 --> Language Class Initialized
INFO - 2021-01-21 03:16:53 --> Language Class Initialized
INFO - 2021-01-21 03:16:53 --> Config Class Initialized
INFO - 2021-01-21 03:16:53 --> Loader Class Initialized
INFO - 2021-01-21 03:16:53 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:53 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:53 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:53 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:53 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:53 --> Controller Class Initialized
DEBUG - 2021-01-21 03:16:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 03:16:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:16:53 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:54 --> Total execution time: 0.5361
INFO - 2021-01-21 03:16:55 --> Config Class Initialized
INFO - 2021-01-21 03:16:55 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:55 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:55 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:55 --> URI Class Initialized
INFO - 2021-01-21 03:16:55 --> Router Class Initialized
INFO - 2021-01-21 03:16:55 --> Output Class Initialized
INFO - 2021-01-21 03:16:55 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:55 --> Input Class Initialized
INFO - 2021-01-21 03:16:55 --> Language Class Initialized
INFO - 2021-01-21 03:16:55 --> Language Class Initialized
INFO - 2021-01-21 03:16:55 --> Config Class Initialized
INFO - 2021-01-21 03:16:55 --> Loader Class Initialized
INFO - 2021-01-21 03:16:55 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:55 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:55 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:55 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:55 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:55 --> Controller Class Initialized
DEBUG - 2021-01-21 03:16:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 03:16:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:16:55 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:55 --> Total execution time: 0.4386
INFO - 2021-01-21 03:16:57 --> Config Class Initialized
INFO - 2021-01-21 03:16:57 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:16:57 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:16:57 --> Utf8 Class Initialized
INFO - 2021-01-21 03:16:57 --> URI Class Initialized
INFO - 2021-01-21 03:16:57 --> Router Class Initialized
INFO - 2021-01-21 03:16:57 --> Output Class Initialized
INFO - 2021-01-21 03:16:57 --> Security Class Initialized
DEBUG - 2021-01-21 03:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:16:57 --> Input Class Initialized
INFO - 2021-01-21 03:16:57 --> Language Class Initialized
INFO - 2021-01-21 03:16:57 --> Language Class Initialized
INFO - 2021-01-21 03:16:57 --> Config Class Initialized
INFO - 2021-01-21 03:16:57 --> Loader Class Initialized
INFO - 2021-01-21 03:16:57 --> Helper loaded: url_helper
INFO - 2021-01-21 03:16:57 --> Helper loaded: file_helper
INFO - 2021-01-21 03:16:57 --> Helper loaded: form_helper
INFO - 2021-01-21 03:16:57 --> Helper loaded: my_helper
INFO - 2021-01-21 03:16:57 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:16:57 --> Controller Class Initialized
DEBUG - 2021-01-21 03:16:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:16:57 --> Final output sent to browser
DEBUG - 2021-01-21 03:16:57 --> Total execution time: 0.3665
INFO - 2021-01-21 03:17:27 --> Config Class Initialized
INFO - 2021-01-21 03:17:27 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:17:27 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:17:27 --> Utf8 Class Initialized
INFO - 2021-01-21 03:17:27 --> URI Class Initialized
INFO - 2021-01-21 03:17:27 --> Router Class Initialized
INFO - 2021-01-21 03:17:27 --> Output Class Initialized
INFO - 2021-01-21 03:17:27 --> Security Class Initialized
DEBUG - 2021-01-21 03:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:17:27 --> Input Class Initialized
INFO - 2021-01-21 03:17:27 --> Language Class Initialized
INFO - 2021-01-21 03:17:27 --> Language Class Initialized
INFO - 2021-01-21 03:17:27 --> Config Class Initialized
INFO - 2021-01-21 03:17:27 --> Loader Class Initialized
INFO - 2021-01-21 03:17:27 --> Helper loaded: url_helper
INFO - 2021-01-21 03:17:27 --> Helper loaded: file_helper
INFO - 2021-01-21 03:17:27 --> Helper loaded: form_helper
INFO - 2021-01-21 03:17:27 --> Helper loaded: my_helper
INFO - 2021-01-21 03:17:27 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:17:27 --> Controller Class Initialized
ERROR - 2021-01-21 03:17:27 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2904
ERROR - 2021-01-21 03:17:27 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2904
ERROR - 2021-01-21 03:17:27 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2906
ERROR - 2021-01-21 03:17:27 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2907
ERROR - 2021-01-21 03:17:27 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
ERROR - 2021-01-21 03:17:27 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
ERROR - 2021-01-21 03:17:27 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
DEBUG - 2021-01-21 03:17:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 03:17:27 --> Final output sent to browser
DEBUG - 2021-01-21 03:17:27 --> Total execution time: 0.6051
INFO - 2021-01-21 03:18:20 --> Config Class Initialized
INFO - 2021-01-21 03:18:20 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:20 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:20 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:20 --> URI Class Initialized
INFO - 2021-01-21 03:18:21 --> Router Class Initialized
INFO - 2021-01-21 03:18:21 --> Output Class Initialized
INFO - 2021-01-21 03:18:21 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:21 --> Input Class Initialized
INFO - 2021-01-21 03:18:21 --> Language Class Initialized
INFO - 2021-01-21 03:18:21 --> Language Class Initialized
INFO - 2021-01-21 03:18:21 --> Config Class Initialized
INFO - 2021-01-21 03:18:21 --> Loader Class Initialized
INFO - 2021-01-21 03:18:21 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:21 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:21 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:21 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:21 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:21 --> Controller Class Initialized
ERROR - 2021-01-21 03:18:21 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 1028
ERROR - 2021-01-21 03:18:21 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 1028
ERROR - 2021-01-21 03:18:21 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 1030
ERROR - 2021-01-21 03:18:21 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 1031
ERROR - 2021-01-21 03:18:21 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 1032
ERROR - 2021-01-21 03:18:21 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 1032
ERROR - 2021-01-21 03:18:21 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 1032
DEBUG - 2021-01-21 03:18:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-21 03:18:21 --> Final output sent to browser
DEBUG - 2021-01-21 03:18:21 --> Total execution time: 0.6016
INFO - 2021-01-21 03:18:24 --> Config Class Initialized
INFO - 2021-01-21 03:18:24 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:24 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:24 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:24 --> URI Class Initialized
INFO - 2021-01-21 03:18:24 --> Router Class Initialized
INFO - 2021-01-21 03:18:24 --> Output Class Initialized
INFO - 2021-01-21 03:18:24 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:24 --> Input Class Initialized
INFO - 2021-01-21 03:18:24 --> Language Class Initialized
INFO - 2021-01-21 03:18:24 --> Language Class Initialized
INFO - 2021-01-21 03:18:24 --> Config Class Initialized
INFO - 2021-01-21 03:18:24 --> Loader Class Initialized
INFO - 2021-01-21 03:18:24 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:24 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:24 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:24 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:24 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:25 --> Controller Class Initialized
ERROR - 2021-01-21 03:18:25 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2904
ERROR - 2021-01-21 03:18:25 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2904
ERROR - 2021-01-21 03:18:25 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2906
ERROR - 2021-01-21 03:18:25 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2907
ERROR - 2021-01-21 03:18:25 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
ERROR - 2021-01-21 03:18:25 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
ERROR - 2021-01-21 03:18:25 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
DEBUG - 2021-01-21 03:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 03:18:25 --> Final output sent to browser
DEBUG - 2021-01-21 03:18:25 --> Total execution time: 0.5233
INFO - 2021-01-21 03:18:34 --> Config Class Initialized
INFO - 2021-01-21 03:18:34 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:34 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:34 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:34 --> URI Class Initialized
INFO - 2021-01-21 03:18:34 --> Router Class Initialized
INFO - 2021-01-21 03:18:34 --> Output Class Initialized
INFO - 2021-01-21 03:18:34 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:34 --> Input Class Initialized
INFO - 2021-01-21 03:18:34 --> Language Class Initialized
INFO - 2021-01-21 03:18:34 --> Language Class Initialized
INFO - 2021-01-21 03:18:34 --> Config Class Initialized
INFO - 2021-01-21 03:18:34 --> Loader Class Initialized
INFO - 2021-01-21 03:18:34 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:34 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:34 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:34 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:34 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:34 --> Controller Class Initialized
INFO - 2021-01-21 03:18:34 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:18:34 --> Config Class Initialized
INFO - 2021-01-21 03:18:34 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:34 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:34 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:34 --> URI Class Initialized
INFO - 2021-01-21 03:18:34 --> Router Class Initialized
INFO - 2021-01-21 03:18:34 --> Output Class Initialized
INFO - 2021-01-21 03:18:34 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:34 --> Input Class Initialized
INFO - 2021-01-21 03:18:34 --> Language Class Initialized
INFO - 2021-01-21 03:18:34 --> Language Class Initialized
INFO - 2021-01-21 03:18:34 --> Config Class Initialized
INFO - 2021-01-21 03:18:34 --> Loader Class Initialized
INFO - 2021-01-21 03:18:34 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:34 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:34 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:34 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:35 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:35 --> Controller Class Initialized
DEBUG - 2021-01-21 03:18:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 03:18:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:18:35 --> Final output sent to browser
DEBUG - 2021-01-21 03:18:35 --> Total execution time: 0.4531
INFO - 2021-01-21 03:18:39 --> Config Class Initialized
INFO - 2021-01-21 03:18:39 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:39 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:39 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:39 --> URI Class Initialized
INFO - 2021-01-21 03:18:39 --> Router Class Initialized
INFO - 2021-01-21 03:18:39 --> Output Class Initialized
INFO - 2021-01-21 03:18:39 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:39 --> Input Class Initialized
INFO - 2021-01-21 03:18:39 --> Language Class Initialized
INFO - 2021-01-21 03:18:39 --> Language Class Initialized
INFO - 2021-01-21 03:18:39 --> Config Class Initialized
INFO - 2021-01-21 03:18:39 --> Loader Class Initialized
INFO - 2021-01-21 03:18:39 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:39 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:39 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:39 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:39 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:39 --> Controller Class Initialized
INFO - 2021-01-21 03:18:39 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:18:39 --> Final output sent to browser
DEBUG - 2021-01-21 03:18:39 --> Total execution time: 0.4421
INFO - 2021-01-21 03:18:39 --> Config Class Initialized
INFO - 2021-01-21 03:18:39 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:39 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:39 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:39 --> URI Class Initialized
INFO - 2021-01-21 03:18:39 --> Router Class Initialized
INFO - 2021-01-21 03:18:39 --> Output Class Initialized
INFO - 2021-01-21 03:18:39 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:40 --> Input Class Initialized
INFO - 2021-01-21 03:18:40 --> Language Class Initialized
INFO - 2021-01-21 03:18:40 --> Language Class Initialized
INFO - 2021-01-21 03:18:40 --> Config Class Initialized
INFO - 2021-01-21 03:18:40 --> Loader Class Initialized
INFO - 2021-01-21 03:18:40 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:40 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:40 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:40 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:40 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:40 --> Controller Class Initialized
DEBUG - 2021-01-21 03:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 03:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:18:40 --> Final output sent to browser
DEBUG - 2021-01-21 03:18:40 --> Total execution time: 0.4962
INFO - 2021-01-21 03:18:42 --> Config Class Initialized
INFO - 2021-01-21 03:18:42 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:42 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:42 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:42 --> URI Class Initialized
INFO - 2021-01-21 03:18:42 --> Router Class Initialized
INFO - 2021-01-21 03:18:42 --> Output Class Initialized
INFO - 2021-01-21 03:18:42 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:42 --> Input Class Initialized
INFO - 2021-01-21 03:18:42 --> Language Class Initialized
INFO - 2021-01-21 03:18:42 --> Language Class Initialized
INFO - 2021-01-21 03:18:42 --> Config Class Initialized
INFO - 2021-01-21 03:18:42 --> Loader Class Initialized
INFO - 2021-01-21 03:18:42 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:42 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:42 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:42 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:42 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:42 --> Controller Class Initialized
DEBUG - 2021-01-21 03:18:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 03:18:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:18:42 --> Final output sent to browser
DEBUG - 2021-01-21 03:18:42 --> Total execution time: 0.4591
INFO - 2021-01-21 03:18:43 --> Config Class Initialized
INFO - 2021-01-21 03:18:43 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:43 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:43 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:43 --> URI Class Initialized
INFO - 2021-01-21 03:18:43 --> Router Class Initialized
INFO - 2021-01-21 03:18:43 --> Output Class Initialized
INFO - 2021-01-21 03:18:43 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:44 --> Input Class Initialized
INFO - 2021-01-21 03:18:44 --> Language Class Initialized
INFO - 2021-01-21 03:18:44 --> Language Class Initialized
INFO - 2021-01-21 03:18:44 --> Config Class Initialized
INFO - 2021-01-21 03:18:44 --> Loader Class Initialized
INFO - 2021-01-21 03:18:44 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:44 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:44 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:44 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:44 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:44 --> Controller Class Initialized
ERROR - 2021-01-21 03:18:44 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2904
ERROR - 2021-01-21 03:18:44 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2904
ERROR - 2021-01-21 03:18:44 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2906
ERROR - 2021-01-21 03:18:44 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2907
ERROR - 2021-01-21 03:18:44 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
ERROR - 2021-01-21 03:18:44 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
ERROR - 2021-01-21 03:18:44 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
DEBUG - 2021-01-21 03:18:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 03:18:44 --> Final output sent to browser
DEBUG - 2021-01-21 03:18:44 --> Total execution time: 0.5015
INFO - 2021-01-21 03:18:57 --> Config Class Initialized
INFO - 2021-01-21 03:18:57 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:57 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:57 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:57 --> URI Class Initialized
INFO - 2021-01-21 03:18:57 --> Router Class Initialized
INFO - 2021-01-21 03:18:57 --> Output Class Initialized
INFO - 2021-01-21 03:18:57 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:57 --> Input Class Initialized
INFO - 2021-01-21 03:18:57 --> Language Class Initialized
INFO - 2021-01-21 03:18:57 --> Language Class Initialized
INFO - 2021-01-21 03:18:57 --> Config Class Initialized
INFO - 2021-01-21 03:18:57 --> Loader Class Initialized
INFO - 2021-01-21 03:18:57 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:57 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:57 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:57 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:57 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:57 --> Controller Class Initialized
INFO - 2021-01-21 03:18:57 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:18:57 --> Config Class Initialized
INFO - 2021-01-21 03:18:57 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:18:57 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:18:57 --> Utf8 Class Initialized
INFO - 2021-01-21 03:18:57 --> URI Class Initialized
INFO - 2021-01-21 03:18:57 --> Router Class Initialized
INFO - 2021-01-21 03:18:57 --> Output Class Initialized
INFO - 2021-01-21 03:18:57 --> Security Class Initialized
DEBUG - 2021-01-21 03:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:18:57 --> Input Class Initialized
INFO - 2021-01-21 03:18:58 --> Language Class Initialized
INFO - 2021-01-21 03:18:58 --> Language Class Initialized
INFO - 2021-01-21 03:18:58 --> Config Class Initialized
INFO - 2021-01-21 03:18:58 --> Loader Class Initialized
INFO - 2021-01-21 03:18:58 --> Helper loaded: url_helper
INFO - 2021-01-21 03:18:58 --> Helper loaded: file_helper
INFO - 2021-01-21 03:18:58 --> Helper loaded: form_helper
INFO - 2021-01-21 03:18:58 --> Helper loaded: my_helper
INFO - 2021-01-21 03:18:58 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:18:58 --> Controller Class Initialized
DEBUG - 2021-01-21 03:18:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 03:18:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:18:58 --> Final output sent to browser
DEBUG - 2021-01-21 03:18:58 --> Total execution time: 0.4981
INFO - 2021-01-21 03:19:06 --> Config Class Initialized
INFO - 2021-01-21 03:19:06 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:06 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:06 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:06 --> URI Class Initialized
INFO - 2021-01-21 03:19:06 --> Router Class Initialized
INFO - 2021-01-21 03:19:06 --> Output Class Initialized
INFO - 2021-01-21 03:19:06 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:06 --> Input Class Initialized
INFO - 2021-01-21 03:19:06 --> Language Class Initialized
INFO - 2021-01-21 03:19:06 --> Language Class Initialized
INFO - 2021-01-21 03:19:06 --> Config Class Initialized
INFO - 2021-01-21 03:19:06 --> Loader Class Initialized
INFO - 2021-01-21 03:19:06 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:06 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:06 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:06 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:06 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:06 --> Controller Class Initialized
INFO - 2021-01-21 03:19:06 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:19:06 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:06 --> Total execution time: 0.4627
INFO - 2021-01-21 03:19:06 --> Config Class Initialized
INFO - 2021-01-21 03:19:06 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:06 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:06 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:07 --> URI Class Initialized
INFO - 2021-01-21 03:19:07 --> Router Class Initialized
INFO - 2021-01-21 03:19:07 --> Output Class Initialized
INFO - 2021-01-21 03:19:07 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:07 --> Input Class Initialized
INFO - 2021-01-21 03:19:07 --> Language Class Initialized
INFO - 2021-01-21 03:19:07 --> Language Class Initialized
INFO - 2021-01-21 03:19:07 --> Config Class Initialized
INFO - 2021-01-21 03:19:07 --> Loader Class Initialized
INFO - 2021-01-21 03:19:07 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:07 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:07 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:07 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:07 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:07 --> Controller Class Initialized
DEBUG - 2021-01-21 03:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 03:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:19:07 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:07 --> Total execution time: 0.5555
INFO - 2021-01-21 03:19:09 --> Config Class Initialized
INFO - 2021-01-21 03:19:09 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:09 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:09 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:09 --> URI Class Initialized
INFO - 2021-01-21 03:19:09 --> Router Class Initialized
INFO - 2021-01-21 03:19:09 --> Output Class Initialized
INFO - 2021-01-21 03:19:09 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:09 --> Input Class Initialized
INFO - 2021-01-21 03:19:09 --> Language Class Initialized
INFO - 2021-01-21 03:19:09 --> Language Class Initialized
INFO - 2021-01-21 03:19:09 --> Config Class Initialized
INFO - 2021-01-21 03:19:09 --> Loader Class Initialized
INFO - 2021-01-21 03:19:09 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:09 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:09 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:09 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:09 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:09 --> Controller Class Initialized
DEBUG - 2021-01-21 03:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 03:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:19:09 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:09 --> Total execution time: 0.3684
INFO - 2021-01-21 03:19:12 --> Config Class Initialized
INFO - 2021-01-21 03:19:12 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:12 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:12 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:12 --> URI Class Initialized
INFO - 2021-01-21 03:19:12 --> Router Class Initialized
INFO - 2021-01-21 03:19:12 --> Output Class Initialized
INFO - 2021-01-21 03:19:12 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:12 --> Input Class Initialized
INFO - 2021-01-21 03:19:12 --> Language Class Initialized
INFO - 2021-01-21 03:19:12 --> Language Class Initialized
INFO - 2021-01-21 03:19:12 --> Config Class Initialized
INFO - 2021-01-21 03:19:12 --> Loader Class Initialized
INFO - 2021-01-21 03:19:12 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:12 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:12 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:12 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:12 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:12 --> Controller Class Initialized
ERROR - 2021-01-21 03:19:12 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4103
ERROR - 2021-01-21 03:19:12 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4103
ERROR - 2021-01-21 03:19:12 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4105
ERROR - 2021-01-21 03:19:12 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4106
ERROR - 2021-01-21 03:19:12 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4107
ERROR - 2021-01-21 03:19:12 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4107
ERROR - 2021-01-21 03:19:12 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4107
DEBUG - 2021-01-21 03:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-21 03:19:12 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:12 --> Total execution time: 0.5813
INFO - 2021-01-21 03:19:21 --> Config Class Initialized
INFO - 2021-01-21 03:19:21 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:21 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:21 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:21 --> URI Class Initialized
INFO - 2021-01-21 03:19:21 --> Router Class Initialized
INFO - 2021-01-21 03:19:21 --> Output Class Initialized
INFO - 2021-01-21 03:19:21 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:21 --> Input Class Initialized
INFO - 2021-01-21 03:19:21 --> Language Class Initialized
INFO - 2021-01-21 03:19:21 --> Language Class Initialized
INFO - 2021-01-21 03:19:21 --> Config Class Initialized
INFO - 2021-01-21 03:19:21 --> Loader Class Initialized
INFO - 2021-01-21 03:19:21 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:21 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:21 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:21 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:21 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:21 --> Controller Class Initialized
INFO - 2021-01-21 03:19:21 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:19:21 --> Config Class Initialized
INFO - 2021-01-21 03:19:21 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:21 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:21 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:21 --> URI Class Initialized
INFO - 2021-01-21 03:19:21 --> Router Class Initialized
INFO - 2021-01-21 03:19:21 --> Output Class Initialized
INFO - 2021-01-21 03:19:21 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:21 --> Input Class Initialized
INFO - 2021-01-21 03:19:21 --> Language Class Initialized
INFO - 2021-01-21 03:19:21 --> Language Class Initialized
INFO - 2021-01-21 03:19:21 --> Config Class Initialized
INFO - 2021-01-21 03:19:21 --> Loader Class Initialized
INFO - 2021-01-21 03:19:21 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:21 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:21 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:21 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:21 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:21 --> Controller Class Initialized
DEBUG - 2021-01-21 03:19:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 03:19:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:19:21 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:21 --> Total execution time: 0.4425
INFO - 2021-01-21 03:19:25 --> Config Class Initialized
INFO - 2021-01-21 03:19:25 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:25 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:25 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:25 --> URI Class Initialized
INFO - 2021-01-21 03:19:25 --> Router Class Initialized
INFO - 2021-01-21 03:19:25 --> Output Class Initialized
INFO - 2021-01-21 03:19:25 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:25 --> Input Class Initialized
INFO - 2021-01-21 03:19:25 --> Language Class Initialized
INFO - 2021-01-21 03:19:25 --> Language Class Initialized
INFO - 2021-01-21 03:19:25 --> Config Class Initialized
INFO - 2021-01-21 03:19:25 --> Loader Class Initialized
INFO - 2021-01-21 03:19:25 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:25 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:25 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:25 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:25 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:25 --> Controller Class Initialized
INFO - 2021-01-21 03:19:25 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:25 --> Total execution time: 0.4476
INFO - 2021-01-21 03:19:29 --> Config Class Initialized
INFO - 2021-01-21 03:19:29 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:29 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:29 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:29 --> URI Class Initialized
INFO - 2021-01-21 03:19:29 --> Router Class Initialized
INFO - 2021-01-21 03:19:29 --> Output Class Initialized
INFO - 2021-01-21 03:19:29 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:29 --> Input Class Initialized
INFO - 2021-01-21 03:19:29 --> Language Class Initialized
INFO - 2021-01-21 03:19:29 --> Language Class Initialized
INFO - 2021-01-21 03:19:29 --> Config Class Initialized
INFO - 2021-01-21 03:19:29 --> Loader Class Initialized
INFO - 2021-01-21 03:19:29 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:29 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:29 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:29 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:29 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:29 --> Controller Class Initialized
INFO - 2021-01-21 03:19:29 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:19:29 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:29 --> Total execution time: 0.4957
INFO - 2021-01-21 03:19:30 --> Config Class Initialized
INFO - 2021-01-21 03:19:30 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:30 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:30 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:31 --> URI Class Initialized
INFO - 2021-01-21 03:19:31 --> Router Class Initialized
INFO - 2021-01-21 03:19:31 --> Output Class Initialized
INFO - 2021-01-21 03:19:31 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:31 --> Input Class Initialized
INFO - 2021-01-21 03:19:31 --> Language Class Initialized
INFO - 2021-01-21 03:19:31 --> Language Class Initialized
INFO - 2021-01-21 03:19:31 --> Config Class Initialized
INFO - 2021-01-21 03:19:31 --> Loader Class Initialized
INFO - 2021-01-21 03:19:31 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:31 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:31 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:31 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:31 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:31 --> Controller Class Initialized
DEBUG - 2021-01-21 03:19:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 03:19:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:19:31 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:31 --> Total execution time: 0.5722
INFO - 2021-01-21 03:19:33 --> Config Class Initialized
INFO - 2021-01-21 03:19:33 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:33 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:33 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:33 --> URI Class Initialized
INFO - 2021-01-21 03:19:33 --> Router Class Initialized
INFO - 2021-01-21 03:19:33 --> Output Class Initialized
INFO - 2021-01-21 03:19:33 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:33 --> Input Class Initialized
INFO - 2021-01-21 03:19:33 --> Language Class Initialized
INFO - 2021-01-21 03:19:33 --> Language Class Initialized
INFO - 2021-01-21 03:19:33 --> Config Class Initialized
INFO - 2021-01-21 03:19:33 --> Loader Class Initialized
INFO - 2021-01-21 03:19:33 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:33 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:33 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:33 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:33 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:33 --> Controller Class Initialized
DEBUG - 2021-01-21 03:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-01-21 03:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:19:33 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:33 --> Total execution time: 0.4547
INFO - 2021-01-21 03:19:33 --> Config Class Initialized
INFO - 2021-01-21 03:19:33 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:33 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:33 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:33 --> URI Class Initialized
INFO - 2021-01-21 03:19:33 --> Router Class Initialized
INFO - 2021-01-21 03:19:33 --> Output Class Initialized
INFO - 2021-01-21 03:19:33 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:33 --> Input Class Initialized
INFO - 2021-01-21 03:19:33 --> Language Class Initialized
INFO - 2021-01-21 03:19:33 --> Language Class Initialized
INFO - 2021-01-21 03:19:33 --> Config Class Initialized
INFO - 2021-01-21 03:19:33 --> Loader Class Initialized
INFO - 2021-01-21 03:19:33 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:33 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:34 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:34 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:34 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:34 --> Controller Class Initialized
INFO - 2021-01-21 03:19:35 --> Config Class Initialized
INFO - 2021-01-21 03:19:35 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:19:35 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:19:35 --> Utf8 Class Initialized
INFO - 2021-01-21 03:19:36 --> URI Class Initialized
INFO - 2021-01-21 03:19:36 --> Router Class Initialized
INFO - 2021-01-21 03:19:36 --> Output Class Initialized
INFO - 2021-01-21 03:19:36 --> Security Class Initialized
DEBUG - 2021-01-21 03:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:19:36 --> Input Class Initialized
INFO - 2021-01-21 03:19:36 --> Language Class Initialized
INFO - 2021-01-21 03:19:36 --> Language Class Initialized
INFO - 2021-01-21 03:19:36 --> Config Class Initialized
INFO - 2021-01-21 03:19:36 --> Loader Class Initialized
INFO - 2021-01-21 03:19:36 --> Helper loaded: url_helper
INFO - 2021-01-21 03:19:36 --> Helper loaded: file_helper
INFO - 2021-01-21 03:19:36 --> Helper loaded: form_helper
INFO - 2021-01-21 03:19:36 --> Helper loaded: my_helper
INFO - 2021-01-21 03:19:36 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:19:36 --> Controller Class Initialized
INFO - 2021-01-21 03:19:36 --> Final output sent to browser
DEBUG - 2021-01-21 03:19:36 --> Total execution time: 0.4479
INFO - 2021-01-21 03:20:07 --> Config Class Initialized
INFO - 2021-01-21 03:20:07 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:07 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:07 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:07 --> URI Class Initialized
INFO - 2021-01-21 03:20:07 --> Router Class Initialized
INFO - 2021-01-21 03:20:07 --> Output Class Initialized
INFO - 2021-01-21 03:20:07 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:07 --> Input Class Initialized
INFO - 2021-01-21 03:20:07 --> Language Class Initialized
INFO - 2021-01-21 03:20:07 --> Language Class Initialized
INFO - 2021-01-21 03:20:07 --> Config Class Initialized
INFO - 2021-01-21 03:20:07 --> Loader Class Initialized
INFO - 2021-01-21 03:20:07 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:07 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:07 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:07 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:07 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:07 --> Controller Class Initialized
INFO - 2021-01-21 03:20:07 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:07 --> Total execution time: 0.4466
INFO - 2021-01-21 03:20:07 --> Config Class Initialized
INFO - 2021-01-21 03:20:07 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:07 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:07 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:07 --> URI Class Initialized
INFO - 2021-01-21 03:20:07 --> Router Class Initialized
INFO - 2021-01-21 03:20:07 --> Output Class Initialized
INFO - 2021-01-21 03:20:07 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:07 --> Input Class Initialized
INFO - 2021-01-21 03:20:07 --> Language Class Initialized
INFO - 2021-01-21 03:20:07 --> Language Class Initialized
INFO - 2021-01-21 03:20:07 --> Config Class Initialized
INFO - 2021-01-21 03:20:07 --> Loader Class Initialized
INFO - 2021-01-21 03:20:07 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:07 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:07 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:07 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:07 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:08 --> Controller Class Initialized
INFO - 2021-01-21 03:20:12 --> Config Class Initialized
INFO - 2021-01-21 03:20:12 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:12 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:12 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:12 --> URI Class Initialized
INFO - 2021-01-21 03:20:12 --> Router Class Initialized
INFO - 2021-01-21 03:20:12 --> Output Class Initialized
INFO - 2021-01-21 03:20:12 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:12 --> Input Class Initialized
INFO - 2021-01-21 03:20:12 --> Language Class Initialized
INFO - 2021-01-21 03:20:12 --> Language Class Initialized
INFO - 2021-01-21 03:20:12 --> Config Class Initialized
INFO - 2021-01-21 03:20:12 --> Loader Class Initialized
INFO - 2021-01-21 03:20:12 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:12 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:12 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:12 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:12 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:12 --> Controller Class Initialized
INFO - 2021-01-21 03:20:12 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:12 --> Total execution time: 0.3642
INFO - 2021-01-21 03:20:12 --> Config Class Initialized
INFO - 2021-01-21 03:20:12 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:12 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:12 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:13 --> URI Class Initialized
INFO - 2021-01-21 03:20:13 --> Router Class Initialized
INFO - 2021-01-21 03:20:13 --> Output Class Initialized
INFO - 2021-01-21 03:20:13 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:13 --> Input Class Initialized
INFO - 2021-01-21 03:20:13 --> Language Class Initialized
INFO - 2021-01-21 03:20:13 --> Language Class Initialized
INFO - 2021-01-21 03:20:13 --> Config Class Initialized
INFO - 2021-01-21 03:20:13 --> Loader Class Initialized
INFO - 2021-01-21 03:20:13 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:13 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:13 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:13 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:13 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:13 --> Controller Class Initialized
INFO - 2021-01-21 03:20:17 --> Config Class Initialized
INFO - 2021-01-21 03:20:17 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:17 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:17 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:18 --> URI Class Initialized
INFO - 2021-01-21 03:20:18 --> Router Class Initialized
INFO - 2021-01-21 03:20:18 --> Output Class Initialized
INFO - 2021-01-21 03:20:18 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:18 --> Input Class Initialized
INFO - 2021-01-21 03:20:18 --> Language Class Initialized
INFO - 2021-01-21 03:20:18 --> Language Class Initialized
INFO - 2021-01-21 03:20:18 --> Config Class Initialized
INFO - 2021-01-21 03:20:18 --> Loader Class Initialized
INFO - 2021-01-21 03:20:18 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:18 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:18 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:18 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:18 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:18 --> Controller Class Initialized
INFO - 2021-01-21 03:20:18 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:20:18 --> Config Class Initialized
INFO - 2021-01-21 03:20:18 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:18 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:18 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:18 --> URI Class Initialized
INFO - 2021-01-21 03:20:18 --> Router Class Initialized
INFO - 2021-01-21 03:20:18 --> Output Class Initialized
INFO - 2021-01-21 03:20:18 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:18 --> Input Class Initialized
INFO - 2021-01-21 03:20:18 --> Language Class Initialized
INFO - 2021-01-21 03:20:18 --> Language Class Initialized
INFO - 2021-01-21 03:20:18 --> Config Class Initialized
INFO - 2021-01-21 03:20:18 --> Loader Class Initialized
INFO - 2021-01-21 03:20:18 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:18 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:18 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:18 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:18 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:18 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 03:20:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:18 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:18 --> Total execution time: 0.3886
INFO - 2021-01-21 03:20:24 --> Config Class Initialized
INFO - 2021-01-21 03:20:24 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:24 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:24 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:24 --> URI Class Initialized
INFO - 2021-01-21 03:20:24 --> Router Class Initialized
INFO - 2021-01-21 03:20:24 --> Output Class Initialized
INFO - 2021-01-21 03:20:24 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:24 --> Input Class Initialized
INFO - 2021-01-21 03:20:24 --> Language Class Initialized
INFO - 2021-01-21 03:20:24 --> Language Class Initialized
INFO - 2021-01-21 03:20:24 --> Config Class Initialized
INFO - 2021-01-21 03:20:24 --> Loader Class Initialized
INFO - 2021-01-21 03:20:24 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:24 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:24 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:24 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:24 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:24 --> Controller Class Initialized
INFO - 2021-01-21 03:20:24 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:24 --> Total execution time: 0.4495
INFO - 2021-01-21 03:20:27 --> Config Class Initialized
INFO - 2021-01-21 03:20:27 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:27 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:27 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:27 --> URI Class Initialized
INFO - 2021-01-21 03:20:27 --> Router Class Initialized
INFO - 2021-01-21 03:20:27 --> Output Class Initialized
INFO - 2021-01-21 03:20:27 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:27 --> Input Class Initialized
INFO - 2021-01-21 03:20:27 --> Language Class Initialized
INFO - 2021-01-21 03:20:27 --> Language Class Initialized
INFO - 2021-01-21 03:20:28 --> Config Class Initialized
INFO - 2021-01-21 03:20:28 --> Loader Class Initialized
INFO - 2021-01-21 03:20:28 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:28 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:28 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:28 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:28 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:28 --> Controller Class Initialized
INFO - 2021-01-21 03:20:28 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:20:28 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:28 --> Total execution time: 0.4969
INFO - 2021-01-21 03:20:28 --> Config Class Initialized
INFO - 2021-01-21 03:20:28 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:28 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:28 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:28 --> URI Class Initialized
INFO - 2021-01-21 03:20:28 --> Router Class Initialized
INFO - 2021-01-21 03:20:28 --> Output Class Initialized
INFO - 2021-01-21 03:20:28 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:28 --> Input Class Initialized
INFO - 2021-01-21 03:20:28 --> Language Class Initialized
INFO - 2021-01-21 03:20:28 --> Language Class Initialized
INFO - 2021-01-21 03:20:28 --> Config Class Initialized
INFO - 2021-01-21 03:20:28 --> Loader Class Initialized
INFO - 2021-01-21 03:20:28 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:28 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:28 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:28 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:28 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:28 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 03:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:28 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:28 --> Total execution time: 0.4896
INFO - 2021-01-21 03:20:30 --> Config Class Initialized
INFO - 2021-01-21 03:20:30 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:30 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:30 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:30 --> URI Class Initialized
INFO - 2021-01-21 03:20:30 --> Router Class Initialized
INFO - 2021-01-21 03:20:30 --> Output Class Initialized
INFO - 2021-01-21 03:20:30 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:30 --> Input Class Initialized
INFO - 2021-01-21 03:20:30 --> Language Class Initialized
INFO - 2021-01-21 03:20:30 --> Language Class Initialized
INFO - 2021-01-21 03:20:30 --> Config Class Initialized
INFO - 2021-01-21 03:20:30 --> Loader Class Initialized
INFO - 2021-01-21 03:20:30 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:30 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:30 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:30 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:30 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:30 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-01-21 03:20:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:30 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:30 --> Total execution time: 0.5840
INFO - 2021-01-21 03:20:30 --> Config Class Initialized
INFO - 2021-01-21 03:20:30 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:30 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:30 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:30 --> URI Class Initialized
INFO - 2021-01-21 03:20:30 --> Router Class Initialized
INFO - 2021-01-21 03:20:30 --> Output Class Initialized
INFO - 2021-01-21 03:20:30 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:30 --> Input Class Initialized
INFO - 2021-01-21 03:20:30 --> Language Class Initialized
INFO - 2021-01-21 03:20:30 --> Language Class Initialized
INFO - 2021-01-21 03:20:30 --> Config Class Initialized
INFO - 2021-01-21 03:20:31 --> Loader Class Initialized
INFO - 2021-01-21 03:20:31 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:31 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:31 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:31 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:31 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:31 --> Controller Class Initialized
INFO - 2021-01-21 03:20:31 --> Config Class Initialized
INFO - 2021-01-21 03:20:31 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:31 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:31 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:31 --> URI Class Initialized
INFO - 2021-01-21 03:20:31 --> Router Class Initialized
INFO - 2021-01-21 03:20:31 --> Output Class Initialized
INFO - 2021-01-21 03:20:31 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:31 --> Input Class Initialized
INFO - 2021-01-21 03:20:31 --> Language Class Initialized
INFO - 2021-01-21 03:20:32 --> Language Class Initialized
INFO - 2021-01-21 03:20:32 --> Config Class Initialized
INFO - 2021-01-21 03:20:32 --> Loader Class Initialized
INFO - 2021-01-21 03:20:32 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:32 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:32 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:32 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:32 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:32 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-01-21 03:20:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:32 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:32 --> Total execution time: 0.4082
INFO - 2021-01-21 03:20:36 --> Config Class Initialized
INFO - 2021-01-21 03:20:36 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:36 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:36 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:36 --> URI Class Initialized
INFO - 2021-01-21 03:20:36 --> Router Class Initialized
INFO - 2021-01-21 03:20:36 --> Output Class Initialized
INFO - 2021-01-21 03:20:36 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:36 --> Input Class Initialized
INFO - 2021-01-21 03:20:36 --> Language Class Initialized
INFO - 2021-01-21 03:20:36 --> Language Class Initialized
INFO - 2021-01-21 03:20:36 --> Config Class Initialized
INFO - 2021-01-21 03:20:36 --> Loader Class Initialized
INFO - 2021-01-21 03:20:36 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:36 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:36 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:36 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:36 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:36 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-21 03:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:36 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:36 --> Total execution time: 0.4798
INFO - 2021-01-21 03:20:36 --> Config Class Initialized
INFO - 2021-01-21 03:20:36 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:37 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:37 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:37 --> URI Class Initialized
INFO - 2021-01-21 03:20:37 --> Router Class Initialized
INFO - 2021-01-21 03:20:37 --> Output Class Initialized
INFO - 2021-01-21 03:20:37 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:37 --> Input Class Initialized
INFO - 2021-01-21 03:20:37 --> Language Class Initialized
INFO - 2021-01-21 03:20:37 --> Language Class Initialized
INFO - 2021-01-21 03:20:37 --> Config Class Initialized
INFO - 2021-01-21 03:20:37 --> Loader Class Initialized
INFO - 2021-01-21 03:20:37 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:37 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:37 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:37 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:37 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:37 --> Controller Class Initialized
INFO - 2021-01-21 03:20:41 --> Config Class Initialized
INFO - 2021-01-21 03:20:41 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:41 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:41 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:41 --> URI Class Initialized
INFO - 2021-01-21 03:20:41 --> Router Class Initialized
INFO - 2021-01-21 03:20:41 --> Output Class Initialized
INFO - 2021-01-21 03:20:41 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:41 --> Input Class Initialized
INFO - 2021-01-21 03:20:41 --> Language Class Initialized
INFO - 2021-01-21 03:20:41 --> Language Class Initialized
INFO - 2021-01-21 03:20:41 --> Config Class Initialized
INFO - 2021-01-21 03:20:41 --> Loader Class Initialized
INFO - 2021-01-21 03:20:41 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:41 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:41 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:41 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:41 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:41 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-21 03:20:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:41 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:41 --> Total execution time: 0.3711
INFO - 2021-01-21 03:20:41 --> Config Class Initialized
INFO - 2021-01-21 03:20:41 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:41 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:41 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:41 --> URI Class Initialized
INFO - 2021-01-21 03:20:41 --> Router Class Initialized
INFO - 2021-01-21 03:20:41 --> Output Class Initialized
INFO - 2021-01-21 03:20:41 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:41 --> Input Class Initialized
INFO - 2021-01-21 03:20:41 --> Language Class Initialized
INFO - 2021-01-21 03:20:41 --> Language Class Initialized
INFO - 2021-01-21 03:20:41 --> Config Class Initialized
INFO - 2021-01-21 03:20:41 --> Loader Class Initialized
INFO - 2021-01-21 03:20:41 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:41 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:42 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:42 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:42 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:42 --> Controller Class Initialized
INFO - 2021-01-21 03:20:42 --> Config Class Initialized
INFO - 2021-01-21 03:20:42 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:42 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:42 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:42 --> URI Class Initialized
INFO - 2021-01-21 03:20:42 --> Router Class Initialized
INFO - 2021-01-21 03:20:42 --> Output Class Initialized
INFO - 2021-01-21 03:20:42 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:42 --> Input Class Initialized
INFO - 2021-01-21 03:20:42 --> Language Class Initialized
INFO - 2021-01-21 03:20:42 --> Language Class Initialized
INFO - 2021-01-21 03:20:42 --> Config Class Initialized
INFO - 2021-01-21 03:20:42 --> Loader Class Initialized
INFO - 2021-01-21 03:20:43 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:43 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:43 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:43 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:43 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:43 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-21 03:20:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:43 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:43 --> Total execution time: 0.3634
INFO - 2021-01-21 03:20:43 --> Config Class Initialized
INFO - 2021-01-21 03:20:43 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:43 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:43 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:43 --> URI Class Initialized
INFO - 2021-01-21 03:20:43 --> Router Class Initialized
INFO - 2021-01-21 03:20:43 --> Output Class Initialized
INFO - 2021-01-21 03:20:43 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:43 --> Input Class Initialized
INFO - 2021-01-21 03:20:43 --> Language Class Initialized
INFO - 2021-01-21 03:20:43 --> Language Class Initialized
INFO - 2021-01-21 03:20:43 --> Config Class Initialized
INFO - 2021-01-21 03:20:43 --> Loader Class Initialized
INFO - 2021-01-21 03:20:43 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:43 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:43 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:43 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:43 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:43 --> Controller Class Initialized
INFO - 2021-01-21 03:20:44 --> Config Class Initialized
INFO - 2021-01-21 03:20:44 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:44 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:44 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:44 --> URI Class Initialized
INFO - 2021-01-21 03:20:44 --> Router Class Initialized
INFO - 2021-01-21 03:20:44 --> Output Class Initialized
INFO - 2021-01-21 03:20:44 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:44 --> Input Class Initialized
INFO - 2021-01-21 03:20:44 --> Language Class Initialized
INFO - 2021-01-21 03:20:44 --> Language Class Initialized
INFO - 2021-01-21 03:20:44 --> Config Class Initialized
INFO - 2021-01-21 03:20:44 --> Loader Class Initialized
INFO - 2021-01-21 03:20:44 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:44 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:44 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:44 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:44 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:44 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-01-21 03:20:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:45 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:45 --> Total execution time: 0.4016
INFO - 2021-01-21 03:20:46 --> Config Class Initialized
INFO - 2021-01-21 03:20:46 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:46 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:46 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:46 --> URI Class Initialized
INFO - 2021-01-21 03:20:46 --> Router Class Initialized
INFO - 2021-01-21 03:20:46 --> Output Class Initialized
INFO - 2021-01-21 03:20:46 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:46 --> Input Class Initialized
INFO - 2021-01-21 03:20:46 --> Language Class Initialized
INFO - 2021-01-21 03:20:46 --> Language Class Initialized
INFO - 2021-01-21 03:20:46 --> Config Class Initialized
INFO - 2021-01-21 03:20:46 --> Loader Class Initialized
INFO - 2021-01-21 03:20:46 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:46 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:46 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:46 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:46 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-01-21 03:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:46 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:46 --> Total execution time: 0.3616
INFO - 2021-01-21 03:20:46 --> Config Class Initialized
INFO - 2021-01-21 03:20:46 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:46 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:46 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:46 --> URI Class Initialized
INFO - 2021-01-21 03:20:46 --> Router Class Initialized
INFO - 2021-01-21 03:20:46 --> Output Class Initialized
INFO - 2021-01-21 03:20:46 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:46 --> Input Class Initialized
INFO - 2021-01-21 03:20:46 --> Language Class Initialized
INFO - 2021-01-21 03:20:46 --> Language Class Initialized
INFO - 2021-01-21 03:20:46 --> Config Class Initialized
INFO - 2021-01-21 03:20:46 --> Loader Class Initialized
INFO - 2021-01-21 03:20:46 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:46 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:46 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:47 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:47 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:47 --> Controller Class Initialized
INFO - 2021-01-21 03:20:48 --> Config Class Initialized
INFO - 2021-01-21 03:20:48 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:48 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:48 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:48 --> URI Class Initialized
INFO - 2021-01-21 03:20:48 --> Router Class Initialized
INFO - 2021-01-21 03:20:48 --> Output Class Initialized
INFO - 2021-01-21 03:20:48 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:48 --> Input Class Initialized
INFO - 2021-01-21 03:20:48 --> Language Class Initialized
INFO - 2021-01-21 03:20:48 --> Language Class Initialized
INFO - 2021-01-21 03:20:48 --> Config Class Initialized
INFO - 2021-01-21 03:20:48 --> Loader Class Initialized
INFO - 2021-01-21 03:20:48 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:48 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:48 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:48 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:48 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:48 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2021-01-21 03:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:48 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:48 --> Total execution time: 0.3856
INFO - 2021-01-21 03:20:48 --> Config Class Initialized
INFO - 2021-01-21 03:20:48 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:49 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:49 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:49 --> URI Class Initialized
INFO - 2021-01-21 03:20:49 --> Router Class Initialized
INFO - 2021-01-21 03:20:49 --> Output Class Initialized
INFO - 2021-01-21 03:20:49 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:49 --> Input Class Initialized
INFO - 2021-01-21 03:20:49 --> Language Class Initialized
INFO - 2021-01-21 03:20:49 --> Language Class Initialized
INFO - 2021-01-21 03:20:49 --> Config Class Initialized
INFO - 2021-01-21 03:20:49 --> Loader Class Initialized
INFO - 2021-01-21 03:20:49 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:49 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:49 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:49 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:49 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:49 --> Controller Class Initialized
INFO - 2021-01-21 03:20:50 --> Config Class Initialized
INFO - 2021-01-21 03:20:50 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:50 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:50 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:50 --> URI Class Initialized
INFO - 2021-01-21 03:20:50 --> Router Class Initialized
INFO - 2021-01-21 03:20:50 --> Output Class Initialized
INFO - 2021-01-21 03:20:50 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:50 --> Input Class Initialized
INFO - 2021-01-21 03:20:50 --> Language Class Initialized
INFO - 2021-01-21 03:20:50 --> Language Class Initialized
INFO - 2021-01-21 03:20:50 --> Config Class Initialized
INFO - 2021-01-21 03:20:50 --> Loader Class Initialized
INFO - 2021-01-21 03:20:50 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:50 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:50 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:50 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:50 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:50 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-01-21 03:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:50 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:50 --> Total execution time: 0.4057
INFO - 2021-01-21 03:20:50 --> Config Class Initialized
INFO - 2021-01-21 03:20:50 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:50 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:50 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:50 --> URI Class Initialized
INFO - 2021-01-21 03:20:50 --> Router Class Initialized
INFO - 2021-01-21 03:20:50 --> Output Class Initialized
INFO - 2021-01-21 03:20:50 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:50 --> Input Class Initialized
INFO - 2021-01-21 03:20:50 --> Language Class Initialized
INFO - 2021-01-21 03:20:50 --> Language Class Initialized
INFO - 2021-01-21 03:20:50 --> Config Class Initialized
INFO - 2021-01-21 03:20:50 --> Loader Class Initialized
INFO - 2021-01-21 03:20:50 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:50 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:50 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:50 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:50 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:50 --> Controller Class Initialized
INFO - 2021-01-21 03:20:53 --> Config Class Initialized
INFO - 2021-01-21 03:20:53 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:53 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:53 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:53 --> URI Class Initialized
INFO - 2021-01-21 03:20:53 --> Router Class Initialized
INFO - 2021-01-21 03:20:53 --> Output Class Initialized
INFO - 2021-01-21 03:20:53 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:53 --> Input Class Initialized
INFO - 2021-01-21 03:20:53 --> Language Class Initialized
INFO - 2021-01-21 03:20:53 --> Language Class Initialized
INFO - 2021-01-21 03:20:53 --> Config Class Initialized
INFO - 2021-01-21 03:20:53 --> Loader Class Initialized
INFO - 2021-01-21 03:20:53 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:53 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:53 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:53 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:53 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:53 --> Controller Class Initialized
DEBUG - 2021-01-21 03:20:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-01-21 03:20:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:20:53 --> Final output sent to browser
DEBUG - 2021-01-21 03:20:53 --> Total execution time: 0.4045
INFO - 2021-01-21 03:20:53 --> Config Class Initialized
INFO - 2021-01-21 03:20:53 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:53 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:53 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:53 --> URI Class Initialized
INFO - 2021-01-21 03:20:53 --> Router Class Initialized
INFO - 2021-01-21 03:20:53 --> Output Class Initialized
INFO - 2021-01-21 03:20:53 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:53 --> Input Class Initialized
INFO - 2021-01-21 03:20:53 --> Language Class Initialized
INFO - 2021-01-21 03:20:53 --> Language Class Initialized
INFO - 2021-01-21 03:20:53 --> Config Class Initialized
INFO - 2021-01-21 03:20:53 --> Loader Class Initialized
INFO - 2021-01-21 03:20:53 --> Helper loaded: url_helper
INFO - 2021-01-21 03:20:53 --> Helper loaded: file_helper
INFO - 2021-01-21 03:20:53 --> Helper loaded: form_helper
INFO - 2021-01-21 03:20:53 --> Helper loaded: my_helper
INFO - 2021-01-21 03:20:53 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:20:53 --> Controller Class Initialized
INFO - 2021-01-21 03:20:59 --> Config Class Initialized
INFO - 2021-01-21 03:20:59 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:20:59 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:20:59 --> Utf8 Class Initialized
INFO - 2021-01-21 03:20:59 --> URI Class Initialized
INFO - 2021-01-21 03:20:59 --> Router Class Initialized
INFO - 2021-01-21 03:20:59 --> Output Class Initialized
INFO - 2021-01-21 03:20:59 --> Security Class Initialized
DEBUG - 2021-01-21 03:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:20:59 --> Input Class Initialized
INFO - 2021-01-21 03:20:59 --> Language Class Initialized
INFO - 2021-01-21 03:20:59 --> Language Class Initialized
INFO - 2021-01-21 03:20:59 --> Config Class Initialized
INFO - 2021-01-21 03:21:00 --> Loader Class Initialized
INFO - 2021-01-21 03:21:00 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:00 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:00 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:00 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:00 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:00 --> Controller Class Initialized
INFO - 2021-01-21 03:21:00 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:21:00 --> Config Class Initialized
INFO - 2021-01-21 03:21:00 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:00 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:00 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:00 --> URI Class Initialized
INFO - 2021-01-21 03:21:00 --> Router Class Initialized
INFO - 2021-01-21 03:21:00 --> Output Class Initialized
INFO - 2021-01-21 03:21:00 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:00 --> Input Class Initialized
INFO - 2021-01-21 03:21:00 --> Language Class Initialized
INFO - 2021-01-21 03:21:00 --> Language Class Initialized
INFO - 2021-01-21 03:21:00 --> Config Class Initialized
INFO - 2021-01-21 03:21:00 --> Loader Class Initialized
INFO - 2021-01-21 03:21:00 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:00 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:00 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:00 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:00 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:00 --> Controller Class Initialized
DEBUG - 2021-01-21 03:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 03:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:21:00 --> Final output sent to browser
DEBUG - 2021-01-21 03:21:00 --> Total execution time: 0.3789
INFO - 2021-01-21 03:21:07 --> Config Class Initialized
INFO - 2021-01-21 03:21:07 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:07 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:07 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:07 --> URI Class Initialized
INFO - 2021-01-21 03:21:07 --> Router Class Initialized
INFO - 2021-01-21 03:21:07 --> Output Class Initialized
INFO - 2021-01-21 03:21:07 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:07 --> Input Class Initialized
INFO - 2021-01-21 03:21:07 --> Language Class Initialized
INFO - 2021-01-21 03:21:07 --> Language Class Initialized
INFO - 2021-01-21 03:21:07 --> Config Class Initialized
INFO - 2021-01-21 03:21:07 --> Loader Class Initialized
INFO - 2021-01-21 03:21:07 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:07 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:07 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:07 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:07 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:07 --> Controller Class Initialized
INFO - 2021-01-21 03:21:07 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:21:07 --> Final output sent to browser
DEBUG - 2021-01-21 03:21:07 --> Total execution time: 0.4694
INFO - 2021-01-21 03:21:09 --> Config Class Initialized
INFO - 2021-01-21 03:21:09 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:09 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:09 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:09 --> URI Class Initialized
INFO - 2021-01-21 03:21:09 --> Router Class Initialized
INFO - 2021-01-21 03:21:09 --> Output Class Initialized
INFO - 2021-01-21 03:21:09 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:09 --> Input Class Initialized
INFO - 2021-01-21 03:21:09 --> Language Class Initialized
INFO - 2021-01-21 03:21:09 --> Language Class Initialized
INFO - 2021-01-21 03:21:09 --> Config Class Initialized
INFO - 2021-01-21 03:21:09 --> Loader Class Initialized
INFO - 2021-01-21 03:21:09 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:09 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:09 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:09 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:09 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:09 --> Controller Class Initialized
DEBUG - 2021-01-21 03:21:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 03:21:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:21:09 --> Final output sent to browser
DEBUG - 2021-01-21 03:21:09 --> Total execution time: 0.5496
INFO - 2021-01-21 03:21:14 --> Config Class Initialized
INFO - 2021-01-21 03:21:14 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:14 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:14 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:14 --> URI Class Initialized
INFO - 2021-01-21 03:21:14 --> Router Class Initialized
INFO - 2021-01-21 03:21:14 --> Output Class Initialized
INFO - 2021-01-21 03:21:14 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:14 --> Input Class Initialized
INFO - 2021-01-21 03:21:14 --> Language Class Initialized
INFO - 2021-01-21 03:21:14 --> Language Class Initialized
INFO - 2021-01-21 03:21:14 --> Config Class Initialized
INFO - 2021-01-21 03:21:14 --> Loader Class Initialized
INFO - 2021-01-21 03:21:14 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:14 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:14 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:15 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:15 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:15 --> Controller Class Initialized
DEBUG - 2021-01-21 03:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-01-21 03:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:21:15 --> Final output sent to browser
DEBUG - 2021-01-21 03:21:15 --> Total execution time: 0.4526
INFO - 2021-01-21 03:21:15 --> Config Class Initialized
INFO - 2021-01-21 03:21:15 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:15 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:15 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:15 --> URI Class Initialized
INFO - 2021-01-21 03:21:15 --> Router Class Initialized
INFO - 2021-01-21 03:21:15 --> Output Class Initialized
INFO - 2021-01-21 03:21:15 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:15 --> Input Class Initialized
INFO - 2021-01-21 03:21:15 --> Language Class Initialized
INFO - 2021-01-21 03:21:15 --> Language Class Initialized
INFO - 2021-01-21 03:21:15 --> Config Class Initialized
INFO - 2021-01-21 03:21:15 --> Loader Class Initialized
INFO - 2021-01-21 03:21:15 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:15 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:15 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:15 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:15 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:15 --> Controller Class Initialized
INFO - 2021-01-21 03:21:19 --> Config Class Initialized
INFO - 2021-01-21 03:21:19 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:19 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:19 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:19 --> URI Class Initialized
INFO - 2021-01-21 03:21:19 --> Router Class Initialized
INFO - 2021-01-21 03:21:19 --> Output Class Initialized
INFO - 2021-01-21 03:21:19 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:19 --> Input Class Initialized
INFO - 2021-01-21 03:21:19 --> Language Class Initialized
INFO - 2021-01-21 03:21:19 --> Language Class Initialized
INFO - 2021-01-21 03:21:19 --> Config Class Initialized
INFO - 2021-01-21 03:21:19 --> Loader Class Initialized
INFO - 2021-01-21 03:21:19 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:19 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:19 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:19 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:19 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:19 --> Controller Class Initialized
INFO - 2021-01-21 03:21:19 --> Final output sent to browser
DEBUG - 2021-01-21 03:21:19 --> Total execution time: 0.3539
INFO - 2021-01-21 03:21:19 --> Config Class Initialized
INFO - 2021-01-21 03:21:19 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:19 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:19 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:19 --> URI Class Initialized
INFO - 2021-01-21 03:21:19 --> Router Class Initialized
INFO - 2021-01-21 03:21:19 --> Output Class Initialized
INFO - 2021-01-21 03:21:19 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:19 --> Input Class Initialized
INFO - 2021-01-21 03:21:19 --> Language Class Initialized
INFO - 2021-01-21 03:21:20 --> Language Class Initialized
INFO - 2021-01-21 03:21:20 --> Config Class Initialized
INFO - 2021-01-21 03:21:20 --> Loader Class Initialized
INFO - 2021-01-21 03:21:20 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:20 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:20 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:20 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:20 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:20 --> Controller Class Initialized
INFO - 2021-01-21 03:21:50 --> Config Class Initialized
INFO - 2021-01-21 03:21:50 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:50 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:50 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:50 --> URI Class Initialized
INFO - 2021-01-21 03:21:50 --> Router Class Initialized
INFO - 2021-01-21 03:21:50 --> Output Class Initialized
INFO - 2021-01-21 03:21:50 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:50 --> Input Class Initialized
INFO - 2021-01-21 03:21:50 --> Language Class Initialized
INFO - 2021-01-21 03:21:50 --> Language Class Initialized
INFO - 2021-01-21 03:21:50 --> Config Class Initialized
INFO - 2021-01-21 03:21:50 --> Loader Class Initialized
INFO - 2021-01-21 03:21:50 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:50 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:50 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:50 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:50 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:51 --> Controller Class Initialized
INFO - 2021-01-21 03:21:51 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:21:51 --> Config Class Initialized
INFO - 2021-01-21 03:21:51 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:51 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:51 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:51 --> URI Class Initialized
INFO - 2021-01-21 03:21:51 --> Router Class Initialized
INFO - 2021-01-21 03:21:51 --> Output Class Initialized
INFO - 2021-01-21 03:21:51 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:51 --> Input Class Initialized
INFO - 2021-01-21 03:21:51 --> Language Class Initialized
INFO - 2021-01-21 03:21:51 --> Language Class Initialized
INFO - 2021-01-21 03:21:51 --> Config Class Initialized
INFO - 2021-01-21 03:21:51 --> Loader Class Initialized
INFO - 2021-01-21 03:21:51 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:51 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:51 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:51 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:51 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:51 --> Controller Class Initialized
DEBUG - 2021-01-21 03:21:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 03:21:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:21:51 --> Final output sent to browser
DEBUG - 2021-01-21 03:21:51 --> Total execution time: 0.4102
INFO - 2021-01-21 03:21:56 --> Config Class Initialized
INFO - 2021-01-21 03:21:56 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:56 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:56 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:56 --> URI Class Initialized
INFO - 2021-01-21 03:21:56 --> Router Class Initialized
INFO - 2021-01-21 03:21:56 --> Output Class Initialized
INFO - 2021-01-21 03:21:57 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:57 --> Input Class Initialized
INFO - 2021-01-21 03:21:57 --> Language Class Initialized
INFO - 2021-01-21 03:21:57 --> Language Class Initialized
INFO - 2021-01-21 03:21:57 --> Config Class Initialized
INFO - 2021-01-21 03:21:57 --> Loader Class Initialized
INFO - 2021-01-21 03:21:57 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:57 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:57 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:57 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:57 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:57 --> Controller Class Initialized
INFO - 2021-01-21 03:21:57 --> Helper loaded: cookie_helper
INFO - 2021-01-21 03:21:57 --> Final output sent to browser
DEBUG - 2021-01-21 03:21:57 --> Total execution time: 0.4863
INFO - 2021-01-21 03:21:58 --> Config Class Initialized
INFO - 2021-01-21 03:21:58 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:21:58 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:21:58 --> Utf8 Class Initialized
INFO - 2021-01-21 03:21:58 --> URI Class Initialized
INFO - 2021-01-21 03:21:58 --> Router Class Initialized
INFO - 2021-01-21 03:21:58 --> Output Class Initialized
INFO - 2021-01-21 03:21:58 --> Security Class Initialized
DEBUG - 2021-01-21 03:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:21:58 --> Input Class Initialized
INFO - 2021-01-21 03:21:58 --> Language Class Initialized
INFO - 2021-01-21 03:21:58 --> Language Class Initialized
INFO - 2021-01-21 03:21:58 --> Config Class Initialized
INFO - 2021-01-21 03:21:58 --> Loader Class Initialized
INFO - 2021-01-21 03:21:58 --> Helper loaded: url_helper
INFO - 2021-01-21 03:21:58 --> Helper loaded: file_helper
INFO - 2021-01-21 03:21:58 --> Helper loaded: form_helper
INFO - 2021-01-21 03:21:58 --> Helper loaded: my_helper
INFO - 2021-01-21 03:21:58 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:21:58 --> Controller Class Initialized
DEBUG - 2021-01-21 03:21:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 03:21:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:21:58 --> Final output sent to browser
DEBUG - 2021-01-21 03:21:58 --> Total execution time: 0.6092
INFO - 2021-01-21 03:22:00 --> Config Class Initialized
INFO - 2021-01-21 03:22:00 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:22:00 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:22:00 --> Utf8 Class Initialized
INFO - 2021-01-21 03:22:00 --> URI Class Initialized
INFO - 2021-01-21 03:22:00 --> Router Class Initialized
INFO - 2021-01-21 03:22:00 --> Output Class Initialized
INFO - 2021-01-21 03:22:00 --> Security Class Initialized
DEBUG - 2021-01-21 03:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:22:00 --> Input Class Initialized
INFO - 2021-01-21 03:22:00 --> Language Class Initialized
INFO - 2021-01-21 03:22:00 --> Language Class Initialized
INFO - 2021-01-21 03:22:00 --> Config Class Initialized
INFO - 2021-01-21 03:22:00 --> Loader Class Initialized
INFO - 2021-01-21 03:22:00 --> Helper loaded: url_helper
INFO - 2021-01-21 03:22:00 --> Helper loaded: file_helper
INFO - 2021-01-21 03:22:00 --> Helper loaded: form_helper
INFO - 2021-01-21 03:22:00 --> Helper loaded: my_helper
INFO - 2021-01-21 03:22:00 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:22:00 --> Controller Class Initialized
DEBUG - 2021-01-21 03:22:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-21 03:22:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:22:00 --> Final output sent to browser
DEBUG - 2021-01-21 03:22:00 --> Total execution time: 0.3943
INFO - 2021-01-21 03:22:01 --> Config Class Initialized
INFO - 2021-01-21 03:22:01 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:22:01 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:22:01 --> Utf8 Class Initialized
INFO - 2021-01-21 03:22:01 --> URI Class Initialized
INFO - 2021-01-21 03:22:01 --> Router Class Initialized
INFO - 2021-01-21 03:22:01 --> Output Class Initialized
INFO - 2021-01-21 03:22:02 --> Security Class Initialized
DEBUG - 2021-01-21 03:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:22:02 --> Input Class Initialized
INFO - 2021-01-21 03:22:02 --> Language Class Initialized
INFO - 2021-01-21 03:22:02 --> Language Class Initialized
INFO - 2021-01-21 03:22:02 --> Config Class Initialized
INFO - 2021-01-21 03:22:02 --> Loader Class Initialized
INFO - 2021-01-21 03:22:02 --> Helper loaded: url_helper
INFO - 2021-01-21 03:22:02 --> Helper loaded: file_helper
INFO - 2021-01-21 03:22:02 --> Helper loaded: form_helper
INFO - 2021-01-21 03:22:02 --> Helper loaded: my_helper
INFO - 2021-01-21 03:22:02 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:22:02 --> Controller Class Initialized
DEBUG - 2021-01-21 03:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 03:22:02 --> Final output sent to browser
DEBUG - 2021-01-21 03:22:02 --> Total execution time: 0.4121
INFO - 2021-01-21 03:22:11 --> Config Class Initialized
INFO - 2021-01-21 03:22:11 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:22:11 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:22:11 --> Utf8 Class Initialized
INFO - 2021-01-21 03:22:11 --> URI Class Initialized
INFO - 2021-01-21 03:22:11 --> Router Class Initialized
INFO - 2021-01-21 03:22:11 --> Output Class Initialized
INFO - 2021-01-21 03:22:11 --> Security Class Initialized
DEBUG - 2021-01-21 03:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:22:11 --> Input Class Initialized
INFO - 2021-01-21 03:22:11 --> Language Class Initialized
INFO - 2021-01-21 03:22:11 --> Language Class Initialized
INFO - 2021-01-21 03:22:11 --> Config Class Initialized
INFO - 2021-01-21 03:22:11 --> Loader Class Initialized
INFO - 2021-01-21 03:22:11 --> Helper loaded: url_helper
INFO - 2021-01-21 03:22:11 --> Helper loaded: file_helper
INFO - 2021-01-21 03:22:11 --> Helper loaded: form_helper
INFO - 2021-01-21 03:22:11 --> Helper loaded: my_helper
INFO - 2021-01-21 03:22:11 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:22:11 --> Controller Class Initialized
DEBUG - 2021-01-21 03:22:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 03:22:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 03:22:11 --> Final output sent to browser
DEBUG - 2021-01-21 03:22:11 --> Total execution time: 0.3843
INFO - 2021-01-21 03:22:13 --> Config Class Initialized
INFO - 2021-01-21 03:22:13 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:22:13 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:22:13 --> Utf8 Class Initialized
INFO - 2021-01-21 03:22:13 --> URI Class Initialized
INFO - 2021-01-21 03:22:14 --> Router Class Initialized
INFO - 2021-01-21 03:22:14 --> Output Class Initialized
INFO - 2021-01-21 03:22:14 --> Security Class Initialized
DEBUG - 2021-01-21 03:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:22:14 --> Input Class Initialized
INFO - 2021-01-21 03:22:14 --> Language Class Initialized
INFO - 2021-01-21 03:22:14 --> Language Class Initialized
INFO - 2021-01-21 03:22:14 --> Config Class Initialized
INFO - 2021-01-21 03:22:14 --> Loader Class Initialized
INFO - 2021-01-21 03:22:14 --> Helper loaded: url_helper
INFO - 2021-01-21 03:22:14 --> Helper loaded: file_helper
INFO - 2021-01-21 03:22:14 --> Helper loaded: form_helper
INFO - 2021-01-21 03:22:14 --> Helper loaded: my_helper
INFO - 2021-01-21 03:22:14 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:22:14 --> Controller Class Initialized
DEBUG - 2021-01-21 03:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:22:14 --> Final output sent to browser
DEBUG - 2021-01-21 03:22:14 --> Total execution time: 0.4264
INFO - 2021-01-21 03:26:33 --> Config Class Initialized
INFO - 2021-01-21 03:26:33 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:26:33 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:26:33 --> Utf8 Class Initialized
INFO - 2021-01-21 03:26:33 --> URI Class Initialized
INFO - 2021-01-21 03:26:33 --> Router Class Initialized
INFO - 2021-01-21 03:26:33 --> Output Class Initialized
INFO - 2021-01-21 03:26:33 --> Security Class Initialized
DEBUG - 2021-01-21 03:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:26:33 --> Input Class Initialized
INFO - 2021-01-21 03:26:33 --> Language Class Initialized
INFO - 2021-01-21 03:26:33 --> Language Class Initialized
INFO - 2021-01-21 03:26:33 --> Config Class Initialized
INFO - 2021-01-21 03:26:33 --> Loader Class Initialized
INFO - 2021-01-21 03:26:33 --> Helper loaded: url_helper
INFO - 2021-01-21 03:26:33 --> Helper loaded: file_helper
INFO - 2021-01-21 03:26:33 --> Helper loaded: form_helper
INFO - 2021-01-21 03:26:33 --> Helper loaded: my_helper
INFO - 2021-01-21 03:26:33 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:26:33 --> Controller Class Initialized
DEBUG - 2021-01-21 03:26:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-21 03:26:33 --> Final output sent to browser
DEBUG - 2021-01-21 03:26:33 --> Total execution time: 0.4050
INFO - 2021-01-21 03:27:21 --> Config Class Initialized
INFO - 2021-01-21 03:27:21 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:27:21 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:27:21 --> Utf8 Class Initialized
INFO - 2021-01-21 03:27:21 --> URI Class Initialized
INFO - 2021-01-21 03:27:21 --> Router Class Initialized
INFO - 2021-01-21 03:27:21 --> Output Class Initialized
INFO - 2021-01-21 03:27:21 --> Security Class Initialized
DEBUG - 2021-01-21 03:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:27:21 --> Input Class Initialized
INFO - 2021-01-21 03:27:21 --> Language Class Initialized
INFO - 2021-01-21 03:27:21 --> Language Class Initialized
INFO - 2021-01-21 03:27:21 --> Config Class Initialized
INFO - 2021-01-21 03:27:21 --> Loader Class Initialized
INFO - 2021-01-21 03:27:21 --> Helper loaded: url_helper
INFO - 2021-01-21 03:27:21 --> Helper loaded: file_helper
INFO - 2021-01-21 03:27:21 --> Helper loaded: form_helper
INFO - 2021-01-21 03:27:21 --> Helper loaded: my_helper
INFO - 2021-01-21 03:27:21 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:27:21 --> Controller Class Initialized
DEBUG - 2021-01-21 03:27:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:27:21 --> Final output sent to browser
DEBUG - 2021-01-21 03:27:21 --> Total execution time: 0.3715
INFO - 2021-01-21 03:27:45 --> Config Class Initialized
INFO - 2021-01-21 03:27:45 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:27:45 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:27:45 --> Utf8 Class Initialized
INFO - 2021-01-21 03:27:45 --> URI Class Initialized
INFO - 2021-01-21 03:27:45 --> Router Class Initialized
INFO - 2021-01-21 03:27:45 --> Output Class Initialized
INFO - 2021-01-21 03:27:45 --> Security Class Initialized
DEBUG - 2021-01-21 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:27:45 --> Input Class Initialized
INFO - 2021-01-21 03:27:45 --> Language Class Initialized
INFO - 2021-01-21 03:27:45 --> Language Class Initialized
INFO - 2021-01-21 03:27:45 --> Config Class Initialized
INFO - 2021-01-21 03:27:45 --> Loader Class Initialized
INFO - 2021-01-21 03:27:45 --> Helper loaded: url_helper
INFO - 2021-01-21 03:27:45 --> Helper loaded: file_helper
INFO - 2021-01-21 03:27:45 --> Helper loaded: form_helper
INFO - 2021-01-21 03:27:45 --> Helper loaded: my_helper
INFO - 2021-01-21 03:27:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:27:46 --> Controller Class Initialized
ERROR - 2021-01-21 03:27:46 --> Severity: Notice --> Undefined variable: q_mapel1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4605
ERROR - 2021-01-21 03:27:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4605
DEBUG - 2021-01-21 03:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:27:46 --> Final output sent to browser
DEBUG - 2021-01-21 03:27:46 --> Total execution time: 0.4991
INFO - 2021-01-21 03:28:07 --> Config Class Initialized
INFO - 2021-01-21 03:28:07 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:28:07 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:28:07 --> Utf8 Class Initialized
INFO - 2021-01-21 03:28:07 --> URI Class Initialized
INFO - 2021-01-21 03:28:07 --> Router Class Initialized
INFO - 2021-01-21 03:28:07 --> Output Class Initialized
INFO - 2021-01-21 03:28:07 --> Security Class Initialized
DEBUG - 2021-01-21 03:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:28:07 --> Input Class Initialized
INFO - 2021-01-21 03:28:07 --> Language Class Initialized
INFO - 2021-01-21 03:28:07 --> Language Class Initialized
INFO - 2021-01-21 03:28:07 --> Config Class Initialized
INFO - 2021-01-21 03:28:07 --> Loader Class Initialized
INFO - 2021-01-21 03:28:07 --> Helper loaded: url_helper
INFO - 2021-01-21 03:28:07 --> Helper loaded: file_helper
INFO - 2021-01-21 03:28:07 --> Helper loaded: form_helper
INFO - 2021-01-21 03:28:07 --> Helper loaded: my_helper
INFO - 2021-01-21 03:28:07 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:28:07 --> Controller Class Initialized
ERROR - 2021-01-21 03:28:07 --> Severity: Notice --> Undefined variable: q_mapel1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4606
ERROR - 2021-01-21 03:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4606
DEBUG - 2021-01-21 03:28:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:28:07 --> Final output sent to browser
DEBUG - 2021-01-21 03:28:07 --> Total execution time: 0.4037
INFO - 2021-01-21 03:28:25 --> Config Class Initialized
INFO - 2021-01-21 03:28:25 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:28:25 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:28:25 --> Utf8 Class Initialized
INFO - 2021-01-21 03:28:25 --> URI Class Initialized
INFO - 2021-01-21 03:28:25 --> Router Class Initialized
INFO - 2021-01-21 03:28:25 --> Output Class Initialized
INFO - 2021-01-21 03:28:25 --> Security Class Initialized
DEBUG - 2021-01-21 03:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:28:25 --> Input Class Initialized
INFO - 2021-01-21 03:28:25 --> Language Class Initialized
INFO - 2021-01-21 03:28:25 --> Language Class Initialized
INFO - 2021-01-21 03:28:25 --> Config Class Initialized
INFO - 2021-01-21 03:28:25 --> Loader Class Initialized
INFO - 2021-01-21 03:28:25 --> Helper loaded: url_helper
INFO - 2021-01-21 03:28:25 --> Helper loaded: file_helper
INFO - 2021-01-21 03:28:25 --> Helper loaded: form_helper
INFO - 2021-01-21 03:28:25 --> Helper loaded: my_helper
INFO - 2021-01-21 03:28:25 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:28:25 --> Controller Class Initialized
ERROR - 2021-01-21 03:28:25 --> Severity: Notice --> Undefined variable: q_mapel1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4606
ERROR - 2021-01-21 03:28:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4606
DEBUG - 2021-01-21 03:28:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:28:25 --> Final output sent to browser
DEBUG - 2021-01-21 03:28:25 --> Total execution time: 0.4056
INFO - 2021-01-21 03:28:33 --> Config Class Initialized
INFO - 2021-01-21 03:28:33 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:28:33 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:28:33 --> Utf8 Class Initialized
INFO - 2021-01-21 03:28:33 --> URI Class Initialized
INFO - 2021-01-21 03:28:33 --> Router Class Initialized
INFO - 2021-01-21 03:28:33 --> Output Class Initialized
INFO - 2021-01-21 03:28:33 --> Security Class Initialized
DEBUG - 2021-01-21 03:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:28:33 --> Input Class Initialized
INFO - 2021-01-21 03:28:33 --> Language Class Initialized
INFO - 2021-01-21 03:28:33 --> Language Class Initialized
INFO - 2021-01-21 03:28:33 --> Config Class Initialized
INFO - 2021-01-21 03:28:33 --> Loader Class Initialized
INFO - 2021-01-21 03:28:33 --> Helper loaded: url_helper
INFO - 2021-01-21 03:28:33 --> Helper loaded: file_helper
INFO - 2021-01-21 03:28:33 --> Helper loaded: form_helper
INFO - 2021-01-21 03:28:33 --> Helper loaded: my_helper
INFO - 2021-01-21 03:28:34 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:28:34 --> Controller Class Initialized
DEBUG - 2021-01-21 03:28:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:28:34 --> Final output sent to browser
DEBUG - 2021-01-21 03:28:34 --> Total execution time: 0.4275
INFO - 2021-01-21 03:29:00 --> Config Class Initialized
INFO - 2021-01-21 03:29:00 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:29:00 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:29:00 --> Utf8 Class Initialized
INFO - 2021-01-21 03:29:00 --> URI Class Initialized
INFO - 2021-01-21 03:29:00 --> Router Class Initialized
INFO - 2021-01-21 03:29:00 --> Output Class Initialized
INFO - 2021-01-21 03:29:00 --> Security Class Initialized
DEBUG - 2021-01-21 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:29:00 --> Input Class Initialized
INFO - 2021-01-21 03:29:00 --> Language Class Initialized
INFO - 2021-01-21 03:29:00 --> Language Class Initialized
INFO - 2021-01-21 03:29:00 --> Config Class Initialized
INFO - 2021-01-21 03:29:00 --> Loader Class Initialized
INFO - 2021-01-21 03:29:00 --> Helper loaded: url_helper
INFO - 2021-01-21 03:29:00 --> Helper loaded: file_helper
INFO - 2021-01-21 03:29:00 --> Helper loaded: form_helper
INFO - 2021-01-21 03:29:00 --> Helper loaded: my_helper
INFO - 2021-01-21 03:29:00 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:29:00 --> Controller Class Initialized
DEBUG - 2021-01-21 03:29:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:29:00 --> Final output sent to browser
DEBUG - 2021-01-21 03:29:00 --> Total execution time: 0.4010
INFO - 2021-01-21 03:29:36 --> Config Class Initialized
INFO - 2021-01-21 03:29:36 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:29:36 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:29:36 --> Utf8 Class Initialized
INFO - 2021-01-21 03:29:36 --> URI Class Initialized
INFO - 2021-01-21 03:29:36 --> Router Class Initialized
INFO - 2021-01-21 03:29:36 --> Output Class Initialized
INFO - 2021-01-21 03:29:36 --> Security Class Initialized
DEBUG - 2021-01-21 03:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:29:36 --> Input Class Initialized
INFO - 2021-01-21 03:29:36 --> Language Class Initialized
INFO - 2021-01-21 03:29:36 --> Language Class Initialized
INFO - 2021-01-21 03:29:36 --> Config Class Initialized
INFO - 2021-01-21 03:29:36 --> Loader Class Initialized
INFO - 2021-01-21 03:29:36 --> Helper loaded: url_helper
INFO - 2021-01-21 03:29:37 --> Helper loaded: file_helper
INFO - 2021-01-21 03:29:37 --> Helper loaded: form_helper
INFO - 2021-01-21 03:29:37 --> Helper loaded: my_helper
INFO - 2021-01-21 03:29:37 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:29:37 --> Controller Class Initialized
ERROR - 2021-01-21 03:29:37 --> Severity: Notice --> Undefined variable: m1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4599
ERROR - 2021-01-21 03:29:37 --> Severity: Notice --> Undefined variable: m1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4599
DEBUG - 2021-01-21 03:29:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:29:37 --> Final output sent to browser
DEBUG - 2021-01-21 03:29:37 --> Total execution time: 0.4170
INFO - 2021-01-21 03:30:01 --> Config Class Initialized
INFO - 2021-01-21 03:30:01 --> Hooks Class Initialized
DEBUG - 2021-01-21 03:30:01 --> UTF-8 Support Enabled
INFO - 2021-01-21 03:30:01 --> Utf8 Class Initialized
INFO - 2021-01-21 03:30:01 --> URI Class Initialized
INFO - 2021-01-21 03:30:01 --> Router Class Initialized
INFO - 2021-01-21 03:30:01 --> Output Class Initialized
INFO - 2021-01-21 03:30:01 --> Security Class Initialized
DEBUG - 2021-01-21 03:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 03:30:01 --> Input Class Initialized
INFO - 2021-01-21 03:30:01 --> Language Class Initialized
INFO - 2021-01-21 03:30:01 --> Language Class Initialized
INFO - 2021-01-21 03:30:01 --> Config Class Initialized
INFO - 2021-01-21 03:30:01 --> Loader Class Initialized
INFO - 2021-01-21 03:30:01 --> Helper loaded: url_helper
INFO - 2021-01-21 03:30:01 --> Helper loaded: file_helper
INFO - 2021-01-21 03:30:01 --> Helper loaded: form_helper
INFO - 2021-01-21 03:30:01 --> Helper loaded: my_helper
INFO - 2021-01-21 03:30:01 --> Database Driver Class Initialized
DEBUG - 2021-01-21 03:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 03:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 03:30:01 --> Controller Class Initialized
DEBUG - 2021-01-21 03:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 03:30:01 --> Final output sent to browser
DEBUG - 2021-01-21 03:30:01 --> Total execution time: 0.3763
INFO - 2021-01-21 04:21:17 --> Config Class Initialized
INFO - 2021-01-21 04:21:17 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:21:17 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:21:17 --> Utf8 Class Initialized
INFO - 2021-01-21 04:21:17 --> URI Class Initialized
INFO - 2021-01-21 04:21:17 --> Router Class Initialized
INFO - 2021-01-21 04:21:17 --> Output Class Initialized
INFO - 2021-01-21 04:21:17 --> Security Class Initialized
DEBUG - 2021-01-21 04:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:21:17 --> Input Class Initialized
INFO - 2021-01-21 04:21:17 --> Language Class Initialized
INFO - 2021-01-21 04:21:17 --> Language Class Initialized
INFO - 2021-01-21 04:21:17 --> Config Class Initialized
INFO - 2021-01-21 04:21:17 --> Loader Class Initialized
INFO - 2021-01-21 04:21:17 --> Helper loaded: url_helper
INFO - 2021-01-21 04:21:17 --> Helper loaded: file_helper
INFO - 2021-01-21 04:21:17 --> Helper loaded: form_helper
INFO - 2021-01-21 04:21:17 --> Helper loaded: my_helper
INFO - 2021-01-21 04:21:17 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:21:17 --> Controller Class Initialized
DEBUG - 2021-01-21 04:21:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:21:17 --> Final output sent to browser
DEBUG - 2021-01-21 04:21:17 --> Total execution time: 0.4094
INFO - 2021-01-21 04:22:31 --> Config Class Initialized
INFO - 2021-01-21 04:22:31 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:22:31 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:22:31 --> Utf8 Class Initialized
INFO - 2021-01-21 04:22:31 --> URI Class Initialized
INFO - 2021-01-21 04:22:31 --> Router Class Initialized
INFO - 2021-01-21 04:22:31 --> Output Class Initialized
INFO - 2021-01-21 04:22:31 --> Security Class Initialized
DEBUG - 2021-01-21 04:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:22:31 --> Input Class Initialized
INFO - 2021-01-21 04:22:31 --> Language Class Initialized
INFO - 2021-01-21 04:22:31 --> Language Class Initialized
INFO - 2021-01-21 04:22:31 --> Config Class Initialized
INFO - 2021-01-21 04:22:31 --> Loader Class Initialized
INFO - 2021-01-21 04:22:32 --> Helper loaded: url_helper
INFO - 2021-01-21 04:22:32 --> Helper loaded: file_helper
INFO - 2021-01-21 04:22:32 --> Helper loaded: form_helper
INFO - 2021-01-21 04:22:32 --> Helper loaded: my_helper
INFO - 2021-01-21 04:22:32 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:22:32 --> Controller Class Initialized
DEBUG - 2021-01-21 04:22:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:22:32 --> Final output sent to browser
DEBUG - 2021-01-21 04:22:32 --> Total execution time: 0.3755
INFO - 2021-01-21 04:22:45 --> Config Class Initialized
INFO - 2021-01-21 04:22:45 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:22:45 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:22:45 --> Utf8 Class Initialized
INFO - 2021-01-21 04:22:45 --> URI Class Initialized
INFO - 2021-01-21 04:22:45 --> Router Class Initialized
INFO - 2021-01-21 04:22:45 --> Output Class Initialized
INFO - 2021-01-21 04:22:45 --> Security Class Initialized
DEBUG - 2021-01-21 04:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:22:45 --> Input Class Initialized
INFO - 2021-01-21 04:22:45 --> Language Class Initialized
INFO - 2021-01-21 04:22:45 --> Language Class Initialized
INFO - 2021-01-21 04:22:45 --> Config Class Initialized
INFO - 2021-01-21 04:22:45 --> Loader Class Initialized
INFO - 2021-01-21 04:22:45 --> Helper loaded: url_helper
INFO - 2021-01-21 04:22:45 --> Helper loaded: file_helper
INFO - 2021-01-21 04:22:45 --> Helper loaded: form_helper
INFO - 2021-01-21 04:22:45 --> Helper loaded: my_helper
INFO - 2021-01-21 04:22:45 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:22:45 --> Controller Class Initialized
DEBUG - 2021-01-21 04:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:22:45 --> Final output sent to browser
DEBUG - 2021-01-21 04:22:45 --> Total execution time: 0.3902
INFO - 2021-01-21 04:23:03 --> Config Class Initialized
INFO - 2021-01-21 04:23:03 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:23:03 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:23:03 --> Utf8 Class Initialized
INFO - 2021-01-21 04:23:03 --> URI Class Initialized
INFO - 2021-01-21 04:23:03 --> Router Class Initialized
INFO - 2021-01-21 04:23:03 --> Output Class Initialized
INFO - 2021-01-21 04:23:03 --> Security Class Initialized
DEBUG - 2021-01-21 04:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:23:03 --> Input Class Initialized
INFO - 2021-01-21 04:23:03 --> Language Class Initialized
INFO - 2021-01-21 04:23:03 --> Language Class Initialized
INFO - 2021-01-21 04:23:03 --> Config Class Initialized
INFO - 2021-01-21 04:23:03 --> Loader Class Initialized
INFO - 2021-01-21 04:23:03 --> Helper loaded: url_helper
INFO - 2021-01-21 04:23:03 --> Helper loaded: file_helper
INFO - 2021-01-21 04:23:03 --> Helper loaded: form_helper
INFO - 2021-01-21 04:23:03 --> Helper loaded: my_helper
INFO - 2021-01-21 04:23:03 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:23:03 --> Controller Class Initialized
ERROR - 2021-01-21 04:23:03 --> Severity: Notice --> Undefined variable: nap C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
ERROR - 2021-01-21 04:23:03 --> Severity: Notice --> Undefined variable: nap C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
ERROR - 2021-01-21 04:23:03 --> Severity: Notice --> Undefined variable: nap C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
ERROR - 2021-01-21 04:23:03 --> Severity: Notice --> Undefined variable: nap C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
ERROR - 2021-01-21 04:23:03 --> Severity: Notice --> Undefined variable: nap C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
DEBUG - 2021-01-21 04:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:23:03 --> Final output sent to browser
DEBUG - 2021-01-21 04:23:03 --> Total execution time: 0.4597
INFO - 2021-01-21 04:23:19 --> Config Class Initialized
INFO - 2021-01-21 04:23:19 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:23:19 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:23:19 --> Utf8 Class Initialized
INFO - 2021-01-21 04:23:19 --> URI Class Initialized
INFO - 2021-01-21 04:23:19 --> Router Class Initialized
INFO - 2021-01-21 04:23:19 --> Output Class Initialized
INFO - 2021-01-21 04:23:19 --> Security Class Initialized
DEBUG - 2021-01-21 04:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:23:19 --> Input Class Initialized
INFO - 2021-01-21 04:23:19 --> Language Class Initialized
INFO - 2021-01-21 04:23:19 --> Language Class Initialized
INFO - 2021-01-21 04:23:19 --> Config Class Initialized
INFO - 2021-01-21 04:23:19 --> Loader Class Initialized
INFO - 2021-01-21 04:23:19 --> Helper loaded: url_helper
INFO - 2021-01-21 04:23:19 --> Helper loaded: file_helper
INFO - 2021-01-21 04:23:19 --> Helper loaded: form_helper
INFO - 2021-01-21 04:23:19 --> Helper loaded: my_helper
INFO - 2021-01-21 04:23:19 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:23:19 --> Controller Class Initialized
DEBUG - 2021-01-21 04:23:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:23:19 --> Final output sent to browser
DEBUG - 2021-01-21 04:23:19 --> Total execution time: 0.4110
INFO - 2021-01-21 04:24:07 --> Config Class Initialized
INFO - 2021-01-21 04:24:07 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:24:07 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:24:07 --> Utf8 Class Initialized
INFO - 2021-01-21 04:24:07 --> URI Class Initialized
INFO - 2021-01-21 04:24:07 --> Router Class Initialized
INFO - 2021-01-21 04:24:08 --> Output Class Initialized
INFO - 2021-01-21 04:24:08 --> Security Class Initialized
DEBUG - 2021-01-21 04:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:24:08 --> Input Class Initialized
INFO - 2021-01-21 04:24:08 --> Language Class Initialized
INFO - 2021-01-21 04:24:08 --> Language Class Initialized
INFO - 2021-01-21 04:24:08 --> Config Class Initialized
INFO - 2021-01-21 04:24:08 --> Loader Class Initialized
INFO - 2021-01-21 04:24:08 --> Helper loaded: url_helper
INFO - 2021-01-21 04:24:08 --> Helper loaded: file_helper
INFO - 2021-01-21 04:24:08 --> Helper loaded: form_helper
INFO - 2021-01-21 04:24:08 --> Helper loaded: my_helper
INFO - 2021-01-21 04:24:08 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:24:08 --> Controller Class Initialized
DEBUG - 2021-01-21 04:24:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:24:08 --> Final output sent to browser
DEBUG - 2021-01-21 04:24:08 --> Total execution time: 0.3713
INFO - 2021-01-21 04:24:37 --> Config Class Initialized
INFO - 2021-01-21 04:24:37 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:24:37 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:24:37 --> Utf8 Class Initialized
INFO - 2021-01-21 04:24:37 --> URI Class Initialized
INFO - 2021-01-21 04:24:37 --> Router Class Initialized
INFO - 2021-01-21 04:24:37 --> Output Class Initialized
INFO - 2021-01-21 04:24:37 --> Security Class Initialized
DEBUG - 2021-01-21 04:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:24:37 --> Input Class Initialized
INFO - 2021-01-21 04:24:37 --> Language Class Initialized
INFO - 2021-01-21 04:24:37 --> Language Class Initialized
INFO - 2021-01-21 04:24:37 --> Config Class Initialized
INFO - 2021-01-21 04:24:37 --> Loader Class Initialized
INFO - 2021-01-21 04:24:37 --> Helper loaded: url_helper
INFO - 2021-01-21 04:24:37 --> Helper loaded: file_helper
INFO - 2021-01-21 04:24:37 --> Helper loaded: form_helper
INFO - 2021-01-21 04:24:37 --> Helper loaded: my_helper
INFO - 2021-01-21 04:24:37 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:24:37 --> Controller Class Initialized
DEBUG - 2021-01-21 04:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:24:38 --> Final output sent to browser
DEBUG - 2021-01-21 04:24:38 --> Total execution time: 0.3946
INFO - 2021-01-21 04:24:45 --> Config Class Initialized
INFO - 2021-01-21 04:24:45 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:24:45 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:24:45 --> Utf8 Class Initialized
INFO - 2021-01-21 04:24:45 --> URI Class Initialized
INFO - 2021-01-21 04:24:45 --> Router Class Initialized
INFO - 2021-01-21 04:24:45 --> Output Class Initialized
INFO - 2021-01-21 04:24:45 --> Security Class Initialized
DEBUG - 2021-01-21 04:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:24:45 --> Input Class Initialized
INFO - 2021-01-21 04:24:45 --> Language Class Initialized
INFO - 2021-01-21 04:24:45 --> Language Class Initialized
INFO - 2021-01-21 04:24:45 --> Config Class Initialized
INFO - 2021-01-21 04:24:45 --> Loader Class Initialized
INFO - 2021-01-21 04:24:45 --> Helper loaded: url_helper
INFO - 2021-01-21 04:24:45 --> Helper loaded: file_helper
INFO - 2021-01-21 04:24:45 --> Helper loaded: form_helper
INFO - 2021-01-21 04:24:45 --> Helper loaded: my_helper
INFO - 2021-01-21 04:24:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:24:46 --> Controller Class Initialized
DEBUG - 2021-01-21 04:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:24:46 --> Final output sent to browser
DEBUG - 2021-01-21 04:24:46 --> Total execution time: 0.3953
INFO - 2021-01-21 04:24:56 --> Config Class Initialized
INFO - 2021-01-21 04:24:56 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:24:56 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:24:56 --> Utf8 Class Initialized
INFO - 2021-01-21 04:24:56 --> URI Class Initialized
INFO - 2021-01-21 04:24:56 --> Router Class Initialized
INFO - 2021-01-21 04:24:56 --> Output Class Initialized
INFO - 2021-01-21 04:24:56 --> Security Class Initialized
DEBUG - 2021-01-21 04:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:24:56 --> Input Class Initialized
INFO - 2021-01-21 04:24:56 --> Language Class Initialized
INFO - 2021-01-21 04:24:56 --> Language Class Initialized
INFO - 2021-01-21 04:24:56 --> Config Class Initialized
INFO - 2021-01-21 04:24:56 --> Loader Class Initialized
INFO - 2021-01-21 04:24:56 --> Helper loaded: url_helper
INFO - 2021-01-21 04:24:56 --> Helper loaded: file_helper
INFO - 2021-01-21 04:24:56 --> Helper loaded: form_helper
INFO - 2021-01-21 04:24:56 --> Helper loaded: my_helper
INFO - 2021-01-21 04:24:56 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:24:56 --> Controller Class Initialized
DEBUG - 2021-01-21 04:24:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:24:56 --> Final output sent to browser
DEBUG - 2021-01-21 04:24:56 --> Total execution time: 0.3795
INFO - 2021-01-21 04:25:43 --> Config Class Initialized
INFO - 2021-01-21 04:25:43 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:25:43 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:25:43 --> Utf8 Class Initialized
INFO - 2021-01-21 04:25:43 --> URI Class Initialized
INFO - 2021-01-21 04:25:43 --> Router Class Initialized
INFO - 2021-01-21 04:25:43 --> Output Class Initialized
INFO - 2021-01-21 04:25:43 --> Security Class Initialized
DEBUG - 2021-01-21 04:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:25:43 --> Input Class Initialized
INFO - 2021-01-21 04:25:43 --> Language Class Initialized
INFO - 2021-01-21 04:25:43 --> Language Class Initialized
INFO - 2021-01-21 04:25:43 --> Config Class Initialized
INFO - 2021-01-21 04:25:43 --> Loader Class Initialized
INFO - 2021-01-21 04:25:43 --> Helper loaded: url_helper
INFO - 2021-01-21 04:25:43 --> Helper loaded: file_helper
INFO - 2021-01-21 04:25:43 --> Helper loaded: form_helper
INFO - 2021-01-21 04:25:43 --> Helper loaded: my_helper
INFO - 2021-01-21 04:25:43 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:25:43 --> Controller Class Initialized
DEBUG - 2021-01-21 04:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:25:43 --> Final output sent to browser
DEBUG - 2021-01-21 04:25:43 --> Total execution time: 0.3820
INFO - 2021-01-21 04:26:04 --> Config Class Initialized
INFO - 2021-01-21 04:26:04 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:26:04 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:26:04 --> Utf8 Class Initialized
INFO - 2021-01-21 04:26:04 --> URI Class Initialized
INFO - 2021-01-21 04:26:04 --> Router Class Initialized
INFO - 2021-01-21 04:26:04 --> Output Class Initialized
INFO - 2021-01-21 04:26:04 --> Security Class Initialized
DEBUG - 2021-01-21 04:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:26:04 --> Input Class Initialized
INFO - 2021-01-21 04:26:04 --> Language Class Initialized
INFO - 2021-01-21 04:26:05 --> Language Class Initialized
INFO - 2021-01-21 04:26:05 --> Config Class Initialized
INFO - 2021-01-21 04:26:05 --> Loader Class Initialized
INFO - 2021-01-21 04:26:05 --> Helper loaded: url_helper
INFO - 2021-01-21 04:26:05 --> Helper loaded: file_helper
INFO - 2021-01-21 04:26:05 --> Helper loaded: form_helper
INFO - 2021-01-21 04:26:05 --> Helper loaded: my_helper
INFO - 2021-01-21 04:26:05 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:26:05 --> Controller Class Initialized
DEBUG - 2021-01-21 04:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:26:05 --> Final output sent to browser
DEBUG - 2021-01-21 04:26:05 --> Total execution time: 0.3795
INFO - 2021-01-21 04:26:45 --> Config Class Initialized
INFO - 2021-01-21 04:26:45 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:26:45 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:26:45 --> Utf8 Class Initialized
INFO - 2021-01-21 04:26:45 --> URI Class Initialized
INFO - 2021-01-21 04:26:45 --> Router Class Initialized
INFO - 2021-01-21 04:26:45 --> Output Class Initialized
INFO - 2021-01-21 04:26:45 --> Security Class Initialized
DEBUG - 2021-01-21 04:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:26:45 --> Input Class Initialized
INFO - 2021-01-21 04:26:45 --> Language Class Initialized
INFO - 2021-01-21 04:26:45 --> Language Class Initialized
INFO - 2021-01-21 04:26:45 --> Config Class Initialized
INFO - 2021-01-21 04:26:45 --> Loader Class Initialized
INFO - 2021-01-21 04:26:45 --> Helper loaded: url_helper
INFO - 2021-01-21 04:26:45 --> Helper loaded: file_helper
INFO - 2021-01-21 04:26:45 --> Helper loaded: form_helper
INFO - 2021-01-21 04:26:45 --> Helper loaded: my_helper
INFO - 2021-01-21 04:26:45 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:26:45 --> Controller Class Initialized
DEBUG - 2021-01-21 04:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:26:45 --> Final output sent to browser
DEBUG - 2021-01-21 04:26:45 --> Total execution time: 0.4039
INFO - 2021-01-21 04:27:36 --> Config Class Initialized
INFO - 2021-01-21 04:27:36 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:27:36 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:27:36 --> Utf8 Class Initialized
INFO - 2021-01-21 04:27:36 --> URI Class Initialized
INFO - 2021-01-21 04:27:36 --> Router Class Initialized
INFO - 2021-01-21 04:27:36 --> Output Class Initialized
INFO - 2021-01-21 04:27:36 --> Security Class Initialized
DEBUG - 2021-01-21 04:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:27:36 --> Input Class Initialized
INFO - 2021-01-21 04:27:36 --> Language Class Initialized
INFO - 2021-01-21 04:27:36 --> Language Class Initialized
INFO - 2021-01-21 04:27:36 --> Config Class Initialized
INFO - 2021-01-21 04:27:36 --> Loader Class Initialized
INFO - 2021-01-21 04:27:36 --> Helper loaded: url_helper
INFO - 2021-01-21 04:27:36 --> Helper loaded: file_helper
INFO - 2021-01-21 04:27:36 --> Helper loaded: form_helper
INFO - 2021-01-21 04:27:36 --> Helper loaded: my_helper
INFO - 2021-01-21 04:27:36 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:27:36 --> Controller Class Initialized
DEBUG - 2021-01-21 04:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:27:36 --> Final output sent to browser
DEBUG - 2021-01-21 04:27:36 --> Total execution time: 0.3922
INFO - 2021-01-21 04:28:01 --> Config Class Initialized
INFO - 2021-01-21 04:28:01 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:28:01 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:28:01 --> Utf8 Class Initialized
INFO - 2021-01-21 04:28:01 --> URI Class Initialized
INFO - 2021-01-21 04:28:01 --> Router Class Initialized
INFO - 2021-01-21 04:28:01 --> Output Class Initialized
INFO - 2021-01-21 04:28:01 --> Security Class Initialized
DEBUG - 2021-01-21 04:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:28:01 --> Input Class Initialized
INFO - 2021-01-21 04:28:01 --> Language Class Initialized
INFO - 2021-01-21 04:28:01 --> Language Class Initialized
INFO - 2021-01-21 04:28:01 --> Config Class Initialized
INFO - 2021-01-21 04:28:01 --> Loader Class Initialized
INFO - 2021-01-21 04:28:01 --> Helper loaded: url_helper
INFO - 2021-01-21 04:28:01 --> Helper loaded: file_helper
INFO - 2021-01-21 04:28:01 --> Helper loaded: form_helper
INFO - 2021-01-21 04:28:01 --> Helper loaded: my_helper
INFO - 2021-01-21 04:28:01 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:28:01 --> Controller Class Initialized
DEBUG - 2021-01-21 04:28:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:28:01 --> Final output sent to browser
DEBUG - 2021-01-21 04:28:01 --> Total execution time: 0.3981
INFO - 2021-01-21 04:43:03 --> Config Class Initialized
INFO - 2021-01-21 04:43:03 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:43:03 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:43:03 --> Utf8 Class Initialized
INFO - 2021-01-21 04:43:03 --> URI Class Initialized
INFO - 2021-01-21 04:43:03 --> Router Class Initialized
INFO - 2021-01-21 04:43:03 --> Output Class Initialized
INFO - 2021-01-21 04:43:03 --> Security Class Initialized
DEBUG - 2021-01-21 04:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:43:04 --> Input Class Initialized
INFO - 2021-01-21 04:43:04 --> Language Class Initialized
INFO - 2021-01-21 04:43:04 --> Language Class Initialized
INFO - 2021-01-21 04:43:04 --> Config Class Initialized
INFO - 2021-01-21 04:43:04 --> Loader Class Initialized
INFO - 2021-01-21 04:43:04 --> Helper loaded: url_helper
INFO - 2021-01-21 04:43:04 --> Helper loaded: file_helper
INFO - 2021-01-21 04:43:04 --> Helper loaded: form_helper
INFO - 2021-01-21 04:43:04 --> Helper loaded: my_helper
INFO - 2021-01-21 04:43:04 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:43:04 --> Controller Class Initialized
DEBUG - 2021-01-21 04:43:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 04:43:05 --> Final output sent to browser
DEBUG - 2021-01-21 04:43:05 --> Total execution time: 1.5547
INFO - 2021-01-21 04:44:33 --> Config Class Initialized
INFO - 2021-01-21 04:44:33 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:44:33 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:44:33 --> Utf8 Class Initialized
INFO - 2021-01-21 04:44:33 --> URI Class Initialized
INFO - 2021-01-21 04:44:33 --> Router Class Initialized
INFO - 2021-01-21 04:44:34 --> Output Class Initialized
INFO - 2021-01-21 04:44:34 --> Security Class Initialized
DEBUG - 2021-01-21 04:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:44:34 --> Input Class Initialized
INFO - 2021-01-21 04:44:34 --> Language Class Initialized
INFO - 2021-01-21 04:44:34 --> Language Class Initialized
INFO - 2021-01-21 04:44:34 --> Config Class Initialized
INFO - 2021-01-21 04:44:34 --> Loader Class Initialized
INFO - 2021-01-21 04:44:34 --> Helper loaded: url_helper
INFO - 2021-01-21 04:44:34 --> Helper loaded: file_helper
INFO - 2021-01-21 04:44:34 --> Helper loaded: form_helper
INFO - 2021-01-21 04:44:34 --> Helper loaded: my_helper
INFO - 2021-01-21 04:44:34 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:44:34 --> Controller Class Initialized
DEBUG - 2021-01-21 04:44:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:44:34 --> Final output sent to browser
DEBUG - 2021-01-21 04:44:34 --> Total execution time: 1.0380
INFO - 2021-01-21 04:51:43 --> Config Class Initialized
INFO - 2021-01-21 04:51:43 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:51:43 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:51:43 --> Utf8 Class Initialized
INFO - 2021-01-21 04:51:43 --> URI Class Initialized
INFO - 2021-01-21 04:51:43 --> Router Class Initialized
INFO - 2021-01-21 04:51:44 --> Output Class Initialized
INFO - 2021-01-21 04:51:44 --> Security Class Initialized
DEBUG - 2021-01-21 04:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:51:44 --> Input Class Initialized
INFO - 2021-01-21 04:51:44 --> Language Class Initialized
INFO - 2021-01-21 04:51:44 --> Language Class Initialized
INFO - 2021-01-21 04:51:44 --> Config Class Initialized
INFO - 2021-01-21 04:51:44 --> Loader Class Initialized
INFO - 2021-01-21 04:51:44 --> Helper loaded: url_helper
INFO - 2021-01-21 04:51:44 --> Helper loaded: file_helper
INFO - 2021-01-21 04:51:44 --> Helper loaded: form_helper
INFO - 2021-01-21 04:51:44 --> Helper loaded: my_helper
INFO - 2021-01-21 04:51:44 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:51:44 --> Controller Class Initialized
DEBUG - 2021-01-21 04:51:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:51:44 --> Final output sent to browser
DEBUG - 2021-01-21 04:51:45 --> Total execution time: 1.1798
INFO - 2021-01-21 04:56:18 --> Config Class Initialized
INFO - 2021-01-21 04:56:18 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:56:18 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:56:18 --> Utf8 Class Initialized
INFO - 2021-01-21 04:56:18 --> URI Class Initialized
INFO - 2021-01-21 04:56:18 --> Router Class Initialized
INFO - 2021-01-21 04:56:18 --> Output Class Initialized
INFO - 2021-01-21 04:56:18 --> Security Class Initialized
DEBUG - 2021-01-21 04:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:56:18 --> Input Class Initialized
INFO - 2021-01-21 04:56:18 --> Language Class Initialized
INFO - 2021-01-21 04:56:19 --> Language Class Initialized
INFO - 2021-01-21 04:56:19 --> Config Class Initialized
INFO - 2021-01-21 04:56:19 --> Loader Class Initialized
INFO - 2021-01-21 04:56:19 --> Helper loaded: url_helper
INFO - 2021-01-21 04:56:19 --> Helper loaded: file_helper
INFO - 2021-01-21 04:56:19 --> Helper loaded: form_helper
INFO - 2021-01-21 04:56:19 --> Helper loaded: my_helper
INFO - 2021-01-21 04:56:19 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:56:19 --> Controller Class Initialized
DEBUG - 2021-01-21 04:56:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:56:19 --> Final output sent to browser
DEBUG - 2021-01-21 04:56:19 --> Total execution time: 1.1897
INFO - 2021-01-21 04:56:45 --> Config Class Initialized
INFO - 2021-01-21 04:56:46 --> Hooks Class Initialized
DEBUG - 2021-01-21 04:56:46 --> UTF-8 Support Enabled
INFO - 2021-01-21 04:56:46 --> Utf8 Class Initialized
INFO - 2021-01-21 04:56:46 --> URI Class Initialized
INFO - 2021-01-21 04:56:46 --> Router Class Initialized
INFO - 2021-01-21 04:56:46 --> Output Class Initialized
INFO - 2021-01-21 04:56:46 --> Security Class Initialized
DEBUG - 2021-01-21 04:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 04:56:46 --> Input Class Initialized
INFO - 2021-01-21 04:56:46 --> Language Class Initialized
INFO - 2021-01-21 04:56:46 --> Language Class Initialized
INFO - 2021-01-21 04:56:46 --> Config Class Initialized
INFO - 2021-01-21 04:56:46 --> Loader Class Initialized
INFO - 2021-01-21 04:56:46 --> Helper loaded: url_helper
INFO - 2021-01-21 04:56:46 --> Helper loaded: file_helper
INFO - 2021-01-21 04:56:46 --> Helper loaded: form_helper
INFO - 2021-01-21 04:56:46 --> Helper loaded: my_helper
INFO - 2021-01-21 04:56:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 04:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 04:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 04:56:47 --> Controller Class Initialized
DEBUG - 2021-01-21 04:56:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 04:56:47 --> Final output sent to browser
DEBUG - 2021-01-21 04:56:47 --> Total execution time: 1.2916
INFO - 2021-01-21 05:03:54 --> Config Class Initialized
INFO - 2021-01-21 05:03:54 --> Hooks Class Initialized
DEBUG - 2021-01-21 05:03:54 --> UTF-8 Support Enabled
INFO - 2021-01-21 05:03:54 --> Utf8 Class Initialized
INFO - 2021-01-21 05:03:54 --> URI Class Initialized
INFO - 2021-01-21 05:03:54 --> Router Class Initialized
INFO - 2021-01-21 05:03:54 --> Output Class Initialized
INFO - 2021-01-21 05:03:55 --> Security Class Initialized
DEBUG - 2021-01-21 05:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 05:03:55 --> Input Class Initialized
INFO - 2021-01-21 05:03:55 --> Language Class Initialized
INFO - 2021-01-21 05:03:55 --> Language Class Initialized
INFO - 2021-01-21 05:03:55 --> Config Class Initialized
INFO - 2021-01-21 05:03:55 --> Loader Class Initialized
INFO - 2021-01-21 05:03:55 --> Helper loaded: url_helper
INFO - 2021-01-21 05:03:55 --> Helper loaded: file_helper
INFO - 2021-01-21 05:03:55 --> Helper loaded: form_helper
INFO - 2021-01-21 05:03:55 --> Helper loaded: my_helper
INFO - 2021-01-21 05:03:55 --> Database Driver Class Initialized
DEBUG - 2021-01-21 05:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 05:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 05:03:55 --> Controller Class Initialized
DEBUG - 2021-01-21 05:03:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 05:03:55 --> Final output sent to browser
DEBUG - 2021-01-21 05:03:55 --> Total execution time: 1.0368
INFO - 2021-01-21 05:04:41 --> Config Class Initialized
INFO - 2021-01-21 05:04:41 --> Hooks Class Initialized
DEBUG - 2021-01-21 05:04:41 --> UTF-8 Support Enabled
INFO - 2021-01-21 05:04:41 --> Utf8 Class Initialized
INFO - 2021-01-21 05:04:41 --> URI Class Initialized
INFO - 2021-01-21 05:04:41 --> Router Class Initialized
INFO - 2021-01-21 05:04:41 --> Output Class Initialized
INFO - 2021-01-21 05:04:42 --> Security Class Initialized
DEBUG - 2021-01-21 05:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 05:04:42 --> Input Class Initialized
INFO - 2021-01-21 05:04:42 --> Language Class Initialized
INFO - 2021-01-21 05:04:42 --> Language Class Initialized
INFO - 2021-01-21 05:04:42 --> Config Class Initialized
INFO - 2021-01-21 05:04:42 --> Loader Class Initialized
INFO - 2021-01-21 05:04:42 --> Helper loaded: url_helper
INFO - 2021-01-21 05:04:42 --> Helper loaded: file_helper
INFO - 2021-01-21 05:04:42 --> Helper loaded: form_helper
INFO - 2021-01-21 05:04:42 --> Helper loaded: my_helper
INFO - 2021-01-21 05:04:42 --> Database Driver Class Initialized
DEBUG - 2021-01-21 05:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 05:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 05:04:42 --> Controller Class Initialized
DEBUG - 2021-01-21 05:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-21 05:04:42 --> Final output sent to browser
DEBUG - 2021-01-21 05:04:42 --> Total execution time: 1.0301
INFO - 2021-01-21 05:10:49 --> Config Class Initialized
INFO - 2021-01-21 05:10:49 --> Hooks Class Initialized
DEBUG - 2021-01-21 05:10:49 --> UTF-8 Support Enabled
INFO - 2021-01-21 05:10:49 --> Utf8 Class Initialized
INFO - 2021-01-21 05:10:49 --> URI Class Initialized
INFO - 2021-01-21 05:10:49 --> Router Class Initialized
INFO - 2021-01-21 05:10:49 --> Output Class Initialized
INFO - 2021-01-21 05:10:49 --> Security Class Initialized
DEBUG - 2021-01-21 05:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 05:10:49 --> Input Class Initialized
INFO - 2021-01-21 05:10:49 --> Language Class Initialized
INFO - 2021-01-21 05:10:50 --> Language Class Initialized
INFO - 2021-01-21 05:10:50 --> Config Class Initialized
INFO - 2021-01-21 05:10:50 --> Loader Class Initialized
INFO - 2021-01-21 05:10:50 --> Helper loaded: url_helper
INFO - 2021-01-21 05:10:50 --> Helper loaded: file_helper
INFO - 2021-01-21 05:10:50 --> Helper loaded: form_helper
INFO - 2021-01-21 05:10:50 --> Helper loaded: my_helper
INFO - 2021-01-21 05:10:50 --> Database Driver Class Initialized
DEBUG - 2021-01-21 05:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 05:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 05:10:50 --> Controller Class Initialized
INFO - 2021-01-21 05:10:50 --> Helper loaded: cookie_helper
INFO - 2021-01-21 05:10:50 --> Config Class Initialized
INFO - 2021-01-21 05:10:50 --> Hooks Class Initialized
DEBUG - 2021-01-21 05:10:50 --> UTF-8 Support Enabled
INFO - 2021-01-21 05:10:50 --> Utf8 Class Initialized
INFO - 2021-01-21 05:10:50 --> URI Class Initialized
INFO - 2021-01-21 05:10:50 --> Router Class Initialized
INFO - 2021-01-21 05:10:50 --> Output Class Initialized
INFO - 2021-01-21 05:10:50 --> Security Class Initialized
DEBUG - 2021-01-21 05:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 05:10:51 --> Input Class Initialized
INFO - 2021-01-21 05:10:51 --> Language Class Initialized
INFO - 2021-01-21 05:10:51 --> Language Class Initialized
INFO - 2021-01-21 05:10:51 --> Config Class Initialized
INFO - 2021-01-21 05:10:51 --> Loader Class Initialized
INFO - 2021-01-21 05:10:51 --> Helper loaded: url_helper
INFO - 2021-01-21 05:10:51 --> Helper loaded: file_helper
INFO - 2021-01-21 05:10:51 --> Helper loaded: form_helper
INFO - 2021-01-21 05:10:51 --> Helper loaded: my_helper
INFO - 2021-01-21 05:10:51 --> Database Driver Class Initialized
DEBUG - 2021-01-21 05:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 05:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 05:10:51 --> Controller Class Initialized
DEBUG - 2021-01-21 05:10:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 05:10:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 05:10:51 --> Final output sent to browser
DEBUG - 2021-01-21 05:10:51 --> Total execution time: 1.2034
INFO - 2021-01-21 05:11:03 --> Config Class Initialized
INFO - 2021-01-21 05:11:03 --> Hooks Class Initialized
DEBUG - 2021-01-21 05:11:03 --> UTF-8 Support Enabled
INFO - 2021-01-21 05:11:03 --> Utf8 Class Initialized
INFO - 2021-01-21 05:11:03 --> URI Class Initialized
INFO - 2021-01-21 05:11:03 --> Router Class Initialized
INFO - 2021-01-21 05:11:03 --> Output Class Initialized
INFO - 2021-01-21 05:11:03 --> Security Class Initialized
DEBUG - 2021-01-21 05:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 05:11:03 --> Input Class Initialized
INFO - 2021-01-21 05:11:03 --> Language Class Initialized
INFO - 2021-01-21 05:11:04 --> Language Class Initialized
INFO - 2021-01-21 05:11:04 --> Config Class Initialized
INFO - 2021-01-21 05:11:04 --> Loader Class Initialized
INFO - 2021-01-21 05:11:04 --> Helper loaded: url_helper
INFO - 2021-01-21 05:11:04 --> Helper loaded: file_helper
INFO - 2021-01-21 05:11:04 --> Helper loaded: form_helper
INFO - 2021-01-21 05:11:04 --> Helper loaded: my_helper
INFO - 2021-01-21 05:11:04 --> Database Driver Class Initialized
DEBUG - 2021-01-21 05:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 05:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 05:11:04 --> Controller Class Initialized
INFO - 2021-01-21 05:11:04 --> Helper loaded: cookie_helper
INFO - 2021-01-21 05:11:04 --> Final output sent to browser
DEBUG - 2021-01-21 05:11:04 --> Total execution time: 1.0663
INFO - 2021-01-21 05:11:05 --> Config Class Initialized
INFO - 2021-01-21 05:11:05 --> Hooks Class Initialized
DEBUG - 2021-01-21 05:11:05 --> UTF-8 Support Enabled
INFO - 2021-01-21 05:11:05 --> Utf8 Class Initialized
INFO - 2021-01-21 05:11:05 --> URI Class Initialized
INFO - 2021-01-21 05:11:05 --> Router Class Initialized
INFO - 2021-01-21 05:11:05 --> Output Class Initialized
INFO - 2021-01-21 05:11:05 --> Security Class Initialized
DEBUG - 2021-01-21 05:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 05:11:05 --> Input Class Initialized
INFO - 2021-01-21 05:11:05 --> Language Class Initialized
INFO - 2021-01-21 05:11:05 --> Language Class Initialized
INFO - 2021-01-21 05:11:05 --> Config Class Initialized
INFO - 2021-01-21 05:11:06 --> Loader Class Initialized
INFO - 2021-01-21 05:11:06 --> Helper loaded: url_helper
INFO - 2021-01-21 05:11:06 --> Helper loaded: file_helper
INFO - 2021-01-21 05:11:06 --> Helper loaded: form_helper
INFO - 2021-01-21 05:11:06 --> Helper loaded: my_helper
INFO - 2021-01-21 05:11:06 --> Database Driver Class Initialized
DEBUG - 2021-01-21 05:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 05:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 05:11:06 --> Controller Class Initialized
DEBUG - 2021-01-21 05:11:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 05:11:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 05:11:06 --> Final output sent to browser
DEBUG - 2021-01-21 05:11:07 --> Total execution time: 1.8076
INFO - 2021-01-21 05:11:08 --> Config Class Initialized
INFO - 2021-01-21 05:11:08 --> Hooks Class Initialized
DEBUG - 2021-01-21 05:11:08 --> UTF-8 Support Enabled
INFO - 2021-01-21 05:11:09 --> Utf8 Class Initialized
INFO - 2021-01-21 05:11:09 --> URI Class Initialized
INFO - 2021-01-21 05:11:09 --> Router Class Initialized
INFO - 2021-01-21 05:11:09 --> Output Class Initialized
INFO - 2021-01-21 05:11:09 --> Security Class Initialized
DEBUG - 2021-01-21 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 05:11:09 --> Input Class Initialized
INFO - 2021-01-21 05:11:09 --> Language Class Initialized
INFO - 2021-01-21 05:11:09 --> Language Class Initialized
INFO - 2021-01-21 05:11:09 --> Config Class Initialized
INFO - 2021-01-21 05:11:09 --> Loader Class Initialized
INFO - 2021-01-21 05:11:09 --> Helper loaded: url_helper
INFO - 2021-01-21 05:11:09 --> Helper loaded: file_helper
INFO - 2021-01-21 05:11:09 --> Helper loaded: form_helper
INFO - 2021-01-21 05:11:09 --> Helper loaded: my_helper
INFO - 2021-01-21 05:11:09 --> Database Driver Class Initialized
DEBUG - 2021-01-21 05:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 05:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 05:11:09 --> Controller Class Initialized
DEBUG - 2021-01-21 05:11:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 05:11:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 05:11:10 --> Final output sent to browser
DEBUG - 2021-01-21 05:11:10 --> Total execution time: 1.1198
INFO - 2021-01-21 05:11:19 --> Config Class Initialized
INFO - 2021-01-21 05:11:19 --> Hooks Class Initialized
DEBUG - 2021-01-21 05:11:19 --> UTF-8 Support Enabled
INFO - 2021-01-21 05:11:19 --> Utf8 Class Initialized
INFO - 2021-01-21 05:11:19 --> URI Class Initialized
INFO - 2021-01-21 05:11:19 --> Router Class Initialized
INFO - 2021-01-21 05:11:19 --> Output Class Initialized
INFO - 2021-01-21 05:11:19 --> Security Class Initialized
DEBUG - 2021-01-21 05:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 05:11:19 --> Input Class Initialized
INFO - 2021-01-21 05:11:19 --> Language Class Initialized
INFO - 2021-01-21 05:11:19 --> Language Class Initialized
INFO - 2021-01-21 05:11:19 --> Config Class Initialized
INFO - 2021-01-21 05:11:19 --> Loader Class Initialized
INFO - 2021-01-21 05:11:19 --> Helper loaded: url_helper
INFO - 2021-01-21 05:11:19 --> Helper loaded: file_helper
INFO - 2021-01-21 05:11:19 --> Helper loaded: form_helper
INFO - 2021-01-21 05:11:19 --> Helper loaded: my_helper
INFO - 2021-01-21 05:11:20 --> Database Driver Class Initialized
DEBUG - 2021-01-21 05:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 05:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 05:11:20 --> Controller Class Initialized
DEBUG - 2021-01-21 05:11:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 05:11:20 --> Final output sent to browser
DEBUG - 2021-01-21 05:11:20 --> Total execution time: 1.1938
INFO - 2021-01-21 05:30:27 --> Config Class Initialized
INFO - 2021-01-21 05:30:27 --> Hooks Class Initialized
DEBUG - 2021-01-21 05:30:27 --> UTF-8 Support Enabled
INFO - 2021-01-21 05:30:27 --> Utf8 Class Initialized
INFO - 2021-01-21 05:30:27 --> URI Class Initialized
INFO - 2021-01-21 05:30:27 --> Router Class Initialized
INFO - 2021-01-21 05:30:27 --> Output Class Initialized
INFO - 2021-01-21 05:30:27 --> Security Class Initialized
DEBUG - 2021-01-21 05:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 05:30:27 --> Input Class Initialized
INFO - 2021-01-21 05:30:27 --> Language Class Initialized
INFO - 2021-01-21 05:30:27 --> Language Class Initialized
INFO - 2021-01-21 05:30:27 --> Config Class Initialized
INFO - 2021-01-21 05:30:27 --> Loader Class Initialized
INFO - 2021-01-21 05:30:27 --> Helper loaded: url_helper
INFO - 2021-01-21 05:30:27 --> Helper loaded: file_helper
INFO - 2021-01-21 05:30:28 --> Helper loaded: form_helper
INFO - 2021-01-21 05:30:28 --> Helper loaded: my_helper
INFO - 2021-01-21 05:30:28 --> Database Driver Class Initialized
DEBUG - 2021-01-21 05:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 05:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 05:30:28 --> Controller Class Initialized
DEBUG - 2021-01-21 05:30:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 05:30:28 --> Final output sent to browser
DEBUG - 2021-01-21 05:30:28 --> Total execution time: 1.2562
INFO - 2021-01-21 07:39:46 --> Config Class Initialized
INFO - 2021-01-21 07:39:46 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:39:46 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:39:46 --> Utf8 Class Initialized
INFO - 2021-01-21 07:39:46 --> URI Class Initialized
INFO - 2021-01-21 07:39:46 --> Router Class Initialized
INFO - 2021-01-21 07:39:46 --> Output Class Initialized
INFO - 2021-01-21 07:39:46 --> Security Class Initialized
DEBUG - 2021-01-21 07:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:39:46 --> Input Class Initialized
INFO - 2021-01-21 07:39:46 --> Language Class Initialized
INFO - 2021-01-21 07:39:46 --> Language Class Initialized
INFO - 2021-01-21 07:39:46 --> Config Class Initialized
INFO - 2021-01-21 07:39:46 --> Loader Class Initialized
INFO - 2021-01-21 07:39:46 --> Helper loaded: url_helper
INFO - 2021-01-21 07:39:46 --> Helper loaded: file_helper
INFO - 2021-01-21 07:39:46 --> Helper loaded: form_helper
INFO - 2021-01-21 07:39:46 --> Helper loaded: my_helper
INFO - 2021-01-21 07:39:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:39:46 --> Controller Class Initialized
DEBUG - 2021-01-21 07:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 07:39:47 --> Final output sent to browser
DEBUG - 2021-01-21 07:39:47 --> Total execution time: 0.4964
INFO - 2021-01-21 07:40:25 --> Config Class Initialized
INFO - 2021-01-21 07:40:25 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:40:25 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:40:25 --> Utf8 Class Initialized
INFO - 2021-01-21 07:40:25 --> URI Class Initialized
INFO - 2021-01-21 07:40:25 --> Router Class Initialized
INFO - 2021-01-21 07:40:25 --> Output Class Initialized
INFO - 2021-01-21 07:40:25 --> Security Class Initialized
DEBUG - 2021-01-21 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:40:25 --> Input Class Initialized
INFO - 2021-01-21 07:40:25 --> Language Class Initialized
INFO - 2021-01-21 07:40:25 --> Language Class Initialized
INFO - 2021-01-21 07:40:25 --> Config Class Initialized
INFO - 2021-01-21 07:40:25 --> Loader Class Initialized
INFO - 2021-01-21 07:40:25 --> Helper loaded: url_helper
INFO - 2021-01-21 07:40:25 --> Helper loaded: file_helper
INFO - 2021-01-21 07:40:25 --> Helper loaded: form_helper
INFO - 2021-01-21 07:40:25 --> Helper loaded: my_helper
INFO - 2021-01-21 07:40:25 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:40:25 --> Controller Class Initialized
INFO - 2021-01-21 07:40:25 --> Helper loaded: cookie_helper
INFO - 2021-01-21 07:40:25 --> Config Class Initialized
INFO - 2021-01-21 07:40:25 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:40:26 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:40:26 --> Utf8 Class Initialized
INFO - 2021-01-21 07:40:26 --> URI Class Initialized
INFO - 2021-01-21 07:40:26 --> Router Class Initialized
INFO - 2021-01-21 07:40:26 --> Output Class Initialized
INFO - 2021-01-21 07:40:26 --> Security Class Initialized
DEBUG - 2021-01-21 07:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:40:26 --> Input Class Initialized
INFO - 2021-01-21 07:40:26 --> Language Class Initialized
INFO - 2021-01-21 07:40:26 --> Language Class Initialized
INFO - 2021-01-21 07:40:26 --> Config Class Initialized
INFO - 2021-01-21 07:40:26 --> Loader Class Initialized
INFO - 2021-01-21 07:40:26 --> Helper loaded: url_helper
INFO - 2021-01-21 07:40:26 --> Helper loaded: file_helper
INFO - 2021-01-21 07:40:26 --> Helper loaded: form_helper
INFO - 2021-01-21 07:40:26 --> Helper loaded: my_helper
INFO - 2021-01-21 07:40:26 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:40:26 --> Controller Class Initialized
DEBUG - 2021-01-21 07:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 07:40:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 07:40:26 --> Final output sent to browser
DEBUG - 2021-01-21 07:40:26 --> Total execution time: 0.4389
INFO - 2021-01-21 07:40:32 --> Config Class Initialized
INFO - 2021-01-21 07:40:32 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:40:32 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:40:32 --> Utf8 Class Initialized
INFO - 2021-01-21 07:40:32 --> URI Class Initialized
INFO - 2021-01-21 07:40:32 --> Router Class Initialized
INFO - 2021-01-21 07:40:32 --> Output Class Initialized
INFO - 2021-01-21 07:40:32 --> Security Class Initialized
DEBUG - 2021-01-21 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:40:32 --> Input Class Initialized
INFO - 2021-01-21 07:40:32 --> Language Class Initialized
INFO - 2021-01-21 07:40:32 --> Language Class Initialized
INFO - 2021-01-21 07:40:32 --> Config Class Initialized
INFO - 2021-01-21 07:40:32 --> Loader Class Initialized
INFO - 2021-01-21 07:40:32 --> Helper loaded: url_helper
INFO - 2021-01-21 07:40:32 --> Helper loaded: file_helper
INFO - 2021-01-21 07:40:32 --> Helper loaded: form_helper
INFO - 2021-01-21 07:40:32 --> Helper loaded: my_helper
INFO - 2021-01-21 07:40:32 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:40:32 --> Controller Class Initialized
INFO - 2021-01-21 07:40:32 --> Helper loaded: cookie_helper
INFO - 2021-01-21 07:40:32 --> Final output sent to browser
DEBUG - 2021-01-21 07:40:32 --> Total execution time: 0.5115
INFO - 2021-01-21 07:40:33 --> Config Class Initialized
INFO - 2021-01-21 07:40:33 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:40:33 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:40:33 --> Utf8 Class Initialized
INFO - 2021-01-21 07:40:33 --> URI Class Initialized
INFO - 2021-01-21 07:40:33 --> Router Class Initialized
INFO - 2021-01-21 07:40:33 --> Output Class Initialized
INFO - 2021-01-21 07:40:33 --> Security Class Initialized
DEBUG - 2021-01-21 07:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:40:33 --> Input Class Initialized
INFO - 2021-01-21 07:40:33 --> Language Class Initialized
INFO - 2021-01-21 07:40:33 --> Language Class Initialized
INFO - 2021-01-21 07:40:33 --> Config Class Initialized
INFO - 2021-01-21 07:40:33 --> Loader Class Initialized
INFO - 2021-01-21 07:40:33 --> Helper loaded: url_helper
INFO - 2021-01-21 07:40:33 --> Helper loaded: file_helper
INFO - 2021-01-21 07:40:33 --> Helper loaded: form_helper
INFO - 2021-01-21 07:40:33 --> Helper loaded: my_helper
INFO - 2021-01-21 07:40:33 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:40:33 --> Controller Class Initialized
DEBUG - 2021-01-21 07:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 07:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 07:40:33 --> Final output sent to browser
DEBUG - 2021-01-21 07:40:33 --> Total execution time: 0.5340
INFO - 2021-01-21 07:40:36 --> Config Class Initialized
INFO - 2021-01-21 07:40:36 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:40:36 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:40:36 --> Utf8 Class Initialized
INFO - 2021-01-21 07:40:36 --> URI Class Initialized
INFO - 2021-01-21 07:40:36 --> Router Class Initialized
INFO - 2021-01-21 07:40:36 --> Output Class Initialized
INFO - 2021-01-21 07:40:36 --> Security Class Initialized
DEBUG - 2021-01-21 07:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:40:36 --> Input Class Initialized
INFO - 2021-01-21 07:40:36 --> Language Class Initialized
INFO - 2021-01-21 07:40:36 --> Language Class Initialized
INFO - 2021-01-21 07:40:36 --> Config Class Initialized
INFO - 2021-01-21 07:40:37 --> Loader Class Initialized
INFO - 2021-01-21 07:40:37 --> Helper loaded: url_helper
INFO - 2021-01-21 07:40:37 --> Helper loaded: file_helper
INFO - 2021-01-21 07:40:37 --> Helper loaded: form_helper
INFO - 2021-01-21 07:40:37 --> Helper loaded: my_helper
INFO - 2021-01-21 07:40:37 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:40:37 --> Controller Class Initialized
DEBUG - 2021-01-21 07:40:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-21 07:40:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 07:40:37 --> Final output sent to browser
DEBUG - 2021-01-21 07:40:37 --> Total execution time: 0.4685
INFO - 2021-01-21 07:40:37 --> Config Class Initialized
INFO - 2021-01-21 07:40:37 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:40:37 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:40:37 --> Utf8 Class Initialized
INFO - 2021-01-21 07:40:37 --> URI Class Initialized
INFO - 2021-01-21 07:40:37 --> Router Class Initialized
INFO - 2021-01-21 07:40:37 --> Output Class Initialized
INFO - 2021-01-21 07:40:37 --> Security Class Initialized
DEBUG - 2021-01-21 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:40:37 --> Input Class Initialized
INFO - 2021-01-21 07:40:37 --> Language Class Initialized
INFO - 2021-01-21 07:40:37 --> Language Class Initialized
INFO - 2021-01-21 07:40:37 --> Config Class Initialized
INFO - 2021-01-21 07:40:37 --> Loader Class Initialized
INFO - 2021-01-21 07:40:37 --> Helper loaded: url_helper
INFO - 2021-01-21 07:40:37 --> Helper loaded: file_helper
INFO - 2021-01-21 07:40:37 --> Helper loaded: form_helper
INFO - 2021-01-21 07:40:37 --> Helper loaded: my_helper
INFO - 2021-01-21 07:40:37 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:40:37 --> Controller Class Initialized
INFO - 2021-01-21 07:41:13 --> Config Class Initialized
INFO - 2021-01-21 07:41:13 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:41:13 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:41:13 --> Utf8 Class Initialized
INFO - 2021-01-21 07:41:13 --> URI Class Initialized
INFO - 2021-01-21 07:41:13 --> Router Class Initialized
INFO - 2021-01-21 07:41:13 --> Output Class Initialized
INFO - 2021-01-21 07:41:13 --> Security Class Initialized
DEBUG - 2021-01-21 07:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:41:13 --> Input Class Initialized
INFO - 2021-01-21 07:41:13 --> Language Class Initialized
INFO - 2021-01-21 07:41:13 --> Language Class Initialized
INFO - 2021-01-21 07:41:13 --> Config Class Initialized
INFO - 2021-01-21 07:41:13 --> Loader Class Initialized
INFO - 2021-01-21 07:41:13 --> Helper loaded: url_helper
INFO - 2021-01-21 07:41:13 --> Helper loaded: file_helper
INFO - 2021-01-21 07:41:13 --> Helper loaded: form_helper
INFO - 2021-01-21 07:41:13 --> Helper loaded: my_helper
INFO - 2021-01-21 07:41:13 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:41:13 --> Controller Class Initialized
INFO - 2021-01-21 07:45:05 --> Config Class Initialized
INFO - 2021-01-21 07:45:05 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:45:05 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:45:05 --> Utf8 Class Initialized
INFO - 2021-01-21 07:45:05 --> URI Class Initialized
INFO - 2021-01-21 07:45:05 --> Router Class Initialized
INFO - 2021-01-21 07:45:05 --> Output Class Initialized
INFO - 2021-01-21 07:45:05 --> Security Class Initialized
DEBUG - 2021-01-21 07:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:45:05 --> Input Class Initialized
INFO - 2021-01-21 07:45:05 --> Language Class Initialized
INFO - 2021-01-21 07:45:05 --> Language Class Initialized
INFO - 2021-01-21 07:45:05 --> Config Class Initialized
INFO - 2021-01-21 07:45:05 --> Loader Class Initialized
INFO - 2021-01-21 07:45:05 --> Helper loaded: url_helper
INFO - 2021-01-21 07:45:05 --> Helper loaded: file_helper
INFO - 2021-01-21 07:45:05 --> Helper loaded: form_helper
INFO - 2021-01-21 07:45:05 --> Helper loaded: my_helper
INFO - 2021-01-21 07:45:05 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:45:05 --> Controller Class Initialized
INFO - 2021-01-21 07:45:05 --> Helper loaded: cookie_helper
INFO - 2021-01-21 07:45:05 --> Config Class Initialized
INFO - 2021-01-21 07:45:05 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:45:05 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:45:05 --> Utf8 Class Initialized
INFO - 2021-01-21 07:45:05 --> URI Class Initialized
INFO - 2021-01-21 07:45:05 --> Router Class Initialized
INFO - 2021-01-21 07:45:05 --> Output Class Initialized
INFO - 2021-01-21 07:45:05 --> Security Class Initialized
DEBUG - 2021-01-21 07:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:45:05 --> Input Class Initialized
INFO - 2021-01-21 07:45:05 --> Language Class Initialized
INFO - 2021-01-21 07:45:05 --> Language Class Initialized
INFO - 2021-01-21 07:45:05 --> Config Class Initialized
INFO - 2021-01-21 07:45:05 --> Loader Class Initialized
INFO - 2021-01-21 07:45:05 --> Helper loaded: url_helper
INFO - 2021-01-21 07:45:05 --> Helper loaded: file_helper
INFO - 2021-01-21 07:45:05 --> Helper loaded: form_helper
INFO - 2021-01-21 07:45:05 --> Helper loaded: my_helper
INFO - 2021-01-21 07:45:05 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:45:05 --> Controller Class Initialized
DEBUG - 2021-01-21 07:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 07:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 07:45:05 --> Final output sent to browser
DEBUG - 2021-01-21 07:45:05 --> Total execution time: 0.4000
INFO - 2021-01-21 07:45:09 --> Config Class Initialized
INFO - 2021-01-21 07:45:09 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:45:09 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:45:09 --> Utf8 Class Initialized
INFO - 2021-01-21 07:45:09 --> URI Class Initialized
INFO - 2021-01-21 07:45:09 --> Router Class Initialized
INFO - 2021-01-21 07:45:09 --> Output Class Initialized
INFO - 2021-01-21 07:45:09 --> Security Class Initialized
DEBUG - 2021-01-21 07:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:45:09 --> Input Class Initialized
INFO - 2021-01-21 07:45:09 --> Language Class Initialized
INFO - 2021-01-21 07:45:09 --> Language Class Initialized
INFO - 2021-01-21 07:45:09 --> Config Class Initialized
INFO - 2021-01-21 07:45:09 --> Loader Class Initialized
INFO - 2021-01-21 07:45:09 --> Helper loaded: url_helper
INFO - 2021-01-21 07:45:10 --> Helper loaded: file_helper
INFO - 2021-01-21 07:45:10 --> Helper loaded: form_helper
INFO - 2021-01-21 07:45:10 --> Helper loaded: my_helper
INFO - 2021-01-21 07:45:10 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:45:10 --> Controller Class Initialized
INFO - 2021-01-21 07:45:10 --> Helper loaded: cookie_helper
INFO - 2021-01-21 07:45:10 --> Final output sent to browser
DEBUG - 2021-01-21 07:45:10 --> Total execution time: 0.4970
INFO - 2021-01-21 07:45:10 --> Config Class Initialized
INFO - 2021-01-21 07:45:10 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:45:10 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:45:10 --> Utf8 Class Initialized
INFO - 2021-01-21 07:45:10 --> URI Class Initialized
INFO - 2021-01-21 07:45:10 --> Router Class Initialized
INFO - 2021-01-21 07:45:10 --> Output Class Initialized
INFO - 2021-01-21 07:45:10 --> Security Class Initialized
DEBUG - 2021-01-21 07:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:45:10 --> Input Class Initialized
INFO - 2021-01-21 07:45:10 --> Language Class Initialized
INFO - 2021-01-21 07:45:10 --> Language Class Initialized
INFO - 2021-01-21 07:45:10 --> Config Class Initialized
INFO - 2021-01-21 07:45:10 --> Loader Class Initialized
INFO - 2021-01-21 07:45:10 --> Helper loaded: url_helper
INFO - 2021-01-21 07:45:10 --> Helper loaded: file_helper
INFO - 2021-01-21 07:45:11 --> Helper loaded: form_helper
INFO - 2021-01-21 07:45:11 --> Helper loaded: my_helper
INFO - 2021-01-21 07:45:11 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:45:11 --> Controller Class Initialized
DEBUG - 2021-01-21 07:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 07:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 07:45:11 --> Final output sent to browser
DEBUG - 2021-01-21 07:45:11 --> Total execution time: 0.5972
INFO - 2021-01-21 07:45:12 --> Config Class Initialized
INFO - 2021-01-21 07:45:12 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:45:12 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:45:12 --> Utf8 Class Initialized
INFO - 2021-01-21 07:45:12 --> URI Class Initialized
INFO - 2021-01-21 07:45:12 --> Router Class Initialized
INFO - 2021-01-21 07:45:12 --> Output Class Initialized
INFO - 2021-01-21 07:45:12 --> Security Class Initialized
DEBUG - 2021-01-21 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:45:12 --> Input Class Initialized
INFO - 2021-01-21 07:45:12 --> Language Class Initialized
INFO - 2021-01-21 07:45:12 --> Language Class Initialized
INFO - 2021-01-21 07:45:12 --> Config Class Initialized
INFO - 2021-01-21 07:45:12 --> Loader Class Initialized
INFO - 2021-01-21 07:45:12 --> Helper loaded: url_helper
INFO - 2021-01-21 07:45:12 --> Helper loaded: file_helper
INFO - 2021-01-21 07:45:12 --> Helper loaded: form_helper
INFO - 2021-01-21 07:45:13 --> Helper loaded: my_helper
INFO - 2021-01-21 07:45:13 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:45:13 --> Controller Class Initialized
DEBUG - 2021-01-21 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 07:45:13 --> Final output sent to browser
DEBUG - 2021-01-21 07:45:13 --> Total execution time: 0.5095
INFO - 2021-01-21 07:45:14 --> Config Class Initialized
INFO - 2021-01-21 07:45:14 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:45:14 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:45:14 --> Utf8 Class Initialized
INFO - 2021-01-21 07:45:14 --> URI Class Initialized
INFO - 2021-01-21 07:45:14 --> Router Class Initialized
INFO - 2021-01-21 07:45:14 --> Output Class Initialized
INFO - 2021-01-21 07:45:14 --> Security Class Initialized
DEBUG - 2021-01-21 07:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:45:14 --> Input Class Initialized
INFO - 2021-01-21 07:45:14 --> Language Class Initialized
INFO - 2021-01-21 07:45:14 --> Language Class Initialized
INFO - 2021-01-21 07:45:14 --> Config Class Initialized
INFO - 2021-01-21 07:45:14 --> Loader Class Initialized
INFO - 2021-01-21 07:45:14 --> Helper loaded: url_helper
INFO - 2021-01-21 07:45:14 --> Helper loaded: file_helper
INFO - 2021-01-21 07:45:14 --> Helper loaded: form_helper
INFO - 2021-01-21 07:45:14 --> Helper loaded: my_helper
INFO - 2021-01-21 07:45:14 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:45:14 --> Controller Class Initialized
DEBUG - 2021-01-21 07:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:45:15 --> Final output sent to browser
DEBUG - 2021-01-21 07:45:15 --> Total execution time: 0.4914
INFO - 2021-01-21 07:47:10 --> Config Class Initialized
INFO - 2021-01-21 07:47:10 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:47:10 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:47:10 --> Utf8 Class Initialized
INFO - 2021-01-21 07:47:10 --> URI Class Initialized
INFO - 2021-01-21 07:47:10 --> Router Class Initialized
INFO - 2021-01-21 07:47:10 --> Output Class Initialized
INFO - 2021-01-21 07:47:10 --> Security Class Initialized
DEBUG - 2021-01-21 07:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:47:10 --> Input Class Initialized
INFO - 2021-01-21 07:47:10 --> Language Class Initialized
INFO - 2021-01-21 07:47:10 --> Language Class Initialized
INFO - 2021-01-21 07:47:10 --> Config Class Initialized
INFO - 2021-01-21 07:47:10 --> Loader Class Initialized
INFO - 2021-01-21 07:47:10 --> Helper loaded: url_helper
INFO - 2021-01-21 07:47:10 --> Helper loaded: file_helper
INFO - 2021-01-21 07:47:10 --> Helper loaded: form_helper
INFO - 2021-01-21 07:47:10 --> Helper loaded: my_helper
INFO - 2021-01-21 07:47:10 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:47:10 --> Controller Class Initialized
DEBUG - 2021-01-21 07:47:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:47:11 --> Final output sent to browser
DEBUG - 2021-01-21 07:47:11 --> Total execution time: 0.5461
INFO - 2021-01-21 07:48:58 --> Config Class Initialized
INFO - 2021-01-21 07:48:58 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:48:58 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:48:58 --> Utf8 Class Initialized
INFO - 2021-01-21 07:48:58 --> URI Class Initialized
INFO - 2021-01-21 07:48:58 --> Router Class Initialized
INFO - 2021-01-21 07:48:58 --> Output Class Initialized
INFO - 2021-01-21 07:48:58 --> Security Class Initialized
DEBUG - 2021-01-21 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:48:58 --> Input Class Initialized
INFO - 2021-01-21 07:48:58 --> Language Class Initialized
INFO - 2021-01-21 07:48:58 --> Language Class Initialized
INFO - 2021-01-21 07:48:58 --> Config Class Initialized
INFO - 2021-01-21 07:48:58 --> Loader Class Initialized
INFO - 2021-01-21 07:48:58 --> Helper loaded: url_helper
INFO - 2021-01-21 07:48:58 --> Helper loaded: file_helper
INFO - 2021-01-21 07:48:58 --> Helper loaded: form_helper
INFO - 2021-01-21 07:48:58 --> Helper loaded: my_helper
INFO - 2021-01-21 07:48:58 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:48:58 --> Controller Class Initialized
DEBUG - 2021-01-21 07:48:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:48:58 --> Final output sent to browser
DEBUG - 2021-01-21 07:48:58 --> Total execution time: 0.5102
INFO - 2021-01-21 07:56:46 --> Config Class Initialized
INFO - 2021-01-21 07:56:46 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:56:46 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:56:46 --> Utf8 Class Initialized
INFO - 2021-01-21 07:56:46 --> URI Class Initialized
INFO - 2021-01-21 07:56:46 --> Router Class Initialized
INFO - 2021-01-21 07:56:46 --> Output Class Initialized
INFO - 2021-01-21 07:56:46 --> Security Class Initialized
DEBUG - 2021-01-21 07:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:56:46 --> Input Class Initialized
INFO - 2021-01-21 07:56:46 --> Language Class Initialized
INFO - 2021-01-21 07:56:46 --> Language Class Initialized
INFO - 2021-01-21 07:56:46 --> Config Class Initialized
INFO - 2021-01-21 07:56:46 --> Loader Class Initialized
INFO - 2021-01-21 07:56:46 --> Helper loaded: url_helper
INFO - 2021-01-21 07:56:46 --> Helper loaded: file_helper
INFO - 2021-01-21 07:56:46 --> Helper loaded: form_helper
INFO - 2021-01-21 07:56:46 --> Helper loaded: my_helper
INFO - 2021-01-21 07:56:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:56:46 --> Controller Class Initialized
DEBUG - 2021-01-21 07:56:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:56:46 --> Final output sent to browser
DEBUG - 2021-01-21 07:56:46 --> Total execution time: 0.4659
INFO - 2021-01-21 07:57:12 --> Config Class Initialized
INFO - 2021-01-21 07:57:12 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:57:12 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:57:12 --> Utf8 Class Initialized
INFO - 2021-01-21 07:57:13 --> URI Class Initialized
INFO - 2021-01-21 07:57:13 --> Router Class Initialized
INFO - 2021-01-21 07:57:13 --> Output Class Initialized
INFO - 2021-01-21 07:57:13 --> Security Class Initialized
DEBUG - 2021-01-21 07:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:57:13 --> Input Class Initialized
INFO - 2021-01-21 07:57:13 --> Language Class Initialized
INFO - 2021-01-21 07:57:13 --> Language Class Initialized
INFO - 2021-01-21 07:57:13 --> Config Class Initialized
INFO - 2021-01-21 07:57:13 --> Loader Class Initialized
INFO - 2021-01-21 07:57:13 --> Helper loaded: url_helper
INFO - 2021-01-21 07:57:13 --> Helper loaded: file_helper
INFO - 2021-01-21 07:57:13 --> Helper loaded: form_helper
INFO - 2021-01-21 07:57:13 --> Helper loaded: my_helper
INFO - 2021-01-21 07:57:13 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:57:13 --> Controller Class Initialized
DEBUG - 2021-01-21 07:57:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:57:13 --> Final output sent to browser
DEBUG - 2021-01-21 07:57:13 --> Total execution time: 0.5157
INFO - 2021-01-21 07:58:00 --> Config Class Initialized
INFO - 2021-01-21 07:58:00 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:58:00 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:58:00 --> Utf8 Class Initialized
INFO - 2021-01-21 07:58:00 --> URI Class Initialized
INFO - 2021-01-21 07:58:00 --> Router Class Initialized
INFO - 2021-01-21 07:58:00 --> Output Class Initialized
INFO - 2021-01-21 07:58:00 --> Security Class Initialized
DEBUG - 2021-01-21 07:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:58:00 --> Input Class Initialized
INFO - 2021-01-21 07:58:00 --> Language Class Initialized
INFO - 2021-01-21 07:58:00 --> Language Class Initialized
INFO - 2021-01-21 07:58:00 --> Config Class Initialized
INFO - 2021-01-21 07:58:00 --> Loader Class Initialized
INFO - 2021-01-21 07:58:00 --> Helper loaded: url_helper
INFO - 2021-01-21 07:58:00 --> Helper loaded: file_helper
INFO - 2021-01-21 07:58:00 --> Helper loaded: form_helper
INFO - 2021-01-21 07:58:00 --> Helper loaded: my_helper
INFO - 2021-01-21 07:58:00 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:58:00 --> Controller Class Initialized
DEBUG - 2021-01-21 07:58:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:58:01 --> Final output sent to browser
DEBUG - 2021-01-21 07:58:01 --> Total execution time: 0.4991
INFO - 2021-01-21 07:58:24 --> Config Class Initialized
INFO - 2021-01-21 07:58:24 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:58:24 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:58:24 --> Utf8 Class Initialized
INFO - 2021-01-21 07:58:24 --> URI Class Initialized
INFO - 2021-01-21 07:58:24 --> Router Class Initialized
INFO - 2021-01-21 07:58:24 --> Output Class Initialized
INFO - 2021-01-21 07:58:24 --> Security Class Initialized
DEBUG - 2021-01-21 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:58:24 --> Input Class Initialized
INFO - 2021-01-21 07:58:24 --> Language Class Initialized
INFO - 2021-01-21 07:58:24 --> Language Class Initialized
INFO - 2021-01-21 07:58:24 --> Config Class Initialized
INFO - 2021-01-21 07:58:24 --> Loader Class Initialized
INFO - 2021-01-21 07:58:24 --> Helper loaded: url_helper
INFO - 2021-01-21 07:58:24 --> Helper loaded: file_helper
INFO - 2021-01-21 07:58:24 --> Helper loaded: form_helper
INFO - 2021-01-21 07:58:24 --> Helper loaded: my_helper
INFO - 2021-01-21 07:58:24 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:58:24 --> Controller Class Initialized
DEBUG - 2021-01-21 07:58:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:58:24 --> Final output sent to browser
DEBUG - 2021-01-21 07:58:24 --> Total execution time: 0.4928
INFO - 2021-01-21 07:58:34 --> Config Class Initialized
INFO - 2021-01-21 07:58:34 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:58:34 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:58:34 --> Utf8 Class Initialized
INFO - 2021-01-21 07:58:34 --> URI Class Initialized
INFO - 2021-01-21 07:58:34 --> Router Class Initialized
INFO - 2021-01-21 07:58:34 --> Output Class Initialized
INFO - 2021-01-21 07:58:34 --> Security Class Initialized
DEBUG - 2021-01-21 07:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:58:35 --> Input Class Initialized
INFO - 2021-01-21 07:58:35 --> Language Class Initialized
INFO - 2021-01-21 07:58:35 --> Language Class Initialized
INFO - 2021-01-21 07:58:35 --> Config Class Initialized
INFO - 2021-01-21 07:58:35 --> Loader Class Initialized
INFO - 2021-01-21 07:58:35 --> Helper loaded: url_helper
INFO - 2021-01-21 07:58:35 --> Helper loaded: file_helper
INFO - 2021-01-21 07:58:35 --> Helper loaded: form_helper
INFO - 2021-01-21 07:58:35 --> Helper loaded: my_helper
INFO - 2021-01-21 07:58:35 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:58:35 --> Controller Class Initialized
DEBUG - 2021-01-21 07:58:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:58:35 --> Final output sent to browser
DEBUG - 2021-01-21 07:58:35 --> Total execution time: 0.5005
INFO - 2021-01-21 07:58:46 --> Config Class Initialized
INFO - 2021-01-21 07:58:46 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:58:46 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:58:46 --> Utf8 Class Initialized
INFO - 2021-01-21 07:58:46 --> URI Class Initialized
INFO - 2021-01-21 07:58:46 --> Router Class Initialized
INFO - 2021-01-21 07:58:46 --> Output Class Initialized
INFO - 2021-01-21 07:58:46 --> Security Class Initialized
DEBUG - 2021-01-21 07:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:58:46 --> Input Class Initialized
INFO - 2021-01-21 07:58:46 --> Language Class Initialized
INFO - 2021-01-21 07:58:46 --> Language Class Initialized
INFO - 2021-01-21 07:58:46 --> Config Class Initialized
INFO - 2021-01-21 07:58:46 --> Loader Class Initialized
INFO - 2021-01-21 07:58:46 --> Helper loaded: url_helper
INFO - 2021-01-21 07:58:46 --> Helper loaded: file_helper
INFO - 2021-01-21 07:58:46 --> Helper loaded: form_helper
INFO - 2021-01-21 07:58:46 --> Helper loaded: my_helper
INFO - 2021-01-21 07:58:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:58:46 --> Controller Class Initialized
DEBUG - 2021-01-21 07:58:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:58:46 --> Final output sent to browser
DEBUG - 2021-01-21 07:58:46 --> Total execution time: 0.5186
INFO - 2021-01-21 07:58:55 --> Config Class Initialized
INFO - 2021-01-21 07:58:55 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:58:55 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:58:55 --> Utf8 Class Initialized
INFO - 2021-01-21 07:58:55 --> URI Class Initialized
INFO - 2021-01-21 07:58:55 --> Router Class Initialized
INFO - 2021-01-21 07:58:55 --> Output Class Initialized
INFO - 2021-01-21 07:58:55 --> Security Class Initialized
DEBUG - 2021-01-21 07:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:58:55 --> Input Class Initialized
INFO - 2021-01-21 07:58:55 --> Language Class Initialized
INFO - 2021-01-21 07:58:55 --> Language Class Initialized
INFO - 2021-01-21 07:58:55 --> Config Class Initialized
INFO - 2021-01-21 07:58:55 --> Loader Class Initialized
INFO - 2021-01-21 07:58:55 --> Helper loaded: url_helper
INFO - 2021-01-21 07:58:55 --> Helper loaded: file_helper
INFO - 2021-01-21 07:58:55 --> Helper loaded: form_helper
INFO - 2021-01-21 07:58:55 --> Helper loaded: my_helper
INFO - 2021-01-21 07:58:55 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:58:55 --> Controller Class Initialized
DEBUG - 2021-01-21 07:58:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-21 07:58:55 --> Final output sent to browser
DEBUG - 2021-01-21 07:58:55 --> Total execution time: 0.4925
INFO - 2021-01-21 07:59:27 --> Config Class Initialized
INFO - 2021-01-21 07:59:27 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:59:27 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:59:27 --> Utf8 Class Initialized
INFO - 2021-01-21 07:59:27 --> URI Class Initialized
INFO - 2021-01-21 07:59:27 --> Router Class Initialized
INFO - 2021-01-21 07:59:27 --> Output Class Initialized
INFO - 2021-01-21 07:59:27 --> Security Class Initialized
DEBUG - 2021-01-21 07:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:59:27 --> Input Class Initialized
INFO - 2021-01-21 07:59:27 --> Language Class Initialized
INFO - 2021-01-21 07:59:27 --> Language Class Initialized
INFO - 2021-01-21 07:59:27 --> Config Class Initialized
INFO - 2021-01-21 07:59:27 --> Loader Class Initialized
INFO - 2021-01-21 07:59:27 --> Helper loaded: url_helper
INFO - 2021-01-21 07:59:27 --> Helper loaded: file_helper
INFO - 2021-01-21 07:59:27 --> Helper loaded: form_helper
INFO - 2021-01-21 07:59:27 --> Helper loaded: my_helper
INFO - 2021-01-21 07:59:27 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:59:27 --> Controller Class Initialized
INFO - 2021-01-21 07:59:27 --> Helper loaded: cookie_helper
INFO - 2021-01-21 07:59:27 --> Config Class Initialized
INFO - 2021-01-21 07:59:27 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:59:27 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:59:27 --> Utf8 Class Initialized
INFO - 2021-01-21 07:59:27 --> URI Class Initialized
INFO - 2021-01-21 07:59:27 --> Router Class Initialized
INFO - 2021-01-21 07:59:27 --> Output Class Initialized
INFO - 2021-01-21 07:59:27 --> Security Class Initialized
DEBUG - 2021-01-21 07:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:59:27 --> Input Class Initialized
INFO - 2021-01-21 07:59:27 --> Language Class Initialized
INFO - 2021-01-21 07:59:27 --> Language Class Initialized
INFO - 2021-01-21 07:59:28 --> Config Class Initialized
INFO - 2021-01-21 07:59:28 --> Loader Class Initialized
INFO - 2021-01-21 07:59:28 --> Helper loaded: url_helper
INFO - 2021-01-21 07:59:28 --> Helper loaded: file_helper
INFO - 2021-01-21 07:59:28 --> Helper loaded: form_helper
INFO - 2021-01-21 07:59:28 --> Helper loaded: my_helper
INFO - 2021-01-21 07:59:28 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:59:28 --> Controller Class Initialized
DEBUG - 2021-01-21 07:59:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 07:59:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 07:59:28 --> Final output sent to browser
DEBUG - 2021-01-21 07:59:28 --> Total execution time: 0.6453
INFO - 2021-01-21 07:59:36 --> Config Class Initialized
INFO - 2021-01-21 07:59:36 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:59:36 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:59:36 --> Utf8 Class Initialized
INFO - 2021-01-21 07:59:36 --> URI Class Initialized
INFO - 2021-01-21 07:59:36 --> Router Class Initialized
INFO - 2021-01-21 07:59:36 --> Output Class Initialized
INFO - 2021-01-21 07:59:36 --> Security Class Initialized
DEBUG - 2021-01-21 07:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:59:36 --> Input Class Initialized
INFO - 2021-01-21 07:59:36 --> Language Class Initialized
INFO - 2021-01-21 07:59:36 --> Language Class Initialized
INFO - 2021-01-21 07:59:36 --> Config Class Initialized
INFO - 2021-01-21 07:59:36 --> Loader Class Initialized
INFO - 2021-01-21 07:59:36 --> Helper loaded: url_helper
INFO - 2021-01-21 07:59:36 --> Helper loaded: file_helper
INFO - 2021-01-21 07:59:36 --> Helper loaded: form_helper
INFO - 2021-01-21 07:59:36 --> Helper loaded: my_helper
INFO - 2021-01-21 07:59:36 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:59:37 --> Controller Class Initialized
INFO - 2021-01-21 07:59:37 --> Helper loaded: cookie_helper
INFO - 2021-01-21 07:59:37 --> Final output sent to browser
DEBUG - 2021-01-21 07:59:37 --> Total execution time: 0.5089
INFO - 2021-01-21 07:59:37 --> Config Class Initialized
INFO - 2021-01-21 07:59:37 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:59:37 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:59:37 --> Utf8 Class Initialized
INFO - 2021-01-21 07:59:37 --> URI Class Initialized
INFO - 2021-01-21 07:59:37 --> Router Class Initialized
INFO - 2021-01-21 07:59:37 --> Output Class Initialized
INFO - 2021-01-21 07:59:37 --> Security Class Initialized
DEBUG - 2021-01-21 07:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:59:37 --> Input Class Initialized
INFO - 2021-01-21 07:59:37 --> Language Class Initialized
INFO - 2021-01-21 07:59:37 --> Language Class Initialized
INFO - 2021-01-21 07:59:37 --> Config Class Initialized
INFO - 2021-01-21 07:59:37 --> Loader Class Initialized
INFO - 2021-01-21 07:59:37 --> Helper loaded: url_helper
INFO - 2021-01-21 07:59:37 --> Helper loaded: file_helper
INFO - 2021-01-21 07:59:37 --> Helper loaded: form_helper
INFO - 2021-01-21 07:59:37 --> Helper loaded: my_helper
INFO - 2021-01-21 07:59:37 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:59:37 --> Controller Class Initialized
DEBUG - 2021-01-21 07:59:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 07:59:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 07:59:37 --> Final output sent to browser
DEBUG - 2021-01-21 07:59:37 --> Total execution time: 0.5957
INFO - 2021-01-21 07:59:39 --> Config Class Initialized
INFO - 2021-01-21 07:59:39 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:59:39 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:59:39 --> Utf8 Class Initialized
INFO - 2021-01-21 07:59:39 --> URI Class Initialized
INFO - 2021-01-21 07:59:39 --> Router Class Initialized
INFO - 2021-01-21 07:59:39 --> Output Class Initialized
INFO - 2021-01-21 07:59:39 --> Security Class Initialized
DEBUG - 2021-01-21 07:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:59:39 --> Input Class Initialized
INFO - 2021-01-21 07:59:39 --> Language Class Initialized
INFO - 2021-01-21 07:59:39 --> Language Class Initialized
INFO - 2021-01-21 07:59:39 --> Config Class Initialized
INFO - 2021-01-21 07:59:39 --> Loader Class Initialized
INFO - 2021-01-21 07:59:39 --> Helper loaded: url_helper
INFO - 2021-01-21 07:59:39 --> Helper loaded: file_helper
INFO - 2021-01-21 07:59:39 --> Helper loaded: form_helper
INFO - 2021-01-21 07:59:39 --> Helper loaded: my_helper
INFO - 2021-01-21 07:59:39 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:59:39 --> Controller Class Initialized
DEBUG - 2021-01-21 07:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 07:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 07:59:39 --> Final output sent to browser
DEBUG - 2021-01-21 07:59:39 --> Total execution time: 0.5030
INFO - 2021-01-21 07:59:40 --> Config Class Initialized
INFO - 2021-01-21 07:59:40 --> Hooks Class Initialized
DEBUG - 2021-01-21 07:59:40 --> UTF-8 Support Enabled
INFO - 2021-01-21 07:59:40 --> Utf8 Class Initialized
INFO - 2021-01-21 07:59:40 --> URI Class Initialized
INFO - 2021-01-21 07:59:41 --> Router Class Initialized
INFO - 2021-01-21 07:59:41 --> Output Class Initialized
INFO - 2021-01-21 07:59:41 --> Security Class Initialized
DEBUG - 2021-01-21 07:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 07:59:41 --> Input Class Initialized
INFO - 2021-01-21 07:59:41 --> Language Class Initialized
INFO - 2021-01-21 07:59:41 --> Language Class Initialized
INFO - 2021-01-21 07:59:41 --> Config Class Initialized
INFO - 2021-01-21 07:59:41 --> Loader Class Initialized
INFO - 2021-01-21 07:59:41 --> Helper loaded: url_helper
INFO - 2021-01-21 07:59:41 --> Helper loaded: file_helper
INFO - 2021-01-21 07:59:41 --> Helper loaded: form_helper
INFO - 2021-01-21 07:59:41 --> Helper loaded: my_helper
INFO - 2021-01-21 07:59:41 --> Database Driver Class Initialized
DEBUG - 2021-01-21 07:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 07:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 07:59:41 --> Controller Class Initialized
DEBUG - 2021-01-21 07:59:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 07:59:41 --> Final output sent to browser
DEBUG - 2021-01-21 07:59:41 --> Total execution time: 0.4480
INFO - 2021-01-21 08:00:32 --> Config Class Initialized
INFO - 2021-01-21 08:00:32 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:00:32 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:00:32 --> Utf8 Class Initialized
INFO - 2021-01-21 08:00:32 --> URI Class Initialized
INFO - 2021-01-21 08:00:32 --> Router Class Initialized
INFO - 2021-01-21 08:00:32 --> Output Class Initialized
INFO - 2021-01-21 08:00:32 --> Security Class Initialized
DEBUG - 2021-01-21 08:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:00:32 --> Input Class Initialized
INFO - 2021-01-21 08:00:32 --> Language Class Initialized
INFO - 2021-01-21 08:00:32 --> Language Class Initialized
INFO - 2021-01-21 08:00:32 --> Config Class Initialized
INFO - 2021-01-21 08:00:32 --> Loader Class Initialized
INFO - 2021-01-21 08:00:32 --> Helper loaded: url_helper
INFO - 2021-01-21 08:00:32 --> Helper loaded: file_helper
INFO - 2021-01-21 08:00:32 --> Helper loaded: form_helper
INFO - 2021-01-21 08:00:32 --> Helper loaded: my_helper
INFO - 2021-01-21 08:00:33 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:00:33 --> Controller Class Initialized
DEBUG - 2021-01-21 08:00:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 08:00:33 --> Final output sent to browser
DEBUG - 2021-01-21 08:00:33 --> Total execution time: 0.5270
INFO - 2021-01-21 08:00:54 --> Config Class Initialized
INFO - 2021-01-21 08:00:54 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:00:54 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:00:54 --> Utf8 Class Initialized
INFO - 2021-01-21 08:00:54 --> URI Class Initialized
INFO - 2021-01-21 08:00:54 --> Router Class Initialized
INFO - 2021-01-21 08:00:54 --> Output Class Initialized
INFO - 2021-01-21 08:00:54 --> Security Class Initialized
DEBUG - 2021-01-21 08:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:00:54 --> Input Class Initialized
INFO - 2021-01-21 08:00:54 --> Language Class Initialized
INFO - 2021-01-21 08:00:54 --> Language Class Initialized
INFO - 2021-01-21 08:00:54 --> Config Class Initialized
INFO - 2021-01-21 08:00:54 --> Loader Class Initialized
INFO - 2021-01-21 08:00:54 --> Helper loaded: url_helper
INFO - 2021-01-21 08:00:54 --> Helper loaded: file_helper
INFO - 2021-01-21 08:00:54 --> Helper loaded: form_helper
INFO - 2021-01-21 08:00:54 --> Helper loaded: my_helper
INFO - 2021-01-21 08:00:54 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:00:54 --> Controller Class Initialized
DEBUG - 2021-01-21 08:00:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 08:00:54 --> Final output sent to browser
DEBUG - 2021-01-21 08:00:54 --> Total execution time: 0.4768
INFO - 2021-01-21 08:01:13 --> Config Class Initialized
INFO - 2021-01-21 08:01:13 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:01:13 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:01:13 --> Utf8 Class Initialized
INFO - 2021-01-21 08:01:13 --> URI Class Initialized
INFO - 2021-01-21 08:01:13 --> Router Class Initialized
INFO - 2021-01-21 08:01:13 --> Output Class Initialized
INFO - 2021-01-21 08:01:13 --> Security Class Initialized
DEBUG - 2021-01-21 08:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:01:13 --> Input Class Initialized
INFO - 2021-01-21 08:01:13 --> Language Class Initialized
INFO - 2021-01-21 08:01:13 --> Language Class Initialized
INFO - 2021-01-21 08:01:13 --> Config Class Initialized
INFO - 2021-01-21 08:01:13 --> Loader Class Initialized
INFO - 2021-01-21 08:01:13 --> Helper loaded: url_helper
INFO - 2021-01-21 08:01:13 --> Helper loaded: file_helper
INFO - 2021-01-21 08:01:13 --> Helper loaded: form_helper
INFO - 2021-01-21 08:01:13 --> Helper loaded: my_helper
INFO - 2021-01-21 08:01:13 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:01:13 --> Controller Class Initialized
DEBUG - 2021-01-21 08:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 08:01:14 --> Final output sent to browser
DEBUG - 2021-01-21 08:01:14 --> Total execution time: 0.5648
INFO - 2021-01-21 08:01:33 --> Config Class Initialized
INFO - 2021-01-21 08:01:33 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:01:33 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:01:33 --> Utf8 Class Initialized
INFO - 2021-01-21 08:01:33 --> URI Class Initialized
INFO - 2021-01-21 08:01:33 --> Router Class Initialized
INFO - 2021-01-21 08:01:33 --> Output Class Initialized
INFO - 2021-01-21 08:01:34 --> Security Class Initialized
DEBUG - 2021-01-21 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:01:34 --> Input Class Initialized
INFO - 2021-01-21 08:01:34 --> Language Class Initialized
INFO - 2021-01-21 08:01:34 --> Language Class Initialized
INFO - 2021-01-21 08:01:34 --> Config Class Initialized
INFO - 2021-01-21 08:01:34 --> Loader Class Initialized
INFO - 2021-01-21 08:01:34 --> Helper loaded: url_helper
INFO - 2021-01-21 08:01:34 --> Helper loaded: file_helper
INFO - 2021-01-21 08:01:34 --> Helper loaded: form_helper
INFO - 2021-01-21 08:01:34 --> Helper loaded: my_helper
INFO - 2021-01-21 08:01:34 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:01:34 --> Controller Class Initialized
DEBUG - 2021-01-21 08:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 08:01:34 --> Final output sent to browser
DEBUG - 2021-01-21 08:01:34 --> Total execution time: 0.4878
INFO - 2021-01-21 08:02:38 --> Config Class Initialized
INFO - 2021-01-21 08:02:38 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:02:38 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:02:38 --> Utf8 Class Initialized
INFO - 2021-01-21 08:02:38 --> URI Class Initialized
INFO - 2021-01-21 08:02:38 --> Router Class Initialized
INFO - 2021-01-21 08:02:38 --> Output Class Initialized
INFO - 2021-01-21 08:02:38 --> Security Class Initialized
DEBUG - 2021-01-21 08:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:02:38 --> Input Class Initialized
INFO - 2021-01-21 08:02:38 --> Language Class Initialized
INFO - 2021-01-21 08:02:38 --> Language Class Initialized
INFO - 2021-01-21 08:02:38 --> Config Class Initialized
INFO - 2021-01-21 08:02:38 --> Loader Class Initialized
INFO - 2021-01-21 08:02:38 --> Helper loaded: url_helper
INFO - 2021-01-21 08:02:38 --> Helper loaded: file_helper
INFO - 2021-01-21 08:02:38 --> Helper loaded: form_helper
INFO - 2021-01-21 08:02:38 --> Helper loaded: my_helper
INFO - 2021-01-21 08:02:38 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:02:38 --> Controller Class Initialized
DEBUG - 2021-01-21 08:02:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 08:02:38 --> Final output sent to browser
DEBUG - 2021-01-21 08:02:38 --> Total execution time: 0.5775
INFO - 2021-01-21 08:02:57 --> Config Class Initialized
INFO - 2021-01-21 08:02:57 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:02:57 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:02:57 --> Utf8 Class Initialized
INFO - 2021-01-21 08:02:57 --> URI Class Initialized
INFO - 2021-01-21 08:02:57 --> Router Class Initialized
INFO - 2021-01-21 08:02:57 --> Output Class Initialized
INFO - 2021-01-21 08:02:57 --> Security Class Initialized
DEBUG - 2021-01-21 08:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:02:58 --> Input Class Initialized
INFO - 2021-01-21 08:02:58 --> Language Class Initialized
INFO - 2021-01-21 08:02:58 --> Language Class Initialized
INFO - 2021-01-21 08:02:58 --> Config Class Initialized
INFO - 2021-01-21 08:02:58 --> Loader Class Initialized
INFO - 2021-01-21 08:02:58 --> Helper loaded: url_helper
INFO - 2021-01-21 08:02:58 --> Helper loaded: file_helper
INFO - 2021-01-21 08:02:58 --> Helper loaded: form_helper
INFO - 2021-01-21 08:02:58 --> Helper loaded: my_helper
INFO - 2021-01-21 08:02:58 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:02:58 --> Controller Class Initialized
DEBUG - 2021-01-21 08:02:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 08:02:58 --> Final output sent to browser
DEBUG - 2021-01-21 08:02:58 --> Total execution time: 0.4821
INFO - 2021-01-21 08:05:00 --> Config Class Initialized
INFO - 2021-01-21 08:05:00 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:05:00 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:05:00 --> Utf8 Class Initialized
INFO - 2021-01-21 08:05:00 --> URI Class Initialized
INFO - 2021-01-21 08:05:00 --> Router Class Initialized
INFO - 2021-01-21 08:05:00 --> Output Class Initialized
INFO - 2021-01-21 08:05:00 --> Security Class Initialized
DEBUG - 2021-01-21 08:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:05:00 --> Input Class Initialized
INFO - 2021-01-21 08:05:00 --> Language Class Initialized
INFO - 2021-01-21 08:05:00 --> Language Class Initialized
INFO - 2021-01-21 08:05:00 --> Config Class Initialized
INFO - 2021-01-21 08:05:00 --> Loader Class Initialized
INFO - 2021-01-21 08:05:00 --> Helper loaded: url_helper
INFO - 2021-01-21 08:05:00 --> Helper loaded: file_helper
INFO - 2021-01-21 08:05:00 --> Helper loaded: form_helper
INFO - 2021-01-21 08:05:00 --> Helper loaded: my_helper
INFO - 2021-01-21 08:05:00 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:05:00 --> Controller Class Initialized
INFO - 2021-01-21 08:05:00 --> Helper loaded: cookie_helper
INFO - 2021-01-21 08:05:00 --> Config Class Initialized
INFO - 2021-01-21 08:05:00 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:05:00 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:05:00 --> Utf8 Class Initialized
INFO - 2021-01-21 08:05:00 --> URI Class Initialized
INFO - 2021-01-21 08:05:00 --> Router Class Initialized
INFO - 2021-01-21 08:05:00 --> Output Class Initialized
INFO - 2021-01-21 08:05:00 --> Security Class Initialized
DEBUG - 2021-01-21 08:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:05:00 --> Input Class Initialized
INFO - 2021-01-21 08:05:00 --> Language Class Initialized
INFO - 2021-01-21 08:05:01 --> Language Class Initialized
INFO - 2021-01-21 08:05:01 --> Config Class Initialized
INFO - 2021-01-21 08:05:01 --> Loader Class Initialized
INFO - 2021-01-21 08:05:01 --> Helper loaded: url_helper
INFO - 2021-01-21 08:05:01 --> Helper loaded: file_helper
INFO - 2021-01-21 08:05:01 --> Helper loaded: form_helper
INFO - 2021-01-21 08:05:01 --> Helper loaded: my_helper
INFO - 2021-01-21 08:05:01 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:05:01 --> Controller Class Initialized
DEBUG - 2021-01-21 08:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 08:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 08:05:01 --> Final output sent to browser
DEBUG - 2021-01-21 08:05:01 --> Total execution time: 0.4950
INFO - 2021-01-21 08:05:12 --> Config Class Initialized
INFO - 2021-01-21 08:05:12 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:05:12 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:05:12 --> Utf8 Class Initialized
INFO - 2021-01-21 08:05:12 --> URI Class Initialized
INFO - 2021-01-21 08:05:12 --> Router Class Initialized
INFO - 2021-01-21 08:05:12 --> Output Class Initialized
INFO - 2021-01-21 08:05:12 --> Security Class Initialized
DEBUG - 2021-01-21 08:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:05:12 --> Input Class Initialized
INFO - 2021-01-21 08:05:12 --> Language Class Initialized
INFO - 2021-01-21 08:05:12 --> Language Class Initialized
INFO - 2021-01-21 08:05:12 --> Config Class Initialized
INFO - 2021-01-21 08:05:12 --> Loader Class Initialized
INFO - 2021-01-21 08:05:12 --> Helper loaded: url_helper
INFO - 2021-01-21 08:05:12 --> Helper loaded: file_helper
INFO - 2021-01-21 08:05:13 --> Helper loaded: form_helper
INFO - 2021-01-21 08:05:13 --> Helper loaded: my_helper
INFO - 2021-01-21 08:05:13 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:05:13 --> Controller Class Initialized
INFO - 2021-01-21 08:05:13 --> Helper loaded: cookie_helper
INFO - 2021-01-21 08:05:13 --> Final output sent to browser
DEBUG - 2021-01-21 08:05:13 --> Total execution time: 0.5005
INFO - 2021-01-21 08:05:13 --> Config Class Initialized
INFO - 2021-01-21 08:05:13 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:05:13 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:05:13 --> Utf8 Class Initialized
INFO - 2021-01-21 08:05:13 --> URI Class Initialized
INFO - 2021-01-21 08:05:13 --> Router Class Initialized
INFO - 2021-01-21 08:05:13 --> Output Class Initialized
INFO - 2021-01-21 08:05:13 --> Security Class Initialized
DEBUG - 2021-01-21 08:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:05:13 --> Input Class Initialized
INFO - 2021-01-21 08:05:13 --> Language Class Initialized
INFO - 2021-01-21 08:05:13 --> Language Class Initialized
INFO - 2021-01-21 08:05:13 --> Config Class Initialized
INFO - 2021-01-21 08:05:13 --> Loader Class Initialized
INFO - 2021-01-21 08:05:13 --> Helper loaded: url_helper
INFO - 2021-01-21 08:05:13 --> Helper loaded: file_helper
INFO - 2021-01-21 08:05:14 --> Helper loaded: form_helper
INFO - 2021-01-21 08:05:14 --> Helper loaded: my_helper
INFO - 2021-01-21 08:05:14 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:05:14 --> Controller Class Initialized
DEBUG - 2021-01-21 08:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 08:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 08:05:14 --> Final output sent to browser
DEBUG - 2021-01-21 08:05:14 --> Total execution time: 0.6153
INFO - 2021-01-21 08:05:15 --> Config Class Initialized
INFO - 2021-01-21 08:05:15 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:05:15 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:05:15 --> Utf8 Class Initialized
INFO - 2021-01-21 08:05:15 --> URI Class Initialized
INFO - 2021-01-21 08:05:15 --> Router Class Initialized
INFO - 2021-01-21 08:05:15 --> Output Class Initialized
INFO - 2021-01-21 08:05:15 --> Security Class Initialized
DEBUG - 2021-01-21 08:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:05:15 --> Input Class Initialized
INFO - 2021-01-21 08:05:15 --> Language Class Initialized
INFO - 2021-01-21 08:05:15 --> Language Class Initialized
INFO - 2021-01-21 08:05:16 --> Config Class Initialized
INFO - 2021-01-21 08:05:16 --> Loader Class Initialized
INFO - 2021-01-21 08:05:16 --> Helper loaded: url_helper
INFO - 2021-01-21 08:05:16 --> Helper loaded: file_helper
INFO - 2021-01-21 08:05:16 --> Helper loaded: form_helper
INFO - 2021-01-21 08:05:16 --> Helper loaded: my_helper
INFO - 2021-01-21 08:05:16 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:05:16 --> Controller Class Initialized
DEBUG - 2021-01-21 08:05:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 08:05:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 08:05:16 --> Final output sent to browser
DEBUG - 2021-01-21 08:05:16 --> Total execution time: 0.5061
INFO - 2021-01-21 08:05:18 --> Config Class Initialized
INFO - 2021-01-21 08:05:18 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:05:18 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:05:18 --> Utf8 Class Initialized
INFO - 2021-01-21 08:05:18 --> URI Class Initialized
INFO - 2021-01-21 08:05:18 --> Router Class Initialized
INFO - 2021-01-21 08:05:18 --> Output Class Initialized
INFO - 2021-01-21 08:05:18 --> Security Class Initialized
DEBUG - 2021-01-21 08:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:05:18 --> Input Class Initialized
INFO - 2021-01-21 08:05:18 --> Language Class Initialized
INFO - 2021-01-21 08:05:18 --> Language Class Initialized
INFO - 2021-01-21 08:05:18 --> Config Class Initialized
INFO - 2021-01-21 08:05:18 --> Loader Class Initialized
INFO - 2021-01-21 08:05:18 --> Helper loaded: url_helper
INFO - 2021-01-21 08:05:18 --> Helper loaded: file_helper
INFO - 2021-01-21 08:05:18 --> Helper loaded: form_helper
INFO - 2021-01-21 08:05:18 --> Helper loaded: my_helper
INFO - 2021-01-21 08:05:18 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:05:18 --> Controller Class Initialized
DEBUG - 2021-01-21 08:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-21 08:05:18 --> Final output sent to browser
DEBUG - 2021-01-21 08:05:18 --> Total execution time: 0.5553
INFO - 2021-01-21 08:06:49 --> Config Class Initialized
INFO - 2021-01-21 08:06:49 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:06:49 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:06:49 --> Utf8 Class Initialized
INFO - 2021-01-21 08:06:49 --> URI Class Initialized
INFO - 2021-01-21 08:06:49 --> Router Class Initialized
INFO - 2021-01-21 08:06:49 --> Output Class Initialized
INFO - 2021-01-21 08:06:49 --> Security Class Initialized
DEBUG - 2021-01-21 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:06:49 --> Input Class Initialized
INFO - 2021-01-21 08:06:49 --> Language Class Initialized
INFO - 2021-01-21 08:06:49 --> Language Class Initialized
INFO - 2021-01-21 08:06:49 --> Config Class Initialized
INFO - 2021-01-21 08:06:49 --> Loader Class Initialized
INFO - 2021-01-21 08:06:49 --> Helper loaded: url_helper
INFO - 2021-01-21 08:06:49 --> Helper loaded: file_helper
INFO - 2021-01-21 08:06:49 --> Helper loaded: form_helper
INFO - 2021-01-21 08:06:49 --> Helper loaded: my_helper
INFO - 2021-01-21 08:06:49 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:06:49 --> Controller Class Initialized
DEBUG - 2021-01-21 08:06:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-21 08:06:49 --> Final output sent to browser
DEBUG - 2021-01-21 08:06:49 --> Total execution time: 0.5510
INFO - 2021-01-21 08:07:07 --> Config Class Initialized
INFO - 2021-01-21 08:07:07 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:07:07 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:07:07 --> Utf8 Class Initialized
INFO - 2021-01-21 08:07:07 --> URI Class Initialized
INFO - 2021-01-21 08:07:07 --> Router Class Initialized
INFO - 2021-01-21 08:07:07 --> Output Class Initialized
INFO - 2021-01-21 08:07:07 --> Security Class Initialized
DEBUG - 2021-01-21 08:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:07:07 --> Input Class Initialized
INFO - 2021-01-21 08:07:07 --> Language Class Initialized
INFO - 2021-01-21 08:07:07 --> Language Class Initialized
INFO - 2021-01-21 08:07:07 --> Config Class Initialized
INFO - 2021-01-21 08:07:07 --> Loader Class Initialized
INFO - 2021-01-21 08:07:07 --> Helper loaded: url_helper
INFO - 2021-01-21 08:07:07 --> Helper loaded: file_helper
INFO - 2021-01-21 08:07:07 --> Helper loaded: form_helper
INFO - 2021-01-21 08:07:07 --> Helper loaded: my_helper
INFO - 2021-01-21 08:07:07 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:07:07 --> Controller Class Initialized
DEBUG - 2021-01-21 08:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-21 08:07:07 --> Final output sent to browser
DEBUG - 2021-01-21 08:07:07 --> Total execution time: 0.6741
INFO - 2021-01-21 08:07:46 --> Config Class Initialized
INFO - 2021-01-21 08:07:46 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:07:46 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:07:46 --> Utf8 Class Initialized
INFO - 2021-01-21 08:07:46 --> URI Class Initialized
INFO - 2021-01-21 08:07:46 --> Router Class Initialized
INFO - 2021-01-21 08:07:46 --> Output Class Initialized
INFO - 2021-01-21 08:07:46 --> Security Class Initialized
DEBUG - 2021-01-21 08:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:07:46 --> Input Class Initialized
INFO - 2021-01-21 08:07:46 --> Language Class Initialized
INFO - 2021-01-21 08:07:46 --> Language Class Initialized
INFO - 2021-01-21 08:07:46 --> Config Class Initialized
INFO - 2021-01-21 08:07:46 --> Loader Class Initialized
INFO - 2021-01-21 08:07:46 --> Helper loaded: url_helper
INFO - 2021-01-21 08:07:46 --> Helper loaded: file_helper
INFO - 2021-01-21 08:07:46 --> Helper loaded: form_helper
INFO - 2021-01-21 08:07:46 --> Helper loaded: my_helper
INFO - 2021-01-21 08:07:46 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:07:46 --> Controller Class Initialized
DEBUG - 2021-01-21 08:07:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-21 08:07:46 --> Final output sent to browser
DEBUG - 2021-01-21 08:07:46 --> Total execution time: 0.4797
INFO - 2021-01-21 08:09:16 --> Config Class Initialized
INFO - 2021-01-21 08:09:16 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:09:16 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:09:16 --> Utf8 Class Initialized
INFO - 2021-01-21 08:09:16 --> URI Class Initialized
INFO - 2021-01-21 08:09:16 --> Router Class Initialized
INFO - 2021-01-21 08:09:16 --> Output Class Initialized
INFO - 2021-01-21 08:09:16 --> Security Class Initialized
DEBUG - 2021-01-21 08:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:09:16 --> Input Class Initialized
INFO - 2021-01-21 08:09:16 --> Language Class Initialized
INFO - 2021-01-21 08:09:16 --> Language Class Initialized
INFO - 2021-01-21 08:09:16 --> Config Class Initialized
INFO - 2021-01-21 08:09:16 --> Loader Class Initialized
INFO - 2021-01-21 08:09:16 --> Helper loaded: url_helper
INFO - 2021-01-21 08:09:16 --> Helper loaded: file_helper
INFO - 2021-01-21 08:09:16 --> Helper loaded: form_helper
INFO - 2021-01-21 08:09:16 --> Helper loaded: my_helper
INFO - 2021-01-21 08:09:16 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:09:17 --> Controller Class Initialized
INFO - 2021-01-21 08:09:17 --> Helper loaded: cookie_helper
INFO - 2021-01-21 08:09:17 --> Config Class Initialized
INFO - 2021-01-21 08:09:17 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:09:17 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:09:17 --> Utf8 Class Initialized
INFO - 2021-01-21 08:09:17 --> URI Class Initialized
INFO - 2021-01-21 08:09:17 --> Router Class Initialized
INFO - 2021-01-21 08:09:17 --> Output Class Initialized
INFO - 2021-01-21 08:09:17 --> Security Class Initialized
DEBUG - 2021-01-21 08:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:09:17 --> Input Class Initialized
INFO - 2021-01-21 08:09:17 --> Language Class Initialized
INFO - 2021-01-21 08:09:17 --> Language Class Initialized
INFO - 2021-01-21 08:09:17 --> Config Class Initialized
INFO - 2021-01-21 08:09:17 --> Loader Class Initialized
INFO - 2021-01-21 08:09:17 --> Helper loaded: url_helper
INFO - 2021-01-21 08:09:17 --> Helper loaded: file_helper
INFO - 2021-01-21 08:09:17 --> Helper loaded: form_helper
INFO - 2021-01-21 08:09:17 --> Helper loaded: my_helper
INFO - 2021-01-21 08:09:17 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:09:17 --> Controller Class Initialized
DEBUG - 2021-01-21 08:09:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-21 08:09:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 08:09:17 --> Final output sent to browser
DEBUG - 2021-01-21 08:09:17 --> Total execution time: 0.4825
INFO - 2021-01-21 08:09:20 --> Config Class Initialized
INFO - 2021-01-21 08:09:20 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:09:20 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:09:20 --> Utf8 Class Initialized
INFO - 2021-01-21 08:09:20 --> URI Class Initialized
INFO - 2021-01-21 08:09:20 --> Router Class Initialized
INFO - 2021-01-21 08:09:20 --> Output Class Initialized
INFO - 2021-01-21 08:09:20 --> Security Class Initialized
DEBUG - 2021-01-21 08:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:09:20 --> Input Class Initialized
INFO - 2021-01-21 08:09:20 --> Language Class Initialized
INFO - 2021-01-21 08:09:20 --> Language Class Initialized
INFO - 2021-01-21 08:09:20 --> Config Class Initialized
INFO - 2021-01-21 08:09:20 --> Loader Class Initialized
INFO - 2021-01-21 08:09:20 --> Helper loaded: url_helper
INFO - 2021-01-21 08:09:20 --> Helper loaded: file_helper
INFO - 2021-01-21 08:09:20 --> Helper loaded: form_helper
INFO - 2021-01-21 08:09:21 --> Helper loaded: my_helper
INFO - 2021-01-21 08:09:21 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:09:21 --> Controller Class Initialized
INFO - 2021-01-21 08:09:21 --> Helper loaded: cookie_helper
INFO - 2021-01-21 08:09:21 --> Final output sent to browser
DEBUG - 2021-01-21 08:09:21 --> Total execution time: 0.4922
INFO - 2021-01-21 08:09:21 --> Config Class Initialized
INFO - 2021-01-21 08:09:21 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:09:21 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:09:21 --> Utf8 Class Initialized
INFO - 2021-01-21 08:09:21 --> URI Class Initialized
INFO - 2021-01-21 08:09:21 --> Router Class Initialized
INFO - 2021-01-21 08:09:21 --> Output Class Initialized
INFO - 2021-01-21 08:09:21 --> Security Class Initialized
DEBUG - 2021-01-21 08:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:09:21 --> Input Class Initialized
INFO - 2021-01-21 08:09:21 --> Language Class Initialized
INFO - 2021-01-21 08:09:21 --> Language Class Initialized
INFO - 2021-01-21 08:09:21 --> Config Class Initialized
INFO - 2021-01-21 08:09:21 --> Loader Class Initialized
INFO - 2021-01-21 08:09:21 --> Helper loaded: url_helper
INFO - 2021-01-21 08:09:21 --> Helper loaded: file_helper
INFO - 2021-01-21 08:09:21 --> Helper loaded: form_helper
INFO - 2021-01-21 08:09:21 --> Helper loaded: my_helper
INFO - 2021-01-21 08:09:21 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:09:21 --> Controller Class Initialized
DEBUG - 2021-01-21 08:09:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-21 08:09:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 08:09:21 --> Final output sent to browser
DEBUG - 2021-01-21 08:09:21 --> Total execution time: 0.6394
INFO - 2021-01-21 08:09:23 --> Config Class Initialized
INFO - 2021-01-21 08:09:23 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:09:23 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:09:23 --> Utf8 Class Initialized
INFO - 2021-01-21 08:09:23 --> URI Class Initialized
INFO - 2021-01-21 08:09:23 --> Router Class Initialized
INFO - 2021-01-21 08:09:23 --> Output Class Initialized
INFO - 2021-01-21 08:09:23 --> Security Class Initialized
DEBUG - 2021-01-21 08:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:09:23 --> Input Class Initialized
INFO - 2021-01-21 08:09:23 --> Language Class Initialized
INFO - 2021-01-21 08:09:23 --> Language Class Initialized
INFO - 2021-01-21 08:09:23 --> Config Class Initialized
INFO - 2021-01-21 08:09:23 --> Loader Class Initialized
INFO - 2021-01-21 08:09:23 --> Helper loaded: url_helper
INFO - 2021-01-21 08:09:23 --> Helper loaded: file_helper
INFO - 2021-01-21 08:09:23 --> Helper loaded: form_helper
INFO - 2021-01-21 08:09:23 --> Helper loaded: my_helper
INFO - 2021-01-21 08:09:23 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:09:23 --> Controller Class Initialized
DEBUG - 2021-01-21 08:09:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-21 08:09:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-21 08:09:23 --> Final output sent to browser
DEBUG - 2021-01-21 08:09:23 --> Total execution time: 0.5085
INFO - 2021-01-21 08:09:24 --> Config Class Initialized
INFO - 2021-01-21 08:09:24 --> Hooks Class Initialized
DEBUG - 2021-01-21 08:09:24 --> UTF-8 Support Enabled
INFO - 2021-01-21 08:09:24 --> Utf8 Class Initialized
INFO - 2021-01-21 08:09:24 --> URI Class Initialized
INFO - 2021-01-21 08:09:24 --> Router Class Initialized
INFO - 2021-01-21 08:09:24 --> Output Class Initialized
INFO - 2021-01-21 08:09:24 --> Security Class Initialized
DEBUG - 2021-01-21 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-21 08:09:24 --> Input Class Initialized
INFO - 2021-01-21 08:09:24 --> Language Class Initialized
INFO - 2021-01-21 08:09:24 --> Language Class Initialized
INFO - 2021-01-21 08:09:24 --> Config Class Initialized
INFO - 2021-01-21 08:09:24 --> Loader Class Initialized
INFO - 2021-01-21 08:09:24 --> Helper loaded: url_helper
INFO - 2021-01-21 08:09:24 --> Helper loaded: file_helper
INFO - 2021-01-21 08:09:24 --> Helper loaded: form_helper
INFO - 2021-01-21 08:09:24 --> Helper loaded: my_helper
INFO - 2021-01-21 08:09:24 --> Database Driver Class Initialized
DEBUG - 2021-01-21 08:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-21 08:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-21 08:09:25 --> Controller Class Initialized
DEBUG - 2021-01-21 08:09:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-21 08:09:25 --> Final output sent to browser
DEBUG - 2021-01-21 08:09:25 --> Total execution time: 0.4435
