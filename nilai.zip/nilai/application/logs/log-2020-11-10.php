<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-10 01:23:21 --> Config Class Initialized
INFO - 2020-11-10 01:23:21 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:21 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:21 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:22 --> URI Class Initialized
DEBUG - 2020-11-10 01:23:22 --> No URI present. Default controller set.
INFO - 2020-11-10 01:23:22 --> Router Class Initialized
INFO - 2020-11-10 01:23:22 --> Output Class Initialized
INFO - 2020-11-10 01:23:22 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:22 --> Input Class Initialized
INFO - 2020-11-10 01:23:22 --> Language Class Initialized
INFO - 2020-11-10 01:23:22 --> Language Class Initialized
INFO - 2020-11-10 01:23:22 --> Config Class Initialized
INFO - 2020-11-10 01:23:22 --> Loader Class Initialized
INFO - 2020-11-10 01:23:22 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:22 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:22 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:22 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:22 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:22 --> Controller Class Initialized
INFO - 2020-11-10 01:23:22 --> Config Class Initialized
INFO - 2020-11-10 01:23:22 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:22 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:22 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:22 --> URI Class Initialized
INFO - 2020-11-10 01:23:22 --> Router Class Initialized
INFO - 2020-11-10 01:23:22 --> Output Class Initialized
INFO - 2020-11-10 01:23:22 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:22 --> Input Class Initialized
INFO - 2020-11-10 01:23:22 --> Language Class Initialized
INFO - 2020-11-10 01:23:22 --> Language Class Initialized
INFO - 2020-11-10 01:23:22 --> Config Class Initialized
INFO - 2020-11-10 01:23:22 --> Loader Class Initialized
INFO - 2020-11-10 01:23:22 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:22 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:22 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:22 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:22 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:22 --> Controller Class Initialized
DEBUG - 2020-11-10 01:23:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 01:23:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:23:22 --> Final output sent to browser
DEBUG - 2020-11-10 01:23:22 --> Total execution time: 0.2385
INFO - 2020-11-10 01:23:34 --> Config Class Initialized
INFO - 2020-11-10 01:23:34 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:34 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:34 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:34 --> URI Class Initialized
INFO - 2020-11-10 01:23:34 --> Router Class Initialized
INFO - 2020-11-10 01:23:34 --> Output Class Initialized
INFO - 2020-11-10 01:23:34 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:34 --> Input Class Initialized
INFO - 2020-11-10 01:23:34 --> Language Class Initialized
INFO - 2020-11-10 01:23:34 --> Language Class Initialized
INFO - 2020-11-10 01:23:34 --> Config Class Initialized
INFO - 2020-11-10 01:23:34 --> Loader Class Initialized
INFO - 2020-11-10 01:23:34 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:34 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:34 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:34 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:34 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:34 --> Controller Class Initialized
INFO - 2020-11-10 01:23:34 --> Helper loaded: cookie_helper
INFO - 2020-11-10 01:23:34 --> Final output sent to browser
DEBUG - 2020-11-10 01:23:34 --> Total execution time: 0.3119
INFO - 2020-11-10 01:23:36 --> Config Class Initialized
INFO - 2020-11-10 01:23:36 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:36 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:36 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:36 --> URI Class Initialized
INFO - 2020-11-10 01:23:36 --> Router Class Initialized
INFO - 2020-11-10 01:23:36 --> Output Class Initialized
INFO - 2020-11-10 01:23:36 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:36 --> Input Class Initialized
INFO - 2020-11-10 01:23:36 --> Language Class Initialized
INFO - 2020-11-10 01:23:36 --> Language Class Initialized
INFO - 2020-11-10 01:23:36 --> Config Class Initialized
INFO - 2020-11-10 01:23:36 --> Loader Class Initialized
INFO - 2020-11-10 01:23:36 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:36 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:36 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:36 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:36 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:36 --> Controller Class Initialized
DEBUG - 2020-11-10 01:23:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 01:23:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:23:36 --> Final output sent to browser
DEBUG - 2020-11-10 01:23:36 --> Total execution time: 0.3742
INFO - 2020-11-10 01:23:40 --> Config Class Initialized
INFO - 2020-11-10 01:23:40 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:40 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:40 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:40 --> URI Class Initialized
INFO - 2020-11-10 01:23:40 --> Router Class Initialized
INFO - 2020-11-10 01:23:40 --> Output Class Initialized
INFO - 2020-11-10 01:23:41 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:41 --> Input Class Initialized
INFO - 2020-11-10 01:23:41 --> Language Class Initialized
INFO - 2020-11-10 01:23:41 --> Language Class Initialized
INFO - 2020-11-10 01:23:41 --> Config Class Initialized
INFO - 2020-11-10 01:23:41 --> Loader Class Initialized
INFO - 2020-11-10 01:23:41 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:41 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:41 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:41 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:41 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:41 --> Controller Class Initialized
DEBUG - 2020-11-10 01:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 01:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:23:41 --> Final output sent to browser
DEBUG - 2020-11-10 01:23:41 --> Total execution time: 0.2386
INFO - 2020-11-10 01:23:43 --> Config Class Initialized
INFO - 2020-11-10 01:23:43 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:43 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:43 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:43 --> URI Class Initialized
INFO - 2020-11-10 01:23:43 --> Router Class Initialized
INFO - 2020-11-10 01:23:44 --> Output Class Initialized
INFO - 2020-11-10 01:23:44 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:44 --> Input Class Initialized
INFO - 2020-11-10 01:23:44 --> Language Class Initialized
INFO - 2020-11-10 01:23:44 --> Language Class Initialized
INFO - 2020-11-10 01:23:44 --> Config Class Initialized
INFO - 2020-11-10 01:23:44 --> Loader Class Initialized
INFO - 2020-11-10 01:23:44 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:44 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:44 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:44 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:44 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:44 --> Controller Class Initialized
INFO - 2020-11-10 01:23:44 --> Helper loaded: cookie_helper
INFO - 2020-11-10 01:23:44 --> Config Class Initialized
INFO - 2020-11-10 01:23:44 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:44 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:44 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:44 --> URI Class Initialized
INFO - 2020-11-10 01:23:44 --> Router Class Initialized
INFO - 2020-11-10 01:23:44 --> Output Class Initialized
INFO - 2020-11-10 01:23:44 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:44 --> Input Class Initialized
INFO - 2020-11-10 01:23:44 --> Language Class Initialized
INFO - 2020-11-10 01:23:44 --> Language Class Initialized
INFO - 2020-11-10 01:23:44 --> Config Class Initialized
INFO - 2020-11-10 01:23:44 --> Loader Class Initialized
INFO - 2020-11-10 01:23:44 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:44 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:44 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:44 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:44 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:44 --> Controller Class Initialized
DEBUG - 2020-11-10 01:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 01:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:23:44 --> Final output sent to browser
DEBUG - 2020-11-10 01:23:44 --> Total execution time: 0.2179
INFO - 2020-11-10 01:23:48 --> Config Class Initialized
INFO - 2020-11-10 01:23:48 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:48 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:48 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:48 --> URI Class Initialized
INFO - 2020-11-10 01:23:48 --> Router Class Initialized
INFO - 2020-11-10 01:23:48 --> Output Class Initialized
INFO - 2020-11-10 01:23:48 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:48 --> Input Class Initialized
INFO - 2020-11-10 01:23:48 --> Language Class Initialized
INFO - 2020-11-10 01:23:48 --> Language Class Initialized
INFO - 2020-11-10 01:23:48 --> Config Class Initialized
INFO - 2020-11-10 01:23:48 --> Loader Class Initialized
INFO - 2020-11-10 01:23:48 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:48 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:48 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:48 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:48 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:48 --> Controller Class Initialized
INFO - 2020-11-10 01:23:48 --> Helper loaded: cookie_helper
INFO - 2020-11-10 01:23:49 --> Final output sent to browser
DEBUG - 2020-11-10 01:23:49 --> Total execution time: 0.2586
INFO - 2020-11-10 01:23:50 --> Config Class Initialized
INFO - 2020-11-10 01:23:50 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:50 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:50 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:50 --> URI Class Initialized
INFO - 2020-11-10 01:23:50 --> Router Class Initialized
INFO - 2020-11-10 01:23:50 --> Output Class Initialized
INFO - 2020-11-10 01:23:50 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:50 --> Input Class Initialized
INFO - 2020-11-10 01:23:50 --> Language Class Initialized
INFO - 2020-11-10 01:23:50 --> Language Class Initialized
INFO - 2020-11-10 01:23:50 --> Config Class Initialized
INFO - 2020-11-10 01:23:50 --> Loader Class Initialized
INFO - 2020-11-10 01:23:50 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:50 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:50 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:50 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:50 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:50 --> Controller Class Initialized
DEBUG - 2020-11-10 01:23:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 01:23:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:23:50 --> Final output sent to browser
DEBUG - 2020-11-10 01:23:50 --> Total execution time: 0.3346
INFO - 2020-11-10 01:23:51 --> Config Class Initialized
INFO - 2020-11-10 01:23:51 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:51 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:51 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:51 --> URI Class Initialized
INFO - 2020-11-10 01:23:51 --> Router Class Initialized
INFO - 2020-11-10 01:23:51 --> Output Class Initialized
INFO - 2020-11-10 01:23:51 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:51 --> Input Class Initialized
INFO - 2020-11-10 01:23:51 --> Language Class Initialized
INFO - 2020-11-10 01:23:51 --> Language Class Initialized
INFO - 2020-11-10 01:23:51 --> Config Class Initialized
INFO - 2020-11-10 01:23:51 --> Loader Class Initialized
INFO - 2020-11-10 01:23:51 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:51 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:51 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:51 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:51 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:51 --> Controller Class Initialized
DEBUG - 2020-11-10 01:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 01:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:23:51 --> Final output sent to browser
DEBUG - 2020-11-10 01:23:51 --> Total execution time: 0.2137
INFO - 2020-11-10 01:23:53 --> Config Class Initialized
INFO - 2020-11-10 01:23:53 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:53 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:53 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:53 --> URI Class Initialized
INFO - 2020-11-10 01:23:53 --> Router Class Initialized
INFO - 2020-11-10 01:23:53 --> Output Class Initialized
INFO - 2020-11-10 01:23:53 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:53 --> Input Class Initialized
INFO - 2020-11-10 01:23:53 --> Language Class Initialized
INFO - 2020-11-10 01:23:53 --> Language Class Initialized
INFO - 2020-11-10 01:23:53 --> Config Class Initialized
INFO - 2020-11-10 01:23:53 --> Loader Class Initialized
INFO - 2020-11-10 01:23:53 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:53 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:53 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:53 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:53 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:53 --> Controller Class Initialized
DEBUG - 2020-11-10 01:23:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-10 01:23:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:23:53 --> Final output sent to browser
DEBUG - 2020-11-10 01:23:53 --> Total execution time: 0.2797
INFO - 2020-11-10 01:23:53 --> Config Class Initialized
INFO - 2020-11-10 01:23:53 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:23:53 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:23:53 --> Utf8 Class Initialized
INFO - 2020-11-10 01:23:53 --> URI Class Initialized
INFO - 2020-11-10 01:23:53 --> Router Class Initialized
INFO - 2020-11-10 01:23:53 --> Output Class Initialized
INFO - 2020-11-10 01:23:53 --> Security Class Initialized
DEBUG - 2020-11-10 01:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:23:53 --> Input Class Initialized
INFO - 2020-11-10 01:23:53 --> Language Class Initialized
INFO - 2020-11-10 01:23:53 --> Language Class Initialized
INFO - 2020-11-10 01:23:53 --> Config Class Initialized
INFO - 2020-11-10 01:23:53 --> Loader Class Initialized
INFO - 2020-11-10 01:23:53 --> Helper loaded: url_helper
INFO - 2020-11-10 01:23:53 --> Helper loaded: file_helper
INFO - 2020-11-10 01:23:53 --> Helper loaded: form_helper
INFO - 2020-11-10 01:23:53 --> Helper loaded: my_helper
INFO - 2020-11-10 01:23:53 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:23:53 --> Controller Class Initialized
INFO - 2020-11-10 01:24:02 --> Config Class Initialized
INFO - 2020-11-10 01:24:02 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:02 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:02 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:02 --> URI Class Initialized
INFO - 2020-11-10 01:24:02 --> Router Class Initialized
INFO - 2020-11-10 01:24:02 --> Output Class Initialized
INFO - 2020-11-10 01:24:02 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:02 --> Input Class Initialized
INFO - 2020-11-10 01:24:02 --> Language Class Initialized
INFO - 2020-11-10 01:24:02 --> Language Class Initialized
INFO - 2020-11-10 01:24:02 --> Config Class Initialized
INFO - 2020-11-10 01:24:02 --> Loader Class Initialized
INFO - 2020-11-10 01:24:02 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:02 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:02 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:02 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:02 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:02 --> Controller Class Initialized
INFO - 2020-11-10 01:24:02 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:02 --> Total execution time: 0.2094
INFO - 2020-11-10 01:24:16 --> Config Class Initialized
INFO - 2020-11-10 01:24:16 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:16 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:16 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:16 --> URI Class Initialized
INFO - 2020-11-10 01:24:16 --> Router Class Initialized
INFO - 2020-11-10 01:24:16 --> Output Class Initialized
INFO - 2020-11-10 01:24:16 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:16 --> Input Class Initialized
INFO - 2020-11-10 01:24:16 --> Language Class Initialized
INFO - 2020-11-10 01:24:16 --> Language Class Initialized
INFO - 2020-11-10 01:24:16 --> Config Class Initialized
INFO - 2020-11-10 01:24:16 --> Loader Class Initialized
INFO - 2020-11-10 01:24:16 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:16 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:16 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:16 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:16 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:16 --> Controller Class Initialized
DEBUG - 2020-11-10 01:24:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 01:24:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:24:16 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:16 --> Total execution time: 0.2367
INFO - 2020-11-10 01:24:23 --> Config Class Initialized
INFO - 2020-11-10 01:24:23 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:23 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:23 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:23 --> URI Class Initialized
INFO - 2020-11-10 01:24:23 --> Router Class Initialized
INFO - 2020-11-10 01:24:23 --> Output Class Initialized
INFO - 2020-11-10 01:24:23 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:23 --> Input Class Initialized
INFO - 2020-11-10 01:24:23 --> Language Class Initialized
INFO - 2020-11-10 01:24:23 --> Language Class Initialized
INFO - 2020-11-10 01:24:23 --> Config Class Initialized
INFO - 2020-11-10 01:24:23 --> Loader Class Initialized
INFO - 2020-11-10 01:24:23 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:23 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:23 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:23 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:23 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:23 --> Controller Class Initialized
DEBUG - 2020-11-10 01:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-10 01:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:24:23 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:23 --> Total execution time: 0.2249
INFO - 2020-11-10 01:24:23 --> Config Class Initialized
INFO - 2020-11-10 01:24:23 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:23 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:23 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:23 --> URI Class Initialized
INFO - 2020-11-10 01:24:23 --> Router Class Initialized
INFO - 2020-11-10 01:24:23 --> Output Class Initialized
INFO - 2020-11-10 01:24:23 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:23 --> Input Class Initialized
INFO - 2020-11-10 01:24:23 --> Language Class Initialized
INFO - 2020-11-10 01:24:23 --> Language Class Initialized
INFO - 2020-11-10 01:24:23 --> Config Class Initialized
INFO - 2020-11-10 01:24:23 --> Loader Class Initialized
INFO - 2020-11-10 01:24:23 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:23 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:23 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:23 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:23 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:23 --> Controller Class Initialized
INFO - 2020-11-10 01:24:35 --> Config Class Initialized
INFO - 2020-11-10 01:24:35 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:35 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:35 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:35 --> URI Class Initialized
INFO - 2020-11-10 01:24:35 --> Router Class Initialized
INFO - 2020-11-10 01:24:35 --> Output Class Initialized
INFO - 2020-11-10 01:24:35 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:35 --> Input Class Initialized
INFO - 2020-11-10 01:24:35 --> Language Class Initialized
INFO - 2020-11-10 01:24:35 --> Language Class Initialized
INFO - 2020-11-10 01:24:35 --> Config Class Initialized
INFO - 2020-11-10 01:24:35 --> Loader Class Initialized
INFO - 2020-11-10 01:24:35 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:35 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:35 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:35 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:35 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:35 --> Controller Class Initialized
INFO - 2020-11-10 01:24:35 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:35 --> Total execution time: 0.1766
INFO - 2020-11-10 01:24:37 --> Config Class Initialized
INFO - 2020-11-10 01:24:37 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:37 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:37 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:37 --> URI Class Initialized
INFO - 2020-11-10 01:24:37 --> Router Class Initialized
INFO - 2020-11-10 01:24:37 --> Output Class Initialized
INFO - 2020-11-10 01:24:37 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:37 --> Input Class Initialized
INFO - 2020-11-10 01:24:37 --> Language Class Initialized
INFO - 2020-11-10 01:24:37 --> Language Class Initialized
INFO - 2020-11-10 01:24:37 --> Config Class Initialized
INFO - 2020-11-10 01:24:37 --> Loader Class Initialized
INFO - 2020-11-10 01:24:37 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:37 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:37 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:37 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:37 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:37 --> Controller Class Initialized
INFO - 2020-11-10 01:24:37 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:37 --> Total execution time: 0.1617
INFO - 2020-11-10 01:24:42 --> Config Class Initialized
INFO - 2020-11-10 01:24:42 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:42 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:42 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:42 --> URI Class Initialized
INFO - 2020-11-10 01:24:42 --> Router Class Initialized
INFO - 2020-11-10 01:24:42 --> Output Class Initialized
INFO - 2020-11-10 01:24:42 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:42 --> Input Class Initialized
INFO - 2020-11-10 01:24:42 --> Language Class Initialized
INFO - 2020-11-10 01:24:42 --> Language Class Initialized
INFO - 2020-11-10 01:24:42 --> Config Class Initialized
INFO - 2020-11-10 01:24:42 --> Loader Class Initialized
INFO - 2020-11-10 01:24:42 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:42 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:42 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:42 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:42 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:42 --> Controller Class Initialized
INFO - 2020-11-10 01:24:42 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:42 --> Total execution time: 0.2074
INFO - 2020-11-10 01:24:46 --> Config Class Initialized
INFO - 2020-11-10 01:24:46 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:46 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:46 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:46 --> URI Class Initialized
INFO - 2020-11-10 01:24:46 --> Router Class Initialized
INFO - 2020-11-10 01:24:46 --> Output Class Initialized
INFO - 2020-11-10 01:24:46 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:46 --> Input Class Initialized
INFO - 2020-11-10 01:24:46 --> Language Class Initialized
INFO - 2020-11-10 01:24:46 --> Language Class Initialized
INFO - 2020-11-10 01:24:46 --> Config Class Initialized
INFO - 2020-11-10 01:24:46 --> Loader Class Initialized
INFO - 2020-11-10 01:24:46 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:46 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:46 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:46 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:46 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:46 --> Controller Class Initialized
DEBUG - 2020-11-10 01:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 01:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:24:47 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:47 --> Total execution time: 0.2268
INFO - 2020-11-10 01:24:47 --> Config Class Initialized
INFO - 2020-11-10 01:24:47 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:47 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:47 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:47 --> URI Class Initialized
INFO - 2020-11-10 01:24:48 --> Router Class Initialized
INFO - 2020-11-10 01:24:48 --> Output Class Initialized
INFO - 2020-11-10 01:24:48 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:48 --> Input Class Initialized
INFO - 2020-11-10 01:24:48 --> Language Class Initialized
INFO - 2020-11-10 01:24:48 --> Language Class Initialized
INFO - 2020-11-10 01:24:48 --> Config Class Initialized
INFO - 2020-11-10 01:24:48 --> Loader Class Initialized
INFO - 2020-11-10 01:24:48 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:48 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:48 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:48 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:48 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:48 --> Controller Class Initialized
DEBUG - 2020-11-10 01:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-10 01:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:24:48 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:48 --> Total execution time: 0.2664
INFO - 2020-11-10 01:24:50 --> Config Class Initialized
INFO - 2020-11-10 01:24:50 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:50 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:50 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:50 --> URI Class Initialized
INFO - 2020-11-10 01:24:50 --> Router Class Initialized
INFO - 2020-11-10 01:24:50 --> Output Class Initialized
INFO - 2020-11-10 01:24:50 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:50 --> Input Class Initialized
INFO - 2020-11-10 01:24:50 --> Language Class Initialized
INFO - 2020-11-10 01:24:50 --> Language Class Initialized
INFO - 2020-11-10 01:24:50 --> Config Class Initialized
INFO - 2020-11-10 01:24:50 --> Loader Class Initialized
INFO - 2020-11-10 01:24:50 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:50 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:50 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:50 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:50 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:50 --> Controller Class Initialized
INFO - 2020-11-10 01:24:50 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:50 --> Total execution time: 0.1840
INFO - 2020-11-10 01:24:52 --> Config Class Initialized
INFO - 2020-11-10 01:24:52 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:52 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:52 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:52 --> URI Class Initialized
INFO - 2020-11-10 01:24:52 --> Router Class Initialized
INFO - 2020-11-10 01:24:52 --> Output Class Initialized
INFO - 2020-11-10 01:24:52 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:52 --> Input Class Initialized
INFO - 2020-11-10 01:24:52 --> Language Class Initialized
INFO - 2020-11-10 01:24:52 --> Language Class Initialized
INFO - 2020-11-10 01:24:52 --> Config Class Initialized
INFO - 2020-11-10 01:24:52 --> Loader Class Initialized
INFO - 2020-11-10 01:24:52 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:52 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:52 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:52 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:52 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:52 --> Controller Class Initialized
DEBUG - 2020-11-10 01:24:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 01:24:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:24:52 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:52 --> Total execution time: 0.2583
INFO - 2020-11-10 01:24:54 --> Config Class Initialized
INFO - 2020-11-10 01:24:54 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:54 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:54 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:54 --> URI Class Initialized
INFO - 2020-11-10 01:24:54 --> Router Class Initialized
INFO - 2020-11-10 01:24:54 --> Output Class Initialized
INFO - 2020-11-10 01:24:54 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:54 --> Input Class Initialized
INFO - 2020-11-10 01:24:54 --> Language Class Initialized
INFO - 2020-11-10 01:24:54 --> Language Class Initialized
INFO - 2020-11-10 01:24:54 --> Config Class Initialized
INFO - 2020-11-10 01:24:54 --> Loader Class Initialized
INFO - 2020-11-10 01:24:54 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:54 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:54 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:54 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:54 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:54 --> Controller Class Initialized
DEBUG - 2020-11-10 01:24:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-10 01:24:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:24:54 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:54 --> Total execution time: 0.2199
INFO - 2020-11-10 01:24:54 --> Config Class Initialized
INFO - 2020-11-10 01:24:54 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:54 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:54 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:54 --> URI Class Initialized
INFO - 2020-11-10 01:24:54 --> Router Class Initialized
INFO - 2020-11-10 01:24:54 --> Output Class Initialized
INFO - 2020-11-10 01:24:54 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:54 --> Input Class Initialized
INFO - 2020-11-10 01:24:54 --> Language Class Initialized
INFO - 2020-11-10 01:24:54 --> Language Class Initialized
INFO - 2020-11-10 01:24:54 --> Config Class Initialized
INFO - 2020-11-10 01:24:54 --> Loader Class Initialized
INFO - 2020-11-10 01:24:54 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:54 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:54 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:54 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:54 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:54 --> Controller Class Initialized
INFO - 2020-11-10 01:24:55 --> Config Class Initialized
INFO - 2020-11-10 01:24:55 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:55 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:55 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:55 --> URI Class Initialized
INFO - 2020-11-10 01:24:55 --> Router Class Initialized
INFO - 2020-11-10 01:24:55 --> Output Class Initialized
INFO - 2020-11-10 01:24:55 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:55 --> Input Class Initialized
INFO - 2020-11-10 01:24:55 --> Language Class Initialized
INFO - 2020-11-10 01:24:55 --> Language Class Initialized
INFO - 2020-11-10 01:24:55 --> Config Class Initialized
INFO - 2020-11-10 01:24:55 --> Loader Class Initialized
INFO - 2020-11-10 01:24:55 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:56 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:56 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:56 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:56 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:56 --> Controller Class Initialized
INFO - 2020-11-10 01:24:56 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:56 --> Total execution time: 0.1679
INFO - 2020-11-10 01:24:57 --> Config Class Initialized
INFO - 2020-11-10 01:24:57 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:58 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:58 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:58 --> URI Class Initialized
INFO - 2020-11-10 01:24:58 --> Router Class Initialized
INFO - 2020-11-10 01:24:58 --> Output Class Initialized
INFO - 2020-11-10 01:24:58 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:58 --> Input Class Initialized
INFO - 2020-11-10 01:24:58 --> Language Class Initialized
INFO - 2020-11-10 01:24:58 --> Language Class Initialized
INFO - 2020-11-10 01:24:58 --> Config Class Initialized
INFO - 2020-11-10 01:24:58 --> Loader Class Initialized
INFO - 2020-11-10 01:24:58 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:58 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:58 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:58 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:58 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:58 --> Controller Class Initialized
DEBUG - 2020-11-10 01:24:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 01:24:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:24:58 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:58 --> Total execution time: 0.2612
INFO - 2020-11-10 01:24:59 --> Config Class Initialized
INFO - 2020-11-10 01:24:59 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:24:59 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:24:59 --> Utf8 Class Initialized
INFO - 2020-11-10 01:24:59 --> URI Class Initialized
INFO - 2020-11-10 01:24:59 --> Router Class Initialized
INFO - 2020-11-10 01:24:59 --> Output Class Initialized
INFO - 2020-11-10 01:24:59 --> Security Class Initialized
DEBUG - 2020-11-10 01:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:24:59 --> Input Class Initialized
INFO - 2020-11-10 01:24:59 --> Language Class Initialized
INFO - 2020-11-10 01:24:59 --> Language Class Initialized
INFO - 2020-11-10 01:24:59 --> Config Class Initialized
INFO - 2020-11-10 01:24:59 --> Loader Class Initialized
INFO - 2020-11-10 01:24:59 --> Helper loaded: url_helper
INFO - 2020-11-10 01:24:59 --> Helper loaded: file_helper
INFO - 2020-11-10 01:24:59 --> Helper loaded: form_helper
INFO - 2020-11-10 01:24:59 --> Helper loaded: my_helper
INFO - 2020-11-10 01:24:59 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:24:59 --> Controller Class Initialized
DEBUG - 2020-11-10 01:24:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-10 01:24:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:24:59 --> Final output sent to browser
DEBUG - 2020-11-10 01:24:59 --> Total execution time: 0.2121
INFO - 2020-11-10 01:25:00 --> Config Class Initialized
INFO - 2020-11-10 01:25:00 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:25:00 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:25:00 --> Utf8 Class Initialized
INFO - 2020-11-10 01:25:00 --> URI Class Initialized
INFO - 2020-11-10 01:25:00 --> Router Class Initialized
INFO - 2020-11-10 01:25:00 --> Output Class Initialized
INFO - 2020-11-10 01:25:00 --> Security Class Initialized
DEBUG - 2020-11-10 01:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:25:00 --> Input Class Initialized
INFO - 2020-11-10 01:25:00 --> Language Class Initialized
INFO - 2020-11-10 01:25:00 --> Language Class Initialized
INFO - 2020-11-10 01:25:00 --> Config Class Initialized
INFO - 2020-11-10 01:25:00 --> Loader Class Initialized
INFO - 2020-11-10 01:25:00 --> Helper loaded: url_helper
INFO - 2020-11-10 01:25:00 --> Helper loaded: file_helper
INFO - 2020-11-10 01:25:00 --> Helper loaded: form_helper
INFO - 2020-11-10 01:25:00 --> Helper loaded: my_helper
INFO - 2020-11-10 01:25:00 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:25:00 --> Controller Class Initialized
INFO - 2020-11-10 01:25:00 --> Final output sent to browser
DEBUG - 2020-11-10 01:25:00 --> Total execution time: 0.1761
INFO - 2020-11-10 01:25:06 --> Config Class Initialized
INFO - 2020-11-10 01:25:06 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:25:06 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:25:06 --> Utf8 Class Initialized
INFO - 2020-11-10 01:25:06 --> URI Class Initialized
INFO - 2020-11-10 01:25:06 --> Router Class Initialized
INFO - 2020-11-10 01:25:06 --> Output Class Initialized
INFO - 2020-11-10 01:25:06 --> Security Class Initialized
DEBUG - 2020-11-10 01:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:25:06 --> Input Class Initialized
INFO - 2020-11-10 01:25:06 --> Language Class Initialized
INFO - 2020-11-10 01:25:06 --> Language Class Initialized
INFO - 2020-11-10 01:25:06 --> Config Class Initialized
INFO - 2020-11-10 01:25:06 --> Loader Class Initialized
INFO - 2020-11-10 01:25:06 --> Helper loaded: url_helper
INFO - 2020-11-10 01:25:06 --> Helper loaded: file_helper
INFO - 2020-11-10 01:25:06 --> Helper loaded: form_helper
INFO - 2020-11-10 01:25:06 --> Helper loaded: my_helper
INFO - 2020-11-10 01:25:06 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:25:06 --> Controller Class Initialized
DEBUG - 2020-11-10 01:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-11-10 01:25:06 --> Final output sent to browser
DEBUG - 2020-11-10 01:25:06 --> Total execution time: 0.2801
INFO - 2020-11-10 01:26:03 --> Config Class Initialized
INFO - 2020-11-10 01:26:03 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:03 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:03 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:03 --> URI Class Initialized
INFO - 2020-11-10 01:26:03 --> Router Class Initialized
INFO - 2020-11-10 01:26:03 --> Output Class Initialized
INFO - 2020-11-10 01:26:03 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:03 --> Input Class Initialized
INFO - 2020-11-10 01:26:03 --> Language Class Initialized
INFO - 2020-11-10 01:26:03 --> Language Class Initialized
INFO - 2020-11-10 01:26:03 --> Config Class Initialized
INFO - 2020-11-10 01:26:03 --> Loader Class Initialized
INFO - 2020-11-10 01:26:03 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:03 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:03 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:03 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:03 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:03 --> Controller Class Initialized
DEBUG - 2020-11-10 01:26:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 01:26:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:26:03 --> Final output sent to browser
DEBUG - 2020-11-10 01:26:03 --> Total execution time: 0.3001
INFO - 2020-11-10 01:26:08 --> Config Class Initialized
INFO - 2020-11-10 01:26:08 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:08 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:08 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:08 --> URI Class Initialized
INFO - 2020-11-10 01:26:08 --> Router Class Initialized
INFO - 2020-11-10 01:26:08 --> Output Class Initialized
INFO - 2020-11-10 01:26:08 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:08 --> Input Class Initialized
INFO - 2020-11-10 01:26:08 --> Language Class Initialized
INFO - 2020-11-10 01:26:08 --> Language Class Initialized
INFO - 2020-11-10 01:26:08 --> Config Class Initialized
INFO - 2020-11-10 01:26:08 --> Loader Class Initialized
INFO - 2020-11-10 01:26:08 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:08 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:08 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:08 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:08 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:08 --> Controller Class Initialized
DEBUG - 2020-11-10 01:26:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-10 01:26:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:26:08 --> Final output sent to browser
DEBUG - 2020-11-10 01:26:08 --> Total execution time: 0.3098
INFO - 2020-11-10 01:26:26 --> Config Class Initialized
INFO - 2020-11-10 01:26:26 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:26 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:26 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:26 --> URI Class Initialized
INFO - 2020-11-10 01:26:26 --> Router Class Initialized
INFO - 2020-11-10 01:26:26 --> Output Class Initialized
INFO - 2020-11-10 01:26:26 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:26 --> Input Class Initialized
INFO - 2020-11-10 01:26:26 --> Language Class Initialized
INFO - 2020-11-10 01:26:26 --> Language Class Initialized
INFO - 2020-11-10 01:26:26 --> Config Class Initialized
INFO - 2020-11-10 01:26:26 --> Loader Class Initialized
INFO - 2020-11-10 01:26:26 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:26 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:26 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:26 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:26 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:26 --> Controller Class Initialized
DEBUG - 2020-11-10 01:26:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 01:26:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:26:26 --> Final output sent to browser
DEBUG - 2020-11-10 01:26:26 --> Total execution time: 0.2228
INFO - 2020-11-10 01:26:33 --> Config Class Initialized
INFO - 2020-11-10 01:26:33 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:33 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:33 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:33 --> URI Class Initialized
INFO - 2020-11-10 01:26:33 --> Router Class Initialized
INFO - 2020-11-10 01:26:33 --> Output Class Initialized
INFO - 2020-11-10 01:26:33 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:33 --> Input Class Initialized
INFO - 2020-11-10 01:26:33 --> Language Class Initialized
INFO - 2020-11-10 01:26:33 --> Language Class Initialized
INFO - 2020-11-10 01:26:33 --> Config Class Initialized
INFO - 2020-11-10 01:26:33 --> Loader Class Initialized
INFO - 2020-11-10 01:26:33 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:33 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:33 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:33 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:33 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:33 --> Controller Class Initialized
DEBUG - 2020-11-10 01:26:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-10 01:26:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:26:33 --> Final output sent to browser
DEBUG - 2020-11-10 01:26:33 --> Total execution time: 0.2300
INFO - 2020-11-10 01:26:46 --> Config Class Initialized
INFO - 2020-11-10 01:26:46 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:46 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:46 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:46 --> URI Class Initialized
INFO - 2020-11-10 01:26:46 --> Router Class Initialized
INFO - 2020-11-10 01:26:46 --> Output Class Initialized
INFO - 2020-11-10 01:26:46 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:46 --> Input Class Initialized
INFO - 2020-11-10 01:26:46 --> Language Class Initialized
INFO - 2020-11-10 01:26:47 --> Language Class Initialized
INFO - 2020-11-10 01:26:47 --> Config Class Initialized
INFO - 2020-11-10 01:26:47 --> Loader Class Initialized
INFO - 2020-11-10 01:26:47 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:47 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:47 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:47 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:47 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:47 --> Controller Class Initialized
INFO - 2020-11-10 01:26:47 --> Helper loaded: cookie_helper
INFO - 2020-11-10 01:26:47 --> Config Class Initialized
INFO - 2020-11-10 01:26:47 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:47 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:47 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:47 --> URI Class Initialized
INFO - 2020-11-10 01:26:47 --> Router Class Initialized
INFO - 2020-11-10 01:26:47 --> Output Class Initialized
INFO - 2020-11-10 01:26:47 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:47 --> Input Class Initialized
INFO - 2020-11-10 01:26:47 --> Language Class Initialized
INFO - 2020-11-10 01:26:47 --> Language Class Initialized
INFO - 2020-11-10 01:26:47 --> Config Class Initialized
INFO - 2020-11-10 01:26:47 --> Loader Class Initialized
INFO - 2020-11-10 01:26:47 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:47 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:47 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:47 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:47 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:47 --> Controller Class Initialized
DEBUG - 2020-11-10 01:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 01:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:26:47 --> Final output sent to browser
DEBUG - 2020-11-10 01:26:47 --> Total execution time: 0.2684
INFO - 2020-11-10 01:26:52 --> Config Class Initialized
INFO - 2020-11-10 01:26:52 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:52 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:52 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:52 --> URI Class Initialized
INFO - 2020-11-10 01:26:52 --> Router Class Initialized
INFO - 2020-11-10 01:26:52 --> Output Class Initialized
INFO - 2020-11-10 01:26:52 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:52 --> Input Class Initialized
INFO - 2020-11-10 01:26:52 --> Language Class Initialized
INFO - 2020-11-10 01:26:52 --> Language Class Initialized
INFO - 2020-11-10 01:26:52 --> Config Class Initialized
INFO - 2020-11-10 01:26:52 --> Loader Class Initialized
INFO - 2020-11-10 01:26:52 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:52 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:52 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:52 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:52 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:52 --> Controller Class Initialized
INFO - 2020-11-10 01:26:52 --> Helper loaded: cookie_helper
INFO - 2020-11-10 01:26:52 --> Final output sent to browser
DEBUG - 2020-11-10 01:26:52 --> Total execution time: 0.2937
INFO - 2020-11-10 01:26:53 --> Config Class Initialized
INFO - 2020-11-10 01:26:53 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:53 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:53 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:53 --> URI Class Initialized
INFO - 2020-11-10 01:26:53 --> Router Class Initialized
INFO - 2020-11-10 01:26:53 --> Output Class Initialized
INFO - 2020-11-10 01:26:53 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:53 --> Input Class Initialized
INFO - 2020-11-10 01:26:53 --> Language Class Initialized
INFO - 2020-11-10 01:26:53 --> Language Class Initialized
INFO - 2020-11-10 01:26:53 --> Config Class Initialized
INFO - 2020-11-10 01:26:53 --> Loader Class Initialized
INFO - 2020-11-10 01:26:53 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:53 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:53 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:53 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:53 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:53 --> Controller Class Initialized
DEBUG - 2020-11-10 01:26:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 01:26:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:26:53 --> Final output sent to browser
DEBUG - 2020-11-10 01:26:53 --> Total execution time: 0.3524
INFO - 2020-11-10 01:26:55 --> Config Class Initialized
INFO - 2020-11-10 01:26:55 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:55 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:55 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:55 --> URI Class Initialized
INFO - 2020-11-10 01:26:55 --> Router Class Initialized
INFO - 2020-11-10 01:26:55 --> Output Class Initialized
INFO - 2020-11-10 01:26:55 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:55 --> Input Class Initialized
INFO - 2020-11-10 01:26:55 --> Language Class Initialized
INFO - 2020-11-10 01:26:55 --> Language Class Initialized
INFO - 2020-11-10 01:26:55 --> Config Class Initialized
INFO - 2020-11-10 01:26:55 --> Loader Class Initialized
INFO - 2020-11-10 01:26:55 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:55 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:55 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:55 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:55 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:56 --> Controller Class Initialized
DEBUG - 2020-11-10 01:26:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-10 01:26:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:26:56 --> Final output sent to browser
DEBUG - 2020-11-10 01:26:56 --> Total execution time: 0.2447
INFO - 2020-11-10 01:26:56 --> Config Class Initialized
INFO - 2020-11-10 01:26:56 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:26:56 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:26:56 --> Utf8 Class Initialized
INFO - 2020-11-10 01:26:56 --> URI Class Initialized
INFO - 2020-11-10 01:26:56 --> Router Class Initialized
INFO - 2020-11-10 01:26:56 --> Output Class Initialized
INFO - 2020-11-10 01:26:56 --> Security Class Initialized
DEBUG - 2020-11-10 01:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:26:56 --> Input Class Initialized
INFO - 2020-11-10 01:26:56 --> Language Class Initialized
INFO - 2020-11-10 01:26:56 --> Language Class Initialized
INFO - 2020-11-10 01:26:56 --> Config Class Initialized
INFO - 2020-11-10 01:26:56 --> Loader Class Initialized
INFO - 2020-11-10 01:26:56 --> Helper loaded: url_helper
INFO - 2020-11-10 01:26:56 --> Helper loaded: file_helper
INFO - 2020-11-10 01:26:56 --> Helper loaded: form_helper
INFO - 2020-11-10 01:26:56 --> Helper loaded: my_helper
INFO - 2020-11-10 01:26:56 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:26:56 --> Controller Class Initialized
INFO - 2020-11-10 01:27:24 --> Config Class Initialized
INFO - 2020-11-10 01:27:24 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:27:24 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:27:24 --> Utf8 Class Initialized
INFO - 2020-11-10 01:27:24 --> URI Class Initialized
INFO - 2020-11-10 01:27:24 --> Router Class Initialized
INFO - 2020-11-10 01:27:24 --> Output Class Initialized
INFO - 2020-11-10 01:27:24 --> Security Class Initialized
DEBUG - 2020-11-10 01:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:27:24 --> Input Class Initialized
INFO - 2020-11-10 01:27:24 --> Language Class Initialized
INFO - 2020-11-10 01:27:24 --> Language Class Initialized
INFO - 2020-11-10 01:27:24 --> Config Class Initialized
INFO - 2020-11-10 01:27:24 --> Loader Class Initialized
INFO - 2020-11-10 01:27:24 --> Helper loaded: url_helper
INFO - 2020-11-10 01:27:24 --> Helper loaded: file_helper
INFO - 2020-11-10 01:27:24 --> Helper loaded: form_helper
INFO - 2020-11-10 01:27:24 --> Helper loaded: my_helper
INFO - 2020-11-10 01:27:24 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:27:24 --> Controller Class Initialized
DEBUG - 2020-11-10 01:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-11-10 01:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:27:24 --> Final output sent to browser
DEBUG - 2020-11-10 01:27:24 --> Total execution time: 0.2621
INFO - 2020-11-10 01:27:24 --> Config Class Initialized
INFO - 2020-11-10 01:27:24 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:27:24 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:27:24 --> Utf8 Class Initialized
INFO - 2020-11-10 01:27:24 --> URI Class Initialized
INFO - 2020-11-10 01:27:24 --> Router Class Initialized
INFO - 2020-11-10 01:27:24 --> Output Class Initialized
INFO - 2020-11-10 01:27:24 --> Security Class Initialized
DEBUG - 2020-11-10 01:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:27:24 --> Input Class Initialized
INFO - 2020-11-10 01:27:24 --> Language Class Initialized
INFO - 2020-11-10 01:27:24 --> Language Class Initialized
INFO - 2020-11-10 01:27:25 --> Config Class Initialized
INFO - 2020-11-10 01:27:25 --> Loader Class Initialized
INFO - 2020-11-10 01:27:25 --> Helper loaded: url_helper
INFO - 2020-11-10 01:27:25 --> Helper loaded: file_helper
INFO - 2020-11-10 01:27:25 --> Helper loaded: form_helper
INFO - 2020-11-10 01:27:25 --> Helper loaded: my_helper
INFO - 2020-11-10 01:27:25 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:27:25 --> Controller Class Initialized
INFO - 2020-11-10 01:27:34 --> Config Class Initialized
INFO - 2020-11-10 01:27:34 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:27:34 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:27:34 --> Utf8 Class Initialized
INFO - 2020-11-10 01:27:34 --> URI Class Initialized
INFO - 2020-11-10 01:27:34 --> Router Class Initialized
INFO - 2020-11-10 01:27:34 --> Output Class Initialized
INFO - 2020-11-10 01:27:34 --> Security Class Initialized
DEBUG - 2020-11-10 01:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:27:34 --> Input Class Initialized
INFO - 2020-11-10 01:27:34 --> Language Class Initialized
INFO - 2020-11-10 01:27:34 --> Language Class Initialized
INFO - 2020-11-10 01:27:34 --> Config Class Initialized
INFO - 2020-11-10 01:27:34 --> Loader Class Initialized
INFO - 2020-11-10 01:27:34 --> Helper loaded: url_helper
INFO - 2020-11-10 01:27:34 --> Helper loaded: file_helper
INFO - 2020-11-10 01:27:34 --> Helper loaded: form_helper
INFO - 2020-11-10 01:27:34 --> Helper loaded: my_helper
INFO - 2020-11-10 01:27:34 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:27:34 --> Controller Class Initialized
DEBUG - 2020-11-10 01:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-10 01:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:27:34 --> Final output sent to browser
DEBUG - 2020-11-10 01:27:34 --> Total execution time: 0.2657
INFO - 2020-11-10 01:27:34 --> Config Class Initialized
INFO - 2020-11-10 01:27:34 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:27:34 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:27:34 --> Utf8 Class Initialized
INFO - 2020-11-10 01:27:34 --> URI Class Initialized
INFO - 2020-11-10 01:27:34 --> Router Class Initialized
INFO - 2020-11-10 01:27:34 --> Output Class Initialized
INFO - 2020-11-10 01:27:34 --> Security Class Initialized
DEBUG - 2020-11-10 01:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:27:34 --> Input Class Initialized
INFO - 2020-11-10 01:27:34 --> Language Class Initialized
INFO - 2020-11-10 01:27:34 --> Language Class Initialized
INFO - 2020-11-10 01:27:34 --> Config Class Initialized
INFO - 2020-11-10 01:27:34 --> Loader Class Initialized
INFO - 2020-11-10 01:27:34 --> Helper loaded: url_helper
INFO - 2020-11-10 01:27:34 --> Helper loaded: file_helper
INFO - 2020-11-10 01:27:34 --> Helper loaded: form_helper
INFO - 2020-11-10 01:27:34 --> Helper loaded: my_helper
INFO - 2020-11-10 01:27:34 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:27:34 --> Controller Class Initialized
INFO - 2020-11-10 01:27:38 --> Config Class Initialized
INFO - 2020-11-10 01:27:38 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:27:38 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:27:38 --> Utf8 Class Initialized
INFO - 2020-11-10 01:27:38 --> URI Class Initialized
INFO - 2020-11-10 01:27:38 --> Router Class Initialized
INFO - 2020-11-10 01:27:38 --> Output Class Initialized
INFO - 2020-11-10 01:27:38 --> Security Class Initialized
DEBUG - 2020-11-10 01:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:27:38 --> Input Class Initialized
INFO - 2020-11-10 01:27:38 --> Language Class Initialized
INFO - 2020-11-10 01:27:38 --> Language Class Initialized
INFO - 2020-11-10 01:27:38 --> Config Class Initialized
INFO - 2020-11-10 01:27:38 --> Loader Class Initialized
INFO - 2020-11-10 01:27:38 --> Helper loaded: url_helper
INFO - 2020-11-10 01:27:38 --> Helper loaded: file_helper
INFO - 2020-11-10 01:27:38 --> Helper loaded: form_helper
INFO - 2020-11-10 01:27:38 --> Helper loaded: my_helper
INFO - 2020-11-10 01:27:38 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:27:38 --> Controller Class Initialized
DEBUG - 2020-11-10 01:27:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-11-10 01:27:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:27:38 --> Final output sent to browser
DEBUG - 2020-11-10 01:27:38 --> Total execution time: 0.2612
INFO - 2020-11-10 01:27:38 --> Config Class Initialized
INFO - 2020-11-10 01:27:38 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:27:38 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:27:38 --> Utf8 Class Initialized
INFO - 2020-11-10 01:27:38 --> URI Class Initialized
INFO - 2020-11-10 01:27:38 --> Router Class Initialized
INFO - 2020-11-10 01:27:38 --> Output Class Initialized
INFO - 2020-11-10 01:27:38 --> Security Class Initialized
DEBUG - 2020-11-10 01:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:27:38 --> Input Class Initialized
INFO - 2020-11-10 01:27:38 --> Language Class Initialized
INFO - 2020-11-10 01:27:38 --> Language Class Initialized
INFO - 2020-11-10 01:27:38 --> Config Class Initialized
INFO - 2020-11-10 01:27:38 --> Loader Class Initialized
INFO - 2020-11-10 01:27:38 --> Helper loaded: url_helper
INFO - 2020-11-10 01:27:38 --> Helper loaded: file_helper
INFO - 2020-11-10 01:27:38 --> Helper loaded: form_helper
INFO - 2020-11-10 01:27:38 --> Helper loaded: my_helper
INFO - 2020-11-10 01:27:38 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:27:39 --> Controller Class Initialized
INFO - 2020-11-10 01:27:42 --> Config Class Initialized
INFO - 2020-11-10 01:27:42 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:27:42 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:27:42 --> Utf8 Class Initialized
INFO - 2020-11-10 01:27:42 --> URI Class Initialized
INFO - 2020-11-10 01:27:42 --> Router Class Initialized
INFO - 2020-11-10 01:27:42 --> Output Class Initialized
INFO - 2020-11-10 01:27:42 --> Security Class Initialized
DEBUG - 2020-11-10 01:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:27:42 --> Input Class Initialized
INFO - 2020-11-10 01:27:42 --> Language Class Initialized
INFO - 2020-11-10 01:27:42 --> Language Class Initialized
INFO - 2020-11-10 01:27:42 --> Config Class Initialized
INFO - 2020-11-10 01:27:42 --> Loader Class Initialized
INFO - 2020-11-10 01:27:42 --> Helper loaded: url_helper
INFO - 2020-11-10 01:27:42 --> Helper loaded: file_helper
INFO - 2020-11-10 01:27:42 --> Helper loaded: form_helper
INFO - 2020-11-10 01:27:42 --> Helper loaded: my_helper
INFO - 2020-11-10 01:27:42 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:27:43 --> Controller Class Initialized
DEBUG - 2020-11-10 01:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-10 01:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:27:43 --> Final output sent to browser
DEBUG - 2020-11-10 01:27:43 --> Total execution time: 0.3272
INFO - 2020-11-10 01:27:43 --> Config Class Initialized
INFO - 2020-11-10 01:27:43 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:27:43 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:27:43 --> Utf8 Class Initialized
INFO - 2020-11-10 01:27:43 --> URI Class Initialized
INFO - 2020-11-10 01:27:43 --> Router Class Initialized
INFO - 2020-11-10 01:27:43 --> Output Class Initialized
INFO - 2020-11-10 01:27:43 --> Security Class Initialized
DEBUG - 2020-11-10 01:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:27:43 --> Input Class Initialized
INFO - 2020-11-10 01:27:43 --> Language Class Initialized
INFO - 2020-11-10 01:27:43 --> Language Class Initialized
INFO - 2020-11-10 01:27:43 --> Config Class Initialized
INFO - 2020-11-10 01:27:43 --> Loader Class Initialized
INFO - 2020-11-10 01:27:43 --> Helper loaded: url_helper
INFO - 2020-11-10 01:27:43 --> Helper loaded: file_helper
INFO - 2020-11-10 01:27:43 --> Helper loaded: form_helper
INFO - 2020-11-10 01:27:43 --> Helper loaded: my_helper
INFO - 2020-11-10 01:27:43 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:27:43 --> Controller Class Initialized
INFO - 2020-11-10 01:27:52 --> Config Class Initialized
INFO - 2020-11-10 01:27:52 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:27:52 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:27:52 --> Utf8 Class Initialized
INFO - 2020-11-10 01:27:52 --> URI Class Initialized
INFO - 2020-11-10 01:27:52 --> Router Class Initialized
INFO - 2020-11-10 01:27:52 --> Output Class Initialized
INFO - 2020-11-10 01:27:52 --> Security Class Initialized
DEBUG - 2020-11-10 01:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:27:52 --> Input Class Initialized
INFO - 2020-11-10 01:27:52 --> Language Class Initialized
INFO - 2020-11-10 01:27:52 --> Language Class Initialized
INFO - 2020-11-10 01:27:52 --> Config Class Initialized
INFO - 2020-11-10 01:27:52 --> Loader Class Initialized
INFO - 2020-11-10 01:27:52 --> Helper loaded: url_helper
INFO - 2020-11-10 01:27:52 --> Helper loaded: file_helper
INFO - 2020-11-10 01:27:52 --> Helper loaded: form_helper
INFO - 2020-11-10 01:27:52 --> Helper loaded: my_helper
INFO - 2020-11-10 01:27:52 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:27:52 --> Controller Class Initialized
DEBUG - 2020-11-10 01:27:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-10 01:27:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:27:52 --> Final output sent to browser
DEBUG - 2020-11-10 01:27:52 --> Total execution time: 0.2790
INFO - 2020-11-10 01:28:02 --> Config Class Initialized
INFO - 2020-11-10 01:28:02 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:02 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:02 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:02 --> URI Class Initialized
INFO - 2020-11-10 01:28:02 --> Router Class Initialized
INFO - 2020-11-10 01:28:02 --> Output Class Initialized
INFO - 2020-11-10 01:28:02 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:02 --> Input Class Initialized
INFO - 2020-11-10 01:28:02 --> Language Class Initialized
INFO - 2020-11-10 01:28:02 --> Language Class Initialized
INFO - 2020-11-10 01:28:02 --> Config Class Initialized
INFO - 2020-11-10 01:28:02 --> Loader Class Initialized
INFO - 2020-11-10 01:28:02 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:02 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:02 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:02 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:02 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:02 --> Controller Class Initialized
DEBUG - 2020-11-10 01:28:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-10 01:28:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:28:02 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:02 --> Total execution time: 0.3001
INFO - 2020-11-10 01:28:02 --> Config Class Initialized
INFO - 2020-11-10 01:28:02 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:02 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:02 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:02 --> URI Class Initialized
INFO - 2020-11-10 01:28:02 --> Router Class Initialized
INFO - 2020-11-10 01:28:02 --> Output Class Initialized
INFO - 2020-11-10 01:28:03 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:03 --> Input Class Initialized
INFO - 2020-11-10 01:28:03 --> Language Class Initialized
INFO - 2020-11-10 01:28:03 --> Language Class Initialized
INFO - 2020-11-10 01:28:03 --> Config Class Initialized
INFO - 2020-11-10 01:28:03 --> Loader Class Initialized
INFO - 2020-11-10 01:28:03 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:03 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:03 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:03 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:03 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:03 --> Controller Class Initialized
INFO - 2020-11-10 01:28:10 --> Config Class Initialized
INFO - 2020-11-10 01:28:10 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:10 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:10 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:10 --> URI Class Initialized
INFO - 2020-11-10 01:28:10 --> Router Class Initialized
INFO - 2020-11-10 01:28:10 --> Output Class Initialized
INFO - 2020-11-10 01:28:10 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:10 --> Input Class Initialized
INFO - 2020-11-10 01:28:10 --> Language Class Initialized
INFO - 2020-11-10 01:28:10 --> Language Class Initialized
INFO - 2020-11-10 01:28:10 --> Config Class Initialized
INFO - 2020-11-10 01:28:10 --> Loader Class Initialized
INFO - 2020-11-10 01:28:10 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:10 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:10 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:10 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:10 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:10 --> Controller Class Initialized
DEBUG - 2020-11-10 01:28:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-11-10 01:28:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:28:10 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:11 --> Total execution time: 0.2893
INFO - 2020-11-10 01:28:11 --> Config Class Initialized
INFO - 2020-11-10 01:28:11 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:11 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:11 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:11 --> URI Class Initialized
INFO - 2020-11-10 01:28:11 --> Router Class Initialized
INFO - 2020-11-10 01:28:11 --> Output Class Initialized
INFO - 2020-11-10 01:28:11 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:11 --> Input Class Initialized
INFO - 2020-11-10 01:28:11 --> Language Class Initialized
INFO - 2020-11-10 01:28:11 --> Language Class Initialized
INFO - 2020-11-10 01:28:11 --> Config Class Initialized
INFO - 2020-11-10 01:28:11 --> Loader Class Initialized
INFO - 2020-11-10 01:28:11 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:11 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:11 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:11 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:11 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:11 --> Controller Class Initialized
INFO - 2020-11-10 01:28:18 --> Config Class Initialized
INFO - 2020-11-10 01:28:18 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:18 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:18 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:18 --> URI Class Initialized
INFO - 2020-11-10 01:28:18 --> Router Class Initialized
INFO - 2020-11-10 01:28:18 --> Output Class Initialized
INFO - 2020-11-10 01:28:18 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:18 --> Input Class Initialized
INFO - 2020-11-10 01:28:18 --> Language Class Initialized
INFO - 2020-11-10 01:28:18 --> Language Class Initialized
INFO - 2020-11-10 01:28:18 --> Config Class Initialized
INFO - 2020-11-10 01:28:18 --> Loader Class Initialized
INFO - 2020-11-10 01:28:18 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:18 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:18 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:18 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:18 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:18 --> Controller Class Initialized
DEBUG - 2020-11-10 01:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-10 01:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:28:18 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:18 --> Total execution time: 0.2493
INFO - 2020-11-10 01:28:18 --> Config Class Initialized
INFO - 2020-11-10 01:28:18 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:18 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:18 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:18 --> URI Class Initialized
INFO - 2020-11-10 01:28:18 --> Router Class Initialized
INFO - 2020-11-10 01:28:18 --> Output Class Initialized
INFO - 2020-11-10 01:28:18 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:18 --> Input Class Initialized
INFO - 2020-11-10 01:28:18 --> Language Class Initialized
INFO - 2020-11-10 01:28:18 --> Language Class Initialized
INFO - 2020-11-10 01:28:18 --> Config Class Initialized
INFO - 2020-11-10 01:28:18 --> Loader Class Initialized
INFO - 2020-11-10 01:28:18 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:18 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:18 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:18 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:18 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:19 --> Controller Class Initialized
INFO - 2020-11-10 01:28:27 --> Config Class Initialized
INFO - 2020-11-10 01:28:27 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:27 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:27 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:27 --> URI Class Initialized
INFO - 2020-11-10 01:28:27 --> Router Class Initialized
INFO - 2020-11-10 01:28:27 --> Output Class Initialized
INFO - 2020-11-10 01:28:27 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:27 --> Input Class Initialized
INFO - 2020-11-10 01:28:27 --> Language Class Initialized
INFO - 2020-11-10 01:28:27 --> Language Class Initialized
INFO - 2020-11-10 01:28:27 --> Config Class Initialized
INFO - 2020-11-10 01:28:27 --> Loader Class Initialized
INFO - 2020-11-10 01:28:27 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:27 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:27 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:27 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:27 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:27 --> Controller Class Initialized
DEBUG - 2020-11-10 01:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-11-10 01:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:28:27 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:27 --> Total execution time: 0.2625
INFO - 2020-11-10 01:28:28 --> Config Class Initialized
INFO - 2020-11-10 01:28:28 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:28 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:28 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:28 --> URI Class Initialized
INFO - 2020-11-10 01:28:28 --> Router Class Initialized
INFO - 2020-11-10 01:28:28 --> Output Class Initialized
INFO - 2020-11-10 01:28:28 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:28 --> Input Class Initialized
INFO - 2020-11-10 01:28:28 --> Language Class Initialized
INFO - 2020-11-10 01:28:28 --> Language Class Initialized
INFO - 2020-11-10 01:28:28 --> Config Class Initialized
INFO - 2020-11-10 01:28:28 --> Loader Class Initialized
INFO - 2020-11-10 01:28:28 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:28 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:28 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:28 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:28 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:28 --> Controller Class Initialized
INFO - 2020-11-10 01:28:30 --> Config Class Initialized
INFO - 2020-11-10 01:28:30 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:30 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:30 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:30 --> URI Class Initialized
INFO - 2020-11-10 01:28:30 --> Router Class Initialized
INFO - 2020-11-10 01:28:30 --> Output Class Initialized
INFO - 2020-11-10 01:28:30 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:30 --> Input Class Initialized
INFO - 2020-11-10 01:28:30 --> Language Class Initialized
INFO - 2020-11-10 01:28:30 --> Language Class Initialized
INFO - 2020-11-10 01:28:30 --> Config Class Initialized
INFO - 2020-11-10 01:28:30 --> Loader Class Initialized
INFO - 2020-11-10 01:28:30 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:30 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:30 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:30 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:30 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:30 --> Controller Class Initialized
INFO - 2020-11-10 01:28:30 --> Helper loaded: cookie_helper
INFO - 2020-11-10 01:28:30 --> Config Class Initialized
INFO - 2020-11-10 01:28:30 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:30 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:30 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:30 --> URI Class Initialized
INFO - 2020-11-10 01:28:30 --> Router Class Initialized
INFO - 2020-11-10 01:28:30 --> Output Class Initialized
INFO - 2020-11-10 01:28:30 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:30 --> Input Class Initialized
INFO - 2020-11-10 01:28:30 --> Language Class Initialized
INFO - 2020-11-10 01:28:30 --> Language Class Initialized
INFO - 2020-11-10 01:28:30 --> Config Class Initialized
INFO - 2020-11-10 01:28:30 --> Loader Class Initialized
INFO - 2020-11-10 01:28:30 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:30 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:30 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:30 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:30 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:30 --> Controller Class Initialized
DEBUG - 2020-11-10 01:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 01:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:28:31 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:31 --> Total execution time: 0.2722
INFO - 2020-11-10 01:28:35 --> Config Class Initialized
INFO - 2020-11-10 01:28:35 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:35 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:35 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:35 --> URI Class Initialized
INFO - 2020-11-10 01:28:35 --> Router Class Initialized
INFO - 2020-11-10 01:28:35 --> Output Class Initialized
INFO - 2020-11-10 01:28:35 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:35 --> Input Class Initialized
INFO - 2020-11-10 01:28:35 --> Language Class Initialized
INFO - 2020-11-10 01:28:35 --> Language Class Initialized
INFO - 2020-11-10 01:28:35 --> Config Class Initialized
INFO - 2020-11-10 01:28:35 --> Loader Class Initialized
INFO - 2020-11-10 01:28:35 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:35 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:35 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:35 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:35 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:35 --> Controller Class Initialized
INFO - 2020-11-10 01:28:35 --> Helper loaded: cookie_helper
INFO - 2020-11-10 01:28:35 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:35 --> Total execution time: 0.3165
INFO - 2020-11-10 01:28:36 --> Config Class Initialized
INFO - 2020-11-10 01:28:36 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:36 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:36 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:36 --> URI Class Initialized
INFO - 2020-11-10 01:28:36 --> Router Class Initialized
INFO - 2020-11-10 01:28:36 --> Output Class Initialized
INFO - 2020-11-10 01:28:36 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:36 --> Input Class Initialized
INFO - 2020-11-10 01:28:36 --> Language Class Initialized
INFO - 2020-11-10 01:28:36 --> Language Class Initialized
INFO - 2020-11-10 01:28:36 --> Config Class Initialized
INFO - 2020-11-10 01:28:36 --> Loader Class Initialized
INFO - 2020-11-10 01:28:36 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:36 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:36 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:36 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:37 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:37 --> Controller Class Initialized
DEBUG - 2020-11-10 01:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 01:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:28:37 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:37 --> Total execution time: 0.3547
INFO - 2020-11-10 01:28:53 --> Config Class Initialized
INFO - 2020-11-10 01:28:53 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:53 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:53 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:53 --> URI Class Initialized
INFO - 2020-11-10 01:28:53 --> Router Class Initialized
INFO - 2020-11-10 01:28:53 --> Output Class Initialized
INFO - 2020-11-10 01:28:53 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:53 --> Input Class Initialized
INFO - 2020-11-10 01:28:53 --> Language Class Initialized
INFO - 2020-11-10 01:28:53 --> Language Class Initialized
INFO - 2020-11-10 01:28:53 --> Config Class Initialized
INFO - 2020-11-10 01:28:53 --> Loader Class Initialized
INFO - 2020-11-10 01:28:53 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:53 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:53 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:53 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:53 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:53 --> Controller Class Initialized
DEBUG - 2020-11-10 01:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-10 01:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:28:53 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:53 --> Total execution time: 0.3233
INFO - 2020-11-10 01:28:53 --> Config Class Initialized
INFO - 2020-11-10 01:28:53 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:53 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:53 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:53 --> URI Class Initialized
INFO - 2020-11-10 01:28:53 --> Router Class Initialized
INFO - 2020-11-10 01:28:53 --> Output Class Initialized
INFO - 2020-11-10 01:28:53 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:53 --> Input Class Initialized
INFO - 2020-11-10 01:28:53 --> Language Class Initialized
INFO - 2020-11-10 01:28:53 --> Language Class Initialized
INFO - 2020-11-10 01:28:53 --> Config Class Initialized
INFO - 2020-11-10 01:28:53 --> Loader Class Initialized
INFO - 2020-11-10 01:28:53 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:53 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:53 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:53 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:53 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:53 --> Controller Class Initialized
INFO - 2020-11-10 01:28:54 --> Config Class Initialized
INFO - 2020-11-10 01:28:54 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:54 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:54 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:54 --> URI Class Initialized
INFO - 2020-11-10 01:28:54 --> Router Class Initialized
INFO - 2020-11-10 01:28:54 --> Output Class Initialized
INFO - 2020-11-10 01:28:54 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:54 --> Input Class Initialized
INFO - 2020-11-10 01:28:54 --> Language Class Initialized
INFO - 2020-11-10 01:28:54 --> Language Class Initialized
INFO - 2020-11-10 01:28:54 --> Config Class Initialized
INFO - 2020-11-10 01:28:54 --> Loader Class Initialized
INFO - 2020-11-10 01:28:54 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:54 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:54 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:54 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:54 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:55 --> Controller Class Initialized
DEBUG - 2020-11-10 01:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-10 01:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:28:55 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:55 --> Total execution time: 0.3356
INFO - 2020-11-10 01:28:59 --> Config Class Initialized
INFO - 2020-11-10 01:28:59 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:28:59 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:28:59 --> Utf8 Class Initialized
INFO - 2020-11-10 01:28:59 --> URI Class Initialized
INFO - 2020-11-10 01:28:59 --> Router Class Initialized
INFO - 2020-11-10 01:28:59 --> Output Class Initialized
INFO - 2020-11-10 01:28:59 --> Security Class Initialized
DEBUG - 2020-11-10 01:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:28:59 --> Input Class Initialized
INFO - 2020-11-10 01:28:59 --> Language Class Initialized
INFO - 2020-11-10 01:28:59 --> Language Class Initialized
INFO - 2020-11-10 01:28:59 --> Config Class Initialized
INFO - 2020-11-10 01:28:59 --> Loader Class Initialized
INFO - 2020-11-10 01:28:59 --> Helper loaded: url_helper
INFO - 2020-11-10 01:28:59 --> Helper loaded: file_helper
INFO - 2020-11-10 01:28:59 --> Helper loaded: form_helper
INFO - 2020-11-10 01:28:59 --> Helper loaded: my_helper
INFO - 2020-11-10 01:28:59 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:28:59 --> Controller Class Initialized
INFO - 2020-11-10 01:28:59 --> Final output sent to browser
DEBUG - 2020-11-10 01:28:59 --> Total execution time: 0.2216
INFO - 2020-11-10 01:29:12 --> Config Class Initialized
INFO - 2020-11-10 01:29:12 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:29:12 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:29:12 --> Utf8 Class Initialized
INFO - 2020-11-10 01:29:12 --> URI Class Initialized
INFO - 2020-11-10 01:29:12 --> Router Class Initialized
INFO - 2020-11-10 01:29:12 --> Output Class Initialized
INFO - 2020-11-10 01:29:12 --> Security Class Initialized
DEBUG - 2020-11-10 01:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:29:12 --> Input Class Initialized
INFO - 2020-11-10 01:29:12 --> Language Class Initialized
INFO - 2020-11-10 01:29:12 --> Language Class Initialized
INFO - 2020-11-10 01:29:12 --> Config Class Initialized
INFO - 2020-11-10 01:29:12 --> Loader Class Initialized
INFO - 2020-11-10 01:29:12 --> Helper loaded: url_helper
INFO - 2020-11-10 01:29:12 --> Helper loaded: file_helper
INFO - 2020-11-10 01:29:12 --> Helper loaded: form_helper
INFO - 2020-11-10 01:29:12 --> Helper loaded: my_helper
INFO - 2020-11-10 01:29:12 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:29:12 --> Controller Class Initialized
DEBUG - 2020-11-10 01:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-11-10 01:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:29:12 --> Final output sent to browser
DEBUG - 2020-11-10 01:29:12 --> Total execution time: 0.3349
INFO - 2020-11-10 01:29:17 --> Config Class Initialized
INFO - 2020-11-10 01:29:18 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:29:18 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:29:18 --> Utf8 Class Initialized
INFO - 2020-11-10 01:29:18 --> URI Class Initialized
INFO - 2020-11-10 01:29:18 --> Router Class Initialized
INFO - 2020-11-10 01:29:18 --> Output Class Initialized
INFO - 2020-11-10 01:29:18 --> Security Class Initialized
DEBUG - 2020-11-10 01:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:29:18 --> Input Class Initialized
INFO - 2020-11-10 01:29:18 --> Language Class Initialized
INFO - 2020-11-10 01:29:18 --> Language Class Initialized
INFO - 2020-11-10 01:29:18 --> Config Class Initialized
INFO - 2020-11-10 01:29:18 --> Loader Class Initialized
INFO - 2020-11-10 01:29:18 --> Helper loaded: url_helper
INFO - 2020-11-10 01:29:18 --> Helper loaded: file_helper
INFO - 2020-11-10 01:29:18 --> Helper loaded: form_helper
INFO - 2020-11-10 01:29:18 --> Helper loaded: my_helper
INFO - 2020-11-10 01:29:18 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:29:18 --> Controller Class Initialized
DEBUG - 2020-11-10 01:29:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2020-11-10 01:29:18 --> Final output sent to browser
DEBUG - 2020-11-10 01:29:18 --> Total execution time: 0.3169
INFO - 2020-11-10 01:29:42 --> Config Class Initialized
INFO - 2020-11-10 01:29:42 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:29:42 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:29:42 --> Utf8 Class Initialized
INFO - 2020-11-10 01:29:42 --> URI Class Initialized
INFO - 2020-11-10 01:29:42 --> Router Class Initialized
INFO - 2020-11-10 01:29:42 --> Output Class Initialized
INFO - 2020-11-10 01:29:42 --> Security Class Initialized
DEBUG - 2020-11-10 01:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:29:42 --> Input Class Initialized
INFO - 2020-11-10 01:29:42 --> Language Class Initialized
INFO - 2020-11-10 01:29:42 --> Language Class Initialized
INFO - 2020-11-10 01:29:42 --> Config Class Initialized
INFO - 2020-11-10 01:29:42 --> Loader Class Initialized
INFO - 2020-11-10 01:29:42 --> Helper loaded: url_helper
INFO - 2020-11-10 01:29:42 --> Helper loaded: file_helper
INFO - 2020-11-10 01:29:42 --> Helper loaded: form_helper
INFO - 2020-11-10 01:29:42 --> Helper loaded: my_helper
INFO - 2020-11-10 01:29:42 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:29:42 --> Controller Class Initialized
DEBUG - 2020-11-10 01:29:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-10 01:29:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:29:42 --> Final output sent to browser
DEBUG - 2020-11-10 01:29:42 --> Total execution time: 0.3637
INFO - 2020-11-10 01:29:44 --> Config Class Initialized
INFO - 2020-11-10 01:29:44 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:29:44 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:29:44 --> Utf8 Class Initialized
INFO - 2020-11-10 01:29:44 --> URI Class Initialized
INFO - 2020-11-10 01:29:44 --> Router Class Initialized
INFO - 2020-11-10 01:29:44 --> Output Class Initialized
INFO - 2020-11-10 01:29:44 --> Security Class Initialized
DEBUG - 2020-11-10 01:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:29:44 --> Input Class Initialized
INFO - 2020-11-10 01:29:44 --> Language Class Initialized
INFO - 2020-11-10 01:29:44 --> Language Class Initialized
INFO - 2020-11-10 01:29:44 --> Config Class Initialized
INFO - 2020-11-10 01:29:44 --> Loader Class Initialized
INFO - 2020-11-10 01:29:44 --> Helper loaded: url_helper
INFO - 2020-11-10 01:29:44 --> Helper loaded: file_helper
INFO - 2020-11-10 01:29:44 --> Helper loaded: form_helper
INFO - 2020-11-10 01:29:44 --> Helper loaded: my_helper
INFO - 2020-11-10 01:29:44 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:29:44 --> Controller Class Initialized
DEBUG - 2020-11-10 01:29:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-10 01:29:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:29:44 --> Final output sent to browser
DEBUG - 2020-11-10 01:29:44 --> Total execution time: 0.2455
INFO - 2020-11-10 01:29:45 --> Config Class Initialized
INFO - 2020-11-10 01:29:45 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:29:45 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:29:45 --> Utf8 Class Initialized
INFO - 2020-11-10 01:29:45 --> URI Class Initialized
INFO - 2020-11-10 01:29:45 --> Router Class Initialized
INFO - 2020-11-10 01:29:45 --> Output Class Initialized
INFO - 2020-11-10 01:29:45 --> Security Class Initialized
DEBUG - 2020-11-10 01:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:29:45 --> Input Class Initialized
INFO - 2020-11-10 01:29:45 --> Language Class Initialized
INFO - 2020-11-10 01:29:45 --> Language Class Initialized
INFO - 2020-11-10 01:29:45 --> Config Class Initialized
INFO - 2020-11-10 01:29:45 --> Loader Class Initialized
INFO - 2020-11-10 01:29:45 --> Helper loaded: url_helper
INFO - 2020-11-10 01:29:45 --> Helper loaded: file_helper
INFO - 2020-11-10 01:29:45 --> Helper loaded: form_helper
INFO - 2020-11-10 01:29:45 --> Helper loaded: my_helper
INFO - 2020-11-10 01:29:45 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:29:45 --> Controller Class Initialized
INFO - 2020-11-10 01:29:46 --> Config Class Initialized
INFO - 2020-11-10 01:29:46 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:29:46 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:29:46 --> Utf8 Class Initialized
INFO - 2020-11-10 01:29:46 --> URI Class Initialized
INFO - 2020-11-10 01:29:46 --> Router Class Initialized
INFO - 2020-11-10 01:29:46 --> Output Class Initialized
INFO - 2020-11-10 01:29:46 --> Security Class Initialized
DEBUG - 2020-11-10 01:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:29:46 --> Input Class Initialized
INFO - 2020-11-10 01:29:46 --> Language Class Initialized
INFO - 2020-11-10 01:29:46 --> Language Class Initialized
INFO - 2020-11-10 01:29:46 --> Config Class Initialized
INFO - 2020-11-10 01:29:46 --> Loader Class Initialized
INFO - 2020-11-10 01:29:46 --> Helper loaded: url_helper
INFO - 2020-11-10 01:29:46 --> Helper loaded: file_helper
INFO - 2020-11-10 01:29:46 --> Helper loaded: form_helper
INFO - 2020-11-10 01:29:46 --> Helper loaded: my_helper
INFO - 2020-11-10 01:29:46 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:29:46 --> Controller Class Initialized
DEBUG - 2020-11-10 01:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-10 01:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:29:46 --> Final output sent to browser
DEBUG - 2020-11-10 01:29:46 --> Total execution time: 0.2747
INFO - 2020-11-10 01:29:48 --> Config Class Initialized
INFO - 2020-11-10 01:29:48 --> Hooks Class Initialized
DEBUG - 2020-11-10 01:29:48 --> UTF-8 Support Enabled
INFO - 2020-11-10 01:29:48 --> Utf8 Class Initialized
INFO - 2020-11-10 01:29:48 --> URI Class Initialized
INFO - 2020-11-10 01:29:48 --> Router Class Initialized
INFO - 2020-11-10 01:29:48 --> Output Class Initialized
INFO - 2020-11-10 01:29:48 --> Security Class Initialized
DEBUG - 2020-11-10 01:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 01:29:48 --> Input Class Initialized
INFO - 2020-11-10 01:29:48 --> Language Class Initialized
INFO - 2020-11-10 01:29:48 --> Language Class Initialized
INFO - 2020-11-10 01:29:48 --> Config Class Initialized
INFO - 2020-11-10 01:29:48 --> Loader Class Initialized
INFO - 2020-11-10 01:29:48 --> Helper loaded: url_helper
INFO - 2020-11-10 01:29:48 --> Helper loaded: file_helper
INFO - 2020-11-10 01:29:48 --> Helper loaded: form_helper
INFO - 2020-11-10 01:29:48 --> Helper loaded: my_helper
INFO - 2020-11-10 01:29:48 --> Database Driver Class Initialized
DEBUG - 2020-11-10 01:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 01:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 01:29:48 --> Controller Class Initialized
DEBUG - 2020-11-10 01:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-11-10 01:29:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 01:29:48 --> Final output sent to browser
DEBUG - 2020-11-10 01:29:48 --> Total execution time: 0.2814
INFO - 2020-11-10 02:04:13 --> Config Class Initialized
INFO - 2020-11-10 02:04:13 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:13 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:13 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:13 --> URI Class Initialized
INFO - 2020-11-10 02:04:13 --> Router Class Initialized
INFO - 2020-11-10 02:04:13 --> Output Class Initialized
INFO - 2020-11-10 02:04:13 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:14 --> Input Class Initialized
INFO - 2020-11-10 02:04:14 --> Language Class Initialized
INFO - 2020-11-10 02:04:14 --> Language Class Initialized
INFO - 2020-11-10 02:04:14 --> Config Class Initialized
INFO - 2020-11-10 02:04:14 --> Loader Class Initialized
INFO - 2020-11-10 02:04:14 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:14 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:14 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:14 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:14 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:14 --> Controller Class Initialized
INFO - 2020-11-10 02:04:14 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:04:14 --> Config Class Initialized
INFO - 2020-11-10 02:04:14 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:14 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:14 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:14 --> URI Class Initialized
INFO - 2020-11-10 02:04:14 --> Router Class Initialized
INFO - 2020-11-10 02:04:14 --> Output Class Initialized
INFO - 2020-11-10 02:04:14 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:14 --> Input Class Initialized
INFO - 2020-11-10 02:04:14 --> Language Class Initialized
INFO - 2020-11-10 02:04:14 --> Language Class Initialized
INFO - 2020-11-10 02:04:14 --> Config Class Initialized
INFO - 2020-11-10 02:04:14 --> Loader Class Initialized
INFO - 2020-11-10 02:04:14 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:15 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:15 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:15 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:15 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:15 --> Controller Class Initialized
DEBUG - 2020-11-10 02:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 02:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:04:15 --> Final output sent to browser
DEBUG - 2020-11-10 02:04:15 --> Total execution time: 0.7764
INFO - 2020-11-10 02:04:22 --> Config Class Initialized
INFO - 2020-11-10 02:04:23 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:23 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:23 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:23 --> URI Class Initialized
INFO - 2020-11-10 02:04:23 --> Router Class Initialized
INFO - 2020-11-10 02:04:23 --> Output Class Initialized
INFO - 2020-11-10 02:04:23 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:23 --> Input Class Initialized
INFO - 2020-11-10 02:04:23 --> Language Class Initialized
INFO - 2020-11-10 02:04:23 --> Language Class Initialized
INFO - 2020-11-10 02:04:23 --> Config Class Initialized
INFO - 2020-11-10 02:04:23 --> Loader Class Initialized
INFO - 2020-11-10 02:04:23 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:23 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:23 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:23 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:23 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:23 --> Controller Class Initialized
INFO - 2020-11-10 02:04:23 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:04:23 --> Final output sent to browser
DEBUG - 2020-11-10 02:04:23 --> Total execution time: 0.6848
INFO - 2020-11-10 02:04:24 --> Config Class Initialized
INFO - 2020-11-10 02:04:24 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:24 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:24 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:24 --> URI Class Initialized
INFO - 2020-11-10 02:04:24 --> Router Class Initialized
INFO - 2020-11-10 02:04:24 --> Output Class Initialized
INFO - 2020-11-10 02:04:24 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:24 --> Input Class Initialized
INFO - 2020-11-10 02:04:24 --> Language Class Initialized
INFO - 2020-11-10 02:04:24 --> Language Class Initialized
INFO - 2020-11-10 02:04:24 --> Config Class Initialized
INFO - 2020-11-10 02:04:24 --> Loader Class Initialized
INFO - 2020-11-10 02:04:24 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:24 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:24 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:24 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:24 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:24 --> Controller Class Initialized
DEBUG - 2020-11-10 02:04:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 02:04:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:04:24 --> Final output sent to browser
DEBUG - 2020-11-10 02:04:24 --> Total execution time: 0.7290
INFO - 2020-11-10 02:04:29 --> Config Class Initialized
INFO - 2020-11-10 02:04:29 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:29 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:29 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:29 --> URI Class Initialized
INFO - 2020-11-10 02:04:29 --> Router Class Initialized
INFO - 2020-11-10 02:04:29 --> Output Class Initialized
INFO - 2020-11-10 02:04:29 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:29 --> Input Class Initialized
INFO - 2020-11-10 02:04:29 --> Language Class Initialized
INFO - 2020-11-10 02:04:29 --> Language Class Initialized
INFO - 2020-11-10 02:04:29 --> Config Class Initialized
INFO - 2020-11-10 02:04:29 --> Loader Class Initialized
INFO - 2020-11-10 02:04:29 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:29 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:29 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:29 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:29 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:29 --> Controller Class Initialized
DEBUG - 2020-11-10 02:04:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-11-10 02:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:04:30 --> Final output sent to browser
DEBUG - 2020-11-10 02:04:30 --> Total execution time: 0.9113
INFO - 2020-11-10 02:04:30 --> Config Class Initialized
INFO - 2020-11-10 02:04:30 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:30 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:30 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:30 --> URI Class Initialized
INFO - 2020-11-10 02:04:30 --> Router Class Initialized
INFO - 2020-11-10 02:04:30 --> Output Class Initialized
INFO - 2020-11-10 02:04:30 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:30 --> Input Class Initialized
INFO - 2020-11-10 02:04:30 --> Language Class Initialized
INFO - 2020-11-10 02:04:30 --> Language Class Initialized
INFO - 2020-11-10 02:04:30 --> Config Class Initialized
INFO - 2020-11-10 02:04:30 --> Loader Class Initialized
INFO - 2020-11-10 02:04:30 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:30 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:30 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:30 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:30 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:31 --> Controller Class Initialized
INFO - 2020-11-10 02:04:40 --> Config Class Initialized
INFO - 2020-11-10 02:04:40 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:40 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:40 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:40 --> URI Class Initialized
INFO - 2020-11-10 02:04:40 --> Router Class Initialized
INFO - 2020-11-10 02:04:40 --> Output Class Initialized
INFO - 2020-11-10 02:04:40 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:40 --> Input Class Initialized
INFO - 2020-11-10 02:04:40 --> Language Class Initialized
INFO - 2020-11-10 02:04:41 --> Language Class Initialized
INFO - 2020-11-10 02:04:41 --> Config Class Initialized
INFO - 2020-11-10 02:04:41 --> Loader Class Initialized
INFO - 2020-11-10 02:04:41 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:41 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:41 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:41 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:41 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:41 --> Controller Class Initialized
DEBUG - 2020-11-10 02:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-10 02:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:04:41 --> Final output sent to browser
DEBUG - 2020-11-10 02:04:41 --> Total execution time: 0.8658
INFO - 2020-11-10 02:04:41 --> Config Class Initialized
INFO - 2020-11-10 02:04:41 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:41 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:41 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:41 --> URI Class Initialized
INFO - 2020-11-10 02:04:41 --> Router Class Initialized
INFO - 2020-11-10 02:04:41 --> Output Class Initialized
INFO - 2020-11-10 02:04:41 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:41 --> Input Class Initialized
INFO - 2020-11-10 02:04:41 --> Language Class Initialized
INFO - 2020-11-10 02:04:41 --> Language Class Initialized
INFO - 2020-11-10 02:04:42 --> Config Class Initialized
INFO - 2020-11-10 02:04:42 --> Loader Class Initialized
INFO - 2020-11-10 02:04:42 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:42 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:42 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:42 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:42 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:42 --> Controller Class Initialized
INFO - 2020-11-10 02:04:53 --> Config Class Initialized
INFO - 2020-11-10 02:04:53 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:53 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:53 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:53 --> URI Class Initialized
INFO - 2020-11-10 02:04:53 --> Router Class Initialized
INFO - 2020-11-10 02:04:53 --> Output Class Initialized
INFO - 2020-11-10 02:04:53 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:53 --> Input Class Initialized
INFO - 2020-11-10 02:04:53 --> Language Class Initialized
INFO - 2020-11-10 02:04:53 --> Language Class Initialized
INFO - 2020-11-10 02:04:53 --> Config Class Initialized
INFO - 2020-11-10 02:04:53 --> Loader Class Initialized
INFO - 2020-11-10 02:04:53 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:53 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:53 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:53 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:53 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:54 --> Controller Class Initialized
DEBUG - 2020-11-10 02:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-11-10 02:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:04:54 --> Final output sent to browser
DEBUG - 2020-11-10 02:04:54 --> Total execution time: 0.9230
INFO - 2020-11-10 02:04:54 --> Config Class Initialized
INFO - 2020-11-10 02:04:54 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:04:54 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:04:54 --> Utf8 Class Initialized
INFO - 2020-11-10 02:04:54 --> URI Class Initialized
INFO - 2020-11-10 02:04:54 --> Router Class Initialized
INFO - 2020-11-10 02:04:54 --> Output Class Initialized
INFO - 2020-11-10 02:04:54 --> Security Class Initialized
DEBUG - 2020-11-10 02:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:04:54 --> Input Class Initialized
INFO - 2020-11-10 02:04:54 --> Language Class Initialized
INFO - 2020-11-10 02:04:54 --> Language Class Initialized
INFO - 2020-11-10 02:04:54 --> Config Class Initialized
INFO - 2020-11-10 02:04:54 --> Loader Class Initialized
INFO - 2020-11-10 02:04:54 --> Helper loaded: url_helper
INFO - 2020-11-10 02:04:54 --> Helper loaded: file_helper
INFO - 2020-11-10 02:04:54 --> Helper loaded: form_helper
INFO - 2020-11-10 02:04:54 --> Helper loaded: my_helper
INFO - 2020-11-10 02:04:54 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:04:55 --> Controller Class Initialized
INFO - 2020-11-10 02:04:59 --> Config Class Initialized
INFO - 2020-11-10 02:04:59 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:05:00 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:05:00 --> Utf8 Class Initialized
INFO - 2020-11-10 02:05:00 --> URI Class Initialized
INFO - 2020-11-10 02:05:00 --> Router Class Initialized
INFO - 2020-11-10 02:05:00 --> Output Class Initialized
INFO - 2020-11-10 02:05:00 --> Security Class Initialized
DEBUG - 2020-11-10 02:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:05:00 --> Input Class Initialized
INFO - 2020-11-10 02:05:00 --> Language Class Initialized
INFO - 2020-11-10 02:05:00 --> Language Class Initialized
INFO - 2020-11-10 02:05:00 --> Config Class Initialized
INFO - 2020-11-10 02:05:00 --> Loader Class Initialized
INFO - 2020-11-10 02:05:00 --> Helper loaded: url_helper
INFO - 2020-11-10 02:05:00 --> Helper loaded: file_helper
INFO - 2020-11-10 02:05:00 --> Helper loaded: form_helper
INFO - 2020-11-10 02:05:00 --> Helper loaded: my_helper
INFO - 2020-11-10 02:05:00 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:05:00 --> Controller Class Initialized
INFO - 2020-11-10 02:05:05 --> Config Class Initialized
INFO - 2020-11-10 02:05:05 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:05:05 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:05:05 --> Utf8 Class Initialized
INFO - 2020-11-10 02:05:05 --> URI Class Initialized
INFO - 2020-11-10 02:05:05 --> Router Class Initialized
INFO - 2020-11-10 02:05:05 --> Output Class Initialized
INFO - 2020-11-10 02:05:05 --> Security Class Initialized
DEBUG - 2020-11-10 02:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:05:05 --> Input Class Initialized
INFO - 2020-11-10 02:05:05 --> Language Class Initialized
INFO - 2020-11-10 02:05:05 --> Language Class Initialized
INFO - 2020-11-10 02:05:05 --> Config Class Initialized
INFO - 2020-11-10 02:05:05 --> Loader Class Initialized
INFO - 2020-11-10 02:05:05 --> Helper loaded: url_helper
INFO - 2020-11-10 02:05:05 --> Helper loaded: file_helper
INFO - 2020-11-10 02:05:05 --> Helper loaded: form_helper
INFO - 2020-11-10 02:05:05 --> Helper loaded: my_helper
INFO - 2020-11-10 02:05:05 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:05:06 --> Controller Class Initialized
DEBUG - 2020-11-10 02:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-11-10 02:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:05:06 --> Final output sent to browser
DEBUG - 2020-11-10 02:05:06 --> Total execution time: 1.0436
INFO - 2020-11-10 02:05:06 --> Config Class Initialized
INFO - 2020-11-10 02:05:06 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:05:06 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:05:06 --> Utf8 Class Initialized
INFO - 2020-11-10 02:05:06 --> URI Class Initialized
INFO - 2020-11-10 02:05:06 --> Router Class Initialized
INFO - 2020-11-10 02:05:06 --> Output Class Initialized
INFO - 2020-11-10 02:05:06 --> Security Class Initialized
DEBUG - 2020-11-10 02:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:05:06 --> Input Class Initialized
INFO - 2020-11-10 02:05:06 --> Language Class Initialized
INFO - 2020-11-10 02:05:06 --> Language Class Initialized
INFO - 2020-11-10 02:05:06 --> Config Class Initialized
INFO - 2020-11-10 02:05:06 --> Loader Class Initialized
INFO - 2020-11-10 02:05:06 --> Helper loaded: url_helper
INFO - 2020-11-10 02:05:06 --> Helper loaded: file_helper
INFO - 2020-11-10 02:05:06 --> Helper loaded: form_helper
INFO - 2020-11-10 02:05:06 --> Helper loaded: my_helper
INFO - 2020-11-10 02:05:06 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:05:06 --> Controller Class Initialized
INFO - 2020-11-10 02:05:10 --> Config Class Initialized
INFO - 2020-11-10 02:05:10 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:05:10 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:05:10 --> Utf8 Class Initialized
INFO - 2020-11-10 02:05:10 --> URI Class Initialized
INFO - 2020-11-10 02:05:10 --> Router Class Initialized
INFO - 2020-11-10 02:05:11 --> Output Class Initialized
INFO - 2020-11-10 02:05:11 --> Security Class Initialized
DEBUG - 2020-11-10 02:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:05:11 --> Input Class Initialized
INFO - 2020-11-10 02:05:11 --> Language Class Initialized
INFO - 2020-11-10 02:05:11 --> Language Class Initialized
INFO - 2020-11-10 02:05:11 --> Config Class Initialized
INFO - 2020-11-10 02:05:11 --> Loader Class Initialized
INFO - 2020-11-10 02:05:11 --> Helper loaded: url_helper
INFO - 2020-11-10 02:05:11 --> Helper loaded: file_helper
INFO - 2020-11-10 02:05:11 --> Helper loaded: form_helper
INFO - 2020-11-10 02:05:11 --> Helper loaded: my_helper
INFO - 2020-11-10 02:05:11 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:05:11 --> Controller Class Initialized
INFO - 2020-11-10 02:05:18 --> Config Class Initialized
INFO - 2020-11-10 02:05:18 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:05:18 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:05:18 --> Utf8 Class Initialized
INFO - 2020-11-10 02:05:18 --> URI Class Initialized
INFO - 2020-11-10 02:05:18 --> Router Class Initialized
INFO - 2020-11-10 02:05:18 --> Output Class Initialized
INFO - 2020-11-10 02:05:18 --> Security Class Initialized
DEBUG - 2020-11-10 02:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:05:18 --> Input Class Initialized
INFO - 2020-11-10 02:05:18 --> Language Class Initialized
INFO - 2020-11-10 02:05:18 --> Language Class Initialized
INFO - 2020-11-10 02:05:18 --> Config Class Initialized
INFO - 2020-11-10 02:05:18 --> Loader Class Initialized
INFO - 2020-11-10 02:05:18 --> Helper loaded: url_helper
INFO - 2020-11-10 02:05:18 --> Helper loaded: file_helper
INFO - 2020-11-10 02:05:18 --> Helper loaded: form_helper
INFO - 2020-11-10 02:05:18 --> Helper loaded: my_helper
INFO - 2020-11-10 02:05:18 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:05:19 --> Controller Class Initialized
DEBUG - 2020-11-10 02:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-10 02:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:05:19 --> Final output sent to browser
DEBUG - 2020-11-10 02:05:19 --> Total execution time: 0.9095
INFO - 2020-11-10 02:05:19 --> Config Class Initialized
INFO - 2020-11-10 02:05:19 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:05:19 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:05:19 --> Utf8 Class Initialized
INFO - 2020-11-10 02:05:19 --> URI Class Initialized
INFO - 2020-11-10 02:05:19 --> Router Class Initialized
INFO - 2020-11-10 02:05:19 --> Output Class Initialized
INFO - 2020-11-10 02:05:19 --> Security Class Initialized
DEBUG - 2020-11-10 02:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:05:19 --> Input Class Initialized
INFO - 2020-11-10 02:05:19 --> Language Class Initialized
INFO - 2020-11-10 02:05:19 --> Language Class Initialized
INFO - 2020-11-10 02:05:19 --> Config Class Initialized
INFO - 2020-11-10 02:05:19 --> Loader Class Initialized
INFO - 2020-11-10 02:05:19 --> Helper loaded: url_helper
INFO - 2020-11-10 02:05:19 --> Helper loaded: file_helper
INFO - 2020-11-10 02:05:19 --> Helper loaded: form_helper
INFO - 2020-11-10 02:05:19 --> Helper loaded: my_helper
INFO - 2020-11-10 02:05:19 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:05:20 --> Controller Class Initialized
INFO - 2020-11-10 02:05:25 --> Config Class Initialized
INFO - 2020-11-10 02:05:25 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:05:25 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:05:25 --> Utf8 Class Initialized
INFO - 2020-11-10 02:05:25 --> URI Class Initialized
INFO - 2020-11-10 02:05:25 --> Router Class Initialized
INFO - 2020-11-10 02:05:25 --> Output Class Initialized
INFO - 2020-11-10 02:05:25 --> Security Class Initialized
DEBUG - 2020-11-10 02:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:05:26 --> Input Class Initialized
INFO - 2020-11-10 02:05:26 --> Language Class Initialized
INFO - 2020-11-10 02:05:26 --> Language Class Initialized
INFO - 2020-11-10 02:05:26 --> Config Class Initialized
INFO - 2020-11-10 02:05:26 --> Loader Class Initialized
INFO - 2020-11-10 02:05:26 --> Helper loaded: url_helper
INFO - 2020-11-10 02:05:26 --> Helper loaded: file_helper
INFO - 2020-11-10 02:05:26 --> Helper loaded: form_helper
INFO - 2020-11-10 02:05:26 --> Helper loaded: my_helper
INFO - 2020-11-10 02:05:26 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:05:26 --> Controller Class Initialized
DEBUG - 2020-11-10 02:05:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-10 02:05:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:05:26 --> Final output sent to browser
DEBUG - 2020-11-10 02:05:26 --> Total execution time: 0.9266
INFO - 2020-11-10 02:05:26 --> Config Class Initialized
INFO - 2020-11-10 02:05:26 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:05:26 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:05:26 --> Utf8 Class Initialized
INFO - 2020-11-10 02:05:26 --> URI Class Initialized
INFO - 2020-11-10 02:05:26 --> Router Class Initialized
INFO - 2020-11-10 02:05:26 --> Output Class Initialized
INFO - 2020-11-10 02:05:26 --> Security Class Initialized
DEBUG - 2020-11-10 02:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:05:27 --> Input Class Initialized
INFO - 2020-11-10 02:05:27 --> Language Class Initialized
INFO - 2020-11-10 02:05:27 --> Language Class Initialized
INFO - 2020-11-10 02:05:27 --> Config Class Initialized
INFO - 2020-11-10 02:05:27 --> Loader Class Initialized
INFO - 2020-11-10 02:05:27 --> Helper loaded: url_helper
INFO - 2020-11-10 02:05:27 --> Helper loaded: file_helper
INFO - 2020-11-10 02:05:27 --> Helper loaded: form_helper
INFO - 2020-11-10 02:05:27 --> Helper loaded: my_helper
INFO - 2020-11-10 02:05:27 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:05:27 --> Controller Class Initialized
INFO - 2020-11-10 02:05:51 --> Config Class Initialized
INFO - 2020-11-10 02:05:51 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:05:51 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:05:51 --> Utf8 Class Initialized
INFO - 2020-11-10 02:05:52 --> URI Class Initialized
INFO - 2020-11-10 02:05:52 --> Router Class Initialized
INFO - 2020-11-10 02:05:52 --> Output Class Initialized
INFO - 2020-11-10 02:05:52 --> Security Class Initialized
DEBUG - 2020-11-10 02:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:05:52 --> Input Class Initialized
INFO - 2020-11-10 02:05:52 --> Language Class Initialized
INFO - 2020-11-10 02:05:52 --> Language Class Initialized
INFO - 2020-11-10 02:05:52 --> Config Class Initialized
INFO - 2020-11-10 02:05:52 --> Loader Class Initialized
INFO - 2020-11-10 02:05:52 --> Helper loaded: url_helper
INFO - 2020-11-10 02:05:52 --> Helper loaded: file_helper
INFO - 2020-11-10 02:05:52 --> Helper loaded: form_helper
INFO - 2020-11-10 02:05:52 --> Helper loaded: my_helper
INFO - 2020-11-10 02:05:52 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:05:52 --> Controller Class Initialized
DEBUG - 2020-11-10 02:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-10 02:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:05:52 --> Final output sent to browser
DEBUG - 2020-11-10 02:05:52 --> Total execution time: 0.9405
INFO - 2020-11-10 02:06:01 --> Config Class Initialized
INFO - 2020-11-10 02:06:01 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:02 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:02 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:02 --> URI Class Initialized
INFO - 2020-11-10 02:06:02 --> Router Class Initialized
INFO - 2020-11-10 02:06:02 --> Output Class Initialized
INFO - 2020-11-10 02:06:02 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:02 --> Input Class Initialized
INFO - 2020-11-10 02:06:02 --> Language Class Initialized
INFO - 2020-11-10 02:06:02 --> Language Class Initialized
INFO - 2020-11-10 02:06:02 --> Config Class Initialized
INFO - 2020-11-10 02:06:02 --> Loader Class Initialized
INFO - 2020-11-10 02:06:02 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:02 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:02 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:02 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:02 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:02 --> Controller Class Initialized
DEBUG - 2020-11-10 02:06:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-10 02:06:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:06:02 --> Final output sent to browser
DEBUG - 2020-11-10 02:06:02 --> Total execution time: 0.8983
INFO - 2020-11-10 02:06:02 --> Config Class Initialized
INFO - 2020-11-10 02:06:02 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:03 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:03 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:03 --> URI Class Initialized
INFO - 2020-11-10 02:06:03 --> Router Class Initialized
INFO - 2020-11-10 02:06:03 --> Output Class Initialized
INFO - 2020-11-10 02:06:03 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:03 --> Input Class Initialized
INFO - 2020-11-10 02:06:03 --> Language Class Initialized
INFO - 2020-11-10 02:06:03 --> Language Class Initialized
INFO - 2020-11-10 02:06:03 --> Config Class Initialized
INFO - 2020-11-10 02:06:03 --> Loader Class Initialized
INFO - 2020-11-10 02:06:03 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:03 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:03 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:03 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:03 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:03 --> Controller Class Initialized
INFO - 2020-11-10 02:06:11 --> Config Class Initialized
INFO - 2020-11-10 02:06:11 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:11 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:11 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:11 --> URI Class Initialized
INFO - 2020-11-10 02:06:11 --> Router Class Initialized
INFO - 2020-11-10 02:06:11 --> Output Class Initialized
INFO - 2020-11-10 02:06:11 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:11 --> Input Class Initialized
INFO - 2020-11-10 02:06:11 --> Language Class Initialized
INFO - 2020-11-10 02:06:11 --> Language Class Initialized
INFO - 2020-11-10 02:06:11 --> Config Class Initialized
INFO - 2020-11-10 02:06:11 --> Loader Class Initialized
INFO - 2020-11-10 02:06:11 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:11 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:11 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:11 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:11 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:11 --> Controller Class Initialized
DEBUG - 2020-11-10 02:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-11-10 02:06:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:06:12 --> Final output sent to browser
DEBUG - 2020-11-10 02:06:12 --> Total execution time: 0.7457
INFO - 2020-11-10 02:06:12 --> Config Class Initialized
INFO - 2020-11-10 02:06:12 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:12 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:12 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:12 --> URI Class Initialized
INFO - 2020-11-10 02:06:12 --> Router Class Initialized
INFO - 2020-11-10 02:06:12 --> Output Class Initialized
INFO - 2020-11-10 02:06:12 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:12 --> Input Class Initialized
INFO - 2020-11-10 02:06:12 --> Language Class Initialized
INFO - 2020-11-10 02:06:12 --> Language Class Initialized
INFO - 2020-11-10 02:06:12 --> Config Class Initialized
INFO - 2020-11-10 02:06:12 --> Loader Class Initialized
INFO - 2020-11-10 02:06:12 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:12 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:12 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:12 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:12 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:13 --> Controller Class Initialized
INFO - 2020-11-10 02:06:16 --> Config Class Initialized
INFO - 2020-11-10 02:06:16 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:16 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:16 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:16 --> URI Class Initialized
INFO - 2020-11-10 02:06:16 --> Router Class Initialized
INFO - 2020-11-10 02:06:16 --> Output Class Initialized
INFO - 2020-11-10 02:06:16 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:16 --> Input Class Initialized
INFO - 2020-11-10 02:06:16 --> Language Class Initialized
INFO - 2020-11-10 02:06:16 --> Language Class Initialized
INFO - 2020-11-10 02:06:16 --> Config Class Initialized
INFO - 2020-11-10 02:06:16 --> Loader Class Initialized
INFO - 2020-11-10 02:06:16 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:16 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:16 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:16 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:16 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:17 --> Controller Class Initialized
INFO - 2020-11-10 02:06:17 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:06:17 --> Config Class Initialized
INFO - 2020-11-10 02:06:17 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:17 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:17 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:17 --> URI Class Initialized
INFO - 2020-11-10 02:06:17 --> Router Class Initialized
INFO - 2020-11-10 02:06:17 --> Output Class Initialized
INFO - 2020-11-10 02:06:17 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:17 --> Input Class Initialized
INFO - 2020-11-10 02:06:17 --> Language Class Initialized
INFO - 2020-11-10 02:06:17 --> Language Class Initialized
INFO - 2020-11-10 02:06:17 --> Config Class Initialized
INFO - 2020-11-10 02:06:17 --> Loader Class Initialized
INFO - 2020-11-10 02:06:17 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:17 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:17 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:17 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:17 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:17 --> Controller Class Initialized
DEBUG - 2020-11-10 02:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 02:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:06:17 --> Final output sent to browser
DEBUG - 2020-11-10 02:06:17 --> Total execution time: 0.7634
INFO - 2020-11-10 02:06:23 --> Config Class Initialized
INFO - 2020-11-10 02:06:23 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:23 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:23 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:23 --> URI Class Initialized
INFO - 2020-11-10 02:06:23 --> Router Class Initialized
INFO - 2020-11-10 02:06:23 --> Output Class Initialized
INFO - 2020-11-10 02:06:23 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:23 --> Input Class Initialized
INFO - 2020-11-10 02:06:23 --> Language Class Initialized
INFO - 2020-11-10 02:06:24 --> Language Class Initialized
INFO - 2020-11-10 02:06:24 --> Config Class Initialized
INFO - 2020-11-10 02:06:24 --> Loader Class Initialized
INFO - 2020-11-10 02:06:24 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:24 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:24 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:24 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:24 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:24 --> Controller Class Initialized
INFO - 2020-11-10 02:06:24 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:06:24 --> Final output sent to browser
DEBUG - 2020-11-10 02:06:24 --> Total execution time: 0.9424
INFO - 2020-11-10 02:06:25 --> Config Class Initialized
INFO - 2020-11-10 02:06:25 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:25 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:25 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:25 --> URI Class Initialized
INFO - 2020-11-10 02:06:25 --> Router Class Initialized
INFO - 2020-11-10 02:06:25 --> Output Class Initialized
INFO - 2020-11-10 02:06:25 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:25 --> Input Class Initialized
INFO - 2020-11-10 02:06:25 --> Language Class Initialized
INFO - 2020-11-10 02:06:26 --> Language Class Initialized
INFO - 2020-11-10 02:06:26 --> Config Class Initialized
INFO - 2020-11-10 02:06:26 --> Loader Class Initialized
INFO - 2020-11-10 02:06:26 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:26 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:26 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:26 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:26 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:26 --> Controller Class Initialized
DEBUG - 2020-11-10 02:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 02:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:06:26 --> Final output sent to browser
DEBUG - 2020-11-10 02:06:26 --> Total execution time: 0.7107
INFO - 2020-11-10 02:06:35 --> Config Class Initialized
INFO - 2020-11-10 02:06:35 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:35 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:35 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:35 --> URI Class Initialized
INFO - 2020-11-10 02:06:35 --> Router Class Initialized
INFO - 2020-11-10 02:06:35 --> Output Class Initialized
INFO - 2020-11-10 02:06:35 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:36 --> Input Class Initialized
INFO - 2020-11-10 02:06:36 --> Language Class Initialized
INFO - 2020-11-10 02:06:36 --> Language Class Initialized
INFO - 2020-11-10 02:06:36 --> Config Class Initialized
INFO - 2020-11-10 02:06:36 --> Loader Class Initialized
INFO - 2020-11-10 02:06:36 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:36 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:36 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:36 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:36 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:36 --> Controller Class Initialized
DEBUG - 2020-11-10 02:06:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 02:06:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:06:36 --> Final output sent to browser
DEBUG - 2020-11-10 02:06:36 --> Total execution time: 1.0376
INFO - 2020-11-10 02:06:37 --> Config Class Initialized
INFO - 2020-11-10 02:06:37 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:37 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:37 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:37 --> URI Class Initialized
INFO - 2020-11-10 02:06:37 --> Router Class Initialized
INFO - 2020-11-10 02:06:37 --> Output Class Initialized
INFO - 2020-11-10 02:06:37 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:37 --> Input Class Initialized
INFO - 2020-11-10 02:06:38 --> Language Class Initialized
INFO - 2020-11-10 02:06:38 --> Language Class Initialized
INFO - 2020-11-10 02:06:38 --> Config Class Initialized
INFO - 2020-11-10 02:06:38 --> Loader Class Initialized
INFO - 2020-11-10 02:06:38 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:38 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:38 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:38 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:38 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:38 --> Controller Class Initialized
DEBUG - 2020-11-10 02:06:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-10 02:06:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:06:38 --> Final output sent to browser
DEBUG - 2020-11-10 02:06:38 --> Total execution time: 0.8356
INFO - 2020-11-10 02:06:51 --> Config Class Initialized
INFO - 2020-11-10 02:06:51 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:51 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:51 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:51 --> URI Class Initialized
INFO - 2020-11-10 02:06:51 --> Router Class Initialized
INFO - 2020-11-10 02:06:51 --> Output Class Initialized
INFO - 2020-11-10 02:06:51 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:51 --> Input Class Initialized
INFO - 2020-11-10 02:06:51 --> Language Class Initialized
INFO - 2020-11-10 02:06:52 --> Language Class Initialized
INFO - 2020-11-10 02:06:52 --> Config Class Initialized
INFO - 2020-11-10 02:06:52 --> Loader Class Initialized
INFO - 2020-11-10 02:06:52 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:52 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:52 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:52 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:52 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:52 --> Controller Class Initialized
DEBUG - 2020-11-10 02:06:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 02:06:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:06:52 --> Final output sent to browser
DEBUG - 2020-11-10 02:06:52 --> Total execution time: 0.9252
INFO - 2020-11-10 02:06:57 --> Config Class Initialized
INFO - 2020-11-10 02:06:57 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:06:57 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:06:57 --> Utf8 Class Initialized
INFO - 2020-11-10 02:06:57 --> URI Class Initialized
INFO - 2020-11-10 02:06:57 --> Router Class Initialized
INFO - 2020-11-10 02:06:57 --> Output Class Initialized
INFO - 2020-11-10 02:06:57 --> Security Class Initialized
DEBUG - 2020-11-10 02:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:06:57 --> Input Class Initialized
INFO - 2020-11-10 02:06:57 --> Language Class Initialized
INFO - 2020-11-10 02:06:57 --> Language Class Initialized
INFO - 2020-11-10 02:06:57 --> Config Class Initialized
INFO - 2020-11-10 02:06:57 --> Loader Class Initialized
INFO - 2020-11-10 02:06:57 --> Helper loaded: url_helper
INFO - 2020-11-10 02:06:57 --> Helper loaded: file_helper
INFO - 2020-11-10 02:06:57 --> Helper loaded: form_helper
INFO - 2020-11-10 02:06:57 --> Helper loaded: my_helper
INFO - 2020-11-10 02:06:57 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:06:58 --> Controller Class Initialized
DEBUG - 2020-11-10 02:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-10 02:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:06:58 --> Final output sent to browser
DEBUG - 2020-11-10 02:06:58 --> Total execution time: 1.0347
INFO - 2020-11-10 02:07:16 --> Config Class Initialized
INFO - 2020-11-10 02:07:16 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:07:16 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:07:16 --> Utf8 Class Initialized
INFO - 2020-11-10 02:07:16 --> URI Class Initialized
INFO - 2020-11-10 02:07:16 --> Router Class Initialized
INFO - 2020-11-10 02:07:16 --> Output Class Initialized
INFO - 2020-11-10 02:07:16 --> Security Class Initialized
DEBUG - 2020-11-10 02:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:07:16 --> Input Class Initialized
INFO - 2020-11-10 02:07:16 --> Language Class Initialized
INFO - 2020-11-10 02:07:16 --> Language Class Initialized
INFO - 2020-11-10 02:07:16 --> Config Class Initialized
INFO - 2020-11-10 02:07:16 --> Loader Class Initialized
INFO - 2020-11-10 02:07:16 --> Helper loaded: url_helper
INFO - 2020-11-10 02:07:16 --> Helper loaded: file_helper
INFO - 2020-11-10 02:07:16 --> Helper loaded: form_helper
INFO - 2020-11-10 02:07:16 --> Helper loaded: my_helper
INFO - 2020-11-10 02:07:16 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:07:17 --> Controller Class Initialized
DEBUG - 2020-11-10 02:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 02:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:07:17 --> Final output sent to browser
DEBUG - 2020-11-10 02:07:17 --> Total execution time: 1.0015
INFO - 2020-11-10 02:07:18 --> Config Class Initialized
INFO - 2020-11-10 02:07:18 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:07:18 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:07:19 --> Utf8 Class Initialized
INFO - 2020-11-10 02:07:19 --> URI Class Initialized
INFO - 2020-11-10 02:07:19 --> Router Class Initialized
INFO - 2020-11-10 02:07:19 --> Output Class Initialized
INFO - 2020-11-10 02:07:19 --> Security Class Initialized
DEBUG - 2020-11-10 02:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:07:19 --> Input Class Initialized
INFO - 2020-11-10 02:07:19 --> Language Class Initialized
INFO - 2020-11-10 02:07:19 --> Language Class Initialized
INFO - 2020-11-10 02:07:19 --> Config Class Initialized
INFO - 2020-11-10 02:07:19 --> Loader Class Initialized
INFO - 2020-11-10 02:07:19 --> Helper loaded: url_helper
INFO - 2020-11-10 02:07:19 --> Helper loaded: file_helper
INFO - 2020-11-10 02:07:19 --> Helper loaded: form_helper
INFO - 2020-11-10 02:07:19 --> Helper loaded: my_helper
INFO - 2020-11-10 02:07:19 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:07:19 --> Controller Class Initialized
DEBUG - 2020-11-10 02:07:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-10 02:07:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:07:19 --> Final output sent to browser
DEBUG - 2020-11-10 02:07:19 --> Total execution time: 1.0095
INFO - 2020-11-10 02:07:20 --> Config Class Initialized
INFO - 2020-11-10 02:07:20 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:07:20 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:07:20 --> Utf8 Class Initialized
INFO - 2020-11-10 02:07:20 --> URI Class Initialized
INFO - 2020-11-10 02:07:20 --> Router Class Initialized
INFO - 2020-11-10 02:07:20 --> Output Class Initialized
INFO - 2020-11-10 02:07:20 --> Security Class Initialized
DEBUG - 2020-11-10 02:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:07:20 --> Input Class Initialized
INFO - 2020-11-10 02:07:20 --> Language Class Initialized
INFO - 2020-11-10 02:07:20 --> Language Class Initialized
INFO - 2020-11-10 02:07:20 --> Config Class Initialized
INFO - 2020-11-10 02:07:20 --> Loader Class Initialized
INFO - 2020-11-10 02:07:20 --> Helper loaded: url_helper
INFO - 2020-11-10 02:07:20 --> Helper loaded: file_helper
INFO - 2020-11-10 02:07:20 --> Helper loaded: form_helper
INFO - 2020-11-10 02:07:20 --> Helper loaded: my_helper
INFO - 2020-11-10 02:07:20 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:07:20 --> Controller Class Initialized
INFO - 2020-11-10 02:07:29 --> Config Class Initialized
INFO - 2020-11-10 02:07:29 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:07:29 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:07:29 --> Utf8 Class Initialized
INFO - 2020-11-10 02:07:29 --> URI Class Initialized
INFO - 2020-11-10 02:07:29 --> Router Class Initialized
INFO - 2020-11-10 02:07:29 --> Output Class Initialized
INFO - 2020-11-10 02:07:29 --> Security Class Initialized
DEBUG - 2020-11-10 02:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:07:29 --> Input Class Initialized
INFO - 2020-11-10 02:07:29 --> Language Class Initialized
INFO - 2020-11-10 02:07:30 --> Language Class Initialized
INFO - 2020-11-10 02:07:30 --> Config Class Initialized
INFO - 2020-11-10 02:07:30 --> Loader Class Initialized
INFO - 2020-11-10 02:07:30 --> Helper loaded: url_helper
INFO - 2020-11-10 02:07:30 --> Helper loaded: file_helper
INFO - 2020-11-10 02:07:30 --> Helper loaded: form_helper
INFO - 2020-11-10 02:07:30 --> Helper loaded: my_helper
INFO - 2020-11-10 02:07:30 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:07:30 --> Controller Class Initialized
INFO - 2020-11-10 02:07:30 --> Final output sent to browser
DEBUG - 2020-11-10 02:07:30 --> Total execution time: 0.8138
INFO - 2020-11-10 02:08:06 --> Config Class Initialized
INFO - 2020-11-10 02:08:06 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:06 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:06 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:06 --> URI Class Initialized
INFO - 2020-11-10 02:08:06 --> Router Class Initialized
INFO - 2020-11-10 02:08:06 --> Output Class Initialized
INFO - 2020-11-10 02:08:06 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:07 --> Input Class Initialized
INFO - 2020-11-10 02:08:07 --> Language Class Initialized
INFO - 2020-11-10 02:08:07 --> Language Class Initialized
INFO - 2020-11-10 02:08:07 --> Config Class Initialized
INFO - 2020-11-10 02:08:07 --> Loader Class Initialized
INFO - 2020-11-10 02:08:07 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:07 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:07 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:07 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:07 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:07 --> Controller Class Initialized
INFO - 2020-11-10 02:08:07 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:07 --> Total execution time: 0.7094
INFO - 2020-11-10 02:08:07 --> Config Class Initialized
INFO - 2020-11-10 02:08:07 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:07 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:07 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:07 --> URI Class Initialized
INFO - 2020-11-10 02:08:07 --> Router Class Initialized
INFO - 2020-11-10 02:08:08 --> Output Class Initialized
INFO - 2020-11-10 02:08:08 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:08 --> Input Class Initialized
INFO - 2020-11-10 02:08:08 --> Language Class Initialized
INFO - 2020-11-10 02:08:08 --> Language Class Initialized
INFO - 2020-11-10 02:08:08 --> Config Class Initialized
INFO - 2020-11-10 02:08:08 --> Loader Class Initialized
INFO - 2020-11-10 02:08:08 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:08 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:08 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:08 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:08 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:08 --> Controller Class Initialized
INFO - 2020-11-10 02:08:08 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:08 --> Total execution time: 0.8883
INFO - 2020-11-10 02:08:09 --> Config Class Initialized
INFO - 2020-11-10 02:08:09 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:09 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:09 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:09 --> URI Class Initialized
INFO - 2020-11-10 02:08:09 --> Router Class Initialized
INFO - 2020-11-10 02:08:09 --> Output Class Initialized
INFO - 2020-11-10 02:08:09 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:09 --> Input Class Initialized
INFO - 2020-11-10 02:08:09 --> Language Class Initialized
INFO - 2020-11-10 02:08:09 --> Language Class Initialized
INFO - 2020-11-10 02:08:10 --> Config Class Initialized
INFO - 2020-11-10 02:08:10 --> Loader Class Initialized
INFO - 2020-11-10 02:08:10 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:10 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:10 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:10 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:10 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:10 --> Controller Class Initialized
INFO - 2020-11-10 02:08:10 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:10 --> Total execution time: 0.8190
INFO - 2020-11-10 02:08:13 --> Config Class Initialized
INFO - 2020-11-10 02:08:14 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:14 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:14 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:14 --> URI Class Initialized
INFO - 2020-11-10 02:08:14 --> Router Class Initialized
INFO - 2020-11-10 02:08:14 --> Output Class Initialized
INFO - 2020-11-10 02:08:14 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:14 --> Input Class Initialized
INFO - 2020-11-10 02:08:14 --> Language Class Initialized
INFO - 2020-11-10 02:08:14 --> Language Class Initialized
INFO - 2020-11-10 02:08:14 --> Config Class Initialized
INFO - 2020-11-10 02:08:14 --> Loader Class Initialized
INFO - 2020-11-10 02:08:14 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:14 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:14 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:14 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:14 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:14 --> Controller Class Initialized
INFO - 2020-11-10 02:08:14 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:14 --> Total execution time: 0.7419
INFO - 2020-11-10 02:08:23 --> Config Class Initialized
INFO - 2020-11-10 02:08:23 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:23 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:24 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:24 --> URI Class Initialized
INFO - 2020-11-10 02:08:24 --> Router Class Initialized
INFO - 2020-11-10 02:08:24 --> Output Class Initialized
INFO - 2020-11-10 02:08:24 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:24 --> Input Class Initialized
INFO - 2020-11-10 02:08:24 --> Language Class Initialized
INFO - 2020-11-10 02:08:24 --> Language Class Initialized
INFO - 2020-11-10 02:08:24 --> Config Class Initialized
INFO - 2020-11-10 02:08:24 --> Loader Class Initialized
INFO - 2020-11-10 02:08:24 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:24 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:24 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:24 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:24 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:24 --> Controller Class Initialized
INFO - 2020-11-10 02:08:24 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:08:24 --> Config Class Initialized
INFO - 2020-11-10 02:08:24 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:24 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:24 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:24 --> URI Class Initialized
INFO - 2020-11-10 02:08:24 --> Router Class Initialized
INFO - 2020-11-10 02:08:24 --> Output Class Initialized
INFO - 2020-11-10 02:08:24 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:24 --> Input Class Initialized
INFO - 2020-11-10 02:08:25 --> Language Class Initialized
INFO - 2020-11-10 02:08:25 --> Language Class Initialized
INFO - 2020-11-10 02:08:25 --> Config Class Initialized
INFO - 2020-11-10 02:08:25 --> Loader Class Initialized
INFO - 2020-11-10 02:08:25 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:25 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:25 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:25 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:25 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:25 --> Controller Class Initialized
DEBUG - 2020-11-10 02:08:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 02:08:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:08:25 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:25 --> Total execution time: 0.9138
INFO - 2020-11-10 02:08:34 --> Config Class Initialized
INFO - 2020-11-10 02:08:34 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:34 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:34 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:34 --> URI Class Initialized
INFO - 2020-11-10 02:08:34 --> Router Class Initialized
INFO - 2020-11-10 02:08:34 --> Output Class Initialized
INFO - 2020-11-10 02:08:34 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:34 --> Input Class Initialized
INFO - 2020-11-10 02:08:34 --> Language Class Initialized
INFO - 2020-11-10 02:08:34 --> Language Class Initialized
INFO - 2020-11-10 02:08:34 --> Config Class Initialized
INFO - 2020-11-10 02:08:34 --> Loader Class Initialized
INFO - 2020-11-10 02:08:34 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:34 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:34 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:34 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:35 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:35 --> Controller Class Initialized
INFO - 2020-11-10 02:08:35 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:08:35 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:35 --> Total execution time: 0.8192
INFO - 2020-11-10 02:08:35 --> Config Class Initialized
INFO - 2020-11-10 02:08:35 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:35 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:35 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:35 --> URI Class Initialized
INFO - 2020-11-10 02:08:35 --> Router Class Initialized
INFO - 2020-11-10 02:08:35 --> Output Class Initialized
INFO - 2020-11-10 02:08:35 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:35 --> Input Class Initialized
INFO - 2020-11-10 02:08:35 --> Language Class Initialized
INFO - 2020-11-10 02:08:35 --> Language Class Initialized
INFO - 2020-11-10 02:08:35 --> Config Class Initialized
INFO - 2020-11-10 02:08:36 --> Loader Class Initialized
INFO - 2020-11-10 02:08:36 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:36 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:36 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:36 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:36 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:36 --> Controller Class Initialized
DEBUG - 2020-11-10 02:08:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 02:08:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:08:36 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:36 --> Total execution time: 0.7179
INFO - 2020-11-10 02:08:43 --> Config Class Initialized
INFO - 2020-11-10 02:08:43 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:43 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:43 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:43 --> URI Class Initialized
INFO - 2020-11-10 02:08:43 --> Router Class Initialized
INFO - 2020-11-10 02:08:43 --> Output Class Initialized
INFO - 2020-11-10 02:08:43 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:43 --> Input Class Initialized
INFO - 2020-11-10 02:08:43 --> Language Class Initialized
INFO - 2020-11-10 02:08:43 --> Language Class Initialized
INFO - 2020-11-10 02:08:43 --> Config Class Initialized
INFO - 2020-11-10 02:08:43 --> Loader Class Initialized
INFO - 2020-11-10 02:08:43 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:43 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:43 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:44 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:44 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:44 --> Controller Class Initialized
DEBUG - 2020-11-10 02:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-11-10 02:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:08:44 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:44 --> Total execution time: 0.8968
INFO - 2020-11-10 02:08:49 --> Config Class Initialized
INFO - 2020-11-10 02:08:49 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:49 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:49 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:49 --> URI Class Initialized
INFO - 2020-11-10 02:08:49 --> Router Class Initialized
INFO - 2020-11-10 02:08:49 --> Output Class Initialized
INFO - 2020-11-10 02:08:49 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:49 --> Input Class Initialized
INFO - 2020-11-10 02:08:49 --> Language Class Initialized
INFO - 2020-11-10 02:08:49 --> Language Class Initialized
INFO - 2020-11-10 02:08:49 --> Config Class Initialized
INFO - 2020-11-10 02:08:49 --> Loader Class Initialized
INFO - 2020-11-10 02:08:49 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:49 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:49 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:49 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:49 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:50 --> Controller Class Initialized
DEBUG - 2020-11-10 02:08:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-10 02:08:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:08:50 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:50 --> Total execution time: 0.9324
INFO - 2020-11-10 02:08:52 --> Config Class Initialized
INFO - 2020-11-10 02:08:52 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:52 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:52 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:52 --> URI Class Initialized
INFO - 2020-11-10 02:08:52 --> Router Class Initialized
INFO - 2020-11-10 02:08:52 --> Output Class Initialized
INFO - 2020-11-10 02:08:52 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:52 --> Input Class Initialized
INFO - 2020-11-10 02:08:52 --> Language Class Initialized
INFO - 2020-11-10 02:08:52 --> Language Class Initialized
INFO - 2020-11-10 02:08:52 --> Config Class Initialized
INFO - 2020-11-10 02:08:52 --> Loader Class Initialized
INFO - 2020-11-10 02:08:52 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:52 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:52 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:52 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:53 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:53 --> Controller Class Initialized
INFO - 2020-11-10 02:08:53 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:53 --> Total execution time: 0.9083
INFO - 2020-11-10 02:08:58 --> Config Class Initialized
INFO - 2020-11-10 02:08:58 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:58 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:58 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:58 --> URI Class Initialized
INFO - 2020-11-10 02:08:58 --> Router Class Initialized
INFO - 2020-11-10 02:08:58 --> Output Class Initialized
INFO - 2020-11-10 02:08:58 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:58 --> Input Class Initialized
INFO - 2020-11-10 02:08:58 --> Language Class Initialized
INFO - 2020-11-10 02:08:58 --> Language Class Initialized
INFO - 2020-11-10 02:08:58 --> Config Class Initialized
INFO - 2020-11-10 02:08:58 --> Loader Class Initialized
INFO - 2020-11-10 02:08:59 --> Helper loaded: url_helper
INFO - 2020-11-10 02:08:59 --> Helper loaded: file_helper
INFO - 2020-11-10 02:08:59 --> Helper loaded: form_helper
INFO - 2020-11-10 02:08:59 --> Helper loaded: my_helper
INFO - 2020-11-10 02:08:59 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:08:59 --> Controller Class Initialized
DEBUG - 2020-11-10 02:08:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-10 02:08:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:08:59 --> Final output sent to browser
DEBUG - 2020-11-10 02:08:59 --> Total execution time: 0.9419
INFO - 2020-11-10 02:08:59 --> Config Class Initialized
INFO - 2020-11-10 02:08:59 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:08:59 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:08:59 --> Utf8 Class Initialized
INFO - 2020-11-10 02:08:59 --> URI Class Initialized
INFO - 2020-11-10 02:08:59 --> Router Class Initialized
INFO - 2020-11-10 02:08:59 --> Output Class Initialized
INFO - 2020-11-10 02:08:59 --> Security Class Initialized
DEBUG - 2020-11-10 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:08:59 --> Input Class Initialized
INFO - 2020-11-10 02:08:59 --> Language Class Initialized
INFO - 2020-11-10 02:09:00 --> Language Class Initialized
INFO - 2020-11-10 02:09:00 --> Config Class Initialized
INFO - 2020-11-10 02:09:00 --> Loader Class Initialized
INFO - 2020-11-10 02:09:00 --> Helper loaded: url_helper
INFO - 2020-11-10 02:09:00 --> Helper loaded: file_helper
INFO - 2020-11-10 02:09:00 --> Helper loaded: form_helper
INFO - 2020-11-10 02:09:00 --> Helper loaded: my_helper
INFO - 2020-11-10 02:09:00 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:09:00 --> Controller Class Initialized
INFO - 2020-11-10 02:09:02 --> Config Class Initialized
INFO - 2020-11-10 02:09:02 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:09:02 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:09:02 --> Utf8 Class Initialized
INFO - 2020-11-10 02:09:02 --> URI Class Initialized
INFO - 2020-11-10 02:09:02 --> Router Class Initialized
INFO - 2020-11-10 02:09:02 --> Output Class Initialized
INFO - 2020-11-10 02:09:02 --> Security Class Initialized
DEBUG - 2020-11-10 02:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:09:02 --> Input Class Initialized
INFO - 2020-11-10 02:09:03 --> Language Class Initialized
INFO - 2020-11-10 02:09:03 --> Language Class Initialized
INFO - 2020-11-10 02:09:03 --> Config Class Initialized
INFO - 2020-11-10 02:09:03 --> Loader Class Initialized
INFO - 2020-11-10 02:09:03 --> Helper loaded: url_helper
INFO - 2020-11-10 02:09:03 --> Helper loaded: file_helper
INFO - 2020-11-10 02:09:03 --> Helper loaded: form_helper
INFO - 2020-11-10 02:09:03 --> Helper loaded: my_helper
INFO - 2020-11-10 02:09:03 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:09:03 --> Controller Class Initialized
DEBUG - 2020-11-10 02:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-10 02:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:09:03 --> Final output sent to browser
DEBUG - 2020-11-10 02:09:03 --> Total execution time: 0.9356
INFO - 2020-11-10 02:09:10 --> Config Class Initialized
INFO - 2020-11-10 02:09:10 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:09:10 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:09:10 --> Utf8 Class Initialized
INFO - 2020-11-10 02:09:10 --> URI Class Initialized
INFO - 2020-11-10 02:09:11 --> Router Class Initialized
INFO - 2020-11-10 02:09:11 --> Output Class Initialized
INFO - 2020-11-10 02:09:11 --> Security Class Initialized
DEBUG - 2020-11-10 02:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:09:11 --> Input Class Initialized
INFO - 2020-11-10 02:09:11 --> Language Class Initialized
INFO - 2020-11-10 02:09:11 --> Language Class Initialized
INFO - 2020-11-10 02:09:11 --> Config Class Initialized
INFO - 2020-11-10 02:09:11 --> Loader Class Initialized
INFO - 2020-11-10 02:09:11 --> Helper loaded: url_helper
INFO - 2020-11-10 02:09:11 --> Helper loaded: file_helper
INFO - 2020-11-10 02:09:11 --> Helper loaded: form_helper
INFO - 2020-11-10 02:09:11 --> Helper loaded: my_helper
INFO - 2020-11-10 02:09:11 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:09:11 --> Controller Class Initialized
DEBUG - 2020-11-10 02:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-10 02:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:09:11 --> Final output sent to browser
DEBUG - 2020-11-10 02:09:11 --> Total execution time: 1.1325
INFO - 2020-11-10 02:09:12 --> Config Class Initialized
INFO - 2020-11-10 02:09:12 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:09:12 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:09:12 --> Utf8 Class Initialized
INFO - 2020-11-10 02:09:12 --> URI Class Initialized
INFO - 2020-11-10 02:09:13 --> Router Class Initialized
INFO - 2020-11-10 02:09:13 --> Output Class Initialized
INFO - 2020-11-10 02:09:13 --> Security Class Initialized
DEBUG - 2020-11-10 02:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:09:13 --> Input Class Initialized
INFO - 2020-11-10 02:09:13 --> Language Class Initialized
INFO - 2020-11-10 02:09:13 --> Language Class Initialized
INFO - 2020-11-10 02:09:13 --> Config Class Initialized
INFO - 2020-11-10 02:09:13 --> Loader Class Initialized
INFO - 2020-11-10 02:09:13 --> Helper loaded: url_helper
INFO - 2020-11-10 02:09:13 --> Helper loaded: file_helper
INFO - 2020-11-10 02:09:13 --> Helper loaded: form_helper
INFO - 2020-11-10 02:09:13 --> Helper loaded: my_helper
INFO - 2020-11-10 02:09:13 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:09:13 --> Controller Class Initialized
DEBUG - 2020-11-10 02:09:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-11-10 02:09:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:09:13 --> Final output sent to browser
DEBUG - 2020-11-10 02:09:13 --> Total execution time: 1.0208
INFO - 2020-11-10 02:09:17 --> Config Class Initialized
INFO - 2020-11-10 02:09:17 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:09:17 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:09:18 --> Utf8 Class Initialized
INFO - 2020-11-10 02:09:18 --> URI Class Initialized
INFO - 2020-11-10 02:09:18 --> Router Class Initialized
INFO - 2020-11-10 02:09:18 --> Output Class Initialized
INFO - 2020-11-10 02:09:18 --> Security Class Initialized
DEBUG - 2020-11-10 02:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:09:18 --> Input Class Initialized
INFO - 2020-11-10 02:09:18 --> Language Class Initialized
INFO - 2020-11-10 02:09:18 --> Language Class Initialized
INFO - 2020-11-10 02:09:18 --> Config Class Initialized
INFO - 2020-11-10 02:09:18 --> Loader Class Initialized
INFO - 2020-11-10 02:09:18 --> Helper loaded: url_helper
INFO - 2020-11-10 02:09:18 --> Helper loaded: file_helper
INFO - 2020-11-10 02:09:18 --> Helper loaded: form_helper
INFO - 2020-11-10 02:09:18 --> Helper loaded: my_helper
INFO - 2020-11-10 02:09:18 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:09:18 --> Controller Class Initialized
DEBUG - 2020-11-10 02:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2020-11-10 02:09:18 --> Final output sent to browser
DEBUG - 2020-11-10 02:09:18 --> Total execution time: 1.0603
INFO - 2020-11-10 02:13:48 --> Config Class Initialized
INFO - 2020-11-10 02:13:48 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:13:48 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:13:48 --> Utf8 Class Initialized
INFO - 2020-11-10 02:13:48 --> URI Class Initialized
INFO - 2020-11-10 02:13:48 --> Router Class Initialized
INFO - 2020-11-10 02:13:48 --> Output Class Initialized
INFO - 2020-11-10 02:13:48 --> Security Class Initialized
DEBUG - 2020-11-10 02:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:13:48 --> Input Class Initialized
INFO - 2020-11-10 02:13:48 --> Language Class Initialized
INFO - 2020-11-10 02:13:48 --> Language Class Initialized
INFO - 2020-11-10 02:13:48 --> Config Class Initialized
INFO - 2020-11-10 02:13:48 --> Loader Class Initialized
INFO - 2020-11-10 02:13:48 --> Helper loaded: url_helper
INFO - 2020-11-10 02:13:48 --> Helper loaded: file_helper
INFO - 2020-11-10 02:13:48 --> Helper loaded: form_helper
INFO - 2020-11-10 02:13:48 --> Helper loaded: my_helper
INFO - 2020-11-10 02:13:49 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:13:49 --> Controller Class Initialized
DEBUG - 2020-11-10 02:13:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-10 02:13:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:13:49 --> Final output sent to browser
DEBUG - 2020-11-10 02:13:49 --> Total execution time: 0.9794
INFO - 2020-11-10 02:14:25 --> Config Class Initialized
INFO - 2020-11-10 02:14:25 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:14:25 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:14:25 --> Utf8 Class Initialized
INFO - 2020-11-10 02:14:25 --> URI Class Initialized
INFO - 2020-11-10 02:14:25 --> Router Class Initialized
INFO - 2020-11-10 02:14:25 --> Output Class Initialized
INFO - 2020-11-10 02:14:25 --> Security Class Initialized
DEBUG - 2020-11-10 02:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:14:25 --> Input Class Initialized
INFO - 2020-11-10 02:14:25 --> Language Class Initialized
INFO - 2020-11-10 02:14:25 --> Language Class Initialized
INFO - 2020-11-10 02:14:26 --> Config Class Initialized
INFO - 2020-11-10 02:14:26 --> Loader Class Initialized
INFO - 2020-11-10 02:14:26 --> Helper loaded: url_helper
INFO - 2020-11-10 02:14:26 --> Helper loaded: file_helper
INFO - 2020-11-10 02:14:26 --> Helper loaded: form_helper
INFO - 2020-11-10 02:14:26 --> Helper loaded: my_helper
INFO - 2020-11-10 02:14:26 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:14:26 --> Controller Class Initialized
INFO - 2020-11-10 02:14:26 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:14:26 --> Config Class Initialized
INFO - 2020-11-10 02:14:26 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:14:26 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:14:26 --> Utf8 Class Initialized
INFO - 2020-11-10 02:14:26 --> URI Class Initialized
INFO - 2020-11-10 02:14:26 --> Router Class Initialized
INFO - 2020-11-10 02:14:26 --> Output Class Initialized
INFO - 2020-11-10 02:14:26 --> Security Class Initialized
DEBUG - 2020-11-10 02:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:14:26 --> Input Class Initialized
INFO - 2020-11-10 02:14:26 --> Language Class Initialized
INFO - 2020-11-10 02:14:26 --> Language Class Initialized
INFO - 2020-11-10 02:14:26 --> Config Class Initialized
INFO - 2020-11-10 02:14:26 --> Loader Class Initialized
INFO - 2020-11-10 02:14:26 --> Helper loaded: url_helper
INFO - 2020-11-10 02:14:26 --> Helper loaded: file_helper
INFO - 2020-11-10 02:14:27 --> Helper loaded: form_helper
INFO - 2020-11-10 02:14:27 --> Helper loaded: my_helper
INFO - 2020-11-10 02:14:27 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:14:27 --> Controller Class Initialized
DEBUG - 2020-11-10 02:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 02:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:14:27 --> Final output sent to browser
DEBUG - 2020-11-10 02:14:27 --> Total execution time: 0.9547
INFO - 2020-11-10 02:14:38 --> Config Class Initialized
INFO - 2020-11-10 02:14:38 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:14:38 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:14:38 --> Utf8 Class Initialized
INFO - 2020-11-10 02:14:38 --> URI Class Initialized
INFO - 2020-11-10 02:14:38 --> Router Class Initialized
INFO - 2020-11-10 02:14:38 --> Output Class Initialized
INFO - 2020-11-10 02:14:38 --> Security Class Initialized
DEBUG - 2020-11-10 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:14:38 --> Input Class Initialized
INFO - 2020-11-10 02:14:38 --> Language Class Initialized
INFO - 2020-11-10 02:14:38 --> Language Class Initialized
INFO - 2020-11-10 02:14:38 --> Config Class Initialized
INFO - 2020-11-10 02:14:38 --> Loader Class Initialized
INFO - 2020-11-10 02:14:38 --> Helper loaded: url_helper
INFO - 2020-11-10 02:14:38 --> Helper loaded: file_helper
INFO - 2020-11-10 02:14:38 --> Helper loaded: form_helper
INFO - 2020-11-10 02:14:38 --> Helper loaded: my_helper
INFO - 2020-11-10 02:14:38 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:14:38 --> Controller Class Initialized
INFO - 2020-11-10 02:14:38 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:14:38 --> Final output sent to browser
DEBUG - 2020-11-10 02:14:38 --> Total execution time: 0.8207
INFO - 2020-11-10 02:14:39 --> Config Class Initialized
INFO - 2020-11-10 02:14:39 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:14:39 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:14:39 --> Utf8 Class Initialized
INFO - 2020-11-10 02:14:39 --> URI Class Initialized
INFO - 2020-11-10 02:14:39 --> Router Class Initialized
INFO - 2020-11-10 02:14:39 --> Output Class Initialized
INFO - 2020-11-10 02:14:39 --> Security Class Initialized
DEBUG - 2020-11-10 02:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:14:39 --> Input Class Initialized
INFO - 2020-11-10 02:14:39 --> Language Class Initialized
INFO - 2020-11-10 02:14:39 --> Language Class Initialized
INFO - 2020-11-10 02:14:39 --> Config Class Initialized
INFO - 2020-11-10 02:14:39 --> Loader Class Initialized
INFO - 2020-11-10 02:14:39 --> Helper loaded: url_helper
INFO - 2020-11-10 02:14:39 --> Helper loaded: file_helper
INFO - 2020-11-10 02:14:39 --> Helper loaded: form_helper
INFO - 2020-11-10 02:14:39 --> Helper loaded: my_helper
INFO - 2020-11-10 02:14:39 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:14:40 --> Controller Class Initialized
DEBUG - 2020-11-10 02:14:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 02:14:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:14:40 --> Final output sent to browser
DEBUG - 2020-11-10 02:14:40 --> Total execution time: 0.7677
INFO - 2020-11-10 02:14:42 --> Config Class Initialized
INFO - 2020-11-10 02:14:42 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:14:42 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:14:42 --> Utf8 Class Initialized
INFO - 2020-11-10 02:14:42 --> URI Class Initialized
INFO - 2020-11-10 02:14:42 --> Router Class Initialized
INFO - 2020-11-10 02:14:42 --> Output Class Initialized
INFO - 2020-11-10 02:14:42 --> Security Class Initialized
DEBUG - 2020-11-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:14:42 --> Input Class Initialized
INFO - 2020-11-10 02:14:42 --> Language Class Initialized
INFO - 2020-11-10 02:14:42 --> Language Class Initialized
INFO - 2020-11-10 02:14:43 --> Config Class Initialized
INFO - 2020-11-10 02:14:43 --> Loader Class Initialized
INFO - 2020-11-10 02:14:43 --> Helper loaded: url_helper
INFO - 2020-11-10 02:14:43 --> Helper loaded: file_helper
INFO - 2020-11-10 02:14:43 --> Helper loaded: form_helper
INFO - 2020-11-10 02:14:43 --> Helper loaded: my_helper
INFO - 2020-11-10 02:14:43 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:14:43 --> Controller Class Initialized
DEBUG - 2020-11-10 02:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-10 02:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:14:43 --> Final output sent to browser
DEBUG - 2020-11-10 02:14:43 --> Total execution time: 1.0629
INFO - 2020-11-10 02:14:43 --> Config Class Initialized
INFO - 2020-11-10 02:14:43 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:14:43 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:14:43 --> Utf8 Class Initialized
INFO - 2020-11-10 02:14:44 --> URI Class Initialized
INFO - 2020-11-10 02:14:44 --> Router Class Initialized
INFO - 2020-11-10 02:14:44 --> Output Class Initialized
INFO - 2020-11-10 02:14:44 --> Security Class Initialized
DEBUG - 2020-11-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:14:44 --> Input Class Initialized
INFO - 2020-11-10 02:14:44 --> Language Class Initialized
INFO - 2020-11-10 02:14:44 --> Language Class Initialized
INFO - 2020-11-10 02:14:44 --> Config Class Initialized
INFO - 2020-11-10 02:14:44 --> Loader Class Initialized
INFO - 2020-11-10 02:14:44 --> Helper loaded: url_helper
INFO - 2020-11-10 02:14:44 --> Helper loaded: file_helper
INFO - 2020-11-10 02:14:44 --> Helper loaded: form_helper
INFO - 2020-11-10 02:14:44 --> Helper loaded: my_helper
INFO - 2020-11-10 02:14:44 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:14:44 --> Controller Class Initialized
INFO - 2020-11-10 02:15:02 --> Config Class Initialized
INFO - 2020-11-10 02:15:02 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:02 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:02 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:02 --> URI Class Initialized
INFO - 2020-11-10 02:15:02 --> Router Class Initialized
INFO - 2020-11-10 02:15:02 --> Output Class Initialized
INFO - 2020-11-10 02:15:02 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:02 --> Input Class Initialized
INFO - 2020-11-10 02:15:02 --> Language Class Initialized
INFO - 2020-11-10 02:15:02 --> Language Class Initialized
INFO - 2020-11-10 02:15:02 --> Config Class Initialized
INFO - 2020-11-10 02:15:02 --> Loader Class Initialized
INFO - 2020-11-10 02:15:02 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:02 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:02 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:02 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:02 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:02 --> Controller Class Initialized
DEBUG - 2020-11-10 02:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-11-10 02:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:15:03 --> Final output sent to browser
DEBUG - 2020-11-10 02:15:03 --> Total execution time: 0.9682
INFO - 2020-11-10 02:15:03 --> Config Class Initialized
INFO - 2020-11-10 02:15:03 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:03 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:03 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:03 --> URI Class Initialized
INFO - 2020-11-10 02:15:03 --> Router Class Initialized
INFO - 2020-11-10 02:15:03 --> Output Class Initialized
INFO - 2020-11-10 02:15:03 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:03 --> Input Class Initialized
INFO - 2020-11-10 02:15:03 --> Language Class Initialized
INFO - 2020-11-10 02:15:03 --> Language Class Initialized
INFO - 2020-11-10 02:15:03 --> Config Class Initialized
INFO - 2020-11-10 02:15:03 --> Loader Class Initialized
INFO - 2020-11-10 02:15:03 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:03 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:03 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:03 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:03 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:03 --> Controller Class Initialized
INFO - 2020-11-10 02:15:04 --> Config Class Initialized
INFO - 2020-11-10 02:15:04 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:04 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:04 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:04 --> URI Class Initialized
INFO - 2020-11-10 02:15:05 --> Router Class Initialized
INFO - 2020-11-10 02:15:05 --> Output Class Initialized
INFO - 2020-11-10 02:15:05 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:05 --> Input Class Initialized
INFO - 2020-11-10 02:15:05 --> Language Class Initialized
INFO - 2020-11-10 02:15:05 --> Language Class Initialized
INFO - 2020-11-10 02:15:05 --> Config Class Initialized
INFO - 2020-11-10 02:15:05 --> Loader Class Initialized
INFO - 2020-11-10 02:15:05 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:05 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:05 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:05 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:05 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:05 --> Controller Class Initialized
DEBUG - 2020-11-10 02:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-11-10 02:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:15:05 --> Final output sent to browser
DEBUG - 2020-11-10 02:15:05 --> Total execution time: 1.0250
INFO - 2020-11-10 02:15:06 --> Config Class Initialized
INFO - 2020-11-10 02:15:06 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:06 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:06 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:06 --> URI Class Initialized
INFO - 2020-11-10 02:15:06 --> Router Class Initialized
INFO - 2020-11-10 02:15:06 --> Output Class Initialized
INFO - 2020-11-10 02:15:06 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:06 --> Input Class Initialized
INFO - 2020-11-10 02:15:06 --> Language Class Initialized
INFO - 2020-11-10 02:15:06 --> Language Class Initialized
INFO - 2020-11-10 02:15:06 --> Config Class Initialized
INFO - 2020-11-10 02:15:06 --> Loader Class Initialized
INFO - 2020-11-10 02:15:06 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:06 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:06 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:06 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:06 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:06 --> Controller Class Initialized
INFO - 2020-11-10 02:15:07 --> Config Class Initialized
INFO - 2020-11-10 02:15:08 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:08 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:08 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:08 --> URI Class Initialized
INFO - 2020-11-10 02:15:08 --> Router Class Initialized
INFO - 2020-11-10 02:15:08 --> Output Class Initialized
INFO - 2020-11-10 02:15:08 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:08 --> Input Class Initialized
INFO - 2020-11-10 02:15:08 --> Language Class Initialized
INFO - 2020-11-10 02:15:08 --> Language Class Initialized
INFO - 2020-11-10 02:15:08 --> Config Class Initialized
INFO - 2020-11-10 02:15:08 --> Loader Class Initialized
INFO - 2020-11-10 02:15:08 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:08 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:08 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:08 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:08 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:08 --> Controller Class Initialized
DEBUG - 2020-11-10 02:15:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-10 02:15:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:15:09 --> Final output sent to browser
DEBUG - 2020-11-10 02:15:09 --> Total execution time: 1.0531
INFO - 2020-11-10 02:15:09 --> Config Class Initialized
INFO - 2020-11-10 02:15:09 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:09 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:09 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:09 --> URI Class Initialized
INFO - 2020-11-10 02:15:09 --> Router Class Initialized
INFO - 2020-11-10 02:15:09 --> Output Class Initialized
INFO - 2020-11-10 02:15:09 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:09 --> Input Class Initialized
INFO - 2020-11-10 02:15:09 --> Language Class Initialized
INFO - 2020-11-10 02:15:09 --> Language Class Initialized
INFO - 2020-11-10 02:15:09 --> Config Class Initialized
INFO - 2020-11-10 02:15:09 --> Loader Class Initialized
INFO - 2020-11-10 02:15:09 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:09 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:09 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:09 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:09 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:09 --> Controller Class Initialized
INFO - 2020-11-10 02:15:10 --> Config Class Initialized
INFO - 2020-11-10 02:15:10 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:10 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:11 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:11 --> URI Class Initialized
INFO - 2020-11-10 02:15:11 --> Router Class Initialized
INFO - 2020-11-10 02:15:11 --> Output Class Initialized
INFO - 2020-11-10 02:15:11 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:11 --> Input Class Initialized
INFO - 2020-11-10 02:15:11 --> Language Class Initialized
INFO - 2020-11-10 02:15:11 --> Language Class Initialized
INFO - 2020-11-10 02:15:11 --> Config Class Initialized
INFO - 2020-11-10 02:15:11 --> Loader Class Initialized
INFO - 2020-11-10 02:15:11 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:11 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:11 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:11 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:11 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:11 --> Controller Class Initialized
DEBUG - 2020-11-10 02:15:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-11-10 02:15:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:15:11 --> Final output sent to browser
DEBUG - 2020-11-10 02:15:11 --> Total execution time: 0.8717
INFO - 2020-11-10 02:15:11 --> Config Class Initialized
INFO - 2020-11-10 02:15:11 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:12 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:12 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:12 --> URI Class Initialized
INFO - 2020-11-10 02:15:12 --> Router Class Initialized
INFO - 2020-11-10 02:15:12 --> Output Class Initialized
INFO - 2020-11-10 02:15:12 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:12 --> Input Class Initialized
INFO - 2020-11-10 02:15:12 --> Language Class Initialized
INFO - 2020-11-10 02:15:12 --> Language Class Initialized
INFO - 2020-11-10 02:15:12 --> Config Class Initialized
INFO - 2020-11-10 02:15:12 --> Loader Class Initialized
INFO - 2020-11-10 02:15:12 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:12 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:12 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:12 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:12 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:12 --> Controller Class Initialized
INFO - 2020-11-10 02:15:13 --> Config Class Initialized
INFO - 2020-11-10 02:15:13 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:14 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:14 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:14 --> URI Class Initialized
INFO - 2020-11-10 02:15:14 --> Router Class Initialized
INFO - 2020-11-10 02:15:14 --> Output Class Initialized
INFO - 2020-11-10 02:15:14 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:14 --> Input Class Initialized
INFO - 2020-11-10 02:15:14 --> Language Class Initialized
INFO - 2020-11-10 02:15:14 --> Language Class Initialized
INFO - 2020-11-10 02:15:14 --> Config Class Initialized
INFO - 2020-11-10 02:15:14 --> Loader Class Initialized
INFO - 2020-11-10 02:15:14 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:14 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:14 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:14 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:14 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:14 --> Controller Class Initialized
DEBUG - 2020-11-10 02:15:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-10 02:15:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:15:14 --> Final output sent to browser
DEBUG - 2020-11-10 02:15:14 --> Total execution time: 1.0049
INFO - 2020-11-10 02:15:16 --> Config Class Initialized
INFO - 2020-11-10 02:15:16 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:16 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:16 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:16 --> URI Class Initialized
INFO - 2020-11-10 02:15:16 --> Router Class Initialized
INFO - 2020-11-10 02:15:16 --> Output Class Initialized
INFO - 2020-11-10 02:15:16 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:17 --> Input Class Initialized
INFO - 2020-11-10 02:15:17 --> Language Class Initialized
INFO - 2020-11-10 02:15:17 --> Language Class Initialized
INFO - 2020-11-10 02:15:17 --> Config Class Initialized
INFO - 2020-11-10 02:15:17 --> Loader Class Initialized
INFO - 2020-11-10 02:15:17 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:17 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:17 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:17 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:17 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:17 --> Controller Class Initialized
DEBUG - 2020-11-10 02:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-11-10 02:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:15:17 --> Final output sent to browser
DEBUG - 2020-11-10 02:15:17 --> Total execution time: 1.0158
INFO - 2020-11-10 02:15:17 --> Config Class Initialized
INFO - 2020-11-10 02:15:17 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:15:17 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:15:17 --> Utf8 Class Initialized
INFO - 2020-11-10 02:15:17 --> URI Class Initialized
INFO - 2020-11-10 02:15:17 --> Router Class Initialized
INFO - 2020-11-10 02:15:17 --> Output Class Initialized
INFO - 2020-11-10 02:15:17 --> Security Class Initialized
DEBUG - 2020-11-10 02:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:15:17 --> Input Class Initialized
INFO - 2020-11-10 02:15:17 --> Language Class Initialized
INFO - 2020-11-10 02:15:18 --> Language Class Initialized
INFO - 2020-11-10 02:15:18 --> Config Class Initialized
INFO - 2020-11-10 02:15:18 --> Loader Class Initialized
INFO - 2020-11-10 02:15:18 --> Helper loaded: url_helper
INFO - 2020-11-10 02:15:18 --> Helper loaded: file_helper
INFO - 2020-11-10 02:15:18 --> Helper loaded: form_helper
INFO - 2020-11-10 02:15:18 --> Helper loaded: my_helper
INFO - 2020-11-10 02:15:18 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:15:18 --> Controller Class Initialized
INFO - 2020-11-10 02:17:34 --> Config Class Initialized
INFO - 2020-11-10 02:17:34 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:17:35 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:17:35 --> Utf8 Class Initialized
INFO - 2020-11-10 02:17:35 --> URI Class Initialized
INFO - 2020-11-10 02:17:35 --> Router Class Initialized
INFO - 2020-11-10 02:17:35 --> Output Class Initialized
INFO - 2020-11-10 02:17:35 --> Security Class Initialized
DEBUG - 2020-11-10 02:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:17:35 --> Input Class Initialized
INFO - 2020-11-10 02:17:35 --> Language Class Initialized
INFO - 2020-11-10 02:17:35 --> Language Class Initialized
INFO - 2020-11-10 02:17:35 --> Config Class Initialized
INFO - 2020-11-10 02:17:35 --> Loader Class Initialized
INFO - 2020-11-10 02:17:35 --> Helper loaded: url_helper
INFO - 2020-11-10 02:17:35 --> Helper loaded: file_helper
INFO - 2020-11-10 02:17:35 --> Helper loaded: form_helper
INFO - 2020-11-10 02:17:35 --> Helper loaded: my_helper
INFO - 2020-11-10 02:17:35 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:17:35 --> Controller Class Initialized
INFO - 2020-11-10 02:17:35 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:17:35 --> Config Class Initialized
INFO - 2020-11-10 02:17:36 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:17:36 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:17:36 --> Utf8 Class Initialized
INFO - 2020-11-10 02:17:36 --> URI Class Initialized
INFO - 2020-11-10 02:17:36 --> Router Class Initialized
INFO - 2020-11-10 02:17:36 --> Output Class Initialized
INFO - 2020-11-10 02:17:36 --> Security Class Initialized
DEBUG - 2020-11-10 02:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:17:36 --> Input Class Initialized
INFO - 2020-11-10 02:17:36 --> Language Class Initialized
INFO - 2020-11-10 02:17:36 --> Language Class Initialized
INFO - 2020-11-10 02:17:36 --> Config Class Initialized
INFO - 2020-11-10 02:17:36 --> Loader Class Initialized
INFO - 2020-11-10 02:17:36 --> Helper loaded: url_helper
INFO - 2020-11-10 02:17:36 --> Helper loaded: file_helper
INFO - 2020-11-10 02:17:36 --> Helper loaded: form_helper
INFO - 2020-11-10 02:17:36 --> Helper loaded: my_helper
INFO - 2020-11-10 02:17:36 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:17:36 --> Controller Class Initialized
DEBUG - 2020-11-10 02:17:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 02:17:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:17:37 --> Final output sent to browser
DEBUG - 2020-11-10 02:17:37 --> Total execution time: 1.0401
INFO - 2020-11-10 02:17:41 --> Config Class Initialized
INFO - 2020-11-10 02:17:41 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:17:41 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:17:42 --> Utf8 Class Initialized
INFO - 2020-11-10 02:17:42 --> URI Class Initialized
INFO - 2020-11-10 02:17:42 --> Router Class Initialized
INFO - 2020-11-10 02:17:42 --> Output Class Initialized
INFO - 2020-11-10 02:17:42 --> Security Class Initialized
DEBUG - 2020-11-10 02:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:17:42 --> Input Class Initialized
INFO - 2020-11-10 02:17:42 --> Language Class Initialized
INFO - 2020-11-10 02:17:42 --> Language Class Initialized
INFO - 2020-11-10 02:17:42 --> Config Class Initialized
INFO - 2020-11-10 02:17:42 --> Loader Class Initialized
INFO - 2020-11-10 02:17:42 --> Helper loaded: url_helper
INFO - 2020-11-10 02:17:42 --> Helper loaded: file_helper
INFO - 2020-11-10 02:17:42 --> Helper loaded: form_helper
INFO - 2020-11-10 02:17:42 --> Helper loaded: my_helper
INFO - 2020-11-10 02:17:42 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:17:42 --> Controller Class Initialized
INFO - 2020-11-10 02:17:42 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:17:42 --> Final output sent to browser
DEBUG - 2020-11-10 02:17:42 --> Total execution time: 1.0020
INFO - 2020-11-10 02:17:43 --> Config Class Initialized
INFO - 2020-11-10 02:17:44 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:17:44 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:17:44 --> Utf8 Class Initialized
INFO - 2020-11-10 02:17:44 --> URI Class Initialized
INFO - 2020-11-10 02:17:44 --> Router Class Initialized
INFO - 2020-11-10 02:17:44 --> Output Class Initialized
INFO - 2020-11-10 02:17:44 --> Security Class Initialized
DEBUG - 2020-11-10 02:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:17:44 --> Input Class Initialized
INFO - 2020-11-10 02:17:44 --> Language Class Initialized
INFO - 2020-11-10 02:17:44 --> Language Class Initialized
INFO - 2020-11-10 02:17:44 --> Config Class Initialized
INFO - 2020-11-10 02:17:44 --> Loader Class Initialized
INFO - 2020-11-10 02:17:44 --> Helper loaded: url_helper
INFO - 2020-11-10 02:17:44 --> Helper loaded: file_helper
INFO - 2020-11-10 02:17:44 --> Helper loaded: form_helper
INFO - 2020-11-10 02:17:44 --> Helper loaded: my_helper
INFO - 2020-11-10 02:17:44 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:17:44 --> Controller Class Initialized
DEBUG - 2020-11-10 02:17:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 02:17:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:17:44 --> Final output sent to browser
DEBUG - 2020-11-10 02:17:44 --> Total execution time: 0.7859
INFO - 2020-11-10 02:17:49 --> Config Class Initialized
INFO - 2020-11-10 02:17:49 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:17:49 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:17:49 --> Utf8 Class Initialized
INFO - 2020-11-10 02:17:49 --> URI Class Initialized
INFO - 2020-11-10 02:17:49 --> Router Class Initialized
INFO - 2020-11-10 02:17:50 --> Output Class Initialized
INFO - 2020-11-10 02:17:50 --> Security Class Initialized
DEBUG - 2020-11-10 02:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:17:50 --> Input Class Initialized
INFO - 2020-11-10 02:17:50 --> Language Class Initialized
INFO - 2020-11-10 02:17:50 --> Language Class Initialized
INFO - 2020-11-10 02:17:50 --> Config Class Initialized
INFO - 2020-11-10 02:17:50 --> Loader Class Initialized
INFO - 2020-11-10 02:17:50 --> Helper loaded: url_helper
INFO - 2020-11-10 02:17:50 --> Helper loaded: file_helper
INFO - 2020-11-10 02:17:50 --> Helper loaded: form_helper
INFO - 2020-11-10 02:17:50 --> Helper loaded: my_helper
INFO - 2020-11-10 02:17:50 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:17:50 --> Controller Class Initialized
DEBUG - 2020-11-10 02:17:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-10 02:17:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:17:50 --> Final output sent to browser
DEBUG - 2020-11-10 02:17:50 --> Total execution time: 1.1151
INFO - 2020-11-10 02:17:53 --> Config Class Initialized
INFO - 2020-11-10 02:17:53 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:17:53 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:17:53 --> Utf8 Class Initialized
INFO - 2020-11-10 02:17:53 --> URI Class Initialized
INFO - 2020-11-10 02:17:53 --> Router Class Initialized
INFO - 2020-11-10 02:17:53 --> Output Class Initialized
INFO - 2020-11-10 02:17:53 --> Security Class Initialized
DEBUG - 2020-11-10 02:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:17:53 --> Input Class Initialized
INFO - 2020-11-10 02:17:53 --> Language Class Initialized
INFO - 2020-11-10 02:17:53 --> Language Class Initialized
INFO - 2020-11-10 02:17:53 --> Config Class Initialized
INFO - 2020-11-10 02:17:53 --> Loader Class Initialized
INFO - 2020-11-10 02:17:53 --> Helper loaded: url_helper
INFO - 2020-11-10 02:17:53 --> Helper loaded: file_helper
INFO - 2020-11-10 02:17:54 --> Helper loaded: form_helper
INFO - 2020-11-10 02:17:54 --> Helper loaded: my_helper
INFO - 2020-11-10 02:17:54 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:17:54 --> Controller Class Initialized
INFO - 2020-11-10 02:17:54 --> Final output sent to browser
DEBUG - 2020-11-10 02:17:54 --> Total execution time: 0.9194
INFO - 2020-11-10 02:31:12 --> Config Class Initialized
INFO - 2020-11-10 02:31:12 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:12 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:12 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:12 --> URI Class Initialized
INFO - 2020-11-10 02:31:12 --> Router Class Initialized
INFO - 2020-11-10 02:31:12 --> Output Class Initialized
INFO - 2020-11-10 02:31:12 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:12 --> Input Class Initialized
INFO - 2020-11-10 02:31:12 --> Language Class Initialized
INFO - 2020-11-10 02:31:12 --> Language Class Initialized
INFO - 2020-11-10 02:31:12 --> Config Class Initialized
INFO - 2020-11-10 02:31:12 --> Loader Class Initialized
INFO - 2020-11-10 02:31:12 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:13 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:13 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:13 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:13 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:13 --> Controller Class Initialized
INFO - 2020-11-10 02:31:13 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:31:13 --> Config Class Initialized
INFO - 2020-11-10 02:31:13 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:13 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:13 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:13 --> URI Class Initialized
INFO - 2020-11-10 02:31:13 --> Router Class Initialized
INFO - 2020-11-10 02:31:13 --> Output Class Initialized
INFO - 2020-11-10 02:31:13 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:13 --> Input Class Initialized
INFO - 2020-11-10 02:31:13 --> Language Class Initialized
INFO - 2020-11-10 02:31:13 --> Language Class Initialized
INFO - 2020-11-10 02:31:13 --> Config Class Initialized
INFO - 2020-11-10 02:31:13 --> Loader Class Initialized
INFO - 2020-11-10 02:31:13 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:14 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:14 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:14 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:14 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:14 --> Controller Class Initialized
DEBUG - 2020-11-10 02:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 02:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:31:14 --> Final output sent to browser
DEBUG - 2020-11-10 02:31:14 --> Total execution time: 1.0415
INFO - 2020-11-10 02:31:21 --> Config Class Initialized
INFO - 2020-11-10 02:31:21 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:21 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:21 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:21 --> URI Class Initialized
INFO - 2020-11-10 02:31:21 --> Router Class Initialized
INFO - 2020-11-10 02:31:21 --> Output Class Initialized
INFO - 2020-11-10 02:31:21 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:21 --> Input Class Initialized
INFO - 2020-11-10 02:31:21 --> Language Class Initialized
INFO - 2020-11-10 02:31:21 --> Language Class Initialized
INFO - 2020-11-10 02:31:21 --> Config Class Initialized
INFO - 2020-11-10 02:31:21 --> Loader Class Initialized
INFO - 2020-11-10 02:31:21 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:22 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:22 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:22 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:22 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:22 --> Controller Class Initialized
INFO - 2020-11-10 02:31:22 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:31:22 --> Final output sent to browser
DEBUG - 2020-11-10 02:31:22 --> Total execution time: 1.1126
INFO - 2020-11-10 02:31:23 --> Config Class Initialized
INFO - 2020-11-10 02:31:23 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:23 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:23 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:23 --> URI Class Initialized
INFO - 2020-11-10 02:31:23 --> Router Class Initialized
INFO - 2020-11-10 02:31:23 --> Output Class Initialized
INFO - 2020-11-10 02:31:23 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:23 --> Input Class Initialized
INFO - 2020-11-10 02:31:23 --> Language Class Initialized
INFO - 2020-11-10 02:31:23 --> Language Class Initialized
INFO - 2020-11-10 02:31:23 --> Config Class Initialized
INFO - 2020-11-10 02:31:23 --> Loader Class Initialized
INFO - 2020-11-10 02:31:23 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:23 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:23 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:23 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:23 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:23 --> Controller Class Initialized
DEBUG - 2020-11-10 02:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 02:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:31:23 --> Final output sent to browser
DEBUG - 2020-11-10 02:31:23 --> Total execution time: 0.8967
INFO - 2020-11-10 02:31:26 --> Config Class Initialized
INFO - 2020-11-10 02:31:26 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:26 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:26 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:26 --> URI Class Initialized
INFO - 2020-11-10 02:31:26 --> Router Class Initialized
INFO - 2020-11-10 02:31:26 --> Output Class Initialized
INFO - 2020-11-10 02:31:26 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:26 --> Input Class Initialized
INFO - 2020-11-10 02:31:26 --> Language Class Initialized
INFO - 2020-11-10 02:31:27 --> Language Class Initialized
INFO - 2020-11-10 02:31:27 --> Config Class Initialized
INFO - 2020-11-10 02:31:27 --> Loader Class Initialized
INFO - 2020-11-10 02:31:27 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:27 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:27 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:27 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:27 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:27 --> Controller Class Initialized
DEBUG - 2020-11-10 02:31:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 02:31:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:31:27 --> Final output sent to browser
DEBUG - 2020-11-10 02:31:27 --> Total execution time: 0.9857
INFO - 2020-11-10 02:31:30 --> Config Class Initialized
INFO - 2020-11-10 02:31:30 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:30 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:30 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:30 --> URI Class Initialized
INFO - 2020-11-10 02:31:30 --> Router Class Initialized
INFO - 2020-11-10 02:31:30 --> Output Class Initialized
INFO - 2020-11-10 02:31:30 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:30 --> Input Class Initialized
INFO - 2020-11-10 02:31:30 --> Language Class Initialized
INFO - 2020-11-10 02:31:30 --> Language Class Initialized
INFO - 2020-11-10 02:31:30 --> Config Class Initialized
INFO - 2020-11-10 02:31:30 --> Loader Class Initialized
INFO - 2020-11-10 02:31:30 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:30 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:30 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:30 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:30 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:30 --> Controller Class Initialized
INFO - 2020-11-10 02:31:30 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:31:30 --> Config Class Initialized
INFO - 2020-11-10 02:31:30 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:30 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:30 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:30 --> URI Class Initialized
INFO - 2020-11-10 02:31:30 --> Router Class Initialized
INFO - 2020-11-10 02:31:31 --> Output Class Initialized
INFO - 2020-11-10 02:31:31 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:31 --> Input Class Initialized
INFO - 2020-11-10 02:31:31 --> Language Class Initialized
INFO - 2020-11-10 02:31:31 --> Language Class Initialized
INFO - 2020-11-10 02:31:31 --> Config Class Initialized
INFO - 2020-11-10 02:31:31 --> Loader Class Initialized
INFO - 2020-11-10 02:31:31 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:31 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:31 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:31 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:31 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:31 --> Controller Class Initialized
DEBUG - 2020-11-10 02:31:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 02:31:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:31:31 --> Final output sent to browser
DEBUG - 2020-11-10 02:31:31 --> Total execution time: 0.9034
INFO - 2020-11-10 02:31:36 --> Config Class Initialized
INFO - 2020-11-10 02:31:36 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:36 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:36 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:36 --> URI Class Initialized
INFO - 2020-11-10 02:31:36 --> Router Class Initialized
INFO - 2020-11-10 02:31:36 --> Output Class Initialized
INFO - 2020-11-10 02:31:36 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:36 --> Input Class Initialized
INFO - 2020-11-10 02:31:36 --> Language Class Initialized
INFO - 2020-11-10 02:31:36 --> Language Class Initialized
INFO - 2020-11-10 02:31:36 --> Config Class Initialized
INFO - 2020-11-10 02:31:36 --> Loader Class Initialized
INFO - 2020-11-10 02:31:36 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:36 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:36 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:36 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:36 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:37 --> Controller Class Initialized
INFO - 2020-11-10 02:31:37 --> Helper loaded: cookie_helper
INFO - 2020-11-10 02:31:37 --> Final output sent to browser
DEBUG - 2020-11-10 02:31:37 --> Total execution time: 1.0276
INFO - 2020-11-10 02:31:37 --> Config Class Initialized
INFO - 2020-11-10 02:31:37 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:37 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:37 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:37 --> URI Class Initialized
INFO - 2020-11-10 02:31:37 --> Router Class Initialized
INFO - 2020-11-10 02:31:37 --> Output Class Initialized
INFO - 2020-11-10 02:31:37 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:38 --> Input Class Initialized
INFO - 2020-11-10 02:31:38 --> Language Class Initialized
INFO - 2020-11-10 02:31:38 --> Language Class Initialized
INFO - 2020-11-10 02:31:38 --> Config Class Initialized
INFO - 2020-11-10 02:31:38 --> Loader Class Initialized
INFO - 2020-11-10 02:31:38 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:38 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:38 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:38 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:38 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:38 --> Controller Class Initialized
DEBUG - 2020-11-10 02:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 02:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:31:38 --> Final output sent to browser
DEBUG - 2020-11-10 02:31:38 --> Total execution time: 0.9325
INFO - 2020-11-10 02:31:39 --> Config Class Initialized
INFO - 2020-11-10 02:31:39 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:39 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:40 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:40 --> URI Class Initialized
INFO - 2020-11-10 02:31:40 --> Router Class Initialized
INFO - 2020-11-10 02:31:40 --> Output Class Initialized
INFO - 2020-11-10 02:31:40 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:40 --> Input Class Initialized
INFO - 2020-11-10 02:31:40 --> Language Class Initialized
INFO - 2020-11-10 02:31:40 --> Language Class Initialized
INFO - 2020-11-10 02:31:40 --> Config Class Initialized
INFO - 2020-11-10 02:31:40 --> Loader Class Initialized
INFO - 2020-11-10 02:31:40 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:40 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:40 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:40 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:40 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:40 --> Controller Class Initialized
DEBUG - 2020-11-10 02:31:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-10 02:31:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:31:40 --> Final output sent to browser
DEBUG - 2020-11-10 02:31:40 --> Total execution time: 0.9744
INFO - 2020-11-10 02:31:42 --> Config Class Initialized
INFO - 2020-11-10 02:31:42 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:42 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:42 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:42 --> URI Class Initialized
INFO - 2020-11-10 02:31:42 --> Router Class Initialized
INFO - 2020-11-10 02:31:42 --> Output Class Initialized
INFO - 2020-11-10 02:31:42 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:42 --> Input Class Initialized
INFO - 2020-11-10 02:31:42 --> Language Class Initialized
INFO - 2020-11-10 02:31:42 --> Language Class Initialized
INFO - 2020-11-10 02:31:42 --> Config Class Initialized
INFO - 2020-11-10 02:31:42 --> Loader Class Initialized
INFO - 2020-11-10 02:31:42 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:42 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:42 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:43 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:43 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:43 --> Controller Class Initialized
DEBUG - 2020-11-10 02:31:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-10 02:31:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 02:31:43 --> Final output sent to browser
DEBUG - 2020-11-10 02:31:43 --> Total execution time: 1.1281
INFO - 2020-11-10 02:31:43 --> Config Class Initialized
INFO - 2020-11-10 02:31:43 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:43 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:43 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:43 --> URI Class Initialized
INFO - 2020-11-10 02:31:43 --> Router Class Initialized
INFO - 2020-11-10 02:31:43 --> Output Class Initialized
INFO - 2020-11-10 02:31:43 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:43 --> Input Class Initialized
INFO - 2020-11-10 02:31:43 --> Language Class Initialized
INFO - 2020-11-10 02:31:43 --> Language Class Initialized
INFO - 2020-11-10 02:31:43 --> Config Class Initialized
INFO - 2020-11-10 02:31:43 --> Loader Class Initialized
INFO - 2020-11-10 02:31:43 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:44 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:44 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:44 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:44 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:44 --> Controller Class Initialized
INFO - 2020-11-10 02:31:45 --> Config Class Initialized
INFO - 2020-11-10 02:31:45 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:31:45 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:31:45 --> Utf8 Class Initialized
INFO - 2020-11-10 02:31:45 --> URI Class Initialized
INFO - 2020-11-10 02:31:46 --> Router Class Initialized
INFO - 2020-11-10 02:31:46 --> Output Class Initialized
INFO - 2020-11-10 02:31:46 --> Security Class Initialized
DEBUG - 2020-11-10 02:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:31:46 --> Input Class Initialized
INFO - 2020-11-10 02:31:46 --> Language Class Initialized
INFO - 2020-11-10 02:31:46 --> Language Class Initialized
INFO - 2020-11-10 02:31:46 --> Config Class Initialized
INFO - 2020-11-10 02:31:46 --> Loader Class Initialized
INFO - 2020-11-10 02:31:46 --> Helper loaded: url_helper
INFO - 2020-11-10 02:31:46 --> Helper loaded: file_helper
INFO - 2020-11-10 02:31:46 --> Helper loaded: form_helper
INFO - 2020-11-10 02:31:46 --> Helper loaded: my_helper
INFO - 2020-11-10 02:31:46 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:31:46 --> Controller Class Initialized
INFO - 2020-11-10 02:32:13 --> Config Class Initialized
INFO - 2020-11-10 02:32:13 --> Hooks Class Initialized
DEBUG - 2020-11-10 02:32:13 --> UTF-8 Support Enabled
INFO - 2020-11-10 02:32:13 --> Utf8 Class Initialized
INFO - 2020-11-10 02:32:13 --> URI Class Initialized
INFO - 2020-11-10 02:32:13 --> Router Class Initialized
INFO - 2020-11-10 02:32:13 --> Output Class Initialized
INFO - 2020-11-10 02:32:13 --> Security Class Initialized
DEBUG - 2020-11-10 02:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 02:32:13 --> Input Class Initialized
INFO - 2020-11-10 02:32:13 --> Language Class Initialized
INFO - 2020-11-10 02:32:13 --> Language Class Initialized
INFO - 2020-11-10 02:32:13 --> Config Class Initialized
INFO - 2020-11-10 02:32:13 --> Loader Class Initialized
INFO - 2020-11-10 02:32:13 --> Helper loaded: url_helper
INFO - 2020-11-10 02:32:13 --> Helper loaded: file_helper
INFO - 2020-11-10 02:32:13 --> Helper loaded: form_helper
INFO - 2020-11-10 02:32:13 --> Helper loaded: my_helper
INFO - 2020-11-10 02:32:13 --> Database Driver Class Initialized
DEBUG - 2020-11-10 02:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 02:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 02:32:13 --> Controller Class Initialized
INFO - 2020-11-10 02:32:13 --> Final output sent to browser
DEBUG - 2020-11-10 02:32:13 --> Total execution time: 0.9334
INFO - 2020-11-10 08:10:14 --> Config Class Initialized
INFO - 2020-11-10 08:10:14 --> Hooks Class Initialized
DEBUG - 2020-11-10 08:10:14 --> UTF-8 Support Enabled
INFO - 2020-11-10 08:10:14 --> Utf8 Class Initialized
INFO - 2020-11-10 08:10:14 --> URI Class Initialized
DEBUG - 2020-11-10 08:10:14 --> No URI present. Default controller set.
INFO - 2020-11-10 08:10:14 --> Router Class Initialized
INFO - 2020-11-10 08:10:14 --> Output Class Initialized
INFO - 2020-11-10 08:10:14 --> Security Class Initialized
DEBUG - 2020-11-10 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 08:10:14 --> Input Class Initialized
INFO - 2020-11-10 08:10:14 --> Language Class Initialized
INFO - 2020-11-10 08:10:14 --> Language Class Initialized
INFO - 2020-11-10 08:10:14 --> Config Class Initialized
INFO - 2020-11-10 08:10:14 --> Loader Class Initialized
INFO - 2020-11-10 08:10:14 --> Helper loaded: url_helper
INFO - 2020-11-10 08:10:14 --> Helper loaded: file_helper
INFO - 2020-11-10 08:10:14 --> Helper loaded: form_helper
INFO - 2020-11-10 08:10:14 --> Helper loaded: my_helper
INFO - 2020-11-10 08:10:14 --> Database Driver Class Initialized
DEBUG - 2020-11-10 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 08:10:14 --> Controller Class Initialized
INFO - 2020-11-10 08:10:14 --> Config Class Initialized
INFO - 2020-11-10 08:10:14 --> Hooks Class Initialized
DEBUG - 2020-11-10 08:10:15 --> UTF-8 Support Enabled
INFO - 2020-11-10 08:10:15 --> Utf8 Class Initialized
INFO - 2020-11-10 08:10:15 --> URI Class Initialized
INFO - 2020-11-10 08:10:15 --> Router Class Initialized
INFO - 2020-11-10 08:10:15 --> Output Class Initialized
INFO - 2020-11-10 08:10:15 --> Security Class Initialized
DEBUG - 2020-11-10 08:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 08:10:15 --> Input Class Initialized
INFO - 2020-11-10 08:10:15 --> Language Class Initialized
INFO - 2020-11-10 08:10:15 --> Language Class Initialized
INFO - 2020-11-10 08:10:15 --> Config Class Initialized
INFO - 2020-11-10 08:10:15 --> Loader Class Initialized
INFO - 2020-11-10 08:10:15 --> Helper loaded: url_helper
INFO - 2020-11-10 08:10:15 --> Helper loaded: file_helper
INFO - 2020-11-10 08:10:15 --> Helper loaded: form_helper
INFO - 2020-11-10 08:10:15 --> Helper loaded: my_helper
INFO - 2020-11-10 08:10:15 --> Database Driver Class Initialized
DEBUG - 2020-11-10 08:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 08:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 08:10:15 --> Controller Class Initialized
DEBUG - 2020-11-10 08:10:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-10 08:10:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 08:10:15 --> Final output sent to browser
DEBUG - 2020-11-10 08:10:15 --> Total execution time: 0.9656
INFO - 2020-11-10 08:10:21 --> Config Class Initialized
INFO - 2020-11-10 08:10:21 --> Hooks Class Initialized
DEBUG - 2020-11-10 08:10:21 --> UTF-8 Support Enabled
INFO - 2020-11-10 08:10:21 --> Utf8 Class Initialized
INFO - 2020-11-10 08:10:21 --> URI Class Initialized
INFO - 2020-11-10 08:10:21 --> Router Class Initialized
INFO - 2020-11-10 08:10:21 --> Output Class Initialized
INFO - 2020-11-10 08:10:21 --> Security Class Initialized
DEBUG - 2020-11-10 08:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 08:10:21 --> Input Class Initialized
INFO - 2020-11-10 08:10:21 --> Language Class Initialized
INFO - 2020-11-10 08:10:21 --> Language Class Initialized
INFO - 2020-11-10 08:10:21 --> Config Class Initialized
INFO - 2020-11-10 08:10:21 --> Loader Class Initialized
INFO - 2020-11-10 08:10:21 --> Helper loaded: url_helper
INFO - 2020-11-10 08:10:21 --> Helper loaded: file_helper
INFO - 2020-11-10 08:10:21 --> Helper loaded: form_helper
INFO - 2020-11-10 08:10:21 --> Helper loaded: my_helper
INFO - 2020-11-10 08:10:21 --> Database Driver Class Initialized
DEBUG - 2020-11-10 08:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 08:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 08:10:21 --> Controller Class Initialized
INFO - 2020-11-10 08:10:22 --> Helper loaded: cookie_helper
INFO - 2020-11-10 08:10:22 --> Final output sent to browser
DEBUG - 2020-11-10 08:10:22 --> Total execution time: 0.8354
INFO - 2020-11-10 08:10:22 --> Config Class Initialized
INFO - 2020-11-10 08:10:22 --> Hooks Class Initialized
DEBUG - 2020-11-10 08:10:22 --> UTF-8 Support Enabled
INFO - 2020-11-10 08:10:22 --> Utf8 Class Initialized
INFO - 2020-11-10 08:10:22 --> URI Class Initialized
INFO - 2020-11-10 08:10:22 --> Router Class Initialized
INFO - 2020-11-10 08:10:22 --> Output Class Initialized
INFO - 2020-11-10 08:10:22 --> Security Class Initialized
DEBUG - 2020-11-10 08:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 08:10:22 --> Input Class Initialized
INFO - 2020-11-10 08:10:22 --> Language Class Initialized
INFO - 2020-11-10 08:10:22 --> Language Class Initialized
INFO - 2020-11-10 08:10:22 --> Config Class Initialized
INFO - 2020-11-10 08:10:23 --> Loader Class Initialized
INFO - 2020-11-10 08:10:23 --> Helper loaded: url_helper
INFO - 2020-11-10 08:10:23 --> Helper loaded: file_helper
INFO - 2020-11-10 08:10:23 --> Helper loaded: form_helper
INFO - 2020-11-10 08:10:23 --> Helper loaded: my_helper
INFO - 2020-11-10 08:10:23 --> Database Driver Class Initialized
DEBUG - 2020-11-10 08:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-10 08:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 08:10:23 --> Controller Class Initialized
DEBUG - 2020-11-10 08:10:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-10 08:10:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-10 08:10:23 --> Final output sent to browser
DEBUG - 2020-11-10 08:10:23 --> Total execution time: 0.8320
