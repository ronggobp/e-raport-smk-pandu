<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-10-02 02:19:49 --> Config Class Initialized
INFO - 2021-10-02 02:19:49 --> Hooks Class Initialized
DEBUG - 2021-10-02 02:19:49 --> UTF-8 Support Enabled
INFO - 2021-10-02 02:19:49 --> Utf8 Class Initialized
INFO - 2021-10-02 02:19:49 --> URI Class Initialized
INFO - 2021-10-02 02:19:49 --> Router Class Initialized
INFO - 2021-10-02 02:19:49 --> Output Class Initialized
INFO - 2021-10-02 02:19:49 --> Security Class Initialized
DEBUG - 2021-10-02 02:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-02 02:19:49 --> Input Class Initialized
INFO - 2021-10-02 02:19:49 --> Language Class Initialized
INFO - 2021-10-02 02:19:49 --> Language Class Initialized
INFO - 2021-10-02 02:19:49 --> Config Class Initialized
INFO - 2021-10-02 02:19:49 --> Loader Class Initialized
INFO - 2021-10-02 02:19:49 --> Helper loaded: url_helper
INFO - 2021-10-02 02:19:49 --> Helper loaded: file_helper
INFO - 2021-10-02 02:19:49 --> Helper loaded: form_helper
INFO - 2021-10-02 02:19:49 --> Helper loaded: my_helper
INFO - 2021-10-02 02:19:50 --> Database Driver Class Initialized
DEBUG - 2021-10-02 02:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-02 02:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-02 02:19:50 --> Controller Class Initialized
DEBUG - 2021-10-02 02:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-02 02:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-02 02:19:50 --> Final output sent to browser
DEBUG - 2021-10-02 02:19:50 --> Total execution time: 0.6710
INFO - 2021-10-02 02:19:56 --> Config Class Initialized
INFO - 2021-10-02 02:19:56 --> Hooks Class Initialized
DEBUG - 2021-10-02 02:19:56 --> UTF-8 Support Enabled
INFO - 2021-10-02 02:19:56 --> Utf8 Class Initialized
INFO - 2021-10-02 02:19:56 --> URI Class Initialized
DEBUG - 2021-10-02 02:19:56 --> No URI present. Default controller set.
INFO - 2021-10-02 02:19:56 --> Router Class Initialized
INFO - 2021-10-02 02:19:56 --> Output Class Initialized
INFO - 2021-10-02 02:19:56 --> Security Class Initialized
DEBUG - 2021-10-02 02:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-02 02:19:56 --> Input Class Initialized
INFO - 2021-10-02 02:19:56 --> Language Class Initialized
INFO - 2021-10-02 02:19:56 --> Language Class Initialized
INFO - 2021-10-02 02:19:56 --> Config Class Initialized
INFO - 2021-10-02 02:19:56 --> Loader Class Initialized
INFO - 2021-10-02 02:19:56 --> Helper loaded: url_helper
INFO - 2021-10-02 02:19:56 --> Helper loaded: file_helper
INFO - 2021-10-02 02:19:56 --> Helper loaded: form_helper
INFO - 2021-10-02 02:19:56 --> Helper loaded: my_helper
INFO - 2021-10-02 02:19:56 --> Database Driver Class Initialized
DEBUG - 2021-10-02 02:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-02 02:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-02 02:19:56 --> Controller Class Initialized
INFO - 2021-10-02 02:19:56 --> Config Class Initialized
INFO - 2021-10-02 02:19:56 --> Hooks Class Initialized
DEBUG - 2021-10-02 02:19:56 --> UTF-8 Support Enabled
INFO - 2021-10-02 02:19:56 --> Utf8 Class Initialized
INFO - 2021-10-02 02:19:56 --> URI Class Initialized
INFO - 2021-10-02 02:19:56 --> Router Class Initialized
INFO - 2021-10-02 02:19:56 --> Output Class Initialized
INFO - 2021-10-02 02:19:56 --> Security Class Initialized
DEBUG - 2021-10-02 02:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-02 02:19:56 --> Input Class Initialized
INFO - 2021-10-02 02:19:56 --> Language Class Initialized
INFO - 2021-10-02 02:19:56 --> Language Class Initialized
INFO - 2021-10-02 02:19:56 --> Config Class Initialized
INFO - 2021-10-02 02:19:56 --> Loader Class Initialized
INFO - 2021-10-02 02:19:56 --> Helper loaded: url_helper
INFO - 2021-10-02 02:19:56 --> Helper loaded: file_helper
INFO - 2021-10-02 02:19:56 --> Helper loaded: form_helper
INFO - 2021-10-02 02:19:56 --> Helper loaded: my_helper
INFO - 2021-10-02 02:19:56 --> Database Driver Class Initialized
DEBUG - 2021-10-02 02:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-02 02:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-02 02:19:56 --> Controller Class Initialized
DEBUG - 2021-10-02 02:19:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-02 02:19:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-02 02:19:56 --> Final output sent to browser
DEBUG - 2021-10-02 02:19:56 --> Total execution time: 0.0585
INFO - 2021-10-02 02:19:58 --> Config Class Initialized
INFO - 2021-10-02 02:19:58 --> Hooks Class Initialized
DEBUG - 2021-10-02 02:19:58 --> UTF-8 Support Enabled
INFO - 2021-10-02 02:19:58 --> Utf8 Class Initialized
INFO - 2021-10-02 02:19:58 --> URI Class Initialized
DEBUG - 2021-10-02 02:19:58 --> No URI present. Default controller set.
INFO - 2021-10-02 02:19:58 --> Router Class Initialized
INFO - 2021-10-02 02:19:58 --> Output Class Initialized
INFO - 2021-10-02 02:19:58 --> Security Class Initialized
DEBUG - 2021-10-02 02:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-02 02:19:58 --> Input Class Initialized
INFO - 2021-10-02 02:19:58 --> Language Class Initialized
INFO - 2021-10-02 02:19:58 --> Language Class Initialized
INFO - 2021-10-02 02:19:58 --> Config Class Initialized
INFO - 2021-10-02 02:19:58 --> Loader Class Initialized
INFO - 2021-10-02 02:19:58 --> Helper loaded: url_helper
INFO - 2021-10-02 02:19:58 --> Helper loaded: file_helper
INFO - 2021-10-02 02:19:58 --> Helper loaded: form_helper
INFO - 2021-10-02 02:19:58 --> Helper loaded: my_helper
INFO - 2021-10-02 02:19:58 --> Database Driver Class Initialized
DEBUG - 2021-10-02 02:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-02 02:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-02 02:19:58 --> Controller Class Initialized
INFO - 2021-10-02 02:19:58 --> Config Class Initialized
INFO - 2021-10-02 02:19:58 --> Hooks Class Initialized
DEBUG - 2021-10-02 02:19:58 --> UTF-8 Support Enabled
INFO - 2021-10-02 02:19:58 --> Utf8 Class Initialized
INFO - 2021-10-02 02:19:58 --> URI Class Initialized
INFO - 2021-10-02 02:19:58 --> Router Class Initialized
INFO - 2021-10-02 02:19:58 --> Output Class Initialized
INFO - 2021-10-02 02:19:58 --> Security Class Initialized
DEBUG - 2021-10-02 02:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-02 02:19:58 --> Input Class Initialized
INFO - 2021-10-02 02:19:58 --> Language Class Initialized
INFO - 2021-10-02 02:19:58 --> Language Class Initialized
INFO - 2021-10-02 02:19:58 --> Config Class Initialized
INFO - 2021-10-02 02:19:58 --> Loader Class Initialized
INFO - 2021-10-02 02:19:58 --> Helper loaded: url_helper
INFO - 2021-10-02 02:19:58 --> Helper loaded: file_helper
INFO - 2021-10-02 02:19:58 --> Helper loaded: form_helper
INFO - 2021-10-02 02:19:58 --> Helper loaded: my_helper
INFO - 2021-10-02 02:19:58 --> Database Driver Class Initialized
DEBUG - 2021-10-02 02:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-02 02:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-02 02:19:58 --> Controller Class Initialized
DEBUG - 2021-10-02 02:19:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-10-02 02:19:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-10-02 02:19:58 --> Final output sent to browser
DEBUG - 2021-10-02 02:19:58 --> Total execution time: 0.0570
