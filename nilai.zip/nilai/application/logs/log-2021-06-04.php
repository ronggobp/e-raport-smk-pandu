<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-04 10:19:22 --> Config Class Initialized
INFO - 2021-06-04 10:19:22 --> Hooks Class Initialized
DEBUG - 2021-06-04 10:19:22 --> UTF-8 Support Enabled
INFO - 2021-06-04 10:19:22 --> Utf8 Class Initialized
INFO - 2021-06-04 10:19:22 --> URI Class Initialized
DEBUG - 2021-06-04 10:19:22 --> No URI present. Default controller set.
INFO - 2021-06-04 10:19:22 --> Router Class Initialized
INFO - 2021-06-04 10:19:22 --> Output Class Initialized
INFO - 2021-06-04 10:19:22 --> Security Class Initialized
DEBUG - 2021-06-04 10:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-04 10:19:22 --> Input Class Initialized
INFO - 2021-06-04 10:19:22 --> Language Class Initialized
INFO - 2021-06-04 10:19:22 --> Language Class Initialized
INFO - 2021-06-04 10:19:22 --> Config Class Initialized
INFO - 2021-06-04 10:19:22 --> Loader Class Initialized
INFO - 2021-06-04 10:19:22 --> Helper loaded: url_helper
INFO - 2021-06-04 10:19:22 --> Helper loaded: file_helper
INFO - 2021-06-04 10:19:22 --> Helper loaded: form_helper
INFO - 2021-06-04 10:19:22 --> Helper loaded: my_helper
INFO - 2021-06-04 10:19:22 --> Database Driver Class Initialized
DEBUG - 2021-06-04 10:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-04 10:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-04 10:19:23 --> Controller Class Initialized
INFO - 2021-06-04 10:19:23 --> Config Class Initialized
INFO - 2021-06-04 10:19:23 --> Hooks Class Initialized
DEBUG - 2021-06-04 10:19:23 --> UTF-8 Support Enabled
INFO - 2021-06-04 10:19:23 --> Utf8 Class Initialized
INFO - 2021-06-04 10:19:23 --> URI Class Initialized
INFO - 2021-06-04 10:19:23 --> Router Class Initialized
INFO - 2021-06-04 10:19:23 --> Output Class Initialized
INFO - 2021-06-04 10:19:23 --> Security Class Initialized
DEBUG - 2021-06-04 10:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-04 10:19:23 --> Input Class Initialized
INFO - 2021-06-04 10:19:23 --> Language Class Initialized
INFO - 2021-06-04 10:19:23 --> Language Class Initialized
INFO - 2021-06-04 10:19:23 --> Config Class Initialized
INFO - 2021-06-04 10:19:23 --> Loader Class Initialized
INFO - 2021-06-04 10:19:23 --> Helper loaded: url_helper
INFO - 2021-06-04 10:19:23 --> Helper loaded: file_helper
INFO - 2021-06-04 10:19:23 --> Helper loaded: form_helper
INFO - 2021-06-04 10:19:23 --> Helper loaded: my_helper
INFO - 2021-06-04 10:19:23 --> Database Driver Class Initialized
DEBUG - 2021-06-04 10:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-04 10:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-04 10:19:23 --> Controller Class Initialized
DEBUG - 2021-06-04 10:19:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-04 10:19:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-04 10:19:23 --> Final output sent to browser
DEBUG - 2021-06-04 10:19:23 --> Total execution time: 0.1553
