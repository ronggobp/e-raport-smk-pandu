<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-28 02:18:08 --> Config Class Initialized
INFO - 2021-04-28 02:18:08 --> Hooks Class Initialized
DEBUG - 2021-04-28 02:18:08 --> UTF-8 Support Enabled
INFO - 2021-04-28 02:18:08 --> Utf8 Class Initialized
INFO - 2021-04-28 02:18:08 --> URI Class Initialized
DEBUG - 2021-04-28 02:18:08 --> No URI present. Default controller set.
INFO - 2021-04-28 02:18:08 --> Router Class Initialized
INFO - 2021-04-28 02:18:08 --> Output Class Initialized
INFO - 2021-04-28 02:18:08 --> Security Class Initialized
DEBUG - 2021-04-28 02:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 02:18:08 --> Input Class Initialized
INFO - 2021-04-28 02:18:08 --> Language Class Initialized
INFO - 2021-04-28 02:18:08 --> Language Class Initialized
INFO - 2021-04-28 02:18:08 --> Config Class Initialized
INFO - 2021-04-28 02:18:08 --> Loader Class Initialized
INFO - 2021-04-28 02:18:08 --> Helper loaded: url_helper
INFO - 2021-04-28 02:18:08 --> Helper loaded: file_helper
INFO - 2021-04-28 02:18:08 --> Helper loaded: form_helper
INFO - 2021-04-28 02:18:08 --> Helper loaded: my_helper
INFO - 2021-04-28 02:18:08 --> Database Driver Class Initialized
DEBUG - 2021-04-28 02:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 02:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 02:18:08 --> Controller Class Initialized
INFO - 2021-04-28 02:18:08 --> Config Class Initialized
INFO - 2021-04-28 02:18:08 --> Hooks Class Initialized
DEBUG - 2021-04-28 02:18:08 --> UTF-8 Support Enabled
INFO - 2021-04-28 02:18:08 --> Utf8 Class Initialized
INFO - 2021-04-28 02:18:08 --> URI Class Initialized
INFO - 2021-04-28 02:18:08 --> Router Class Initialized
INFO - 2021-04-28 02:18:08 --> Output Class Initialized
INFO - 2021-04-28 02:18:08 --> Security Class Initialized
DEBUG - 2021-04-28 02:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 02:18:08 --> Input Class Initialized
INFO - 2021-04-28 02:18:08 --> Language Class Initialized
INFO - 2021-04-28 02:18:08 --> Language Class Initialized
INFO - 2021-04-28 02:18:08 --> Config Class Initialized
INFO - 2021-04-28 02:18:08 --> Loader Class Initialized
INFO - 2021-04-28 02:18:08 --> Helper loaded: url_helper
INFO - 2021-04-28 02:18:08 --> Helper loaded: file_helper
INFO - 2021-04-28 02:18:08 --> Helper loaded: form_helper
INFO - 2021-04-28 02:18:08 --> Helper loaded: my_helper
INFO - 2021-04-28 02:18:08 --> Database Driver Class Initialized
DEBUG - 2021-04-28 02:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 02:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 02:18:08 --> Controller Class Initialized
DEBUG - 2021-04-28 02:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 02:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 02:18:08 --> Final output sent to browser
DEBUG - 2021-04-28 02:18:08 --> Total execution time: 0.0814
INFO - 2021-04-28 02:18:15 --> Config Class Initialized
INFO - 2021-04-28 02:18:15 --> Hooks Class Initialized
DEBUG - 2021-04-28 02:18:15 --> UTF-8 Support Enabled
INFO - 2021-04-28 02:18:15 --> Utf8 Class Initialized
INFO - 2021-04-28 02:18:15 --> URI Class Initialized
INFO - 2021-04-28 02:18:15 --> Router Class Initialized
INFO - 2021-04-28 02:18:15 --> Output Class Initialized
INFO - 2021-04-28 02:18:15 --> Security Class Initialized
DEBUG - 2021-04-28 02:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 02:18:15 --> Input Class Initialized
INFO - 2021-04-28 02:18:15 --> Language Class Initialized
INFO - 2021-04-28 02:18:15 --> Language Class Initialized
INFO - 2021-04-28 02:18:15 --> Config Class Initialized
INFO - 2021-04-28 02:18:15 --> Loader Class Initialized
INFO - 2021-04-28 02:18:15 --> Helper loaded: url_helper
INFO - 2021-04-28 02:18:15 --> Helper loaded: file_helper
INFO - 2021-04-28 02:18:15 --> Helper loaded: form_helper
INFO - 2021-04-28 02:18:15 --> Helper loaded: my_helper
INFO - 2021-04-28 02:18:15 --> Database Driver Class Initialized
DEBUG - 2021-04-28 02:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 02:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 02:18:15 --> Controller Class Initialized
INFO - 2021-04-28 02:18:15 --> Helper loaded: cookie_helper
INFO - 2021-04-28 02:18:15 --> Final output sent to browser
DEBUG - 2021-04-28 02:18:15 --> Total execution time: 0.0831
INFO - 2021-04-28 02:18:16 --> Config Class Initialized
INFO - 2021-04-28 02:18:16 --> Hooks Class Initialized
DEBUG - 2021-04-28 02:18:16 --> UTF-8 Support Enabled
INFO - 2021-04-28 02:18:16 --> Utf8 Class Initialized
INFO - 2021-04-28 02:18:16 --> URI Class Initialized
INFO - 2021-04-28 02:18:16 --> Router Class Initialized
INFO - 2021-04-28 02:18:16 --> Output Class Initialized
INFO - 2021-04-28 02:18:16 --> Security Class Initialized
DEBUG - 2021-04-28 02:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 02:18:16 --> Input Class Initialized
INFO - 2021-04-28 02:18:16 --> Language Class Initialized
INFO - 2021-04-28 02:18:16 --> Language Class Initialized
INFO - 2021-04-28 02:18:16 --> Config Class Initialized
INFO - 2021-04-28 02:18:16 --> Loader Class Initialized
INFO - 2021-04-28 02:18:16 --> Helper loaded: url_helper
INFO - 2021-04-28 02:18:16 --> Helper loaded: file_helper
INFO - 2021-04-28 02:18:16 --> Helper loaded: form_helper
INFO - 2021-04-28 02:18:16 --> Helper loaded: my_helper
INFO - 2021-04-28 02:18:16 --> Database Driver Class Initialized
DEBUG - 2021-04-28 02:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 02:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 02:18:16 --> Controller Class Initialized
DEBUG - 2021-04-28 02:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 02:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 02:18:16 --> Final output sent to browser
DEBUG - 2021-04-28 02:18:16 --> Total execution time: 0.0896
INFO - 2021-04-28 02:18:19 --> Config Class Initialized
INFO - 2021-04-28 02:18:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 02:18:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 02:18:19 --> Utf8 Class Initialized
INFO - 2021-04-28 02:18:19 --> URI Class Initialized
INFO - 2021-04-28 02:18:19 --> Router Class Initialized
INFO - 2021-04-28 02:18:19 --> Output Class Initialized
INFO - 2021-04-28 02:18:19 --> Security Class Initialized
DEBUG - 2021-04-28 02:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 02:18:19 --> Input Class Initialized
INFO - 2021-04-28 02:18:19 --> Language Class Initialized
INFO - 2021-04-28 02:18:19 --> Language Class Initialized
INFO - 2021-04-28 02:18:19 --> Config Class Initialized
INFO - 2021-04-28 02:18:19 --> Loader Class Initialized
INFO - 2021-04-28 02:18:19 --> Helper loaded: url_helper
INFO - 2021-04-28 02:18:19 --> Helper loaded: file_helper
INFO - 2021-04-28 02:18:19 --> Helper loaded: form_helper
INFO - 2021-04-28 02:18:19 --> Helper loaded: my_helper
INFO - 2021-04-28 02:18:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 02:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 02:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 02:18:19 --> Controller Class Initialized
DEBUG - 2021-04-28 02:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-28 02:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 02:18:19 --> Final output sent to browser
DEBUG - 2021-04-28 02:18:19 --> Total execution time: 0.0709
INFO - 2021-04-28 02:18:19 --> Config Class Initialized
INFO - 2021-04-28 02:18:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 02:18:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 02:18:19 --> Utf8 Class Initialized
INFO - 2021-04-28 02:18:19 --> URI Class Initialized
INFO - 2021-04-28 02:18:19 --> Router Class Initialized
INFO - 2021-04-28 02:18:19 --> Output Class Initialized
INFO - 2021-04-28 02:18:19 --> Security Class Initialized
DEBUG - 2021-04-28 02:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 02:18:19 --> Input Class Initialized
INFO - 2021-04-28 02:18:19 --> Language Class Initialized
INFO - 2021-04-28 02:18:19 --> Language Class Initialized
INFO - 2021-04-28 02:18:19 --> Config Class Initialized
INFO - 2021-04-28 02:18:19 --> Loader Class Initialized
INFO - 2021-04-28 02:18:19 --> Helper loaded: url_helper
INFO - 2021-04-28 02:18:19 --> Helper loaded: file_helper
INFO - 2021-04-28 02:18:19 --> Helper loaded: form_helper
INFO - 2021-04-28 02:18:19 --> Helper loaded: my_helper
INFO - 2021-04-28 02:18:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 02:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 02:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 02:18:19 --> Controller Class Initialized
INFO - 2021-04-28 02:23:19 --> Config Class Initialized
INFO - 2021-04-28 02:23:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 02:23:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 02:23:19 --> Utf8 Class Initialized
INFO - 2021-04-28 02:23:19 --> URI Class Initialized
INFO - 2021-04-28 02:23:19 --> Router Class Initialized
INFO - 2021-04-28 02:23:19 --> Output Class Initialized
INFO - 2021-04-28 02:23:19 --> Security Class Initialized
DEBUG - 2021-04-28 02:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 02:23:19 --> Input Class Initialized
INFO - 2021-04-28 02:23:19 --> Language Class Initialized
INFO - 2021-04-28 02:23:19 --> Language Class Initialized
INFO - 2021-04-28 02:23:19 --> Config Class Initialized
INFO - 2021-04-28 02:23:19 --> Loader Class Initialized
INFO - 2021-04-28 02:23:19 --> Helper loaded: url_helper
INFO - 2021-04-28 02:23:19 --> Helper loaded: file_helper
INFO - 2021-04-28 02:23:19 --> Helper loaded: form_helper
INFO - 2021-04-28 02:23:19 --> Helper loaded: my_helper
INFO - 2021-04-28 02:23:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 02:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 02:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 02:23:19 --> Controller Class Initialized
ERROR - 2021-04-28 02:23:19 --> Query error: Unknown column 'b.nmsiswa' in 'field list' - Invalid query: SELECT 
                                                        a.id, a.id_kelas, b.nmsiswa
                                                        FROM t_kelas_siswa a
                                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                        WHERE a.id_kelas = '1' 
                                                        AND a.ta = '2020'
                                                        ORDER BY b.nama ASC, b.nis ASC
INFO - 2021-04-28 02:23:19 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 02:23:41 --> Config Class Initialized
INFO - 2021-04-28 02:23:41 --> Hooks Class Initialized
DEBUG - 2021-04-28 02:23:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 02:23:41 --> Utf8 Class Initialized
INFO - 2021-04-28 02:23:41 --> URI Class Initialized
INFO - 2021-04-28 02:23:41 --> Router Class Initialized
INFO - 2021-04-28 02:23:41 --> Output Class Initialized
INFO - 2021-04-28 02:23:41 --> Security Class Initialized
DEBUG - 2021-04-28 02:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 02:23:41 --> Input Class Initialized
INFO - 2021-04-28 02:23:41 --> Language Class Initialized
INFO - 2021-04-28 02:23:41 --> Language Class Initialized
INFO - 2021-04-28 02:23:41 --> Config Class Initialized
INFO - 2021-04-28 02:23:41 --> Loader Class Initialized
INFO - 2021-04-28 02:23:41 --> Helper loaded: url_helper
INFO - 2021-04-28 02:23:41 --> Helper loaded: file_helper
INFO - 2021-04-28 02:23:41 --> Helper loaded: form_helper
INFO - 2021-04-28 02:23:41 --> Helper loaded: my_helper
INFO - 2021-04-28 02:23:41 --> Database Driver Class Initialized
DEBUG - 2021-04-28 02:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 02:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 02:23:41 --> Controller Class Initialized
DEBUG - 2021-04-28 02:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 02:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 02:23:41 --> Final output sent to browser
DEBUG - 2021-04-28 02:23:41 --> Total execution time: 0.0690
INFO - 2021-04-28 03:00:55 --> Config Class Initialized
INFO - 2021-04-28 03:00:55 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:00:55 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:00:55 --> Utf8 Class Initialized
INFO - 2021-04-28 03:00:55 --> URI Class Initialized
INFO - 2021-04-28 03:00:55 --> Router Class Initialized
INFO - 2021-04-28 03:00:55 --> Output Class Initialized
INFO - 2021-04-28 03:00:55 --> Security Class Initialized
DEBUG - 2021-04-28 03:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:00:55 --> Input Class Initialized
INFO - 2021-04-28 03:00:55 --> Language Class Initialized
INFO - 2021-04-28 03:00:55 --> Language Class Initialized
INFO - 2021-04-28 03:00:55 --> Config Class Initialized
INFO - 2021-04-28 03:00:55 --> Loader Class Initialized
INFO - 2021-04-28 03:00:55 --> Helper loaded: url_helper
INFO - 2021-04-28 03:00:55 --> Helper loaded: file_helper
INFO - 2021-04-28 03:00:55 --> Helper loaded: form_helper
INFO - 2021-04-28 03:00:55 --> Helper loaded: my_helper
INFO - 2021-04-28 03:00:55 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:00:55 --> Controller Class Initialized
DEBUG - 2021-04-28 03:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-28 03:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:00:55 --> Final output sent to browser
DEBUG - 2021-04-28 03:00:55 --> Total execution time: 0.0662
INFO - 2021-04-28 03:00:56 --> Config Class Initialized
INFO - 2021-04-28 03:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:00:56 --> Utf8 Class Initialized
INFO - 2021-04-28 03:00:56 --> URI Class Initialized
INFO - 2021-04-28 03:00:56 --> Router Class Initialized
INFO - 2021-04-28 03:00:56 --> Output Class Initialized
INFO - 2021-04-28 03:00:56 --> Security Class Initialized
DEBUG - 2021-04-28 03:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:00:56 --> Input Class Initialized
INFO - 2021-04-28 03:00:56 --> Language Class Initialized
INFO - 2021-04-28 03:00:56 --> Language Class Initialized
INFO - 2021-04-28 03:00:56 --> Config Class Initialized
INFO - 2021-04-28 03:00:56 --> Loader Class Initialized
INFO - 2021-04-28 03:00:56 --> Helper loaded: url_helper
INFO - 2021-04-28 03:00:56 --> Helper loaded: file_helper
INFO - 2021-04-28 03:00:56 --> Helper loaded: form_helper
INFO - 2021-04-28 03:00:56 --> Helper loaded: my_helper
INFO - 2021-04-28 03:00:56 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:00:56 --> Controller Class Initialized
INFO - 2021-04-28 03:00:59 --> Config Class Initialized
INFO - 2021-04-28 03:00:59 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:00:59 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:00:59 --> Utf8 Class Initialized
INFO - 2021-04-28 03:00:59 --> URI Class Initialized
INFO - 2021-04-28 03:00:59 --> Router Class Initialized
INFO - 2021-04-28 03:00:59 --> Output Class Initialized
INFO - 2021-04-28 03:00:59 --> Security Class Initialized
DEBUG - 2021-04-28 03:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:00:59 --> Input Class Initialized
INFO - 2021-04-28 03:00:59 --> Language Class Initialized
INFO - 2021-04-28 03:00:59 --> Language Class Initialized
INFO - 2021-04-28 03:00:59 --> Config Class Initialized
INFO - 2021-04-28 03:00:59 --> Loader Class Initialized
INFO - 2021-04-28 03:00:59 --> Helper loaded: url_helper
INFO - 2021-04-28 03:00:59 --> Helper loaded: file_helper
INFO - 2021-04-28 03:00:59 --> Helper loaded: form_helper
INFO - 2021-04-28 03:00:59 --> Helper loaded: my_helper
INFO - 2021-04-28 03:00:59 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:00:59 --> Controller Class Initialized
DEBUG - 2021-04-28 03:00:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-28 03:00:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:00:59 --> Final output sent to browser
DEBUG - 2021-04-28 03:00:59 --> Total execution time: 0.0912
INFO - 2021-04-28 03:00:59 --> Config Class Initialized
INFO - 2021-04-28 03:00:59 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:00:59 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:00:59 --> Utf8 Class Initialized
INFO - 2021-04-28 03:00:59 --> URI Class Initialized
INFO - 2021-04-28 03:00:59 --> Router Class Initialized
INFO - 2021-04-28 03:00:59 --> Output Class Initialized
INFO - 2021-04-28 03:00:59 --> Security Class Initialized
DEBUG - 2021-04-28 03:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:00:59 --> Input Class Initialized
INFO - 2021-04-28 03:00:59 --> Language Class Initialized
INFO - 2021-04-28 03:00:59 --> Language Class Initialized
INFO - 2021-04-28 03:00:59 --> Config Class Initialized
INFO - 2021-04-28 03:00:59 --> Loader Class Initialized
INFO - 2021-04-28 03:00:59 --> Helper loaded: url_helper
INFO - 2021-04-28 03:00:59 --> Helper loaded: file_helper
INFO - 2021-04-28 03:00:59 --> Helper loaded: form_helper
INFO - 2021-04-28 03:00:59 --> Helper loaded: my_helper
INFO - 2021-04-28 03:00:59 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:00 --> Controller Class Initialized
INFO - 2021-04-28 03:01:01 --> Config Class Initialized
INFO - 2021-04-28 03:01:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:01 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:01 --> URI Class Initialized
INFO - 2021-04-28 03:01:01 --> Router Class Initialized
INFO - 2021-04-28 03:01:01 --> Output Class Initialized
INFO - 2021-04-28 03:01:01 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:01 --> Input Class Initialized
INFO - 2021-04-28 03:01:01 --> Language Class Initialized
INFO - 2021-04-28 03:01:01 --> Language Class Initialized
INFO - 2021-04-28 03:01:01 --> Config Class Initialized
INFO - 2021-04-28 03:01:01 --> Loader Class Initialized
INFO - 2021-04-28 03:01:01 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:01 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:01 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:01 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:01 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:01 --> Controller Class Initialized
INFO - 2021-04-28 03:01:01 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:01 --> Total execution time: 0.0622
INFO - 2021-04-28 03:01:10 --> Config Class Initialized
INFO - 2021-04-28 03:01:10 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:10 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:10 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:10 --> URI Class Initialized
INFO - 2021-04-28 03:01:10 --> Router Class Initialized
INFO - 2021-04-28 03:01:10 --> Output Class Initialized
INFO - 2021-04-28 03:01:10 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:10 --> Input Class Initialized
INFO - 2021-04-28 03:01:10 --> Language Class Initialized
INFO - 2021-04-28 03:01:10 --> Language Class Initialized
INFO - 2021-04-28 03:01:10 --> Config Class Initialized
INFO - 2021-04-28 03:01:10 --> Loader Class Initialized
INFO - 2021-04-28 03:01:10 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:10 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:10 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:10 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:10 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:10 --> Controller Class Initialized
INFO - 2021-04-28 03:01:10 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:10 --> Total execution time: 0.0641
INFO - 2021-04-28 03:01:10 --> Config Class Initialized
INFO - 2021-04-28 03:01:10 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:10 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:10 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:10 --> URI Class Initialized
INFO - 2021-04-28 03:01:10 --> Router Class Initialized
INFO - 2021-04-28 03:01:10 --> Output Class Initialized
INFO - 2021-04-28 03:01:10 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:10 --> Input Class Initialized
INFO - 2021-04-28 03:01:10 --> Language Class Initialized
INFO - 2021-04-28 03:01:10 --> Language Class Initialized
INFO - 2021-04-28 03:01:10 --> Config Class Initialized
INFO - 2021-04-28 03:01:10 --> Loader Class Initialized
INFO - 2021-04-28 03:01:10 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:10 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:10 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:10 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:10 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:10 --> Controller Class Initialized
INFO - 2021-04-28 03:01:12 --> Config Class Initialized
INFO - 2021-04-28 03:01:12 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:12 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:12 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:12 --> URI Class Initialized
INFO - 2021-04-28 03:01:12 --> Router Class Initialized
INFO - 2021-04-28 03:01:12 --> Output Class Initialized
INFO - 2021-04-28 03:01:12 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:12 --> Input Class Initialized
INFO - 2021-04-28 03:01:12 --> Language Class Initialized
INFO - 2021-04-28 03:01:12 --> Language Class Initialized
INFO - 2021-04-28 03:01:12 --> Config Class Initialized
INFO - 2021-04-28 03:01:12 --> Loader Class Initialized
INFO - 2021-04-28 03:01:12 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:12 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:12 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:12 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:12 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:12 --> Controller Class Initialized
DEBUG - 2021-04-28 03:01:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-28 03:01:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:01:12 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:12 --> Total execution time: 0.0627
INFO - 2021-04-28 03:01:13 --> Config Class Initialized
INFO - 2021-04-28 03:01:13 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:13 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:13 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:13 --> URI Class Initialized
INFO - 2021-04-28 03:01:13 --> Router Class Initialized
INFO - 2021-04-28 03:01:13 --> Output Class Initialized
INFO - 2021-04-28 03:01:13 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:13 --> Input Class Initialized
INFO - 2021-04-28 03:01:13 --> Language Class Initialized
INFO - 2021-04-28 03:01:13 --> Language Class Initialized
INFO - 2021-04-28 03:01:13 --> Config Class Initialized
INFO - 2021-04-28 03:01:13 --> Loader Class Initialized
INFO - 2021-04-28 03:01:13 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:13 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:13 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:13 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:13 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:13 --> Controller Class Initialized
INFO - 2021-04-28 03:01:14 --> Config Class Initialized
INFO - 2021-04-28 03:01:14 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:14 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:14 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:14 --> URI Class Initialized
INFO - 2021-04-28 03:01:14 --> Router Class Initialized
INFO - 2021-04-28 03:01:14 --> Output Class Initialized
INFO - 2021-04-28 03:01:14 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:14 --> Input Class Initialized
INFO - 2021-04-28 03:01:14 --> Language Class Initialized
INFO - 2021-04-28 03:01:14 --> Language Class Initialized
INFO - 2021-04-28 03:01:14 --> Config Class Initialized
INFO - 2021-04-28 03:01:14 --> Loader Class Initialized
INFO - 2021-04-28 03:01:14 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:14 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:14 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:14 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:14 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:14 --> Controller Class Initialized
DEBUG - 2021-04-28 03:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-04-28 03:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:01:14 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:14 --> Total execution time: 0.0871
INFO - 2021-04-28 03:01:32 --> Config Class Initialized
INFO - 2021-04-28 03:01:32 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:32 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:32 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:32 --> URI Class Initialized
INFO - 2021-04-28 03:01:32 --> Router Class Initialized
INFO - 2021-04-28 03:01:32 --> Output Class Initialized
INFO - 2021-04-28 03:01:32 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:32 --> Input Class Initialized
INFO - 2021-04-28 03:01:32 --> Language Class Initialized
INFO - 2021-04-28 03:01:32 --> Language Class Initialized
INFO - 2021-04-28 03:01:32 --> Config Class Initialized
INFO - 2021-04-28 03:01:32 --> Loader Class Initialized
INFO - 2021-04-28 03:01:32 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:32 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:32 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:32 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:32 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:32 --> Controller Class Initialized
INFO - 2021-04-28 03:01:32 --> Config Class Initialized
INFO - 2021-04-28 03:01:32 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:32 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:32 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:32 --> URI Class Initialized
INFO - 2021-04-28 03:01:32 --> Router Class Initialized
INFO - 2021-04-28 03:01:32 --> Output Class Initialized
INFO - 2021-04-28 03:01:32 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:32 --> Input Class Initialized
INFO - 2021-04-28 03:01:32 --> Language Class Initialized
INFO - 2021-04-28 03:01:32 --> Language Class Initialized
INFO - 2021-04-28 03:01:32 --> Config Class Initialized
INFO - 2021-04-28 03:01:32 --> Loader Class Initialized
INFO - 2021-04-28 03:01:32 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:32 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:32 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:32 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:32 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:32 --> Controller Class Initialized
DEBUG - 2021-04-28 03:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-28 03:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:01:32 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:32 --> Total execution time: 0.0697
INFO - 2021-04-28 03:01:32 --> Config Class Initialized
INFO - 2021-04-28 03:01:32 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:32 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:32 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:32 --> URI Class Initialized
INFO - 2021-04-28 03:01:32 --> Router Class Initialized
INFO - 2021-04-28 03:01:32 --> Output Class Initialized
INFO - 2021-04-28 03:01:32 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:32 --> Input Class Initialized
INFO - 2021-04-28 03:01:32 --> Language Class Initialized
INFO - 2021-04-28 03:01:32 --> Language Class Initialized
INFO - 2021-04-28 03:01:32 --> Config Class Initialized
INFO - 2021-04-28 03:01:32 --> Loader Class Initialized
INFO - 2021-04-28 03:01:32 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:32 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:32 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:32 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:32 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:32 --> Controller Class Initialized
INFO - 2021-04-28 03:01:35 --> Config Class Initialized
INFO - 2021-04-28 03:01:35 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:35 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:35 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:35 --> URI Class Initialized
INFO - 2021-04-28 03:01:35 --> Router Class Initialized
INFO - 2021-04-28 03:01:35 --> Output Class Initialized
INFO - 2021-04-28 03:01:35 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:35 --> Input Class Initialized
INFO - 2021-04-28 03:01:35 --> Language Class Initialized
INFO - 2021-04-28 03:01:35 --> Language Class Initialized
INFO - 2021-04-28 03:01:35 --> Config Class Initialized
INFO - 2021-04-28 03:01:35 --> Loader Class Initialized
INFO - 2021-04-28 03:01:35 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:35 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:35 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:35 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:35 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:35 --> Controller Class Initialized
DEBUG - 2021-04-28 03:01:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 03:01:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:01:35 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:35 --> Total execution time: 0.0768
INFO - 2021-04-28 03:01:36 --> Config Class Initialized
INFO - 2021-04-28 03:01:36 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:36 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:36 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:36 --> URI Class Initialized
INFO - 2021-04-28 03:01:36 --> Router Class Initialized
INFO - 2021-04-28 03:01:36 --> Output Class Initialized
INFO - 2021-04-28 03:01:36 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:36 --> Input Class Initialized
INFO - 2021-04-28 03:01:36 --> Language Class Initialized
INFO - 2021-04-28 03:01:36 --> Language Class Initialized
INFO - 2021-04-28 03:01:36 --> Config Class Initialized
INFO - 2021-04-28 03:01:36 --> Loader Class Initialized
INFO - 2021-04-28 03:01:36 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:36 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:36 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:36 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:36 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:36 --> Controller Class Initialized
DEBUG - 2021-04-28 03:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 03:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:01:36 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:36 --> Total execution time: 0.0582
INFO - 2021-04-28 03:01:40 --> Config Class Initialized
INFO - 2021-04-28 03:01:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:40 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:40 --> URI Class Initialized
INFO - 2021-04-28 03:01:40 --> Router Class Initialized
INFO - 2021-04-28 03:01:40 --> Output Class Initialized
INFO - 2021-04-28 03:01:40 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:40 --> Input Class Initialized
INFO - 2021-04-28 03:01:40 --> Language Class Initialized
INFO - 2021-04-28 03:01:40 --> Language Class Initialized
INFO - 2021-04-28 03:01:40 --> Config Class Initialized
INFO - 2021-04-28 03:01:40 --> Loader Class Initialized
INFO - 2021-04-28 03:01:40 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:40 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:40 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:40 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:40 --> Controller Class Initialized
INFO - 2021-04-28 03:01:40 --> Config Class Initialized
INFO - 2021-04-28 03:01:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:40 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:40 --> URI Class Initialized
INFO - 2021-04-28 03:01:40 --> Router Class Initialized
INFO - 2021-04-28 03:01:40 --> Output Class Initialized
INFO - 2021-04-28 03:01:40 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:40 --> Input Class Initialized
INFO - 2021-04-28 03:01:40 --> Language Class Initialized
INFO - 2021-04-28 03:01:40 --> Language Class Initialized
INFO - 2021-04-28 03:01:40 --> Config Class Initialized
INFO - 2021-04-28 03:01:40 --> Loader Class Initialized
INFO - 2021-04-28 03:01:40 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:40 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:40 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:40 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:40 --> Controller Class Initialized
DEBUG - 2021-04-28 03:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 03:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:01:40 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:40 --> Total execution time: 0.0514
INFO - 2021-04-28 03:01:43 --> Config Class Initialized
INFO - 2021-04-28 03:01:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:43 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:43 --> URI Class Initialized
INFO - 2021-04-28 03:01:43 --> Router Class Initialized
INFO - 2021-04-28 03:01:43 --> Output Class Initialized
INFO - 2021-04-28 03:01:43 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:43 --> Input Class Initialized
INFO - 2021-04-28 03:01:43 --> Language Class Initialized
INFO - 2021-04-28 03:01:43 --> Language Class Initialized
INFO - 2021-04-28 03:01:43 --> Config Class Initialized
INFO - 2021-04-28 03:01:43 --> Loader Class Initialized
INFO - 2021-04-28 03:01:43 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:43 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:43 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:43 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:43 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:43 --> Controller Class Initialized
INFO - 2021-04-28 03:01:43 --> Helper loaded: cookie_helper
INFO - 2021-04-28 03:01:43 --> Config Class Initialized
INFO - 2021-04-28 03:01:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:43 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:43 --> URI Class Initialized
INFO - 2021-04-28 03:01:43 --> Router Class Initialized
INFO - 2021-04-28 03:01:43 --> Output Class Initialized
INFO - 2021-04-28 03:01:43 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:43 --> Input Class Initialized
INFO - 2021-04-28 03:01:43 --> Language Class Initialized
INFO - 2021-04-28 03:01:43 --> Language Class Initialized
INFO - 2021-04-28 03:01:43 --> Config Class Initialized
INFO - 2021-04-28 03:01:43 --> Loader Class Initialized
INFO - 2021-04-28 03:01:43 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:43 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:43 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:43 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:43 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:43 --> Controller Class Initialized
DEBUG - 2021-04-28 03:01:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 03:01:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:01:43 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:43 --> Total execution time: 0.0656
INFO - 2021-04-28 03:01:49 --> Config Class Initialized
INFO - 2021-04-28 03:01:49 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:49 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:49 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:49 --> URI Class Initialized
INFO - 2021-04-28 03:01:49 --> Router Class Initialized
INFO - 2021-04-28 03:01:49 --> Output Class Initialized
INFO - 2021-04-28 03:01:49 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:49 --> Input Class Initialized
INFO - 2021-04-28 03:01:49 --> Language Class Initialized
INFO - 2021-04-28 03:01:49 --> Language Class Initialized
INFO - 2021-04-28 03:01:49 --> Config Class Initialized
INFO - 2021-04-28 03:01:49 --> Loader Class Initialized
INFO - 2021-04-28 03:01:49 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:49 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:49 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:49 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:49 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:49 --> Controller Class Initialized
INFO - 2021-04-28 03:01:49 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:49 --> Total execution time: 0.0716
INFO - 2021-04-28 03:01:54 --> Config Class Initialized
INFO - 2021-04-28 03:01:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:54 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:54 --> URI Class Initialized
INFO - 2021-04-28 03:01:54 --> Router Class Initialized
INFO - 2021-04-28 03:01:54 --> Output Class Initialized
INFO - 2021-04-28 03:01:54 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:54 --> Input Class Initialized
INFO - 2021-04-28 03:01:54 --> Language Class Initialized
INFO - 2021-04-28 03:01:54 --> Language Class Initialized
INFO - 2021-04-28 03:01:54 --> Config Class Initialized
INFO - 2021-04-28 03:01:54 --> Loader Class Initialized
INFO - 2021-04-28 03:01:54 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:54 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:54 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:54 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:54 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:54 --> Controller Class Initialized
INFO - 2021-04-28 03:01:54 --> Helper loaded: cookie_helper
INFO - 2021-04-28 03:01:54 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:54 --> Total execution time: 0.0941
INFO - 2021-04-28 03:01:55 --> Config Class Initialized
INFO - 2021-04-28 03:01:55 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:01:55 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:01:55 --> Utf8 Class Initialized
INFO - 2021-04-28 03:01:55 --> URI Class Initialized
INFO - 2021-04-28 03:01:55 --> Router Class Initialized
INFO - 2021-04-28 03:01:55 --> Output Class Initialized
INFO - 2021-04-28 03:01:55 --> Security Class Initialized
DEBUG - 2021-04-28 03:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:01:55 --> Input Class Initialized
INFO - 2021-04-28 03:01:55 --> Language Class Initialized
INFO - 2021-04-28 03:01:55 --> Language Class Initialized
INFO - 2021-04-28 03:01:55 --> Config Class Initialized
INFO - 2021-04-28 03:01:55 --> Loader Class Initialized
INFO - 2021-04-28 03:01:55 --> Helper loaded: url_helper
INFO - 2021-04-28 03:01:55 --> Helper loaded: file_helper
INFO - 2021-04-28 03:01:55 --> Helper loaded: form_helper
INFO - 2021-04-28 03:01:55 --> Helper loaded: my_helper
INFO - 2021-04-28 03:01:55 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:01:55 --> Controller Class Initialized
DEBUG - 2021-04-28 03:01:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 03:01:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:01:55 --> Final output sent to browser
DEBUG - 2021-04-28 03:01:55 --> Total execution time: 0.0864
INFO - 2021-04-28 03:02:00 --> Config Class Initialized
INFO - 2021-04-28 03:02:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:02:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:02:00 --> Utf8 Class Initialized
INFO - 2021-04-28 03:02:00 --> URI Class Initialized
INFO - 2021-04-28 03:02:00 --> Router Class Initialized
INFO - 2021-04-28 03:02:00 --> Output Class Initialized
INFO - 2021-04-28 03:02:00 --> Security Class Initialized
DEBUG - 2021-04-28 03:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:02:00 --> Input Class Initialized
INFO - 2021-04-28 03:02:00 --> Language Class Initialized
INFO - 2021-04-28 03:02:00 --> Language Class Initialized
INFO - 2021-04-28 03:02:00 --> Config Class Initialized
INFO - 2021-04-28 03:02:00 --> Loader Class Initialized
INFO - 2021-04-28 03:02:00 --> Helper loaded: url_helper
INFO - 2021-04-28 03:02:00 --> Helper loaded: file_helper
INFO - 2021-04-28 03:02:00 --> Helper loaded: form_helper
INFO - 2021-04-28 03:02:00 --> Helper loaded: my_helper
INFO - 2021-04-28 03:02:00 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:02:00 --> Controller Class Initialized
DEBUG - 2021-04-28 03:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-04-28 03:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:02:00 --> Final output sent to browser
DEBUG - 2021-04-28 03:02:00 --> Total execution time: 0.0872
INFO - 2021-04-28 03:02:10 --> Config Class Initialized
INFO - 2021-04-28 03:02:10 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:02:10 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:02:10 --> Utf8 Class Initialized
INFO - 2021-04-28 03:02:10 --> URI Class Initialized
INFO - 2021-04-28 03:02:10 --> Router Class Initialized
INFO - 2021-04-28 03:02:10 --> Output Class Initialized
INFO - 2021-04-28 03:02:10 --> Security Class Initialized
DEBUG - 2021-04-28 03:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:02:10 --> Input Class Initialized
INFO - 2021-04-28 03:02:10 --> Language Class Initialized
INFO - 2021-04-28 03:02:10 --> Language Class Initialized
INFO - 2021-04-28 03:02:10 --> Config Class Initialized
INFO - 2021-04-28 03:02:10 --> Loader Class Initialized
INFO - 2021-04-28 03:02:10 --> Helper loaded: url_helper
INFO - 2021-04-28 03:02:10 --> Helper loaded: file_helper
INFO - 2021-04-28 03:02:10 --> Helper loaded: form_helper
INFO - 2021-04-28 03:02:10 --> Helper loaded: my_helper
INFO - 2021-04-28 03:02:10 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:02:10 --> Controller Class Initialized
DEBUG - 2021-04-28 03:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-04-28 03:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:02:10 --> Final output sent to browser
DEBUG - 2021-04-28 03:02:10 --> Total execution time: 0.0589
INFO - 2021-04-28 03:02:13 --> Config Class Initialized
INFO - 2021-04-28 03:02:13 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:02:13 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:02:13 --> Utf8 Class Initialized
INFO - 2021-04-28 03:02:13 --> URI Class Initialized
INFO - 2021-04-28 03:02:13 --> Router Class Initialized
INFO - 2021-04-28 03:02:13 --> Output Class Initialized
INFO - 2021-04-28 03:02:13 --> Security Class Initialized
DEBUG - 2021-04-28 03:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:02:13 --> Input Class Initialized
INFO - 2021-04-28 03:02:13 --> Language Class Initialized
INFO - 2021-04-28 03:02:13 --> Language Class Initialized
INFO - 2021-04-28 03:02:13 --> Config Class Initialized
INFO - 2021-04-28 03:02:13 --> Loader Class Initialized
INFO - 2021-04-28 03:02:13 --> Helper loaded: url_helper
INFO - 2021-04-28 03:02:13 --> Helper loaded: file_helper
INFO - 2021-04-28 03:02:13 --> Helper loaded: form_helper
INFO - 2021-04-28 03:02:13 --> Helper loaded: my_helper
INFO - 2021-04-28 03:02:13 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:02:13 --> Controller Class Initialized
DEBUG - 2021-04-28 03:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-04-28 03:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:02:13 --> Final output sent to browser
DEBUG - 2021-04-28 03:02:13 --> Total execution time: 0.0746
INFO - 2021-04-28 03:05:51 --> Config Class Initialized
INFO - 2021-04-28 03:05:51 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:05:51 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:05:51 --> Utf8 Class Initialized
INFO - 2021-04-28 03:05:51 --> URI Class Initialized
INFO - 2021-04-28 03:05:51 --> Router Class Initialized
INFO - 2021-04-28 03:05:51 --> Output Class Initialized
INFO - 2021-04-28 03:05:51 --> Security Class Initialized
DEBUG - 2021-04-28 03:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:05:51 --> Input Class Initialized
INFO - 2021-04-28 03:05:51 --> Language Class Initialized
INFO - 2021-04-28 03:05:51 --> Language Class Initialized
INFO - 2021-04-28 03:05:51 --> Config Class Initialized
INFO - 2021-04-28 03:05:51 --> Loader Class Initialized
INFO - 2021-04-28 03:05:51 --> Helper loaded: url_helper
INFO - 2021-04-28 03:05:51 --> Helper loaded: file_helper
INFO - 2021-04-28 03:05:51 --> Helper loaded: form_helper
INFO - 2021-04-28 03:05:51 --> Helper loaded: my_helper
INFO - 2021-04-28 03:05:51 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:05:51 --> Controller Class Initialized
DEBUG - 2021-04-28 03:05:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-04-28 03:05:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:05:51 --> Final output sent to browser
DEBUG - 2021-04-28 03:05:51 --> Total execution time: 0.0610
INFO - 2021-04-28 03:05:52 --> Config Class Initialized
INFO - 2021-04-28 03:05:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:05:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:05:52 --> Utf8 Class Initialized
INFO - 2021-04-28 03:05:52 --> URI Class Initialized
INFO - 2021-04-28 03:05:52 --> Router Class Initialized
INFO - 2021-04-28 03:05:52 --> Output Class Initialized
INFO - 2021-04-28 03:05:52 --> Security Class Initialized
DEBUG - 2021-04-28 03:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:05:52 --> Input Class Initialized
INFO - 2021-04-28 03:05:52 --> Language Class Initialized
INFO - 2021-04-28 03:05:52 --> Language Class Initialized
INFO - 2021-04-28 03:05:52 --> Config Class Initialized
INFO - 2021-04-28 03:05:52 --> Loader Class Initialized
INFO - 2021-04-28 03:05:52 --> Helper loaded: url_helper
INFO - 2021-04-28 03:05:52 --> Helper loaded: file_helper
INFO - 2021-04-28 03:05:52 --> Helper loaded: form_helper
INFO - 2021-04-28 03:05:52 --> Helper loaded: my_helper
INFO - 2021-04-28 03:05:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:05:52 --> Controller Class Initialized
INFO - 2021-04-28 03:05:52 --> Helper loaded: cookie_helper
INFO - 2021-04-28 03:05:52 --> Config Class Initialized
INFO - 2021-04-28 03:05:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:05:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:05:52 --> Utf8 Class Initialized
INFO - 2021-04-28 03:05:52 --> URI Class Initialized
INFO - 2021-04-28 03:05:52 --> Router Class Initialized
INFO - 2021-04-28 03:05:52 --> Output Class Initialized
INFO - 2021-04-28 03:05:52 --> Security Class Initialized
DEBUG - 2021-04-28 03:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:05:52 --> Input Class Initialized
INFO - 2021-04-28 03:05:52 --> Language Class Initialized
INFO - 2021-04-28 03:05:52 --> Language Class Initialized
INFO - 2021-04-28 03:05:52 --> Config Class Initialized
INFO - 2021-04-28 03:05:52 --> Loader Class Initialized
INFO - 2021-04-28 03:05:52 --> Helper loaded: url_helper
INFO - 2021-04-28 03:05:52 --> Helper loaded: file_helper
INFO - 2021-04-28 03:05:52 --> Helper loaded: form_helper
INFO - 2021-04-28 03:05:52 --> Helper loaded: my_helper
INFO - 2021-04-28 03:05:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:05:52 --> Controller Class Initialized
DEBUG - 2021-04-28 03:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 03:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:05:52 --> Final output sent to browser
DEBUG - 2021-04-28 03:05:52 --> Total execution time: 0.0482
INFO - 2021-04-28 03:05:58 --> Config Class Initialized
INFO - 2021-04-28 03:05:58 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:05:58 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:05:58 --> Utf8 Class Initialized
INFO - 2021-04-28 03:05:58 --> URI Class Initialized
INFO - 2021-04-28 03:05:58 --> Router Class Initialized
INFO - 2021-04-28 03:05:58 --> Output Class Initialized
INFO - 2021-04-28 03:05:58 --> Security Class Initialized
DEBUG - 2021-04-28 03:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:05:58 --> Input Class Initialized
INFO - 2021-04-28 03:05:58 --> Language Class Initialized
INFO - 2021-04-28 03:05:58 --> Language Class Initialized
INFO - 2021-04-28 03:05:58 --> Config Class Initialized
INFO - 2021-04-28 03:05:58 --> Loader Class Initialized
INFO - 2021-04-28 03:05:58 --> Helper loaded: url_helper
INFO - 2021-04-28 03:05:58 --> Helper loaded: file_helper
INFO - 2021-04-28 03:05:58 --> Helper loaded: form_helper
INFO - 2021-04-28 03:05:58 --> Helper loaded: my_helper
INFO - 2021-04-28 03:05:58 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:05:58 --> Controller Class Initialized
INFO - 2021-04-28 03:05:58 --> Helper loaded: cookie_helper
INFO - 2021-04-28 03:05:58 --> Final output sent to browser
DEBUG - 2021-04-28 03:05:58 --> Total execution time: 0.0816
INFO - 2021-04-28 03:06:00 --> Config Class Initialized
INFO - 2021-04-28 03:06:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:06:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:06:00 --> Utf8 Class Initialized
INFO - 2021-04-28 03:06:00 --> URI Class Initialized
INFO - 2021-04-28 03:06:00 --> Router Class Initialized
INFO - 2021-04-28 03:06:00 --> Output Class Initialized
INFO - 2021-04-28 03:06:00 --> Security Class Initialized
DEBUG - 2021-04-28 03:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:06:00 --> Input Class Initialized
INFO - 2021-04-28 03:06:00 --> Language Class Initialized
INFO - 2021-04-28 03:06:00 --> Language Class Initialized
INFO - 2021-04-28 03:06:00 --> Config Class Initialized
INFO - 2021-04-28 03:06:00 --> Loader Class Initialized
INFO - 2021-04-28 03:06:00 --> Helper loaded: url_helper
INFO - 2021-04-28 03:06:00 --> Helper loaded: file_helper
INFO - 2021-04-28 03:06:00 --> Helper loaded: form_helper
INFO - 2021-04-28 03:06:00 --> Helper loaded: my_helper
INFO - 2021-04-28 03:06:00 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:06:00 --> Controller Class Initialized
DEBUG - 2021-04-28 03:06:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 03:06:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:06:00 --> Final output sent to browser
DEBUG - 2021-04-28 03:06:00 --> Total execution time: 0.0864
INFO - 2021-04-28 03:06:01 --> Config Class Initialized
INFO - 2021-04-28 03:06:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:06:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:06:01 --> Utf8 Class Initialized
INFO - 2021-04-28 03:06:01 --> URI Class Initialized
INFO - 2021-04-28 03:06:01 --> Router Class Initialized
INFO - 2021-04-28 03:06:01 --> Output Class Initialized
INFO - 2021-04-28 03:06:01 --> Security Class Initialized
DEBUG - 2021-04-28 03:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:06:01 --> Input Class Initialized
INFO - 2021-04-28 03:06:01 --> Language Class Initialized
INFO - 2021-04-28 03:06:01 --> Language Class Initialized
INFO - 2021-04-28 03:06:01 --> Config Class Initialized
INFO - 2021-04-28 03:06:01 --> Loader Class Initialized
INFO - 2021-04-28 03:06:01 --> Helper loaded: url_helper
INFO - 2021-04-28 03:06:01 --> Helper loaded: file_helper
INFO - 2021-04-28 03:06:01 --> Helper loaded: form_helper
INFO - 2021-04-28 03:06:01 --> Helper loaded: my_helper
INFO - 2021-04-28 03:06:01 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:06:01 --> Controller Class Initialized
DEBUG - 2021-04-28 03:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 03:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:06:01 --> Final output sent to browser
DEBUG - 2021-04-28 03:06:01 --> Total execution time: 0.0761
INFO - 2021-04-28 03:06:09 --> Config Class Initialized
INFO - 2021-04-28 03:06:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:06:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:06:09 --> Utf8 Class Initialized
INFO - 2021-04-28 03:06:09 --> URI Class Initialized
INFO - 2021-04-28 03:06:09 --> Router Class Initialized
INFO - 2021-04-28 03:06:09 --> Output Class Initialized
INFO - 2021-04-28 03:06:09 --> Security Class Initialized
DEBUG - 2021-04-28 03:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:06:09 --> Input Class Initialized
INFO - 2021-04-28 03:06:09 --> Language Class Initialized
INFO - 2021-04-28 03:06:09 --> Language Class Initialized
INFO - 2021-04-28 03:06:09 --> Config Class Initialized
INFO - 2021-04-28 03:06:09 --> Loader Class Initialized
INFO - 2021-04-28 03:06:09 --> Helper loaded: url_helper
INFO - 2021-04-28 03:06:09 --> Helper loaded: file_helper
INFO - 2021-04-28 03:06:09 --> Helper loaded: form_helper
INFO - 2021-04-28 03:06:09 --> Helper loaded: my_helper
INFO - 2021-04-28 03:06:09 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:06:10 --> Controller Class Initialized
DEBUG - 2021-04-28 03:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 03:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:06:10 --> Final output sent to browser
DEBUG - 2021-04-28 03:06:10 --> Total execution time: 0.0532
INFO - 2021-04-28 03:06:11 --> Config Class Initialized
INFO - 2021-04-28 03:06:11 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:06:11 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:06:11 --> Utf8 Class Initialized
INFO - 2021-04-28 03:06:11 --> URI Class Initialized
INFO - 2021-04-28 03:06:11 --> Router Class Initialized
INFO - 2021-04-28 03:06:11 --> Output Class Initialized
INFO - 2021-04-28 03:06:11 --> Security Class Initialized
DEBUG - 2021-04-28 03:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:06:11 --> Input Class Initialized
INFO - 2021-04-28 03:06:11 --> Language Class Initialized
INFO - 2021-04-28 03:06:11 --> Language Class Initialized
INFO - 2021-04-28 03:06:11 --> Config Class Initialized
INFO - 2021-04-28 03:06:11 --> Loader Class Initialized
INFO - 2021-04-28 03:06:11 --> Helper loaded: url_helper
INFO - 2021-04-28 03:06:11 --> Helper loaded: file_helper
INFO - 2021-04-28 03:06:11 --> Helper loaded: form_helper
INFO - 2021-04-28 03:06:11 --> Helper loaded: my_helper
INFO - 2021-04-28 03:06:11 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:06:11 --> Controller Class Initialized
DEBUG - 2021-04-28 03:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 03:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:06:11 --> Final output sent to browser
DEBUG - 2021-04-28 03:06:11 --> Total execution time: 0.0714
INFO - 2021-04-28 03:06:16 --> Config Class Initialized
INFO - 2021-04-28 03:06:16 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:06:16 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:06:16 --> Utf8 Class Initialized
INFO - 2021-04-28 03:06:16 --> URI Class Initialized
INFO - 2021-04-28 03:06:16 --> Router Class Initialized
INFO - 2021-04-28 03:06:16 --> Output Class Initialized
INFO - 2021-04-28 03:06:16 --> Security Class Initialized
DEBUG - 2021-04-28 03:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:06:16 --> Input Class Initialized
INFO - 2021-04-28 03:06:16 --> Language Class Initialized
INFO - 2021-04-28 03:06:16 --> Language Class Initialized
INFO - 2021-04-28 03:06:16 --> Config Class Initialized
INFO - 2021-04-28 03:06:16 --> Loader Class Initialized
INFO - 2021-04-28 03:06:16 --> Helper loaded: url_helper
INFO - 2021-04-28 03:06:16 --> Helper loaded: file_helper
INFO - 2021-04-28 03:06:16 --> Helper loaded: form_helper
INFO - 2021-04-28 03:06:16 --> Helper loaded: my_helper
INFO - 2021-04-28 03:06:16 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:06:16 --> Controller Class Initialized
INFO - 2021-04-28 03:06:16 --> Config Class Initialized
INFO - 2021-04-28 03:06:16 --> Hooks Class Initialized
DEBUG - 2021-04-28 03:06:16 --> UTF-8 Support Enabled
INFO - 2021-04-28 03:06:16 --> Utf8 Class Initialized
INFO - 2021-04-28 03:06:16 --> URI Class Initialized
INFO - 2021-04-28 03:06:16 --> Router Class Initialized
INFO - 2021-04-28 03:06:16 --> Output Class Initialized
INFO - 2021-04-28 03:06:16 --> Security Class Initialized
DEBUG - 2021-04-28 03:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 03:06:16 --> Input Class Initialized
INFO - 2021-04-28 03:06:16 --> Language Class Initialized
INFO - 2021-04-28 03:06:16 --> Language Class Initialized
INFO - 2021-04-28 03:06:16 --> Config Class Initialized
INFO - 2021-04-28 03:06:16 --> Loader Class Initialized
INFO - 2021-04-28 03:06:16 --> Helper loaded: url_helper
INFO - 2021-04-28 03:06:16 --> Helper loaded: file_helper
INFO - 2021-04-28 03:06:16 --> Helper loaded: form_helper
INFO - 2021-04-28 03:06:16 --> Helper loaded: my_helper
INFO - 2021-04-28 03:06:16 --> Database Driver Class Initialized
DEBUG - 2021-04-28 03:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 03:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 03:06:16 --> Controller Class Initialized
DEBUG - 2021-04-28 03:06:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 03:06:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 03:06:16 --> Final output sent to browser
DEBUG - 2021-04-28 03:06:16 --> Total execution time: 0.0587
INFO - 2021-04-28 05:02:05 --> Config Class Initialized
INFO - 2021-04-28 05:02:05 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:02:05 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:02:05 --> Utf8 Class Initialized
INFO - 2021-04-28 05:02:05 --> URI Class Initialized
INFO - 2021-04-28 05:02:05 --> Router Class Initialized
INFO - 2021-04-28 05:02:05 --> Output Class Initialized
INFO - 2021-04-28 05:02:05 --> Security Class Initialized
DEBUG - 2021-04-28 05:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:02:05 --> Input Class Initialized
INFO - 2021-04-28 05:02:05 --> Language Class Initialized
INFO - 2021-04-28 05:02:05 --> Language Class Initialized
INFO - 2021-04-28 05:02:05 --> Config Class Initialized
INFO - 2021-04-28 05:02:05 --> Loader Class Initialized
INFO - 2021-04-28 05:02:05 --> Helper loaded: url_helper
INFO - 2021-04-28 05:02:05 --> Helper loaded: file_helper
INFO - 2021-04-28 05:02:05 --> Helper loaded: form_helper
INFO - 2021-04-28 05:02:05 --> Helper loaded: my_helper
INFO - 2021-04-28 05:02:05 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:02:05 --> Controller Class Initialized
DEBUG - 2021-04-28 05:02:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:02:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:02:05 --> Final output sent to browser
DEBUG - 2021-04-28 05:02:05 --> Total execution time: 0.1095
INFO - 2021-04-28 05:02:11 --> Config Class Initialized
INFO - 2021-04-28 05:02:11 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:02:11 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:02:11 --> Utf8 Class Initialized
INFO - 2021-04-28 05:02:11 --> URI Class Initialized
INFO - 2021-04-28 05:02:11 --> Router Class Initialized
INFO - 2021-04-28 05:02:11 --> Output Class Initialized
INFO - 2021-04-28 05:02:11 --> Security Class Initialized
DEBUG - 2021-04-28 05:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:02:11 --> Input Class Initialized
INFO - 2021-04-28 05:02:11 --> Language Class Initialized
INFO - 2021-04-28 05:02:11 --> Language Class Initialized
INFO - 2021-04-28 05:02:11 --> Config Class Initialized
INFO - 2021-04-28 05:02:11 --> Loader Class Initialized
INFO - 2021-04-28 05:02:11 --> Helper loaded: url_helper
INFO - 2021-04-28 05:02:11 --> Helper loaded: file_helper
INFO - 2021-04-28 05:02:11 --> Helper loaded: form_helper
INFO - 2021-04-28 05:02:11 --> Helper loaded: my_helper
INFO - 2021-04-28 05:02:11 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:02:11 --> Controller Class Initialized
DEBUG - 2021-04-28 05:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:02:11 --> Final output sent to browser
DEBUG - 2021-04-28 05:02:11 --> Total execution time: 0.0978
INFO - 2021-04-28 05:02:12 --> Config Class Initialized
INFO - 2021-04-28 05:02:12 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:02:12 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:02:12 --> Utf8 Class Initialized
INFO - 2021-04-28 05:02:12 --> URI Class Initialized
INFO - 2021-04-28 05:02:12 --> Router Class Initialized
INFO - 2021-04-28 05:02:12 --> Output Class Initialized
INFO - 2021-04-28 05:02:12 --> Security Class Initialized
DEBUG - 2021-04-28 05:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:02:12 --> Input Class Initialized
INFO - 2021-04-28 05:02:12 --> Language Class Initialized
INFO - 2021-04-28 05:02:12 --> Language Class Initialized
INFO - 2021-04-28 05:02:12 --> Config Class Initialized
INFO - 2021-04-28 05:02:12 --> Loader Class Initialized
INFO - 2021-04-28 05:02:12 --> Helper loaded: url_helper
INFO - 2021-04-28 05:02:12 --> Helper loaded: file_helper
INFO - 2021-04-28 05:02:12 --> Helper loaded: form_helper
INFO - 2021-04-28 05:02:12 --> Helper loaded: my_helper
INFO - 2021-04-28 05:02:12 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:02:12 --> Controller Class Initialized
DEBUG - 2021-04-28 05:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:02:12 --> Final output sent to browser
DEBUG - 2021-04-28 05:02:12 --> Total execution time: 0.1038
INFO - 2021-04-28 05:02:19 --> Config Class Initialized
INFO - 2021-04-28 05:02:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:02:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:02:19 --> Utf8 Class Initialized
INFO - 2021-04-28 05:02:19 --> URI Class Initialized
INFO - 2021-04-28 05:02:19 --> Router Class Initialized
INFO - 2021-04-28 05:02:19 --> Output Class Initialized
INFO - 2021-04-28 05:02:19 --> Security Class Initialized
DEBUG - 2021-04-28 05:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:02:19 --> Input Class Initialized
INFO - 2021-04-28 05:02:19 --> Language Class Initialized
INFO - 2021-04-28 05:02:19 --> Language Class Initialized
INFO - 2021-04-28 05:02:19 --> Config Class Initialized
INFO - 2021-04-28 05:02:19 --> Loader Class Initialized
INFO - 2021-04-28 05:02:19 --> Helper loaded: url_helper
INFO - 2021-04-28 05:02:19 --> Helper loaded: file_helper
INFO - 2021-04-28 05:02:19 --> Helper loaded: form_helper
INFO - 2021-04-28 05:02:19 --> Helper loaded: my_helper
INFO - 2021-04-28 05:02:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:02:19 --> Controller Class Initialized
INFO - 2021-04-28 05:02:19 --> Config Class Initialized
INFO - 2021-04-28 05:02:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:02:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:02:19 --> Utf8 Class Initialized
INFO - 2021-04-28 05:02:19 --> URI Class Initialized
INFO - 2021-04-28 05:02:19 --> Router Class Initialized
INFO - 2021-04-28 05:02:19 --> Output Class Initialized
INFO - 2021-04-28 05:02:19 --> Security Class Initialized
DEBUG - 2021-04-28 05:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:02:19 --> Input Class Initialized
INFO - 2021-04-28 05:02:19 --> Language Class Initialized
INFO - 2021-04-28 05:02:19 --> Language Class Initialized
INFO - 2021-04-28 05:02:19 --> Config Class Initialized
INFO - 2021-04-28 05:02:19 --> Loader Class Initialized
INFO - 2021-04-28 05:02:19 --> Helper loaded: url_helper
INFO - 2021-04-28 05:02:19 --> Helper loaded: file_helper
INFO - 2021-04-28 05:02:19 --> Helper loaded: form_helper
INFO - 2021-04-28 05:02:19 --> Helper loaded: my_helper
INFO - 2021-04-28 05:02:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:02:19 --> Controller Class Initialized
DEBUG - 2021-04-28 05:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:02:19 --> Final output sent to browser
DEBUG - 2021-04-28 05:02:19 --> Total execution time: 0.1217
INFO - 2021-04-28 05:04:29 --> Config Class Initialized
INFO - 2021-04-28 05:04:29 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:04:29 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:04:29 --> Utf8 Class Initialized
INFO - 2021-04-28 05:04:29 --> URI Class Initialized
DEBUG - 2021-04-28 05:04:29 --> No URI present. Default controller set.
INFO - 2021-04-28 05:04:29 --> Router Class Initialized
INFO - 2021-04-28 05:04:29 --> Output Class Initialized
INFO - 2021-04-28 05:04:29 --> Security Class Initialized
DEBUG - 2021-04-28 05:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:04:30 --> Input Class Initialized
INFO - 2021-04-28 05:04:30 --> Language Class Initialized
INFO - 2021-04-28 05:04:30 --> Language Class Initialized
INFO - 2021-04-28 05:04:30 --> Config Class Initialized
INFO - 2021-04-28 05:04:30 --> Loader Class Initialized
INFO - 2021-04-28 05:04:30 --> Helper loaded: url_helper
INFO - 2021-04-28 05:04:30 --> Helper loaded: file_helper
INFO - 2021-04-28 05:04:30 --> Helper loaded: form_helper
INFO - 2021-04-28 05:04:30 --> Helper loaded: my_helper
INFO - 2021-04-28 05:04:30 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:04:30 --> Controller Class Initialized
INFO - 2021-04-28 05:04:30 --> Config Class Initialized
INFO - 2021-04-28 05:04:30 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:04:30 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:04:30 --> Utf8 Class Initialized
INFO - 2021-04-28 05:04:30 --> URI Class Initialized
INFO - 2021-04-28 05:04:30 --> Router Class Initialized
INFO - 2021-04-28 05:04:30 --> Output Class Initialized
INFO - 2021-04-28 05:04:30 --> Security Class Initialized
DEBUG - 2021-04-28 05:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:04:30 --> Input Class Initialized
INFO - 2021-04-28 05:04:30 --> Language Class Initialized
INFO - 2021-04-28 05:04:30 --> Language Class Initialized
INFO - 2021-04-28 05:04:30 --> Config Class Initialized
INFO - 2021-04-28 05:04:30 --> Loader Class Initialized
INFO - 2021-04-28 05:04:30 --> Helper loaded: url_helper
INFO - 2021-04-28 05:04:30 --> Helper loaded: file_helper
INFO - 2021-04-28 05:04:30 --> Helper loaded: form_helper
INFO - 2021-04-28 05:04:30 --> Helper loaded: my_helper
INFO - 2021-04-28 05:04:30 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:04:30 --> Controller Class Initialized
DEBUG - 2021-04-28 05:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 05:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:04:30 --> Final output sent to browser
DEBUG - 2021-04-28 05:04:30 --> Total execution time: 0.1042
INFO - 2021-04-28 05:04:40 --> Config Class Initialized
INFO - 2021-04-28 05:04:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:04:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:04:40 --> Utf8 Class Initialized
INFO - 2021-04-28 05:04:40 --> URI Class Initialized
INFO - 2021-04-28 05:04:40 --> Router Class Initialized
INFO - 2021-04-28 05:04:40 --> Output Class Initialized
INFO - 2021-04-28 05:04:40 --> Security Class Initialized
DEBUG - 2021-04-28 05:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:04:40 --> Input Class Initialized
INFO - 2021-04-28 05:04:40 --> Language Class Initialized
INFO - 2021-04-28 05:04:40 --> Language Class Initialized
INFO - 2021-04-28 05:04:40 --> Config Class Initialized
INFO - 2021-04-28 05:04:40 --> Loader Class Initialized
INFO - 2021-04-28 05:04:40 --> Helper loaded: url_helper
INFO - 2021-04-28 05:04:40 --> Helper loaded: file_helper
INFO - 2021-04-28 05:04:40 --> Helper loaded: form_helper
INFO - 2021-04-28 05:04:40 --> Helper loaded: my_helper
INFO - 2021-04-28 05:04:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:04:40 --> Controller Class Initialized
INFO - 2021-04-28 05:04:40 --> Helper loaded: cookie_helper
INFO - 2021-04-28 05:04:40 --> Final output sent to browser
DEBUG - 2021-04-28 05:04:40 --> Total execution time: 0.1910
INFO - 2021-04-28 05:04:42 --> Config Class Initialized
INFO - 2021-04-28 05:04:42 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:04:42 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:04:42 --> Utf8 Class Initialized
INFO - 2021-04-28 05:04:42 --> URI Class Initialized
INFO - 2021-04-28 05:04:42 --> Router Class Initialized
INFO - 2021-04-28 05:04:42 --> Output Class Initialized
INFO - 2021-04-28 05:04:42 --> Security Class Initialized
DEBUG - 2021-04-28 05:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:04:42 --> Input Class Initialized
INFO - 2021-04-28 05:04:42 --> Language Class Initialized
INFO - 2021-04-28 05:04:42 --> Language Class Initialized
INFO - 2021-04-28 05:04:42 --> Config Class Initialized
INFO - 2021-04-28 05:04:42 --> Loader Class Initialized
INFO - 2021-04-28 05:04:42 --> Helper loaded: url_helper
INFO - 2021-04-28 05:04:42 --> Helper loaded: file_helper
INFO - 2021-04-28 05:04:42 --> Helper loaded: form_helper
INFO - 2021-04-28 05:04:42 --> Helper loaded: my_helper
INFO - 2021-04-28 05:04:42 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:04:42 --> Controller Class Initialized
DEBUG - 2021-04-28 05:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 05:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:04:42 --> Final output sent to browser
DEBUG - 2021-04-28 05:04:42 --> Total execution time: 0.1534
INFO - 2021-04-28 05:10:30 --> Config Class Initialized
INFO - 2021-04-28 05:10:30 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:10:30 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:10:30 --> Utf8 Class Initialized
INFO - 2021-04-28 05:10:30 --> URI Class Initialized
INFO - 2021-04-28 05:10:30 --> Router Class Initialized
INFO - 2021-04-28 05:10:30 --> Output Class Initialized
INFO - 2021-04-28 05:10:30 --> Security Class Initialized
DEBUG - 2021-04-28 05:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:10:30 --> Input Class Initialized
INFO - 2021-04-28 05:10:30 --> Language Class Initialized
INFO - 2021-04-28 05:10:30 --> Language Class Initialized
INFO - 2021-04-28 05:10:30 --> Config Class Initialized
INFO - 2021-04-28 05:10:30 --> Loader Class Initialized
INFO - 2021-04-28 05:10:30 --> Helper loaded: url_helper
INFO - 2021-04-28 05:10:30 --> Helper loaded: file_helper
INFO - 2021-04-28 05:10:30 --> Helper loaded: form_helper
INFO - 2021-04-28 05:10:30 --> Helper loaded: my_helper
INFO - 2021-04-28 05:10:30 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:10:30 --> Controller Class Initialized
DEBUG - 2021-04-28 05:10:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 05:10:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:10:30 --> Final output sent to browser
DEBUG - 2021-04-28 05:10:30 --> Total execution time: 0.1316
INFO - 2021-04-28 05:10:31 --> Config Class Initialized
INFO - 2021-04-28 05:10:31 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:10:31 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:10:31 --> Utf8 Class Initialized
INFO - 2021-04-28 05:10:31 --> URI Class Initialized
INFO - 2021-04-28 05:10:32 --> Router Class Initialized
INFO - 2021-04-28 05:10:32 --> Output Class Initialized
INFO - 2021-04-28 05:10:32 --> Security Class Initialized
DEBUG - 2021-04-28 05:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:10:32 --> Input Class Initialized
INFO - 2021-04-28 05:10:32 --> Language Class Initialized
INFO - 2021-04-28 05:10:32 --> Language Class Initialized
INFO - 2021-04-28 05:10:32 --> Config Class Initialized
INFO - 2021-04-28 05:10:32 --> Loader Class Initialized
INFO - 2021-04-28 05:10:32 --> Helper loaded: url_helper
INFO - 2021-04-28 05:10:32 --> Helper loaded: file_helper
INFO - 2021-04-28 05:10:32 --> Helper loaded: form_helper
INFO - 2021-04-28 05:10:32 --> Helper loaded: my_helper
INFO - 2021-04-28 05:10:32 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:10:32 --> Controller Class Initialized
DEBUG - 2021-04-28 05:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:10:32 --> Final output sent to browser
DEBUG - 2021-04-28 05:10:32 --> Total execution time: 0.1073
INFO - 2021-04-28 05:10:32 --> Config Class Initialized
INFO - 2021-04-28 05:10:32 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:10:32 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:10:32 --> Utf8 Class Initialized
INFO - 2021-04-28 05:10:32 --> URI Class Initialized
INFO - 2021-04-28 05:10:32 --> Router Class Initialized
INFO - 2021-04-28 05:10:32 --> Output Class Initialized
INFO - 2021-04-28 05:10:32 --> Security Class Initialized
DEBUG - 2021-04-28 05:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:10:32 --> Input Class Initialized
INFO - 2021-04-28 05:10:32 --> Language Class Initialized
INFO - 2021-04-28 05:10:32 --> Language Class Initialized
INFO - 2021-04-28 05:10:32 --> Config Class Initialized
INFO - 2021-04-28 05:10:32 --> Loader Class Initialized
INFO - 2021-04-28 05:10:32 --> Helper loaded: url_helper
INFO - 2021-04-28 05:10:32 --> Helper loaded: file_helper
INFO - 2021-04-28 05:10:32 --> Helper loaded: form_helper
INFO - 2021-04-28 05:10:32 --> Helper loaded: my_helper
INFO - 2021-04-28 05:10:32 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:10:32 --> Controller Class Initialized
DEBUG - 2021-04-28 05:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:10:32 --> Final output sent to browser
DEBUG - 2021-04-28 05:10:32 --> Total execution time: 0.1435
INFO - 2021-04-28 05:10:37 --> Config Class Initialized
INFO - 2021-04-28 05:10:37 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:10:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:10:37 --> Utf8 Class Initialized
INFO - 2021-04-28 05:10:37 --> URI Class Initialized
INFO - 2021-04-28 05:10:37 --> Router Class Initialized
INFO - 2021-04-28 05:10:37 --> Output Class Initialized
INFO - 2021-04-28 05:10:37 --> Security Class Initialized
DEBUG - 2021-04-28 05:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:10:37 --> Input Class Initialized
INFO - 2021-04-28 05:10:37 --> Language Class Initialized
INFO - 2021-04-28 05:10:37 --> Language Class Initialized
INFO - 2021-04-28 05:10:37 --> Config Class Initialized
INFO - 2021-04-28 05:10:37 --> Loader Class Initialized
INFO - 2021-04-28 05:10:37 --> Helper loaded: url_helper
INFO - 2021-04-28 05:10:37 --> Helper loaded: file_helper
INFO - 2021-04-28 05:10:37 --> Helper loaded: form_helper
INFO - 2021-04-28 05:10:37 --> Helper loaded: my_helper
INFO - 2021-04-28 05:10:37 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:10:37 --> Controller Class Initialized
INFO - 2021-04-28 05:10:37 --> Config Class Initialized
INFO - 2021-04-28 05:10:37 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:10:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:10:37 --> Utf8 Class Initialized
INFO - 2021-04-28 05:10:37 --> URI Class Initialized
INFO - 2021-04-28 05:10:37 --> Router Class Initialized
INFO - 2021-04-28 05:10:37 --> Output Class Initialized
INFO - 2021-04-28 05:10:37 --> Security Class Initialized
DEBUG - 2021-04-28 05:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:10:37 --> Input Class Initialized
INFO - 2021-04-28 05:10:37 --> Language Class Initialized
INFO - 2021-04-28 05:10:37 --> Language Class Initialized
INFO - 2021-04-28 05:10:37 --> Config Class Initialized
INFO - 2021-04-28 05:10:37 --> Loader Class Initialized
INFO - 2021-04-28 05:10:37 --> Helper loaded: url_helper
INFO - 2021-04-28 05:10:37 --> Helper loaded: file_helper
INFO - 2021-04-28 05:10:37 --> Helper loaded: form_helper
INFO - 2021-04-28 05:10:37 --> Helper loaded: my_helper
INFO - 2021-04-28 05:10:37 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:10:37 --> Controller Class Initialized
DEBUG - 2021-04-28 05:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:10:37 --> Final output sent to browser
DEBUG - 2021-04-28 05:10:37 --> Total execution time: 0.1534
INFO - 2021-04-28 05:11:23 --> Config Class Initialized
INFO - 2021-04-28 05:11:23 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:11:23 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:11:23 --> Utf8 Class Initialized
INFO - 2021-04-28 05:11:23 --> URI Class Initialized
INFO - 2021-04-28 05:11:23 --> Router Class Initialized
INFO - 2021-04-28 05:11:23 --> Output Class Initialized
INFO - 2021-04-28 05:11:23 --> Security Class Initialized
DEBUG - 2021-04-28 05:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:11:23 --> Input Class Initialized
INFO - 2021-04-28 05:11:23 --> Language Class Initialized
INFO - 2021-04-28 05:11:23 --> Language Class Initialized
INFO - 2021-04-28 05:11:23 --> Config Class Initialized
INFO - 2021-04-28 05:11:23 --> Loader Class Initialized
INFO - 2021-04-28 05:11:23 --> Helper loaded: url_helper
INFO - 2021-04-28 05:11:23 --> Helper loaded: file_helper
INFO - 2021-04-28 05:11:23 --> Helper loaded: form_helper
INFO - 2021-04-28 05:11:23 --> Helper loaded: my_helper
INFO - 2021-04-28 05:11:23 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:11:23 --> Controller Class Initialized
DEBUG - 2021-04-28 05:11:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:11:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:11:23 --> Final output sent to browser
DEBUG - 2021-04-28 05:11:23 --> Total execution time: 0.1371
INFO - 2021-04-28 05:11:24 --> Config Class Initialized
INFO - 2021-04-28 05:11:24 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:11:24 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:11:24 --> Utf8 Class Initialized
INFO - 2021-04-28 05:11:24 --> URI Class Initialized
INFO - 2021-04-28 05:11:24 --> Router Class Initialized
INFO - 2021-04-28 05:11:24 --> Output Class Initialized
INFO - 2021-04-28 05:11:24 --> Security Class Initialized
DEBUG - 2021-04-28 05:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:11:24 --> Input Class Initialized
INFO - 2021-04-28 05:11:24 --> Language Class Initialized
INFO - 2021-04-28 05:11:24 --> Language Class Initialized
INFO - 2021-04-28 05:11:24 --> Config Class Initialized
INFO - 2021-04-28 05:11:24 --> Loader Class Initialized
INFO - 2021-04-28 05:11:24 --> Helper loaded: url_helper
INFO - 2021-04-28 05:11:24 --> Helper loaded: file_helper
INFO - 2021-04-28 05:11:24 --> Helper loaded: form_helper
INFO - 2021-04-28 05:11:24 --> Helper loaded: my_helper
INFO - 2021-04-28 05:11:24 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:11:24 --> Controller Class Initialized
DEBUG - 2021-04-28 05:11:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:11:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:11:24 --> Final output sent to browser
DEBUG - 2021-04-28 05:11:24 --> Total execution time: 0.1800
INFO - 2021-04-28 05:11:30 --> Config Class Initialized
INFO - 2021-04-28 05:11:30 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:11:30 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:11:30 --> Utf8 Class Initialized
INFO - 2021-04-28 05:11:30 --> URI Class Initialized
INFO - 2021-04-28 05:11:30 --> Router Class Initialized
INFO - 2021-04-28 05:11:30 --> Output Class Initialized
INFO - 2021-04-28 05:11:30 --> Security Class Initialized
DEBUG - 2021-04-28 05:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:11:30 --> Input Class Initialized
INFO - 2021-04-28 05:11:30 --> Language Class Initialized
INFO - 2021-04-28 05:11:30 --> Language Class Initialized
INFO - 2021-04-28 05:11:30 --> Config Class Initialized
INFO - 2021-04-28 05:11:30 --> Loader Class Initialized
INFO - 2021-04-28 05:11:30 --> Helper loaded: url_helper
INFO - 2021-04-28 05:11:30 --> Helper loaded: file_helper
INFO - 2021-04-28 05:11:30 --> Helper loaded: form_helper
INFO - 2021-04-28 05:11:30 --> Helper loaded: my_helper
INFO - 2021-04-28 05:11:30 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:11:30 --> Controller Class Initialized
INFO - 2021-04-28 05:11:30 --> Config Class Initialized
INFO - 2021-04-28 05:11:30 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:11:30 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:11:30 --> Utf8 Class Initialized
INFO - 2021-04-28 05:11:30 --> URI Class Initialized
INFO - 2021-04-28 05:11:30 --> Router Class Initialized
INFO - 2021-04-28 05:11:30 --> Output Class Initialized
INFO - 2021-04-28 05:11:30 --> Security Class Initialized
DEBUG - 2021-04-28 05:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:11:30 --> Input Class Initialized
INFO - 2021-04-28 05:11:30 --> Language Class Initialized
INFO - 2021-04-28 05:11:30 --> Language Class Initialized
INFO - 2021-04-28 05:11:30 --> Config Class Initialized
INFO - 2021-04-28 05:11:30 --> Loader Class Initialized
INFO - 2021-04-28 05:11:30 --> Helper loaded: url_helper
INFO - 2021-04-28 05:11:30 --> Helper loaded: file_helper
INFO - 2021-04-28 05:11:30 --> Helper loaded: form_helper
INFO - 2021-04-28 05:11:30 --> Helper loaded: my_helper
INFO - 2021-04-28 05:11:30 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:11:30 --> Controller Class Initialized
DEBUG - 2021-04-28 05:11:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:11:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:11:30 --> Final output sent to browser
DEBUG - 2021-04-28 05:11:30 --> Total execution time: 0.1617
INFO - 2021-04-28 05:12:21 --> Config Class Initialized
INFO - 2021-04-28 05:12:21 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:12:21 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:12:21 --> Utf8 Class Initialized
INFO - 2021-04-28 05:12:21 --> URI Class Initialized
INFO - 2021-04-28 05:12:21 --> Router Class Initialized
INFO - 2021-04-28 05:12:21 --> Output Class Initialized
INFO - 2021-04-28 05:12:21 --> Security Class Initialized
DEBUG - 2021-04-28 05:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:12:21 --> Input Class Initialized
INFO - 2021-04-28 05:12:21 --> Language Class Initialized
INFO - 2021-04-28 05:12:21 --> Language Class Initialized
INFO - 2021-04-28 05:12:21 --> Config Class Initialized
INFO - 2021-04-28 05:12:21 --> Loader Class Initialized
INFO - 2021-04-28 05:12:21 --> Helper loaded: url_helper
INFO - 2021-04-28 05:12:21 --> Helper loaded: file_helper
INFO - 2021-04-28 05:12:21 --> Helper loaded: form_helper
INFO - 2021-04-28 05:12:21 --> Helper loaded: my_helper
INFO - 2021-04-28 05:12:21 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:12:21 --> Controller Class Initialized
DEBUG - 2021-04-28 05:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:12:21 --> Final output sent to browser
DEBUG - 2021-04-28 05:12:21 --> Total execution time: 0.1768
INFO - 2021-04-28 05:12:30 --> Config Class Initialized
INFO - 2021-04-28 05:12:30 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:12:30 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:12:30 --> Utf8 Class Initialized
INFO - 2021-04-28 05:12:30 --> URI Class Initialized
INFO - 2021-04-28 05:12:30 --> Router Class Initialized
INFO - 2021-04-28 05:12:30 --> Output Class Initialized
INFO - 2021-04-28 05:12:30 --> Security Class Initialized
DEBUG - 2021-04-28 05:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:12:30 --> Input Class Initialized
INFO - 2021-04-28 05:12:30 --> Language Class Initialized
INFO - 2021-04-28 05:12:31 --> Language Class Initialized
INFO - 2021-04-28 05:12:31 --> Config Class Initialized
INFO - 2021-04-28 05:12:31 --> Loader Class Initialized
INFO - 2021-04-28 05:12:31 --> Helper loaded: url_helper
INFO - 2021-04-28 05:12:31 --> Helper loaded: file_helper
INFO - 2021-04-28 05:12:31 --> Helper loaded: form_helper
INFO - 2021-04-28 05:12:31 --> Helper loaded: my_helper
INFO - 2021-04-28 05:12:31 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:12:31 --> Controller Class Initialized
DEBUG - 2021-04-28 05:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:12:31 --> Final output sent to browser
DEBUG - 2021-04-28 05:12:31 --> Total execution time: 0.1404
INFO - 2021-04-28 05:12:33 --> Config Class Initialized
INFO - 2021-04-28 05:12:33 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:12:33 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:12:33 --> Utf8 Class Initialized
INFO - 2021-04-28 05:12:33 --> URI Class Initialized
INFO - 2021-04-28 05:12:33 --> Router Class Initialized
INFO - 2021-04-28 05:12:33 --> Output Class Initialized
INFO - 2021-04-28 05:12:33 --> Security Class Initialized
DEBUG - 2021-04-28 05:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:12:33 --> Input Class Initialized
INFO - 2021-04-28 05:12:33 --> Language Class Initialized
INFO - 2021-04-28 05:12:33 --> Language Class Initialized
INFO - 2021-04-28 05:12:33 --> Config Class Initialized
INFO - 2021-04-28 05:12:33 --> Loader Class Initialized
INFO - 2021-04-28 05:12:33 --> Helper loaded: url_helper
INFO - 2021-04-28 05:12:33 --> Helper loaded: file_helper
INFO - 2021-04-28 05:12:33 --> Helper loaded: form_helper
INFO - 2021-04-28 05:12:33 --> Helper loaded: my_helper
INFO - 2021-04-28 05:12:33 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:12:33 --> Controller Class Initialized
DEBUG - 2021-04-28 05:12:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:12:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:12:33 --> Final output sent to browser
DEBUG - 2021-04-28 05:12:33 --> Total execution time: 0.1416
INFO - 2021-04-28 05:12:40 --> Config Class Initialized
INFO - 2021-04-28 05:12:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:12:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:12:40 --> Utf8 Class Initialized
INFO - 2021-04-28 05:12:40 --> URI Class Initialized
INFO - 2021-04-28 05:12:40 --> Router Class Initialized
INFO - 2021-04-28 05:12:40 --> Output Class Initialized
INFO - 2021-04-28 05:12:40 --> Security Class Initialized
DEBUG - 2021-04-28 05:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:12:40 --> Input Class Initialized
INFO - 2021-04-28 05:12:40 --> Language Class Initialized
INFO - 2021-04-28 05:12:40 --> Language Class Initialized
INFO - 2021-04-28 05:12:40 --> Config Class Initialized
INFO - 2021-04-28 05:12:40 --> Loader Class Initialized
INFO - 2021-04-28 05:12:40 --> Helper loaded: url_helper
INFO - 2021-04-28 05:12:40 --> Helper loaded: file_helper
INFO - 2021-04-28 05:12:40 --> Helper loaded: form_helper
INFO - 2021-04-28 05:12:40 --> Helper loaded: my_helper
INFO - 2021-04-28 05:12:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:12:40 --> Controller Class Initialized
INFO - 2021-04-28 05:12:40 --> Config Class Initialized
INFO - 2021-04-28 05:12:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:12:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:12:40 --> Utf8 Class Initialized
INFO - 2021-04-28 05:12:40 --> URI Class Initialized
INFO - 2021-04-28 05:12:40 --> Router Class Initialized
INFO - 2021-04-28 05:12:40 --> Output Class Initialized
INFO - 2021-04-28 05:12:40 --> Security Class Initialized
DEBUG - 2021-04-28 05:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:12:40 --> Input Class Initialized
INFO - 2021-04-28 05:12:40 --> Language Class Initialized
INFO - 2021-04-28 05:12:40 --> Language Class Initialized
INFO - 2021-04-28 05:12:40 --> Config Class Initialized
INFO - 2021-04-28 05:12:40 --> Loader Class Initialized
INFO - 2021-04-28 05:12:40 --> Helper loaded: url_helper
INFO - 2021-04-28 05:12:40 --> Helper loaded: file_helper
INFO - 2021-04-28 05:12:40 --> Helper loaded: form_helper
INFO - 2021-04-28 05:12:40 --> Helper loaded: my_helper
INFO - 2021-04-28 05:12:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:12:40 --> Controller Class Initialized
DEBUG - 2021-04-28 05:12:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:12:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:12:40 --> Final output sent to browser
DEBUG - 2021-04-28 05:12:40 --> Total execution time: 0.1577
INFO - 2021-04-28 05:30:42 --> Config Class Initialized
INFO - 2021-04-28 05:30:42 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:30:42 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:30:42 --> Utf8 Class Initialized
INFO - 2021-04-28 05:30:42 --> URI Class Initialized
DEBUG - 2021-04-28 05:30:42 --> No URI present. Default controller set.
INFO - 2021-04-28 05:30:42 --> Router Class Initialized
INFO - 2021-04-28 05:30:42 --> Output Class Initialized
INFO - 2021-04-28 05:30:42 --> Security Class Initialized
DEBUG - 2021-04-28 05:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:30:42 --> Input Class Initialized
INFO - 2021-04-28 05:30:42 --> Language Class Initialized
INFO - 2021-04-28 05:30:42 --> Language Class Initialized
INFO - 2021-04-28 05:30:42 --> Config Class Initialized
INFO - 2021-04-28 05:30:42 --> Loader Class Initialized
INFO - 2021-04-28 05:30:42 --> Helper loaded: url_helper
INFO - 2021-04-28 05:30:42 --> Helper loaded: file_helper
INFO - 2021-04-28 05:30:42 --> Helper loaded: form_helper
INFO - 2021-04-28 05:30:42 --> Helper loaded: my_helper
INFO - 2021-04-28 05:30:42 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:30:42 --> Controller Class Initialized
INFO - 2021-04-28 05:30:42 --> Config Class Initialized
INFO - 2021-04-28 05:30:42 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:30:42 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:30:42 --> Utf8 Class Initialized
INFO - 2021-04-28 05:30:42 --> URI Class Initialized
INFO - 2021-04-28 05:30:42 --> Router Class Initialized
INFO - 2021-04-28 05:30:42 --> Output Class Initialized
INFO - 2021-04-28 05:30:42 --> Security Class Initialized
DEBUG - 2021-04-28 05:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:30:42 --> Input Class Initialized
INFO - 2021-04-28 05:30:42 --> Language Class Initialized
INFO - 2021-04-28 05:30:42 --> Language Class Initialized
INFO - 2021-04-28 05:30:42 --> Config Class Initialized
INFO - 2021-04-28 05:30:42 --> Loader Class Initialized
INFO - 2021-04-28 05:30:42 --> Helper loaded: url_helper
INFO - 2021-04-28 05:30:42 --> Helper loaded: file_helper
INFO - 2021-04-28 05:30:42 --> Helper loaded: form_helper
INFO - 2021-04-28 05:30:42 --> Helper loaded: my_helper
INFO - 2021-04-28 05:30:42 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:30:42 --> Controller Class Initialized
DEBUG - 2021-04-28 05:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 05:30:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:30:42 --> Final output sent to browser
DEBUG - 2021-04-28 05:30:42 --> Total execution time: 0.1607
INFO - 2021-04-28 05:30:49 --> Config Class Initialized
INFO - 2021-04-28 05:30:49 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:30:49 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:30:49 --> Utf8 Class Initialized
INFO - 2021-04-28 05:30:49 --> URI Class Initialized
INFO - 2021-04-28 05:30:49 --> Router Class Initialized
INFO - 2021-04-28 05:30:49 --> Output Class Initialized
INFO - 2021-04-28 05:30:49 --> Security Class Initialized
DEBUG - 2021-04-28 05:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:30:49 --> Input Class Initialized
INFO - 2021-04-28 05:30:49 --> Language Class Initialized
INFO - 2021-04-28 05:30:49 --> Language Class Initialized
INFO - 2021-04-28 05:30:49 --> Config Class Initialized
INFO - 2021-04-28 05:30:49 --> Loader Class Initialized
INFO - 2021-04-28 05:30:49 --> Helper loaded: url_helper
INFO - 2021-04-28 05:30:49 --> Helper loaded: file_helper
INFO - 2021-04-28 05:30:49 --> Helper loaded: form_helper
INFO - 2021-04-28 05:30:49 --> Helper loaded: my_helper
INFO - 2021-04-28 05:30:49 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:30:49 --> Controller Class Initialized
INFO - 2021-04-28 05:30:49 --> Helper loaded: cookie_helper
INFO - 2021-04-28 05:30:49 --> Final output sent to browser
DEBUG - 2021-04-28 05:30:49 --> Total execution time: 0.1676
INFO - 2021-04-28 05:30:50 --> Config Class Initialized
INFO - 2021-04-28 05:30:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:30:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:30:50 --> Utf8 Class Initialized
INFO - 2021-04-28 05:30:50 --> URI Class Initialized
INFO - 2021-04-28 05:30:50 --> Router Class Initialized
INFO - 2021-04-28 05:30:50 --> Output Class Initialized
INFO - 2021-04-28 05:30:50 --> Security Class Initialized
DEBUG - 2021-04-28 05:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:30:50 --> Input Class Initialized
INFO - 2021-04-28 05:30:50 --> Language Class Initialized
INFO - 2021-04-28 05:30:50 --> Language Class Initialized
INFO - 2021-04-28 05:30:50 --> Config Class Initialized
INFO - 2021-04-28 05:30:50 --> Loader Class Initialized
INFO - 2021-04-28 05:30:50 --> Helper loaded: url_helper
INFO - 2021-04-28 05:30:50 --> Helper loaded: file_helper
INFO - 2021-04-28 05:30:50 --> Helper loaded: form_helper
INFO - 2021-04-28 05:30:50 --> Helper loaded: my_helper
INFO - 2021-04-28 05:30:50 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:30:50 --> Controller Class Initialized
DEBUG - 2021-04-28 05:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 05:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:30:50 --> Final output sent to browser
DEBUG - 2021-04-28 05:30:50 --> Total execution time: 0.1709
INFO - 2021-04-28 05:30:55 --> Config Class Initialized
INFO - 2021-04-28 05:30:55 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:30:55 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:30:55 --> Utf8 Class Initialized
INFO - 2021-04-28 05:30:55 --> URI Class Initialized
INFO - 2021-04-28 05:30:55 --> Router Class Initialized
INFO - 2021-04-28 05:30:55 --> Output Class Initialized
INFO - 2021-04-28 05:30:55 --> Security Class Initialized
DEBUG - 2021-04-28 05:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:30:55 --> Input Class Initialized
INFO - 2021-04-28 05:30:55 --> Language Class Initialized
INFO - 2021-04-28 05:30:55 --> Language Class Initialized
INFO - 2021-04-28 05:30:55 --> Config Class Initialized
INFO - 2021-04-28 05:30:55 --> Loader Class Initialized
INFO - 2021-04-28 05:30:55 --> Helper loaded: url_helper
INFO - 2021-04-28 05:30:55 --> Helper loaded: file_helper
INFO - 2021-04-28 05:30:55 --> Helper loaded: form_helper
INFO - 2021-04-28 05:30:55 --> Helper loaded: my_helper
INFO - 2021-04-28 05:30:55 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:30:55 --> Controller Class Initialized
DEBUG - 2021-04-28 05:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:30:55 --> Final output sent to browser
DEBUG - 2021-04-28 05:30:55 --> Total execution time: 0.1547
INFO - 2021-04-28 05:30:56 --> Config Class Initialized
INFO - 2021-04-28 05:30:56 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:30:56 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:30:56 --> Utf8 Class Initialized
INFO - 2021-04-28 05:30:56 --> URI Class Initialized
INFO - 2021-04-28 05:30:56 --> Router Class Initialized
INFO - 2021-04-28 05:30:56 --> Output Class Initialized
INFO - 2021-04-28 05:30:56 --> Security Class Initialized
DEBUG - 2021-04-28 05:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:30:56 --> Input Class Initialized
INFO - 2021-04-28 05:30:56 --> Language Class Initialized
INFO - 2021-04-28 05:30:56 --> Language Class Initialized
INFO - 2021-04-28 05:30:56 --> Config Class Initialized
INFO - 2021-04-28 05:30:56 --> Loader Class Initialized
INFO - 2021-04-28 05:30:56 --> Helper loaded: url_helper
INFO - 2021-04-28 05:30:56 --> Helper loaded: file_helper
INFO - 2021-04-28 05:30:56 --> Helper loaded: form_helper
INFO - 2021-04-28 05:30:56 --> Helper loaded: my_helper
INFO - 2021-04-28 05:30:56 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:30:56 --> Controller Class Initialized
DEBUG - 2021-04-28 05:30:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:30:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:30:56 --> Final output sent to browser
DEBUG - 2021-04-28 05:30:56 --> Total execution time: 0.1636
INFO - 2021-04-28 05:31:01 --> Config Class Initialized
INFO - 2021-04-28 05:31:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:31:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:31:01 --> Utf8 Class Initialized
INFO - 2021-04-28 05:31:01 --> URI Class Initialized
INFO - 2021-04-28 05:31:01 --> Router Class Initialized
INFO - 2021-04-28 05:31:01 --> Output Class Initialized
INFO - 2021-04-28 05:31:01 --> Security Class Initialized
DEBUG - 2021-04-28 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:31:01 --> Input Class Initialized
INFO - 2021-04-28 05:31:01 --> Language Class Initialized
INFO - 2021-04-28 05:31:01 --> Language Class Initialized
INFO - 2021-04-28 05:31:01 --> Config Class Initialized
INFO - 2021-04-28 05:31:01 --> Loader Class Initialized
INFO - 2021-04-28 05:31:01 --> Helper loaded: url_helper
INFO - 2021-04-28 05:31:01 --> Helper loaded: file_helper
INFO - 2021-04-28 05:31:01 --> Helper loaded: form_helper
INFO - 2021-04-28 05:31:01 --> Helper loaded: my_helper
INFO - 2021-04-28 05:31:01 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:31:01 --> Controller Class Initialized
INFO - 2021-04-28 05:31:01 --> Config Class Initialized
INFO - 2021-04-28 05:31:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:31:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:31:01 --> Utf8 Class Initialized
INFO - 2021-04-28 05:31:01 --> URI Class Initialized
INFO - 2021-04-28 05:31:01 --> Router Class Initialized
INFO - 2021-04-28 05:31:01 --> Output Class Initialized
INFO - 2021-04-28 05:31:01 --> Security Class Initialized
DEBUG - 2021-04-28 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:31:01 --> Input Class Initialized
INFO - 2021-04-28 05:31:01 --> Language Class Initialized
INFO - 2021-04-28 05:31:01 --> Language Class Initialized
INFO - 2021-04-28 05:31:01 --> Config Class Initialized
INFO - 2021-04-28 05:31:01 --> Loader Class Initialized
INFO - 2021-04-28 05:31:01 --> Helper loaded: url_helper
INFO - 2021-04-28 05:31:01 --> Helper loaded: file_helper
INFO - 2021-04-28 05:31:01 --> Helper loaded: form_helper
INFO - 2021-04-28 05:31:01 --> Helper loaded: my_helper
INFO - 2021-04-28 05:31:01 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:31:01 --> Controller Class Initialized
DEBUG - 2021-04-28 05:31:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:31:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:31:01 --> Final output sent to browser
DEBUG - 2021-04-28 05:31:01 --> Total execution time: 0.1429
INFO - 2021-04-28 05:31:33 --> Config Class Initialized
INFO - 2021-04-28 05:31:33 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:31:33 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:31:33 --> Utf8 Class Initialized
INFO - 2021-04-28 05:31:33 --> URI Class Initialized
INFO - 2021-04-28 05:31:33 --> Router Class Initialized
INFO - 2021-04-28 05:31:33 --> Output Class Initialized
INFO - 2021-04-28 05:31:33 --> Security Class Initialized
DEBUG - 2021-04-28 05:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:31:33 --> Input Class Initialized
INFO - 2021-04-28 05:31:33 --> Language Class Initialized
INFO - 2021-04-28 05:31:33 --> Language Class Initialized
INFO - 2021-04-28 05:31:33 --> Config Class Initialized
INFO - 2021-04-28 05:31:33 --> Loader Class Initialized
INFO - 2021-04-28 05:31:33 --> Helper loaded: url_helper
INFO - 2021-04-28 05:31:33 --> Helper loaded: file_helper
INFO - 2021-04-28 05:31:33 --> Helper loaded: form_helper
INFO - 2021-04-28 05:31:33 --> Helper loaded: my_helper
INFO - 2021-04-28 05:31:33 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:31:33 --> Controller Class Initialized
DEBUG - 2021-04-28 05:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:31:33 --> Final output sent to browser
DEBUG - 2021-04-28 05:31:33 --> Total execution time: 0.1474
INFO - 2021-04-28 05:32:59 --> Config Class Initialized
INFO - 2021-04-28 05:32:59 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:32:59 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:32:59 --> Utf8 Class Initialized
INFO - 2021-04-28 05:32:59 --> URI Class Initialized
INFO - 2021-04-28 05:32:59 --> Router Class Initialized
INFO - 2021-04-28 05:32:59 --> Output Class Initialized
INFO - 2021-04-28 05:32:59 --> Security Class Initialized
DEBUG - 2021-04-28 05:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:32:59 --> Input Class Initialized
INFO - 2021-04-28 05:32:59 --> Language Class Initialized
INFO - 2021-04-28 05:32:59 --> Language Class Initialized
INFO - 2021-04-28 05:32:59 --> Config Class Initialized
INFO - 2021-04-28 05:32:59 --> Loader Class Initialized
INFO - 2021-04-28 05:32:59 --> Helper loaded: url_helper
INFO - 2021-04-28 05:32:59 --> Helper loaded: file_helper
INFO - 2021-04-28 05:32:59 --> Helper loaded: form_helper
INFO - 2021-04-28 05:32:59 --> Helper loaded: my_helper
INFO - 2021-04-28 05:32:59 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:32:59 --> Controller Class Initialized
DEBUG - 2021-04-28 05:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:32:59 --> Final output sent to browser
DEBUG - 2021-04-28 05:32:59 --> Total execution time: 0.1774
INFO - 2021-04-28 05:36:24 --> Config Class Initialized
INFO - 2021-04-28 05:36:24 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:36:24 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:36:24 --> Utf8 Class Initialized
INFO - 2021-04-28 05:36:24 --> URI Class Initialized
INFO - 2021-04-28 05:36:24 --> Router Class Initialized
INFO - 2021-04-28 05:36:24 --> Output Class Initialized
INFO - 2021-04-28 05:36:24 --> Security Class Initialized
DEBUG - 2021-04-28 05:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:36:24 --> Input Class Initialized
INFO - 2021-04-28 05:36:24 --> Language Class Initialized
INFO - 2021-04-28 05:36:24 --> Language Class Initialized
INFO - 2021-04-28 05:36:24 --> Config Class Initialized
INFO - 2021-04-28 05:36:24 --> Loader Class Initialized
INFO - 2021-04-28 05:36:24 --> Helper loaded: url_helper
INFO - 2021-04-28 05:36:24 --> Helper loaded: file_helper
INFO - 2021-04-28 05:36:24 --> Helper loaded: form_helper
INFO - 2021-04-28 05:36:24 --> Helper loaded: my_helper
INFO - 2021-04-28 05:36:24 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:36:24 --> Controller Class Initialized
DEBUG - 2021-04-28 05:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-28 05:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:36:24 --> Final output sent to browser
DEBUG - 2021-04-28 05:36:24 --> Total execution time: 0.1361
INFO - 2021-04-28 05:36:25 --> Config Class Initialized
INFO - 2021-04-28 05:36:25 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:36:25 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:36:25 --> Utf8 Class Initialized
INFO - 2021-04-28 05:36:25 --> URI Class Initialized
INFO - 2021-04-28 05:36:25 --> Router Class Initialized
INFO - 2021-04-28 05:36:25 --> Output Class Initialized
INFO - 2021-04-28 05:36:25 --> Security Class Initialized
DEBUG - 2021-04-28 05:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:36:25 --> Input Class Initialized
INFO - 2021-04-28 05:36:25 --> Language Class Initialized
INFO - 2021-04-28 05:36:25 --> Language Class Initialized
INFO - 2021-04-28 05:36:25 --> Config Class Initialized
INFO - 2021-04-28 05:36:25 --> Loader Class Initialized
INFO - 2021-04-28 05:36:25 --> Helper loaded: url_helper
INFO - 2021-04-28 05:36:25 --> Helper loaded: file_helper
INFO - 2021-04-28 05:36:25 --> Helper loaded: form_helper
INFO - 2021-04-28 05:36:25 --> Helper loaded: my_helper
INFO - 2021-04-28 05:36:25 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:36:25 --> Controller Class Initialized
INFO - 2021-04-28 05:38:58 --> Config Class Initialized
INFO - 2021-04-28 05:38:58 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:38:58 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:38:58 --> Utf8 Class Initialized
INFO - 2021-04-28 05:38:58 --> URI Class Initialized
INFO - 2021-04-28 05:38:58 --> Router Class Initialized
INFO - 2021-04-28 05:38:58 --> Output Class Initialized
INFO - 2021-04-28 05:38:58 --> Security Class Initialized
DEBUG - 2021-04-28 05:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:38:58 --> Input Class Initialized
INFO - 2021-04-28 05:38:58 --> Language Class Initialized
INFO - 2021-04-28 05:38:58 --> Language Class Initialized
INFO - 2021-04-28 05:38:58 --> Config Class Initialized
INFO - 2021-04-28 05:38:58 --> Loader Class Initialized
INFO - 2021-04-28 05:38:58 --> Helper loaded: url_helper
INFO - 2021-04-28 05:38:58 --> Helper loaded: file_helper
INFO - 2021-04-28 05:38:58 --> Helper loaded: form_helper
INFO - 2021-04-28 05:38:58 --> Helper loaded: my_helper
INFO - 2021-04-28 05:38:58 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:38:58 --> Controller Class Initialized
ERROR - 2021-04-28 05:38:58 --> Severity: Notice --> Undefined index: ta C:\xampp\htdocs\nilai\application\modules\set_kelas\controllers\Set_kelas.php 124
ERROR - 2021-04-28 05:38:58 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                        a.id, a.id_kelas, b.nama nmsiswa
                                                        FROM t_kelas_siswa a
                                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                        WHERE a.id_kelas = '1' 
                                                        AND a.ta = ''
                                                        ORDER BY b.nama ASC, b.nis ASC
INFO - 2021-04-28 05:38:58 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 05:39:08 --> Config Class Initialized
INFO - 2021-04-28 05:39:08 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:39:08 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:39:08 --> Utf8 Class Initialized
INFO - 2021-04-28 05:39:08 --> URI Class Initialized
INFO - 2021-04-28 05:39:08 --> Router Class Initialized
INFO - 2021-04-28 05:39:08 --> Output Class Initialized
INFO - 2021-04-28 05:39:08 --> Security Class Initialized
DEBUG - 2021-04-28 05:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:39:08 --> Input Class Initialized
INFO - 2021-04-28 05:39:08 --> Language Class Initialized
INFO - 2021-04-28 05:39:08 --> Language Class Initialized
INFO - 2021-04-28 05:39:08 --> Config Class Initialized
INFO - 2021-04-28 05:39:08 --> Loader Class Initialized
INFO - 2021-04-28 05:39:08 --> Helper loaded: url_helper
INFO - 2021-04-28 05:39:08 --> Helper loaded: file_helper
INFO - 2021-04-28 05:39:08 --> Helper loaded: form_helper
INFO - 2021-04-28 05:39:08 --> Helper loaded: my_helper
INFO - 2021-04-28 05:39:08 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:39:08 --> Controller Class Initialized
ERROR - 2021-04-28 05:39:08 --> Severity: Notice --> Undefined index: ta C:\xampp\htdocs\nilai\application\modules\set_kelas\controllers\Set_kelas.php 124
ERROR - 2021-04-28 05:39:08 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                        a.id, a.id_kelas, b.nama nmsiswa
                                                        FROM t_kelas_siswa a
                                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                        WHERE a.id_kelas = '1' 
                                                        AND a.ta = ''
                                                        ORDER BY b.nama ASC, b.nis ASC
INFO - 2021-04-28 05:39:08 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 05:41:34 --> Config Class Initialized
INFO - 2021-04-28 05:41:34 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:41:34 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:41:34 --> Utf8 Class Initialized
INFO - 2021-04-28 05:41:34 --> URI Class Initialized
INFO - 2021-04-28 05:41:34 --> Router Class Initialized
INFO - 2021-04-28 05:41:34 --> Output Class Initialized
INFO - 2021-04-28 05:41:34 --> Security Class Initialized
DEBUG - 2021-04-28 05:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:41:34 --> Input Class Initialized
INFO - 2021-04-28 05:41:34 --> Language Class Initialized
INFO - 2021-04-28 05:41:34 --> Language Class Initialized
INFO - 2021-04-28 05:41:34 --> Config Class Initialized
INFO - 2021-04-28 05:41:34 --> Loader Class Initialized
INFO - 2021-04-28 05:41:34 --> Helper loaded: url_helper
INFO - 2021-04-28 05:41:34 --> Helper loaded: file_helper
INFO - 2021-04-28 05:41:34 --> Helper loaded: form_helper
INFO - 2021-04-28 05:41:34 --> Helper loaded: my_helper
INFO - 2021-04-28 05:41:34 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:41:34 --> Controller Class Initialized
DEBUG - 2021-04-28 05:41:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:41:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:41:34 --> Final output sent to browser
DEBUG - 2021-04-28 05:41:34 --> Total execution time: 0.1472
INFO - 2021-04-28 05:41:37 --> Config Class Initialized
INFO - 2021-04-28 05:41:37 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:41:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:41:37 --> Utf8 Class Initialized
INFO - 2021-04-28 05:41:37 --> URI Class Initialized
INFO - 2021-04-28 05:41:37 --> Router Class Initialized
INFO - 2021-04-28 05:41:37 --> Output Class Initialized
INFO - 2021-04-28 05:41:37 --> Security Class Initialized
DEBUG - 2021-04-28 05:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:41:37 --> Input Class Initialized
INFO - 2021-04-28 05:41:37 --> Language Class Initialized
INFO - 2021-04-28 05:41:37 --> Language Class Initialized
INFO - 2021-04-28 05:41:37 --> Config Class Initialized
INFO - 2021-04-28 05:41:37 --> Loader Class Initialized
INFO - 2021-04-28 05:41:37 --> Helper loaded: url_helper
INFO - 2021-04-28 05:41:37 --> Helper loaded: file_helper
INFO - 2021-04-28 05:41:37 --> Helper loaded: form_helper
INFO - 2021-04-28 05:41:37 --> Helper loaded: my_helper
INFO - 2021-04-28 05:41:37 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:41:37 --> Controller Class Initialized
DEBUG - 2021-04-28 05:41:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:41:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:41:37 --> Final output sent to browser
DEBUG - 2021-04-28 05:41:37 --> Total execution time: 0.1076
INFO - 2021-04-28 05:41:41 --> Config Class Initialized
INFO - 2021-04-28 05:41:41 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:41:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:41:41 --> Utf8 Class Initialized
INFO - 2021-04-28 05:41:41 --> URI Class Initialized
INFO - 2021-04-28 05:41:41 --> Router Class Initialized
INFO - 2021-04-28 05:41:41 --> Output Class Initialized
INFO - 2021-04-28 05:41:41 --> Security Class Initialized
DEBUG - 2021-04-28 05:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:41:41 --> Input Class Initialized
INFO - 2021-04-28 05:41:41 --> Language Class Initialized
INFO - 2021-04-28 05:41:41 --> Language Class Initialized
INFO - 2021-04-28 05:41:41 --> Config Class Initialized
INFO - 2021-04-28 05:41:41 --> Loader Class Initialized
INFO - 2021-04-28 05:41:41 --> Helper loaded: url_helper
INFO - 2021-04-28 05:41:41 --> Helper loaded: file_helper
INFO - 2021-04-28 05:41:41 --> Helper loaded: form_helper
INFO - 2021-04-28 05:41:41 --> Helper loaded: my_helper
INFO - 2021-04-28 05:41:41 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:41:41 --> Controller Class Initialized
INFO - 2021-04-28 05:41:41 --> Config Class Initialized
INFO - 2021-04-28 05:41:41 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:41:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:41:41 --> Utf8 Class Initialized
INFO - 2021-04-28 05:41:41 --> URI Class Initialized
INFO - 2021-04-28 05:41:41 --> Router Class Initialized
INFO - 2021-04-28 05:41:41 --> Output Class Initialized
INFO - 2021-04-28 05:41:41 --> Security Class Initialized
DEBUG - 2021-04-28 05:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:41:41 --> Input Class Initialized
INFO - 2021-04-28 05:41:41 --> Language Class Initialized
INFO - 2021-04-28 05:41:41 --> Language Class Initialized
INFO - 2021-04-28 05:41:41 --> Config Class Initialized
INFO - 2021-04-28 05:41:41 --> Loader Class Initialized
INFO - 2021-04-28 05:41:41 --> Helper loaded: url_helper
INFO - 2021-04-28 05:41:41 --> Helper loaded: file_helper
INFO - 2021-04-28 05:41:41 --> Helper loaded: form_helper
INFO - 2021-04-28 05:41:41 --> Helper loaded: my_helper
INFO - 2021-04-28 05:41:41 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:41:41 --> Controller Class Initialized
DEBUG - 2021-04-28 05:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:41:41 --> Final output sent to browser
DEBUG - 2021-04-28 05:41:41 --> Total execution time: 0.1417
INFO - 2021-04-28 05:42:03 --> Config Class Initialized
INFO - 2021-04-28 05:42:03 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:42:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:42:03 --> Utf8 Class Initialized
INFO - 2021-04-28 05:42:03 --> URI Class Initialized
INFO - 2021-04-28 05:42:03 --> Router Class Initialized
INFO - 2021-04-28 05:42:03 --> Output Class Initialized
INFO - 2021-04-28 05:42:03 --> Security Class Initialized
DEBUG - 2021-04-28 05:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:42:03 --> Input Class Initialized
INFO - 2021-04-28 05:42:03 --> Language Class Initialized
INFO - 2021-04-28 05:42:03 --> Language Class Initialized
INFO - 2021-04-28 05:42:03 --> Config Class Initialized
INFO - 2021-04-28 05:42:03 --> Loader Class Initialized
INFO - 2021-04-28 05:42:03 --> Helper loaded: url_helper
INFO - 2021-04-28 05:42:03 --> Helper loaded: file_helper
INFO - 2021-04-28 05:42:03 --> Helper loaded: form_helper
INFO - 2021-04-28 05:42:03 --> Helper loaded: my_helper
INFO - 2021-04-28 05:42:03 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:42:03 --> Controller Class Initialized
DEBUG - 2021-04-28 05:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:42:03 --> Final output sent to browser
DEBUG - 2021-04-28 05:42:03 --> Total execution time: 0.1368
INFO - 2021-04-28 05:42:19 --> Config Class Initialized
INFO - 2021-04-28 05:42:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:42:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:42:19 --> Utf8 Class Initialized
INFO - 2021-04-28 05:42:19 --> URI Class Initialized
INFO - 2021-04-28 05:42:19 --> Router Class Initialized
INFO - 2021-04-28 05:42:19 --> Output Class Initialized
INFO - 2021-04-28 05:42:19 --> Security Class Initialized
DEBUG - 2021-04-28 05:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:42:19 --> Input Class Initialized
INFO - 2021-04-28 05:42:19 --> Language Class Initialized
INFO - 2021-04-28 05:42:19 --> Language Class Initialized
INFO - 2021-04-28 05:42:19 --> Config Class Initialized
INFO - 2021-04-28 05:42:19 --> Loader Class Initialized
INFO - 2021-04-28 05:42:19 --> Helper loaded: url_helper
INFO - 2021-04-28 05:42:19 --> Helper loaded: file_helper
INFO - 2021-04-28 05:42:19 --> Helper loaded: form_helper
INFO - 2021-04-28 05:42:19 --> Helper loaded: my_helper
INFO - 2021-04-28 05:42:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:42:19 --> Controller Class Initialized
DEBUG - 2021-04-28 05:42:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:42:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:42:19 --> Final output sent to browser
DEBUG - 2021-04-28 05:42:19 --> Total execution time: 0.1864
INFO - 2021-04-28 05:42:21 --> Config Class Initialized
INFO - 2021-04-28 05:42:21 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:42:21 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:42:21 --> Utf8 Class Initialized
INFO - 2021-04-28 05:42:21 --> URI Class Initialized
INFO - 2021-04-28 05:42:21 --> Router Class Initialized
INFO - 2021-04-28 05:42:21 --> Output Class Initialized
INFO - 2021-04-28 05:42:21 --> Security Class Initialized
DEBUG - 2021-04-28 05:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:42:21 --> Input Class Initialized
INFO - 2021-04-28 05:42:21 --> Language Class Initialized
INFO - 2021-04-28 05:42:21 --> Language Class Initialized
INFO - 2021-04-28 05:42:21 --> Config Class Initialized
INFO - 2021-04-28 05:42:21 --> Loader Class Initialized
INFO - 2021-04-28 05:42:21 --> Helper loaded: url_helper
INFO - 2021-04-28 05:42:21 --> Helper loaded: file_helper
INFO - 2021-04-28 05:42:21 --> Helper loaded: form_helper
INFO - 2021-04-28 05:42:21 --> Helper loaded: my_helper
INFO - 2021-04-28 05:42:21 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:42:21 --> Controller Class Initialized
DEBUG - 2021-04-28 05:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:42:21 --> Final output sent to browser
DEBUG - 2021-04-28 05:42:21 --> Total execution time: 0.1572
INFO - 2021-04-28 05:42:23 --> Config Class Initialized
INFO - 2021-04-28 05:42:23 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:42:23 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:42:23 --> Utf8 Class Initialized
INFO - 2021-04-28 05:42:23 --> URI Class Initialized
INFO - 2021-04-28 05:42:23 --> Router Class Initialized
INFO - 2021-04-28 05:42:23 --> Output Class Initialized
INFO - 2021-04-28 05:42:23 --> Security Class Initialized
DEBUG - 2021-04-28 05:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:42:23 --> Input Class Initialized
INFO - 2021-04-28 05:42:23 --> Language Class Initialized
INFO - 2021-04-28 05:42:23 --> Language Class Initialized
INFO - 2021-04-28 05:42:23 --> Config Class Initialized
INFO - 2021-04-28 05:42:23 --> Loader Class Initialized
INFO - 2021-04-28 05:42:23 --> Helper loaded: url_helper
INFO - 2021-04-28 05:42:23 --> Helper loaded: file_helper
INFO - 2021-04-28 05:42:23 --> Helper loaded: form_helper
INFO - 2021-04-28 05:42:23 --> Helper loaded: my_helper
INFO - 2021-04-28 05:42:23 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:42:23 --> Controller Class Initialized
DEBUG - 2021-04-28 05:42:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:42:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:42:23 --> Final output sent to browser
DEBUG - 2021-04-28 05:42:23 --> Total execution time: 0.1308
INFO - 2021-04-28 05:45:38 --> Config Class Initialized
INFO - 2021-04-28 05:45:38 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:45:38 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:45:38 --> Utf8 Class Initialized
INFO - 2021-04-28 05:45:38 --> URI Class Initialized
INFO - 2021-04-28 05:45:38 --> Router Class Initialized
INFO - 2021-04-28 05:45:38 --> Output Class Initialized
INFO - 2021-04-28 05:45:38 --> Security Class Initialized
DEBUG - 2021-04-28 05:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:45:38 --> Input Class Initialized
INFO - 2021-04-28 05:45:38 --> Language Class Initialized
INFO - 2021-04-28 05:45:38 --> Language Class Initialized
INFO - 2021-04-28 05:45:38 --> Config Class Initialized
INFO - 2021-04-28 05:45:38 --> Loader Class Initialized
INFO - 2021-04-28 05:45:38 --> Helper loaded: url_helper
INFO - 2021-04-28 05:45:38 --> Helper loaded: file_helper
INFO - 2021-04-28 05:45:38 --> Helper loaded: form_helper
INFO - 2021-04-28 05:45:38 --> Helper loaded: my_helper
INFO - 2021-04-28 05:45:38 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:45:38 --> Controller Class Initialized
DEBUG - 2021-04-28 05:45:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:45:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:45:38 --> Final output sent to browser
DEBUG - 2021-04-28 05:45:38 --> Total execution time: 0.1860
INFO - 2021-04-28 05:45:40 --> Config Class Initialized
INFO - 2021-04-28 05:45:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:45:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:45:40 --> Utf8 Class Initialized
INFO - 2021-04-28 05:45:40 --> URI Class Initialized
INFO - 2021-04-28 05:45:40 --> Router Class Initialized
INFO - 2021-04-28 05:45:40 --> Output Class Initialized
INFO - 2021-04-28 05:45:40 --> Security Class Initialized
DEBUG - 2021-04-28 05:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:45:40 --> Input Class Initialized
INFO - 2021-04-28 05:45:40 --> Language Class Initialized
INFO - 2021-04-28 05:45:40 --> Language Class Initialized
INFO - 2021-04-28 05:45:40 --> Config Class Initialized
INFO - 2021-04-28 05:45:40 --> Loader Class Initialized
INFO - 2021-04-28 05:45:40 --> Helper loaded: url_helper
INFO - 2021-04-28 05:45:40 --> Helper loaded: file_helper
INFO - 2021-04-28 05:45:40 --> Helper loaded: form_helper
INFO - 2021-04-28 05:45:40 --> Helper loaded: my_helper
INFO - 2021-04-28 05:45:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:45:40 --> Controller Class Initialized
DEBUG - 2021-04-28 05:45:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:45:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:45:40 --> Final output sent to browser
DEBUG - 2021-04-28 05:45:40 --> Total execution time: 0.1374
INFO - 2021-04-28 05:45:45 --> Config Class Initialized
INFO - 2021-04-28 05:45:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:45:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:45:45 --> Utf8 Class Initialized
INFO - 2021-04-28 05:45:45 --> URI Class Initialized
INFO - 2021-04-28 05:45:45 --> Router Class Initialized
INFO - 2021-04-28 05:45:45 --> Output Class Initialized
INFO - 2021-04-28 05:45:45 --> Security Class Initialized
DEBUG - 2021-04-28 05:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:45:45 --> Input Class Initialized
INFO - 2021-04-28 05:45:45 --> Language Class Initialized
INFO - 2021-04-28 05:45:45 --> Language Class Initialized
INFO - 2021-04-28 05:45:45 --> Config Class Initialized
INFO - 2021-04-28 05:45:45 --> Loader Class Initialized
INFO - 2021-04-28 05:45:45 --> Helper loaded: url_helper
INFO - 2021-04-28 05:45:45 --> Helper loaded: file_helper
INFO - 2021-04-28 05:45:45 --> Helper loaded: form_helper
INFO - 2021-04-28 05:45:45 --> Helper loaded: my_helper
INFO - 2021-04-28 05:45:45 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:45:45 --> Controller Class Initialized
INFO - 2021-04-28 05:45:45 --> Config Class Initialized
INFO - 2021-04-28 05:45:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:45:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:45:45 --> Utf8 Class Initialized
INFO - 2021-04-28 05:45:45 --> URI Class Initialized
INFO - 2021-04-28 05:45:45 --> Router Class Initialized
INFO - 2021-04-28 05:45:45 --> Output Class Initialized
INFO - 2021-04-28 05:45:45 --> Security Class Initialized
DEBUG - 2021-04-28 05:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:45:45 --> Input Class Initialized
INFO - 2021-04-28 05:45:45 --> Language Class Initialized
INFO - 2021-04-28 05:45:45 --> Language Class Initialized
INFO - 2021-04-28 05:45:45 --> Config Class Initialized
INFO - 2021-04-28 05:45:45 --> Loader Class Initialized
INFO - 2021-04-28 05:45:45 --> Helper loaded: url_helper
INFO - 2021-04-28 05:45:45 --> Helper loaded: file_helper
INFO - 2021-04-28 05:45:45 --> Helper loaded: form_helper
INFO - 2021-04-28 05:45:45 --> Helper loaded: my_helper
INFO - 2021-04-28 05:45:45 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:45:45 --> Controller Class Initialized
DEBUG - 2021-04-28 05:45:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:45:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:45:45 --> Final output sent to browser
DEBUG - 2021-04-28 05:45:45 --> Total execution time: 0.1487
INFO - 2021-04-28 05:45:48 --> Config Class Initialized
INFO - 2021-04-28 05:45:48 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:45:48 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:45:48 --> Utf8 Class Initialized
INFO - 2021-04-28 05:45:48 --> URI Class Initialized
INFO - 2021-04-28 05:45:48 --> Router Class Initialized
INFO - 2021-04-28 05:45:48 --> Output Class Initialized
INFO - 2021-04-28 05:45:48 --> Security Class Initialized
DEBUG - 2021-04-28 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:45:48 --> Input Class Initialized
INFO - 2021-04-28 05:45:48 --> Language Class Initialized
INFO - 2021-04-28 05:45:48 --> Language Class Initialized
INFO - 2021-04-28 05:45:48 --> Config Class Initialized
INFO - 2021-04-28 05:45:48 --> Loader Class Initialized
INFO - 2021-04-28 05:45:48 --> Helper loaded: url_helper
INFO - 2021-04-28 05:45:48 --> Helper loaded: file_helper
INFO - 2021-04-28 05:45:48 --> Helper loaded: form_helper
INFO - 2021-04-28 05:45:48 --> Helper loaded: my_helper
INFO - 2021-04-28 05:45:48 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:45:48 --> Controller Class Initialized
DEBUG - 2021-04-28 05:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:45:48 --> Final output sent to browser
DEBUG - 2021-04-28 05:45:48 --> Total execution time: 0.1574
INFO - 2021-04-28 05:45:52 --> Config Class Initialized
INFO - 2021-04-28 05:45:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:45:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:45:52 --> Utf8 Class Initialized
INFO - 2021-04-28 05:45:52 --> URI Class Initialized
INFO - 2021-04-28 05:45:52 --> Router Class Initialized
INFO - 2021-04-28 05:45:52 --> Output Class Initialized
INFO - 2021-04-28 05:45:52 --> Security Class Initialized
DEBUG - 2021-04-28 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:45:52 --> Input Class Initialized
INFO - 2021-04-28 05:45:52 --> Language Class Initialized
INFO - 2021-04-28 05:45:52 --> Language Class Initialized
INFO - 2021-04-28 05:45:52 --> Config Class Initialized
INFO - 2021-04-28 05:45:52 --> Loader Class Initialized
INFO - 2021-04-28 05:45:52 --> Helper loaded: url_helper
INFO - 2021-04-28 05:45:52 --> Helper loaded: file_helper
INFO - 2021-04-28 05:45:52 --> Helper loaded: form_helper
INFO - 2021-04-28 05:45:52 --> Helper loaded: my_helper
INFO - 2021-04-28 05:45:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:45:52 --> Controller Class Initialized
INFO - 2021-04-28 05:45:52 --> Config Class Initialized
INFO - 2021-04-28 05:45:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:45:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:45:52 --> Utf8 Class Initialized
INFO - 2021-04-28 05:45:52 --> URI Class Initialized
INFO - 2021-04-28 05:45:52 --> Router Class Initialized
INFO - 2021-04-28 05:45:52 --> Output Class Initialized
INFO - 2021-04-28 05:45:52 --> Security Class Initialized
DEBUG - 2021-04-28 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:45:52 --> Input Class Initialized
INFO - 2021-04-28 05:45:52 --> Language Class Initialized
INFO - 2021-04-28 05:45:52 --> Language Class Initialized
INFO - 2021-04-28 05:45:52 --> Config Class Initialized
INFO - 2021-04-28 05:45:52 --> Loader Class Initialized
INFO - 2021-04-28 05:45:52 --> Helper loaded: url_helper
INFO - 2021-04-28 05:45:52 --> Helper loaded: file_helper
INFO - 2021-04-28 05:45:52 --> Helper loaded: form_helper
INFO - 2021-04-28 05:45:52 --> Helper loaded: my_helper
INFO - 2021-04-28 05:45:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:45:52 --> Controller Class Initialized
DEBUG - 2021-04-28 05:45:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:45:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:45:52 --> Final output sent to browser
DEBUG - 2021-04-28 05:45:52 --> Total execution time: 0.1329
INFO - 2021-04-28 05:45:53 --> Config Class Initialized
INFO - 2021-04-28 05:45:53 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:45:53 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:45:53 --> Utf8 Class Initialized
INFO - 2021-04-28 05:45:53 --> URI Class Initialized
INFO - 2021-04-28 05:45:53 --> Router Class Initialized
INFO - 2021-04-28 05:45:53 --> Output Class Initialized
INFO - 2021-04-28 05:45:53 --> Security Class Initialized
DEBUG - 2021-04-28 05:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:45:53 --> Input Class Initialized
INFO - 2021-04-28 05:45:53 --> Language Class Initialized
INFO - 2021-04-28 05:45:53 --> Language Class Initialized
INFO - 2021-04-28 05:45:53 --> Config Class Initialized
INFO - 2021-04-28 05:45:53 --> Loader Class Initialized
INFO - 2021-04-28 05:45:53 --> Helper loaded: url_helper
INFO - 2021-04-28 05:45:53 --> Helper loaded: file_helper
INFO - 2021-04-28 05:45:53 --> Helper loaded: form_helper
INFO - 2021-04-28 05:45:53 --> Helper loaded: my_helper
INFO - 2021-04-28 05:45:53 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:45:53 --> Controller Class Initialized
DEBUG - 2021-04-28 05:45:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:45:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:45:53 --> Final output sent to browser
DEBUG - 2021-04-28 05:45:53 --> Total execution time: 0.1404
INFO - 2021-04-28 05:50:32 --> Config Class Initialized
INFO - 2021-04-28 05:50:32 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:32 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:32 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:32 --> URI Class Initialized
INFO - 2021-04-28 05:50:32 --> Router Class Initialized
INFO - 2021-04-28 05:50:32 --> Output Class Initialized
INFO - 2021-04-28 05:50:32 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:32 --> Input Class Initialized
INFO - 2021-04-28 05:50:32 --> Language Class Initialized
INFO - 2021-04-28 05:50:32 --> Language Class Initialized
INFO - 2021-04-28 05:50:32 --> Config Class Initialized
INFO - 2021-04-28 05:50:32 --> Loader Class Initialized
INFO - 2021-04-28 05:50:32 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:32 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:32 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:32 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:32 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:32 --> Controller Class Initialized
DEBUG - 2021-04-28 05:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:50:32 --> Final output sent to browser
DEBUG - 2021-04-28 05:50:32 --> Total execution time: 0.1125
INFO - 2021-04-28 05:50:34 --> Config Class Initialized
INFO - 2021-04-28 05:50:34 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:34 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:34 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:34 --> URI Class Initialized
INFO - 2021-04-28 05:50:34 --> Router Class Initialized
INFO - 2021-04-28 05:50:34 --> Output Class Initialized
INFO - 2021-04-28 05:50:34 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:34 --> Input Class Initialized
INFO - 2021-04-28 05:50:34 --> Language Class Initialized
INFO - 2021-04-28 05:50:34 --> Language Class Initialized
INFO - 2021-04-28 05:50:34 --> Config Class Initialized
INFO - 2021-04-28 05:50:34 --> Loader Class Initialized
INFO - 2021-04-28 05:50:34 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:34 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:34 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:34 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:34 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:34 --> Controller Class Initialized
INFO - 2021-04-28 05:50:34 --> Final output sent to browser
DEBUG - 2021-04-28 05:50:34 --> Total execution time: 0.1598
INFO - 2021-04-28 05:50:37 --> Config Class Initialized
INFO - 2021-04-28 05:50:37 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:37 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:37 --> URI Class Initialized
INFO - 2021-04-28 05:50:37 --> Router Class Initialized
INFO - 2021-04-28 05:50:37 --> Output Class Initialized
INFO - 2021-04-28 05:50:37 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:37 --> Input Class Initialized
INFO - 2021-04-28 05:50:37 --> Language Class Initialized
INFO - 2021-04-28 05:50:37 --> Language Class Initialized
INFO - 2021-04-28 05:50:37 --> Config Class Initialized
INFO - 2021-04-28 05:50:37 --> Loader Class Initialized
INFO - 2021-04-28 05:50:37 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:37 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:37 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:37 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:37 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:37 --> Controller Class Initialized
DEBUG - 2021-04-28 05:50:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:50:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:50:37 --> Final output sent to browser
DEBUG - 2021-04-28 05:50:37 --> Total execution time: 0.1547
INFO - 2021-04-28 05:50:40 --> Config Class Initialized
INFO - 2021-04-28 05:50:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:40 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:40 --> URI Class Initialized
INFO - 2021-04-28 05:50:40 --> Router Class Initialized
INFO - 2021-04-28 05:50:40 --> Output Class Initialized
INFO - 2021-04-28 05:50:40 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:40 --> Input Class Initialized
INFO - 2021-04-28 05:50:40 --> Language Class Initialized
INFO - 2021-04-28 05:50:40 --> Language Class Initialized
INFO - 2021-04-28 05:50:40 --> Config Class Initialized
INFO - 2021-04-28 05:50:40 --> Loader Class Initialized
INFO - 2021-04-28 05:50:40 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:40 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:40 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:40 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:40 --> Controller Class Initialized
INFO - 2021-04-28 05:50:40 --> Final output sent to browser
DEBUG - 2021-04-28 05:50:40 --> Total execution time: 0.1393
INFO - 2021-04-28 05:50:42 --> Config Class Initialized
INFO - 2021-04-28 05:50:42 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:42 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:42 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:42 --> URI Class Initialized
INFO - 2021-04-28 05:50:42 --> Router Class Initialized
INFO - 2021-04-28 05:50:42 --> Output Class Initialized
INFO - 2021-04-28 05:50:42 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:42 --> Input Class Initialized
INFO - 2021-04-28 05:50:42 --> Language Class Initialized
INFO - 2021-04-28 05:50:42 --> Language Class Initialized
INFO - 2021-04-28 05:50:42 --> Config Class Initialized
INFO - 2021-04-28 05:50:42 --> Loader Class Initialized
INFO - 2021-04-28 05:50:42 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:42 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:42 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:42 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:42 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:42 --> Controller Class Initialized
INFO - 2021-04-28 05:50:42 --> Final output sent to browser
DEBUG - 2021-04-28 05:50:42 --> Total execution time: 0.1458
INFO - 2021-04-28 05:50:44 --> Config Class Initialized
INFO - 2021-04-28 05:50:44 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:44 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:44 --> URI Class Initialized
INFO - 2021-04-28 05:50:44 --> Router Class Initialized
INFO - 2021-04-28 05:50:44 --> Output Class Initialized
INFO - 2021-04-28 05:50:44 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:44 --> Input Class Initialized
INFO - 2021-04-28 05:50:44 --> Language Class Initialized
INFO - 2021-04-28 05:50:44 --> Language Class Initialized
INFO - 2021-04-28 05:50:44 --> Config Class Initialized
INFO - 2021-04-28 05:50:44 --> Loader Class Initialized
INFO - 2021-04-28 05:50:44 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:44 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:44 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:44 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:44 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:44 --> Controller Class Initialized
INFO - 2021-04-28 05:50:44 --> Final output sent to browser
DEBUG - 2021-04-28 05:50:44 --> Total execution time: 0.1439
INFO - 2021-04-28 05:50:45 --> Config Class Initialized
INFO - 2021-04-28 05:50:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:45 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:45 --> URI Class Initialized
INFO - 2021-04-28 05:50:45 --> Router Class Initialized
INFO - 2021-04-28 05:50:45 --> Output Class Initialized
INFO - 2021-04-28 05:50:45 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:45 --> Input Class Initialized
INFO - 2021-04-28 05:50:45 --> Language Class Initialized
INFO - 2021-04-28 05:50:45 --> Language Class Initialized
INFO - 2021-04-28 05:50:45 --> Config Class Initialized
INFO - 2021-04-28 05:50:45 --> Loader Class Initialized
INFO - 2021-04-28 05:50:45 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:45 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:45 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:45 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:45 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:45 --> Controller Class Initialized
DEBUG - 2021-04-28 05:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:50:45 --> Final output sent to browser
DEBUG - 2021-04-28 05:50:45 --> Total execution time: 0.1394
INFO - 2021-04-28 05:50:51 --> Config Class Initialized
INFO - 2021-04-28 05:50:51 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:51 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:51 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:51 --> URI Class Initialized
INFO - 2021-04-28 05:50:51 --> Router Class Initialized
INFO - 2021-04-28 05:50:51 --> Output Class Initialized
INFO - 2021-04-28 05:50:51 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:51 --> Input Class Initialized
INFO - 2021-04-28 05:50:51 --> Language Class Initialized
INFO - 2021-04-28 05:50:51 --> Language Class Initialized
INFO - 2021-04-28 05:50:51 --> Config Class Initialized
INFO - 2021-04-28 05:50:51 --> Loader Class Initialized
INFO - 2021-04-28 05:50:51 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:51 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:51 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:51 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:51 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:51 --> Controller Class Initialized
DEBUG - 2021-04-28 05:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-28 05:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:50:51 --> Final output sent to browser
DEBUG - 2021-04-28 05:50:51 --> Total execution time: 0.1098
INFO - 2021-04-28 05:50:51 --> Config Class Initialized
INFO - 2021-04-28 05:50:51 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:51 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:51 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:51 --> URI Class Initialized
INFO - 2021-04-28 05:50:51 --> Router Class Initialized
INFO - 2021-04-28 05:50:51 --> Output Class Initialized
INFO - 2021-04-28 05:50:51 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:51 --> Input Class Initialized
INFO - 2021-04-28 05:50:51 --> Language Class Initialized
INFO - 2021-04-28 05:50:51 --> Language Class Initialized
INFO - 2021-04-28 05:50:51 --> Config Class Initialized
INFO - 2021-04-28 05:50:51 --> Loader Class Initialized
INFO - 2021-04-28 05:50:52 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:52 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:52 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:52 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:52 --> Controller Class Initialized
INFO - 2021-04-28 05:50:54 --> Config Class Initialized
INFO - 2021-04-28 05:50:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:54 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:54 --> URI Class Initialized
INFO - 2021-04-28 05:50:54 --> Router Class Initialized
INFO - 2021-04-28 05:50:54 --> Output Class Initialized
INFO - 2021-04-28 05:50:54 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:54 --> Input Class Initialized
INFO - 2021-04-28 05:50:54 --> Language Class Initialized
INFO - 2021-04-28 05:50:54 --> Language Class Initialized
INFO - 2021-04-28 05:50:54 --> Config Class Initialized
INFO - 2021-04-28 05:50:54 --> Loader Class Initialized
INFO - 2021-04-28 05:50:54 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:54 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:54 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:54 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:54 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:54 --> Controller Class Initialized
INFO - 2021-04-28 05:50:54 --> Final output sent to browser
DEBUG - 2021-04-28 05:50:54 --> Total execution time: 0.1610
INFO - 2021-04-28 05:50:54 --> Config Class Initialized
INFO - 2021-04-28 05:50:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:50:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:50:54 --> Utf8 Class Initialized
INFO - 2021-04-28 05:50:54 --> URI Class Initialized
INFO - 2021-04-28 05:50:54 --> Router Class Initialized
INFO - 2021-04-28 05:50:54 --> Output Class Initialized
INFO - 2021-04-28 05:50:54 --> Security Class Initialized
DEBUG - 2021-04-28 05:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:50:54 --> Input Class Initialized
INFO - 2021-04-28 05:50:54 --> Language Class Initialized
INFO - 2021-04-28 05:50:54 --> Language Class Initialized
INFO - 2021-04-28 05:50:54 --> Config Class Initialized
INFO - 2021-04-28 05:50:54 --> Loader Class Initialized
INFO - 2021-04-28 05:50:54 --> Helper loaded: url_helper
INFO - 2021-04-28 05:50:54 --> Helper loaded: file_helper
INFO - 2021-04-28 05:50:54 --> Helper loaded: form_helper
INFO - 2021-04-28 05:50:54 --> Helper loaded: my_helper
INFO - 2021-04-28 05:50:54 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:50:54 --> Controller Class Initialized
INFO - 2021-04-28 05:51:00 --> Config Class Initialized
INFO - 2021-04-28 05:51:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:51:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:51:00 --> Utf8 Class Initialized
INFO - 2021-04-28 05:51:00 --> URI Class Initialized
INFO - 2021-04-28 05:51:00 --> Router Class Initialized
INFO - 2021-04-28 05:51:00 --> Output Class Initialized
INFO - 2021-04-28 05:51:00 --> Security Class Initialized
DEBUG - 2021-04-28 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:51:00 --> Input Class Initialized
INFO - 2021-04-28 05:51:00 --> Language Class Initialized
INFO - 2021-04-28 05:51:00 --> Language Class Initialized
INFO - 2021-04-28 05:51:00 --> Config Class Initialized
INFO - 2021-04-28 05:51:00 --> Loader Class Initialized
INFO - 2021-04-28 05:51:00 --> Helper loaded: url_helper
INFO - 2021-04-28 05:51:00 --> Helper loaded: file_helper
INFO - 2021-04-28 05:51:00 --> Helper loaded: form_helper
INFO - 2021-04-28 05:51:00 --> Helper loaded: my_helper
INFO - 2021-04-28 05:51:00 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:51:00 --> Controller Class Initialized
DEBUG - 2021-04-28 05:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:51:00 --> Final output sent to browser
DEBUG - 2021-04-28 05:51:00 --> Total execution time: 0.1062
INFO - 2021-04-28 05:51:44 --> Config Class Initialized
INFO - 2021-04-28 05:51:44 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:51:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:51:44 --> Utf8 Class Initialized
INFO - 2021-04-28 05:51:44 --> URI Class Initialized
INFO - 2021-04-28 05:51:44 --> Router Class Initialized
INFO - 2021-04-28 05:51:44 --> Output Class Initialized
INFO - 2021-04-28 05:51:44 --> Security Class Initialized
DEBUG - 2021-04-28 05:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:51:44 --> Input Class Initialized
INFO - 2021-04-28 05:51:44 --> Language Class Initialized
INFO - 2021-04-28 05:51:44 --> Language Class Initialized
INFO - 2021-04-28 05:51:44 --> Config Class Initialized
INFO - 2021-04-28 05:51:44 --> Loader Class Initialized
INFO - 2021-04-28 05:51:44 --> Helper loaded: url_helper
INFO - 2021-04-28 05:51:44 --> Helper loaded: file_helper
INFO - 2021-04-28 05:51:44 --> Helper loaded: form_helper
INFO - 2021-04-28 05:51:44 --> Helper loaded: my_helper
INFO - 2021-04-28 05:51:44 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:51:44 --> Controller Class Initialized
DEBUG - 2021-04-28 05:51:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-28 05:51:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:51:44 --> Final output sent to browser
DEBUG - 2021-04-28 05:51:44 --> Total execution time: 0.1604
INFO - 2021-04-28 05:51:45 --> Config Class Initialized
INFO - 2021-04-28 05:51:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:51:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:51:45 --> Utf8 Class Initialized
INFO - 2021-04-28 05:51:45 --> URI Class Initialized
INFO - 2021-04-28 05:51:45 --> Router Class Initialized
INFO - 2021-04-28 05:51:45 --> Output Class Initialized
INFO - 2021-04-28 05:51:45 --> Security Class Initialized
DEBUG - 2021-04-28 05:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:51:45 --> Input Class Initialized
INFO - 2021-04-28 05:51:45 --> Language Class Initialized
INFO - 2021-04-28 05:51:45 --> Language Class Initialized
INFO - 2021-04-28 05:51:45 --> Config Class Initialized
INFO - 2021-04-28 05:51:45 --> Loader Class Initialized
INFO - 2021-04-28 05:51:45 --> Helper loaded: url_helper
INFO - 2021-04-28 05:51:45 --> Helper loaded: file_helper
INFO - 2021-04-28 05:51:45 --> Helper loaded: form_helper
INFO - 2021-04-28 05:51:45 --> Helper loaded: my_helper
INFO - 2021-04-28 05:51:45 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:51:45 --> Controller Class Initialized
INFO - 2021-04-28 05:51:47 --> Config Class Initialized
INFO - 2021-04-28 05:51:47 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:51:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:51:47 --> Utf8 Class Initialized
INFO - 2021-04-28 05:51:47 --> URI Class Initialized
INFO - 2021-04-28 05:51:47 --> Router Class Initialized
INFO - 2021-04-28 05:51:47 --> Output Class Initialized
INFO - 2021-04-28 05:51:47 --> Security Class Initialized
DEBUG - 2021-04-28 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:51:47 --> Input Class Initialized
INFO - 2021-04-28 05:51:47 --> Language Class Initialized
INFO - 2021-04-28 05:51:47 --> Language Class Initialized
INFO - 2021-04-28 05:51:47 --> Config Class Initialized
INFO - 2021-04-28 05:51:47 --> Loader Class Initialized
INFO - 2021-04-28 05:51:47 --> Helper loaded: url_helper
INFO - 2021-04-28 05:51:47 --> Helper loaded: file_helper
INFO - 2021-04-28 05:51:47 --> Helper loaded: form_helper
INFO - 2021-04-28 05:51:47 --> Helper loaded: my_helper
INFO - 2021-04-28 05:51:47 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:51:47 --> Controller Class Initialized
ERROR - 2021-04-28 05:51:47 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '1'
INFO - 2021-04-28 05:51:47 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 05:51:51 --> Config Class Initialized
INFO - 2021-04-28 05:51:51 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:51:51 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:51:51 --> Utf8 Class Initialized
INFO - 2021-04-28 05:51:51 --> URI Class Initialized
INFO - 2021-04-28 05:51:51 --> Router Class Initialized
INFO - 2021-04-28 05:51:51 --> Output Class Initialized
INFO - 2021-04-28 05:51:51 --> Security Class Initialized
DEBUG - 2021-04-28 05:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:51:51 --> Input Class Initialized
INFO - 2021-04-28 05:51:51 --> Language Class Initialized
INFO - 2021-04-28 05:51:51 --> Language Class Initialized
INFO - 2021-04-28 05:51:51 --> Config Class Initialized
INFO - 2021-04-28 05:51:51 --> Loader Class Initialized
INFO - 2021-04-28 05:51:51 --> Helper loaded: url_helper
INFO - 2021-04-28 05:51:51 --> Helper loaded: file_helper
INFO - 2021-04-28 05:51:51 --> Helper loaded: form_helper
INFO - 2021-04-28 05:51:51 --> Helper loaded: my_helper
INFO - 2021-04-28 05:51:51 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:51:51 --> Controller Class Initialized
DEBUG - 2021-04-28 05:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-28 05:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:51:51 --> Final output sent to browser
DEBUG - 2021-04-28 05:51:51 --> Total execution time: 0.1202
INFO - 2021-04-28 05:51:52 --> Config Class Initialized
INFO - 2021-04-28 05:51:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:51:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:51:52 --> Utf8 Class Initialized
INFO - 2021-04-28 05:51:52 --> URI Class Initialized
INFO - 2021-04-28 05:51:52 --> Router Class Initialized
INFO - 2021-04-28 05:51:52 --> Output Class Initialized
INFO - 2021-04-28 05:51:52 --> Security Class Initialized
DEBUG - 2021-04-28 05:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:51:52 --> Input Class Initialized
INFO - 2021-04-28 05:51:52 --> Language Class Initialized
INFO - 2021-04-28 05:51:52 --> Language Class Initialized
INFO - 2021-04-28 05:51:52 --> Config Class Initialized
INFO - 2021-04-28 05:51:52 --> Loader Class Initialized
INFO - 2021-04-28 05:51:52 --> Helper loaded: url_helper
INFO - 2021-04-28 05:51:52 --> Helper loaded: file_helper
INFO - 2021-04-28 05:51:52 --> Helper loaded: form_helper
INFO - 2021-04-28 05:51:52 --> Helper loaded: my_helper
INFO - 2021-04-28 05:51:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:51:52 --> Controller Class Initialized
INFO - 2021-04-28 05:51:55 --> Config Class Initialized
INFO - 2021-04-28 05:51:55 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:51:55 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:51:55 --> Utf8 Class Initialized
INFO - 2021-04-28 05:51:55 --> URI Class Initialized
INFO - 2021-04-28 05:51:55 --> Router Class Initialized
INFO - 2021-04-28 05:51:55 --> Output Class Initialized
INFO - 2021-04-28 05:51:55 --> Security Class Initialized
DEBUG - 2021-04-28 05:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:51:55 --> Input Class Initialized
INFO - 2021-04-28 05:51:55 --> Language Class Initialized
INFO - 2021-04-28 05:51:55 --> Language Class Initialized
INFO - 2021-04-28 05:51:55 --> Config Class Initialized
INFO - 2021-04-28 05:51:55 --> Loader Class Initialized
INFO - 2021-04-28 05:51:55 --> Helper loaded: url_helper
INFO - 2021-04-28 05:51:55 --> Helper loaded: file_helper
INFO - 2021-04-28 05:51:55 --> Helper loaded: form_helper
INFO - 2021-04-28 05:51:55 --> Helper loaded: my_helper
INFO - 2021-04-28 05:51:55 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:51:55 --> Controller Class Initialized
ERROR - 2021-04-28 05:51:55 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '1'
INFO - 2021-04-28 05:51:55 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 05:53:00 --> Config Class Initialized
INFO - 2021-04-28 05:53:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:00 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:00 --> URI Class Initialized
INFO - 2021-04-28 05:53:00 --> Router Class Initialized
INFO - 2021-04-28 05:53:00 --> Output Class Initialized
INFO - 2021-04-28 05:53:00 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:00 --> Input Class Initialized
INFO - 2021-04-28 05:53:00 --> Language Class Initialized
INFO - 2021-04-28 05:53:00 --> Language Class Initialized
INFO - 2021-04-28 05:53:00 --> Config Class Initialized
INFO - 2021-04-28 05:53:00 --> Loader Class Initialized
INFO - 2021-04-28 05:53:00 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:00 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:00 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:00 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:00 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:00 --> Controller Class Initialized
DEBUG - 2021-04-28 05:53:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-28 05:53:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:53:00 --> Final output sent to browser
DEBUG - 2021-04-28 05:53:00 --> Total execution time: 0.0916
INFO - 2021-04-28 05:53:00 --> Config Class Initialized
INFO - 2021-04-28 05:53:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:00 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:00 --> URI Class Initialized
INFO - 2021-04-28 05:53:00 --> Router Class Initialized
INFO - 2021-04-28 05:53:00 --> Output Class Initialized
INFO - 2021-04-28 05:53:00 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:00 --> Input Class Initialized
INFO - 2021-04-28 05:53:00 --> Language Class Initialized
INFO - 2021-04-28 05:53:00 --> Language Class Initialized
INFO - 2021-04-28 05:53:00 --> Config Class Initialized
INFO - 2021-04-28 05:53:00 --> Loader Class Initialized
INFO - 2021-04-28 05:53:00 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:00 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:00 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:00 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:00 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:00 --> Controller Class Initialized
INFO - 2021-04-28 05:53:02 --> Config Class Initialized
INFO - 2021-04-28 05:53:02 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:02 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:02 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:02 --> URI Class Initialized
INFO - 2021-04-28 05:53:02 --> Router Class Initialized
INFO - 2021-04-28 05:53:02 --> Output Class Initialized
INFO - 2021-04-28 05:53:02 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:02 --> Input Class Initialized
INFO - 2021-04-28 05:53:02 --> Language Class Initialized
INFO - 2021-04-28 05:53:02 --> Language Class Initialized
INFO - 2021-04-28 05:53:02 --> Config Class Initialized
INFO - 2021-04-28 05:53:02 --> Loader Class Initialized
INFO - 2021-04-28 05:53:02 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:02 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:02 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:02 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:02 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:02 --> Controller Class Initialized
ERROR - 2021-04-28 05:53:02 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '1'
INFO - 2021-04-28 05:53:02 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 05:53:06 --> Config Class Initialized
INFO - 2021-04-28 05:53:06 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:06 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:06 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:06 --> URI Class Initialized
INFO - 2021-04-28 05:53:06 --> Router Class Initialized
INFO - 2021-04-28 05:53:06 --> Output Class Initialized
INFO - 2021-04-28 05:53:06 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:06 --> Input Class Initialized
INFO - 2021-04-28 05:53:06 --> Language Class Initialized
INFO - 2021-04-28 05:53:06 --> Language Class Initialized
INFO - 2021-04-28 05:53:06 --> Config Class Initialized
INFO - 2021-04-28 05:53:06 --> Loader Class Initialized
INFO - 2021-04-28 05:53:06 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:06 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:06 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:06 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:06 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:06 --> Controller Class Initialized
DEBUG - 2021-04-28 05:53:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:53:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:53:06 --> Final output sent to browser
DEBUG - 2021-04-28 05:53:06 --> Total execution time: 0.1475
INFO - 2021-04-28 05:53:07 --> Config Class Initialized
INFO - 2021-04-28 05:53:07 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:07 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:07 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:07 --> URI Class Initialized
INFO - 2021-04-28 05:53:07 --> Router Class Initialized
INFO - 2021-04-28 05:53:07 --> Output Class Initialized
INFO - 2021-04-28 05:53:07 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:07 --> Input Class Initialized
INFO - 2021-04-28 05:53:07 --> Language Class Initialized
INFO - 2021-04-28 05:53:07 --> Language Class Initialized
INFO - 2021-04-28 05:53:07 --> Config Class Initialized
INFO - 2021-04-28 05:53:07 --> Loader Class Initialized
INFO - 2021-04-28 05:53:07 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:07 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:07 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:07 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:07 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:07 --> Controller Class Initialized
DEBUG - 2021-04-28 05:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:53:07 --> Final output sent to browser
DEBUG - 2021-04-28 05:53:07 --> Total execution time: 0.1489
INFO - 2021-04-28 05:53:10 --> Config Class Initialized
INFO - 2021-04-28 05:53:10 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:10 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:10 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:10 --> URI Class Initialized
INFO - 2021-04-28 05:53:10 --> Router Class Initialized
INFO - 2021-04-28 05:53:10 --> Output Class Initialized
INFO - 2021-04-28 05:53:10 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:10 --> Input Class Initialized
INFO - 2021-04-28 05:53:10 --> Language Class Initialized
INFO - 2021-04-28 05:53:10 --> Language Class Initialized
INFO - 2021-04-28 05:53:10 --> Config Class Initialized
INFO - 2021-04-28 05:53:10 --> Loader Class Initialized
INFO - 2021-04-28 05:53:10 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:10 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:10 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:10 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:11 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:11 --> Controller Class Initialized
INFO - 2021-04-28 05:53:11 --> Config Class Initialized
INFO - 2021-04-28 05:53:11 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:11 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:11 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:11 --> URI Class Initialized
INFO - 2021-04-28 05:53:11 --> Router Class Initialized
INFO - 2021-04-28 05:53:11 --> Output Class Initialized
INFO - 2021-04-28 05:53:11 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:11 --> Input Class Initialized
INFO - 2021-04-28 05:53:11 --> Language Class Initialized
INFO - 2021-04-28 05:53:11 --> Language Class Initialized
INFO - 2021-04-28 05:53:11 --> Config Class Initialized
INFO - 2021-04-28 05:53:11 --> Loader Class Initialized
INFO - 2021-04-28 05:53:11 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:11 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:11 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:11 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:11 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:11 --> Controller Class Initialized
DEBUG - 2021-04-28 05:53:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:53:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:53:11 --> Final output sent to browser
DEBUG - 2021-04-28 05:53:11 --> Total execution time: 0.1238
INFO - 2021-04-28 05:53:12 --> Config Class Initialized
INFO - 2021-04-28 05:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:12 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:12 --> URI Class Initialized
INFO - 2021-04-28 05:53:12 --> Router Class Initialized
INFO - 2021-04-28 05:53:12 --> Output Class Initialized
INFO - 2021-04-28 05:53:12 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:12 --> Input Class Initialized
INFO - 2021-04-28 05:53:12 --> Language Class Initialized
INFO - 2021-04-28 05:53:12 --> Language Class Initialized
INFO - 2021-04-28 05:53:12 --> Config Class Initialized
INFO - 2021-04-28 05:53:12 --> Loader Class Initialized
INFO - 2021-04-28 05:53:12 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:12 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:12 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:12 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:12 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:12 --> Controller Class Initialized
DEBUG - 2021-04-28 05:53:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 05:53:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:53:12 --> Final output sent to browser
DEBUG - 2021-04-28 05:53:12 --> Total execution time: 0.1236
INFO - 2021-04-28 05:53:14 --> Config Class Initialized
INFO - 2021-04-28 05:53:14 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:14 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:14 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:14 --> URI Class Initialized
INFO - 2021-04-28 05:53:14 --> Router Class Initialized
INFO - 2021-04-28 05:53:14 --> Output Class Initialized
INFO - 2021-04-28 05:53:14 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:14 --> Input Class Initialized
INFO - 2021-04-28 05:53:14 --> Language Class Initialized
INFO - 2021-04-28 05:53:14 --> Language Class Initialized
INFO - 2021-04-28 05:53:14 --> Config Class Initialized
INFO - 2021-04-28 05:53:14 --> Loader Class Initialized
INFO - 2021-04-28 05:53:14 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:14 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:14 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:14 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:14 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:14 --> Controller Class Initialized
DEBUG - 2021-04-28 05:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:53:14 --> Final output sent to browser
DEBUG - 2021-04-28 05:53:14 --> Total execution time: 0.1347
INFO - 2021-04-28 05:53:17 --> Config Class Initialized
INFO - 2021-04-28 05:53:17 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:17 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:17 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:17 --> URI Class Initialized
INFO - 2021-04-28 05:53:17 --> Router Class Initialized
INFO - 2021-04-28 05:53:17 --> Output Class Initialized
INFO - 2021-04-28 05:53:17 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:17 --> Input Class Initialized
INFO - 2021-04-28 05:53:17 --> Language Class Initialized
INFO - 2021-04-28 05:53:17 --> Language Class Initialized
INFO - 2021-04-28 05:53:17 --> Config Class Initialized
INFO - 2021-04-28 05:53:17 --> Loader Class Initialized
INFO - 2021-04-28 05:53:17 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:17 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:17 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:17 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:17 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:17 --> Controller Class Initialized
INFO - 2021-04-28 05:53:17 --> Final output sent to browser
DEBUG - 2021-04-28 05:53:17 --> Total execution time: 0.1231
INFO - 2021-04-28 05:53:19 --> Config Class Initialized
INFO - 2021-04-28 05:53:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:19 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:19 --> URI Class Initialized
INFO - 2021-04-28 05:53:19 --> Router Class Initialized
INFO - 2021-04-28 05:53:19 --> Output Class Initialized
INFO - 2021-04-28 05:53:19 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:19 --> Input Class Initialized
INFO - 2021-04-28 05:53:19 --> Language Class Initialized
INFO - 2021-04-28 05:53:19 --> Language Class Initialized
INFO - 2021-04-28 05:53:19 --> Config Class Initialized
INFO - 2021-04-28 05:53:19 --> Loader Class Initialized
INFO - 2021-04-28 05:53:19 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:19 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:19 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:19 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:19 --> Controller Class Initialized
DEBUG - 2021-04-28 05:53:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-28 05:53:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:53:19 --> Final output sent to browser
DEBUG - 2021-04-28 05:53:19 --> Total execution time: 0.1190
INFO - 2021-04-28 05:53:19 --> Config Class Initialized
INFO - 2021-04-28 05:53:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:53:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:53:19 --> Utf8 Class Initialized
INFO - 2021-04-28 05:53:19 --> URI Class Initialized
INFO - 2021-04-28 05:53:19 --> Router Class Initialized
INFO - 2021-04-28 05:53:19 --> Output Class Initialized
INFO - 2021-04-28 05:53:19 --> Security Class Initialized
DEBUG - 2021-04-28 05:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:53:19 --> Input Class Initialized
INFO - 2021-04-28 05:53:19 --> Language Class Initialized
INFO - 2021-04-28 05:53:19 --> Language Class Initialized
INFO - 2021-04-28 05:53:19 --> Config Class Initialized
INFO - 2021-04-28 05:53:19 --> Loader Class Initialized
INFO - 2021-04-28 05:53:19 --> Helper loaded: url_helper
INFO - 2021-04-28 05:53:19 --> Helper loaded: file_helper
INFO - 2021-04-28 05:53:19 --> Helper loaded: form_helper
INFO - 2021-04-28 05:53:19 --> Helper loaded: my_helper
INFO - 2021-04-28 05:53:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:53:19 --> Controller Class Initialized
INFO - 2021-04-28 05:54:51 --> Config Class Initialized
INFO - 2021-04-28 05:54:51 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:54:51 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:54:51 --> Utf8 Class Initialized
INFO - 2021-04-28 05:54:51 --> URI Class Initialized
INFO - 2021-04-28 05:54:51 --> Router Class Initialized
INFO - 2021-04-28 05:54:51 --> Output Class Initialized
INFO - 2021-04-28 05:54:51 --> Security Class Initialized
DEBUG - 2021-04-28 05:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:54:51 --> Input Class Initialized
INFO - 2021-04-28 05:54:51 --> Language Class Initialized
INFO - 2021-04-28 05:54:51 --> Language Class Initialized
INFO - 2021-04-28 05:54:51 --> Config Class Initialized
INFO - 2021-04-28 05:54:51 --> Loader Class Initialized
INFO - 2021-04-28 05:54:51 --> Helper loaded: url_helper
INFO - 2021-04-28 05:54:51 --> Helper loaded: file_helper
INFO - 2021-04-28 05:54:51 --> Helper loaded: form_helper
INFO - 2021-04-28 05:54:51 --> Helper loaded: my_helper
INFO - 2021-04-28 05:54:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:54:52 --> Controller Class Initialized
ERROR - 2021-04-28 05:54:52 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '1'
INFO - 2021-04-28 05:54:52 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 05:54:52 --> Config Class Initialized
INFO - 2021-04-28 05:54:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:54:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:54:52 --> Utf8 Class Initialized
INFO - 2021-04-28 05:54:52 --> URI Class Initialized
INFO - 2021-04-28 05:54:52 --> Router Class Initialized
INFO - 2021-04-28 05:54:52 --> Output Class Initialized
INFO - 2021-04-28 05:54:52 --> Security Class Initialized
DEBUG - 2021-04-28 05:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:54:53 --> Input Class Initialized
INFO - 2021-04-28 05:54:53 --> Language Class Initialized
INFO - 2021-04-28 05:54:53 --> Language Class Initialized
INFO - 2021-04-28 05:54:53 --> Config Class Initialized
INFO - 2021-04-28 05:54:53 --> Loader Class Initialized
INFO - 2021-04-28 05:54:53 --> Helper loaded: url_helper
INFO - 2021-04-28 05:54:53 --> Helper loaded: file_helper
INFO - 2021-04-28 05:54:53 --> Helper loaded: form_helper
INFO - 2021-04-28 05:54:53 --> Helper loaded: my_helper
INFO - 2021-04-28 05:54:53 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:54:53 --> Controller Class Initialized
INFO - 2021-04-28 05:54:53 --> Final output sent to browser
DEBUG - 2021-04-28 05:54:53 --> Total execution time: 0.1300
INFO - 2021-04-28 05:55:39 --> Config Class Initialized
INFO - 2021-04-28 05:55:39 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:39 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:39 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:39 --> URI Class Initialized
INFO - 2021-04-28 05:55:39 --> Router Class Initialized
INFO - 2021-04-28 05:55:39 --> Output Class Initialized
INFO - 2021-04-28 05:55:39 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:39 --> Input Class Initialized
INFO - 2021-04-28 05:55:39 --> Language Class Initialized
INFO - 2021-04-28 05:55:39 --> Language Class Initialized
INFO - 2021-04-28 05:55:39 --> Config Class Initialized
INFO - 2021-04-28 05:55:39 --> Loader Class Initialized
INFO - 2021-04-28 05:55:39 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:39 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:39 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:39 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:39 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:39 --> Controller Class Initialized
DEBUG - 2021-04-28 05:55:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-28 05:55:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:55:39 --> Final output sent to browser
DEBUG - 2021-04-28 05:55:39 --> Total execution time: 0.1313
INFO - 2021-04-28 05:55:40 --> Config Class Initialized
INFO - 2021-04-28 05:55:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:40 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:40 --> URI Class Initialized
INFO - 2021-04-28 05:55:40 --> Router Class Initialized
INFO - 2021-04-28 05:55:40 --> Output Class Initialized
INFO - 2021-04-28 05:55:40 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:40 --> Input Class Initialized
INFO - 2021-04-28 05:55:40 --> Language Class Initialized
INFO - 2021-04-28 05:55:40 --> Language Class Initialized
INFO - 2021-04-28 05:55:40 --> Config Class Initialized
INFO - 2021-04-28 05:55:40 --> Loader Class Initialized
INFO - 2021-04-28 05:55:40 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:40 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:40 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:40 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:40 --> Controller Class Initialized
INFO - 2021-04-28 05:55:41 --> Config Class Initialized
INFO - 2021-04-28 05:55:41 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:41 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:41 --> URI Class Initialized
INFO - 2021-04-28 05:55:41 --> Router Class Initialized
INFO - 2021-04-28 05:55:41 --> Output Class Initialized
INFO - 2021-04-28 05:55:41 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:41 --> Input Class Initialized
INFO - 2021-04-28 05:55:41 --> Language Class Initialized
INFO - 2021-04-28 05:55:41 --> Language Class Initialized
INFO - 2021-04-28 05:55:41 --> Config Class Initialized
INFO - 2021-04-28 05:55:41 --> Loader Class Initialized
INFO - 2021-04-28 05:55:41 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:41 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:41 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:41 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:41 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:41 --> Controller Class Initialized
INFO - 2021-04-28 05:55:41 --> Final output sent to browser
DEBUG - 2021-04-28 05:55:41 --> Total execution time: 0.1368
INFO - 2021-04-28 05:55:46 --> Config Class Initialized
INFO - 2021-04-28 05:55:46 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:46 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:46 --> URI Class Initialized
INFO - 2021-04-28 05:55:46 --> Router Class Initialized
INFO - 2021-04-28 05:55:46 --> Output Class Initialized
INFO - 2021-04-28 05:55:46 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:46 --> Input Class Initialized
INFO - 2021-04-28 05:55:46 --> Language Class Initialized
INFO - 2021-04-28 05:55:46 --> Language Class Initialized
INFO - 2021-04-28 05:55:46 --> Config Class Initialized
INFO - 2021-04-28 05:55:46 --> Loader Class Initialized
INFO - 2021-04-28 05:55:46 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:46 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:46 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:46 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:46 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:46 --> Controller Class Initialized
INFO - 2021-04-28 05:55:46 --> Final output sent to browser
DEBUG - 2021-04-28 05:55:46 --> Total execution time: 0.1377
INFO - 2021-04-28 05:55:50 --> Config Class Initialized
INFO - 2021-04-28 05:55:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:50 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:50 --> URI Class Initialized
INFO - 2021-04-28 05:55:50 --> Router Class Initialized
INFO - 2021-04-28 05:55:50 --> Output Class Initialized
INFO - 2021-04-28 05:55:50 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:50 --> Input Class Initialized
INFO - 2021-04-28 05:55:50 --> Language Class Initialized
INFO - 2021-04-28 05:55:50 --> Language Class Initialized
INFO - 2021-04-28 05:55:50 --> Config Class Initialized
INFO - 2021-04-28 05:55:50 --> Loader Class Initialized
INFO - 2021-04-28 05:55:50 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:50 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:50 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:50 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:50 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:50 --> Controller Class Initialized
INFO - 2021-04-28 05:55:50 --> Final output sent to browser
DEBUG - 2021-04-28 05:55:50 --> Total execution time: 0.1497
INFO - 2021-04-28 05:55:50 --> Config Class Initialized
INFO - 2021-04-28 05:55:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:50 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:50 --> URI Class Initialized
INFO - 2021-04-28 05:55:50 --> Router Class Initialized
INFO - 2021-04-28 05:55:50 --> Output Class Initialized
INFO - 2021-04-28 05:55:50 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:50 --> Input Class Initialized
INFO - 2021-04-28 05:55:50 --> Language Class Initialized
INFO - 2021-04-28 05:55:50 --> Language Class Initialized
INFO - 2021-04-28 05:55:50 --> Config Class Initialized
INFO - 2021-04-28 05:55:50 --> Loader Class Initialized
INFO - 2021-04-28 05:55:50 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:50 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:50 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:50 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:50 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:50 --> Controller Class Initialized
INFO - 2021-04-28 05:55:52 --> Config Class Initialized
INFO - 2021-04-28 05:55:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:52 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:52 --> URI Class Initialized
INFO - 2021-04-28 05:55:52 --> Router Class Initialized
INFO - 2021-04-28 05:55:52 --> Output Class Initialized
INFO - 2021-04-28 05:55:52 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:52 --> Input Class Initialized
INFO - 2021-04-28 05:55:52 --> Language Class Initialized
INFO - 2021-04-28 05:55:52 --> Language Class Initialized
INFO - 2021-04-28 05:55:52 --> Config Class Initialized
INFO - 2021-04-28 05:55:52 --> Loader Class Initialized
INFO - 2021-04-28 05:55:52 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:52 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:52 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:52 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:52 --> Controller Class Initialized
DEBUG - 2021-04-28 05:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-28 05:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:55:52 --> Final output sent to browser
DEBUG - 2021-04-28 05:55:52 --> Total execution time: 0.1405
INFO - 2021-04-28 05:55:52 --> Config Class Initialized
INFO - 2021-04-28 05:55:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:52 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:52 --> URI Class Initialized
INFO - 2021-04-28 05:55:52 --> Router Class Initialized
INFO - 2021-04-28 05:55:52 --> Output Class Initialized
INFO - 2021-04-28 05:55:52 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:52 --> Input Class Initialized
INFO - 2021-04-28 05:55:52 --> Language Class Initialized
INFO - 2021-04-28 05:55:53 --> Language Class Initialized
INFO - 2021-04-28 05:55:53 --> Config Class Initialized
INFO - 2021-04-28 05:55:53 --> Loader Class Initialized
INFO - 2021-04-28 05:55:53 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:53 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:53 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:53 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:53 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:53 --> Controller Class Initialized
INFO - 2021-04-28 05:55:57 --> Config Class Initialized
INFO - 2021-04-28 05:55:57 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:57 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:57 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:57 --> URI Class Initialized
INFO - 2021-04-28 05:55:57 --> Router Class Initialized
INFO - 2021-04-28 05:55:57 --> Output Class Initialized
INFO - 2021-04-28 05:55:57 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:57 --> Input Class Initialized
INFO - 2021-04-28 05:55:57 --> Language Class Initialized
INFO - 2021-04-28 05:55:57 --> Language Class Initialized
INFO - 2021-04-28 05:55:57 --> Config Class Initialized
INFO - 2021-04-28 05:55:57 --> Loader Class Initialized
INFO - 2021-04-28 05:55:57 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:57 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:57 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:57 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:57 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:57 --> Controller Class Initialized
DEBUG - 2021-04-28 05:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 05:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:55:57 --> Final output sent to browser
DEBUG - 2021-04-28 05:55:57 --> Total execution time: 0.1351
INFO - 2021-04-28 05:55:59 --> Config Class Initialized
INFO - 2021-04-28 05:55:59 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:59 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:59 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:59 --> URI Class Initialized
INFO - 2021-04-28 05:55:59 --> Router Class Initialized
INFO - 2021-04-28 05:55:59 --> Output Class Initialized
INFO - 2021-04-28 05:55:59 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:59 --> Input Class Initialized
INFO - 2021-04-28 05:55:59 --> Language Class Initialized
INFO - 2021-04-28 05:55:59 --> Language Class Initialized
INFO - 2021-04-28 05:55:59 --> Config Class Initialized
INFO - 2021-04-28 05:55:59 --> Loader Class Initialized
INFO - 2021-04-28 05:55:59 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:59 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:59 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:59 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:59 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:59 --> Controller Class Initialized
DEBUG - 2021-04-28 05:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-28 05:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:55:59 --> Final output sent to browser
DEBUG - 2021-04-28 05:55:59 --> Total execution time: 0.1379
INFO - 2021-04-28 05:55:59 --> Config Class Initialized
INFO - 2021-04-28 05:55:59 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:55:59 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:55:59 --> Utf8 Class Initialized
INFO - 2021-04-28 05:55:59 --> URI Class Initialized
INFO - 2021-04-28 05:55:59 --> Router Class Initialized
INFO - 2021-04-28 05:55:59 --> Output Class Initialized
INFO - 2021-04-28 05:55:59 --> Security Class Initialized
DEBUG - 2021-04-28 05:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:55:59 --> Input Class Initialized
INFO - 2021-04-28 05:55:59 --> Language Class Initialized
INFO - 2021-04-28 05:55:59 --> Language Class Initialized
INFO - 2021-04-28 05:55:59 --> Config Class Initialized
INFO - 2021-04-28 05:55:59 --> Loader Class Initialized
INFO - 2021-04-28 05:55:59 --> Helper loaded: url_helper
INFO - 2021-04-28 05:55:59 --> Helper loaded: file_helper
INFO - 2021-04-28 05:55:59 --> Helper loaded: form_helper
INFO - 2021-04-28 05:55:59 --> Helper loaded: my_helper
INFO - 2021-04-28 05:55:59 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:55:59 --> Controller Class Initialized
INFO - 2021-04-28 05:56:01 --> Config Class Initialized
INFO - 2021-04-28 05:56:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:01 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:01 --> URI Class Initialized
INFO - 2021-04-28 05:56:01 --> Router Class Initialized
INFO - 2021-04-28 05:56:01 --> Output Class Initialized
INFO - 2021-04-28 05:56:01 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:01 --> Input Class Initialized
INFO - 2021-04-28 05:56:01 --> Language Class Initialized
INFO - 2021-04-28 05:56:01 --> Language Class Initialized
INFO - 2021-04-28 05:56:01 --> Config Class Initialized
INFO - 2021-04-28 05:56:01 --> Loader Class Initialized
INFO - 2021-04-28 05:56:01 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:01 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:01 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:01 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:01 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:01 --> Controller Class Initialized
INFO - 2021-04-28 05:56:01 --> Final output sent to browser
DEBUG - 2021-04-28 05:56:01 --> Total execution time: 0.1514
INFO - 2021-04-28 05:56:01 --> Config Class Initialized
INFO - 2021-04-28 05:56:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:01 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:01 --> URI Class Initialized
INFO - 2021-04-28 05:56:01 --> Router Class Initialized
INFO - 2021-04-28 05:56:01 --> Output Class Initialized
INFO - 2021-04-28 05:56:01 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:01 --> Input Class Initialized
INFO - 2021-04-28 05:56:01 --> Language Class Initialized
INFO - 2021-04-28 05:56:01 --> Language Class Initialized
INFO - 2021-04-28 05:56:01 --> Config Class Initialized
INFO - 2021-04-28 05:56:01 --> Loader Class Initialized
INFO - 2021-04-28 05:56:01 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:01 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:01 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:01 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:01 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:01 --> Controller Class Initialized
INFO - 2021-04-28 05:56:04 --> Config Class Initialized
INFO - 2021-04-28 05:56:04 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:04 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:04 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:04 --> URI Class Initialized
INFO - 2021-04-28 05:56:04 --> Router Class Initialized
INFO - 2021-04-28 05:56:04 --> Output Class Initialized
INFO - 2021-04-28 05:56:04 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:04 --> Input Class Initialized
INFO - 2021-04-28 05:56:04 --> Language Class Initialized
INFO - 2021-04-28 05:56:04 --> Language Class Initialized
INFO - 2021-04-28 05:56:04 --> Config Class Initialized
INFO - 2021-04-28 05:56:04 --> Loader Class Initialized
INFO - 2021-04-28 05:56:04 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:04 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:04 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:04 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:04 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:04 --> Controller Class Initialized
DEBUG - 2021-04-28 05:56:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-28 05:56:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 05:56:04 --> Final output sent to browser
DEBUG - 2021-04-28 05:56:04 --> Total execution time: 0.1318
INFO - 2021-04-28 05:56:05 --> Config Class Initialized
INFO - 2021-04-28 05:56:05 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:05 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:05 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:05 --> URI Class Initialized
INFO - 2021-04-28 05:56:05 --> Router Class Initialized
INFO - 2021-04-28 05:56:05 --> Output Class Initialized
INFO - 2021-04-28 05:56:05 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:05 --> Input Class Initialized
INFO - 2021-04-28 05:56:05 --> Language Class Initialized
INFO - 2021-04-28 05:56:05 --> Language Class Initialized
INFO - 2021-04-28 05:56:05 --> Config Class Initialized
INFO - 2021-04-28 05:56:05 --> Loader Class Initialized
INFO - 2021-04-28 05:56:05 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:05 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:05 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:05 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:05 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:05 --> Controller Class Initialized
INFO - 2021-04-28 05:56:06 --> Config Class Initialized
INFO - 2021-04-28 05:56:06 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:06 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:06 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:06 --> URI Class Initialized
INFO - 2021-04-28 05:56:06 --> Router Class Initialized
INFO - 2021-04-28 05:56:07 --> Output Class Initialized
INFO - 2021-04-28 05:56:07 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:07 --> Input Class Initialized
INFO - 2021-04-28 05:56:07 --> Language Class Initialized
INFO - 2021-04-28 05:56:07 --> Language Class Initialized
INFO - 2021-04-28 05:56:07 --> Config Class Initialized
INFO - 2021-04-28 05:56:07 --> Loader Class Initialized
INFO - 2021-04-28 05:56:07 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:07 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:07 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:07 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:07 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:07 --> Controller Class Initialized
INFO - 2021-04-28 05:56:07 --> Final output sent to browser
DEBUG - 2021-04-28 05:56:07 --> Total execution time: 0.1532
INFO - 2021-04-28 05:56:07 --> Config Class Initialized
INFO - 2021-04-28 05:56:07 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:07 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:07 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:07 --> URI Class Initialized
INFO - 2021-04-28 05:56:07 --> Router Class Initialized
INFO - 2021-04-28 05:56:07 --> Output Class Initialized
INFO - 2021-04-28 05:56:07 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:07 --> Input Class Initialized
INFO - 2021-04-28 05:56:07 --> Language Class Initialized
INFO - 2021-04-28 05:56:07 --> Language Class Initialized
INFO - 2021-04-28 05:56:07 --> Config Class Initialized
INFO - 2021-04-28 05:56:07 --> Loader Class Initialized
INFO - 2021-04-28 05:56:07 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:07 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:07 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:07 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:07 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:07 --> Controller Class Initialized
INFO - 2021-04-28 05:56:09 --> Config Class Initialized
INFO - 2021-04-28 05:56:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:09 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:09 --> URI Class Initialized
INFO - 2021-04-28 05:56:09 --> Router Class Initialized
INFO - 2021-04-28 05:56:09 --> Output Class Initialized
INFO - 2021-04-28 05:56:09 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:09 --> Input Class Initialized
INFO - 2021-04-28 05:56:09 --> Language Class Initialized
INFO - 2021-04-28 05:56:09 --> Language Class Initialized
INFO - 2021-04-28 05:56:09 --> Config Class Initialized
INFO - 2021-04-28 05:56:09 --> Loader Class Initialized
INFO - 2021-04-28 05:56:09 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:09 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:09 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:09 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:09 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:09 --> Controller Class Initialized
INFO - 2021-04-28 05:56:09 --> Final output sent to browser
DEBUG - 2021-04-28 05:56:09 --> Total execution time: 0.1608
INFO - 2021-04-28 05:56:13 --> Config Class Initialized
INFO - 2021-04-28 05:56:13 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:13 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:13 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:13 --> URI Class Initialized
INFO - 2021-04-28 05:56:13 --> Router Class Initialized
INFO - 2021-04-28 05:56:13 --> Output Class Initialized
INFO - 2021-04-28 05:56:13 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:13 --> Input Class Initialized
INFO - 2021-04-28 05:56:13 --> Language Class Initialized
INFO - 2021-04-28 05:56:13 --> Language Class Initialized
INFO - 2021-04-28 05:56:13 --> Config Class Initialized
INFO - 2021-04-28 05:56:13 --> Loader Class Initialized
INFO - 2021-04-28 05:56:13 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:13 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:13 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:13 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:13 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:13 --> Controller Class Initialized
INFO - 2021-04-28 05:56:13 --> Final output sent to browser
DEBUG - 2021-04-28 05:56:13 --> Total execution time: 0.0998
INFO - 2021-04-28 05:56:13 --> Config Class Initialized
INFO - 2021-04-28 05:56:13 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:13 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:13 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:13 --> URI Class Initialized
INFO - 2021-04-28 05:56:13 --> Router Class Initialized
INFO - 2021-04-28 05:56:13 --> Output Class Initialized
INFO - 2021-04-28 05:56:13 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:13 --> Input Class Initialized
INFO - 2021-04-28 05:56:13 --> Language Class Initialized
INFO - 2021-04-28 05:56:13 --> Language Class Initialized
INFO - 2021-04-28 05:56:13 --> Config Class Initialized
INFO - 2021-04-28 05:56:13 --> Loader Class Initialized
INFO - 2021-04-28 05:56:13 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:13 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:13 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:13 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:13 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:14 --> Controller Class Initialized
INFO - 2021-04-28 05:56:16 --> Config Class Initialized
INFO - 2021-04-28 05:56:16 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:16 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:16 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:16 --> URI Class Initialized
INFO - 2021-04-28 05:56:16 --> Router Class Initialized
INFO - 2021-04-28 05:56:16 --> Output Class Initialized
INFO - 2021-04-28 05:56:16 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:16 --> Input Class Initialized
INFO - 2021-04-28 05:56:16 --> Language Class Initialized
INFO - 2021-04-28 05:56:16 --> Language Class Initialized
INFO - 2021-04-28 05:56:16 --> Config Class Initialized
INFO - 2021-04-28 05:56:16 --> Loader Class Initialized
INFO - 2021-04-28 05:56:16 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:16 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:16 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:16 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:16 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:16 --> Controller Class Initialized
INFO - 2021-04-28 05:56:16 --> Final output sent to browser
DEBUG - 2021-04-28 05:56:16 --> Total execution time: 0.1316
INFO - 2021-04-28 05:56:16 --> Config Class Initialized
INFO - 2021-04-28 05:56:16 --> Hooks Class Initialized
DEBUG - 2021-04-28 05:56:16 --> UTF-8 Support Enabled
INFO - 2021-04-28 05:56:16 --> Utf8 Class Initialized
INFO - 2021-04-28 05:56:16 --> URI Class Initialized
INFO - 2021-04-28 05:56:16 --> Router Class Initialized
INFO - 2021-04-28 05:56:16 --> Output Class Initialized
INFO - 2021-04-28 05:56:16 --> Security Class Initialized
DEBUG - 2021-04-28 05:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 05:56:16 --> Input Class Initialized
INFO - 2021-04-28 05:56:16 --> Language Class Initialized
INFO - 2021-04-28 05:56:16 --> Language Class Initialized
INFO - 2021-04-28 05:56:16 --> Config Class Initialized
INFO - 2021-04-28 05:56:16 --> Loader Class Initialized
INFO - 2021-04-28 05:56:16 --> Helper loaded: url_helper
INFO - 2021-04-28 05:56:16 --> Helper loaded: file_helper
INFO - 2021-04-28 05:56:16 --> Helper loaded: form_helper
INFO - 2021-04-28 05:56:16 --> Helper loaded: my_helper
INFO - 2021-04-28 05:56:16 --> Database Driver Class Initialized
DEBUG - 2021-04-28 05:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 05:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 05:56:16 --> Controller Class Initialized
INFO - 2021-04-28 06:34:56 --> Config Class Initialized
INFO - 2021-04-28 06:34:56 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:34:56 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:34:56 --> Utf8 Class Initialized
INFO - 2021-04-28 06:34:56 --> URI Class Initialized
DEBUG - 2021-04-28 06:34:56 --> No URI present. Default controller set.
INFO - 2021-04-28 06:34:56 --> Router Class Initialized
INFO - 2021-04-28 06:34:56 --> Output Class Initialized
INFO - 2021-04-28 06:34:56 --> Security Class Initialized
DEBUG - 2021-04-28 06:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:34:56 --> Input Class Initialized
INFO - 2021-04-28 06:34:56 --> Language Class Initialized
INFO - 2021-04-28 06:34:56 --> Language Class Initialized
INFO - 2021-04-28 06:34:56 --> Config Class Initialized
INFO - 2021-04-28 06:34:56 --> Loader Class Initialized
INFO - 2021-04-28 06:34:56 --> Helper loaded: url_helper
INFO - 2021-04-28 06:34:56 --> Helper loaded: file_helper
INFO - 2021-04-28 06:34:56 --> Helper loaded: form_helper
INFO - 2021-04-28 06:34:56 --> Helper loaded: my_helper
INFO - 2021-04-28 06:34:56 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:34:56 --> Controller Class Initialized
INFO - 2021-04-28 06:34:56 --> Config Class Initialized
INFO - 2021-04-28 06:34:56 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:34:56 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:34:56 --> Utf8 Class Initialized
INFO - 2021-04-28 06:34:56 --> URI Class Initialized
INFO - 2021-04-28 06:34:56 --> Router Class Initialized
INFO - 2021-04-28 06:34:56 --> Output Class Initialized
INFO - 2021-04-28 06:34:56 --> Security Class Initialized
DEBUG - 2021-04-28 06:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:34:56 --> Input Class Initialized
INFO - 2021-04-28 06:34:56 --> Language Class Initialized
INFO - 2021-04-28 06:34:56 --> Language Class Initialized
INFO - 2021-04-28 06:34:56 --> Config Class Initialized
INFO - 2021-04-28 06:34:56 --> Loader Class Initialized
INFO - 2021-04-28 06:34:56 --> Helper loaded: url_helper
INFO - 2021-04-28 06:34:56 --> Helper loaded: file_helper
INFO - 2021-04-28 06:34:56 --> Helper loaded: form_helper
INFO - 2021-04-28 06:34:56 --> Helper loaded: my_helper
INFO - 2021-04-28 06:34:56 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:34:56 --> Controller Class Initialized
DEBUG - 2021-04-28 06:34:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 06:34:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:34:56 --> Final output sent to browser
DEBUG - 2021-04-28 06:34:56 --> Total execution time: 0.0481
INFO - 2021-04-28 06:35:02 --> Config Class Initialized
INFO - 2021-04-28 06:35:02 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:02 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:02 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:02 --> URI Class Initialized
INFO - 2021-04-28 06:35:02 --> Router Class Initialized
INFO - 2021-04-28 06:35:02 --> Output Class Initialized
INFO - 2021-04-28 06:35:02 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:02 --> Input Class Initialized
INFO - 2021-04-28 06:35:02 --> Language Class Initialized
INFO - 2021-04-28 06:35:02 --> Language Class Initialized
INFO - 2021-04-28 06:35:02 --> Config Class Initialized
INFO - 2021-04-28 06:35:02 --> Loader Class Initialized
INFO - 2021-04-28 06:35:02 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:02 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:02 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:02 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:02 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:02 --> Controller Class Initialized
INFO - 2021-04-28 06:35:02 --> Helper loaded: cookie_helper
INFO - 2021-04-28 06:35:02 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:02 --> Total execution time: 0.0789
INFO - 2021-04-28 06:35:04 --> Config Class Initialized
INFO - 2021-04-28 06:35:04 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:04 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:04 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:04 --> URI Class Initialized
INFO - 2021-04-28 06:35:04 --> Router Class Initialized
INFO - 2021-04-28 06:35:04 --> Output Class Initialized
INFO - 2021-04-28 06:35:04 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:04 --> Input Class Initialized
INFO - 2021-04-28 06:35:04 --> Language Class Initialized
INFO - 2021-04-28 06:35:04 --> Language Class Initialized
INFO - 2021-04-28 06:35:04 --> Config Class Initialized
INFO - 2021-04-28 06:35:04 --> Loader Class Initialized
INFO - 2021-04-28 06:35:04 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:04 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:04 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:04 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:04 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:04 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 06:35:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:04 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:04 --> Total execution time: 0.1240
INFO - 2021-04-28 06:35:06 --> Config Class Initialized
INFO - 2021-04-28 06:35:06 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:06 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:06 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:06 --> URI Class Initialized
INFO - 2021-04-28 06:35:06 --> Router Class Initialized
INFO - 2021-04-28 06:35:06 --> Output Class Initialized
INFO - 2021-04-28 06:35:06 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:06 --> Input Class Initialized
INFO - 2021-04-28 06:35:06 --> Language Class Initialized
INFO - 2021-04-28 06:35:06 --> Language Class Initialized
INFO - 2021-04-28 06:35:06 --> Config Class Initialized
INFO - 2021-04-28 06:35:06 --> Loader Class Initialized
INFO - 2021-04-28 06:35:06 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:06 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:06 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:06 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:06 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:06 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-28 06:35:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:06 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:06 --> Total execution time: 0.0693
INFO - 2021-04-28 06:35:06 --> Config Class Initialized
INFO - 2021-04-28 06:35:06 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:06 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:06 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:06 --> URI Class Initialized
INFO - 2021-04-28 06:35:06 --> Router Class Initialized
INFO - 2021-04-28 06:35:06 --> Output Class Initialized
INFO - 2021-04-28 06:35:06 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:06 --> Input Class Initialized
INFO - 2021-04-28 06:35:06 --> Language Class Initialized
INFO - 2021-04-28 06:35:06 --> Language Class Initialized
INFO - 2021-04-28 06:35:06 --> Config Class Initialized
INFO - 2021-04-28 06:35:06 --> Loader Class Initialized
INFO - 2021-04-28 06:35:06 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:06 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:06 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:06 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:06 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:06 --> Controller Class Initialized
INFO - 2021-04-28 06:35:08 --> Config Class Initialized
INFO - 2021-04-28 06:35:08 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:08 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:08 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:08 --> URI Class Initialized
INFO - 2021-04-28 06:35:08 --> Router Class Initialized
INFO - 2021-04-28 06:35:08 --> Output Class Initialized
INFO - 2021-04-28 06:35:08 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:08 --> Input Class Initialized
INFO - 2021-04-28 06:35:08 --> Language Class Initialized
INFO - 2021-04-28 06:35:08 --> Language Class Initialized
INFO - 2021-04-28 06:35:08 --> Config Class Initialized
INFO - 2021-04-28 06:35:08 --> Loader Class Initialized
INFO - 2021-04-28 06:35:08 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:08 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:08 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2021-04-28 06:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:08 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:08 --> Total execution time: 0.0694
INFO - 2021-04-28 06:35:08 --> Config Class Initialized
INFO - 2021-04-28 06:35:08 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:08 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:08 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:08 --> URI Class Initialized
INFO - 2021-04-28 06:35:08 --> Router Class Initialized
INFO - 2021-04-28 06:35:08 --> Output Class Initialized
INFO - 2021-04-28 06:35:08 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:08 --> Input Class Initialized
INFO - 2021-04-28 06:35:08 --> Language Class Initialized
INFO - 2021-04-28 06:35:08 --> Language Class Initialized
INFO - 2021-04-28 06:35:08 --> Config Class Initialized
INFO - 2021-04-28 06:35:08 --> Loader Class Initialized
INFO - 2021-04-28 06:35:08 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:08 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:08 --> Controller Class Initialized
INFO - 2021-04-28 06:35:08 --> Config Class Initialized
INFO - 2021-04-28 06:35:08 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:08 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:08 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:08 --> URI Class Initialized
INFO - 2021-04-28 06:35:08 --> Router Class Initialized
INFO - 2021-04-28 06:35:08 --> Output Class Initialized
INFO - 2021-04-28 06:35:08 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:08 --> Input Class Initialized
INFO - 2021-04-28 06:35:08 --> Language Class Initialized
INFO - 2021-04-28 06:35:08 --> Language Class Initialized
INFO - 2021-04-28 06:35:08 --> Config Class Initialized
INFO - 2021-04-28 06:35:08 --> Loader Class Initialized
INFO - 2021-04-28 06:35:08 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:08 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:08 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-28 06:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:08 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:08 --> Total execution time: 0.0722
INFO - 2021-04-28 06:35:08 --> Config Class Initialized
INFO - 2021-04-28 06:35:08 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:08 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:08 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:08 --> URI Class Initialized
INFO - 2021-04-28 06:35:08 --> Router Class Initialized
INFO - 2021-04-28 06:35:08 --> Output Class Initialized
INFO - 2021-04-28 06:35:08 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:08 --> Input Class Initialized
INFO - 2021-04-28 06:35:08 --> Language Class Initialized
INFO - 2021-04-28 06:35:08 --> Language Class Initialized
INFO - 2021-04-28 06:35:08 --> Config Class Initialized
INFO - 2021-04-28 06:35:08 --> Loader Class Initialized
INFO - 2021-04-28 06:35:08 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:08 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:08 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:08 --> Controller Class Initialized
INFO - 2021-04-28 06:35:09 --> Config Class Initialized
INFO - 2021-04-28 06:35:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:09 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:09 --> URI Class Initialized
INFO - 2021-04-28 06:35:09 --> Router Class Initialized
INFO - 2021-04-28 06:35:09 --> Output Class Initialized
INFO - 2021-04-28 06:35:09 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:09 --> Input Class Initialized
INFO - 2021-04-28 06:35:09 --> Language Class Initialized
INFO - 2021-04-28 06:35:09 --> Language Class Initialized
INFO - 2021-04-28 06:35:09 --> Config Class Initialized
INFO - 2021-04-28 06:35:09 --> Loader Class Initialized
INFO - 2021-04-28 06:35:09 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:09 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:09 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:09 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:09 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:09 --> Controller Class Initialized
INFO - 2021-04-28 06:35:09 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:09 --> Total execution time: 0.0723
INFO - 2021-04-28 06:35:13 --> Config Class Initialized
INFO - 2021-04-28 06:35:13 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:13 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:13 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:13 --> URI Class Initialized
INFO - 2021-04-28 06:35:13 --> Router Class Initialized
INFO - 2021-04-28 06:35:13 --> Output Class Initialized
INFO - 2021-04-28 06:35:13 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:13 --> Input Class Initialized
INFO - 2021-04-28 06:35:13 --> Language Class Initialized
INFO - 2021-04-28 06:35:13 --> Language Class Initialized
INFO - 2021-04-28 06:35:13 --> Config Class Initialized
INFO - 2021-04-28 06:35:13 --> Loader Class Initialized
INFO - 2021-04-28 06:35:13 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:13 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:13 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:13 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:13 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:13 --> Controller Class Initialized
INFO - 2021-04-28 06:35:13 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:13 --> Total execution time: 0.0556
INFO - 2021-04-28 06:35:13 --> Config Class Initialized
INFO - 2021-04-28 06:35:13 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:14 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:14 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:14 --> URI Class Initialized
INFO - 2021-04-28 06:35:14 --> Router Class Initialized
INFO - 2021-04-28 06:35:14 --> Output Class Initialized
INFO - 2021-04-28 06:35:14 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:14 --> Input Class Initialized
INFO - 2021-04-28 06:35:14 --> Language Class Initialized
INFO - 2021-04-28 06:35:14 --> Language Class Initialized
INFO - 2021-04-28 06:35:14 --> Config Class Initialized
INFO - 2021-04-28 06:35:14 --> Loader Class Initialized
INFO - 2021-04-28 06:35:14 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:14 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:14 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:14 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:14 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:14 --> Controller Class Initialized
INFO - 2021-04-28 06:35:16 --> Config Class Initialized
INFO - 2021-04-28 06:35:16 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:16 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:16 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:16 --> URI Class Initialized
INFO - 2021-04-28 06:35:16 --> Router Class Initialized
INFO - 2021-04-28 06:35:16 --> Output Class Initialized
INFO - 2021-04-28 06:35:16 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:16 --> Input Class Initialized
INFO - 2021-04-28 06:35:16 --> Language Class Initialized
INFO - 2021-04-28 06:35:16 --> Language Class Initialized
INFO - 2021-04-28 06:35:16 --> Config Class Initialized
INFO - 2021-04-28 06:35:16 --> Loader Class Initialized
INFO - 2021-04-28 06:35:16 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:16 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:16 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:16 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:16 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:16 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-28 06:35:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:16 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:16 --> Total execution time: 0.0673
INFO - 2021-04-28 06:35:16 --> Config Class Initialized
INFO - 2021-04-28 06:35:16 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:16 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:16 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:16 --> URI Class Initialized
INFO - 2021-04-28 06:35:16 --> Router Class Initialized
INFO - 2021-04-28 06:35:16 --> Output Class Initialized
INFO - 2021-04-28 06:35:16 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:16 --> Input Class Initialized
INFO - 2021-04-28 06:35:16 --> Language Class Initialized
INFO - 2021-04-28 06:35:16 --> Language Class Initialized
INFO - 2021-04-28 06:35:16 --> Config Class Initialized
INFO - 2021-04-28 06:35:16 --> Loader Class Initialized
INFO - 2021-04-28 06:35:16 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:16 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:16 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:16 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:16 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:16 --> Controller Class Initialized
INFO - 2021-04-28 06:35:17 --> Config Class Initialized
INFO - 2021-04-28 06:35:17 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:17 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:17 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:17 --> URI Class Initialized
INFO - 2021-04-28 06:35:17 --> Router Class Initialized
INFO - 2021-04-28 06:35:17 --> Output Class Initialized
INFO - 2021-04-28 06:35:17 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:17 --> Input Class Initialized
INFO - 2021-04-28 06:35:17 --> Language Class Initialized
INFO - 2021-04-28 06:35:17 --> Language Class Initialized
INFO - 2021-04-28 06:35:17 --> Config Class Initialized
INFO - 2021-04-28 06:35:17 --> Loader Class Initialized
INFO - 2021-04-28 06:35:17 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:17 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:17 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:17 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:17 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:17 --> Controller Class Initialized
INFO - 2021-04-28 06:35:17 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:17 --> Total execution time: 0.0756
INFO - 2021-04-28 06:35:30 --> Config Class Initialized
INFO - 2021-04-28 06:35:30 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:30 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:30 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:30 --> URI Class Initialized
INFO - 2021-04-28 06:35:30 --> Router Class Initialized
INFO - 2021-04-28 06:35:30 --> Output Class Initialized
INFO - 2021-04-28 06:35:30 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:30 --> Input Class Initialized
INFO - 2021-04-28 06:35:30 --> Language Class Initialized
INFO - 2021-04-28 06:35:30 --> Language Class Initialized
INFO - 2021-04-28 06:35:30 --> Config Class Initialized
INFO - 2021-04-28 06:35:30 --> Loader Class Initialized
INFO - 2021-04-28 06:35:30 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:30 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:30 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:30 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:30 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:30 --> Controller Class Initialized
INFO - 2021-04-28 06:35:30 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:30 --> Total execution time: 0.0571
INFO - 2021-04-28 06:35:30 --> Config Class Initialized
INFO - 2021-04-28 06:35:30 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:30 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:30 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:30 --> URI Class Initialized
INFO - 2021-04-28 06:35:30 --> Router Class Initialized
INFO - 2021-04-28 06:35:30 --> Output Class Initialized
INFO - 2021-04-28 06:35:30 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:30 --> Input Class Initialized
INFO - 2021-04-28 06:35:30 --> Language Class Initialized
INFO - 2021-04-28 06:35:31 --> Language Class Initialized
INFO - 2021-04-28 06:35:31 --> Config Class Initialized
INFO - 2021-04-28 06:35:31 --> Loader Class Initialized
INFO - 2021-04-28 06:35:31 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:31 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:31 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:31 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:31 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:31 --> Controller Class Initialized
INFO - 2021-04-28 06:35:33 --> Config Class Initialized
INFO - 2021-04-28 06:35:33 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:33 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:33 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:33 --> URI Class Initialized
INFO - 2021-04-28 06:35:33 --> Router Class Initialized
INFO - 2021-04-28 06:35:33 --> Output Class Initialized
INFO - 2021-04-28 06:35:33 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:33 --> Input Class Initialized
INFO - 2021-04-28 06:35:33 --> Language Class Initialized
INFO - 2021-04-28 06:35:33 --> Language Class Initialized
INFO - 2021-04-28 06:35:33 --> Config Class Initialized
INFO - 2021-04-28 06:35:33 --> Loader Class Initialized
INFO - 2021-04-28 06:35:33 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:33 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:33 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:33 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:33 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:33 --> Controller Class Initialized
INFO - 2021-04-28 06:35:33 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:33 --> Total execution time: 0.0734
INFO - 2021-04-28 06:35:37 --> Config Class Initialized
INFO - 2021-04-28 06:35:37 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:37 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:37 --> URI Class Initialized
INFO - 2021-04-28 06:35:37 --> Router Class Initialized
INFO - 2021-04-28 06:35:37 --> Output Class Initialized
INFO - 2021-04-28 06:35:37 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:37 --> Input Class Initialized
INFO - 2021-04-28 06:35:37 --> Language Class Initialized
INFO - 2021-04-28 06:35:37 --> Language Class Initialized
INFO - 2021-04-28 06:35:37 --> Config Class Initialized
INFO - 2021-04-28 06:35:37 --> Loader Class Initialized
INFO - 2021-04-28 06:35:37 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:37 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:37 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:37 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:37 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:37 --> Controller Class Initialized
INFO - 2021-04-28 06:35:37 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:37 --> Total execution time: 0.0818
INFO - 2021-04-28 06:35:37 --> Config Class Initialized
INFO - 2021-04-28 06:35:37 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:37 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:37 --> URI Class Initialized
INFO - 2021-04-28 06:35:37 --> Router Class Initialized
INFO - 2021-04-28 06:35:37 --> Output Class Initialized
INFO - 2021-04-28 06:35:37 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:37 --> Input Class Initialized
INFO - 2021-04-28 06:35:37 --> Language Class Initialized
INFO - 2021-04-28 06:35:37 --> Language Class Initialized
INFO - 2021-04-28 06:35:37 --> Config Class Initialized
INFO - 2021-04-28 06:35:37 --> Loader Class Initialized
INFO - 2021-04-28 06:35:37 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:37 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:37 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:37 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:37 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:37 --> Controller Class Initialized
INFO - 2021-04-28 06:35:39 --> Config Class Initialized
INFO - 2021-04-28 06:35:39 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:39 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:39 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:39 --> URI Class Initialized
INFO - 2021-04-28 06:35:39 --> Router Class Initialized
INFO - 2021-04-28 06:35:39 --> Output Class Initialized
INFO - 2021-04-28 06:35:39 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:39 --> Input Class Initialized
INFO - 2021-04-28 06:35:39 --> Language Class Initialized
INFO - 2021-04-28 06:35:39 --> Language Class Initialized
INFO - 2021-04-28 06:35:39 --> Config Class Initialized
INFO - 2021-04-28 06:35:39 --> Loader Class Initialized
INFO - 2021-04-28 06:35:39 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:39 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:39 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:39 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:39 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:39 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 06:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:39 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:39 --> Total execution time: 0.0763
INFO - 2021-04-28 06:35:40 --> Config Class Initialized
INFO - 2021-04-28 06:35:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:40 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:40 --> URI Class Initialized
INFO - 2021-04-28 06:35:40 --> Router Class Initialized
INFO - 2021-04-28 06:35:40 --> Output Class Initialized
INFO - 2021-04-28 06:35:40 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:40 --> Input Class Initialized
INFO - 2021-04-28 06:35:40 --> Language Class Initialized
INFO - 2021-04-28 06:35:40 --> Language Class Initialized
INFO - 2021-04-28 06:35:40 --> Config Class Initialized
INFO - 2021-04-28 06:35:40 --> Loader Class Initialized
INFO - 2021-04-28 06:35:40 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:40 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:40 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:40 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:40 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-28 06:35:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:40 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:40 --> Total execution time: 0.0746
INFO - 2021-04-28 06:35:52 --> Config Class Initialized
INFO - 2021-04-28 06:35:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:52 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:52 --> URI Class Initialized
INFO - 2021-04-28 06:35:52 --> Router Class Initialized
INFO - 2021-04-28 06:35:52 --> Output Class Initialized
INFO - 2021-04-28 06:35:52 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:52 --> Input Class Initialized
INFO - 2021-04-28 06:35:52 --> Language Class Initialized
INFO - 2021-04-28 06:35:52 --> Language Class Initialized
INFO - 2021-04-28 06:35:52 --> Config Class Initialized
INFO - 2021-04-28 06:35:52 --> Loader Class Initialized
INFO - 2021-04-28 06:35:52 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:52 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:52 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:52 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:52 --> Controller Class Initialized
INFO - 2021-04-28 06:35:52 --> Config Class Initialized
INFO - 2021-04-28 06:35:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:52 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:52 --> URI Class Initialized
INFO - 2021-04-28 06:35:52 --> Router Class Initialized
INFO - 2021-04-28 06:35:52 --> Output Class Initialized
INFO - 2021-04-28 06:35:52 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:52 --> Input Class Initialized
INFO - 2021-04-28 06:35:52 --> Language Class Initialized
INFO - 2021-04-28 06:35:52 --> Language Class Initialized
INFO - 2021-04-28 06:35:52 --> Config Class Initialized
INFO - 2021-04-28 06:35:52 --> Loader Class Initialized
INFO - 2021-04-28 06:35:52 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:52 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:52 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:52 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:53 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 06:35:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:53 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:53 --> Total execution time: 0.0741
INFO - 2021-04-28 06:35:57 --> Config Class Initialized
INFO - 2021-04-28 06:35:57 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:57 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:57 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:57 --> URI Class Initialized
INFO - 2021-04-28 06:35:57 --> Router Class Initialized
INFO - 2021-04-28 06:35:57 --> Output Class Initialized
INFO - 2021-04-28 06:35:57 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:57 --> Input Class Initialized
INFO - 2021-04-28 06:35:57 --> Language Class Initialized
INFO - 2021-04-28 06:35:57 --> Language Class Initialized
INFO - 2021-04-28 06:35:57 --> Config Class Initialized
INFO - 2021-04-28 06:35:57 --> Loader Class Initialized
INFO - 2021-04-28 06:35:57 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:57 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:57 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:57 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:57 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:57 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-28 06:35:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:57 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:57 --> Total execution time: 0.0755
INFO - 2021-04-28 06:35:57 --> Config Class Initialized
INFO - 2021-04-28 06:35:57 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:57 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:57 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:57 --> URI Class Initialized
INFO - 2021-04-28 06:35:57 --> Router Class Initialized
INFO - 2021-04-28 06:35:57 --> Output Class Initialized
INFO - 2021-04-28 06:35:57 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:57 --> Input Class Initialized
INFO - 2021-04-28 06:35:57 --> Language Class Initialized
INFO - 2021-04-28 06:35:57 --> Language Class Initialized
INFO - 2021-04-28 06:35:57 --> Config Class Initialized
INFO - 2021-04-28 06:35:57 --> Loader Class Initialized
INFO - 2021-04-28 06:35:57 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:57 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:57 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:57 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:57 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:57 --> Controller Class Initialized
INFO - 2021-04-28 06:35:58 --> Config Class Initialized
INFO - 2021-04-28 06:35:58 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:35:58 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:35:58 --> Utf8 Class Initialized
INFO - 2021-04-28 06:35:58 --> URI Class Initialized
INFO - 2021-04-28 06:35:58 --> Router Class Initialized
INFO - 2021-04-28 06:35:58 --> Output Class Initialized
INFO - 2021-04-28 06:35:58 --> Security Class Initialized
DEBUG - 2021-04-28 06:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:35:58 --> Input Class Initialized
INFO - 2021-04-28 06:35:58 --> Language Class Initialized
INFO - 2021-04-28 06:35:58 --> Language Class Initialized
INFO - 2021-04-28 06:35:58 --> Config Class Initialized
INFO - 2021-04-28 06:35:58 --> Loader Class Initialized
INFO - 2021-04-28 06:35:58 --> Helper loaded: url_helper
INFO - 2021-04-28 06:35:58 --> Helper loaded: file_helper
INFO - 2021-04-28 06:35:58 --> Helper loaded: form_helper
INFO - 2021-04-28 06:35:58 --> Helper loaded: my_helper
INFO - 2021-04-28 06:35:58 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:35:58 --> Controller Class Initialized
DEBUG - 2021-04-28 06:35:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-04-28 06:35:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:35:58 --> Final output sent to browser
DEBUG - 2021-04-28 06:35:58 --> Total execution time: 0.0647
INFO - 2021-04-28 06:36:09 --> Config Class Initialized
INFO - 2021-04-28 06:36:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:09 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:09 --> URI Class Initialized
INFO - 2021-04-28 06:36:09 --> Router Class Initialized
INFO - 2021-04-28 06:36:09 --> Output Class Initialized
INFO - 2021-04-28 06:36:09 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:09 --> Input Class Initialized
INFO - 2021-04-28 06:36:09 --> Language Class Initialized
INFO - 2021-04-28 06:36:09 --> Language Class Initialized
INFO - 2021-04-28 06:36:09 --> Config Class Initialized
INFO - 2021-04-28 06:36:09 --> Loader Class Initialized
INFO - 2021-04-28 06:36:09 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:09 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:09 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:09 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:09 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:09 --> Controller Class Initialized
INFO - 2021-04-28 06:36:09 --> Config Class Initialized
INFO - 2021-04-28 06:36:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:09 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:09 --> URI Class Initialized
INFO - 2021-04-28 06:36:09 --> Router Class Initialized
INFO - 2021-04-28 06:36:09 --> Output Class Initialized
INFO - 2021-04-28 06:36:09 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:09 --> Input Class Initialized
INFO - 2021-04-28 06:36:09 --> Language Class Initialized
INFO - 2021-04-28 06:36:09 --> Language Class Initialized
INFO - 2021-04-28 06:36:09 --> Config Class Initialized
INFO - 2021-04-28 06:36:09 --> Loader Class Initialized
INFO - 2021-04-28 06:36:09 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:09 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:09 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:09 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:09 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:09 --> Controller Class Initialized
DEBUG - 2021-04-28 06:36:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-28 06:36:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:36:09 --> Final output sent to browser
DEBUG - 2021-04-28 06:36:09 --> Total execution time: 0.0470
INFO - 2021-04-28 06:36:09 --> Config Class Initialized
INFO - 2021-04-28 06:36:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:09 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:09 --> URI Class Initialized
INFO - 2021-04-28 06:36:09 --> Router Class Initialized
INFO - 2021-04-28 06:36:09 --> Output Class Initialized
INFO - 2021-04-28 06:36:09 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:09 --> Input Class Initialized
INFO - 2021-04-28 06:36:09 --> Language Class Initialized
INFO - 2021-04-28 06:36:09 --> Language Class Initialized
INFO - 2021-04-28 06:36:09 --> Config Class Initialized
INFO - 2021-04-28 06:36:09 --> Loader Class Initialized
INFO - 2021-04-28 06:36:09 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:09 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:09 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:09 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:09 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:09 --> Controller Class Initialized
INFO - 2021-04-28 06:36:14 --> Config Class Initialized
INFO - 2021-04-28 06:36:14 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:14 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:14 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:14 --> URI Class Initialized
INFO - 2021-04-28 06:36:14 --> Router Class Initialized
INFO - 2021-04-28 06:36:14 --> Output Class Initialized
INFO - 2021-04-28 06:36:14 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:14 --> Input Class Initialized
INFO - 2021-04-28 06:36:14 --> Language Class Initialized
INFO - 2021-04-28 06:36:14 --> Language Class Initialized
INFO - 2021-04-28 06:36:14 --> Config Class Initialized
INFO - 2021-04-28 06:36:14 --> Loader Class Initialized
INFO - 2021-04-28 06:36:14 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:14 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:14 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:14 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:14 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:14 --> Controller Class Initialized
INFO - 2021-04-28 06:36:14 --> Helper loaded: cookie_helper
INFO - 2021-04-28 06:36:14 --> Config Class Initialized
INFO - 2021-04-28 06:36:14 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:14 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:14 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:14 --> URI Class Initialized
INFO - 2021-04-28 06:36:14 --> Router Class Initialized
INFO - 2021-04-28 06:36:14 --> Output Class Initialized
INFO - 2021-04-28 06:36:14 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:14 --> Input Class Initialized
INFO - 2021-04-28 06:36:14 --> Language Class Initialized
INFO - 2021-04-28 06:36:14 --> Language Class Initialized
INFO - 2021-04-28 06:36:14 --> Config Class Initialized
INFO - 2021-04-28 06:36:14 --> Loader Class Initialized
INFO - 2021-04-28 06:36:14 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:14 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:14 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:14 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:14 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:14 --> Controller Class Initialized
DEBUG - 2021-04-28 06:36:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 06:36:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:36:14 --> Final output sent to browser
DEBUG - 2021-04-28 06:36:14 --> Total execution time: 0.0432
INFO - 2021-04-28 06:36:19 --> Config Class Initialized
INFO - 2021-04-28 06:36:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:19 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:19 --> URI Class Initialized
INFO - 2021-04-28 06:36:19 --> Router Class Initialized
INFO - 2021-04-28 06:36:19 --> Output Class Initialized
INFO - 2021-04-28 06:36:19 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:19 --> Input Class Initialized
INFO - 2021-04-28 06:36:19 --> Language Class Initialized
INFO - 2021-04-28 06:36:19 --> Language Class Initialized
INFO - 2021-04-28 06:36:19 --> Config Class Initialized
INFO - 2021-04-28 06:36:19 --> Loader Class Initialized
INFO - 2021-04-28 06:36:19 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:19 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:19 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:19 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:19 --> Controller Class Initialized
INFO - 2021-04-28 06:36:19 --> Helper loaded: cookie_helper
INFO - 2021-04-28 06:36:19 --> Final output sent to browser
DEBUG - 2021-04-28 06:36:19 --> Total execution time: 0.0712
INFO - 2021-04-28 06:36:19 --> Config Class Initialized
INFO - 2021-04-28 06:36:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:19 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:19 --> URI Class Initialized
INFO - 2021-04-28 06:36:19 --> Router Class Initialized
INFO - 2021-04-28 06:36:19 --> Output Class Initialized
INFO - 2021-04-28 06:36:19 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:19 --> Input Class Initialized
INFO - 2021-04-28 06:36:19 --> Language Class Initialized
INFO - 2021-04-28 06:36:19 --> Language Class Initialized
INFO - 2021-04-28 06:36:19 --> Config Class Initialized
INFO - 2021-04-28 06:36:19 --> Loader Class Initialized
INFO - 2021-04-28 06:36:19 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:19 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:19 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:19 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:19 --> Controller Class Initialized
DEBUG - 2021-04-28 06:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 06:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:36:19 --> Final output sent to browser
DEBUG - 2021-04-28 06:36:19 --> Total execution time: 0.0933
INFO - 2021-04-28 06:36:20 --> Config Class Initialized
INFO - 2021-04-28 06:36:20 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:20 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:20 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:21 --> URI Class Initialized
INFO - 2021-04-28 06:36:21 --> Router Class Initialized
INFO - 2021-04-28 06:36:21 --> Output Class Initialized
INFO - 2021-04-28 06:36:21 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:21 --> Input Class Initialized
INFO - 2021-04-28 06:36:21 --> Language Class Initialized
INFO - 2021-04-28 06:36:21 --> Language Class Initialized
INFO - 2021-04-28 06:36:21 --> Config Class Initialized
INFO - 2021-04-28 06:36:21 --> Loader Class Initialized
INFO - 2021-04-28 06:36:21 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:21 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:21 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:21 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:21 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:21 --> Controller Class Initialized
DEBUG - 2021-04-28 06:36:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-04-28 06:36:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:36:21 --> Final output sent to browser
DEBUG - 2021-04-28 06:36:21 --> Total execution time: 0.0997
INFO - 2021-04-28 06:36:21 --> Config Class Initialized
INFO - 2021-04-28 06:36:21 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:21 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:21 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:21 --> URI Class Initialized
INFO - 2021-04-28 06:36:21 --> Router Class Initialized
INFO - 2021-04-28 06:36:21 --> Output Class Initialized
INFO - 2021-04-28 06:36:21 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:21 --> Input Class Initialized
INFO - 2021-04-28 06:36:21 --> Language Class Initialized
INFO - 2021-04-28 06:36:21 --> Language Class Initialized
INFO - 2021-04-28 06:36:21 --> Config Class Initialized
INFO - 2021-04-28 06:36:21 --> Loader Class Initialized
INFO - 2021-04-28 06:36:21 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:21 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:21 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:21 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:21 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:21 --> Controller Class Initialized
DEBUG - 2021-04-28 06:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-04-28 06:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:36:22 --> Final output sent to browser
DEBUG - 2021-04-28 06:36:22 --> Total execution time: 0.0492
INFO - 2021-04-28 06:36:22 --> Config Class Initialized
INFO - 2021-04-28 06:36:22 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:22 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:22 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:22 --> URI Class Initialized
INFO - 2021-04-28 06:36:22 --> Router Class Initialized
INFO - 2021-04-28 06:36:22 --> Output Class Initialized
INFO - 2021-04-28 06:36:22 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:22 --> Input Class Initialized
INFO - 2021-04-28 06:36:22 --> Language Class Initialized
INFO - 2021-04-28 06:36:22 --> Language Class Initialized
INFO - 2021-04-28 06:36:22 --> Config Class Initialized
INFO - 2021-04-28 06:36:22 --> Loader Class Initialized
INFO - 2021-04-28 06:36:22 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:22 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:22 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:22 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:22 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:22 --> Controller Class Initialized
INFO - 2021-04-28 06:36:23 --> Config Class Initialized
INFO - 2021-04-28 06:36:23 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:23 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:23 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:23 --> URI Class Initialized
INFO - 2021-04-28 06:36:23 --> Router Class Initialized
INFO - 2021-04-28 06:36:23 --> Output Class Initialized
INFO - 2021-04-28 06:36:23 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:23 --> Input Class Initialized
INFO - 2021-04-28 06:36:23 --> Language Class Initialized
INFO - 2021-04-28 06:36:23 --> Language Class Initialized
INFO - 2021-04-28 06:36:23 --> Config Class Initialized
INFO - 2021-04-28 06:36:23 --> Loader Class Initialized
INFO - 2021-04-28 06:36:23 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:23 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:23 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:23 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:23 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:23 --> Controller Class Initialized
ERROR - 2021-04-28 06:36:23 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                        b.id ids, b.nama, 0 nilai
                                        FROM t_kelas_siswa a 
                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                        WHERE a.id_kelas = 1 
                                        AND a.ta = '2020'
                                        ORDER BY b.nama ASC
INFO - 2021-04-28 06:36:23 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 06:36:25 --> Config Class Initialized
INFO - 2021-04-28 06:36:25 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:25 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:25 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:25 --> URI Class Initialized
INFO - 2021-04-28 06:36:25 --> Router Class Initialized
INFO - 2021-04-28 06:36:25 --> Output Class Initialized
INFO - 2021-04-28 06:36:25 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:25 --> Input Class Initialized
INFO - 2021-04-28 06:36:25 --> Language Class Initialized
INFO - 2021-04-28 06:36:25 --> Language Class Initialized
INFO - 2021-04-28 06:36:25 --> Config Class Initialized
INFO - 2021-04-28 06:36:25 --> Loader Class Initialized
INFO - 2021-04-28 06:36:25 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:25 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:25 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:25 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:25 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:25 --> Controller Class Initialized
ERROR - 2021-04-28 06:36:25 --> Query error: Unknown column 'c.ta' in 'on clause' - Invalid query: SELECT 
                                d.nama nmsiswa, a.jenis, a.id_mapel_kd, a.id_siswa, a.nilai
                                FROM t_nilai a
                                LEFT JOIN t_mapel_kd b ON a.id_mapel_kd = b.id
                                LEFT JOIN t_kelas_siswa c ON CONCAT(a.id_siswa,LEFT(a.tasm,4)) = CONCAT(c.id_siswa,c.ta)
                                LEFT JOIN m_siswa d ON c.id_siswa = d.id
                                WHERE c.id_kelas = 1 AND b.id_mapel = 124
                                AND a.tasm = '20202'
                                ORDER BY d.id
INFO - 2021-04-28 06:36:25 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 06:36:36 --> Config Class Initialized
INFO - 2021-04-28 06:36:36 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:36 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:36 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:36 --> URI Class Initialized
INFO - 2021-04-28 06:36:36 --> Router Class Initialized
INFO - 2021-04-28 06:36:36 --> Output Class Initialized
INFO - 2021-04-28 06:36:36 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:36 --> Input Class Initialized
INFO - 2021-04-28 06:36:36 --> Language Class Initialized
INFO - 2021-04-28 06:36:36 --> Language Class Initialized
INFO - 2021-04-28 06:36:36 --> Config Class Initialized
INFO - 2021-04-28 06:36:36 --> Loader Class Initialized
INFO - 2021-04-28 06:36:36 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:36 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:36 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:36 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:36 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:36 --> Controller Class Initialized
DEBUG - 2021-04-28 06:36:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-04-28 06:36:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:36:36 --> Final output sent to browser
DEBUG - 2021-04-28 06:36:36 --> Total execution time: 0.0653
INFO - 2021-04-28 06:36:36 --> Config Class Initialized
INFO - 2021-04-28 06:36:36 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:36 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:36 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:36 --> URI Class Initialized
INFO - 2021-04-28 06:36:36 --> Router Class Initialized
INFO - 2021-04-28 06:36:36 --> Output Class Initialized
INFO - 2021-04-28 06:36:36 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:36 --> Input Class Initialized
INFO - 2021-04-28 06:36:36 --> Language Class Initialized
INFO - 2021-04-28 06:36:36 --> Language Class Initialized
INFO - 2021-04-28 06:36:36 --> Config Class Initialized
INFO - 2021-04-28 06:36:36 --> Loader Class Initialized
INFO - 2021-04-28 06:36:36 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:36 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:36 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:36 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:36 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:36 --> Controller Class Initialized
INFO - 2021-04-28 06:36:38 --> Config Class Initialized
INFO - 2021-04-28 06:36:38 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:38 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:38 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:38 --> URI Class Initialized
INFO - 2021-04-28 06:36:38 --> Router Class Initialized
INFO - 2021-04-28 06:36:38 --> Output Class Initialized
INFO - 2021-04-28 06:36:38 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:38 --> Input Class Initialized
INFO - 2021-04-28 06:36:38 --> Language Class Initialized
INFO - 2021-04-28 06:36:38 --> Language Class Initialized
INFO - 2021-04-28 06:36:38 --> Config Class Initialized
INFO - 2021-04-28 06:36:38 --> Loader Class Initialized
INFO - 2021-04-28 06:36:38 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:38 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:38 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:38 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:38 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:38 --> Controller Class Initialized
ERROR - 2021-04-28 06:36:38 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                        b.id ids, b.nama, 0 nilai
                                        FROM t_kelas_siswa a 
                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                        WHERE a.id_kelas = 1 
                                        AND a.ta = '2020'
                                        ORDER BY b.nama ASC
INFO - 2021-04-28 06:36:38 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 06:36:39 --> Config Class Initialized
INFO - 2021-04-28 06:36:39 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:39 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:39 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:39 --> URI Class Initialized
INFO - 2021-04-28 06:36:39 --> Router Class Initialized
INFO - 2021-04-28 06:36:39 --> Output Class Initialized
INFO - 2021-04-28 06:36:39 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:39 --> Input Class Initialized
INFO - 2021-04-28 06:36:39 --> Language Class Initialized
INFO - 2021-04-28 06:36:39 --> Language Class Initialized
INFO - 2021-04-28 06:36:39 --> Config Class Initialized
INFO - 2021-04-28 06:36:39 --> Loader Class Initialized
INFO - 2021-04-28 06:36:39 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:39 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:39 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:39 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:39 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:39 --> Controller Class Initialized
ERROR - 2021-04-28 06:36:39 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                        b.id ids, b.nama, 0 nilai
                                        FROM t_kelas_siswa a 
                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                        WHERE a.id_kelas = 1 
                                        AND a.ta = '2020'
                                        ORDER BY b.nama ASC
INFO - 2021-04-28 06:36:39 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 06:36:40 --> Config Class Initialized
INFO - 2021-04-28 06:36:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:36:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:36:40 --> Utf8 Class Initialized
INFO - 2021-04-28 06:36:40 --> URI Class Initialized
INFO - 2021-04-28 06:36:40 --> Router Class Initialized
INFO - 2021-04-28 06:36:40 --> Output Class Initialized
INFO - 2021-04-28 06:36:40 --> Security Class Initialized
DEBUG - 2021-04-28 06:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:36:40 --> Input Class Initialized
INFO - 2021-04-28 06:36:40 --> Language Class Initialized
INFO - 2021-04-28 06:36:40 --> Language Class Initialized
INFO - 2021-04-28 06:36:40 --> Config Class Initialized
INFO - 2021-04-28 06:36:40 --> Loader Class Initialized
INFO - 2021-04-28 06:36:40 --> Helper loaded: url_helper
INFO - 2021-04-28 06:36:40 --> Helper loaded: file_helper
INFO - 2021-04-28 06:36:40 --> Helper loaded: form_helper
INFO - 2021-04-28 06:36:40 --> Helper loaded: my_helper
INFO - 2021-04-28 06:36:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:36:40 --> Controller Class Initialized
INFO - 2021-04-28 06:36:40 --> Final output sent to browser
DEBUG - 2021-04-28 06:36:40 --> Total execution time: 0.0718
INFO - 2021-04-28 06:38:51 --> Config Class Initialized
INFO - 2021-04-28 06:38:51 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:38:51 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:38:51 --> Utf8 Class Initialized
INFO - 2021-04-28 06:38:51 --> URI Class Initialized
INFO - 2021-04-28 06:38:51 --> Router Class Initialized
INFO - 2021-04-28 06:38:51 --> Output Class Initialized
INFO - 2021-04-28 06:38:51 --> Security Class Initialized
DEBUG - 2021-04-28 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:38:51 --> Input Class Initialized
INFO - 2021-04-28 06:38:51 --> Language Class Initialized
INFO - 2021-04-28 06:38:51 --> Language Class Initialized
INFO - 2021-04-28 06:38:51 --> Config Class Initialized
INFO - 2021-04-28 06:38:51 --> Loader Class Initialized
INFO - 2021-04-28 06:38:51 --> Helper loaded: url_helper
INFO - 2021-04-28 06:38:51 --> Helper loaded: file_helper
INFO - 2021-04-28 06:38:51 --> Helper loaded: form_helper
INFO - 2021-04-28 06:38:51 --> Helper loaded: my_helper
INFO - 2021-04-28 06:38:51 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:38:51 --> Controller Class Initialized
ERROR - 2021-04-28 06:38:51 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                a.id_siswa, b.nama
                                                FROM t_kelas_siswa a
                                                INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                WHERE a.id_kelas = '1' AND a.ta = '2020'
INFO - 2021-04-28 06:38:51 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 06:42:16 --> Config Class Initialized
INFO - 2021-04-28 06:42:16 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:42:16 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:42:16 --> Utf8 Class Initialized
INFO - 2021-04-28 06:42:16 --> URI Class Initialized
INFO - 2021-04-28 06:42:16 --> Router Class Initialized
INFO - 2021-04-28 06:42:16 --> Output Class Initialized
INFO - 2021-04-28 06:42:16 --> Security Class Initialized
DEBUG - 2021-04-28 06:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:42:16 --> Input Class Initialized
INFO - 2021-04-28 06:42:16 --> Language Class Initialized
INFO - 2021-04-28 06:42:16 --> Language Class Initialized
INFO - 2021-04-28 06:42:16 --> Config Class Initialized
INFO - 2021-04-28 06:42:16 --> Loader Class Initialized
INFO - 2021-04-28 06:42:16 --> Helper loaded: url_helper
INFO - 2021-04-28 06:42:16 --> Helper loaded: file_helper
INFO - 2021-04-28 06:42:16 --> Helper loaded: form_helper
INFO - 2021-04-28 06:42:16 --> Helper loaded: my_helper
INFO - 2021-04-28 06:42:16 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:42:16 --> Controller Class Initialized
ERROR - 2021-04-28 06:42:16 --> Severity: Notice --> Undefined index: ta C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 5149
ERROR - 2021-04-28 06:42:16 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                a.id_siswa, b.nama
                                                FROM t_kelas_siswa a
                                                INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                WHERE a.id_kelas = '1' AND a.ta = ''
INFO - 2021-04-28 06:42:16 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 06:42:53 --> Config Class Initialized
INFO - 2021-04-28 06:42:53 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:42:53 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:42:53 --> Utf8 Class Initialized
INFO - 2021-04-28 06:42:53 --> URI Class Initialized
INFO - 2021-04-28 06:42:53 --> Router Class Initialized
INFO - 2021-04-28 06:42:53 --> Output Class Initialized
INFO - 2021-04-28 06:42:53 --> Security Class Initialized
DEBUG - 2021-04-28 06:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:42:53 --> Input Class Initialized
INFO - 2021-04-28 06:42:53 --> Language Class Initialized
INFO - 2021-04-28 06:42:53 --> Language Class Initialized
INFO - 2021-04-28 06:42:53 --> Config Class Initialized
INFO - 2021-04-28 06:42:53 --> Loader Class Initialized
INFO - 2021-04-28 06:42:53 --> Helper loaded: url_helper
INFO - 2021-04-28 06:42:53 --> Helper loaded: file_helper
INFO - 2021-04-28 06:42:53 --> Helper loaded: form_helper
INFO - 2021-04-28 06:42:53 --> Helper loaded: my_helper
INFO - 2021-04-28 06:42:53 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:42:53 --> Controller Class Initialized
DEBUG - 2021-04-28 06:42:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-04-28 06:42:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 06:42:53 --> Final output sent to browser
DEBUG - 2021-04-28 06:42:53 --> Total execution time: 0.0746
INFO - 2021-04-28 06:43:04 --> Config Class Initialized
INFO - 2021-04-28 06:43:04 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:43:04 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:43:04 --> Utf8 Class Initialized
INFO - 2021-04-28 06:43:04 --> URI Class Initialized
INFO - 2021-04-28 06:43:04 --> Router Class Initialized
INFO - 2021-04-28 06:43:04 --> Output Class Initialized
INFO - 2021-04-28 06:43:04 --> Security Class Initialized
DEBUG - 2021-04-28 06:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:43:04 --> Input Class Initialized
INFO - 2021-04-28 06:43:04 --> Language Class Initialized
INFO - 2021-04-28 06:43:04 --> Language Class Initialized
INFO - 2021-04-28 06:43:04 --> Config Class Initialized
INFO - 2021-04-28 06:43:04 --> Loader Class Initialized
INFO - 2021-04-28 06:43:04 --> Helper loaded: url_helper
INFO - 2021-04-28 06:43:04 --> Helper loaded: file_helper
INFO - 2021-04-28 06:43:04 --> Helper loaded: form_helper
INFO - 2021-04-28 06:43:04 --> Helper loaded: my_helper
INFO - 2021-04-28 06:43:04 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:43:04 --> Controller Class Initialized
ERROR - 2021-04-28 06:43:04 --> Query error: Unknown column 'b.ta' in 'where clause' - Invalid query: SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = 1418 AND b.ta = '2020/2021'
INFO - 2021-04-28 06:43:04 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 06:45:06 --> Config Class Initialized
INFO - 2021-04-28 06:45:06 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:45:06 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:45:06 --> Utf8 Class Initialized
INFO - 2021-04-28 06:45:06 --> URI Class Initialized
INFO - 2021-04-28 06:45:06 --> Router Class Initialized
INFO - 2021-04-28 06:45:06 --> Output Class Initialized
INFO - 2021-04-28 06:45:06 --> Security Class Initialized
DEBUG - 2021-04-28 06:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:45:06 --> Input Class Initialized
INFO - 2021-04-28 06:45:06 --> Language Class Initialized
INFO - 2021-04-28 06:45:06 --> Language Class Initialized
INFO - 2021-04-28 06:45:06 --> Config Class Initialized
INFO - 2021-04-28 06:45:06 --> Loader Class Initialized
INFO - 2021-04-28 06:45:06 --> Helper loaded: url_helper
INFO - 2021-04-28 06:45:06 --> Helper loaded: file_helper
INFO - 2021-04-28 06:45:06 --> Helper loaded: form_helper
INFO - 2021-04-28 06:45:06 --> Helper loaded: my_helper
INFO - 2021-04-28 06:45:06 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:45:06 --> Controller Class Initialized
ERROR - 2021-04-28 06:45:06 --> Query error: Unknown column 'b.ta' in 'where clause' - Invalid query: SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = 1418 AND b.ta = '2020/2021'
INFO - 2021-04-28 06:45:06 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 06:45:08 --> Config Class Initialized
INFO - 2021-04-28 06:45:08 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:45:08 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:45:08 --> Utf8 Class Initialized
INFO - 2021-04-28 06:45:08 --> URI Class Initialized
INFO - 2021-04-28 06:45:08 --> Router Class Initialized
INFO - 2021-04-28 06:45:08 --> Output Class Initialized
INFO - 2021-04-28 06:45:08 --> Security Class Initialized
DEBUG - 2021-04-28 06:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:45:08 --> Input Class Initialized
INFO - 2021-04-28 06:45:08 --> Language Class Initialized
INFO - 2021-04-28 06:45:08 --> Language Class Initialized
INFO - 2021-04-28 06:45:08 --> Config Class Initialized
INFO - 2021-04-28 06:45:08 --> Loader Class Initialized
INFO - 2021-04-28 06:45:08 --> Helper loaded: url_helper
INFO - 2021-04-28 06:45:08 --> Helper loaded: file_helper
INFO - 2021-04-28 06:45:08 --> Helper loaded: form_helper
INFO - 2021-04-28 06:45:08 --> Helper loaded: my_helper
INFO - 2021-04-28 06:45:08 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:45:08 --> Controller Class Initialized
ERROR - 2021-04-28 06:45:08 --> Query error: Unknown column 'b.ta' in 'where clause' - Invalid query: SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = 1418 AND b.ta = '2020/2021'
INFO - 2021-04-28 06:45:08 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 06:45:12 --> Config Class Initialized
INFO - 2021-04-28 06:45:12 --> Hooks Class Initialized
DEBUG - 2021-04-28 06:45:12 --> UTF-8 Support Enabled
INFO - 2021-04-28 06:45:12 --> Utf8 Class Initialized
INFO - 2021-04-28 06:45:12 --> URI Class Initialized
INFO - 2021-04-28 06:45:12 --> Router Class Initialized
INFO - 2021-04-28 06:45:12 --> Output Class Initialized
INFO - 2021-04-28 06:45:12 --> Security Class Initialized
DEBUG - 2021-04-28 06:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 06:45:12 --> Input Class Initialized
INFO - 2021-04-28 06:45:12 --> Language Class Initialized
INFO - 2021-04-28 06:45:12 --> Language Class Initialized
INFO - 2021-04-28 06:45:12 --> Config Class Initialized
INFO - 2021-04-28 06:45:12 --> Loader Class Initialized
INFO - 2021-04-28 06:45:12 --> Helper loaded: url_helper
INFO - 2021-04-28 06:45:12 --> Helper loaded: file_helper
INFO - 2021-04-28 06:45:12 --> Helper loaded: form_helper
INFO - 2021-04-28 06:45:12 --> Helper loaded: my_helper
INFO - 2021-04-28 06:45:12 --> Database Driver Class Initialized
DEBUG - 2021-04-28 06:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 06:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 06:45:12 --> Controller Class Initialized
ERROR - 2021-04-28 06:45:12 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                a.id_siswa, b.nama
                                                FROM t_kelas_siswa a
                                                INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                WHERE a.id_kelas = '1' AND a.ta = '2020'
INFO - 2021-04-28 06:45:12 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 08:11:49 --> Config Class Initialized
INFO - 2021-04-28 08:11:49 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:11:49 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:11:49 --> Utf8 Class Initialized
INFO - 2021-04-28 08:11:49 --> URI Class Initialized
DEBUG - 2021-04-28 08:11:49 --> No URI present. Default controller set.
INFO - 2021-04-28 08:11:49 --> Router Class Initialized
INFO - 2021-04-28 08:11:49 --> Output Class Initialized
INFO - 2021-04-28 08:11:49 --> Security Class Initialized
DEBUG - 2021-04-28 08:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:11:49 --> Input Class Initialized
INFO - 2021-04-28 08:11:49 --> Language Class Initialized
INFO - 2021-04-28 08:11:49 --> Language Class Initialized
INFO - 2021-04-28 08:11:49 --> Config Class Initialized
INFO - 2021-04-28 08:11:49 --> Loader Class Initialized
INFO - 2021-04-28 08:11:49 --> Helper loaded: url_helper
INFO - 2021-04-28 08:11:49 --> Helper loaded: file_helper
INFO - 2021-04-28 08:11:49 --> Helper loaded: form_helper
INFO - 2021-04-28 08:11:49 --> Helper loaded: my_helper
INFO - 2021-04-28 08:11:49 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:11:49 --> Controller Class Initialized
INFO - 2021-04-28 08:11:50 --> Config Class Initialized
INFO - 2021-04-28 08:11:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:11:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:11:50 --> Utf8 Class Initialized
INFO - 2021-04-28 08:11:50 --> URI Class Initialized
INFO - 2021-04-28 08:11:50 --> Router Class Initialized
INFO - 2021-04-28 08:11:50 --> Output Class Initialized
INFO - 2021-04-28 08:11:50 --> Security Class Initialized
DEBUG - 2021-04-28 08:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:11:50 --> Input Class Initialized
INFO - 2021-04-28 08:11:50 --> Language Class Initialized
INFO - 2021-04-28 08:11:50 --> Language Class Initialized
INFO - 2021-04-28 08:11:50 --> Config Class Initialized
INFO - 2021-04-28 08:11:50 --> Loader Class Initialized
INFO - 2021-04-28 08:11:50 --> Helper loaded: url_helper
INFO - 2021-04-28 08:11:50 --> Helper loaded: file_helper
INFO - 2021-04-28 08:11:50 --> Helper loaded: form_helper
INFO - 2021-04-28 08:11:50 --> Helper loaded: my_helper
INFO - 2021-04-28 08:11:50 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:11:50 --> Controller Class Initialized
DEBUG - 2021-04-28 08:11:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 08:11:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:11:50 --> Final output sent to browser
DEBUG - 2021-04-28 08:11:50 --> Total execution time: 0.1414
INFO - 2021-04-28 08:12:00 --> Config Class Initialized
INFO - 2021-04-28 08:12:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:00 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:00 --> URI Class Initialized
INFO - 2021-04-28 08:12:00 --> Router Class Initialized
INFO - 2021-04-28 08:12:00 --> Output Class Initialized
INFO - 2021-04-28 08:12:00 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:00 --> Input Class Initialized
INFO - 2021-04-28 08:12:00 --> Language Class Initialized
INFO - 2021-04-28 08:12:00 --> Language Class Initialized
INFO - 2021-04-28 08:12:00 --> Config Class Initialized
INFO - 2021-04-28 08:12:00 --> Loader Class Initialized
INFO - 2021-04-28 08:12:00 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:00 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:00 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:00 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:00 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:00 --> Controller Class Initialized
INFO - 2021-04-28 08:12:00 --> Helper loaded: cookie_helper
INFO - 2021-04-28 08:12:00 --> Final output sent to browser
DEBUG - 2021-04-28 08:12:00 --> Total execution time: 0.1440
INFO - 2021-04-28 08:12:01 --> Config Class Initialized
INFO - 2021-04-28 08:12:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:01 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:01 --> URI Class Initialized
INFO - 2021-04-28 08:12:01 --> Router Class Initialized
INFO - 2021-04-28 08:12:01 --> Output Class Initialized
INFO - 2021-04-28 08:12:01 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:01 --> Input Class Initialized
INFO - 2021-04-28 08:12:01 --> Language Class Initialized
INFO - 2021-04-28 08:12:01 --> Language Class Initialized
INFO - 2021-04-28 08:12:01 --> Config Class Initialized
INFO - 2021-04-28 08:12:01 --> Loader Class Initialized
INFO - 2021-04-28 08:12:01 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:01 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:01 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:01 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:01 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:01 --> Controller Class Initialized
DEBUG - 2021-04-28 08:12:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 08:12:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:12:01 --> Final output sent to browser
DEBUG - 2021-04-28 08:12:01 --> Total execution time: 0.1876
INFO - 2021-04-28 08:12:04 --> Config Class Initialized
INFO - 2021-04-28 08:12:04 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:04 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:04 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:04 --> URI Class Initialized
INFO - 2021-04-28 08:12:04 --> Router Class Initialized
INFO - 2021-04-28 08:12:04 --> Output Class Initialized
INFO - 2021-04-28 08:12:04 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:04 --> Input Class Initialized
INFO - 2021-04-28 08:12:04 --> Language Class Initialized
INFO - 2021-04-28 08:12:04 --> Language Class Initialized
INFO - 2021-04-28 08:12:04 --> Config Class Initialized
INFO - 2021-04-28 08:12:04 --> Loader Class Initialized
INFO - 2021-04-28 08:12:04 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:04 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:04 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:04 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:04 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:04 --> Controller Class Initialized
INFO - 2021-04-28 08:12:04 --> Helper loaded: cookie_helper
INFO - 2021-04-28 08:12:04 --> Config Class Initialized
INFO - 2021-04-28 08:12:04 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:04 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:04 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:04 --> URI Class Initialized
INFO - 2021-04-28 08:12:04 --> Router Class Initialized
INFO - 2021-04-28 08:12:04 --> Output Class Initialized
INFO - 2021-04-28 08:12:04 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:04 --> Input Class Initialized
INFO - 2021-04-28 08:12:04 --> Language Class Initialized
INFO - 2021-04-28 08:12:04 --> Language Class Initialized
INFO - 2021-04-28 08:12:04 --> Config Class Initialized
INFO - 2021-04-28 08:12:04 --> Loader Class Initialized
INFO - 2021-04-28 08:12:04 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:04 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:04 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:04 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:04 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:04 --> Controller Class Initialized
DEBUG - 2021-04-28 08:12:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 08:12:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:12:04 --> Final output sent to browser
DEBUG - 2021-04-28 08:12:04 --> Total execution time: 0.1812
INFO - 2021-04-28 08:12:10 --> Config Class Initialized
INFO - 2021-04-28 08:12:10 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:10 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:10 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:10 --> URI Class Initialized
INFO - 2021-04-28 08:12:10 --> Router Class Initialized
INFO - 2021-04-28 08:12:10 --> Output Class Initialized
INFO - 2021-04-28 08:12:10 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:10 --> Input Class Initialized
INFO - 2021-04-28 08:12:10 --> Language Class Initialized
INFO - 2021-04-28 08:12:10 --> Language Class Initialized
INFO - 2021-04-28 08:12:10 --> Config Class Initialized
INFO - 2021-04-28 08:12:10 --> Loader Class Initialized
INFO - 2021-04-28 08:12:10 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:10 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:10 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:10 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:10 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:10 --> Controller Class Initialized
INFO - 2021-04-28 08:12:10 --> Helper loaded: cookie_helper
INFO - 2021-04-28 08:12:10 --> Final output sent to browser
DEBUG - 2021-04-28 08:12:10 --> Total execution time: 0.1338
INFO - 2021-04-28 08:12:10 --> Config Class Initialized
INFO - 2021-04-28 08:12:10 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:10 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:10 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:10 --> URI Class Initialized
INFO - 2021-04-28 08:12:10 --> Router Class Initialized
INFO - 2021-04-28 08:12:10 --> Output Class Initialized
INFO - 2021-04-28 08:12:10 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:10 --> Input Class Initialized
INFO - 2021-04-28 08:12:10 --> Language Class Initialized
INFO - 2021-04-28 08:12:10 --> Language Class Initialized
INFO - 2021-04-28 08:12:10 --> Config Class Initialized
INFO - 2021-04-28 08:12:10 --> Loader Class Initialized
INFO - 2021-04-28 08:12:10 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:10 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:10 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:10 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:10 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:10 --> Controller Class Initialized
DEBUG - 2021-04-28 08:12:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 08:12:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:12:10 --> Final output sent to browser
DEBUG - 2021-04-28 08:12:10 --> Total execution time: 0.1433
INFO - 2021-04-28 08:12:12 --> Config Class Initialized
INFO - 2021-04-28 08:12:12 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:12 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:12 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:12 --> URI Class Initialized
INFO - 2021-04-28 08:12:13 --> Router Class Initialized
INFO - 2021-04-28 08:12:13 --> Output Class Initialized
INFO - 2021-04-28 08:12:13 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:13 --> Input Class Initialized
INFO - 2021-04-28 08:12:13 --> Language Class Initialized
INFO - 2021-04-28 08:12:13 --> Language Class Initialized
INFO - 2021-04-28 08:12:13 --> Config Class Initialized
INFO - 2021-04-28 08:12:13 --> Loader Class Initialized
INFO - 2021-04-28 08:12:13 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:13 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:13 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:13 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:13 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:13 --> Controller Class Initialized
DEBUG - 2021-04-28 08:12:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-04-28 08:12:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:12:13 --> Final output sent to browser
DEBUG - 2021-04-28 08:12:13 --> Total execution time: 0.1887
INFO - 2021-04-28 08:12:16 --> Config Class Initialized
INFO - 2021-04-28 08:12:16 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:16 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:16 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:16 --> URI Class Initialized
INFO - 2021-04-28 08:12:16 --> Router Class Initialized
INFO - 2021-04-28 08:12:16 --> Output Class Initialized
INFO - 2021-04-28 08:12:16 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:16 --> Input Class Initialized
INFO - 2021-04-28 08:12:16 --> Language Class Initialized
INFO - 2021-04-28 08:12:16 --> Language Class Initialized
INFO - 2021-04-28 08:12:16 --> Config Class Initialized
INFO - 2021-04-28 08:12:16 --> Loader Class Initialized
INFO - 2021-04-28 08:12:16 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:16 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:16 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:16 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:16 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:16 --> Controller Class Initialized
DEBUG - 2021-04-28 08:12:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-04-28 08:12:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:12:16 --> Final output sent to browser
DEBUG - 2021-04-28 08:12:16 --> Total execution time: 0.2116
INFO - 2021-04-28 08:12:17 --> Config Class Initialized
INFO - 2021-04-28 08:12:17 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:17 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:17 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:17 --> URI Class Initialized
INFO - 2021-04-28 08:12:17 --> Router Class Initialized
INFO - 2021-04-28 08:12:17 --> Output Class Initialized
INFO - 2021-04-28 08:12:17 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:17 --> Input Class Initialized
INFO - 2021-04-28 08:12:17 --> Language Class Initialized
INFO - 2021-04-28 08:12:17 --> Language Class Initialized
INFO - 2021-04-28 08:12:17 --> Config Class Initialized
INFO - 2021-04-28 08:12:17 --> Loader Class Initialized
INFO - 2021-04-28 08:12:17 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:17 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:17 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:17 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:17 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:17 --> Controller Class Initialized
DEBUG - 2021-04-28 08:12:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-04-28 08:12:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:12:17 --> Final output sent to browser
DEBUG - 2021-04-28 08:12:17 --> Total execution time: 0.1865
INFO - 2021-04-28 08:12:19 --> Config Class Initialized
INFO - 2021-04-28 08:12:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:12:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:12:19 --> Utf8 Class Initialized
INFO - 2021-04-28 08:12:19 --> URI Class Initialized
INFO - 2021-04-28 08:12:19 --> Router Class Initialized
INFO - 2021-04-28 08:12:19 --> Output Class Initialized
INFO - 2021-04-28 08:12:19 --> Security Class Initialized
DEBUG - 2021-04-28 08:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:12:19 --> Input Class Initialized
INFO - 2021-04-28 08:12:19 --> Language Class Initialized
INFO - 2021-04-28 08:12:19 --> Language Class Initialized
INFO - 2021-04-28 08:12:19 --> Config Class Initialized
INFO - 2021-04-28 08:12:19 --> Loader Class Initialized
INFO - 2021-04-28 08:12:19 --> Helper loaded: url_helper
INFO - 2021-04-28 08:12:19 --> Helper loaded: file_helper
INFO - 2021-04-28 08:12:19 --> Helper loaded: form_helper
INFO - 2021-04-28 08:12:19 --> Helper loaded: my_helper
INFO - 2021-04-28 08:12:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:12:19 --> Controller Class Initialized
ERROR - 2021-04-28 08:12:19 --> Query error: Unknown column 'b.ta' in 'where clause' - Invalid query: select 
                a.id_siswa ids, c.nama nmsiswa, a.nilai, a.desk
                from t_nilai_ekstra a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join m_siswa c on b.id_siswa = c.id
                inner join m_ekstra d on a.id_ekstra = d.id
                where a.id_ekstra = '10' 
                and b.id_kelas = '1' 
                and a.tasm = '20202' 
                and b.ta = '2020'
INFO - 2021-04-28 08:12:19 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 08:27:53 --> Config Class Initialized
INFO - 2021-04-28 08:27:53 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:27:53 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:27:53 --> Utf8 Class Initialized
INFO - 2021-04-28 08:27:53 --> URI Class Initialized
INFO - 2021-04-28 08:27:54 --> Router Class Initialized
INFO - 2021-04-28 08:27:54 --> Output Class Initialized
INFO - 2021-04-28 08:27:54 --> Security Class Initialized
DEBUG - 2021-04-28 08:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:27:54 --> Input Class Initialized
INFO - 2021-04-28 08:27:54 --> Language Class Initialized
INFO - 2021-04-28 08:27:54 --> Language Class Initialized
INFO - 2021-04-28 08:27:54 --> Config Class Initialized
INFO - 2021-04-28 08:27:54 --> Loader Class Initialized
INFO - 2021-04-28 08:27:54 --> Helper loaded: url_helper
INFO - 2021-04-28 08:27:54 --> Helper loaded: file_helper
INFO - 2021-04-28 08:27:54 --> Helper loaded: form_helper
INFO - 2021-04-28 08:27:54 --> Helper loaded: my_helper
INFO - 2021-04-28 08:27:55 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:27:55 --> Controller Class Initialized
DEBUG - 2021-04-28 08:27:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-04-28 08:27:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:27:55 --> Final output sent to browser
DEBUG - 2021-04-28 08:27:55 --> Total execution time: 2.1921
INFO - 2021-04-28 08:27:57 --> Config Class Initialized
INFO - 2021-04-28 08:27:57 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:27:57 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:27:57 --> Utf8 Class Initialized
INFO - 2021-04-28 08:27:57 --> URI Class Initialized
INFO - 2021-04-28 08:27:57 --> Router Class Initialized
INFO - 2021-04-28 08:27:57 --> Output Class Initialized
INFO - 2021-04-28 08:27:57 --> Security Class Initialized
DEBUG - 2021-04-28 08:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:27:57 --> Input Class Initialized
INFO - 2021-04-28 08:27:57 --> Language Class Initialized
INFO - 2021-04-28 08:27:57 --> Language Class Initialized
INFO - 2021-04-28 08:27:57 --> Config Class Initialized
INFO - 2021-04-28 08:27:57 --> Loader Class Initialized
INFO - 2021-04-28 08:27:57 --> Helper loaded: url_helper
INFO - 2021-04-28 08:27:57 --> Helper loaded: file_helper
INFO - 2021-04-28 08:27:57 --> Helper loaded: form_helper
INFO - 2021-04-28 08:27:57 --> Helper loaded: my_helper
INFO - 2021-04-28 08:27:57 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:27:57 --> Controller Class Initialized
ERROR - 2021-04-28 08:27:57 --> Query error: Unknown column 'b.ta' in 'where clause' - Invalid query: select 
                a.id_siswa ids, c.nama nmsiswa, a.nilai, a.desk
                from t_nilai_ekstra a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join m_siswa c on b.id_siswa = c.id
                inner join m_ekstra d on a.id_ekstra = d.id
                where a.id_ekstra = '11' 
                and b.id_kelas = '1' 
                and a.tasm = '20202' 
                and b.ta = '2020'
INFO - 2021-04-28 08:27:57 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 08:34:46 --> Config Class Initialized
INFO - 2021-04-28 08:34:46 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:34:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:34:46 --> Utf8 Class Initialized
INFO - 2021-04-28 08:34:46 --> URI Class Initialized
INFO - 2021-04-28 08:34:46 --> Router Class Initialized
INFO - 2021-04-28 08:34:46 --> Output Class Initialized
INFO - 2021-04-28 08:34:46 --> Security Class Initialized
DEBUG - 2021-04-28 08:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:34:46 --> Input Class Initialized
INFO - 2021-04-28 08:34:46 --> Language Class Initialized
INFO - 2021-04-28 08:34:46 --> Language Class Initialized
INFO - 2021-04-28 08:34:46 --> Config Class Initialized
INFO - 2021-04-28 08:34:46 --> Loader Class Initialized
INFO - 2021-04-28 08:34:46 --> Helper loaded: url_helper
INFO - 2021-04-28 08:34:46 --> Helper loaded: file_helper
INFO - 2021-04-28 08:34:46 --> Helper loaded: form_helper
INFO - 2021-04-28 08:34:46 --> Helper loaded: my_helper
INFO - 2021-04-28 08:34:46 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:34:46 --> Controller Class Initialized
DEBUG - 2021-04-28 08:34:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-04-28 08:34:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:34:46 --> Final output sent to browser
DEBUG - 2021-04-28 08:34:46 --> Total execution time: 0.1551
INFO - 2021-04-28 08:34:48 --> Config Class Initialized
INFO - 2021-04-28 08:34:48 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:34:48 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:34:48 --> Utf8 Class Initialized
INFO - 2021-04-28 08:34:48 --> URI Class Initialized
INFO - 2021-04-28 08:34:48 --> Router Class Initialized
INFO - 2021-04-28 08:34:48 --> Output Class Initialized
INFO - 2021-04-28 08:34:48 --> Security Class Initialized
DEBUG - 2021-04-28 08:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:34:48 --> Input Class Initialized
INFO - 2021-04-28 08:34:48 --> Language Class Initialized
INFO - 2021-04-28 08:34:48 --> Language Class Initialized
INFO - 2021-04-28 08:34:48 --> Config Class Initialized
INFO - 2021-04-28 08:34:48 --> Loader Class Initialized
INFO - 2021-04-28 08:34:48 --> Helper loaded: url_helper
INFO - 2021-04-28 08:34:48 --> Helper loaded: file_helper
INFO - 2021-04-28 08:34:48 --> Helper loaded: form_helper
INFO - 2021-04-28 08:34:48 --> Helper loaded: my_helper
INFO - 2021-04-28 08:34:48 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:34:48 --> Controller Class Initialized
INFO - 2021-04-28 08:34:48 --> Final output sent to browser
DEBUG - 2021-04-28 08:34:48 --> Total execution time: 0.2051
INFO - 2021-04-28 08:35:02 --> Config Class Initialized
INFO - 2021-04-28 08:35:02 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:35:02 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:35:02 --> Utf8 Class Initialized
INFO - 2021-04-28 08:35:02 --> URI Class Initialized
INFO - 2021-04-28 08:35:02 --> Router Class Initialized
INFO - 2021-04-28 08:35:02 --> Output Class Initialized
INFO - 2021-04-28 08:35:02 --> Security Class Initialized
DEBUG - 2021-04-28 08:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:35:02 --> Input Class Initialized
INFO - 2021-04-28 08:35:02 --> Language Class Initialized
INFO - 2021-04-28 08:35:03 --> Language Class Initialized
INFO - 2021-04-28 08:35:03 --> Config Class Initialized
INFO - 2021-04-28 08:35:03 --> Loader Class Initialized
INFO - 2021-04-28 08:35:03 --> Helper loaded: url_helper
INFO - 2021-04-28 08:35:03 --> Helper loaded: file_helper
INFO - 2021-04-28 08:35:03 --> Helper loaded: form_helper
INFO - 2021-04-28 08:35:03 --> Helper loaded: my_helper
INFO - 2021-04-28 08:35:03 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:35:03 --> Controller Class Initialized
INFO - 2021-04-28 08:35:03 --> Helper loaded: cookie_helper
INFO - 2021-04-28 08:35:03 --> Config Class Initialized
INFO - 2021-04-28 08:35:03 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:35:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:35:03 --> Utf8 Class Initialized
INFO - 2021-04-28 08:35:03 --> URI Class Initialized
INFO - 2021-04-28 08:35:03 --> Router Class Initialized
INFO - 2021-04-28 08:35:03 --> Output Class Initialized
INFO - 2021-04-28 08:35:03 --> Security Class Initialized
DEBUG - 2021-04-28 08:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:35:03 --> Input Class Initialized
INFO - 2021-04-28 08:35:03 --> Language Class Initialized
INFO - 2021-04-28 08:35:03 --> Language Class Initialized
INFO - 2021-04-28 08:35:03 --> Config Class Initialized
INFO - 2021-04-28 08:35:03 --> Loader Class Initialized
INFO - 2021-04-28 08:35:03 --> Helper loaded: url_helper
INFO - 2021-04-28 08:35:03 --> Helper loaded: file_helper
INFO - 2021-04-28 08:35:03 --> Helper loaded: form_helper
INFO - 2021-04-28 08:35:03 --> Helper loaded: my_helper
INFO - 2021-04-28 08:35:03 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:35:03 --> Controller Class Initialized
DEBUG - 2021-04-28 08:35:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 08:35:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:35:03 --> Final output sent to browser
DEBUG - 2021-04-28 08:35:03 --> Total execution time: 0.1523
INFO - 2021-04-28 08:35:07 --> Config Class Initialized
INFO - 2021-04-28 08:35:07 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:35:07 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:35:07 --> Utf8 Class Initialized
INFO - 2021-04-28 08:35:07 --> URI Class Initialized
INFO - 2021-04-28 08:35:07 --> Router Class Initialized
INFO - 2021-04-28 08:35:07 --> Output Class Initialized
INFO - 2021-04-28 08:35:07 --> Security Class Initialized
DEBUG - 2021-04-28 08:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:35:07 --> Input Class Initialized
INFO - 2021-04-28 08:35:07 --> Language Class Initialized
INFO - 2021-04-28 08:35:07 --> Language Class Initialized
INFO - 2021-04-28 08:35:07 --> Config Class Initialized
INFO - 2021-04-28 08:35:07 --> Loader Class Initialized
INFO - 2021-04-28 08:35:07 --> Helper loaded: url_helper
INFO - 2021-04-28 08:35:07 --> Helper loaded: file_helper
INFO - 2021-04-28 08:35:07 --> Helper loaded: form_helper
INFO - 2021-04-28 08:35:07 --> Helper loaded: my_helper
INFO - 2021-04-28 08:35:07 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:35:07 --> Controller Class Initialized
INFO - 2021-04-28 08:35:08 --> Helper loaded: cookie_helper
INFO - 2021-04-28 08:35:08 --> Final output sent to browser
DEBUG - 2021-04-28 08:35:08 --> Total execution time: 0.2355
INFO - 2021-04-28 08:35:08 --> Config Class Initialized
INFO - 2021-04-28 08:35:08 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:35:08 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:35:08 --> Utf8 Class Initialized
INFO - 2021-04-28 08:35:08 --> URI Class Initialized
INFO - 2021-04-28 08:35:08 --> Router Class Initialized
INFO - 2021-04-28 08:35:08 --> Output Class Initialized
INFO - 2021-04-28 08:35:08 --> Security Class Initialized
DEBUG - 2021-04-28 08:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:35:08 --> Input Class Initialized
INFO - 2021-04-28 08:35:08 --> Language Class Initialized
INFO - 2021-04-28 08:35:08 --> Language Class Initialized
INFO - 2021-04-28 08:35:08 --> Config Class Initialized
INFO - 2021-04-28 08:35:08 --> Loader Class Initialized
INFO - 2021-04-28 08:35:08 --> Helper loaded: url_helper
INFO - 2021-04-28 08:35:08 --> Helper loaded: file_helper
INFO - 2021-04-28 08:35:08 --> Helper loaded: form_helper
INFO - 2021-04-28 08:35:08 --> Helper loaded: my_helper
INFO - 2021-04-28 08:35:08 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:35:08 --> Controller Class Initialized
DEBUG - 2021-04-28 08:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-28 08:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:35:08 --> Final output sent to browser
DEBUG - 2021-04-28 08:35:08 --> Total execution time: 0.2692
INFO - 2021-04-28 08:35:11 --> Config Class Initialized
INFO - 2021-04-28 08:35:11 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:35:11 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:35:11 --> Utf8 Class Initialized
INFO - 2021-04-28 08:35:11 --> URI Class Initialized
INFO - 2021-04-28 08:35:11 --> Router Class Initialized
INFO - 2021-04-28 08:35:11 --> Output Class Initialized
INFO - 2021-04-28 08:35:11 --> Security Class Initialized
DEBUG - 2021-04-28 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:35:12 --> Input Class Initialized
INFO - 2021-04-28 08:35:12 --> Language Class Initialized
INFO - 2021-04-28 08:35:12 --> Language Class Initialized
INFO - 2021-04-28 08:35:12 --> Config Class Initialized
INFO - 2021-04-28 08:35:12 --> Loader Class Initialized
INFO - 2021-04-28 08:35:12 --> Helper loaded: url_helper
INFO - 2021-04-28 08:35:12 --> Helper loaded: file_helper
INFO - 2021-04-28 08:35:12 --> Helper loaded: form_helper
INFO - 2021-04-28 08:35:12 --> Helper loaded: my_helper
INFO - 2021-04-28 08:35:12 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:35:12 --> Controller Class Initialized
ERROR - 2021-04-28 08:35:12 --> Query error: Unknown column 'a.tasm' in 'where clause' - Invalid query: SELECT 
                                                        a.id, a.id_kelas, b.nama nmsiswa
                                                        FROM t_kelas_siswa a
                                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                        WHERE a.id_kelas = '1' 
                                                        AND a.tasm = '20202'
                                                        ORDER BY b.nama ASC, b.nis ASC
INFO - 2021-04-28 08:35:12 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 08:41:28 --> Config Class Initialized
INFO - 2021-04-28 08:41:28 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:41:28 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:41:28 --> Utf8 Class Initialized
INFO - 2021-04-28 08:41:28 --> URI Class Initialized
INFO - 2021-04-28 08:41:28 --> Router Class Initialized
INFO - 2021-04-28 08:41:28 --> Output Class Initialized
INFO - 2021-04-28 08:41:28 --> Security Class Initialized
DEBUG - 2021-04-28 08:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:41:28 --> Input Class Initialized
INFO - 2021-04-28 08:41:29 --> Language Class Initialized
INFO - 2021-04-28 08:41:29 --> Language Class Initialized
INFO - 2021-04-28 08:41:29 --> Config Class Initialized
INFO - 2021-04-28 08:41:29 --> Loader Class Initialized
INFO - 2021-04-28 08:41:29 --> Helper loaded: url_helper
INFO - 2021-04-28 08:41:29 --> Helper loaded: file_helper
INFO - 2021-04-28 08:41:29 --> Helper loaded: form_helper
INFO - 2021-04-28 08:41:29 --> Helper loaded: my_helper
INFO - 2021-04-28 08:41:29 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:41:29 --> Controller Class Initialized
ERROR - 2021-04-28 08:41:30 --> Query error: Unknown column 'a.tasm' in 'where clause' - Invalid query: SELECT 
                                                        a.id, a.id_kelas, b.nama nmsiswa
                                                        FROM t_kelas_siswa a
                                                        INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                        WHERE a.id_kelas = '1' 
                                                        AND a.tasm = '20202'
                                                        ORDER BY b.nama ASC, b.nis ASC
INFO - 2021-04-28 08:41:30 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-28 08:45:14 --> Config Class Initialized
INFO - 2021-04-28 08:45:14 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:45:14 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:45:14 --> Utf8 Class Initialized
INFO - 2021-04-28 08:45:14 --> URI Class Initialized
INFO - 2021-04-28 08:45:14 --> Router Class Initialized
INFO - 2021-04-28 08:45:14 --> Output Class Initialized
INFO - 2021-04-28 08:45:14 --> Security Class Initialized
DEBUG - 2021-04-28 08:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:45:14 --> Input Class Initialized
INFO - 2021-04-28 08:45:14 --> Language Class Initialized
INFO - 2021-04-28 08:45:14 --> Language Class Initialized
INFO - 2021-04-28 08:45:14 --> Config Class Initialized
INFO - 2021-04-28 08:45:14 --> Loader Class Initialized
INFO - 2021-04-28 08:45:14 --> Helper loaded: url_helper
INFO - 2021-04-28 08:45:14 --> Helper loaded: file_helper
INFO - 2021-04-28 08:45:14 --> Helper loaded: form_helper
INFO - 2021-04-28 08:45:14 --> Helper loaded: my_helper
INFO - 2021-04-28 08:45:14 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:45:14 --> Controller Class Initialized
DEBUG - 2021-04-28 08:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-28 08:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:45:14 --> Final output sent to browser
DEBUG - 2021-04-28 08:45:14 --> Total execution time: 0.2625
INFO - 2021-04-28 08:45:19 --> Config Class Initialized
INFO - 2021-04-28 08:45:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:45:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:45:19 --> Utf8 Class Initialized
INFO - 2021-04-28 08:45:19 --> URI Class Initialized
INFO - 2021-04-28 08:45:19 --> Router Class Initialized
INFO - 2021-04-28 08:45:19 --> Output Class Initialized
INFO - 2021-04-28 08:45:19 --> Security Class Initialized
DEBUG - 2021-04-28 08:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:45:19 --> Input Class Initialized
INFO - 2021-04-28 08:45:19 --> Language Class Initialized
INFO - 2021-04-28 08:45:19 --> Language Class Initialized
INFO - 2021-04-28 08:45:19 --> Config Class Initialized
INFO - 2021-04-28 08:45:19 --> Loader Class Initialized
INFO - 2021-04-28 08:45:19 --> Helper loaded: url_helper
INFO - 2021-04-28 08:45:19 --> Helper loaded: file_helper
INFO - 2021-04-28 08:45:19 --> Helper loaded: form_helper
INFO - 2021-04-28 08:45:19 --> Helper loaded: my_helper
INFO - 2021-04-28 08:45:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:45:19 --> Controller Class Initialized
INFO - 2021-04-28 08:45:19 --> Helper loaded: cookie_helper
INFO - 2021-04-28 08:45:19 --> Config Class Initialized
INFO - 2021-04-28 08:45:19 --> Hooks Class Initialized
DEBUG - 2021-04-28 08:45:19 --> UTF-8 Support Enabled
INFO - 2021-04-28 08:45:19 --> Utf8 Class Initialized
INFO - 2021-04-28 08:45:19 --> URI Class Initialized
INFO - 2021-04-28 08:45:19 --> Router Class Initialized
INFO - 2021-04-28 08:45:19 --> Output Class Initialized
INFO - 2021-04-28 08:45:19 --> Security Class Initialized
DEBUG - 2021-04-28 08:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 08:45:19 --> Input Class Initialized
INFO - 2021-04-28 08:45:19 --> Language Class Initialized
INFO - 2021-04-28 08:45:19 --> Language Class Initialized
INFO - 2021-04-28 08:45:19 --> Config Class Initialized
INFO - 2021-04-28 08:45:19 --> Loader Class Initialized
INFO - 2021-04-28 08:45:19 --> Helper loaded: url_helper
INFO - 2021-04-28 08:45:19 --> Helper loaded: file_helper
INFO - 2021-04-28 08:45:19 --> Helper loaded: form_helper
INFO - 2021-04-28 08:45:19 --> Helper loaded: my_helper
INFO - 2021-04-28 08:45:19 --> Database Driver Class Initialized
DEBUG - 2021-04-28 08:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 08:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 08:45:19 --> Controller Class Initialized
DEBUG - 2021-04-28 08:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-28 08:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-28 08:45:19 --> Final output sent to browser
DEBUG - 2021-04-28 08:45:19 --> Total execution time: 0.2805
