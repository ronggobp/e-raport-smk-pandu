<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-03 09:25:21 --> Config Class Initialized
INFO - 2021-12-03 09:25:21 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:21 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:21 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:21 --> URI Class Initialized
DEBUG - 2021-12-03 09:25:21 --> No URI present. Default controller set.
INFO - 2021-12-03 09:25:21 --> Router Class Initialized
INFO - 2021-12-03 09:25:21 --> Output Class Initialized
INFO - 2021-12-03 09:25:21 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:21 --> Input Class Initialized
INFO - 2021-12-03 09:25:21 --> Language Class Initialized
INFO - 2021-12-03 09:25:21 --> Language Class Initialized
INFO - 2021-12-03 09:25:21 --> Config Class Initialized
INFO - 2021-12-03 09:25:21 --> Loader Class Initialized
INFO - 2021-12-03 09:25:21 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:21 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:21 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:21 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:21 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:21 --> Controller Class Initialized
INFO - 2021-12-03 09:25:21 --> Config Class Initialized
INFO - 2021-12-03 09:25:21 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:21 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:21 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:21 --> URI Class Initialized
INFO - 2021-12-03 09:25:21 --> Router Class Initialized
INFO - 2021-12-03 09:25:21 --> Output Class Initialized
INFO - 2021-12-03 09:25:21 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:21 --> Input Class Initialized
INFO - 2021-12-03 09:25:21 --> Language Class Initialized
INFO - 2021-12-03 09:25:21 --> Language Class Initialized
INFO - 2021-12-03 09:25:21 --> Config Class Initialized
INFO - 2021-12-03 09:25:21 --> Loader Class Initialized
INFO - 2021-12-03 09:25:21 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:21 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:22 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:22 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:22 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:22 --> Controller Class Initialized
DEBUG - 2021-12-03 09:25:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-03 09:25:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-03 09:25:22 --> Final output sent to browser
DEBUG - 2021-12-03 09:25:22 --> Total execution time: 0.1276
INFO - 2021-12-03 09:25:26 --> Config Class Initialized
INFO - 2021-12-03 09:25:26 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:26 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:26 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:26 --> URI Class Initialized
INFO - 2021-12-03 09:25:26 --> Router Class Initialized
INFO - 2021-12-03 09:25:26 --> Output Class Initialized
INFO - 2021-12-03 09:25:26 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:26 --> Input Class Initialized
INFO - 2021-12-03 09:25:26 --> Language Class Initialized
INFO - 2021-12-03 09:25:26 --> Language Class Initialized
INFO - 2021-12-03 09:25:26 --> Config Class Initialized
INFO - 2021-12-03 09:25:26 --> Loader Class Initialized
INFO - 2021-12-03 09:25:26 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:26 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:26 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:26 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:26 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:26 --> Controller Class Initialized
INFO - 2021-12-03 09:25:26 --> Helper loaded: cookie_helper
INFO - 2021-12-03 09:25:26 --> Final output sent to browser
DEBUG - 2021-12-03 09:25:26 --> Total execution time: 0.1097
INFO - 2021-12-03 09:25:26 --> Config Class Initialized
INFO - 2021-12-03 09:25:26 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:26 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:26 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:26 --> URI Class Initialized
INFO - 2021-12-03 09:25:26 --> Router Class Initialized
INFO - 2021-12-03 09:25:26 --> Output Class Initialized
INFO - 2021-12-03 09:25:26 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:26 --> Input Class Initialized
INFO - 2021-12-03 09:25:26 --> Language Class Initialized
INFO - 2021-12-03 09:25:26 --> Language Class Initialized
INFO - 2021-12-03 09:25:26 --> Config Class Initialized
INFO - 2021-12-03 09:25:26 --> Loader Class Initialized
INFO - 2021-12-03 09:25:26 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:26 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:26 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:26 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:26 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:26 --> Controller Class Initialized
DEBUG - 2021-12-03 09:25:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-03 09:25:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-03 09:25:27 --> Final output sent to browser
DEBUG - 2021-12-03 09:25:27 --> Total execution time: 1.1061
INFO - 2021-12-03 09:25:30 --> Config Class Initialized
INFO - 2021-12-03 09:25:30 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:30 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:30 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:30 --> URI Class Initialized
INFO - 2021-12-03 09:25:30 --> Router Class Initialized
INFO - 2021-12-03 09:25:30 --> Output Class Initialized
INFO - 2021-12-03 09:25:30 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:30 --> Input Class Initialized
INFO - 2021-12-03 09:25:30 --> Language Class Initialized
INFO - 2021-12-03 09:25:30 --> Language Class Initialized
INFO - 2021-12-03 09:25:30 --> Config Class Initialized
INFO - 2021-12-03 09:25:30 --> Loader Class Initialized
INFO - 2021-12-03 09:25:30 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:30 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:30 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:30 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:30 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:30 --> Controller Class Initialized
DEBUG - 2021-12-03 09:25:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-03 09:25:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-03 09:25:30 --> Final output sent to browser
DEBUG - 2021-12-03 09:25:30 --> Total execution time: 0.0879
INFO - 2021-12-03 09:25:30 --> Config Class Initialized
INFO - 2021-12-03 09:25:30 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:30 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:30 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:30 --> URI Class Initialized
INFO - 2021-12-03 09:25:30 --> Router Class Initialized
INFO - 2021-12-03 09:25:30 --> Output Class Initialized
INFO - 2021-12-03 09:25:30 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:30 --> Input Class Initialized
INFO - 2021-12-03 09:25:30 --> Language Class Initialized
INFO - 2021-12-03 09:25:30 --> Language Class Initialized
INFO - 2021-12-03 09:25:30 --> Config Class Initialized
INFO - 2021-12-03 09:25:30 --> Loader Class Initialized
INFO - 2021-12-03 09:25:30 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:30 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:30 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:30 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:30 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:30 --> Controller Class Initialized
INFO - 2021-12-03 09:25:38 --> Config Class Initialized
INFO - 2021-12-03 09:25:38 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:38 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:38 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:38 --> URI Class Initialized
INFO - 2021-12-03 09:25:38 --> Router Class Initialized
INFO - 2021-12-03 09:25:38 --> Output Class Initialized
INFO - 2021-12-03 09:25:38 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:38 --> Input Class Initialized
INFO - 2021-12-03 09:25:38 --> Language Class Initialized
INFO - 2021-12-03 09:25:38 --> Language Class Initialized
INFO - 2021-12-03 09:25:38 --> Config Class Initialized
INFO - 2021-12-03 09:25:38 --> Loader Class Initialized
INFO - 2021-12-03 09:25:38 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:38 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:38 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:38 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:38 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:38 --> Controller Class Initialized
INFO - 2021-12-03 09:25:38 --> Helper loaded: cookie_helper
INFO - 2021-12-03 09:25:38 --> Config Class Initialized
INFO - 2021-12-03 09:25:38 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:38 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:38 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:38 --> URI Class Initialized
INFO - 2021-12-03 09:25:38 --> Router Class Initialized
INFO - 2021-12-03 09:25:38 --> Output Class Initialized
INFO - 2021-12-03 09:25:38 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:38 --> Input Class Initialized
INFO - 2021-12-03 09:25:38 --> Language Class Initialized
INFO - 2021-12-03 09:25:38 --> Language Class Initialized
INFO - 2021-12-03 09:25:38 --> Config Class Initialized
INFO - 2021-12-03 09:25:38 --> Loader Class Initialized
INFO - 2021-12-03 09:25:38 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:38 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:38 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:38 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:38 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:38 --> Controller Class Initialized
DEBUG - 2021-12-03 09:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-03 09:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-03 09:25:38 --> Final output sent to browser
DEBUG - 2021-12-03 09:25:38 --> Total execution time: 0.0646
INFO - 2021-12-03 09:25:48 --> Config Class Initialized
INFO - 2021-12-03 09:25:48 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:48 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:48 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:48 --> URI Class Initialized
INFO - 2021-12-03 09:25:48 --> Router Class Initialized
INFO - 2021-12-03 09:25:48 --> Output Class Initialized
INFO - 2021-12-03 09:25:48 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:48 --> Input Class Initialized
INFO - 2021-12-03 09:25:48 --> Language Class Initialized
INFO - 2021-12-03 09:25:48 --> Language Class Initialized
INFO - 2021-12-03 09:25:48 --> Config Class Initialized
INFO - 2021-12-03 09:25:48 --> Loader Class Initialized
INFO - 2021-12-03 09:25:48 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:48 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:48 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:48 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:49 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:49 --> Controller Class Initialized
INFO - 2021-12-03 09:25:49 --> Helper loaded: cookie_helper
INFO - 2021-12-03 09:25:49 --> Final output sent to browser
DEBUG - 2021-12-03 09:25:49 --> Total execution time: 0.0793
INFO - 2021-12-03 09:25:49 --> Config Class Initialized
INFO - 2021-12-03 09:25:49 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:49 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:49 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:49 --> URI Class Initialized
INFO - 2021-12-03 09:25:49 --> Router Class Initialized
INFO - 2021-12-03 09:25:49 --> Output Class Initialized
INFO - 2021-12-03 09:25:49 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:49 --> Input Class Initialized
INFO - 2021-12-03 09:25:49 --> Language Class Initialized
INFO - 2021-12-03 09:25:49 --> Language Class Initialized
INFO - 2021-12-03 09:25:49 --> Config Class Initialized
INFO - 2021-12-03 09:25:49 --> Loader Class Initialized
INFO - 2021-12-03 09:25:49 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:49 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:49 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:49 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:49 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:49 --> Controller Class Initialized
DEBUG - 2021-12-03 09:25:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-03 09:25:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-03 09:25:50 --> Final output sent to browser
DEBUG - 2021-12-03 09:25:50 --> Total execution time: 1.0808
INFO - 2021-12-03 09:25:51 --> Config Class Initialized
INFO - 2021-12-03 09:25:51 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:51 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:51 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:51 --> URI Class Initialized
INFO - 2021-12-03 09:25:51 --> Router Class Initialized
INFO - 2021-12-03 09:25:51 --> Output Class Initialized
INFO - 2021-12-03 09:25:51 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:51 --> Input Class Initialized
INFO - 2021-12-03 09:25:51 --> Language Class Initialized
INFO - 2021-12-03 09:25:51 --> Language Class Initialized
INFO - 2021-12-03 09:25:51 --> Config Class Initialized
INFO - 2021-12-03 09:25:51 --> Loader Class Initialized
INFO - 2021-12-03 09:25:51 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:52 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:52 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:52 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:52 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:52 --> Controller Class Initialized
DEBUG - 2021-12-03 09:25:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-03 09:25:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-03 09:25:52 --> Final output sent to browser
DEBUG - 2021-12-03 09:25:52 --> Total execution time: 0.1323
INFO - 2021-12-03 09:25:54 --> Config Class Initialized
INFO - 2021-12-03 09:25:54 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:25:54 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:25:54 --> Utf8 Class Initialized
INFO - 2021-12-03 09:25:54 --> URI Class Initialized
INFO - 2021-12-03 09:25:54 --> Router Class Initialized
INFO - 2021-12-03 09:25:54 --> Output Class Initialized
INFO - 2021-12-03 09:25:54 --> Security Class Initialized
DEBUG - 2021-12-03 09:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:25:54 --> Input Class Initialized
INFO - 2021-12-03 09:25:54 --> Language Class Initialized
INFO - 2021-12-03 09:25:54 --> Language Class Initialized
INFO - 2021-12-03 09:25:54 --> Config Class Initialized
INFO - 2021-12-03 09:25:54 --> Loader Class Initialized
INFO - 2021-12-03 09:25:54 --> Helper loaded: url_helper
INFO - 2021-12-03 09:25:54 --> Helper loaded: file_helper
INFO - 2021-12-03 09:25:54 --> Helper loaded: form_helper
INFO - 2021-12-03 09:25:54 --> Helper loaded: my_helper
INFO - 2021-12-03 09:25:54 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:25:54 --> Controller Class Initialized
DEBUG - 2021-12-03 09:25:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:25:54 --> Final output sent to browser
DEBUG - 2021-12-03 09:25:54 --> Total execution time: 0.2311
INFO - 2021-12-03 09:28:02 --> Config Class Initialized
INFO - 2021-12-03 09:28:02 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:28:02 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:28:02 --> Utf8 Class Initialized
INFO - 2021-12-03 09:28:02 --> URI Class Initialized
INFO - 2021-12-03 09:28:02 --> Router Class Initialized
INFO - 2021-12-03 09:28:02 --> Output Class Initialized
INFO - 2021-12-03 09:28:02 --> Security Class Initialized
DEBUG - 2021-12-03 09:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:28:02 --> Input Class Initialized
INFO - 2021-12-03 09:28:02 --> Language Class Initialized
INFO - 2021-12-03 09:28:02 --> Language Class Initialized
INFO - 2021-12-03 09:28:02 --> Config Class Initialized
INFO - 2021-12-03 09:28:02 --> Loader Class Initialized
INFO - 2021-12-03 09:28:02 --> Helper loaded: url_helper
INFO - 2021-12-03 09:28:02 --> Helper loaded: file_helper
INFO - 2021-12-03 09:28:02 --> Helper loaded: form_helper
INFO - 2021-12-03 09:28:02 --> Helper loaded: my_helper
INFO - 2021-12-03 09:28:02 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:28:02 --> Controller Class Initialized
DEBUG - 2021-12-03 09:28:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:28:02 --> Final output sent to browser
DEBUG - 2021-12-03 09:28:02 --> Total execution time: 0.1556
INFO - 2021-12-03 09:29:19 --> Config Class Initialized
INFO - 2021-12-03 09:29:19 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:29:19 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:29:19 --> Utf8 Class Initialized
INFO - 2021-12-03 09:29:19 --> URI Class Initialized
INFO - 2021-12-03 09:29:19 --> Router Class Initialized
INFO - 2021-12-03 09:29:19 --> Output Class Initialized
INFO - 2021-12-03 09:29:19 --> Security Class Initialized
DEBUG - 2021-12-03 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:29:19 --> Input Class Initialized
INFO - 2021-12-03 09:29:19 --> Language Class Initialized
INFO - 2021-12-03 09:29:19 --> Language Class Initialized
INFO - 2021-12-03 09:29:19 --> Config Class Initialized
INFO - 2021-12-03 09:29:19 --> Loader Class Initialized
INFO - 2021-12-03 09:29:19 --> Helper loaded: url_helper
INFO - 2021-12-03 09:29:19 --> Helper loaded: file_helper
INFO - 2021-12-03 09:29:19 --> Helper loaded: form_helper
INFO - 2021-12-03 09:29:19 --> Helper loaded: my_helper
INFO - 2021-12-03 09:29:19 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:29:19 --> Controller Class Initialized
DEBUG - 2021-12-03 09:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:29:19 --> Final output sent to browser
DEBUG - 2021-12-03 09:29:19 --> Total execution time: 0.1396
INFO - 2021-12-03 09:29:38 --> Config Class Initialized
INFO - 2021-12-03 09:29:38 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:29:38 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:29:38 --> Utf8 Class Initialized
INFO - 2021-12-03 09:29:38 --> URI Class Initialized
INFO - 2021-12-03 09:29:38 --> Router Class Initialized
INFO - 2021-12-03 09:29:38 --> Output Class Initialized
INFO - 2021-12-03 09:29:38 --> Security Class Initialized
DEBUG - 2021-12-03 09:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:29:38 --> Input Class Initialized
INFO - 2021-12-03 09:29:38 --> Language Class Initialized
INFO - 2021-12-03 09:29:38 --> Language Class Initialized
INFO - 2021-12-03 09:29:38 --> Config Class Initialized
INFO - 2021-12-03 09:29:38 --> Loader Class Initialized
INFO - 2021-12-03 09:29:38 --> Helper loaded: url_helper
INFO - 2021-12-03 09:29:38 --> Helper loaded: file_helper
INFO - 2021-12-03 09:29:38 --> Helper loaded: form_helper
INFO - 2021-12-03 09:29:38 --> Helper loaded: my_helper
INFO - 2021-12-03 09:29:38 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:29:38 --> Controller Class Initialized
DEBUG - 2021-12-03 09:29:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:29:38 --> Final output sent to browser
DEBUG - 2021-12-03 09:29:38 --> Total execution time: 0.1258
INFO - 2021-12-03 09:30:01 --> Config Class Initialized
INFO - 2021-12-03 09:30:01 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:30:01 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:30:01 --> Utf8 Class Initialized
INFO - 2021-12-03 09:30:01 --> URI Class Initialized
INFO - 2021-12-03 09:30:01 --> Router Class Initialized
INFO - 2021-12-03 09:30:01 --> Output Class Initialized
INFO - 2021-12-03 09:30:01 --> Security Class Initialized
DEBUG - 2021-12-03 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:30:01 --> Input Class Initialized
INFO - 2021-12-03 09:30:01 --> Language Class Initialized
INFO - 2021-12-03 09:30:01 --> Language Class Initialized
INFO - 2021-12-03 09:30:01 --> Config Class Initialized
INFO - 2021-12-03 09:30:01 --> Loader Class Initialized
INFO - 2021-12-03 09:30:01 --> Helper loaded: url_helper
INFO - 2021-12-03 09:30:01 --> Helper loaded: file_helper
INFO - 2021-12-03 09:30:01 --> Helper loaded: form_helper
INFO - 2021-12-03 09:30:01 --> Helper loaded: my_helper
INFO - 2021-12-03 09:30:01 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:30:01 --> Controller Class Initialized
DEBUG - 2021-12-03 09:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:30:01 --> Final output sent to browser
DEBUG - 2021-12-03 09:30:01 --> Total execution time: 0.1380
INFO - 2021-12-03 09:33:17 --> Config Class Initialized
INFO - 2021-12-03 09:33:17 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:33:17 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:33:17 --> Utf8 Class Initialized
INFO - 2021-12-03 09:33:17 --> URI Class Initialized
INFO - 2021-12-03 09:33:17 --> Router Class Initialized
INFO - 2021-12-03 09:33:17 --> Output Class Initialized
INFO - 2021-12-03 09:33:17 --> Security Class Initialized
DEBUG - 2021-12-03 09:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:33:17 --> Input Class Initialized
INFO - 2021-12-03 09:33:17 --> Language Class Initialized
INFO - 2021-12-03 09:33:17 --> Language Class Initialized
INFO - 2021-12-03 09:33:17 --> Config Class Initialized
INFO - 2021-12-03 09:33:17 --> Loader Class Initialized
INFO - 2021-12-03 09:33:17 --> Helper loaded: url_helper
INFO - 2021-12-03 09:33:17 --> Helper loaded: file_helper
INFO - 2021-12-03 09:33:17 --> Helper loaded: form_helper
INFO - 2021-12-03 09:33:17 --> Helper loaded: my_helper
INFO - 2021-12-03 09:33:17 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:33:17 --> Controller Class Initialized
DEBUG - 2021-12-03 09:33:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:33:17 --> Final output sent to browser
DEBUG - 2021-12-03 09:33:17 --> Total execution time: 0.1455
INFO - 2021-12-03 09:33:58 --> Config Class Initialized
INFO - 2021-12-03 09:33:58 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:33:58 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:33:58 --> Utf8 Class Initialized
INFO - 2021-12-03 09:33:58 --> URI Class Initialized
INFO - 2021-12-03 09:33:58 --> Router Class Initialized
INFO - 2021-12-03 09:33:58 --> Output Class Initialized
INFO - 2021-12-03 09:33:58 --> Security Class Initialized
DEBUG - 2021-12-03 09:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:33:58 --> Input Class Initialized
INFO - 2021-12-03 09:33:58 --> Language Class Initialized
INFO - 2021-12-03 09:33:58 --> Language Class Initialized
INFO - 2021-12-03 09:33:58 --> Config Class Initialized
INFO - 2021-12-03 09:33:58 --> Loader Class Initialized
INFO - 2021-12-03 09:33:58 --> Helper loaded: url_helper
INFO - 2021-12-03 09:33:58 --> Helper loaded: file_helper
INFO - 2021-12-03 09:33:58 --> Helper loaded: form_helper
INFO - 2021-12-03 09:33:58 --> Helper loaded: my_helper
INFO - 2021-12-03 09:33:58 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:33:58 --> Controller Class Initialized
DEBUG - 2021-12-03 09:33:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:33:58 --> Final output sent to browser
DEBUG - 2021-12-03 09:33:58 --> Total execution time: 0.1566
INFO - 2021-12-03 09:34:21 --> Config Class Initialized
INFO - 2021-12-03 09:34:21 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:34:21 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:34:21 --> Utf8 Class Initialized
INFO - 2021-12-03 09:34:21 --> URI Class Initialized
INFO - 2021-12-03 09:34:21 --> Router Class Initialized
INFO - 2021-12-03 09:34:21 --> Output Class Initialized
INFO - 2021-12-03 09:34:21 --> Security Class Initialized
DEBUG - 2021-12-03 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:34:21 --> Input Class Initialized
INFO - 2021-12-03 09:34:21 --> Language Class Initialized
INFO - 2021-12-03 09:34:21 --> Language Class Initialized
INFO - 2021-12-03 09:34:21 --> Config Class Initialized
INFO - 2021-12-03 09:34:21 --> Loader Class Initialized
INFO - 2021-12-03 09:34:21 --> Helper loaded: url_helper
INFO - 2021-12-03 09:34:21 --> Helper loaded: file_helper
INFO - 2021-12-03 09:34:21 --> Helper loaded: form_helper
INFO - 2021-12-03 09:34:21 --> Helper loaded: my_helper
INFO - 2021-12-03 09:34:21 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:34:21 --> Controller Class Initialized
DEBUG - 2021-12-03 09:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:34:21 --> Final output sent to browser
DEBUG - 2021-12-03 09:34:21 --> Total execution time: 0.1623
INFO - 2021-12-03 09:35:28 --> Config Class Initialized
INFO - 2021-12-03 09:35:28 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:35:28 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:35:28 --> Utf8 Class Initialized
INFO - 2021-12-03 09:35:28 --> URI Class Initialized
INFO - 2021-12-03 09:35:28 --> Router Class Initialized
INFO - 2021-12-03 09:35:28 --> Output Class Initialized
INFO - 2021-12-03 09:35:28 --> Security Class Initialized
DEBUG - 2021-12-03 09:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:35:28 --> Input Class Initialized
INFO - 2021-12-03 09:35:28 --> Language Class Initialized
INFO - 2021-12-03 09:35:28 --> Language Class Initialized
INFO - 2021-12-03 09:35:28 --> Config Class Initialized
INFO - 2021-12-03 09:35:28 --> Loader Class Initialized
INFO - 2021-12-03 09:35:28 --> Helper loaded: url_helper
INFO - 2021-12-03 09:35:28 --> Helper loaded: file_helper
INFO - 2021-12-03 09:35:28 --> Helper loaded: form_helper
INFO - 2021-12-03 09:35:28 --> Helper loaded: my_helper
INFO - 2021-12-03 09:35:28 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:35:28 --> Controller Class Initialized
DEBUG - 2021-12-03 09:35:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:35:28 --> Final output sent to browser
DEBUG - 2021-12-03 09:35:28 --> Total execution time: 0.1384
INFO - 2021-12-03 09:35:44 --> Config Class Initialized
INFO - 2021-12-03 09:35:44 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:35:44 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:35:44 --> Utf8 Class Initialized
INFO - 2021-12-03 09:35:44 --> URI Class Initialized
INFO - 2021-12-03 09:35:44 --> Router Class Initialized
INFO - 2021-12-03 09:35:44 --> Output Class Initialized
INFO - 2021-12-03 09:35:44 --> Security Class Initialized
DEBUG - 2021-12-03 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:35:44 --> Input Class Initialized
INFO - 2021-12-03 09:35:44 --> Language Class Initialized
INFO - 2021-12-03 09:35:44 --> Language Class Initialized
INFO - 2021-12-03 09:35:44 --> Config Class Initialized
INFO - 2021-12-03 09:35:44 --> Loader Class Initialized
INFO - 2021-12-03 09:35:44 --> Helper loaded: url_helper
INFO - 2021-12-03 09:35:44 --> Helper loaded: file_helper
INFO - 2021-12-03 09:35:44 --> Helper loaded: form_helper
INFO - 2021-12-03 09:35:44 --> Helper loaded: my_helper
INFO - 2021-12-03 09:35:44 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:35:44 --> Controller Class Initialized
DEBUG - 2021-12-03 09:35:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:35:44 --> Final output sent to browser
DEBUG - 2021-12-03 09:35:44 --> Total execution time: 0.1401
INFO - 2021-12-03 09:35:46 --> Config Class Initialized
INFO - 2021-12-03 09:35:46 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:35:46 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:35:46 --> Utf8 Class Initialized
INFO - 2021-12-03 09:35:46 --> URI Class Initialized
INFO - 2021-12-03 09:35:46 --> Router Class Initialized
INFO - 2021-12-03 09:35:46 --> Output Class Initialized
INFO - 2021-12-03 09:35:46 --> Security Class Initialized
DEBUG - 2021-12-03 09:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:35:46 --> Input Class Initialized
INFO - 2021-12-03 09:35:46 --> Language Class Initialized
INFO - 2021-12-03 09:35:46 --> Language Class Initialized
INFO - 2021-12-03 09:35:46 --> Config Class Initialized
INFO - 2021-12-03 09:35:46 --> Loader Class Initialized
INFO - 2021-12-03 09:35:46 --> Helper loaded: url_helper
INFO - 2021-12-03 09:35:46 --> Helper loaded: file_helper
INFO - 2021-12-03 09:35:46 --> Helper loaded: form_helper
INFO - 2021-12-03 09:35:46 --> Helper loaded: my_helper
INFO - 2021-12-03 09:35:46 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:35:46 --> Controller Class Initialized
DEBUG - 2021-12-03 09:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:35:46 --> Final output sent to browser
DEBUG - 2021-12-03 09:35:46 --> Total execution time: 0.1430
INFO - 2021-12-03 09:39:20 --> Config Class Initialized
INFO - 2021-12-03 09:39:20 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:39:20 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:39:20 --> Utf8 Class Initialized
INFO - 2021-12-03 09:39:20 --> URI Class Initialized
INFO - 2021-12-03 09:39:20 --> Router Class Initialized
INFO - 2021-12-03 09:39:20 --> Output Class Initialized
INFO - 2021-12-03 09:39:20 --> Security Class Initialized
DEBUG - 2021-12-03 09:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:39:20 --> Input Class Initialized
INFO - 2021-12-03 09:39:20 --> Language Class Initialized
INFO - 2021-12-03 09:39:20 --> Language Class Initialized
INFO - 2021-12-03 09:39:20 --> Config Class Initialized
INFO - 2021-12-03 09:39:20 --> Loader Class Initialized
INFO - 2021-12-03 09:39:20 --> Helper loaded: url_helper
INFO - 2021-12-03 09:39:20 --> Helper loaded: file_helper
INFO - 2021-12-03 09:39:20 --> Helper loaded: form_helper
INFO - 2021-12-03 09:39:20 --> Helper loaded: my_helper
INFO - 2021-12-03 09:39:20 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:39:20 --> Controller Class Initialized
DEBUG - 2021-12-03 09:39:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:39:20 --> Final output sent to browser
DEBUG - 2021-12-03 09:39:20 --> Total execution time: 0.1477
INFO - 2021-12-03 09:39:55 --> Config Class Initialized
INFO - 2021-12-03 09:39:55 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:39:55 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:39:55 --> Utf8 Class Initialized
INFO - 2021-12-03 09:39:55 --> URI Class Initialized
INFO - 2021-12-03 09:39:55 --> Router Class Initialized
INFO - 2021-12-03 09:39:55 --> Output Class Initialized
INFO - 2021-12-03 09:39:55 --> Security Class Initialized
DEBUG - 2021-12-03 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:39:55 --> Input Class Initialized
INFO - 2021-12-03 09:39:55 --> Language Class Initialized
INFO - 2021-12-03 09:39:55 --> Language Class Initialized
INFO - 2021-12-03 09:39:55 --> Config Class Initialized
INFO - 2021-12-03 09:39:55 --> Loader Class Initialized
INFO - 2021-12-03 09:39:55 --> Helper loaded: url_helper
INFO - 2021-12-03 09:39:55 --> Helper loaded: file_helper
INFO - 2021-12-03 09:39:55 --> Helper loaded: form_helper
INFO - 2021-12-03 09:39:55 --> Helper loaded: my_helper
INFO - 2021-12-03 09:39:55 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:39:55 --> Controller Class Initialized
DEBUG - 2021-12-03 09:39:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:39:56 --> Final output sent to browser
DEBUG - 2021-12-03 09:39:56 --> Total execution time: 0.1560
INFO - 2021-12-03 09:40:05 --> Config Class Initialized
INFO - 2021-12-03 09:40:05 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:40:05 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:40:05 --> Utf8 Class Initialized
INFO - 2021-12-03 09:40:05 --> URI Class Initialized
INFO - 2021-12-03 09:40:05 --> Router Class Initialized
INFO - 2021-12-03 09:40:05 --> Output Class Initialized
INFO - 2021-12-03 09:40:05 --> Security Class Initialized
DEBUG - 2021-12-03 09:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:40:05 --> Input Class Initialized
INFO - 2021-12-03 09:40:05 --> Language Class Initialized
INFO - 2021-12-03 09:40:05 --> Language Class Initialized
INFO - 2021-12-03 09:40:05 --> Config Class Initialized
INFO - 2021-12-03 09:40:05 --> Loader Class Initialized
INFO - 2021-12-03 09:40:05 --> Helper loaded: url_helper
INFO - 2021-12-03 09:40:05 --> Helper loaded: file_helper
INFO - 2021-12-03 09:40:05 --> Helper loaded: form_helper
INFO - 2021-12-03 09:40:05 --> Helper loaded: my_helper
INFO - 2021-12-03 09:40:05 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:40:05 --> Controller Class Initialized
DEBUG - 2021-12-03 09:40:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:40:05 --> Final output sent to browser
DEBUG - 2021-12-03 09:40:05 --> Total execution time: 0.1530
INFO - 2021-12-03 09:40:22 --> Config Class Initialized
INFO - 2021-12-03 09:40:22 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:40:22 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:40:22 --> Utf8 Class Initialized
INFO - 2021-12-03 09:40:22 --> URI Class Initialized
INFO - 2021-12-03 09:40:22 --> Router Class Initialized
INFO - 2021-12-03 09:40:22 --> Output Class Initialized
INFO - 2021-12-03 09:40:22 --> Security Class Initialized
DEBUG - 2021-12-03 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:40:22 --> Input Class Initialized
INFO - 2021-12-03 09:40:22 --> Language Class Initialized
INFO - 2021-12-03 09:40:22 --> Language Class Initialized
INFO - 2021-12-03 09:40:22 --> Config Class Initialized
INFO - 2021-12-03 09:40:22 --> Loader Class Initialized
INFO - 2021-12-03 09:40:22 --> Helper loaded: url_helper
INFO - 2021-12-03 09:40:22 --> Helper loaded: file_helper
INFO - 2021-12-03 09:40:22 --> Helper loaded: form_helper
INFO - 2021-12-03 09:40:22 --> Helper loaded: my_helper
INFO - 2021-12-03 09:40:22 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:40:22 --> Controller Class Initialized
DEBUG - 2021-12-03 09:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:40:23 --> Final output sent to browser
DEBUG - 2021-12-03 09:40:23 --> Total execution time: 0.1553
INFO - 2021-12-03 09:40:31 --> Config Class Initialized
INFO - 2021-12-03 09:40:31 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:40:31 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:40:31 --> Utf8 Class Initialized
INFO - 2021-12-03 09:40:31 --> URI Class Initialized
INFO - 2021-12-03 09:40:31 --> Router Class Initialized
INFO - 2021-12-03 09:40:31 --> Output Class Initialized
INFO - 2021-12-03 09:40:31 --> Security Class Initialized
DEBUG - 2021-12-03 09:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:40:31 --> Input Class Initialized
INFO - 2021-12-03 09:40:31 --> Language Class Initialized
INFO - 2021-12-03 09:40:31 --> Language Class Initialized
INFO - 2021-12-03 09:40:31 --> Config Class Initialized
INFO - 2021-12-03 09:40:31 --> Loader Class Initialized
INFO - 2021-12-03 09:40:31 --> Helper loaded: url_helper
INFO - 2021-12-03 09:40:31 --> Helper loaded: file_helper
INFO - 2021-12-03 09:40:31 --> Helper loaded: form_helper
INFO - 2021-12-03 09:40:31 --> Helper loaded: my_helper
INFO - 2021-12-03 09:40:31 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:40:31 --> Controller Class Initialized
DEBUG - 2021-12-03 09:40:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:40:31 --> Final output sent to browser
DEBUG - 2021-12-03 09:40:31 --> Total execution time: 0.1367
INFO - 2021-12-03 09:40:38 --> Config Class Initialized
INFO - 2021-12-03 09:40:38 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:40:38 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:40:38 --> Utf8 Class Initialized
INFO - 2021-12-03 09:40:38 --> URI Class Initialized
INFO - 2021-12-03 09:40:38 --> Router Class Initialized
INFO - 2021-12-03 09:40:39 --> Output Class Initialized
INFO - 2021-12-03 09:40:39 --> Security Class Initialized
DEBUG - 2021-12-03 09:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:40:39 --> Input Class Initialized
INFO - 2021-12-03 09:40:39 --> Language Class Initialized
INFO - 2021-12-03 09:40:39 --> Language Class Initialized
INFO - 2021-12-03 09:40:39 --> Config Class Initialized
INFO - 2021-12-03 09:40:39 --> Loader Class Initialized
INFO - 2021-12-03 09:40:39 --> Helper loaded: url_helper
INFO - 2021-12-03 09:40:39 --> Helper loaded: file_helper
INFO - 2021-12-03 09:40:39 --> Helper loaded: form_helper
INFO - 2021-12-03 09:40:39 --> Helper loaded: my_helper
INFO - 2021-12-03 09:40:39 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:40:39 --> Controller Class Initialized
DEBUG - 2021-12-03 09:40:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:40:39 --> Final output sent to browser
DEBUG - 2021-12-03 09:40:39 --> Total execution time: 0.2124
INFO - 2021-12-03 09:45:04 --> Config Class Initialized
INFO - 2021-12-03 09:45:04 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:45:04 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:45:04 --> Utf8 Class Initialized
INFO - 2021-12-03 09:45:04 --> URI Class Initialized
INFO - 2021-12-03 09:45:04 --> Router Class Initialized
INFO - 2021-12-03 09:45:04 --> Output Class Initialized
INFO - 2021-12-03 09:45:04 --> Security Class Initialized
DEBUG - 2021-12-03 09:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:45:04 --> Input Class Initialized
INFO - 2021-12-03 09:45:04 --> Language Class Initialized
INFO - 2021-12-03 09:45:04 --> Language Class Initialized
INFO - 2021-12-03 09:45:04 --> Config Class Initialized
INFO - 2021-12-03 09:45:04 --> Loader Class Initialized
INFO - 2021-12-03 09:45:04 --> Helper loaded: url_helper
INFO - 2021-12-03 09:45:04 --> Helper loaded: file_helper
INFO - 2021-12-03 09:45:04 --> Helper loaded: form_helper
INFO - 2021-12-03 09:45:04 --> Helper loaded: my_helper
INFO - 2021-12-03 09:45:04 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:45:04 --> Controller Class Initialized
DEBUG - 2021-12-03 09:45:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:45:04 --> Final output sent to browser
DEBUG - 2021-12-03 09:45:04 --> Total execution time: 0.1368
INFO - 2021-12-03 09:48:31 --> Config Class Initialized
INFO - 2021-12-03 09:48:31 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:48:31 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:48:31 --> Utf8 Class Initialized
INFO - 2021-12-03 09:48:31 --> URI Class Initialized
INFO - 2021-12-03 09:48:31 --> Router Class Initialized
INFO - 2021-12-03 09:48:31 --> Output Class Initialized
INFO - 2021-12-03 09:48:31 --> Security Class Initialized
DEBUG - 2021-12-03 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:48:31 --> Input Class Initialized
INFO - 2021-12-03 09:48:31 --> Language Class Initialized
INFO - 2021-12-03 09:48:31 --> Language Class Initialized
INFO - 2021-12-03 09:48:31 --> Config Class Initialized
INFO - 2021-12-03 09:48:31 --> Loader Class Initialized
INFO - 2021-12-03 09:48:31 --> Helper loaded: url_helper
INFO - 2021-12-03 09:48:31 --> Helper loaded: file_helper
INFO - 2021-12-03 09:48:31 --> Helper loaded: form_helper
INFO - 2021-12-03 09:48:31 --> Helper loaded: my_helper
INFO - 2021-12-03 09:48:31 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:48:31 --> Controller Class Initialized
ERROR - 2021-12-03 09:48:31 --> Severity: Warning --> include(date.php): failed to open stream: No such file or directory C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_mm_xi.php 403
ERROR - 2021-12-03 09:48:31 --> Severity: Warning --> include(): Failed opening 'date.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_mm_xi.php 403
DEBUG - 2021-12-03 09:48:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:48:31 --> Final output sent to browser
DEBUG - 2021-12-03 09:48:31 --> Total execution time: 0.1767
INFO - 2021-12-03 09:49:03 --> Config Class Initialized
INFO - 2021-12-03 09:49:03 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:49:03 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:49:03 --> Utf8 Class Initialized
INFO - 2021-12-03 09:49:03 --> URI Class Initialized
INFO - 2021-12-03 09:49:03 --> Router Class Initialized
INFO - 2021-12-03 09:49:03 --> Output Class Initialized
INFO - 2021-12-03 09:49:03 --> Security Class Initialized
DEBUG - 2021-12-03 09:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:49:03 --> Input Class Initialized
INFO - 2021-12-03 09:49:03 --> Language Class Initialized
INFO - 2021-12-03 09:49:03 --> Language Class Initialized
INFO - 2021-12-03 09:49:03 --> Config Class Initialized
INFO - 2021-12-03 09:49:03 --> Loader Class Initialized
INFO - 2021-12-03 09:49:03 --> Helper loaded: url_helper
INFO - 2021-12-03 09:49:03 --> Helper loaded: file_helper
INFO - 2021-12-03 09:49:03 --> Helper loaded: form_helper
INFO - 2021-12-03 09:49:03 --> Helper loaded: my_helper
INFO - 2021-12-03 09:49:03 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:49:03 --> Controller Class Initialized
DEBUG - 2021-12-03 09:49:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:49:03 --> Final output sent to browser
DEBUG - 2021-12-03 09:49:03 --> Total execution time: 0.1928
INFO - 2021-12-03 09:51:49 --> Config Class Initialized
INFO - 2021-12-03 09:51:49 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:51:49 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:51:49 --> Utf8 Class Initialized
INFO - 2021-12-03 09:51:49 --> URI Class Initialized
INFO - 2021-12-03 09:51:49 --> Router Class Initialized
INFO - 2021-12-03 09:51:49 --> Output Class Initialized
INFO - 2021-12-03 09:51:49 --> Security Class Initialized
DEBUG - 2021-12-03 09:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:51:49 --> Input Class Initialized
INFO - 2021-12-03 09:51:49 --> Language Class Initialized
INFO - 2021-12-03 09:51:49 --> Language Class Initialized
INFO - 2021-12-03 09:51:49 --> Config Class Initialized
INFO - 2021-12-03 09:51:49 --> Loader Class Initialized
INFO - 2021-12-03 09:51:49 --> Helper loaded: url_helper
INFO - 2021-12-03 09:51:49 --> Helper loaded: file_helper
INFO - 2021-12-03 09:51:49 --> Helper loaded: form_helper
INFO - 2021-12-03 09:51:49 --> Helper loaded: my_helper
INFO - 2021-12-03 09:51:49 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:51:49 --> Controller Class Initialized
ERROR - 2021-12-03 09:51:49 --> Severity: Warning --> include(date.php): failed to open stream: No such file or directory C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_mm_xi.php 403
ERROR - 2021-12-03 09:51:49 --> Severity: Warning --> include(): Failed opening 'date.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_mm_xi.php 403
DEBUG - 2021-12-03 09:51:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:51:49 --> Final output sent to browser
DEBUG - 2021-12-03 09:51:49 --> Total execution time: 0.1236
INFO - 2021-12-03 09:52:01 --> Config Class Initialized
INFO - 2021-12-03 09:52:01 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:52:01 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:52:01 --> Utf8 Class Initialized
INFO - 2021-12-03 09:52:01 --> URI Class Initialized
INFO - 2021-12-03 09:52:01 --> Router Class Initialized
INFO - 2021-12-03 09:52:01 --> Output Class Initialized
INFO - 2021-12-03 09:52:01 --> Security Class Initialized
DEBUG - 2021-12-03 09:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:52:01 --> Input Class Initialized
INFO - 2021-12-03 09:52:01 --> Language Class Initialized
INFO - 2021-12-03 09:52:01 --> Language Class Initialized
INFO - 2021-12-03 09:52:01 --> Config Class Initialized
INFO - 2021-12-03 09:52:01 --> Loader Class Initialized
INFO - 2021-12-03 09:52:01 --> Helper loaded: url_helper
INFO - 2021-12-03 09:52:01 --> Helper loaded: file_helper
INFO - 2021-12-03 09:52:01 --> Helper loaded: form_helper
INFO - 2021-12-03 09:52:01 --> Helper loaded: my_helper
INFO - 2021-12-03 09:52:01 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:52:01 --> Controller Class Initialized
DEBUG - 2021-12-03 09:52:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:52:01 --> Final output sent to browser
DEBUG - 2021-12-03 09:52:01 --> Total execution time: 0.1387
INFO - 2021-12-03 09:53:44 --> Config Class Initialized
INFO - 2021-12-03 09:53:44 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:53:44 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:53:44 --> Utf8 Class Initialized
INFO - 2021-12-03 09:53:44 --> URI Class Initialized
INFO - 2021-12-03 09:53:44 --> Router Class Initialized
INFO - 2021-12-03 09:53:44 --> Output Class Initialized
INFO - 2021-12-03 09:53:44 --> Security Class Initialized
DEBUG - 2021-12-03 09:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:53:44 --> Input Class Initialized
INFO - 2021-12-03 09:53:44 --> Language Class Initialized
INFO - 2021-12-03 09:53:44 --> Language Class Initialized
INFO - 2021-12-03 09:53:44 --> Config Class Initialized
INFO - 2021-12-03 09:53:44 --> Loader Class Initialized
INFO - 2021-12-03 09:53:44 --> Helper loaded: url_helper
INFO - 2021-12-03 09:53:44 --> Helper loaded: file_helper
INFO - 2021-12-03 09:53:44 --> Helper loaded: form_helper
INFO - 2021-12-03 09:53:44 --> Helper loaded: my_helper
INFO - 2021-12-03 09:53:44 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:53:44 --> Controller Class Initialized
DEBUG - 2021-12-03 09:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:53:44 --> Final output sent to browser
DEBUG - 2021-12-03 09:53:44 --> Total execution time: 0.1784
INFO - 2021-12-03 09:59:50 --> Config Class Initialized
INFO - 2021-12-03 09:59:50 --> Hooks Class Initialized
DEBUG - 2021-12-03 09:59:50 --> UTF-8 Support Enabled
INFO - 2021-12-03 09:59:50 --> Utf8 Class Initialized
INFO - 2021-12-03 09:59:50 --> URI Class Initialized
INFO - 2021-12-03 09:59:50 --> Router Class Initialized
INFO - 2021-12-03 09:59:50 --> Output Class Initialized
INFO - 2021-12-03 09:59:50 --> Security Class Initialized
DEBUG - 2021-12-03 09:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 09:59:50 --> Input Class Initialized
INFO - 2021-12-03 09:59:50 --> Language Class Initialized
INFO - 2021-12-03 09:59:50 --> Language Class Initialized
INFO - 2021-12-03 09:59:50 --> Config Class Initialized
INFO - 2021-12-03 09:59:50 --> Loader Class Initialized
INFO - 2021-12-03 09:59:50 --> Helper loaded: url_helper
INFO - 2021-12-03 09:59:50 --> Helper loaded: file_helper
INFO - 2021-12-03 09:59:50 --> Helper loaded: form_helper
INFO - 2021-12-03 09:59:50 --> Helper loaded: my_helper
INFO - 2021-12-03 09:59:50 --> Database Driver Class Initialized
DEBUG - 2021-12-03 09:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 09:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 09:59:50 --> Controller Class Initialized
DEBUG - 2021-12-03 09:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 09:59:50 --> Final output sent to browser
DEBUG - 2021-12-03 09:59:50 --> Total execution time: 0.1420
INFO - 2021-12-03 10:00:28 --> Config Class Initialized
INFO - 2021-12-03 10:00:28 --> Hooks Class Initialized
DEBUG - 2021-12-03 10:00:28 --> UTF-8 Support Enabled
INFO - 2021-12-03 10:00:28 --> Utf8 Class Initialized
INFO - 2021-12-03 10:00:28 --> URI Class Initialized
INFO - 2021-12-03 10:00:28 --> Router Class Initialized
INFO - 2021-12-03 10:00:28 --> Output Class Initialized
INFO - 2021-12-03 10:00:28 --> Security Class Initialized
DEBUG - 2021-12-03 10:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 10:00:28 --> Input Class Initialized
INFO - 2021-12-03 10:00:28 --> Language Class Initialized
INFO - 2021-12-03 10:00:28 --> Language Class Initialized
INFO - 2021-12-03 10:00:28 --> Config Class Initialized
INFO - 2021-12-03 10:00:28 --> Loader Class Initialized
INFO - 2021-12-03 10:00:28 --> Helper loaded: url_helper
INFO - 2021-12-03 10:00:28 --> Helper loaded: file_helper
INFO - 2021-12-03 10:00:28 --> Helper loaded: form_helper
INFO - 2021-12-03 10:00:28 --> Helper loaded: my_helper
INFO - 2021-12-03 10:00:28 --> Database Driver Class Initialized
DEBUG - 2021-12-03 10:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 10:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 10:00:28 --> Controller Class Initialized
DEBUG - 2021-12-03 10:00:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 10:00:28 --> Final output sent to browser
DEBUG - 2021-12-03 10:00:28 --> Total execution time: 0.1609
INFO - 2021-12-03 10:00:52 --> Config Class Initialized
INFO - 2021-12-03 10:00:52 --> Hooks Class Initialized
DEBUG - 2021-12-03 10:00:52 --> UTF-8 Support Enabled
INFO - 2021-12-03 10:00:52 --> Utf8 Class Initialized
INFO - 2021-12-03 10:00:52 --> URI Class Initialized
INFO - 2021-12-03 10:00:52 --> Router Class Initialized
INFO - 2021-12-03 10:00:52 --> Output Class Initialized
INFO - 2021-12-03 10:00:52 --> Security Class Initialized
DEBUG - 2021-12-03 10:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 10:00:52 --> Input Class Initialized
INFO - 2021-12-03 10:00:52 --> Language Class Initialized
INFO - 2021-12-03 10:00:52 --> Language Class Initialized
INFO - 2021-12-03 10:00:52 --> Config Class Initialized
INFO - 2021-12-03 10:00:52 --> Loader Class Initialized
INFO - 2021-12-03 10:00:52 --> Helper loaded: url_helper
INFO - 2021-12-03 10:00:52 --> Helper loaded: file_helper
INFO - 2021-12-03 10:00:52 --> Helper loaded: form_helper
INFO - 2021-12-03 10:00:52 --> Helper loaded: my_helper
INFO - 2021-12-03 10:00:52 --> Database Driver Class Initialized
DEBUG - 2021-12-03 10:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 10:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 10:00:52 --> Controller Class Initialized
DEBUG - 2021-12-03 10:00:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 10:00:52 --> Final output sent to browser
DEBUG - 2021-12-03 10:00:52 --> Total execution time: 0.1637
INFO - 2021-12-03 10:02:05 --> Config Class Initialized
INFO - 2021-12-03 10:02:05 --> Hooks Class Initialized
DEBUG - 2021-12-03 10:02:05 --> UTF-8 Support Enabled
INFO - 2021-12-03 10:02:05 --> Utf8 Class Initialized
INFO - 2021-12-03 10:02:05 --> URI Class Initialized
INFO - 2021-12-03 10:02:05 --> Router Class Initialized
INFO - 2021-12-03 10:02:05 --> Output Class Initialized
INFO - 2021-12-03 10:02:05 --> Security Class Initialized
DEBUG - 2021-12-03 10:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 10:02:05 --> Input Class Initialized
INFO - 2021-12-03 10:02:05 --> Language Class Initialized
INFO - 2021-12-03 10:02:05 --> Language Class Initialized
INFO - 2021-12-03 10:02:05 --> Config Class Initialized
INFO - 2021-12-03 10:02:05 --> Loader Class Initialized
INFO - 2021-12-03 10:02:05 --> Helper loaded: url_helper
INFO - 2021-12-03 10:02:05 --> Helper loaded: file_helper
INFO - 2021-12-03 10:02:05 --> Helper loaded: form_helper
INFO - 2021-12-03 10:02:05 --> Helper loaded: my_helper
INFO - 2021-12-03 10:02:05 --> Database Driver Class Initialized
DEBUG - 2021-12-03 10:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 10:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 10:02:05 --> Controller Class Initialized
DEBUG - 2021-12-03 10:02:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 10:02:06 --> Final output sent to browser
DEBUG - 2021-12-03 10:02:06 --> Total execution time: 0.1561
INFO - 2021-12-03 10:02:42 --> Config Class Initialized
INFO - 2021-12-03 10:02:42 --> Hooks Class Initialized
DEBUG - 2021-12-03 10:02:42 --> UTF-8 Support Enabled
INFO - 2021-12-03 10:02:42 --> Utf8 Class Initialized
INFO - 2021-12-03 10:02:42 --> URI Class Initialized
INFO - 2021-12-03 10:02:42 --> Router Class Initialized
INFO - 2021-12-03 10:02:42 --> Output Class Initialized
INFO - 2021-12-03 10:02:42 --> Security Class Initialized
DEBUG - 2021-12-03 10:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 10:02:42 --> Input Class Initialized
INFO - 2021-12-03 10:02:42 --> Language Class Initialized
INFO - 2021-12-03 10:02:42 --> Language Class Initialized
INFO - 2021-12-03 10:02:42 --> Config Class Initialized
INFO - 2021-12-03 10:02:42 --> Loader Class Initialized
INFO - 2021-12-03 10:02:42 --> Helper loaded: url_helper
INFO - 2021-12-03 10:02:42 --> Helper loaded: file_helper
INFO - 2021-12-03 10:02:42 --> Helper loaded: form_helper
INFO - 2021-12-03 10:02:42 --> Helper loaded: my_helper
INFO - 2021-12-03 10:02:42 --> Database Driver Class Initialized
DEBUG - 2021-12-03 10:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 10:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 10:02:42 --> Controller Class Initialized
DEBUG - 2021-12-03 10:02:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 10:02:42 --> Final output sent to browser
DEBUG - 2021-12-03 10:02:42 --> Total execution time: 0.1596
INFO - 2021-12-03 10:03:21 --> Config Class Initialized
INFO - 2021-12-03 10:03:21 --> Hooks Class Initialized
DEBUG - 2021-12-03 10:03:21 --> UTF-8 Support Enabled
INFO - 2021-12-03 10:03:21 --> Utf8 Class Initialized
INFO - 2021-12-03 10:03:21 --> URI Class Initialized
INFO - 2021-12-03 10:03:22 --> Router Class Initialized
INFO - 2021-12-03 10:03:22 --> Output Class Initialized
INFO - 2021-12-03 10:03:22 --> Security Class Initialized
DEBUG - 2021-12-03 10:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-03 10:03:22 --> Input Class Initialized
INFO - 2021-12-03 10:03:22 --> Language Class Initialized
INFO - 2021-12-03 10:03:22 --> Language Class Initialized
INFO - 2021-12-03 10:03:22 --> Config Class Initialized
INFO - 2021-12-03 10:03:22 --> Loader Class Initialized
INFO - 2021-12-03 10:03:22 --> Helper loaded: url_helper
INFO - 2021-12-03 10:03:22 --> Helper loaded: file_helper
INFO - 2021-12-03 10:03:22 --> Helper loaded: form_helper
INFO - 2021-12-03 10:03:22 --> Helper loaded: my_helper
INFO - 2021-12-03 10:03:22 --> Database Driver Class Initialized
DEBUG - 2021-12-03 10:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-03 10:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-03 10:03:22 --> Controller Class Initialized
DEBUG - 2021-12-03 10:03:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-03 10:03:22 --> Final output sent to browser
DEBUG - 2021-12-03 10:03:22 --> Total execution time: 0.1452
