<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-16 01:41:09 --> Config Class Initialized
INFO - 2020-12-16 01:41:09 --> Hooks Class Initialized
DEBUG - 2020-12-16 01:41:09 --> UTF-8 Support Enabled
INFO - 2020-12-16 01:41:09 --> Utf8 Class Initialized
INFO - 2020-12-16 01:41:09 --> URI Class Initialized
DEBUG - 2020-12-16 01:41:09 --> No URI present. Default controller set.
INFO - 2020-12-16 01:41:09 --> Router Class Initialized
INFO - 2020-12-16 01:41:09 --> Output Class Initialized
INFO - 2020-12-16 01:41:09 --> Security Class Initialized
DEBUG - 2020-12-16 01:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-16 01:41:09 --> Input Class Initialized
INFO - 2020-12-16 01:41:09 --> Language Class Initialized
INFO - 2020-12-16 01:41:09 --> Language Class Initialized
INFO - 2020-12-16 01:41:09 --> Config Class Initialized
INFO - 2020-12-16 01:41:09 --> Loader Class Initialized
INFO - 2020-12-16 01:41:09 --> Helper loaded: url_helper
INFO - 2020-12-16 01:41:09 --> Helper loaded: file_helper
INFO - 2020-12-16 01:41:09 --> Helper loaded: form_helper
INFO - 2020-12-16 01:41:09 --> Helper loaded: my_helper
INFO - 2020-12-16 01:41:09 --> Database Driver Class Initialized
DEBUG - 2020-12-16 01:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-16 01:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-16 01:41:09 --> Controller Class Initialized
INFO - 2020-12-16 01:41:09 --> Config Class Initialized
INFO - 2020-12-16 01:41:09 --> Hooks Class Initialized
DEBUG - 2020-12-16 01:41:09 --> UTF-8 Support Enabled
INFO - 2020-12-16 01:41:09 --> Utf8 Class Initialized
INFO - 2020-12-16 01:41:09 --> URI Class Initialized
INFO - 2020-12-16 01:41:10 --> Router Class Initialized
INFO - 2020-12-16 01:41:10 --> Output Class Initialized
INFO - 2020-12-16 01:41:10 --> Security Class Initialized
DEBUG - 2020-12-16 01:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-16 01:41:10 --> Input Class Initialized
INFO - 2020-12-16 01:41:10 --> Language Class Initialized
INFO - 2020-12-16 01:41:10 --> Language Class Initialized
INFO - 2020-12-16 01:41:10 --> Config Class Initialized
INFO - 2020-12-16 01:41:10 --> Loader Class Initialized
INFO - 2020-12-16 01:41:10 --> Helper loaded: url_helper
INFO - 2020-12-16 01:41:10 --> Helper loaded: file_helper
INFO - 2020-12-16 01:41:10 --> Helper loaded: form_helper
INFO - 2020-12-16 01:41:10 --> Helper loaded: my_helper
INFO - 2020-12-16 01:41:10 --> Database Driver Class Initialized
DEBUG - 2020-12-16 01:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-16 01:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-16 01:41:10 --> Controller Class Initialized
DEBUG - 2020-12-16 01:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-16 01:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-16 01:41:10 --> Final output sent to browser
DEBUG - 2020-12-16 01:41:10 --> Total execution time: 0.4255
INFO - 2020-12-16 01:41:47 --> Config Class Initialized
INFO - 2020-12-16 01:41:47 --> Hooks Class Initialized
DEBUG - 2020-12-16 01:41:47 --> UTF-8 Support Enabled
INFO - 2020-12-16 01:41:47 --> Utf8 Class Initialized
INFO - 2020-12-16 01:41:47 --> URI Class Initialized
INFO - 2020-12-16 01:41:47 --> Router Class Initialized
INFO - 2020-12-16 01:41:47 --> Output Class Initialized
INFO - 2020-12-16 01:41:47 --> Security Class Initialized
DEBUG - 2020-12-16 01:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-16 01:41:47 --> Input Class Initialized
INFO - 2020-12-16 01:41:47 --> Language Class Initialized
INFO - 2020-12-16 01:41:47 --> Language Class Initialized
INFO - 2020-12-16 01:41:47 --> Config Class Initialized
INFO - 2020-12-16 01:41:47 --> Loader Class Initialized
INFO - 2020-12-16 01:41:47 --> Helper loaded: url_helper
INFO - 2020-12-16 01:41:47 --> Helper loaded: file_helper
INFO - 2020-12-16 01:41:47 --> Helper loaded: form_helper
INFO - 2020-12-16 01:41:47 --> Helper loaded: my_helper
INFO - 2020-12-16 01:41:47 --> Database Driver Class Initialized
DEBUG - 2020-12-16 01:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-16 01:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-16 01:41:47 --> Controller Class Initialized
INFO - 2020-12-16 01:41:48 --> Helper loaded: cookie_helper
INFO - 2020-12-16 01:41:48 --> Final output sent to browser
DEBUG - 2020-12-16 01:41:48 --> Total execution time: 1.0954
INFO - 2020-12-16 01:41:49 --> Config Class Initialized
INFO - 2020-12-16 01:41:49 --> Hooks Class Initialized
DEBUG - 2020-12-16 01:41:49 --> UTF-8 Support Enabled
INFO - 2020-12-16 01:41:49 --> Utf8 Class Initialized
INFO - 2020-12-16 01:41:49 --> URI Class Initialized
INFO - 2020-12-16 01:41:49 --> Router Class Initialized
INFO - 2020-12-16 01:41:49 --> Output Class Initialized
INFO - 2020-12-16 01:41:49 --> Security Class Initialized
DEBUG - 2020-12-16 01:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-16 01:41:49 --> Input Class Initialized
INFO - 2020-12-16 01:41:49 --> Language Class Initialized
INFO - 2020-12-16 01:41:49 --> Language Class Initialized
INFO - 2020-12-16 01:41:49 --> Config Class Initialized
INFO - 2020-12-16 01:41:49 --> Loader Class Initialized
INFO - 2020-12-16 01:41:49 --> Helper loaded: url_helper
INFO - 2020-12-16 01:41:49 --> Helper loaded: file_helper
INFO - 2020-12-16 01:41:49 --> Helper loaded: form_helper
INFO - 2020-12-16 01:41:49 --> Helper loaded: my_helper
INFO - 2020-12-16 01:41:49 --> Database Driver Class Initialized
DEBUG - 2020-12-16 01:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-16 01:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-16 01:41:49 --> Controller Class Initialized
DEBUG - 2020-12-16 01:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-16 01:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-16 01:41:49 --> Final output sent to browser
DEBUG - 2020-12-16 01:41:49 --> Total execution time: 0.4300
