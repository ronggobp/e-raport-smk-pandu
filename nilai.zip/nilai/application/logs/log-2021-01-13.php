<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-13 01:17:27 --> Config Class Initialized
INFO - 2021-01-13 01:17:27 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:17:27 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:17:27 --> Utf8 Class Initialized
INFO - 2021-01-13 01:17:27 --> URI Class Initialized
DEBUG - 2021-01-13 01:17:27 --> No URI present. Default controller set.
INFO - 2021-01-13 01:17:27 --> Router Class Initialized
INFO - 2021-01-13 01:17:27 --> Output Class Initialized
INFO - 2021-01-13 01:17:27 --> Security Class Initialized
DEBUG - 2021-01-13 01:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:17:27 --> Input Class Initialized
INFO - 2021-01-13 01:17:27 --> Language Class Initialized
INFO - 2021-01-13 01:17:27 --> Language Class Initialized
INFO - 2021-01-13 01:17:27 --> Config Class Initialized
INFO - 2021-01-13 01:17:27 --> Loader Class Initialized
INFO - 2021-01-13 01:17:27 --> Helper loaded: url_helper
INFO - 2021-01-13 01:17:27 --> Helper loaded: file_helper
INFO - 2021-01-13 01:17:27 --> Helper loaded: form_helper
INFO - 2021-01-13 01:17:27 --> Helper loaded: my_helper
INFO - 2021-01-13 01:17:27 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:17:27 --> Controller Class Initialized
INFO - 2021-01-13 01:17:27 --> Config Class Initialized
INFO - 2021-01-13 01:17:27 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:17:27 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:17:27 --> Utf8 Class Initialized
INFO - 2021-01-13 01:17:27 --> URI Class Initialized
INFO - 2021-01-13 01:17:27 --> Router Class Initialized
INFO - 2021-01-13 01:17:27 --> Output Class Initialized
INFO - 2021-01-13 01:17:27 --> Security Class Initialized
DEBUG - 2021-01-13 01:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:17:27 --> Input Class Initialized
INFO - 2021-01-13 01:17:27 --> Language Class Initialized
INFO - 2021-01-13 01:17:27 --> Language Class Initialized
INFO - 2021-01-13 01:17:27 --> Config Class Initialized
INFO - 2021-01-13 01:17:27 --> Loader Class Initialized
INFO - 2021-01-13 01:17:27 --> Helper loaded: url_helper
INFO - 2021-01-13 01:17:27 --> Helper loaded: file_helper
INFO - 2021-01-13 01:17:27 --> Helper loaded: form_helper
INFO - 2021-01-13 01:17:27 --> Helper loaded: my_helper
INFO - 2021-01-13 01:17:27 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:17:27 --> Controller Class Initialized
DEBUG - 2021-01-13 01:17:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-13 01:17:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 01:17:27 --> Final output sent to browser
DEBUG - 2021-01-13 01:17:27 --> Total execution time: 0.1898
INFO - 2021-01-13 01:17:36 --> Config Class Initialized
INFO - 2021-01-13 01:17:36 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:17:36 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:17:36 --> Utf8 Class Initialized
INFO - 2021-01-13 01:17:36 --> URI Class Initialized
INFO - 2021-01-13 01:17:36 --> Router Class Initialized
INFO - 2021-01-13 01:17:36 --> Output Class Initialized
INFO - 2021-01-13 01:17:36 --> Security Class Initialized
DEBUG - 2021-01-13 01:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:17:36 --> Input Class Initialized
INFO - 2021-01-13 01:17:36 --> Language Class Initialized
INFO - 2021-01-13 01:17:36 --> Language Class Initialized
INFO - 2021-01-13 01:17:36 --> Config Class Initialized
INFO - 2021-01-13 01:17:36 --> Loader Class Initialized
INFO - 2021-01-13 01:17:36 --> Helper loaded: url_helper
INFO - 2021-01-13 01:17:36 --> Helper loaded: file_helper
INFO - 2021-01-13 01:17:36 --> Helper loaded: form_helper
INFO - 2021-01-13 01:17:36 --> Helper loaded: my_helper
INFO - 2021-01-13 01:17:36 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:17:36 --> Controller Class Initialized
INFO - 2021-01-13 01:17:36 --> Helper loaded: cookie_helper
INFO - 2021-01-13 01:17:36 --> Final output sent to browser
DEBUG - 2021-01-13 01:17:36 --> Total execution time: 0.3685
INFO - 2021-01-13 01:17:37 --> Config Class Initialized
INFO - 2021-01-13 01:17:37 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:17:37 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:17:37 --> Utf8 Class Initialized
INFO - 2021-01-13 01:17:37 --> URI Class Initialized
INFO - 2021-01-13 01:17:37 --> Router Class Initialized
INFO - 2021-01-13 01:17:37 --> Output Class Initialized
INFO - 2021-01-13 01:17:37 --> Security Class Initialized
DEBUG - 2021-01-13 01:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:17:37 --> Input Class Initialized
INFO - 2021-01-13 01:17:37 --> Language Class Initialized
INFO - 2021-01-13 01:17:37 --> Language Class Initialized
INFO - 2021-01-13 01:17:37 --> Config Class Initialized
INFO - 2021-01-13 01:17:37 --> Loader Class Initialized
INFO - 2021-01-13 01:17:37 --> Helper loaded: url_helper
INFO - 2021-01-13 01:17:37 --> Helper loaded: file_helper
INFO - 2021-01-13 01:17:37 --> Helper loaded: form_helper
INFO - 2021-01-13 01:17:37 --> Helper loaded: my_helper
INFO - 2021-01-13 01:17:37 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:17:37 --> Controller Class Initialized
DEBUG - 2021-01-13 01:17:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-13 01:17:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 01:17:37 --> Final output sent to browser
DEBUG - 2021-01-13 01:17:37 --> Total execution time: 0.3082
INFO - 2021-01-13 01:17:39 --> Config Class Initialized
INFO - 2021-01-13 01:17:39 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:17:39 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:17:39 --> Utf8 Class Initialized
INFO - 2021-01-13 01:17:39 --> URI Class Initialized
INFO - 2021-01-13 01:17:39 --> Router Class Initialized
INFO - 2021-01-13 01:17:39 --> Output Class Initialized
INFO - 2021-01-13 01:17:39 --> Security Class Initialized
DEBUG - 2021-01-13 01:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:17:39 --> Input Class Initialized
INFO - 2021-01-13 01:17:39 --> Language Class Initialized
INFO - 2021-01-13 01:17:39 --> Language Class Initialized
INFO - 2021-01-13 01:17:39 --> Config Class Initialized
INFO - 2021-01-13 01:17:39 --> Loader Class Initialized
INFO - 2021-01-13 01:17:39 --> Helper loaded: url_helper
INFO - 2021-01-13 01:17:39 --> Helper loaded: file_helper
INFO - 2021-01-13 01:17:39 --> Helper loaded: form_helper
INFO - 2021-01-13 01:17:39 --> Helper loaded: my_helper
INFO - 2021-01-13 01:17:39 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:17:39 --> Controller Class Initialized
DEBUG - 2021-01-13 01:17:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-13 01:17:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 01:17:39 --> Final output sent to browser
DEBUG - 2021-01-13 01:17:39 --> Total execution time: 0.3139
INFO - 2021-01-13 01:17:40 --> Config Class Initialized
INFO - 2021-01-13 01:17:40 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:17:40 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:17:40 --> Utf8 Class Initialized
INFO - 2021-01-13 01:17:40 --> URI Class Initialized
INFO - 2021-01-13 01:17:40 --> Router Class Initialized
INFO - 2021-01-13 01:17:40 --> Output Class Initialized
INFO - 2021-01-13 01:17:40 --> Security Class Initialized
DEBUG - 2021-01-13 01:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:17:40 --> Input Class Initialized
INFO - 2021-01-13 01:17:40 --> Language Class Initialized
INFO - 2021-01-13 01:17:40 --> Language Class Initialized
INFO - 2021-01-13 01:17:40 --> Config Class Initialized
INFO - 2021-01-13 01:17:40 --> Loader Class Initialized
INFO - 2021-01-13 01:17:40 --> Helper loaded: url_helper
INFO - 2021-01-13 01:17:40 --> Helper loaded: file_helper
INFO - 2021-01-13 01:17:40 --> Helper loaded: form_helper
INFO - 2021-01-13 01:17:40 --> Helper loaded: my_helper
INFO - 2021-01-13 01:17:40 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:17:40 --> Controller Class Initialized
DEBUG - 2021-01-13 01:17:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-13 01:17:41 --> Final output sent to browser
DEBUG - 2021-01-13 01:17:41 --> Total execution time: 0.2748
INFO - 2021-01-13 01:58:07 --> Config Class Initialized
INFO - 2021-01-13 01:58:07 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:58:07 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:58:07 --> Utf8 Class Initialized
INFO - 2021-01-13 01:58:07 --> URI Class Initialized
INFO - 2021-01-13 01:58:07 --> Router Class Initialized
INFO - 2021-01-13 01:58:07 --> Output Class Initialized
INFO - 2021-01-13 01:58:07 --> Security Class Initialized
DEBUG - 2021-01-13 01:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:58:07 --> Input Class Initialized
INFO - 2021-01-13 01:58:07 --> Language Class Initialized
INFO - 2021-01-13 01:58:07 --> Language Class Initialized
INFO - 2021-01-13 01:58:07 --> Config Class Initialized
INFO - 2021-01-13 01:58:07 --> Loader Class Initialized
INFO - 2021-01-13 01:58:07 --> Helper loaded: url_helper
INFO - 2021-01-13 01:58:07 --> Helper loaded: file_helper
INFO - 2021-01-13 01:58:07 --> Helper loaded: form_helper
INFO - 2021-01-13 01:58:07 --> Helper loaded: my_helper
INFO - 2021-01-13 01:58:07 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:58:07 --> Controller Class Initialized
DEBUG - 2021-01-13 01:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2021-01-13 01:58:07 --> Final output sent to browser
DEBUG - 2021-01-13 01:58:07 --> Total execution time: 0.2673
INFO - 2021-01-13 01:59:33 --> Config Class Initialized
INFO - 2021-01-13 01:59:33 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:33 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:33 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:33 --> URI Class Initialized
INFO - 2021-01-13 01:59:33 --> Router Class Initialized
INFO - 2021-01-13 01:59:33 --> Output Class Initialized
INFO - 2021-01-13 01:59:33 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:33 --> Input Class Initialized
INFO - 2021-01-13 01:59:33 --> Language Class Initialized
INFO - 2021-01-13 01:59:33 --> Language Class Initialized
INFO - 2021-01-13 01:59:33 --> Config Class Initialized
INFO - 2021-01-13 01:59:33 --> Loader Class Initialized
INFO - 2021-01-13 01:59:33 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:33 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:33 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:33 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:33 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:33 --> Controller Class Initialized
DEBUG - 2021-01-13 01:59:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-13 01:59:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 01:59:33 --> Final output sent to browser
DEBUG - 2021-01-13 01:59:33 --> Total execution time: 0.2280
INFO - 2021-01-13 01:59:35 --> Config Class Initialized
INFO - 2021-01-13 01:59:35 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:35 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:35 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:35 --> URI Class Initialized
INFO - 2021-01-13 01:59:35 --> Router Class Initialized
INFO - 2021-01-13 01:59:35 --> Output Class Initialized
INFO - 2021-01-13 01:59:35 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:35 --> Input Class Initialized
INFO - 2021-01-13 01:59:35 --> Language Class Initialized
INFO - 2021-01-13 01:59:35 --> Language Class Initialized
INFO - 2021-01-13 01:59:35 --> Config Class Initialized
INFO - 2021-01-13 01:59:35 --> Loader Class Initialized
INFO - 2021-01-13 01:59:35 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:35 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:35 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:35 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:35 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:35 --> Controller Class Initialized
DEBUG - 2021-01-13 01:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-13 01:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 01:59:35 --> Final output sent to browser
DEBUG - 2021-01-13 01:59:35 --> Total execution time: 0.2406
INFO - 2021-01-13 01:59:35 --> Config Class Initialized
INFO - 2021-01-13 01:59:35 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:35 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:35 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:35 --> URI Class Initialized
INFO - 2021-01-13 01:59:35 --> Router Class Initialized
INFO - 2021-01-13 01:59:35 --> Output Class Initialized
INFO - 2021-01-13 01:59:35 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:35 --> Input Class Initialized
INFO - 2021-01-13 01:59:35 --> Language Class Initialized
INFO - 2021-01-13 01:59:35 --> Language Class Initialized
INFO - 2021-01-13 01:59:35 --> Config Class Initialized
INFO - 2021-01-13 01:59:35 --> Loader Class Initialized
INFO - 2021-01-13 01:59:35 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:35 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:35 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:35 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:35 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:35 --> Controller Class Initialized
INFO - 2021-01-13 01:59:38 --> Config Class Initialized
INFO - 2021-01-13 01:59:38 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:38 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:38 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:38 --> URI Class Initialized
INFO - 2021-01-13 01:59:38 --> Router Class Initialized
INFO - 2021-01-13 01:59:38 --> Output Class Initialized
INFO - 2021-01-13 01:59:38 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:38 --> Input Class Initialized
INFO - 2021-01-13 01:59:38 --> Language Class Initialized
INFO - 2021-01-13 01:59:38 --> Language Class Initialized
INFO - 2021-01-13 01:59:38 --> Config Class Initialized
INFO - 2021-01-13 01:59:38 --> Loader Class Initialized
INFO - 2021-01-13 01:59:38 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:38 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:38 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:38 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:38 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:38 --> Controller Class Initialized
INFO - 2021-01-13 01:59:38 --> Helper loaded: cookie_helper
INFO - 2021-01-13 01:59:38 --> Config Class Initialized
INFO - 2021-01-13 01:59:38 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:38 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:38 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:38 --> URI Class Initialized
INFO - 2021-01-13 01:59:38 --> Router Class Initialized
INFO - 2021-01-13 01:59:38 --> Output Class Initialized
INFO - 2021-01-13 01:59:38 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:39 --> Input Class Initialized
INFO - 2021-01-13 01:59:39 --> Language Class Initialized
INFO - 2021-01-13 01:59:39 --> Language Class Initialized
INFO - 2021-01-13 01:59:39 --> Config Class Initialized
INFO - 2021-01-13 01:59:39 --> Loader Class Initialized
INFO - 2021-01-13 01:59:39 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:39 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:39 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:39 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:39 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:39 --> Controller Class Initialized
DEBUG - 2021-01-13 01:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-13 01:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 01:59:39 --> Final output sent to browser
DEBUG - 2021-01-13 01:59:39 --> Total execution time: 0.2264
INFO - 2021-01-13 01:59:48 --> Config Class Initialized
INFO - 2021-01-13 01:59:48 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:48 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:48 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:48 --> URI Class Initialized
INFO - 2021-01-13 01:59:48 --> Router Class Initialized
INFO - 2021-01-13 01:59:48 --> Output Class Initialized
INFO - 2021-01-13 01:59:48 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:48 --> Input Class Initialized
INFO - 2021-01-13 01:59:48 --> Language Class Initialized
INFO - 2021-01-13 01:59:48 --> Language Class Initialized
INFO - 2021-01-13 01:59:48 --> Config Class Initialized
INFO - 2021-01-13 01:59:48 --> Loader Class Initialized
INFO - 2021-01-13 01:59:48 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:48 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:48 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:48 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:48 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:48 --> Controller Class Initialized
INFO - 2021-01-13 01:59:48 --> Helper loaded: cookie_helper
INFO - 2021-01-13 01:59:48 --> Final output sent to browser
DEBUG - 2021-01-13 01:59:48 --> Total execution time: 0.2937
INFO - 2021-01-13 01:59:49 --> Config Class Initialized
INFO - 2021-01-13 01:59:49 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:49 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:49 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:49 --> URI Class Initialized
INFO - 2021-01-13 01:59:49 --> Router Class Initialized
INFO - 2021-01-13 01:59:49 --> Output Class Initialized
INFO - 2021-01-13 01:59:49 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:49 --> Input Class Initialized
INFO - 2021-01-13 01:59:49 --> Language Class Initialized
INFO - 2021-01-13 01:59:49 --> Language Class Initialized
INFO - 2021-01-13 01:59:49 --> Config Class Initialized
INFO - 2021-01-13 01:59:49 --> Loader Class Initialized
INFO - 2021-01-13 01:59:49 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:49 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:49 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:49 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:49 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:49 --> Controller Class Initialized
DEBUG - 2021-01-13 01:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-13 01:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 01:59:49 --> Final output sent to browser
DEBUG - 2021-01-13 01:59:49 --> Total execution time: 0.3521
INFO - 2021-01-13 01:59:51 --> Config Class Initialized
INFO - 2021-01-13 01:59:51 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:51 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:51 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:51 --> URI Class Initialized
INFO - 2021-01-13 01:59:51 --> Router Class Initialized
INFO - 2021-01-13 01:59:51 --> Output Class Initialized
INFO - 2021-01-13 01:59:51 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:51 --> Input Class Initialized
INFO - 2021-01-13 01:59:51 --> Language Class Initialized
INFO - 2021-01-13 01:59:51 --> Language Class Initialized
INFO - 2021-01-13 01:59:51 --> Config Class Initialized
INFO - 2021-01-13 01:59:51 --> Loader Class Initialized
INFO - 2021-01-13 01:59:51 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:51 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:51 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:51 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:51 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:51 --> Controller Class Initialized
DEBUG - 2021-01-13 01:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-13 01:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 01:59:51 --> Final output sent to browser
DEBUG - 2021-01-13 01:59:51 --> Total execution time: 0.2635
INFO - 2021-01-13 01:59:52 --> Config Class Initialized
INFO - 2021-01-13 01:59:52 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:52 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:52 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:52 --> URI Class Initialized
INFO - 2021-01-13 01:59:52 --> Router Class Initialized
INFO - 2021-01-13 01:59:52 --> Output Class Initialized
INFO - 2021-01-13 01:59:52 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:52 --> Input Class Initialized
INFO - 2021-01-13 01:59:52 --> Language Class Initialized
INFO - 2021-01-13 01:59:52 --> Language Class Initialized
INFO - 2021-01-13 01:59:52 --> Config Class Initialized
INFO - 2021-01-13 01:59:52 --> Loader Class Initialized
INFO - 2021-01-13 01:59:52 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:52 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:52 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:52 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:53 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:53 --> Controller Class Initialized
DEBUG - 2021-01-13 01:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-13 01:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 01:59:53 --> Final output sent to browser
DEBUG - 2021-01-13 01:59:53 --> Total execution time: 0.2670
INFO - 2021-01-13 01:59:53 --> Config Class Initialized
INFO - 2021-01-13 01:59:53 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:53 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:53 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:53 --> URI Class Initialized
INFO - 2021-01-13 01:59:53 --> Router Class Initialized
INFO - 2021-01-13 01:59:53 --> Output Class Initialized
INFO - 2021-01-13 01:59:53 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:53 --> Input Class Initialized
INFO - 2021-01-13 01:59:53 --> Language Class Initialized
INFO - 2021-01-13 01:59:53 --> Language Class Initialized
INFO - 2021-01-13 01:59:53 --> Config Class Initialized
INFO - 2021-01-13 01:59:53 --> Loader Class Initialized
INFO - 2021-01-13 01:59:53 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:53 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:53 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:53 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:53 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:53 --> Controller Class Initialized
INFO - 2021-01-13 01:59:54 --> Config Class Initialized
INFO - 2021-01-13 01:59:54 --> Hooks Class Initialized
DEBUG - 2021-01-13 01:59:54 --> UTF-8 Support Enabled
INFO - 2021-01-13 01:59:54 --> Utf8 Class Initialized
INFO - 2021-01-13 01:59:54 --> URI Class Initialized
INFO - 2021-01-13 01:59:54 --> Router Class Initialized
INFO - 2021-01-13 01:59:54 --> Output Class Initialized
INFO - 2021-01-13 01:59:54 --> Security Class Initialized
DEBUG - 2021-01-13 01:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 01:59:54 --> Input Class Initialized
INFO - 2021-01-13 01:59:54 --> Language Class Initialized
INFO - 2021-01-13 01:59:54 --> Language Class Initialized
INFO - 2021-01-13 01:59:54 --> Config Class Initialized
INFO - 2021-01-13 01:59:54 --> Loader Class Initialized
INFO - 2021-01-13 01:59:54 --> Helper loaded: url_helper
INFO - 2021-01-13 01:59:54 --> Helper loaded: file_helper
INFO - 2021-01-13 01:59:54 --> Helper loaded: form_helper
INFO - 2021-01-13 01:59:54 --> Helper loaded: my_helper
INFO - 2021-01-13 01:59:54 --> Database Driver Class Initialized
DEBUG - 2021-01-13 01:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 01:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 01:59:54 --> Controller Class Initialized
DEBUG - 2021-01-13 01:59:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-13 01:59:54 --> Final output sent to browser
DEBUG - 2021-01-13 01:59:54 --> Total execution time: 0.3368
INFO - 2021-01-13 02:00:01 --> Config Class Initialized
INFO - 2021-01-13 02:00:01 --> Hooks Class Initialized
DEBUG - 2021-01-13 02:00:01 --> UTF-8 Support Enabled
INFO - 2021-01-13 02:00:01 --> Utf8 Class Initialized
INFO - 2021-01-13 02:00:01 --> URI Class Initialized
INFO - 2021-01-13 02:00:01 --> Router Class Initialized
INFO - 2021-01-13 02:00:01 --> Output Class Initialized
INFO - 2021-01-13 02:00:01 --> Security Class Initialized
DEBUG - 2021-01-13 02:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 02:00:01 --> Input Class Initialized
INFO - 2021-01-13 02:00:01 --> Language Class Initialized
INFO - 2021-01-13 02:00:01 --> Language Class Initialized
INFO - 2021-01-13 02:00:01 --> Config Class Initialized
INFO - 2021-01-13 02:00:01 --> Loader Class Initialized
INFO - 2021-01-13 02:00:01 --> Helper loaded: url_helper
INFO - 2021-01-13 02:00:01 --> Helper loaded: file_helper
INFO - 2021-01-13 02:00:02 --> Helper loaded: form_helper
INFO - 2021-01-13 02:00:02 --> Helper loaded: my_helper
INFO - 2021-01-13 02:00:02 --> Database Driver Class Initialized
DEBUG - 2021-01-13 02:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 02:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 02:00:02 --> Controller Class Initialized
DEBUG - 2021-01-13 02:00:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-13 02:00:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 02:00:02 --> Final output sent to browser
DEBUG - 2021-01-13 02:00:02 --> Total execution time: 0.2730
INFO - 2021-01-13 02:00:03 --> Config Class Initialized
INFO - 2021-01-13 02:00:03 --> Hooks Class Initialized
DEBUG - 2021-01-13 02:00:03 --> UTF-8 Support Enabled
INFO - 2021-01-13 02:00:03 --> Utf8 Class Initialized
INFO - 2021-01-13 02:00:03 --> URI Class Initialized
INFO - 2021-01-13 02:00:03 --> Router Class Initialized
INFO - 2021-01-13 02:00:03 --> Output Class Initialized
INFO - 2021-01-13 02:00:03 --> Security Class Initialized
DEBUG - 2021-01-13 02:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 02:00:03 --> Input Class Initialized
INFO - 2021-01-13 02:00:03 --> Language Class Initialized
INFO - 2021-01-13 02:00:03 --> Language Class Initialized
INFO - 2021-01-13 02:00:03 --> Config Class Initialized
INFO - 2021-01-13 02:00:03 --> Loader Class Initialized
INFO - 2021-01-13 02:00:03 --> Helper loaded: url_helper
INFO - 2021-01-13 02:00:03 --> Helper loaded: file_helper
INFO - 2021-01-13 02:00:03 --> Helper loaded: form_helper
INFO - 2021-01-13 02:00:03 --> Helper loaded: my_helper
INFO - 2021-01-13 02:00:03 --> Database Driver Class Initialized
DEBUG - 2021-01-13 02:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 02:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 02:00:03 --> Controller Class Initialized
DEBUG - 2021-01-13 02:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-13 02:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 02:00:03 --> Final output sent to browser
DEBUG - 2021-01-13 02:00:03 --> Total execution time: 0.2301
INFO - 2021-01-13 02:00:05 --> Config Class Initialized
INFO - 2021-01-13 02:00:05 --> Hooks Class Initialized
DEBUG - 2021-01-13 02:00:05 --> UTF-8 Support Enabled
INFO - 2021-01-13 02:00:05 --> Utf8 Class Initialized
INFO - 2021-01-13 02:00:05 --> URI Class Initialized
INFO - 2021-01-13 02:00:05 --> Router Class Initialized
INFO - 2021-01-13 02:00:05 --> Output Class Initialized
INFO - 2021-01-13 02:00:05 --> Security Class Initialized
DEBUG - 2021-01-13 02:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 02:00:05 --> Input Class Initialized
INFO - 2021-01-13 02:00:05 --> Language Class Initialized
INFO - 2021-01-13 02:00:05 --> Language Class Initialized
INFO - 2021-01-13 02:00:05 --> Config Class Initialized
INFO - 2021-01-13 02:00:05 --> Loader Class Initialized
INFO - 2021-01-13 02:00:05 --> Helper loaded: url_helper
INFO - 2021-01-13 02:00:05 --> Helper loaded: file_helper
INFO - 2021-01-13 02:00:05 --> Helper loaded: form_helper
INFO - 2021-01-13 02:00:05 --> Helper loaded: my_helper
INFO - 2021-01-13 02:00:05 --> Database Driver Class Initialized
DEBUG - 2021-01-13 02:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 02:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 02:00:05 --> Controller Class Initialized
DEBUG - 2021-01-13 02:00:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-13 02:00:05 --> Final output sent to browser
DEBUG - 2021-01-13 02:00:05 --> Total execution time: 0.3407
INFO - 2021-01-13 05:39:39 --> Config Class Initialized
INFO - 2021-01-13 05:39:39 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:39:39 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:39:39 --> Utf8 Class Initialized
INFO - 2021-01-13 05:39:39 --> URI Class Initialized
INFO - 2021-01-13 05:39:39 --> Router Class Initialized
INFO - 2021-01-13 05:39:39 --> Output Class Initialized
INFO - 2021-01-13 05:39:39 --> Security Class Initialized
DEBUG - 2021-01-13 05:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:39:39 --> Input Class Initialized
INFO - 2021-01-13 05:39:39 --> Language Class Initialized
INFO - 2021-01-13 05:39:39 --> Language Class Initialized
INFO - 2021-01-13 05:39:39 --> Config Class Initialized
INFO - 2021-01-13 05:39:39 --> Loader Class Initialized
INFO - 2021-01-13 05:39:39 --> Helper loaded: url_helper
INFO - 2021-01-13 05:39:39 --> Helper loaded: file_helper
INFO - 2021-01-13 05:39:39 --> Helper loaded: form_helper
INFO - 2021-01-13 05:39:39 --> Helper loaded: my_helper
INFO - 2021-01-13 05:39:39 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:39:39 --> Controller Class Initialized
DEBUG - 2021-01-13 05:39:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-13 05:39:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:39:39 --> Final output sent to browser
DEBUG - 2021-01-13 05:39:39 --> Total execution time: 0.2465
INFO - 2021-01-13 05:39:41 --> Config Class Initialized
INFO - 2021-01-13 05:39:41 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:39:41 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:39:41 --> Utf8 Class Initialized
INFO - 2021-01-13 05:39:41 --> URI Class Initialized
DEBUG - 2021-01-13 05:39:41 --> No URI present. Default controller set.
INFO - 2021-01-13 05:39:41 --> Router Class Initialized
INFO - 2021-01-13 05:39:41 --> Output Class Initialized
INFO - 2021-01-13 05:39:41 --> Security Class Initialized
DEBUG - 2021-01-13 05:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:39:41 --> Input Class Initialized
INFO - 2021-01-13 05:39:41 --> Language Class Initialized
INFO - 2021-01-13 05:39:41 --> Language Class Initialized
INFO - 2021-01-13 05:39:41 --> Config Class Initialized
INFO - 2021-01-13 05:39:41 --> Loader Class Initialized
INFO - 2021-01-13 05:39:41 --> Helper loaded: url_helper
INFO - 2021-01-13 05:39:41 --> Helper loaded: file_helper
INFO - 2021-01-13 05:39:41 --> Helper loaded: form_helper
INFO - 2021-01-13 05:39:41 --> Helper loaded: my_helper
INFO - 2021-01-13 05:39:41 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:39:41 --> Controller Class Initialized
INFO - 2021-01-13 05:39:41 --> Config Class Initialized
INFO - 2021-01-13 05:39:41 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:39:41 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:39:41 --> Utf8 Class Initialized
INFO - 2021-01-13 05:39:41 --> URI Class Initialized
INFO - 2021-01-13 05:39:41 --> Router Class Initialized
INFO - 2021-01-13 05:39:41 --> Output Class Initialized
INFO - 2021-01-13 05:39:41 --> Security Class Initialized
DEBUG - 2021-01-13 05:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:39:41 --> Input Class Initialized
INFO - 2021-01-13 05:39:41 --> Language Class Initialized
INFO - 2021-01-13 05:39:41 --> Language Class Initialized
INFO - 2021-01-13 05:39:41 --> Config Class Initialized
INFO - 2021-01-13 05:39:42 --> Loader Class Initialized
INFO - 2021-01-13 05:39:42 --> Helper loaded: url_helper
INFO - 2021-01-13 05:39:42 --> Helper loaded: file_helper
INFO - 2021-01-13 05:39:42 --> Helper loaded: form_helper
INFO - 2021-01-13 05:39:42 --> Helper loaded: my_helper
INFO - 2021-01-13 05:39:42 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:39:42 --> Controller Class Initialized
DEBUG - 2021-01-13 05:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-13 05:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:39:42 --> Final output sent to browser
DEBUG - 2021-01-13 05:39:42 --> Total execution time: 0.3111
INFO - 2021-01-13 05:39:49 --> Config Class Initialized
INFO - 2021-01-13 05:39:49 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:39:49 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:39:49 --> Utf8 Class Initialized
INFO - 2021-01-13 05:39:49 --> URI Class Initialized
INFO - 2021-01-13 05:39:49 --> Router Class Initialized
INFO - 2021-01-13 05:39:49 --> Output Class Initialized
INFO - 2021-01-13 05:39:49 --> Security Class Initialized
DEBUG - 2021-01-13 05:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:39:50 --> Input Class Initialized
INFO - 2021-01-13 05:39:50 --> Language Class Initialized
INFO - 2021-01-13 05:39:50 --> Language Class Initialized
INFO - 2021-01-13 05:39:50 --> Config Class Initialized
INFO - 2021-01-13 05:39:50 --> Loader Class Initialized
INFO - 2021-01-13 05:39:50 --> Helper loaded: url_helper
INFO - 2021-01-13 05:39:50 --> Helper loaded: file_helper
INFO - 2021-01-13 05:39:50 --> Helper loaded: form_helper
INFO - 2021-01-13 05:39:50 --> Helper loaded: my_helper
INFO - 2021-01-13 05:39:50 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:39:50 --> Controller Class Initialized
INFO - 2021-01-13 05:39:50 --> Helper loaded: cookie_helper
INFO - 2021-01-13 05:39:50 --> Final output sent to browser
DEBUG - 2021-01-13 05:39:50 --> Total execution time: 0.3349
INFO - 2021-01-13 05:39:50 --> Config Class Initialized
INFO - 2021-01-13 05:39:50 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:39:50 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:39:50 --> Utf8 Class Initialized
INFO - 2021-01-13 05:39:50 --> URI Class Initialized
INFO - 2021-01-13 05:39:50 --> Router Class Initialized
INFO - 2021-01-13 05:39:50 --> Output Class Initialized
INFO - 2021-01-13 05:39:50 --> Security Class Initialized
DEBUG - 2021-01-13 05:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:39:50 --> Input Class Initialized
INFO - 2021-01-13 05:39:50 --> Language Class Initialized
INFO - 2021-01-13 05:39:50 --> Language Class Initialized
INFO - 2021-01-13 05:39:50 --> Config Class Initialized
INFO - 2021-01-13 05:39:50 --> Loader Class Initialized
INFO - 2021-01-13 05:39:50 --> Helper loaded: url_helper
INFO - 2021-01-13 05:39:50 --> Helper loaded: file_helper
INFO - 2021-01-13 05:39:50 --> Helper loaded: form_helper
INFO - 2021-01-13 05:39:50 --> Helper loaded: my_helper
INFO - 2021-01-13 05:39:50 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:39:50 --> Controller Class Initialized
DEBUG - 2021-01-13 05:39:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-13 05:39:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:39:51 --> Final output sent to browser
DEBUG - 2021-01-13 05:39:51 --> Total execution time: 0.3536
INFO - 2021-01-13 05:39:55 --> Config Class Initialized
INFO - 2021-01-13 05:39:55 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:39:55 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:39:55 --> Utf8 Class Initialized
INFO - 2021-01-13 05:39:55 --> URI Class Initialized
INFO - 2021-01-13 05:39:55 --> Router Class Initialized
INFO - 2021-01-13 05:39:55 --> Output Class Initialized
INFO - 2021-01-13 05:39:55 --> Security Class Initialized
DEBUG - 2021-01-13 05:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:39:55 --> Input Class Initialized
INFO - 2021-01-13 05:39:55 --> Language Class Initialized
INFO - 2021-01-13 05:39:55 --> Language Class Initialized
INFO - 2021-01-13 05:39:55 --> Config Class Initialized
INFO - 2021-01-13 05:39:55 --> Loader Class Initialized
INFO - 2021-01-13 05:39:55 --> Helper loaded: url_helper
INFO - 2021-01-13 05:39:55 --> Helper loaded: file_helper
INFO - 2021-01-13 05:39:56 --> Helper loaded: form_helper
INFO - 2021-01-13 05:39:56 --> Helper loaded: my_helper
INFO - 2021-01-13 05:39:56 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:39:56 --> Controller Class Initialized
INFO - 2021-01-13 05:39:56 --> Helper loaded: cookie_helper
INFO - 2021-01-13 05:39:56 --> Config Class Initialized
INFO - 2021-01-13 05:39:56 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:39:56 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:39:56 --> Utf8 Class Initialized
INFO - 2021-01-13 05:39:56 --> URI Class Initialized
INFO - 2021-01-13 05:39:56 --> Router Class Initialized
INFO - 2021-01-13 05:39:56 --> Output Class Initialized
INFO - 2021-01-13 05:39:56 --> Security Class Initialized
DEBUG - 2021-01-13 05:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:39:56 --> Input Class Initialized
INFO - 2021-01-13 05:39:56 --> Language Class Initialized
INFO - 2021-01-13 05:39:56 --> Language Class Initialized
INFO - 2021-01-13 05:39:56 --> Config Class Initialized
INFO - 2021-01-13 05:39:56 --> Loader Class Initialized
INFO - 2021-01-13 05:39:56 --> Helper loaded: url_helper
INFO - 2021-01-13 05:39:56 --> Helper loaded: file_helper
INFO - 2021-01-13 05:39:56 --> Helper loaded: form_helper
INFO - 2021-01-13 05:39:56 --> Helper loaded: my_helper
INFO - 2021-01-13 05:39:56 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:39:56 --> Controller Class Initialized
DEBUG - 2021-01-13 05:39:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-13 05:39:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:39:56 --> Final output sent to browser
DEBUG - 2021-01-13 05:39:56 --> Total execution time: 0.2681
INFO - 2021-01-13 05:39:59 --> Config Class Initialized
INFO - 2021-01-13 05:39:59 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:39:59 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:39:59 --> Utf8 Class Initialized
INFO - 2021-01-13 05:39:59 --> URI Class Initialized
INFO - 2021-01-13 05:40:00 --> Router Class Initialized
INFO - 2021-01-13 05:40:00 --> Output Class Initialized
INFO - 2021-01-13 05:40:00 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:00 --> Input Class Initialized
INFO - 2021-01-13 05:40:00 --> Language Class Initialized
INFO - 2021-01-13 05:40:00 --> Language Class Initialized
INFO - 2021-01-13 05:40:00 --> Config Class Initialized
INFO - 2021-01-13 05:40:00 --> Loader Class Initialized
INFO - 2021-01-13 05:40:00 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:00 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:00 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:00 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:00 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:00 --> Controller Class Initialized
INFO - 2021-01-13 05:40:00 --> Final output sent to browser
DEBUG - 2021-01-13 05:40:00 --> Total execution time: 0.3201
INFO - 2021-01-13 05:40:03 --> Config Class Initialized
INFO - 2021-01-13 05:40:03 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:40:03 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:40:03 --> Utf8 Class Initialized
INFO - 2021-01-13 05:40:03 --> URI Class Initialized
INFO - 2021-01-13 05:40:03 --> Router Class Initialized
INFO - 2021-01-13 05:40:04 --> Output Class Initialized
INFO - 2021-01-13 05:40:04 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:04 --> Input Class Initialized
INFO - 2021-01-13 05:40:04 --> Language Class Initialized
INFO - 2021-01-13 05:40:04 --> Language Class Initialized
INFO - 2021-01-13 05:40:04 --> Config Class Initialized
INFO - 2021-01-13 05:40:04 --> Loader Class Initialized
INFO - 2021-01-13 05:40:04 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:04 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:04 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:04 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:04 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:04 --> Controller Class Initialized
INFO - 2021-01-13 05:40:04 --> Helper loaded: cookie_helper
INFO - 2021-01-13 05:40:04 --> Final output sent to browser
DEBUG - 2021-01-13 05:40:04 --> Total execution time: 0.3539
INFO - 2021-01-13 05:40:04 --> Config Class Initialized
INFO - 2021-01-13 05:40:04 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:40:04 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:40:04 --> Utf8 Class Initialized
INFO - 2021-01-13 05:40:04 --> URI Class Initialized
INFO - 2021-01-13 05:40:04 --> Router Class Initialized
INFO - 2021-01-13 05:40:04 --> Output Class Initialized
INFO - 2021-01-13 05:40:04 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:04 --> Input Class Initialized
INFO - 2021-01-13 05:40:04 --> Language Class Initialized
INFO - 2021-01-13 05:40:04 --> Language Class Initialized
INFO - 2021-01-13 05:40:04 --> Config Class Initialized
INFO - 2021-01-13 05:40:04 --> Loader Class Initialized
INFO - 2021-01-13 05:40:04 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:04 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:04 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:04 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:04 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:04 --> Controller Class Initialized
DEBUG - 2021-01-13 05:40:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-13 05:40:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:40:05 --> Final output sent to browser
DEBUG - 2021-01-13 05:40:05 --> Total execution time: 0.3689
INFO - 2021-01-13 05:40:06 --> Config Class Initialized
INFO - 2021-01-13 05:40:06 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:40:06 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:40:06 --> Utf8 Class Initialized
INFO - 2021-01-13 05:40:06 --> URI Class Initialized
INFO - 2021-01-13 05:40:06 --> Router Class Initialized
INFO - 2021-01-13 05:40:06 --> Output Class Initialized
INFO - 2021-01-13 05:40:06 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:06 --> Input Class Initialized
INFO - 2021-01-13 05:40:06 --> Language Class Initialized
INFO - 2021-01-13 05:40:06 --> Language Class Initialized
INFO - 2021-01-13 05:40:06 --> Config Class Initialized
INFO - 2021-01-13 05:40:06 --> Loader Class Initialized
INFO - 2021-01-13 05:40:06 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:06 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:06 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:06 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:06 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:06 --> Controller Class Initialized
DEBUG - 2021-01-13 05:40:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-13 05:40:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:40:06 --> Final output sent to browser
DEBUG - 2021-01-13 05:40:06 --> Total execution time: 0.2895
INFO - 2021-01-13 05:40:06 --> Config Class Initialized
INFO - 2021-01-13 05:40:06 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:40:06 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:40:06 --> Utf8 Class Initialized
INFO - 2021-01-13 05:40:06 --> URI Class Initialized
INFO - 2021-01-13 05:40:06 --> Router Class Initialized
INFO - 2021-01-13 05:40:06 --> Output Class Initialized
INFO - 2021-01-13 05:40:06 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:06 --> Input Class Initialized
INFO - 2021-01-13 05:40:06 --> Language Class Initialized
INFO - 2021-01-13 05:40:06 --> Language Class Initialized
INFO - 2021-01-13 05:40:06 --> Config Class Initialized
INFO - 2021-01-13 05:40:07 --> Loader Class Initialized
INFO - 2021-01-13 05:40:07 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:07 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:07 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:07 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:07 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:07 --> Controller Class Initialized
INFO - 2021-01-13 05:40:34 --> Config Class Initialized
INFO - 2021-01-13 05:40:34 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:40:34 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:40:34 --> Utf8 Class Initialized
INFO - 2021-01-13 05:40:34 --> URI Class Initialized
INFO - 2021-01-13 05:40:34 --> Router Class Initialized
INFO - 2021-01-13 05:40:34 --> Output Class Initialized
INFO - 2021-01-13 05:40:34 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:34 --> Input Class Initialized
INFO - 2021-01-13 05:40:34 --> Language Class Initialized
INFO - 2021-01-13 05:40:34 --> Language Class Initialized
INFO - 2021-01-13 05:40:34 --> Config Class Initialized
INFO - 2021-01-13 05:40:34 --> Loader Class Initialized
INFO - 2021-01-13 05:40:34 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:34 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:34 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:34 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:34 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:34 --> Controller Class Initialized
DEBUG - 2021-01-13 05:40:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-01-13 05:40:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:40:34 --> Final output sent to browser
DEBUG - 2021-01-13 05:40:34 --> Total execution time: 0.3044
INFO - 2021-01-13 05:40:35 --> Config Class Initialized
INFO - 2021-01-13 05:40:35 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:40:35 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:40:35 --> Utf8 Class Initialized
INFO - 2021-01-13 05:40:35 --> URI Class Initialized
INFO - 2021-01-13 05:40:35 --> Router Class Initialized
INFO - 2021-01-13 05:40:35 --> Output Class Initialized
INFO - 2021-01-13 05:40:35 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:35 --> Input Class Initialized
INFO - 2021-01-13 05:40:35 --> Language Class Initialized
INFO - 2021-01-13 05:40:35 --> Language Class Initialized
INFO - 2021-01-13 05:40:35 --> Config Class Initialized
INFO - 2021-01-13 05:40:35 --> Loader Class Initialized
INFO - 2021-01-13 05:40:35 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:35 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:35 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:35 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:35 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:35 --> Controller Class Initialized
INFO - 2021-01-13 05:40:38 --> Config Class Initialized
INFO - 2021-01-13 05:40:38 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:40:38 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:40:38 --> Utf8 Class Initialized
INFO - 2021-01-13 05:40:38 --> URI Class Initialized
INFO - 2021-01-13 05:40:38 --> Router Class Initialized
INFO - 2021-01-13 05:40:38 --> Output Class Initialized
INFO - 2021-01-13 05:40:38 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:38 --> Input Class Initialized
INFO - 2021-01-13 05:40:38 --> Language Class Initialized
INFO - 2021-01-13 05:40:38 --> Language Class Initialized
INFO - 2021-01-13 05:40:38 --> Config Class Initialized
INFO - 2021-01-13 05:40:38 --> Loader Class Initialized
INFO - 2021-01-13 05:40:38 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:38 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:38 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:38 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:38 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:38 --> Controller Class Initialized
DEBUG - 2021-01-13 05:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-01-13 05:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:40:38 --> Final output sent to browser
DEBUG - 2021-01-13 05:40:38 --> Total execution time: 0.2826
INFO - 2021-01-13 05:40:38 --> Config Class Initialized
INFO - 2021-01-13 05:40:38 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:40:38 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:40:38 --> Utf8 Class Initialized
INFO - 2021-01-13 05:40:38 --> URI Class Initialized
INFO - 2021-01-13 05:40:38 --> Router Class Initialized
INFO - 2021-01-13 05:40:38 --> Output Class Initialized
INFO - 2021-01-13 05:40:38 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:38 --> Input Class Initialized
INFO - 2021-01-13 05:40:38 --> Language Class Initialized
INFO - 2021-01-13 05:40:38 --> Language Class Initialized
INFO - 2021-01-13 05:40:38 --> Config Class Initialized
INFO - 2021-01-13 05:40:38 --> Loader Class Initialized
INFO - 2021-01-13 05:40:38 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:38 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:38 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:38 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:38 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:39 --> Controller Class Initialized
INFO - 2021-01-13 05:40:41 --> Config Class Initialized
INFO - 2021-01-13 05:40:41 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:40:41 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:40:41 --> Utf8 Class Initialized
INFO - 2021-01-13 05:40:41 --> URI Class Initialized
INFO - 2021-01-13 05:40:41 --> Router Class Initialized
INFO - 2021-01-13 05:40:41 --> Output Class Initialized
INFO - 2021-01-13 05:40:41 --> Security Class Initialized
DEBUG - 2021-01-13 05:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:40:41 --> Input Class Initialized
INFO - 2021-01-13 05:40:41 --> Language Class Initialized
INFO - 2021-01-13 05:40:41 --> Language Class Initialized
INFO - 2021-01-13 05:40:41 --> Config Class Initialized
INFO - 2021-01-13 05:40:41 --> Loader Class Initialized
INFO - 2021-01-13 05:40:41 --> Helper loaded: url_helper
INFO - 2021-01-13 05:40:41 --> Helper loaded: file_helper
INFO - 2021-01-13 05:40:41 --> Helper loaded: form_helper
INFO - 2021-01-13 05:40:41 --> Helper loaded: my_helper
INFO - 2021-01-13 05:40:41 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:40:41 --> Controller Class Initialized
DEBUG - 2021-01-13 05:40:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-01-13 05:40:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:40:41 --> Final output sent to browser
DEBUG - 2021-01-13 05:40:41 --> Total execution time: 0.3014
INFO - 2021-01-13 05:41:56 --> Config Class Initialized
INFO - 2021-01-13 05:41:56 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:41:56 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:41:56 --> Utf8 Class Initialized
INFO - 2021-01-13 05:41:56 --> URI Class Initialized
INFO - 2021-01-13 05:41:56 --> Router Class Initialized
INFO - 2021-01-13 05:41:56 --> Output Class Initialized
INFO - 2021-01-13 05:41:56 --> Security Class Initialized
DEBUG - 2021-01-13 05:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:41:56 --> Input Class Initialized
INFO - 2021-01-13 05:41:56 --> Language Class Initialized
INFO - 2021-01-13 05:41:56 --> Language Class Initialized
INFO - 2021-01-13 05:41:56 --> Config Class Initialized
INFO - 2021-01-13 05:41:56 --> Loader Class Initialized
INFO - 2021-01-13 05:41:56 --> Helper loaded: url_helper
INFO - 2021-01-13 05:41:56 --> Helper loaded: file_helper
INFO - 2021-01-13 05:41:56 --> Helper loaded: form_helper
INFO - 2021-01-13 05:41:56 --> Helper loaded: my_helper
INFO - 2021-01-13 05:41:56 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:41:56 --> Controller Class Initialized
DEBUG - 2021-01-13 05:41:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-13 05:41:56 --> Final output sent to browser
DEBUG - 2021-01-13 05:41:56 --> Total execution time: 0.2282
INFO - 2021-01-13 05:42:04 --> Config Class Initialized
INFO - 2021-01-13 05:42:04 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:42:04 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:42:04 --> Utf8 Class Initialized
INFO - 2021-01-13 05:42:04 --> URI Class Initialized
INFO - 2021-01-13 05:42:04 --> Router Class Initialized
INFO - 2021-01-13 05:42:04 --> Output Class Initialized
INFO - 2021-01-13 05:42:04 --> Security Class Initialized
DEBUG - 2021-01-13 05:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:42:04 --> Input Class Initialized
INFO - 2021-01-13 05:42:04 --> Language Class Initialized
INFO - 2021-01-13 05:42:04 --> Language Class Initialized
INFO - 2021-01-13 05:42:04 --> Config Class Initialized
INFO - 2021-01-13 05:42:04 --> Loader Class Initialized
INFO - 2021-01-13 05:42:04 --> Helper loaded: url_helper
INFO - 2021-01-13 05:42:04 --> Helper loaded: file_helper
INFO - 2021-01-13 05:42:04 --> Helper loaded: form_helper
INFO - 2021-01-13 05:42:04 --> Helper loaded: my_helper
INFO - 2021-01-13 05:42:04 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:42:04 --> Controller Class Initialized
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
ERROR - 2021-01-13 05:42:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 508
DEBUG - 2021-01-13 05:42:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-13 05:42:04 --> Final output sent to browser
DEBUG - 2021-01-13 05:42:04 --> Total execution time: 0.6413
INFO - 2021-01-13 05:42:43 --> Config Class Initialized
INFO - 2021-01-13 05:42:43 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:42:43 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:42:43 --> Utf8 Class Initialized
INFO - 2021-01-13 05:42:43 --> URI Class Initialized
INFO - 2021-01-13 05:42:43 --> Router Class Initialized
INFO - 2021-01-13 05:42:43 --> Output Class Initialized
INFO - 2021-01-13 05:42:43 --> Security Class Initialized
DEBUG - 2021-01-13 05:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:42:43 --> Input Class Initialized
INFO - 2021-01-13 05:42:43 --> Language Class Initialized
INFO - 2021-01-13 05:42:43 --> Language Class Initialized
INFO - 2021-01-13 05:42:43 --> Config Class Initialized
INFO - 2021-01-13 05:42:43 --> Loader Class Initialized
INFO - 2021-01-13 05:42:43 --> Helper loaded: url_helper
INFO - 2021-01-13 05:42:43 --> Helper loaded: file_helper
INFO - 2021-01-13 05:42:43 --> Helper loaded: form_helper
INFO - 2021-01-13 05:42:43 --> Helper loaded: my_helper
INFO - 2021-01-13 05:42:43 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:42:43 --> Controller Class Initialized
INFO - 2021-01-13 05:42:43 --> Helper loaded: cookie_helper
INFO - 2021-01-13 05:42:44 --> Config Class Initialized
INFO - 2021-01-13 05:42:44 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:42:44 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:42:44 --> Utf8 Class Initialized
INFO - 2021-01-13 05:42:44 --> URI Class Initialized
INFO - 2021-01-13 05:42:44 --> Router Class Initialized
INFO - 2021-01-13 05:42:44 --> Output Class Initialized
INFO - 2021-01-13 05:42:44 --> Security Class Initialized
DEBUG - 2021-01-13 05:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:42:44 --> Input Class Initialized
INFO - 2021-01-13 05:42:44 --> Language Class Initialized
INFO - 2021-01-13 05:42:44 --> Language Class Initialized
INFO - 2021-01-13 05:42:44 --> Config Class Initialized
INFO - 2021-01-13 05:42:44 --> Loader Class Initialized
INFO - 2021-01-13 05:42:44 --> Helper loaded: url_helper
INFO - 2021-01-13 05:42:44 --> Helper loaded: file_helper
INFO - 2021-01-13 05:42:44 --> Helper loaded: form_helper
INFO - 2021-01-13 05:42:44 --> Helper loaded: my_helper
INFO - 2021-01-13 05:42:44 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:42:44 --> Controller Class Initialized
DEBUG - 2021-01-13 05:42:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-13 05:42:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:42:44 --> Final output sent to browser
DEBUG - 2021-01-13 05:42:44 --> Total execution time: 0.2691
INFO - 2021-01-13 05:42:49 --> Config Class Initialized
INFO - 2021-01-13 05:42:49 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:42:49 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:42:49 --> Utf8 Class Initialized
INFO - 2021-01-13 05:42:49 --> URI Class Initialized
INFO - 2021-01-13 05:42:49 --> Router Class Initialized
INFO - 2021-01-13 05:42:49 --> Output Class Initialized
INFO - 2021-01-13 05:42:49 --> Security Class Initialized
DEBUG - 2021-01-13 05:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:42:49 --> Input Class Initialized
INFO - 2021-01-13 05:42:49 --> Language Class Initialized
INFO - 2021-01-13 05:42:49 --> Language Class Initialized
INFO - 2021-01-13 05:42:49 --> Config Class Initialized
INFO - 2021-01-13 05:42:49 --> Loader Class Initialized
INFO - 2021-01-13 05:42:49 --> Helper loaded: url_helper
INFO - 2021-01-13 05:42:49 --> Helper loaded: file_helper
INFO - 2021-01-13 05:42:49 --> Helper loaded: form_helper
INFO - 2021-01-13 05:42:49 --> Helper loaded: my_helper
INFO - 2021-01-13 05:42:49 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:42:49 --> Controller Class Initialized
INFO - 2021-01-13 05:42:49 --> Helper loaded: cookie_helper
INFO - 2021-01-13 05:42:49 --> Final output sent to browser
DEBUG - 2021-01-13 05:42:49 --> Total execution time: 0.3634
INFO - 2021-01-13 05:42:49 --> Config Class Initialized
INFO - 2021-01-13 05:42:49 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:42:49 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:42:49 --> Utf8 Class Initialized
INFO - 2021-01-13 05:42:49 --> URI Class Initialized
INFO - 2021-01-13 05:42:49 --> Router Class Initialized
INFO - 2021-01-13 05:42:49 --> Output Class Initialized
INFO - 2021-01-13 05:42:49 --> Security Class Initialized
DEBUG - 2021-01-13 05:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:42:49 --> Input Class Initialized
INFO - 2021-01-13 05:42:49 --> Language Class Initialized
INFO - 2021-01-13 05:42:49 --> Language Class Initialized
INFO - 2021-01-13 05:42:49 --> Config Class Initialized
INFO - 2021-01-13 05:42:49 --> Loader Class Initialized
INFO - 2021-01-13 05:42:49 --> Helper loaded: url_helper
INFO - 2021-01-13 05:42:49 --> Helper loaded: file_helper
INFO - 2021-01-13 05:42:49 --> Helper loaded: form_helper
INFO - 2021-01-13 05:42:49 --> Helper loaded: my_helper
INFO - 2021-01-13 05:42:50 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:42:50 --> Controller Class Initialized
DEBUG - 2021-01-13 05:42:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-13 05:42:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:42:50 --> Final output sent to browser
DEBUG - 2021-01-13 05:42:50 --> Total execution time: 0.4517
INFO - 2021-01-13 05:42:53 --> Config Class Initialized
INFO - 2021-01-13 05:42:53 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:42:53 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:42:53 --> Utf8 Class Initialized
INFO - 2021-01-13 05:42:53 --> URI Class Initialized
INFO - 2021-01-13 05:42:53 --> Router Class Initialized
INFO - 2021-01-13 05:42:53 --> Output Class Initialized
INFO - 2021-01-13 05:42:53 --> Security Class Initialized
DEBUG - 2021-01-13 05:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:42:53 --> Input Class Initialized
INFO - 2021-01-13 05:42:53 --> Language Class Initialized
INFO - 2021-01-13 05:42:53 --> Language Class Initialized
INFO - 2021-01-13 05:42:53 --> Config Class Initialized
INFO - 2021-01-13 05:42:53 --> Loader Class Initialized
INFO - 2021-01-13 05:42:53 --> Helper loaded: url_helper
INFO - 2021-01-13 05:42:53 --> Helper loaded: file_helper
INFO - 2021-01-13 05:42:53 --> Helper loaded: form_helper
INFO - 2021-01-13 05:42:53 --> Helper loaded: my_helper
INFO - 2021-01-13 05:42:53 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:42:53 --> Controller Class Initialized
DEBUG - 2021-01-13 05:42:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-01-13 05:42:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:42:53 --> Final output sent to browser
DEBUG - 2021-01-13 05:42:53 --> Total execution time: 0.3961
INFO - 2021-01-13 05:42:57 --> Config Class Initialized
INFO - 2021-01-13 05:42:57 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:42:57 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:42:57 --> Utf8 Class Initialized
INFO - 2021-01-13 05:42:57 --> URI Class Initialized
INFO - 2021-01-13 05:42:57 --> Router Class Initialized
INFO - 2021-01-13 05:42:57 --> Output Class Initialized
INFO - 2021-01-13 05:42:57 --> Security Class Initialized
DEBUG - 2021-01-13 05:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:42:57 --> Input Class Initialized
INFO - 2021-01-13 05:42:57 --> Language Class Initialized
INFO - 2021-01-13 05:42:57 --> Language Class Initialized
INFO - 2021-01-13 05:42:57 --> Config Class Initialized
INFO - 2021-01-13 05:42:57 --> Loader Class Initialized
INFO - 2021-01-13 05:42:57 --> Helper loaded: url_helper
INFO - 2021-01-13 05:42:57 --> Helper loaded: file_helper
INFO - 2021-01-13 05:42:57 --> Helper loaded: form_helper
INFO - 2021-01-13 05:42:57 --> Helper loaded: my_helper
INFO - 2021-01-13 05:42:57 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:42:58 --> Controller Class Initialized
DEBUG - 2021-01-13 05:42:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-13 05:42:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:42:58 --> Final output sent to browser
DEBUG - 2021-01-13 05:42:58 --> Total execution time: 0.3439
INFO - 2021-01-13 05:43:01 --> Config Class Initialized
INFO - 2021-01-13 05:43:01 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:01 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:01 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:01 --> URI Class Initialized
INFO - 2021-01-13 05:43:01 --> Router Class Initialized
INFO - 2021-01-13 05:43:01 --> Output Class Initialized
INFO - 2021-01-13 05:43:01 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:01 --> Input Class Initialized
INFO - 2021-01-13 05:43:01 --> Language Class Initialized
INFO - 2021-01-13 05:43:01 --> Language Class Initialized
INFO - 2021-01-13 05:43:01 --> Config Class Initialized
INFO - 2021-01-13 05:43:01 --> Loader Class Initialized
INFO - 2021-01-13 05:43:01 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:01 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:01 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:01 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:01 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:01 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-13 05:43:01 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:01 --> Total execution time: 0.3110
INFO - 2021-01-13 05:43:09 --> Config Class Initialized
INFO - 2021-01-13 05:43:09 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:09 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:09 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:09 --> URI Class Initialized
INFO - 2021-01-13 05:43:09 --> Router Class Initialized
INFO - 2021-01-13 05:43:09 --> Output Class Initialized
INFO - 2021-01-13 05:43:09 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:09 --> Input Class Initialized
INFO - 2021-01-13 05:43:09 --> Language Class Initialized
INFO - 2021-01-13 05:43:09 --> Language Class Initialized
INFO - 2021-01-13 05:43:09 --> Config Class Initialized
INFO - 2021-01-13 05:43:09 --> Loader Class Initialized
INFO - 2021-01-13 05:43:09 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:09 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:09 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:09 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:09 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:09 --> Controller Class Initialized
INFO - 2021-01-13 05:43:09 --> Helper loaded: cookie_helper
INFO - 2021-01-13 05:43:09 --> Config Class Initialized
INFO - 2021-01-13 05:43:09 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:09 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:09 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:09 --> URI Class Initialized
INFO - 2021-01-13 05:43:09 --> Router Class Initialized
INFO - 2021-01-13 05:43:09 --> Output Class Initialized
INFO - 2021-01-13 05:43:09 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:09 --> Input Class Initialized
INFO - 2021-01-13 05:43:09 --> Language Class Initialized
INFO - 2021-01-13 05:43:09 --> Language Class Initialized
INFO - 2021-01-13 05:43:09 --> Config Class Initialized
INFO - 2021-01-13 05:43:09 --> Loader Class Initialized
INFO - 2021-01-13 05:43:09 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:09 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:09 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:09 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:09 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:09 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-13 05:43:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:09 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:09 --> Total execution time: 0.2471
INFO - 2021-01-13 05:43:13 --> Config Class Initialized
INFO - 2021-01-13 05:43:13 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:13 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:13 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:13 --> URI Class Initialized
INFO - 2021-01-13 05:43:13 --> Router Class Initialized
INFO - 2021-01-13 05:43:13 --> Output Class Initialized
INFO - 2021-01-13 05:43:13 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:13 --> Input Class Initialized
INFO - 2021-01-13 05:43:13 --> Language Class Initialized
INFO - 2021-01-13 05:43:13 --> Language Class Initialized
INFO - 2021-01-13 05:43:13 --> Config Class Initialized
INFO - 2021-01-13 05:43:13 --> Loader Class Initialized
INFO - 2021-01-13 05:43:13 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:13 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:13 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:13 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:13 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:13 --> Controller Class Initialized
INFO - 2021-01-13 05:43:13 --> Helper loaded: cookie_helper
INFO - 2021-01-13 05:43:13 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:13 --> Total execution time: 0.3450
INFO - 2021-01-13 05:43:14 --> Config Class Initialized
INFO - 2021-01-13 05:43:14 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:14 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:14 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:14 --> URI Class Initialized
INFO - 2021-01-13 05:43:14 --> Router Class Initialized
INFO - 2021-01-13 05:43:14 --> Output Class Initialized
INFO - 2021-01-13 05:43:14 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:14 --> Input Class Initialized
INFO - 2021-01-13 05:43:14 --> Language Class Initialized
INFO - 2021-01-13 05:43:14 --> Language Class Initialized
INFO - 2021-01-13 05:43:14 --> Config Class Initialized
INFO - 2021-01-13 05:43:14 --> Loader Class Initialized
INFO - 2021-01-13 05:43:14 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:14 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:14 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:14 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:14 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:14 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-13 05:43:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:14 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:14 --> Total execution time: 0.3721
INFO - 2021-01-13 05:43:15 --> Config Class Initialized
INFO - 2021-01-13 05:43:15 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:15 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:15 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:15 --> URI Class Initialized
INFO - 2021-01-13 05:43:15 --> Router Class Initialized
INFO - 2021-01-13 05:43:15 --> Output Class Initialized
INFO - 2021-01-13 05:43:15 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:15 --> Input Class Initialized
INFO - 2021-01-13 05:43:15 --> Language Class Initialized
INFO - 2021-01-13 05:43:15 --> Language Class Initialized
INFO - 2021-01-13 05:43:15 --> Config Class Initialized
INFO - 2021-01-13 05:43:15 --> Loader Class Initialized
INFO - 2021-01-13 05:43:15 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:15 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:15 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:15 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:15 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:15 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-01-13 05:43:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:15 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:15 --> Total execution time: 0.3068
INFO - 2021-01-13 05:43:17 --> Config Class Initialized
INFO - 2021-01-13 05:43:17 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:17 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:17 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:17 --> URI Class Initialized
INFO - 2021-01-13 05:43:17 --> Router Class Initialized
INFO - 2021-01-13 05:43:17 --> Output Class Initialized
INFO - 2021-01-13 05:43:17 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:17 --> Input Class Initialized
INFO - 2021-01-13 05:43:17 --> Language Class Initialized
INFO - 2021-01-13 05:43:17 --> Language Class Initialized
INFO - 2021-01-13 05:43:18 --> Config Class Initialized
INFO - 2021-01-13 05:43:18 --> Loader Class Initialized
INFO - 2021-01-13 05:43:18 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:18 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:18 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:18 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:18 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:18 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-13 05:43:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:18 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:18 --> Total execution time: 0.2682
INFO - 2021-01-13 05:43:22 --> Config Class Initialized
INFO - 2021-01-13 05:43:22 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:22 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:22 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:22 --> URI Class Initialized
INFO - 2021-01-13 05:43:22 --> Router Class Initialized
INFO - 2021-01-13 05:43:22 --> Output Class Initialized
INFO - 2021-01-13 05:43:22 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:22 --> Input Class Initialized
INFO - 2021-01-13 05:43:22 --> Language Class Initialized
INFO - 2021-01-13 05:43:22 --> Language Class Initialized
INFO - 2021-01-13 05:43:22 --> Config Class Initialized
INFO - 2021-01-13 05:43:22 --> Loader Class Initialized
INFO - 2021-01-13 05:43:22 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:22 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:22 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:22 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:22 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:22 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-13 05:43:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:22 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:22 --> Total execution time: 0.2605
INFO - 2021-01-13 05:43:23 --> Config Class Initialized
INFO - 2021-01-13 05:43:23 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:23 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:24 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:24 --> URI Class Initialized
INFO - 2021-01-13 05:43:24 --> Router Class Initialized
INFO - 2021-01-13 05:43:24 --> Output Class Initialized
INFO - 2021-01-13 05:43:24 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:24 --> Input Class Initialized
INFO - 2021-01-13 05:43:24 --> Language Class Initialized
INFO - 2021-01-13 05:43:24 --> Language Class Initialized
INFO - 2021-01-13 05:43:24 --> Config Class Initialized
INFO - 2021-01-13 05:43:24 --> Loader Class Initialized
INFO - 2021-01-13 05:43:24 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:24 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:24 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:24 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:24 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:24 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-13 05:43:24 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:24 --> Total execution time: 0.3142
INFO - 2021-01-13 05:43:28 --> Config Class Initialized
INFO - 2021-01-13 05:43:28 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:28 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:28 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:28 --> URI Class Initialized
INFO - 2021-01-13 05:43:28 --> Router Class Initialized
INFO - 2021-01-13 05:43:28 --> Output Class Initialized
INFO - 2021-01-13 05:43:28 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:28 --> Input Class Initialized
INFO - 2021-01-13 05:43:28 --> Language Class Initialized
INFO - 2021-01-13 05:43:28 --> Language Class Initialized
INFO - 2021-01-13 05:43:28 --> Config Class Initialized
INFO - 2021-01-13 05:43:28 --> Loader Class Initialized
INFO - 2021-01-13 05:43:28 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:28 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:28 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:28 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:28 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:28 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-13 05:43:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:28 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:28 --> Total execution time: 0.3510
INFO - 2021-01-13 05:43:29 --> Config Class Initialized
INFO - 2021-01-13 05:43:29 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:29 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:29 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:29 --> URI Class Initialized
INFO - 2021-01-13 05:43:29 --> Router Class Initialized
INFO - 2021-01-13 05:43:29 --> Output Class Initialized
INFO - 2021-01-13 05:43:29 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:29 --> Input Class Initialized
INFO - 2021-01-13 05:43:29 --> Language Class Initialized
INFO - 2021-01-13 05:43:29 --> Language Class Initialized
INFO - 2021-01-13 05:43:29 --> Config Class Initialized
INFO - 2021-01-13 05:43:29 --> Loader Class Initialized
INFO - 2021-01-13 05:43:29 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:29 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:29 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:29 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:29 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:29 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-13 05:43:29 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:29 --> Total execution time: 0.3214
INFO - 2021-01-13 05:43:35 --> Config Class Initialized
INFO - 2021-01-13 05:43:35 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:35 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:35 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:35 --> URI Class Initialized
INFO - 2021-01-13 05:43:35 --> Router Class Initialized
INFO - 2021-01-13 05:43:36 --> Output Class Initialized
INFO - 2021-01-13 05:43:36 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:36 --> Input Class Initialized
INFO - 2021-01-13 05:43:36 --> Language Class Initialized
INFO - 2021-01-13 05:43:36 --> Language Class Initialized
INFO - 2021-01-13 05:43:36 --> Config Class Initialized
INFO - 2021-01-13 05:43:36 --> Loader Class Initialized
INFO - 2021-01-13 05:43:36 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:36 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:36 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:36 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:36 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:36 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-13 05:43:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:36 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:36 --> Total execution time: 0.2849
INFO - 2021-01-13 05:43:39 --> Config Class Initialized
INFO - 2021-01-13 05:43:39 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:39 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:39 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:39 --> URI Class Initialized
DEBUG - 2021-01-13 05:43:39 --> No URI present. Default controller set.
INFO - 2021-01-13 05:43:39 --> Router Class Initialized
INFO - 2021-01-13 05:43:39 --> Output Class Initialized
INFO - 2021-01-13 05:43:39 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:39 --> Input Class Initialized
INFO - 2021-01-13 05:43:39 --> Language Class Initialized
INFO - 2021-01-13 05:43:39 --> Language Class Initialized
INFO - 2021-01-13 05:43:39 --> Config Class Initialized
INFO - 2021-01-13 05:43:39 --> Loader Class Initialized
INFO - 2021-01-13 05:43:39 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:39 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:39 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:39 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:39 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:40 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-13 05:43:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:40 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:40 --> Total execution time: 0.3823
INFO - 2021-01-13 05:43:41 --> Config Class Initialized
INFO - 2021-01-13 05:43:42 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:42 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:42 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:42 --> URI Class Initialized
INFO - 2021-01-13 05:43:42 --> Router Class Initialized
INFO - 2021-01-13 05:43:42 --> Output Class Initialized
INFO - 2021-01-13 05:43:42 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:42 --> Input Class Initialized
INFO - 2021-01-13 05:43:42 --> Language Class Initialized
INFO - 2021-01-13 05:43:42 --> Language Class Initialized
INFO - 2021-01-13 05:43:42 --> Config Class Initialized
INFO - 2021-01-13 05:43:42 --> Loader Class Initialized
INFO - 2021-01-13 05:43:42 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:42 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:42 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:42 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:42 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:42 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-13 05:43:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:42 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:42 --> Total execution time: 0.3509
INFO - 2021-01-13 05:43:46 --> Config Class Initialized
INFO - 2021-01-13 05:43:46 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:46 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:46 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:46 --> URI Class Initialized
INFO - 2021-01-13 05:43:46 --> Router Class Initialized
INFO - 2021-01-13 05:43:46 --> Output Class Initialized
INFO - 2021-01-13 05:43:46 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:46 --> Input Class Initialized
INFO - 2021-01-13 05:43:46 --> Language Class Initialized
INFO - 2021-01-13 05:43:46 --> Language Class Initialized
INFO - 2021-01-13 05:43:46 --> Config Class Initialized
INFO - 2021-01-13 05:43:46 --> Loader Class Initialized
INFO - 2021-01-13 05:43:46 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:46 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:46 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:46 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:46 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:46 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-13 05:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-13 05:43:46 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:46 --> Total execution time: 0.2587
INFO - 2021-01-13 05:43:48 --> Config Class Initialized
INFO - 2021-01-13 05:43:48 --> Hooks Class Initialized
DEBUG - 2021-01-13 05:43:48 --> UTF-8 Support Enabled
INFO - 2021-01-13 05:43:48 --> Utf8 Class Initialized
INFO - 2021-01-13 05:43:48 --> URI Class Initialized
INFO - 2021-01-13 05:43:48 --> Router Class Initialized
INFO - 2021-01-13 05:43:48 --> Output Class Initialized
INFO - 2021-01-13 05:43:48 --> Security Class Initialized
DEBUG - 2021-01-13 05:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-13 05:43:48 --> Input Class Initialized
INFO - 2021-01-13 05:43:48 --> Language Class Initialized
INFO - 2021-01-13 05:43:48 --> Language Class Initialized
INFO - 2021-01-13 05:43:48 --> Config Class Initialized
INFO - 2021-01-13 05:43:48 --> Loader Class Initialized
INFO - 2021-01-13 05:43:48 --> Helper loaded: url_helper
INFO - 2021-01-13 05:43:48 --> Helper loaded: file_helper
INFO - 2021-01-13 05:43:48 --> Helper loaded: form_helper
INFO - 2021-01-13 05:43:48 --> Helper loaded: my_helper
INFO - 2021-01-13 05:43:48 --> Database Driver Class Initialized
DEBUG - 2021-01-13 05:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-13 05:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-13 05:43:48 --> Controller Class Initialized
DEBUG - 2021-01-13 05:43:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-13 05:43:48 --> Final output sent to browser
DEBUG - 2021-01-13 05:43:48 --> Total execution time: 0.3032
