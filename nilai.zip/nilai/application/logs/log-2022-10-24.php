<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-10-24 09:24:25 --> Config Class Initialized
INFO - 2022-10-24 09:24:25 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:24:25 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:24:25 --> Utf8 Class Initialized
INFO - 2022-10-24 09:24:25 --> URI Class Initialized
INFO - 2022-10-24 09:24:25 --> Router Class Initialized
INFO - 2022-10-24 09:24:25 --> Output Class Initialized
INFO - 2022-10-24 09:24:25 --> Security Class Initialized
DEBUG - 2022-10-24 09:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:24:25 --> Input Class Initialized
INFO - 2022-10-24 09:24:25 --> Language Class Initialized
INFO - 2022-10-24 09:24:25 --> Language Class Initialized
INFO - 2022-10-24 09:24:25 --> Config Class Initialized
INFO - 2022-10-24 09:24:25 --> Loader Class Initialized
INFO - 2022-10-24 09:24:25 --> Helper loaded: url_helper
INFO - 2022-10-24 09:24:25 --> Helper loaded: file_helper
INFO - 2022-10-24 09:24:25 --> Helper loaded: form_helper
INFO - 2022-10-24 09:24:25 --> Helper loaded: my_helper
INFO - 2022-10-24 09:24:25 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:24:26 --> Controller Class Initialized
DEBUG - 2022-10-24 09:24:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-10-24 09:24:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-24 09:24:26 --> Final output sent to browser
DEBUG - 2022-10-24 09:24:26 --> Total execution time: 0.7294
INFO - 2022-10-24 09:24:34 --> Config Class Initialized
INFO - 2022-10-24 09:24:34 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:24:34 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:24:34 --> Utf8 Class Initialized
INFO - 2022-10-24 09:24:34 --> URI Class Initialized
INFO - 2022-10-24 09:24:34 --> Router Class Initialized
INFO - 2022-10-24 09:24:34 --> Output Class Initialized
INFO - 2022-10-24 09:24:34 --> Security Class Initialized
DEBUG - 2022-10-24 09:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:24:34 --> Input Class Initialized
INFO - 2022-10-24 09:24:34 --> Language Class Initialized
INFO - 2022-10-24 09:24:34 --> Language Class Initialized
INFO - 2022-10-24 09:24:34 --> Config Class Initialized
INFO - 2022-10-24 09:24:34 --> Loader Class Initialized
INFO - 2022-10-24 09:24:34 --> Helper loaded: url_helper
INFO - 2022-10-24 09:24:34 --> Helper loaded: file_helper
INFO - 2022-10-24 09:24:34 --> Helper loaded: form_helper
INFO - 2022-10-24 09:24:34 --> Helper loaded: my_helper
INFO - 2022-10-24 09:24:34 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:24:34 --> Controller Class Initialized
INFO - 2022-10-24 09:24:34 --> Helper loaded: cookie_helper
INFO - 2022-10-24 09:24:34 --> Final output sent to browser
DEBUG - 2022-10-24 09:24:34 --> Total execution time: 0.0649
INFO - 2022-10-24 09:24:34 --> Config Class Initialized
INFO - 2022-10-24 09:24:34 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:24:34 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:24:34 --> Utf8 Class Initialized
INFO - 2022-10-24 09:24:34 --> URI Class Initialized
INFO - 2022-10-24 09:24:34 --> Router Class Initialized
INFO - 2022-10-24 09:24:34 --> Output Class Initialized
INFO - 2022-10-24 09:24:34 --> Security Class Initialized
DEBUG - 2022-10-24 09:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:24:34 --> Input Class Initialized
INFO - 2022-10-24 09:24:34 --> Language Class Initialized
INFO - 2022-10-24 09:24:34 --> Language Class Initialized
INFO - 2022-10-24 09:24:34 --> Config Class Initialized
INFO - 2022-10-24 09:24:34 --> Loader Class Initialized
INFO - 2022-10-24 09:24:34 --> Helper loaded: url_helper
INFO - 2022-10-24 09:24:34 --> Helper loaded: file_helper
INFO - 2022-10-24 09:24:34 --> Helper loaded: form_helper
INFO - 2022-10-24 09:24:34 --> Helper loaded: my_helper
INFO - 2022-10-24 09:24:34 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:24:34 --> Controller Class Initialized
DEBUG - 2022-10-24 09:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-10-24 09:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-24 09:24:34 --> Final output sent to browser
DEBUG - 2022-10-24 09:24:34 --> Total execution time: 0.6603
INFO - 2022-10-24 09:24:38 --> Config Class Initialized
INFO - 2022-10-24 09:24:38 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:24:38 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:24:38 --> Utf8 Class Initialized
INFO - 2022-10-24 09:24:38 --> URI Class Initialized
INFO - 2022-10-24 09:24:38 --> Router Class Initialized
INFO - 2022-10-24 09:24:38 --> Output Class Initialized
INFO - 2022-10-24 09:24:38 --> Security Class Initialized
DEBUG - 2022-10-24 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:24:38 --> Input Class Initialized
INFO - 2022-10-24 09:24:38 --> Language Class Initialized
INFO - 2022-10-24 09:24:38 --> Language Class Initialized
INFO - 2022-10-24 09:24:38 --> Config Class Initialized
INFO - 2022-10-24 09:24:38 --> Loader Class Initialized
INFO - 2022-10-24 09:24:38 --> Helper loaded: url_helper
INFO - 2022-10-24 09:24:38 --> Helper loaded: file_helper
INFO - 2022-10-24 09:24:38 --> Helper loaded: form_helper
INFO - 2022-10-24 09:24:38 --> Helper loaded: my_helper
INFO - 2022-10-24 09:24:38 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:24:38 --> Controller Class Initialized
DEBUG - 2022-10-24 09:24:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-10-24 09:24:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-24 09:24:38 --> Final output sent to browser
DEBUG - 2022-10-24 09:24:38 --> Total execution time: 0.0779
INFO - 2022-10-24 09:24:38 --> Config Class Initialized
INFO - 2022-10-24 09:24:38 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:24:38 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:24:38 --> Utf8 Class Initialized
INFO - 2022-10-24 09:24:38 --> URI Class Initialized
INFO - 2022-10-24 09:24:38 --> Router Class Initialized
INFO - 2022-10-24 09:24:38 --> Output Class Initialized
INFO - 2022-10-24 09:24:38 --> Security Class Initialized
DEBUG - 2022-10-24 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:24:38 --> Input Class Initialized
INFO - 2022-10-24 09:24:38 --> Language Class Initialized
INFO - 2022-10-24 09:24:38 --> Language Class Initialized
INFO - 2022-10-24 09:24:38 --> Config Class Initialized
INFO - 2022-10-24 09:24:38 --> Loader Class Initialized
INFO - 2022-10-24 09:24:38 --> Helper loaded: url_helper
INFO - 2022-10-24 09:24:38 --> Helper loaded: file_helper
INFO - 2022-10-24 09:24:38 --> Helper loaded: form_helper
INFO - 2022-10-24 09:24:38 --> Helper loaded: my_helper
INFO - 2022-10-24 09:24:38 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:24:38 --> Controller Class Initialized
INFO - 2022-10-24 09:24:53 --> Config Class Initialized
INFO - 2022-10-24 09:24:53 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:24:53 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:24:53 --> Utf8 Class Initialized
INFO - 2022-10-24 09:24:53 --> URI Class Initialized
INFO - 2022-10-24 09:24:53 --> Router Class Initialized
INFO - 2022-10-24 09:24:53 --> Output Class Initialized
INFO - 2022-10-24 09:24:53 --> Security Class Initialized
DEBUG - 2022-10-24 09:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:24:53 --> Input Class Initialized
INFO - 2022-10-24 09:24:53 --> Language Class Initialized
INFO - 2022-10-24 09:24:53 --> Language Class Initialized
INFO - 2022-10-24 09:24:53 --> Config Class Initialized
INFO - 2022-10-24 09:24:53 --> Loader Class Initialized
INFO - 2022-10-24 09:24:53 --> Helper loaded: url_helper
INFO - 2022-10-24 09:24:53 --> Helper loaded: file_helper
INFO - 2022-10-24 09:24:53 --> Helper loaded: form_helper
INFO - 2022-10-24 09:24:53 --> Helper loaded: my_helper
INFO - 2022-10-24 09:24:53 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:24:53 --> Controller Class Initialized
DEBUG - 2022-10-24 09:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2022-10-24 09:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-24 09:24:53 --> Final output sent to browser
DEBUG - 2022-10-24 09:24:53 --> Total execution time: 0.0847
INFO - 2022-10-24 09:24:53 --> Config Class Initialized
INFO - 2022-10-24 09:24:53 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:24:53 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:24:53 --> Utf8 Class Initialized
INFO - 2022-10-24 09:24:53 --> URI Class Initialized
INFO - 2022-10-24 09:24:53 --> Router Class Initialized
INFO - 2022-10-24 09:24:53 --> Output Class Initialized
INFO - 2022-10-24 09:24:53 --> Security Class Initialized
DEBUG - 2022-10-24 09:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:24:53 --> Input Class Initialized
INFO - 2022-10-24 09:24:53 --> Language Class Initialized
INFO - 2022-10-24 09:24:53 --> Language Class Initialized
INFO - 2022-10-24 09:24:53 --> Config Class Initialized
INFO - 2022-10-24 09:24:53 --> Loader Class Initialized
INFO - 2022-10-24 09:24:53 --> Helper loaded: url_helper
INFO - 2022-10-24 09:24:53 --> Helper loaded: file_helper
INFO - 2022-10-24 09:24:53 --> Helper loaded: form_helper
INFO - 2022-10-24 09:24:53 --> Helper loaded: my_helper
INFO - 2022-10-24 09:24:53 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:24:53 --> Controller Class Initialized
INFO - 2022-10-24 09:26:58 --> Config Class Initialized
INFO - 2022-10-24 09:26:58 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:26:58 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:26:58 --> Utf8 Class Initialized
INFO - 2022-10-24 09:26:58 --> URI Class Initialized
INFO - 2022-10-24 09:26:58 --> Router Class Initialized
INFO - 2022-10-24 09:26:58 --> Output Class Initialized
INFO - 2022-10-24 09:26:58 --> Security Class Initialized
DEBUG - 2022-10-24 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:26:58 --> Input Class Initialized
INFO - 2022-10-24 09:26:58 --> Language Class Initialized
INFO - 2022-10-24 09:26:58 --> Language Class Initialized
INFO - 2022-10-24 09:26:58 --> Config Class Initialized
INFO - 2022-10-24 09:26:58 --> Loader Class Initialized
INFO - 2022-10-24 09:26:58 --> Helper loaded: url_helper
INFO - 2022-10-24 09:26:58 --> Helper loaded: file_helper
INFO - 2022-10-24 09:26:58 --> Helper loaded: form_helper
INFO - 2022-10-24 09:26:58 --> Helper loaded: my_helper
INFO - 2022-10-24 09:26:58 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:26:58 --> Controller Class Initialized
DEBUG - 2022-10-24 09:26:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-10-24 09:26:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-24 09:26:58 --> Final output sent to browser
DEBUG - 2022-10-24 09:26:58 --> Total execution time: 0.0844
INFO - 2022-10-24 09:26:58 --> Config Class Initialized
INFO - 2022-10-24 09:26:58 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:26:58 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:26:58 --> Utf8 Class Initialized
INFO - 2022-10-24 09:26:58 --> URI Class Initialized
INFO - 2022-10-24 09:26:58 --> Router Class Initialized
INFO - 2022-10-24 09:26:58 --> Output Class Initialized
INFO - 2022-10-24 09:26:58 --> Security Class Initialized
DEBUG - 2022-10-24 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:26:58 --> Input Class Initialized
INFO - 2022-10-24 09:26:58 --> Language Class Initialized
INFO - 2022-10-24 09:26:58 --> Language Class Initialized
INFO - 2022-10-24 09:26:58 --> Config Class Initialized
INFO - 2022-10-24 09:26:58 --> Loader Class Initialized
INFO - 2022-10-24 09:26:58 --> Helper loaded: url_helper
INFO - 2022-10-24 09:26:58 --> Helper loaded: file_helper
INFO - 2022-10-24 09:26:58 --> Helper loaded: form_helper
INFO - 2022-10-24 09:26:58 --> Helper loaded: my_helper
INFO - 2022-10-24 09:26:58 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:26:58 --> Controller Class Initialized
INFO - 2022-10-24 09:26:59 --> Config Class Initialized
INFO - 2022-10-24 09:26:59 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:26:59 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:26:59 --> Utf8 Class Initialized
INFO - 2022-10-24 09:26:59 --> URI Class Initialized
INFO - 2022-10-24 09:26:59 --> Router Class Initialized
INFO - 2022-10-24 09:26:59 --> Output Class Initialized
INFO - 2022-10-24 09:26:59 --> Security Class Initialized
DEBUG - 2022-10-24 09:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:26:59 --> Input Class Initialized
INFO - 2022-10-24 09:26:59 --> Language Class Initialized
INFO - 2022-10-24 09:26:59 --> Language Class Initialized
INFO - 2022-10-24 09:26:59 --> Config Class Initialized
INFO - 2022-10-24 09:26:59 --> Loader Class Initialized
INFO - 2022-10-24 09:26:59 --> Helper loaded: url_helper
INFO - 2022-10-24 09:26:59 --> Helper loaded: file_helper
INFO - 2022-10-24 09:26:59 --> Helper loaded: form_helper
INFO - 2022-10-24 09:26:59 --> Helper loaded: my_helper
INFO - 2022-10-24 09:26:59 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:26:59 --> Controller Class Initialized
DEBUG - 2022-10-24 09:26:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-10-24 09:26:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-24 09:26:59 --> Final output sent to browser
DEBUG - 2022-10-24 09:26:59 --> Total execution time: 0.0452
INFO - 2022-10-24 09:26:59 --> Config Class Initialized
INFO - 2022-10-24 09:26:59 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:26:59 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:26:59 --> Utf8 Class Initialized
INFO - 2022-10-24 09:26:59 --> URI Class Initialized
INFO - 2022-10-24 09:26:59 --> Router Class Initialized
INFO - 2022-10-24 09:26:59 --> Output Class Initialized
INFO - 2022-10-24 09:26:59 --> Security Class Initialized
DEBUG - 2022-10-24 09:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:26:59 --> Input Class Initialized
INFO - 2022-10-24 09:26:59 --> Language Class Initialized
INFO - 2022-10-24 09:26:59 --> Language Class Initialized
INFO - 2022-10-24 09:26:59 --> Config Class Initialized
INFO - 2022-10-24 09:26:59 --> Loader Class Initialized
INFO - 2022-10-24 09:26:59 --> Helper loaded: url_helper
INFO - 2022-10-24 09:26:59 --> Helper loaded: file_helper
INFO - 2022-10-24 09:26:59 --> Helper loaded: form_helper
INFO - 2022-10-24 09:26:59 --> Helper loaded: my_helper
INFO - 2022-10-24 09:26:59 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:26:59 --> Controller Class Initialized
INFO - 2022-10-24 09:27:00 --> Config Class Initialized
INFO - 2022-10-24 09:27:00 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:27:00 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:27:00 --> Utf8 Class Initialized
INFO - 2022-10-24 09:27:00 --> URI Class Initialized
INFO - 2022-10-24 09:27:00 --> Router Class Initialized
INFO - 2022-10-24 09:27:00 --> Output Class Initialized
INFO - 2022-10-24 09:27:00 --> Security Class Initialized
DEBUG - 2022-10-24 09:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:27:00 --> Input Class Initialized
INFO - 2022-10-24 09:27:00 --> Language Class Initialized
INFO - 2022-10-24 09:27:00 --> Language Class Initialized
INFO - 2022-10-24 09:27:00 --> Config Class Initialized
INFO - 2022-10-24 09:27:00 --> Loader Class Initialized
INFO - 2022-10-24 09:27:00 --> Helper loaded: url_helper
INFO - 2022-10-24 09:27:00 --> Helper loaded: file_helper
INFO - 2022-10-24 09:27:00 --> Helper loaded: form_helper
INFO - 2022-10-24 09:27:00 --> Helper loaded: my_helper
INFO - 2022-10-24 09:27:00 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:27:00 --> Controller Class Initialized
INFO - 2022-10-24 09:27:00 --> Final output sent to browser
DEBUG - 2022-10-24 09:27:00 --> Total execution time: 0.2412
INFO - 2022-10-24 09:27:00 --> Config Class Initialized
INFO - 2022-10-24 09:27:00 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:27:00 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:27:00 --> Utf8 Class Initialized
INFO - 2022-10-24 09:27:00 --> URI Class Initialized
INFO - 2022-10-24 09:27:00 --> Router Class Initialized
INFO - 2022-10-24 09:27:00 --> Output Class Initialized
INFO - 2022-10-24 09:27:00 --> Security Class Initialized
DEBUG - 2022-10-24 09:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:27:00 --> Input Class Initialized
INFO - 2022-10-24 09:27:00 --> Language Class Initialized
INFO - 2022-10-24 09:27:00 --> Language Class Initialized
INFO - 2022-10-24 09:27:00 --> Config Class Initialized
INFO - 2022-10-24 09:27:00 --> Loader Class Initialized
INFO - 2022-10-24 09:27:00 --> Helper loaded: url_helper
INFO - 2022-10-24 09:27:00 --> Helper loaded: file_helper
INFO - 2022-10-24 09:27:00 --> Helper loaded: form_helper
INFO - 2022-10-24 09:27:00 --> Helper loaded: my_helper
INFO - 2022-10-24 09:27:00 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:27:00 --> Controller Class Initialized
INFO - 2022-10-24 09:27:02 --> Config Class Initialized
INFO - 2022-10-24 09:27:02 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:27:02 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:27:02 --> Utf8 Class Initialized
INFO - 2022-10-24 09:27:02 --> URI Class Initialized
INFO - 2022-10-24 09:27:02 --> Router Class Initialized
INFO - 2022-10-24 09:27:02 --> Output Class Initialized
INFO - 2022-10-24 09:27:02 --> Security Class Initialized
DEBUG - 2022-10-24 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:27:02 --> Input Class Initialized
INFO - 2022-10-24 09:27:02 --> Language Class Initialized
INFO - 2022-10-24 09:27:02 --> Language Class Initialized
INFO - 2022-10-24 09:27:02 --> Config Class Initialized
INFO - 2022-10-24 09:27:02 --> Loader Class Initialized
INFO - 2022-10-24 09:27:02 --> Helper loaded: url_helper
INFO - 2022-10-24 09:27:02 --> Helper loaded: file_helper
INFO - 2022-10-24 09:27:02 --> Helper loaded: form_helper
INFO - 2022-10-24 09:27:02 --> Helper loaded: my_helper
INFO - 2022-10-24 09:27:02 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:27:02 --> Controller Class Initialized
INFO - 2022-10-24 09:27:02 --> Helper loaded: cookie_helper
INFO - 2022-10-24 09:27:02 --> Config Class Initialized
INFO - 2022-10-24 09:27:02 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:27:02 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:27:02 --> Utf8 Class Initialized
INFO - 2022-10-24 09:27:02 --> URI Class Initialized
INFO - 2022-10-24 09:27:02 --> Router Class Initialized
INFO - 2022-10-24 09:27:02 --> Output Class Initialized
INFO - 2022-10-24 09:27:02 --> Security Class Initialized
DEBUG - 2022-10-24 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:27:02 --> Input Class Initialized
INFO - 2022-10-24 09:27:02 --> Language Class Initialized
INFO - 2022-10-24 09:27:02 --> Language Class Initialized
INFO - 2022-10-24 09:27:02 --> Config Class Initialized
INFO - 2022-10-24 09:27:02 --> Loader Class Initialized
INFO - 2022-10-24 09:27:02 --> Helper loaded: url_helper
INFO - 2022-10-24 09:27:02 --> Helper loaded: file_helper
INFO - 2022-10-24 09:27:02 --> Helper loaded: form_helper
INFO - 2022-10-24 09:27:02 --> Helper loaded: my_helper
INFO - 2022-10-24 09:27:02 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:27:02 --> Controller Class Initialized
DEBUG - 2022-10-24 09:27:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-10-24 09:27:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-24 09:27:02 --> Final output sent to browser
DEBUG - 2022-10-24 09:27:02 --> Total execution time: 0.0435
INFO - 2022-10-24 09:27:13 --> Config Class Initialized
INFO - 2022-10-24 09:27:13 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:27:13 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:27:13 --> Utf8 Class Initialized
INFO - 2022-10-24 09:27:13 --> URI Class Initialized
INFO - 2022-10-24 09:27:13 --> Router Class Initialized
INFO - 2022-10-24 09:27:13 --> Output Class Initialized
INFO - 2022-10-24 09:27:13 --> Security Class Initialized
DEBUG - 2022-10-24 09:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:27:13 --> Input Class Initialized
INFO - 2022-10-24 09:27:13 --> Language Class Initialized
INFO - 2022-10-24 09:27:13 --> Language Class Initialized
INFO - 2022-10-24 09:27:13 --> Config Class Initialized
INFO - 2022-10-24 09:27:13 --> Loader Class Initialized
INFO - 2022-10-24 09:27:13 --> Helper loaded: url_helper
INFO - 2022-10-24 09:27:13 --> Helper loaded: file_helper
INFO - 2022-10-24 09:27:13 --> Helper loaded: form_helper
INFO - 2022-10-24 09:27:13 --> Helper loaded: my_helper
INFO - 2022-10-24 09:27:13 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:27:13 --> Controller Class Initialized
INFO - 2022-10-24 09:27:13 --> Helper loaded: cookie_helper
INFO - 2022-10-24 09:27:13 --> Final output sent to browser
DEBUG - 2022-10-24 09:27:13 --> Total execution time: 0.0610
INFO - 2022-10-24 09:27:13 --> Config Class Initialized
INFO - 2022-10-24 09:27:13 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:27:13 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:27:13 --> Utf8 Class Initialized
INFO - 2022-10-24 09:27:13 --> URI Class Initialized
INFO - 2022-10-24 09:27:13 --> Router Class Initialized
INFO - 2022-10-24 09:27:13 --> Output Class Initialized
INFO - 2022-10-24 09:27:13 --> Security Class Initialized
DEBUG - 2022-10-24 09:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:27:13 --> Input Class Initialized
INFO - 2022-10-24 09:27:13 --> Language Class Initialized
INFO - 2022-10-24 09:27:13 --> Language Class Initialized
INFO - 2022-10-24 09:27:13 --> Config Class Initialized
INFO - 2022-10-24 09:27:13 --> Loader Class Initialized
INFO - 2022-10-24 09:27:13 --> Helper loaded: url_helper
INFO - 2022-10-24 09:27:13 --> Helper loaded: file_helper
INFO - 2022-10-24 09:27:13 --> Helper loaded: form_helper
INFO - 2022-10-24 09:27:13 --> Helper loaded: my_helper
INFO - 2022-10-24 09:27:13 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:27:13 --> Controller Class Initialized
DEBUG - 2022-10-24 09:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-10-24 09:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-24 09:27:13 --> Final output sent to browser
DEBUG - 2022-10-24 09:27:13 --> Total execution time: 0.0806
INFO - 2022-10-24 09:27:15 --> Config Class Initialized
INFO - 2022-10-24 09:27:15 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:27:15 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:27:15 --> Utf8 Class Initialized
INFO - 2022-10-24 09:27:15 --> URI Class Initialized
INFO - 2022-10-24 09:27:15 --> Router Class Initialized
INFO - 2022-10-24 09:27:15 --> Output Class Initialized
INFO - 2022-10-24 09:27:15 --> Security Class Initialized
DEBUG - 2022-10-24 09:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:27:15 --> Input Class Initialized
INFO - 2022-10-24 09:27:15 --> Language Class Initialized
INFO - 2022-10-24 09:27:15 --> Language Class Initialized
INFO - 2022-10-24 09:27:15 --> Config Class Initialized
INFO - 2022-10-24 09:27:15 --> Loader Class Initialized
INFO - 2022-10-24 09:27:15 --> Helper loaded: url_helper
INFO - 2022-10-24 09:27:15 --> Helper loaded: file_helper
INFO - 2022-10-24 09:27:15 --> Helper loaded: form_helper
INFO - 2022-10-24 09:27:15 --> Helper loaded: my_helper
INFO - 2022-10-24 09:27:15 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:27:15 --> Controller Class Initialized
DEBUG - 2022-10-24 09:27:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-10-24 09:27:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-10-24 09:27:15 --> Final output sent to browser
DEBUG - 2022-10-24 09:27:15 --> Total execution time: 0.0794
INFO - 2022-10-24 09:27:16 --> Config Class Initialized
INFO - 2022-10-24 09:27:16 --> Hooks Class Initialized
DEBUG - 2022-10-24 09:27:16 --> UTF-8 Support Enabled
INFO - 2022-10-24 09:27:16 --> Utf8 Class Initialized
INFO - 2022-10-24 09:27:16 --> URI Class Initialized
INFO - 2022-10-24 09:27:16 --> Router Class Initialized
INFO - 2022-10-24 09:27:16 --> Output Class Initialized
INFO - 2022-10-24 09:27:16 --> Security Class Initialized
DEBUG - 2022-10-24 09:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-10-24 09:27:16 --> Input Class Initialized
INFO - 2022-10-24 09:27:16 --> Language Class Initialized
INFO - 2022-10-24 09:27:16 --> Language Class Initialized
INFO - 2022-10-24 09:27:16 --> Config Class Initialized
INFO - 2022-10-24 09:27:16 --> Loader Class Initialized
INFO - 2022-10-24 09:27:16 --> Helper loaded: url_helper
INFO - 2022-10-24 09:27:16 --> Helper loaded: file_helper
INFO - 2022-10-24 09:27:16 --> Helper loaded: form_helper
INFO - 2022-10-24 09:27:16 --> Helper loaded: my_helper
INFO - 2022-10-24 09:27:16 --> Database Driver Class Initialized
DEBUG - 2022-10-24 09:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-10-24 09:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-10-24 09:27:16 --> Controller Class Initialized
DEBUG - 2022-10-24 09:27:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2022-10-24 09:27:16 --> Final output sent to browser
DEBUG - 2022-10-24 09:27:16 --> Total execution time: 0.0984
