<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-03 03:20:38 --> Config Class Initialized
INFO - 2022-06-03 03:20:38 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:20:38 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:20:38 --> Utf8 Class Initialized
INFO - 2022-06-03 03:20:38 --> URI Class Initialized
DEBUG - 2022-06-03 03:20:38 --> No URI present. Default controller set.
INFO - 2022-06-03 03:20:38 --> Router Class Initialized
INFO - 2022-06-03 03:20:38 --> Output Class Initialized
INFO - 2022-06-03 03:20:38 --> Security Class Initialized
DEBUG - 2022-06-03 03:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:20:38 --> Input Class Initialized
INFO - 2022-06-03 03:20:38 --> Language Class Initialized
INFO - 2022-06-03 03:20:38 --> Language Class Initialized
INFO - 2022-06-03 03:20:38 --> Config Class Initialized
INFO - 2022-06-03 03:20:38 --> Loader Class Initialized
INFO - 2022-06-03 03:20:38 --> Helper loaded: url_helper
INFO - 2022-06-03 03:20:38 --> Helper loaded: file_helper
INFO - 2022-06-03 03:20:38 --> Helper loaded: form_helper
INFO - 2022-06-03 03:20:38 --> Helper loaded: my_helper
INFO - 2022-06-03 03:20:38 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:20:38 --> Controller Class Initialized
INFO - 2022-06-03 03:20:38 --> Config Class Initialized
INFO - 2022-06-03 03:20:38 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:20:38 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:20:38 --> Utf8 Class Initialized
INFO - 2022-06-03 03:20:38 --> URI Class Initialized
INFO - 2022-06-03 03:20:38 --> Router Class Initialized
INFO - 2022-06-03 03:20:38 --> Output Class Initialized
INFO - 2022-06-03 03:20:38 --> Security Class Initialized
DEBUG - 2022-06-03 03:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:20:38 --> Input Class Initialized
INFO - 2022-06-03 03:20:38 --> Language Class Initialized
INFO - 2022-06-03 03:20:38 --> Language Class Initialized
INFO - 2022-06-03 03:20:38 --> Config Class Initialized
INFO - 2022-06-03 03:20:38 --> Loader Class Initialized
INFO - 2022-06-03 03:20:38 --> Helper loaded: url_helper
INFO - 2022-06-03 03:20:38 --> Helper loaded: file_helper
INFO - 2022-06-03 03:20:38 --> Helper loaded: form_helper
INFO - 2022-06-03 03:20:38 --> Helper loaded: my_helper
INFO - 2022-06-03 03:20:38 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:20:38 --> Controller Class Initialized
DEBUG - 2022-06-03 03:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-03 03:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-03 03:20:38 --> Final output sent to browser
DEBUG - 2022-06-03 03:20:38 --> Total execution time: 0.0888
INFO - 2022-06-03 03:20:44 --> Config Class Initialized
INFO - 2022-06-03 03:20:44 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:20:44 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:20:44 --> Utf8 Class Initialized
INFO - 2022-06-03 03:20:44 --> URI Class Initialized
INFO - 2022-06-03 03:20:44 --> Router Class Initialized
INFO - 2022-06-03 03:20:44 --> Output Class Initialized
INFO - 2022-06-03 03:20:44 --> Security Class Initialized
DEBUG - 2022-06-03 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:20:44 --> Input Class Initialized
INFO - 2022-06-03 03:20:44 --> Language Class Initialized
INFO - 2022-06-03 03:20:44 --> Language Class Initialized
INFO - 2022-06-03 03:20:44 --> Config Class Initialized
INFO - 2022-06-03 03:20:44 --> Loader Class Initialized
INFO - 2022-06-03 03:20:44 --> Helper loaded: url_helper
INFO - 2022-06-03 03:20:44 --> Helper loaded: file_helper
INFO - 2022-06-03 03:20:44 --> Helper loaded: form_helper
INFO - 2022-06-03 03:20:44 --> Helper loaded: my_helper
INFO - 2022-06-03 03:20:44 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:20:44 --> Controller Class Initialized
INFO - 2022-06-03 03:20:44 --> Helper loaded: cookie_helper
INFO - 2022-06-03 03:20:44 --> Final output sent to browser
DEBUG - 2022-06-03 03:20:44 --> Total execution time: 0.0829
INFO - 2022-06-03 03:20:44 --> Config Class Initialized
INFO - 2022-06-03 03:20:44 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:20:44 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:20:44 --> Utf8 Class Initialized
INFO - 2022-06-03 03:20:45 --> URI Class Initialized
INFO - 2022-06-03 03:20:45 --> Router Class Initialized
INFO - 2022-06-03 03:20:45 --> Output Class Initialized
INFO - 2022-06-03 03:20:45 --> Security Class Initialized
DEBUG - 2022-06-03 03:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:20:45 --> Input Class Initialized
INFO - 2022-06-03 03:20:45 --> Language Class Initialized
INFO - 2022-06-03 03:20:45 --> Language Class Initialized
INFO - 2022-06-03 03:20:45 --> Config Class Initialized
INFO - 2022-06-03 03:20:45 --> Loader Class Initialized
INFO - 2022-06-03 03:20:45 --> Helper loaded: url_helper
INFO - 2022-06-03 03:20:45 --> Helper loaded: file_helper
INFO - 2022-06-03 03:20:45 --> Helper loaded: form_helper
INFO - 2022-06-03 03:20:45 --> Helper loaded: my_helper
INFO - 2022-06-03 03:20:45 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:20:45 --> Controller Class Initialized
DEBUG - 2022-06-03 03:20:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-03 03:20:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-03 03:20:45 --> Final output sent to browser
DEBUG - 2022-06-03 03:20:45 --> Total execution time: 0.0861
INFO - 2022-06-03 03:20:49 --> Config Class Initialized
INFO - 2022-06-03 03:20:49 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:20:49 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:20:49 --> Utf8 Class Initialized
INFO - 2022-06-03 03:20:49 --> URI Class Initialized
INFO - 2022-06-03 03:20:49 --> Router Class Initialized
INFO - 2022-06-03 03:20:49 --> Output Class Initialized
INFO - 2022-06-03 03:20:49 --> Security Class Initialized
DEBUG - 2022-06-03 03:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:20:49 --> Input Class Initialized
INFO - 2022-06-03 03:20:49 --> Language Class Initialized
INFO - 2022-06-03 03:20:49 --> Language Class Initialized
INFO - 2022-06-03 03:20:49 --> Config Class Initialized
INFO - 2022-06-03 03:20:49 --> Loader Class Initialized
INFO - 2022-06-03 03:20:49 --> Helper loaded: url_helper
INFO - 2022-06-03 03:20:49 --> Helper loaded: file_helper
INFO - 2022-06-03 03:20:49 --> Helper loaded: form_helper
INFO - 2022-06-03 03:20:49 --> Helper loaded: my_helper
INFO - 2022-06-03 03:20:49 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:20:49 --> Controller Class Initialized
DEBUG - 2022-06-03 03:20:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-03 03:20:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-03 03:20:49 --> Final output sent to browser
DEBUG - 2022-06-03 03:20:49 --> Total execution time: 0.0836
INFO - 2022-06-03 03:21:06 --> Config Class Initialized
INFO - 2022-06-03 03:21:06 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:21:06 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:21:06 --> Utf8 Class Initialized
INFO - 2022-06-03 03:21:06 --> URI Class Initialized
INFO - 2022-06-03 03:21:07 --> Router Class Initialized
INFO - 2022-06-03 03:21:07 --> Output Class Initialized
INFO - 2022-06-03 03:21:07 --> Security Class Initialized
DEBUG - 2022-06-03 03:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:21:07 --> Input Class Initialized
INFO - 2022-06-03 03:21:07 --> Language Class Initialized
INFO - 2022-06-03 03:21:07 --> Language Class Initialized
INFO - 2022-06-03 03:21:07 --> Config Class Initialized
INFO - 2022-06-03 03:21:07 --> Loader Class Initialized
INFO - 2022-06-03 03:21:07 --> Helper loaded: url_helper
INFO - 2022-06-03 03:21:07 --> Helper loaded: file_helper
INFO - 2022-06-03 03:21:07 --> Helper loaded: form_helper
INFO - 2022-06-03 03:21:07 --> Helper loaded: my_helper
INFO - 2022-06-03 03:21:07 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:21:07 --> Controller Class Initialized
DEBUG - 2022-06-03 03:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-03 03:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-03 03:21:07 --> Final output sent to browser
DEBUG - 2022-06-03 03:21:07 --> Total execution time: 0.0812
INFO - 2022-06-03 03:21:08 --> Config Class Initialized
INFO - 2022-06-03 03:21:08 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:21:08 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:21:08 --> Utf8 Class Initialized
INFO - 2022-06-03 03:21:08 --> URI Class Initialized
INFO - 2022-06-03 03:21:08 --> Router Class Initialized
INFO - 2022-06-03 03:21:08 --> Output Class Initialized
INFO - 2022-06-03 03:21:08 --> Security Class Initialized
DEBUG - 2022-06-03 03:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:21:08 --> Input Class Initialized
INFO - 2022-06-03 03:21:08 --> Language Class Initialized
INFO - 2022-06-03 03:21:08 --> Language Class Initialized
INFO - 2022-06-03 03:21:08 --> Config Class Initialized
INFO - 2022-06-03 03:21:08 --> Loader Class Initialized
INFO - 2022-06-03 03:21:08 --> Helper loaded: url_helper
INFO - 2022-06-03 03:21:08 --> Helper loaded: file_helper
INFO - 2022-06-03 03:21:08 --> Helper loaded: form_helper
INFO - 2022-06-03 03:21:08 --> Helper loaded: my_helper
INFO - 2022-06-03 03:21:09 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:21:09 --> Controller Class Initialized
ERROR - 2022-06-03 03:21:09 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: SELECT 
                                    		ekstra, nilai, ekstra2, nilai2
                                    		FROM t_nilai_ekstra
                                    		WHERE id_siswa = 1 AND tasm = '20212'
INFO - 2022-06-03 03:21:09 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-03 03:21:11 --> Config Class Initialized
INFO - 2022-06-03 03:21:11 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:21:11 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:21:11 --> Utf8 Class Initialized
INFO - 2022-06-03 03:21:11 --> URI Class Initialized
INFO - 2022-06-03 03:21:11 --> Router Class Initialized
INFO - 2022-06-03 03:21:11 --> Output Class Initialized
INFO - 2022-06-03 03:21:11 --> Security Class Initialized
DEBUG - 2022-06-03 03:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:21:11 --> Input Class Initialized
INFO - 2022-06-03 03:21:11 --> Language Class Initialized
INFO - 2022-06-03 03:21:11 --> Language Class Initialized
INFO - 2022-06-03 03:21:11 --> Config Class Initialized
INFO - 2022-06-03 03:21:11 --> Loader Class Initialized
INFO - 2022-06-03 03:21:11 --> Helper loaded: url_helper
INFO - 2022-06-03 03:21:11 --> Helper loaded: file_helper
INFO - 2022-06-03 03:21:11 --> Helper loaded: form_helper
INFO - 2022-06-03 03:21:11 --> Helper loaded: my_helper
INFO - 2022-06-03 03:21:11 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:21:11 --> Controller Class Initialized
ERROR - 2022-06-03 03:21:11 --> Query error: Unknown column 'a.desk' in 'field list' - Invalid query: SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = 1 AND a.nilai != '0' AND a.tasm = '20212'
INFO - 2022-06-03 03:21:11 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-03 03:22:21 --> Config Class Initialized
INFO - 2022-06-03 03:22:21 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:22:21 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:22:21 --> Utf8 Class Initialized
INFO - 2022-06-03 03:22:21 --> URI Class Initialized
INFO - 2022-06-03 03:22:21 --> Router Class Initialized
INFO - 2022-06-03 03:22:21 --> Output Class Initialized
INFO - 2022-06-03 03:22:21 --> Security Class Initialized
DEBUG - 2022-06-03 03:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:22:21 --> Input Class Initialized
INFO - 2022-06-03 03:22:21 --> Language Class Initialized
INFO - 2022-06-03 03:22:21 --> Language Class Initialized
INFO - 2022-06-03 03:22:21 --> Config Class Initialized
INFO - 2022-06-03 03:22:21 --> Loader Class Initialized
INFO - 2022-06-03 03:22:21 --> Helper loaded: url_helper
INFO - 2022-06-03 03:22:21 --> Helper loaded: file_helper
INFO - 2022-06-03 03:22:21 --> Helper loaded: form_helper
INFO - 2022-06-03 03:22:21 --> Helper loaded: my_helper
INFO - 2022-06-03 03:22:21 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:22:21 --> Controller Class Initialized
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:22:21 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:22:21 --> Final output sent to browser
DEBUG - 2022-06-03 03:22:21 --> Total execution time: 0.1371
INFO - 2022-06-03 03:31:35 --> Config Class Initialized
INFO - 2022-06-03 03:31:35 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:31:35 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:31:35 --> Utf8 Class Initialized
INFO - 2022-06-03 03:31:35 --> URI Class Initialized
INFO - 2022-06-03 03:31:35 --> Router Class Initialized
INFO - 2022-06-03 03:31:35 --> Output Class Initialized
INFO - 2022-06-03 03:31:35 --> Security Class Initialized
DEBUG - 2022-06-03 03:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:31:35 --> Input Class Initialized
INFO - 2022-06-03 03:31:35 --> Language Class Initialized
INFO - 2022-06-03 03:31:35 --> Language Class Initialized
INFO - 2022-06-03 03:31:35 --> Config Class Initialized
INFO - 2022-06-03 03:31:35 --> Loader Class Initialized
INFO - 2022-06-03 03:31:35 --> Helper loaded: url_helper
INFO - 2022-06-03 03:31:35 --> Helper loaded: file_helper
INFO - 2022-06-03 03:31:35 --> Helper loaded: form_helper
INFO - 2022-06-03 03:31:35 --> Helper loaded: my_helper
INFO - 2022-06-03 03:31:35 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:31:35 --> Controller Class Initialized
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:31:35 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:31:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:31:35 --> Final output sent to browser
DEBUG - 2022-06-03 03:31:35 --> Total execution time: 0.0878
INFO - 2022-06-03 03:31:36 --> Config Class Initialized
INFO - 2022-06-03 03:31:36 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:31:36 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:31:36 --> Utf8 Class Initialized
INFO - 2022-06-03 03:31:36 --> URI Class Initialized
INFO - 2022-06-03 03:31:36 --> Router Class Initialized
INFO - 2022-06-03 03:31:36 --> Output Class Initialized
INFO - 2022-06-03 03:31:36 --> Security Class Initialized
DEBUG - 2022-06-03 03:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:31:36 --> Input Class Initialized
INFO - 2022-06-03 03:31:36 --> Language Class Initialized
INFO - 2022-06-03 03:31:36 --> Language Class Initialized
INFO - 2022-06-03 03:31:36 --> Config Class Initialized
INFO - 2022-06-03 03:31:36 --> Loader Class Initialized
INFO - 2022-06-03 03:31:36 --> Helper loaded: url_helper
INFO - 2022-06-03 03:31:36 --> Helper loaded: file_helper
INFO - 2022-06-03 03:31:36 --> Helper loaded: form_helper
INFO - 2022-06-03 03:31:36 --> Helper loaded: my_helper
INFO - 2022-06-03 03:31:36 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:31:36 --> Controller Class Initialized
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:31:36 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:31:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:31:36 --> Final output sent to browser
DEBUG - 2022-06-03 03:31:36 --> Total execution time: 0.1030
INFO - 2022-06-03 03:31:49 --> Config Class Initialized
INFO - 2022-06-03 03:31:49 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:31:49 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:31:49 --> Utf8 Class Initialized
INFO - 2022-06-03 03:31:49 --> URI Class Initialized
INFO - 2022-06-03 03:31:49 --> Router Class Initialized
INFO - 2022-06-03 03:31:49 --> Output Class Initialized
INFO - 2022-06-03 03:31:49 --> Security Class Initialized
DEBUG - 2022-06-03 03:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:31:49 --> Input Class Initialized
INFO - 2022-06-03 03:31:49 --> Language Class Initialized
INFO - 2022-06-03 03:31:49 --> Language Class Initialized
INFO - 2022-06-03 03:31:49 --> Config Class Initialized
INFO - 2022-06-03 03:31:49 --> Loader Class Initialized
INFO - 2022-06-03 03:31:49 --> Helper loaded: url_helper
INFO - 2022-06-03 03:31:49 --> Helper loaded: file_helper
INFO - 2022-06-03 03:31:49 --> Helper loaded: form_helper
INFO - 2022-06-03 03:31:49 --> Helper loaded: my_helper
INFO - 2022-06-03 03:31:49 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:31:49 --> Controller Class Initialized
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:31:49 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:31:49 --> Final output sent to browser
DEBUG - 2022-06-03 03:31:49 --> Total execution time: 0.0925
INFO - 2022-06-03 03:34:42 --> Config Class Initialized
INFO - 2022-06-03 03:34:42 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:34:42 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:34:42 --> Utf8 Class Initialized
INFO - 2022-06-03 03:34:42 --> URI Class Initialized
INFO - 2022-06-03 03:34:42 --> Router Class Initialized
INFO - 2022-06-03 03:34:42 --> Output Class Initialized
INFO - 2022-06-03 03:34:42 --> Security Class Initialized
DEBUG - 2022-06-03 03:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:34:42 --> Input Class Initialized
INFO - 2022-06-03 03:34:42 --> Language Class Initialized
INFO - 2022-06-03 03:34:42 --> Language Class Initialized
INFO - 2022-06-03 03:34:42 --> Config Class Initialized
INFO - 2022-06-03 03:34:42 --> Loader Class Initialized
INFO - 2022-06-03 03:34:42 --> Helper loaded: url_helper
INFO - 2022-06-03 03:34:42 --> Helper loaded: file_helper
INFO - 2022-06-03 03:34:42 --> Helper loaded: form_helper
INFO - 2022-06-03 03:34:42 --> Helper loaded: my_helper
INFO - 2022-06-03 03:34:42 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:34:42 --> Controller Class Initialized
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:34:42 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:34:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:34:42 --> Final output sent to browser
DEBUG - 2022-06-03 03:34:42 --> Total execution time: 0.0927
INFO - 2022-06-03 03:35:30 --> Config Class Initialized
INFO - 2022-06-03 03:35:30 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:35:30 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:35:30 --> Utf8 Class Initialized
INFO - 2022-06-03 03:35:30 --> URI Class Initialized
INFO - 2022-06-03 03:35:30 --> Router Class Initialized
INFO - 2022-06-03 03:35:30 --> Output Class Initialized
INFO - 2022-06-03 03:35:30 --> Security Class Initialized
DEBUG - 2022-06-03 03:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:35:30 --> Input Class Initialized
INFO - 2022-06-03 03:35:30 --> Language Class Initialized
INFO - 2022-06-03 03:35:30 --> Language Class Initialized
INFO - 2022-06-03 03:35:30 --> Config Class Initialized
INFO - 2022-06-03 03:35:30 --> Loader Class Initialized
INFO - 2022-06-03 03:35:30 --> Helper loaded: url_helper
INFO - 2022-06-03 03:35:30 --> Helper loaded: file_helper
INFO - 2022-06-03 03:35:30 --> Helper loaded: form_helper
INFO - 2022-06-03 03:35:30 --> Helper loaded: my_helper
INFO - 2022-06-03 03:35:30 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:35:31 --> Controller Class Initialized
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:35:31 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:35:31 --> Final output sent to browser
DEBUG - 2022-06-03 03:35:31 --> Total execution time: 0.0956
INFO - 2022-06-03 03:37:30 --> Config Class Initialized
INFO - 2022-06-03 03:37:30 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:37:30 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:37:30 --> Utf8 Class Initialized
INFO - 2022-06-03 03:37:30 --> URI Class Initialized
INFO - 2022-06-03 03:37:30 --> Router Class Initialized
INFO - 2022-06-03 03:37:30 --> Output Class Initialized
INFO - 2022-06-03 03:37:30 --> Security Class Initialized
DEBUG - 2022-06-03 03:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:37:30 --> Input Class Initialized
INFO - 2022-06-03 03:37:30 --> Language Class Initialized
INFO - 2022-06-03 03:37:30 --> Language Class Initialized
INFO - 2022-06-03 03:37:30 --> Config Class Initialized
INFO - 2022-06-03 03:37:30 --> Loader Class Initialized
INFO - 2022-06-03 03:37:30 --> Helper loaded: url_helper
INFO - 2022-06-03 03:37:30 --> Helper loaded: file_helper
INFO - 2022-06-03 03:37:30 --> Helper loaded: form_helper
INFO - 2022-06-03 03:37:30 --> Helper loaded: my_helper
INFO - 2022-06-03 03:37:30 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:37:30 --> Controller Class Initialized
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:37:30 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:37:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:37:30 --> Final output sent to browser
DEBUG - 2022-06-03 03:37:30 --> Total execution time: 0.0923
INFO - 2022-06-03 03:41:25 --> Config Class Initialized
INFO - 2022-06-03 03:41:25 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:41:25 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:41:25 --> Utf8 Class Initialized
INFO - 2022-06-03 03:41:25 --> URI Class Initialized
INFO - 2022-06-03 03:41:25 --> Router Class Initialized
INFO - 2022-06-03 03:41:25 --> Output Class Initialized
INFO - 2022-06-03 03:41:25 --> Security Class Initialized
DEBUG - 2022-06-03 03:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:41:25 --> Input Class Initialized
INFO - 2022-06-03 03:41:25 --> Language Class Initialized
INFO - 2022-06-03 03:41:25 --> Language Class Initialized
INFO - 2022-06-03 03:41:25 --> Config Class Initialized
INFO - 2022-06-03 03:41:25 --> Loader Class Initialized
INFO - 2022-06-03 03:41:25 --> Helper loaded: url_helper
INFO - 2022-06-03 03:41:25 --> Helper loaded: file_helper
INFO - 2022-06-03 03:41:25 --> Helper loaded: form_helper
INFO - 2022-06-03 03:41:25 --> Helper loaded: my_helper
INFO - 2022-06-03 03:41:25 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:41:25 --> Controller Class Initialized
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:41:25 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:41:25 --> Final output sent to browser
DEBUG - 2022-06-03 03:41:25 --> Total execution time: 0.0799
INFO - 2022-06-03 03:41:26 --> Config Class Initialized
INFO - 2022-06-03 03:41:26 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:41:26 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:41:26 --> Utf8 Class Initialized
INFO - 2022-06-03 03:41:26 --> URI Class Initialized
INFO - 2022-06-03 03:41:26 --> Router Class Initialized
INFO - 2022-06-03 03:41:26 --> Output Class Initialized
INFO - 2022-06-03 03:41:26 --> Security Class Initialized
DEBUG - 2022-06-03 03:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:41:26 --> Input Class Initialized
INFO - 2022-06-03 03:41:26 --> Language Class Initialized
INFO - 2022-06-03 03:41:26 --> Language Class Initialized
INFO - 2022-06-03 03:41:26 --> Config Class Initialized
INFO - 2022-06-03 03:41:26 --> Loader Class Initialized
INFO - 2022-06-03 03:41:26 --> Helper loaded: url_helper
INFO - 2022-06-03 03:41:26 --> Helper loaded: file_helper
INFO - 2022-06-03 03:41:26 --> Helper loaded: form_helper
INFO - 2022-06-03 03:41:26 --> Helper loaded: my_helper
INFO - 2022-06-03 03:41:26 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:41:26 --> Controller Class Initialized
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:41:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:41:26 --> Final output sent to browser
DEBUG - 2022-06-03 03:41:26 --> Total execution time: 0.0859
INFO - 2022-06-03 03:41:26 --> Config Class Initialized
INFO - 2022-06-03 03:41:26 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:41:26 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:41:26 --> Utf8 Class Initialized
INFO - 2022-06-03 03:41:26 --> URI Class Initialized
INFO - 2022-06-03 03:41:26 --> Router Class Initialized
INFO - 2022-06-03 03:41:26 --> Output Class Initialized
INFO - 2022-06-03 03:41:26 --> Security Class Initialized
DEBUG - 2022-06-03 03:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:41:26 --> Input Class Initialized
INFO - 2022-06-03 03:41:26 --> Language Class Initialized
INFO - 2022-06-03 03:41:26 --> Language Class Initialized
INFO - 2022-06-03 03:41:26 --> Config Class Initialized
INFO - 2022-06-03 03:41:26 --> Loader Class Initialized
INFO - 2022-06-03 03:41:26 --> Helper loaded: url_helper
INFO - 2022-06-03 03:41:26 --> Helper loaded: file_helper
INFO - 2022-06-03 03:41:26 --> Helper loaded: form_helper
INFO - 2022-06-03 03:41:26 --> Helper loaded: my_helper
INFO - 2022-06-03 03:41:26 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:41:26 --> Controller Class Initialized
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:41:26 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:41:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:41:26 --> Final output sent to browser
DEBUG - 2022-06-03 03:41:26 --> Total execution time: 0.0935
INFO - 2022-06-03 03:57:49 --> Config Class Initialized
INFO - 2022-06-03 03:57:49 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:57:49 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:57:49 --> Utf8 Class Initialized
INFO - 2022-06-03 03:57:49 --> URI Class Initialized
INFO - 2022-06-03 03:57:49 --> Router Class Initialized
INFO - 2022-06-03 03:57:49 --> Output Class Initialized
INFO - 2022-06-03 03:57:49 --> Security Class Initialized
DEBUG - 2022-06-03 03:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:57:49 --> Input Class Initialized
INFO - 2022-06-03 03:57:49 --> Language Class Initialized
INFO - 2022-06-03 03:57:49 --> Language Class Initialized
INFO - 2022-06-03 03:57:49 --> Config Class Initialized
INFO - 2022-06-03 03:57:49 --> Loader Class Initialized
INFO - 2022-06-03 03:57:49 --> Helper loaded: url_helper
INFO - 2022-06-03 03:57:49 --> Helper loaded: file_helper
INFO - 2022-06-03 03:57:49 --> Helper loaded: form_helper
INFO - 2022-06-03 03:57:49 --> Helper loaded: my_helper
INFO - 2022-06-03 03:57:50 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:57:50 --> Controller Class Initialized
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:57:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:57:50 --> Final output sent to browser
DEBUG - 2022-06-03 03:57:50 --> Total execution time: 0.0858
INFO - 2022-06-03 03:57:50 --> Config Class Initialized
INFO - 2022-06-03 03:57:50 --> Hooks Class Initialized
DEBUG - 2022-06-03 03:57:50 --> UTF-8 Support Enabled
INFO - 2022-06-03 03:57:50 --> Utf8 Class Initialized
INFO - 2022-06-03 03:57:50 --> URI Class Initialized
INFO - 2022-06-03 03:57:50 --> Router Class Initialized
INFO - 2022-06-03 03:57:50 --> Output Class Initialized
INFO - 2022-06-03 03:57:50 --> Security Class Initialized
DEBUG - 2022-06-03 03:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 03:57:50 --> Input Class Initialized
INFO - 2022-06-03 03:57:50 --> Language Class Initialized
INFO - 2022-06-03 03:57:50 --> Language Class Initialized
INFO - 2022-06-03 03:57:50 --> Config Class Initialized
INFO - 2022-06-03 03:57:50 --> Loader Class Initialized
INFO - 2022-06-03 03:57:50 --> Helper loaded: url_helper
INFO - 2022-06-03 03:57:50 --> Helper loaded: file_helper
INFO - 2022-06-03 03:57:50 --> Helper loaded: form_helper
INFO - 2022-06-03 03:57:50 --> Helper loaded: my_helper
INFO - 2022-06-03 03:57:50 --> Database Driver Class Initialized
DEBUG - 2022-06-03 03:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 03:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 03:57:50 --> Controller Class Initialized
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 158
ERROR - 2022-06-03 03:57:50 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 03:57:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 03:57:50 --> Final output sent to browser
DEBUG - 2022-06-03 03:57:50 --> Total execution time: 0.0869
INFO - 2022-06-03 04:00:30 --> Config Class Initialized
INFO - 2022-06-03 04:00:30 --> Hooks Class Initialized
DEBUG - 2022-06-03 04:00:30 --> UTF-8 Support Enabled
INFO - 2022-06-03 04:00:30 --> Utf8 Class Initialized
INFO - 2022-06-03 04:00:30 --> URI Class Initialized
INFO - 2022-06-03 04:00:30 --> Router Class Initialized
INFO - 2022-06-03 04:00:30 --> Output Class Initialized
INFO - 2022-06-03 04:00:30 --> Security Class Initialized
DEBUG - 2022-06-03 04:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 04:00:30 --> Input Class Initialized
INFO - 2022-06-03 04:00:30 --> Language Class Initialized
INFO - 2022-06-03 04:00:30 --> Language Class Initialized
INFO - 2022-06-03 04:00:30 --> Config Class Initialized
INFO - 2022-06-03 04:00:30 --> Loader Class Initialized
INFO - 2022-06-03 04:00:30 --> Helper loaded: url_helper
INFO - 2022-06-03 04:00:30 --> Helper loaded: file_helper
INFO - 2022-06-03 04:00:30 --> Helper loaded: form_helper
INFO - 2022-06-03 04:00:30 --> Helper loaded: my_helper
INFO - 2022-06-03 04:00:30 --> Database Driver Class Initialized
DEBUG - 2022-06-03 04:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 04:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 04:00:30 --> Controller Class Initialized
ERROR - 2022-06-03 04:00:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:00:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:00:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 04:00:30 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 04:00:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:00:30 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:00:30 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 04:00:30 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 04:00:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 04:00:30 --> Final output sent to browser
DEBUG - 2022-06-03 04:00:30 --> Total execution time: 0.0783
INFO - 2022-06-03 04:25:03 --> Config Class Initialized
INFO - 2022-06-03 04:25:03 --> Hooks Class Initialized
DEBUG - 2022-06-03 04:25:03 --> UTF-8 Support Enabled
INFO - 2022-06-03 04:25:03 --> Utf8 Class Initialized
INFO - 2022-06-03 04:25:03 --> URI Class Initialized
INFO - 2022-06-03 04:25:03 --> Router Class Initialized
INFO - 2022-06-03 04:25:03 --> Output Class Initialized
INFO - 2022-06-03 04:25:03 --> Security Class Initialized
DEBUG - 2022-06-03 04:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 04:25:03 --> Input Class Initialized
INFO - 2022-06-03 04:25:03 --> Language Class Initialized
INFO - 2022-06-03 04:25:03 --> Language Class Initialized
INFO - 2022-06-03 04:25:03 --> Config Class Initialized
INFO - 2022-06-03 04:25:03 --> Loader Class Initialized
INFO - 2022-06-03 04:25:03 --> Helper loaded: url_helper
INFO - 2022-06-03 04:25:03 --> Helper loaded: file_helper
INFO - 2022-06-03 04:25:03 --> Helper loaded: form_helper
INFO - 2022-06-03 04:25:03 --> Helper loaded: my_helper
INFO - 2022-06-03 04:25:03 --> Database Driver Class Initialized
DEBUG - 2022-06-03 04:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 04:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 04:25:03 --> Controller Class Initialized
ERROR - 2022-06-03 04:25:03 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:25:03 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:25:03 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 04:25:03 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 04:25:03 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:25:03 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:25:03 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 04:25:03 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 04:25:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 04:25:03 --> Final output sent to browser
DEBUG - 2022-06-03 04:25:03 --> Total execution time: 0.0988
INFO - 2022-06-03 04:46:35 --> Config Class Initialized
INFO - 2022-06-03 04:46:35 --> Hooks Class Initialized
DEBUG - 2022-06-03 04:46:35 --> UTF-8 Support Enabled
INFO - 2022-06-03 04:46:35 --> Utf8 Class Initialized
INFO - 2022-06-03 04:46:35 --> URI Class Initialized
INFO - 2022-06-03 04:46:35 --> Router Class Initialized
INFO - 2022-06-03 04:46:35 --> Output Class Initialized
INFO - 2022-06-03 04:46:35 --> Security Class Initialized
DEBUG - 2022-06-03 04:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 04:46:35 --> Input Class Initialized
INFO - 2022-06-03 04:46:35 --> Language Class Initialized
INFO - 2022-06-03 04:46:35 --> Language Class Initialized
INFO - 2022-06-03 04:46:35 --> Config Class Initialized
INFO - 2022-06-03 04:46:35 --> Loader Class Initialized
INFO - 2022-06-03 04:46:35 --> Helper loaded: url_helper
INFO - 2022-06-03 04:46:35 --> Helper loaded: file_helper
INFO - 2022-06-03 04:46:35 --> Helper loaded: form_helper
INFO - 2022-06-03 04:46:35 --> Helper loaded: my_helper
INFO - 2022-06-03 04:46:35 --> Database Driver Class Initialized
DEBUG - 2022-06-03 04:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 04:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 04:46:35 --> Controller Class Initialized
ERROR - 2022-06-03 04:46:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:46:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:46:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 04:46:35 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 04:46:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:46:35 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:46:35 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 04:46:35 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 04:46:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 04:46:35 --> Final output sent to browser
DEBUG - 2022-06-03 04:46:35 --> Total execution time: 0.0822
INFO - 2022-06-03 04:57:15 --> Config Class Initialized
INFO - 2022-06-03 04:57:15 --> Hooks Class Initialized
DEBUG - 2022-06-03 04:57:15 --> UTF-8 Support Enabled
INFO - 2022-06-03 04:57:15 --> Utf8 Class Initialized
INFO - 2022-06-03 04:57:15 --> URI Class Initialized
INFO - 2022-06-03 04:57:15 --> Router Class Initialized
INFO - 2022-06-03 04:57:15 --> Output Class Initialized
INFO - 2022-06-03 04:57:15 --> Security Class Initialized
DEBUG - 2022-06-03 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 04:57:15 --> Input Class Initialized
INFO - 2022-06-03 04:57:15 --> Language Class Initialized
INFO - 2022-06-03 04:57:15 --> Language Class Initialized
INFO - 2022-06-03 04:57:15 --> Config Class Initialized
INFO - 2022-06-03 04:57:15 --> Loader Class Initialized
INFO - 2022-06-03 04:57:15 --> Helper loaded: url_helper
INFO - 2022-06-03 04:57:15 --> Helper loaded: file_helper
INFO - 2022-06-03 04:57:15 --> Helper loaded: form_helper
INFO - 2022-06-03 04:57:15 --> Helper loaded: my_helper
INFO - 2022-06-03 04:57:15 --> Database Driver Class Initialized
DEBUG - 2022-06-03 04:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 04:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 04:57:15 --> Controller Class Initialized
ERROR - 2022-06-03 04:57:15 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:57:15 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:57:15 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 04:57:15 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 04:57:15 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:57:15 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:57:15 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 04:57:15 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 04:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 04:57:15 --> Final output sent to browser
DEBUG - 2022-06-03 04:57:15 --> Total execution time: 0.0854
INFO - 2022-06-03 04:57:16 --> Config Class Initialized
INFO - 2022-06-03 04:57:16 --> Hooks Class Initialized
DEBUG - 2022-06-03 04:57:16 --> UTF-8 Support Enabled
INFO - 2022-06-03 04:57:16 --> Utf8 Class Initialized
INFO - 2022-06-03 04:57:16 --> URI Class Initialized
INFO - 2022-06-03 04:57:16 --> Router Class Initialized
INFO - 2022-06-03 04:57:16 --> Output Class Initialized
INFO - 2022-06-03 04:57:16 --> Security Class Initialized
DEBUG - 2022-06-03 04:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 04:57:16 --> Input Class Initialized
INFO - 2022-06-03 04:57:16 --> Language Class Initialized
INFO - 2022-06-03 04:57:16 --> Language Class Initialized
INFO - 2022-06-03 04:57:16 --> Config Class Initialized
INFO - 2022-06-03 04:57:16 --> Loader Class Initialized
INFO - 2022-06-03 04:57:16 --> Helper loaded: url_helper
INFO - 2022-06-03 04:57:16 --> Helper loaded: file_helper
INFO - 2022-06-03 04:57:16 --> Helper loaded: form_helper
INFO - 2022-06-03 04:57:16 --> Helper loaded: my_helper
INFO - 2022-06-03 04:57:16 --> Database Driver Class Initialized
DEBUG - 2022-06-03 04:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 04:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 04:57:16 --> Controller Class Initialized
ERROR - 2022-06-03 04:57:16 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:57:16 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:57:16 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 04:57:16 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 04:57:16 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:57:16 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:57:16 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 04:57:16 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 04:57:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 04:57:16 --> Final output sent to browser
DEBUG - 2022-06-03 04:57:16 --> Total execution time: 0.0778
INFO - 2022-06-03 04:57:17 --> Config Class Initialized
INFO - 2022-06-03 04:57:17 --> Hooks Class Initialized
DEBUG - 2022-06-03 04:57:17 --> UTF-8 Support Enabled
INFO - 2022-06-03 04:57:17 --> Utf8 Class Initialized
INFO - 2022-06-03 04:57:17 --> URI Class Initialized
INFO - 2022-06-03 04:57:17 --> Router Class Initialized
INFO - 2022-06-03 04:57:17 --> Output Class Initialized
INFO - 2022-06-03 04:57:17 --> Security Class Initialized
DEBUG - 2022-06-03 04:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 04:57:17 --> Input Class Initialized
INFO - 2022-06-03 04:57:17 --> Language Class Initialized
INFO - 2022-06-03 04:57:17 --> Language Class Initialized
INFO - 2022-06-03 04:57:17 --> Config Class Initialized
INFO - 2022-06-03 04:57:17 --> Loader Class Initialized
INFO - 2022-06-03 04:57:17 --> Helper loaded: url_helper
INFO - 2022-06-03 04:57:17 --> Helper loaded: file_helper
INFO - 2022-06-03 04:57:17 --> Helper loaded: form_helper
INFO - 2022-06-03 04:57:17 --> Helper loaded: my_helper
INFO - 2022-06-03 04:57:17 --> Database Driver Class Initialized
DEBUG - 2022-06-03 04:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 04:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 04:57:17 --> Controller Class Initialized
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 04:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 04:57:17 --> Final output sent to browser
DEBUG - 2022-06-03 04:57:17 --> Total execution time: 0.0747
INFO - 2022-06-03 04:57:17 --> Config Class Initialized
INFO - 2022-06-03 04:57:17 --> Hooks Class Initialized
DEBUG - 2022-06-03 04:57:17 --> UTF-8 Support Enabled
INFO - 2022-06-03 04:57:17 --> Utf8 Class Initialized
INFO - 2022-06-03 04:57:17 --> URI Class Initialized
INFO - 2022-06-03 04:57:17 --> Router Class Initialized
INFO - 2022-06-03 04:57:17 --> Output Class Initialized
INFO - 2022-06-03 04:57:17 --> Security Class Initialized
DEBUG - 2022-06-03 04:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-03 04:57:17 --> Input Class Initialized
INFO - 2022-06-03 04:57:17 --> Language Class Initialized
INFO - 2022-06-03 04:57:17 --> Language Class Initialized
INFO - 2022-06-03 04:57:17 --> Config Class Initialized
INFO - 2022-06-03 04:57:17 --> Loader Class Initialized
INFO - 2022-06-03 04:57:17 --> Helper loaded: url_helper
INFO - 2022-06-03 04:57:17 --> Helper loaded: file_helper
INFO - 2022-06-03 04:57:17 --> Helper loaded: form_helper
INFO - 2022-06-03 04:57:17 --> Helper loaded: my_helper
INFO - 2022-06-03 04:57:17 --> Database Driver Class Initialized
DEBUG - 2022-06-03 04:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-03 04:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-03 04:57:17 --> Controller Class Initialized
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 161
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nilai' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 159
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 160
ERROR - 2022-06-03 04:57:17 --> Severity: Warning --> Illegal string offset 'nama' C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 169
DEBUG - 2022-06-03 04:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-06-03 04:57:17 --> Final output sent to browser
DEBUG - 2022-06-03 04:57:17 --> Total execution time: 0.0844
