<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-20 03:42:38 --> Config Class Initialized
INFO - 2020-12-20 03:42:38 --> Hooks Class Initialized
DEBUG - 2020-12-20 03:42:38 --> UTF-8 Support Enabled
INFO - 2020-12-20 03:42:38 --> Utf8 Class Initialized
INFO - 2020-12-20 03:42:38 --> URI Class Initialized
DEBUG - 2020-12-20 03:42:38 --> No URI present. Default controller set.
INFO - 2020-12-20 03:42:38 --> Router Class Initialized
INFO - 2020-12-20 03:42:38 --> Output Class Initialized
INFO - 2020-12-20 03:42:38 --> Security Class Initialized
DEBUG - 2020-12-20 03:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 03:42:38 --> Input Class Initialized
INFO - 2020-12-20 03:42:38 --> Language Class Initialized
INFO - 2020-12-20 03:42:38 --> Language Class Initialized
INFO - 2020-12-20 03:42:38 --> Config Class Initialized
INFO - 2020-12-20 03:42:38 --> Loader Class Initialized
INFO - 2020-12-20 03:42:38 --> Helper loaded: url_helper
INFO - 2020-12-20 03:42:38 --> Helper loaded: file_helper
INFO - 2020-12-20 03:42:38 --> Helper loaded: form_helper
INFO - 2020-12-20 03:42:38 --> Helper loaded: my_helper
INFO - 2020-12-20 03:42:38 --> Database Driver Class Initialized
DEBUG - 2020-12-20 03:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 03:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 03:42:38 --> Controller Class Initialized
INFO - 2020-12-20 03:42:38 --> Config Class Initialized
INFO - 2020-12-20 03:42:38 --> Hooks Class Initialized
DEBUG - 2020-12-20 03:42:38 --> UTF-8 Support Enabled
INFO - 2020-12-20 03:42:38 --> Utf8 Class Initialized
INFO - 2020-12-20 03:42:38 --> URI Class Initialized
INFO - 2020-12-20 03:42:38 --> Router Class Initialized
INFO - 2020-12-20 03:42:38 --> Output Class Initialized
INFO - 2020-12-20 03:42:38 --> Security Class Initialized
DEBUG - 2020-12-20 03:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 03:42:38 --> Input Class Initialized
INFO - 2020-12-20 03:42:38 --> Language Class Initialized
INFO - 2020-12-20 03:42:39 --> Language Class Initialized
INFO - 2020-12-20 03:42:39 --> Config Class Initialized
INFO - 2020-12-20 03:42:39 --> Loader Class Initialized
INFO - 2020-12-20 03:42:39 --> Helper loaded: url_helper
INFO - 2020-12-20 03:42:39 --> Helper loaded: file_helper
INFO - 2020-12-20 03:42:39 --> Helper loaded: form_helper
INFO - 2020-12-20 03:42:39 --> Helper loaded: my_helper
INFO - 2020-12-20 03:42:39 --> Database Driver Class Initialized
DEBUG - 2020-12-20 03:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 03:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 03:42:39 --> Controller Class Initialized
DEBUG - 2020-12-20 03:42:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-20 03:42:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 03:42:39 --> Final output sent to browser
DEBUG - 2020-12-20 03:42:39 --> Total execution time: 0.2821
INFO - 2020-12-20 03:44:08 --> Config Class Initialized
INFO - 2020-12-20 03:44:08 --> Hooks Class Initialized
DEBUG - 2020-12-20 03:44:08 --> UTF-8 Support Enabled
INFO - 2020-12-20 03:44:08 --> Utf8 Class Initialized
INFO - 2020-12-20 03:44:08 --> URI Class Initialized
INFO - 2020-12-20 03:44:08 --> Router Class Initialized
INFO - 2020-12-20 03:44:08 --> Output Class Initialized
INFO - 2020-12-20 03:44:08 --> Security Class Initialized
DEBUG - 2020-12-20 03:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 03:44:08 --> Input Class Initialized
INFO - 2020-12-20 03:44:08 --> Language Class Initialized
INFO - 2020-12-20 03:44:08 --> Language Class Initialized
INFO - 2020-12-20 03:44:08 --> Config Class Initialized
INFO - 2020-12-20 03:44:08 --> Loader Class Initialized
INFO - 2020-12-20 03:44:08 --> Helper loaded: url_helper
INFO - 2020-12-20 03:44:08 --> Helper loaded: file_helper
INFO - 2020-12-20 03:44:08 --> Helper loaded: form_helper
INFO - 2020-12-20 03:44:08 --> Helper loaded: my_helper
INFO - 2020-12-20 03:44:08 --> Database Driver Class Initialized
DEBUG - 2020-12-20 03:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 03:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 03:44:08 --> Controller Class Initialized
INFO - 2020-12-20 03:44:08 --> Helper loaded: cookie_helper
INFO - 2020-12-20 03:44:08 --> Final output sent to browser
DEBUG - 2020-12-20 03:44:08 --> Total execution time: 0.3007
INFO - 2020-12-20 03:44:10 --> Config Class Initialized
INFO - 2020-12-20 03:44:10 --> Hooks Class Initialized
DEBUG - 2020-12-20 03:44:10 --> UTF-8 Support Enabled
INFO - 2020-12-20 03:44:10 --> Utf8 Class Initialized
INFO - 2020-12-20 03:44:10 --> URI Class Initialized
INFO - 2020-12-20 03:44:10 --> Router Class Initialized
INFO - 2020-12-20 03:44:10 --> Output Class Initialized
INFO - 2020-12-20 03:44:10 --> Security Class Initialized
DEBUG - 2020-12-20 03:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 03:44:10 --> Input Class Initialized
INFO - 2020-12-20 03:44:10 --> Language Class Initialized
INFO - 2020-12-20 03:44:10 --> Language Class Initialized
INFO - 2020-12-20 03:44:10 --> Config Class Initialized
INFO - 2020-12-20 03:44:10 --> Loader Class Initialized
INFO - 2020-12-20 03:44:10 --> Helper loaded: url_helper
INFO - 2020-12-20 03:44:10 --> Helper loaded: file_helper
INFO - 2020-12-20 03:44:10 --> Helper loaded: form_helper
INFO - 2020-12-20 03:44:10 --> Helper loaded: my_helper
INFO - 2020-12-20 03:44:10 --> Database Driver Class Initialized
DEBUG - 2020-12-20 03:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 03:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 03:44:10 --> Controller Class Initialized
DEBUG - 2020-12-20 03:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-20 03:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 03:44:10 --> Final output sent to browser
DEBUG - 2020-12-20 03:44:10 --> Total execution time: 0.3589
INFO - 2020-12-20 03:45:52 --> Config Class Initialized
INFO - 2020-12-20 03:45:52 --> Hooks Class Initialized
DEBUG - 2020-12-20 03:45:52 --> UTF-8 Support Enabled
INFO - 2020-12-20 03:45:52 --> Utf8 Class Initialized
INFO - 2020-12-20 03:45:52 --> URI Class Initialized
INFO - 2020-12-20 03:45:52 --> Router Class Initialized
INFO - 2020-12-20 03:45:52 --> Output Class Initialized
INFO - 2020-12-20 03:45:52 --> Security Class Initialized
DEBUG - 2020-12-20 03:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 03:45:52 --> Input Class Initialized
INFO - 2020-12-20 03:45:52 --> Language Class Initialized
INFO - 2020-12-20 03:45:52 --> Language Class Initialized
INFO - 2020-12-20 03:45:52 --> Config Class Initialized
INFO - 2020-12-20 03:45:52 --> Loader Class Initialized
INFO - 2020-12-20 03:45:52 --> Helper loaded: url_helper
INFO - 2020-12-20 03:45:52 --> Helper loaded: file_helper
INFO - 2020-12-20 03:45:52 --> Helper loaded: form_helper
INFO - 2020-12-20 03:45:52 --> Helper loaded: my_helper
INFO - 2020-12-20 03:45:52 --> Database Driver Class Initialized
DEBUG - 2020-12-20 03:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 03:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 03:45:52 --> Controller Class Initialized
DEBUG - 2020-12-20 03:45:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-20 03:45:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 03:45:52 --> Final output sent to browser
DEBUG - 2020-12-20 03:45:52 --> Total execution time: 0.2562
INFO - 2020-12-20 03:45:52 --> Config Class Initialized
INFO - 2020-12-20 03:45:52 --> Hooks Class Initialized
DEBUG - 2020-12-20 03:45:52 --> UTF-8 Support Enabled
INFO - 2020-12-20 03:45:52 --> Utf8 Class Initialized
INFO - 2020-12-20 03:45:52 --> URI Class Initialized
INFO - 2020-12-20 03:45:52 --> Router Class Initialized
INFO - 2020-12-20 03:45:52 --> Output Class Initialized
INFO - 2020-12-20 03:45:52 --> Security Class Initialized
DEBUG - 2020-12-20 03:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 03:45:52 --> Input Class Initialized
INFO - 2020-12-20 03:45:52 --> Language Class Initialized
INFO - 2020-12-20 03:45:52 --> Language Class Initialized
INFO - 2020-12-20 03:45:52 --> Config Class Initialized
INFO - 2020-12-20 03:45:52 --> Loader Class Initialized
INFO - 2020-12-20 03:45:52 --> Helper loaded: url_helper
INFO - 2020-12-20 03:45:52 --> Helper loaded: file_helper
INFO - 2020-12-20 03:45:52 --> Helper loaded: form_helper
INFO - 2020-12-20 03:45:52 --> Helper loaded: my_helper
INFO - 2020-12-20 03:45:52 --> Database Driver Class Initialized
DEBUG - 2020-12-20 03:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 03:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 03:45:52 --> Controller Class Initialized
INFO - 2020-12-20 03:50:23 --> Config Class Initialized
INFO - 2020-12-20 03:50:23 --> Hooks Class Initialized
DEBUG - 2020-12-20 03:50:23 --> UTF-8 Support Enabled
INFO - 2020-12-20 03:50:23 --> Utf8 Class Initialized
INFO - 2020-12-20 03:50:23 --> URI Class Initialized
INFO - 2020-12-20 03:50:23 --> Router Class Initialized
INFO - 2020-12-20 03:50:23 --> Output Class Initialized
INFO - 2020-12-20 03:50:23 --> Security Class Initialized
DEBUG - 2020-12-20 03:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 03:50:23 --> Input Class Initialized
INFO - 2020-12-20 03:50:23 --> Language Class Initialized
INFO - 2020-12-20 03:50:23 --> Language Class Initialized
INFO - 2020-12-20 03:50:23 --> Config Class Initialized
INFO - 2020-12-20 03:50:23 --> Loader Class Initialized
INFO - 2020-12-20 03:50:23 --> Helper loaded: url_helper
INFO - 2020-12-20 03:50:23 --> Helper loaded: file_helper
INFO - 2020-12-20 03:50:23 --> Helper loaded: form_helper
INFO - 2020-12-20 03:50:23 --> Helper loaded: my_helper
INFO - 2020-12-20 03:50:23 --> Database Driver Class Initialized
DEBUG - 2020-12-20 03:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 03:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 03:50:24 --> Controller Class Initialized
INFO - 2020-12-20 03:50:24 --> Final output sent to browser
DEBUG - 2020-12-20 03:50:24 --> Total execution time: 0.2572
INFO - 2020-12-20 03:51:03 --> Config Class Initialized
INFO - 2020-12-20 03:51:03 --> Hooks Class Initialized
DEBUG - 2020-12-20 03:51:03 --> UTF-8 Support Enabled
INFO - 2020-12-20 03:51:03 --> Utf8 Class Initialized
INFO - 2020-12-20 03:51:03 --> URI Class Initialized
INFO - 2020-12-20 03:51:03 --> Router Class Initialized
INFO - 2020-12-20 03:51:03 --> Output Class Initialized
INFO - 2020-12-20 03:51:03 --> Security Class Initialized
DEBUG - 2020-12-20 03:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 03:51:03 --> Input Class Initialized
INFO - 2020-12-20 03:51:03 --> Language Class Initialized
INFO - 2020-12-20 03:51:03 --> Language Class Initialized
INFO - 2020-12-20 03:51:03 --> Config Class Initialized
INFO - 2020-12-20 03:51:03 --> Loader Class Initialized
INFO - 2020-12-20 03:51:03 --> Helper loaded: url_helper
INFO - 2020-12-20 03:51:03 --> Helper loaded: file_helper
INFO - 2020-12-20 03:51:03 --> Helper loaded: form_helper
INFO - 2020-12-20 03:51:03 --> Helper loaded: my_helper
INFO - 2020-12-20 03:51:03 --> Database Driver Class Initialized
DEBUG - 2020-12-20 03:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 03:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 03:51:03 --> Controller Class Initialized
INFO - 2020-12-20 03:51:03 --> Final output sent to browser
DEBUG - 2020-12-20 03:51:03 --> Total execution time: 0.2311
INFO - 2020-12-20 04:00:50 --> Config Class Initialized
INFO - 2020-12-20 04:00:50 --> Hooks Class Initialized
DEBUG - 2020-12-20 04:00:50 --> UTF-8 Support Enabled
INFO - 2020-12-20 04:00:50 --> Utf8 Class Initialized
INFO - 2020-12-20 04:00:50 --> URI Class Initialized
INFO - 2020-12-20 04:00:50 --> Router Class Initialized
INFO - 2020-12-20 04:00:50 --> Output Class Initialized
INFO - 2020-12-20 04:00:50 --> Security Class Initialized
DEBUG - 2020-12-20 04:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 04:00:50 --> Input Class Initialized
INFO - 2020-12-20 04:00:50 --> Language Class Initialized
INFO - 2020-12-20 04:00:50 --> Language Class Initialized
INFO - 2020-12-20 04:00:50 --> Config Class Initialized
INFO - 2020-12-20 04:00:50 --> Loader Class Initialized
INFO - 2020-12-20 04:00:50 --> Helper loaded: url_helper
INFO - 2020-12-20 04:00:50 --> Helper loaded: file_helper
INFO - 2020-12-20 04:00:50 --> Helper loaded: form_helper
INFO - 2020-12-20 04:00:50 --> Helper loaded: my_helper
INFO - 2020-12-20 04:00:50 --> Database Driver Class Initialized
DEBUG - 2020-12-20 04:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 04:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 04:00:50 --> Controller Class Initialized
DEBUG - 2020-12-20 04:00:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-20 04:00:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 04:00:50 --> Final output sent to browser
DEBUG - 2020-12-20 04:00:50 --> Total execution time: 0.2296
INFO - 2020-12-20 04:00:50 --> Config Class Initialized
INFO - 2020-12-20 04:00:50 --> Hooks Class Initialized
DEBUG - 2020-12-20 04:00:50 --> UTF-8 Support Enabled
INFO - 2020-12-20 04:00:50 --> Utf8 Class Initialized
INFO - 2020-12-20 04:00:50 --> URI Class Initialized
INFO - 2020-12-20 04:00:50 --> Router Class Initialized
INFO - 2020-12-20 04:00:50 --> Output Class Initialized
INFO - 2020-12-20 04:00:50 --> Security Class Initialized
DEBUG - 2020-12-20 04:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 04:00:50 --> Input Class Initialized
INFO - 2020-12-20 04:00:50 --> Language Class Initialized
INFO - 2020-12-20 04:00:50 --> Language Class Initialized
INFO - 2020-12-20 04:00:50 --> Config Class Initialized
INFO - 2020-12-20 04:00:50 --> Loader Class Initialized
INFO - 2020-12-20 04:00:50 --> Helper loaded: url_helper
INFO - 2020-12-20 04:00:50 --> Helper loaded: file_helper
INFO - 2020-12-20 04:00:50 --> Helper loaded: form_helper
INFO - 2020-12-20 04:00:50 --> Helper loaded: my_helper
INFO - 2020-12-20 04:00:50 --> Database Driver Class Initialized
DEBUG - 2020-12-20 04:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 04:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 04:00:50 --> Controller Class Initialized
INFO - 2020-12-20 04:00:54 --> Config Class Initialized
INFO - 2020-12-20 04:00:54 --> Hooks Class Initialized
DEBUG - 2020-12-20 04:00:54 --> UTF-8 Support Enabled
INFO - 2020-12-20 04:00:54 --> Utf8 Class Initialized
INFO - 2020-12-20 04:00:54 --> URI Class Initialized
INFO - 2020-12-20 04:00:54 --> Router Class Initialized
INFO - 2020-12-20 04:00:54 --> Output Class Initialized
INFO - 2020-12-20 04:00:54 --> Security Class Initialized
DEBUG - 2020-12-20 04:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 04:00:54 --> Input Class Initialized
INFO - 2020-12-20 04:00:54 --> Language Class Initialized
INFO - 2020-12-20 04:00:54 --> Language Class Initialized
INFO - 2020-12-20 04:00:54 --> Config Class Initialized
INFO - 2020-12-20 04:00:54 --> Loader Class Initialized
INFO - 2020-12-20 04:00:54 --> Helper loaded: url_helper
INFO - 2020-12-20 04:00:54 --> Helper loaded: file_helper
INFO - 2020-12-20 04:00:54 --> Helper loaded: form_helper
INFO - 2020-12-20 04:00:54 --> Helper loaded: my_helper
INFO - 2020-12-20 04:00:54 --> Database Driver Class Initialized
DEBUG - 2020-12-20 04:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 04:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 04:00:54 --> Controller Class Initialized
INFO - 2020-12-20 04:00:54 --> Final output sent to browser
DEBUG - 2020-12-20 04:00:54 --> Total execution time: 0.2180
INFO - 2020-12-20 05:02:28 --> Config Class Initialized
INFO - 2020-12-20 05:02:28 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:02:28 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:02:28 --> Utf8 Class Initialized
INFO - 2020-12-20 05:02:28 --> URI Class Initialized
INFO - 2020-12-20 05:02:28 --> Router Class Initialized
INFO - 2020-12-20 05:02:28 --> Output Class Initialized
INFO - 2020-12-20 05:02:28 --> Security Class Initialized
DEBUG - 2020-12-20 05:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:02:28 --> Input Class Initialized
INFO - 2020-12-20 05:02:28 --> Language Class Initialized
INFO - 2020-12-20 05:02:28 --> Language Class Initialized
INFO - 2020-12-20 05:02:28 --> Config Class Initialized
INFO - 2020-12-20 05:02:28 --> Loader Class Initialized
INFO - 2020-12-20 05:02:28 --> Helper loaded: url_helper
INFO - 2020-12-20 05:02:28 --> Helper loaded: file_helper
INFO - 2020-12-20 05:02:28 --> Helper loaded: form_helper
INFO - 2020-12-20 05:02:28 --> Helper loaded: my_helper
INFO - 2020-12-20 05:02:28 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:02:28 --> Controller Class Initialized
INFO - 2020-12-20 05:02:28 --> Helper loaded: cookie_helper
INFO - 2020-12-20 05:02:28 --> Config Class Initialized
INFO - 2020-12-20 05:02:29 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:02:29 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:02:29 --> Utf8 Class Initialized
INFO - 2020-12-20 05:02:29 --> URI Class Initialized
INFO - 2020-12-20 05:02:29 --> Router Class Initialized
INFO - 2020-12-20 05:02:29 --> Output Class Initialized
INFO - 2020-12-20 05:02:29 --> Security Class Initialized
DEBUG - 2020-12-20 05:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:02:29 --> Input Class Initialized
INFO - 2020-12-20 05:02:29 --> Language Class Initialized
INFO - 2020-12-20 05:02:29 --> Language Class Initialized
INFO - 2020-12-20 05:02:29 --> Config Class Initialized
INFO - 2020-12-20 05:02:29 --> Loader Class Initialized
INFO - 2020-12-20 05:02:29 --> Helper loaded: url_helper
INFO - 2020-12-20 05:02:29 --> Helper loaded: file_helper
INFO - 2020-12-20 05:02:29 --> Helper loaded: form_helper
INFO - 2020-12-20 05:02:29 --> Helper loaded: my_helper
INFO - 2020-12-20 05:02:29 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:02:29 --> Controller Class Initialized
DEBUG - 2020-12-20 05:02:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-20 05:02:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:02:29 --> Final output sent to browser
DEBUG - 2020-12-20 05:02:29 --> Total execution time: 0.7522
INFO - 2020-12-20 05:02:35 --> Config Class Initialized
INFO - 2020-12-20 05:02:35 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:02:35 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:02:35 --> Utf8 Class Initialized
INFO - 2020-12-20 05:02:35 --> URI Class Initialized
INFO - 2020-12-20 05:02:35 --> Router Class Initialized
INFO - 2020-12-20 05:02:35 --> Output Class Initialized
INFO - 2020-12-20 05:02:35 --> Security Class Initialized
DEBUG - 2020-12-20 05:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:02:35 --> Input Class Initialized
INFO - 2020-12-20 05:02:35 --> Language Class Initialized
INFO - 2020-12-20 05:02:35 --> Language Class Initialized
INFO - 2020-12-20 05:02:35 --> Config Class Initialized
INFO - 2020-12-20 05:02:35 --> Loader Class Initialized
INFO - 2020-12-20 05:02:36 --> Helper loaded: url_helper
INFO - 2020-12-20 05:02:36 --> Helper loaded: file_helper
INFO - 2020-12-20 05:02:36 --> Helper loaded: form_helper
INFO - 2020-12-20 05:02:36 --> Helper loaded: my_helper
INFO - 2020-12-20 05:02:36 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:02:36 --> Controller Class Initialized
INFO - 2020-12-20 05:02:36 --> Helper loaded: cookie_helper
INFO - 2020-12-20 05:02:36 --> Final output sent to browser
DEBUG - 2020-12-20 05:02:36 --> Total execution time: 0.8160
INFO - 2020-12-20 05:02:36 --> Config Class Initialized
INFO - 2020-12-20 05:02:37 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:02:37 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:02:37 --> Utf8 Class Initialized
INFO - 2020-12-20 05:02:37 --> URI Class Initialized
INFO - 2020-12-20 05:02:37 --> Router Class Initialized
INFO - 2020-12-20 05:02:37 --> Output Class Initialized
INFO - 2020-12-20 05:02:37 --> Security Class Initialized
DEBUG - 2020-12-20 05:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:02:37 --> Input Class Initialized
INFO - 2020-12-20 05:02:37 --> Language Class Initialized
INFO - 2020-12-20 05:02:37 --> Language Class Initialized
INFO - 2020-12-20 05:02:37 --> Config Class Initialized
INFO - 2020-12-20 05:02:37 --> Loader Class Initialized
INFO - 2020-12-20 05:02:37 --> Helper loaded: url_helper
INFO - 2020-12-20 05:02:37 --> Helper loaded: file_helper
INFO - 2020-12-20 05:02:37 --> Helper loaded: form_helper
INFO - 2020-12-20 05:02:37 --> Helper loaded: my_helper
INFO - 2020-12-20 05:02:37 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:02:37 --> Controller Class Initialized
DEBUG - 2020-12-20 05:02:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-20 05:02:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:02:37 --> Final output sent to browser
DEBUG - 2020-12-20 05:02:37 --> Total execution time: 0.5727
INFO - 2020-12-20 05:02:59 --> Config Class Initialized
INFO - 2020-12-20 05:02:59 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:02:59 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:02:59 --> Utf8 Class Initialized
INFO - 2020-12-20 05:02:59 --> URI Class Initialized
INFO - 2020-12-20 05:02:59 --> Router Class Initialized
INFO - 2020-12-20 05:02:59 --> Output Class Initialized
INFO - 2020-12-20 05:02:59 --> Security Class Initialized
DEBUG - 2020-12-20 05:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:02:59 --> Input Class Initialized
INFO - 2020-12-20 05:02:59 --> Language Class Initialized
INFO - 2020-12-20 05:02:59 --> Language Class Initialized
INFO - 2020-12-20 05:02:59 --> Config Class Initialized
INFO - 2020-12-20 05:02:59 --> Loader Class Initialized
INFO - 2020-12-20 05:02:59 --> Helper loaded: url_helper
INFO - 2020-12-20 05:02:59 --> Helper loaded: file_helper
INFO - 2020-12-20 05:02:59 --> Helper loaded: form_helper
INFO - 2020-12-20 05:02:59 --> Helper loaded: my_helper
INFO - 2020-12-20 05:02:59 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:02:59 --> Controller Class Initialized
DEBUG - 2020-12-20 05:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-20 05:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:02:59 --> Final output sent to browser
DEBUG - 2020-12-20 05:02:59 --> Total execution time: 0.6724
INFO - 2020-12-20 05:03:05 --> Config Class Initialized
INFO - 2020-12-20 05:03:05 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:03:05 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:03:05 --> Utf8 Class Initialized
INFO - 2020-12-20 05:03:05 --> URI Class Initialized
INFO - 2020-12-20 05:03:05 --> Router Class Initialized
INFO - 2020-12-20 05:03:05 --> Output Class Initialized
INFO - 2020-12-20 05:03:05 --> Security Class Initialized
DEBUG - 2020-12-20 05:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:03:05 --> Input Class Initialized
INFO - 2020-12-20 05:03:05 --> Language Class Initialized
INFO - 2020-12-20 05:03:05 --> Language Class Initialized
INFO - 2020-12-20 05:03:05 --> Config Class Initialized
INFO - 2020-12-20 05:03:05 --> Loader Class Initialized
INFO - 2020-12-20 05:03:05 --> Helper loaded: url_helper
INFO - 2020-12-20 05:03:05 --> Helper loaded: file_helper
INFO - 2020-12-20 05:03:05 --> Helper loaded: form_helper
INFO - 2020-12-20 05:03:05 --> Helper loaded: my_helper
INFO - 2020-12-20 05:03:05 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:03:05 --> Controller Class Initialized
DEBUG - 2020-12-20 05:03:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-12-20 05:03:05 --> Final output sent to browser
DEBUG - 2020-12-20 05:03:06 --> Total execution time: 0.6975
INFO - 2020-12-20 05:04:12 --> Config Class Initialized
INFO - 2020-12-20 05:04:13 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:04:13 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:04:13 --> Utf8 Class Initialized
INFO - 2020-12-20 05:04:13 --> URI Class Initialized
INFO - 2020-12-20 05:04:13 --> Router Class Initialized
INFO - 2020-12-20 05:04:13 --> Output Class Initialized
INFO - 2020-12-20 05:04:13 --> Security Class Initialized
DEBUG - 2020-12-20 05:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:04:13 --> Input Class Initialized
INFO - 2020-12-20 05:04:13 --> Language Class Initialized
INFO - 2020-12-20 05:04:13 --> Language Class Initialized
INFO - 2020-12-20 05:04:13 --> Config Class Initialized
INFO - 2020-12-20 05:04:13 --> Loader Class Initialized
INFO - 2020-12-20 05:04:13 --> Helper loaded: url_helper
INFO - 2020-12-20 05:04:13 --> Helper loaded: file_helper
INFO - 2020-12-20 05:04:13 --> Helper loaded: form_helper
INFO - 2020-12-20 05:04:13 --> Helper loaded: my_helper
INFO - 2020-12-20 05:04:13 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:04:13 --> Controller Class Initialized
DEBUG - 2020-12-20 05:04:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:04:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:04:13 --> Final output sent to browser
DEBUG - 2020-12-20 05:04:13 --> Total execution time: 0.9438
INFO - 2020-12-20 05:05:24 --> Config Class Initialized
INFO - 2020-12-20 05:05:24 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:05:24 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:05:24 --> Utf8 Class Initialized
INFO - 2020-12-20 05:05:24 --> URI Class Initialized
INFO - 2020-12-20 05:05:24 --> Router Class Initialized
INFO - 2020-12-20 05:05:24 --> Output Class Initialized
INFO - 2020-12-20 05:05:24 --> Security Class Initialized
DEBUG - 2020-12-20 05:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:05:24 --> Input Class Initialized
INFO - 2020-12-20 05:05:24 --> Language Class Initialized
INFO - 2020-12-20 05:05:24 --> Language Class Initialized
INFO - 2020-12-20 05:05:24 --> Config Class Initialized
INFO - 2020-12-20 05:05:24 --> Loader Class Initialized
INFO - 2020-12-20 05:05:24 --> Helper loaded: url_helper
INFO - 2020-12-20 05:05:25 --> Helper loaded: file_helper
INFO - 2020-12-20 05:05:25 --> Helper loaded: form_helper
INFO - 2020-12-20 05:05:25 --> Helper loaded: my_helper
INFO - 2020-12-20 05:05:25 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:05:25 --> Controller Class Initialized
DEBUG - 2020-12-20 05:05:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:05:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:05:25 --> Final output sent to browser
DEBUG - 2020-12-20 05:05:25 --> Total execution time: 0.7771
INFO - 2020-12-20 05:08:03 --> Config Class Initialized
INFO - 2020-12-20 05:08:03 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:08:03 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:08:03 --> Utf8 Class Initialized
INFO - 2020-12-20 05:08:03 --> URI Class Initialized
INFO - 2020-12-20 05:08:03 --> Router Class Initialized
INFO - 2020-12-20 05:08:03 --> Output Class Initialized
INFO - 2020-12-20 05:08:03 --> Security Class Initialized
DEBUG - 2020-12-20 05:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:08:03 --> Input Class Initialized
INFO - 2020-12-20 05:08:03 --> Language Class Initialized
INFO - 2020-12-20 05:08:03 --> Language Class Initialized
INFO - 2020-12-20 05:08:03 --> Config Class Initialized
INFO - 2020-12-20 05:08:03 --> Loader Class Initialized
INFO - 2020-12-20 05:08:03 --> Helper loaded: url_helper
INFO - 2020-12-20 05:08:03 --> Helper loaded: file_helper
INFO - 2020-12-20 05:08:03 --> Helper loaded: form_helper
INFO - 2020-12-20 05:08:03 --> Helper loaded: my_helper
INFO - 2020-12-20 05:08:03 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:08:03 --> Controller Class Initialized
DEBUG - 2020-12-20 05:08:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:08:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:08:04 --> Final output sent to browser
DEBUG - 2020-12-20 05:08:04 --> Total execution time: 0.6528
INFO - 2020-12-20 05:09:22 --> Config Class Initialized
INFO - 2020-12-20 05:09:22 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:09:22 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:09:22 --> Utf8 Class Initialized
INFO - 2020-12-20 05:09:22 --> URI Class Initialized
INFO - 2020-12-20 05:09:22 --> Router Class Initialized
INFO - 2020-12-20 05:09:22 --> Output Class Initialized
INFO - 2020-12-20 05:09:22 --> Security Class Initialized
DEBUG - 2020-12-20 05:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:09:22 --> Input Class Initialized
INFO - 2020-12-20 05:09:22 --> Language Class Initialized
INFO - 2020-12-20 05:09:22 --> Language Class Initialized
INFO - 2020-12-20 05:09:22 --> Config Class Initialized
INFO - 2020-12-20 05:09:22 --> Loader Class Initialized
INFO - 2020-12-20 05:09:22 --> Helper loaded: url_helper
INFO - 2020-12-20 05:09:22 --> Helper loaded: file_helper
INFO - 2020-12-20 05:09:22 --> Helper loaded: form_helper
INFO - 2020-12-20 05:09:22 --> Helper loaded: my_helper
INFO - 2020-12-20 05:09:22 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:09:23 --> Controller Class Initialized
DEBUG - 2020-12-20 05:09:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:09:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:09:23 --> Final output sent to browser
DEBUG - 2020-12-20 05:09:23 --> Total execution time: 0.7742
INFO - 2020-12-20 05:10:24 --> Config Class Initialized
INFO - 2020-12-20 05:10:24 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:10:24 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:10:24 --> Utf8 Class Initialized
INFO - 2020-12-20 05:10:24 --> URI Class Initialized
INFO - 2020-12-20 05:10:24 --> Router Class Initialized
INFO - 2020-12-20 05:10:24 --> Output Class Initialized
INFO - 2020-12-20 05:10:24 --> Security Class Initialized
DEBUG - 2020-12-20 05:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:10:24 --> Input Class Initialized
INFO - 2020-12-20 05:10:24 --> Language Class Initialized
INFO - 2020-12-20 05:10:24 --> Language Class Initialized
INFO - 2020-12-20 05:10:24 --> Config Class Initialized
INFO - 2020-12-20 05:10:24 --> Loader Class Initialized
INFO - 2020-12-20 05:10:24 --> Helper loaded: url_helper
INFO - 2020-12-20 05:10:24 --> Helper loaded: file_helper
INFO - 2020-12-20 05:10:24 --> Helper loaded: form_helper
INFO - 2020-12-20 05:10:24 --> Helper loaded: my_helper
INFO - 2020-12-20 05:10:24 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:10:24 --> Controller Class Initialized
DEBUG - 2020-12-20 05:10:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:10:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:10:24 --> Final output sent to browser
DEBUG - 2020-12-20 05:10:24 --> Total execution time: 0.6350
INFO - 2020-12-20 05:13:58 --> Config Class Initialized
INFO - 2020-12-20 05:13:58 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:13:58 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:13:58 --> Utf8 Class Initialized
INFO - 2020-12-20 05:13:58 --> URI Class Initialized
INFO - 2020-12-20 05:13:58 --> Router Class Initialized
INFO - 2020-12-20 05:13:58 --> Output Class Initialized
INFO - 2020-12-20 05:13:58 --> Security Class Initialized
DEBUG - 2020-12-20 05:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:13:58 --> Input Class Initialized
INFO - 2020-12-20 05:13:58 --> Language Class Initialized
INFO - 2020-12-20 05:13:58 --> Language Class Initialized
INFO - 2020-12-20 05:13:58 --> Config Class Initialized
INFO - 2020-12-20 05:13:58 --> Loader Class Initialized
INFO - 2020-12-20 05:13:58 --> Helper loaded: url_helper
INFO - 2020-12-20 05:13:58 --> Helper loaded: file_helper
INFO - 2020-12-20 05:13:58 --> Helper loaded: form_helper
INFO - 2020-12-20 05:13:58 --> Helper loaded: my_helper
INFO - 2020-12-20 05:13:58 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:13:58 --> Controller Class Initialized
DEBUG - 2020-12-20 05:13:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:13:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:13:58 --> Final output sent to browser
DEBUG - 2020-12-20 05:13:58 --> Total execution time: 0.7204
INFO - 2020-12-20 05:19:05 --> Config Class Initialized
INFO - 2020-12-20 05:19:05 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:19:05 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:19:05 --> Utf8 Class Initialized
INFO - 2020-12-20 05:19:05 --> URI Class Initialized
INFO - 2020-12-20 05:19:05 --> Router Class Initialized
INFO - 2020-12-20 05:19:05 --> Output Class Initialized
INFO - 2020-12-20 05:19:05 --> Security Class Initialized
DEBUG - 2020-12-20 05:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:19:05 --> Input Class Initialized
INFO - 2020-12-20 05:19:05 --> Language Class Initialized
INFO - 2020-12-20 05:19:05 --> Language Class Initialized
INFO - 2020-12-20 05:19:05 --> Config Class Initialized
INFO - 2020-12-20 05:19:05 --> Loader Class Initialized
INFO - 2020-12-20 05:19:05 --> Helper loaded: url_helper
INFO - 2020-12-20 05:19:05 --> Helper loaded: file_helper
INFO - 2020-12-20 05:19:05 --> Helper loaded: form_helper
INFO - 2020-12-20 05:19:05 --> Helper loaded: my_helper
INFO - 2020-12-20 05:19:05 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:19:05 --> Controller Class Initialized
DEBUG - 2020-12-20 05:19:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:19:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:19:05 --> Final output sent to browser
DEBUG - 2020-12-20 05:19:05 --> Total execution time: 0.6032
INFO - 2020-12-20 05:19:36 --> Config Class Initialized
INFO - 2020-12-20 05:19:36 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:19:36 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:19:36 --> Utf8 Class Initialized
INFO - 2020-12-20 05:19:36 --> URI Class Initialized
INFO - 2020-12-20 05:19:36 --> Router Class Initialized
INFO - 2020-12-20 05:19:36 --> Output Class Initialized
INFO - 2020-12-20 05:19:36 --> Security Class Initialized
DEBUG - 2020-12-20 05:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:19:36 --> Input Class Initialized
INFO - 2020-12-20 05:19:36 --> Language Class Initialized
INFO - 2020-12-20 05:19:36 --> Language Class Initialized
INFO - 2020-12-20 05:19:36 --> Config Class Initialized
INFO - 2020-12-20 05:19:36 --> Loader Class Initialized
INFO - 2020-12-20 05:19:36 --> Helper loaded: url_helper
INFO - 2020-12-20 05:19:36 --> Helper loaded: file_helper
INFO - 2020-12-20 05:19:36 --> Helper loaded: form_helper
INFO - 2020-12-20 05:19:36 --> Helper loaded: my_helper
INFO - 2020-12-20 05:19:36 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:19:36 --> Controller Class Initialized
DEBUG - 2020-12-20 05:19:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:19:37 --> Final output sent to browser
DEBUG - 2020-12-20 05:19:37 --> Total execution time: 0.6884
INFO - 2020-12-20 05:33:16 --> Config Class Initialized
INFO - 2020-12-20 05:33:16 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:33:16 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:33:16 --> Utf8 Class Initialized
INFO - 2020-12-20 05:33:16 --> URI Class Initialized
INFO - 2020-12-20 05:33:16 --> Router Class Initialized
INFO - 2020-12-20 05:33:16 --> Output Class Initialized
INFO - 2020-12-20 05:33:16 --> Security Class Initialized
DEBUG - 2020-12-20 05:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:33:16 --> Input Class Initialized
INFO - 2020-12-20 05:33:16 --> Language Class Initialized
INFO - 2020-12-20 05:33:16 --> Language Class Initialized
INFO - 2020-12-20 05:33:16 --> Config Class Initialized
INFO - 2020-12-20 05:33:16 --> Loader Class Initialized
INFO - 2020-12-20 05:33:16 --> Helper loaded: url_helper
INFO - 2020-12-20 05:33:16 --> Helper loaded: file_helper
INFO - 2020-12-20 05:33:16 --> Helper loaded: form_helper
INFO - 2020-12-20 05:33:16 --> Helper loaded: my_helper
INFO - 2020-12-20 05:33:17 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:33:17 --> Controller Class Initialized
ERROR - 2020-12-20 05:33:17 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
INFO - 2020-12-20 05:33:47 --> Config Class Initialized
INFO - 2020-12-20 05:33:47 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:33:47 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:33:47 --> Utf8 Class Initialized
INFO - 2020-12-20 05:33:47 --> URI Class Initialized
INFO - 2020-12-20 05:33:47 --> Router Class Initialized
INFO - 2020-12-20 05:33:47 --> Output Class Initialized
INFO - 2020-12-20 05:33:47 --> Security Class Initialized
DEBUG - 2020-12-20 05:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:33:47 --> Input Class Initialized
INFO - 2020-12-20 05:33:47 --> Language Class Initialized
INFO - 2020-12-20 05:33:47 --> Language Class Initialized
INFO - 2020-12-20 05:33:47 --> Config Class Initialized
INFO - 2020-12-20 05:33:47 --> Loader Class Initialized
INFO - 2020-12-20 05:33:47 --> Helper loaded: url_helper
INFO - 2020-12-20 05:33:47 --> Helper loaded: file_helper
INFO - 2020-12-20 05:33:47 --> Helper loaded: form_helper
INFO - 2020-12-20 05:33:47 --> Helper loaded: my_helper
INFO - 2020-12-20 05:33:47 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:33:47 --> Controller Class Initialized
ERROR - 2020-12-20 05:33:47 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 73
INFO - 2020-12-20 05:34:29 --> Config Class Initialized
INFO - 2020-12-20 05:34:29 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:34:29 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:34:29 --> Utf8 Class Initialized
INFO - 2020-12-20 05:34:29 --> URI Class Initialized
INFO - 2020-12-20 05:34:29 --> Router Class Initialized
INFO - 2020-12-20 05:34:29 --> Output Class Initialized
INFO - 2020-12-20 05:34:29 --> Security Class Initialized
DEBUG - 2020-12-20 05:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:34:29 --> Input Class Initialized
INFO - 2020-12-20 05:34:29 --> Language Class Initialized
INFO - 2020-12-20 05:34:29 --> Language Class Initialized
INFO - 2020-12-20 05:34:29 --> Config Class Initialized
INFO - 2020-12-20 05:34:30 --> Loader Class Initialized
INFO - 2020-12-20 05:34:30 --> Helper loaded: url_helper
INFO - 2020-12-20 05:34:30 --> Helper loaded: file_helper
INFO - 2020-12-20 05:34:30 --> Helper loaded: form_helper
INFO - 2020-12-20 05:34:30 --> Helper loaded: my_helper
INFO - 2020-12-20 05:34:30 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:34:30 --> Controller Class Initialized
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:30 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:31 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:32 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:33 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:34 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:35 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:39 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:34:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:34:48 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:34:48 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:34:48 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:34:48 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:34:48 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:34:48 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:34:48 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
DEBUG - 2020-12-20 05:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:34:48 --> Final output sent to browser
DEBUG - 2020-12-20 05:34:48 --> Total execution time: 18.6270
INFO - 2020-12-20 05:36:11 --> Config Class Initialized
INFO - 2020-12-20 05:36:11 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:36:11 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:36:11 --> Utf8 Class Initialized
INFO - 2020-12-20 05:36:11 --> URI Class Initialized
INFO - 2020-12-20 05:36:11 --> Router Class Initialized
INFO - 2020-12-20 05:36:11 --> Output Class Initialized
INFO - 2020-12-20 05:36:11 --> Security Class Initialized
DEBUG - 2020-12-20 05:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:36:11 --> Input Class Initialized
INFO - 2020-12-20 05:36:11 --> Language Class Initialized
INFO - 2020-12-20 05:36:12 --> Language Class Initialized
INFO - 2020-12-20 05:36:12 --> Config Class Initialized
INFO - 2020-12-20 05:36:12 --> Loader Class Initialized
INFO - 2020-12-20 05:36:12 --> Helper loaded: url_helper
INFO - 2020-12-20 05:36:12 --> Helper loaded: file_helper
INFO - 2020-12-20 05:36:12 --> Helper loaded: form_helper
INFO - 2020-12-20 05:36:12 --> Helper loaded: my_helper
INFO - 2020-12-20 05:36:12 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:36:12 --> Controller Class Initialized
ERROR - 2020-12-20 05:36:12 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
INFO - 2020-12-20 05:36:35 --> Config Class Initialized
INFO - 2020-12-20 05:36:35 --> Hooks Class Initialized
DEBUG - 2020-12-20 05:36:35 --> UTF-8 Support Enabled
INFO - 2020-12-20 05:36:35 --> Utf8 Class Initialized
INFO - 2020-12-20 05:36:35 --> URI Class Initialized
INFO - 2020-12-20 05:36:35 --> Router Class Initialized
INFO - 2020-12-20 05:36:35 --> Output Class Initialized
INFO - 2020-12-20 05:36:35 --> Security Class Initialized
DEBUG - 2020-12-20 05:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 05:36:35 --> Input Class Initialized
INFO - 2020-12-20 05:36:35 --> Language Class Initialized
INFO - 2020-12-20 05:36:35 --> Language Class Initialized
INFO - 2020-12-20 05:36:35 --> Config Class Initialized
INFO - 2020-12-20 05:36:35 --> Loader Class Initialized
INFO - 2020-12-20 05:36:35 --> Helper loaded: url_helper
INFO - 2020-12-20 05:36:35 --> Helper loaded: file_helper
INFO - 2020-12-20 05:36:35 --> Helper loaded: form_helper
INFO - 2020-12-20 05:36:35 --> Helper loaded: my_helper
INFO - 2020-12-20 05:36:35 --> Database Driver Class Initialized
DEBUG - 2020-12-20 05:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 05:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 05:36:35 --> Controller Class Initialized
ERROR - 2020-12-20 05:36:35 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:35 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:35 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:35 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:35 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:36 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:37 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:38 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:39 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:40 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:41 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:42 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:43 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:44 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:45 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:46 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:47 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:48 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:49 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:50 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:51 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:52 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 05:36:55 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
DEBUG - 2020-12-20 05:36:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 05:36:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 05:36:55 --> Final output sent to browser
DEBUG - 2020-12-20 05:36:56 --> Total execution time: 20.7516
INFO - 2020-12-20 06:07:47 --> Config Class Initialized
INFO - 2020-12-20 06:07:47 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:07:47 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:07:47 --> Utf8 Class Initialized
INFO - 2020-12-20 06:07:47 --> URI Class Initialized
INFO - 2020-12-20 06:07:47 --> Router Class Initialized
INFO - 2020-12-20 06:07:47 --> Output Class Initialized
INFO - 2020-12-20 06:07:47 --> Security Class Initialized
DEBUG - 2020-12-20 06:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:07:47 --> Input Class Initialized
INFO - 2020-12-20 06:07:47 --> Language Class Initialized
INFO - 2020-12-20 06:07:47 --> Language Class Initialized
INFO - 2020-12-20 06:07:47 --> Config Class Initialized
INFO - 2020-12-20 06:07:47 --> Loader Class Initialized
INFO - 2020-12-20 06:07:47 --> Helper loaded: url_helper
INFO - 2020-12-20 06:07:47 --> Helper loaded: file_helper
INFO - 2020-12-20 06:07:47 --> Helper loaded: form_helper
INFO - 2020-12-20 06:07:47 --> Helper loaded: my_helper
INFO - 2020-12-20 06:07:47 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:07:47 --> Controller Class Initialized
ERROR - 2020-12-20 06:07:47 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:47 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:47 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:48 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:49 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:50 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:51 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:52 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:53 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:54 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:55 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:56 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:57 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:58 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:07:59 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:00 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:03 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:04 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:05 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:06 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:07 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:10 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:11 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
DEBUG - 2020-12-20 06:08:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 06:08:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 06:08:11 --> Final output sent to browser
DEBUG - 2020-12-20 06:08:11 --> Total execution time: 24.8766
INFO - 2020-12-20 06:08:50 --> Config Class Initialized
INFO - 2020-12-20 06:08:50 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:08:50 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:08:50 --> Utf8 Class Initialized
INFO - 2020-12-20 06:08:50 --> URI Class Initialized
INFO - 2020-12-20 06:08:50 --> Router Class Initialized
INFO - 2020-12-20 06:08:50 --> Output Class Initialized
INFO - 2020-12-20 06:08:50 --> Security Class Initialized
DEBUG - 2020-12-20 06:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:08:51 --> Input Class Initialized
INFO - 2020-12-20 06:08:51 --> Language Class Initialized
INFO - 2020-12-20 06:08:51 --> Language Class Initialized
INFO - 2020-12-20 06:08:51 --> Config Class Initialized
INFO - 2020-12-20 06:08:51 --> Loader Class Initialized
INFO - 2020-12-20 06:08:51 --> Helper loaded: url_helper
INFO - 2020-12-20 06:08:51 --> Helper loaded: file_helper
INFO - 2020-12-20 06:08:51 --> Helper loaded: form_helper
INFO - 2020-12-20 06:08:51 --> Helper loaded: my_helper
INFO - 2020-12-20 06:08:51 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:08:51 --> Controller Class Initialized
ERROR - 2020-12-20 06:08:51 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:51 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:51 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:51 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:51 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:51 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:51 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:52 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:53 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:54 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:55 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:56 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:57 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:58 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:08:59 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:00 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:01 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:02 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:03 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:04 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:05 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:06 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:07 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:08 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:09 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:10 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:11 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:12 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:13 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:14 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:15 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant religius_ - assumed 'religius_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant nasionalis_ - assumed 'nasionalis_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant mandiri_ - assumed 'mandiri_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-20 06:09:16 --> Severity: Notice --> Use of undefined constant gotong_ - assumed 'gotong_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 94
DEBUG - 2020-12-20 06:09:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 06:09:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 06:09:17 --> Final output sent to browser
DEBUG - 2020-12-20 06:09:17 --> Total execution time: 26.4180
INFO - 2020-12-20 06:10:29 --> Config Class Initialized
INFO - 2020-12-20 06:10:29 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:10:29 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:10:30 --> Utf8 Class Initialized
INFO - 2020-12-20 06:10:30 --> URI Class Initialized
INFO - 2020-12-20 06:10:30 --> Router Class Initialized
INFO - 2020-12-20 06:10:30 --> Output Class Initialized
INFO - 2020-12-20 06:10:30 --> Security Class Initialized
DEBUG - 2020-12-20 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:10:30 --> Input Class Initialized
INFO - 2020-12-20 06:10:30 --> Language Class Initialized
INFO - 2020-12-20 06:10:30 --> Language Class Initialized
INFO - 2020-12-20 06:10:30 --> Config Class Initialized
INFO - 2020-12-20 06:10:30 --> Loader Class Initialized
INFO - 2020-12-20 06:10:30 --> Helper loaded: url_helper
INFO - 2020-12-20 06:10:30 --> Helper loaded: file_helper
INFO - 2020-12-20 06:10:30 --> Helper loaded: form_helper
INFO - 2020-12-20 06:10:30 --> Helper loaded: my_helper
INFO - 2020-12-20 06:10:30 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:10:30 --> Controller Class Initialized
DEBUG - 2020-12-20 06:10:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 06:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 06:10:31 --> Final output sent to browser
DEBUG - 2020-12-20 06:10:31 --> Total execution time: 1.1359
INFO - 2020-12-20 06:20:42 --> Config Class Initialized
INFO - 2020-12-20 06:20:42 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:20:42 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:20:42 --> Utf8 Class Initialized
INFO - 2020-12-20 06:20:42 --> URI Class Initialized
INFO - 2020-12-20 06:20:42 --> Router Class Initialized
INFO - 2020-12-20 06:20:43 --> Output Class Initialized
INFO - 2020-12-20 06:20:43 --> Security Class Initialized
DEBUG - 2020-12-20 06:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:20:43 --> Input Class Initialized
INFO - 2020-12-20 06:20:43 --> Language Class Initialized
INFO - 2020-12-20 06:20:43 --> Language Class Initialized
INFO - 2020-12-20 06:20:43 --> Config Class Initialized
INFO - 2020-12-20 06:20:43 --> Loader Class Initialized
INFO - 2020-12-20 06:20:43 --> Helper loaded: url_helper
INFO - 2020-12-20 06:20:43 --> Helper loaded: file_helper
INFO - 2020-12-20 06:20:43 --> Helper loaded: form_helper
INFO - 2020-12-20 06:20:43 --> Helper loaded: my_helper
INFO - 2020-12-20 06:20:43 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:20:43 --> Controller Class Initialized
DEBUG - 2020-12-20 06:20:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 06:20:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 06:20:44 --> Final output sent to browser
DEBUG - 2020-12-20 06:20:44 --> Total execution time: 1.2946
INFO - 2020-12-20 06:22:14 --> Config Class Initialized
INFO - 2020-12-20 06:22:14 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:22:14 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:22:14 --> Utf8 Class Initialized
INFO - 2020-12-20 06:22:14 --> URI Class Initialized
INFO - 2020-12-20 06:22:14 --> Router Class Initialized
INFO - 2020-12-20 06:22:14 --> Output Class Initialized
INFO - 2020-12-20 06:22:14 --> Security Class Initialized
DEBUG - 2020-12-20 06:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:22:14 --> Input Class Initialized
INFO - 2020-12-20 06:22:14 --> Language Class Initialized
INFO - 2020-12-20 06:22:14 --> Language Class Initialized
INFO - 2020-12-20 06:22:14 --> Config Class Initialized
INFO - 2020-12-20 06:22:14 --> Loader Class Initialized
INFO - 2020-12-20 06:22:14 --> Helper loaded: url_helper
INFO - 2020-12-20 06:22:14 --> Helper loaded: file_helper
INFO - 2020-12-20 06:22:15 --> Helper loaded: form_helper
INFO - 2020-12-20 06:22:15 --> Helper loaded: my_helper
INFO - 2020-12-20 06:22:15 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:22:15 --> Controller Class Initialized
ERROR - 2020-12-20 06:22:15 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-20 06:22:39 --> Config Class Initialized
INFO - 2020-12-20 06:22:39 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:22:39 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:22:39 --> Utf8 Class Initialized
INFO - 2020-12-20 06:22:39 --> URI Class Initialized
INFO - 2020-12-20 06:22:39 --> Router Class Initialized
INFO - 2020-12-20 06:22:39 --> Output Class Initialized
INFO - 2020-12-20 06:22:39 --> Security Class Initialized
DEBUG - 2020-12-20 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:22:39 --> Input Class Initialized
INFO - 2020-12-20 06:22:39 --> Language Class Initialized
INFO - 2020-12-20 06:22:39 --> Language Class Initialized
INFO - 2020-12-20 06:22:39 --> Config Class Initialized
INFO - 2020-12-20 06:22:39 --> Loader Class Initialized
INFO - 2020-12-20 06:22:39 --> Helper loaded: url_helper
INFO - 2020-12-20 06:22:39 --> Helper loaded: file_helper
INFO - 2020-12-20 06:22:40 --> Helper loaded: form_helper
INFO - 2020-12-20 06:22:40 --> Helper loaded: my_helper
INFO - 2020-12-20 06:22:40 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:22:40 --> Controller Class Initialized
ERROR - 2020-12-20 06:22:40 --> Severity: Parsing Error --> syntax error, unexpected '$religius' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-20 06:23:07 --> Config Class Initialized
INFO - 2020-12-20 06:23:07 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:23:07 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:23:07 --> Utf8 Class Initialized
INFO - 2020-12-20 06:23:07 --> URI Class Initialized
INFO - 2020-12-20 06:23:08 --> Router Class Initialized
INFO - 2020-12-20 06:23:08 --> Output Class Initialized
INFO - 2020-12-20 06:23:08 --> Security Class Initialized
DEBUG - 2020-12-20 06:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:23:08 --> Input Class Initialized
INFO - 2020-12-20 06:23:08 --> Language Class Initialized
INFO - 2020-12-20 06:23:08 --> Language Class Initialized
INFO - 2020-12-20 06:23:08 --> Config Class Initialized
INFO - 2020-12-20 06:23:08 --> Loader Class Initialized
INFO - 2020-12-20 06:23:08 --> Helper loaded: url_helper
INFO - 2020-12-20 06:23:08 --> Helper loaded: file_helper
INFO - 2020-12-20 06:23:08 --> Helper loaded: form_helper
INFO - 2020-12-20 06:23:08 --> Helper loaded: my_helper
INFO - 2020-12-20 06:23:08 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:23:08 --> Controller Class Initialized
ERROR - 2020-12-20 06:23:08 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-20 06:23:30 --> Config Class Initialized
INFO - 2020-12-20 06:23:30 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:23:30 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:23:30 --> Utf8 Class Initialized
INFO - 2020-12-20 06:23:30 --> URI Class Initialized
INFO - 2020-12-20 06:23:30 --> Router Class Initialized
INFO - 2020-12-20 06:23:30 --> Output Class Initialized
INFO - 2020-12-20 06:23:30 --> Security Class Initialized
DEBUG - 2020-12-20 06:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:23:30 --> Input Class Initialized
INFO - 2020-12-20 06:23:30 --> Language Class Initialized
INFO - 2020-12-20 06:23:30 --> Language Class Initialized
INFO - 2020-12-20 06:23:30 --> Config Class Initialized
INFO - 2020-12-20 06:23:30 --> Loader Class Initialized
INFO - 2020-12-20 06:23:30 --> Helper loaded: url_helper
INFO - 2020-12-20 06:23:31 --> Helper loaded: file_helper
INFO - 2020-12-20 06:23:31 --> Helper loaded: form_helper
INFO - 2020-12-20 06:23:31 --> Helper loaded: my_helper
INFO - 2020-12-20 06:23:31 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:23:31 --> Controller Class Initialized
ERROR - 2020-12-20 06:23:31 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-20 06:26:40 --> Config Class Initialized
INFO - 2020-12-20 06:26:40 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:26:40 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:26:40 --> Utf8 Class Initialized
INFO - 2020-12-20 06:26:40 --> URI Class Initialized
INFO - 2020-12-20 06:26:40 --> Router Class Initialized
INFO - 2020-12-20 06:26:41 --> Output Class Initialized
INFO - 2020-12-20 06:26:41 --> Security Class Initialized
DEBUG - 2020-12-20 06:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:26:41 --> Input Class Initialized
INFO - 2020-12-20 06:26:41 --> Language Class Initialized
INFO - 2020-12-20 06:26:41 --> Language Class Initialized
INFO - 2020-12-20 06:26:41 --> Config Class Initialized
INFO - 2020-12-20 06:26:41 --> Loader Class Initialized
INFO - 2020-12-20 06:26:41 --> Helper loaded: url_helper
INFO - 2020-12-20 06:26:41 --> Helper loaded: file_helper
INFO - 2020-12-20 06:26:41 --> Helper loaded: form_helper
INFO - 2020-12-20 06:26:41 --> Helper loaded: my_helper
INFO - 2020-12-20 06:26:41 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:26:41 --> Controller Class Initialized
ERROR - 2020-12-20 06:26:41 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-20 06:27:00 --> Config Class Initialized
INFO - 2020-12-20 06:27:00 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:27:00 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:27:00 --> Utf8 Class Initialized
INFO - 2020-12-20 06:27:00 --> URI Class Initialized
INFO - 2020-12-20 06:27:00 --> Router Class Initialized
INFO - 2020-12-20 06:27:00 --> Output Class Initialized
INFO - 2020-12-20 06:27:00 --> Security Class Initialized
DEBUG - 2020-12-20 06:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:27:00 --> Input Class Initialized
INFO - 2020-12-20 06:27:00 --> Language Class Initialized
INFO - 2020-12-20 06:27:00 --> Language Class Initialized
INFO - 2020-12-20 06:27:00 --> Config Class Initialized
INFO - 2020-12-20 06:27:01 --> Loader Class Initialized
INFO - 2020-12-20 06:27:01 --> Helper loaded: url_helper
INFO - 2020-12-20 06:27:01 --> Helper loaded: file_helper
INFO - 2020-12-20 06:27:01 --> Helper loaded: form_helper
INFO - 2020-12-20 06:27:01 --> Helper loaded: my_helper
INFO - 2020-12-20 06:27:01 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:27:01 --> Controller Class Initialized
ERROR - 2020-12-20 06:27:01 --> Severity: Parsing Error --> syntax error, unexpected '"religius_"' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-20 06:27:32 --> Config Class Initialized
INFO - 2020-12-20 06:27:32 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:27:32 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:27:32 --> Utf8 Class Initialized
INFO - 2020-12-20 06:27:32 --> URI Class Initialized
INFO - 2020-12-20 06:27:32 --> Router Class Initialized
INFO - 2020-12-20 06:27:32 --> Output Class Initialized
INFO - 2020-12-20 06:27:32 --> Security Class Initialized
DEBUG - 2020-12-20 06:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:27:32 --> Input Class Initialized
INFO - 2020-12-20 06:27:32 --> Language Class Initialized
INFO - 2020-12-20 06:27:32 --> Language Class Initialized
INFO - 2020-12-20 06:27:32 --> Config Class Initialized
INFO - 2020-12-20 06:27:32 --> Loader Class Initialized
INFO - 2020-12-20 06:27:32 --> Helper loaded: url_helper
INFO - 2020-12-20 06:27:32 --> Helper loaded: file_helper
INFO - 2020-12-20 06:27:32 --> Helper loaded: form_helper
INFO - 2020-12-20 06:27:32 --> Helper loaded: my_helper
INFO - 2020-12-20 06:27:32 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:27:32 --> Controller Class Initialized
ERROR - 2020-12-20 06:27:32 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
INFO - 2020-12-20 06:27:44 --> Config Class Initialized
INFO - 2020-12-20 06:27:44 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:27:44 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:27:44 --> Utf8 Class Initialized
INFO - 2020-12-20 06:27:44 --> URI Class Initialized
INFO - 2020-12-20 06:27:44 --> Router Class Initialized
INFO - 2020-12-20 06:27:44 --> Output Class Initialized
INFO - 2020-12-20 06:27:44 --> Security Class Initialized
DEBUG - 2020-12-20 06:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:27:44 --> Input Class Initialized
INFO - 2020-12-20 06:27:44 --> Language Class Initialized
INFO - 2020-12-20 06:27:44 --> Language Class Initialized
INFO - 2020-12-20 06:27:44 --> Config Class Initialized
INFO - 2020-12-20 06:27:44 --> Loader Class Initialized
INFO - 2020-12-20 06:27:44 --> Helper loaded: url_helper
INFO - 2020-12-20 06:27:44 --> Helper loaded: file_helper
INFO - 2020-12-20 06:27:44 --> Helper loaded: form_helper
INFO - 2020-12-20 06:27:44 --> Helper loaded: my_helper
INFO - 2020-12-20 06:27:44 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:27:45 --> Controller Class Initialized
ERROR - 2020-12-20 06:27:45 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
INFO - 2020-12-20 06:28:19 --> Config Class Initialized
INFO - 2020-12-20 06:28:19 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:28:20 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:28:20 --> Utf8 Class Initialized
INFO - 2020-12-20 06:28:20 --> URI Class Initialized
INFO - 2020-12-20 06:28:20 --> Router Class Initialized
INFO - 2020-12-20 06:28:20 --> Output Class Initialized
INFO - 2020-12-20 06:28:20 --> Security Class Initialized
DEBUG - 2020-12-20 06:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:28:20 --> Input Class Initialized
INFO - 2020-12-20 06:28:20 --> Language Class Initialized
INFO - 2020-12-20 06:28:20 --> Language Class Initialized
INFO - 2020-12-20 06:28:20 --> Config Class Initialized
INFO - 2020-12-20 06:28:20 --> Loader Class Initialized
INFO - 2020-12-20 06:28:20 --> Helper loaded: url_helper
INFO - 2020-12-20 06:28:20 --> Helper loaded: file_helper
INFO - 2020-12-20 06:28:20 --> Helper loaded: form_helper
INFO - 2020-12-20 06:28:20 --> Helper loaded: my_helper
INFO - 2020-12-20 06:28:20 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:28:21 --> Controller Class Initialized
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:21 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-20 06:28:22 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
DEBUG - 2020-12-20 06:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 06:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 06:28:23 --> Final output sent to browser
DEBUG - 2020-12-20 06:28:23 --> Total execution time: 3.0832
INFO - 2020-12-20 06:29:58 --> Config Class Initialized
INFO - 2020-12-20 06:29:58 --> Hooks Class Initialized
DEBUG - 2020-12-20 06:29:58 --> UTF-8 Support Enabled
INFO - 2020-12-20 06:29:58 --> Utf8 Class Initialized
INFO - 2020-12-20 06:29:58 --> URI Class Initialized
INFO - 2020-12-20 06:29:58 --> Router Class Initialized
INFO - 2020-12-20 06:29:58 --> Output Class Initialized
INFO - 2020-12-20 06:29:58 --> Security Class Initialized
DEBUG - 2020-12-20 06:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-20 06:29:58 --> Input Class Initialized
INFO - 2020-12-20 06:29:58 --> Language Class Initialized
INFO - 2020-12-20 06:29:58 --> Language Class Initialized
INFO - 2020-12-20 06:29:58 --> Config Class Initialized
INFO - 2020-12-20 06:29:58 --> Loader Class Initialized
INFO - 2020-12-20 06:29:58 --> Helper loaded: url_helper
INFO - 2020-12-20 06:29:58 --> Helper loaded: file_helper
INFO - 2020-12-20 06:29:59 --> Helper loaded: form_helper
INFO - 2020-12-20 06:29:59 --> Helper loaded: my_helper
INFO - 2020-12-20 06:29:59 --> Database Driver Class Initialized
DEBUG - 2020-12-20 06:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-20 06:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-20 06:29:59 --> Controller Class Initialized
DEBUG - 2020-12-20 06:29:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-20 06:29:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-20 06:29:59 --> Final output sent to browser
DEBUG - 2020-12-20 06:29:59 --> Total execution time: 1.1750
