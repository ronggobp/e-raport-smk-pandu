<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-02 05:36:31 --> Config Class Initialized
INFO - 2021-06-02 05:36:31 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:36:31 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:36:31 --> Utf8 Class Initialized
INFO - 2021-06-02 05:36:31 --> URI Class Initialized
DEBUG - 2021-06-02 05:36:31 --> No URI present. Default controller set.
INFO - 2021-06-02 05:36:31 --> Router Class Initialized
INFO - 2021-06-02 05:36:31 --> Output Class Initialized
INFO - 2021-06-02 05:36:31 --> Security Class Initialized
DEBUG - 2021-06-02 05:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:36:31 --> Input Class Initialized
INFO - 2021-06-02 05:36:31 --> Language Class Initialized
INFO - 2021-06-02 05:36:32 --> Language Class Initialized
INFO - 2021-06-02 05:36:32 --> Config Class Initialized
INFO - 2021-06-02 05:36:32 --> Loader Class Initialized
INFO - 2021-06-02 05:36:32 --> Helper loaded: url_helper
INFO - 2021-06-02 05:36:32 --> Helper loaded: file_helper
INFO - 2021-06-02 05:36:32 --> Helper loaded: form_helper
INFO - 2021-06-02 05:36:32 --> Helper loaded: my_helper
INFO - 2021-06-02 05:36:32 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:36:32 --> Controller Class Initialized
INFO - 2021-06-02 05:36:32 --> Config Class Initialized
INFO - 2021-06-02 05:36:32 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:36:32 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:36:32 --> Utf8 Class Initialized
INFO - 2021-06-02 05:36:32 --> URI Class Initialized
INFO - 2021-06-02 05:36:32 --> Router Class Initialized
INFO - 2021-06-02 05:36:32 --> Output Class Initialized
INFO - 2021-06-02 05:36:32 --> Security Class Initialized
DEBUG - 2021-06-02 05:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:36:32 --> Input Class Initialized
INFO - 2021-06-02 05:36:32 --> Language Class Initialized
INFO - 2021-06-02 05:36:32 --> Language Class Initialized
INFO - 2021-06-02 05:36:32 --> Config Class Initialized
INFO - 2021-06-02 05:36:32 --> Loader Class Initialized
INFO - 2021-06-02 05:36:32 --> Helper loaded: url_helper
INFO - 2021-06-02 05:36:32 --> Helper loaded: file_helper
INFO - 2021-06-02 05:36:32 --> Helper loaded: form_helper
INFO - 2021-06-02 05:36:32 --> Helper loaded: my_helper
INFO - 2021-06-02 05:36:32 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:36:32 --> Controller Class Initialized
DEBUG - 2021-06-02 05:36:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-02 05:36:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 05:36:32 --> Final output sent to browser
DEBUG - 2021-06-02 05:36:32 --> Total execution time: 0.1130
INFO - 2021-06-02 05:36:40 --> Config Class Initialized
INFO - 2021-06-02 05:36:40 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:36:40 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:36:40 --> Utf8 Class Initialized
INFO - 2021-06-02 05:36:40 --> URI Class Initialized
INFO - 2021-06-02 05:36:40 --> Router Class Initialized
INFO - 2021-06-02 05:36:40 --> Output Class Initialized
INFO - 2021-06-02 05:36:40 --> Security Class Initialized
DEBUG - 2021-06-02 05:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:36:40 --> Input Class Initialized
INFO - 2021-06-02 05:36:40 --> Language Class Initialized
INFO - 2021-06-02 05:36:40 --> Language Class Initialized
INFO - 2021-06-02 05:36:40 --> Config Class Initialized
INFO - 2021-06-02 05:36:40 --> Loader Class Initialized
INFO - 2021-06-02 05:36:40 --> Helper loaded: url_helper
INFO - 2021-06-02 05:36:40 --> Helper loaded: file_helper
INFO - 2021-06-02 05:36:40 --> Helper loaded: form_helper
INFO - 2021-06-02 05:36:40 --> Helper loaded: my_helper
INFO - 2021-06-02 05:36:40 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:36:40 --> Controller Class Initialized
INFO - 2021-06-02 05:36:40 --> Helper loaded: cookie_helper
INFO - 2021-06-02 05:36:40 --> Final output sent to browser
DEBUG - 2021-06-02 05:36:40 --> Total execution time: 0.1892
INFO - 2021-06-02 05:36:40 --> Config Class Initialized
INFO - 2021-06-02 05:36:40 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:36:40 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:36:40 --> Utf8 Class Initialized
INFO - 2021-06-02 05:36:40 --> URI Class Initialized
INFO - 2021-06-02 05:36:40 --> Router Class Initialized
INFO - 2021-06-02 05:36:40 --> Output Class Initialized
INFO - 2021-06-02 05:36:40 --> Security Class Initialized
DEBUG - 2021-06-02 05:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:36:40 --> Input Class Initialized
INFO - 2021-06-02 05:36:40 --> Language Class Initialized
INFO - 2021-06-02 05:36:40 --> Language Class Initialized
INFO - 2021-06-02 05:36:40 --> Config Class Initialized
INFO - 2021-06-02 05:36:40 --> Loader Class Initialized
INFO - 2021-06-02 05:36:40 --> Helper loaded: url_helper
INFO - 2021-06-02 05:36:40 --> Helper loaded: file_helper
INFO - 2021-06-02 05:36:40 --> Helper loaded: form_helper
INFO - 2021-06-02 05:36:40 --> Helper loaded: my_helper
INFO - 2021-06-02 05:36:40 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:36:40 --> Controller Class Initialized
DEBUG - 2021-06-02 05:36:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-02 05:36:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 05:36:41 --> Final output sent to browser
DEBUG - 2021-06-02 05:36:41 --> Total execution time: 0.3637
INFO - 2021-06-02 05:36:44 --> Config Class Initialized
INFO - 2021-06-02 05:36:44 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:36:44 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:36:44 --> Utf8 Class Initialized
INFO - 2021-06-02 05:36:44 --> URI Class Initialized
INFO - 2021-06-02 05:36:44 --> Router Class Initialized
INFO - 2021-06-02 05:36:44 --> Output Class Initialized
INFO - 2021-06-02 05:36:44 --> Security Class Initialized
DEBUG - 2021-06-02 05:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:36:44 --> Input Class Initialized
INFO - 2021-06-02 05:36:44 --> Language Class Initialized
INFO - 2021-06-02 05:36:44 --> Language Class Initialized
INFO - 2021-06-02 05:36:44 --> Config Class Initialized
INFO - 2021-06-02 05:36:44 --> Loader Class Initialized
INFO - 2021-06-02 05:36:44 --> Helper loaded: url_helper
INFO - 2021-06-02 05:36:44 --> Helper loaded: file_helper
INFO - 2021-06-02 05:36:44 --> Helper loaded: form_helper
INFO - 2021-06-02 05:36:44 --> Helper loaded: my_helper
INFO - 2021-06-02 05:36:44 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:36:44 --> Controller Class Initialized
INFO - 2021-06-02 05:36:44 --> Helper loaded: cookie_helper
INFO - 2021-06-02 05:36:44 --> Config Class Initialized
INFO - 2021-06-02 05:36:44 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:36:44 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:36:44 --> Utf8 Class Initialized
INFO - 2021-06-02 05:36:44 --> URI Class Initialized
INFO - 2021-06-02 05:36:44 --> Router Class Initialized
INFO - 2021-06-02 05:36:44 --> Output Class Initialized
INFO - 2021-06-02 05:36:44 --> Security Class Initialized
DEBUG - 2021-06-02 05:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:36:44 --> Input Class Initialized
INFO - 2021-06-02 05:36:44 --> Language Class Initialized
INFO - 2021-06-02 05:36:44 --> Language Class Initialized
INFO - 2021-06-02 05:36:44 --> Config Class Initialized
INFO - 2021-06-02 05:36:44 --> Loader Class Initialized
INFO - 2021-06-02 05:36:44 --> Helper loaded: url_helper
INFO - 2021-06-02 05:36:44 --> Helper loaded: file_helper
INFO - 2021-06-02 05:36:44 --> Helper loaded: form_helper
INFO - 2021-06-02 05:36:44 --> Helper loaded: my_helper
INFO - 2021-06-02 05:36:44 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:36:44 --> Controller Class Initialized
DEBUG - 2021-06-02 05:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-02 05:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 05:36:44 --> Final output sent to browser
DEBUG - 2021-06-02 05:36:44 --> Total execution time: 0.0723
INFO - 2021-06-02 05:36:53 --> Config Class Initialized
INFO - 2021-06-02 05:36:53 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:36:53 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:36:53 --> Utf8 Class Initialized
INFO - 2021-06-02 05:36:53 --> URI Class Initialized
INFO - 2021-06-02 05:36:53 --> Router Class Initialized
INFO - 2021-06-02 05:36:53 --> Output Class Initialized
INFO - 2021-06-02 05:36:53 --> Security Class Initialized
DEBUG - 2021-06-02 05:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:36:53 --> Input Class Initialized
INFO - 2021-06-02 05:36:53 --> Language Class Initialized
INFO - 2021-06-02 05:36:53 --> Language Class Initialized
INFO - 2021-06-02 05:36:53 --> Config Class Initialized
INFO - 2021-06-02 05:36:53 --> Loader Class Initialized
INFO - 2021-06-02 05:36:53 --> Helper loaded: url_helper
INFO - 2021-06-02 05:36:53 --> Helper loaded: file_helper
INFO - 2021-06-02 05:36:53 --> Helper loaded: form_helper
INFO - 2021-06-02 05:36:53 --> Helper loaded: my_helper
INFO - 2021-06-02 05:36:53 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:36:53 --> Controller Class Initialized
INFO - 2021-06-02 05:36:53 --> Helper loaded: cookie_helper
INFO - 2021-06-02 05:36:53 --> Final output sent to browser
DEBUG - 2021-06-02 05:36:53 --> Total execution time: 0.1256
INFO - 2021-06-02 05:36:54 --> Config Class Initialized
INFO - 2021-06-02 05:36:54 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:36:54 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:36:54 --> Utf8 Class Initialized
INFO - 2021-06-02 05:36:54 --> URI Class Initialized
INFO - 2021-06-02 05:36:54 --> Router Class Initialized
INFO - 2021-06-02 05:36:54 --> Output Class Initialized
INFO - 2021-06-02 05:36:54 --> Security Class Initialized
DEBUG - 2021-06-02 05:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:36:54 --> Input Class Initialized
INFO - 2021-06-02 05:36:54 --> Language Class Initialized
INFO - 2021-06-02 05:36:54 --> Language Class Initialized
INFO - 2021-06-02 05:36:54 --> Config Class Initialized
INFO - 2021-06-02 05:36:54 --> Loader Class Initialized
INFO - 2021-06-02 05:36:54 --> Helper loaded: url_helper
INFO - 2021-06-02 05:36:54 --> Helper loaded: file_helper
INFO - 2021-06-02 05:36:54 --> Helper loaded: form_helper
INFO - 2021-06-02 05:36:54 --> Helper loaded: my_helper
INFO - 2021-06-02 05:36:54 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:36:54 --> Controller Class Initialized
DEBUG - 2021-06-02 05:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-02 05:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 05:36:54 --> Final output sent to browser
DEBUG - 2021-06-02 05:36:54 --> Total execution time: 0.1232
INFO - 2021-06-02 05:36:56 --> Config Class Initialized
INFO - 2021-06-02 05:36:56 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:36:56 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:36:56 --> Utf8 Class Initialized
INFO - 2021-06-02 05:36:56 --> URI Class Initialized
INFO - 2021-06-02 05:36:56 --> Router Class Initialized
INFO - 2021-06-02 05:36:56 --> Output Class Initialized
INFO - 2021-06-02 05:36:56 --> Security Class Initialized
DEBUG - 2021-06-02 05:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:36:56 --> Input Class Initialized
INFO - 2021-06-02 05:36:56 --> Language Class Initialized
INFO - 2021-06-02 05:36:56 --> Language Class Initialized
INFO - 2021-06-02 05:36:56 --> Config Class Initialized
INFO - 2021-06-02 05:36:56 --> Loader Class Initialized
INFO - 2021-06-02 05:36:57 --> Helper loaded: url_helper
INFO - 2021-06-02 05:36:57 --> Helper loaded: file_helper
INFO - 2021-06-02 05:36:57 --> Helper loaded: form_helper
INFO - 2021-06-02 05:36:57 --> Helper loaded: my_helper
INFO - 2021-06-02 05:36:57 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:36:57 --> Controller Class Initialized
DEBUG - 2021-06-02 05:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-02 05:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 05:36:57 --> Final output sent to browser
DEBUG - 2021-06-02 05:36:57 --> Total execution time: 0.3997
INFO - 2021-06-02 05:37:01 --> Config Class Initialized
INFO - 2021-06-02 05:37:01 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:37:01 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:37:01 --> Utf8 Class Initialized
INFO - 2021-06-02 05:37:01 --> URI Class Initialized
DEBUG - 2021-06-02 05:37:01 --> No URI present. Default controller set.
INFO - 2021-06-02 05:37:01 --> Router Class Initialized
INFO - 2021-06-02 05:37:01 --> Output Class Initialized
INFO - 2021-06-02 05:37:01 --> Security Class Initialized
DEBUG - 2021-06-02 05:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:37:01 --> Input Class Initialized
INFO - 2021-06-02 05:37:01 --> Language Class Initialized
INFO - 2021-06-02 05:37:01 --> Language Class Initialized
INFO - 2021-06-02 05:37:01 --> Config Class Initialized
INFO - 2021-06-02 05:37:01 --> Loader Class Initialized
INFO - 2021-06-02 05:37:01 --> Helper loaded: url_helper
INFO - 2021-06-02 05:37:01 --> Helper loaded: file_helper
INFO - 2021-06-02 05:37:01 --> Helper loaded: form_helper
INFO - 2021-06-02 05:37:01 --> Helper loaded: my_helper
INFO - 2021-06-02 05:37:01 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:37:01 --> Controller Class Initialized
DEBUG - 2021-06-02 05:37:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-02 05:37:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 05:37:01 --> Final output sent to browser
DEBUG - 2021-06-02 05:37:01 --> Total execution time: 0.2005
INFO - 2021-06-02 05:37:04 --> Config Class Initialized
INFO - 2021-06-02 05:37:04 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:37:04 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:37:04 --> Utf8 Class Initialized
INFO - 2021-06-02 05:37:04 --> URI Class Initialized
INFO - 2021-06-02 05:37:04 --> Router Class Initialized
INFO - 2021-06-02 05:37:04 --> Output Class Initialized
INFO - 2021-06-02 05:37:04 --> Security Class Initialized
DEBUG - 2021-06-02 05:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:37:04 --> Input Class Initialized
INFO - 2021-06-02 05:37:04 --> Language Class Initialized
INFO - 2021-06-02 05:37:04 --> Language Class Initialized
INFO - 2021-06-02 05:37:04 --> Config Class Initialized
INFO - 2021-06-02 05:37:04 --> Loader Class Initialized
INFO - 2021-06-02 05:37:04 --> Helper loaded: url_helper
INFO - 2021-06-02 05:37:04 --> Helper loaded: file_helper
INFO - 2021-06-02 05:37:04 --> Helper loaded: form_helper
INFO - 2021-06-02 05:37:04 --> Helper loaded: my_helper
INFO - 2021-06-02 05:37:04 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:37:04 --> Controller Class Initialized
DEBUG - 2021-06-02 05:37:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-02 05:37:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 05:37:04 --> Final output sent to browser
DEBUG - 2021-06-02 05:37:04 --> Total execution time: 0.2109
INFO - 2021-06-02 05:37:06 --> Config Class Initialized
INFO - 2021-06-02 05:37:06 --> Hooks Class Initialized
DEBUG - 2021-06-02 05:37:06 --> UTF-8 Support Enabled
INFO - 2021-06-02 05:37:06 --> Utf8 Class Initialized
INFO - 2021-06-02 05:37:06 --> URI Class Initialized
INFO - 2021-06-02 05:37:06 --> Router Class Initialized
INFO - 2021-06-02 05:37:06 --> Output Class Initialized
INFO - 2021-06-02 05:37:06 --> Security Class Initialized
DEBUG - 2021-06-02 05:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 05:37:06 --> Input Class Initialized
INFO - 2021-06-02 05:37:06 --> Language Class Initialized
INFO - 2021-06-02 05:37:06 --> Language Class Initialized
INFO - 2021-06-02 05:37:06 --> Config Class Initialized
INFO - 2021-06-02 05:37:06 --> Loader Class Initialized
INFO - 2021-06-02 05:37:06 --> Helper loaded: url_helper
INFO - 2021-06-02 05:37:06 --> Helper loaded: file_helper
INFO - 2021-06-02 05:37:06 --> Helper loaded: form_helper
INFO - 2021-06-02 05:37:06 --> Helper loaded: my_helper
INFO - 2021-06-02 05:37:06 --> Database Driver Class Initialized
DEBUG - 2021-06-02 05:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 05:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 05:37:06 --> Controller Class Initialized
DEBUG - 2021-06-02 05:37:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 05:37:07 --> Final output sent to browser
DEBUG - 2021-06-02 05:37:07 --> Total execution time: 0.6586
INFO - 2021-06-02 06:41:32 --> Config Class Initialized
INFO - 2021-06-02 06:41:32 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:41:32 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:41:32 --> Utf8 Class Initialized
INFO - 2021-06-02 06:41:32 --> URI Class Initialized
INFO - 2021-06-02 06:41:32 --> Router Class Initialized
INFO - 2021-06-02 06:41:32 --> Output Class Initialized
INFO - 2021-06-02 06:41:32 --> Security Class Initialized
DEBUG - 2021-06-02 06:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:41:32 --> Input Class Initialized
INFO - 2021-06-02 06:41:32 --> Language Class Initialized
INFO - 2021-06-02 06:41:33 --> Language Class Initialized
INFO - 2021-06-02 06:41:33 --> Config Class Initialized
INFO - 2021-06-02 06:41:33 --> Loader Class Initialized
INFO - 2021-06-02 06:41:33 --> Helper loaded: url_helper
INFO - 2021-06-02 06:41:33 --> Helper loaded: file_helper
INFO - 2021-06-02 06:41:33 --> Helper loaded: form_helper
INFO - 2021-06-02 06:41:33 --> Helper loaded: my_helper
INFO - 2021-06-02 06:41:33 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:41:33 --> Controller Class Initialized
DEBUG - 2021-06-02 06:41:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:41:34 --> Final output sent to browser
DEBUG - 2021-06-02 06:41:34 --> Total execution time: 1.9086
INFO - 2021-06-02 06:41:44 --> Config Class Initialized
INFO - 2021-06-02 06:41:44 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:41:44 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:41:44 --> Utf8 Class Initialized
INFO - 2021-06-02 06:41:44 --> URI Class Initialized
INFO - 2021-06-02 06:41:44 --> Router Class Initialized
INFO - 2021-06-02 06:41:44 --> Output Class Initialized
INFO - 2021-06-02 06:41:44 --> Security Class Initialized
DEBUG - 2021-06-02 06:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:41:44 --> Input Class Initialized
INFO - 2021-06-02 06:41:44 --> Language Class Initialized
INFO - 2021-06-02 06:41:44 --> Language Class Initialized
INFO - 2021-06-02 06:41:44 --> Config Class Initialized
INFO - 2021-06-02 06:41:44 --> Loader Class Initialized
INFO - 2021-06-02 06:41:44 --> Helper loaded: url_helper
INFO - 2021-06-02 06:41:44 --> Helper loaded: file_helper
INFO - 2021-06-02 06:41:44 --> Helper loaded: form_helper
INFO - 2021-06-02 06:41:44 --> Helper loaded: my_helper
INFO - 2021-06-02 06:41:44 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:41:44 --> Controller Class Initialized
DEBUG - 2021-06-02 06:41:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:41:44 --> Final output sent to browser
DEBUG - 2021-06-02 06:41:44 --> Total execution time: 0.1285
INFO - 2021-06-02 06:41:45 --> Config Class Initialized
INFO - 2021-06-02 06:41:45 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:41:45 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:41:45 --> Utf8 Class Initialized
INFO - 2021-06-02 06:41:45 --> URI Class Initialized
INFO - 2021-06-02 06:41:45 --> Router Class Initialized
INFO - 2021-06-02 06:41:45 --> Output Class Initialized
INFO - 2021-06-02 06:41:45 --> Security Class Initialized
DEBUG - 2021-06-02 06:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:41:45 --> Input Class Initialized
INFO - 2021-06-02 06:41:45 --> Language Class Initialized
INFO - 2021-06-02 06:41:45 --> Language Class Initialized
INFO - 2021-06-02 06:41:45 --> Config Class Initialized
INFO - 2021-06-02 06:41:45 --> Loader Class Initialized
INFO - 2021-06-02 06:41:45 --> Helper loaded: url_helper
INFO - 2021-06-02 06:41:45 --> Helper loaded: file_helper
INFO - 2021-06-02 06:41:45 --> Helper loaded: form_helper
INFO - 2021-06-02 06:41:45 --> Helper loaded: my_helper
INFO - 2021-06-02 06:41:45 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:41:46 --> Controller Class Initialized
DEBUG - 2021-06-02 06:41:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:41:46 --> Final output sent to browser
DEBUG - 2021-06-02 06:41:46 --> Total execution time: 0.1315
INFO - 2021-06-02 06:42:13 --> Config Class Initialized
INFO - 2021-06-02 06:42:13 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:42:13 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:42:13 --> Utf8 Class Initialized
INFO - 2021-06-02 06:42:13 --> URI Class Initialized
INFO - 2021-06-02 06:42:13 --> Router Class Initialized
INFO - 2021-06-02 06:42:13 --> Output Class Initialized
INFO - 2021-06-02 06:42:13 --> Security Class Initialized
DEBUG - 2021-06-02 06:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:42:13 --> Input Class Initialized
INFO - 2021-06-02 06:42:13 --> Language Class Initialized
INFO - 2021-06-02 06:42:13 --> Language Class Initialized
INFO - 2021-06-02 06:42:13 --> Config Class Initialized
INFO - 2021-06-02 06:42:13 --> Loader Class Initialized
INFO - 2021-06-02 06:42:13 --> Helper loaded: url_helper
INFO - 2021-06-02 06:42:13 --> Helper loaded: file_helper
INFO - 2021-06-02 06:42:13 --> Helper loaded: form_helper
INFO - 2021-06-02 06:42:13 --> Helper loaded: my_helper
INFO - 2021-06-02 06:42:13 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:42:13 --> Controller Class Initialized
DEBUG - 2021-06-02 06:42:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:42:13 --> Final output sent to browser
DEBUG - 2021-06-02 06:42:13 --> Total execution time: 0.0921
INFO - 2021-06-02 06:42:14 --> Config Class Initialized
INFO - 2021-06-02 06:42:14 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:42:14 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:42:14 --> Utf8 Class Initialized
INFO - 2021-06-02 06:42:14 --> URI Class Initialized
INFO - 2021-06-02 06:42:14 --> Router Class Initialized
INFO - 2021-06-02 06:42:14 --> Output Class Initialized
INFO - 2021-06-02 06:42:14 --> Security Class Initialized
DEBUG - 2021-06-02 06:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:42:14 --> Input Class Initialized
INFO - 2021-06-02 06:42:14 --> Language Class Initialized
INFO - 2021-06-02 06:42:14 --> Language Class Initialized
INFO - 2021-06-02 06:42:14 --> Config Class Initialized
INFO - 2021-06-02 06:42:14 --> Loader Class Initialized
INFO - 2021-06-02 06:42:14 --> Helper loaded: url_helper
INFO - 2021-06-02 06:42:14 --> Helper loaded: file_helper
INFO - 2021-06-02 06:42:14 --> Helper loaded: form_helper
INFO - 2021-06-02 06:42:14 --> Helper loaded: my_helper
INFO - 2021-06-02 06:42:14 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:42:14 --> Controller Class Initialized
DEBUG - 2021-06-02 06:42:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:42:14 --> Final output sent to browser
DEBUG - 2021-06-02 06:42:14 --> Total execution time: 0.1500
INFO - 2021-06-02 06:42:39 --> Config Class Initialized
INFO - 2021-06-02 06:42:39 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:42:39 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:42:39 --> Utf8 Class Initialized
INFO - 2021-06-02 06:42:39 --> URI Class Initialized
INFO - 2021-06-02 06:42:39 --> Router Class Initialized
INFO - 2021-06-02 06:42:39 --> Output Class Initialized
INFO - 2021-06-02 06:42:39 --> Security Class Initialized
DEBUG - 2021-06-02 06:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:42:39 --> Input Class Initialized
INFO - 2021-06-02 06:42:39 --> Language Class Initialized
INFO - 2021-06-02 06:42:39 --> Language Class Initialized
INFO - 2021-06-02 06:42:39 --> Config Class Initialized
INFO - 2021-06-02 06:42:39 --> Loader Class Initialized
INFO - 2021-06-02 06:42:39 --> Helper loaded: url_helper
INFO - 2021-06-02 06:42:39 --> Helper loaded: file_helper
INFO - 2021-06-02 06:42:39 --> Helper loaded: form_helper
INFO - 2021-06-02 06:42:39 --> Helper loaded: my_helper
INFO - 2021-06-02 06:42:39 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:42:39 --> Controller Class Initialized
DEBUG - 2021-06-02 06:42:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:42:39 --> Final output sent to browser
DEBUG - 2021-06-02 06:42:39 --> Total execution time: 0.1029
INFO - 2021-06-02 06:43:51 --> Config Class Initialized
INFO - 2021-06-02 06:43:51 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:43:51 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:43:51 --> Utf8 Class Initialized
INFO - 2021-06-02 06:43:51 --> URI Class Initialized
INFO - 2021-06-02 06:43:51 --> Router Class Initialized
INFO - 2021-06-02 06:43:51 --> Output Class Initialized
INFO - 2021-06-02 06:43:51 --> Security Class Initialized
DEBUG - 2021-06-02 06:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:43:51 --> Input Class Initialized
INFO - 2021-06-02 06:43:51 --> Language Class Initialized
INFO - 2021-06-02 06:43:51 --> Language Class Initialized
INFO - 2021-06-02 06:43:51 --> Config Class Initialized
INFO - 2021-06-02 06:43:51 --> Loader Class Initialized
INFO - 2021-06-02 06:43:51 --> Helper loaded: url_helper
INFO - 2021-06-02 06:43:51 --> Helper loaded: file_helper
INFO - 2021-06-02 06:43:51 --> Helper loaded: form_helper
INFO - 2021-06-02 06:43:51 --> Helper loaded: my_helper
INFO - 2021-06-02 06:43:51 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:43:51 --> Controller Class Initialized
DEBUG - 2021-06-02 06:43:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:43:51 --> Final output sent to browser
DEBUG - 2021-06-02 06:43:51 --> Total execution time: 0.1334
INFO - 2021-06-02 06:43:52 --> Config Class Initialized
INFO - 2021-06-02 06:43:52 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:43:52 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:43:52 --> Utf8 Class Initialized
INFO - 2021-06-02 06:43:52 --> URI Class Initialized
INFO - 2021-06-02 06:43:52 --> Router Class Initialized
INFO - 2021-06-02 06:43:52 --> Output Class Initialized
INFO - 2021-06-02 06:43:52 --> Security Class Initialized
DEBUG - 2021-06-02 06:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:43:52 --> Input Class Initialized
INFO - 2021-06-02 06:43:52 --> Language Class Initialized
INFO - 2021-06-02 06:43:52 --> Language Class Initialized
INFO - 2021-06-02 06:43:52 --> Config Class Initialized
INFO - 2021-06-02 06:43:52 --> Loader Class Initialized
INFO - 2021-06-02 06:43:52 --> Helper loaded: url_helper
INFO - 2021-06-02 06:43:52 --> Helper loaded: file_helper
INFO - 2021-06-02 06:43:52 --> Helper loaded: form_helper
INFO - 2021-06-02 06:43:52 --> Helper loaded: my_helper
INFO - 2021-06-02 06:43:52 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:43:53 --> Controller Class Initialized
DEBUG - 2021-06-02 06:43:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:43:53 --> Final output sent to browser
DEBUG - 2021-06-02 06:43:53 --> Total execution time: 0.1323
INFO - 2021-06-02 06:44:06 --> Config Class Initialized
INFO - 2021-06-02 06:44:06 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:44:06 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:44:06 --> Utf8 Class Initialized
INFO - 2021-06-02 06:44:06 --> URI Class Initialized
INFO - 2021-06-02 06:44:06 --> Router Class Initialized
INFO - 2021-06-02 06:44:06 --> Output Class Initialized
INFO - 2021-06-02 06:44:06 --> Security Class Initialized
DEBUG - 2021-06-02 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:44:06 --> Input Class Initialized
INFO - 2021-06-02 06:44:06 --> Language Class Initialized
INFO - 2021-06-02 06:44:06 --> Language Class Initialized
INFO - 2021-06-02 06:44:06 --> Config Class Initialized
INFO - 2021-06-02 06:44:06 --> Loader Class Initialized
INFO - 2021-06-02 06:44:06 --> Helper loaded: url_helper
INFO - 2021-06-02 06:44:06 --> Helper loaded: file_helper
INFO - 2021-06-02 06:44:06 --> Helper loaded: form_helper
INFO - 2021-06-02 06:44:06 --> Helper loaded: my_helper
INFO - 2021-06-02 06:44:06 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:44:06 --> Controller Class Initialized
DEBUG - 2021-06-02 06:44:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:44:06 --> Final output sent to browser
DEBUG - 2021-06-02 06:44:06 --> Total execution time: 0.1861
INFO - 2021-06-02 06:44:07 --> Config Class Initialized
INFO - 2021-06-02 06:44:07 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:44:07 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:44:07 --> Utf8 Class Initialized
INFO - 2021-06-02 06:44:07 --> URI Class Initialized
INFO - 2021-06-02 06:44:07 --> Router Class Initialized
INFO - 2021-06-02 06:44:07 --> Output Class Initialized
INFO - 2021-06-02 06:44:07 --> Security Class Initialized
DEBUG - 2021-06-02 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:44:07 --> Input Class Initialized
INFO - 2021-06-02 06:44:07 --> Language Class Initialized
INFO - 2021-06-02 06:44:07 --> Language Class Initialized
INFO - 2021-06-02 06:44:07 --> Config Class Initialized
INFO - 2021-06-02 06:44:07 --> Loader Class Initialized
INFO - 2021-06-02 06:44:07 --> Helper loaded: url_helper
INFO - 2021-06-02 06:44:07 --> Helper loaded: file_helper
INFO - 2021-06-02 06:44:07 --> Helper loaded: form_helper
INFO - 2021-06-02 06:44:07 --> Helper loaded: my_helper
INFO - 2021-06-02 06:44:07 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:44:08 --> Controller Class Initialized
DEBUG - 2021-06-02 06:44:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:44:08 --> Final output sent to browser
DEBUG - 2021-06-02 06:44:08 --> Total execution time: 0.1380
INFO - 2021-06-02 06:44:42 --> Config Class Initialized
INFO - 2021-06-02 06:44:42 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:44:42 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:44:42 --> Utf8 Class Initialized
INFO - 2021-06-02 06:44:42 --> URI Class Initialized
INFO - 2021-06-02 06:44:42 --> Router Class Initialized
INFO - 2021-06-02 06:44:42 --> Output Class Initialized
INFO - 2021-06-02 06:44:42 --> Security Class Initialized
DEBUG - 2021-06-02 06:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:44:42 --> Input Class Initialized
INFO - 2021-06-02 06:44:42 --> Language Class Initialized
INFO - 2021-06-02 06:44:42 --> Language Class Initialized
INFO - 2021-06-02 06:44:42 --> Config Class Initialized
INFO - 2021-06-02 06:44:42 --> Loader Class Initialized
INFO - 2021-06-02 06:44:42 --> Helper loaded: url_helper
INFO - 2021-06-02 06:44:42 --> Helper loaded: file_helper
INFO - 2021-06-02 06:44:42 --> Helper loaded: form_helper
INFO - 2021-06-02 06:44:42 --> Helper loaded: my_helper
INFO - 2021-06-02 06:44:42 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:44:42 --> Controller Class Initialized
DEBUG - 2021-06-02 06:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:44:42 --> Final output sent to browser
DEBUG - 2021-06-02 06:44:42 --> Total execution time: 0.1165
INFO - 2021-06-02 06:46:27 --> Config Class Initialized
INFO - 2021-06-02 06:46:27 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:46:27 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:46:27 --> Utf8 Class Initialized
INFO - 2021-06-02 06:46:27 --> URI Class Initialized
INFO - 2021-06-02 06:46:27 --> Router Class Initialized
INFO - 2021-06-02 06:46:27 --> Output Class Initialized
INFO - 2021-06-02 06:46:27 --> Security Class Initialized
DEBUG - 2021-06-02 06:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:46:27 --> Input Class Initialized
INFO - 2021-06-02 06:46:27 --> Language Class Initialized
INFO - 2021-06-02 06:46:27 --> Language Class Initialized
INFO - 2021-06-02 06:46:27 --> Config Class Initialized
INFO - 2021-06-02 06:46:27 --> Loader Class Initialized
INFO - 2021-06-02 06:46:27 --> Helper loaded: url_helper
INFO - 2021-06-02 06:46:27 --> Helper loaded: file_helper
INFO - 2021-06-02 06:46:27 --> Helper loaded: form_helper
INFO - 2021-06-02 06:46:27 --> Helper loaded: my_helper
INFO - 2021-06-02 06:46:28 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:46:28 --> Controller Class Initialized
DEBUG - 2021-06-02 06:46:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:46:28 --> Final output sent to browser
DEBUG - 2021-06-02 06:46:28 --> Total execution time: 0.1272
INFO - 2021-06-02 06:46:40 --> Config Class Initialized
INFO - 2021-06-02 06:46:40 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:46:40 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:46:40 --> Utf8 Class Initialized
INFO - 2021-06-02 06:46:40 --> URI Class Initialized
INFO - 2021-06-02 06:46:40 --> Router Class Initialized
INFO - 2021-06-02 06:46:40 --> Output Class Initialized
INFO - 2021-06-02 06:46:40 --> Security Class Initialized
DEBUG - 2021-06-02 06:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:46:40 --> Input Class Initialized
INFO - 2021-06-02 06:46:40 --> Language Class Initialized
INFO - 2021-06-02 06:46:40 --> Language Class Initialized
INFO - 2021-06-02 06:46:40 --> Config Class Initialized
INFO - 2021-06-02 06:46:40 --> Loader Class Initialized
INFO - 2021-06-02 06:46:40 --> Helper loaded: url_helper
INFO - 2021-06-02 06:46:40 --> Helper loaded: file_helper
INFO - 2021-06-02 06:46:40 --> Helper loaded: form_helper
INFO - 2021-06-02 06:46:40 --> Helper loaded: my_helper
INFO - 2021-06-02 06:46:40 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:46:40 --> Controller Class Initialized
DEBUG - 2021-06-02 06:46:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:46:40 --> Final output sent to browser
DEBUG - 2021-06-02 06:46:40 --> Total execution time: 0.1175
INFO - 2021-06-02 06:46:53 --> Config Class Initialized
INFO - 2021-06-02 06:46:53 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:46:53 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:46:53 --> Utf8 Class Initialized
INFO - 2021-06-02 06:46:53 --> URI Class Initialized
INFO - 2021-06-02 06:46:53 --> Router Class Initialized
INFO - 2021-06-02 06:46:53 --> Output Class Initialized
INFO - 2021-06-02 06:46:53 --> Security Class Initialized
DEBUG - 2021-06-02 06:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:46:53 --> Input Class Initialized
INFO - 2021-06-02 06:46:53 --> Language Class Initialized
INFO - 2021-06-02 06:46:53 --> Language Class Initialized
INFO - 2021-06-02 06:46:53 --> Config Class Initialized
INFO - 2021-06-02 06:46:53 --> Loader Class Initialized
INFO - 2021-06-02 06:46:53 --> Helper loaded: url_helper
INFO - 2021-06-02 06:46:53 --> Helper loaded: file_helper
INFO - 2021-06-02 06:46:53 --> Helper loaded: form_helper
INFO - 2021-06-02 06:46:53 --> Helper loaded: my_helper
INFO - 2021-06-02 06:46:53 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:46:53 --> Controller Class Initialized
DEBUG - 2021-06-02 06:46:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:46:53 --> Final output sent to browser
DEBUG - 2021-06-02 06:46:53 --> Total execution time: 0.1136
INFO - 2021-06-02 06:47:55 --> Config Class Initialized
INFO - 2021-06-02 06:47:55 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:47:55 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:47:55 --> Utf8 Class Initialized
INFO - 2021-06-02 06:47:55 --> URI Class Initialized
INFO - 2021-06-02 06:47:55 --> Router Class Initialized
INFO - 2021-06-02 06:47:55 --> Output Class Initialized
INFO - 2021-06-02 06:47:55 --> Security Class Initialized
DEBUG - 2021-06-02 06:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:47:55 --> Input Class Initialized
INFO - 2021-06-02 06:47:55 --> Language Class Initialized
INFO - 2021-06-02 06:47:55 --> Language Class Initialized
INFO - 2021-06-02 06:47:55 --> Config Class Initialized
INFO - 2021-06-02 06:47:55 --> Loader Class Initialized
INFO - 2021-06-02 06:47:55 --> Helper loaded: url_helper
INFO - 2021-06-02 06:47:55 --> Helper loaded: file_helper
INFO - 2021-06-02 06:47:55 --> Helper loaded: form_helper
INFO - 2021-06-02 06:47:55 --> Helper loaded: my_helper
INFO - 2021-06-02 06:47:55 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:47:55 --> Controller Class Initialized
DEBUG - 2021-06-02 06:47:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:47:55 --> Final output sent to browser
DEBUG - 2021-06-02 06:47:55 --> Total execution time: 0.1446
INFO - 2021-06-02 06:48:13 --> Config Class Initialized
INFO - 2021-06-02 06:48:13 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:48:13 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:48:13 --> Utf8 Class Initialized
INFO - 2021-06-02 06:48:13 --> URI Class Initialized
INFO - 2021-06-02 06:48:13 --> Router Class Initialized
INFO - 2021-06-02 06:48:13 --> Output Class Initialized
INFO - 2021-06-02 06:48:13 --> Security Class Initialized
DEBUG - 2021-06-02 06:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:48:13 --> Input Class Initialized
INFO - 2021-06-02 06:48:13 --> Language Class Initialized
INFO - 2021-06-02 06:48:13 --> Language Class Initialized
INFO - 2021-06-02 06:48:13 --> Config Class Initialized
INFO - 2021-06-02 06:48:13 --> Loader Class Initialized
INFO - 2021-06-02 06:48:13 --> Helper loaded: url_helper
INFO - 2021-06-02 06:48:13 --> Helper loaded: file_helper
INFO - 2021-06-02 06:48:13 --> Helper loaded: form_helper
INFO - 2021-06-02 06:48:13 --> Helper loaded: my_helper
INFO - 2021-06-02 06:48:13 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:48:13 --> Controller Class Initialized
DEBUG - 2021-06-02 06:48:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:48:13 --> Final output sent to browser
DEBUG - 2021-06-02 06:48:13 --> Total execution time: 0.1456
INFO - 2021-06-02 06:48:27 --> Config Class Initialized
INFO - 2021-06-02 06:48:27 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:48:27 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:48:27 --> Utf8 Class Initialized
INFO - 2021-06-02 06:48:27 --> URI Class Initialized
INFO - 2021-06-02 06:48:27 --> Router Class Initialized
INFO - 2021-06-02 06:48:27 --> Output Class Initialized
INFO - 2021-06-02 06:48:27 --> Security Class Initialized
DEBUG - 2021-06-02 06:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:48:27 --> Input Class Initialized
INFO - 2021-06-02 06:48:27 --> Language Class Initialized
INFO - 2021-06-02 06:48:27 --> Language Class Initialized
INFO - 2021-06-02 06:48:27 --> Config Class Initialized
INFO - 2021-06-02 06:48:27 --> Loader Class Initialized
INFO - 2021-06-02 06:48:27 --> Helper loaded: url_helper
INFO - 2021-06-02 06:48:27 --> Helper loaded: file_helper
INFO - 2021-06-02 06:48:27 --> Helper loaded: form_helper
INFO - 2021-06-02 06:48:27 --> Helper loaded: my_helper
INFO - 2021-06-02 06:48:27 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:48:27 --> Controller Class Initialized
DEBUG - 2021-06-02 06:48:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:48:27 --> Final output sent to browser
DEBUG - 2021-06-02 06:48:27 --> Total execution time: 0.1125
INFO - 2021-06-02 06:48:51 --> Config Class Initialized
INFO - 2021-06-02 06:48:51 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:48:51 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:48:51 --> Utf8 Class Initialized
INFO - 2021-06-02 06:48:51 --> URI Class Initialized
INFO - 2021-06-02 06:48:51 --> Router Class Initialized
INFO - 2021-06-02 06:48:51 --> Output Class Initialized
INFO - 2021-06-02 06:48:51 --> Security Class Initialized
DEBUG - 2021-06-02 06:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:48:51 --> Input Class Initialized
INFO - 2021-06-02 06:48:51 --> Language Class Initialized
INFO - 2021-06-02 06:48:51 --> Language Class Initialized
INFO - 2021-06-02 06:48:51 --> Config Class Initialized
INFO - 2021-06-02 06:48:51 --> Loader Class Initialized
INFO - 2021-06-02 06:48:51 --> Helper loaded: url_helper
INFO - 2021-06-02 06:48:51 --> Helper loaded: file_helper
INFO - 2021-06-02 06:48:51 --> Helper loaded: form_helper
INFO - 2021-06-02 06:48:51 --> Helper loaded: my_helper
INFO - 2021-06-02 06:48:51 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:48:51 --> Controller Class Initialized
DEBUG - 2021-06-02 06:48:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:48:51 --> Final output sent to browser
DEBUG - 2021-06-02 06:48:51 --> Total execution time: 0.1432
INFO - 2021-06-02 06:51:35 --> Config Class Initialized
INFO - 2021-06-02 06:51:35 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:51:35 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:51:35 --> Utf8 Class Initialized
INFO - 2021-06-02 06:51:35 --> URI Class Initialized
INFO - 2021-06-02 06:51:35 --> Router Class Initialized
INFO - 2021-06-02 06:51:35 --> Output Class Initialized
INFO - 2021-06-02 06:51:35 --> Security Class Initialized
DEBUG - 2021-06-02 06:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:51:35 --> Input Class Initialized
INFO - 2021-06-02 06:51:35 --> Language Class Initialized
INFO - 2021-06-02 06:51:35 --> Language Class Initialized
INFO - 2021-06-02 06:51:35 --> Config Class Initialized
INFO - 2021-06-02 06:51:35 --> Loader Class Initialized
INFO - 2021-06-02 06:51:35 --> Helper loaded: url_helper
INFO - 2021-06-02 06:51:35 --> Helper loaded: file_helper
INFO - 2021-06-02 06:51:35 --> Helper loaded: form_helper
INFO - 2021-06-02 06:51:35 --> Helper loaded: my_helper
INFO - 2021-06-02 06:51:35 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:51:35 --> Controller Class Initialized
DEBUG - 2021-06-02 06:51:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:51:35 --> Final output sent to browser
DEBUG - 2021-06-02 06:51:35 --> Total execution time: 0.1128
INFO - 2021-06-02 06:56:20 --> Config Class Initialized
INFO - 2021-06-02 06:56:20 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:56:20 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:56:20 --> Utf8 Class Initialized
INFO - 2021-06-02 06:56:20 --> URI Class Initialized
INFO - 2021-06-02 06:56:20 --> Router Class Initialized
INFO - 2021-06-02 06:56:20 --> Output Class Initialized
INFO - 2021-06-02 06:56:20 --> Security Class Initialized
DEBUG - 2021-06-02 06:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:56:20 --> Input Class Initialized
INFO - 2021-06-02 06:56:20 --> Language Class Initialized
INFO - 2021-06-02 06:56:20 --> Language Class Initialized
INFO - 2021-06-02 06:56:20 --> Config Class Initialized
INFO - 2021-06-02 06:56:20 --> Loader Class Initialized
INFO - 2021-06-02 06:56:20 --> Helper loaded: url_helper
INFO - 2021-06-02 06:56:20 --> Helper loaded: file_helper
INFO - 2021-06-02 06:56:20 --> Helper loaded: form_helper
INFO - 2021-06-02 06:56:20 --> Helper loaded: my_helper
INFO - 2021-06-02 06:56:20 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:56:20 --> Controller Class Initialized
DEBUG - 2021-06-02 06:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:56:20 --> Final output sent to browser
DEBUG - 2021-06-02 06:56:20 --> Total execution time: 0.1314
INFO - 2021-06-02 06:56:47 --> Config Class Initialized
INFO - 2021-06-02 06:56:47 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:56:47 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:56:47 --> Utf8 Class Initialized
INFO - 2021-06-02 06:56:47 --> URI Class Initialized
INFO - 2021-06-02 06:56:47 --> Router Class Initialized
INFO - 2021-06-02 06:56:47 --> Output Class Initialized
INFO - 2021-06-02 06:56:47 --> Security Class Initialized
DEBUG - 2021-06-02 06:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:56:47 --> Input Class Initialized
INFO - 2021-06-02 06:56:47 --> Language Class Initialized
INFO - 2021-06-02 06:56:47 --> Language Class Initialized
INFO - 2021-06-02 06:56:47 --> Config Class Initialized
INFO - 2021-06-02 06:56:47 --> Loader Class Initialized
INFO - 2021-06-02 06:56:47 --> Helper loaded: url_helper
INFO - 2021-06-02 06:56:47 --> Helper loaded: file_helper
INFO - 2021-06-02 06:56:47 --> Helper loaded: form_helper
INFO - 2021-06-02 06:56:47 --> Helper loaded: my_helper
INFO - 2021-06-02 06:56:47 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:56:47 --> Controller Class Initialized
DEBUG - 2021-06-02 06:56:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:56:47 --> Final output sent to browser
DEBUG - 2021-06-02 06:56:47 --> Total execution time: 0.1221
INFO - 2021-06-02 06:56:58 --> Config Class Initialized
INFO - 2021-06-02 06:56:58 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:56:59 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:56:59 --> Utf8 Class Initialized
INFO - 2021-06-02 06:56:59 --> URI Class Initialized
INFO - 2021-06-02 06:56:59 --> Router Class Initialized
INFO - 2021-06-02 06:56:59 --> Output Class Initialized
INFO - 2021-06-02 06:56:59 --> Security Class Initialized
DEBUG - 2021-06-02 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:56:59 --> Input Class Initialized
INFO - 2021-06-02 06:56:59 --> Language Class Initialized
INFO - 2021-06-02 06:56:59 --> Language Class Initialized
INFO - 2021-06-02 06:56:59 --> Config Class Initialized
INFO - 2021-06-02 06:56:59 --> Loader Class Initialized
INFO - 2021-06-02 06:56:59 --> Helper loaded: url_helper
INFO - 2021-06-02 06:56:59 --> Helper loaded: file_helper
INFO - 2021-06-02 06:56:59 --> Helper loaded: form_helper
INFO - 2021-06-02 06:56:59 --> Helper loaded: my_helper
INFO - 2021-06-02 06:56:59 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:56:59 --> Controller Class Initialized
DEBUG - 2021-06-02 06:56:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:56:59 --> Final output sent to browser
DEBUG - 2021-06-02 06:56:59 --> Total execution time: 0.2134
INFO - 2021-06-02 06:57:40 --> Config Class Initialized
INFO - 2021-06-02 06:57:40 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:57:41 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:57:41 --> Utf8 Class Initialized
INFO - 2021-06-02 06:57:41 --> URI Class Initialized
INFO - 2021-06-02 06:57:41 --> Router Class Initialized
INFO - 2021-06-02 06:57:41 --> Output Class Initialized
INFO - 2021-06-02 06:57:41 --> Security Class Initialized
DEBUG - 2021-06-02 06:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:57:41 --> Input Class Initialized
INFO - 2021-06-02 06:57:41 --> Language Class Initialized
INFO - 2021-06-02 06:57:41 --> Language Class Initialized
INFO - 2021-06-02 06:57:41 --> Config Class Initialized
INFO - 2021-06-02 06:57:41 --> Loader Class Initialized
INFO - 2021-06-02 06:57:41 --> Helper loaded: url_helper
INFO - 2021-06-02 06:57:41 --> Helper loaded: file_helper
INFO - 2021-06-02 06:57:41 --> Helper loaded: form_helper
INFO - 2021-06-02 06:57:41 --> Helper loaded: my_helper
INFO - 2021-06-02 06:57:41 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:57:41 --> Controller Class Initialized
DEBUG - 2021-06-02 06:57:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:57:41 --> Final output sent to browser
DEBUG - 2021-06-02 06:57:41 --> Total execution time: 0.1986
INFO - 2021-06-02 06:58:04 --> Config Class Initialized
INFO - 2021-06-02 06:58:04 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:58:04 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:58:04 --> Utf8 Class Initialized
INFO - 2021-06-02 06:58:04 --> URI Class Initialized
INFO - 2021-06-02 06:58:04 --> Router Class Initialized
INFO - 2021-06-02 06:58:04 --> Output Class Initialized
INFO - 2021-06-02 06:58:04 --> Security Class Initialized
DEBUG - 2021-06-02 06:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:58:04 --> Input Class Initialized
INFO - 2021-06-02 06:58:04 --> Language Class Initialized
INFO - 2021-06-02 06:58:04 --> Language Class Initialized
INFO - 2021-06-02 06:58:04 --> Config Class Initialized
INFO - 2021-06-02 06:58:04 --> Loader Class Initialized
INFO - 2021-06-02 06:58:04 --> Helper loaded: url_helper
INFO - 2021-06-02 06:58:04 --> Helper loaded: file_helper
INFO - 2021-06-02 06:58:04 --> Helper loaded: form_helper
INFO - 2021-06-02 06:58:04 --> Helper loaded: my_helper
INFO - 2021-06-02 06:58:04 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:58:04 --> Controller Class Initialized
DEBUG - 2021-06-02 06:58:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:58:04 --> Final output sent to browser
DEBUG - 2021-06-02 06:58:04 --> Total execution time: 0.1159
INFO - 2021-06-02 06:59:02 --> Config Class Initialized
INFO - 2021-06-02 06:59:02 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:59:02 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:59:02 --> Utf8 Class Initialized
INFO - 2021-06-02 06:59:02 --> URI Class Initialized
INFO - 2021-06-02 06:59:02 --> Router Class Initialized
INFO - 2021-06-02 06:59:02 --> Output Class Initialized
INFO - 2021-06-02 06:59:02 --> Security Class Initialized
DEBUG - 2021-06-02 06:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:59:02 --> Input Class Initialized
INFO - 2021-06-02 06:59:02 --> Language Class Initialized
INFO - 2021-06-02 06:59:02 --> Language Class Initialized
INFO - 2021-06-02 06:59:02 --> Config Class Initialized
INFO - 2021-06-02 06:59:02 --> Loader Class Initialized
INFO - 2021-06-02 06:59:02 --> Helper loaded: url_helper
INFO - 2021-06-02 06:59:02 --> Helper loaded: file_helper
INFO - 2021-06-02 06:59:02 --> Helper loaded: form_helper
INFO - 2021-06-02 06:59:02 --> Helper loaded: my_helper
INFO - 2021-06-02 06:59:02 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:59:02 --> Controller Class Initialized
DEBUG - 2021-06-02 06:59:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:59:02 --> Final output sent to browser
DEBUG - 2021-06-02 06:59:02 --> Total execution time: 0.1335
INFO - 2021-06-02 06:59:42 --> Config Class Initialized
INFO - 2021-06-02 06:59:42 --> Hooks Class Initialized
DEBUG - 2021-06-02 06:59:42 --> UTF-8 Support Enabled
INFO - 2021-06-02 06:59:42 --> Utf8 Class Initialized
INFO - 2021-06-02 06:59:42 --> URI Class Initialized
INFO - 2021-06-02 06:59:42 --> Router Class Initialized
INFO - 2021-06-02 06:59:42 --> Output Class Initialized
INFO - 2021-06-02 06:59:42 --> Security Class Initialized
DEBUG - 2021-06-02 06:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 06:59:42 --> Input Class Initialized
INFO - 2021-06-02 06:59:42 --> Language Class Initialized
INFO - 2021-06-02 06:59:42 --> Language Class Initialized
INFO - 2021-06-02 06:59:42 --> Config Class Initialized
INFO - 2021-06-02 06:59:42 --> Loader Class Initialized
INFO - 2021-06-02 06:59:42 --> Helper loaded: url_helper
INFO - 2021-06-02 06:59:42 --> Helper loaded: file_helper
INFO - 2021-06-02 06:59:42 --> Helper loaded: form_helper
INFO - 2021-06-02 06:59:42 --> Helper loaded: my_helper
INFO - 2021-06-02 06:59:42 --> Database Driver Class Initialized
DEBUG - 2021-06-02 06:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 06:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 06:59:42 --> Controller Class Initialized
DEBUG - 2021-06-02 06:59:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 06:59:42 --> Final output sent to browser
DEBUG - 2021-06-02 06:59:42 --> Total execution time: 0.2564
INFO - 2021-06-02 07:00:06 --> Config Class Initialized
INFO - 2021-06-02 07:00:06 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:00:06 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:00:06 --> Utf8 Class Initialized
INFO - 2021-06-02 07:00:06 --> URI Class Initialized
INFO - 2021-06-02 07:00:06 --> Router Class Initialized
INFO - 2021-06-02 07:00:06 --> Output Class Initialized
INFO - 2021-06-02 07:00:06 --> Security Class Initialized
DEBUG - 2021-06-02 07:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:00:06 --> Input Class Initialized
INFO - 2021-06-02 07:00:06 --> Language Class Initialized
INFO - 2021-06-02 07:00:06 --> Language Class Initialized
INFO - 2021-06-02 07:00:06 --> Config Class Initialized
INFO - 2021-06-02 07:00:06 --> Loader Class Initialized
INFO - 2021-06-02 07:00:06 --> Helper loaded: url_helper
INFO - 2021-06-02 07:00:06 --> Helper loaded: file_helper
INFO - 2021-06-02 07:00:06 --> Helper loaded: form_helper
INFO - 2021-06-02 07:00:06 --> Helper loaded: my_helper
INFO - 2021-06-02 07:00:06 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:00:06 --> Controller Class Initialized
DEBUG - 2021-06-02 07:00:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:00:06 --> Final output sent to browser
DEBUG - 2021-06-02 07:00:06 --> Total execution time: 0.1182
INFO - 2021-06-02 07:00:36 --> Config Class Initialized
INFO - 2021-06-02 07:00:36 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:00:36 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:00:36 --> Utf8 Class Initialized
INFO - 2021-06-02 07:00:36 --> URI Class Initialized
INFO - 2021-06-02 07:00:36 --> Router Class Initialized
INFO - 2021-06-02 07:00:36 --> Output Class Initialized
INFO - 2021-06-02 07:00:36 --> Security Class Initialized
DEBUG - 2021-06-02 07:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:00:36 --> Input Class Initialized
INFO - 2021-06-02 07:00:36 --> Language Class Initialized
INFO - 2021-06-02 07:00:36 --> Language Class Initialized
INFO - 2021-06-02 07:00:36 --> Config Class Initialized
INFO - 2021-06-02 07:00:36 --> Loader Class Initialized
INFO - 2021-06-02 07:00:36 --> Helper loaded: url_helper
INFO - 2021-06-02 07:00:36 --> Helper loaded: file_helper
INFO - 2021-06-02 07:00:36 --> Helper loaded: form_helper
INFO - 2021-06-02 07:00:36 --> Helper loaded: my_helper
INFO - 2021-06-02 07:00:36 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:00:36 --> Controller Class Initialized
DEBUG - 2021-06-02 07:00:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:00:36 --> Final output sent to browser
DEBUG - 2021-06-02 07:00:36 --> Total execution time: 0.1302
INFO - 2021-06-02 07:01:19 --> Config Class Initialized
INFO - 2021-06-02 07:01:19 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:01:19 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:01:19 --> Utf8 Class Initialized
INFO - 2021-06-02 07:01:19 --> URI Class Initialized
INFO - 2021-06-02 07:01:19 --> Router Class Initialized
INFO - 2021-06-02 07:01:19 --> Output Class Initialized
INFO - 2021-06-02 07:01:19 --> Security Class Initialized
DEBUG - 2021-06-02 07:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:01:19 --> Input Class Initialized
INFO - 2021-06-02 07:01:19 --> Language Class Initialized
INFO - 2021-06-02 07:01:19 --> Language Class Initialized
INFO - 2021-06-02 07:01:19 --> Config Class Initialized
INFO - 2021-06-02 07:01:19 --> Loader Class Initialized
INFO - 2021-06-02 07:01:19 --> Helper loaded: url_helper
INFO - 2021-06-02 07:01:19 --> Helper loaded: file_helper
INFO - 2021-06-02 07:01:19 --> Helper loaded: form_helper
INFO - 2021-06-02 07:01:19 --> Helper loaded: my_helper
INFO - 2021-06-02 07:01:19 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:01:19 --> Controller Class Initialized
DEBUG - 2021-06-02 07:01:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:01:19 --> Final output sent to browser
DEBUG - 2021-06-02 07:01:19 --> Total execution time: 0.1071
INFO - 2021-06-02 07:01:51 --> Config Class Initialized
INFO - 2021-06-02 07:01:51 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:01:51 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:01:51 --> Utf8 Class Initialized
INFO - 2021-06-02 07:01:51 --> URI Class Initialized
INFO - 2021-06-02 07:01:51 --> Router Class Initialized
INFO - 2021-06-02 07:01:51 --> Output Class Initialized
INFO - 2021-06-02 07:01:51 --> Security Class Initialized
DEBUG - 2021-06-02 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:01:51 --> Input Class Initialized
INFO - 2021-06-02 07:01:51 --> Language Class Initialized
INFO - 2021-06-02 07:01:51 --> Language Class Initialized
INFO - 2021-06-02 07:01:51 --> Config Class Initialized
INFO - 2021-06-02 07:01:51 --> Loader Class Initialized
INFO - 2021-06-02 07:01:51 --> Helper loaded: url_helper
INFO - 2021-06-02 07:01:51 --> Helper loaded: file_helper
INFO - 2021-06-02 07:01:51 --> Helper loaded: form_helper
INFO - 2021-06-02 07:01:51 --> Helper loaded: my_helper
INFO - 2021-06-02 07:01:51 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:01:51 --> Controller Class Initialized
DEBUG - 2021-06-02 07:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:01:51 --> Final output sent to browser
DEBUG - 2021-06-02 07:01:51 --> Total execution time: 0.2009
INFO - 2021-06-02 07:02:05 --> Config Class Initialized
INFO - 2021-06-02 07:02:05 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:02:05 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:02:05 --> Utf8 Class Initialized
INFO - 2021-06-02 07:02:05 --> URI Class Initialized
INFO - 2021-06-02 07:02:05 --> Router Class Initialized
INFO - 2021-06-02 07:02:05 --> Output Class Initialized
INFO - 2021-06-02 07:02:05 --> Security Class Initialized
DEBUG - 2021-06-02 07:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:02:05 --> Input Class Initialized
INFO - 2021-06-02 07:02:05 --> Language Class Initialized
INFO - 2021-06-02 07:02:05 --> Language Class Initialized
INFO - 2021-06-02 07:02:05 --> Config Class Initialized
INFO - 2021-06-02 07:02:05 --> Loader Class Initialized
INFO - 2021-06-02 07:02:05 --> Helper loaded: url_helper
INFO - 2021-06-02 07:02:05 --> Helper loaded: file_helper
INFO - 2021-06-02 07:02:05 --> Helper loaded: form_helper
INFO - 2021-06-02 07:02:05 --> Helper loaded: my_helper
INFO - 2021-06-02 07:02:05 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:02:05 --> Controller Class Initialized
DEBUG - 2021-06-02 07:02:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-02 07:02:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 07:02:06 --> Final output sent to browser
DEBUG - 2021-06-02 07:02:06 --> Total execution time: 0.2135
INFO - 2021-06-02 07:02:07 --> Config Class Initialized
INFO - 2021-06-02 07:02:07 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:02:07 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:02:07 --> Utf8 Class Initialized
INFO - 2021-06-02 07:02:07 --> URI Class Initialized
INFO - 2021-06-02 07:02:07 --> Router Class Initialized
INFO - 2021-06-02 07:02:07 --> Output Class Initialized
INFO - 2021-06-02 07:02:07 --> Security Class Initialized
DEBUG - 2021-06-02 07:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:02:07 --> Input Class Initialized
INFO - 2021-06-02 07:02:07 --> Language Class Initialized
INFO - 2021-06-02 07:02:07 --> Language Class Initialized
INFO - 2021-06-02 07:02:07 --> Config Class Initialized
INFO - 2021-06-02 07:02:07 --> Loader Class Initialized
INFO - 2021-06-02 07:02:07 --> Helper loaded: url_helper
INFO - 2021-06-02 07:02:07 --> Helper loaded: file_helper
INFO - 2021-06-02 07:02:07 --> Helper loaded: form_helper
INFO - 2021-06-02 07:02:07 --> Helper loaded: my_helper
INFO - 2021-06-02 07:02:07 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:02:07 --> Controller Class Initialized
DEBUG - 2021-06-02 07:02:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:02:07 --> Final output sent to browser
DEBUG - 2021-06-02 07:02:07 --> Total execution time: 0.1209
INFO - 2021-06-02 07:02:27 --> Config Class Initialized
INFO - 2021-06-02 07:02:27 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:02:27 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:02:27 --> Utf8 Class Initialized
INFO - 2021-06-02 07:02:27 --> URI Class Initialized
INFO - 2021-06-02 07:02:27 --> Router Class Initialized
INFO - 2021-06-02 07:02:27 --> Output Class Initialized
INFO - 2021-06-02 07:02:27 --> Security Class Initialized
DEBUG - 2021-06-02 07:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:02:27 --> Input Class Initialized
INFO - 2021-06-02 07:02:27 --> Language Class Initialized
INFO - 2021-06-02 07:02:27 --> Language Class Initialized
INFO - 2021-06-02 07:02:27 --> Config Class Initialized
INFO - 2021-06-02 07:02:27 --> Loader Class Initialized
INFO - 2021-06-02 07:02:27 --> Helper loaded: url_helper
INFO - 2021-06-02 07:02:27 --> Helper loaded: file_helper
INFO - 2021-06-02 07:02:27 --> Helper loaded: form_helper
INFO - 2021-06-02 07:02:27 --> Helper loaded: my_helper
INFO - 2021-06-02 07:02:27 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:02:27 --> Controller Class Initialized
DEBUG - 2021-06-02 07:02:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:02:27 --> Final output sent to browser
DEBUG - 2021-06-02 07:02:27 --> Total execution time: 0.1364
INFO - 2021-06-02 07:02:50 --> Config Class Initialized
INFO - 2021-06-02 07:02:50 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:02:50 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:02:50 --> Utf8 Class Initialized
INFO - 2021-06-02 07:02:50 --> URI Class Initialized
INFO - 2021-06-02 07:02:50 --> Router Class Initialized
INFO - 2021-06-02 07:02:50 --> Output Class Initialized
INFO - 2021-06-02 07:02:50 --> Security Class Initialized
DEBUG - 2021-06-02 07:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:02:50 --> Input Class Initialized
INFO - 2021-06-02 07:02:50 --> Language Class Initialized
INFO - 2021-06-02 07:02:50 --> Language Class Initialized
INFO - 2021-06-02 07:02:50 --> Config Class Initialized
INFO - 2021-06-02 07:02:50 --> Loader Class Initialized
INFO - 2021-06-02 07:02:50 --> Helper loaded: url_helper
INFO - 2021-06-02 07:02:50 --> Helper loaded: file_helper
INFO - 2021-06-02 07:02:50 --> Helper loaded: form_helper
INFO - 2021-06-02 07:02:50 --> Helper loaded: my_helper
INFO - 2021-06-02 07:02:50 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:02:50 --> Controller Class Initialized
DEBUG - 2021-06-02 07:02:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:02:50 --> Final output sent to browser
DEBUG - 2021-06-02 07:02:50 --> Total execution time: 0.1195
INFO - 2021-06-02 07:02:57 --> Config Class Initialized
INFO - 2021-06-02 07:02:57 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:02:57 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:02:57 --> Utf8 Class Initialized
INFO - 2021-06-02 07:02:57 --> URI Class Initialized
INFO - 2021-06-02 07:02:57 --> Router Class Initialized
INFO - 2021-06-02 07:02:57 --> Output Class Initialized
INFO - 2021-06-02 07:02:57 --> Security Class Initialized
DEBUG - 2021-06-02 07:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:02:57 --> Input Class Initialized
INFO - 2021-06-02 07:02:57 --> Language Class Initialized
INFO - 2021-06-02 07:02:57 --> Language Class Initialized
INFO - 2021-06-02 07:02:57 --> Config Class Initialized
INFO - 2021-06-02 07:02:57 --> Loader Class Initialized
INFO - 2021-06-02 07:02:57 --> Helper loaded: url_helper
INFO - 2021-06-02 07:02:57 --> Helper loaded: file_helper
INFO - 2021-06-02 07:02:57 --> Helper loaded: form_helper
INFO - 2021-06-02 07:02:57 --> Helper loaded: my_helper
INFO - 2021-06-02 07:02:57 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:02:57 --> Controller Class Initialized
DEBUG - 2021-06-02 07:02:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:02:57 --> Final output sent to browser
DEBUG - 2021-06-02 07:02:57 --> Total execution time: 0.1228
INFO - 2021-06-02 07:03:06 --> Config Class Initialized
INFO - 2021-06-02 07:03:06 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:03:06 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:03:06 --> Utf8 Class Initialized
INFO - 2021-06-02 07:03:06 --> URI Class Initialized
INFO - 2021-06-02 07:03:06 --> Router Class Initialized
INFO - 2021-06-02 07:03:06 --> Output Class Initialized
INFO - 2021-06-02 07:03:06 --> Security Class Initialized
DEBUG - 2021-06-02 07:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:03:06 --> Input Class Initialized
INFO - 2021-06-02 07:03:06 --> Language Class Initialized
INFO - 2021-06-02 07:03:06 --> Language Class Initialized
INFO - 2021-06-02 07:03:06 --> Config Class Initialized
INFO - 2021-06-02 07:03:06 --> Loader Class Initialized
INFO - 2021-06-02 07:03:06 --> Helper loaded: url_helper
INFO - 2021-06-02 07:03:06 --> Helper loaded: file_helper
INFO - 2021-06-02 07:03:06 --> Helper loaded: form_helper
INFO - 2021-06-02 07:03:06 --> Helper loaded: my_helper
INFO - 2021-06-02 07:03:06 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:03:06 --> Controller Class Initialized
DEBUG - 2021-06-02 07:03:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:03:06 --> Final output sent to browser
DEBUG - 2021-06-02 07:03:06 --> Total execution time: 0.1180
INFO - 2021-06-02 07:03:33 --> Config Class Initialized
INFO - 2021-06-02 07:03:33 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:03:33 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:03:33 --> Utf8 Class Initialized
INFO - 2021-06-02 07:03:33 --> URI Class Initialized
INFO - 2021-06-02 07:03:33 --> Router Class Initialized
INFO - 2021-06-02 07:03:33 --> Output Class Initialized
INFO - 2021-06-02 07:03:33 --> Security Class Initialized
DEBUG - 2021-06-02 07:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:03:33 --> Input Class Initialized
INFO - 2021-06-02 07:03:33 --> Language Class Initialized
INFO - 2021-06-02 07:03:33 --> Language Class Initialized
INFO - 2021-06-02 07:03:33 --> Config Class Initialized
INFO - 2021-06-02 07:03:33 --> Loader Class Initialized
INFO - 2021-06-02 07:03:33 --> Helper loaded: url_helper
INFO - 2021-06-02 07:03:33 --> Helper loaded: file_helper
INFO - 2021-06-02 07:03:33 --> Helper loaded: form_helper
INFO - 2021-06-02 07:03:33 --> Helper loaded: my_helper
INFO - 2021-06-02 07:03:33 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:03:33 --> Controller Class Initialized
DEBUG - 2021-06-02 07:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 07:03:33 --> Final output sent to browser
DEBUG - 2021-06-02 07:03:33 --> Total execution time: 0.1782
INFO - 2021-06-02 07:59:02 --> Config Class Initialized
INFO - 2021-06-02 07:59:02 --> Hooks Class Initialized
DEBUG - 2021-06-02 07:59:02 --> UTF-8 Support Enabled
INFO - 2021-06-02 07:59:02 --> Utf8 Class Initialized
INFO - 2021-06-02 07:59:02 --> URI Class Initialized
INFO - 2021-06-02 07:59:02 --> Router Class Initialized
INFO - 2021-06-02 07:59:02 --> Output Class Initialized
INFO - 2021-06-02 07:59:02 --> Security Class Initialized
DEBUG - 2021-06-02 07:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 07:59:02 --> Input Class Initialized
INFO - 2021-06-02 07:59:02 --> Language Class Initialized
INFO - 2021-06-02 07:59:02 --> Language Class Initialized
INFO - 2021-06-02 07:59:02 --> Config Class Initialized
INFO - 2021-06-02 07:59:02 --> Loader Class Initialized
INFO - 2021-06-02 07:59:02 --> Helper loaded: url_helper
INFO - 2021-06-02 07:59:02 --> Helper loaded: file_helper
INFO - 2021-06-02 07:59:02 --> Helper loaded: form_helper
INFO - 2021-06-02 07:59:02 --> Helper loaded: my_helper
INFO - 2021-06-02 07:59:02 --> Database Driver Class Initialized
DEBUG - 2021-06-02 07:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 07:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 07:59:02 --> Controller Class Initialized
DEBUG - 2021-06-02 07:59:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-06-02 07:59:02 --> Final output sent to browser
DEBUG - 2021-06-02 07:59:02 --> Total execution time: 0.1191
INFO - 2021-06-02 09:32:29 --> Config Class Initialized
INFO - 2021-06-02 09:32:29 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:32:29 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:32:29 --> Utf8 Class Initialized
INFO - 2021-06-02 09:32:29 --> URI Class Initialized
INFO - 2021-06-02 09:32:29 --> Router Class Initialized
INFO - 2021-06-02 09:32:29 --> Output Class Initialized
INFO - 2021-06-02 09:32:29 --> Security Class Initialized
DEBUG - 2021-06-02 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:32:29 --> Input Class Initialized
INFO - 2021-06-02 09:32:29 --> Language Class Initialized
INFO - 2021-06-02 09:32:29 --> Language Class Initialized
INFO - 2021-06-02 09:32:29 --> Config Class Initialized
INFO - 2021-06-02 09:32:29 --> Loader Class Initialized
INFO - 2021-06-02 09:32:29 --> Helper loaded: url_helper
INFO - 2021-06-02 09:32:29 --> Helper loaded: file_helper
INFO - 2021-06-02 09:32:29 --> Helper loaded: form_helper
INFO - 2021-06-02 09:32:29 --> Helper loaded: my_helper
INFO - 2021-06-02 09:32:29 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:32:29 --> Controller Class Initialized
DEBUG - 2021-06-02 09:32:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:32:29 --> Final output sent to browser
DEBUG - 2021-06-02 09:32:29 --> Total execution time: 0.1011
INFO - 2021-06-02 09:32:47 --> Config Class Initialized
INFO - 2021-06-02 09:32:47 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:32:47 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:32:47 --> Utf8 Class Initialized
INFO - 2021-06-02 09:32:47 --> URI Class Initialized
INFO - 2021-06-02 09:32:47 --> Router Class Initialized
INFO - 2021-06-02 09:32:47 --> Output Class Initialized
INFO - 2021-06-02 09:32:47 --> Security Class Initialized
DEBUG - 2021-06-02 09:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:32:47 --> Input Class Initialized
INFO - 2021-06-02 09:32:47 --> Language Class Initialized
INFO - 2021-06-02 09:32:47 --> Language Class Initialized
INFO - 2021-06-02 09:32:47 --> Config Class Initialized
INFO - 2021-06-02 09:32:47 --> Loader Class Initialized
INFO - 2021-06-02 09:32:47 --> Helper loaded: url_helper
INFO - 2021-06-02 09:32:47 --> Helper loaded: file_helper
INFO - 2021-06-02 09:32:47 --> Helper loaded: form_helper
INFO - 2021-06-02 09:32:47 --> Helper loaded: my_helper
INFO - 2021-06-02 09:32:47 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:32:47 --> Controller Class Initialized
DEBUG - 2021-06-02 09:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:32:47 --> Final output sent to browser
DEBUG - 2021-06-02 09:32:47 --> Total execution time: 0.0807
INFO - 2021-06-02 09:33:35 --> Config Class Initialized
INFO - 2021-06-02 09:33:35 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:33:35 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:33:35 --> Utf8 Class Initialized
INFO - 2021-06-02 09:33:35 --> URI Class Initialized
INFO - 2021-06-02 09:33:35 --> Router Class Initialized
INFO - 2021-06-02 09:33:35 --> Output Class Initialized
INFO - 2021-06-02 09:33:35 --> Security Class Initialized
DEBUG - 2021-06-02 09:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:33:35 --> Input Class Initialized
INFO - 2021-06-02 09:33:35 --> Language Class Initialized
INFO - 2021-06-02 09:33:35 --> Language Class Initialized
INFO - 2021-06-02 09:33:35 --> Config Class Initialized
INFO - 2021-06-02 09:33:35 --> Loader Class Initialized
INFO - 2021-06-02 09:33:35 --> Helper loaded: url_helper
INFO - 2021-06-02 09:33:35 --> Helper loaded: file_helper
INFO - 2021-06-02 09:33:35 --> Helper loaded: form_helper
INFO - 2021-06-02 09:33:35 --> Helper loaded: my_helper
INFO - 2021-06-02 09:33:35 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:33:35 --> Controller Class Initialized
DEBUG - 2021-06-02 09:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:33:35 --> Final output sent to browser
DEBUG - 2021-06-02 09:33:35 --> Total execution time: 0.0721
INFO - 2021-06-02 09:37:44 --> Config Class Initialized
INFO - 2021-06-02 09:37:44 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:37:44 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:37:44 --> Utf8 Class Initialized
INFO - 2021-06-02 09:37:44 --> URI Class Initialized
INFO - 2021-06-02 09:37:44 --> Router Class Initialized
INFO - 2021-06-02 09:37:44 --> Output Class Initialized
INFO - 2021-06-02 09:37:44 --> Security Class Initialized
DEBUG - 2021-06-02 09:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:37:44 --> Input Class Initialized
INFO - 2021-06-02 09:37:44 --> Language Class Initialized
INFO - 2021-06-02 09:37:44 --> Language Class Initialized
INFO - 2021-06-02 09:37:44 --> Config Class Initialized
INFO - 2021-06-02 09:37:44 --> Loader Class Initialized
INFO - 2021-06-02 09:37:44 --> Helper loaded: url_helper
INFO - 2021-06-02 09:37:44 --> Helper loaded: file_helper
INFO - 2021-06-02 09:37:44 --> Helper loaded: form_helper
INFO - 2021-06-02 09:37:44 --> Helper loaded: my_helper
INFO - 2021-06-02 09:37:44 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:37:44 --> Controller Class Initialized
DEBUG - 2021-06-02 09:37:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:37:44 --> Final output sent to browser
DEBUG - 2021-06-02 09:37:44 --> Total execution time: 0.0811
INFO - 2021-06-02 09:38:34 --> Config Class Initialized
INFO - 2021-06-02 09:38:34 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:38:34 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:38:34 --> Utf8 Class Initialized
INFO - 2021-06-02 09:38:34 --> URI Class Initialized
INFO - 2021-06-02 09:38:34 --> Router Class Initialized
INFO - 2021-06-02 09:38:34 --> Output Class Initialized
INFO - 2021-06-02 09:38:34 --> Security Class Initialized
DEBUG - 2021-06-02 09:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:38:34 --> Input Class Initialized
INFO - 2021-06-02 09:38:34 --> Language Class Initialized
INFO - 2021-06-02 09:38:34 --> Language Class Initialized
INFO - 2021-06-02 09:38:34 --> Config Class Initialized
INFO - 2021-06-02 09:38:34 --> Loader Class Initialized
INFO - 2021-06-02 09:38:34 --> Helper loaded: url_helper
INFO - 2021-06-02 09:38:34 --> Helper loaded: file_helper
INFO - 2021-06-02 09:38:34 --> Helper loaded: form_helper
INFO - 2021-06-02 09:38:34 --> Helper loaded: my_helper
INFO - 2021-06-02 09:38:34 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:38:34 --> Controller Class Initialized
DEBUG - 2021-06-02 09:38:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:38:34 --> Final output sent to browser
DEBUG - 2021-06-02 09:38:34 --> Total execution time: 0.0661
INFO - 2021-06-02 09:39:42 --> Config Class Initialized
INFO - 2021-06-02 09:39:42 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:39:42 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:39:42 --> Utf8 Class Initialized
INFO - 2021-06-02 09:39:42 --> URI Class Initialized
INFO - 2021-06-02 09:39:42 --> Router Class Initialized
INFO - 2021-06-02 09:39:42 --> Output Class Initialized
INFO - 2021-06-02 09:39:42 --> Security Class Initialized
DEBUG - 2021-06-02 09:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:39:42 --> Input Class Initialized
INFO - 2021-06-02 09:39:42 --> Language Class Initialized
INFO - 2021-06-02 09:39:42 --> Language Class Initialized
INFO - 2021-06-02 09:39:42 --> Config Class Initialized
INFO - 2021-06-02 09:39:42 --> Loader Class Initialized
INFO - 2021-06-02 09:39:42 --> Helper loaded: url_helper
INFO - 2021-06-02 09:39:42 --> Helper loaded: file_helper
INFO - 2021-06-02 09:39:42 --> Helper loaded: form_helper
INFO - 2021-06-02 09:39:42 --> Helper loaded: my_helper
INFO - 2021-06-02 09:39:42 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:39:42 --> Controller Class Initialized
DEBUG - 2021-06-02 09:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:39:42 --> Final output sent to browser
DEBUG - 2021-06-02 09:39:42 --> Total execution time: 0.0821
INFO - 2021-06-02 09:39:58 --> Config Class Initialized
INFO - 2021-06-02 09:39:58 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:39:58 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:39:58 --> Utf8 Class Initialized
INFO - 2021-06-02 09:39:58 --> URI Class Initialized
INFO - 2021-06-02 09:39:58 --> Router Class Initialized
INFO - 2021-06-02 09:39:58 --> Output Class Initialized
INFO - 2021-06-02 09:39:58 --> Security Class Initialized
DEBUG - 2021-06-02 09:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:39:58 --> Input Class Initialized
INFO - 2021-06-02 09:39:58 --> Language Class Initialized
INFO - 2021-06-02 09:39:58 --> Language Class Initialized
INFO - 2021-06-02 09:39:58 --> Config Class Initialized
INFO - 2021-06-02 09:39:58 --> Loader Class Initialized
INFO - 2021-06-02 09:39:58 --> Helper loaded: url_helper
INFO - 2021-06-02 09:39:58 --> Helper loaded: file_helper
INFO - 2021-06-02 09:39:58 --> Helper loaded: form_helper
INFO - 2021-06-02 09:39:58 --> Helper loaded: my_helper
INFO - 2021-06-02 09:39:58 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:39:58 --> Controller Class Initialized
DEBUG - 2021-06-02 09:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:39:58 --> Final output sent to browser
DEBUG - 2021-06-02 09:39:58 --> Total execution time: 0.0733
INFO - 2021-06-02 09:40:54 --> Config Class Initialized
INFO - 2021-06-02 09:40:54 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:40:54 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:40:54 --> Utf8 Class Initialized
INFO - 2021-06-02 09:40:54 --> URI Class Initialized
INFO - 2021-06-02 09:40:54 --> Router Class Initialized
INFO - 2021-06-02 09:40:54 --> Output Class Initialized
INFO - 2021-06-02 09:40:54 --> Security Class Initialized
DEBUG - 2021-06-02 09:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:40:54 --> Input Class Initialized
INFO - 2021-06-02 09:40:54 --> Language Class Initialized
INFO - 2021-06-02 09:40:54 --> Language Class Initialized
INFO - 2021-06-02 09:40:54 --> Config Class Initialized
INFO - 2021-06-02 09:40:54 --> Loader Class Initialized
INFO - 2021-06-02 09:40:54 --> Helper loaded: url_helper
INFO - 2021-06-02 09:40:54 --> Helper loaded: file_helper
INFO - 2021-06-02 09:40:54 --> Helper loaded: form_helper
INFO - 2021-06-02 09:40:54 --> Helper loaded: my_helper
INFO - 2021-06-02 09:40:54 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:40:54 --> Controller Class Initialized
DEBUG - 2021-06-02 09:40:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:40:54 --> Final output sent to browser
DEBUG - 2021-06-02 09:40:54 --> Total execution time: 0.0655
INFO - 2021-06-02 09:40:54 --> Config Class Initialized
INFO - 2021-06-02 09:40:54 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:40:54 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:40:54 --> Utf8 Class Initialized
INFO - 2021-06-02 09:40:54 --> URI Class Initialized
INFO - 2021-06-02 09:40:54 --> Router Class Initialized
INFO - 2021-06-02 09:40:54 --> Output Class Initialized
INFO - 2021-06-02 09:40:54 --> Security Class Initialized
DEBUG - 2021-06-02 09:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:40:54 --> Input Class Initialized
INFO - 2021-06-02 09:40:54 --> Language Class Initialized
INFO - 2021-06-02 09:40:54 --> Language Class Initialized
INFO - 2021-06-02 09:40:54 --> Config Class Initialized
INFO - 2021-06-02 09:40:54 --> Loader Class Initialized
INFO - 2021-06-02 09:40:54 --> Helper loaded: url_helper
INFO - 2021-06-02 09:40:54 --> Helper loaded: file_helper
INFO - 2021-06-02 09:40:54 --> Helper loaded: form_helper
INFO - 2021-06-02 09:40:54 --> Helper loaded: my_helper
INFO - 2021-06-02 09:40:54 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:40:54 --> Controller Class Initialized
DEBUG - 2021-06-02 09:40:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:40:54 --> Final output sent to browser
DEBUG - 2021-06-02 09:40:54 --> Total execution time: 0.0580
INFO - 2021-06-02 09:41:25 --> Config Class Initialized
INFO - 2021-06-02 09:41:25 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:41:25 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:41:25 --> Utf8 Class Initialized
INFO - 2021-06-02 09:41:25 --> URI Class Initialized
INFO - 2021-06-02 09:41:25 --> Router Class Initialized
INFO - 2021-06-02 09:41:25 --> Output Class Initialized
INFO - 2021-06-02 09:41:25 --> Security Class Initialized
DEBUG - 2021-06-02 09:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:41:25 --> Input Class Initialized
INFO - 2021-06-02 09:41:25 --> Language Class Initialized
INFO - 2021-06-02 09:41:25 --> Language Class Initialized
INFO - 2021-06-02 09:41:25 --> Config Class Initialized
INFO - 2021-06-02 09:41:25 --> Loader Class Initialized
INFO - 2021-06-02 09:41:25 --> Helper loaded: url_helper
INFO - 2021-06-02 09:41:25 --> Helper loaded: file_helper
INFO - 2021-06-02 09:41:25 --> Helper loaded: form_helper
INFO - 2021-06-02 09:41:25 --> Helper loaded: my_helper
INFO - 2021-06-02 09:41:25 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:41:25 --> Controller Class Initialized
DEBUG - 2021-06-02 09:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:41:25 --> Final output sent to browser
DEBUG - 2021-06-02 09:41:25 --> Total execution time: 0.0690
INFO - 2021-06-02 09:41:33 --> Config Class Initialized
INFO - 2021-06-02 09:41:33 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:41:33 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:41:33 --> Utf8 Class Initialized
INFO - 2021-06-02 09:41:33 --> URI Class Initialized
INFO - 2021-06-02 09:41:33 --> Router Class Initialized
INFO - 2021-06-02 09:41:33 --> Output Class Initialized
INFO - 2021-06-02 09:41:33 --> Security Class Initialized
DEBUG - 2021-06-02 09:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:41:33 --> Input Class Initialized
INFO - 2021-06-02 09:41:33 --> Language Class Initialized
INFO - 2021-06-02 09:41:33 --> Language Class Initialized
INFO - 2021-06-02 09:41:33 --> Config Class Initialized
INFO - 2021-06-02 09:41:33 --> Loader Class Initialized
INFO - 2021-06-02 09:41:33 --> Helper loaded: url_helper
INFO - 2021-06-02 09:41:33 --> Helper loaded: file_helper
INFO - 2021-06-02 09:41:33 --> Helper loaded: form_helper
INFO - 2021-06-02 09:41:33 --> Helper loaded: my_helper
INFO - 2021-06-02 09:41:33 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:41:33 --> Controller Class Initialized
DEBUG - 2021-06-02 09:41:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:41:33 --> Final output sent to browser
DEBUG - 2021-06-02 09:41:33 --> Total execution time: 0.0637
INFO - 2021-06-02 09:41:47 --> Config Class Initialized
INFO - 2021-06-02 09:41:47 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:41:47 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:41:47 --> Utf8 Class Initialized
INFO - 2021-06-02 09:41:47 --> URI Class Initialized
INFO - 2021-06-02 09:41:47 --> Router Class Initialized
INFO - 2021-06-02 09:41:47 --> Output Class Initialized
INFO - 2021-06-02 09:41:47 --> Security Class Initialized
DEBUG - 2021-06-02 09:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:41:47 --> Input Class Initialized
INFO - 2021-06-02 09:41:47 --> Language Class Initialized
INFO - 2021-06-02 09:41:47 --> Language Class Initialized
INFO - 2021-06-02 09:41:47 --> Config Class Initialized
INFO - 2021-06-02 09:41:47 --> Loader Class Initialized
INFO - 2021-06-02 09:41:47 --> Helper loaded: url_helper
INFO - 2021-06-02 09:41:47 --> Helper loaded: file_helper
INFO - 2021-06-02 09:41:47 --> Helper loaded: form_helper
INFO - 2021-06-02 09:41:47 --> Helper loaded: my_helper
INFO - 2021-06-02 09:41:47 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:41:47 --> Controller Class Initialized
DEBUG - 2021-06-02 09:41:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:41:47 --> Final output sent to browser
DEBUG - 2021-06-02 09:41:47 --> Total execution time: 0.0687
INFO - 2021-06-02 09:41:56 --> Config Class Initialized
INFO - 2021-06-02 09:41:56 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:41:56 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:41:56 --> Utf8 Class Initialized
INFO - 2021-06-02 09:41:56 --> URI Class Initialized
INFO - 2021-06-02 09:41:56 --> Router Class Initialized
INFO - 2021-06-02 09:41:56 --> Output Class Initialized
INFO - 2021-06-02 09:41:56 --> Security Class Initialized
DEBUG - 2021-06-02 09:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:41:56 --> Input Class Initialized
INFO - 2021-06-02 09:41:56 --> Language Class Initialized
INFO - 2021-06-02 09:41:56 --> Language Class Initialized
INFO - 2021-06-02 09:41:56 --> Config Class Initialized
INFO - 2021-06-02 09:41:56 --> Loader Class Initialized
INFO - 2021-06-02 09:41:56 --> Helper loaded: url_helper
INFO - 2021-06-02 09:41:56 --> Helper loaded: file_helper
INFO - 2021-06-02 09:41:56 --> Helper loaded: form_helper
INFO - 2021-06-02 09:41:56 --> Helper loaded: my_helper
INFO - 2021-06-02 09:41:56 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:41:56 --> Controller Class Initialized
DEBUG - 2021-06-02 09:41:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:41:56 --> Final output sent to browser
DEBUG - 2021-06-02 09:41:56 --> Total execution time: 0.0545
INFO - 2021-06-02 09:42:02 --> Config Class Initialized
INFO - 2021-06-02 09:42:02 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:42:02 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:42:02 --> Utf8 Class Initialized
INFO - 2021-06-02 09:42:02 --> URI Class Initialized
INFO - 2021-06-02 09:42:02 --> Router Class Initialized
INFO - 2021-06-02 09:42:02 --> Output Class Initialized
INFO - 2021-06-02 09:42:02 --> Security Class Initialized
DEBUG - 2021-06-02 09:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:42:02 --> Input Class Initialized
INFO - 2021-06-02 09:42:02 --> Language Class Initialized
INFO - 2021-06-02 09:42:02 --> Language Class Initialized
INFO - 2021-06-02 09:42:02 --> Config Class Initialized
INFO - 2021-06-02 09:42:02 --> Loader Class Initialized
INFO - 2021-06-02 09:42:02 --> Helper loaded: url_helper
INFO - 2021-06-02 09:42:02 --> Helper loaded: file_helper
INFO - 2021-06-02 09:42:02 --> Helper loaded: form_helper
INFO - 2021-06-02 09:42:02 --> Helper loaded: my_helper
INFO - 2021-06-02 09:42:02 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:42:02 --> Controller Class Initialized
DEBUG - 2021-06-02 09:42:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:42:02 --> Final output sent to browser
DEBUG - 2021-06-02 09:42:02 --> Total execution time: 0.0761
INFO - 2021-06-02 09:43:16 --> Config Class Initialized
INFO - 2021-06-02 09:43:16 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:43:16 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:43:16 --> Utf8 Class Initialized
INFO - 2021-06-02 09:43:16 --> URI Class Initialized
INFO - 2021-06-02 09:43:16 --> Router Class Initialized
INFO - 2021-06-02 09:43:16 --> Output Class Initialized
INFO - 2021-06-02 09:43:16 --> Security Class Initialized
DEBUG - 2021-06-02 09:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:43:16 --> Input Class Initialized
INFO - 2021-06-02 09:43:16 --> Language Class Initialized
INFO - 2021-06-02 09:43:16 --> Language Class Initialized
INFO - 2021-06-02 09:43:16 --> Config Class Initialized
INFO - 2021-06-02 09:43:16 --> Loader Class Initialized
INFO - 2021-06-02 09:43:16 --> Helper loaded: url_helper
INFO - 2021-06-02 09:43:16 --> Helper loaded: file_helper
INFO - 2021-06-02 09:43:16 --> Helper loaded: form_helper
INFO - 2021-06-02 09:43:16 --> Helper loaded: my_helper
INFO - 2021-06-02 09:43:16 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:43:16 --> Controller Class Initialized
DEBUG - 2021-06-02 09:43:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:43:16 --> Final output sent to browser
DEBUG - 2021-06-02 09:43:16 --> Total execution time: 0.0683
INFO - 2021-06-02 09:43:39 --> Config Class Initialized
INFO - 2021-06-02 09:43:39 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:43:39 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:43:39 --> Utf8 Class Initialized
INFO - 2021-06-02 09:43:39 --> URI Class Initialized
INFO - 2021-06-02 09:43:39 --> Router Class Initialized
INFO - 2021-06-02 09:43:39 --> Output Class Initialized
INFO - 2021-06-02 09:43:39 --> Security Class Initialized
DEBUG - 2021-06-02 09:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:43:39 --> Input Class Initialized
INFO - 2021-06-02 09:43:39 --> Language Class Initialized
INFO - 2021-06-02 09:43:39 --> Language Class Initialized
INFO - 2021-06-02 09:43:39 --> Config Class Initialized
INFO - 2021-06-02 09:43:39 --> Loader Class Initialized
INFO - 2021-06-02 09:43:39 --> Helper loaded: url_helper
INFO - 2021-06-02 09:43:39 --> Helper loaded: file_helper
INFO - 2021-06-02 09:43:39 --> Helper loaded: form_helper
INFO - 2021-06-02 09:43:39 --> Helper loaded: my_helper
INFO - 2021-06-02 09:43:39 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:43:39 --> Controller Class Initialized
DEBUG - 2021-06-02 09:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:43:39 --> Final output sent to browser
DEBUG - 2021-06-02 09:43:39 --> Total execution time: 0.0860
INFO - 2021-06-02 09:44:11 --> Config Class Initialized
INFO - 2021-06-02 09:44:11 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:44:11 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:44:11 --> Utf8 Class Initialized
INFO - 2021-06-02 09:44:11 --> URI Class Initialized
INFO - 2021-06-02 09:44:11 --> Router Class Initialized
INFO - 2021-06-02 09:44:11 --> Output Class Initialized
INFO - 2021-06-02 09:44:11 --> Security Class Initialized
DEBUG - 2021-06-02 09:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:44:11 --> Input Class Initialized
INFO - 2021-06-02 09:44:11 --> Language Class Initialized
INFO - 2021-06-02 09:44:11 --> Language Class Initialized
INFO - 2021-06-02 09:44:11 --> Config Class Initialized
INFO - 2021-06-02 09:44:11 --> Loader Class Initialized
INFO - 2021-06-02 09:44:11 --> Helper loaded: url_helper
INFO - 2021-06-02 09:44:11 --> Helper loaded: file_helper
INFO - 2021-06-02 09:44:11 --> Helper loaded: form_helper
INFO - 2021-06-02 09:44:11 --> Helper loaded: my_helper
INFO - 2021-06-02 09:44:11 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:44:11 --> Controller Class Initialized
DEBUG - 2021-06-02 09:44:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:44:11 --> Final output sent to browser
DEBUG - 2021-06-02 09:44:11 --> Total execution time: 0.0724
INFO - 2021-06-02 09:44:40 --> Config Class Initialized
INFO - 2021-06-02 09:44:40 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:44:40 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:44:40 --> Utf8 Class Initialized
INFO - 2021-06-02 09:44:40 --> URI Class Initialized
INFO - 2021-06-02 09:44:40 --> Router Class Initialized
INFO - 2021-06-02 09:44:40 --> Output Class Initialized
INFO - 2021-06-02 09:44:40 --> Security Class Initialized
DEBUG - 2021-06-02 09:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:44:40 --> Input Class Initialized
INFO - 2021-06-02 09:44:40 --> Language Class Initialized
INFO - 2021-06-02 09:44:40 --> Language Class Initialized
INFO - 2021-06-02 09:44:40 --> Config Class Initialized
INFO - 2021-06-02 09:44:40 --> Loader Class Initialized
INFO - 2021-06-02 09:44:40 --> Helper loaded: url_helper
INFO - 2021-06-02 09:44:40 --> Helper loaded: file_helper
INFO - 2021-06-02 09:44:40 --> Helper loaded: form_helper
INFO - 2021-06-02 09:44:40 --> Helper loaded: my_helper
INFO - 2021-06-02 09:44:40 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:44:40 --> Controller Class Initialized
DEBUG - 2021-06-02 09:44:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:44:40 --> Final output sent to browser
DEBUG - 2021-06-02 09:44:40 --> Total execution time: 0.0943
INFO - 2021-06-02 09:45:26 --> Config Class Initialized
INFO - 2021-06-02 09:45:26 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:45:26 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:45:26 --> Utf8 Class Initialized
INFO - 2021-06-02 09:45:26 --> URI Class Initialized
INFO - 2021-06-02 09:45:26 --> Router Class Initialized
INFO - 2021-06-02 09:45:26 --> Output Class Initialized
INFO - 2021-06-02 09:45:26 --> Security Class Initialized
DEBUG - 2021-06-02 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:45:26 --> Input Class Initialized
INFO - 2021-06-02 09:45:26 --> Language Class Initialized
INFO - 2021-06-02 09:45:26 --> Language Class Initialized
INFO - 2021-06-02 09:45:26 --> Config Class Initialized
INFO - 2021-06-02 09:45:26 --> Loader Class Initialized
INFO - 2021-06-02 09:45:26 --> Helper loaded: url_helper
INFO - 2021-06-02 09:45:26 --> Helper loaded: file_helper
INFO - 2021-06-02 09:45:26 --> Helper loaded: form_helper
INFO - 2021-06-02 09:45:26 --> Helper loaded: my_helper
INFO - 2021-06-02 09:45:26 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:45:26 --> Controller Class Initialized
DEBUG - 2021-06-02 09:45:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:45:26 --> Final output sent to browser
DEBUG - 2021-06-02 09:45:26 --> Total execution time: 0.0698
INFO - 2021-06-02 09:45:30 --> Config Class Initialized
INFO - 2021-06-02 09:45:30 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:45:30 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:45:30 --> Utf8 Class Initialized
INFO - 2021-06-02 09:45:30 --> URI Class Initialized
INFO - 2021-06-02 09:45:30 --> Router Class Initialized
INFO - 2021-06-02 09:45:30 --> Output Class Initialized
INFO - 2021-06-02 09:45:30 --> Security Class Initialized
DEBUG - 2021-06-02 09:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:45:30 --> Input Class Initialized
INFO - 2021-06-02 09:45:30 --> Language Class Initialized
INFO - 2021-06-02 09:45:30 --> Language Class Initialized
INFO - 2021-06-02 09:45:30 --> Config Class Initialized
INFO - 2021-06-02 09:45:30 --> Loader Class Initialized
INFO - 2021-06-02 09:45:30 --> Helper loaded: url_helper
INFO - 2021-06-02 09:45:30 --> Helper loaded: file_helper
INFO - 2021-06-02 09:45:30 --> Helper loaded: form_helper
INFO - 2021-06-02 09:45:30 --> Helper loaded: my_helper
INFO - 2021-06-02 09:45:30 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:45:30 --> Controller Class Initialized
DEBUG - 2021-06-02 09:45:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:45:30 --> Final output sent to browser
DEBUG - 2021-06-02 09:45:30 --> Total execution time: 0.0699
INFO - 2021-06-02 09:45:42 --> Config Class Initialized
INFO - 2021-06-02 09:45:42 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:45:42 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:45:42 --> Utf8 Class Initialized
INFO - 2021-06-02 09:45:42 --> URI Class Initialized
INFO - 2021-06-02 09:45:42 --> Router Class Initialized
INFO - 2021-06-02 09:45:42 --> Output Class Initialized
INFO - 2021-06-02 09:45:42 --> Security Class Initialized
DEBUG - 2021-06-02 09:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:45:42 --> Input Class Initialized
INFO - 2021-06-02 09:45:42 --> Language Class Initialized
INFO - 2021-06-02 09:45:42 --> Language Class Initialized
INFO - 2021-06-02 09:45:42 --> Config Class Initialized
INFO - 2021-06-02 09:45:42 --> Loader Class Initialized
INFO - 2021-06-02 09:45:42 --> Helper loaded: url_helper
INFO - 2021-06-02 09:45:42 --> Helper loaded: file_helper
INFO - 2021-06-02 09:45:42 --> Helper loaded: form_helper
INFO - 2021-06-02 09:45:42 --> Helper loaded: my_helper
INFO - 2021-06-02 09:45:42 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:45:42 --> Controller Class Initialized
DEBUG - 2021-06-02 09:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:45:42 --> Final output sent to browser
DEBUG - 2021-06-02 09:45:42 --> Total execution time: 0.0578
INFO - 2021-06-02 09:46:10 --> Config Class Initialized
INFO - 2021-06-02 09:46:10 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:46:10 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:46:10 --> Utf8 Class Initialized
INFO - 2021-06-02 09:46:10 --> URI Class Initialized
INFO - 2021-06-02 09:46:10 --> Router Class Initialized
INFO - 2021-06-02 09:46:10 --> Output Class Initialized
INFO - 2021-06-02 09:46:10 --> Security Class Initialized
DEBUG - 2021-06-02 09:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:46:10 --> Input Class Initialized
INFO - 2021-06-02 09:46:10 --> Language Class Initialized
INFO - 2021-06-02 09:46:10 --> Language Class Initialized
INFO - 2021-06-02 09:46:10 --> Config Class Initialized
INFO - 2021-06-02 09:46:10 --> Loader Class Initialized
INFO - 2021-06-02 09:46:10 --> Helper loaded: url_helper
INFO - 2021-06-02 09:46:10 --> Helper loaded: file_helper
INFO - 2021-06-02 09:46:10 --> Helper loaded: form_helper
INFO - 2021-06-02 09:46:10 --> Helper loaded: my_helper
INFO - 2021-06-02 09:46:10 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:46:10 --> Controller Class Initialized
DEBUG - 2021-06-02 09:46:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-02 09:46:10 --> Final output sent to browser
DEBUG - 2021-06-02 09:46:10 --> Total execution time: 0.0563
INFO - 2021-06-02 09:50:26 --> Config Class Initialized
INFO - 2021-06-02 09:50:26 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:26 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:26 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:26 --> URI Class Initialized
INFO - 2021-06-02 09:50:26 --> Router Class Initialized
INFO - 2021-06-02 09:50:26 --> Output Class Initialized
INFO - 2021-06-02 09:50:26 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:26 --> Input Class Initialized
INFO - 2021-06-02 09:50:26 --> Language Class Initialized
INFO - 2021-06-02 09:50:26 --> Language Class Initialized
INFO - 2021-06-02 09:50:26 --> Config Class Initialized
INFO - 2021-06-02 09:50:26 --> Loader Class Initialized
INFO - 2021-06-02 09:50:26 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:26 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:26 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:26 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:26 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:26 --> Controller Class Initialized
INFO - 2021-06-02 09:50:26 --> Helper loaded: cookie_helper
INFO - 2021-06-02 09:50:26 --> Config Class Initialized
INFO - 2021-06-02 09:50:26 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:26 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:26 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:26 --> URI Class Initialized
INFO - 2021-06-02 09:50:26 --> Router Class Initialized
INFO - 2021-06-02 09:50:26 --> Output Class Initialized
INFO - 2021-06-02 09:50:26 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:26 --> Input Class Initialized
INFO - 2021-06-02 09:50:26 --> Language Class Initialized
INFO - 2021-06-02 09:50:26 --> Language Class Initialized
INFO - 2021-06-02 09:50:26 --> Config Class Initialized
INFO - 2021-06-02 09:50:26 --> Loader Class Initialized
INFO - 2021-06-02 09:50:26 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:26 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:26 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:26 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:26 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:26 --> Controller Class Initialized
DEBUG - 2021-06-02 09:50:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-02 09:50:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 09:50:26 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:26 --> Total execution time: 0.0826
INFO - 2021-06-02 09:50:31 --> Config Class Initialized
INFO - 2021-06-02 09:50:31 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:31 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:31 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:31 --> URI Class Initialized
INFO - 2021-06-02 09:50:31 --> Router Class Initialized
INFO - 2021-06-02 09:50:31 --> Output Class Initialized
INFO - 2021-06-02 09:50:31 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:31 --> Input Class Initialized
INFO - 2021-06-02 09:50:31 --> Language Class Initialized
INFO - 2021-06-02 09:50:31 --> Language Class Initialized
INFO - 2021-06-02 09:50:31 --> Config Class Initialized
INFO - 2021-06-02 09:50:31 --> Loader Class Initialized
INFO - 2021-06-02 09:50:31 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:31 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:31 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:31 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:31 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:31 --> Controller Class Initialized
INFO - 2021-06-02 09:50:31 --> Helper loaded: cookie_helper
INFO - 2021-06-02 09:50:31 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:31 --> Total execution time: 0.0721
INFO - 2021-06-02 09:50:32 --> Config Class Initialized
INFO - 2021-06-02 09:50:32 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:32 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:32 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:32 --> URI Class Initialized
INFO - 2021-06-02 09:50:32 --> Router Class Initialized
INFO - 2021-06-02 09:50:32 --> Output Class Initialized
INFO - 2021-06-02 09:50:32 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:32 --> Input Class Initialized
INFO - 2021-06-02 09:50:32 --> Language Class Initialized
INFO - 2021-06-02 09:50:32 --> Language Class Initialized
INFO - 2021-06-02 09:50:32 --> Config Class Initialized
INFO - 2021-06-02 09:50:32 --> Loader Class Initialized
INFO - 2021-06-02 09:50:32 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:32 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:32 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:32 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:32 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:32 --> Controller Class Initialized
DEBUG - 2021-06-02 09:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-02 09:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 09:50:32 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:32 --> Total execution time: 0.1665
INFO - 2021-06-02 09:50:33 --> Config Class Initialized
INFO - 2021-06-02 09:50:33 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:33 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:33 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:33 --> URI Class Initialized
INFO - 2021-06-02 09:50:33 --> Router Class Initialized
INFO - 2021-06-02 09:50:33 --> Output Class Initialized
INFO - 2021-06-02 09:50:33 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:33 --> Input Class Initialized
INFO - 2021-06-02 09:50:33 --> Language Class Initialized
INFO - 2021-06-02 09:50:33 --> Language Class Initialized
INFO - 2021-06-02 09:50:33 --> Config Class Initialized
INFO - 2021-06-02 09:50:33 --> Loader Class Initialized
INFO - 2021-06-02 09:50:33 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:33 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:33 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:33 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:33 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:34 --> Controller Class Initialized
DEBUG - 2021-06-02 09:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-06-02 09:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 09:50:34 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:34 --> Total execution time: 0.1020
INFO - 2021-06-02 09:50:34 --> Config Class Initialized
INFO - 2021-06-02 09:50:34 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:34 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:34 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:34 --> URI Class Initialized
INFO - 2021-06-02 09:50:34 --> Router Class Initialized
INFO - 2021-06-02 09:50:34 --> Output Class Initialized
INFO - 2021-06-02 09:50:34 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:34 --> Input Class Initialized
INFO - 2021-06-02 09:50:34 --> Language Class Initialized
INFO - 2021-06-02 09:50:34 --> Language Class Initialized
INFO - 2021-06-02 09:50:34 --> Config Class Initialized
INFO - 2021-06-02 09:50:34 --> Loader Class Initialized
INFO - 2021-06-02 09:50:34 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:34 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:34 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:34 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:34 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:34 --> Controller Class Initialized
INFO - 2021-06-02 09:50:37 --> Config Class Initialized
INFO - 2021-06-02 09:50:37 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:37 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:37 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:37 --> URI Class Initialized
INFO - 2021-06-02 09:50:37 --> Router Class Initialized
INFO - 2021-06-02 09:50:37 --> Output Class Initialized
INFO - 2021-06-02 09:50:37 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:37 --> Input Class Initialized
INFO - 2021-06-02 09:50:37 --> Language Class Initialized
INFO - 2021-06-02 09:50:37 --> Language Class Initialized
INFO - 2021-06-02 09:50:37 --> Config Class Initialized
INFO - 2021-06-02 09:50:37 --> Loader Class Initialized
INFO - 2021-06-02 09:50:37 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:37 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:37 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:37 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:37 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:37 --> Controller Class Initialized
DEBUG - 2021-06-02 09:50:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-06-02 09:50:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 09:50:37 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:37 --> Total execution time: 0.1082
INFO - 2021-06-02 09:50:37 --> Config Class Initialized
INFO - 2021-06-02 09:50:37 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:37 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:37 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:37 --> URI Class Initialized
INFO - 2021-06-02 09:50:37 --> Router Class Initialized
INFO - 2021-06-02 09:50:37 --> Output Class Initialized
INFO - 2021-06-02 09:50:37 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:37 --> Input Class Initialized
INFO - 2021-06-02 09:50:37 --> Language Class Initialized
INFO - 2021-06-02 09:50:37 --> Language Class Initialized
INFO - 2021-06-02 09:50:37 --> Config Class Initialized
INFO - 2021-06-02 09:50:37 --> Loader Class Initialized
INFO - 2021-06-02 09:50:37 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:37 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:37 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:37 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:37 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:37 --> Controller Class Initialized
INFO - 2021-06-02 09:50:46 --> Config Class Initialized
INFO - 2021-06-02 09:50:46 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:46 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:46 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:46 --> URI Class Initialized
INFO - 2021-06-02 09:50:46 --> Router Class Initialized
INFO - 2021-06-02 09:50:46 --> Output Class Initialized
INFO - 2021-06-02 09:50:46 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:46 --> Input Class Initialized
INFO - 2021-06-02 09:50:46 --> Language Class Initialized
INFO - 2021-06-02 09:50:46 --> Language Class Initialized
INFO - 2021-06-02 09:50:46 --> Config Class Initialized
INFO - 2021-06-02 09:50:46 --> Loader Class Initialized
INFO - 2021-06-02 09:50:46 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:46 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:46 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:46 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:46 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:46 --> Controller Class Initialized
INFO - 2021-06-02 09:50:46 --> Helper loaded: cookie_helper
INFO - 2021-06-02 09:50:46 --> Config Class Initialized
INFO - 2021-06-02 09:50:46 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:46 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:46 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:46 --> URI Class Initialized
INFO - 2021-06-02 09:50:46 --> Router Class Initialized
INFO - 2021-06-02 09:50:46 --> Output Class Initialized
INFO - 2021-06-02 09:50:46 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:46 --> Input Class Initialized
INFO - 2021-06-02 09:50:46 --> Language Class Initialized
INFO - 2021-06-02 09:50:46 --> Language Class Initialized
INFO - 2021-06-02 09:50:46 --> Config Class Initialized
INFO - 2021-06-02 09:50:46 --> Loader Class Initialized
INFO - 2021-06-02 09:50:46 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:46 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:46 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:46 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:46 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:46 --> Controller Class Initialized
DEBUG - 2021-06-02 09:50:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-02 09:50:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 09:50:46 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:46 --> Total execution time: 0.0459
INFO - 2021-06-02 09:50:54 --> Config Class Initialized
INFO - 2021-06-02 09:50:54 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:54 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:54 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:54 --> URI Class Initialized
INFO - 2021-06-02 09:50:54 --> Router Class Initialized
INFO - 2021-06-02 09:50:54 --> Output Class Initialized
INFO - 2021-06-02 09:50:54 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:54 --> Input Class Initialized
INFO - 2021-06-02 09:50:54 --> Language Class Initialized
INFO - 2021-06-02 09:50:54 --> Language Class Initialized
INFO - 2021-06-02 09:50:54 --> Config Class Initialized
INFO - 2021-06-02 09:50:54 --> Loader Class Initialized
INFO - 2021-06-02 09:50:54 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:54 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:54 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:54 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:54 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:54 --> Controller Class Initialized
INFO - 2021-06-02 09:50:54 --> Helper loaded: cookie_helper
INFO - 2021-06-02 09:50:54 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:54 --> Total execution time: 0.0595
INFO - 2021-06-02 09:50:54 --> Config Class Initialized
INFO - 2021-06-02 09:50:54 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:54 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:54 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:54 --> URI Class Initialized
INFO - 2021-06-02 09:50:54 --> Router Class Initialized
INFO - 2021-06-02 09:50:54 --> Output Class Initialized
INFO - 2021-06-02 09:50:54 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:54 --> Input Class Initialized
INFO - 2021-06-02 09:50:54 --> Language Class Initialized
INFO - 2021-06-02 09:50:54 --> Language Class Initialized
INFO - 2021-06-02 09:50:54 --> Config Class Initialized
INFO - 2021-06-02 09:50:54 --> Loader Class Initialized
INFO - 2021-06-02 09:50:54 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:54 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:54 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:54 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:54 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:54 --> Controller Class Initialized
DEBUG - 2021-06-02 09:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-02 09:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 09:50:54 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:54 --> Total execution time: 0.0746
INFO - 2021-06-02 09:50:56 --> Config Class Initialized
INFO - 2021-06-02 09:50:56 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:56 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:56 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:56 --> URI Class Initialized
INFO - 2021-06-02 09:50:56 --> Router Class Initialized
INFO - 2021-06-02 09:50:56 --> Output Class Initialized
INFO - 2021-06-02 09:50:56 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:56 --> Input Class Initialized
INFO - 2021-06-02 09:50:56 --> Language Class Initialized
INFO - 2021-06-02 09:50:56 --> Language Class Initialized
INFO - 2021-06-02 09:50:56 --> Config Class Initialized
INFO - 2021-06-02 09:50:56 --> Loader Class Initialized
INFO - 2021-06-02 09:50:56 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:56 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:56 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:56 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:56 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:56 --> Controller Class Initialized
DEBUG - 2021-06-02 09:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-02 09:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 09:50:56 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:56 --> Total execution time: 0.0865
INFO - 2021-06-02 09:50:58 --> Config Class Initialized
INFO - 2021-06-02 09:50:58 --> Hooks Class Initialized
DEBUG - 2021-06-02 09:50:58 --> UTF-8 Support Enabled
INFO - 2021-06-02 09:50:58 --> Utf8 Class Initialized
INFO - 2021-06-02 09:50:58 --> URI Class Initialized
INFO - 2021-06-02 09:50:58 --> Router Class Initialized
INFO - 2021-06-02 09:50:58 --> Output Class Initialized
INFO - 2021-06-02 09:50:58 --> Security Class Initialized
DEBUG - 2021-06-02 09:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 09:50:59 --> Input Class Initialized
INFO - 2021-06-02 09:50:59 --> Language Class Initialized
INFO - 2021-06-02 09:50:59 --> Language Class Initialized
INFO - 2021-06-02 09:50:59 --> Config Class Initialized
INFO - 2021-06-02 09:50:59 --> Loader Class Initialized
INFO - 2021-06-02 09:50:59 --> Helper loaded: url_helper
INFO - 2021-06-02 09:50:59 --> Helper loaded: file_helper
INFO - 2021-06-02 09:50:59 --> Helper loaded: form_helper
INFO - 2021-06-02 09:50:59 --> Helper loaded: my_helper
INFO - 2021-06-02 09:50:59 --> Database Driver Class Initialized
DEBUG - 2021-06-02 09:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 09:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 09:50:59 --> Controller Class Initialized
DEBUG - 2021-06-02 09:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-06-02 09:50:59 --> Final output sent to browser
DEBUG - 2021-06-02 09:50:59 --> Total execution time: 0.0834
INFO - 2021-06-02 10:04:41 --> Config Class Initialized
INFO - 2021-06-02 10:04:41 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:04:41 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:04:41 --> Utf8 Class Initialized
INFO - 2021-06-02 10:04:41 --> URI Class Initialized
INFO - 2021-06-02 10:04:41 --> Router Class Initialized
INFO - 2021-06-02 10:04:41 --> Output Class Initialized
INFO - 2021-06-02 10:04:41 --> Security Class Initialized
DEBUG - 2021-06-02 10:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:04:41 --> Input Class Initialized
INFO - 2021-06-02 10:04:41 --> Language Class Initialized
INFO - 2021-06-02 10:04:41 --> Language Class Initialized
INFO - 2021-06-02 10:04:41 --> Config Class Initialized
INFO - 2021-06-02 10:04:41 --> Loader Class Initialized
INFO - 2021-06-02 10:04:41 --> Helper loaded: url_helper
INFO - 2021-06-02 10:04:41 --> Helper loaded: file_helper
INFO - 2021-06-02 10:04:41 --> Helper loaded: form_helper
INFO - 2021-06-02 10:04:41 --> Helper loaded: my_helper
INFO - 2021-06-02 10:04:41 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:04:41 --> Controller Class Initialized
INFO - 2021-06-02 10:04:41 --> Helper loaded: cookie_helper
INFO - 2021-06-02 10:04:41 --> Config Class Initialized
INFO - 2021-06-02 10:04:41 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:04:41 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:04:41 --> Utf8 Class Initialized
INFO - 2021-06-02 10:04:41 --> URI Class Initialized
INFO - 2021-06-02 10:04:41 --> Router Class Initialized
INFO - 2021-06-02 10:04:41 --> Output Class Initialized
INFO - 2021-06-02 10:04:41 --> Security Class Initialized
DEBUG - 2021-06-02 10:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:04:41 --> Input Class Initialized
INFO - 2021-06-02 10:04:41 --> Language Class Initialized
INFO - 2021-06-02 10:04:41 --> Language Class Initialized
INFO - 2021-06-02 10:04:41 --> Config Class Initialized
INFO - 2021-06-02 10:04:41 --> Loader Class Initialized
INFO - 2021-06-02 10:04:41 --> Helper loaded: url_helper
INFO - 2021-06-02 10:04:41 --> Helper loaded: file_helper
INFO - 2021-06-02 10:04:41 --> Helper loaded: form_helper
INFO - 2021-06-02 10:04:41 --> Helper loaded: my_helper
INFO - 2021-06-02 10:04:41 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:04:41 --> Controller Class Initialized
DEBUG - 2021-06-02 10:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-02 10:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:04:41 --> Final output sent to browser
DEBUG - 2021-06-02 10:04:41 --> Total execution time: 0.0734
INFO - 2021-06-02 10:05:01 --> Config Class Initialized
INFO - 2021-06-02 10:05:01 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:01 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:01 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:01 --> URI Class Initialized
INFO - 2021-06-02 10:05:01 --> Router Class Initialized
INFO - 2021-06-02 10:05:01 --> Output Class Initialized
INFO - 2021-06-02 10:05:01 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:01 --> Input Class Initialized
INFO - 2021-06-02 10:05:01 --> Language Class Initialized
INFO - 2021-06-02 10:05:01 --> Language Class Initialized
INFO - 2021-06-02 10:05:01 --> Config Class Initialized
INFO - 2021-06-02 10:05:01 --> Loader Class Initialized
INFO - 2021-06-02 10:05:01 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:01 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:01 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:01 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:01 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:01 --> Controller Class Initialized
INFO - 2021-06-02 10:05:01 --> Helper loaded: cookie_helper
INFO - 2021-06-02 10:05:01 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:01 --> Total execution time: 0.0718
INFO - 2021-06-02 10:05:02 --> Config Class Initialized
INFO - 2021-06-02 10:05:02 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:02 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:02 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:02 --> URI Class Initialized
INFO - 2021-06-02 10:05:02 --> Router Class Initialized
INFO - 2021-06-02 10:05:02 --> Output Class Initialized
INFO - 2021-06-02 10:05:02 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:02 --> Input Class Initialized
INFO - 2021-06-02 10:05:02 --> Language Class Initialized
INFO - 2021-06-02 10:05:02 --> Language Class Initialized
INFO - 2021-06-02 10:05:02 --> Config Class Initialized
INFO - 2021-06-02 10:05:02 --> Loader Class Initialized
INFO - 2021-06-02 10:05:02 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:02 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:02 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:02 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:02 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:02 --> Controller Class Initialized
DEBUG - 2021-06-02 10:05:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-02 10:05:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:05:02 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:02 --> Total execution time: 0.0699
INFO - 2021-06-02 10:05:05 --> Config Class Initialized
INFO - 2021-06-02 10:05:05 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:05 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:05 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:05 --> URI Class Initialized
INFO - 2021-06-02 10:05:05 --> Router Class Initialized
INFO - 2021-06-02 10:05:05 --> Output Class Initialized
INFO - 2021-06-02 10:05:05 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:05 --> Input Class Initialized
INFO - 2021-06-02 10:05:05 --> Language Class Initialized
INFO - 2021-06-02 10:05:05 --> Language Class Initialized
INFO - 2021-06-02 10:05:05 --> Config Class Initialized
INFO - 2021-06-02 10:05:05 --> Loader Class Initialized
INFO - 2021-06-02 10:05:05 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:05 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:05 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:05 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:05 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:05 --> Controller Class Initialized
INFO - 2021-06-02 10:05:05 --> Helper loaded: cookie_helper
INFO - 2021-06-02 10:05:05 --> Config Class Initialized
INFO - 2021-06-02 10:05:05 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:05 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:05 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:05 --> URI Class Initialized
INFO - 2021-06-02 10:05:05 --> Router Class Initialized
INFO - 2021-06-02 10:05:05 --> Output Class Initialized
INFO - 2021-06-02 10:05:05 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:05 --> Input Class Initialized
INFO - 2021-06-02 10:05:05 --> Language Class Initialized
INFO - 2021-06-02 10:05:05 --> Language Class Initialized
INFO - 2021-06-02 10:05:05 --> Config Class Initialized
INFO - 2021-06-02 10:05:05 --> Loader Class Initialized
INFO - 2021-06-02 10:05:05 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:05 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:05 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:05 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:05 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:05 --> Controller Class Initialized
DEBUG - 2021-06-02 10:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-02 10:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:05:05 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:05 --> Total execution time: 0.0725
INFO - 2021-06-02 10:05:13 --> Config Class Initialized
INFO - 2021-06-02 10:05:13 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:14 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:14 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:14 --> URI Class Initialized
INFO - 2021-06-02 10:05:14 --> Router Class Initialized
INFO - 2021-06-02 10:05:14 --> Output Class Initialized
INFO - 2021-06-02 10:05:14 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:14 --> Input Class Initialized
INFO - 2021-06-02 10:05:14 --> Language Class Initialized
INFO - 2021-06-02 10:05:14 --> Language Class Initialized
INFO - 2021-06-02 10:05:14 --> Config Class Initialized
INFO - 2021-06-02 10:05:14 --> Loader Class Initialized
INFO - 2021-06-02 10:05:14 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:14 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:14 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:14 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:14 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:14 --> Controller Class Initialized
INFO - 2021-06-02 10:05:14 --> Helper loaded: cookie_helper
INFO - 2021-06-02 10:05:14 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:14 --> Total execution time: 0.0569
INFO - 2021-06-02 10:05:14 --> Config Class Initialized
INFO - 2021-06-02 10:05:14 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:14 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:14 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:14 --> URI Class Initialized
INFO - 2021-06-02 10:05:14 --> Router Class Initialized
INFO - 2021-06-02 10:05:14 --> Output Class Initialized
INFO - 2021-06-02 10:05:14 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:14 --> Input Class Initialized
INFO - 2021-06-02 10:05:14 --> Language Class Initialized
INFO - 2021-06-02 10:05:14 --> Language Class Initialized
INFO - 2021-06-02 10:05:14 --> Config Class Initialized
INFO - 2021-06-02 10:05:14 --> Loader Class Initialized
INFO - 2021-06-02 10:05:14 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:14 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:14 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:14 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:14 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:14 --> Controller Class Initialized
DEBUG - 2021-06-02 10:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-02 10:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:05:14 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:14 --> Total execution time: 0.0849
INFO - 2021-06-02 10:05:16 --> Config Class Initialized
INFO - 2021-06-02 10:05:16 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:16 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:16 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:16 --> URI Class Initialized
INFO - 2021-06-02 10:05:16 --> Router Class Initialized
INFO - 2021-06-02 10:05:16 --> Output Class Initialized
INFO - 2021-06-02 10:05:16 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:16 --> Input Class Initialized
INFO - 2021-06-02 10:05:16 --> Language Class Initialized
INFO - 2021-06-02 10:05:16 --> Language Class Initialized
INFO - 2021-06-02 10:05:16 --> Config Class Initialized
INFO - 2021-06-02 10:05:16 --> Loader Class Initialized
INFO - 2021-06-02 10:05:16 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:16 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:16 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:16 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:16 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:16 --> Controller Class Initialized
DEBUG - 2021-06-02 10:05:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-02 10:05:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:05:16 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:16 --> Total execution time: 0.0774
INFO - 2021-06-02 10:05:19 --> Config Class Initialized
INFO - 2021-06-02 10:05:19 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:19 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:19 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:19 --> URI Class Initialized
INFO - 2021-06-02 10:05:19 --> Router Class Initialized
INFO - 2021-06-02 10:05:19 --> Output Class Initialized
INFO - 2021-06-02 10:05:19 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:19 --> Input Class Initialized
INFO - 2021-06-02 10:05:19 --> Language Class Initialized
INFO - 2021-06-02 10:05:19 --> Language Class Initialized
INFO - 2021-06-02 10:05:19 --> Config Class Initialized
INFO - 2021-06-02 10:05:19 --> Loader Class Initialized
INFO - 2021-06-02 10:05:19 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:19 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:19 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:19 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:19 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:19 --> Controller Class Initialized
DEBUG - 2021-06-02 10:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-06-02 10:05:19 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:19 --> Total execution time: 0.1040
INFO - 2021-06-02 10:05:39 --> Config Class Initialized
INFO - 2021-06-02 10:05:39 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:39 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:39 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:39 --> URI Class Initialized
INFO - 2021-06-02 10:05:39 --> Router Class Initialized
INFO - 2021-06-02 10:05:39 --> Output Class Initialized
INFO - 2021-06-02 10:05:39 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:39 --> Input Class Initialized
INFO - 2021-06-02 10:05:39 --> Language Class Initialized
INFO - 2021-06-02 10:05:39 --> Language Class Initialized
INFO - 2021-06-02 10:05:39 --> Config Class Initialized
INFO - 2021-06-02 10:05:39 --> Loader Class Initialized
INFO - 2021-06-02 10:05:39 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:39 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:39 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:39 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:39 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:39 --> Controller Class Initialized
INFO - 2021-06-02 10:05:39 --> Helper loaded: cookie_helper
INFO - 2021-06-02 10:05:39 --> Config Class Initialized
INFO - 2021-06-02 10:05:39 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:39 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:39 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:39 --> URI Class Initialized
INFO - 2021-06-02 10:05:39 --> Router Class Initialized
INFO - 2021-06-02 10:05:39 --> Output Class Initialized
INFO - 2021-06-02 10:05:39 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:39 --> Input Class Initialized
INFO - 2021-06-02 10:05:39 --> Language Class Initialized
INFO - 2021-06-02 10:05:39 --> Language Class Initialized
INFO - 2021-06-02 10:05:39 --> Config Class Initialized
INFO - 2021-06-02 10:05:39 --> Loader Class Initialized
INFO - 2021-06-02 10:05:39 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:39 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:39 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:39 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:39 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:39 --> Controller Class Initialized
DEBUG - 2021-06-02 10:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-02 10:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:05:39 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:39 --> Total execution time: 0.0676
INFO - 2021-06-02 10:05:46 --> Config Class Initialized
INFO - 2021-06-02 10:05:46 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:46 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:46 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:46 --> URI Class Initialized
INFO - 2021-06-02 10:05:46 --> Router Class Initialized
INFO - 2021-06-02 10:05:46 --> Output Class Initialized
INFO - 2021-06-02 10:05:46 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:46 --> Input Class Initialized
INFO - 2021-06-02 10:05:46 --> Language Class Initialized
INFO - 2021-06-02 10:05:46 --> Language Class Initialized
INFO - 2021-06-02 10:05:46 --> Config Class Initialized
INFO - 2021-06-02 10:05:46 --> Loader Class Initialized
INFO - 2021-06-02 10:05:46 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:46 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:46 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:46 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:46 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:46 --> Controller Class Initialized
INFO - 2021-06-02 10:05:46 --> Helper loaded: cookie_helper
INFO - 2021-06-02 10:05:46 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:46 --> Total execution time: 0.0545
INFO - 2021-06-02 10:05:47 --> Config Class Initialized
INFO - 2021-06-02 10:05:47 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:47 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:47 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:47 --> URI Class Initialized
INFO - 2021-06-02 10:05:47 --> Router Class Initialized
INFO - 2021-06-02 10:05:47 --> Output Class Initialized
INFO - 2021-06-02 10:05:47 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:47 --> Input Class Initialized
INFO - 2021-06-02 10:05:47 --> Language Class Initialized
INFO - 2021-06-02 10:05:47 --> Language Class Initialized
INFO - 2021-06-02 10:05:47 --> Config Class Initialized
INFO - 2021-06-02 10:05:47 --> Loader Class Initialized
INFO - 2021-06-02 10:05:47 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:47 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:47 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:47 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:47 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:47 --> Controller Class Initialized
DEBUG - 2021-06-02 10:05:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-02 10:05:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:05:47 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:47 --> Total execution time: 0.0682
INFO - 2021-06-02 10:05:51 --> Config Class Initialized
INFO - 2021-06-02 10:05:51 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:51 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:51 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:51 --> URI Class Initialized
INFO - 2021-06-02 10:05:51 --> Router Class Initialized
INFO - 2021-06-02 10:05:51 --> Output Class Initialized
INFO - 2021-06-02 10:05:51 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:51 --> Input Class Initialized
INFO - 2021-06-02 10:05:51 --> Language Class Initialized
INFO - 2021-06-02 10:05:51 --> Language Class Initialized
INFO - 2021-06-02 10:05:51 --> Config Class Initialized
INFO - 2021-06-02 10:05:51 --> Loader Class Initialized
INFO - 2021-06-02 10:05:51 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:51 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:51 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:51 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:51 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:51 --> Controller Class Initialized
DEBUG - 2021-06-02 10:05:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-06-02 10:05:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:05:51 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:51 --> Total execution time: 0.0849
INFO - 2021-06-02 10:05:51 --> Config Class Initialized
INFO - 2021-06-02 10:05:51 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:51 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:51 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:51 --> URI Class Initialized
INFO - 2021-06-02 10:05:51 --> Router Class Initialized
INFO - 2021-06-02 10:05:51 --> Output Class Initialized
INFO - 2021-06-02 10:05:51 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:51 --> Input Class Initialized
INFO - 2021-06-02 10:05:51 --> Language Class Initialized
INFO - 2021-06-02 10:05:51 --> Language Class Initialized
INFO - 2021-06-02 10:05:51 --> Config Class Initialized
INFO - 2021-06-02 10:05:51 --> Loader Class Initialized
INFO - 2021-06-02 10:05:51 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:51 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:51 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:51 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:51 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:51 --> Controller Class Initialized
INFO - 2021-06-02 10:05:57 --> Config Class Initialized
INFO - 2021-06-02 10:05:57 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:05:57 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:05:57 --> Utf8 Class Initialized
INFO - 2021-06-02 10:05:57 --> URI Class Initialized
INFO - 2021-06-02 10:05:57 --> Router Class Initialized
INFO - 2021-06-02 10:05:57 --> Output Class Initialized
INFO - 2021-06-02 10:05:57 --> Security Class Initialized
DEBUG - 2021-06-02 10:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:05:57 --> Input Class Initialized
INFO - 2021-06-02 10:05:57 --> Language Class Initialized
INFO - 2021-06-02 10:05:57 --> Language Class Initialized
INFO - 2021-06-02 10:05:57 --> Config Class Initialized
INFO - 2021-06-02 10:05:57 --> Loader Class Initialized
INFO - 2021-06-02 10:05:57 --> Helper loaded: url_helper
INFO - 2021-06-02 10:05:57 --> Helper loaded: file_helper
INFO - 2021-06-02 10:05:57 --> Helper loaded: form_helper
INFO - 2021-06-02 10:05:57 --> Helper loaded: my_helper
INFO - 2021-06-02 10:05:57 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:05:57 --> Controller Class Initialized
DEBUG - 2021-06-02 10:05:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-06-02 10:05:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:05:57 --> Final output sent to browser
DEBUG - 2021-06-02 10:05:57 --> Total execution time: 0.1114
INFO - 2021-06-02 10:06:13 --> Config Class Initialized
INFO - 2021-06-02 10:06:13 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:13 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:13 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:13 --> URI Class Initialized
INFO - 2021-06-02 10:06:13 --> Router Class Initialized
INFO - 2021-06-02 10:06:13 --> Output Class Initialized
INFO - 2021-06-02 10:06:13 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:13 --> Input Class Initialized
INFO - 2021-06-02 10:06:13 --> Language Class Initialized
INFO - 2021-06-02 10:06:13 --> Language Class Initialized
INFO - 2021-06-02 10:06:13 --> Config Class Initialized
INFO - 2021-06-02 10:06:13 --> Loader Class Initialized
INFO - 2021-06-02 10:06:13 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:13 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:13 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:13 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:13 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:13 --> Controller Class Initialized
INFO - 2021-06-02 10:06:13 --> Config Class Initialized
INFO - 2021-06-02 10:06:13 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:13 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:13 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:13 --> URI Class Initialized
INFO - 2021-06-02 10:06:13 --> Router Class Initialized
INFO - 2021-06-02 10:06:13 --> Output Class Initialized
INFO - 2021-06-02 10:06:13 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:13 --> Input Class Initialized
INFO - 2021-06-02 10:06:13 --> Language Class Initialized
INFO - 2021-06-02 10:06:13 --> Language Class Initialized
INFO - 2021-06-02 10:06:13 --> Config Class Initialized
INFO - 2021-06-02 10:06:13 --> Loader Class Initialized
INFO - 2021-06-02 10:06:13 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:13 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:13 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:13 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:13 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:13 --> Controller Class Initialized
DEBUG - 2021-06-02 10:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-06-02 10:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:06:13 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:13 --> Total execution time: 0.0441
INFO - 2021-06-02 10:06:13 --> Config Class Initialized
INFO - 2021-06-02 10:06:13 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:13 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:13 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:13 --> URI Class Initialized
INFO - 2021-06-02 10:06:13 --> Router Class Initialized
INFO - 2021-06-02 10:06:13 --> Output Class Initialized
INFO - 2021-06-02 10:06:13 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:13 --> Input Class Initialized
INFO - 2021-06-02 10:06:13 --> Language Class Initialized
INFO - 2021-06-02 10:06:13 --> Language Class Initialized
INFO - 2021-06-02 10:06:13 --> Config Class Initialized
INFO - 2021-06-02 10:06:13 --> Loader Class Initialized
INFO - 2021-06-02 10:06:13 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:13 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:13 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:13 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:13 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:13 --> Controller Class Initialized
INFO - 2021-06-02 10:06:16 --> Config Class Initialized
INFO - 2021-06-02 10:06:16 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:16 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:16 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:16 --> URI Class Initialized
INFO - 2021-06-02 10:06:16 --> Router Class Initialized
INFO - 2021-06-02 10:06:16 --> Output Class Initialized
INFO - 2021-06-02 10:06:16 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:16 --> Input Class Initialized
INFO - 2021-06-02 10:06:16 --> Language Class Initialized
INFO - 2021-06-02 10:06:16 --> Language Class Initialized
INFO - 2021-06-02 10:06:16 --> Config Class Initialized
INFO - 2021-06-02 10:06:16 --> Loader Class Initialized
INFO - 2021-06-02 10:06:16 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:16 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:16 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:16 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:16 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:16 --> Controller Class Initialized
INFO - 2021-06-02 10:06:16 --> Helper loaded: cookie_helper
INFO - 2021-06-02 10:06:16 --> Config Class Initialized
INFO - 2021-06-02 10:06:16 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:16 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:16 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:16 --> URI Class Initialized
INFO - 2021-06-02 10:06:16 --> Router Class Initialized
INFO - 2021-06-02 10:06:16 --> Output Class Initialized
INFO - 2021-06-02 10:06:16 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:16 --> Input Class Initialized
INFO - 2021-06-02 10:06:16 --> Language Class Initialized
INFO - 2021-06-02 10:06:16 --> Language Class Initialized
INFO - 2021-06-02 10:06:16 --> Config Class Initialized
INFO - 2021-06-02 10:06:16 --> Loader Class Initialized
INFO - 2021-06-02 10:06:16 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:16 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:16 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:16 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:16 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:16 --> Controller Class Initialized
DEBUG - 2021-06-02 10:06:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-02 10:06:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:06:16 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:16 --> Total execution time: 0.0681
INFO - 2021-06-02 10:06:20 --> Config Class Initialized
INFO - 2021-06-02 10:06:20 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:20 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:20 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:20 --> URI Class Initialized
INFO - 2021-06-02 10:06:20 --> Router Class Initialized
INFO - 2021-06-02 10:06:20 --> Output Class Initialized
INFO - 2021-06-02 10:06:20 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:20 --> Input Class Initialized
INFO - 2021-06-02 10:06:20 --> Language Class Initialized
INFO - 2021-06-02 10:06:20 --> Language Class Initialized
INFO - 2021-06-02 10:06:20 --> Config Class Initialized
INFO - 2021-06-02 10:06:20 --> Loader Class Initialized
INFO - 2021-06-02 10:06:20 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:20 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:20 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:20 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:20 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:20 --> Controller Class Initialized
INFO - 2021-06-02 10:06:20 --> Helper loaded: cookie_helper
INFO - 2021-06-02 10:06:20 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:20 --> Total execution time: 0.0589
INFO - 2021-06-02 10:06:20 --> Config Class Initialized
INFO - 2021-06-02 10:06:20 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:20 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:20 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:20 --> URI Class Initialized
INFO - 2021-06-02 10:06:20 --> Router Class Initialized
INFO - 2021-06-02 10:06:20 --> Output Class Initialized
INFO - 2021-06-02 10:06:20 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:20 --> Input Class Initialized
INFO - 2021-06-02 10:06:20 --> Language Class Initialized
INFO - 2021-06-02 10:06:20 --> Language Class Initialized
INFO - 2021-06-02 10:06:20 --> Config Class Initialized
INFO - 2021-06-02 10:06:20 --> Loader Class Initialized
INFO - 2021-06-02 10:06:20 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:20 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:20 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:20 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:20 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:20 --> Controller Class Initialized
DEBUG - 2021-06-02 10:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-02 10:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:06:20 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:20 --> Total execution time: 0.0721
INFO - 2021-06-02 10:06:22 --> Config Class Initialized
INFO - 2021-06-02 10:06:22 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:22 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:22 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:22 --> URI Class Initialized
INFO - 2021-06-02 10:06:22 --> Router Class Initialized
INFO - 2021-06-02 10:06:22 --> Output Class Initialized
INFO - 2021-06-02 10:06:22 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:22 --> Input Class Initialized
INFO - 2021-06-02 10:06:22 --> Language Class Initialized
INFO - 2021-06-02 10:06:22 --> Language Class Initialized
INFO - 2021-06-02 10:06:22 --> Config Class Initialized
INFO - 2021-06-02 10:06:22 --> Loader Class Initialized
INFO - 2021-06-02 10:06:22 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:22 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:22 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:22 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:22 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:22 --> Controller Class Initialized
DEBUG - 2021-06-02 10:06:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-02 10:06:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:06:22 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:22 --> Total execution time: 0.1275
INFO - 2021-06-02 10:06:24 --> Config Class Initialized
INFO - 2021-06-02 10:06:24 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:24 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:24 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:24 --> URI Class Initialized
INFO - 2021-06-02 10:06:24 --> Router Class Initialized
INFO - 2021-06-02 10:06:24 --> Output Class Initialized
INFO - 2021-06-02 10:06:24 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:24 --> Input Class Initialized
INFO - 2021-06-02 10:06:24 --> Language Class Initialized
INFO - 2021-06-02 10:06:24 --> Language Class Initialized
INFO - 2021-06-02 10:06:24 --> Config Class Initialized
INFO - 2021-06-02 10:06:24 --> Loader Class Initialized
INFO - 2021-06-02 10:06:24 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:24 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:24 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:24 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:24 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:24 --> Controller Class Initialized
DEBUG - 2021-06-02 10:06:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-02 10:06:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:06:24 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:24 --> Total execution time: 0.1241
INFO - 2021-06-02 10:06:26 --> Config Class Initialized
INFO - 2021-06-02 10:06:26 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:26 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:26 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:26 --> URI Class Initialized
INFO - 2021-06-02 10:06:26 --> Router Class Initialized
INFO - 2021-06-02 10:06:26 --> Output Class Initialized
INFO - 2021-06-02 10:06:26 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:26 --> Input Class Initialized
INFO - 2021-06-02 10:06:26 --> Language Class Initialized
INFO - 2021-06-02 10:06:26 --> Language Class Initialized
INFO - 2021-06-02 10:06:26 --> Config Class Initialized
INFO - 2021-06-02 10:06:26 --> Loader Class Initialized
INFO - 2021-06-02 10:06:26 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:26 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:26 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:26 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:26 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:26 --> Controller Class Initialized
DEBUG - 2021-06-02 10:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-02 10:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:06:26 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:26 --> Total execution time: 0.1009
INFO - 2021-06-02 10:06:26 --> Config Class Initialized
INFO - 2021-06-02 10:06:26 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:26 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:26 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:26 --> URI Class Initialized
INFO - 2021-06-02 10:06:26 --> Router Class Initialized
INFO - 2021-06-02 10:06:26 --> Output Class Initialized
INFO - 2021-06-02 10:06:26 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:26 --> Input Class Initialized
INFO - 2021-06-02 10:06:26 --> Language Class Initialized
INFO - 2021-06-02 10:06:26 --> Language Class Initialized
INFO - 2021-06-02 10:06:26 --> Config Class Initialized
INFO - 2021-06-02 10:06:26 --> Loader Class Initialized
INFO - 2021-06-02 10:06:26 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:26 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:26 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:26 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:26 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:26 --> Controller Class Initialized
INFO - 2021-06-02 10:06:35 --> Config Class Initialized
INFO - 2021-06-02 10:06:35 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:35 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:35 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:35 --> URI Class Initialized
INFO - 2021-06-02 10:06:35 --> Router Class Initialized
INFO - 2021-06-02 10:06:35 --> Output Class Initialized
INFO - 2021-06-02 10:06:35 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:35 --> Input Class Initialized
INFO - 2021-06-02 10:06:35 --> Language Class Initialized
INFO - 2021-06-02 10:06:35 --> Language Class Initialized
INFO - 2021-06-02 10:06:35 --> Config Class Initialized
INFO - 2021-06-02 10:06:35 --> Loader Class Initialized
INFO - 2021-06-02 10:06:35 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:35 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:35 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:35 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:35 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:35 --> Controller Class Initialized
INFO - 2021-06-02 10:06:35 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:35 --> Total execution time: 0.1081
INFO - 2021-06-02 10:06:39 --> Config Class Initialized
INFO - 2021-06-02 10:06:39 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:39 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:39 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:39 --> URI Class Initialized
INFO - 2021-06-02 10:06:39 --> Router Class Initialized
INFO - 2021-06-02 10:06:39 --> Output Class Initialized
INFO - 2021-06-02 10:06:39 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:39 --> Input Class Initialized
INFO - 2021-06-02 10:06:39 --> Language Class Initialized
INFO - 2021-06-02 10:06:39 --> Language Class Initialized
INFO - 2021-06-02 10:06:39 --> Config Class Initialized
INFO - 2021-06-02 10:06:39 --> Loader Class Initialized
INFO - 2021-06-02 10:06:39 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:39 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:39 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:39 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:39 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:39 --> Controller Class Initialized
INFO - 2021-06-02 10:06:39 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:39 --> Total execution time: 0.0671
INFO - 2021-06-02 10:06:39 --> Config Class Initialized
INFO - 2021-06-02 10:06:39 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:39 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:39 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:39 --> URI Class Initialized
INFO - 2021-06-02 10:06:39 --> Router Class Initialized
INFO - 2021-06-02 10:06:39 --> Output Class Initialized
INFO - 2021-06-02 10:06:39 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:39 --> Input Class Initialized
INFO - 2021-06-02 10:06:39 --> Language Class Initialized
INFO - 2021-06-02 10:06:39 --> Language Class Initialized
INFO - 2021-06-02 10:06:39 --> Config Class Initialized
INFO - 2021-06-02 10:06:39 --> Loader Class Initialized
INFO - 2021-06-02 10:06:39 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:39 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:40 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:40 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:40 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:40 --> Controller Class Initialized
INFO - 2021-06-02 10:06:42 --> Config Class Initialized
INFO - 2021-06-02 10:06:42 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:42 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:42 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:42 --> URI Class Initialized
INFO - 2021-06-02 10:06:42 --> Router Class Initialized
INFO - 2021-06-02 10:06:42 --> Output Class Initialized
INFO - 2021-06-02 10:06:42 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:42 --> Input Class Initialized
INFO - 2021-06-02 10:06:42 --> Language Class Initialized
INFO - 2021-06-02 10:06:42 --> Language Class Initialized
INFO - 2021-06-02 10:06:42 --> Config Class Initialized
INFO - 2021-06-02 10:06:42 --> Loader Class Initialized
INFO - 2021-06-02 10:06:42 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:42 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:42 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:42 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:42 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:42 --> Controller Class Initialized
INFO - 2021-06-02 10:06:42 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:42 --> Total execution time: 0.0774
INFO - 2021-06-02 10:06:50 --> Config Class Initialized
INFO - 2021-06-02 10:06:50 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:50 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:50 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:50 --> URI Class Initialized
INFO - 2021-06-02 10:06:50 --> Router Class Initialized
INFO - 2021-06-02 10:06:50 --> Output Class Initialized
INFO - 2021-06-02 10:06:50 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:50 --> Input Class Initialized
INFO - 2021-06-02 10:06:50 --> Language Class Initialized
INFO - 2021-06-02 10:06:50 --> Language Class Initialized
INFO - 2021-06-02 10:06:50 --> Config Class Initialized
INFO - 2021-06-02 10:06:50 --> Loader Class Initialized
INFO - 2021-06-02 10:06:50 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:50 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:50 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:50 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:50 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:50 --> Controller Class Initialized
INFO - 2021-06-02 10:06:50 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:50 --> Total execution time: 0.1588
INFO - 2021-06-02 10:06:53 --> Config Class Initialized
INFO - 2021-06-02 10:06:53 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:53 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:53 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:53 --> URI Class Initialized
INFO - 2021-06-02 10:06:53 --> Router Class Initialized
INFO - 2021-06-02 10:06:53 --> Output Class Initialized
INFO - 2021-06-02 10:06:53 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:53 --> Input Class Initialized
INFO - 2021-06-02 10:06:53 --> Language Class Initialized
INFO - 2021-06-02 10:06:53 --> Language Class Initialized
INFO - 2021-06-02 10:06:53 --> Config Class Initialized
INFO - 2021-06-02 10:06:53 --> Loader Class Initialized
INFO - 2021-06-02 10:06:53 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:53 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:53 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:53 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:53 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:53 --> Controller Class Initialized
INFO - 2021-06-02 10:06:53 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:53 --> Total execution time: 0.0952
INFO - 2021-06-02 10:06:56 --> Config Class Initialized
INFO - 2021-06-02 10:06:56 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:56 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:56 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:56 --> URI Class Initialized
INFO - 2021-06-02 10:06:56 --> Router Class Initialized
INFO - 2021-06-02 10:06:56 --> Output Class Initialized
INFO - 2021-06-02 10:06:56 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:56 --> Input Class Initialized
INFO - 2021-06-02 10:06:56 --> Language Class Initialized
INFO - 2021-06-02 10:06:56 --> Language Class Initialized
INFO - 2021-06-02 10:06:56 --> Config Class Initialized
INFO - 2021-06-02 10:06:56 --> Loader Class Initialized
INFO - 2021-06-02 10:06:56 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:56 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:56 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:56 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:56 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:56 --> Controller Class Initialized
INFO - 2021-06-02 10:06:56 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:56 --> Total execution time: 0.1271
INFO - 2021-06-02 10:06:59 --> Config Class Initialized
INFO - 2021-06-02 10:06:59 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:06:59 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:06:59 --> Utf8 Class Initialized
INFO - 2021-06-02 10:06:59 --> URI Class Initialized
INFO - 2021-06-02 10:06:59 --> Router Class Initialized
INFO - 2021-06-02 10:06:59 --> Output Class Initialized
INFO - 2021-06-02 10:06:59 --> Security Class Initialized
DEBUG - 2021-06-02 10:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:06:59 --> Input Class Initialized
INFO - 2021-06-02 10:06:59 --> Language Class Initialized
INFO - 2021-06-02 10:06:59 --> Language Class Initialized
INFO - 2021-06-02 10:06:59 --> Config Class Initialized
INFO - 2021-06-02 10:06:59 --> Loader Class Initialized
INFO - 2021-06-02 10:06:59 --> Helper loaded: url_helper
INFO - 2021-06-02 10:06:59 --> Helper loaded: file_helper
INFO - 2021-06-02 10:06:59 --> Helper loaded: form_helper
INFO - 2021-06-02 10:06:59 --> Helper loaded: my_helper
INFO - 2021-06-02 10:06:59 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:06:59 --> Controller Class Initialized
INFO - 2021-06-02 10:06:59 --> Final output sent to browser
DEBUG - 2021-06-02 10:06:59 --> Total execution time: 0.0434
INFO - 2021-06-02 10:07:02 --> Config Class Initialized
INFO - 2021-06-02 10:07:02 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:02 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:02 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:02 --> URI Class Initialized
INFO - 2021-06-02 10:07:02 --> Router Class Initialized
INFO - 2021-06-02 10:07:02 --> Output Class Initialized
INFO - 2021-06-02 10:07:02 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:02 --> Input Class Initialized
INFO - 2021-06-02 10:07:02 --> Language Class Initialized
INFO - 2021-06-02 10:07:02 --> Language Class Initialized
INFO - 2021-06-02 10:07:02 --> Config Class Initialized
INFO - 2021-06-02 10:07:02 --> Loader Class Initialized
INFO - 2021-06-02 10:07:02 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:02 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:02 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:02 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:02 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:02 --> Controller Class Initialized
INFO - 2021-06-02 10:07:03 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:03 --> Total execution time: 0.1395
INFO - 2021-06-02 10:07:09 --> Config Class Initialized
INFO - 2021-06-02 10:07:09 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:09 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:09 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:09 --> URI Class Initialized
INFO - 2021-06-02 10:07:09 --> Router Class Initialized
INFO - 2021-06-02 10:07:09 --> Output Class Initialized
INFO - 2021-06-02 10:07:09 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:09 --> Input Class Initialized
INFO - 2021-06-02 10:07:09 --> Language Class Initialized
INFO - 2021-06-02 10:07:09 --> Language Class Initialized
INFO - 2021-06-02 10:07:09 --> Config Class Initialized
INFO - 2021-06-02 10:07:09 --> Loader Class Initialized
INFO - 2021-06-02 10:07:09 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:09 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:09 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:09 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:09 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:09 --> Controller Class Initialized
DEBUG - 2021-06-02 10:07:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-02 10:07:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:07:09 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:09 --> Total execution time: 0.0864
INFO - 2021-06-02 10:07:15 --> Config Class Initialized
INFO - 2021-06-02 10:07:15 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:15 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:15 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:15 --> URI Class Initialized
INFO - 2021-06-02 10:07:15 --> Router Class Initialized
INFO - 2021-06-02 10:07:15 --> Output Class Initialized
INFO - 2021-06-02 10:07:15 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:15 --> Input Class Initialized
INFO - 2021-06-02 10:07:15 --> Language Class Initialized
INFO - 2021-06-02 10:07:15 --> Language Class Initialized
INFO - 2021-06-02 10:07:15 --> Config Class Initialized
INFO - 2021-06-02 10:07:15 --> Loader Class Initialized
INFO - 2021-06-02 10:07:15 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:15 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:15 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:15 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:15 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:15 --> Controller Class Initialized
DEBUG - 2021-06-02 10:07:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-02 10:07:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:07:15 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:15 --> Total execution time: 0.1040
INFO - 2021-06-02 10:07:16 --> Config Class Initialized
INFO - 2021-06-02 10:07:16 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:16 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:16 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:16 --> URI Class Initialized
INFO - 2021-06-02 10:07:16 --> Router Class Initialized
INFO - 2021-06-02 10:07:16 --> Output Class Initialized
INFO - 2021-06-02 10:07:16 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:16 --> Input Class Initialized
INFO - 2021-06-02 10:07:16 --> Language Class Initialized
INFO - 2021-06-02 10:07:16 --> Language Class Initialized
INFO - 2021-06-02 10:07:16 --> Config Class Initialized
INFO - 2021-06-02 10:07:16 --> Loader Class Initialized
INFO - 2021-06-02 10:07:16 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:16 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:16 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:16 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:16 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:16 --> Controller Class Initialized
INFO - 2021-06-02 10:07:16 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:16 --> Total execution time: 0.0829
INFO - 2021-06-02 10:07:24 --> Config Class Initialized
INFO - 2021-06-02 10:07:24 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:24 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:24 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:24 --> URI Class Initialized
INFO - 2021-06-02 10:07:24 --> Router Class Initialized
INFO - 2021-06-02 10:07:24 --> Output Class Initialized
INFO - 2021-06-02 10:07:24 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:24 --> Input Class Initialized
INFO - 2021-06-02 10:07:24 --> Language Class Initialized
INFO - 2021-06-02 10:07:24 --> Language Class Initialized
INFO - 2021-06-02 10:07:24 --> Config Class Initialized
INFO - 2021-06-02 10:07:24 --> Loader Class Initialized
INFO - 2021-06-02 10:07:24 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:24 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:24 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:24 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:24 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:24 --> Controller Class Initialized
INFO - 2021-06-02 10:07:24 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:24 --> Total execution time: 0.0542
INFO - 2021-06-02 10:07:24 --> Config Class Initialized
INFO - 2021-06-02 10:07:24 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:24 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:24 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:24 --> URI Class Initialized
INFO - 2021-06-02 10:07:24 --> Router Class Initialized
INFO - 2021-06-02 10:07:24 --> Output Class Initialized
INFO - 2021-06-02 10:07:24 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:24 --> Input Class Initialized
INFO - 2021-06-02 10:07:24 --> Language Class Initialized
INFO - 2021-06-02 10:07:24 --> Language Class Initialized
INFO - 2021-06-02 10:07:24 --> Config Class Initialized
INFO - 2021-06-02 10:07:24 --> Loader Class Initialized
INFO - 2021-06-02 10:07:24 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:24 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:24 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:24 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:24 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:24 --> Controller Class Initialized
DEBUG - 2021-06-02 10:07:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-02 10:07:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:07:24 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:24 --> Total execution time: 0.0839
INFO - 2021-06-02 10:07:25 --> Config Class Initialized
INFO - 2021-06-02 10:07:25 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:25 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:25 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:25 --> URI Class Initialized
INFO - 2021-06-02 10:07:25 --> Router Class Initialized
INFO - 2021-06-02 10:07:25 --> Output Class Initialized
INFO - 2021-06-02 10:07:25 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:25 --> Input Class Initialized
INFO - 2021-06-02 10:07:25 --> Language Class Initialized
INFO - 2021-06-02 10:07:25 --> Language Class Initialized
INFO - 2021-06-02 10:07:25 --> Config Class Initialized
INFO - 2021-06-02 10:07:25 --> Loader Class Initialized
INFO - 2021-06-02 10:07:25 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:25 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:25 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:25 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:25 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:25 --> Controller Class Initialized
INFO - 2021-06-02 10:07:25 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:25 --> Total execution time: 0.0718
INFO - 2021-06-02 10:07:31 --> Config Class Initialized
INFO - 2021-06-02 10:07:31 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:31 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:31 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:31 --> URI Class Initialized
INFO - 2021-06-02 10:07:31 --> Router Class Initialized
INFO - 2021-06-02 10:07:31 --> Output Class Initialized
INFO - 2021-06-02 10:07:31 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:31 --> Input Class Initialized
INFO - 2021-06-02 10:07:31 --> Language Class Initialized
INFO - 2021-06-02 10:07:31 --> Language Class Initialized
INFO - 2021-06-02 10:07:31 --> Config Class Initialized
INFO - 2021-06-02 10:07:31 --> Loader Class Initialized
INFO - 2021-06-02 10:07:31 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:31 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:31 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:31 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:31 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:31 --> Controller Class Initialized
INFO - 2021-06-02 10:07:31 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:31 --> Total execution time: 0.1411
INFO - 2021-06-02 10:07:33 --> Config Class Initialized
INFO - 2021-06-02 10:07:33 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:33 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:33 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:33 --> URI Class Initialized
INFO - 2021-06-02 10:07:33 --> Router Class Initialized
INFO - 2021-06-02 10:07:33 --> Output Class Initialized
INFO - 2021-06-02 10:07:33 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:33 --> Input Class Initialized
INFO - 2021-06-02 10:07:33 --> Language Class Initialized
INFO - 2021-06-02 10:07:33 --> Language Class Initialized
INFO - 2021-06-02 10:07:33 --> Config Class Initialized
INFO - 2021-06-02 10:07:33 --> Loader Class Initialized
INFO - 2021-06-02 10:07:33 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:33 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:33 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:33 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:33 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:33 --> Controller Class Initialized
DEBUG - 2021-06-02 10:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-02 10:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:07:33 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:33 --> Total execution time: 0.0656
INFO - 2021-06-02 10:07:35 --> Config Class Initialized
INFO - 2021-06-02 10:07:35 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:35 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:35 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:35 --> URI Class Initialized
INFO - 2021-06-02 10:07:35 --> Router Class Initialized
INFO - 2021-06-02 10:07:35 --> Output Class Initialized
INFO - 2021-06-02 10:07:35 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:35 --> Input Class Initialized
INFO - 2021-06-02 10:07:35 --> Language Class Initialized
INFO - 2021-06-02 10:07:35 --> Language Class Initialized
INFO - 2021-06-02 10:07:35 --> Config Class Initialized
INFO - 2021-06-02 10:07:35 --> Loader Class Initialized
INFO - 2021-06-02 10:07:35 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:35 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:35 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:35 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:35 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:35 --> Controller Class Initialized
DEBUG - 2021-06-02 10:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-02 10:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-02 10:07:35 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:35 --> Total execution time: 0.0660
INFO - 2021-06-02 10:07:35 --> Config Class Initialized
INFO - 2021-06-02 10:07:35 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:35 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:35 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:35 --> URI Class Initialized
INFO - 2021-06-02 10:07:35 --> Router Class Initialized
INFO - 2021-06-02 10:07:35 --> Output Class Initialized
INFO - 2021-06-02 10:07:35 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:35 --> Input Class Initialized
INFO - 2021-06-02 10:07:35 --> Language Class Initialized
INFO - 2021-06-02 10:07:35 --> Language Class Initialized
INFO - 2021-06-02 10:07:35 --> Config Class Initialized
INFO - 2021-06-02 10:07:35 --> Loader Class Initialized
INFO - 2021-06-02 10:07:35 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:35 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:35 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:35 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:35 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:35 --> Controller Class Initialized
INFO - 2021-06-02 10:07:38 --> Config Class Initialized
INFO - 2021-06-02 10:07:38 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:38 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:38 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:38 --> URI Class Initialized
INFO - 2021-06-02 10:07:38 --> Router Class Initialized
INFO - 2021-06-02 10:07:38 --> Output Class Initialized
INFO - 2021-06-02 10:07:38 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:38 --> Input Class Initialized
INFO - 2021-06-02 10:07:38 --> Language Class Initialized
INFO - 2021-06-02 10:07:38 --> Language Class Initialized
INFO - 2021-06-02 10:07:38 --> Config Class Initialized
INFO - 2021-06-02 10:07:38 --> Loader Class Initialized
INFO - 2021-06-02 10:07:38 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:38 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:38 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:38 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:38 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:38 --> Controller Class Initialized
INFO - 2021-06-02 10:07:38 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:38 --> Total execution time: 0.0585
INFO - 2021-06-02 10:07:41 --> Config Class Initialized
INFO - 2021-06-02 10:07:41 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:41 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:41 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:41 --> URI Class Initialized
INFO - 2021-06-02 10:07:41 --> Router Class Initialized
INFO - 2021-06-02 10:07:41 --> Output Class Initialized
INFO - 2021-06-02 10:07:41 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:41 --> Input Class Initialized
INFO - 2021-06-02 10:07:41 --> Language Class Initialized
INFO - 2021-06-02 10:07:41 --> Language Class Initialized
INFO - 2021-06-02 10:07:41 --> Config Class Initialized
INFO - 2021-06-02 10:07:41 --> Loader Class Initialized
INFO - 2021-06-02 10:07:41 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:41 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:41 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:41 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:41 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:41 --> Controller Class Initialized
INFO - 2021-06-02 10:07:41 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:41 --> Total execution time: 0.1286
INFO - 2021-06-02 10:07:44 --> Config Class Initialized
INFO - 2021-06-02 10:07:44 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:44 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:44 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:44 --> URI Class Initialized
INFO - 2021-06-02 10:07:44 --> Router Class Initialized
INFO - 2021-06-02 10:07:44 --> Output Class Initialized
INFO - 2021-06-02 10:07:44 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:44 --> Input Class Initialized
INFO - 2021-06-02 10:07:44 --> Language Class Initialized
INFO - 2021-06-02 10:07:44 --> Language Class Initialized
INFO - 2021-06-02 10:07:44 --> Config Class Initialized
INFO - 2021-06-02 10:07:44 --> Loader Class Initialized
INFO - 2021-06-02 10:07:44 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:44 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:44 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:44 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:44 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:44 --> Controller Class Initialized
INFO - 2021-06-02 10:07:44 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:44 --> Total execution time: 0.0791
INFO - 2021-06-02 10:07:48 --> Config Class Initialized
INFO - 2021-06-02 10:07:48 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:48 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:48 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:48 --> URI Class Initialized
INFO - 2021-06-02 10:07:48 --> Router Class Initialized
INFO - 2021-06-02 10:07:48 --> Output Class Initialized
INFO - 2021-06-02 10:07:48 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:48 --> Input Class Initialized
INFO - 2021-06-02 10:07:48 --> Language Class Initialized
INFO - 2021-06-02 10:07:48 --> Language Class Initialized
INFO - 2021-06-02 10:07:48 --> Config Class Initialized
INFO - 2021-06-02 10:07:48 --> Loader Class Initialized
INFO - 2021-06-02 10:07:48 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:48 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:48 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:48 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:48 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:48 --> Controller Class Initialized
INFO - 2021-06-02 10:07:48 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:48 --> Total execution time: 0.1126
INFO - 2021-06-02 10:07:51 --> Config Class Initialized
INFO - 2021-06-02 10:07:51 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:51 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:51 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:51 --> URI Class Initialized
INFO - 2021-06-02 10:07:51 --> Router Class Initialized
INFO - 2021-06-02 10:07:51 --> Output Class Initialized
INFO - 2021-06-02 10:07:51 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:51 --> Input Class Initialized
INFO - 2021-06-02 10:07:51 --> Language Class Initialized
INFO - 2021-06-02 10:07:51 --> Language Class Initialized
INFO - 2021-06-02 10:07:51 --> Config Class Initialized
INFO - 2021-06-02 10:07:51 --> Loader Class Initialized
INFO - 2021-06-02 10:07:51 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:51 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:51 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:51 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:51 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:51 --> Controller Class Initialized
INFO - 2021-06-02 10:07:51 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:51 --> Total execution time: 0.0675
INFO - 2021-06-02 10:07:55 --> Config Class Initialized
INFO - 2021-06-02 10:07:55 --> Hooks Class Initialized
DEBUG - 2021-06-02 10:07:55 --> UTF-8 Support Enabled
INFO - 2021-06-02 10:07:55 --> Utf8 Class Initialized
INFO - 2021-06-02 10:07:55 --> URI Class Initialized
INFO - 2021-06-02 10:07:55 --> Router Class Initialized
INFO - 2021-06-02 10:07:55 --> Output Class Initialized
INFO - 2021-06-02 10:07:55 --> Security Class Initialized
DEBUG - 2021-06-02 10:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-02 10:07:55 --> Input Class Initialized
INFO - 2021-06-02 10:07:55 --> Language Class Initialized
INFO - 2021-06-02 10:07:55 --> Language Class Initialized
INFO - 2021-06-02 10:07:55 --> Config Class Initialized
INFO - 2021-06-02 10:07:55 --> Loader Class Initialized
INFO - 2021-06-02 10:07:55 --> Helper loaded: url_helper
INFO - 2021-06-02 10:07:55 --> Helper loaded: file_helper
INFO - 2021-06-02 10:07:55 --> Helper loaded: form_helper
INFO - 2021-06-02 10:07:55 --> Helper loaded: my_helper
INFO - 2021-06-02 10:07:55 --> Database Driver Class Initialized
DEBUG - 2021-06-02 10:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-02 10:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-02 10:07:55 --> Controller Class Initialized
INFO - 2021-06-02 10:07:55 --> Final output sent to browser
DEBUG - 2021-06-02 10:07:55 --> Total execution time: 0.1298
