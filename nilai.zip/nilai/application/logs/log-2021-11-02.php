<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-11-02 07:48:49 --> Config Class Initialized
INFO - 2021-11-02 07:48:49 --> Hooks Class Initialized
DEBUG - 2021-11-02 07:48:49 --> UTF-8 Support Enabled
INFO - 2021-11-02 07:48:49 --> Utf8 Class Initialized
INFO - 2021-11-02 07:48:49 --> URI Class Initialized
INFO - 2021-11-02 07:48:49 --> Router Class Initialized
INFO - 2021-11-02 07:48:49 --> Output Class Initialized
INFO - 2021-11-02 07:48:49 --> Security Class Initialized
DEBUG - 2021-11-02 07:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-02 07:48:49 --> Input Class Initialized
INFO - 2021-11-02 07:48:49 --> Language Class Initialized
INFO - 2021-11-02 07:48:50 --> Language Class Initialized
INFO - 2021-11-02 07:48:50 --> Config Class Initialized
INFO - 2021-11-02 07:48:50 --> Loader Class Initialized
INFO - 2021-11-02 07:48:50 --> Helper loaded: url_helper
INFO - 2021-11-02 07:48:50 --> Helper loaded: file_helper
INFO - 2021-11-02 07:48:50 --> Helper loaded: form_helper
INFO - 2021-11-02 07:48:50 --> Helper loaded: my_helper
INFO - 2021-11-02 07:48:50 --> Database Driver Class Initialized
DEBUG - 2021-11-02 07:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-02 07:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-02 07:48:50 --> Controller Class Initialized
DEBUG - 2021-11-02 07:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-02 07:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-02 07:48:50 --> Final output sent to browser
DEBUG - 2021-11-02 07:48:50 --> Total execution time: 0.7093
INFO - 2021-11-02 07:54:15 --> Config Class Initialized
INFO - 2021-11-02 07:54:15 --> Hooks Class Initialized
DEBUG - 2021-11-02 07:54:15 --> UTF-8 Support Enabled
INFO - 2021-11-02 07:54:15 --> Utf8 Class Initialized
INFO - 2021-11-02 07:54:15 --> URI Class Initialized
INFO - 2021-11-02 07:54:15 --> Router Class Initialized
INFO - 2021-11-02 07:54:15 --> Output Class Initialized
INFO - 2021-11-02 07:54:15 --> Security Class Initialized
DEBUG - 2021-11-02 07:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-02 07:54:15 --> Input Class Initialized
INFO - 2021-11-02 07:54:15 --> Language Class Initialized
INFO - 2021-11-02 07:54:15 --> Language Class Initialized
INFO - 2021-11-02 07:54:15 --> Config Class Initialized
INFO - 2021-11-02 07:54:15 --> Loader Class Initialized
INFO - 2021-11-02 07:54:15 --> Helper loaded: url_helper
INFO - 2021-11-02 07:54:15 --> Helper loaded: file_helper
INFO - 2021-11-02 07:54:15 --> Helper loaded: form_helper
INFO - 2021-11-02 07:54:15 --> Helper loaded: my_helper
INFO - 2021-11-02 07:54:15 --> Database Driver Class Initialized
DEBUG - 2021-11-02 07:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-02 07:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-02 07:54:15 --> Controller Class Initialized
INFO - 2021-11-02 07:54:15 --> Helper loaded: cookie_helper
INFO - 2021-11-02 07:54:15 --> Final output sent to browser
DEBUG - 2021-11-02 07:54:15 --> Total execution time: 0.0721
INFO - 2021-11-02 07:54:16 --> Config Class Initialized
INFO - 2021-11-02 07:54:16 --> Hooks Class Initialized
DEBUG - 2021-11-02 07:54:16 --> UTF-8 Support Enabled
INFO - 2021-11-02 07:54:16 --> Utf8 Class Initialized
INFO - 2021-11-02 07:54:16 --> URI Class Initialized
INFO - 2021-11-02 07:54:16 --> Router Class Initialized
INFO - 2021-11-02 07:54:16 --> Output Class Initialized
INFO - 2021-11-02 07:54:16 --> Security Class Initialized
DEBUG - 2021-11-02 07:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-02 07:54:16 --> Input Class Initialized
INFO - 2021-11-02 07:54:16 --> Language Class Initialized
INFO - 2021-11-02 07:54:16 --> Language Class Initialized
INFO - 2021-11-02 07:54:16 --> Config Class Initialized
INFO - 2021-11-02 07:54:16 --> Loader Class Initialized
INFO - 2021-11-02 07:54:16 --> Helper loaded: url_helper
INFO - 2021-11-02 07:54:16 --> Helper loaded: file_helper
INFO - 2021-11-02 07:54:16 --> Helper loaded: form_helper
INFO - 2021-11-02 07:54:16 --> Helper loaded: my_helper
INFO - 2021-11-02 07:54:16 --> Database Driver Class Initialized
DEBUG - 2021-11-02 07:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-02 07:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-02 07:54:16 --> Controller Class Initialized
DEBUG - 2021-11-02 07:54:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-02 07:54:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-02 07:54:17 --> Final output sent to browser
DEBUG - 2021-11-02 07:54:17 --> Total execution time: 0.8446
INFO - 2021-11-02 07:54:54 --> Config Class Initialized
INFO - 2021-11-02 07:54:54 --> Hooks Class Initialized
DEBUG - 2021-11-02 07:54:54 --> UTF-8 Support Enabled
INFO - 2021-11-02 07:54:54 --> Utf8 Class Initialized
INFO - 2021-11-02 07:54:54 --> URI Class Initialized
INFO - 2021-11-02 07:54:54 --> Router Class Initialized
INFO - 2021-11-02 07:54:54 --> Output Class Initialized
INFO - 2021-11-02 07:54:54 --> Security Class Initialized
DEBUG - 2021-11-02 07:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-02 07:54:54 --> Input Class Initialized
INFO - 2021-11-02 07:54:54 --> Language Class Initialized
INFO - 2021-11-02 07:54:54 --> Language Class Initialized
INFO - 2021-11-02 07:54:54 --> Config Class Initialized
INFO - 2021-11-02 07:54:54 --> Loader Class Initialized
INFO - 2021-11-02 07:54:54 --> Helper loaded: url_helper
INFO - 2021-11-02 07:54:54 --> Helper loaded: file_helper
INFO - 2021-11-02 07:54:54 --> Helper loaded: form_helper
INFO - 2021-11-02 07:54:54 --> Helper loaded: my_helper
INFO - 2021-11-02 07:54:54 --> Database Driver Class Initialized
DEBUG - 2021-11-02 07:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-02 07:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-02 07:54:54 --> Controller Class Initialized
DEBUG - 2021-11-02 07:54:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-11-02 07:54:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-02 07:54:54 --> Final output sent to browser
DEBUG - 2021-11-02 07:54:54 --> Total execution time: 0.1089
INFO - 2021-11-02 07:54:56 --> Config Class Initialized
INFO - 2021-11-02 07:54:56 --> Hooks Class Initialized
DEBUG - 2021-11-02 07:54:56 --> UTF-8 Support Enabled
INFO - 2021-11-02 07:54:56 --> Utf8 Class Initialized
INFO - 2021-11-02 07:54:56 --> URI Class Initialized
INFO - 2021-11-02 07:54:56 --> Router Class Initialized
INFO - 2021-11-02 07:54:56 --> Output Class Initialized
INFO - 2021-11-02 07:54:56 --> Security Class Initialized
DEBUG - 2021-11-02 07:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-02 07:54:56 --> Input Class Initialized
INFO - 2021-11-02 07:54:56 --> Language Class Initialized
INFO - 2021-11-02 07:54:56 --> Language Class Initialized
INFO - 2021-11-02 07:54:56 --> Config Class Initialized
INFO - 2021-11-02 07:54:56 --> Loader Class Initialized
INFO - 2021-11-02 07:54:56 --> Helper loaded: url_helper
INFO - 2021-11-02 07:54:56 --> Helper loaded: file_helper
INFO - 2021-11-02 07:54:56 --> Helper loaded: form_helper
INFO - 2021-11-02 07:54:56 --> Helper loaded: my_helper
INFO - 2021-11-02 07:54:56 --> Database Driver Class Initialized
DEBUG - 2021-11-02 07:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-02 07:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-02 07:54:56 --> Controller Class Initialized
DEBUG - 2021-11-02 07:54:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-11-02 07:54:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-02 07:54:56 --> Final output sent to browser
DEBUG - 2021-11-02 07:54:56 --> Total execution time: 0.0818
INFO - 2021-11-02 07:54:56 --> Config Class Initialized
INFO - 2021-11-02 07:54:56 --> Hooks Class Initialized
DEBUG - 2021-11-02 07:54:56 --> UTF-8 Support Enabled
INFO - 2021-11-02 07:54:56 --> Utf8 Class Initialized
INFO - 2021-11-02 07:54:56 --> URI Class Initialized
INFO - 2021-11-02 07:54:56 --> Router Class Initialized
INFO - 2021-11-02 07:54:56 --> Output Class Initialized
INFO - 2021-11-02 07:54:56 --> Security Class Initialized
DEBUG - 2021-11-02 07:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-02 07:54:56 --> Input Class Initialized
INFO - 2021-11-02 07:54:56 --> Language Class Initialized
INFO - 2021-11-02 07:54:56 --> Language Class Initialized
INFO - 2021-11-02 07:54:56 --> Config Class Initialized
INFO - 2021-11-02 07:54:56 --> Loader Class Initialized
INFO - 2021-11-02 07:54:56 --> Helper loaded: url_helper
INFO - 2021-11-02 07:54:56 --> Helper loaded: file_helper
INFO - 2021-11-02 07:54:56 --> Helper loaded: form_helper
INFO - 2021-11-02 07:54:56 --> Helper loaded: my_helper
INFO - 2021-11-02 07:54:56 --> Database Driver Class Initialized
DEBUG - 2021-11-02 07:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-02 07:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-02 07:54:56 --> Controller Class Initialized
INFO - 2021-11-02 07:54:58 --> Config Class Initialized
INFO - 2021-11-02 07:54:58 --> Hooks Class Initialized
DEBUG - 2021-11-02 07:54:58 --> UTF-8 Support Enabled
INFO - 2021-11-02 07:54:58 --> Utf8 Class Initialized
INFO - 2021-11-02 07:54:58 --> URI Class Initialized
INFO - 2021-11-02 07:54:58 --> Router Class Initialized
INFO - 2021-11-02 07:54:58 --> Output Class Initialized
INFO - 2021-11-02 07:54:58 --> Security Class Initialized
DEBUG - 2021-11-02 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-02 07:54:58 --> Input Class Initialized
INFO - 2021-11-02 07:54:58 --> Language Class Initialized
INFO - 2021-11-02 07:54:58 --> Language Class Initialized
INFO - 2021-11-02 07:54:58 --> Config Class Initialized
INFO - 2021-11-02 07:54:58 --> Loader Class Initialized
INFO - 2021-11-02 07:54:58 --> Helper loaded: url_helper
INFO - 2021-11-02 07:54:58 --> Helper loaded: file_helper
INFO - 2021-11-02 07:54:58 --> Helper loaded: form_helper
INFO - 2021-11-02 07:54:58 --> Helper loaded: my_helper
INFO - 2021-11-02 07:54:58 --> Database Driver Class Initialized
DEBUG - 2021-11-02 07:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-02 07:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-02 07:54:58 --> Controller Class Initialized
INFO - 2021-11-02 07:54:58 --> Final output sent to browser
DEBUG - 2021-11-02 07:54:58 --> Total execution time: 0.0671
INFO - 2021-11-02 07:54:58 --> Config Class Initialized
INFO - 2021-11-02 07:54:58 --> Hooks Class Initialized
DEBUG - 2021-11-02 07:54:58 --> UTF-8 Support Enabled
INFO - 2021-11-02 07:54:58 --> Utf8 Class Initialized
INFO - 2021-11-02 07:54:58 --> URI Class Initialized
INFO - 2021-11-02 07:54:58 --> Router Class Initialized
INFO - 2021-11-02 07:54:58 --> Output Class Initialized
INFO - 2021-11-02 07:54:58 --> Security Class Initialized
DEBUG - 2021-11-02 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-02 07:54:58 --> Input Class Initialized
INFO - 2021-11-02 07:54:58 --> Language Class Initialized
INFO - 2021-11-02 07:54:58 --> Language Class Initialized
INFO - 2021-11-02 07:54:58 --> Config Class Initialized
INFO - 2021-11-02 07:54:58 --> Loader Class Initialized
INFO - 2021-11-02 07:54:58 --> Helper loaded: url_helper
INFO - 2021-11-02 07:54:58 --> Helper loaded: file_helper
INFO - 2021-11-02 07:54:58 --> Helper loaded: form_helper
INFO - 2021-11-02 07:54:58 --> Helper loaded: my_helper
INFO - 2021-11-02 07:54:58 --> Database Driver Class Initialized
DEBUG - 2021-11-02 07:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-02 07:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-02 07:54:58 --> Controller Class Initialized
INFO - 2021-11-02 07:54:59 --> Config Class Initialized
INFO - 2021-11-02 07:54:59 --> Hooks Class Initialized
DEBUG - 2021-11-02 07:54:59 --> UTF-8 Support Enabled
INFO - 2021-11-02 07:54:59 --> Utf8 Class Initialized
INFO - 2021-11-02 07:54:59 --> URI Class Initialized
INFO - 2021-11-02 07:54:59 --> Router Class Initialized
INFO - 2021-11-02 07:54:59 --> Output Class Initialized
INFO - 2021-11-02 07:54:59 --> Security Class Initialized
DEBUG - 2021-11-02 07:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-02 07:54:59 --> Input Class Initialized
INFO - 2021-11-02 07:54:59 --> Language Class Initialized
INFO - 2021-11-02 07:54:59 --> Language Class Initialized
INFO - 2021-11-02 07:54:59 --> Config Class Initialized
INFO - 2021-11-02 07:54:59 --> Loader Class Initialized
INFO - 2021-11-02 07:54:59 --> Helper loaded: url_helper
INFO - 2021-11-02 07:54:59 --> Helper loaded: file_helper
INFO - 2021-11-02 07:54:59 --> Helper loaded: form_helper
INFO - 2021-11-02 07:54:59 --> Helper loaded: my_helper
INFO - 2021-11-02 07:54:59 --> Database Driver Class Initialized
DEBUG - 2021-11-02 07:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-02 07:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-02 07:54:59 --> Controller Class Initialized
DEBUG - 2021-11-02 07:54:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-11-02 07:54:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-02 07:54:59 --> Final output sent to browser
DEBUG - 2021-11-02 07:54:59 --> Total execution time: 0.0684
