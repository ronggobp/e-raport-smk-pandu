<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-23 04:08:16 --> Config Class Initialized
INFO - 2021-08-23 04:08:16 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:16 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:16 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:16 --> URI Class Initialized
INFO - 2021-08-23 04:08:16 --> Router Class Initialized
INFO - 2021-08-23 04:08:16 --> Output Class Initialized
INFO - 2021-08-23 04:08:16 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:16 --> Input Class Initialized
INFO - 2021-08-23 04:08:16 --> Language Class Initialized
INFO - 2021-08-23 04:08:16 --> Language Class Initialized
INFO - 2021-08-23 04:08:16 --> Config Class Initialized
INFO - 2021-08-23 04:08:16 --> Loader Class Initialized
INFO - 2021-08-23 04:08:16 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:16 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:16 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:16 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:16 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:16 --> Controller Class Initialized
DEBUG - 2021-08-23 04:08:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-23 04:08:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:08:16 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:16 --> Total execution time: 0.5859
INFO - 2021-08-23 04:08:25 --> Config Class Initialized
INFO - 2021-08-23 04:08:25 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:25 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:25 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:25 --> URI Class Initialized
INFO - 2021-08-23 04:08:25 --> Router Class Initialized
INFO - 2021-08-23 04:08:25 --> Output Class Initialized
INFO - 2021-08-23 04:08:25 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:25 --> Input Class Initialized
INFO - 2021-08-23 04:08:25 --> Language Class Initialized
INFO - 2021-08-23 04:08:25 --> Language Class Initialized
INFO - 2021-08-23 04:08:25 --> Config Class Initialized
INFO - 2021-08-23 04:08:25 --> Loader Class Initialized
INFO - 2021-08-23 04:08:25 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:25 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:25 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:25 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:25 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:25 --> Controller Class Initialized
INFO - 2021-08-23 04:08:25 --> Helper loaded: cookie_helper
INFO - 2021-08-23 04:08:25 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:25 --> Total execution time: 0.0829
INFO - 2021-08-23 04:08:25 --> Config Class Initialized
INFO - 2021-08-23 04:08:25 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:25 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:25 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:25 --> URI Class Initialized
INFO - 2021-08-23 04:08:25 --> Router Class Initialized
INFO - 2021-08-23 04:08:25 --> Output Class Initialized
INFO - 2021-08-23 04:08:25 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:25 --> Input Class Initialized
INFO - 2021-08-23 04:08:25 --> Language Class Initialized
INFO - 2021-08-23 04:08:25 --> Language Class Initialized
INFO - 2021-08-23 04:08:25 --> Config Class Initialized
INFO - 2021-08-23 04:08:25 --> Loader Class Initialized
INFO - 2021-08-23 04:08:25 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:25 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:25 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:25 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:25 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:25 --> Controller Class Initialized
DEBUG - 2021-08-23 04:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-23 04:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:08:26 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:26 --> Total execution time: 0.8208
INFO - 2021-08-23 04:08:29 --> Config Class Initialized
INFO - 2021-08-23 04:08:29 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:29 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:29 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:29 --> URI Class Initialized
INFO - 2021-08-23 04:08:29 --> Router Class Initialized
INFO - 2021-08-23 04:08:29 --> Output Class Initialized
INFO - 2021-08-23 04:08:29 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:29 --> Input Class Initialized
INFO - 2021-08-23 04:08:29 --> Language Class Initialized
INFO - 2021-08-23 04:08:29 --> Language Class Initialized
INFO - 2021-08-23 04:08:29 --> Config Class Initialized
INFO - 2021-08-23 04:08:29 --> Loader Class Initialized
INFO - 2021-08-23 04:08:29 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:29 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:29 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:29 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:29 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:29 --> Controller Class Initialized
DEBUG - 2021-08-23 04:08:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-23 04:08:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:08:29 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:29 --> Total execution time: 0.0823
INFO - 2021-08-23 04:08:31 --> Config Class Initialized
INFO - 2021-08-23 04:08:31 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:31 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:31 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:31 --> URI Class Initialized
INFO - 2021-08-23 04:08:31 --> Router Class Initialized
INFO - 2021-08-23 04:08:31 --> Output Class Initialized
INFO - 2021-08-23 04:08:31 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:31 --> Input Class Initialized
INFO - 2021-08-23 04:08:31 --> Language Class Initialized
INFO - 2021-08-23 04:08:31 --> Language Class Initialized
INFO - 2021-08-23 04:08:31 --> Config Class Initialized
INFO - 2021-08-23 04:08:31 --> Loader Class Initialized
INFO - 2021-08-23 04:08:31 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:31 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:31 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:31 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:31 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:31 --> Controller Class Initialized
DEBUG - 2021-08-23 04:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-08-23 04:08:31 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:31 --> Total execution time: 0.2777
INFO - 2021-08-23 04:08:37 --> Config Class Initialized
INFO - 2021-08-23 04:08:37 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:37 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:37 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:37 --> URI Class Initialized
INFO - 2021-08-23 04:08:37 --> Router Class Initialized
INFO - 2021-08-23 04:08:37 --> Output Class Initialized
INFO - 2021-08-23 04:08:37 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:37 --> Input Class Initialized
INFO - 2021-08-23 04:08:37 --> Language Class Initialized
INFO - 2021-08-23 04:08:37 --> Language Class Initialized
INFO - 2021-08-23 04:08:37 --> Config Class Initialized
INFO - 2021-08-23 04:08:37 --> Loader Class Initialized
INFO - 2021-08-23 04:08:37 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:37 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:37 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:37 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:37 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:37 --> Controller Class Initialized
DEBUG - 2021-08-23 04:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-23 04:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:08:37 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:37 --> Total execution time: 0.1241
INFO - 2021-08-23 04:08:42 --> Config Class Initialized
INFO - 2021-08-23 04:08:42 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:42 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:42 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:42 --> URI Class Initialized
INFO - 2021-08-23 04:08:42 --> Router Class Initialized
INFO - 2021-08-23 04:08:42 --> Output Class Initialized
INFO - 2021-08-23 04:08:42 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:42 --> Input Class Initialized
INFO - 2021-08-23 04:08:42 --> Language Class Initialized
INFO - 2021-08-23 04:08:42 --> Language Class Initialized
INFO - 2021-08-23 04:08:42 --> Config Class Initialized
INFO - 2021-08-23 04:08:42 --> Loader Class Initialized
INFO - 2021-08-23 04:08:42 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:42 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:42 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:42 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:42 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:42 --> Controller Class Initialized
DEBUG - 2021-08-23 04:08:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:08:43 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:43 --> Total execution time: 0.2293
INFO - 2021-08-23 04:08:50 --> Config Class Initialized
INFO - 2021-08-23 04:08:50 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:50 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:50 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:50 --> URI Class Initialized
INFO - 2021-08-23 04:08:50 --> Router Class Initialized
INFO - 2021-08-23 04:08:50 --> Output Class Initialized
INFO - 2021-08-23 04:08:50 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:50 --> Input Class Initialized
INFO - 2021-08-23 04:08:50 --> Language Class Initialized
INFO - 2021-08-23 04:08:50 --> Language Class Initialized
INFO - 2021-08-23 04:08:50 --> Config Class Initialized
INFO - 2021-08-23 04:08:50 --> Loader Class Initialized
INFO - 2021-08-23 04:08:50 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:50 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:50 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:50 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:50 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:50 --> Controller Class Initialized
DEBUG - 2021-08-23 04:08:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:08:50 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:50 --> Total execution time: 0.1488
INFO - 2021-08-23 04:08:53 --> Config Class Initialized
INFO - 2021-08-23 04:08:53 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:53 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:53 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:53 --> URI Class Initialized
INFO - 2021-08-23 04:08:53 --> Router Class Initialized
INFO - 2021-08-23 04:08:53 --> Output Class Initialized
INFO - 2021-08-23 04:08:53 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:53 --> Input Class Initialized
INFO - 2021-08-23 04:08:53 --> Language Class Initialized
INFO - 2021-08-23 04:08:53 --> Language Class Initialized
INFO - 2021-08-23 04:08:53 --> Config Class Initialized
INFO - 2021-08-23 04:08:53 --> Loader Class Initialized
INFO - 2021-08-23 04:08:53 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:53 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:53 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:53 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:53 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:53 --> Controller Class Initialized
DEBUG - 2021-08-23 04:08:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:08:53 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:53 --> Total execution time: 0.1495
INFO - 2021-08-23 04:08:59 --> Config Class Initialized
INFO - 2021-08-23 04:08:59 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:08:59 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:08:59 --> Utf8 Class Initialized
INFO - 2021-08-23 04:08:59 --> URI Class Initialized
INFO - 2021-08-23 04:08:59 --> Router Class Initialized
INFO - 2021-08-23 04:08:59 --> Output Class Initialized
INFO - 2021-08-23 04:08:59 --> Security Class Initialized
DEBUG - 2021-08-23 04:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:08:59 --> Input Class Initialized
INFO - 2021-08-23 04:08:59 --> Language Class Initialized
INFO - 2021-08-23 04:08:59 --> Language Class Initialized
INFO - 2021-08-23 04:08:59 --> Config Class Initialized
INFO - 2021-08-23 04:08:59 --> Loader Class Initialized
INFO - 2021-08-23 04:08:59 --> Helper loaded: url_helper
INFO - 2021-08-23 04:08:59 --> Helper loaded: file_helper
INFO - 2021-08-23 04:08:59 --> Helper loaded: form_helper
INFO - 2021-08-23 04:08:59 --> Helper loaded: my_helper
INFO - 2021-08-23 04:08:59 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:08:59 --> Controller Class Initialized
DEBUG - 2021-08-23 04:08:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:08:59 --> Final output sent to browser
DEBUG - 2021-08-23 04:08:59 --> Total execution time: 0.1403
INFO - 2021-08-23 04:09:03 --> Config Class Initialized
INFO - 2021-08-23 04:09:03 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:09:03 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:09:03 --> Utf8 Class Initialized
INFO - 2021-08-23 04:09:03 --> URI Class Initialized
INFO - 2021-08-23 04:09:03 --> Router Class Initialized
INFO - 2021-08-23 04:09:03 --> Output Class Initialized
INFO - 2021-08-23 04:09:03 --> Security Class Initialized
DEBUG - 2021-08-23 04:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:09:03 --> Input Class Initialized
INFO - 2021-08-23 04:09:03 --> Language Class Initialized
INFO - 2021-08-23 04:09:03 --> Language Class Initialized
INFO - 2021-08-23 04:09:03 --> Config Class Initialized
INFO - 2021-08-23 04:09:03 --> Loader Class Initialized
INFO - 2021-08-23 04:09:03 --> Helper loaded: url_helper
INFO - 2021-08-23 04:09:03 --> Helper loaded: file_helper
INFO - 2021-08-23 04:09:03 --> Helper loaded: form_helper
INFO - 2021-08-23 04:09:03 --> Helper loaded: my_helper
INFO - 2021-08-23 04:09:03 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:09:03 --> Controller Class Initialized
DEBUG - 2021-08-23 04:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:09:03 --> Final output sent to browser
DEBUG - 2021-08-23 04:09:03 --> Total execution time: 0.1296
INFO - 2021-08-23 04:10:07 --> Config Class Initialized
INFO - 2021-08-23 04:10:07 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:07 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:07 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:07 --> URI Class Initialized
INFO - 2021-08-23 04:10:07 --> Router Class Initialized
INFO - 2021-08-23 04:10:07 --> Output Class Initialized
INFO - 2021-08-23 04:10:07 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:07 --> Input Class Initialized
INFO - 2021-08-23 04:10:07 --> Language Class Initialized
INFO - 2021-08-23 04:10:07 --> Language Class Initialized
INFO - 2021-08-23 04:10:07 --> Config Class Initialized
INFO - 2021-08-23 04:10:07 --> Loader Class Initialized
INFO - 2021-08-23 04:10:07 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:07 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:07 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:07 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:07 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:07 --> Controller Class Initialized
INFO - 2021-08-23 04:10:07 --> Helper loaded: cookie_helper
INFO - 2021-08-23 04:10:07 --> Config Class Initialized
INFO - 2021-08-23 04:10:07 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:07 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:07 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:07 --> URI Class Initialized
INFO - 2021-08-23 04:10:07 --> Router Class Initialized
INFO - 2021-08-23 04:10:07 --> Output Class Initialized
INFO - 2021-08-23 04:10:07 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:07 --> Input Class Initialized
INFO - 2021-08-23 04:10:07 --> Language Class Initialized
INFO - 2021-08-23 04:10:07 --> Language Class Initialized
INFO - 2021-08-23 04:10:07 --> Config Class Initialized
INFO - 2021-08-23 04:10:07 --> Loader Class Initialized
INFO - 2021-08-23 04:10:07 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:07 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:07 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:07 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:07 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:07 --> Controller Class Initialized
DEBUG - 2021-08-23 04:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-23 04:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:10:07 --> Final output sent to browser
DEBUG - 2021-08-23 04:10:07 --> Total execution time: 0.0538
INFO - 2021-08-23 04:10:13 --> Config Class Initialized
INFO - 2021-08-23 04:10:13 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:13 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:13 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:13 --> URI Class Initialized
INFO - 2021-08-23 04:10:13 --> Router Class Initialized
INFO - 2021-08-23 04:10:13 --> Output Class Initialized
INFO - 2021-08-23 04:10:13 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:13 --> Input Class Initialized
INFO - 2021-08-23 04:10:13 --> Language Class Initialized
INFO - 2021-08-23 04:10:13 --> Language Class Initialized
INFO - 2021-08-23 04:10:13 --> Config Class Initialized
INFO - 2021-08-23 04:10:13 --> Loader Class Initialized
INFO - 2021-08-23 04:10:13 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:13 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:13 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:13 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:13 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:13 --> Controller Class Initialized
INFO - 2021-08-23 04:10:13 --> Final output sent to browser
DEBUG - 2021-08-23 04:10:13 --> Total execution time: 0.0560
INFO - 2021-08-23 04:10:20 --> Config Class Initialized
INFO - 2021-08-23 04:10:20 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:20 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:20 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:20 --> URI Class Initialized
INFO - 2021-08-23 04:10:20 --> Router Class Initialized
INFO - 2021-08-23 04:10:20 --> Output Class Initialized
INFO - 2021-08-23 04:10:20 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:20 --> Input Class Initialized
INFO - 2021-08-23 04:10:20 --> Language Class Initialized
INFO - 2021-08-23 04:10:20 --> Language Class Initialized
INFO - 2021-08-23 04:10:20 --> Config Class Initialized
INFO - 2021-08-23 04:10:20 --> Loader Class Initialized
INFO - 2021-08-23 04:10:20 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:20 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:20 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:20 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:20 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:20 --> Controller Class Initialized
INFO - 2021-08-23 04:10:20 --> Helper loaded: cookie_helper
INFO - 2021-08-23 04:10:20 --> Final output sent to browser
DEBUG - 2021-08-23 04:10:20 --> Total execution time: 0.0622
INFO - 2021-08-23 04:10:20 --> Config Class Initialized
INFO - 2021-08-23 04:10:20 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:20 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:20 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:20 --> URI Class Initialized
INFO - 2021-08-23 04:10:20 --> Router Class Initialized
INFO - 2021-08-23 04:10:20 --> Output Class Initialized
INFO - 2021-08-23 04:10:20 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:20 --> Input Class Initialized
INFO - 2021-08-23 04:10:20 --> Language Class Initialized
INFO - 2021-08-23 04:10:20 --> Language Class Initialized
INFO - 2021-08-23 04:10:20 --> Config Class Initialized
INFO - 2021-08-23 04:10:20 --> Loader Class Initialized
INFO - 2021-08-23 04:10:20 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:20 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:20 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:20 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:20 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:20 --> Controller Class Initialized
DEBUG - 2021-08-23 04:10:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-23 04:10:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:10:21 --> Final output sent to browser
DEBUG - 2021-08-23 04:10:21 --> Total execution time: 0.7616
INFO - 2021-08-23 04:10:22 --> Config Class Initialized
INFO - 2021-08-23 04:10:22 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:22 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:22 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:22 --> URI Class Initialized
INFO - 2021-08-23 04:10:22 --> Router Class Initialized
INFO - 2021-08-23 04:10:22 --> Output Class Initialized
INFO - 2021-08-23 04:10:22 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:22 --> Input Class Initialized
INFO - 2021-08-23 04:10:22 --> Language Class Initialized
INFO - 2021-08-23 04:10:22 --> Language Class Initialized
INFO - 2021-08-23 04:10:22 --> Config Class Initialized
INFO - 2021-08-23 04:10:22 --> Loader Class Initialized
INFO - 2021-08-23 04:10:22 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:22 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:22 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:22 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:22 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:22 --> Controller Class Initialized
DEBUG - 2021-08-23 04:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-08-23 04:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:10:22 --> Final output sent to browser
DEBUG - 2021-08-23 04:10:22 --> Total execution time: 0.0808
INFO - 2021-08-23 04:10:22 --> Config Class Initialized
INFO - 2021-08-23 04:10:22 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:22 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:22 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:22 --> URI Class Initialized
INFO - 2021-08-23 04:10:22 --> Router Class Initialized
INFO - 2021-08-23 04:10:22 --> Output Class Initialized
INFO - 2021-08-23 04:10:22 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:22 --> Input Class Initialized
INFO - 2021-08-23 04:10:22 --> Language Class Initialized
INFO - 2021-08-23 04:10:22 --> Language Class Initialized
INFO - 2021-08-23 04:10:22 --> Config Class Initialized
INFO - 2021-08-23 04:10:22 --> Loader Class Initialized
INFO - 2021-08-23 04:10:22 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:22 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:22 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:22 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:22 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:22 --> Controller Class Initialized
INFO - 2021-08-23 04:10:24 --> Config Class Initialized
INFO - 2021-08-23 04:10:24 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:24 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:24 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:24 --> URI Class Initialized
INFO - 2021-08-23 04:10:24 --> Router Class Initialized
INFO - 2021-08-23 04:10:24 --> Output Class Initialized
INFO - 2021-08-23 04:10:24 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:24 --> Input Class Initialized
INFO - 2021-08-23 04:10:24 --> Language Class Initialized
INFO - 2021-08-23 04:10:24 --> Language Class Initialized
INFO - 2021-08-23 04:10:24 --> Config Class Initialized
INFO - 2021-08-23 04:10:24 --> Loader Class Initialized
INFO - 2021-08-23 04:10:24 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:24 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:24 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:24 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:24 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:24 --> Controller Class Initialized
INFO - 2021-08-23 04:10:24 --> Final output sent to browser
DEBUG - 2021-08-23 04:10:24 --> Total execution time: 0.0540
INFO - 2021-08-23 04:10:28 --> Config Class Initialized
INFO - 2021-08-23 04:10:28 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:28 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:28 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:28 --> URI Class Initialized
INFO - 2021-08-23 04:10:28 --> Router Class Initialized
INFO - 2021-08-23 04:10:28 --> Output Class Initialized
INFO - 2021-08-23 04:10:28 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:28 --> Input Class Initialized
INFO - 2021-08-23 04:10:28 --> Language Class Initialized
INFO - 2021-08-23 04:10:28 --> Language Class Initialized
INFO - 2021-08-23 04:10:28 --> Config Class Initialized
INFO - 2021-08-23 04:10:28 --> Loader Class Initialized
INFO - 2021-08-23 04:10:28 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:28 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:28 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:28 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:28 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:28 --> Controller Class Initialized
INFO - 2021-08-23 04:10:52 --> Config Class Initialized
INFO - 2021-08-23 04:10:52 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:10:52 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:10:52 --> Utf8 Class Initialized
INFO - 2021-08-23 04:10:52 --> URI Class Initialized
INFO - 2021-08-23 04:10:52 --> Router Class Initialized
INFO - 2021-08-23 04:10:52 --> Output Class Initialized
INFO - 2021-08-23 04:10:52 --> Security Class Initialized
DEBUG - 2021-08-23 04:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:10:52 --> Input Class Initialized
INFO - 2021-08-23 04:10:52 --> Language Class Initialized
INFO - 2021-08-23 04:10:52 --> Language Class Initialized
INFO - 2021-08-23 04:10:52 --> Config Class Initialized
INFO - 2021-08-23 04:10:52 --> Loader Class Initialized
INFO - 2021-08-23 04:10:52 --> Helper loaded: url_helper
INFO - 2021-08-23 04:10:52 --> Helper loaded: file_helper
INFO - 2021-08-23 04:10:52 --> Helper loaded: form_helper
INFO - 2021-08-23 04:10:52 --> Helper loaded: my_helper
INFO - 2021-08-23 04:10:52 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:10:52 --> Controller Class Initialized
INFO - 2021-08-23 04:10:52 --> Final output sent to browser
DEBUG - 2021-08-23 04:10:52 --> Total execution time: 0.0455
INFO - 2021-08-23 04:11:29 --> Config Class Initialized
INFO - 2021-08-23 04:11:29 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:29 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:29 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:29 --> URI Class Initialized
INFO - 2021-08-23 04:11:29 --> Router Class Initialized
INFO - 2021-08-23 04:11:29 --> Output Class Initialized
INFO - 2021-08-23 04:11:29 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:29 --> Input Class Initialized
INFO - 2021-08-23 04:11:29 --> Language Class Initialized
INFO - 2021-08-23 04:11:29 --> Language Class Initialized
INFO - 2021-08-23 04:11:29 --> Config Class Initialized
INFO - 2021-08-23 04:11:29 --> Loader Class Initialized
INFO - 2021-08-23 04:11:29 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:29 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:29 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:29 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:29 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:29 --> Controller Class Initialized
INFO - 2021-08-23 04:11:29 --> Final output sent to browser
DEBUG - 2021-08-23 04:11:29 --> Total execution time: 0.0634
INFO - 2021-08-23 04:11:29 --> Config Class Initialized
INFO - 2021-08-23 04:11:29 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:29 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:29 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:29 --> URI Class Initialized
INFO - 2021-08-23 04:11:29 --> Router Class Initialized
INFO - 2021-08-23 04:11:29 --> Output Class Initialized
INFO - 2021-08-23 04:11:29 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:29 --> Input Class Initialized
INFO - 2021-08-23 04:11:29 --> Language Class Initialized
INFO - 2021-08-23 04:11:29 --> Language Class Initialized
INFO - 2021-08-23 04:11:29 --> Config Class Initialized
INFO - 2021-08-23 04:11:29 --> Loader Class Initialized
INFO - 2021-08-23 04:11:29 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:29 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:29 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:29 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:29 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:29 --> Controller Class Initialized
INFO - 2021-08-23 04:11:32 --> Config Class Initialized
INFO - 2021-08-23 04:11:32 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:32 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:32 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:32 --> URI Class Initialized
INFO - 2021-08-23 04:11:32 --> Router Class Initialized
INFO - 2021-08-23 04:11:32 --> Output Class Initialized
INFO - 2021-08-23 04:11:32 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:32 --> Input Class Initialized
INFO - 2021-08-23 04:11:32 --> Language Class Initialized
INFO - 2021-08-23 04:11:32 --> Language Class Initialized
INFO - 2021-08-23 04:11:32 --> Config Class Initialized
INFO - 2021-08-23 04:11:32 --> Loader Class Initialized
INFO - 2021-08-23 04:11:32 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:32 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:32 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:32 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:32 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:32 --> Controller Class Initialized
DEBUG - 2021-08-23 04:11:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-08-23 04:11:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:11:32 --> Final output sent to browser
DEBUG - 2021-08-23 04:11:32 --> Total execution time: 0.0854
INFO - 2021-08-23 04:11:32 --> Config Class Initialized
INFO - 2021-08-23 04:11:32 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:32 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:32 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:32 --> URI Class Initialized
INFO - 2021-08-23 04:11:32 --> Router Class Initialized
INFO - 2021-08-23 04:11:32 --> Output Class Initialized
INFO - 2021-08-23 04:11:32 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:32 --> Input Class Initialized
INFO - 2021-08-23 04:11:32 --> Language Class Initialized
INFO - 2021-08-23 04:11:32 --> Language Class Initialized
INFO - 2021-08-23 04:11:32 --> Config Class Initialized
INFO - 2021-08-23 04:11:32 --> Loader Class Initialized
INFO - 2021-08-23 04:11:32 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:32 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:32 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:32 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:32 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:32 --> Controller Class Initialized
INFO - 2021-08-23 04:11:38 --> Config Class Initialized
INFO - 2021-08-23 04:11:38 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:38 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:38 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:38 --> URI Class Initialized
INFO - 2021-08-23 04:11:38 --> Router Class Initialized
INFO - 2021-08-23 04:11:38 --> Output Class Initialized
INFO - 2021-08-23 04:11:38 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:38 --> Input Class Initialized
INFO - 2021-08-23 04:11:38 --> Language Class Initialized
INFO - 2021-08-23 04:11:38 --> Language Class Initialized
INFO - 2021-08-23 04:11:38 --> Config Class Initialized
INFO - 2021-08-23 04:11:38 --> Loader Class Initialized
INFO - 2021-08-23 04:11:38 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:38 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:38 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:38 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:38 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:38 --> Controller Class Initialized
INFO - 2021-08-23 04:11:38 --> Config Class Initialized
INFO - 2021-08-23 04:11:38 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:38 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:38 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:38 --> URI Class Initialized
INFO - 2021-08-23 04:11:38 --> Router Class Initialized
INFO - 2021-08-23 04:11:38 --> Output Class Initialized
INFO - 2021-08-23 04:11:38 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:38 --> Input Class Initialized
INFO - 2021-08-23 04:11:38 --> Language Class Initialized
INFO - 2021-08-23 04:11:38 --> Language Class Initialized
INFO - 2021-08-23 04:11:38 --> Config Class Initialized
INFO - 2021-08-23 04:11:38 --> Loader Class Initialized
INFO - 2021-08-23 04:11:38 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:38 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:38 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:38 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:38 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:38 --> Controller Class Initialized
INFO - 2021-08-23 04:11:39 --> Config Class Initialized
INFO - 2021-08-23 04:11:39 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:39 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:39 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:39 --> URI Class Initialized
INFO - 2021-08-23 04:11:39 --> Router Class Initialized
INFO - 2021-08-23 04:11:39 --> Output Class Initialized
INFO - 2021-08-23 04:11:39 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:39 --> Input Class Initialized
INFO - 2021-08-23 04:11:39 --> Language Class Initialized
INFO - 2021-08-23 04:11:39 --> Language Class Initialized
INFO - 2021-08-23 04:11:39 --> Config Class Initialized
INFO - 2021-08-23 04:11:39 --> Loader Class Initialized
INFO - 2021-08-23 04:11:39 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:39 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:39 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:39 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:39 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:39 --> Controller Class Initialized
INFO - 2021-08-23 04:11:39 --> Config Class Initialized
INFO - 2021-08-23 04:11:39 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:39 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:39 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:39 --> URI Class Initialized
INFO - 2021-08-23 04:11:39 --> Router Class Initialized
INFO - 2021-08-23 04:11:39 --> Output Class Initialized
INFO - 2021-08-23 04:11:39 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:39 --> Input Class Initialized
INFO - 2021-08-23 04:11:39 --> Language Class Initialized
INFO - 2021-08-23 04:11:39 --> Language Class Initialized
INFO - 2021-08-23 04:11:39 --> Config Class Initialized
INFO - 2021-08-23 04:11:39 --> Loader Class Initialized
INFO - 2021-08-23 04:11:39 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:39 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:39 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:39 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:39 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:39 --> Controller Class Initialized
INFO - 2021-08-23 04:11:40 --> Config Class Initialized
INFO - 2021-08-23 04:11:40 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:40 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:40 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:40 --> URI Class Initialized
INFO - 2021-08-23 04:11:40 --> Router Class Initialized
INFO - 2021-08-23 04:11:40 --> Output Class Initialized
INFO - 2021-08-23 04:11:40 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:40 --> Input Class Initialized
INFO - 2021-08-23 04:11:40 --> Language Class Initialized
INFO - 2021-08-23 04:11:40 --> Language Class Initialized
INFO - 2021-08-23 04:11:40 --> Config Class Initialized
INFO - 2021-08-23 04:11:40 --> Loader Class Initialized
INFO - 2021-08-23 04:11:40 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:40 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:40 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:40 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:40 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:40 --> Controller Class Initialized
INFO - 2021-08-23 04:11:46 --> Config Class Initialized
INFO - 2021-08-23 04:11:46 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:46 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:46 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:46 --> URI Class Initialized
INFO - 2021-08-23 04:11:46 --> Router Class Initialized
INFO - 2021-08-23 04:11:46 --> Output Class Initialized
INFO - 2021-08-23 04:11:46 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:46 --> Input Class Initialized
INFO - 2021-08-23 04:11:46 --> Language Class Initialized
INFO - 2021-08-23 04:11:46 --> Language Class Initialized
INFO - 2021-08-23 04:11:46 --> Config Class Initialized
INFO - 2021-08-23 04:11:46 --> Loader Class Initialized
INFO - 2021-08-23 04:11:46 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:46 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:46 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:46 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:46 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:46 --> Controller Class Initialized
INFO - 2021-08-23 04:11:46 --> Final output sent to browser
DEBUG - 2021-08-23 04:11:46 --> Total execution time: 0.0558
INFO - 2021-08-23 04:11:46 --> Config Class Initialized
INFO - 2021-08-23 04:11:46 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:46 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:46 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:46 --> URI Class Initialized
INFO - 2021-08-23 04:11:46 --> Router Class Initialized
INFO - 2021-08-23 04:11:46 --> Output Class Initialized
INFO - 2021-08-23 04:11:46 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:46 --> Input Class Initialized
INFO - 2021-08-23 04:11:46 --> Language Class Initialized
INFO - 2021-08-23 04:11:46 --> Language Class Initialized
INFO - 2021-08-23 04:11:46 --> Config Class Initialized
INFO - 2021-08-23 04:11:46 --> Loader Class Initialized
INFO - 2021-08-23 04:11:46 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:46 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:46 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:46 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:46 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:46 --> Controller Class Initialized
INFO - 2021-08-23 04:11:48 --> Config Class Initialized
INFO - 2021-08-23 04:11:48 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:48 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:48 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:48 --> URI Class Initialized
INFO - 2021-08-23 04:11:48 --> Router Class Initialized
INFO - 2021-08-23 04:11:48 --> Output Class Initialized
INFO - 2021-08-23 04:11:48 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:48 --> Input Class Initialized
INFO - 2021-08-23 04:11:48 --> Language Class Initialized
INFO - 2021-08-23 04:11:48 --> Language Class Initialized
INFO - 2021-08-23 04:11:48 --> Config Class Initialized
INFO - 2021-08-23 04:11:48 --> Loader Class Initialized
INFO - 2021-08-23 04:11:48 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:48 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:48 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:48 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:48 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:48 --> Controller Class Initialized
INFO - 2021-08-23 04:11:48 --> Final output sent to browser
DEBUG - 2021-08-23 04:11:48 --> Total execution time: 0.0641
INFO - 2021-08-23 04:11:55 --> Config Class Initialized
INFO - 2021-08-23 04:11:55 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:55 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:55 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:55 --> URI Class Initialized
INFO - 2021-08-23 04:11:55 --> Router Class Initialized
INFO - 2021-08-23 04:11:55 --> Output Class Initialized
INFO - 2021-08-23 04:11:55 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:55 --> Input Class Initialized
INFO - 2021-08-23 04:11:55 --> Language Class Initialized
INFO - 2021-08-23 04:11:55 --> Language Class Initialized
INFO - 2021-08-23 04:11:55 --> Config Class Initialized
INFO - 2021-08-23 04:11:55 --> Loader Class Initialized
INFO - 2021-08-23 04:11:55 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:55 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:55 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:55 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:55 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:55 --> Controller Class Initialized
INFO - 2021-08-23 04:11:55 --> Final output sent to browser
DEBUG - 2021-08-23 04:11:55 --> Total execution time: 0.0650
INFO - 2021-08-23 04:11:55 --> Config Class Initialized
INFO - 2021-08-23 04:11:55 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:55 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:55 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:55 --> URI Class Initialized
INFO - 2021-08-23 04:11:55 --> Router Class Initialized
INFO - 2021-08-23 04:11:55 --> Output Class Initialized
INFO - 2021-08-23 04:11:55 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:55 --> Input Class Initialized
INFO - 2021-08-23 04:11:55 --> Language Class Initialized
INFO - 2021-08-23 04:11:55 --> Language Class Initialized
INFO - 2021-08-23 04:11:55 --> Config Class Initialized
INFO - 2021-08-23 04:11:55 --> Loader Class Initialized
INFO - 2021-08-23 04:11:55 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:55 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:55 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:55 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:55 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:55 --> Controller Class Initialized
INFO - 2021-08-23 04:11:57 --> Config Class Initialized
INFO - 2021-08-23 04:11:57 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:57 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:57 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:57 --> URI Class Initialized
INFO - 2021-08-23 04:11:57 --> Router Class Initialized
INFO - 2021-08-23 04:11:57 --> Output Class Initialized
INFO - 2021-08-23 04:11:57 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:57 --> Input Class Initialized
INFO - 2021-08-23 04:11:57 --> Language Class Initialized
INFO - 2021-08-23 04:11:57 --> Language Class Initialized
INFO - 2021-08-23 04:11:57 --> Config Class Initialized
INFO - 2021-08-23 04:11:57 --> Loader Class Initialized
INFO - 2021-08-23 04:11:57 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:57 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:57 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:57 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:57 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:58 --> Controller Class Initialized
INFO - 2021-08-23 04:11:58 --> Helper loaded: cookie_helper
INFO - 2021-08-23 04:11:58 --> Config Class Initialized
INFO - 2021-08-23 04:11:58 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:11:58 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:11:58 --> Utf8 Class Initialized
INFO - 2021-08-23 04:11:58 --> URI Class Initialized
INFO - 2021-08-23 04:11:58 --> Router Class Initialized
INFO - 2021-08-23 04:11:58 --> Output Class Initialized
INFO - 2021-08-23 04:11:58 --> Security Class Initialized
DEBUG - 2021-08-23 04:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:11:58 --> Input Class Initialized
INFO - 2021-08-23 04:11:58 --> Language Class Initialized
INFO - 2021-08-23 04:11:58 --> Language Class Initialized
INFO - 2021-08-23 04:11:58 --> Config Class Initialized
INFO - 2021-08-23 04:11:58 --> Loader Class Initialized
INFO - 2021-08-23 04:11:58 --> Helper loaded: url_helper
INFO - 2021-08-23 04:11:58 --> Helper loaded: file_helper
INFO - 2021-08-23 04:11:58 --> Helper loaded: form_helper
INFO - 2021-08-23 04:11:58 --> Helper loaded: my_helper
INFO - 2021-08-23 04:11:58 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:11:58 --> Controller Class Initialized
DEBUG - 2021-08-23 04:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-23 04:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:11:58 --> Final output sent to browser
DEBUG - 2021-08-23 04:11:58 --> Total execution time: 0.0560
INFO - 2021-08-23 04:12:04 --> Config Class Initialized
INFO - 2021-08-23 04:12:04 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:04 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:04 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:04 --> URI Class Initialized
INFO - 2021-08-23 04:12:04 --> Router Class Initialized
INFO - 2021-08-23 04:12:04 --> Output Class Initialized
INFO - 2021-08-23 04:12:04 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:04 --> Input Class Initialized
INFO - 2021-08-23 04:12:04 --> Language Class Initialized
INFO - 2021-08-23 04:12:04 --> Language Class Initialized
INFO - 2021-08-23 04:12:04 --> Config Class Initialized
INFO - 2021-08-23 04:12:04 --> Loader Class Initialized
INFO - 2021-08-23 04:12:04 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:04 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:04 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:04 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:04 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:04 --> Controller Class Initialized
INFO - 2021-08-23 04:12:04 --> Final output sent to browser
DEBUG - 2021-08-23 04:12:04 --> Total execution time: 0.0591
INFO - 2021-08-23 04:12:10 --> Config Class Initialized
INFO - 2021-08-23 04:12:10 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:10 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:10 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:10 --> URI Class Initialized
INFO - 2021-08-23 04:12:10 --> Router Class Initialized
INFO - 2021-08-23 04:12:10 --> Output Class Initialized
INFO - 2021-08-23 04:12:10 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:10 --> Input Class Initialized
INFO - 2021-08-23 04:12:10 --> Language Class Initialized
INFO - 2021-08-23 04:12:10 --> Language Class Initialized
INFO - 2021-08-23 04:12:10 --> Config Class Initialized
INFO - 2021-08-23 04:12:10 --> Loader Class Initialized
INFO - 2021-08-23 04:12:10 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:10 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:10 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:10 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:10 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:10 --> Controller Class Initialized
INFO - 2021-08-23 04:12:10 --> Helper loaded: cookie_helper
INFO - 2021-08-23 04:12:10 --> Final output sent to browser
DEBUG - 2021-08-23 04:12:10 --> Total execution time: 0.0643
INFO - 2021-08-23 04:12:10 --> Config Class Initialized
INFO - 2021-08-23 04:12:10 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:10 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:10 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:10 --> URI Class Initialized
INFO - 2021-08-23 04:12:10 --> Router Class Initialized
INFO - 2021-08-23 04:12:10 --> Output Class Initialized
INFO - 2021-08-23 04:12:10 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:10 --> Input Class Initialized
INFO - 2021-08-23 04:12:10 --> Language Class Initialized
INFO - 2021-08-23 04:12:10 --> Language Class Initialized
INFO - 2021-08-23 04:12:10 --> Config Class Initialized
INFO - 2021-08-23 04:12:10 --> Loader Class Initialized
INFO - 2021-08-23 04:12:10 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:10 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:10 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:10 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:10 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:10 --> Controller Class Initialized
DEBUG - 2021-08-23 04:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-23 04:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:12:11 --> Final output sent to browser
DEBUG - 2021-08-23 04:12:11 --> Total execution time: 0.6804
INFO - 2021-08-23 04:12:11 --> Config Class Initialized
INFO - 2021-08-23 04:12:11 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:11 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:11 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:11 --> URI Class Initialized
INFO - 2021-08-23 04:12:11 --> Router Class Initialized
INFO - 2021-08-23 04:12:11 --> Output Class Initialized
INFO - 2021-08-23 04:12:11 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:11 --> Input Class Initialized
INFO - 2021-08-23 04:12:11 --> Language Class Initialized
INFO - 2021-08-23 04:12:11 --> Language Class Initialized
INFO - 2021-08-23 04:12:11 --> Config Class Initialized
INFO - 2021-08-23 04:12:11 --> Loader Class Initialized
INFO - 2021-08-23 04:12:11 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:11 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:11 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:11 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:11 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:12 --> Controller Class Initialized
DEBUG - 2021-08-23 04:12:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-08-23 04:12:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:12:12 --> Final output sent to browser
DEBUG - 2021-08-23 04:12:12 --> Total execution time: 0.0655
INFO - 2021-08-23 04:12:12 --> Config Class Initialized
INFO - 2021-08-23 04:12:12 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:12 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:12 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:12 --> URI Class Initialized
INFO - 2021-08-23 04:12:12 --> Router Class Initialized
INFO - 2021-08-23 04:12:12 --> Output Class Initialized
INFO - 2021-08-23 04:12:12 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:12 --> Input Class Initialized
INFO - 2021-08-23 04:12:12 --> Language Class Initialized
INFO - 2021-08-23 04:12:12 --> Language Class Initialized
INFO - 2021-08-23 04:12:12 --> Config Class Initialized
INFO - 2021-08-23 04:12:12 --> Loader Class Initialized
INFO - 2021-08-23 04:12:12 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:12 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:12 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:12 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:12 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:12 --> Controller Class Initialized
INFO - 2021-08-23 04:12:13 --> Config Class Initialized
INFO - 2021-08-23 04:12:13 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:13 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:13 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:13 --> URI Class Initialized
INFO - 2021-08-23 04:12:13 --> Router Class Initialized
INFO - 2021-08-23 04:12:13 --> Output Class Initialized
INFO - 2021-08-23 04:12:13 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:13 --> Input Class Initialized
INFO - 2021-08-23 04:12:13 --> Language Class Initialized
INFO - 2021-08-23 04:12:13 --> Language Class Initialized
INFO - 2021-08-23 04:12:13 --> Config Class Initialized
INFO - 2021-08-23 04:12:13 --> Loader Class Initialized
INFO - 2021-08-23 04:12:13 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:13 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:13 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:13 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:13 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:13 --> Controller Class Initialized
INFO - 2021-08-23 04:12:16 --> Config Class Initialized
INFO - 2021-08-23 04:12:16 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:16 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:16 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:16 --> URI Class Initialized
INFO - 2021-08-23 04:12:16 --> Router Class Initialized
INFO - 2021-08-23 04:12:16 --> Output Class Initialized
INFO - 2021-08-23 04:12:16 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:16 --> Input Class Initialized
INFO - 2021-08-23 04:12:16 --> Language Class Initialized
INFO - 2021-08-23 04:12:16 --> Language Class Initialized
INFO - 2021-08-23 04:12:16 --> Config Class Initialized
INFO - 2021-08-23 04:12:16 --> Loader Class Initialized
INFO - 2021-08-23 04:12:16 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:16 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:16 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:16 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:16 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:16 --> Controller Class Initialized
INFO - 2021-08-23 04:12:16 --> Final output sent to browser
DEBUG - 2021-08-23 04:12:16 --> Total execution time: 0.0639
INFO - 2021-08-23 04:12:16 --> Config Class Initialized
INFO - 2021-08-23 04:12:16 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:16 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:16 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:16 --> URI Class Initialized
INFO - 2021-08-23 04:12:16 --> Router Class Initialized
INFO - 2021-08-23 04:12:16 --> Output Class Initialized
INFO - 2021-08-23 04:12:16 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:16 --> Input Class Initialized
INFO - 2021-08-23 04:12:16 --> Language Class Initialized
INFO - 2021-08-23 04:12:16 --> Language Class Initialized
INFO - 2021-08-23 04:12:16 --> Config Class Initialized
INFO - 2021-08-23 04:12:16 --> Loader Class Initialized
INFO - 2021-08-23 04:12:16 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:16 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:16 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:16 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:16 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:16 --> Controller Class Initialized
INFO - 2021-08-23 04:12:17 --> Config Class Initialized
INFO - 2021-08-23 04:12:17 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:17 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:17 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:18 --> URI Class Initialized
INFO - 2021-08-23 04:12:18 --> Router Class Initialized
INFO - 2021-08-23 04:12:18 --> Output Class Initialized
INFO - 2021-08-23 04:12:18 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:18 --> Input Class Initialized
INFO - 2021-08-23 04:12:18 --> Language Class Initialized
INFO - 2021-08-23 04:12:18 --> Language Class Initialized
INFO - 2021-08-23 04:12:18 --> Config Class Initialized
INFO - 2021-08-23 04:12:18 --> Loader Class Initialized
INFO - 2021-08-23 04:12:18 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:18 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:18 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:18 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:18 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:18 --> Controller Class Initialized
INFO - 2021-08-23 04:12:27 --> Config Class Initialized
INFO - 2021-08-23 04:12:27 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:12:27 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:12:27 --> Utf8 Class Initialized
INFO - 2021-08-23 04:12:27 --> URI Class Initialized
INFO - 2021-08-23 04:12:27 --> Router Class Initialized
INFO - 2021-08-23 04:12:27 --> Output Class Initialized
INFO - 2021-08-23 04:12:27 --> Security Class Initialized
DEBUG - 2021-08-23 04:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:12:27 --> Input Class Initialized
INFO - 2021-08-23 04:12:27 --> Language Class Initialized
INFO - 2021-08-23 04:12:27 --> Language Class Initialized
INFO - 2021-08-23 04:12:27 --> Config Class Initialized
INFO - 2021-08-23 04:12:27 --> Loader Class Initialized
INFO - 2021-08-23 04:12:27 --> Helper loaded: url_helper
INFO - 2021-08-23 04:12:27 --> Helper loaded: file_helper
INFO - 2021-08-23 04:12:27 --> Helper loaded: form_helper
INFO - 2021-08-23 04:12:27 --> Helper loaded: my_helper
INFO - 2021-08-23 04:12:27 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:12:27 --> Controller Class Initialized
DEBUG - 2021-08-23 04:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-23 04:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:12:27 --> Final output sent to browser
DEBUG - 2021-08-23 04:12:27 --> Total execution time: 0.0459
INFO - 2021-08-23 04:13:26 --> Config Class Initialized
INFO - 2021-08-23 04:13:26 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:26 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:26 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:26 --> URI Class Initialized
INFO - 2021-08-23 04:13:26 --> Router Class Initialized
INFO - 2021-08-23 04:13:26 --> Output Class Initialized
INFO - 2021-08-23 04:13:26 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:26 --> Input Class Initialized
INFO - 2021-08-23 04:13:26 --> Language Class Initialized
INFO - 2021-08-23 04:13:26 --> Language Class Initialized
INFO - 2021-08-23 04:13:26 --> Config Class Initialized
INFO - 2021-08-23 04:13:26 --> Loader Class Initialized
INFO - 2021-08-23 04:13:26 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:26 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:26 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:26 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:26 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:26 --> Controller Class Initialized
INFO - 2021-08-23 04:13:26 --> Helper loaded: cookie_helper
INFO - 2021-08-23 04:13:26 --> Config Class Initialized
INFO - 2021-08-23 04:13:26 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:26 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:26 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:26 --> URI Class Initialized
INFO - 2021-08-23 04:13:26 --> Router Class Initialized
INFO - 2021-08-23 04:13:26 --> Output Class Initialized
INFO - 2021-08-23 04:13:26 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:26 --> Input Class Initialized
INFO - 2021-08-23 04:13:26 --> Language Class Initialized
INFO - 2021-08-23 04:13:26 --> Language Class Initialized
INFO - 2021-08-23 04:13:26 --> Config Class Initialized
INFO - 2021-08-23 04:13:26 --> Loader Class Initialized
INFO - 2021-08-23 04:13:26 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:26 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:26 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:26 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:26 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:26 --> Controller Class Initialized
DEBUG - 2021-08-23 04:13:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-23 04:13:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:13:26 --> Final output sent to browser
DEBUG - 2021-08-23 04:13:26 --> Total execution time: 0.0434
INFO - 2021-08-23 04:13:31 --> Config Class Initialized
INFO - 2021-08-23 04:13:31 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:31 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:31 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:31 --> URI Class Initialized
INFO - 2021-08-23 04:13:31 --> Router Class Initialized
INFO - 2021-08-23 04:13:31 --> Output Class Initialized
INFO - 2021-08-23 04:13:31 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:31 --> Input Class Initialized
INFO - 2021-08-23 04:13:31 --> Language Class Initialized
INFO - 2021-08-23 04:13:31 --> Language Class Initialized
INFO - 2021-08-23 04:13:31 --> Config Class Initialized
INFO - 2021-08-23 04:13:31 --> Loader Class Initialized
INFO - 2021-08-23 04:13:31 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:31 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:31 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:31 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:31 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:31 --> Controller Class Initialized
INFO - 2021-08-23 04:13:31 --> Helper loaded: cookie_helper
INFO - 2021-08-23 04:13:31 --> Final output sent to browser
DEBUG - 2021-08-23 04:13:31 --> Total execution time: 0.0685
INFO - 2021-08-23 04:13:31 --> Config Class Initialized
INFO - 2021-08-23 04:13:31 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:31 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:31 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:31 --> URI Class Initialized
INFO - 2021-08-23 04:13:31 --> Router Class Initialized
INFO - 2021-08-23 04:13:31 --> Output Class Initialized
INFO - 2021-08-23 04:13:31 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:31 --> Input Class Initialized
INFO - 2021-08-23 04:13:31 --> Language Class Initialized
INFO - 2021-08-23 04:13:31 --> Language Class Initialized
INFO - 2021-08-23 04:13:31 --> Config Class Initialized
INFO - 2021-08-23 04:13:31 --> Loader Class Initialized
INFO - 2021-08-23 04:13:31 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:31 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:31 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:31 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:31 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:31 --> Controller Class Initialized
DEBUG - 2021-08-23 04:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-23 04:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:13:32 --> Final output sent to browser
DEBUG - 2021-08-23 04:13:32 --> Total execution time: 0.6899
INFO - 2021-08-23 04:13:36 --> Config Class Initialized
INFO - 2021-08-23 04:13:36 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:36 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:36 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:36 --> URI Class Initialized
INFO - 2021-08-23 04:13:36 --> Router Class Initialized
INFO - 2021-08-23 04:13:36 --> Output Class Initialized
INFO - 2021-08-23 04:13:36 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:36 --> Input Class Initialized
INFO - 2021-08-23 04:13:36 --> Language Class Initialized
INFO - 2021-08-23 04:13:36 --> Language Class Initialized
INFO - 2021-08-23 04:13:36 --> Config Class Initialized
INFO - 2021-08-23 04:13:36 --> Loader Class Initialized
INFO - 2021-08-23 04:13:36 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:36 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:36 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:36 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:36 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:36 --> Controller Class Initialized
DEBUG - 2021-08-23 04:13:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-08-23 04:13:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-23 04:13:36 --> Final output sent to browser
DEBUG - 2021-08-23 04:13:36 --> Total execution time: 0.0790
INFO - 2021-08-23 04:13:41 --> Config Class Initialized
INFO - 2021-08-23 04:13:41 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:41 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:41 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:41 --> URI Class Initialized
INFO - 2021-08-23 04:13:41 --> Router Class Initialized
INFO - 2021-08-23 04:13:41 --> Output Class Initialized
INFO - 2021-08-23 04:13:41 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:41 --> Input Class Initialized
INFO - 2021-08-23 04:13:41 --> Language Class Initialized
INFO - 2021-08-23 04:13:41 --> Language Class Initialized
INFO - 2021-08-23 04:13:41 --> Config Class Initialized
INFO - 2021-08-23 04:13:41 --> Loader Class Initialized
INFO - 2021-08-23 04:13:41 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:41 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:41 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:41 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:41 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:41 --> Controller Class Initialized
DEBUG - 2021-08-23 04:13:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:13:41 --> Final output sent to browser
DEBUG - 2021-08-23 04:13:41 --> Total execution time: 0.2070
INFO - 2021-08-23 04:13:42 --> Config Class Initialized
INFO - 2021-08-23 04:13:42 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:42 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:42 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:42 --> URI Class Initialized
INFO - 2021-08-23 04:13:42 --> Router Class Initialized
INFO - 2021-08-23 04:13:42 --> Output Class Initialized
INFO - 2021-08-23 04:13:42 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:42 --> Input Class Initialized
INFO - 2021-08-23 04:13:42 --> Language Class Initialized
INFO - 2021-08-23 04:13:42 --> Language Class Initialized
INFO - 2021-08-23 04:13:42 --> Config Class Initialized
INFO - 2021-08-23 04:13:42 --> Loader Class Initialized
INFO - 2021-08-23 04:13:42 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:42 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:42 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:42 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:42 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:42 --> Controller Class Initialized
DEBUG - 2021-08-23 04:13:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:13:42 --> Final output sent to browser
DEBUG - 2021-08-23 04:13:42 --> Total execution time: 0.1504
INFO - 2021-08-23 04:13:45 --> Config Class Initialized
INFO - 2021-08-23 04:13:45 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:45 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:45 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:45 --> URI Class Initialized
INFO - 2021-08-23 04:13:45 --> Router Class Initialized
INFO - 2021-08-23 04:13:45 --> Output Class Initialized
INFO - 2021-08-23 04:13:45 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:45 --> Input Class Initialized
INFO - 2021-08-23 04:13:45 --> Language Class Initialized
INFO - 2021-08-23 04:13:45 --> Language Class Initialized
INFO - 2021-08-23 04:13:45 --> Config Class Initialized
INFO - 2021-08-23 04:13:45 --> Loader Class Initialized
INFO - 2021-08-23 04:13:45 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:45 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:45 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:45 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:45 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:45 --> Controller Class Initialized
DEBUG - 2021-08-23 04:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:13:45 --> Final output sent to browser
DEBUG - 2021-08-23 04:13:45 --> Total execution time: 0.1516
INFO - 2021-08-23 04:13:49 --> Config Class Initialized
INFO - 2021-08-23 04:13:49 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:49 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:49 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:49 --> URI Class Initialized
INFO - 2021-08-23 04:13:49 --> Router Class Initialized
INFO - 2021-08-23 04:13:49 --> Output Class Initialized
INFO - 2021-08-23 04:13:49 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:49 --> Input Class Initialized
INFO - 2021-08-23 04:13:49 --> Language Class Initialized
INFO - 2021-08-23 04:13:49 --> Language Class Initialized
INFO - 2021-08-23 04:13:49 --> Config Class Initialized
INFO - 2021-08-23 04:13:49 --> Loader Class Initialized
INFO - 2021-08-23 04:13:49 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:49 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:49 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:49 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:49 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:49 --> Controller Class Initialized
DEBUG - 2021-08-23 04:13:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:13:49 --> Final output sent to browser
DEBUG - 2021-08-23 04:13:49 --> Total execution time: 0.1398
INFO - 2021-08-23 04:13:59 --> Config Class Initialized
INFO - 2021-08-23 04:13:59 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:13:59 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:13:59 --> Utf8 Class Initialized
INFO - 2021-08-23 04:13:59 --> URI Class Initialized
INFO - 2021-08-23 04:13:59 --> Router Class Initialized
INFO - 2021-08-23 04:13:59 --> Output Class Initialized
INFO - 2021-08-23 04:13:59 --> Security Class Initialized
DEBUG - 2021-08-23 04:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:13:59 --> Input Class Initialized
INFO - 2021-08-23 04:13:59 --> Language Class Initialized
INFO - 2021-08-23 04:13:59 --> Language Class Initialized
INFO - 2021-08-23 04:13:59 --> Config Class Initialized
INFO - 2021-08-23 04:13:59 --> Loader Class Initialized
INFO - 2021-08-23 04:13:59 --> Helper loaded: url_helper
INFO - 2021-08-23 04:13:59 --> Helper loaded: file_helper
INFO - 2021-08-23 04:13:59 --> Helper loaded: form_helper
INFO - 2021-08-23 04:13:59 --> Helper loaded: my_helper
INFO - 2021-08-23 04:13:59 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:13:59 --> Controller Class Initialized
DEBUG - 2021-08-23 04:13:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:13:59 --> Final output sent to browser
DEBUG - 2021-08-23 04:13:59 --> Total execution time: 0.1463
INFO - 2021-08-23 04:14:01 --> Config Class Initialized
INFO - 2021-08-23 04:14:01 --> Hooks Class Initialized
DEBUG - 2021-08-23 04:14:01 --> UTF-8 Support Enabled
INFO - 2021-08-23 04:14:01 --> Utf8 Class Initialized
INFO - 2021-08-23 04:14:01 --> URI Class Initialized
INFO - 2021-08-23 04:14:01 --> Router Class Initialized
INFO - 2021-08-23 04:14:01 --> Output Class Initialized
INFO - 2021-08-23 04:14:01 --> Security Class Initialized
DEBUG - 2021-08-23 04:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-23 04:14:01 --> Input Class Initialized
INFO - 2021-08-23 04:14:01 --> Language Class Initialized
INFO - 2021-08-23 04:14:01 --> Language Class Initialized
INFO - 2021-08-23 04:14:01 --> Config Class Initialized
INFO - 2021-08-23 04:14:01 --> Loader Class Initialized
INFO - 2021-08-23 04:14:01 --> Helper loaded: url_helper
INFO - 2021-08-23 04:14:01 --> Helper loaded: file_helper
INFO - 2021-08-23 04:14:01 --> Helper loaded: form_helper
INFO - 2021-08-23 04:14:01 --> Helper loaded: my_helper
INFO - 2021-08-23 04:14:01 --> Database Driver Class Initialized
DEBUG - 2021-08-23 04:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-23 04:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-23 04:14:01 --> Controller Class Initialized
DEBUG - 2021-08-23 04:14:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-08-23 04:14:01 --> Final output sent to browser
DEBUG - 2021-08-23 04:14:01 --> Total execution time: 0.1446
