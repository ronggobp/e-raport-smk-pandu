<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-26 04:22:09 --> Config Class Initialized
INFO - 2021-04-26 04:22:09 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:09 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:09 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:09 --> URI Class Initialized
DEBUG - 2021-04-26 04:22:09 --> No URI present. Default controller set.
INFO - 2021-04-26 04:22:09 --> Router Class Initialized
INFO - 2021-04-26 04:22:09 --> Output Class Initialized
INFO - 2021-04-26 04:22:09 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:09 --> Input Class Initialized
INFO - 2021-04-26 04:22:09 --> Language Class Initialized
INFO - 2021-04-26 04:22:09 --> Language Class Initialized
INFO - 2021-04-26 04:22:09 --> Config Class Initialized
INFO - 2021-04-26 04:22:09 --> Loader Class Initialized
INFO - 2021-04-26 04:22:09 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:09 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:09 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:09 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:09 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:10 --> Controller Class Initialized
INFO - 2021-04-26 04:22:10 --> Config Class Initialized
INFO - 2021-04-26 04:22:10 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:10 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:10 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:10 --> URI Class Initialized
INFO - 2021-04-26 04:22:10 --> Router Class Initialized
INFO - 2021-04-26 04:22:10 --> Output Class Initialized
INFO - 2021-04-26 04:22:10 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:10 --> Input Class Initialized
INFO - 2021-04-26 04:22:10 --> Language Class Initialized
INFO - 2021-04-26 04:22:10 --> Language Class Initialized
INFO - 2021-04-26 04:22:10 --> Config Class Initialized
INFO - 2021-04-26 04:22:10 --> Loader Class Initialized
INFO - 2021-04-26 04:22:10 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:10 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:10 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:10 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:10 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:10 --> Controller Class Initialized
DEBUG - 2021-04-26 04:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-26 04:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:22:10 --> Final output sent to browser
DEBUG - 2021-04-26 04:22:10 --> Total execution time: 0.1105
INFO - 2021-04-26 04:22:16 --> Config Class Initialized
INFO - 2021-04-26 04:22:16 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:16 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:16 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:16 --> URI Class Initialized
INFO - 2021-04-26 04:22:16 --> Router Class Initialized
INFO - 2021-04-26 04:22:16 --> Output Class Initialized
INFO - 2021-04-26 04:22:16 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:16 --> Input Class Initialized
INFO - 2021-04-26 04:22:16 --> Language Class Initialized
INFO - 2021-04-26 04:22:16 --> Language Class Initialized
INFO - 2021-04-26 04:22:16 --> Config Class Initialized
INFO - 2021-04-26 04:22:16 --> Loader Class Initialized
INFO - 2021-04-26 04:22:16 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:16 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:16 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:16 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:16 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:16 --> Controller Class Initialized
INFO - 2021-04-26 04:22:16 --> Helper loaded: cookie_helper
INFO - 2021-04-26 04:22:16 --> Final output sent to browser
DEBUG - 2021-04-26 04:22:16 --> Total execution time: 0.1259
INFO - 2021-04-26 04:22:16 --> Config Class Initialized
INFO - 2021-04-26 04:22:16 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:16 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:16 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:16 --> URI Class Initialized
INFO - 2021-04-26 04:22:16 --> Router Class Initialized
INFO - 2021-04-26 04:22:16 --> Output Class Initialized
INFO - 2021-04-26 04:22:16 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:16 --> Input Class Initialized
INFO - 2021-04-26 04:22:16 --> Language Class Initialized
INFO - 2021-04-26 04:22:16 --> Language Class Initialized
INFO - 2021-04-26 04:22:16 --> Config Class Initialized
INFO - 2021-04-26 04:22:16 --> Loader Class Initialized
INFO - 2021-04-26 04:22:16 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:16 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:16 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:16 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:16 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:16 --> Controller Class Initialized
DEBUG - 2021-04-26 04:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-26 04:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:22:17 --> Final output sent to browser
DEBUG - 2021-04-26 04:22:17 --> Total execution time: 0.2928
INFO - 2021-04-26 04:22:20 --> Config Class Initialized
INFO - 2021-04-26 04:22:20 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:20 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:20 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:20 --> URI Class Initialized
INFO - 2021-04-26 04:22:20 --> Router Class Initialized
INFO - 2021-04-26 04:22:20 --> Output Class Initialized
INFO - 2021-04-26 04:22:20 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:20 --> Input Class Initialized
INFO - 2021-04-26 04:22:20 --> Language Class Initialized
INFO - 2021-04-26 04:22:20 --> Language Class Initialized
INFO - 2021-04-26 04:22:20 --> Config Class Initialized
INFO - 2021-04-26 04:22:20 --> Loader Class Initialized
INFO - 2021-04-26 04:22:20 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:20 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:20 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:21 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:21 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:21 --> Controller Class Initialized
DEBUG - 2021-04-26 04:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-26 04:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:22:21 --> Final output sent to browser
DEBUG - 2021-04-26 04:22:21 --> Total execution time: 0.1173
INFO - 2021-04-26 04:22:21 --> Config Class Initialized
INFO - 2021-04-26 04:22:21 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:21 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:21 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:21 --> URI Class Initialized
INFO - 2021-04-26 04:22:21 --> Router Class Initialized
INFO - 2021-04-26 04:22:21 --> Output Class Initialized
INFO - 2021-04-26 04:22:21 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:21 --> Input Class Initialized
INFO - 2021-04-26 04:22:21 --> Language Class Initialized
INFO - 2021-04-26 04:22:21 --> Language Class Initialized
INFO - 2021-04-26 04:22:21 --> Config Class Initialized
INFO - 2021-04-26 04:22:21 --> Loader Class Initialized
INFO - 2021-04-26 04:22:21 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:21 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:21 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:21 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:21 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:21 --> Controller Class Initialized
INFO - 2021-04-26 04:22:24 --> Config Class Initialized
INFO - 2021-04-26 04:22:24 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:24 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:24 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:24 --> URI Class Initialized
INFO - 2021-04-26 04:22:24 --> Router Class Initialized
INFO - 2021-04-26 04:22:24 --> Output Class Initialized
INFO - 2021-04-26 04:22:24 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:24 --> Input Class Initialized
INFO - 2021-04-26 04:22:24 --> Language Class Initialized
INFO - 2021-04-26 04:22:24 --> Language Class Initialized
INFO - 2021-04-26 04:22:24 --> Config Class Initialized
INFO - 2021-04-26 04:22:24 --> Loader Class Initialized
INFO - 2021-04-26 04:22:24 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:24 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:24 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:24 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:24 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:24 --> Controller Class Initialized
DEBUG - 2021-04-26 04:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-26 04:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:22:24 --> Final output sent to browser
DEBUG - 2021-04-26 04:22:24 --> Total execution time: 0.1187
INFO - 2021-04-26 04:22:26 --> Config Class Initialized
INFO - 2021-04-26 04:22:26 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:26 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:26 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:26 --> URI Class Initialized
INFO - 2021-04-26 04:22:26 --> Router Class Initialized
INFO - 2021-04-26 04:22:26 --> Output Class Initialized
INFO - 2021-04-26 04:22:26 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:26 --> Input Class Initialized
INFO - 2021-04-26 04:22:26 --> Language Class Initialized
INFO - 2021-04-26 04:22:26 --> Language Class Initialized
INFO - 2021-04-26 04:22:26 --> Config Class Initialized
INFO - 2021-04-26 04:22:26 --> Loader Class Initialized
INFO - 2021-04-26 04:22:26 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:26 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:26 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:26 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:26 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:26 --> Controller Class Initialized
DEBUG - 2021-04-26 04:22:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-26 04:22:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:22:26 --> Final output sent to browser
DEBUG - 2021-04-26 04:22:26 --> Total execution time: 0.0929
INFO - 2021-04-26 04:22:43 --> Config Class Initialized
INFO - 2021-04-26 04:22:43 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:43 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:43 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:43 --> URI Class Initialized
INFO - 2021-04-26 04:22:43 --> Router Class Initialized
INFO - 2021-04-26 04:22:43 --> Output Class Initialized
INFO - 2021-04-26 04:22:43 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:43 --> Input Class Initialized
INFO - 2021-04-26 04:22:43 --> Language Class Initialized
INFO - 2021-04-26 04:22:43 --> Language Class Initialized
INFO - 2021-04-26 04:22:43 --> Config Class Initialized
INFO - 2021-04-26 04:22:43 --> Loader Class Initialized
INFO - 2021-04-26 04:22:43 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:43 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:43 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:43 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:43 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:43 --> Controller Class Initialized
INFO - 2021-04-26 04:22:43 --> Config Class Initialized
INFO - 2021-04-26 04:22:43 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:22:43 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:22:43 --> Utf8 Class Initialized
INFO - 2021-04-26 04:22:43 --> URI Class Initialized
INFO - 2021-04-26 04:22:43 --> Router Class Initialized
INFO - 2021-04-26 04:22:43 --> Output Class Initialized
INFO - 2021-04-26 04:22:43 --> Security Class Initialized
DEBUG - 2021-04-26 04:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:22:43 --> Input Class Initialized
INFO - 2021-04-26 04:22:43 --> Language Class Initialized
INFO - 2021-04-26 04:22:43 --> Language Class Initialized
INFO - 2021-04-26 04:22:43 --> Config Class Initialized
INFO - 2021-04-26 04:22:43 --> Loader Class Initialized
INFO - 2021-04-26 04:22:43 --> Helper loaded: url_helper
INFO - 2021-04-26 04:22:43 --> Helper loaded: file_helper
INFO - 2021-04-26 04:22:43 --> Helper loaded: form_helper
INFO - 2021-04-26 04:22:43 --> Helper loaded: my_helper
INFO - 2021-04-26 04:22:43 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:22:43 --> Controller Class Initialized
DEBUG - 2021-04-26 04:22:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-26 04:22:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:22:43 --> Final output sent to browser
DEBUG - 2021-04-26 04:22:43 --> Total execution time: 0.0494
INFO - 2021-04-26 04:25:38 --> Config Class Initialized
INFO - 2021-04-26 04:25:38 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:25:38 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:25:38 --> Utf8 Class Initialized
INFO - 2021-04-26 04:25:38 --> URI Class Initialized
INFO - 2021-04-26 04:25:38 --> Router Class Initialized
INFO - 2021-04-26 04:25:38 --> Output Class Initialized
INFO - 2021-04-26 04:25:39 --> Security Class Initialized
DEBUG - 2021-04-26 04:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:25:39 --> Input Class Initialized
INFO - 2021-04-26 04:25:39 --> Language Class Initialized
INFO - 2021-04-26 04:25:39 --> Language Class Initialized
INFO - 2021-04-26 04:25:39 --> Config Class Initialized
INFO - 2021-04-26 04:25:39 --> Loader Class Initialized
INFO - 2021-04-26 04:25:39 --> Helper loaded: url_helper
INFO - 2021-04-26 04:25:39 --> Helper loaded: file_helper
INFO - 2021-04-26 04:25:39 --> Helper loaded: form_helper
INFO - 2021-04-26 04:25:39 --> Helper loaded: my_helper
INFO - 2021-04-26 04:25:39 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:25:39 --> Controller Class Initialized
DEBUG - 2021-04-26 04:25:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-26 04:25:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:25:39 --> Final output sent to browser
DEBUG - 2021-04-26 04:25:39 --> Total execution time: 0.1022
INFO - 2021-04-26 04:25:44 --> Config Class Initialized
INFO - 2021-04-26 04:25:44 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:25:44 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:25:44 --> Utf8 Class Initialized
INFO - 2021-04-26 04:25:44 --> URI Class Initialized
INFO - 2021-04-26 04:25:44 --> Router Class Initialized
INFO - 2021-04-26 04:25:44 --> Output Class Initialized
INFO - 2021-04-26 04:25:44 --> Security Class Initialized
DEBUG - 2021-04-26 04:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:25:44 --> Input Class Initialized
INFO - 2021-04-26 04:25:44 --> Language Class Initialized
INFO - 2021-04-26 04:25:44 --> Language Class Initialized
INFO - 2021-04-26 04:25:44 --> Config Class Initialized
INFO - 2021-04-26 04:25:44 --> Loader Class Initialized
INFO - 2021-04-26 04:25:44 --> Helper loaded: url_helper
INFO - 2021-04-26 04:25:44 --> Helper loaded: file_helper
INFO - 2021-04-26 04:25:44 --> Helper loaded: form_helper
INFO - 2021-04-26 04:25:44 --> Helper loaded: my_helper
INFO - 2021-04-26 04:25:44 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:25:44 --> Controller Class Initialized
INFO - 2021-04-26 04:25:44 --> Config Class Initialized
INFO - 2021-04-26 04:25:44 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:25:44 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:25:44 --> Utf8 Class Initialized
INFO - 2021-04-26 04:25:44 --> URI Class Initialized
INFO - 2021-04-26 04:25:44 --> Router Class Initialized
INFO - 2021-04-26 04:25:44 --> Output Class Initialized
INFO - 2021-04-26 04:25:44 --> Security Class Initialized
DEBUG - 2021-04-26 04:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:25:44 --> Input Class Initialized
INFO - 2021-04-26 04:25:44 --> Language Class Initialized
INFO - 2021-04-26 04:25:44 --> Language Class Initialized
INFO - 2021-04-26 04:25:44 --> Config Class Initialized
INFO - 2021-04-26 04:25:44 --> Loader Class Initialized
INFO - 2021-04-26 04:25:44 --> Helper loaded: url_helper
INFO - 2021-04-26 04:25:44 --> Helper loaded: file_helper
INFO - 2021-04-26 04:25:44 --> Helper loaded: form_helper
INFO - 2021-04-26 04:25:44 --> Helper loaded: my_helper
INFO - 2021-04-26 04:25:44 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:25:44 --> Controller Class Initialized
DEBUG - 2021-04-26 04:25:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-26 04:25:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:25:44 --> Final output sent to browser
DEBUG - 2021-04-26 04:25:44 --> Total execution time: 0.0800
INFO - 2021-04-26 04:42:19 --> Config Class Initialized
INFO - 2021-04-26 04:42:19 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:19 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:19 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:19 --> URI Class Initialized
INFO - 2021-04-26 04:42:19 --> Router Class Initialized
INFO - 2021-04-26 04:42:19 --> Output Class Initialized
INFO - 2021-04-26 04:42:19 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:19 --> Input Class Initialized
INFO - 2021-04-26 04:42:19 --> Language Class Initialized
INFO - 2021-04-26 04:42:19 --> Language Class Initialized
INFO - 2021-04-26 04:42:19 --> Config Class Initialized
INFO - 2021-04-26 04:42:19 --> Loader Class Initialized
INFO - 2021-04-26 04:42:19 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:19 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:19 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:19 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:19 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:19 --> Controller Class Initialized
DEBUG - 2021-04-26 04:42:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-04-26 04:42:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:42:19 --> Final output sent to browser
DEBUG - 2021-04-26 04:42:19 --> Total execution time: 0.1062
INFO - 2021-04-26 04:42:19 --> Config Class Initialized
INFO - 2021-04-26 04:42:19 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:19 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:19 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:19 --> URI Class Initialized
INFO - 2021-04-26 04:42:19 --> Router Class Initialized
INFO - 2021-04-26 04:42:19 --> Output Class Initialized
INFO - 2021-04-26 04:42:19 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:19 --> Input Class Initialized
INFO - 2021-04-26 04:42:19 --> Language Class Initialized
INFO - 2021-04-26 04:42:19 --> Language Class Initialized
INFO - 2021-04-26 04:42:19 --> Config Class Initialized
INFO - 2021-04-26 04:42:19 --> Loader Class Initialized
INFO - 2021-04-26 04:42:19 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:19 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:19 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:19 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:19 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:19 --> Controller Class Initialized
INFO - 2021-04-26 04:42:21 --> Config Class Initialized
INFO - 2021-04-26 04:42:21 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:21 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:21 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:21 --> URI Class Initialized
INFO - 2021-04-26 04:42:21 --> Router Class Initialized
INFO - 2021-04-26 04:42:21 --> Output Class Initialized
INFO - 2021-04-26 04:42:21 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:21 --> Input Class Initialized
INFO - 2021-04-26 04:42:21 --> Language Class Initialized
INFO - 2021-04-26 04:42:21 --> Language Class Initialized
INFO - 2021-04-26 04:42:21 --> Config Class Initialized
INFO - 2021-04-26 04:42:21 --> Loader Class Initialized
INFO - 2021-04-26 04:42:21 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:21 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:21 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:21 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:21 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:21 --> Controller Class Initialized
DEBUG - 2021-04-26 04:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-26 04:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:42:21 --> Final output sent to browser
DEBUG - 2021-04-26 04:42:21 --> Total execution time: 0.0984
INFO - 2021-04-26 04:42:21 --> Config Class Initialized
INFO - 2021-04-26 04:42:21 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:21 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:21 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:21 --> URI Class Initialized
INFO - 2021-04-26 04:42:21 --> Router Class Initialized
INFO - 2021-04-26 04:42:21 --> Output Class Initialized
INFO - 2021-04-26 04:42:21 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:21 --> Input Class Initialized
INFO - 2021-04-26 04:42:21 --> Language Class Initialized
INFO - 2021-04-26 04:42:21 --> Language Class Initialized
INFO - 2021-04-26 04:42:21 --> Config Class Initialized
INFO - 2021-04-26 04:42:21 --> Loader Class Initialized
INFO - 2021-04-26 04:42:21 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:21 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:21 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:21 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:21 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:22 --> Controller Class Initialized
INFO - 2021-04-26 04:42:35 --> Config Class Initialized
INFO - 2021-04-26 04:42:35 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:35 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:35 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:35 --> URI Class Initialized
INFO - 2021-04-26 04:42:35 --> Router Class Initialized
INFO - 2021-04-26 04:42:35 --> Output Class Initialized
INFO - 2021-04-26 04:42:35 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:35 --> Input Class Initialized
INFO - 2021-04-26 04:42:35 --> Language Class Initialized
INFO - 2021-04-26 04:42:35 --> Language Class Initialized
INFO - 2021-04-26 04:42:35 --> Config Class Initialized
INFO - 2021-04-26 04:42:35 --> Loader Class Initialized
INFO - 2021-04-26 04:42:35 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:35 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:35 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:35 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:35 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:35 --> Controller Class Initialized
INFO - 2021-04-26 04:42:35 --> Final output sent to browser
DEBUG - 2021-04-26 04:42:35 --> Total execution time: 0.0755
INFO - 2021-04-26 04:42:35 --> Config Class Initialized
INFO - 2021-04-26 04:42:35 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:35 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:35 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:35 --> URI Class Initialized
INFO - 2021-04-26 04:42:35 --> Router Class Initialized
INFO - 2021-04-26 04:42:35 --> Output Class Initialized
INFO - 2021-04-26 04:42:35 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:35 --> Input Class Initialized
INFO - 2021-04-26 04:42:35 --> Language Class Initialized
INFO - 2021-04-26 04:42:35 --> Language Class Initialized
INFO - 2021-04-26 04:42:35 --> Config Class Initialized
INFO - 2021-04-26 04:42:35 --> Loader Class Initialized
INFO - 2021-04-26 04:42:35 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:35 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:35 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:35 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:35 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:35 --> Controller Class Initialized
INFO - 2021-04-26 04:42:42 --> Config Class Initialized
INFO - 2021-04-26 04:42:42 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:42 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:42 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:42 --> URI Class Initialized
INFO - 2021-04-26 04:42:42 --> Router Class Initialized
INFO - 2021-04-26 04:42:42 --> Output Class Initialized
INFO - 2021-04-26 04:42:42 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:42 --> Input Class Initialized
INFO - 2021-04-26 04:42:42 --> Language Class Initialized
INFO - 2021-04-26 04:42:42 --> Language Class Initialized
INFO - 2021-04-26 04:42:42 --> Config Class Initialized
INFO - 2021-04-26 04:42:42 --> Loader Class Initialized
INFO - 2021-04-26 04:42:42 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:42 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:42 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:42 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:42 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:42 --> Controller Class Initialized
DEBUG - 2021-04-26 04:42:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-26 04:42:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:42:42 --> Final output sent to browser
DEBUG - 2021-04-26 04:42:42 --> Total execution time: 0.0856
INFO - 2021-04-26 04:42:43 --> Config Class Initialized
INFO - 2021-04-26 04:42:43 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:44 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:44 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:44 --> URI Class Initialized
INFO - 2021-04-26 04:42:44 --> Router Class Initialized
INFO - 2021-04-26 04:42:44 --> Output Class Initialized
INFO - 2021-04-26 04:42:44 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:44 --> Input Class Initialized
INFO - 2021-04-26 04:42:44 --> Language Class Initialized
INFO - 2021-04-26 04:42:44 --> Language Class Initialized
INFO - 2021-04-26 04:42:44 --> Config Class Initialized
INFO - 2021-04-26 04:42:44 --> Loader Class Initialized
INFO - 2021-04-26 04:42:44 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:44 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:44 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:44 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:44 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:44 --> Controller Class Initialized
DEBUG - 2021-04-26 04:42:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-26 04:42:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:42:44 --> Final output sent to browser
DEBUG - 2021-04-26 04:42:44 --> Total execution time: 0.0882
INFO - 2021-04-26 04:42:52 --> Config Class Initialized
INFO - 2021-04-26 04:42:52 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:52 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:52 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:52 --> URI Class Initialized
INFO - 2021-04-26 04:42:52 --> Router Class Initialized
INFO - 2021-04-26 04:42:52 --> Output Class Initialized
INFO - 2021-04-26 04:42:52 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:52 --> Input Class Initialized
INFO - 2021-04-26 04:42:52 --> Language Class Initialized
INFO - 2021-04-26 04:42:52 --> Language Class Initialized
INFO - 2021-04-26 04:42:52 --> Config Class Initialized
INFO - 2021-04-26 04:42:52 --> Loader Class Initialized
INFO - 2021-04-26 04:42:52 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:52 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:52 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:52 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:52 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:52 --> Controller Class Initialized
INFO - 2021-04-26 04:42:52 --> Config Class Initialized
INFO - 2021-04-26 04:42:52 --> Hooks Class Initialized
DEBUG - 2021-04-26 04:42:52 --> UTF-8 Support Enabled
INFO - 2021-04-26 04:42:52 --> Utf8 Class Initialized
INFO - 2021-04-26 04:42:52 --> URI Class Initialized
INFO - 2021-04-26 04:42:52 --> Router Class Initialized
INFO - 2021-04-26 04:42:52 --> Output Class Initialized
INFO - 2021-04-26 04:42:52 --> Security Class Initialized
DEBUG - 2021-04-26 04:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 04:42:52 --> Input Class Initialized
INFO - 2021-04-26 04:42:52 --> Language Class Initialized
INFO - 2021-04-26 04:42:52 --> Language Class Initialized
INFO - 2021-04-26 04:42:52 --> Config Class Initialized
INFO - 2021-04-26 04:42:52 --> Loader Class Initialized
INFO - 2021-04-26 04:42:52 --> Helper loaded: url_helper
INFO - 2021-04-26 04:42:52 --> Helper loaded: file_helper
INFO - 2021-04-26 04:42:52 --> Helper loaded: form_helper
INFO - 2021-04-26 04:42:52 --> Helper loaded: my_helper
INFO - 2021-04-26 04:42:52 --> Database Driver Class Initialized
DEBUG - 2021-04-26 04:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 04:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 04:42:52 --> Controller Class Initialized
DEBUG - 2021-04-26 04:42:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-26 04:42:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 04:42:52 --> Final output sent to browser
DEBUG - 2021-04-26 04:42:52 --> Total execution time: 0.0754
INFO - 2021-04-26 05:45:21 --> Config Class Initialized
INFO - 2021-04-26 05:45:21 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:21 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:21 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:21 --> URI Class Initialized
INFO - 2021-04-26 05:45:21 --> Router Class Initialized
INFO - 2021-04-26 05:45:21 --> Output Class Initialized
INFO - 2021-04-26 05:45:21 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:21 --> Input Class Initialized
INFO - 2021-04-26 05:45:21 --> Language Class Initialized
INFO - 2021-04-26 05:45:21 --> Language Class Initialized
INFO - 2021-04-26 05:45:21 --> Config Class Initialized
INFO - 2021-04-26 05:45:21 --> Loader Class Initialized
INFO - 2021-04-26 05:45:21 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:21 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:21 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:21 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:21 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:21 --> Controller Class Initialized
DEBUG - 2021-04-26 05:45:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-26 05:45:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:45:21 --> Final output sent to browser
DEBUG - 2021-04-26 05:45:21 --> Total execution time: 0.0633
INFO - 2021-04-26 05:45:26 --> Config Class Initialized
INFO - 2021-04-26 05:45:26 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:26 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:26 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:26 --> URI Class Initialized
INFO - 2021-04-26 05:45:26 --> Router Class Initialized
INFO - 2021-04-26 05:45:26 --> Output Class Initialized
INFO - 2021-04-26 05:45:26 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:26 --> Input Class Initialized
INFO - 2021-04-26 05:45:26 --> Language Class Initialized
INFO - 2021-04-26 05:45:26 --> Language Class Initialized
INFO - 2021-04-26 05:45:26 --> Config Class Initialized
INFO - 2021-04-26 05:45:26 --> Loader Class Initialized
INFO - 2021-04-26 05:45:26 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:26 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:26 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:26 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:26 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:26 --> Controller Class Initialized
DEBUG - 2021-04-26 05:45:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-26 05:45:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:45:26 --> Final output sent to browser
DEBUG - 2021-04-26 05:45:26 --> Total execution time: 0.0636
INFO - 2021-04-26 05:45:26 --> Config Class Initialized
INFO - 2021-04-26 05:45:26 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:26 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:26 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:26 --> URI Class Initialized
INFO - 2021-04-26 05:45:26 --> Router Class Initialized
INFO - 2021-04-26 05:45:26 --> Output Class Initialized
INFO - 2021-04-26 05:45:26 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:26 --> Input Class Initialized
INFO - 2021-04-26 05:45:26 --> Language Class Initialized
INFO - 2021-04-26 05:45:26 --> Language Class Initialized
INFO - 2021-04-26 05:45:26 --> Config Class Initialized
INFO - 2021-04-26 05:45:26 --> Loader Class Initialized
INFO - 2021-04-26 05:45:26 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:26 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:26 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:26 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:26 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:26 --> Controller Class Initialized
INFO - 2021-04-26 05:45:27 --> Config Class Initialized
INFO - 2021-04-26 05:45:27 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:27 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:27 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:27 --> URI Class Initialized
INFO - 2021-04-26 05:45:27 --> Router Class Initialized
INFO - 2021-04-26 05:45:27 --> Output Class Initialized
INFO - 2021-04-26 05:45:27 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:27 --> Input Class Initialized
INFO - 2021-04-26 05:45:27 --> Language Class Initialized
INFO - 2021-04-26 05:45:27 --> Language Class Initialized
INFO - 2021-04-26 05:45:27 --> Config Class Initialized
INFO - 2021-04-26 05:45:27 --> Loader Class Initialized
INFO - 2021-04-26 05:45:27 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:27 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:27 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:27 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:27 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:27 --> Controller Class Initialized
DEBUG - 2021-04-26 05:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-04-26 05:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:45:27 --> Final output sent to browser
DEBUG - 2021-04-26 05:45:27 --> Total execution time: 0.0653
INFO - 2021-04-26 05:45:27 --> Config Class Initialized
INFO - 2021-04-26 05:45:27 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:27 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:27 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:27 --> URI Class Initialized
INFO - 2021-04-26 05:45:27 --> Router Class Initialized
INFO - 2021-04-26 05:45:27 --> Output Class Initialized
INFO - 2021-04-26 05:45:27 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:27 --> Input Class Initialized
INFO - 2021-04-26 05:45:27 --> Language Class Initialized
INFO - 2021-04-26 05:45:27 --> Language Class Initialized
INFO - 2021-04-26 05:45:27 --> Config Class Initialized
INFO - 2021-04-26 05:45:27 --> Loader Class Initialized
INFO - 2021-04-26 05:45:27 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:27 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:27 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:27 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:27 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:27 --> Controller Class Initialized
INFO - 2021-04-26 05:45:28 --> Config Class Initialized
INFO - 2021-04-26 05:45:28 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:28 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:28 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:28 --> URI Class Initialized
INFO - 2021-04-26 05:45:28 --> Router Class Initialized
INFO - 2021-04-26 05:45:28 --> Output Class Initialized
INFO - 2021-04-26 05:45:28 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:28 --> Input Class Initialized
INFO - 2021-04-26 05:45:28 --> Language Class Initialized
INFO - 2021-04-26 05:45:28 --> Language Class Initialized
INFO - 2021-04-26 05:45:28 --> Config Class Initialized
INFO - 2021-04-26 05:45:28 --> Loader Class Initialized
INFO - 2021-04-26 05:45:28 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:28 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:28 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:28 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:28 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:28 --> Controller Class Initialized
DEBUG - 2021-04-26 05:45:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-26 05:45:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:45:28 --> Final output sent to browser
DEBUG - 2021-04-26 05:45:28 --> Total execution time: 0.0631
INFO - 2021-04-26 05:45:28 --> Config Class Initialized
INFO - 2021-04-26 05:45:28 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:28 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:28 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:28 --> URI Class Initialized
INFO - 2021-04-26 05:45:28 --> Router Class Initialized
INFO - 2021-04-26 05:45:28 --> Output Class Initialized
INFO - 2021-04-26 05:45:28 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:28 --> Input Class Initialized
INFO - 2021-04-26 05:45:28 --> Language Class Initialized
INFO - 2021-04-26 05:45:28 --> Language Class Initialized
INFO - 2021-04-26 05:45:28 --> Config Class Initialized
INFO - 2021-04-26 05:45:28 --> Loader Class Initialized
INFO - 2021-04-26 05:45:28 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:28 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:28 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:28 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:28 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:28 --> Controller Class Initialized
INFO - 2021-04-26 05:45:35 --> Config Class Initialized
INFO - 2021-04-26 05:45:35 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:35 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:35 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:35 --> URI Class Initialized
INFO - 2021-04-26 05:45:35 --> Router Class Initialized
INFO - 2021-04-26 05:45:35 --> Output Class Initialized
INFO - 2021-04-26 05:45:35 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:35 --> Input Class Initialized
INFO - 2021-04-26 05:45:35 --> Language Class Initialized
INFO - 2021-04-26 05:45:35 --> Language Class Initialized
INFO - 2021-04-26 05:45:35 --> Config Class Initialized
INFO - 2021-04-26 05:45:35 --> Loader Class Initialized
INFO - 2021-04-26 05:45:35 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:35 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:35 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:35 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:35 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:35 --> Controller Class Initialized
DEBUG - 2021-04-26 05:45:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-04-26 05:45:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:45:35 --> Final output sent to browser
DEBUG - 2021-04-26 05:45:35 --> Total execution time: 0.0576
INFO - 2021-04-26 05:45:35 --> Config Class Initialized
INFO - 2021-04-26 05:45:35 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:35 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:35 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:35 --> URI Class Initialized
INFO - 2021-04-26 05:45:35 --> Router Class Initialized
INFO - 2021-04-26 05:45:35 --> Output Class Initialized
INFO - 2021-04-26 05:45:35 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:35 --> Input Class Initialized
INFO - 2021-04-26 05:45:35 --> Language Class Initialized
INFO - 2021-04-26 05:45:35 --> Language Class Initialized
INFO - 2021-04-26 05:45:35 --> Config Class Initialized
INFO - 2021-04-26 05:45:35 --> Loader Class Initialized
INFO - 2021-04-26 05:45:35 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:35 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:35 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:35 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:35 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:35 --> Controller Class Initialized
INFO - 2021-04-26 05:45:36 --> Config Class Initialized
INFO - 2021-04-26 05:45:36 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:36 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:36 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:36 --> URI Class Initialized
INFO - 2021-04-26 05:45:36 --> Router Class Initialized
INFO - 2021-04-26 05:45:36 --> Output Class Initialized
INFO - 2021-04-26 05:45:36 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:36 --> Input Class Initialized
INFO - 2021-04-26 05:45:36 --> Language Class Initialized
INFO - 2021-04-26 05:45:36 --> Language Class Initialized
INFO - 2021-04-26 05:45:36 --> Config Class Initialized
INFO - 2021-04-26 05:45:36 --> Loader Class Initialized
INFO - 2021-04-26 05:45:36 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:36 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:36 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:36 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:36 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:36 --> Controller Class Initialized
DEBUG - 2021-04-26 05:45:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-26 05:45:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:45:36 --> Final output sent to browser
DEBUG - 2021-04-26 05:45:36 --> Total execution time: 0.1030
INFO - 2021-04-26 05:45:37 --> Config Class Initialized
INFO - 2021-04-26 05:45:37 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:37 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:37 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:37 --> URI Class Initialized
INFO - 2021-04-26 05:45:37 --> Router Class Initialized
INFO - 2021-04-26 05:45:37 --> Output Class Initialized
INFO - 2021-04-26 05:45:37 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:37 --> Input Class Initialized
INFO - 2021-04-26 05:45:37 --> Language Class Initialized
INFO - 2021-04-26 05:45:37 --> Language Class Initialized
INFO - 2021-04-26 05:45:37 --> Config Class Initialized
INFO - 2021-04-26 05:45:37 --> Loader Class Initialized
INFO - 2021-04-26 05:45:37 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:37 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:37 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:37 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:37 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:37 --> Controller Class Initialized
INFO - 2021-04-26 05:45:42 --> Config Class Initialized
INFO - 2021-04-26 05:45:42 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:42 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:42 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:42 --> URI Class Initialized
INFO - 2021-04-26 05:45:42 --> Router Class Initialized
INFO - 2021-04-26 05:45:42 --> Output Class Initialized
INFO - 2021-04-26 05:45:42 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:42 --> Input Class Initialized
INFO - 2021-04-26 05:45:42 --> Language Class Initialized
INFO - 2021-04-26 05:45:42 --> Language Class Initialized
INFO - 2021-04-26 05:45:42 --> Config Class Initialized
INFO - 2021-04-26 05:45:42 --> Loader Class Initialized
INFO - 2021-04-26 05:45:42 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:42 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:42 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:42 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:42 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:42 --> Controller Class Initialized
INFO - 2021-04-26 05:45:42 --> Final output sent to browser
DEBUG - 2021-04-26 05:45:42 --> Total execution time: 0.0817
INFO - 2021-04-26 05:45:42 --> Config Class Initialized
INFO - 2021-04-26 05:45:42 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:42 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:42 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:42 --> URI Class Initialized
INFO - 2021-04-26 05:45:42 --> Router Class Initialized
INFO - 2021-04-26 05:45:42 --> Output Class Initialized
INFO - 2021-04-26 05:45:42 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:42 --> Input Class Initialized
INFO - 2021-04-26 05:45:42 --> Language Class Initialized
INFO - 2021-04-26 05:45:42 --> Language Class Initialized
INFO - 2021-04-26 05:45:42 --> Config Class Initialized
INFO - 2021-04-26 05:45:42 --> Loader Class Initialized
INFO - 2021-04-26 05:45:42 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:42 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:42 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:42 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:42 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:42 --> Controller Class Initialized
INFO - 2021-04-26 05:45:44 --> Config Class Initialized
INFO - 2021-04-26 05:45:44 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:44 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:44 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:44 --> URI Class Initialized
INFO - 2021-04-26 05:45:44 --> Router Class Initialized
INFO - 2021-04-26 05:45:44 --> Output Class Initialized
INFO - 2021-04-26 05:45:44 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:44 --> Input Class Initialized
INFO - 2021-04-26 05:45:44 --> Language Class Initialized
INFO - 2021-04-26 05:45:44 --> Language Class Initialized
INFO - 2021-04-26 05:45:44 --> Config Class Initialized
INFO - 2021-04-26 05:45:44 --> Loader Class Initialized
INFO - 2021-04-26 05:45:44 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:44 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:44 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:44 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:44 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:44 --> Controller Class Initialized
ERROR - 2021-04-26 05:45:44 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '6'
INFO - 2021-04-26 05:45:44 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-26 05:45:47 --> Config Class Initialized
INFO - 2021-04-26 05:45:47 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:47 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:47 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:47 --> URI Class Initialized
INFO - 2021-04-26 05:45:47 --> Router Class Initialized
INFO - 2021-04-26 05:45:47 --> Output Class Initialized
INFO - 2021-04-26 05:45:47 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:47 --> Input Class Initialized
INFO - 2021-04-26 05:45:47 --> Language Class Initialized
INFO - 2021-04-26 05:45:48 --> Language Class Initialized
INFO - 2021-04-26 05:45:48 --> Config Class Initialized
INFO - 2021-04-26 05:45:48 --> Loader Class Initialized
INFO - 2021-04-26 05:45:48 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:48 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:48 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:48 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:48 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:48 --> Controller Class Initialized
ERROR - 2021-04-26 05:45:48 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_walikelas`, CONSTRAINT `FK_t_walikelas_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '7'
INFO - 2021-04-26 05:45:48 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-26 05:45:59 --> Config Class Initialized
INFO - 2021-04-26 05:45:59 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:45:59 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:45:59 --> Utf8 Class Initialized
INFO - 2021-04-26 05:45:59 --> URI Class Initialized
INFO - 2021-04-26 05:45:59 --> Router Class Initialized
INFO - 2021-04-26 05:45:59 --> Output Class Initialized
INFO - 2021-04-26 05:45:59 --> Security Class Initialized
DEBUG - 2021-04-26 05:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:45:59 --> Input Class Initialized
INFO - 2021-04-26 05:45:59 --> Language Class Initialized
INFO - 2021-04-26 05:45:59 --> Language Class Initialized
INFO - 2021-04-26 05:45:59 --> Config Class Initialized
INFO - 2021-04-26 05:45:59 --> Loader Class Initialized
INFO - 2021-04-26 05:45:59 --> Helper loaded: url_helper
INFO - 2021-04-26 05:45:59 --> Helper loaded: file_helper
INFO - 2021-04-26 05:45:59 --> Helper loaded: form_helper
INFO - 2021-04-26 05:45:59 --> Helper loaded: my_helper
INFO - 2021-04-26 05:45:59 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:45:59 --> Controller Class Initialized
INFO - 2021-04-26 05:45:59 --> Final output sent to browser
DEBUG - 2021-04-26 05:45:59 --> Total execution time: 0.0947
INFO - 2021-04-26 05:46:03 --> Config Class Initialized
INFO - 2021-04-26 05:46:03 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:03 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:03 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:03 --> URI Class Initialized
INFO - 2021-04-26 05:46:03 --> Router Class Initialized
INFO - 2021-04-26 05:46:03 --> Output Class Initialized
INFO - 2021-04-26 05:46:03 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:03 --> Input Class Initialized
INFO - 2021-04-26 05:46:03 --> Language Class Initialized
INFO - 2021-04-26 05:46:03 --> Language Class Initialized
INFO - 2021-04-26 05:46:03 --> Config Class Initialized
INFO - 2021-04-26 05:46:03 --> Loader Class Initialized
INFO - 2021-04-26 05:46:03 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:03 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:03 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:03 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:03 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:03 --> Controller Class Initialized
ERROR - 2021-04-26 05:46:03 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_walikelas`, CONSTRAINT `FK_t_walikelas_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '7'
INFO - 2021-04-26 05:46:03 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-26 05:46:05 --> Config Class Initialized
INFO - 2021-04-26 05:46:05 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:05 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:05 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:05 --> URI Class Initialized
INFO - 2021-04-26 05:46:05 --> Router Class Initialized
INFO - 2021-04-26 05:46:05 --> Output Class Initialized
INFO - 2021-04-26 05:46:05 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:05 --> Input Class Initialized
INFO - 2021-04-26 05:46:05 --> Language Class Initialized
INFO - 2021-04-26 05:46:05 --> Language Class Initialized
INFO - 2021-04-26 05:46:05 --> Config Class Initialized
INFO - 2021-04-26 05:46:05 --> Loader Class Initialized
INFO - 2021-04-26 05:46:05 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:05 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:05 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:05 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:05 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:05 --> Controller Class Initialized
ERROR - 2021-04-26 05:46:05 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '6'
INFO - 2021-04-26 05:46:05 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-26 05:46:32 --> Config Class Initialized
INFO - 2021-04-26 05:46:32 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:32 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:32 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:32 --> URI Class Initialized
INFO - 2021-04-26 05:46:32 --> Router Class Initialized
INFO - 2021-04-26 05:46:32 --> Output Class Initialized
INFO - 2021-04-26 05:46:32 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:32 --> Input Class Initialized
INFO - 2021-04-26 05:46:32 --> Language Class Initialized
INFO - 2021-04-26 05:46:32 --> Language Class Initialized
INFO - 2021-04-26 05:46:32 --> Config Class Initialized
INFO - 2021-04-26 05:46:32 --> Loader Class Initialized
INFO - 2021-04-26 05:46:32 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:32 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:32 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:32 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:32 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:32 --> Controller Class Initialized
DEBUG - 2021-04-26 05:46:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-26 05:46:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:46:32 --> Final output sent to browser
DEBUG - 2021-04-26 05:46:32 --> Total execution time: 0.0932
INFO - 2021-04-26 05:46:32 --> Config Class Initialized
INFO - 2021-04-26 05:46:32 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:32 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:32 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:32 --> URI Class Initialized
INFO - 2021-04-26 05:46:32 --> Router Class Initialized
INFO - 2021-04-26 05:46:32 --> Output Class Initialized
INFO - 2021-04-26 05:46:32 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:32 --> Input Class Initialized
INFO - 2021-04-26 05:46:32 --> Language Class Initialized
INFO - 2021-04-26 05:46:32 --> Language Class Initialized
INFO - 2021-04-26 05:46:32 --> Config Class Initialized
INFO - 2021-04-26 05:46:32 --> Loader Class Initialized
INFO - 2021-04-26 05:46:32 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:32 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:32 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:32 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:32 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:32 --> Controller Class Initialized
INFO - 2021-04-26 05:46:37 --> Config Class Initialized
INFO - 2021-04-26 05:46:37 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:37 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:37 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:37 --> URI Class Initialized
INFO - 2021-04-26 05:46:37 --> Router Class Initialized
INFO - 2021-04-26 05:46:37 --> Output Class Initialized
INFO - 2021-04-26 05:46:37 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:37 --> Input Class Initialized
INFO - 2021-04-26 05:46:37 --> Language Class Initialized
INFO - 2021-04-26 05:46:37 --> Language Class Initialized
INFO - 2021-04-26 05:46:37 --> Config Class Initialized
INFO - 2021-04-26 05:46:37 --> Loader Class Initialized
INFO - 2021-04-26 05:46:37 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:37 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:37 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:37 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:37 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:37 --> Controller Class Initialized
INFO - 2021-04-26 05:46:37 --> Final output sent to browser
DEBUG - 2021-04-26 05:46:37 --> Total execution time: 0.0789
INFO - 2021-04-26 05:46:37 --> Config Class Initialized
INFO - 2021-04-26 05:46:37 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:37 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:37 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:37 --> URI Class Initialized
INFO - 2021-04-26 05:46:37 --> Router Class Initialized
INFO - 2021-04-26 05:46:37 --> Output Class Initialized
INFO - 2021-04-26 05:46:37 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:37 --> Input Class Initialized
INFO - 2021-04-26 05:46:37 --> Language Class Initialized
INFO - 2021-04-26 05:46:37 --> Language Class Initialized
INFO - 2021-04-26 05:46:37 --> Config Class Initialized
INFO - 2021-04-26 05:46:37 --> Loader Class Initialized
INFO - 2021-04-26 05:46:37 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:37 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:37 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:37 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:37 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:37 --> Controller Class Initialized
INFO - 2021-04-26 05:46:44 --> Config Class Initialized
INFO - 2021-04-26 05:46:44 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:44 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:44 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:44 --> URI Class Initialized
INFO - 2021-04-26 05:46:44 --> Router Class Initialized
INFO - 2021-04-26 05:46:44 --> Output Class Initialized
INFO - 2021-04-26 05:46:44 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:44 --> Input Class Initialized
INFO - 2021-04-26 05:46:44 --> Language Class Initialized
INFO - 2021-04-26 05:46:44 --> Language Class Initialized
INFO - 2021-04-26 05:46:44 --> Config Class Initialized
INFO - 2021-04-26 05:46:44 --> Loader Class Initialized
INFO - 2021-04-26 05:46:44 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:44 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:44 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:44 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:44 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:44 --> Controller Class Initialized
DEBUG - 2021-04-26 05:46:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-26 05:46:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:46:44 --> Final output sent to browser
DEBUG - 2021-04-26 05:46:44 --> Total execution time: 0.0753
INFO - 2021-04-26 05:46:44 --> Config Class Initialized
INFO - 2021-04-26 05:46:44 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:44 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:44 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:44 --> URI Class Initialized
INFO - 2021-04-26 05:46:44 --> Router Class Initialized
INFO - 2021-04-26 05:46:44 --> Output Class Initialized
INFO - 2021-04-26 05:46:44 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:44 --> Input Class Initialized
INFO - 2021-04-26 05:46:44 --> Language Class Initialized
INFO - 2021-04-26 05:46:44 --> Language Class Initialized
INFO - 2021-04-26 05:46:44 --> Config Class Initialized
INFO - 2021-04-26 05:46:44 --> Loader Class Initialized
INFO - 2021-04-26 05:46:44 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:44 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:44 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:44 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:44 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:44 --> Controller Class Initialized
INFO - 2021-04-26 05:46:46 --> Config Class Initialized
INFO - 2021-04-26 05:46:46 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:46 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:46 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:46 --> URI Class Initialized
INFO - 2021-04-26 05:46:46 --> Router Class Initialized
INFO - 2021-04-26 05:46:46 --> Output Class Initialized
INFO - 2021-04-26 05:46:46 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:46 --> Input Class Initialized
INFO - 2021-04-26 05:46:46 --> Language Class Initialized
INFO - 2021-04-26 05:46:46 --> Language Class Initialized
INFO - 2021-04-26 05:46:46 --> Config Class Initialized
INFO - 2021-04-26 05:46:46 --> Loader Class Initialized
INFO - 2021-04-26 05:46:46 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:46 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:46 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:46 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:46 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:46 --> Controller Class Initialized
ERROR - 2021-04-26 05:46:46 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_walikelas`, CONSTRAINT `FK_t_walikelas_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '6'
INFO - 2021-04-26 05:46:46 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-26 05:46:49 --> Config Class Initialized
INFO - 2021-04-26 05:46:49 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:49 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:49 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:49 --> URI Class Initialized
INFO - 2021-04-26 05:46:49 --> Router Class Initialized
INFO - 2021-04-26 05:46:49 --> Output Class Initialized
INFO - 2021-04-26 05:46:49 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:49 --> Input Class Initialized
INFO - 2021-04-26 05:46:49 --> Language Class Initialized
INFO - 2021-04-26 05:46:49 --> Language Class Initialized
INFO - 2021-04-26 05:46:49 --> Config Class Initialized
INFO - 2021-04-26 05:46:49 --> Loader Class Initialized
INFO - 2021-04-26 05:46:49 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:49 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:49 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:49 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:49 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:49 --> Controller Class Initialized
ERROR - 2021-04-26 05:46:49 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_walikelas`, CONSTRAINT `FK_t_walikelas_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '7'
INFO - 2021-04-26 05:46:49 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-26 05:46:50 --> Config Class Initialized
INFO - 2021-04-26 05:46:50 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:50 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:50 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:50 --> URI Class Initialized
INFO - 2021-04-26 05:46:50 --> Router Class Initialized
INFO - 2021-04-26 05:46:50 --> Output Class Initialized
INFO - 2021-04-26 05:46:50 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:50 --> Input Class Initialized
INFO - 2021-04-26 05:46:50 --> Language Class Initialized
INFO - 2021-04-26 05:46:50 --> Language Class Initialized
INFO - 2021-04-26 05:46:50 --> Config Class Initialized
INFO - 2021-04-26 05:46:50 --> Loader Class Initialized
INFO - 2021-04-26 05:46:50 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:50 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:50 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:50 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:50 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:50 --> Controller Class Initialized
INFO - 2021-04-26 05:46:50 --> Final output sent to browser
DEBUG - 2021-04-26 05:46:50 --> Total execution time: 0.0835
INFO - 2021-04-26 05:46:55 --> Config Class Initialized
INFO - 2021-04-26 05:46:55 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:55 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:55 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:55 --> URI Class Initialized
INFO - 2021-04-26 05:46:55 --> Router Class Initialized
INFO - 2021-04-26 05:46:55 --> Output Class Initialized
INFO - 2021-04-26 05:46:55 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:55 --> Input Class Initialized
INFO - 2021-04-26 05:46:55 --> Language Class Initialized
INFO - 2021-04-26 05:46:55 --> Language Class Initialized
INFO - 2021-04-26 05:46:55 --> Config Class Initialized
INFO - 2021-04-26 05:46:55 --> Loader Class Initialized
INFO - 2021-04-26 05:46:55 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:55 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:55 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:55 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:55 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:55 --> Controller Class Initialized
INFO - 2021-04-26 05:46:55 --> Final output sent to browser
DEBUG - 2021-04-26 05:46:55 --> Total execution time: 0.0737
INFO - 2021-04-26 05:46:55 --> Config Class Initialized
INFO - 2021-04-26 05:46:55 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:55 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:55 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:55 --> URI Class Initialized
INFO - 2021-04-26 05:46:55 --> Router Class Initialized
INFO - 2021-04-26 05:46:55 --> Output Class Initialized
INFO - 2021-04-26 05:46:55 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:55 --> Input Class Initialized
INFO - 2021-04-26 05:46:55 --> Language Class Initialized
INFO - 2021-04-26 05:46:55 --> Language Class Initialized
INFO - 2021-04-26 05:46:55 --> Config Class Initialized
INFO - 2021-04-26 05:46:55 --> Loader Class Initialized
INFO - 2021-04-26 05:46:55 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:55 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:55 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:55 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:55 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:55 --> Controller Class Initialized
INFO - 2021-04-26 05:46:58 --> Config Class Initialized
INFO - 2021-04-26 05:46:58 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:58 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:58 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:58 --> URI Class Initialized
INFO - 2021-04-26 05:46:58 --> Router Class Initialized
INFO - 2021-04-26 05:46:58 --> Output Class Initialized
INFO - 2021-04-26 05:46:58 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:58 --> Input Class Initialized
INFO - 2021-04-26 05:46:58 --> Language Class Initialized
INFO - 2021-04-26 05:46:58 --> Language Class Initialized
INFO - 2021-04-26 05:46:58 --> Config Class Initialized
INFO - 2021-04-26 05:46:58 --> Loader Class Initialized
INFO - 2021-04-26 05:46:58 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:58 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:58 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:58 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:58 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:58 --> Controller Class Initialized
INFO - 2021-04-26 05:46:58 --> Final output sent to browser
DEBUG - 2021-04-26 05:46:58 --> Total execution time: 0.0853
INFO - 2021-04-26 05:46:58 --> Config Class Initialized
INFO - 2021-04-26 05:46:58 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:46:58 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:46:58 --> Utf8 Class Initialized
INFO - 2021-04-26 05:46:58 --> URI Class Initialized
INFO - 2021-04-26 05:46:58 --> Router Class Initialized
INFO - 2021-04-26 05:46:58 --> Output Class Initialized
INFO - 2021-04-26 05:46:58 --> Security Class Initialized
DEBUG - 2021-04-26 05:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:46:58 --> Input Class Initialized
INFO - 2021-04-26 05:46:58 --> Language Class Initialized
INFO - 2021-04-26 05:46:58 --> Language Class Initialized
INFO - 2021-04-26 05:46:58 --> Config Class Initialized
INFO - 2021-04-26 05:46:58 --> Loader Class Initialized
INFO - 2021-04-26 05:46:58 --> Helper loaded: url_helper
INFO - 2021-04-26 05:46:58 --> Helper loaded: file_helper
INFO - 2021-04-26 05:46:58 --> Helper loaded: form_helper
INFO - 2021-04-26 05:46:58 --> Helper loaded: my_helper
INFO - 2021-04-26 05:46:58 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:46:58 --> Controller Class Initialized
INFO - 2021-04-26 05:47:01 --> Config Class Initialized
INFO - 2021-04-26 05:47:01 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:01 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:01 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:01 --> URI Class Initialized
INFO - 2021-04-26 05:47:01 --> Router Class Initialized
INFO - 2021-04-26 05:47:01 --> Output Class Initialized
INFO - 2021-04-26 05:47:01 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:01 --> Input Class Initialized
INFO - 2021-04-26 05:47:01 --> Language Class Initialized
INFO - 2021-04-26 05:47:01 --> Language Class Initialized
INFO - 2021-04-26 05:47:01 --> Config Class Initialized
INFO - 2021-04-26 05:47:01 --> Loader Class Initialized
INFO - 2021-04-26 05:47:01 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:01 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:01 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:01 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:01 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:01 --> Controller Class Initialized
ERROR - 2021-04-26 05:47:01 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_walikelas`, CONSTRAINT `FK_t_walikelas_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '7'
INFO - 2021-04-26 05:47:01 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-26 05:47:31 --> Config Class Initialized
INFO - 2021-04-26 05:47:31 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:31 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:31 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:31 --> URI Class Initialized
INFO - 2021-04-26 05:47:31 --> Router Class Initialized
INFO - 2021-04-26 05:47:31 --> Output Class Initialized
INFO - 2021-04-26 05:47:31 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:31 --> Input Class Initialized
INFO - 2021-04-26 05:47:31 --> Language Class Initialized
INFO - 2021-04-26 05:47:31 --> Language Class Initialized
INFO - 2021-04-26 05:47:31 --> Config Class Initialized
INFO - 2021-04-26 05:47:31 --> Loader Class Initialized
INFO - 2021-04-26 05:47:31 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:31 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:31 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:31 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:31 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:31 --> Controller Class Initialized
DEBUG - 2021-04-26 05:47:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-26 05:47:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:47:32 --> Final output sent to browser
DEBUG - 2021-04-26 05:47:32 --> Total execution time: 0.0888
INFO - 2021-04-26 05:47:32 --> Config Class Initialized
INFO - 2021-04-26 05:47:32 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:32 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:32 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:32 --> URI Class Initialized
INFO - 2021-04-26 05:47:32 --> Router Class Initialized
INFO - 2021-04-26 05:47:32 --> Output Class Initialized
INFO - 2021-04-26 05:47:32 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:32 --> Input Class Initialized
INFO - 2021-04-26 05:47:32 --> Language Class Initialized
INFO - 2021-04-26 05:47:32 --> Language Class Initialized
INFO - 2021-04-26 05:47:32 --> Config Class Initialized
INFO - 2021-04-26 05:47:32 --> Loader Class Initialized
INFO - 2021-04-26 05:47:32 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:32 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:32 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:32 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:32 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:32 --> Controller Class Initialized
INFO - 2021-04-26 05:47:37 --> Config Class Initialized
INFO - 2021-04-26 05:47:37 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:37 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:37 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:37 --> URI Class Initialized
INFO - 2021-04-26 05:47:37 --> Router Class Initialized
INFO - 2021-04-26 05:47:37 --> Output Class Initialized
INFO - 2021-04-26 05:47:37 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:37 --> Input Class Initialized
INFO - 2021-04-26 05:47:37 --> Language Class Initialized
INFO - 2021-04-26 05:47:37 --> Language Class Initialized
INFO - 2021-04-26 05:47:37 --> Config Class Initialized
INFO - 2021-04-26 05:47:37 --> Loader Class Initialized
INFO - 2021-04-26 05:47:37 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:37 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:37 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:37 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:37 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:37 --> Controller Class Initialized
INFO - 2021-04-26 05:47:37 --> Final output sent to browser
DEBUG - 2021-04-26 05:47:37 --> Total execution time: 0.0837
INFO - 2021-04-26 05:47:37 --> Config Class Initialized
INFO - 2021-04-26 05:47:37 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:37 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:37 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:37 --> URI Class Initialized
INFO - 2021-04-26 05:47:37 --> Router Class Initialized
INFO - 2021-04-26 05:47:37 --> Output Class Initialized
INFO - 2021-04-26 05:47:37 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:37 --> Input Class Initialized
INFO - 2021-04-26 05:47:37 --> Language Class Initialized
INFO - 2021-04-26 05:47:37 --> Language Class Initialized
INFO - 2021-04-26 05:47:37 --> Config Class Initialized
INFO - 2021-04-26 05:47:37 --> Loader Class Initialized
INFO - 2021-04-26 05:47:37 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:37 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:37 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:37 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:37 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:37 --> Controller Class Initialized
INFO - 2021-04-26 05:47:39 --> Config Class Initialized
INFO - 2021-04-26 05:47:39 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:39 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:39 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:39 --> URI Class Initialized
INFO - 2021-04-26 05:47:39 --> Router Class Initialized
INFO - 2021-04-26 05:47:39 --> Output Class Initialized
INFO - 2021-04-26 05:47:39 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:39 --> Input Class Initialized
INFO - 2021-04-26 05:47:39 --> Language Class Initialized
INFO - 2021-04-26 05:47:39 --> Language Class Initialized
INFO - 2021-04-26 05:47:39 --> Config Class Initialized
INFO - 2021-04-26 05:47:39 --> Loader Class Initialized
INFO - 2021-04-26 05:47:39 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:39 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:39 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:39 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:39 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:39 --> Controller Class Initialized
DEBUG - 2021-04-26 05:47:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-26 05:47:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:47:39 --> Final output sent to browser
DEBUG - 2021-04-26 05:47:39 --> Total execution time: 0.0634
INFO - 2021-04-26 05:47:39 --> Config Class Initialized
INFO - 2021-04-26 05:47:39 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:39 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:39 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:39 --> URI Class Initialized
INFO - 2021-04-26 05:47:39 --> Router Class Initialized
INFO - 2021-04-26 05:47:39 --> Output Class Initialized
INFO - 2021-04-26 05:47:39 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:39 --> Input Class Initialized
INFO - 2021-04-26 05:47:39 --> Language Class Initialized
INFO - 2021-04-26 05:47:39 --> Language Class Initialized
INFO - 2021-04-26 05:47:39 --> Config Class Initialized
INFO - 2021-04-26 05:47:39 --> Loader Class Initialized
INFO - 2021-04-26 05:47:39 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:39 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:39 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:39 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:39 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:39 --> Controller Class Initialized
INFO - 2021-04-26 05:47:42 --> Config Class Initialized
INFO - 2021-04-26 05:47:42 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:42 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:42 --> URI Class Initialized
INFO - 2021-04-26 05:47:42 --> Router Class Initialized
INFO - 2021-04-26 05:47:42 --> Output Class Initialized
INFO - 2021-04-26 05:47:42 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:42 --> Input Class Initialized
INFO - 2021-04-26 05:47:42 --> Language Class Initialized
INFO - 2021-04-26 05:47:42 --> Language Class Initialized
INFO - 2021-04-26 05:47:42 --> Config Class Initialized
INFO - 2021-04-26 05:47:42 --> Loader Class Initialized
INFO - 2021-04-26 05:47:42 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:42 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:42 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:42 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:42 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:42 --> Controller Class Initialized
ERROR - 2021-04-26 05:47:42 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_walikelas`, CONSTRAINT `FK_t_walikelas_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '7'
INFO - 2021-04-26 05:47:42 --> Language file loaded: language/english/db_lang.php
INFO - 2021-04-26 05:47:44 --> Config Class Initialized
INFO - 2021-04-26 05:47:44 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:44 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:44 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:44 --> URI Class Initialized
INFO - 2021-04-26 05:47:44 --> Router Class Initialized
INFO - 2021-04-26 05:47:44 --> Output Class Initialized
INFO - 2021-04-26 05:47:44 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:44 --> Input Class Initialized
INFO - 2021-04-26 05:47:44 --> Language Class Initialized
INFO - 2021-04-26 05:47:44 --> Language Class Initialized
INFO - 2021-04-26 05:47:44 --> Config Class Initialized
INFO - 2021-04-26 05:47:44 --> Loader Class Initialized
INFO - 2021-04-26 05:47:44 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:44 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:44 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:44 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:44 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:44 --> Controller Class Initialized
INFO - 2021-04-26 05:47:44 --> Final output sent to browser
DEBUG - 2021-04-26 05:47:44 --> Total execution time: 0.0872
INFO - 2021-04-26 05:47:44 --> Config Class Initialized
INFO - 2021-04-26 05:47:44 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:44 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:44 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:44 --> URI Class Initialized
INFO - 2021-04-26 05:47:44 --> Router Class Initialized
INFO - 2021-04-26 05:47:44 --> Output Class Initialized
INFO - 2021-04-26 05:47:44 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:44 --> Input Class Initialized
INFO - 2021-04-26 05:47:44 --> Language Class Initialized
INFO - 2021-04-26 05:47:44 --> Language Class Initialized
INFO - 2021-04-26 05:47:44 --> Config Class Initialized
INFO - 2021-04-26 05:47:44 --> Loader Class Initialized
INFO - 2021-04-26 05:47:44 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:44 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:44 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:44 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:44 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:44 --> Controller Class Initialized
INFO - 2021-04-26 05:47:46 --> Config Class Initialized
INFO - 2021-04-26 05:47:46 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:46 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:46 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:46 --> URI Class Initialized
INFO - 2021-04-26 05:47:46 --> Router Class Initialized
INFO - 2021-04-26 05:47:46 --> Output Class Initialized
INFO - 2021-04-26 05:47:46 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:46 --> Input Class Initialized
INFO - 2021-04-26 05:47:46 --> Language Class Initialized
INFO - 2021-04-26 05:47:46 --> Language Class Initialized
INFO - 2021-04-26 05:47:46 --> Config Class Initialized
INFO - 2021-04-26 05:47:46 --> Loader Class Initialized
INFO - 2021-04-26 05:47:46 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:46 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:46 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:46 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:46 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:46 --> Controller Class Initialized
DEBUG - 2021-04-26 05:47:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-26 05:47:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:47:46 --> Final output sent to browser
DEBUG - 2021-04-26 05:47:46 --> Total execution time: 0.0790
INFO - 2021-04-26 05:47:46 --> Config Class Initialized
INFO - 2021-04-26 05:47:46 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:46 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:46 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:46 --> URI Class Initialized
INFO - 2021-04-26 05:47:46 --> Router Class Initialized
INFO - 2021-04-26 05:47:46 --> Output Class Initialized
INFO - 2021-04-26 05:47:46 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:46 --> Input Class Initialized
INFO - 2021-04-26 05:47:46 --> Language Class Initialized
INFO - 2021-04-26 05:47:46 --> Language Class Initialized
INFO - 2021-04-26 05:47:46 --> Config Class Initialized
INFO - 2021-04-26 05:47:46 --> Loader Class Initialized
INFO - 2021-04-26 05:47:46 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:46 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:46 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:46 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:46 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:46 --> Controller Class Initialized
INFO - 2021-04-26 05:47:49 --> Config Class Initialized
INFO - 2021-04-26 05:47:49 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:49 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:49 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:49 --> URI Class Initialized
INFO - 2021-04-26 05:47:49 --> Router Class Initialized
INFO - 2021-04-26 05:47:49 --> Output Class Initialized
INFO - 2021-04-26 05:47:49 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:49 --> Input Class Initialized
INFO - 2021-04-26 05:47:49 --> Language Class Initialized
INFO - 2021-04-26 05:47:49 --> Language Class Initialized
INFO - 2021-04-26 05:47:49 --> Config Class Initialized
INFO - 2021-04-26 05:47:49 --> Loader Class Initialized
INFO - 2021-04-26 05:47:49 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:49 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:49 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:49 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:49 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:49 --> Controller Class Initialized
INFO - 2021-04-26 05:47:49 --> Final output sent to browser
DEBUG - 2021-04-26 05:47:49 --> Total execution time: 0.0932
INFO - 2021-04-26 05:47:49 --> Config Class Initialized
INFO - 2021-04-26 05:47:49 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:49 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:49 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:49 --> URI Class Initialized
INFO - 2021-04-26 05:47:49 --> Router Class Initialized
INFO - 2021-04-26 05:47:49 --> Output Class Initialized
INFO - 2021-04-26 05:47:49 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:49 --> Input Class Initialized
INFO - 2021-04-26 05:47:49 --> Language Class Initialized
INFO - 2021-04-26 05:47:49 --> Language Class Initialized
INFO - 2021-04-26 05:47:49 --> Config Class Initialized
INFO - 2021-04-26 05:47:49 --> Loader Class Initialized
INFO - 2021-04-26 05:47:49 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:49 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:49 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:49 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:49 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:49 --> Controller Class Initialized
INFO - 2021-04-26 05:47:50 --> Config Class Initialized
INFO - 2021-04-26 05:47:50 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:50 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:50 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:50 --> URI Class Initialized
INFO - 2021-04-26 05:47:50 --> Router Class Initialized
INFO - 2021-04-26 05:47:50 --> Output Class Initialized
INFO - 2021-04-26 05:47:50 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:50 --> Input Class Initialized
INFO - 2021-04-26 05:47:50 --> Language Class Initialized
INFO - 2021-04-26 05:47:50 --> Language Class Initialized
INFO - 2021-04-26 05:47:50 --> Config Class Initialized
INFO - 2021-04-26 05:47:50 --> Loader Class Initialized
INFO - 2021-04-26 05:47:50 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:50 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:50 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:50 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:50 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:50 --> Controller Class Initialized
DEBUG - 2021-04-26 05:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-26 05:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:47:50 --> Final output sent to browser
DEBUG - 2021-04-26 05:47:50 --> Total execution time: 0.0759
INFO - 2021-04-26 05:47:51 --> Config Class Initialized
INFO - 2021-04-26 05:47:51 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:51 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:51 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:51 --> URI Class Initialized
INFO - 2021-04-26 05:47:51 --> Router Class Initialized
INFO - 2021-04-26 05:47:51 --> Output Class Initialized
INFO - 2021-04-26 05:47:51 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:51 --> Input Class Initialized
INFO - 2021-04-26 05:47:51 --> Language Class Initialized
INFO - 2021-04-26 05:47:51 --> Language Class Initialized
INFO - 2021-04-26 05:47:51 --> Config Class Initialized
INFO - 2021-04-26 05:47:51 --> Loader Class Initialized
INFO - 2021-04-26 05:47:51 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:51 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:51 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:51 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:51 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:51 --> Controller Class Initialized
INFO - 2021-04-26 05:47:53 --> Config Class Initialized
INFO - 2021-04-26 05:47:53 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:53 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:53 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:53 --> URI Class Initialized
INFO - 2021-04-26 05:47:53 --> Router Class Initialized
INFO - 2021-04-26 05:47:53 --> Output Class Initialized
INFO - 2021-04-26 05:47:53 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:53 --> Input Class Initialized
INFO - 2021-04-26 05:47:53 --> Language Class Initialized
INFO - 2021-04-26 05:47:54 --> Language Class Initialized
INFO - 2021-04-26 05:47:54 --> Config Class Initialized
INFO - 2021-04-26 05:47:54 --> Loader Class Initialized
INFO - 2021-04-26 05:47:54 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:54 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:54 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:54 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:54 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:54 --> Controller Class Initialized
INFO - 2021-04-26 05:47:54 --> Final output sent to browser
DEBUG - 2021-04-26 05:47:54 --> Total execution time: 0.0976
INFO - 2021-04-26 05:47:54 --> Config Class Initialized
INFO - 2021-04-26 05:47:54 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:54 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:54 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:54 --> URI Class Initialized
INFO - 2021-04-26 05:47:54 --> Router Class Initialized
INFO - 2021-04-26 05:47:54 --> Output Class Initialized
INFO - 2021-04-26 05:47:54 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:54 --> Input Class Initialized
INFO - 2021-04-26 05:47:54 --> Language Class Initialized
INFO - 2021-04-26 05:47:54 --> Language Class Initialized
INFO - 2021-04-26 05:47:54 --> Config Class Initialized
INFO - 2021-04-26 05:47:54 --> Loader Class Initialized
INFO - 2021-04-26 05:47:54 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:54 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:54 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:54 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:54 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:54 --> Controller Class Initialized
INFO - 2021-04-26 05:47:54 --> Config Class Initialized
INFO - 2021-04-26 05:47:54 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:47:54 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:47:54 --> Utf8 Class Initialized
INFO - 2021-04-26 05:47:54 --> URI Class Initialized
INFO - 2021-04-26 05:47:54 --> Router Class Initialized
INFO - 2021-04-26 05:47:54 --> Output Class Initialized
INFO - 2021-04-26 05:47:54 --> Security Class Initialized
DEBUG - 2021-04-26 05:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:47:54 --> Input Class Initialized
INFO - 2021-04-26 05:47:54 --> Language Class Initialized
INFO - 2021-04-26 05:47:54 --> Language Class Initialized
INFO - 2021-04-26 05:47:54 --> Config Class Initialized
INFO - 2021-04-26 05:47:54 --> Loader Class Initialized
INFO - 2021-04-26 05:47:54 --> Helper loaded: url_helper
INFO - 2021-04-26 05:47:54 --> Helper loaded: file_helper
INFO - 2021-04-26 05:47:54 --> Helper loaded: form_helper
INFO - 2021-04-26 05:47:54 --> Helper loaded: my_helper
INFO - 2021-04-26 05:47:54 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:47:54 --> Controller Class Initialized
INFO - 2021-04-26 05:47:54 --> Final output sent to browser
DEBUG - 2021-04-26 05:47:54 --> Total execution time: 0.0849
INFO - 2021-04-26 05:48:00 --> Config Class Initialized
INFO - 2021-04-26 05:48:00 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:48:00 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:48:00 --> Utf8 Class Initialized
INFO - 2021-04-26 05:48:00 --> URI Class Initialized
INFO - 2021-04-26 05:48:00 --> Router Class Initialized
INFO - 2021-04-26 05:48:00 --> Output Class Initialized
INFO - 2021-04-26 05:48:00 --> Security Class Initialized
DEBUG - 2021-04-26 05:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:48:00 --> Input Class Initialized
INFO - 2021-04-26 05:48:00 --> Language Class Initialized
INFO - 2021-04-26 05:48:00 --> Language Class Initialized
INFO - 2021-04-26 05:48:00 --> Config Class Initialized
INFO - 2021-04-26 05:48:00 --> Loader Class Initialized
INFO - 2021-04-26 05:48:00 --> Helper loaded: url_helper
INFO - 2021-04-26 05:48:00 --> Helper loaded: file_helper
INFO - 2021-04-26 05:48:00 --> Helper loaded: form_helper
INFO - 2021-04-26 05:48:00 --> Helper loaded: my_helper
INFO - 2021-04-26 05:48:00 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:48:00 --> Controller Class Initialized
INFO - 2021-04-26 05:48:00 --> Final output sent to browser
DEBUG - 2021-04-26 05:48:00 --> Total execution time: 0.0593
INFO - 2021-04-26 05:48:00 --> Config Class Initialized
INFO - 2021-04-26 05:48:00 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:48:00 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:48:00 --> Utf8 Class Initialized
INFO - 2021-04-26 05:48:00 --> URI Class Initialized
INFO - 2021-04-26 05:48:00 --> Router Class Initialized
INFO - 2021-04-26 05:48:00 --> Output Class Initialized
INFO - 2021-04-26 05:48:00 --> Security Class Initialized
DEBUG - 2021-04-26 05:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:48:00 --> Input Class Initialized
INFO - 2021-04-26 05:48:00 --> Language Class Initialized
INFO - 2021-04-26 05:48:00 --> Language Class Initialized
INFO - 2021-04-26 05:48:00 --> Config Class Initialized
INFO - 2021-04-26 05:48:00 --> Loader Class Initialized
INFO - 2021-04-26 05:48:00 --> Helper loaded: url_helper
INFO - 2021-04-26 05:48:00 --> Helper loaded: file_helper
INFO - 2021-04-26 05:48:00 --> Helper loaded: form_helper
INFO - 2021-04-26 05:48:00 --> Helper loaded: my_helper
INFO - 2021-04-26 05:48:00 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:48:00 --> Controller Class Initialized
INFO - 2021-04-26 05:48:01 --> Config Class Initialized
INFO - 2021-04-26 05:48:01 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:48:02 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:48:02 --> Utf8 Class Initialized
INFO - 2021-04-26 05:48:02 --> URI Class Initialized
INFO - 2021-04-26 05:48:02 --> Router Class Initialized
INFO - 2021-04-26 05:48:02 --> Output Class Initialized
INFO - 2021-04-26 05:48:02 --> Security Class Initialized
DEBUG - 2021-04-26 05:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:48:02 --> Input Class Initialized
INFO - 2021-04-26 05:48:02 --> Language Class Initialized
INFO - 2021-04-26 05:48:02 --> Language Class Initialized
INFO - 2021-04-26 05:48:02 --> Config Class Initialized
INFO - 2021-04-26 05:48:02 --> Loader Class Initialized
INFO - 2021-04-26 05:48:02 --> Helper loaded: url_helper
INFO - 2021-04-26 05:48:02 --> Helper loaded: file_helper
INFO - 2021-04-26 05:48:02 --> Helper loaded: form_helper
INFO - 2021-04-26 05:48:02 --> Helper loaded: my_helper
INFO - 2021-04-26 05:48:02 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:48:02 --> Controller Class Initialized
DEBUG - 2021-04-26 05:48:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-26 05:48:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:48:02 --> Final output sent to browser
DEBUG - 2021-04-26 05:48:02 --> Total execution time: 0.0824
INFO - 2021-04-26 05:48:03 --> Config Class Initialized
INFO - 2021-04-26 05:48:03 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:48:03 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:48:03 --> Utf8 Class Initialized
INFO - 2021-04-26 05:48:03 --> URI Class Initialized
INFO - 2021-04-26 05:48:03 --> Router Class Initialized
INFO - 2021-04-26 05:48:03 --> Output Class Initialized
INFO - 2021-04-26 05:48:03 --> Security Class Initialized
DEBUG - 2021-04-26 05:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:48:03 --> Input Class Initialized
INFO - 2021-04-26 05:48:03 --> Language Class Initialized
INFO - 2021-04-26 05:48:03 --> Language Class Initialized
INFO - 2021-04-26 05:48:03 --> Config Class Initialized
INFO - 2021-04-26 05:48:03 --> Loader Class Initialized
INFO - 2021-04-26 05:48:03 --> Helper loaded: url_helper
INFO - 2021-04-26 05:48:03 --> Helper loaded: file_helper
INFO - 2021-04-26 05:48:03 --> Helper loaded: form_helper
INFO - 2021-04-26 05:48:03 --> Helper loaded: my_helper
INFO - 2021-04-26 05:48:03 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:48:03 --> Controller Class Initialized
DEBUG - 2021-04-26 05:48:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-26 05:48:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:48:03 --> Final output sent to browser
DEBUG - 2021-04-26 05:48:03 --> Total execution time: 0.0907
INFO - 2021-04-26 05:48:15 --> Config Class Initialized
INFO - 2021-04-26 05:48:15 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:48:15 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:48:15 --> Utf8 Class Initialized
INFO - 2021-04-26 05:48:15 --> URI Class Initialized
INFO - 2021-04-26 05:48:15 --> Router Class Initialized
INFO - 2021-04-26 05:48:15 --> Output Class Initialized
INFO - 2021-04-26 05:48:15 --> Security Class Initialized
DEBUG - 2021-04-26 05:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:48:15 --> Input Class Initialized
INFO - 2021-04-26 05:48:15 --> Language Class Initialized
INFO - 2021-04-26 05:48:15 --> Language Class Initialized
INFO - 2021-04-26 05:48:15 --> Config Class Initialized
INFO - 2021-04-26 05:48:15 --> Loader Class Initialized
INFO - 2021-04-26 05:48:15 --> Helper loaded: url_helper
INFO - 2021-04-26 05:48:15 --> Helper loaded: file_helper
INFO - 2021-04-26 05:48:15 --> Helper loaded: form_helper
INFO - 2021-04-26 05:48:15 --> Helper loaded: my_helper
INFO - 2021-04-26 05:48:15 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:48:15 --> Controller Class Initialized
INFO - 2021-04-26 05:48:15 --> Config Class Initialized
INFO - 2021-04-26 05:48:15 --> Hooks Class Initialized
DEBUG - 2021-04-26 05:48:15 --> UTF-8 Support Enabled
INFO - 2021-04-26 05:48:15 --> Utf8 Class Initialized
INFO - 2021-04-26 05:48:15 --> URI Class Initialized
INFO - 2021-04-26 05:48:15 --> Router Class Initialized
INFO - 2021-04-26 05:48:15 --> Output Class Initialized
INFO - 2021-04-26 05:48:15 --> Security Class Initialized
DEBUG - 2021-04-26 05:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-26 05:48:15 --> Input Class Initialized
INFO - 2021-04-26 05:48:15 --> Language Class Initialized
INFO - 2021-04-26 05:48:15 --> Language Class Initialized
INFO - 2021-04-26 05:48:15 --> Config Class Initialized
INFO - 2021-04-26 05:48:15 --> Loader Class Initialized
INFO - 2021-04-26 05:48:15 --> Helper loaded: url_helper
INFO - 2021-04-26 05:48:15 --> Helper loaded: file_helper
INFO - 2021-04-26 05:48:15 --> Helper loaded: form_helper
INFO - 2021-04-26 05:48:15 --> Helper loaded: my_helper
INFO - 2021-04-26 05:48:15 --> Database Driver Class Initialized
DEBUG - 2021-04-26 05:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-26 05:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-26 05:48:15 --> Controller Class Initialized
DEBUG - 2021-04-26 05:48:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-26 05:48:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-26 05:48:15 --> Final output sent to browser
DEBUG - 2021-04-26 05:48:15 --> Total execution time: 0.0634
