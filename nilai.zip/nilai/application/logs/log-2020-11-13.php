<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-13 02:03:25 --> Config Class Initialized
INFO - 2020-11-13 02:03:25 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:03:26 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:03:26 --> Utf8 Class Initialized
INFO - 2020-11-13 02:03:26 --> URI Class Initialized
DEBUG - 2020-11-13 02:03:26 --> No URI present. Default controller set.
INFO - 2020-11-13 02:03:26 --> Router Class Initialized
INFO - 2020-11-13 02:03:26 --> Output Class Initialized
INFO - 2020-11-13 02:03:26 --> Security Class Initialized
DEBUG - 2020-11-13 02:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:03:26 --> Input Class Initialized
INFO - 2020-11-13 02:03:26 --> Language Class Initialized
INFO - 2020-11-13 02:03:26 --> Language Class Initialized
INFO - 2020-11-13 02:03:26 --> Config Class Initialized
INFO - 2020-11-13 02:03:26 --> Loader Class Initialized
INFO - 2020-11-13 02:03:26 --> Helper loaded: url_helper
INFO - 2020-11-13 02:03:26 --> Helper loaded: file_helper
INFO - 2020-11-13 02:03:26 --> Helper loaded: form_helper
INFO - 2020-11-13 02:03:26 --> Helper loaded: my_helper
INFO - 2020-11-13 02:03:26 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:03:26 --> Controller Class Initialized
INFO - 2020-11-13 02:03:26 --> Config Class Initialized
INFO - 2020-11-13 02:03:26 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:03:26 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:03:26 --> Utf8 Class Initialized
INFO - 2020-11-13 02:03:26 --> URI Class Initialized
INFO - 2020-11-13 02:03:26 --> Router Class Initialized
INFO - 2020-11-13 02:03:26 --> Output Class Initialized
INFO - 2020-11-13 02:03:26 --> Security Class Initialized
DEBUG - 2020-11-13 02:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:03:26 --> Input Class Initialized
INFO - 2020-11-13 02:03:26 --> Language Class Initialized
INFO - 2020-11-13 02:03:26 --> Language Class Initialized
INFO - 2020-11-13 02:03:26 --> Config Class Initialized
INFO - 2020-11-13 02:03:26 --> Loader Class Initialized
INFO - 2020-11-13 02:03:26 --> Helper loaded: url_helper
INFO - 2020-11-13 02:03:26 --> Helper loaded: file_helper
INFO - 2020-11-13 02:03:26 --> Helper loaded: form_helper
INFO - 2020-11-13 02:03:26 --> Helper loaded: my_helper
INFO - 2020-11-13 02:03:26 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:03:26 --> Controller Class Initialized
DEBUG - 2020-11-13 02:03:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-13 02:03:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:03:27 --> Final output sent to browser
DEBUG - 2020-11-13 02:03:27 --> Total execution time: 0.2601
INFO - 2020-11-13 02:43:29 --> Config Class Initialized
INFO - 2020-11-13 02:43:29 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:43:29 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:43:29 --> Utf8 Class Initialized
INFO - 2020-11-13 02:43:29 --> URI Class Initialized
INFO - 2020-11-13 02:43:29 --> Router Class Initialized
INFO - 2020-11-13 02:43:29 --> Output Class Initialized
INFO - 2020-11-13 02:43:29 --> Security Class Initialized
DEBUG - 2020-11-13 02:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:43:29 --> Input Class Initialized
INFO - 2020-11-13 02:43:29 --> Language Class Initialized
INFO - 2020-11-13 02:43:29 --> Language Class Initialized
INFO - 2020-11-13 02:43:29 --> Config Class Initialized
INFO - 2020-11-13 02:43:29 --> Loader Class Initialized
INFO - 2020-11-13 02:43:29 --> Helper loaded: url_helper
INFO - 2020-11-13 02:43:29 --> Helper loaded: file_helper
INFO - 2020-11-13 02:43:29 --> Helper loaded: form_helper
INFO - 2020-11-13 02:43:29 --> Helper loaded: my_helper
INFO - 2020-11-13 02:43:29 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:43:29 --> Controller Class Initialized
DEBUG - 2020-11-13 02:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-13 02:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:43:29 --> Final output sent to browser
DEBUG - 2020-11-13 02:43:29 --> Total execution time: 0.2025
INFO - 2020-11-13 02:44:21 --> Config Class Initialized
INFO - 2020-11-13 02:44:21 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:44:21 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:44:21 --> Utf8 Class Initialized
INFO - 2020-11-13 02:44:21 --> URI Class Initialized
INFO - 2020-11-13 02:44:21 --> Router Class Initialized
INFO - 2020-11-13 02:44:21 --> Output Class Initialized
INFO - 2020-11-13 02:44:21 --> Security Class Initialized
DEBUG - 2020-11-13 02:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:44:21 --> Input Class Initialized
INFO - 2020-11-13 02:44:21 --> Language Class Initialized
INFO - 2020-11-13 02:44:21 --> Language Class Initialized
INFO - 2020-11-13 02:44:21 --> Config Class Initialized
INFO - 2020-11-13 02:44:21 --> Loader Class Initialized
INFO - 2020-11-13 02:44:21 --> Helper loaded: url_helper
INFO - 2020-11-13 02:44:21 --> Helper loaded: file_helper
INFO - 2020-11-13 02:44:21 --> Helper loaded: form_helper
INFO - 2020-11-13 02:44:21 --> Helper loaded: my_helper
INFO - 2020-11-13 02:44:21 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:44:21 --> Controller Class Initialized
INFO - 2020-11-13 02:44:21 --> Helper loaded: cookie_helper
INFO - 2020-11-13 02:44:21 --> Final output sent to browser
DEBUG - 2020-11-13 02:44:21 --> Total execution time: 0.3130
INFO - 2020-11-13 02:44:23 --> Config Class Initialized
INFO - 2020-11-13 02:44:23 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:44:23 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:44:23 --> Utf8 Class Initialized
INFO - 2020-11-13 02:44:23 --> URI Class Initialized
INFO - 2020-11-13 02:44:23 --> Router Class Initialized
INFO - 2020-11-13 02:44:23 --> Output Class Initialized
INFO - 2020-11-13 02:44:23 --> Security Class Initialized
DEBUG - 2020-11-13 02:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:44:23 --> Input Class Initialized
INFO - 2020-11-13 02:44:23 --> Language Class Initialized
INFO - 2020-11-13 02:44:23 --> Language Class Initialized
INFO - 2020-11-13 02:44:23 --> Config Class Initialized
INFO - 2020-11-13 02:44:23 --> Loader Class Initialized
INFO - 2020-11-13 02:44:23 --> Helper loaded: url_helper
INFO - 2020-11-13 02:44:23 --> Helper loaded: file_helper
INFO - 2020-11-13 02:44:23 --> Helper loaded: form_helper
INFO - 2020-11-13 02:44:23 --> Helper loaded: my_helper
INFO - 2020-11-13 02:44:23 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:44:23 --> Controller Class Initialized
DEBUG - 2020-11-13 02:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-13 02:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:44:23 --> Final output sent to browser
DEBUG - 2020-11-13 02:44:23 --> Total execution time: 0.3650
INFO - 2020-11-13 02:44:27 --> Config Class Initialized
INFO - 2020-11-13 02:44:27 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:44:27 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:44:27 --> Utf8 Class Initialized
INFO - 2020-11-13 02:44:27 --> URI Class Initialized
INFO - 2020-11-13 02:44:27 --> Router Class Initialized
INFO - 2020-11-13 02:44:27 --> Output Class Initialized
INFO - 2020-11-13 02:44:27 --> Security Class Initialized
DEBUG - 2020-11-13 02:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:44:27 --> Input Class Initialized
INFO - 2020-11-13 02:44:27 --> Language Class Initialized
INFO - 2020-11-13 02:44:27 --> Language Class Initialized
INFO - 2020-11-13 02:44:27 --> Config Class Initialized
INFO - 2020-11-13 02:44:27 --> Loader Class Initialized
INFO - 2020-11-13 02:44:27 --> Helper loaded: url_helper
INFO - 2020-11-13 02:44:27 --> Helper loaded: file_helper
INFO - 2020-11-13 02:44:27 --> Helper loaded: form_helper
INFO - 2020-11-13 02:44:27 --> Helper loaded: my_helper
INFO - 2020-11-13 02:44:27 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:44:27 --> Controller Class Initialized
DEBUG - 2020-11-13 02:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-13 02:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:44:27 --> Final output sent to browser
DEBUG - 2020-11-13 02:44:27 --> Total execution time: 0.2499
INFO - 2020-11-13 02:44:28 --> Config Class Initialized
INFO - 2020-11-13 02:44:28 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:44:28 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:44:28 --> Utf8 Class Initialized
INFO - 2020-11-13 02:44:28 --> URI Class Initialized
INFO - 2020-11-13 02:44:28 --> Router Class Initialized
INFO - 2020-11-13 02:44:28 --> Output Class Initialized
INFO - 2020-11-13 02:44:28 --> Security Class Initialized
DEBUG - 2020-11-13 02:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:44:28 --> Input Class Initialized
INFO - 2020-11-13 02:44:28 --> Language Class Initialized
INFO - 2020-11-13 02:44:28 --> Language Class Initialized
INFO - 2020-11-13 02:44:28 --> Config Class Initialized
INFO - 2020-11-13 02:44:28 --> Loader Class Initialized
INFO - 2020-11-13 02:44:28 --> Helper loaded: url_helper
INFO - 2020-11-13 02:44:28 --> Helper loaded: file_helper
INFO - 2020-11-13 02:44:28 --> Helper loaded: form_helper
INFO - 2020-11-13 02:44:28 --> Helper loaded: my_helper
INFO - 2020-11-13 02:44:28 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:44:28 --> Controller Class Initialized
DEBUG - 2020-11-13 02:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-13 02:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:44:28 --> Final output sent to browser
DEBUG - 2020-11-13 02:44:28 --> Total execution time: 0.2437
INFO - 2020-11-13 02:44:28 --> Config Class Initialized
INFO - 2020-11-13 02:44:28 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:44:28 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:44:28 --> Utf8 Class Initialized
INFO - 2020-11-13 02:44:28 --> URI Class Initialized
INFO - 2020-11-13 02:44:28 --> Router Class Initialized
INFO - 2020-11-13 02:44:28 --> Output Class Initialized
INFO - 2020-11-13 02:44:28 --> Security Class Initialized
DEBUG - 2020-11-13 02:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:44:29 --> Input Class Initialized
INFO - 2020-11-13 02:44:29 --> Language Class Initialized
INFO - 2020-11-13 02:44:29 --> Language Class Initialized
INFO - 2020-11-13 02:44:29 --> Config Class Initialized
INFO - 2020-11-13 02:44:29 --> Loader Class Initialized
INFO - 2020-11-13 02:44:29 --> Helper loaded: url_helper
INFO - 2020-11-13 02:44:29 --> Helper loaded: file_helper
INFO - 2020-11-13 02:44:29 --> Helper loaded: form_helper
INFO - 2020-11-13 02:44:29 --> Helper loaded: my_helper
INFO - 2020-11-13 02:44:29 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:44:29 --> Controller Class Initialized
INFO - 2020-11-13 02:44:30 --> Config Class Initialized
INFO - 2020-11-13 02:44:30 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:44:30 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:44:30 --> Utf8 Class Initialized
INFO - 2020-11-13 02:44:30 --> URI Class Initialized
INFO - 2020-11-13 02:44:30 --> Router Class Initialized
INFO - 2020-11-13 02:44:30 --> Output Class Initialized
INFO - 2020-11-13 02:44:30 --> Security Class Initialized
DEBUG - 2020-11-13 02:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:44:30 --> Input Class Initialized
INFO - 2020-11-13 02:44:30 --> Language Class Initialized
INFO - 2020-11-13 02:44:30 --> Language Class Initialized
INFO - 2020-11-13 02:44:30 --> Config Class Initialized
INFO - 2020-11-13 02:44:30 --> Loader Class Initialized
INFO - 2020-11-13 02:44:30 --> Helper loaded: url_helper
INFO - 2020-11-13 02:44:30 --> Helper loaded: file_helper
INFO - 2020-11-13 02:44:30 --> Helper loaded: form_helper
INFO - 2020-11-13 02:44:30 --> Helper loaded: my_helper
INFO - 2020-11-13 02:44:30 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:44:30 --> Controller Class Initialized
DEBUG - 2020-11-13 02:44:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-13 02:44:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:44:30 --> Final output sent to browser
DEBUG - 2020-11-13 02:44:30 --> Total execution time: 0.2303
INFO - 2020-11-13 02:44:31 --> Config Class Initialized
INFO - 2020-11-13 02:44:31 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:44:31 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:44:31 --> Utf8 Class Initialized
INFO - 2020-11-13 02:44:31 --> URI Class Initialized
INFO - 2020-11-13 02:44:31 --> Router Class Initialized
INFO - 2020-11-13 02:44:31 --> Output Class Initialized
INFO - 2020-11-13 02:44:31 --> Security Class Initialized
DEBUG - 2020-11-13 02:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:44:31 --> Input Class Initialized
INFO - 2020-11-13 02:44:31 --> Language Class Initialized
INFO - 2020-11-13 02:44:31 --> Language Class Initialized
INFO - 2020-11-13 02:44:31 --> Config Class Initialized
INFO - 2020-11-13 02:44:31 --> Loader Class Initialized
INFO - 2020-11-13 02:44:31 --> Helper loaded: url_helper
INFO - 2020-11-13 02:44:31 --> Helper loaded: file_helper
INFO - 2020-11-13 02:44:31 --> Helper loaded: form_helper
INFO - 2020-11-13 02:44:31 --> Helper loaded: my_helper
INFO - 2020-11-13 02:44:31 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:44:31 --> Controller Class Initialized
DEBUG - 2020-11-13 02:44:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 02:44:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:44:31 --> Final output sent to browser
DEBUG - 2020-11-13 02:44:31 --> Total execution time: 0.2510
INFO - 2020-11-13 02:44:32 --> Config Class Initialized
INFO - 2020-11-13 02:44:32 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:44:32 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:44:32 --> Utf8 Class Initialized
INFO - 2020-11-13 02:44:32 --> URI Class Initialized
INFO - 2020-11-13 02:44:32 --> Router Class Initialized
INFO - 2020-11-13 02:44:32 --> Output Class Initialized
INFO - 2020-11-13 02:44:33 --> Security Class Initialized
DEBUG - 2020-11-13 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:44:33 --> Input Class Initialized
INFO - 2020-11-13 02:44:33 --> Language Class Initialized
INFO - 2020-11-13 02:44:33 --> Language Class Initialized
INFO - 2020-11-13 02:44:33 --> Config Class Initialized
INFO - 2020-11-13 02:44:33 --> Loader Class Initialized
INFO - 2020-11-13 02:44:33 --> Helper loaded: url_helper
INFO - 2020-11-13 02:44:33 --> Helper loaded: file_helper
INFO - 2020-11-13 02:44:33 --> Helper loaded: form_helper
INFO - 2020-11-13 02:44:33 --> Helper loaded: my_helper
INFO - 2020-11-13 02:44:33 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:44:33 --> Controller Class Initialized
INFO - 2020-11-13 02:44:33 --> Final output sent to browser
DEBUG - 2020-11-13 02:44:33 --> Total execution time: 0.1868
INFO - 2020-11-13 02:45:39 --> Config Class Initialized
INFO - 2020-11-13 02:45:39 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:45:39 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:45:39 --> Utf8 Class Initialized
INFO - 2020-11-13 02:45:39 --> URI Class Initialized
INFO - 2020-11-13 02:45:39 --> Router Class Initialized
INFO - 2020-11-13 02:45:39 --> Output Class Initialized
INFO - 2020-11-13 02:45:39 --> Security Class Initialized
DEBUG - 2020-11-13 02:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:45:39 --> Input Class Initialized
INFO - 2020-11-13 02:45:39 --> Language Class Initialized
INFO - 2020-11-13 02:45:39 --> Language Class Initialized
INFO - 2020-11-13 02:45:39 --> Config Class Initialized
INFO - 2020-11-13 02:45:39 --> Loader Class Initialized
INFO - 2020-11-13 02:45:39 --> Helper loaded: url_helper
INFO - 2020-11-13 02:45:39 --> Helper loaded: file_helper
INFO - 2020-11-13 02:45:39 --> Helper loaded: form_helper
INFO - 2020-11-13 02:45:39 --> Helper loaded: my_helper
INFO - 2020-11-13 02:45:39 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:45:39 --> Controller Class Initialized
DEBUG - 2020-11-13 02:45:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2020-11-13 02:45:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:45:39 --> Final output sent to browser
DEBUG - 2020-11-13 02:45:39 --> Total execution time: 0.2570
INFO - 2020-11-13 02:45:42 --> Config Class Initialized
INFO - 2020-11-13 02:45:42 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:45:42 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:45:42 --> Utf8 Class Initialized
INFO - 2020-11-13 02:45:42 --> URI Class Initialized
INFO - 2020-11-13 02:45:42 --> Router Class Initialized
INFO - 2020-11-13 02:45:42 --> Output Class Initialized
INFO - 2020-11-13 02:45:42 --> Security Class Initialized
DEBUG - 2020-11-13 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:45:42 --> Input Class Initialized
INFO - 2020-11-13 02:45:42 --> Language Class Initialized
INFO - 2020-11-13 02:45:42 --> Language Class Initialized
INFO - 2020-11-13 02:45:42 --> Config Class Initialized
INFO - 2020-11-13 02:45:42 --> Loader Class Initialized
INFO - 2020-11-13 02:45:42 --> Helper loaded: url_helper
INFO - 2020-11-13 02:45:42 --> Helper loaded: file_helper
INFO - 2020-11-13 02:45:42 --> Helper loaded: form_helper
INFO - 2020-11-13 02:45:42 --> Helper loaded: my_helper
INFO - 2020-11-13 02:45:42 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:45:42 --> Controller Class Initialized
DEBUG - 2020-11-13 02:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 02:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:45:42 --> Final output sent to browser
DEBUG - 2020-11-13 02:45:42 --> Total execution time: 0.2382
INFO - 2020-11-13 02:45:46 --> Config Class Initialized
INFO - 2020-11-13 02:45:46 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:45:46 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:45:46 --> Utf8 Class Initialized
INFO - 2020-11-13 02:45:46 --> URI Class Initialized
INFO - 2020-11-13 02:45:46 --> Router Class Initialized
INFO - 2020-11-13 02:45:46 --> Output Class Initialized
INFO - 2020-11-13 02:45:46 --> Security Class Initialized
DEBUG - 2020-11-13 02:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:45:46 --> Input Class Initialized
INFO - 2020-11-13 02:45:46 --> Language Class Initialized
INFO - 2020-11-13 02:45:46 --> Language Class Initialized
INFO - 2020-11-13 02:45:46 --> Config Class Initialized
INFO - 2020-11-13 02:45:46 --> Loader Class Initialized
INFO - 2020-11-13 02:45:46 --> Helper loaded: url_helper
INFO - 2020-11-13 02:45:46 --> Helper loaded: file_helper
INFO - 2020-11-13 02:45:46 --> Helper loaded: form_helper
INFO - 2020-11-13 02:45:46 --> Helper loaded: my_helper
INFO - 2020-11-13 02:45:46 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:45:46 --> Controller Class Initialized
DEBUG - 2020-11-13 02:45:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2020-11-13 02:45:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:45:46 --> Final output sent to browser
DEBUG - 2020-11-13 02:45:46 --> Total execution time: 0.2476
INFO - 2020-11-13 02:47:50 --> Config Class Initialized
INFO - 2020-11-13 02:47:50 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:47:50 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:47:50 --> Utf8 Class Initialized
INFO - 2020-11-13 02:47:50 --> URI Class Initialized
INFO - 2020-11-13 02:47:50 --> Router Class Initialized
INFO - 2020-11-13 02:47:50 --> Output Class Initialized
INFO - 2020-11-13 02:47:50 --> Security Class Initialized
DEBUG - 2020-11-13 02:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:47:50 --> Input Class Initialized
INFO - 2020-11-13 02:47:50 --> Language Class Initialized
INFO - 2020-11-13 02:47:50 --> Language Class Initialized
INFO - 2020-11-13 02:47:50 --> Config Class Initialized
INFO - 2020-11-13 02:47:50 --> Loader Class Initialized
INFO - 2020-11-13 02:47:50 --> Helper loaded: url_helper
INFO - 2020-11-13 02:47:50 --> Helper loaded: file_helper
INFO - 2020-11-13 02:47:50 --> Helper loaded: form_helper
INFO - 2020-11-13 02:47:50 --> Helper loaded: my_helper
INFO - 2020-11-13 02:47:50 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:47:50 --> Controller Class Initialized
DEBUG - 2020-11-13 02:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 02:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:47:50 --> Final output sent to browser
DEBUG - 2020-11-13 02:47:50 --> Total execution time: 0.2400
INFO - 2020-11-13 02:47:52 --> Config Class Initialized
INFO - 2020-11-13 02:47:52 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:47:52 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:47:52 --> Utf8 Class Initialized
INFO - 2020-11-13 02:47:52 --> URI Class Initialized
INFO - 2020-11-13 02:47:52 --> Router Class Initialized
INFO - 2020-11-13 02:47:52 --> Output Class Initialized
INFO - 2020-11-13 02:47:52 --> Security Class Initialized
DEBUG - 2020-11-13 02:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:47:52 --> Input Class Initialized
INFO - 2020-11-13 02:47:52 --> Language Class Initialized
INFO - 2020-11-13 02:47:52 --> Language Class Initialized
INFO - 2020-11-13 02:47:52 --> Config Class Initialized
INFO - 2020-11-13 02:47:52 --> Loader Class Initialized
INFO - 2020-11-13 02:47:52 --> Helper loaded: url_helper
INFO - 2020-11-13 02:47:52 --> Helper loaded: file_helper
INFO - 2020-11-13 02:47:52 --> Helper loaded: form_helper
INFO - 2020-11-13 02:47:52 --> Helper loaded: my_helper
INFO - 2020-11-13 02:47:52 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:47:52 --> Controller Class Initialized
INFO - 2020-11-13 02:47:52 --> Final output sent to browser
DEBUG - 2020-11-13 02:47:52 --> Total execution time: 0.2020
INFO - 2020-11-13 02:53:28 --> Config Class Initialized
INFO - 2020-11-13 02:53:28 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:53:28 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:53:28 --> Utf8 Class Initialized
INFO - 2020-11-13 02:53:28 --> URI Class Initialized
INFO - 2020-11-13 02:53:28 --> Router Class Initialized
INFO - 2020-11-13 02:53:28 --> Output Class Initialized
INFO - 2020-11-13 02:53:28 --> Security Class Initialized
DEBUG - 2020-11-13 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:53:28 --> Input Class Initialized
INFO - 2020-11-13 02:53:28 --> Language Class Initialized
ERROR - 2020-11-13 02:53:28 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 103
INFO - 2020-11-13 02:53:33 --> Config Class Initialized
INFO - 2020-11-13 02:53:33 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:53:33 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:53:33 --> Utf8 Class Initialized
INFO - 2020-11-13 02:53:33 --> URI Class Initialized
INFO - 2020-11-13 02:53:33 --> Router Class Initialized
INFO - 2020-11-13 02:53:33 --> Output Class Initialized
INFO - 2020-11-13 02:53:33 --> Security Class Initialized
DEBUG - 2020-11-13 02:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:53:33 --> Input Class Initialized
INFO - 2020-11-13 02:53:33 --> Language Class Initialized
ERROR - 2020-11-13 02:53:34 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 103
INFO - 2020-11-13 02:53:35 --> Config Class Initialized
INFO - 2020-11-13 02:53:35 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:53:35 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:53:35 --> Utf8 Class Initialized
INFO - 2020-11-13 02:53:35 --> URI Class Initialized
INFO - 2020-11-13 02:53:35 --> Router Class Initialized
INFO - 2020-11-13 02:53:35 --> Output Class Initialized
INFO - 2020-11-13 02:53:36 --> Security Class Initialized
DEBUG - 2020-11-13 02:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:53:36 --> Input Class Initialized
INFO - 2020-11-13 02:53:36 --> Language Class Initialized
ERROR - 2020-11-13 02:53:36 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 103
INFO - 2020-11-13 02:53:36 --> Config Class Initialized
INFO - 2020-11-13 02:53:36 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:53:36 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:53:36 --> Utf8 Class Initialized
INFO - 2020-11-13 02:53:36 --> URI Class Initialized
INFO - 2020-11-13 02:53:36 --> Router Class Initialized
INFO - 2020-11-13 02:53:36 --> Output Class Initialized
INFO - 2020-11-13 02:53:36 --> Security Class Initialized
DEBUG - 2020-11-13 02:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:53:36 --> Input Class Initialized
INFO - 2020-11-13 02:53:36 --> Language Class Initialized
ERROR - 2020-11-13 02:53:36 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 103
INFO - 2020-11-13 02:53:37 --> Config Class Initialized
INFO - 2020-11-13 02:53:37 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:53:37 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:53:37 --> Utf8 Class Initialized
INFO - 2020-11-13 02:53:37 --> URI Class Initialized
INFO - 2020-11-13 02:53:37 --> Router Class Initialized
INFO - 2020-11-13 02:53:37 --> Output Class Initialized
INFO - 2020-11-13 02:53:37 --> Security Class Initialized
DEBUG - 2020-11-13 02:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:53:37 --> Input Class Initialized
INFO - 2020-11-13 02:53:37 --> Language Class Initialized
INFO - 2020-11-13 02:53:37 --> Language Class Initialized
INFO - 2020-11-13 02:53:37 --> Config Class Initialized
INFO - 2020-11-13 02:53:37 --> Loader Class Initialized
INFO - 2020-11-13 02:53:37 --> Helper loaded: url_helper
INFO - 2020-11-13 02:53:37 --> Helper loaded: file_helper
INFO - 2020-11-13 02:53:37 --> Helper loaded: form_helper
INFO - 2020-11-13 02:53:37 --> Helper loaded: my_helper
INFO - 2020-11-13 02:53:37 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:53:37 --> Controller Class Initialized
DEBUG - 2020-11-13 02:53:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-13 02:53:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:53:37 --> Final output sent to browser
DEBUG - 2020-11-13 02:53:37 --> Total execution time: 0.2184
INFO - 2020-11-13 02:53:39 --> Config Class Initialized
INFO - 2020-11-13 02:53:39 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:53:39 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:53:39 --> Utf8 Class Initialized
INFO - 2020-11-13 02:53:39 --> URI Class Initialized
INFO - 2020-11-13 02:53:39 --> Router Class Initialized
INFO - 2020-11-13 02:53:39 --> Output Class Initialized
INFO - 2020-11-13 02:53:39 --> Security Class Initialized
DEBUG - 2020-11-13 02:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:53:39 --> Input Class Initialized
INFO - 2020-11-13 02:53:39 --> Language Class Initialized
ERROR - 2020-11-13 02:53:39 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 103
INFO - 2020-11-13 02:53:47 --> Config Class Initialized
INFO - 2020-11-13 02:53:47 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:53:47 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:53:47 --> Utf8 Class Initialized
INFO - 2020-11-13 02:53:47 --> URI Class Initialized
INFO - 2020-11-13 02:53:47 --> Router Class Initialized
INFO - 2020-11-13 02:53:47 --> Output Class Initialized
INFO - 2020-11-13 02:53:47 --> Security Class Initialized
DEBUG - 2020-11-13 02:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:53:47 --> Input Class Initialized
INFO - 2020-11-13 02:53:47 --> Language Class Initialized
INFO - 2020-11-13 02:53:47 --> Language Class Initialized
INFO - 2020-11-13 02:53:47 --> Config Class Initialized
INFO - 2020-11-13 02:53:47 --> Loader Class Initialized
INFO - 2020-11-13 02:53:47 --> Helper loaded: url_helper
INFO - 2020-11-13 02:53:47 --> Helper loaded: file_helper
INFO - 2020-11-13 02:53:47 --> Helper loaded: form_helper
INFO - 2020-11-13 02:53:47 --> Helper loaded: my_helper
INFO - 2020-11-13 02:53:47 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:53:47 --> Controller Class Initialized
DEBUG - 2020-11-13 02:53:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 02:53:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 02:53:47 --> Final output sent to browser
DEBUG - 2020-11-13 02:53:47 --> Total execution time: 0.2612
INFO - 2020-11-13 02:54:00 --> Config Class Initialized
INFO - 2020-11-13 02:54:00 --> Hooks Class Initialized
DEBUG - 2020-11-13 02:54:00 --> UTF-8 Support Enabled
INFO - 2020-11-13 02:54:00 --> Utf8 Class Initialized
INFO - 2020-11-13 02:54:00 --> URI Class Initialized
INFO - 2020-11-13 02:54:00 --> Router Class Initialized
INFO - 2020-11-13 02:54:00 --> Output Class Initialized
INFO - 2020-11-13 02:54:00 --> Security Class Initialized
DEBUG - 2020-11-13 02:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 02:54:00 --> Input Class Initialized
INFO - 2020-11-13 02:54:00 --> Language Class Initialized
INFO - 2020-11-13 02:54:00 --> Language Class Initialized
INFO - 2020-11-13 02:54:00 --> Config Class Initialized
INFO - 2020-11-13 02:54:00 --> Loader Class Initialized
INFO - 2020-11-13 02:54:00 --> Helper loaded: url_helper
INFO - 2020-11-13 02:54:00 --> Helper loaded: file_helper
INFO - 2020-11-13 02:54:00 --> Helper loaded: form_helper
INFO - 2020-11-13 02:54:00 --> Helper loaded: my_helper
INFO - 2020-11-13 02:54:00 --> Database Driver Class Initialized
DEBUG - 2020-11-13 02:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 02:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 02:54:00 --> Controller Class Initialized
INFO - 2020-11-13 05:13:19 --> Config Class Initialized
INFO - 2020-11-13 05:13:19 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:19 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:19 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:19 --> URI Class Initialized
INFO - 2020-11-13 05:13:19 --> Router Class Initialized
INFO - 2020-11-13 05:13:19 --> Output Class Initialized
INFO - 2020-11-13 05:13:19 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:19 --> Input Class Initialized
INFO - 2020-11-13 05:13:19 --> Language Class Initialized
INFO - 2020-11-13 05:13:19 --> Language Class Initialized
INFO - 2020-11-13 05:13:19 --> Config Class Initialized
INFO - 2020-11-13 05:13:19 --> Loader Class Initialized
INFO - 2020-11-13 05:13:19 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:19 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:19 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:19 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:19 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:19 --> Controller Class Initialized
INFO - 2020-11-13 05:13:19 --> Helper loaded: cookie_helper
INFO - 2020-11-13 05:13:19 --> Config Class Initialized
INFO - 2020-11-13 05:13:19 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:19 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:19 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:19 --> URI Class Initialized
INFO - 2020-11-13 05:13:19 --> Router Class Initialized
INFO - 2020-11-13 05:13:19 --> Output Class Initialized
INFO - 2020-11-13 05:13:19 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:20 --> Input Class Initialized
INFO - 2020-11-13 05:13:20 --> Language Class Initialized
INFO - 2020-11-13 05:13:20 --> Language Class Initialized
INFO - 2020-11-13 05:13:20 --> Config Class Initialized
INFO - 2020-11-13 05:13:20 --> Loader Class Initialized
INFO - 2020-11-13 05:13:20 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:20 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:20 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:20 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:20 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:20 --> Controller Class Initialized
DEBUG - 2020-11-13 05:13:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-13 05:13:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:13:20 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:20 --> Total execution time: 0.2380
INFO - 2020-11-13 05:13:30 --> Config Class Initialized
INFO - 2020-11-13 05:13:30 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:30 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:30 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:30 --> URI Class Initialized
INFO - 2020-11-13 05:13:30 --> Router Class Initialized
INFO - 2020-11-13 05:13:30 --> Output Class Initialized
INFO - 2020-11-13 05:13:30 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:30 --> Input Class Initialized
INFO - 2020-11-13 05:13:30 --> Language Class Initialized
INFO - 2020-11-13 05:13:30 --> Language Class Initialized
INFO - 2020-11-13 05:13:30 --> Config Class Initialized
INFO - 2020-11-13 05:13:30 --> Loader Class Initialized
INFO - 2020-11-13 05:13:30 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:30 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:30 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:30 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:30 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:30 --> Controller Class Initialized
DEBUG - 2020-11-13 05:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 05:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:13:30 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:30 --> Total execution time: 0.2511
INFO - 2020-11-13 05:13:33 --> Config Class Initialized
INFO - 2020-11-13 05:13:33 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:33 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:33 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:33 --> URI Class Initialized
INFO - 2020-11-13 05:13:33 --> Router Class Initialized
INFO - 2020-11-13 05:13:33 --> Output Class Initialized
INFO - 2020-11-13 05:13:33 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:33 --> Input Class Initialized
INFO - 2020-11-13 05:13:33 --> Language Class Initialized
INFO - 2020-11-13 05:13:33 --> Language Class Initialized
INFO - 2020-11-13 05:13:33 --> Config Class Initialized
INFO - 2020-11-13 05:13:34 --> Loader Class Initialized
INFO - 2020-11-13 05:13:34 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:34 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:34 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:34 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:34 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:34 --> Controller Class Initialized
DEBUG - 2020-11-13 05:13:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-11-13 05:13:34 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:34 --> Total execution time: 0.2580
INFO - 2020-11-13 05:13:35 --> Config Class Initialized
INFO - 2020-11-13 05:13:35 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:35 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:35 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:35 --> URI Class Initialized
INFO - 2020-11-13 05:13:35 --> Router Class Initialized
INFO - 2020-11-13 05:13:35 --> Output Class Initialized
INFO - 2020-11-13 05:13:35 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:36 --> Input Class Initialized
INFO - 2020-11-13 05:13:36 --> Language Class Initialized
INFO - 2020-11-13 05:13:36 --> Language Class Initialized
INFO - 2020-11-13 05:13:36 --> Config Class Initialized
INFO - 2020-11-13 05:13:36 --> Loader Class Initialized
INFO - 2020-11-13 05:13:36 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:36 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:36 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:36 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:36 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:36 --> Controller Class Initialized
INFO - 2020-11-13 05:13:36 --> Config Class Initialized
INFO - 2020-11-13 05:13:36 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:36 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:36 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:36 --> URI Class Initialized
INFO - 2020-11-13 05:13:36 --> Router Class Initialized
INFO - 2020-11-13 05:13:36 --> Output Class Initialized
INFO - 2020-11-13 05:13:36 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:36 --> Input Class Initialized
INFO - 2020-11-13 05:13:36 --> Language Class Initialized
INFO - 2020-11-13 05:13:36 --> Language Class Initialized
INFO - 2020-11-13 05:13:36 --> Config Class Initialized
INFO - 2020-11-13 05:13:36 --> Loader Class Initialized
INFO - 2020-11-13 05:13:36 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:36 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:36 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:36 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:36 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:36 --> Controller Class Initialized
DEBUG - 2020-11-13 05:13:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-13 05:13:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:13:36 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:36 --> Total execution time: 0.2479
INFO - 2020-11-13 05:13:39 --> Config Class Initialized
INFO - 2020-11-13 05:13:39 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:39 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:39 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:39 --> URI Class Initialized
INFO - 2020-11-13 05:13:39 --> Router Class Initialized
INFO - 2020-11-13 05:13:39 --> Output Class Initialized
INFO - 2020-11-13 05:13:39 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:39 --> Input Class Initialized
INFO - 2020-11-13 05:13:39 --> Language Class Initialized
INFO - 2020-11-13 05:13:39 --> Language Class Initialized
INFO - 2020-11-13 05:13:39 --> Config Class Initialized
INFO - 2020-11-13 05:13:39 --> Loader Class Initialized
INFO - 2020-11-13 05:13:39 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:39 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:39 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:39 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:39 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:39 --> Controller Class Initialized
DEBUG - 2020-11-13 05:13:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 05:13:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:13:39 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:39 --> Total execution time: 0.2326
INFO - 2020-11-13 05:13:41 --> Config Class Initialized
INFO - 2020-11-13 05:13:41 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:41 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:41 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:41 --> URI Class Initialized
INFO - 2020-11-13 05:13:41 --> Router Class Initialized
INFO - 2020-11-13 05:13:41 --> Output Class Initialized
INFO - 2020-11-13 05:13:41 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:41 --> Input Class Initialized
INFO - 2020-11-13 05:13:42 --> Language Class Initialized
INFO - 2020-11-13 05:13:42 --> Language Class Initialized
INFO - 2020-11-13 05:13:42 --> Config Class Initialized
INFO - 2020-11-13 05:13:42 --> Loader Class Initialized
INFO - 2020-11-13 05:13:42 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:42 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:42 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:42 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:42 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:42 --> Controller Class Initialized
INFO - 2020-11-13 05:13:42 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:42 --> Total execution time: 0.1956
INFO - 2020-11-13 05:13:42 --> Config Class Initialized
INFO - 2020-11-13 05:13:42 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:42 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:42 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:42 --> URI Class Initialized
INFO - 2020-11-13 05:13:42 --> Router Class Initialized
INFO - 2020-11-13 05:13:43 --> Output Class Initialized
INFO - 2020-11-13 05:13:43 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:43 --> Input Class Initialized
INFO - 2020-11-13 05:13:43 --> Language Class Initialized
INFO - 2020-11-13 05:13:43 --> Language Class Initialized
INFO - 2020-11-13 05:13:43 --> Config Class Initialized
INFO - 2020-11-13 05:13:43 --> Loader Class Initialized
INFO - 2020-11-13 05:13:43 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:43 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:43 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:43 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:43 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:43 --> Controller Class Initialized
INFO - 2020-11-13 05:13:43 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:43 --> Total execution time: 0.2524
INFO - 2020-11-13 05:13:47 --> Config Class Initialized
INFO - 2020-11-13 05:13:47 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:47 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:47 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:47 --> URI Class Initialized
INFO - 2020-11-13 05:13:47 --> Router Class Initialized
INFO - 2020-11-13 05:13:47 --> Output Class Initialized
INFO - 2020-11-13 05:13:47 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:47 --> Input Class Initialized
INFO - 2020-11-13 05:13:47 --> Language Class Initialized
INFO - 2020-11-13 05:13:47 --> Language Class Initialized
INFO - 2020-11-13 05:13:47 --> Config Class Initialized
INFO - 2020-11-13 05:13:47 --> Loader Class Initialized
INFO - 2020-11-13 05:13:47 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:47 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:47 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:47 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:47 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:48 --> Controller Class Initialized
INFO - 2020-11-13 05:13:48 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:48 --> Total execution time: 0.2718
INFO - 2020-11-13 05:13:48 --> Config Class Initialized
INFO - 2020-11-13 05:13:48 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:48 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:48 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:48 --> URI Class Initialized
INFO - 2020-11-13 05:13:48 --> Router Class Initialized
INFO - 2020-11-13 05:13:48 --> Output Class Initialized
INFO - 2020-11-13 05:13:48 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:48 --> Input Class Initialized
INFO - 2020-11-13 05:13:48 --> Language Class Initialized
INFO - 2020-11-13 05:13:48 --> Language Class Initialized
INFO - 2020-11-13 05:13:48 --> Config Class Initialized
INFO - 2020-11-13 05:13:48 --> Loader Class Initialized
INFO - 2020-11-13 05:13:48 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:48 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:48 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:48 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:48 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:48 --> Controller Class Initialized
DEBUG - 2020-11-13 05:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 05:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:13:48 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:48 --> Total execution time: 0.3655
INFO - 2020-11-13 05:13:50 --> Config Class Initialized
INFO - 2020-11-13 05:13:50 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:13:50 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:13:50 --> Utf8 Class Initialized
INFO - 2020-11-13 05:13:50 --> URI Class Initialized
INFO - 2020-11-13 05:13:50 --> Router Class Initialized
INFO - 2020-11-13 05:13:50 --> Output Class Initialized
INFO - 2020-11-13 05:13:50 --> Security Class Initialized
DEBUG - 2020-11-13 05:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:13:50 --> Input Class Initialized
INFO - 2020-11-13 05:13:50 --> Language Class Initialized
INFO - 2020-11-13 05:13:50 --> Language Class Initialized
INFO - 2020-11-13 05:13:51 --> Config Class Initialized
INFO - 2020-11-13 05:13:51 --> Loader Class Initialized
INFO - 2020-11-13 05:13:51 --> Helper loaded: url_helper
INFO - 2020-11-13 05:13:51 --> Helper loaded: file_helper
INFO - 2020-11-13 05:13:51 --> Helper loaded: form_helper
INFO - 2020-11-13 05:13:51 --> Helper loaded: my_helper
INFO - 2020-11-13 05:13:51 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:13:51 --> Controller Class Initialized
DEBUG - 2020-11-13 05:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 05:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:13:51 --> Final output sent to browser
DEBUG - 2020-11-13 05:13:51 --> Total execution time: 0.2533
INFO - 2020-11-13 05:15:39 --> Config Class Initialized
INFO - 2020-11-13 05:15:39 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:39 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:39 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:39 --> URI Class Initialized
INFO - 2020-11-13 05:15:39 --> Router Class Initialized
INFO - 2020-11-13 05:15:39 --> Output Class Initialized
INFO - 2020-11-13 05:15:39 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:39 --> Input Class Initialized
INFO - 2020-11-13 05:15:39 --> Language Class Initialized
INFO - 2020-11-13 05:15:39 --> Language Class Initialized
INFO - 2020-11-13 05:15:39 --> Config Class Initialized
INFO - 2020-11-13 05:15:39 --> Loader Class Initialized
INFO - 2020-11-13 05:15:39 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:39 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:39 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:39 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:39 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:39 --> Controller Class Initialized
DEBUG - 2020-11-13 05:15:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 05:15:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:15:39 --> Final output sent to browser
DEBUG - 2020-11-13 05:15:39 --> Total execution time: 0.2514
INFO - 2020-11-13 05:15:41 --> Config Class Initialized
INFO - 2020-11-13 05:15:41 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:41 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:41 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:41 --> URI Class Initialized
INFO - 2020-11-13 05:15:41 --> Router Class Initialized
INFO - 2020-11-13 05:15:41 --> Output Class Initialized
INFO - 2020-11-13 05:15:41 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:41 --> Input Class Initialized
INFO - 2020-11-13 05:15:42 --> Language Class Initialized
INFO - 2020-11-13 05:15:42 --> Language Class Initialized
INFO - 2020-11-13 05:15:42 --> Config Class Initialized
INFO - 2020-11-13 05:15:42 --> Loader Class Initialized
INFO - 2020-11-13 05:15:42 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:42 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:42 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:42 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:42 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:42 --> Controller Class Initialized
INFO - 2020-11-13 05:15:42 --> Config Class Initialized
INFO - 2020-11-13 05:15:42 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:42 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:42 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:42 --> URI Class Initialized
INFO - 2020-11-13 05:15:42 --> Router Class Initialized
INFO - 2020-11-13 05:15:42 --> Output Class Initialized
INFO - 2020-11-13 05:15:42 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:42 --> Input Class Initialized
INFO - 2020-11-13 05:15:42 --> Language Class Initialized
INFO - 2020-11-13 05:15:42 --> Language Class Initialized
INFO - 2020-11-13 05:15:42 --> Config Class Initialized
INFO - 2020-11-13 05:15:42 --> Loader Class Initialized
INFO - 2020-11-13 05:15:42 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:42 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:42 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:42 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:42 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:42 --> Controller Class Initialized
DEBUG - 2020-11-13 05:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-13 05:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:15:42 --> Final output sent to browser
DEBUG - 2020-11-13 05:15:42 --> Total execution time: 0.2533
INFO - 2020-11-13 05:15:43 --> Config Class Initialized
INFO - 2020-11-13 05:15:43 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:43 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:43 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:44 --> URI Class Initialized
INFO - 2020-11-13 05:15:44 --> Router Class Initialized
INFO - 2020-11-13 05:15:44 --> Output Class Initialized
INFO - 2020-11-13 05:15:44 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:44 --> Input Class Initialized
INFO - 2020-11-13 05:15:44 --> Language Class Initialized
INFO - 2020-11-13 05:15:44 --> Language Class Initialized
INFO - 2020-11-13 05:15:44 --> Config Class Initialized
INFO - 2020-11-13 05:15:44 --> Loader Class Initialized
INFO - 2020-11-13 05:15:44 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:44 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:44 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:44 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:44 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:44 --> Controller Class Initialized
DEBUG - 2020-11-13 05:15:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 05:15:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:15:44 --> Final output sent to browser
DEBUG - 2020-11-13 05:15:44 --> Total execution time: 0.2568
INFO - 2020-11-13 05:15:45 --> Config Class Initialized
INFO - 2020-11-13 05:15:45 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:45 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:45 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:45 --> URI Class Initialized
INFO - 2020-11-13 05:15:45 --> Router Class Initialized
INFO - 2020-11-13 05:15:45 --> Output Class Initialized
INFO - 2020-11-13 05:15:45 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:45 --> Input Class Initialized
INFO - 2020-11-13 05:15:45 --> Language Class Initialized
INFO - 2020-11-13 05:15:45 --> Language Class Initialized
INFO - 2020-11-13 05:15:45 --> Config Class Initialized
INFO - 2020-11-13 05:15:45 --> Loader Class Initialized
INFO - 2020-11-13 05:15:45 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:45 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:45 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:45 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:45 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:45 --> Controller Class Initialized
INFO - 2020-11-13 05:15:45 --> Config Class Initialized
INFO - 2020-11-13 05:15:45 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:45 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:45 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:45 --> URI Class Initialized
INFO - 2020-11-13 05:15:45 --> Router Class Initialized
INFO - 2020-11-13 05:15:45 --> Output Class Initialized
INFO - 2020-11-13 05:15:45 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:45 --> Input Class Initialized
INFO - 2020-11-13 05:15:45 --> Language Class Initialized
INFO - 2020-11-13 05:15:45 --> Language Class Initialized
INFO - 2020-11-13 05:15:45 --> Config Class Initialized
INFO - 2020-11-13 05:15:45 --> Loader Class Initialized
INFO - 2020-11-13 05:15:45 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:45 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:45 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:45 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:45 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:45 --> Controller Class Initialized
DEBUG - 2020-11-13 05:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-13 05:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:15:45 --> Final output sent to browser
DEBUG - 2020-11-13 05:15:45 --> Total execution time: 0.2424
INFO - 2020-11-13 05:15:46 --> Config Class Initialized
INFO - 2020-11-13 05:15:46 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:46 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:46 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:46 --> URI Class Initialized
INFO - 2020-11-13 05:15:46 --> Router Class Initialized
INFO - 2020-11-13 05:15:46 --> Output Class Initialized
INFO - 2020-11-13 05:15:46 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:46 --> Input Class Initialized
INFO - 2020-11-13 05:15:46 --> Language Class Initialized
INFO - 2020-11-13 05:15:46 --> Language Class Initialized
INFO - 2020-11-13 05:15:46 --> Config Class Initialized
INFO - 2020-11-13 05:15:46 --> Loader Class Initialized
INFO - 2020-11-13 05:15:46 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:46 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:46 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:46 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:46 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:46 --> Controller Class Initialized
DEBUG - 2020-11-13 05:15:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-13 05:15:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:15:46 --> Final output sent to browser
DEBUG - 2020-11-13 05:15:46 --> Total execution time: 0.2367
INFO - 2020-11-13 05:15:46 --> Config Class Initialized
INFO - 2020-11-13 05:15:46 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:46 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:46 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:46 --> URI Class Initialized
INFO - 2020-11-13 05:15:46 --> Router Class Initialized
INFO - 2020-11-13 05:15:46 --> Output Class Initialized
INFO - 2020-11-13 05:15:46 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:46 --> Input Class Initialized
INFO - 2020-11-13 05:15:46 --> Language Class Initialized
INFO - 2020-11-13 05:15:46 --> Language Class Initialized
INFO - 2020-11-13 05:15:46 --> Config Class Initialized
INFO - 2020-11-13 05:15:46 --> Loader Class Initialized
INFO - 2020-11-13 05:15:46 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:46 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:46 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:46 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:46 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:47 --> Controller Class Initialized
INFO - 2020-11-13 05:15:47 --> Config Class Initialized
INFO - 2020-11-13 05:15:47 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:47 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:47 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:47 --> URI Class Initialized
INFO - 2020-11-13 05:15:47 --> Router Class Initialized
INFO - 2020-11-13 05:15:47 --> Output Class Initialized
INFO - 2020-11-13 05:15:47 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:47 --> Input Class Initialized
INFO - 2020-11-13 05:15:47 --> Language Class Initialized
INFO - 2020-11-13 05:15:47 --> Language Class Initialized
INFO - 2020-11-13 05:15:47 --> Config Class Initialized
INFO - 2020-11-13 05:15:47 --> Loader Class Initialized
INFO - 2020-11-13 05:15:47 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:47 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:47 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:47 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:47 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:47 --> Controller Class Initialized
INFO - 2020-11-13 05:15:47 --> Config Class Initialized
INFO - 2020-11-13 05:15:47 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:47 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:47 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:47 --> URI Class Initialized
INFO - 2020-11-13 05:15:47 --> Router Class Initialized
INFO - 2020-11-13 05:15:47 --> Output Class Initialized
INFO - 2020-11-13 05:15:47 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:47 --> Input Class Initialized
INFO - 2020-11-13 05:15:47 --> Language Class Initialized
INFO - 2020-11-13 05:15:47 --> Language Class Initialized
INFO - 2020-11-13 05:15:47 --> Config Class Initialized
INFO - 2020-11-13 05:15:47 --> Loader Class Initialized
INFO - 2020-11-13 05:15:47 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:47 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:47 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:47 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:47 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:47 --> Controller Class Initialized
DEBUG - 2020-11-13 05:15:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-13 05:15:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:15:47 --> Final output sent to browser
DEBUG - 2020-11-13 05:15:47 --> Total execution time: 0.2564
INFO - 2020-11-13 05:15:48 --> Config Class Initialized
INFO - 2020-11-13 05:15:48 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:48 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:48 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:48 --> URI Class Initialized
INFO - 2020-11-13 05:15:48 --> Router Class Initialized
INFO - 2020-11-13 05:15:48 --> Output Class Initialized
INFO - 2020-11-13 05:15:48 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:48 --> Input Class Initialized
INFO - 2020-11-13 05:15:48 --> Language Class Initialized
INFO - 2020-11-13 05:15:48 --> Language Class Initialized
INFO - 2020-11-13 05:15:48 --> Config Class Initialized
INFO - 2020-11-13 05:15:48 --> Loader Class Initialized
INFO - 2020-11-13 05:15:48 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:48 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:48 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:48 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:48 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:49 --> Controller Class Initialized
DEBUG - 2020-11-13 05:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-13 05:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:15:49 --> Final output sent to browser
DEBUG - 2020-11-13 05:15:49 --> Total execution time: 0.2579
INFO - 2020-11-13 05:15:49 --> Config Class Initialized
INFO - 2020-11-13 05:15:49 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:49 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:49 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:49 --> URI Class Initialized
INFO - 2020-11-13 05:15:49 --> Router Class Initialized
INFO - 2020-11-13 05:15:49 --> Output Class Initialized
INFO - 2020-11-13 05:15:49 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:49 --> Input Class Initialized
INFO - 2020-11-13 05:15:49 --> Language Class Initialized
INFO - 2020-11-13 05:15:49 --> Language Class Initialized
INFO - 2020-11-13 05:15:49 --> Config Class Initialized
INFO - 2020-11-13 05:15:49 --> Loader Class Initialized
INFO - 2020-11-13 05:15:49 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:49 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:49 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:49 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:49 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:49 --> Controller Class Initialized
INFO - 2020-11-13 05:15:53 --> Config Class Initialized
INFO - 2020-11-13 05:15:53 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:53 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:53 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:53 --> URI Class Initialized
INFO - 2020-11-13 05:15:53 --> Router Class Initialized
INFO - 2020-11-13 05:15:53 --> Output Class Initialized
INFO - 2020-11-13 05:15:53 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:53 --> Input Class Initialized
INFO - 2020-11-13 05:15:53 --> Language Class Initialized
INFO - 2020-11-13 05:15:53 --> Language Class Initialized
INFO - 2020-11-13 05:15:53 --> Config Class Initialized
INFO - 2020-11-13 05:15:53 --> Loader Class Initialized
INFO - 2020-11-13 05:15:53 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:53 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:53 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:53 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:53 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:53 --> Controller Class Initialized
DEBUG - 2020-11-13 05:15:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-13 05:15:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:15:53 --> Final output sent to browser
DEBUG - 2020-11-13 05:15:53 --> Total execution time: 0.2837
INFO - 2020-11-13 05:15:58 --> Config Class Initialized
INFO - 2020-11-13 05:15:58 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:58 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:58 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:58 --> URI Class Initialized
INFO - 2020-11-13 05:15:58 --> Router Class Initialized
INFO - 2020-11-13 05:15:58 --> Output Class Initialized
INFO - 2020-11-13 05:15:58 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:58 --> Input Class Initialized
INFO - 2020-11-13 05:15:58 --> Language Class Initialized
INFO - 2020-11-13 05:15:58 --> Language Class Initialized
INFO - 2020-11-13 05:15:58 --> Config Class Initialized
INFO - 2020-11-13 05:15:58 --> Loader Class Initialized
INFO - 2020-11-13 05:15:58 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:58 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:58 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:58 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:58 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:15:58 --> Controller Class Initialized
INFO - 2020-11-13 05:15:58 --> Helper loaded: cookie_helper
INFO - 2020-11-13 05:15:58 --> Final output sent to browser
DEBUG - 2020-11-13 05:15:58 --> Total execution time: 0.3699
INFO - 2020-11-13 05:15:59 --> Config Class Initialized
INFO - 2020-11-13 05:15:59 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:15:59 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:15:59 --> Utf8 Class Initialized
INFO - 2020-11-13 05:15:59 --> URI Class Initialized
INFO - 2020-11-13 05:15:59 --> Router Class Initialized
INFO - 2020-11-13 05:15:59 --> Output Class Initialized
INFO - 2020-11-13 05:15:59 --> Security Class Initialized
DEBUG - 2020-11-13 05:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:15:59 --> Input Class Initialized
INFO - 2020-11-13 05:15:59 --> Language Class Initialized
INFO - 2020-11-13 05:15:59 --> Language Class Initialized
INFO - 2020-11-13 05:15:59 --> Config Class Initialized
INFO - 2020-11-13 05:15:59 --> Loader Class Initialized
INFO - 2020-11-13 05:15:59 --> Helper loaded: url_helper
INFO - 2020-11-13 05:15:59 --> Helper loaded: file_helper
INFO - 2020-11-13 05:15:59 --> Helper loaded: form_helper
INFO - 2020-11-13 05:15:59 --> Helper loaded: my_helper
INFO - 2020-11-13 05:15:59 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:16:00 --> Controller Class Initialized
DEBUG - 2020-11-13 05:16:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-13 05:16:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:16:00 --> Final output sent to browser
DEBUG - 2020-11-13 05:16:00 --> Total execution time: 0.3938
INFO - 2020-11-13 05:16:01 --> Config Class Initialized
INFO - 2020-11-13 05:16:01 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:16:01 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:16:01 --> Utf8 Class Initialized
INFO - 2020-11-13 05:16:01 --> URI Class Initialized
INFO - 2020-11-13 05:16:01 --> Router Class Initialized
INFO - 2020-11-13 05:16:01 --> Output Class Initialized
INFO - 2020-11-13 05:16:01 --> Security Class Initialized
DEBUG - 2020-11-13 05:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:16:01 --> Input Class Initialized
INFO - 2020-11-13 05:16:01 --> Language Class Initialized
INFO - 2020-11-13 05:16:01 --> Language Class Initialized
INFO - 2020-11-13 05:16:01 --> Config Class Initialized
INFO - 2020-11-13 05:16:01 --> Loader Class Initialized
INFO - 2020-11-13 05:16:01 --> Helper loaded: url_helper
INFO - 2020-11-13 05:16:01 --> Helper loaded: file_helper
INFO - 2020-11-13 05:16:01 --> Helper loaded: form_helper
INFO - 2020-11-13 05:16:01 --> Helper loaded: my_helper
INFO - 2020-11-13 05:16:01 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:16:01 --> Controller Class Initialized
DEBUG - 2020-11-13 05:16:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-13 05:16:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:16:01 --> Final output sent to browser
DEBUG - 2020-11-13 05:16:01 --> Total execution time: 0.3468
INFO - 2020-11-13 05:16:02 --> Config Class Initialized
INFO - 2020-11-13 05:16:02 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:16:02 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:16:02 --> Utf8 Class Initialized
INFO - 2020-11-13 05:16:02 --> URI Class Initialized
INFO - 2020-11-13 05:16:02 --> Router Class Initialized
INFO - 2020-11-13 05:16:02 --> Output Class Initialized
INFO - 2020-11-13 05:16:02 --> Security Class Initialized
DEBUG - 2020-11-13 05:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:16:02 --> Input Class Initialized
INFO - 2020-11-13 05:16:02 --> Language Class Initialized
INFO - 2020-11-13 05:16:03 --> Language Class Initialized
INFO - 2020-11-13 05:16:03 --> Config Class Initialized
INFO - 2020-11-13 05:16:03 --> Loader Class Initialized
INFO - 2020-11-13 05:16:03 --> Helper loaded: url_helper
INFO - 2020-11-13 05:16:03 --> Helper loaded: file_helper
INFO - 2020-11-13 05:16:03 --> Helper loaded: form_helper
INFO - 2020-11-13 05:16:03 --> Helper loaded: my_helper
INFO - 2020-11-13 05:16:03 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:16:03 --> Controller Class Initialized
DEBUG - 2020-11-13 05:16:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 05:16:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:16:03 --> Final output sent to browser
DEBUG - 2020-11-13 05:16:03 --> Total execution time: 0.2523
INFO - 2020-11-13 05:18:31 --> Config Class Initialized
INFO - 2020-11-13 05:18:31 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:18:31 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:18:31 --> Utf8 Class Initialized
INFO - 2020-11-13 05:18:31 --> URI Class Initialized
INFO - 2020-11-13 05:18:31 --> Router Class Initialized
INFO - 2020-11-13 05:18:31 --> Output Class Initialized
INFO - 2020-11-13 05:18:31 --> Security Class Initialized
DEBUG - 2020-11-13 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:18:31 --> Input Class Initialized
INFO - 2020-11-13 05:18:31 --> Language Class Initialized
INFO - 2020-11-13 05:18:31 --> Language Class Initialized
INFO - 2020-11-13 05:18:31 --> Config Class Initialized
INFO - 2020-11-13 05:18:31 --> Loader Class Initialized
INFO - 2020-11-13 05:18:31 --> Helper loaded: url_helper
INFO - 2020-11-13 05:18:31 --> Helper loaded: file_helper
INFO - 2020-11-13 05:18:31 --> Helper loaded: form_helper
INFO - 2020-11-13 05:18:31 --> Helper loaded: my_helper
INFO - 2020-11-13 05:18:31 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:18:31 --> Controller Class Initialized
INFO - 2020-11-13 05:18:57 --> Config Class Initialized
INFO - 2020-11-13 05:18:57 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:18:57 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:18:57 --> Utf8 Class Initialized
INFO - 2020-11-13 05:18:57 --> URI Class Initialized
INFO - 2020-11-13 05:18:57 --> Router Class Initialized
INFO - 2020-11-13 05:18:57 --> Output Class Initialized
INFO - 2020-11-13 05:18:57 --> Security Class Initialized
DEBUG - 2020-11-13 05:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:18:57 --> Input Class Initialized
INFO - 2020-11-13 05:18:57 --> Language Class Initialized
INFO - 2020-11-13 05:18:57 --> Language Class Initialized
INFO - 2020-11-13 05:18:57 --> Config Class Initialized
INFO - 2020-11-13 05:18:57 --> Loader Class Initialized
INFO - 2020-11-13 05:18:57 --> Helper loaded: url_helper
INFO - 2020-11-13 05:18:57 --> Helper loaded: file_helper
INFO - 2020-11-13 05:18:57 --> Helper loaded: form_helper
INFO - 2020-11-13 05:18:57 --> Helper loaded: my_helper
INFO - 2020-11-13 05:18:57 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:18:58 --> Controller Class Initialized
INFO - 2020-11-13 05:18:58 --> Final output sent to browser
DEBUG - 2020-11-13 05:18:58 --> Total execution time: 0.2485
INFO - 2020-11-13 05:27:56 --> Config Class Initialized
INFO - 2020-11-13 05:27:56 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:27:56 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:27:56 --> Utf8 Class Initialized
INFO - 2020-11-13 05:27:56 --> URI Class Initialized
INFO - 2020-11-13 05:27:56 --> Router Class Initialized
INFO - 2020-11-13 05:27:56 --> Output Class Initialized
INFO - 2020-11-13 05:27:56 --> Security Class Initialized
DEBUG - 2020-11-13 05:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:27:56 --> Input Class Initialized
INFO - 2020-11-13 05:27:56 --> Language Class Initialized
INFO - 2020-11-13 05:27:56 --> Language Class Initialized
INFO - 2020-11-13 05:27:56 --> Config Class Initialized
INFO - 2020-11-13 05:27:56 --> Loader Class Initialized
INFO - 2020-11-13 05:27:56 --> Helper loaded: url_helper
INFO - 2020-11-13 05:27:56 --> Helper loaded: file_helper
INFO - 2020-11-13 05:27:56 --> Helper loaded: form_helper
INFO - 2020-11-13 05:27:56 --> Helper loaded: my_helper
INFO - 2020-11-13 05:27:56 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:27:56 --> Controller Class Initialized
INFO - 2020-11-13 05:29:15 --> Config Class Initialized
INFO - 2020-11-13 05:29:15 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:29:15 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:29:15 --> Utf8 Class Initialized
INFO - 2020-11-13 05:29:15 --> URI Class Initialized
INFO - 2020-11-13 05:29:15 --> Router Class Initialized
INFO - 2020-11-13 05:29:15 --> Output Class Initialized
INFO - 2020-11-13 05:29:15 --> Security Class Initialized
DEBUG - 2020-11-13 05:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:29:15 --> Input Class Initialized
INFO - 2020-11-13 05:29:15 --> Language Class Initialized
INFO - 2020-11-13 05:29:15 --> Language Class Initialized
INFO - 2020-11-13 05:29:15 --> Config Class Initialized
INFO - 2020-11-13 05:29:15 --> Loader Class Initialized
INFO - 2020-11-13 05:29:15 --> Helper loaded: url_helper
INFO - 2020-11-13 05:29:15 --> Helper loaded: file_helper
INFO - 2020-11-13 05:29:15 --> Helper loaded: form_helper
INFO - 2020-11-13 05:29:15 --> Helper loaded: my_helper
INFO - 2020-11-13 05:29:15 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:29:15 --> Controller Class Initialized
INFO - 2020-11-13 05:29:16 --> Config Class Initialized
INFO - 2020-11-13 05:29:16 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:29:16 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:29:16 --> Utf8 Class Initialized
INFO - 2020-11-13 05:29:16 --> URI Class Initialized
INFO - 2020-11-13 05:29:16 --> Router Class Initialized
INFO - 2020-11-13 05:29:16 --> Output Class Initialized
INFO - 2020-11-13 05:29:16 --> Security Class Initialized
DEBUG - 2020-11-13 05:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:29:16 --> Input Class Initialized
INFO - 2020-11-13 05:29:16 --> Language Class Initialized
INFO - 2020-11-13 05:29:16 --> Language Class Initialized
INFO - 2020-11-13 05:29:16 --> Config Class Initialized
INFO - 2020-11-13 05:29:16 --> Loader Class Initialized
INFO - 2020-11-13 05:29:16 --> Helper loaded: url_helper
INFO - 2020-11-13 05:29:16 --> Helper loaded: file_helper
INFO - 2020-11-13 05:29:16 --> Helper loaded: form_helper
INFO - 2020-11-13 05:29:16 --> Helper loaded: my_helper
INFO - 2020-11-13 05:29:16 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:29:16 --> Controller Class Initialized
DEBUG - 2020-11-13 05:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-13 05:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-13 05:29:16 --> Final output sent to browser
DEBUG - 2020-11-13 05:29:16 --> Total execution time: 0.4216
INFO - 2020-11-13 05:29:18 --> Config Class Initialized
INFO - 2020-11-13 05:29:18 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:29:18 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:29:18 --> Utf8 Class Initialized
INFO - 2020-11-13 05:29:18 --> URI Class Initialized
INFO - 2020-11-13 05:29:18 --> Router Class Initialized
INFO - 2020-11-13 05:29:18 --> Output Class Initialized
INFO - 2020-11-13 05:29:18 --> Security Class Initialized
DEBUG - 2020-11-13 05:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:29:18 --> Input Class Initialized
INFO - 2020-11-13 05:29:18 --> Language Class Initialized
INFO - 2020-11-13 05:29:18 --> Language Class Initialized
INFO - 2020-11-13 05:29:18 --> Config Class Initialized
INFO - 2020-11-13 05:29:18 --> Loader Class Initialized
INFO - 2020-11-13 05:29:18 --> Helper loaded: url_helper
INFO - 2020-11-13 05:29:18 --> Helper loaded: file_helper
INFO - 2020-11-13 05:29:18 --> Helper loaded: form_helper
INFO - 2020-11-13 05:29:18 --> Helper loaded: my_helper
INFO - 2020-11-13 05:29:18 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:29:18 --> Controller Class Initialized
INFO - 2020-11-13 05:30:06 --> Config Class Initialized
INFO - 2020-11-13 05:30:06 --> Hooks Class Initialized
DEBUG - 2020-11-13 05:30:06 --> UTF-8 Support Enabled
INFO - 2020-11-13 05:30:06 --> Utf8 Class Initialized
INFO - 2020-11-13 05:30:06 --> URI Class Initialized
INFO - 2020-11-13 05:30:06 --> Router Class Initialized
INFO - 2020-11-13 05:30:06 --> Output Class Initialized
INFO - 2020-11-13 05:30:06 --> Security Class Initialized
DEBUG - 2020-11-13 05:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-13 05:30:06 --> Input Class Initialized
INFO - 2020-11-13 05:30:06 --> Language Class Initialized
INFO - 2020-11-13 05:30:06 --> Language Class Initialized
INFO - 2020-11-13 05:30:06 --> Config Class Initialized
INFO - 2020-11-13 05:30:06 --> Loader Class Initialized
INFO - 2020-11-13 05:30:06 --> Helper loaded: url_helper
INFO - 2020-11-13 05:30:06 --> Helper loaded: file_helper
INFO - 2020-11-13 05:30:06 --> Helper loaded: form_helper
INFO - 2020-11-13 05:30:06 --> Helper loaded: my_helper
INFO - 2020-11-13 05:30:06 --> Database Driver Class Initialized
DEBUG - 2020-11-13 05:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-13 05:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-13 05:30:06 --> Controller Class Initialized
