<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-16 01:18:29 --> Config Class Initialized
INFO - 2021-01-16 01:18:29 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:18:29 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:18:29 --> Utf8 Class Initialized
INFO - 2021-01-16 01:18:29 --> URI Class Initialized
DEBUG - 2021-01-16 01:18:29 --> No URI present. Default controller set.
INFO - 2021-01-16 01:18:29 --> Router Class Initialized
INFO - 2021-01-16 01:18:29 --> Output Class Initialized
INFO - 2021-01-16 01:18:29 --> Security Class Initialized
DEBUG - 2021-01-16 01:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:18:29 --> Input Class Initialized
INFO - 2021-01-16 01:18:29 --> Language Class Initialized
INFO - 2021-01-16 01:18:29 --> Language Class Initialized
INFO - 2021-01-16 01:18:29 --> Config Class Initialized
INFO - 2021-01-16 01:18:29 --> Loader Class Initialized
INFO - 2021-01-16 01:18:29 --> Helper loaded: url_helper
INFO - 2021-01-16 01:18:29 --> Helper loaded: file_helper
INFO - 2021-01-16 01:18:29 --> Helper loaded: form_helper
INFO - 2021-01-16 01:18:29 --> Helper loaded: my_helper
INFO - 2021-01-16 01:18:30 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:18:30 --> Controller Class Initialized
INFO - 2021-01-16 01:18:30 --> Config Class Initialized
INFO - 2021-01-16 01:18:30 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:18:30 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:18:30 --> Utf8 Class Initialized
INFO - 2021-01-16 01:18:30 --> URI Class Initialized
INFO - 2021-01-16 01:18:30 --> Router Class Initialized
INFO - 2021-01-16 01:18:30 --> Output Class Initialized
INFO - 2021-01-16 01:18:30 --> Security Class Initialized
DEBUG - 2021-01-16 01:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:18:30 --> Input Class Initialized
INFO - 2021-01-16 01:18:30 --> Language Class Initialized
INFO - 2021-01-16 01:18:30 --> Language Class Initialized
INFO - 2021-01-16 01:18:30 --> Config Class Initialized
INFO - 2021-01-16 01:18:30 --> Loader Class Initialized
INFO - 2021-01-16 01:18:30 --> Helper loaded: url_helper
INFO - 2021-01-16 01:18:30 --> Helper loaded: file_helper
INFO - 2021-01-16 01:18:30 --> Helper loaded: form_helper
INFO - 2021-01-16 01:18:30 --> Helper loaded: my_helper
INFO - 2021-01-16 01:18:30 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:18:30 --> Controller Class Initialized
DEBUG - 2021-01-16 01:18:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 01:18:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:18:30 --> Final output sent to browser
DEBUG - 2021-01-16 01:18:30 --> Total execution time: 0.2765
INFO - 2021-01-16 01:18:43 --> Config Class Initialized
INFO - 2021-01-16 01:18:43 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:18:43 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:18:43 --> Utf8 Class Initialized
INFO - 2021-01-16 01:18:43 --> URI Class Initialized
INFO - 2021-01-16 01:18:43 --> Router Class Initialized
INFO - 2021-01-16 01:18:43 --> Output Class Initialized
INFO - 2021-01-16 01:18:43 --> Security Class Initialized
DEBUG - 2021-01-16 01:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:18:43 --> Input Class Initialized
INFO - 2021-01-16 01:18:43 --> Language Class Initialized
INFO - 2021-01-16 01:18:43 --> Language Class Initialized
INFO - 2021-01-16 01:18:43 --> Config Class Initialized
INFO - 2021-01-16 01:18:43 --> Loader Class Initialized
INFO - 2021-01-16 01:18:43 --> Helper loaded: url_helper
INFO - 2021-01-16 01:18:43 --> Helper loaded: file_helper
INFO - 2021-01-16 01:18:43 --> Helper loaded: form_helper
INFO - 2021-01-16 01:18:43 --> Helper loaded: my_helper
INFO - 2021-01-16 01:18:43 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:18:43 --> Controller Class Initialized
INFO - 2021-01-16 01:18:43 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:18:43 --> Final output sent to browser
DEBUG - 2021-01-16 01:18:43 --> Total execution time: 0.3095
INFO - 2021-01-16 01:18:44 --> Config Class Initialized
INFO - 2021-01-16 01:18:44 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:18:44 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:18:44 --> Utf8 Class Initialized
INFO - 2021-01-16 01:18:44 --> URI Class Initialized
INFO - 2021-01-16 01:18:44 --> Router Class Initialized
INFO - 2021-01-16 01:18:44 --> Output Class Initialized
INFO - 2021-01-16 01:18:44 --> Security Class Initialized
DEBUG - 2021-01-16 01:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:18:44 --> Input Class Initialized
INFO - 2021-01-16 01:18:44 --> Language Class Initialized
INFO - 2021-01-16 01:18:44 --> Language Class Initialized
INFO - 2021-01-16 01:18:44 --> Config Class Initialized
INFO - 2021-01-16 01:18:44 --> Loader Class Initialized
INFO - 2021-01-16 01:18:44 --> Helper loaded: url_helper
INFO - 2021-01-16 01:18:44 --> Helper loaded: file_helper
INFO - 2021-01-16 01:18:44 --> Helper loaded: form_helper
INFO - 2021-01-16 01:18:44 --> Helper loaded: my_helper
INFO - 2021-01-16 01:18:44 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:18:44 --> Controller Class Initialized
DEBUG - 2021-01-16 01:18:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 01:18:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:18:44 --> Final output sent to browser
DEBUG - 2021-01-16 01:18:44 --> Total execution time: 0.3828
INFO - 2021-01-16 01:18:50 --> Config Class Initialized
INFO - 2021-01-16 01:18:50 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:18:50 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:18:50 --> Utf8 Class Initialized
INFO - 2021-01-16 01:18:50 --> URI Class Initialized
INFO - 2021-01-16 01:18:50 --> Router Class Initialized
INFO - 2021-01-16 01:18:50 --> Output Class Initialized
INFO - 2021-01-16 01:18:50 --> Security Class Initialized
DEBUG - 2021-01-16 01:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:18:50 --> Input Class Initialized
INFO - 2021-01-16 01:18:50 --> Language Class Initialized
INFO - 2021-01-16 01:18:50 --> Language Class Initialized
INFO - 2021-01-16 01:18:50 --> Config Class Initialized
INFO - 2021-01-16 01:18:50 --> Loader Class Initialized
INFO - 2021-01-16 01:18:50 --> Helper loaded: url_helper
INFO - 2021-01-16 01:18:50 --> Helper loaded: file_helper
INFO - 2021-01-16 01:18:50 --> Helper loaded: form_helper
INFO - 2021-01-16 01:18:50 --> Helper loaded: my_helper
INFO - 2021-01-16 01:18:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:18:50 --> Controller Class Initialized
DEBUG - 2021-01-16 01:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-01-16 01:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:18:50 --> Final output sent to browser
DEBUG - 2021-01-16 01:18:50 --> Total execution time: 0.2236
INFO - 2021-01-16 01:18:51 --> Config Class Initialized
INFO - 2021-01-16 01:18:51 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:18:51 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:18:51 --> Utf8 Class Initialized
INFO - 2021-01-16 01:18:51 --> URI Class Initialized
INFO - 2021-01-16 01:18:51 --> Router Class Initialized
INFO - 2021-01-16 01:18:51 --> Output Class Initialized
INFO - 2021-01-16 01:18:51 --> Security Class Initialized
DEBUG - 2021-01-16 01:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:18:51 --> Input Class Initialized
INFO - 2021-01-16 01:18:51 --> Language Class Initialized
INFO - 2021-01-16 01:18:51 --> Language Class Initialized
INFO - 2021-01-16 01:18:51 --> Config Class Initialized
INFO - 2021-01-16 01:18:51 --> Loader Class Initialized
INFO - 2021-01-16 01:18:51 --> Helper loaded: url_helper
INFO - 2021-01-16 01:18:51 --> Helper loaded: file_helper
INFO - 2021-01-16 01:18:51 --> Helper loaded: form_helper
INFO - 2021-01-16 01:18:51 --> Helper loaded: my_helper
INFO - 2021-01-16 01:18:51 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:18:51 --> Controller Class Initialized
INFO - 2021-01-16 01:18:53 --> Config Class Initialized
INFO - 2021-01-16 01:18:53 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:18:53 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:18:53 --> Utf8 Class Initialized
INFO - 2021-01-16 01:18:53 --> URI Class Initialized
INFO - 2021-01-16 01:18:53 --> Router Class Initialized
INFO - 2021-01-16 01:18:53 --> Output Class Initialized
INFO - 2021-01-16 01:18:53 --> Security Class Initialized
DEBUG - 2021-01-16 01:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:18:53 --> Input Class Initialized
INFO - 2021-01-16 01:18:53 --> Language Class Initialized
INFO - 2021-01-16 01:18:53 --> Language Class Initialized
INFO - 2021-01-16 01:18:53 --> Config Class Initialized
INFO - 2021-01-16 01:18:53 --> Loader Class Initialized
INFO - 2021-01-16 01:18:53 --> Helper loaded: url_helper
INFO - 2021-01-16 01:18:53 --> Helper loaded: file_helper
INFO - 2021-01-16 01:18:53 --> Helper loaded: form_helper
INFO - 2021-01-16 01:18:53 --> Helper loaded: my_helper
INFO - 2021-01-16 01:18:54 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:18:54 --> Controller Class Initialized
INFO - 2021-01-16 01:18:54 --> Final output sent to browser
DEBUG - 2021-01-16 01:18:54 --> Total execution time: 0.2963
INFO - 2021-01-16 01:18:58 --> Config Class Initialized
INFO - 2021-01-16 01:18:58 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:18:58 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:18:58 --> Utf8 Class Initialized
INFO - 2021-01-16 01:18:58 --> URI Class Initialized
INFO - 2021-01-16 01:18:58 --> Router Class Initialized
INFO - 2021-01-16 01:18:58 --> Output Class Initialized
INFO - 2021-01-16 01:18:58 --> Security Class Initialized
DEBUG - 2021-01-16 01:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:18:58 --> Input Class Initialized
INFO - 2021-01-16 01:18:58 --> Language Class Initialized
INFO - 2021-01-16 01:18:58 --> Language Class Initialized
INFO - 2021-01-16 01:18:58 --> Config Class Initialized
INFO - 2021-01-16 01:18:58 --> Loader Class Initialized
INFO - 2021-01-16 01:18:58 --> Helper loaded: url_helper
INFO - 2021-01-16 01:18:58 --> Helper loaded: file_helper
INFO - 2021-01-16 01:18:58 --> Helper loaded: form_helper
INFO - 2021-01-16 01:18:58 --> Helper loaded: my_helper
INFO - 2021-01-16 01:18:58 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:18:58 --> Controller Class Initialized
INFO - 2021-01-16 01:18:58 --> Final output sent to browser
DEBUG - 2021-01-16 01:18:58 --> Total execution time: 0.2205
INFO - 2021-01-16 01:18:58 --> Config Class Initialized
INFO - 2021-01-16 01:18:58 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:18:58 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:18:58 --> Utf8 Class Initialized
INFO - 2021-01-16 01:18:58 --> URI Class Initialized
INFO - 2021-01-16 01:18:58 --> Router Class Initialized
INFO - 2021-01-16 01:18:58 --> Output Class Initialized
INFO - 2021-01-16 01:18:58 --> Security Class Initialized
DEBUG - 2021-01-16 01:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:18:58 --> Input Class Initialized
INFO - 2021-01-16 01:18:58 --> Language Class Initialized
INFO - 2021-01-16 01:18:58 --> Language Class Initialized
INFO - 2021-01-16 01:18:58 --> Config Class Initialized
INFO - 2021-01-16 01:18:58 --> Loader Class Initialized
INFO - 2021-01-16 01:18:58 --> Helper loaded: url_helper
INFO - 2021-01-16 01:18:58 --> Helper loaded: file_helper
INFO - 2021-01-16 01:18:58 --> Helper loaded: form_helper
INFO - 2021-01-16 01:18:58 --> Helper loaded: my_helper
INFO - 2021-01-16 01:18:58 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:18:58 --> Controller Class Initialized
INFO - 2021-01-16 01:19:01 --> Config Class Initialized
INFO - 2021-01-16 01:19:01 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:19:01 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:19:01 --> Utf8 Class Initialized
INFO - 2021-01-16 01:19:01 --> URI Class Initialized
INFO - 2021-01-16 01:19:01 --> Router Class Initialized
INFO - 2021-01-16 01:19:01 --> Output Class Initialized
INFO - 2021-01-16 01:19:01 --> Security Class Initialized
DEBUG - 2021-01-16 01:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:19:01 --> Input Class Initialized
INFO - 2021-01-16 01:19:01 --> Language Class Initialized
INFO - 2021-01-16 01:19:01 --> Language Class Initialized
INFO - 2021-01-16 01:19:01 --> Config Class Initialized
INFO - 2021-01-16 01:19:01 --> Loader Class Initialized
INFO - 2021-01-16 01:19:01 --> Helper loaded: url_helper
INFO - 2021-01-16 01:19:01 --> Helper loaded: file_helper
INFO - 2021-01-16 01:19:01 --> Helper loaded: form_helper
INFO - 2021-01-16 01:19:02 --> Helper loaded: my_helper
INFO - 2021-01-16 01:19:02 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:19:02 --> Controller Class Initialized
INFO - 2021-01-16 01:19:02 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:19:02 --> Config Class Initialized
INFO - 2021-01-16 01:19:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:19:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:19:02 --> Utf8 Class Initialized
INFO - 2021-01-16 01:19:02 --> URI Class Initialized
INFO - 2021-01-16 01:19:02 --> Router Class Initialized
INFO - 2021-01-16 01:19:02 --> Output Class Initialized
INFO - 2021-01-16 01:19:02 --> Security Class Initialized
DEBUG - 2021-01-16 01:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:19:02 --> Input Class Initialized
INFO - 2021-01-16 01:19:02 --> Language Class Initialized
INFO - 2021-01-16 01:19:02 --> Language Class Initialized
INFO - 2021-01-16 01:19:02 --> Config Class Initialized
INFO - 2021-01-16 01:19:02 --> Loader Class Initialized
INFO - 2021-01-16 01:19:02 --> Helper loaded: url_helper
INFO - 2021-01-16 01:19:02 --> Helper loaded: file_helper
INFO - 2021-01-16 01:19:02 --> Helper loaded: form_helper
INFO - 2021-01-16 01:19:02 --> Helper loaded: my_helper
INFO - 2021-01-16 01:19:02 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:19:02 --> Controller Class Initialized
DEBUG - 2021-01-16 01:19:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 01:19:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:19:02 --> Final output sent to browser
DEBUG - 2021-01-16 01:19:02 --> Total execution time: 0.2100
INFO - 2021-01-16 01:19:16 --> Config Class Initialized
INFO - 2021-01-16 01:19:16 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:19:16 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:19:16 --> Utf8 Class Initialized
INFO - 2021-01-16 01:19:16 --> URI Class Initialized
INFO - 2021-01-16 01:19:16 --> Router Class Initialized
INFO - 2021-01-16 01:19:16 --> Output Class Initialized
INFO - 2021-01-16 01:19:16 --> Security Class Initialized
DEBUG - 2021-01-16 01:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:19:16 --> Input Class Initialized
INFO - 2021-01-16 01:19:16 --> Language Class Initialized
INFO - 2021-01-16 01:19:16 --> Language Class Initialized
INFO - 2021-01-16 01:19:16 --> Config Class Initialized
INFO - 2021-01-16 01:19:16 --> Loader Class Initialized
INFO - 2021-01-16 01:19:16 --> Helper loaded: url_helper
INFO - 2021-01-16 01:19:16 --> Helper loaded: file_helper
INFO - 2021-01-16 01:19:16 --> Helper loaded: form_helper
INFO - 2021-01-16 01:19:16 --> Helper loaded: my_helper
INFO - 2021-01-16 01:19:16 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:19:16 --> Controller Class Initialized
INFO - 2021-01-16 01:19:16 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:19:16 --> Final output sent to browser
DEBUG - 2021-01-16 01:19:16 --> Total execution time: 0.2872
INFO - 2021-01-16 01:19:16 --> Config Class Initialized
INFO - 2021-01-16 01:19:16 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:19:16 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:19:16 --> Utf8 Class Initialized
INFO - 2021-01-16 01:19:16 --> URI Class Initialized
INFO - 2021-01-16 01:19:17 --> Router Class Initialized
INFO - 2021-01-16 01:19:17 --> Output Class Initialized
INFO - 2021-01-16 01:19:17 --> Security Class Initialized
DEBUG - 2021-01-16 01:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:19:17 --> Input Class Initialized
INFO - 2021-01-16 01:19:17 --> Language Class Initialized
INFO - 2021-01-16 01:19:17 --> Language Class Initialized
INFO - 2021-01-16 01:19:17 --> Config Class Initialized
INFO - 2021-01-16 01:19:17 --> Loader Class Initialized
INFO - 2021-01-16 01:19:17 --> Helper loaded: url_helper
INFO - 2021-01-16 01:19:17 --> Helper loaded: file_helper
INFO - 2021-01-16 01:19:17 --> Helper loaded: form_helper
INFO - 2021-01-16 01:19:17 --> Helper loaded: my_helper
INFO - 2021-01-16 01:19:17 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:19:17 --> Controller Class Initialized
DEBUG - 2021-01-16 01:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 01:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:19:17 --> Final output sent to browser
DEBUG - 2021-01-16 01:19:17 --> Total execution time: 0.3629
INFO - 2021-01-16 01:19:18 --> Config Class Initialized
INFO - 2021-01-16 01:19:18 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:19:18 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:19:18 --> Utf8 Class Initialized
INFO - 2021-01-16 01:19:18 --> URI Class Initialized
INFO - 2021-01-16 01:19:18 --> Router Class Initialized
INFO - 2021-01-16 01:19:18 --> Output Class Initialized
INFO - 2021-01-16 01:19:18 --> Security Class Initialized
DEBUG - 2021-01-16 01:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:19:18 --> Input Class Initialized
INFO - 2021-01-16 01:19:18 --> Language Class Initialized
INFO - 2021-01-16 01:19:18 --> Language Class Initialized
INFO - 2021-01-16 01:19:18 --> Config Class Initialized
INFO - 2021-01-16 01:19:18 --> Loader Class Initialized
INFO - 2021-01-16 01:19:18 --> Helper loaded: url_helper
INFO - 2021-01-16 01:19:18 --> Helper loaded: file_helper
INFO - 2021-01-16 01:19:18 --> Helper loaded: form_helper
INFO - 2021-01-16 01:19:18 --> Helper loaded: my_helper
INFO - 2021-01-16 01:19:19 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:19:19 --> Controller Class Initialized
DEBUG - 2021-01-16 01:19:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-16 01:19:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:19:19 --> Final output sent to browser
DEBUG - 2021-01-16 01:19:19 --> Total execution time: 0.2650
INFO - 2021-01-16 01:19:19 --> Config Class Initialized
INFO - 2021-01-16 01:19:19 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:19:19 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:19:19 --> Utf8 Class Initialized
INFO - 2021-01-16 01:19:19 --> URI Class Initialized
INFO - 2021-01-16 01:19:19 --> Router Class Initialized
INFO - 2021-01-16 01:19:19 --> Output Class Initialized
INFO - 2021-01-16 01:19:19 --> Security Class Initialized
DEBUG - 2021-01-16 01:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:19:19 --> Input Class Initialized
INFO - 2021-01-16 01:19:19 --> Language Class Initialized
INFO - 2021-01-16 01:19:19 --> Language Class Initialized
INFO - 2021-01-16 01:19:19 --> Config Class Initialized
INFO - 2021-01-16 01:19:19 --> Loader Class Initialized
INFO - 2021-01-16 01:19:19 --> Helper loaded: url_helper
INFO - 2021-01-16 01:19:19 --> Helper loaded: file_helper
INFO - 2021-01-16 01:19:19 --> Helper loaded: form_helper
INFO - 2021-01-16 01:19:19 --> Helper loaded: my_helper
INFO - 2021-01-16 01:19:19 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:19:19 --> Controller Class Initialized
DEBUG - 2021-01-16 01:19:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-16 01:19:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:19:19 --> Final output sent to browser
DEBUG - 2021-01-16 01:19:20 --> Total execution time: 0.2790
INFO - 2021-01-16 01:19:21 --> Config Class Initialized
INFO - 2021-01-16 01:19:21 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:19:21 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:19:21 --> Utf8 Class Initialized
INFO - 2021-01-16 01:19:21 --> URI Class Initialized
INFO - 2021-01-16 01:19:21 --> Router Class Initialized
INFO - 2021-01-16 01:19:21 --> Output Class Initialized
INFO - 2021-01-16 01:19:21 --> Security Class Initialized
DEBUG - 2021-01-16 01:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:19:21 --> Input Class Initialized
INFO - 2021-01-16 01:19:21 --> Language Class Initialized
INFO - 2021-01-16 01:19:21 --> Language Class Initialized
INFO - 2021-01-16 01:19:21 --> Config Class Initialized
INFO - 2021-01-16 01:19:21 --> Loader Class Initialized
INFO - 2021-01-16 01:19:21 --> Helper loaded: url_helper
INFO - 2021-01-16 01:19:21 --> Helper loaded: file_helper
INFO - 2021-01-16 01:19:21 --> Helper loaded: form_helper
INFO - 2021-01-16 01:19:21 --> Helper loaded: my_helper
INFO - 2021-01-16 01:19:21 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:19:22 --> Controller Class Initialized
ERROR - 2021-01-16 01:19:22 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2904
ERROR - 2021-01-16 01:19:22 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2904
ERROR - 2021-01-16 01:19:22 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2906
ERROR - 2021-01-16 01:19:22 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2907
ERROR - 2021-01-16 01:19:22 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
ERROR - 2021-01-16 01:19:22 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
ERROR - 2021-01-16 01:19:22 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 2908
DEBUG - 2021-01-16 01:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-16 01:19:22 --> Final output sent to browser
DEBUG - 2021-01-16 01:19:22 --> Total execution time: 0.3445
INFO - 2021-01-16 01:19:45 --> Config Class Initialized
INFO - 2021-01-16 01:19:45 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:19:45 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:19:45 --> Utf8 Class Initialized
INFO - 2021-01-16 01:19:45 --> URI Class Initialized
INFO - 2021-01-16 01:19:45 --> Router Class Initialized
INFO - 2021-01-16 01:19:45 --> Output Class Initialized
INFO - 2021-01-16 01:19:45 --> Security Class Initialized
DEBUG - 2021-01-16 01:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:19:45 --> Input Class Initialized
INFO - 2021-01-16 01:19:45 --> Language Class Initialized
INFO - 2021-01-16 01:19:45 --> Language Class Initialized
INFO - 2021-01-16 01:19:45 --> Config Class Initialized
INFO - 2021-01-16 01:19:45 --> Loader Class Initialized
INFO - 2021-01-16 01:19:45 --> Helper loaded: url_helper
INFO - 2021-01-16 01:19:45 --> Helper loaded: file_helper
INFO - 2021-01-16 01:19:45 --> Helper loaded: form_helper
INFO - 2021-01-16 01:19:45 --> Helper loaded: my_helper
INFO - 2021-01-16 01:19:45 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:19:46 --> Controller Class Initialized
ERROR - 2021-01-16 01:19:46 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 3333
ERROR - 2021-01-16 01:19:46 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 3333
ERROR - 2021-01-16 01:19:46 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 3335
ERROR - 2021-01-16 01:19:46 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 3336
ERROR - 2021-01-16 01:19:46 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 3337
ERROR - 2021-01-16 01:19:46 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 3337
ERROR - 2021-01-16 01:19:46 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 3337
DEBUG - 2021-01-16 01:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 01:19:46 --> Final output sent to browser
DEBUG - 2021-01-16 01:19:46 --> Total execution time: 0.3526
INFO - 2021-01-16 01:20:33 --> Config Class Initialized
INFO - 2021-01-16 01:20:33 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:20:33 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:20:33 --> Utf8 Class Initialized
INFO - 2021-01-16 01:20:33 --> URI Class Initialized
INFO - 2021-01-16 01:20:33 --> Router Class Initialized
INFO - 2021-01-16 01:20:33 --> Output Class Initialized
INFO - 2021-01-16 01:20:33 --> Security Class Initialized
DEBUG - 2021-01-16 01:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:20:33 --> Input Class Initialized
INFO - 2021-01-16 01:20:33 --> Language Class Initialized
INFO - 2021-01-16 01:20:33 --> Language Class Initialized
INFO - 2021-01-16 01:20:33 --> Config Class Initialized
INFO - 2021-01-16 01:20:33 --> Loader Class Initialized
INFO - 2021-01-16 01:20:33 --> Helper loaded: url_helper
INFO - 2021-01-16 01:20:33 --> Helper loaded: file_helper
INFO - 2021-01-16 01:20:33 --> Helper loaded: form_helper
INFO - 2021-01-16 01:20:33 --> Helper loaded: my_helper
INFO - 2021-01-16 01:20:33 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:20:33 --> Controller Class Initialized
INFO - 2021-01-16 01:20:33 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:20:33 --> Config Class Initialized
INFO - 2021-01-16 01:20:33 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:20:33 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:20:33 --> Utf8 Class Initialized
INFO - 2021-01-16 01:20:33 --> URI Class Initialized
INFO - 2021-01-16 01:20:33 --> Router Class Initialized
INFO - 2021-01-16 01:20:33 --> Output Class Initialized
INFO - 2021-01-16 01:20:33 --> Security Class Initialized
DEBUG - 2021-01-16 01:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:20:33 --> Input Class Initialized
INFO - 2021-01-16 01:20:33 --> Language Class Initialized
INFO - 2021-01-16 01:20:33 --> Language Class Initialized
INFO - 2021-01-16 01:20:33 --> Config Class Initialized
INFO - 2021-01-16 01:20:33 --> Loader Class Initialized
INFO - 2021-01-16 01:20:33 --> Helper loaded: url_helper
INFO - 2021-01-16 01:20:33 --> Helper loaded: file_helper
INFO - 2021-01-16 01:20:33 --> Helper loaded: form_helper
INFO - 2021-01-16 01:20:33 --> Helper loaded: my_helper
INFO - 2021-01-16 01:20:33 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:20:33 --> Controller Class Initialized
DEBUG - 2021-01-16 01:20:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 01:20:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:20:33 --> Final output sent to browser
DEBUG - 2021-01-16 01:20:33 --> Total execution time: 0.2263
INFO - 2021-01-16 01:20:38 --> Config Class Initialized
INFO - 2021-01-16 01:20:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:20:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:20:38 --> Utf8 Class Initialized
INFO - 2021-01-16 01:20:38 --> URI Class Initialized
INFO - 2021-01-16 01:20:38 --> Router Class Initialized
INFO - 2021-01-16 01:20:38 --> Output Class Initialized
INFO - 2021-01-16 01:20:38 --> Security Class Initialized
DEBUG - 2021-01-16 01:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:20:38 --> Input Class Initialized
INFO - 2021-01-16 01:20:38 --> Language Class Initialized
INFO - 2021-01-16 01:20:38 --> Language Class Initialized
INFO - 2021-01-16 01:20:38 --> Config Class Initialized
INFO - 2021-01-16 01:20:38 --> Loader Class Initialized
INFO - 2021-01-16 01:20:38 --> Helper loaded: url_helper
INFO - 2021-01-16 01:20:38 --> Helper loaded: file_helper
INFO - 2021-01-16 01:20:38 --> Helper loaded: form_helper
INFO - 2021-01-16 01:20:38 --> Helper loaded: my_helper
INFO - 2021-01-16 01:20:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:20:38 --> Controller Class Initialized
INFO - 2021-01-16 01:20:38 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:20:38 --> Final output sent to browser
DEBUG - 2021-01-16 01:20:38 --> Total execution time: 0.2998
INFO - 2021-01-16 01:20:40 --> Config Class Initialized
INFO - 2021-01-16 01:20:40 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:20:40 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:20:40 --> Utf8 Class Initialized
INFO - 2021-01-16 01:20:40 --> URI Class Initialized
INFO - 2021-01-16 01:20:40 --> Router Class Initialized
INFO - 2021-01-16 01:20:40 --> Output Class Initialized
INFO - 2021-01-16 01:20:40 --> Security Class Initialized
DEBUG - 2021-01-16 01:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:20:40 --> Input Class Initialized
INFO - 2021-01-16 01:20:40 --> Language Class Initialized
INFO - 2021-01-16 01:20:40 --> Language Class Initialized
INFO - 2021-01-16 01:20:40 --> Config Class Initialized
INFO - 2021-01-16 01:20:40 --> Loader Class Initialized
INFO - 2021-01-16 01:20:40 --> Helper loaded: url_helper
INFO - 2021-01-16 01:20:40 --> Helper loaded: file_helper
INFO - 2021-01-16 01:20:40 --> Helper loaded: form_helper
INFO - 2021-01-16 01:20:40 --> Helper loaded: my_helper
INFO - 2021-01-16 01:20:40 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:20:40 --> Controller Class Initialized
DEBUG - 2021-01-16 01:20:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 01:20:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:20:40 --> Final output sent to browser
DEBUG - 2021-01-16 01:20:40 --> Total execution time: 0.3210
INFO - 2021-01-16 01:20:42 --> Config Class Initialized
INFO - 2021-01-16 01:20:42 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:20:43 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:20:43 --> Utf8 Class Initialized
INFO - 2021-01-16 01:20:43 --> URI Class Initialized
INFO - 2021-01-16 01:20:43 --> Router Class Initialized
INFO - 2021-01-16 01:20:43 --> Output Class Initialized
INFO - 2021-01-16 01:20:43 --> Security Class Initialized
DEBUG - 2021-01-16 01:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:20:43 --> Input Class Initialized
INFO - 2021-01-16 01:20:43 --> Language Class Initialized
INFO - 2021-01-16 01:20:43 --> Language Class Initialized
INFO - 2021-01-16 01:20:43 --> Config Class Initialized
INFO - 2021-01-16 01:20:43 --> Loader Class Initialized
INFO - 2021-01-16 01:20:43 --> Helper loaded: url_helper
INFO - 2021-01-16 01:20:43 --> Helper loaded: file_helper
INFO - 2021-01-16 01:20:43 --> Helper loaded: form_helper
INFO - 2021-01-16 01:20:43 --> Helper loaded: my_helper
INFO - 2021-01-16 01:20:43 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:20:43 --> Controller Class Initialized
DEBUG - 2021-01-16 01:20:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-16 01:20:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:20:43 --> Final output sent to browser
DEBUG - 2021-01-16 01:20:43 --> Total execution time: 0.2451
INFO - 2021-01-16 01:20:46 --> Config Class Initialized
INFO - 2021-01-16 01:20:47 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:20:47 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:20:47 --> Utf8 Class Initialized
INFO - 2021-01-16 01:20:47 --> URI Class Initialized
INFO - 2021-01-16 01:20:47 --> Router Class Initialized
INFO - 2021-01-16 01:20:47 --> Output Class Initialized
INFO - 2021-01-16 01:20:47 --> Security Class Initialized
DEBUG - 2021-01-16 01:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:20:47 --> Input Class Initialized
INFO - 2021-01-16 01:20:47 --> Language Class Initialized
INFO - 2021-01-16 01:20:47 --> Language Class Initialized
INFO - 2021-01-16 01:20:47 --> Config Class Initialized
INFO - 2021-01-16 01:20:47 --> Loader Class Initialized
INFO - 2021-01-16 01:20:47 --> Helper loaded: url_helper
INFO - 2021-01-16 01:20:47 --> Helper loaded: file_helper
INFO - 2021-01-16 01:20:47 --> Helper loaded: form_helper
INFO - 2021-01-16 01:20:47 --> Helper loaded: my_helper
INFO - 2021-01-16 01:20:47 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:20:47 --> Controller Class Initialized
ERROR - 2021-01-16 01:20:47 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4103
ERROR - 2021-01-16 01:20:47 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4103
ERROR - 2021-01-16 01:20:47 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4105
ERROR - 2021-01-16 01:20:47 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4106
ERROR - 2021-01-16 01:20:47 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4107
ERROR - 2021-01-16 01:20:47 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4107
ERROR - 2021-01-16 01:20:47 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4107
DEBUG - 2021-01-16 01:20:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-16 01:20:47 --> Final output sent to browser
DEBUG - 2021-01-16 01:20:47 --> Total execution time: 0.3329
INFO - 2021-01-16 01:21:13 --> Config Class Initialized
INFO - 2021-01-16 01:21:13 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:21:13 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:21:13 --> Utf8 Class Initialized
INFO - 2021-01-16 01:21:14 --> URI Class Initialized
INFO - 2021-01-16 01:21:14 --> Router Class Initialized
INFO - 2021-01-16 01:21:14 --> Output Class Initialized
INFO - 2021-01-16 01:21:14 --> Security Class Initialized
DEBUG - 2021-01-16 01:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:21:14 --> Input Class Initialized
INFO - 2021-01-16 01:21:14 --> Language Class Initialized
INFO - 2021-01-16 01:21:14 --> Language Class Initialized
INFO - 2021-01-16 01:21:14 --> Config Class Initialized
INFO - 2021-01-16 01:21:14 --> Loader Class Initialized
INFO - 2021-01-16 01:21:14 --> Helper loaded: url_helper
INFO - 2021-01-16 01:21:14 --> Helper loaded: file_helper
INFO - 2021-01-16 01:21:14 --> Helper loaded: form_helper
INFO - 2021-01-16 01:21:14 --> Helper loaded: my_helper
INFO - 2021-01-16 01:21:14 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:21:14 --> Controller Class Initialized
INFO - 2021-01-16 01:21:14 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:21:14 --> Config Class Initialized
INFO - 2021-01-16 01:21:14 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:21:14 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:21:14 --> Utf8 Class Initialized
INFO - 2021-01-16 01:21:14 --> URI Class Initialized
INFO - 2021-01-16 01:21:14 --> Router Class Initialized
INFO - 2021-01-16 01:21:14 --> Output Class Initialized
INFO - 2021-01-16 01:21:14 --> Security Class Initialized
DEBUG - 2021-01-16 01:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:21:14 --> Input Class Initialized
INFO - 2021-01-16 01:21:14 --> Language Class Initialized
INFO - 2021-01-16 01:21:14 --> Language Class Initialized
INFO - 2021-01-16 01:21:14 --> Config Class Initialized
INFO - 2021-01-16 01:21:14 --> Loader Class Initialized
INFO - 2021-01-16 01:21:14 --> Helper loaded: url_helper
INFO - 2021-01-16 01:21:14 --> Helper loaded: file_helper
INFO - 2021-01-16 01:21:14 --> Helper loaded: form_helper
INFO - 2021-01-16 01:21:14 --> Helper loaded: my_helper
INFO - 2021-01-16 01:21:14 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:21:14 --> Controller Class Initialized
DEBUG - 2021-01-16 01:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 01:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:21:14 --> Final output sent to browser
DEBUG - 2021-01-16 01:21:14 --> Total execution time: 0.2988
INFO - 2021-01-16 01:21:18 --> Config Class Initialized
INFO - 2021-01-16 01:21:18 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:21:18 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:21:18 --> Utf8 Class Initialized
INFO - 2021-01-16 01:21:18 --> URI Class Initialized
INFO - 2021-01-16 01:21:18 --> Router Class Initialized
INFO - 2021-01-16 01:21:18 --> Output Class Initialized
INFO - 2021-01-16 01:21:18 --> Security Class Initialized
DEBUG - 2021-01-16 01:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:21:18 --> Input Class Initialized
INFO - 2021-01-16 01:21:18 --> Language Class Initialized
INFO - 2021-01-16 01:21:18 --> Language Class Initialized
INFO - 2021-01-16 01:21:18 --> Config Class Initialized
INFO - 2021-01-16 01:21:18 --> Loader Class Initialized
INFO - 2021-01-16 01:21:18 --> Helper loaded: url_helper
INFO - 2021-01-16 01:21:18 --> Helper loaded: file_helper
INFO - 2021-01-16 01:21:18 --> Helper loaded: form_helper
INFO - 2021-01-16 01:21:18 --> Helper loaded: my_helper
INFO - 2021-01-16 01:21:18 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:21:18 --> Controller Class Initialized
INFO - 2021-01-16 01:21:18 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:21:18 --> Final output sent to browser
DEBUG - 2021-01-16 01:21:18 --> Total execution time: 0.3265
INFO - 2021-01-16 01:21:19 --> Config Class Initialized
INFO - 2021-01-16 01:21:19 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:21:19 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:21:19 --> Utf8 Class Initialized
INFO - 2021-01-16 01:21:19 --> URI Class Initialized
INFO - 2021-01-16 01:21:19 --> Router Class Initialized
INFO - 2021-01-16 01:21:19 --> Output Class Initialized
INFO - 2021-01-16 01:21:19 --> Security Class Initialized
DEBUG - 2021-01-16 01:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:21:19 --> Input Class Initialized
INFO - 2021-01-16 01:21:19 --> Language Class Initialized
INFO - 2021-01-16 01:21:19 --> Language Class Initialized
INFO - 2021-01-16 01:21:19 --> Config Class Initialized
INFO - 2021-01-16 01:21:19 --> Loader Class Initialized
INFO - 2021-01-16 01:21:19 --> Helper loaded: url_helper
INFO - 2021-01-16 01:21:19 --> Helper loaded: file_helper
INFO - 2021-01-16 01:21:19 --> Helper loaded: form_helper
INFO - 2021-01-16 01:21:19 --> Helper loaded: my_helper
INFO - 2021-01-16 01:21:19 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:21:19 --> Controller Class Initialized
DEBUG - 2021-01-16 01:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 01:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:21:19 --> Final output sent to browser
DEBUG - 2021-01-16 01:21:19 --> Total execution time: 0.3626
INFO - 2021-01-16 01:21:23 --> Config Class Initialized
INFO - 2021-01-16 01:21:23 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:21:23 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:21:23 --> Utf8 Class Initialized
INFO - 2021-01-16 01:21:23 --> URI Class Initialized
INFO - 2021-01-16 01:21:23 --> Router Class Initialized
INFO - 2021-01-16 01:21:23 --> Output Class Initialized
INFO - 2021-01-16 01:21:23 --> Security Class Initialized
DEBUG - 2021-01-16 01:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:21:23 --> Input Class Initialized
INFO - 2021-01-16 01:21:23 --> Language Class Initialized
INFO - 2021-01-16 01:21:23 --> Language Class Initialized
INFO - 2021-01-16 01:21:23 --> Config Class Initialized
INFO - 2021-01-16 01:21:23 --> Loader Class Initialized
INFO - 2021-01-16 01:21:23 --> Helper loaded: url_helper
INFO - 2021-01-16 01:21:23 --> Helper loaded: file_helper
INFO - 2021-01-16 01:21:23 --> Helper loaded: form_helper
INFO - 2021-01-16 01:21:23 --> Helper loaded: my_helper
INFO - 2021-01-16 01:21:23 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:21:23 --> Controller Class Initialized
DEBUG - 2021-01-16 01:21:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-16 01:21:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:21:23 --> Final output sent to browser
DEBUG - 2021-01-16 01:21:23 --> Total execution time: 0.2945
INFO - 2021-01-16 01:21:24 --> Config Class Initialized
INFO - 2021-01-16 01:21:24 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:21:24 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:21:24 --> Utf8 Class Initialized
INFO - 2021-01-16 01:21:24 --> URI Class Initialized
INFO - 2021-01-16 01:21:24 --> Router Class Initialized
INFO - 2021-01-16 01:21:24 --> Output Class Initialized
INFO - 2021-01-16 01:21:24 --> Security Class Initialized
DEBUG - 2021-01-16 01:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:21:24 --> Input Class Initialized
INFO - 2021-01-16 01:21:24 --> Language Class Initialized
INFO - 2021-01-16 01:21:24 --> Language Class Initialized
INFO - 2021-01-16 01:21:24 --> Config Class Initialized
INFO - 2021-01-16 01:21:24 --> Loader Class Initialized
INFO - 2021-01-16 01:21:24 --> Helper loaded: url_helper
INFO - 2021-01-16 01:21:24 --> Helper loaded: file_helper
INFO - 2021-01-16 01:21:24 --> Helper loaded: form_helper
INFO - 2021-01-16 01:21:24 --> Helper loaded: my_helper
INFO - 2021-01-16 01:21:24 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:21:25 --> Controller Class Initialized
ERROR - 2021-01-16 01:21:25 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4489
ERROR - 2021-01-16 01:21:25 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4489
ERROR - 2021-01-16 01:21:25 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4491
ERROR - 2021-01-16 01:21:25 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4492
ERROR - 2021-01-16 01:21:25 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4493
ERROR - 2021-01-16 01:21:25 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4493
ERROR - 2021-01-16 01:21:25 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4493
DEBUG - 2021-01-16 01:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:21:25 --> Final output sent to browser
DEBUG - 2021-01-16 01:21:25 --> Total execution time: 0.3102
INFO - 2021-01-16 01:31:07 --> Config Class Initialized
INFO - 2021-01-16 01:31:07 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:31:07 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:31:07 --> Utf8 Class Initialized
INFO - 2021-01-16 01:31:07 --> URI Class Initialized
INFO - 2021-01-16 01:31:07 --> Router Class Initialized
INFO - 2021-01-16 01:31:07 --> Output Class Initialized
INFO - 2021-01-16 01:31:07 --> Security Class Initialized
DEBUG - 2021-01-16 01:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:31:07 --> Input Class Initialized
INFO - 2021-01-16 01:31:07 --> Language Class Initialized
INFO - 2021-01-16 01:31:07 --> Language Class Initialized
INFO - 2021-01-16 01:31:07 --> Config Class Initialized
INFO - 2021-01-16 01:31:07 --> Loader Class Initialized
INFO - 2021-01-16 01:31:07 --> Helper loaded: url_helper
INFO - 2021-01-16 01:31:07 --> Helper loaded: file_helper
INFO - 2021-01-16 01:31:07 --> Helper loaded: form_helper
INFO - 2021-01-16 01:31:07 --> Helper loaded: my_helper
INFO - 2021-01-16 01:31:07 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:31:07 --> Controller Class Initialized
ERROR - 2021-01-16 01:31:07 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4489
ERROR - 2021-01-16 01:31:07 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4489
ERROR - 2021-01-16 01:31:07 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4491
ERROR - 2021-01-16 01:31:07 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4492
ERROR - 2021-01-16 01:31:07 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4493
ERROR - 2021-01-16 01:31:07 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4493
ERROR - 2021-01-16 01:31:07 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4493
DEBUG - 2021-01-16 01:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:31:08 --> Final output sent to browser
DEBUG - 2021-01-16 01:31:08 --> Total execution time: 0.3431
INFO - 2021-01-16 01:31:38 --> Config Class Initialized
INFO - 2021-01-16 01:31:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:31:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:31:38 --> Utf8 Class Initialized
INFO - 2021-01-16 01:31:38 --> URI Class Initialized
INFO - 2021-01-16 01:31:38 --> Router Class Initialized
INFO - 2021-01-16 01:31:38 --> Output Class Initialized
INFO - 2021-01-16 01:31:38 --> Security Class Initialized
DEBUG - 2021-01-16 01:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:31:38 --> Input Class Initialized
INFO - 2021-01-16 01:31:38 --> Language Class Initialized
INFO - 2021-01-16 01:31:38 --> Language Class Initialized
INFO - 2021-01-16 01:31:38 --> Config Class Initialized
INFO - 2021-01-16 01:31:38 --> Loader Class Initialized
INFO - 2021-01-16 01:31:38 --> Helper loaded: url_helper
INFO - 2021-01-16 01:31:38 --> Helper loaded: file_helper
INFO - 2021-01-16 01:31:38 --> Helper loaded: form_helper
INFO - 2021-01-16 01:31:38 --> Helper loaded: my_helper
INFO - 2021-01-16 01:31:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:31:38 --> Controller Class Initialized
INFO - 2021-01-16 01:31:38 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:31:38 --> Config Class Initialized
INFO - 2021-01-16 01:31:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:31:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:31:38 --> Utf8 Class Initialized
INFO - 2021-01-16 01:31:38 --> URI Class Initialized
INFO - 2021-01-16 01:31:38 --> Router Class Initialized
INFO - 2021-01-16 01:31:38 --> Output Class Initialized
INFO - 2021-01-16 01:31:38 --> Security Class Initialized
DEBUG - 2021-01-16 01:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:31:38 --> Input Class Initialized
INFO - 2021-01-16 01:31:38 --> Language Class Initialized
INFO - 2021-01-16 01:31:38 --> Language Class Initialized
INFO - 2021-01-16 01:31:38 --> Config Class Initialized
INFO - 2021-01-16 01:31:38 --> Loader Class Initialized
INFO - 2021-01-16 01:31:38 --> Helper loaded: url_helper
INFO - 2021-01-16 01:31:38 --> Helper loaded: file_helper
INFO - 2021-01-16 01:31:38 --> Helper loaded: form_helper
INFO - 2021-01-16 01:31:38 --> Helper loaded: my_helper
INFO - 2021-01-16 01:31:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:31:38 --> Controller Class Initialized
DEBUG - 2021-01-16 01:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 01:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:31:38 --> Final output sent to browser
DEBUG - 2021-01-16 01:31:38 --> Total execution time: 0.2559
INFO - 2021-01-16 01:31:43 --> Config Class Initialized
INFO - 2021-01-16 01:31:43 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:31:43 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:31:43 --> Utf8 Class Initialized
INFO - 2021-01-16 01:31:43 --> URI Class Initialized
INFO - 2021-01-16 01:31:43 --> Router Class Initialized
INFO - 2021-01-16 01:31:43 --> Output Class Initialized
INFO - 2021-01-16 01:31:43 --> Security Class Initialized
DEBUG - 2021-01-16 01:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:31:43 --> Input Class Initialized
INFO - 2021-01-16 01:31:43 --> Language Class Initialized
INFO - 2021-01-16 01:31:43 --> Language Class Initialized
INFO - 2021-01-16 01:31:43 --> Config Class Initialized
INFO - 2021-01-16 01:31:43 --> Loader Class Initialized
INFO - 2021-01-16 01:31:43 --> Helper loaded: url_helper
INFO - 2021-01-16 01:31:43 --> Helper loaded: file_helper
INFO - 2021-01-16 01:31:43 --> Helper loaded: form_helper
INFO - 2021-01-16 01:31:43 --> Helper loaded: my_helper
INFO - 2021-01-16 01:31:43 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:31:43 --> Controller Class Initialized
INFO - 2021-01-16 01:31:43 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:31:43 --> Final output sent to browser
DEBUG - 2021-01-16 01:31:43 --> Total execution time: 0.3357
INFO - 2021-01-16 01:31:44 --> Config Class Initialized
INFO - 2021-01-16 01:31:44 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:31:44 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:31:44 --> Utf8 Class Initialized
INFO - 2021-01-16 01:31:44 --> URI Class Initialized
INFO - 2021-01-16 01:31:44 --> Router Class Initialized
INFO - 2021-01-16 01:31:44 --> Output Class Initialized
INFO - 2021-01-16 01:31:44 --> Security Class Initialized
DEBUG - 2021-01-16 01:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:31:44 --> Input Class Initialized
INFO - 2021-01-16 01:31:44 --> Language Class Initialized
INFO - 2021-01-16 01:31:44 --> Language Class Initialized
INFO - 2021-01-16 01:31:44 --> Config Class Initialized
INFO - 2021-01-16 01:31:44 --> Loader Class Initialized
INFO - 2021-01-16 01:31:44 --> Helper loaded: url_helper
INFO - 2021-01-16 01:31:44 --> Helper loaded: file_helper
INFO - 2021-01-16 01:31:44 --> Helper loaded: form_helper
INFO - 2021-01-16 01:31:44 --> Helper loaded: my_helper
INFO - 2021-01-16 01:31:44 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:31:44 --> Controller Class Initialized
DEBUG - 2021-01-16 01:31:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 01:31:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:31:45 --> Final output sent to browser
DEBUG - 2021-01-16 01:31:45 --> Total execution time: 0.4086
INFO - 2021-01-16 01:31:48 --> Config Class Initialized
INFO - 2021-01-16 01:31:48 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:31:48 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:31:48 --> Utf8 Class Initialized
INFO - 2021-01-16 01:31:49 --> URI Class Initialized
INFO - 2021-01-16 01:31:49 --> Router Class Initialized
INFO - 2021-01-16 01:31:49 --> Output Class Initialized
INFO - 2021-01-16 01:31:49 --> Security Class Initialized
DEBUG - 2021-01-16 01:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:31:49 --> Input Class Initialized
INFO - 2021-01-16 01:31:49 --> Language Class Initialized
INFO - 2021-01-16 01:31:49 --> Language Class Initialized
INFO - 2021-01-16 01:31:49 --> Config Class Initialized
INFO - 2021-01-16 01:31:49 --> Loader Class Initialized
INFO - 2021-01-16 01:31:49 --> Helper loaded: url_helper
INFO - 2021-01-16 01:31:49 --> Helper loaded: file_helper
INFO - 2021-01-16 01:31:49 --> Helper loaded: form_helper
INFO - 2021-01-16 01:31:49 --> Helper loaded: my_helper
INFO - 2021-01-16 01:31:49 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:31:49 --> Controller Class Initialized
DEBUG - 2021-01-16 01:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-01-16 01:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:31:49 --> Final output sent to browser
DEBUG - 2021-01-16 01:31:49 --> Total execution time: 0.2699
INFO - 2021-01-16 01:31:49 --> Config Class Initialized
INFO - 2021-01-16 01:31:49 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:31:49 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:31:49 --> Utf8 Class Initialized
INFO - 2021-01-16 01:31:49 --> URI Class Initialized
INFO - 2021-01-16 01:31:49 --> Router Class Initialized
INFO - 2021-01-16 01:31:49 --> Output Class Initialized
INFO - 2021-01-16 01:31:49 --> Security Class Initialized
DEBUG - 2021-01-16 01:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:31:49 --> Input Class Initialized
INFO - 2021-01-16 01:31:49 --> Language Class Initialized
INFO - 2021-01-16 01:31:49 --> Language Class Initialized
INFO - 2021-01-16 01:31:49 --> Config Class Initialized
INFO - 2021-01-16 01:31:49 --> Loader Class Initialized
INFO - 2021-01-16 01:31:49 --> Helper loaded: url_helper
INFO - 2021-01-16 01:31:49 --> Helper loaded: file_helper
INFO - 2021-01-16 01:31:49 --> Helper loaded: form_helper
INFO - 2021-01-16 01:31:49 --> Helper loaded: my_helper
INFO - 2021-01-16 01:31:49 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:31:49 --> Controller Class Initialized
INFO - 2021-01-16 01:31:53 --> Config Class Initialized
INFO - 2021-01-16 01:31:53 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:31:53 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:31:53 --> Utf8 Class Initialized
INFO - 2021-01-16 01:31:53 --> URI Class Initialized
INFO - 2021-01-16 01:31:53 --> Router Class Initialized
INFO - 2021-01-16 01:31:53 --> Output Class Initialized
INFO - 2021-01-16 01:31:53 --> Security Class Initialized
DEBUG - 2021-01-16 01:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:31:53 --> Input Class Initialized
INFO - 2021-01-16 01:31:53 --> Language Class Initialized
INFO - 2021-01-16 01:31:53 --> Language Class Initialized
INFO - 2021-01-16 01:31:53 --> Config Class Initialized
INFO - 2021-01-16 01:31:53 --> Loader Class Initialized
INFO - 2021-01-16 01:31:53 --> Helper loaded: url_helper
INFO - 2021-01-16 01:31:53 --> Helper loaded: file_helper
INFO - 2021-01-16 01:31:53 --> Helper loaded: form_helper
INFO - 2021-01-16 01:31:53 --> Helper loaded: my_helper
INFO - 2021-01-16 01:31:53 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:31:54 --> Controller Class Initialized
INFO - 2021-01-16 01:31:54 --> Final output sent to browser
DEBUG - 2021-01-16 01:31:54 --> Total execution time: 0.2394
INFO - 2021-01-16 01:31:54 --> Config Class Initialized
INFO - 2021-01-16 01:31:54 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:31:54 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:31:54 --> Utf8 Class Initialized
INFO - 2021-01-16 01:31:54 --> URI Class Initialized
INFO - 2021-01-16 01:31:54 --> Router Class Initialized
INFO - 2021-01-16 01:31:54 --> Output Class Initialized
INFO - 2021-01-16 01:31:54 --> Security Class Initialized
DEBUG - 2021-01-16 01:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:31:54 --> Input Class Initialized
INFO - 2021-01-16 01:31:54 --> Language Class Initialized
INFO - 2021-01-16 01:31:54 --> Language Class Initialized
INFO - 2021-01-16 01:31:54 --> Config Class Initialized
INFO - 2021-01-16 01:31:54 --> Loader Class Initialized
INFO - 2021-01-16 01:31:54 --> Helper loaded: url_helper
INFO - 2021-01-16 01:31:54 --> Helper loaded: file_helper
INFO - 2021-01-16 01:31:54 --> Helper loaded: form_helper
INFO - 2021-01-16 01:31:54 --> Helper loaded: my_helper
INFO - 2021-01-16 01:31:54 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:31:54 --> Controller Class Initialized
INFO - 2021-01-16 01:32:10 --> Config Class Initialized
INFO - 2021-01-16 01:32:10 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:32:10 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:32:10 --> Utf8 Class Initialized
INFO - 2021-01-16 01:32:10 --> URI Class Initialized
INFO - 2021-01-16 01:32:10 --> Router Class Initialized
INFO - 2021-01-16 01:32:10 --> Output Class Initialized
INFO - 2021-01-16 01:32:10 --> Security Class Initialized
DEBUG - 2021-01-16 01:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:32:10 --> Input Class Initialized
INFO - 2021-01-16 01:32:10 --> Language Class Initialized
INFO - 2021-01-16 01:32:10 --> Language Class Initialized
INFO - 2021-01-16 01:32:10 --> Config Class Initialized
INFO - 2021-01-16 01:32:10 --> Loader Class Initialized
INFO - 2021-01-16 01:32:10 --> Helper loaded: url_helper
INFO - 2021-01-16 01:32:10 --> Helper loaded: file_helper
INFO - 2021-01-16 01:32:10 --> Helper loaded: form_helper
INFO - 2021-01-16 01:32:10 --> Helper loaded: my_helper
INFO - 2021-01-16 01:32:10 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:32:10 --> Controller Class Initialized
INFO - 2021-01-16 01:32:10 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:32:10 --> Config Class Initialized
INFO - 2021-01-16 01:32:10 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:32:10 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:32:10 --> Utf8 Class Initialized
INFO - 2021-01-16 01:32:10 --> URI Class Initialized
INFO - 2021-01-16 01:32:10 --> Router Class Initialized
INFO - 2021-01-16 01:32:10 --> Output Class Initialized
INFO - 2021-01-16 01:32:10 --> Security Class Initialized
DEBUG - 2021-01-16 01:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:32:10 --> Input Class Initialized
INFO - 2021-01-16 01:32:10 --> Language Class Initialized
INFO - 2021-01-16 01:32:10 --> Language Class Initialized
INFO - 2021-01-16 01:32:10 --> Config Class Initialized
INFO - 2021-01-16 01:32:10 --> Loader Class Initialized
INFO - 2021-01-16 01:32:10 --> Helper loaded: url_helper
INFO - 2021-01-16 01:32:11 --> Helper loaded: file_helper
INFO - 2021-01-16 01:32:11 --> Helper loaded: form_helper
INFO - 2021-01-16 01:32:11 --> Helper loaded: my_helper
INFO - 2021-01-16 01:32:11 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:32:11 --> Controller Class Initialized
DEBUG - 2021-01-16 01:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 01:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:32:11 --> Final output sent to browser
DEBUG - 2021-01-16 01:32:11 --> Total execution time: 0.2583
INFO - 2021-01-16 01:32:19 --> Config Class Initialized
INFO - 2021-01-16 01:32:19 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:32:19 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:32:19 --> Utf8 Class Initialized
INFO - 2021-01-16 01:32:19 --> URI Class Initialized
INFO - 2021-01-16 01:32:19 --> Router Class Initialized
INFO - 2021-01-16 01:32:19 --> Output Class Initialized
INFO - 2021-01-16 01:32:19 --> Security Class Initialized
DEBUG - 2021-01-16 01:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:32:19 --> Input Class Initialized
INFO - 2021-01-16 01:32:19 --> Language Class Initialized
INFO - 2021-01-16 01:32:19 --> Language Class Initialized
INFO - 2021-01-16 01:32:19 --> Config Class Initialized
INFO - 2021-01-16 01:32:19 --> Loader Class Initialized
INFO - 2021-01-16 01:32:19 --> Helper loaded: url_helper
INFO - 2021-01-16 01:32:19 --> Helper loaded: file_helper
INFO - 2021-01-16 01:32:19 --> Helper loaded: form_helper
INFO - 2021-01-16 01:32:19 --> Helper loaded: my_helper
INFO - 2021-01-16 01:32:19 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:32:19 --> Controller Class Initialized
INFO - 2021-01-16 01:32:19 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:32:19 --> Final output sent to browser
DEBUG - 2021-01-16 01:32:19 --> Total execution time: 0.3327
INFO - 2021-01-16 01:32:20 --> Config Class Initialized
INFO - 2021-01-16 01:32:20 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:32:20 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:32:21 --> Utf8 Class Initialized
INFO - 2021-01-16 01:32:21 --> URI Class Initialized
INFO - 2021-01-16 01:32:21 --> Router Class Initialized
INFO - 2021-01-16 01:32:21 --> Output Class Initialized
INFO - 2021-01-16 01:32:21 --> Security Class Initialized
DEBUG - 2021-01-16 01:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:32:21 --> Input Class Initialized
INFO - 2021-01-16 01:32:21 --> Language Class Initialized
INFO - 2021-01-16 01:32:21 --> Language Class Initialized
INFO - 2021-01-16 01:32:21 --> Config Class Initialized
INFO - 2021-01-16 01:32:21 --> Loader Class Initialized
INFO - 2021-01-16 01:32:21 --> Helper loaded: url_helper
INFO - 2021-01-16 01:32:21 --> Helper loaded: file_helper
INFO - 2021-01-16 01:32:21 --> Helper loaded: form_helper
INFO - 2021-01-16 01:32:21 --> Helper loaded: my_helper
INFO - 2021-01-16 01:32:21 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:32:21 --> Controller Class Initialized
DEBUG - 2021-01-16 01:32:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 01:32:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:32:21 --> Final output sent to browser
DEBUG - 2021-01-16 01:32:21 --> Total execution time: 0.3638
INFO - 2021-01-16 01:32:23 --> Config Class Initialized
INFO - 2021-01-16 01:32:23 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:32:23 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:32:23 --> Utf8 Class Initialized
INFO - 2021-01-16 01:32:23 --> URI Class Initialized
INFO - 2021-01-16 01:32:23 --> Router Class Initialized
INFO - 2021-01-16 01:32:23 --> Output Class Initialized
INFO - 2021-01-16 01:32:23 --> Security Class Initialized
DEBUG - 2021-01-16 01:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:32:23 --> Input Class Initialized
INFO - 2021-01-16 01:32:23 --> Language Class Initialized
INFO - 2021-01-16 01:32:23 --> Language Class Initialized
INFO - 2021-01-16 01:32:23 --> Config Class Initialized
INFO - 2021-01-16 01:32:23 --> Loader Class Initialized
INFO - 2021-01-16 01:32:23 --> Helper loaded: url_helper
INFO - 2021-01-16 01:32:23 --> Helper loaded: file_helper
INFO - 2021-01-16 01:32:23 --> Helper loaded: form_helper
INFO - 2021-01-16 01:32:23 --> Helper loaded: my_helper
INFO - 2021-01-16 01:32:23 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:32:23 --> Controller Class Initialized
DEBUG - 2021-01-16 01:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-16 01:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:32:24 --> Final output sent to browser
DEBUG - 2021-01-16 01:32:24 --> Total execution time: 0.2403
INFO - 2021-01-16 01:32:25 --> Config Class Initialized
INFO - 2021-01-16 01:32:25 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:32:25 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:32:25 --> Utf8 Class Initialized
INFO - 2021-01-16 01:32:25 --> URI Class Initialized
INFO - 2021-01-16 01:32:25 --> Router Class Initialized
INFO - 2021-01-16 01:32:25 --> Output Class Initialized
INFO - 2021-01-16 01:32:25 --> Security Class Initialized
DEBUG - 2021-01-16 01:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:32:25 --> Input Class Initialized
INFO - 2021-01-16 01:32:25 --> Language Class Initialized
INFO - 2021-01-16 01:32:25 --> Language Class Initialized
INFO - 2021-01-16 01:32:25 --> Config Class Initialized
INFO - 2021-01-16 01:32:25 --> Loader Class Initialized
INFO - 2021-01-16 01:32:25 --> Helper loaded: url_helper
INFO - 2021-01-16 01:32:25 --> Helper loaded: file_helper
INFO - 2021-01-16 01:32:25 --> Helper loaded: form_helper
INFO - 2021-01-16 01:32:25 --> Helper loaded: my_helper
INFO - 2021-01-16 01:32:25 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:32:25 --> Controller Class Initialized
DEBUG - 2021-01-16 01:32:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:32:25 --> Final output sent to browser
DEBUG - 2021-01-16 01:32:25 --> Total execution time: 0.3024
INFO - 2021-01-16 01:32:35 --> Config Class Initialized
INFO - 2021-01-16 01:32:35 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:32:35 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:32:35 --> Utf8 Class Initialized
INFO - 2021-01-16 01:32:35 --> URI Class Initialized
INFO - 2021-01-16 01:32:35 --> Router Class Initialized
INFO - 2021-01-16 01:32:35 --> Output Class Initialized
INFO - 2021-01-16 01:32:35 --> Security Class Initialized
DEBUG - 2021-01-16 01:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:32:35 --> Input Class Initialized
INFO - 2021-01-16 01:32:35 --> Language Class Initialized
INFO - 2021-01-16 01:32:35 --> Language Class Initialized
INFO - 2021-01-16 01:32:35 --> Config Class Initialized
INFO - 2021-01-16 01:32:35 --> Loader Class Initialized
INFO - 2021-01-16 01:32:35 --> Helper loaded: url_helper
INFO - 2021-01-16 01:32:35 --> Helper loaded: file_helper
INFO - 2021-01-16 01:32:35 --> Helper loaded: form_helper
INFO - 2021-01-16 01:32:35 --> Helper loaded: my_helper
INFO - 2021-01-16 01:32:35 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:32:35 --> Controller Class Initialized
DEBUG - 2021-01-16 01:32:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-16 01:32:35 --> Final output sent to browser
DEBUG - 2021-01-16 01:32:35 --> Total execution time: 0.2968
INFO - 2021-01-16 01:32:50 --> Config Class Initialized
INFO - 2021-01-16 01:32:50 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:32:50 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:32:50 --> Utf8 Class Initialized
INFO - 2021-01-16 01:32:50 --> URI Class Initialized
INFO - 2021-01-16 01:32:50 --> Router Class Initialized
INFO - 2021-01-16 01:32:50 --> Output Class Initialized
INFO - 2021-01-16 01:32:50 --> Security Class Initialized
DEBUG - 2021-01-16 01:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:32:50 --> Input Class Initialized
INFO - 2021-01-16 01:32:50 --> Language Class Initialized
INFO - 2021-01-16 01:32:50 --> Language Class Initialized
INFO - 2021-01-16 01:32:50 --> Config Class Initialized
INFO - 2021-01-16 01:32:50 --> Loader Class Initialized
INFO - 2021-01-16 01:32:50 --> Helper loaded: url_helper
INFO - 2021-01-16 01:32:50 --> Helper loaded: file_helper
INFO - 2021-01-16 01:32:50 --> Helper loaded: form_helper
INFO - 2021-01-16 01:32:50 --> Helper loaded: my_helper
INFO - 2021-01-16 01:32:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:32:50 --> Controller Class Initialized
DEBUG - 2021-01-16 01:32:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:32:50 --> Final output sent to browser
DEBUG - 2021-01-16 01:32:50 --> Total execution time: 0.2833
INFO - 2021-01-16 01:34:15 --> Config Class Initialized
INFO - 2021-01-16 01:34:15 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:34:15 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:34:15 --> Utf8 Class Initialized
INFO - 2021-01-16 01:34:15 --> URI Class Initialized
INFO - 2021-01-16 01:34:15 --> Router Class Initialized
INFO - 2021-01-16 01:34:15 --> Output Class Initialized
INFO - 2021-01-16 01:34:15 --> Security Class Initialized
DEBUG - 2021-01-16 01:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:34:15 --> Input Class Initialized
INFO - 2021-01-16 01:34:16 --> Language Class Initialized
INFO - 2021-01-16 01:34:16 --> Language Class Initialized
INFO - 2021-01-16 01:34:16 --> Config Class Initialized
INFO - 2021-01-16 01:34:16 --> Loader Class Initialized
INFO - 2021-01-16 01:34:16 --> Helper loaded: url_helper
INFO - 2021-01-16 01:34:16 --> Helper loaded: file_helper
INFO - 2021-01-16 01:34:16 --> Helper loaded: form_helper
INFO - 2021-01-16 01:34:16 --> Helper loaded: my_helper
INFO - 2021-01-16 01:34:16 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:34:16 --> Controller Class Initialized
INFO - 2021-01-16 01:34:16 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:34:16 --> Config Class Initialized
INFO - 2021-01-16 01:34:16 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:34:16 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:34:16 --> Utf8 Class Initialized
INFO - 2021-01-16 01:34:16 --> URI Class Initialized
INFO - 2021-01-16 01:34:16 --> Router Class Initialized
INFO - 2021-01-16 01:34:16 --> Output Class Initialized
INFO - 2021-01-16 01:34:16 --> Security Class Initialized
DEBUG - 2021-01-16 01:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:34:16 --> Input Class Initialized
INFO - 2021-01-16 01:34:16 --> Language Class Initialized
INFO - 2021-01-16 01:34:16 --> Language Class Initialized
INFO - 2021-01-16 01:34:16 --> Config Class Initialized
INFO - 2021-01-16 01:34:16 --> Loader Class Initialized
INFO - 2021-01-16 01:34:16 --> Helper loaded: url_helper
INFO - 2021-01-16 01:34:16 --> Helper loaded: file_helper
INFO - 2021-01-16 01:34:16 --> Helper loaded: form_helper
INFO - 2021-01-16 01:34:16 --> Helper loaded: my_helper
INFO - 2021-01-16 01:34:16 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:34:16 --> Controller Class Initialized
DEBUG - 2021-01-16 01:34:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 01:34:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:34:16 --> Final output sent to browser
DEBUG - 2021-01-16 01:34:16 --> Total execution time: 0.2921
INFO - 2021-01-16 01:34:20 --> Config Class Initialized
INFO - 2021-01-16 01:34:20 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:34:20 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:34:20 --> Utf8 Class Initialized
INFO - 2021-01-16 01:34:20 --> URI Class Initialized
INFO - 2021-01-16 01:34:20 --> Router Class Initialized
INFO - 2021-01-16 01:34:20 --> Output Class Initialized
INFO - 2021-01-16 01:34:20 --> Security Class Initialized
DEBUG - 2021-01-16 01:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:34:20 --> Input Class Initialized
INFO - 2021-01-16 01:34:20 --> Language Class Initialized
INFO - 2021-01-16 01:34:20 --> Language Class Initialized
INFO - 2021-01-16 01:34:20 --> Config Class Initialized
INFO - 2021-01-16 01:34:20 --> Loader Class Initialized
INFO - 2021-01-16 01:34:20 --> Helper loaded: url_helper
INFO - 2021-01-16 01:34:20 --> Helper loaded: file_helper
INFO - 2021-01-16 01:34:21 --> Helper loaded: form_helper
INFO - 2021-01-16 01:34:21 --> Helper loaded: my_helper
INFO - 2021-01-16 01:34:21 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:34:21 --> Controller Class Initialized
INFO - 2021-01-16 01:34:21 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:34:21 --> Final output sent to browser
DEBUG - 2021-01-16 01:34:21 --> Total execution time: 0.3461
INFO - 2021-01-16 01:34:22 --> Config Class Initialized
INFO - 2021-01-16 01:34:22 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:34:22 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:34:22 --> Utf8 Class Initialized
INFO - 2021-01-16 01:34:22 --> URI Class Initialized
INFO - 2021-01-16 01:34:22 --> Router Class Initialized
INFO - 2021-01-16 01:34:22 --> Output Class Initialized
INFO - 2021-01-16 01:34:22 --> Security Class Initialized
DEBUG - 2021-01-16 01:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:34:22 --> Input Class Initialized
INFO - 2021-01-16 01:34:22 --> Language Class Initialized
INFO - 2021-01-16 01:34:22 --> Language Class Initialized
INFO - 2021-01-16 01:34:22 --> Config Class Initialized
INFO - 2021-01-16 01:34:22 --> Loader Class Initialized
INFO - 2021-01-16 01:34:22 --> Helper loaded: url_helper
INFO - 2021-01-16 01:34:22 --> Helper loaded: file_helper
INFO - 2021-01-16 01:34:22 --> Helper loaded: form_helper
INFO - 2021-01-16 01:34:22 --> Helper loaded: my_helper
INFO - 2021-01-16 01:34:22 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:34:22 --> Controller Class Initialized
DEBUG - 2021-01-16 01:34:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 01:34:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:34:22 --> Final output sent to browser
DEBUG - 2021-01-16 01:34:22 --> Total execution time: 0.4245
INFO - 2021-01-16 01:34:50 --> Config Class Initialized
INFO - 2021-01-16 01:34:50 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:34:50 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:34:50 --> Utf8 Class Initialized
INFO - 2021-01-16 01:34:50 --> URI Class Initialized
INFO - 2021-01-16 01:34:50 --> Router Class Initialized
INFO - 2021-01-16 01:34:50 --> Output Class Initialized
INFO - 2021-01-16 01:34:50 --> Security Class Initialized
DEBUG - 2021-01-16 01:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:34:50 --> Input Class Initialized
INFO - 2021-01-16 01:34:50 --> Language Class Initialized
INFO - 2021-01-16 01:34:50 --> Language Class Initialized
INFO - 2021-01-16 01:34:50 --> Config Class Initialized
INFO - 2021-01-16 01:34:50 --> Loader Class Initialized
INFO - 2021-01-16 01:34:50 --> Helper loaded: url_helper
INFO - 2021-01-16 01:34:50 --> Helper loaded: file_helper
INFO - 2021-01-16 01:34:50 --> Helper loaded: form_helper
INFO - 2021-01-16 01:34:50 --> Helper loaded: my_helper
INFO - 2021-01-16 01:34:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:34:50 --> Controller Class Initialized
DEBUG - 2021-01-16 01:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-16 01:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:34:51 --> Final output sent to browser
DEBUG - 2021-01-16 01:34:51 --> Total execution time: 0.2706
INFO - 2021-01-16 01:34:51 --> Config Class Initialized
INFO - 2021-01-16 01:34:51 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:34:51 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:34:51 --> Utf8 Class Initialized
INFO - 2021-01-16 01:34:51 --> URI Class Initialized
INFO - 2021-01-16 01:34:51 --> Router Class Initialized
INFO - 2021-01-16 01:34:51 --> Output Class Initialized
INFO - 2021-01-16 01:34:51 --> Security Class Initialized
DEBUG - 2021-01-16 01:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:34:51 --> Input Class Initialized
INFO - 2021-01-16 01:34:51 --> Language Class Initialized
INFO - 2021-01-16 01:34:51 --> Language Class Initialized
INFO - 2021-01-16 01:34:51 --> Config Class Initialized
INFO - 2021-01-16 01:34:51 --> Loader Class Initialized
INFO - 2021-01-16 01:34:51 --> Helper loaded: url_helper
INFO - 2021-01-16 01:34:51 --> Helper loaded: file_helper
INFO - 2021-01-16 01:34:51 --> Helper loaded: form_helper
INFO - 2021-01-16 01:34:51 --> Helper loaded: my_helper
INFO - 2021-01-16 01:34:51 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:34:51 --> Controller Class Initialized
INFO - 2021-01-16 01:34:55 --> Config Class Initialized
INFO - 2021-01-16 01:34:55 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:34:55 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:34:55 --> Utf8 Class Initialized
INFO - 2021-01-16 01:34:55 --> URI Class Initialized
INFO - 2021-01-16 01:34:55 --> Router Class Initialized
INFO - 2021-01-16 01:34:55 --> Output Class Initialized
INFO - 2021-01-16 01:34:55 --> Security Class Initialized
DEBUG - 2021-01-16 01:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:34:55 --> Input Class Initialized
INFO - 2021-01-16 01:34:55 --> Language Class Initialized
INFO - 2021-01-16 01:34:55 --> Language Class Initialized
INFO - 2021-01-16 01:34:55 --> Config Class Initialized
INFO - 2021-01-16 01:34:55 --> Loader Class Initialized
INFO - 2021-01-16 01:34:55 --> Helper loaded: url_helper
INFO - 2021-01-16 01:34:55 --> Helper loaded: file_helper
INFO - 2021-01-16 01:34:55 --> Helper loaded: form_helper
INFO - 2021-01-16 01:34:55 --> Helper loaded: my_helper
INFO - 2021-01-16 01:34:55 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:34:55 --> Controller Class Initialized
INFO - 2021-01-16 01:34:57 --> Config Class Initialized
INFO - 2021-01-16 01:34:57 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:34:57 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:34:57 --> Utf8 Class Initialized
INFO - 2021-01-16 01:34:57 --> URI Class Initialized
INFO - 2021-01-16 01:34:57 --> Router Class Initialized
INFO - 2021-01-16 01:34:57 --> Output Class Initialized
INFO - 2021-01-16 01:34:57 --> Security Class Initialized
DEBUG - 2021-01-16 01:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:34:57 --> Input Class Initialized
INFO - 2021-01-16 01:34:57 --> Language Class Initialized
INFO - 2021-01-16 01:34:57 --> Language Class Initialized
INFO - 2021-01-16 01:34:57 --> Config Class Initialized
INFO - 2021-01-16 01:34:57 --> Loader Class Initialized
INFO - 2021-01-16 01:34:57 --> Helper loaded: url_helper
INFO - 2021-01-16 01:34:57 --> Helper loaded: file_helper
INFO - 2021-01-16 01:34:57 --> Helper loaded: form_helper
INFO - 2021-01-16 01:34:57 --> Helper loaded: my_helper
INFO - 2021-01-16 01:34:57 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:34:57 --> Controller Class Initialized
INFO - 2021-01-16 01:35:00 --> Config Class Initialized
INFO - 2021-01-16 01:35:00 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:00 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:00 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:00 --> URI Class Initialized
INFO - 2021-01-16 01:35:00 --> Router Class Initialized
INFO - 2021-01-16 01:35:00 --> Output Class Initialized
INFO - 2021-01-16 01:35:00 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:00 --> Input Class Initialized
INFO - 2021-01-16 01:35:00 --> Language Class Initialized
INFO - 2021-01-16 01:35:00 --> Language Class Initialized
INFO - 2021-01-16 01:35:00 --> Config Class Initialized
INFO - 2021-01-16 01:35:00 --> Loader Class Initialized
INFO - 2021-01-16 01:35:00 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:00 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:00 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:00 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:00 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:00 --> Controller Class Initialized
INFO - 2021-01-16 01:35:02 --> Config Class Initialized
INFO - 2021-01-16 01:35:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:02 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:02 --> URI Class Initialized
INFO - 2021-01-16 01:35:02 --> Router Class Initialized
INFO - 2021-01-16 01:35:02 --> Output Class Initialized
INFO - 2021-01-16 01:35:02 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:02 --> Input Class Initialized
INFO - 2021-01-16 01:35:02 --> Language Class Initialized
INFO - 2021-01-16 01:35:02 --> Language Class Initialized
INFO - 2021-01-16 01:35:02 --> Config Class Initialized
INFO - 2021-01-16 01:35:02 --> Loader Class Initialized
INFO - 2021-01-16 01:35:02 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:02 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:02 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:02 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:02 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:02 --> Controller Class Initialized
DEBUG - 2021-01-16 01:35:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-16 01:35:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:35:02 --> Final output sent to browser
DEBUG - 2021-01-16 01:35:02 --> Total execution time: 0.2867
INFO - 2021-01-16 01:35:37 --> Config Class Initialized
INFO - 2021-01-16 01:35:37 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:37 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:37 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:37 --> URI Class Initialized
INFO - 2021-01-16 01:35:37 --> Router Class Initialized
INFO - 2021-01-16 01:35:37 --> Output Class Initialized
INFO - 2021-01-16 01:35:37 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:37 --> Input Class Initialized
INFO - 2021-01-16 01:35:37 --> Language Class Initialized
INFO - 2021-01-16 01:35:37 --> Language Class Initialized
INFO - 2021-01-16 01:35:37 --> Config Class Initialized
INFO - 2021-01-16 01:35:37 --> Loader Class Initialized
INFO - 2021-01-16 01:35:37 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:37 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:37 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:37 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:37 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:37 --> Controller Class Initialized
INFO - 2021-01-16 01:35:37 --> Config Class Initialized
INFO - 2021-01-16 01:35:37 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:37 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:37 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:37 --> URI Class Initialized
INFO - 2021-01-16 01:35:37 --> Router Class Initialized
INFO - 2021-01-16 01:35:37 --> Output Class Initialized
INFO - 2021-01-16 01:35:37 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:37 --> Input Class Initialized
INFO - 2021-01-16 01:35:37 --> Language Class Initialized
INFO - 2021-01-16 01:35:37 --> Language Class Initialized
INFO - 2021-01-16 01:35:37 --> Config Class Initialized
INFO - 2021-01-16 01:35:37 --> Loader Class Initialized
INFO - 2021-01-16 01:35:37 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:37 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:37 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:37 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:37 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:37 --> Controller Class Initialized
DEBUG - 2021-01-16 01:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-16 01:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:35:37 --> Final output sent to browser
DEBUG - 2021-01-16 01:35:37 --> Total execution time: 0.2615
INFO - 2021-01-16 01:35:37 --> Config Class Initialized
INFO - 2021-01-16 01:35:37 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:37 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:37 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:37 --> URI Class Initialized
INFO - 2021-01-16 01:35:37 --> Router Class Initialized
INFO - 2021-01-16 01:35:37 --> Output Class Initialized
INFO - 2021-01-16 01:35:37 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:38 --> Input Class Initialized
INFO - 2021-01-16 01:35:38 --> Language Class Initialized
INFO - 2021-01-16 01:35:38 --> Language Class Initialized
INFO - 2021-01-16 01:35:38 --> Config Class Initialized
INFO - 2021-01-16 01:35:38 --> Loader Class Initialized
INFO - 2021-01-16 01:35:38 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:38 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:38 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:38 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:38 --> Controller Class Initialized
INFO - 2021-01-16 01:35:50 --> Config Class Initialized
INFO - 2021-01-16 01:35:50 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:50 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:50 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:50 --> URI Class Initialized
INFO - 2021-01-16 01:35:50 --> Router Class Initialized
INFO - 2021-01-16 01:35:50 --> Output Class Initialized
INFO - 2021-01-16 01:35:50 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:50 --> Input Class Initialized
INFO - 2021-01-16 01:35:50 --> Language Class Initialized
INFO - 2021-01-16 01:35:50 --> Language Class Initialized
INFO - 2021-01-16 01:35:50 --> Config Class Initialized
INFO - 2021-01-16 01:35:50 --> Loader Class Initialized
INFO - 2021-01-16 01:35:50 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:50 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:50 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:50 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:50 --> Controller Class Initialized
INFO - 2021-01-16 01:35:50 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:35:50 --> Config Class Initialized
INFO - 2021-01-16 01:35:50 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:50 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:50 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:50 --> URI Class Initialized
INFO - 2021-01-16 01:35:50 --> Router Class Initialized
INFO - 2021-01-16 01:35:50 --> Output Class Initialized
INFO - 2021-01-16 01:35:50 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:50 --> Input Class Initialized
INFO - 2021-01-16 01:35:50 --> Language Class Initialized
INFO - 2021-01-16 01:35:50 --> Language Class Initialized
INFO - 2021-01-16 01:35:50 --> Config Class Initialized
INFO - 2021-01-16 01:35:50 --> Loader Class Initialized
INFO - 2021-01-16 01:35:50 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:50 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:50 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:50 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:50 --> Controller Class Initialized
DEBUG - 2021-01-16 01:35:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 01:35:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:35:50 --> Final output sent to browser
DEBUG - 2021-01-16 01:35:50 --> Total execution time: 0.2798
INFO - 2021-01-16 01:35:54 --> Config Class Initialized
INFO - 2021-01-16 01:35:54 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:54 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:54 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:54 --> URI Class Initialized
INFO - 2021-01-16 01:35:54 --> Router Class Initialized
INFO - 2021-01-16 01:35:54 --> Output Class Initialized
INFO - 2021-01-16 01:35:54 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:54 --> Input Class Initialized
INFO - 2021-01-16 01:35:54 --> Language Class Initialized
INFO - 2021-01-16 01:35:54 --> Language Class Initialized
INFO - 2021-01-16 01:35:55 --> Config Class Initialized
INFO - 2021-01-16 01:35:55 --> Loader Class Initialized
INFO - 2021-01-16 01:35:55 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:55 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:55 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:55 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:55 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:55 --> Controller Class Initialized
INFO - 2021-01-16 01:35:55 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:35:55 --> Final output sent to browser
DEBUG - 2021-01-16 01:35:55 --> Total execution time: 0.3596
INFO - 2021-01-16 01:35:55 --> Config Class Initialized
INFO - 2021-01-16 01:35:55 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:55 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:55 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:55 --> URI Class Initialized
INFO - 2021-01-16 01:35:55 --> Router Class Initialized
INFO - 2021-01-16 01:35:55 --> Output Class Initialized
INFO - 2021-01-16 01:35:55 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:55 --> Input Class Initialized
INFO - 2021-01-16 01:35:55 --> Language Class Initialized
INFO - 2021-01-16 01:35:55 --> Language Class Initialized
INFO - 2021-01-16 01:35:55 --> Config Class Initialized
INFO - 2021-01-16 01:35:55 --> Loader Class Initialized
INFO - 2021-01-16 01:35:55 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:55 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:55 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:55 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:56 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:56 --> Controller Class Initialized
DEBUG - 2021-01-16 01:35:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 01:35:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:35:56 --> Final output sent to browser
DEBUG - 2021-01-16 01:35:56 --> Total execution time: 0.4269
INFO - 2021-01-16 01:35:58 --> Config Class Initialized
INFO - 2021-01-16 01:35:58 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:35:58 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:35:58 --> Utf8 Class Initialized
INFO - 2021-01-16 01:35:58 --> URI Class Initialized
INFO - 2021-01-16 01:35:58 --> Router Class Initialized
INFO - 2021-01-16 01:35:58 --> Output Class Initialized
INFO - 2021-01-16 01:35:58 --> Security Class Initialized
DEBUG - 2021-01-16 01:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:35:58 --> Input Class Initialized
INFO - 2021-01-16 01:35:58 --> Language Class Initialized
INFO - 2021-01-16 01:35:58 --> Language Class Initialized
INFO - 2021-01-16 01:35:58 --> Config Class Initialized
INFO - 2021-01-16 01:35:58 --> Loader Class Initialized
INFO - 2021-01-16 01:35:58 --> Helper loaded: url_helper
INFO - 2021-01-16 01:35:58 --> Helper loaded: file_helper
INFO - 2021-01-16 01:35:58 --> Helper loaded: form_helper
INFO - 2021-01-16 01:35:58 --> Helper loaded: my_helper
INFO - 2021-01-16 01:35:58 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:35:58 --> Controller Class Initialized
DEBUG - 2021-01-16 01:35:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 01:35:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:35:58 --> Final output sent to browser
DEBUG - 2021-01-16 01:35:58 --> Total execution time: 0.3141
INFO - 2021-01-16 01:36:04 --> Config Class Initialized
INFO - 2021-01-16 01:36:04 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:04 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:04 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:04 --> URI Class Initialized
INFO - 2021-01-16 01:36:04 --> Router Class Initialized
INFO - 2021-01-16 01:36:04 --> Output Class Initialized
INFO - 2021-01-16 01:36:04 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:04 --> Input Class Initialized
INFO - 2021-01-16 01:36:04 --> Language Class Initialized
INFO - 2021-01-16 01:36:04 --> Language Class Initialized
INFO - 2021-01-16 01:36:04 --> Config Class Initialized
INFO - 2021-01-16 01:36:04 --> Loader Class Initialized
INFO - 2021-01-16 01:36:04 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:04 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:04 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:04 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:04 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:04 --> Controller Class Initialized
DEBUG - 2021-01-16 01:36:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-16 01:36:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:36:04 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:04 --> Total execution time: 0.2781
INFO - 2021-01-16 01:36:04 --> Config Class Initialized
INFO - 2021-01-16 01:36:04 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:04 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:04 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:05 --> URI Class Initialized
INFO - 2021-01-16 01:36:05 --> Router Class Initialized
INFO - 2021-01-16 01:36:05 --> Output Class Initialized
INFO - 2021-01-16 01:36:05 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:05 --> Input Class Initialized
INFO - 2021-01-16 01:36:05 --> Language Class Initialized
INFO - 2021-01-16 01:36:05 --> Language Class Initialized
INFO - 2021-01-16 01:36:05 --> Config Class Initialized
INFO - 2021-01-16 01:36:05 --> Loader Class Initialized
INFO - 2021-01-16 01:36:05 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:05 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:05 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:05 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:05 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:05 --> Controller Class Initialized
INFO - 2021-01-16 01:36:07 --> Config Class Initialized
INFO - 2021-01-16 01:36:07 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:07 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:07 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:07 --> URI Class Initialized
INFO - 2021-01-16 01:36:07 --> Router Class Initialized
INFO - 2021-01-16 01:36:07 --> Output Class Initialized
INFO - 2021-01-16 01:36:07 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:07 --> Input Class Initialized
INFO - 2021-01-16 01:36:07 --> Language Class Initialized
INFO - 2021-01-16 01:36:07 --> Language Class Initialized
INFO - 2021-01-16 01:36:07 --> Config Class Initialized
INFO - 2021-01-16 01:36:07 --> Loader Class Initialized
INFO - 2021-01-16 01:36:07 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:07 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:07 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:07 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:07 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:07 --> Controller Class Initialized
INFO - 2021-01-16 01:36:07 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:07 --> Total execution time: 0.2628
INFO - 2021-01-16 01:36:31 --> Config Class Initialized
INFO - 2021-01-16 01:36:31 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:31 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:31 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:31 --> URI Class Initialized
INFO - 2021-01-16 01:36:31 --> Router Class Initialized
INFO - 2021-01-16 01:36:31 --> Output Class Initialized
INFO - 2021-01-16 01:36:31 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:31 --> Input Class Initialized
INFO - 2021-01-16 01:36:31 --> Language Class Initialized
INFO - 2021-01-16 01:36:31 --> Language Class Initialized
INFO - 2021-01-16 01:36:31 --> Config Class Initialized
INFO - 2021-01-16 01:36:31 --> Loader Class Initialized
INFO - 2021-01-16 01:36:31 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:31 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:31 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:31 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:31 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:31 --> Controller Class Initialized
INFO - 2021-01-16 01:36:31 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:31 --> Total execution time: 0.2914
INFO - 2021-01-16 01:36:31 --> Config Class Initialized
INFO - 2021-01-16 01:36:31 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:31 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:31 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:31 --> URI Class Initialized
INFO - 2021-01-16 01:36:31 --> Router Class Initialized
INFO - 2021-01-16 01:36:31 --> Output Class Initialized
INFO - 2021-01-16 01:36:31 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:31 --> Input Class Initialized
INFO - 2021-01-16 01:36:31 --> Language Class Initialized
INFO - 2021-01-16 01:36:31 --> Language Class Initialized
INFO - 2021-01-16 01:36:31 --> Config Class Initialized
INFO - 2021-01-16 01:36:31 --> Loader Class Initialized
INFO - 2021-01-16 01:36:31 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:31 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:31 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:31 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:31 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:32 --> Controller Class Initialized
INFO - 2021-01-16 01:36:33 --> Config Class Initialized
INFO - 2021-01-16 01:36:33 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:33 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:33 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:33 --> URI Class Initialized
INFO - 2021-01-16 01:36:33 --> Router Class Initialized
INFO - 2021-01-16 01:36:33 --> Output Class Initialized
INFO - 2021-01-16 01:36:33 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:33 --> Input Class Initialized
INFO - 2021-01-16 01:36:33 --> Language Class Initialized
INFO - 2021-01-16 01:36:33 --> Language Class Initialized
INFO - 2021-01-16 01:36:33 --> Config Class Initialized
INFO - 2021-01-16 01:36:33 --> Loader Class Initialized
INFO - 2021-01-16 01:36:33 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:33 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:33 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:33 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:33 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:33 --> Controller Class Initialized
INFO - 2021-01-16 01:36:33 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:33 --> Total execution time: 0.2386
INFO - 2021-01-16 01:36:38 --> Config Class Initialized
INFO - 2021-01-16 01:36:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:38 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:38 --> URI Class Initialized
INFO - 2021-01-16 01:36:38 --> Router Class Initialized
INFO - 2021-01-16 01:36:38 --> Output Class Initialized
INFO - 2021-01-16 01:36:38 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:38 --> Input Class Initialized
INFO - 2021-01-16 01:36:38 --> Language Class Initialized
INFO - 2021-01-16 01:36:38 --> Language Class Initialized
INFO - 2021-01-16 01:36:38 --> Config Class Initialized
INFO - 2021-01-16 01:36:38 --> Loader Class Initialized
INFO - 2021-01-16 01:36:38 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:38 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:38 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:38 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:39 --> Controller Class Initialized
INFO - 2021-01-16 01:36:39 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:39 --> Total execution time: 0.3201
INFO - 2021-01-16 01:36:41 --> Config Class Initialized
INFO - 2021-01-16 01:36:41 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:41 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:41 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:41 --> URI Class Initialized
INFO - 2021-01-16 01:36:41 --> Router Class Initialized
INFO - 2021-01-16 01:36:41 --> Output Class Initialized
INFO - 2021-01-16 01:36:41 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:41 --> Input Class Initialized
INFO - 2021-01-16 01:36:41 --> Language Class Initialized
INFO - 2021-01-16 01:36:41 --> Language Class Initialized
INFO - 2021-01-16 01:36:41 --> Config Class Initialized
INFO - 2021-01-16 01:36:41 --> Loader Class Initialized
INFO - 2021-01-16 01:36:41 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:41 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:41 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:41 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:41 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:41 --> Controller Class Initialized
INFO - 2021-01-16 01:36:41 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:41 --> Total execution time: 0.2247
INFO - 2021-01-16 01:36:41 --> Config Class Initialized
INFO - 2021-01-16 01:36:41 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:41 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:42 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:42 --> URI Class Initialized
INFO - 2021-01-16 01:36:42 --> Router Class Initialized
INFO - 2021-01-16 01:36:42 --> Output Class Initialized
INFO - 2021-01-16 01:36:42 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:42 --> Input Class Initialized
INFO - 2021-01-16 01:36:42 --> Language Class Initialized
INFO - 2021-01-16 01:36:42 --> Language Class Initialized
INFO - 2021-01-16 01:36:42 --> Config Class Initialized
INFO - 2021-01-16 01:36:42 --> Loader Class Initialized
INFO - 2021-01-16 01:36:42 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:42 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:42 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:42 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:42 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:42 --> Controller Class Initialized
INFO - 2021-01-16 01:36:42 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:42 --> Total execution time: 0.2530
INFO - 2021-01-16 01:36:43 --> Config Class Initialized
INFO - 2021-01-16 01:36:43 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:43 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:43 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:43 --> URI Class Initialized
INFO - 2021-01-16 01:36:43 --> Router Class Initialized
INFO - 2021-01-16 01:36:43 --> Output Class Initialized
INFO - 2021-01-16 01:36:43 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:43 --> Input Class Initialized
INFO - 2021-01-16 01:36:43 --> Language Class Initialized
INFO - 2021-01-16 01:36:43 --> Language Class Initialized
INFO - 2021-01-16 01:36:43 --> Config Class Initialized
INFO - 2021-01-16 01:36:43 --> Loader Class Initialized
INFO - 2021-01-16 01:36:43 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:43 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:43 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:43 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:43 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:43 --> Controller Class Initialized
INFO - 2021-01-16 01:36:43 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:43 --> Total execution time: 0.2284
INFO - 2021-01-16 01:36:46 --> Config Class Initialized
INFO - 2021-01-16 01:36:46 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:46 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:46 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:46 --> URI Class Initialized
INFO - 2021-01-16 01:36:46 --> Router Class Initialized
INFO - 2021-01-16 01:36:46 --> Output Class Initialized
INFO - 2021-01-16 01:36:46 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:46 --> Input Class Initialized
INFO - 2021-01-16 01:36:46 --> Language Class Initialized
INFO - 2021-01-16 01:36:46 --> Language Class Initialized
INFO - 2021-01-16 01:36:46 --> Config Class Initialized
INFO - 2021-01-16 01:36:46 --> Loader Class Initialized
INFO - 2021-01-16 01:36:46 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:46 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:46 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:46 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:46 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:46 --> Controller Class Initialized
INFO - 2021-01-16 01:36:46 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:46 --> Total execution time: 0.3313
INFO - 2021-01-16 01:36:48 --> Config Class Initialized
INFO - 2021-01-16 01:36:48 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:48 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:48 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:48 --> URI Class Initialized
INFO - 2021-01-16 01:36:48 --> Router Class Initialized
INFO - 2021-01-16 01:36:48 --> Output Class Initialized
INFO - 2021-01-16 01:36:48 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:48 --> Input Class Initialized
INFO - 2021-01-16 01:36:48 --> Language Class Initialized
INFO - 2021-01-16 01:36:48 --> Language Class Initialized
INFO - 2021-01-16 01:36:48 --> Config Class Initialized
INFO - 2021-01-16 01:36:48 --> Loader Class Initialized
INFO - 2021-01-16 01:36:48 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:48 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:48 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:48 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:48 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:49 --> Controller Class Initialized
INFO - 2021-01-16 01:36:49 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:49 --> Total execution time: 0.2558
INFO - 2021-01-16 01:36:51 --> Config Class Initialized
INFO - 2021-01-16 01:36:51 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:51 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:51 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:51 --> URI Class Initialized
INFO - 2021-01-16 01:36:51 --> Router Class Initialized
INFO - 2021-01-16 01:36:51 --> Output Class Initialized
INFO - 2021-01-16 01:36:52 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:52 --> Input Class Initialized
INFO - 2021-01-16 01:36:52 --> Language Class Initialized
INFO - 2021-01-16 01:36:52 --> Language Class Initialized
INFO - 2021-01-16 01:36:52 --> Config Class Initialized
INFO - 2021-01-16 01:36:52 --> Loader Class Initialized
INFO - 2021-01-16 01:36:52 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:52 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:52 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:52 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:52 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:52 --> Controller Class Initialized
INFO - 2021-01-16 01:36:52 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:52 --> Total execution time: 0.3608
INFO - 2021-01-16 01:36:56 --> Config Class Initialized
INFO - 2021-01-16 01:36:56 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:36:56 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:36:56 --> Utf8 Class Initialized
INFO - 2021-01-16 01:36:56 --> URI Class Initialized
INFO - 2021-01-16 01:36:56 --> Router Class Initialized
INFO - 2021-01-16 01:36:56 --> Output Class Initialized
INFO - 2021-01-16 01:36:56 --> Security Class Initialized
DEBUG - 2021-01-16 01:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:36:56 --> Input Class Initialized
INFO - 2021-01-16 01:36:56 --> Language Class Initialized
INFO - 2021-01-16 01:36:56 --> Language Class Initialized
INFO - 2021-01-16 01:36:56 --> Config Class Initialized
INFO - 2021-01-16 01:36:56 --> Loader Class Initialized
INFO - 2021-01-16 01:36:56 --> Helper loaded: url_helper
INFO - 2021-01-16 01:36:56 --> Helper loaded: file_helper
INFO - 2021-01-16 01:36:56 --> Helper loaded: form_helper
INFO - 2021-01-16 01:36:56 --> Helper loaded: my_helper
INFO - 2021-01-16 01:36:56 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:36:56 --> Controller Class Initialized
DEBUG - 2021-01-16 01:36:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 01:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:36:57 --> Final output sent to browser
DEBUG - 2021-01-16 01:36:57 --> Total execution time: 0.3032
INFO - 2021-01-16 01:37:00 --> Config Class Initialized
INFO - 2021-01-16 01:37:00 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:00 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:00 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:00 --> URI Class Initialized
INFO - 2021-01-16 01:37:00 --> Router Class Initialized
INFO - 2021-01-16 01:37:00 --> Output Class Initialized
INFO - 2021-01-16 01:37:00 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:00 --> Input Class Initialized
INFO - 2021-01-16 01:37:00 --> Language Class Initialized
INFO - 2021-01-16 01:37:00 --> Language Class Initialized
INFO - 2021-01-16 01:37:00 --> Config Class Initialized
INFO - 2021-01-16 01:37:00 --> Loader Class Initialized
INFO - 2021-01-16 01:37:00 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:00 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:00 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:00 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:00 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:00 --> Controller Class Initialized
DEBUG - 2021-01-16 01:37:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 01:37:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:37:00 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:00 --> Total execution time: 0.2790
INFO - 2021-01-16 01:37:03 --> Config Class Initialized
INFO - 2021-01-16 01:37:03 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:03 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:03 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:03 --> URI Class Initialized
INFO - 2021-01-16 01:37:03 --> Router Class Initialized
INFO - 2021-01-16 01:37:03 --> Output Class Initialized
INFO - 2021-01-16 01:37:03 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:03 --> Input Class Initialized
INFO - 2021-01-16 01:37:03 --> Language Class Initialized
INFO - 2021-01-16 01:37:03 --> Language Class Initialized
INFO - 2021-01-16 01:37:03 --> Config Class Initialized
INFO - 2021-01-16 01:37:03 --> Loader Class Initialized
INFO - 2021-01-16 01:37:03 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:03 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:03 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:03 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:03 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:03 --> Controller Class Initialized
INFO - 2021-01-16 01:37:03 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:03 --> Total execution time: 0.2844
INFO - 2021-01-16 01:37:13 --> Config Class Initialized
INFO - 2021-01-16 01:37:13 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:13 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:13 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:13 --> URI Class Initialized
INFO - 2021-01-16 01:37:13 --> Router Class Initialized
INFO - 2021-01-16 01:37:13 --> Output Class Initialized
INFO - 2021-01-16 01:37:13 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:13 --> Input Class Initialized
INFO - 2021-01-16 01:37:13 --> Language Class Initialized
INFO - 2021-01-16 01:37:13 --> Language Class Initialized
INFO - 2021-01-16 01:37:13 --> Config Class Initialized
INFO - 2021-01-16 01:37:13 --> Loader Class Initialized
INFO - 2021-01-16 01:37:13 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:13 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:13 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:13 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:13 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:13 --> Controller Class Initialized
INFO - 2021-01-16 01:37:13 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:13 --> Total execution time: 0.3117
INFO - 2021-01-16 01:37:13 --> Config Class Initialized
INFO - 2021-01-16 01:37:13 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:13 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:13 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:13 --> URI Class Initialized
INFO - 2021-01-16 01:37:13 --> Router Class Initialized
INFO - 2021-01-16 01:37:13 --> Output Class Initialized
INFO - 2021-01-16 01:37:13 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:13 --> Input Class Initialized
INFO - 2021-01-16 01:37:13 --> Language Class Initialized
INFO - 2021-01-16 01:37:13 --> Language Class Initialized
INFO - 2021-01-16 01:37:13 --> Config Class Initialized
INFO - 2021-01-16 01:37:13 --> Loader Class Initialized
INFO - 2021-01-16 01:37:13 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:13 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:13 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:13 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:13 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:14 --> Controller Class Initialized
DEBUG - 2021-01-16 01:37:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 01:37:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:37:14 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:14 --> Total execution time: 0.4133
INFO - 2021-01-16 01:37:15 --> Config Class Initialized
INFO - 2021-01-16 01:37:15 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:15 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:15 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:15 --> URI Class Initialized
INFO - 2021-01-16 01:37:15 --> Router Class Initialized
INFO - 2021-01-16 01:37:15 --> Output Class Initialized
INFO - 2021-01-16 01:37:15 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:15 --> Input Class Initialized
INFO - 2021-01-16 01:37:15 --> Language Class Initialized
INFO - 2021-01-16 01:37:15 --> Language Class Initialized
INFO - 2021-01-16 01:37:15 --> Config Class Initialized
INFO - 2021-01-16 01:37:15 --> Loader Class Initialized
INFO - 2021-01-16 01:37:15 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:15 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:15 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:15 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:15 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:15 --> Controller Class Initialized
INFO - 2021-01-16 01:37:15 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:15 --> Total execution time: 0.2650
INFO - 2021-01-16 01:37:26 --> Config Class Initialized
INFO - 2021-01-16 01:37:26 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:26 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:26 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:26 --> URI Class Initialized
INFO - 2021-01-16 01:37:26 --> Router Class Initialized
INFO - 2021-01-16 01:37:26 --> Output Class Initialized
INFO - 2021-01-16 01:37:26 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:26 --> Input Class Initialized
INFO - 2021-01-16 01:37:26 --> Language Class Initialized
INFO - 2021-01-16 01:37:26 --> Language Class Initialized
INFO - 2021-01-16 01:37:26 --> Config Class Initialized
INFO - 2021-01-16 01:37:26 --> Loader Class Initialized
INFO - 2021-01-16 01:37:26 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:26 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:26 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:26 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:26 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:26 --> Controller Class Initialized
INFO - 2021-01-16 01:37:26 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:26 --> Total execution time: 0.3192
INFO - 2021-01-16 01:37:26 --> Config Class Initialized
INFO - 2021-01-16 01:37:26 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:26 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:26 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:26 --> URI Class Initialized
INFO - 2021-01-16 01:37:26 --> Router Class Initialized
INFO - 2021-01-16 01:37:26 --> Output Class Initialized
INFO - 2021-01-16 01:37:26 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:26 --> Input Class Initialized
INFO - 2021-01-16 01:37:26 --> Language Class Initialized
INFO - 2021-01-16 01:37:26 --> Language Class Initialized
INFO - 2021-01-16 01:37:26 --> Config Class Initialized
INFO - 2021-01-16 01:37:26 --> Loader Class Initialized
INFO - 2021-01-16 01:37:26 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:26 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:26 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:26 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:26 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:27 --> Controller Class Initialized
DEBUG - 2021-01-16 01:37:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 01:37:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:37:27 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:27 --> Total execution time: 0.4193
INFO - 2021-01-16 01:37:27 --> Config Class Initialized
INFO - 2021-01-16 01:37:27 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:27 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:27 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:27 --> URI Class Initialized
INFO - 2021-01-16 01:37:27 --> Router Class Initialized
INFO - 2021-01-16 01:37:27 --> Output Class Initialized
INFO - 2021-01-16 01:37:27 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:27 --> Input Class Initialized
INFO - 2021-01-16 01:37:27 --> Language Class Initialized
INFO - 2021-01-16 01:37:27 --> Language Class Initialized
INFO - 2021-01-16 01:37:27 --> Config Class Initialized
INFO - 2021-01-16 01:37:27 --> Loader Class Initialized
INFO - 2021-01-16 01:37:27 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:27 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:27 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:27 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:27 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:27 --> Controller Class Initialized
INFO - 2021-01-16 01:37:27 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:27 --> Total execution time: 0.2474
INFO - 2021-01-16 01:37:31 --> Config Class Initialized
INFO - 2021-01-16 01:37:31 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:31 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:31 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:31 --> URI Class Initialized
INFO - 2021-01-16 01:37:31 --> Router Class Initialized
INFO - 2021-01-16 01:37:31 --> Output Class Initialized
INFO - 2021-01-16 01:37:31 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:31 --> Input Class Initialized
INFO - 2021-01-16 01:37:31 --> Language Class Initialized
INFO - 2021-01-16 01:37:31 --> Language Class Initialized
INFO - 2021-01-16 01:37:31 --> Config Class Initialized
INFO - 2021-01-16 01:37:31 --> Loader Class Initialized
INFO - 2021-01-16 01:37:31 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:31 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:31 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:31 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:31 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:31 --> Controller Class Initialized
INFO - 2021-01-16 01:37:31 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:31 --> Total execution time: 0.3674
INFO - 2021-01-16 01:37:33 --> Config Class Initialized
INFO - 2021-01-16 01:37:33 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:33 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:33 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:33 --> URI Class Initialized
INFO - 2021-01-16 01:37:33 --> Router Class Initialized
INFO - 2021-01-16 01:37:33 --> Output Class Initialized
INFO - 2021-01-16 01:37:33 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:33 --> Input Class Initialized
INFO - 2021-01-16 01:37:33 --> Language Class Initialized
INFO - 2021-01-16 01:37:33 --> Language Class Initialized
INFO - 2021-01-16 01:37:33 --> Config Class Initialized
INFO - 2021-01-16 01:37:33 --> Loader Class Initialized
INFO - 2021-01-16 01:37:33 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:33 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:33 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:33 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:33 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:33 --> Controller Class Initialized
INFO - 2021-01-16 01:37:33 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:33 --> Total execution time: 0.2611
INFO - 2021-01-16 01:37:37 --> Config Class Initialized
INFO - 2021-01-16 01:37:37 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:37 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:37 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:37 --> URI Class Initialized
INFO - 2021-01-16 01:37:37 --> Router Class Initialized
INFO - 2021-01-16 01:37:37 --> Output Class Initialized
INFO - 2021-01-16 01:37:37 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:37 --> Input Class Initialized
INFO - 2021-01-16 01:37:37 --> Language Class Initialized
INFO - 2021-01-16 01:37:37 --> Language Class Initialized
INFO - 2021-01-16 01:37:37 --> Config Class Initialized
INFO - 2021-01-16 01:37:37 --> Loader Class Initialized
INFO - 2021-01-16 01:37:37 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:37 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:37 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:37 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:37 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:37 --> Controller Class Initialized
INFO - 2021-01-16 01:37:37 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:37 --> Total execution time: 0.3505
INFO - 2021-01-16 01:37:41 --> Config Class Initialized
INFO - 2021-01-16 01:37:41 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:41 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:41 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:41 --> URI Class Initialized
INFO - 2021-01-16 01:37:41 --> Router Class Initialized
INFO - 2021-01-16 01:37:41 --> Output Class Initialized
INFO - 2021-01-16 01:37:41 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:41 --> Input Class Initialized
INFO - 2021-01-16 01:37:41 --> Language Class Initialized
INFO - 2021-01-16 01:37:41 --> Language Class Initialized
INFO - 2021-01-16 01:37:41 --> Config Class Initialized
INFO - 2021-01-16 01:37:41 --> Loader Class Initialized
INFO - 2021-01-16 01:37:41 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:41 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:41 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:41 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:41 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:41 --> Controller Class Initialized
INFO - 2021-01-16 01:37:41 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:37:41 --> Config Class Initialized
INFO - 2021-01-16 01:37:41 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:41 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:41 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:41 --> URI Class Initialized
INFO - 2021-01-16 01:37:41 --> Router Class Initialized
INFO - 2021-01-16 01:37:41 --> Output Class Initialized
INFO - 2021-01-16 01:37:41 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:41 --> Input Class Initialized
INFO - 2021-01-16 01:37:41 --> Language Class Initialized
INFO - 2021-01-16 01:37:41 --> Language Class Initialized
INFO - 2021-01-16 01:37:41 --> Config Class Initialized
INFO - 2021-01-16 01:37:41 --> Loader Class Initialized
INFO - 2021-01-16 01:37:41 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:41 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:41 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:41 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:42 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:42 --> Controller Class Initialized
DEBUG - 2021-01-16 01:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 01:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:37:42 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:42 --> Total execution time: 0.3132
INFO - 2021-01-16 01:37:45 --> Config Class Initialized
INFO - 2021-01-16 01:37:45 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:46 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:46 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:46 --> URI Class Initialized
INFO - 2021-01-16 01:37:46 --> Router Class Initialized
INFO - 2021-01-16 01:37:46 --> Output Class Initialized
INFO - 2021-01-16 01:37:46 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:46 --> Input Class Initialized
INFO - 2021-01-16 01:37:46 --> Language Class Initialized
INFO - 2021-01-16 01:37:46 --> Language Class Initialized
INFO - 2021-01-16 01:37:46 --> Config Class Initialized
INFO - 2021-01-16 01:37:46 --> Loader Class Initialized
INFO - 2021-01-16 01:37:46 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:46 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:46 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:46 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:46 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:46 --> Controller Class Initialized
INFO - 2021-01-16 01:37:46 --> Helper loaded: cookie_helper
INFO - 2021-01-16 01:37:46 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:46 --> Total execution time: 0.3703
INFO - 2021-01-16 01:37:46 --> Config Class Initialized
INFO - 2021-01-16 01:37:46 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:46 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:46 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:46 --> URI Class Initialized
INFO - 2021-01-16 01:37:46 --> Router Class Initialized
INFO - 2021-01-16 01:37:46 --> Output Class Initialized
INFO - 2021-01-16 01:37:46 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:46 --> Input Class Initialized
INFO - 2021-01-16 01:37:46 --> Language Class Initialized
INFO - 2021-01-16 01:37:46 --> Language Class Initialized
INFO - 2021-01-16 01:37:46 --> Config Class Initialized
INFO - 2021-01-16 01:37:46 --> Loader Class Initialized
INFO - 2021-01-16 01:37:46 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:46 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:46 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:46 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:46 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:46 --> Controller Class Initialized
DEBUG - 2021-01-16 01:37:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 01:37:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:37:47 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:47 --> Total execution time: 0.4524
INFO - 2021-01-16 01:37:50 --> Config Class Initialized
INFO - 2021-01-16 01:37:50 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:50 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:50 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:50 --> URI Class Initialized
INFO - 2021-01-16 01:37:50 --> Router Class Initialized
INFO - 2021-01-16 01:37:50 --> Output Class Initialized
INFO - 2021-01-16 01:37:50 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:50 --> Input Class Initialized
INFO - 2021-01-16 01:37:50 --> Language Class Initialized
INFO - 2021-01-16 01:37:50 --> Language Class Initialized
INFO - 2021-01-16 01:37:50 --> Config Class Initialized
INFO - 2021-01-16 01:37:50 --> Loader Class Initialized
INFO - 2021-01-16 01:37:50 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:50 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:50 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:50 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:50 --> Controller Class Initialized
DEBUG - 2021-01-16 01:37:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-16 01:37:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:37:50 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:50 --> Total execution time: 0.2909
INFO - 2021-01-16 01:37:52 --> Config Class Initialized
INFO - 2021-01-16 01:37:52 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:37:52 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:37:52 --> Utf8 Class Initialized
INFO - 2021-01-16 01:37:52 --> URI Class Initialized
INFO - 2021-01-16 01:37:52 --> Router Class Initialized
INFO - 2021-01-16 01:37:52 --> Output Class Initialized
INFO - 2021-01-16 01:37:52 --> Security Class Initialized
DEBUG - 2021-01-16 01:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:37:52 --> Input Class Initialized
INFO - 2021-01-16 01:37:52 --> Language Class Initialized
INFO - 2021-01-16 01:37:52 --> Language Class Initialized
INFO - 2021-01-16 01:37:52 --> Config Class Initialized
INFO - 2021-01-16 01:37:52 --> Loader Class Initialized
INFO - 2021-01-16 01:37:52 --> Helper loaded: url_helper
INFO - 2021-01-16 01:37:52 --> Helper loaded: file_helper
INFO - 2021-01-16 01:37:52 --> Helper loaded: form_helper
INFO - 2021-01-16 01:37:52 --> Helper loaded: my_helper
INFO - 2021-01-16 01:37:52 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:37:52 --> Controller Class Initialized
DEBUG - 2021-01-16 01:37:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:37:52 --> Final output sent to browser
DEBUG - 2021-01-16 01:37:52 --> Total execution time: 0.3042
INFO - 2021-01-16 01:38:20 --> Config Class Initialized
INFO - 2021-01-16 01:38:20 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:38:20 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:38:20 --> Utf8 Class Initialized
INFO - 2021-01-16 01:38:20 --> URI Class Initialized
INFO - 2021-01-16 01:38:20 --> Router Class Initialized
INFO - 2021-01-16 01:38:20 --> Output Class Initialized
INFO - 2021-01-16 01:38:20 --> Security Class Initialized
DEBUG - 2021-01-16 01:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:38:20 --> Input Class Initialized
INFO - 2021-01-16 01:38:20 --> Language Class Initialized
INFO - 2021-01-16 01:38:20 --> Language Class Initialized
INFO - 2021-01-16 01:38:20 --> Config Class Initialized
INFO - 2021-01-16 01:38:20 --> Loader Class Initialized
INFO - 2021-01-16 01:38:20 --> Helper loaded: url_helper
INFO - 2021-01-16 01:38:20 --> Helper loaded: file_helper
INFO - 2021-01-16 01:38:20 --> Helper loaded: form_helper
INFO - 2021-01-16 01:38:20 --> Helper loaded: my_helper
INFO - 2021-01-16 01:38:20 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:38:20 --> Controller Class Initialized
DEBUG - 2021-01-16 01:38:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-16 01:38:20 --> Final output sent to browser
DEBUG - 2021-01-16 01:38:20 --> Total execution time: 0.3115
INFO - 2021-01-16 01:45:16 --> Config Class Initialized
INFO - 2021-01-16 01:45:16 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:45:16 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:45:16 --> Utf8 Class Initialized
INFO - 2021-01-16 01:45:16 --> URI Class Initialized
INFO - 2021-01-16 01:45:16 --> Router Class Initialized
INFO - 2021-01-16 01:45:16 --> Output Class Initialized
INFO - 2021-01-16 01:45:16 --> Security Class Initialized
DEBUG - 2021-01-16 01:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:45:16 --> Input Class Initialized
INFO - 2021-01-16 01:45:16 --> Language Class Initialized
INFO - 2021-01-16 01:45:16 --> Language Class Initialized
INFO - 2021-01-16 01:45:16 --> Config Class Initialized
INFO - 2021-01-16 01:45:16 --> Loader Class Initialized
INFO - 2021-01-16 01:45:16 --> Helper loaded: url_helper
INFO - 2021-01-16 01:45:16 --> Helper loaded: file_helper
INFO - 2021-01-16 01:45:16 --> Helper loaded: form_helper
INFO - 2021-01-16 01:45:16 --> Helper loaded: my_helper
INFO - 2021-01-16 01:45:16 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:45:16 --> Controller Class Initialized
DEBUG - 2021-01-16 01:45:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:45:16 --> Final output sent to browser
DEBUG - 2021-01-16 01:45:16 --> Total execution time: 0.2799
INFO - 2021-01-16 01:45:39 --> Config Class Initialized
INFO - 2021-01-16 01:45:39 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:45:39 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:45:39 --> Utf8 Class Initialized
INFO - 2021-01-16 01:45:39 --> URI Class Initialized
INFO - 2021-01-16 01:45:39 --> Router Class Initialized
INFO - 2021-01-16 01:45:39 --> Output Class Initialized
INFO - 2021-01-16 01:45:39 --> Security Class Initialized
DEBUG - 2021-01-16 01:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:45:39 --> Input Class Initialized
INFO - 2021-01-16 01:45:39 --> Language Class Initialized
INFO - 2021-01-16 01:45:39 --> Language Class Initialized
INFO - 2021-01-16 01:45:39 --> Config Class Initialized
INFO - 2021-01-16 01:45:39 --> Loader Class Initialized
INFO - 2021-01-16 01:45:39 --> Helper loaded: url_helper
INFO - 2021-01-16 01:45:39 --> Helper loaded: file_helper
INFO - 2021-01-16 01:45:39 --> Helper loaded: form_helper
INFO - 2021-01-16 01:45:39 --> Helper loaded: my_helper
INFO - 2021-01-16 01:45:39 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:45:39 --> Controller Class Initialized
DEBUG - 2021-01-16 01:45:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:45:39 --> Final output sent to browser
DEBUG - 2021-01-16 01:45:39 --> Total execution time: 0.2770
INFO - 2021-01-16 01:46:54 --> Config Class Initialized
INFO - 2021-01-16 01:46:54 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:46:54 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:46:54 --> Utf8 Class Initialized
INFO - 2021-01-16 01:46:54 --> URI Class Initialized
INFO - 2021-01-16 01:46:54 --> Router Class Initialized
INFO - 2021-01-16 01:46:54 --> Output Class Initialized
INFO - 2021-01-16 01:46:54 --> Security Class Initialized
DEBUG - 2021-01-16 01:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:46:54 --> Input Class Initialized
INFO - 2021-01-16 01:46:54 --> Language Class Initialized
INFO - 2021-01-16 01:46:54 --> Language Class Initialized
INFO - 2021-01-16 01:46:54 --> Config Class Initialized
INFO - 2021-01-16 01:46:54 --> Loader Class Initialized
INFO - 2021-01-16 01:46:54 --> Helper loaded: url_helper
INFO - 2021-01-16 01:46:54 --> Helper loaded: file_helper
INFO - 2021-01-16 01:46:54 --> Helper loaded: form_helper
INFO - 2021-01-16 01:46:54 --> Helper loaded: my_helper
INFO - 2021-01-16 01:46:54 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:46:54 --> Controller Class Initialized
DEBUG - 2021-01-16 01:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-16 01:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 01:46:54 --> Final output sent to browser
DEBUG - 2021-01-16 01:46:54 --> Total execution time: 0.2800
INFO - 2021-01-16 01:46:56 --> Config Class Initialized
INFO - 2021-01-16 01:46:56 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:46:56 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:46:56 --> Utf8 Class Initialized
INFO - 2021-01-16 01:46:56 --> URI Class Initialized
INFO - 2021-01-16 01:46:56 --> Router Class Initialized
INFO - 2021-01-16 01:46:56 --> Output Class Initialized
INFO - 2021-01-16 01:46:56 --> Security Class Initialized
DEBUG - 2021-01-16 01:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:46:56 --> Input Class Initialized
INFO - 2021-01-16 01:46:56 --> Language Class Initialized
INFO - 2021-01-16 01:46:56 --> Language Class Initialized
INFO - 2021-01-16 01:46:56 --> Config Class Initialized
INFO - 2021-01-16 01:46:56 --> Loader Class Initialized
INFO - 2021-01-16 01:46:56 --> Helper loaded: url_helper
INFO - 2021-01-16 01:46:56 --> Helper loaded: file_helper
INFO - 2021-01-16 01:46:56 --> Helper loaded: form_helper
INFO - 2021-01-16 01:46:56 --> Helper loaded: my_helper
INFO - 2021-01-16 01:46:56 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:46:56 --> Controller Class Initialized
DEBUG - 2021-01-16 01:46:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-16 01:46:56 --> Final output sent to browser
DEBUG - 2021-01-16 01:46:56 --> Total execution time: 0.3068
INFO - 2021-01-16 01:51:12 --> Config Class Initialized
INFO - 2021-01-16 01:51:12 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:51:12 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:51:12 --> Utf8 Class Initialized
INFO - 2021-01-16 01:51:12 --> URI Class Initialized
INFO - 2021-01-16 01:51:12 --> Router Class Initialized
INFO - 2021-01-16 01:51:12 --> Output Class Initialized
INFO - 2021-01-16 01:51:12 --> Security Class Initialized
DEBUG - 2021-01-16 01:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:51:12 --> Input Class Initialized
INFO - 2021-01-16 01:51:12 --> Language Class Initialized
INFO - 2021-01-16 01:51:12 --> Language Class Initialized
INFO - 2021-01-16 01:51:12 --> Config Class Initialized
INFO - 2021-01-16 01:51:12 --> Loader Class Initialized
INFO - 2021-01-16 01:51:12 --> Helper loaded: url_helper
INFO - 2021-01-16 01:51:12 --> Helper loaded: file_helper
INFO - 2021-01-16 01:51:12 --> Helper loaded: form_helper
INFO - 2021-01-16 01:51:12 --> Helper loaded: my_helper
INFO - 2021-01-16 01:51:12 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:51:12 --> Controller Class Initialized
DEBUG - 2021-01-16 01:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:51:12 --> Final output sent to browser
DEBUG - 2021-01-16 01:51:12 --> Total execution time: 0.2795
INFO - 2021-01-16 01:51:22 --> Config Class Initialized
INFO - 2021-01-16 01:51:22 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:51:22 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:51:22 --> Utf8 Class Initialized
INFO - 2021-01-16 01:51:22 --> URI Class Initialized
INFO - 2021-01-16 01:51:22 --> Router Class Initialized
INFO - 2021-01-16 01:51:22 --> Output Class Initialized
INFO - 2021-01-16 01:51:22 --> Security Class Initialized
DEBUG - 2021-01-16 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:51:22 --> Input Class Initialized
INFO - 2021-01-16 01:51:22 --> Language Class Initialized
INFO - 2021-01-16 01:51:22 --> Language Class Initialized
INFO - 2021-01-16 01:51:22 --> Config Class Initialized
INFO - 2021-01-16 01:51:22 --> Loader Class Initialized
INFO - 2021-01-16 01:51:22 --> Helper loaded: url_helper
INFO - 2021-01-16 01:51:22 --> Helper loaded: file_helper
INFO - 2021-01-16 01:51:22 --> Helper loaded: form_helper
INFO - 2021-01-16 01:51:22 --> Helper loaded: my_helper
INFO - 2021-01-16 01:51:22 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:51:22 --> Controller Class Initialized
DEBUG - 2021-01-16 01:51:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:51:22 --> Final output sent to browser
DEBUG - 2021-01-16 01:51:22 --> Total execution time: 0.2811
INFO - 2021-01-16 01:51:24 --> Config Class Initialized
INFO - 2021-01-16 01:51:24 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:51:24 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:51:24 --> Utf8 Class Initialized
INFO - 2021-01-16 01:51:24 --> URI Class Initialized
INFO - 2021-01-16 01:51:24 --> Router Class Initialized
INFO - 2021-01-16 01:51:24 --> Output Class Initialized
INFO - 2021-01-16 01:51:24 --> Security Class Initialized
DEBUG - 2021-01-16 01:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:51:24 --> Input Class Initialized
INFO - 2021-01-16 01:51:24 --> Language Class Initialized
INFO - 2021-01-16 01:51:24 --> Language Class Initialized
INFO - 2021-01-16 01:51:24 --> Config Class Initialized
INFO - 2021-01-16 01:51:24 --> Loader Class Initialized
INFO - 2021-01-16 01:51:24 --> Helper loaded: url_helper
INFO - 2021-01-16 01:51:24 --> Helper loaded: file_helper
INFO - 2021-01-16 01:51:24 --> Helper loaded: form_helper
INFO - 2021-01-16 01:51:24 --> Helper loaded: my_helper
INFO - 2021-01-16 01:51:24 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:51:24 --> Controller Class Initialized
DEBUG - 2021-01-16 01:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:51:24 --> Final output sent to browser
DEBUG - 2021-01-16 01:51:24 --> Total execution time: 0.2794
INFO - 2021-01-16 01:51:33 --> Config Class Initialized
INFO - 2021-01-16 01:51:33 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:51:33 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:51:33 --> Utf8 Class Initialized
INFO - 2021-01-16 01:51:33 --> URI Class Initialized
INFO - 2021-01-16 01:51:33 --> Router Class Initialized
INFO - 2021-01-16 01:51:33 --> Output Class Initialized
INFO - 2021-01-16 01:51:33 --> Security Class Initialized
DEBUG - 2021-01-16 01:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:51:33 --> Input Class Initialized
INFO - 2021-01-16 01:51:33 --> Language Class Initialized
INFO - 2021-01-16 01:51:33 --> Language Class Initialized
INFO - 2021-01-16 01:51:33 --> Config Class Initialized
INFO - 2021-01-16 01:51:33 --> Loader Class Initialized
INFO - 2021-01-16 01:51:33 --> Helper loaded: url_helper
INFO - 2021-01-16 01:51:33 --> Helper loaded: file_helper
INFO - 2021-01-16 01:51:33 --> Helper loaded: form_helper
INFO - 2021-01-16 01:51:33 --> Helper loaded: my_helper
INFO - 2021-01-16 01:51:33 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:51:33 --> Controller Class Initialized
DEBUG - 2021-01-16 01:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:51:33 --> Final output sent to browser
DEBUG - 2021-01-16 01:51:33 --> Total execution time: 0.2918
INFO - 2021-01-16 01:58:05 --> Config Class Initialized
INFO - 2021-01-16 01:58:05 --> Hooks Class Initialized
DEBUG - 2021-01-16 01:58:05 --> UTF-8 Support Enabled
INFO - 2021-01-16 01:58:05 --> Utf8 Class Initialized
INFO - 2021-01-16 01:58:05 --> URI Class Initialized
INFO - 2021-01-16 01:58:05 --> Router Class Initialized
INFO - 2021-01-16 01:58:05 --> Output Class Initialized
INFO - 2021-01-16 01:58:05 --> Security Class Initialized
DEBUG - 2021-01-16 01:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 01:58:05 --> Input Class Initialized
INFO - 2021-01-16 01:58:05 --> Language Class Initialized
INFO - 2021-01-16 01:58:05 --> Language Class Initialized
INFO - 2021-01-16 01:58:05 --> Config Class Initialized
INFO - 2021-01-16 01:58:05 --> Loader Class Initialized
INFO - 2021-01-16 01:58:05 --> Helper loaded: url_helper
INFO - 2021-01-16 01:58:05 --> Helper loaded: file_helper
INFO - 2021-01-16 01:58:05 --> Helper loaded: form_helper
INFO - 2021-01-16 01:58:05 --> Helper loaded: my_helper
INFO - 2021-01-16 01:58:05 --> Database Driver Class Initialized
DEBUG - 2021-01-16 01:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 01:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 01:58:05 --> Controller Class Initialized
DEBUG - 2021-01-16 01:58:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 01:58:05 --> Final output sent to browser
DEBUG - 2021-01-16 01:58:05 --> Total execution time: 0.2810
INFO - 2021-01-16 02:00:05 --> Config Class Initialized
INFO - 2021-01-16 02:00:05 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:00:05 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:00:05 --> Utf8 Class Initialized
INFO - 2021-01-16 02:00:05 --> URI Class Initialized
INFO - 2021-01-16 02:00:05 --> Router Class Initialized
INFO - 2021-01-16 02:00:05 --> Output Class Initialized
INFO - 2021-01-16 02:00:05 --> Security Class Initialized
DEBUG - 2021-01-16 02:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:00:05 --> Input Class Initialized
INFO - 2021-01-16 02:00:05 --> Language Class Initialized
ERROR - 2021-01-16 02:00:05 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4672
INFO - 2021-01-16 02:01:38 --> Config Class Initialized
INFO - 2021-01-16 02:01:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:01:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:01:38 --> Utf8 Class Initialized
INFO - 2021-01-16 02:01:38 --> URI Class Initialized
INFO - 2021-01-16 02:01:38 --> Router Class Initialized
INFO - 2021-01-16 02:01:39 --> Output Class Initialized
INFO - 2021-01-16 02:01:39 --> Security Class Initialized
DEBUG - 2021-01-16 02:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:01:39 --> Input Class Initialized
INFO - 2021-01-16 02:01:39 --> Language Class Initialized
ERROR - 2021-01-16 02:01:39 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4673
INFO - 2021-01-16 02:01:49 --> Config Class Initialized
INFO - 2021-01-16 02:01:49 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:01:49 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:01:49 --> Utf8 Class Initialized
INFO - 2021-01-16 02:01:49 --> URI Class Initialized
INFO - 2021-01-16 02:01:49 --> Router Class Initialized
INFO - 2021-01-16 02:01:49 --> Output Class Initialized
INFO - 2021-01-16 02:01:49 --> Security Class Initialized
DEBUG - 2021-01-16 02:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:01:49 --> Input Class Initialized
INFO - 2021-01-16 02:01:49 --> Language Class Initialized
ERROR - 2021-01-16 02:01:49 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4672
INFO - 2021-01-16 02:02:02 --> Config Class Initialized
INFO - 2021-01-16 02:02:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:02:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:02:02 --> Utf8 Class Initialized
INFO - 2021-01-16 02:02:02 --> URI Class Initialized
INFO - 2021-01-16 02:02:02 --> Router Class Initialized
INFO - 2021-01-16 02:02:02 --> Output Class Initialized
INFO - 2021-01-16 02:02:02 --> Security Class Initialized
DEBUG - 2021-01-16 02:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:02:02 --> Input Class Initialized
INFO - 2021-01-16 02:02:02 --> Language Class Initialized
ERROR - 2021-01-16 02:02:02 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4673
INFO - 2021-01-16 02:06:16 --> Config Class Initialized
INFO - 2021-01-16 02:06:16 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:06:16 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:06:16 --> Utf8 Class Initialized
INFO - 2021-01-16 02:06:16 --> URI Class Initialized
INFO - 2021-01-16 02:06:16 --> Router Class Initialized
INFO - 2021-01-16 02:06:16 --> Output Class Initialized
INFO - 2021-01-16 02:06:16 --> Security Class Initialized
DEBUG - 2021-01-16 02:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:06:16 --> Input Class Initialized
INFO - 2021-01-16 02:06:16 --> Language Class Initialized
ERROR - 2021-01-16 02:06:16 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4481
INFO - 2021-01-16 02:06:38 --> Config Class Initialized
INFO - 2021-01-16 02:06:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:06:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:06:38 --> Utf8 Class Initialized
INFO - 2021-01-16 02:06:38 --> URI Class Initialized
INFO - 2021-01-16 02:06:38 --> Router Class Initialized
INFO - 2021-01-16 02:06:38 --> Output Class Initialized
INFO - 2021-01-16 02:06:38 --> Security Class Initialized
DEBUG - 2021-01-16 02:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:06:38 --> Input Class Initialized
INFO - 2021-01-16 02:06:38 --> Language Class Initialized
ERROR - 2021-01-16 02:06:38 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4673
INFO - 2021-01-16 02:07:08 --> Config Class Initialized
INFO - 2021-01-16 02:07:08 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:07:08 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:07:08 --> Utf8 Class Initialized
INFO - 2021-01-16 02:07:08 --> URI Class Initialized
INFO - 2021-01-16 02:07:08 --> Router Class Initialized
INFO - 2021-01-16 02:07:08 --> Output Class Initialized
INFO - 2021-01-16 02:07:08 --> Security Class Initialized
DEBUG - 2021-01-16 02:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:07:08 --> Input Class Initialized
INFO - 2021-01-16 02:07:08 --> Language Class Initialized
ERROR - 2021-01-16 02:07:08 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4667
INFO - 2021-01-16 02:11:29 --> Config Class Initialized
INFO - 2021-01-16 02:11:29 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:11:29 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:11:29 --> Utf8 Class Initialized
INFO - 2021-01-16 02:11:29 --> URI Class Initialized
INFO - 2021-01-16 02:11:29 --> Router Class Initialized
INFO - 2021-01-16 02:11:29 --> Output Class Initialized
INFO - 2021-01-16 02:11:29 --> Security Class Initialized
DEBUG - 2021-01-16 02:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:11:29 --> Input Class Initialized
INFO - 2021-01-16 02:11:29 --> Language Class Initialized
ERROR - 2021-01-16 02:11:29 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4669
INFO - 2021-01-16 02:18:40 --> Config Class Initialized
INFO - 2021-01-16 02:18:40 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:18:40 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:18:40 --> Utf8 Class Initialized
INFO - 2021-01-16 02:18:40 --> URI Class Initialized
INFO - 2021-01-16 02:18:40 --> Router Class Initialized
INFO - 2021-01-16 02:18:40 --> Output Class Initialized
INFO - 2021-01-16 02:18:40 --> Security Class Initialized
DEBUG - 2021-01-16 02:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:18:40 --> Input Class Initialized
INFO - 2021-01-16 02:18:40 --> Language Class Initialized
INFO - 2021-01-16 02:18:40 --> Language Class Initialized
INFO - 2021-01-16 02:18:40 --> Config Class Initialized
INFO - 2021-01-16 02:18:40 --> Loader Class Initialized
INFO - 2021-01-16 02:18:40 --> Helper loaded: url_helper
INFO - 2021-01-16 02:18:40 --> Helper loaded: file_helper
INFO - 2021-01-16 02:18:40 --> Helper loaded: form_helper
INFO - 2021-01-16 02:18:40 --> Helper loaded: my_helper
INFO - 2021-01-16 02:18:40 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:18:40 --> Controller Class Initialized
ERROR - 2021-01-16 02:18:40 --> Severity: Notice --> Undefined index: id_kelas C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4328
ERROR - 2021-01-16 02:18:41 --> Severity: Notice --> Undefined index: id_kelas C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4337
ERROR - 2021-01-16 02:18:41 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4363
ERROR - 2021-01-16 02:18:41 --> Severity: Notice --> Undefined variable: jml_np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4377
ERROR - 2021-01-16 02:18:41 --> Severity: Notice --> Undefined variable: jml_nk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4381
ERROR - 2021-01-16 02:18:41 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4385
ERROR - 2021-01-16 02:18:41 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4363
ERROR - 2021-01-16 02:18:41 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4363
ERROR - 2021-01-16 02:18:41 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4363
ERROR - 2021-01-16 02:18:41 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4363
DEBUG - 2021-01-16 02:18:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:18:41 --> Final output sent to browser
DEBUG - 2021-01-16 02:18:41 --> Total execution time: 0.4219
INFO - 2021-01-16 02:21:36 --> Config Class Initialized
INFO - 2021-01-16 02:21:36 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:21:36 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:21:36 --> Utf8 Class Initialized
INFO - 2021-01-16 02:21:36 --> URI Class Initialized
INFO - 2021-01-16 02:21:36 --> Router Class Initialized
INFO - 2021-01-16 02:21:36 --> Output Class Initialized
INFO - 2021-01-16 02:21:36 --> Security Class Initialized
DEBUG - 2021-01-16 02:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:21:36 --> Input Class Initialized
INFO - 2021-01-16 02:21:36 --> Language Class Initialized
INFO - 2021-01-16 02:21:36 --> Language Class Initialized
INFO - 2021-01-16 02:21:36 --> Config Class Initialized
INFO - 2021-01-16 02:21:36 --> Loader Class Initialized
INFO - 2021-01-16 02:21:36 --> Helper loaded: url_helper
INFO - 2021-01-16 02:21:36 --> Helper loaded: file_helper
INFO - 2021-01-16 02:21:36 --> Helper loaded: form_helper
INFO - 2021-01-16 02:21:36 --> Helper loaded: my_helper
INFO - 2021-01-16 02:21:36 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:21:36 --> Controller Class Initialized
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined index: id_kelas C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4325
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined index: id_kelas C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4334
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined index: id_kelas C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4343
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4370
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined variable: jml_np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4384
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined variable: jml_nk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4388
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4392
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4370
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4370
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4370
ERROR - 2021-01-16 02:21:36 --> Severity: Notice --> Undefined variable: s C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4370
DEBUG - 2021-01-16 02:21:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:21:36 --> Final output sent to browser
DEBUG - 2021-01-16 02:21:36 --> Total execution time: 0.3993
INFO - 2021-01-16 02:21:55 --> Config Class Initialized
INFO - 2021-01-16 02:21:55 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:21:55 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:21:55 --> Utf8 Class Initialized
INFO - 2021-01-16 02:21:55 --> URI Class Initialized
INFO - 2021-01-16 02:21:55 --> Router Class Initialized
INFO - 2021-01-16 02:21:55 --> Output Class Initialized
INFO - 2021-01-16 02:21:55 --> Security Class Initialized
DEBUG - 2021-01-16 02:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:21:55 --> Input Class Initialized
INFO - 2021-01-16 02:21:55 --> Language Class Initialized
INFO - 2021-01-16 02:21:55 --> Language Class Initialized
INFO - 2021-01-16 02:21:55 --> Config Class Initialized
INFO - 2021-01-16 02:21:55 --> Loader Class Initialized
INFO - 2021-01-16 02:21:55 --> Helper loaded: url_helper
INFO - 2021-01-16 02:21:56 --> Helper loaded: file_helper
INFO - 2021-01-16 02:21:56 --> Helper loaded: form_helper
INFO - 2021-01-16 02:21:56 --> Helper loaded: my_helper
INFO - 2021-01-16 02:21:56 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:21:56 --> Controller Class Initialized
ERROR - 2021-01-16 02:21:56 --> Severity: Notice --> Undefined index: id_kelas C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4328
ERROR - 2021-01-16 02:21:56 --> Severity: Notice --> Undefined index: id_kelas C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4337
ERROR - 2021-01-16 02:21:56 --> Severity: Notice --> Undefined variable: s_siswa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4343
ERROR - 2021-01-16 02:21:56 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\nilai\system\database\drivers\mysqli\mysqli_driver.php 306
ERROR - 2021-01-16 02:21:56 --> Query error:  - Invalid query: 
INFO - 2021-01-16 02:21:56 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-16 02:22:35 --> Config Class Initialized
INFO - 2021-01-16 02:22:35 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:22:35 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:22:36 --> Utf8 Class Initialized
INFO - 2021-01-16 02:22:36 --> URI Class Initialized
INFO - 2021-01-16 02:22:36 --> Router Class Initialized
INFO - 2021-01-16 02:22:36 --> Output Class Initialized
INFO - 2021-01-16 02:22:36 --> Security Class Initialized
DEBUG - 2021-01-16 02:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:22:36 --> Input Class Initialized
INFO - 2021-01-16 02:22:36 --> Language Class Initialized
ERROR - 2021-01-16 02:22:36 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4669
INFO - 2021-01-16 02:23:05 --> Config Class Initialized
INFO - 2021-01-16 02:23:05 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:23:05 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:23:05 --> Utf8 Class Initialized
INFO - 2021-01-16 02:23:05 --> URI Class Initialized
INFO - 2021-01-16 02:23:05 --> Router Class Initialized
INFO - 2021-01-16 02:23:05 --> Output Class Initialized
INFO - 2021-01-16 02:23:05 --> Security Class Initialized
DEBUG - 2021-01-16 02:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:23:05 --> Input Class Initialized
INFO - 2021-01-16 02:23:05 --> Language Class Initialized
INFO - 2021-01-16 02:23:05 --> Language Class Initialized
INFO - 2021-01-16 02:23:05 --> Config Class Initialized
INFO - 2021-01-16 02:23:05 --> Loader Class Initialized
INFO - 2021-01-16 02:23:05 --> Helper loaded: url_helper
INFO - 2021-01-16 02:23:05 --> Helper loaded: file_helper
INFO - 2021-01-16 02:23:05 --> Helper loaded: form_helper
INFO - 2021-01-16 02:23:05 --> Helper loaded: my_helper
INFO - 2021-01-16 02:23:05 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:23:05 --> Controller Class Initialized
DEBUG - 2021-01-16 02:23:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:23:05 --> Final output sent to browser
DEBUG - 2021-01-16 02:23:05 --> Total execution time: 0.2924
INFO - 2021-01-16 02:24:42 --> Config Class Initialized
INFO - 2021-01-16 02:24:42 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:24:42 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:24:42 --> Utf8 Class Initialized
INFO - 2021-01-16 02:24:42 --> URI Class Initialized
INFO - 2021-01-16 02:24:42 --> Router Class Initialized
INFO - 2021-01-16 02:24:42 --> Output Class Initialized
INFO - 2021-01-16 02:24:42 --> Security Class Initialized
DEBUG - 2021-01-16 02:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:24:42 --> Input Class Initialized
INFO - 2021-01-16 02:24:42 --> Language Class Initialized
INFO - 2021-01-16 02:24:42 --> Language Class Initialized
INFO - 2021-01-16 02:24:42 --> Config Class Initialized
INFO - 2021-01-16 02:24:43 --> Loader Class Initialized
INFO - 2021-01-16 02:24:43 --> Helper loaded: url_helper
INFO - 2021-01-16 02:24:43 --> Helper loaded: file_helper
INFO - 2021-01-16 02:24:43 --> Helper loaded: form_helper
INFO - 2021-01-16 02:24:43 --> Helper loaded: my_helper
INFO - 2021-01-16 02:24:43 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:24:43 --> Controller Class Initialized
DEBUG - 2021-01-16 02:24:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:24:43 --> Final output sent to browser
DEBUG - 2021-01-16 02:24:43 --> Total execution time: 0.3063
INFO - 2021-01-16 02:30:51 --> Config Class Initialized
INFO - 2021-01-16 02:30:51 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:30:52 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:30:52 --> Utf8 Class Initialized
INFO - 2021-01-16 02:30:52 --> URI Class Initialized
INFO - 2021-01-16 02:30:52 --> Router Class Initialized
INFO - 2021-01-16 02:30:52 --> Output Class Initialized
INFO - 2021-01-16 02:30:52 --> Security Class Initialized
DEBUG - 2021-01-16 02:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:30:52 --> Input Class Initialized
INFO - 2021-01-16 02:30:52 --> Language Class Initialized
INFO - 2021-01-16 02:30:52 --> Language Class Initialized
INFO - 2021-01-16 02:30:52 --> Config Class Initialized
INFO - 2021-01-16 02:30:52 --> Loader Class Initialized
INFO - 2021-01-16 02:30:52 --> Helper loaded: url_helper
INFO - 2021-01-16 02:30:52 --> Helper loaded: file_helper
INFO - 2021-01-16 02:30:52 --> Helper loaded: form_helper
INFO - 2021-01-16 02:30:52 --> Helper loaded: my_helper
INFO - 2021-01-16 02:30:52 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:30:52 --> Controller Class Initialized
DEBUG - 2021-01-16 02:30:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:30:52 --> Final output sent to browser
DEBUG - 2021-01-16 02:30:52 --> Total execution time: 0.2750
INFO - 2021-01-16 02:31:23 --> Config Class Initialized
INFO - 2021-01-16 02:31:23 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:31:23 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:31:23 --> Utf8 Class Initialized
INFO - 2021-01-16 02:31:23 --> URI Class Initialized
INFO - 2021-01-16 02:31:23 --> Router Class Initialized
INFO - 2021-01-16 02:31:23 --> Output Class Initialized
INFO - 2021-01-16 02:31:23 --> Security Class Initialized
DEBUG - 2021-01-16 02:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:31:23 --> Input Class Initialized
INFO - 2021-01-16 02:31:23 --> Language Class Initialized
INFO - 2021-01-16 02:31:23 --> Language Class Initialized
INFO - 2021-01-16 02:31:23 --> Config Class Initialized
INFO - 2021-01-16 02:31:23 --> Loader Class Initialized
INFO - 2021-01-16 02:31:23 --> Helper loaded: url_helper
INFO - 2021-01-16 02:31:23 --> Helper loaded: file_helper
INFO - 2021-01-16 02:31:23 --> Helper loaded: form_helper
INFO - 2021-01-16 02:31:23 --> Helper loaded: my_helper
INFO - 2021-01-16 02:31:23 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:31:23 --> Controller Class Initialized
DEBUG - 2021-01-16 02:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 02:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 02:31:23 --> Final output sent to browser
DEBUG - 2021-01-16 02:31:23 --> Total execution time: 0.3428
INFO - 2021-01-16 02:31:30 --> Config Class Initialized
INFO - 2021-01-16 02:31:30 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:31:30 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:31:30 --> Utf8 Class Initialized
INFO - 2021-01-16 02:31:30 --> URI Class Initialized
INFO - 2021-01-16 02:31:30 --> Router Class Initialized
INFO - 2021-01-16 02:31:30 --> Output Class Initialized
INFO - 2021-01-16 02:31:30 --> Security Class Initialized
DEBUG - 2021-01-16 02:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:31:30 --> Input Class Initialized
INFO - 2021-01-16 02:31:30 --> Language Class Initialized
INFO - 2021-01-16 02:31:30 --> Language Class Initialized
INFO - 2021-01-16 02:31:30 --> Config Class Initialized
INFO - 2021-01-16 02:31:30 --> Loader Class Initialized
INFO - 2021-01-16 02:31:30 --> Helper loaded: url_helper
INFO - 2021-01-16 02:31:30 --> Helper loaded: file_helper
INFO - 2021-01-16 02:31:30 --> Helper loaded: form_helper
INFO - 2021-01-16 02:31:30 --> Helper loaded: my_helper
INFO - 2021-01-16 02:31:30 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:31:30 --> Controller Class Initialized
DEBUG - 2021-01-16 02:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-16 02:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 02:31:30 --> Final output sent to browser
DEBUG - 2021-01-16 02:31:30 --> Total execution time: 0.2903
INFO - 2021-01-16 02:31:30 --> Config Class Initialized
INFO - 2021-01-16 02:31:30 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:31:30 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:31:30 --> Utf8 Class Initialized
INFO - 2021-01-16 02:31:30 --> URI Class Initialized
INFO - 2021-01-16 02:31:30 --> Router Class Initialized
INFO - 2021-01-16 02:31:30 --> Output Class Initialized
INFO - 2021-01-16 02:31:30 --> Security Class Initialized
DEBUG - 2021-01-16 02:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:31:30 --> Input Class Initialized
INFO - 2021-01-16 02:31:30 --> Language Class Initialized
INFO - 2021-01-16 02:31:30 --> Language Class Initialized
INFO - 2021-01-16 02:31:30 --> Config Class Initialized
INFO - 2021-01-16 02:31:30 --> Loader Class Initialized
INFO - 2021-01-16 02:31:30 --> Helper loaded: url_helper
INFO - 2021-01-16 02:31:30 --> Helper loaded: file_helper
INFO - 2021-01-16 02:31:30 --> Helper loaded: form_helper
INFO - 2021-01-16 02:31:30 --> Helper loaded: my_helper
INFO - 2021-01-16 02:31:30 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:31:30 --> Controller Class Initialized
INFO - 2021-01-16 02:31:31 --> Config Class Initialized
INFO - 2021-01-16 02:31:31 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:31:31 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:31:31 --> Utf8 Class Initialized
INFO - 2021-01-16 02:31:31 --> URI Class Initialized
INFO - 2021-01-16 02:31:31 --> Router Class Initialized
INFO - 2021-01-16 02:31:31 --> Output Class Initialized
INFO - 2021-01-16 02:31:31 --> Security Class Initialized
DEBUG - 2021-01-16 02:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:31:31 --> Input Class Initialized
INFO - 2021-01-16 02:31:31 --> Language Class Initialized
INFO - 2021-01-16 02:31:31 --> Language Class Initialized
INFO - 2021-01-16 02:31:31 --> Config Class Initialized
INFO - 2021-01-16 02:31:31 --> Loader Class Initialized
INFO - 2021-01-16 02:31:31 --> Helper loaded: url_helper
INFO - 2021-01-16 02:31:31 --> Helper loaded: file_helper
INFO - 2021-01-16 02:31:31 --> Helper loaded: form_helper
INFO - 2021-01-16 02:31:31 --> Helper loaded: my_helper
INFO - 2021-01-16 02:31:31 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:31:32 --> Controller Class Initialized
DEBUG - 2021-01-16 02:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-16 02:31:32 --> Final output sent to browser
DEBUG - 2021-01-16 02:31:32 --> Total execution time: 0.3828
INFO - 2021-01-16 02:31:33 --> Config Class Initialized
INFO - 2021-01-16 02:31:33 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:31:33 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:31:33 --> Utf8 Class Initialized
INFO - 2021-01-16 02:31:33 --> URI Class Initialized
INFO - 2021-01-16 02:31:33 --> Router Class Initialized
INFO - 2021-01-16 02:31:33 --> Output Class Initialized
INFO - 2021-01-16 02:31:33 --> Security Class Initialized
DEBUG - 2021-01-16 02:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:31:33 --> Input Class Initialized
INFO - 2021-01-16 02:31:33 --> Language Class Initialized
INFO - 2021-01-16 02:31:33 --> Language Class Initialized
INFO - 2021-01-16 02:31:33 --> Config Class Initialized
INFO - 2021-01-16 02:31:33 --> Loader Class Initialized
INFO - 2021-01-16 02:31:33 --> Helper loaded: url_helper
INFO - 2021-01-16 02:31:33 --> Helper loaded: file_helper
INFO - 2021-01-16 02:31:33 --> Helper loaded: form_helper
INFO - 2021-01-16 02:31:33 --> Helper loaded: my_helper
INFO - 2021-01-16 02:31:33 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:31:33 --> Controller Class Initialized
DEBUG - 2021-01-16 02:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 02:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 02:31:33 --> Final output sent to browser
DEBUG - 2021-01-16 02:31:33 --> Total execution time: 0.3554
INFO - 2021-01-16 02:31:38 --> Config Class Initialized
INFO - 2021-01-16 02:31:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:31:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:31:38 --> Utf8 Class Initialized
INFO - 2021-01-16 02:31:38 --> URI Class Initialized
INFO - 2021-01-16 02:31:38 --> Router Class Initialized
INFO - 2021-01-16 02:31:38 --> Output Class Initialized
INFO - 2021-01-16 02:31:38 --> Security Class Initialized
DEBUG - 2021-01-16 02:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:31:38 --> Input Class Initialized
INFO - 2021-01-16 02:31:38 --> Language Class Initialized
INFO - 2021-01-16 02:31:38 --> Language Class Initialized
INFO - 2021-01-16 02:31:38 --> Config Class Initialized
INFO - 2021-01-16 02:31:38 --> Loader Class Initialized
INFO - 2021-01-16 02:31:38 --> Helper loaded: url_helper
INFO - 2021-01-16 02:31:38 --> Helper loaded: file_helper
INFO - 2021-01-16 02:31:38 --> Helper loaded: form_helper
INFO - 2021-01-16 02:31:38 --> Helper loaded: my_helper
INFO - 2021-01-16 02:31:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:31:38 --> Controller Class Initialized
DEBUG - 2021-01-16 02:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 02:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 02:31:38 --> Final output sent to browser
DEBUG - 2021-01-16 02:31:38 --> Total execution time: 0.3026
INFO - 2021-01-16 02:31:39 --> Config Class Initialized
INFO - 2021-01-16 02:31:39 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:31:39 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:31:39 --> Utf8 Class Initialized
INFO - 2021-01-16 02:31:39 --> URI Class Initialized
INFO - 2021-01-16 02:31:39 --> Router Class Initialized
INFO - 2021-01-16 02:31:39 --> Output Class Initialized
INFO - 2021-01-16 02:31:39 --> Security Class Initialized
DEBUG - 2021-01-16 02:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:31:39 --> Input Class Initialized
INFO - 2021-01-16 02:31:39 --> Language Class Initialized
INFO - 2021-01-16 02:31:40 --> Language Class Initialized
INFO - 2021-01-16 02:31:40 --> Config Class Initialized
INFO - 2021-01-16 02:31:40 --> Loader Class Initialized
INFO - 2021-01-16 02:31:40 --> Helper loaded: url_helper
INFO - 2021-01-16 02:31:40 --> Helper loaded: file_helper
INFO - 2021-01-16 02:31:40 --> Helper loaded: form_helper
INFO - 2021-01-16 02:31:40 --> Helper loaded: my_helper
INFO - 2021-01-16 02:31:40 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:31:40 --> Controller Class Initialized
DEBUG - 2021-01-16 02:31:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-16 02:31:40 --> Final output sent to browser
DEBUG - 2021-01-16 02:31:40 --> Total execution time: 0.3281
INFO - 2021-01-16 02:33:16 --> Config Class Initialized
INFO - 2021-01-16 02:33:16 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:33:16 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:33:16 --> Utf8 Class Initialized
INFO - 2021-01-16 02:33:16 --> URI Class Initialized
INFO - 2021-01-16 02:33:16 --> Router Class Initialized
INFO - 2021-01-16 02:33:16 --> Output Class Initialized
INFO - 2021-01-16 02:33:16 --> Security Class Initialized
DEBUG - 2021-01-16 02:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:33:16 --> Input Class Initialized
INFO - 2021-01-16 02:33:16 --> Language Class Initialized
INFO - 2021-01-16 02:33:16 --> Language Class Initialized
INFO - 2021-01-16 02:33:16 --> Config Class Initialized
INFO - 2021-01-16 02:33:16 --> Loader Class Initialized
INFO - 2021-01-16 02:33:16 --> Helper loaded: url_helper
INFO - 2021-01-16 02:33:16 --> Helper loaded: file_helper
INFO - 2021-01-16 02:33:16 --> Helper loaded: form_helper
INFO - 2021-01-16 02:33:16 --> Helper loaded: my_helper
INFO - 2021-01-16 02:33:16 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:33:16 --> Controller Class Initialized
DEBUG - 2021-01-16 02:33:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:33:16 --> Final output sent to browser
DEBUG - 2021-01-16 02:33:16 --> Total execution time: 0.2905
INFO - 2021-01-16 02:34:44 --> Config Class Initialized
INFO - 2021-01-16 02:34:44 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:34:44 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:34:44 --> Utf8 Class Initialized
INFO - 2021-01-16 02:34:44 --> URI Class Initialized
INFO - 2021-01-16 02:34:44 --> Router Class Initialized
INFO - 2021-01-16 02:34:44 --> Output Class Initialized
INFO - 2021-01-16 02:34:44 --> Security Class Initialized
DEBUG - 2021-01-16 02:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:34:44 --> Input Class Initialized
INFO - 2021-01-16 02:34:44 --> Language Class Initialized
INFO - 2021-01-16 02:34:45 --> Language Class Initialized
INFO - 2021-01-16 02:34:45 --> Config Class Initialized
INFO - 2021-01-16 02:34:45 --> Loader Class Initialized
INFO - 2021-01-16 02:34:45 --> Helper loaded: url_helper
INFO - 2021-01-16 02:34:45 --> Helper loaded: file_helper
INFO - 2021-01-16 02:34:45 --> Helper loaded: form_helper
INFO - 2021-01-16 02:34:45 --> Helper loaded: my_helper
INFO - 2021-01-16 02:34:45 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:34:45 --> Controller Class Initialized
DEBUG - 2021-01-16 02:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:34:45 --> Final output sent to browser
DEBUG - 2021-01-16 02:34:45 --> Total execution time: 0.2972
INFO - 2021-01-16 02:34:55 --> Config Class Initialized
INFO - 2021-01-16 02:34:55 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:34:55 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:34:55 --> Utf8 Class Initialized
INFO - 2021-01-16 02:34:55 --> URI Class Initialized
INFO - 2021-01-16 02:34:55 --> Router Class Initialized
INFO - 2021-01-16 02:34:55 --> Output Class Initialized
INFO - 2021-01-16 02:34:55 --> Security Class Initialized
DEBUG - 2021-01-16 02:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:34:56 --> Input Class Initialized
INFO - 2021-01-16 02:34:56 --> Language Class Initialized
INFO - 2021-01-16 02:34:56 --> Language Class Initialized
INFO - 2021-01-16 02:34:56 --> Config Class Initialized
INFO - 2021-01-16 02:34:56 --> Loader Class Initialized
INFO - 2021-01-16 02:34:56 --> Helper loaded: url_helper
INFO - 2021-01-16 02:34:56 --> Helper loaded: file_helper
INFO - 2021-01-16 02:34:56 --> Helper loaded: form_helper
INFO - 2021-01-16 02:34:56 --> Helper loaded: my_helper
INFO - 2021-01-16 02:34:56 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:34:56 --> Controller Class Initialized
ERROR - 2021-01-16 02:34:56 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4487
ERROR - 2021-01-16 02:34:56 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4487
ERROR - 2021-01-16 02:34:56 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4487
DEBUG - 2021-01-16 02:34:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:34:56 --> Final output sent to browser
DEBUG - 2021-01-16 02:34:56 --> Total execution time: 0.3258
INFO - 2021-01-16 02:35:08 --> Config Class Initialized
INFO - 2021-01-16 02:35:08 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:35:08 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:35:08 --> Utf8 Class Initialized
INFO - 2021-01-16 02:35:08 --> URI Class Initialized
INFO - 2021-01-16 02:35:08 --> Router Class Initialized
INFO - 2021-01-16 02:35:08 --> Output Class Initialized
INFO - 2021-01-16 02:35:08 --> Security Class Initialized
DEBUG - 2021-01-16 02:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:35:08 --> Input Class Initialized
INFO - 2021-01-16 02:35:08 --> Language Class Initialized
INFO - 2021-01-16 02:35:08 --> Language Class Initialized
INFO - 2021-01-16 02:35:08 --> Config Class Initialized
INFO - 2021-01-16 02:35:08 --> Loader Class Initialized
INFO - 2021-01-16 02:35:08 --> Helper loaded: url_helper
INFO - 2021-01-16 02:35:09 --> Helper loaded: file_helper
INFO - 2021-01-16 02:35:09 --> Helper loaded: form_helper
INFO - 2021-01-16 02:35:09 --> Helper loaded: my_helper
INFO - 2021-01-16 02:35:09 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:35:09 --> Controller Class Initialized
DEBUG - 2021-01-16 02:35:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:35:09 --> Final output sent to browser
DEBUG - 2021-01-16 02:35:09 --> Total execution time: 0.3308
INFO - 2021-01-16 02:42:30 --> Config Class Initialized
INFO - 2021-01-16 02:42:30 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:42:30 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:42:30 --> Utf8 Class Initialized
INFO - 2021-01-16 02:42:30 --> URI Class Initialized
INFO - 2021-01-16 02:42:30 --> Router Class Initialized
INFO - 2021-01-16 02:42:30 --> Output Class Initialized
INFO - 2021-01-16 02:42:30 --> Security Class Initialized
DEBUG - 2021-01-16 02:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:42:30 --> Input Class Initialized
INFO - 2021-01-16 02:42:30 --> Language Class Initialized
INFO - 2021-01-16 02:42:30 --> Language Class Initialized
INFO - 2021-01-16 02:42:30 --> Config Class Initialized
INFO - 2021-01-16 02:42:30 --> Loader Class Initialized
INFO - 2021-01-16 02:42:30 --> Helper loaded: url_helper
INFO - 2021-01-16 02:42:30 --> Helper loaded: file_helper
INFO - 2021-01-16 02:42:30 --> Helper loaded: form_helper
INFO - 2021-01-16 02:42:30 --> Helper loaded: my_helper
INFO - 2021-01-16 02:42:30 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:42:30 --> Controller Class Initialized
DEBUG - 2021-01-16 02:42:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:42:30 --> Final output sent to browser
DEBUG - 2021-01-16 02:42:30 --> Total execution time: 0.3444
INFO - 2021-01-16 02:42:53 --> Config Class Initialized
INFO - 2021-01-16 02:42:53 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:42:53 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:42:54 --> Utf8 Class Initialized
INFO - 2021-01-16 02:42:54 --> URI Class Initialized
INFO - 2021-01-16 02:42:54 --> Router Class Initialized
INFO - 2021-01-16 02:42:54 --> Output Class Initialized
INFO - 2021-01-16 02:42:54 --> Security Class Initialized
DEBUG - 2021-01-16 02:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:42:54 --> Input Class Initialized
INFO - 2021-01-16 02:42:54 --> Language Class Initialized
INFO - 2021-01-16 02:42:54 --> Language Class Initialized
INFO - 2021-01-16 02:42:54 --> Config Class Initialized
INFO - 2021-01-16 02:42:54 --> Loader Class Initialized
INFO - 2021-01-16 02:42:54 --> Helper loaded: url_helper
INFO - 2021-01-16 02:42:54 --> Helper loaded: file_helper
INFO - 2021-01-16 02:42:54 --> Helper loaded: form_helper
INFO - 2021-01-16 02:42:54 --> Helper loaded: my_helper
INFO - 2021-01-16 02:42:54 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:42:54 --> Controller Class Initialized
DEBUG - 2021-01-16 02:42:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:42:54 --> Final output sent to browser
DEBUG - 2021-01-16 02:42:54 --> Total execution time: 0.2829
INFO - 2021-01-16 02:43:37 --> Config Class Initialized
INFO - 2021-01-16 02:43:37 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:43:37 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:43:37 --> Utf8 Class Initialized
INFO - 2021-01-16 02:43:37 --> URI Class Initialized
INFO - 2021-01-16 02:43:37 --> Router Class Initialized
INFO - 2021-01-16 02:43:37 --> Output Class Initialized
INFO - 2021-01-16 02:43:37 --> Security Class Initialized
DEBUG - 2021-01-16 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:43:37 --> Input Class Initialized
INFO - 2021-01-16 02:43:37 --> Language Class Initialized
INFO - 2021-01-16 02:43:37 --> Language Class Initialized
INFO - 2021-01-16 02:43:37 --> Config Class Initialized
INFO - 2021-01-16 02:43:37 --> Loader Class Initialized
INFO - 2021-01-16 02:43:37 --> Helper loaded: url_helper
INFO - 2021-01-16 02:43:37 --> Helper loaded: file_helper
INFO - 2021-01-16 02:43:37 --> Helper loaded: form_helper
INFO - 2021-01-16 02:43:37 --> Helper loaded: my_helper
INFO - 2021-01-16 02:43:37 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:43:37 --> Controller Class Initialized
ERROR - 2021-01-16 02:43:37 --> Severity: Notice --> Undefined variable: array3 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4483
ERROR - 2021-01-16 02:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4483
DEBUG - 2021-01-16 02:43:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:43:37 --> Final output sent to browser
DEBUG - 2021-01-16 02:43:37 --> Total execution time: 0.3038
INFO - 2021-01-16 02:43:47 --> Config Class Initialized
INFO - 2021-01-16 02:43:47 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:43:47 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:43:47 --> Utf8 Class Initialized
INFO - 2021-01-16 02:43:47 --> URI Class Initialized
INFO - 2021-01-16 02:43:47 --> Router Class Initialized
INFO - 2021-01-16 02:43:47 --> Output Class Initialized
INFO - 2021-01-16 02:43:47 --> Security Class Initialized
DEBUG - 2021-01-16 02:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:43:47 --> Input Class Initialized
INFO - 2021-01-16 02:43:47 --> Language Class Initialized
INFO - 2021-01-16 02:43:47 --> Language Class Initialized
INFO - 2021-01-16 02:43:47 --> Config Class Initialized
INFO - 2021-01-16 02:43:47 --> Loader Class Initialized
INFO - 2021-01-16 02:43:47 --> Helper loaded: url_helper
INFO - 2021-01-16 02:43:47 --> Helper loaded: file_helper
INFO - 2021-01-16 02:43:47 --> Helper loaded: form_helper
INFO - 2021-01-16 02:43:47 --> Helper loaded: my_helper
INFO - 2021-01-16 02:43:47 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:43:47 --> Controller Class Initialized
DEBUG - 2021-01-16 02:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:43:47 --> Final output sent to browser
DEBUG - 2021-01-16 02:43:47 --> Total execution time: 0.2852
INFO - 2021-01-16 02:45:25 --> Config Class Initialized
INFO - 2021-01-16 02:45:25 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:45:25 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:45:25 --> Utf8 Class Initialized
INFO - 2021-01-16 02:45:25 --> URI Class Initialized
INFO - 2021-01-16 02:45:25 --> Router Class Initialized
INFO - 2021-01-16 02:45:25 --> Output Class Initialized
INFO - 2021-01-16 02:45:25 --> Security Class Initialized
DEBUG - 2021-01-16 02:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:45:25 --> Input Class Initialized
INFO - 2021-01-16 02:45:25 --> Language Class Initialized
INFO - 2021-01-16 02:45:25 --> Language Class Initialized
INFO - 2021-01-16 02:45:25 --> Config Class Initialized
INFO - 2021-01-16 02:45:25 --> Loader Class Initialized
INFO - 2021-01-16 02:45:25 --> Helper loaded: url_helper
INFO - 2021-01-16 02:45:25 --> Helper loaded: file_helper
INFO - 2021-01-16 02:45:25 --> Helper loaded: form_helper
INFO - 2021-01-16 02:45:25 --> Helper loaded: my_helper
INFO - 2021-01-16 02:45:25 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:45:25 --> Controller Class Initialized
DEBUG - 2021-01-16 02:45:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-16 02:45:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 02:45:25 --> Final output sent to browser
DEBUG - 2021-01-16 02:45:25 --> Total execution time: 0.3174
INFO - 2021-01-16 02:45:27 --> Config Class Initialized
INFO - 2021-01-16 02:45:27 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:45:27 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:45:27 --> Utf8 Class Initialized
INFO - 2021-01-16 02:45:27 --> URI Class Initialized
INFO - 2021-01-16 02:45:27 --> Router Class Initialized
INFO - 2021-01-16 02:45:27 --> Output Class Initialized
INFO - 2021-01-16 02:45:27 --> Security Class Initialized
DEBUG - 2021-01-16 02:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:45:27 --> Input Class Initialized
INFO - 2021-01-16 02:45:27 --> Language Class Initialized
INFO - 2021-01-16 02:45:27 --> Language Class Initialized
INFO - 2021-01-16 02:45:27 --> Config Class Initialized
INFO - 2021-01-16 02:45:27 --> Loader Class Initialized
INFO - 2021-01-16 02:45:27 --> Helper loaded: url_helper
INFO - 2021-01-16 02:45:27 --> Helper loaded: file_helper
INFO - 2021-01-16 02:45:27 --> Helper loaded: form_helper
INFO - 2021-01-16 02:45:27 --> Helper loaded: my_helper
INFO - 2021-01-16 02:45:27 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:45:27 --> Controller Class Initialized
DEBUG - 2021-01-16 02:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-16 02:45:27 --> Final output sent to browser
DEBUG - 2021-01-16 02:45:27 --> Total execution time: 0.3285
INFO - 2021-01-16 02:45:52 --> Config Class Initialized
INFO - 2021-01-16 02:45:52 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:45:52 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:45:52 --> Utf8 Class Initialized
INFO - 2021-01-16 02:45:52 --> URI Class Initialized
INFO - 2021-01-16 02:45:52 --> Router Class Initialized
INFO - 2021-01-16 02:45:52 --> Output Class Initialized
INFO - 2021-01-16 02:45:52 --> Security Class Initialized
DEBUG - 2021-01-16 02:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:45:52 --> Input Class Initialized
INFO - 2021-01-16 02:45:52 --> Language Class Initialized
INFO - 2021-01-16 02:45:52 --> Language Class Initialized
INFO - 2021-01-16 02:45:52 --> Config Class Initialized
INFO - 2021-01-16 02:45:52 --> Loader Class Initialized
INFO - 2021-01-16 02:45:53 --> Helper loaded: url_helper
INFO - 2021-01-16 02:45:53 --> Helper loaded: file_helper
INFO - 2021-01-16 02:45:53 --> Helper loaded: form_helper
INFO - 2021-01-16 02:45:53 --> Helper loaded: my_helper
INFO - 2021-01-16 02:45:53 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:45:53 --> Controller Class Initialized
DEBUG - 2021-01-16 02:45:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2021-01-16 02:45:53 --> Final output sent to browser
DEBUG - 2021-01-16 02:45:53 --> Total execution time: 0.3044
INFO - 2021-01-16 02:46:15 --> Config Class Initialized
INFO - 2021-01-16 02:46:15 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:46:15 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:46:15 --> Utf8 Class Initialized
INFO - 2021-01-16 02:46:15 --> URI Class Initialized
INFO - 2021-01-16 02:46:15 --> Router Class Initialized
INFO - 2021-01-16 02:46:15 --> Output Class Initialized
INFO - 2021-01-16 02:46:15 --> Security Class Initialized
DEBUG - 2021-01-16 02:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:46:15 --> Input Class Initialized
INFO - 2021-01-16 02:46:15 --> Language Class Initialized
INFO - 2021-01-16 02:46:15 --> Language Class Initialized
INFO - 2021-01-16 02:46:15 --> Config Class Initialized
INFO - 2021-01-16 02:46:15 --> Loader Class Initialized
INFO - 2021-01-16 02:46:15 --> Helper loaded: url_helper
INFO - 2021-01-16 02:46:15 --> Helper loaded: file_helper
INFO - 2021-01-16 02:46:15 --> Helper loaded: form_helper
INFO - 2021-01-16 02:46:15 --> Helper loaded: my_helper
INFO - 2021-01-16 02:46:15 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:46:15 --> Controller Class Initialized
DEBUG - 2021-01-16 02:46:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-16 02:46:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 02:46:15 --> Final output sent to browser
DEBUG - 2021-01-16 02:46:15 --> Total execution time: 0.3610
INFO - 2021-01-16 02:46:17 --> Config Class Initialized
INFO - 2021-01-16 02:46:17 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:46:17 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:46:17 --> Utf8 Class Initialized
INFO - 2021-01-16 02:46:17 --> URI Class Initialized
INFO - 2021-01-16 02:46:17 --> Router Class Initialized
INFO - 2021-01-16 02:46:17 --> Output Class Initialized
INFO - 2021-01-16 02:46:17 --> Security Class Initialized
DEBUG - 2021-01-16 02:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:46:17 --> Input Class Initialized
INFO - 2021-01-16 02:46:17 --> Language Class Initialized
INFO - 2021-01-16 02:46:17 --> Language Class Initialized
INFO - 2021-01-16 02:46:17 --> Config Class Initialized
INFO - 2021-01-16 02:46:17 --> Loader Class Initialized
INFO - 2021-01-16 02:46:17 --> Helper loaded: url_helper
INFO - 2021-01-16 02:46:17 --> Helper loaded: file_helper
INFO - 2021-01-16 02:46:17 --> Helper loaded: form_helper
INFO - 2021-01-16 02:46:17 --> Helper loaded: my_helper
INFO - 2021-01-16 02:46:17 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:46:17 --> Controller Class Initialized
DEBUG - 2021-01-16 02:46:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:46:17 --> Final output sent to browser
DEBUG - 2021-01-16 02:46:17 --> Total execution time: 0.2992
INFO - 2021-01-16 02:48:38 --> Config Class Initialized
INFO - 2021-01-16 02:48:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:48:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:48:38 --> Utf8 Class Initialized
INFO - 2021-01-16 02:48:38 --> URI Class Initialized
INFO - 2021-01-16 02:48:38 --> Router Class Initialized
INFO - 2021-01-16 02:48:38 --> Output Class Initialized
INFO - 2021-01-16 02:48:38 --> Security Class Initialized
DEBUG - 2021-01-16 02:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:48:38 --> Input Class Initialized
INFO - 2021-01-16 02:48:38 --> Language Class Initialized
INFO - 2021-01-16 02:48:38 --> Language Class Initialized
INFO - 2021-01-16 02:48:38 --> Config Class Initialized
INFO - 2021-01-16 02:48:38 --> Loader Class Initialized
INFO - 2021-01-16 02:48:38 --> Helper loaded: url_helper
INFO - 2021-01-16 02:48:38 --> Helper loaded: file_helper
INFO - 2021-01-16 02:48:38 --> Helper loaded: form_helper
INFO - 2021-01-16 02:48:38 --> Helper loaded: my_helper
INFO - 2021-01-16 02:48:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:48:38 --> Controller Class Initialized
DEBUG - 2021-01-16 02:48:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:48:38 --> Final output sent to browser
DEBUG - 2021-01-16 02:48:38 --> Total execution time: 0.2671
INFO - 2021-01-16 02:51:14 --> Config Class Initialized
INFO - 2021-01-16 02:51:14 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:51:14 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:51:14 --> Utf8 Class Initialized
INFO - 2021-01-16 02:51:14 --> URI Class Initialized
INFO - 2021-01-16 02:51:14 --> Router Class Initialized
INFO - 2021-01-16 02:51:14 --> Output Class Initialized
INFO - 2021-01-16 02:51:14 --> Security Class Initialized
DEBUG - 2021-01-16 02:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:51:15 --> Input Class Initialized
INFO - 2021-01-16 02:51:15 --> Language Class Initialized
INFO - 2021-01-16 02:51:15 --> Language Class Initialized
INFO - 2021-01-16 02:51:15 --> Config Class Initialized
INFO - 2021-01-16 02:51:15 --> Loader Class Initialized
INFO - 2021-01-16 02:51:15 --> Helper loaded: url_helper
INFO - 2021-01-16 02:51:15 --> Helper loaded: file_helper
INFO - 2021-01-16 02:51:15 --> Helper loaded: form_helper
INFO - 2021-01-16 02:51:15 --> Helper loaded: my_helper
INFO - 2021-01-16 02:51:15 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:51:15 --> Controller Class Initialized
DEBUG - 2021-01-16 02:51:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 02:51:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 02:51:15 --> Final output sent to browser
DEBUG - 2021-01-16 02:51:15 --> Total execution time: 0.2805
INFO - 2021-01-16 02:51:18 --> Config Class Initialized
INFO - 2021-01-16 02:51:18 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:51:18 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:51:18 --> Utf8 Class Initialized
INFO - 2021-01-16 02:51:18 --> URI Class Initialized
INFO - 2021-01-16 02:51:18 --> Router Class Initialized
INFO - 2021-01-16 02:51:18 --> Output Class Initialized
INFO - 2021-01-16 02:51:18 --> Security Class Initialized
DEBUG - 2021-01-16 02:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:51:18 --> Input Class Initialized
INFO - 2021-01-16 02:51:18 --> Language Class Initialized
INFO - 2021-01-16 02:51:18 --> Language Class Initialized
INFO - 2021-01-16 02:51:18 --> Config Class Initialized
INFO - 2021-01-16 02:51:18 --> Loader Class Initialized
INFO - 2021-01-16 02:51:18 --> Helper loaded: url_helper
INFO - 2021-01-16 02:51:18 --> Helper loaded: file_helper
INFO - 2021-01-16 02:51:18 --> Helper loaded: form_helper
INFO - 2021-01-16 02:51:18 --> Helper loaded: my_helper
INFO - 2021-01-16 02:51:18 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:51:18 --> Controller Class Initialized
DEBUG - 2021-01-16 02:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 02:51:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 02:51:18 --> Final output sent to browser
DEBUG - 2021-01-16 02:51:18 --> Total execution time: 0.2707
INFO - 2021-01-16 02:51:19 --> Config Class Initialized
INFO - 2021-01-16 02:51:19 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:51:19 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:51:19 --> Utf8 Class Initialized
INFO - 2021-01-16 02:51:19 --> URI Class Initialized
INFO - 2021-01-16 02:51:19 --> Router Class Initialized
INFO - 2021-01-16 02:51:19 --> Output Class Initialized
INFO - 2021-01-16 02:51:19 --> Security Class Initialized
DEBUG - 2021-01-16 02:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:51:19 --> Input Class Initialized
INFO - 2021-01-16 02:51:19 --> Language Class Initialized
INFO - 2021-01-16 02:51:19 --> Language Class Initialized
INFO - 2021-01-16 02:51:19 --> Config Class Initialized
INFO - 2021-01-16 02:51:19 --> Loader Class Initialized
INFO - 2021-01-16 02:51:19 --> Helper loaded: url_helper
INFO - 2021-01-16 02:51:19 --> Helper loaded: file_helper
INFO - 2021-01-16 02:51:19 --> Helper loaded: form_helper
INFO - 2021-01-16 02:51:19 --> Helper loaded: my_helper
INFO - 2021-01-16 02:51:19 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:51:19 --> Controller Class Initialized
DEBUG - 2021-01-16 02:51:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-16 02:51:19 --> Final output sent to browser
DEBUG - 2021-01-16 02:51:19 --> Total execution time: 0.3298
INFO - 2021-01-16 02:51:34 --> Config Class Initialized
INFO - 2021-01-16 02:51:34 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:51:34 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:51:34 --> Utf8 Class Initialized
INFO - 2021-01-16 02:51:34 --> URI Class Initialized
INFO - 2021-01-16 02:51:34 --> Router Class Initialized
INFO - 2021-01-16 02:51:34 --> Output Class Initialized
INFO - 2021-01-16 02:51:34 --> Security Class Initialized
DEBUG - 2021-01-16 02:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:51:34 --> Input Class Initialized
INFO - 2021-01-16 02:51:34 --> Language Class Initialized
INFO - 2021-01-16 02:51:34 --> Language Class Initialized
INFO - 2021-01-16 02:51:34 --> Config Class Initialized
INFO - 2021-01-16 02:51:34 --> Loader Class Initialized
INFO - 2021-01-16 02:51:34 --> Helper loaded: url_helper
INFO - 2021-01-16 02:51:34 --> Helper loaded: file_helper
INFO - 2021-01-16 02:51:34 --> Helper loaded: form_helper
INFO - 2021-01-16 02:51:34 --> Helper loaded: my_helper
INFO - 2021-01-16 02:51:34 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:51:34 --> Controller Class Initialized
DEBUG - 2021-01-16 02:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-16 02:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 02:51:34 --> Final output sent to browser
DEBUG - 2021-01-16 02:51:34 --> Total execution time: 0.3177
INFO - 2021-01-16 02:54:23 --> Config Class Initialized
INFO - 2021-01-16 02:54:23 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:54:23 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:54:23 --> Utf8 Class Initialized
INFO - 2021-01-16 02:54:23 --> URI Class Initialized
INFO - 2021-01-16 02:54:23 --> Router Class Initialized
INFO - 2021-01-16 02:54:23 --> Output Class Initialized
INFO - 2021-01-16 02:54:23 --> Security Class Initialized
DEBUG - 2021-01-16 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:54:23 --> Input Class Initialized
INFO - 2021-01-16 02:54:23 --> Language Class Initialized
INFO - 2021-01-16 02:54:23 --> Language Class Initialized
INFO - 2021-01-16 02:54:23 --> Config Class Initialized
INFO - 2021-01-16 02:54:23 --> Loader Class Initialized
INFO - 2021-01-16 02:54:23 --> Helper loaded: url_helper
INFO - 2021-01-16 02:54:23 --> Helper loaded: file_helper
INFO - 2021-01-16 02:54:23 --> Helper loaded: form_helper
INFO - 2021-01-16 02:54:23 --> Helper loaded: my_helper
INFO - 2021-01-16 02:54:23 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:54:23 --> Controller Class Initialized
DEBUG - 2021-01-16 02:54:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:54:23 --> Final output sent to browser
DEBUG - 2021-01-16 02:54:23 --> Total execution time: 0.2793
INFO - 2021-01-16 02:54:36 --> Config Class Initialized
INFO - 2021-01-16 02:54:36 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:54:36 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:54:36 --> Utf8 Class Initialized
INFO - 2021-01-16 02:54:36 --> URI Class Initialized
INFO - 2021-01-16 02:54:36 --> Router Class Initialized
INFO - 2021-01-16 02:54:36 --> Output Class Initialized
INFO - 2021-01-16 02:54:36 --> Security Class Initialized
DEBUG - 2021-01-16 02:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:54:36 --> Input Class Initialized
INFO - 2021-01-16 02:54:36 --> Language Class Initialized
INFO - 2021-01-16 02:54:36 --> Language Class Initialized
INFO - 2021-01-16 02:54:36 --> Config Class Initialized
INFO - 2021-01-16 02:54:36 --> Loader Class Initialized
INFO - 2021-01-16 02:54:36 --> Helper loaded: url_helper
INFO - 2021-01-16 02:54:36 --> Helper loaded: file_helper
INFO - 2021-01-16 02:54:36 --> Helper loaded: form_helper
INFO - 2021-01-16 02:54:36 --> Helper loaded: my_helper
INFO - 2021-01-16 02:54:36 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:54:36 --> Controller Class Initialized
DEBUG - 2021-01-16 02:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:54:36 --> Final output sent to browser
DEBUG - 2021-01-16 02:54:36 --> Total execution time: 0.2867
INFO - 2021-01-16 02:57:50 --> Config Class Initialized
INFO - 2021-01-16 02:57:50 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:57:50 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:57:50 --> Utf8 Class Initialized
INFO - 2021-01-16 02:57:50 --> URI Class Initialized
INFO - 2021-01-16 02:57:50 --> Router Class Initialized
INFO - 2021-01-16 02:57:50 --> Output Class Initialized
INFO - 2021-01-16 02:57:50 --> Security Class Initialized
DEBUG - 2021-01-16 02:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:57:50 --> Input Class Initialized
INFO - 2021-01-16 02:57:50 --> Language Class Initialized
INFO - 2021-01-16 02:57:50 --> Language Class Initialized
INFO - 2021-01-16 02:57:50 --> Config Class Initialized
INFO - 2021-01-16 02:57:50 --> Loader Class Initialized
INFO - 2021-01-16 02:57:50 --> Helper loaded: url_helper
INFO - 2021-01-16 02:57:50 --> Helper loaded: file_helper
INFO - 2021-01-16 02:57:50 --> Helper loaded: form_helper
INFO - 2021-01-16 02:57:50 --> Helper loaded: my_helper
INFO - 2021-01-16 02:57:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:57:50 --> Controller Class Initialized
DEBUG - 2021-01-16 02:57:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:57:50 --> Final output sent to browser
DEBUG - 2021-01-16 02:57:50 --> Total execution time: 0.2716
INFO - 2021-01-16 02:58:11 --> Config Class Initialized
INFO - 2021-01-16 02:58:11 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:58:11 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:58:11 --> Utf8 Class Initialized
INFO - 2021-01-16 02:58:11 --> URI Class Initialized
INFO - 2021-01-16 02:58:11 --> Router Class Initialized
INFO - 2021-01-16 02:58:11 --> Output Class Initialized
INFO - 2021-01-16 02:58:11 --> Security Class Initialized
DEBUG - 2021-01-16 02:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:58:11 --> Input Class Initialized
INFO - 2021-01-16 02:58:11 --> Language Class Initialized
INFO - 2021-01-16 02:58:11 --> Language Class Initialized
INFO - 2021-01-16 02:58:11 --> Config Class Initialized
INFO - 2021-01-16 02:58:11 --> Loader Class Initialized
INFO - 2021-01-16 02:58:11 --> Helper loaded: url_helper
INFO - 2021-01-16 02:58:11 --> Helper loaded: file_helper
INFO - 2021-01-16 02:58:11 --> Helper loaded: form_helper
INFO - 2021-01-16 02:58:11 --> Helper loaded: my_helper
INFO - 2021-01-16 02:58:11 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:58:11 --> Controller Class Initialized
DEBUG - 2021-01-16 02:58:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-16 02:58:12 --> Final output sent to browser
DEBUG - 2021-01-16 02:58:12 --> Total execution time: 0.2922
INFO - 2021-01-16 02:58:37 --> Config Class Initialized
INFO - 2021-01-16 02:58:37 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:58:37 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:58:37 --> Utf8 Class Initialized
INFO - 2021-01-16 02:58:37 --> URI Class Initialized
INFO - 2021-01-16 02:58:37 --> Router Class Initialized
INFO - 2021-01-16 02:58:37 --> Output Class Initialized
INFO - 2021-01-16 02:58:37 --> Security Class Initialized
DEBUG - 2021-01-16 02:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:58:37 --> Input Class Initialized
INFO - 2021-01-16 02:58:37 --> Language Class Initialized
INFO - 2021-01-16 02:58:37 --> Language Class Initialized
INFO - 2021-01-16 02:58:37 --> Config Class Initialized
INFO - 2021-01-16 02:58:37 --> Loader Class Initialized
INFO - 2021-01-16 02:58:37 --> Helper loaded: url_helper
INFO - 2021-01-16 02:58:38 --> Helper loaded: file_helper
INFO - 2021-01-16 02:58:38 --> Helper loaded: form_helper
INFO - 2021-01-16 02:58:38 --> Helper loaded: my_helper
INFO - 2021-01-16 02:58:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:58:38 --> Controller Class Initialized
DEBUG - 2021-01-16 02:58:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:58:38 --> Final output sent to browser
DEBUG - 2021-01-16 02:58:38 --> Total execution time: 0.3684
INFO - 2021-01-16 02:59:53 --> Config Class Initialized
INFO - 2021-01-16 02:59:53 --> Hooks Class Initialized
DEBUG - 2021-01-16 02:59:53 --> UTF-8 Support Enabled
INFO - 2021-01-16 02:59:53 --> Utf8 Class Initialized
INFO - 2021-01-16 02:59:53 --> URI Class Initialized
INFO - 2021-01-16 02:59:53 --> Router Class Initialized
INFO - 2021-01-16 02:59:53 --> Output Class Initialized
INFO - 2021-01-16 02:59:53 --> Security Class Initialized
DEBUG - 2021-01-16 02:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 02:59:53 --> Input Class Initialized
INFO - 2021-01-16 02:59:53 --> Language Class Initialized
INFO - 2021-01-16 02:59:53 --> Language Class Initialized
INFO - 2021-01-16 02:59:53 --> Config Class Initialized
INFO - 2021-01-16 02:59:53 --> Loader Class Initialized
INFO - 2021-01-16 02:59:53 --> Helper loaded: url_helper
INFO - 2021-01-16 02:59:53 --> Helper loaded: file_helper
INFO - 2021-01-16 02:59:53 --> Helper loaded: form_helper
INFO - 2021-01-16 02:59:53 --> Helper loaded: my_helper
INFO - 2021-01-16 02:59:53 --> Database Driver Class Initialized
DEBUG - 2021-01-16 02:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 02:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 02:59:53 --> Controller Class Initialized
DEBUG - 2021-01-16 02:59:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 02:59:54 --> Final output sent to browser
DEBUG - 2021-01-16 02:59:54 --> Total execution time: 0.4122
INFO - 2021-01-16 03:00:53 --> Config Class Initialized
INFO - 2021-01-16 03:00:53 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:00:53 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:00:53 --> Utf8 Class Initialized
INFO - 2021-01-16 03:00:53 --> URI Class Initialized
INFO - 2021-01-16 03:00:53 --> Router Class Initialized
INFO - 2021-01-16 03:00:53 --> Output Class Initialized
INFO - 2021-01-16 03:00:53 --> Security Class Initialized
DEBUG - 2021-01-16 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:00:54 --> Input Class Initialized
INFO - 2021-01-16 03:00:54 --> Language Class Initialized
INFO - 2021-01-16 03:00:54 --> Language Class Initialized
INFO - 2021-01-16 03:00:54 --> Config Class Initialized
INFO - 2021-01-16 03:00:54 --> Loader Class Initialized
INFO - 2021-01-16 03:00:54 --> Helper loaded: url_helper
INFO - 2021-01-16 03:00:54 --> Helper loaded: file_helper
INFO - 2021-01-16 03:00:54 --> Helper loaded: form_helper
INFO - 2021-01-16 03:00:54 --> Helper loaded: my_helper
INFO - 2021-01-16 03:00:54 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:00:54 --> Controller Class Initialized
DEBUG - 2021-01-16 03:00:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:00:54 --> Final output sent to browser
DEBUG - 2021-01-16 03:00:54 --> Total execution time: 0.3418
INFO - 2021-01-16 03:02:01 --> Config Class Initialized
INFO - 2021-01-16 03:02:01 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:02:01 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:02:01 --> Utf8 Class Initialized
INFO - 2021-01-16 03:02:01 --> URI Class Initialized
INFO - 2021-01-16 03:02:01 --> Router Class Initialized
INFO - 2021-01-16 03:02:01 --> Output Class Initialized
INFO - 2021-01-16 03:02:01 --> Security Class Initialized
DEBUG - 2021-01-16 03:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:02:01 --> Input Class Initialized
INFO - 2021-01-16 03:02:01 --> Language Class Initialized
INFO - 2021-01-16 03:02:01 --> Language Class Initialized
INFO - 2021-01-16 03:02:01 --> Config Class Initialized
INFO - 2021-01-16 03:02:01 --> Loader Class Initialized
INFO - 2021-01-16 03:02:01 --> Helper loaded: url_helper
INFO - 2021-01-16 03:02:01 --> Helper loaded: file_helper
INFO - 2021-01-16 03:02:01 --> Helper loaded: form_helper
INFO - 2021-01-16 03:02:01 --> Helper loaded: my_helper
INFO - 2021-01-16 03:02:01 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:02:01 --> Controller Class Initialized
DEBUG - 2021-01-16 03:02:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:02:01 --> Final output sent to browser
DEBUG - 2021-01-16 03:02:01 --> Total execution time: 0.3216
INFO - 2021-01-16 03:02:40 --> Config Class Initialized
INFO - 2021-01-16 03:02:40 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:02:40 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:02:40 --> Utf8 Class Initialized
INFO - 2021-01-16 03:02:40 --> URI Class Initialized
INFO - 2021-01-16 03:02:40 --> Router Class Initialized
INFO - 2021-01-16 03:02:40 --> Output Class Initialized
INFO - 2021-01-16 03:02:40 --> Security Class Initialized
DEBUG - 2021-01-16 03:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:02:40 --> Input Class Initialized
INFO - 2021-01-16 03:02:40 --> Language Class Initialized
INFO - 2021-01-16 03:02:40 --> Language Class Initialized
INFO - 2021-01-16 03:02:40 --> Config Class Initialized
INFO - 2021-01-16 03:02:40 --> Loader Class Initialized
INFO - 2021-01-16 03:02:40 --> Helper loaded: url_helper
INFO - 2021-01-16 03:02:40 --> Helper loaded: file_helper
INFO - 2021-01-16 03:02:40 --> Helper loaded: form_helper
INFO - 2021-01-16 03:02:40 --> Helper loaded: my_helper
INFO - 2021-01-16 03:02:40 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:02:40 --> Controller Class Initialized
DEBUG - 2021-01-16 03:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:02:40 --> Final output sent to browser
DEBUG - 2021-01-16 03:02:40 --> Total execution time: 0.3615
INFO - 2021-01-16 03:03:47 --> Config Class Initialized
INFO - 2021-01-16 03:03:47 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:03:47 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:03:47 --> Utf8 Class Initialized
INFO - 2021-01-16 03:03:47 --> URI Class Initialized
INFO - 2021-01-16 03:03:47 --> Router Class Initialized
INFO - 2021-01-16 03:03:47 --> Output Class Initialized
INFO - 2021-01-16 03:03:47 --> Security Class Initialized
DEBUG - 2021-01-16 03:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:03:47 --> Input Class Initialized
INFO - 2021-01-16 03:03:47 --> Language Class Initialized
INFO - 2021-01-16 03:03:47 --> Language Class Initialized
INFO - 2021-01-16 03:03:47 --> Config Class Initialized
INFO - 2021-01-16 03:03:47 --> Loader Class Initialized
INFO - 2021-01-16 03:03:47 --> Helper loaded: url_helper
INFO - 2021-01-16 03:03:47 --> Helper loaded: file_helper
INFO - 2021-01-16 03:03:47 --> Helper loaded: form_helper
INFO - 2021-01-16 03:03:47 --> Helper loaded: my_helper
INFO - 2021-01-16 03:03:47 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:03:47 --> Controller Class Initialized
DEBUG - 2021-01-16 03:03:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:03:47 --> Final output sent to browser
DEBUG - 2021-01-16 03:03:47 --> Total execution time: 0.3969
INFO - 2021-01-16 03:04:14 --> Config Class Initialized
INFO - 2021-01-16 03:04:14 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:04:14 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:04:14 --> Utf8 Class Initialized
INFO - 2021-01-16 03:04:14 --> URI Class Initialized
INFO - 2021-01-16 03:04:14 --> Router Class Initialized
INFO - 2021-01-16 03:04:14 --> Output Class Initialized
INFO - 2021-01-16 03:04:14 --> Security Class Initialized
DEBUG - 2021-01-16 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:04:14 --> Input Class Initialized
INFO - 2021-01-16 03:04:14 --> Language Class Initialized
INFO - 2021-01-16 03:04:14 --> Language Class Initialized
INFO - 2021-01-16 03:04:14 --> Config Class Initialized
INFO - 2021-01-16 03:04:14 --> Loader Class Initialized
INFO - 2021-01-16 03:04:14 --> Helper loaded: url_helper
INFO - 2021-01-16 03:04:14 --> Helper loaded: file_helper
INFO - 2021-01-16 03:04:14 --> Helper loaded: form_helper
INFO - 2021-01-16 03:04:14 --> Helper loaded: my_helper
INFO - 2021-01-16 03:04:14 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:04:14 --> Controller Class Initialized
DEBUG - 2021-01-16 03:04:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:04:14 --> Final output sent to browser
DEBUG - 2021-01-16 03:04:14 --> Total execution time: 0.3325
INFO - 2021-01-16 03:04:38 --> Config Class Initialized
INFO - 2021-01-16 03:04:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:04:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:04:38 --> Utf8 Class Initialized
INFO - 2021-01-16 03:04:38 --> URI Class Initialized
INFO - 2021-01-16 03:04:38 --> Router Class Initialized
INFO - 2021-01-16 03:04:38 --> Output Class Initialized
INFO - 2021-01-16 03:04:38 --> Security Class Initialized
DEBUG - 2021-01-16 03:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:04:38 --> Input Class Initialized
INFO - 2021-01-16 03:04:38 --> Language Class Initialized
INFO - 2021-01-16 03:04:38 --> Language Class Initialized
INFO - 2021-01-16 03:04:38 --> Config Class Initialized
INFO - 2021-01-16 03:04:38 --> Loader Class Initialized
INFO - 2021-01-16 03:04:38 --> Helper loaded: url_helper
INFO - 2021-01-16 03:04:38 --> Helper loaded: file_helper
INFO - 2021-01-16 03:04:38 --> Helper loaded: form_helper
INFO - 2021-01-16 03:04:38 --> Helper loaded: my_helper
INFO - 2021-01-16 03:04:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:04:39 --> Controller Class Initialized
DEBUG - 2021-01-16 03:04:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-16 03:04:39 --> Final output sent to browser
DEBUG - 2021-01-16 03:04:39 --> Total execution time: 0.3249
INFO - 2021-01-16 03:06:11 --> Config Class Initialized
INFO - 2021-01-16 03:06:11 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:06:11 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:06:11 --> Utf8 Class Initialized
INFO - 2021-01-16 03:06:11 --> URI Class Initialized
INFO - 2021-01-16 03:06:11 --> Router Class Initialized
INFO - 2021-01-16 03:06:11 --> Output Class Initialized
INFO - 2021-01-16 03:06:11 --> Security Class Initialized
DEBUG - 2021-01-16 03:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:06:11 --> Input Class Initialized
INFO - 2021-01-16 03:06:11 --> Language Class Initialized
INFO - 2021-01-16 03:06:11 --> Language Class Initialized
INFO - 2021-01-16 03:06:11 --> Config Class Initialized
INFO - 2021-01-16 03:06:11 --> Loader Class Initialized
INFO - 2021-01-16 03:06:11 --> Helper loaded: url_helper
INFO - 2021-01-16 03:06:11 --> Helper loaded: file_helper
INFO - 2021-01-16 03:06:11 --> Helper loaded: form_helper
INFO - 2021-01-16 03:06:11 --> Helper loaded: my_helper
INFO - 2021-01-16 03:06:11 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:06:11 --> Controller Class Initialized
DEBUG - 2021-01-16 03:06:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-16 03:06:11 --> Final output sent to browser
DEBUG - 2021-01-16 03:06:11 --> Total execution time: 0.3184
INFO - 2021-01-16 03:06:28 --> Config Class Initialized
INFO - 2021-01-16 03:06:28 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:06:28 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:06:28 --> Utf8 Class Initialized
INFO - 2021-01-16 03:06:28 --> URI Class Initialized
INFO - 2021-01-16 03:06:28 --> Router Class Initialized
INFO - 2021-01-16 03:06:28 --> Output Class Initialized
INFO - 2021-01-16 03:06:28 --> Security Class Initialized
DEBUG - 2021-01-16 03:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:06:28 --> Input Class Initialized
INFO - 2021-01-16 03:06:28 --> Language Class Initialized
INFO - 2021-01-16 03:06:28 --> Language Class Initialized
INFO - 2021-01-16 03:06:28 --> Config Class Initialized
INFO - 2021-01-16 03:06:28 --> Loader Class Initialized
INFO - 2021-01-16 03:06:28 --> Helper loaded: url_helper
INFO - 2021-01-16 03:06:28 --> Helper loaded: file_helper
INFO - 2021-01-16 03:06:28 --> Helper loaded: form_helper
INFO - 2021-01-16 03:06:28 --> Helper loaded: my_helper
INFO - 2021-01-16 03:06:28 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:06:28 --> Controller Class Initialized
DEBUG - 2021-01-16 03:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-16 03:06:28 --> Final output sent to browser
DEBUG - 2021-01-16 03:06:28 --> Total execution time: 0.3493
INFO - 2021-01-16 03:06:48 --> Config Class Initialized
INFO - 2021-01-16 03:06:48 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:06:48 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:06:48 --> Utf8 Class Initialized
INFO - 2021-01-16 03:06:48 --> URI Class Initialized
INFO - 2021-01-16 03:06:48 --> Router Class Initialized
INFO - 2021-01-16 03:06:48 --> Output Class Initialized
INFO - 2021-01-16 03:06:48 --> Security Class Initialized
DEBUG - 2021-01-16 03:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:06:48 --> Input Class Initialized
INFO - 2021-01-16 03:06:48 --> Language Class Initialized
INFO - 2021-01-16 03:06:48 --> Language Class Initialized
INFO - 2021-01-16 03:06:48 --> Config Class Initialized
INFO - 2021-01-16 03:06:48 --> Loader Class Initialized
INFO - 2021-01-16 03:06:48 --> Helper loaded: url_helper
INFO - 2021-01-16 03:06:48 --> Helper loaded: file_helper
INFO - 2021-01-16 03:06:48 --> Helper loaded: form_helper
INFO - 2021-01-16 03:06:48 --> Helper loaded: my_helper
INFO - 2021-01-16 03:06:48 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:06:48 --> Controller Class Initialized
DEBUG - 2021-01-16 03:06:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-16 03:06:48 --> Final output sent to browser
DEBUG - 2021-01-16 03:06:48 --> Total execution time: 0.3269
INFO - 2021-01-16 03:08:18 --> Config Class Initialized
INFO - 2021-01-16 03:08:18 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:08:18 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:08:18 --> Utf8 Class Initialized
INFO - 2021-01-16 03:08:18 --> URI Class Initialized
INFO - 2021-01-16 03:08:18 --> Router Class Initialized
INFO - 2021-01-16 03:08:18 --> Output Class Initialized
INFO - 2021-01-16 03:08:18 --> Security Class Initialized
DEBUG - 2021-01-16 03:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:08:18 --> Input Class Initialized
INFO - 2021-01-16 03:08:18 --> Language Class Initialized
INFO - 2021-01-16 03:08:18 --> Language Class Initialized
INFO - 2021-01-16 03:08:18 --> Config Class Initialized
INFO - 2021-01-16 03:08:18 --> Loader Class Initialized
INFO - 2021-01-16 03:08:18 --> Helper loaded: url_helper
INFO - 2021-01-16 03:08:18 --> Helper loaded: file_helper
INFO - 2021-01-16 03:08:18 --> Helper loaded: form_helper
INFO - 2021-01-16 03:08:18 --> Helper loaded: my_helper
INFO - 2021-01-16 03:08:18 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:08:18 --> Controller Class Initialized
DEBUG - 2021-01-16 03:08:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-16 03:08:18 --> Final output sent to browser
DEBUG - 2021-01-16 03:08:18 --> Total execution time: 0.3370
INFO - 2021-01-16 03:09:07 --> Config Class Initialized
INFO - 2021-01-16 03:09:07 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:09:07 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:09:07 --> Utf8 Class Initialized
INFO - 2021-01-16 03:09:07 --> URI Class Initialized
INFO - 2021-01-16 03:09:07 --> Router Class Initialized
INFO - 2021-01-16 03:09:07 --> Output Class Initialized
INFO - 2021-01-16 03:09:07 --> Security Class Initialized
DEBUG - 2021-01-16 03:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:09:07 --> Input Class Initialized
INFO - 2021-01-16 03:09:07 --> Language Class Initialized
INFO - 2021-01-16 03:09:07 --> Language Class Initialized
INFO - 2021-01-16 03:09:07 --> Config Class Initialized
INFO - 2021-01-16 03:09:07 --> Loader Class Initialized
INFO - 2021-01-16 03:09:07 --> Helper loaded: url_helper
INFO - 2021-01-16 03:09:07 --> Helper loaded: file_helper
INFO - 2021-01-16 03:09:07 --> Helper loaded: form_helper
INFO - 2021-01-16 03:09:07 --> Helper loaded: my_helper
INFO - 2021-01-16 03:09:07 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:09:07 --> Controller Class Initialized
DEBUG - 2021-01-16 03:09:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:09:07 --> Final output sent to browser
DEBUG - 2021-01-16 03:09:07 --> Total execution time: 0.3309
INFO - 2021-01-16 03:10:01 --> Config Class Initialized
INFO - 2021-01-16 03:10:01 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:10:01 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:10:01 --> Utf8 Class Initialized
INFO - 2021-01-16 03:10:01 --> URI Class Initialized
INFO - 2021-01-16 03:10:01 --> Router Class Initialized
INFO - 2021-01-16 03:10:01 --> Output Class Initialized
INFO - 2021-01-16 03:10:01 --> Security Class Initialized
DEBUG - 2021-01-16 03:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:10:01 --> Input Class Initialized
INFO - 2021-01-16 03:10:01 --> Language Class Initialized
INFO - 2021-01-16 03:10:01 --> Language Class Initialized
INFO - 2021-01-16 03:10:01 --> Config Class Initialized
INFO - 2021-01-16 03:10:01 --> Loader Class Initialized
INFO - 2021-01-16 03:10:01 --> Helper loaded: url_helper
INFO - 2021-01-16 03:10:01 --> Helper loaded: file_helper
INFO - 2021-01-16 03:10:01 --> Helper loaded: form_helper
INFO - 2021-01-16 03:10:01 --> Helper loaded: my_helper
INFO - 2021-01-16 03:10:01 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:10:01 --> Controller Class Initialized
DEBUG - 2021-01-16 03:10:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:10:01 --> Final output sent to browser
DEBUG - 2021-01-16 03:10:01 --> Total execution time: 0.3573
INFO - 2021-01-16 03:10:29 --> Config Class Initialized
INFO - 2021-01-16 03:10:29 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:10:29 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:10:29 --> Utf8 Class Initialized
INFO - 2021-01-16 03:10:29 --> URI Class Initialized
INFO - 2021-01-16 03:10:29 --> Router Class Initialized
INFO - 2021-01-16 03:10:29 --> Output Class Initialized
INFO - 2021-01-16 03:10:29 --> Security Class Initialized
DEBUG - 2021-01-16 03:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:10:29 --> Input Class Initialized
INFO - 2021-01-16 03:10:29 --> Language Class Initialized
INFO - 2021-01-16 03:10:29 --> Language Class Initialized
INFO - 2021-01-16 03:10:29 --> Config Class Initialized
INFO - 2021-01-16 03:10:29 --> Loader Class Initialized
INFO - 2021-01-16 03:10:29 --> Helper loaded: url_helper
INFO - 2021-01-16 03:10:29 --> Helper loaded: file_helper
INFO - 2021-01-16 03:10:29 --> Helper loaded: form_helper
INFO - 2021-01-16 03:10:29 --> Helper loaded: my_helper
INFO - 2021-01-16 03:10:29 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:10:29 --> Controller Class Initialized
DEBUG - 2021-01-16 03:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:10:29 --> Final output sent to browser
DEBUG - 2021-01-16 03:10:29 --> Total execution time: 0.3566
INFO - 2021-01-16 03:11:05 --> Config Class Initialized
INFO - 2021-01-16 03:11:05 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:11:05 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:11:05 --> Utf8 Class Initialized
INFO - 2021-01-16 03:11:05 --> URI Class Initialized
INFO - 2021-01-16 03:11:05 --> Router Class Initialized
INFO - 2021-01-16 03:11:05 --> Output Class Initialized
INFO - 2021-01-16 03:11:05 --> Security Class Initialized
DEBUG - 2021-01-16 03:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:11:05 --> Input Class Initialized
INFO - 2021-01-16 03:11:05 --> Language Class Initialized
INFO - 2021-01-16 03:11:05 --> Language Class Initialized
INFO - 2021-01-16 03:11:05 --> Config Class Initialized
INFO - 2021-01-16 03:11:05 --> Loader Class Initialized
INFO - 2021-01-16 03:11:05 --> Helper loaded: url_helper
INFO - 2021-01-16 03:11:05 --> Helper loaded: file_helper
INFO - 2021-01-16 03:11:05 --> Helper loaded: form_helper
INFO - 2021-01-16 03:11:05 --> Helper loaded: my_helper
INFO - 2021-01-16 03:11:05 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:11:05 --> Controller Class Initialized
DEBUG - 2021-01-16 03:11:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:11:05 --> Final output sent to browser
DEBUG - 2021-01-16 03:11:05 --> Total execution time: 0.3498
INFO - 2021-01-16 03:11:45 --> Config Class Initialized
INFO - 2021-01-16 03:11:45 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:11:45 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:11:45 --> Utf8 Class Initialized
INFO - 2021-01-16 03:11:45 --> URI Class Initialized
INFO - 2021-01-16 03:11:45 --> Router Class Initialized
INFO - 2021-01-16 03:11:45 --> Output Class Initialized
INFO - 2021-01-16 03:11:45 --> Security Class Initialized
DEBUG - 2021-01-16 03:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:11:45 --> Input Class Initialized
INFO - 2021-01-16 03:11:45 --> Language Class Initialized
INFO - 2021-01-16 03:11:45 --> Language Class Initialized
INFO - 2021-01-16 03:11:45 --> Config Class Initialized
INFO - 2021-01-16 03:11:45 --> Loader Class Initialized
INFO - 2021-01-16 03:11:45 --> Helper loaded: url_helper
INFO - 2021-01-16 03:11:45 --> Helper loaded: file_helper
INFO - 2021-01-16 03:11:45 --> Helper loaded: form_helper
INFO - 2021-01-16 03:11:45 --> Helper loaded: my_helper
INFO - 2021-01-16 03:11:45 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:11:45 --> Controller Class Initialized
DEBUG - 2021-01-16 03:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:11:45 --> Final output sent to browser
DEBUG - 2021-01-16 03:11:45 --> Total execution time: 0.3525
INFO - 2021-01-16 03:12:00 --> Config Class Initialized
INFO - 2021-01-16 03:12:00 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:12:00 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:12:00 --> Utf8 Class Initialized
INFO - 2021-01-16 03:12:00 --> URI Class Initialized
INFO - 2021-01-16 03:12:00 --> Router Class Initialized
INFO - 2021-01-16 03:12:00 --> Output Class Initialized
INFO - 2021-01-16 03:12:00 --> Security Class Initialized
DEBUG - 2021-01-16 03:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:12:00 --> Input Class Initialized
INFO - 2021-01-16 03:12:00 --> Language Class Initialized
INFO - 2021-01-16 03:12:00 --> Language Class Initialized
INFO - 2021-01-16 03:12:01 --> Config Class Initialized
INFO - 2021-01-16 03:12:01 --> Loader Class Initialized
INFO - 2021-01-16 03:12:01 --> Helper loaded: url_helper
INFO - 2021-01-16 03:12:01 --> Helper loaded: file_helper
INFO - 2021-01-16 03:12:01 --> Helper loaded: form_helper
INFO - 2021-01-16 03:12:01 --> Helper loaded: my_helper
INFO - 2021-01-16 03:12:01 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:12:01 --> Controller Class Initialized
DEBUG - 2021-01-16 03:12:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-16 03:12:01 --> Final output sent to browser
DEBUG - 2021-01-16 03:12:01 --> Total execution time: 0.3049
INFO - 2021-01-16 03:12:58 --> Config Class Initialized
INFO - 2021-01-16 03:12:58 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:12:58 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:12:58 --> Utf8 Class Initialized
INFO - 2021-01-16 03:12:58 --> URI Class Initialized
INFO - 2021-01-16 03:12:58 --> Router Class Initialized
INFO - 2021-01-16 03:12:58 --> Output Class Initialized
INFO - 2021-01-16 03:12:58 --> Security Class Initialized
DEBUG - 2021-01-16 03:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:12:58 --> Input Class Initialized
INFO - 2021-01-16 03:12:58 --> Language Class Initialized
INFO - 2021-01-16 03:12:58 --> Language Class Initialized
INFO - 2021-01-16 03:12:58 --> Config Class Initialized
INFO - 2021-01-16 03:12:58 --> Loader Class Initialized
INFO - 2021-01-16 03:12:58 --> Helper loaded: url_helper
INFO - 2021-01-16 03:12:58 --> Helper loaded: file_helper
INFO - 2021-01-16 03:12:58 --> Helper loaded: form_helper
INFO - 2021-01-16 03:12:58 --> Helper loaded: my_helper
INFO - 2021-01-16 03:12:58 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:12:58 --> Controller Class Initialized
DEBUG - 2021-01-16 03:12:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:12:58 --> Final output sent to browser
DEBUG - 2021-01-16 03:12:58 --> Total execution time: 0.3297
INFO - 2021-01-16 03:13:27 --> Config Class Initialized
INFO - 2021-01-16 03:13:27 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:13:27 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:13:27 --> Utf8 Class Initialized
INFO - 2021-01-16 03:13:27 --> URI Class Initialized
INFO - 2021-01-16 03:13:27 --> Router Class Initialized
INFO - 2021-01-16 03:13:27 --> Output Class Initialized
INFO - 2021-01-16 03:13:27 --> Security Class Initialized
DEBUG - 2021-01-16 03:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:13:27 --> Input Class Initialized
INFO - 2021-01-16 03:13:27 --> Language Class Initialized
INFO - 2021-01-16 03:13:27 --> Language Class Initialized
INFO - 2021-01-16 03:13:27 --> Config Class Initialized
INFO - 2021-01-16 03:13:27 --> Loader Class Initialized
INFO - 2021-01-16 03:13:28 --> Helper loaded: url_helper
INFO - 2021-01-16 03:13:28 --> Helper loaded: file_helper
INFO - 2021-01-16 03:13:28 --> Helper loaded: form_helper
INFO - 2021-01-16 03:13:28 --> Helper loaded: my_helper
INFO - 2021-01-16 03:13:28 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:13:28 --> Controller Class Initialized
DEBUG - 2021-01-16 03:13:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:13:28 --> Final output sent to browser
DEBUG - 2021-01-16 03:13:28 --> Total execution time: 0.3302
INFO - 2021-01-16 03:15:23 --> Config Class Initialized
INFO - 2021-01-16 03:15:23 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:15:23 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:15:23 --> Utf8 Class Initialized
INFO - 2021-01-16 03:15:23 --> URI Class Initialized
INFO - 2021-01-16 03:15:23 --> Router Class Initialized
INFO - 2021-01-16 03:15:23 --> Output Class Initialized
INFO - 2021-01-16 03:15:23 --> Security Class Initialized
DEBUG - 2021-01-16 03:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:15:23 --> Input Class Initialized
INFO - 2021-01-16 03:15:23 --> Language Class Initialized
INFO - 2021-01-16 03:15:23 --> Language Class Initialized
INFO - 2021-01-16 03:15:23 --> Config Class Initialized
INFO - 2021-01-16 03:15:23 --> Loader Class Initialized
INFO - 2021-01-16 03:15:23 --> Helper loaded: url_helper
INFO - 2021-01-16 03:15:23 --> Helper loaded: file_helper
INFO - 2021-01-16 03:15:23 --> Helper loaded: form_helper
INFO - 2021-01-16 03:15:23 --> Helper loaded: my_helper
INFO - 2021-01-16 03:15:23 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:15:23 --> Controller Class Initialized
DEBUG - 2021-01-16 03:15:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:15:23 --> Final output sent to browser
DEBUG - 2021-01-16 03:15:23 --> Total execution time: 0.3407
INFO - 2021-01-16 03:16:03 --> Config Class Initialized
INFO - 2021-01-16 03:16:03 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:16:03 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:16:03 --> Utf8 Class Initialized
INFO - 2021-01-16 03:16:03 --> URI Class Initialized
INFO - 2021-01-16 03:16:03 --> Router Class Initialized
INFO - 2021-01-16 03:16:03 --> Output Class Initialized
INFO - 2021-01-16 03:16:03 --> Security Class Initialized
DEBUG - 2021-01-16 03:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:16:03 --> Input Class Initialized
INFO - 2021-01-16 03:16:03 --> Language Class Initialized
INFO - 2021-01-16 03:16:03 --> Language Class Initialized
INFO - 2021-01-16 03:16:03 --> Config Class Initialized
INFO - 2021-01-16 03:16:03 --> Loader Class Initialized
INFO - 2021-01-16 03:16:03 --> Helper loaded: url_helper
INFO - 2021-01-16 03:16:03 --> Helper loaded: file_helper
INFO - 2021-01-16 03:16:03 --> Helper loaded: form_helper
INFO - 2021-01-16 03:16:03 --> Helper loaded: my_helper
INFO - 2021-01-16 03:16:03 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:16:03 --> Controller Class Initialized
DEBUG - 2021-01-16 03:16:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:16:03 --> Final output sent to browser
DEBUG - 2021-01-16 03:16:03 --> Total execution time: 0.3044
INFO - 2021-01-16 03:16:25 --> Config Class Initialized
INFO - 2021-01-16 03:16:25 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:16:25 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:16:25 --> Utf8 Class Initialized
INFO - 2021-01-16 03:16:25 --> URI Class Initialized
INFO - 2021-01-16 03:16:25 --> Router Class Initialized
INFO - 2021-01-16 03:16:25 --> Output Class Initialized
INFO - 2021-01-16 03:16:25 --> Security Class Initialized
DEBUG - 2021-01-16 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:16:25 --> Input Class Initialized
INFO - 2021-01-16 03:16:25 --> Language Class Initialized
INFO - 2021-01-16 03:16:25 --> Language Class Initialized
INFO - 2021-01-16 03:16:25 --> Config Class Initialized
INFO - 2021-01-16 03:16:25 --> Loader Class Initialized
INFO - 2021-01-16 03:16:25 --> Helper loaded: url_helper
INFO - 2021-01-16 03:16:25 --> Helper loaded: file_helper
INFO - 2021-01-16 03:16:25 --> Helper loaded: form_helper
INFO - 2021-01-16 03:16:25 --> Helper loaded: my_helper
INFO - 2021-01-16 03:16:25 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:16:25 --> Controller Class Initialized
DEBUG - 2021-01-16 03:16:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:16:25 --> Final output sent to browser
DEBUG - 2021-01-16 03:16:25 --> Total execution time: 0.3364
INFO - 2021-01-16 03:16:38 --> Config Class Initialized
INFO - 2021-01-16 03:16:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:16:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:16:38 --> Utf8 Class Initialized
INFO - 2021-01-16 03:16:38 --> URI Class Initialized
INFO - 2021-01-16 03:16:38 --> Router Class Initialized
INFO - 2021-01-16 03:16:38 --> Output Class Initialized
INFO - 2021-01-16 03:16:38 --> Security Class Initialized
DEBUG - 2021-01-16 03:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:16:38 --> Input Class Initialized
INFO - 2021-01-16 03:16:38 --> Language Class Initialized
INFO - 2021-01-16 03:16:38 --> Language Class Initialized
INFO - 2021-01-16 03:16:38 --> Config Class Initialized
INFO - 2021-01-16 03:16:38 --> Loader Class Initialized
INFO - 2021-01-16 03:16:38 --> Helper loaded: url_helper
INFO - 2021-01-16 03:16:38 --> Helper loaded: file_helper
INFO - 2021-01-16 03:16:38 --> Helper loaded: form_helper
INFO - 2021-01-16 03:16:38 --> Helper loaded: my_helper
INFO - 2021-01-16 03:16:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:16:38 --> Controller Class Initialized
DEBUG - 2021-01-16 03:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:16:38 --> Final output sent to browser
DEBUG - 2021-01-16 03:16:38 --> Total execution time: 0.3672
INFO - 2021-01-16 03:16:52 --> Config Class Initialized
INFO - 2021-01-16 03:16:52 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:16:52 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:16:52 --> Utf8 Class Initialized
INFO - 2021-01-16 03:16:52 --> URI Class Initialized
INFO - 2021-01-16 03:16:52 --> Router Class Initialized
INFO - 2021-01-16 03:16:52 --> Output Class Initialized
INFO - 2021-01-16 03:16:52 --> Security Class Initialized
DEBUG - 2021-01-16 03:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:16:52 --> Input Class Initialized
INFO - 2021-01-16 03:16:52 --> Language Class Initialized
INFO - 2021-01-16 03:16:52 --> Language Class Initialized
INFO - 2021-01-16 03:16:52 --> Config Class Initialized
INFO - 2021-01-16 03:16:52 --> Loader Class Initialized
INFO - 2021-01-16 03:16:52 --> Helper loaded: url_helper
INFO - 2021-01-16 03:16:52 --> Helper loaded: file_helper
INFO - 2021-01-16 03:16:52 --> Helper loaded: form_helper
INFO - 2021-01-16 03:16:52 --> Helper loaded: my_helper
INFO - 2021-01-16 03:16:52 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:16:52 --> Controller Class Initialized
DEBUG - 2021-01-16 03:16:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-16 03:16:53 --> Final output sent to browser
DEBUG - 2021-01-16 03:16:53 --> Total execution time: 0.4156
INFO - 2021-01-16 03:18:39 --> Config Class Initialized
INFO - 2021-01-16 03:18:39 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:18:39 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:18:39 --> Utf8 Class Initialized
INFO - 2021-01-16 03:18:39 --> URI Class Initialized
INFO - 2021-01-16 03:18:39 --> Router Class Initialized
INFO - 2021-01-16 03:18:39 --> Output Class Initialized
INFO - 2021-01-16 03:18:39 --> Security Class Initialized
DEBUG - 2021-01-16 03:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:18:39 --> Input Class Initialized
INFO - 2021-01-16 03:18:39 --> Language Class Initialized
INFO - 2021-01-16 03:18:39 --> Language Class Initialized
INFO - 2021-01-16 03:18:39 --> Config Class Initialized
INFO - 2021-01-16 03:18:39 --> Loader Class Initialized
INFO - 2021-01-16 03:18:39 --> Helper loaded: url_helper
INFO - 2021-01-16 03:18:39 --> Helper loaded: file_helper
INFO - 2021-01-16 03:18:39 --> Helper loaded: form_helper
INFO - 2021-01-16 03:18:39 --> Helper loaded: my_helper
INFO - 2021-01-16 03:18:39 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:18:39 --> Controller Class Initialized
DEBUG - 2021-01-16 03:18:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:18:39 --> Final output sent to browser
DEBUG - 2021-01-16 03:18:39 --> Total execution time: 0.3136
INFO - 2021-01-16 03:21:10 --> Config Class Initialized
INFO - 2021-01-16 03:21:10 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:21:10 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:21:10 --> Utf8 Class Initialized
INFO - 2021-01-16 03:21:10 --> URI Class Initialized
INFO - 2021-01-16 03:21:10 --> Router Class Initialized
INFO - 2021-01-16 03:21:10 --> Output Class Initialized
INFO - 2021-01-16 03:21:10 --> Security Class Initialized
DEBUG - 2021-01-16 03:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:21:10 --> Input Class Initialized
INFO - 2021-01-16 03:21:10 --> Language Class Initialized
INFO - 2021-01-16 03:21:10 --> Language Class Initialized
INFO - 2021-01-16 03:21:10 --> Config Class Initialized
INFO - 2021-01-16 03:21:10 --> Loader Class Initialized
INFO - 2021-01-16 03:21:10 --> Helper loaded: url_helper
INFO - 2021-01-16 03:21:10 --> Helper loaded: file_helper
INFO - 2021-01-16 03:21:10 --> Helper loaded: form_helper
INFO - 2021-01-16 03:21:11 --> Helper loaded: my_helper
INFO - 2021-01-16 03:21:11 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:21:11 --> Controller Class Initialized
DEBUG - 2021-01-16 03:21:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:21:11 --> Final output sent to browser
DEBUG - 2021-01-16 03:21:11 --> Total execution time: 0.3189
INFO - 2021-01-16 03:23:32 --> Config Class Initialized
INFO - 2021-01-16 03:23:32 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:23:32 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:23:32 --> Utf8 Class Initialized
INFO - 2021-01-16 03:23:33 --> URI Class Initialized
INFO - 2021-01-16 03:23:33 --> Router Class Initialized
INFO - 2021-01-16 03:23:33 --> Output Class Initialized
INFO - 2021-01-16 03:23:33 --> Security Class Initialized
DEBUG - 2021-01-16 03:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:23:33 --> Input Class Initialized
INFO - 2021-01-16 03:23:33 --> Language Class Initialized
INFO - 2021-01-16 03:23:33 --> Language Class Initialized
INFO - 2021-01-16 03:23:33 --> Config Class Initialized
INFO - 2021-01-16 03:23:33 --> Loader Class Initialized
INFO - 2021-01-16 03:23:33 --> Helper loaded: url_helper
INFO - 2021-01-16 03:23:33 --> Helper loaded: file_helper
INFO - 2021-01-16 03:23:33 --> Helper loaded: form_helper
INFO - 2021-01-16 03:23:33 --> Helper loaded: my_helper
INFO - 2021-01-16 03:23:33 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:23:33 --> Controller Class Initialized
DEBUG - 2021-01-16 03:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:23:33 --> Final output sent to browser
DEBUG - 2021-01-16 03:23:33 --> Total execution time: 0.3212
INFO - 2021-01-16 03:23:34 --> Config Class Initialized
INFO - 2021-01-16 03:23:34 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:23:34 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:23:34 --> Utf8 Class Initialized
INFO - 2021-01-16 03:23:34 --> URI Class Initialized
INFO - 2021-01-16 03:23:34 --> Router Class Initialized
INFO - 2021-01-16 03:23:34 --> Output Class Initialized
INFO - 2021-01-16 03:23:34 --> Security Class Initialized
DEBUG - 2021-01-16 03:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:23:34 --> Input Class Initialized
INFO - 2021-01-16 03:23:34 --> Language Class Initialized
INFO - 2021-01-16 03:23:34 --> Language Class Initialized
INFO - 2021-01-16 03:23:34 --> Config Class Initialized
INFO - 2021-01-16 03:23:34 --> Loader Class Initialized
INFO - 2021-01-16 03:23:34 --> Helper loaded: url_helper
INFO - 2021-01-16 03:23:34 --> Helper loaded: file_helper
INFO - 2021-01-16 03:23:34 --> Helper loaded: form_helper
INFO - 2021-01-16 03:23:34 --> Helper loaded: my_helper
INFO - 2021-01-16 03:23:34 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:23:34 --> Controller Class Initialized
DEBUG - 2021-01-16 03:23:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:23:34 --> Final output sent to browser
DEBUG - 2021-01-16 03:23:34 --> Total execution time: 0.3122
INFO - 2021-01-16 03:23:45 --> Config Class Initialized
INFO - 2021-01-16 03:23:45 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:23:45 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:23:45 --> Utf8 Class Initialized
INFO - 2021-01-16 03:23:45 --> URI Class Initialized
INFO - 2021-01-16 03:23:45 --> Router Class Initialized
INFO - 2021-01-16 03:23:45 --> Output Class Initialized
INFO - 2021-01-16 03:23:45 --> Security Class Initialized
DEBUG - 2021-01-16 03:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:23:45 --> Input Class Initialized
INFO - 2021-01-16 03:23:45 --> Language Class Initialized
INFO - 2021-01-16 03:23:45 --> Language Class Initialized
INFO - 2021-01-16 03:23:45 --> Config Class Initialized
INFO - 2021-01-16 03:23:45 --> Loader Class Initialized
INFO - 2021-01-16 03:23:45 --> Helper loaded: url_helper
INFO - 2021-01-16 03:23:45 --> Helper loaded: file_helper
INFO - 2021-01-16 03:23:45 --> Helper loaded: form_helper
INFO - 2021-01-16 03:23:45 --> Helper loaded: my_helper
INFO - 2021-01-16 03:23:45 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:23:45 --> Controller Class Initialized
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4585
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4585
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4585
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4585
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4585
ERROR - 2021-01-16 03:23:45 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4586
DEBUG - 2021-01-16 03:23:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:23:45 --> Final output sent to browser
DEBUG - 2021-01-16 03:23:45 --> Total execution time: 0.4097
INFO - 2021-01-16 03:24:35 --> Config Class Initialized
INFO - 2021-01-16 03:24:35 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:24:35 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:24:35 --> Utf8 Class Initialized
INFO - 2021-01-16 03:24:35 --> URI Class Initialized
INFO - 2021-01-16 03:24:35 --> Router Class Initialized
INFO - 2021-01-16 03:24:35 --> Output Class Initialized
INFO - 2021-01-16 03:24:35 --> Security Class Initialized
DEBUG - 2021-01-16 03:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:24:35 --> Input Class Initialized
INFO - 2021-01-16 03:24:35 --> Language Class Initialized
INFO - 2021-01-16 03:24:35 --> Language Class Initialized
INFO - 2021-01-16 03:24:35 --> Config Class Initialized
INFO - 2021-01-16 03:24:35 --> Loader Class Initialized
INFO - 2021-01-16 03:24:35 --> Helper loaded: url_helper
INFO - 2021-01-16 03:24:35 --> Helper loaded: file_helper
INFO - 2021-01-16 03:24:35 --> Helper loaded: form_helper
INFO - 2021-01-16 03:24:35 --> Helper loaded: my_helper
INFO - 2021-01-16 03:24:35 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:24:35 --> Controller Class Initialized
DEBUG - 2021-01-16 03:24:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:24:35 --> Final output sent to browser
DEBUG - 2021-01-16 03:24:35 --> Total execution time: 0.3309
INFO - 2021-01-16 03:39:51 --> Config Class Initialized
INFO - 2021-01-16 03:39:51 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:39:51 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:39:51 --> Utf8 Class Initialized
INFO - 2021-01-16 03:39:51 --> URI Class Initialized
INFO - 2021-01-16 03:39:51 --> Router Class Initialized
INFO - 2021-01-16 03:39:51 --> Output Class Initialized
INFO - 2021-01-16 03:39:51 --> Security Class Initialized
DEBUG - 2021-01-16 03:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:39:51 --> Input Class Initialized
INFO - 2021-01-16 03:39:51 --> Language Class Initialized
ERROR - 2021-01-16 03:39:51 --> Severity: Parsing Error --> syntax error, unexpected '$q_mapel' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4612
INFO - 2021-01-16 03:40:27 --> Config Class Initialized
INFO - 2021-01-16 03:40:27 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:40:27 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:40:27 --> Utf8 Class Initialized
INFO - 2021-01-16 03:40:27 --> URI Class Initialized
INFO - 2021-01-16 03:40:27 --> Router Class Initialized
INFO - 2021-01-16 03:40:27 --> Output Class Initialized
INFO - 2021-01-16 03:40:27 --> Security Class Initialized
DEBUG - 2021-01-16 03:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:40:27 --> Input Class Initialized
INFO - 2021-01-16 03:40:27 --> Language Class Initialized
INFO - 2021-01-16 03:40:27 --> Language Class Initialized
INFO - 2021-01-16 03:40:27 --> Config Class Initialized
INFO - 2021-01-16 03:40:27 --> Loader Class Initialized
INFO - 2021-01-16 03:40:27 --> Helper loaded: url_helper
INFO - 2021-01-16 03:40:27 --> Helper loaded: file_helper
INFO - 2021-01-16 03:40:27 --> Helper loaded: form_helper
INFO - 2021-01-16 03:40:27 --> Helper loaded: my_helper
INFO - 2021-01-16 03:40:27 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:40:27 --> Controller Class Initialized
DEBUG - 2021-01-16 03:40:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:40:27 --> Final output sent to browser
DEBUG - 2021-01-16 03:40:27 --> Total execution time: 0.3072
INFO - 2021-01-16 03:41:54 --> Config Class Initialized
INFO - 2021-01-16 03:41:54 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:41:54 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:41:54 --> Utf8 Class Initialized
INFO - 2021-01-16 03:41:54 --> URI Class Initialized
INFO - 2021-01-16 03:41:54 --> Router Class Initialized
INFO - 2021-01-16 03:41:54 --> Output Class Initialized
INFO - 2021-01-16 03:41:54 --> Security Class Initialized
DEBUG - 2021-01-16 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:41:54 --> Input Class Initialized
INFO - 2021-01-16 03:41:54 --> Language Class Initialized
INFO - 2021-01-16 03:41:54 --> Language Class Initialized
INFO - 2021-01-16 03:41:54 --> Config Class Initialized
INFO - 2021-01-16 03:41:54 --> Loader Class Initialized
INFO - 2021-01-16 03:41:54 --> Helper loaded: url_helper
INFO - 2021-01-16 03:41:54 --> Helper loaded: file_helper
INFO - 2021-01-16 03:41:54 --> Helper loaded: form_helper
INFO - 2021-01-16 03:41:54 --> Helper loaded: my_helper
INFO - 2021-01-16 03:41:54 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:41:54 --> Controller Class Initialized
DEBUG - 2021-01-16 03:41:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:41:54 --> Final output sent to browser
DEBUG - 2021-01-16 03:41:54 --> Total execution time: 0.3295
INFO - 2021-01-16 03:43:49 --> Config Class Initialized
INFO - 2021-01-16 03:43:49 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:43:49 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:43:49 --> Utf8 Class Initialized
INFO - 2021-01-16 03:43:49 --> URI Class Initialized
INFO - 2021-01-16 03:43:49 --> Router Class Initialized
INFO - 2021-01-16 03:43:49 --> Output Class Initialized
INFO - 2021-01-16 03:43:49 --> Security Class Initialized
DEBUG - 2021-01-16 03:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:43:49 --> Input Class Initialized
INFO - 2021-01-16 03:43:49 --> Language Class Initialized
INFO - 2021-01-16 03:43:49 --> Language Class Initialized
INFO - 2021-01-16 03:43:49 --> Config Class Initialized
INFO - 2021-01-16 03:43:50 --> Loader Class Initialized
INFO - 2021-01-16 03:43:50 --> Helper loaded: url_helper
INFO - 2021-01-16 03:43:50 --> Helper loaded: file_helper
INFO - 2021-01-16 03:43:50 --> Helper loaded: form_helper
INFO - 2021-01-16 03:43:50 --> Helper loaded: my_helper
INFO - 2021-01-16 03:43:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:43:50 --> Controller Class Initialized
DEBUG - 2021-01-16 03:43:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:43:50 --> Final output sent to browser
DEBUG - 2021-01-16 03:43:50 --> Total execution time: 0.3120
INFO - 2021-01-16 03:44:32 --> Config Class Initialized
INFO - 2021-01-16 03:44:32 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:44:32 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:44:32 --> Utf8 Class Initialized
INFO - 2021-01-16 03:44:32 --> URI Class Initialized
INFO - 2021-01-16 03:44:32 --> Router Class Initialized
INFO - 2021-01-16 03:44:32 --> Output Class Initialized
INFO - 2021-01-16 03:44:32 --> Security Class Initialized
DEBUG - 2021-01-16 03:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:44:32 --> Input Class Initialized
INFO - 2021-01-16 03:44:32 --> Language Class Initialized
INFO - 2021-01-16 03:44:32 --> Language Class Initialized
INFO - 2021-01-16 03:44:32 --> Config Class Initialized
INFO - 2021-01-16 03:44:32 --> Loader Class Initialized
INFO - 2021-01-16 03:44:32 --> Helper loaded: url_helper
INFO - 2021-01-16 03:44:32 --> Helper loaded: file_helper
INFO - 2021-01-16 03:44:32 --> Helper loaded: form_helper
INFO - 2021-01-16 03:44:32 --> Helper loaded: my_helper
INFO - 2021-01-16 03:44:32 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:44:32 --> Controller Class Initialized
ERROR - 2021-01-16 03:44:32 --> Severity: Warning --> explode() expects at least 2 parameters, 1 given C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4482
DEBUG - 2021-01-16 03:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:44:32 --> Final output sent to browser
DEBUG - 2021-01-16 03:44:32 --> Total execution time: 0.3438
INFO - 2021-01-16 03:44:55 --> Config Class Initialized
INFO - 2021-01-16 03:44:56 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:44:56 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:44:56 --> Utf8 Class Initialized
INFO - 2021-01-16 03:44:56 --> URI Class Initialized
INFO - 2021-01-16 03:44:56 --> Router Class Initialized
INFO - 2021-01-16 03:44:56 --> Output Class Initialized
INFO - 2021-01-16 03:44:56 --> Security Class Initialized
DEBUG - 2021-01-16 03:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:44:56 --> Input Class Initialized
INFO - 2021-01-16 03:44:56 --> Language Class Initialized
INFO - 2021-01-16 03:44:56 --> Language Class Initialized
INFO - 2021-01-16 03:44:56 --> Config Class Initialized
INFO - 2021-01-16 03:44:56 --> Loader Class Initialized
INFO - 2021-01-16 03:44:56 --> Helper loaded: url_helper
INFO - 2021-01-16 03:44:56 --> Helper loaded: file_helper
INFO - 2021-01-16 03:44:56 --> Helper loaded: form_helper
INFO - 2021-01-16 03:44:56 --> Helper loaded: my_helper
INFO - 2021-01-16 03:44:56 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:44:56 --> Controller Class Initialized
ERROR - 2021-01-16 03:44:56 --> Severity: Warning --> implode(): Argument must be an array C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4482
DEBUG - 2021-01-16 03:44:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:44:56 --> Final output sent to browser
DEBUG - 2021-01-16 03:44:56 --> Total execution time: 0.3259
INFO - 2021-01-16 03:45:05 --> Config Class Initialized
INFO - 2021-01-16 03:45:05 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:45:05 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:45:05 --> Utf8 Class Initialized
INFO - 2021-01-16 03:45:05 --> URI Class Initialized
INFO - 2021-01-16 03:45:06 --> Router Class Initialized
INFO - 2021-01-16 03:45:06 --> Output Class Initialized
INFO - 2021-01-16 03:45:06 --> Security Class Initialized
DEBUG - 2021-01-16 03:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:45:06 --> Input Class Initialized
INFO - 2021-01-16 03:45:06 --> Language Class Initialized
INFO - 2021-01-16 03:45:06 --> Language Class Initialized
INFO - 2021-01-16 03:45:06 --> Config Class Initialized
INFO - 2021-01-16 03:45:06 --> Loader Class Initialized
INFO - 2021-01-16 03:45:06 --> Helper loaded: url_helper
INFO - 2021-01-16 03:45:06 --> Helper loaded: file_helper
INFO - 2021-01-16 03:45:06 --> Helper loaded: form_helper
INFO - 2021-01-16 03:45:06 --> Helper loaded: my_helper
INFO - 2021-01-16 03:45:06 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:45:06 --> Controller Class Initialized
DEBUG - 2021-01-16 03:45:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:45:06 --> Final output sent to browser
DEBUG - 2021-01-16 03:45:06 --> Total execution time: 0.3489
INFO - 2021-01-16 03:50:22 --> Config Class Initialized
INFO - 2021-01-16 03:50:22 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:50:22 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:50:22 --> Utf8 Class Initialized
INFO - 2021-01-16 03:50:22 --> URI Class Initialized
INFO - 2021-01-16 03:50:22 --> Router Class Initialized
INFO - 2021-01-16 03:50:22 --> Output Class Initialized
INFO - 2021-01-16 03:50:22 --> Security Class Initialized
DEBUG - 2021-01-16 03:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:50:22 --> Input Class Initialized
INFO - 2021-01-16 03:50:22 --> Language Class Initialized
INFO - 2021-01-16 03:50:22 --> Language Class Initialized
INFO - 2021-01-16 03:50:22 --> Config Class Initialized
INFO - 2021-01-16 03:50:22 --> Loader Class Initialized
INFO - 2021-01-16 03:50:22 --> Helper loaded: url_helper
INFO - 2021-01-16 03:50:22 --> Helper loaded: file_helper
INFO - 2021-01-16 03:50:22 --> Helper loaded: form_helper
INFO - 2021-01-16 03:50:22 --> Helper loaded: my_helper
INFO - 2021-01-16 03:50:22 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:50:22 --> Controller Class Initialized
ERROR - 2021-01-16 03:50:22 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4588
ERROR - 2021-01-16 03:50:22 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4589
DEBUG - 2021-01-16 03:50:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:50:22 --> Final output sent to browser
DEBUG - 2021-01-16 03:50:22 --> Total execution time: 0.3457
INFO - 2021-01-16 03:50:59 --> Config Class Initialized
INFO - 2021-01-16 03:50:59 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:50:59 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:50:59 --> Utf8 Class Initialized
INFO - 2021-01-16 03:50:59 --> URI Class Initialized
INFO - 2021-01-16 03:50:59 --> Router Class Initialized
INFO - 2021-01-16 03:50:59 --> Output Class Initialized
INFO - 2021-01-16 03:50:59 --> Security Class Initialized
DEBUG - 2021-01-16 03:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:50:59 --> Input Class Initialized
INFO - 2021-01-16 03:50:59 --> Language Class Initialized
INFO - 2021-01-16 03:50:59 --> Language Class Initialized
INFO - 2021-01-16 03:50:59 --> Config Class Initialized
INFO - 2021-01-16 03:50:59 --> Loader Class Initialized
INFO - 2021-01-16 03:50:59 --> Helper loaded: url_helper
INFO - 2021-01-16 03:50:59 --> Helper loaded: file_helper
INFO - 2021-01-16 03:50:59 --> Helper loaded: form_helper
INFO - 2021-01-16 03:50:59 --> Helper loaded: my_helper
INFO - 2021-01-16 03:50:59 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:50:59 --> Controller Class Initialized
ERROR - 2021-01-16 03:50:59 --> Severity: Warning --> number_format() expects parameter 1 to be double, array given C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4484
DEBUG - 2021-01-16 03:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:50:59 --> Final output sent to browser
DEBUG - 2021-01-16 03:50:59 --> Total execution time: 0.3412
INFO - 2021-01-16 03:51:23 --> Config Class Initialized
INFO - 2021-01-16 03:51:23 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:51:23 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:51:23 --> Utf8 Class Initialized
INFO - 2021-01-16 03:51:24 --> URI Class Initialized
INFO - 2021-01-16 03:51:24 --> Router Class Initialized
INFO - 2021-01-16 03:51:24 --> Output Class Initialized
INFO - 2021-01-16 03:51:24 --> Security Class Initialized
DEBUG - 2021-01-16 03:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:51:24 --> Input Class Initialized
INFO - 2021-01-16 03:51:24 --> Language Class Initialized
INFO - 2021-01-16 03:51:24 --> Language Class Initialized
INFO - 2021-01-16 03:51:24 --> Config Class Initialized
INFO - 2021-01-16 03:51:24 --> Loader Class Initialized
INFO - 2021-01-16 03:51:24 --> Helper loaded: url_helper
INFO - 2021-01-16 03:51:24 --> Helper loaded: file_helper
INFO - 2021-01-16 03:51:24 --> Helper loaded: form_helper
INFO - 2021-01-16 03:51:24 --> Helper loaded: my_helper
INFO - 2021-01-16 03:51:24 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:51:24 --> Controller Class Initialized
DEBUG - 2021-01-16 03:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:51:24 --> Final output sent to browser
DEBUG - 2021-01-16 03:51:24 --> Total execution time: 0.3365
INFO - 2021-01-16 03:55:38 --> Config Class Initialized
INFO - 2021-01-16 03:55:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:55:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:55:38 --> Utf8 Class Initialized
INFO - 2021-01-16 03:55:38 --> URI Class Initialized
INFO - 2021-01-16 03:55:38 --> Router Class Initialized
INFO - 2021-01-16 03:55:38 --> Output Class Initialized
INFO - 2021-01-16 03:55:38 --> Security Class Initialized
DEBUG - 2021-01-16 03:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:55:38 --> Input Class Initialized
INFO - 2021-01-16 03:55:38 --> Language Class Initialized
INFO - 2021-01-16 03:55:38 --> Language Class Initialized
INFO - 2021-01-16 03:55:38 --> Config Class Initialized
INFO - 2021-01-16 03:55:38 --> Loader Class Initialized
INFO - 2021-01-16 03:55:38 --> Helper loaded: url_helper
INFO - 2021-01-16 03:55:38 --> Helper loaded: file_helper
INFO - 2021-01-16 03:55:38 --> Helper loaded: form_helper
INFO - 2021-01-16 03:55:38 --> Helper loaded: my_helper
INFO - 2021-01-16 03:55:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:55:38 --> Controller Class Initialized
DEBUG - 2021-01-16 03:55:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:55:38 --> Final output sent to browser
DEBUG - 2021-01-16 03:55:38 --> Total execution time: 0.3041
INFO - 2021-01-16 03:56:47 --> Config Class Initialized
INFO - 2021-01-16 03:56:47 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:56:47 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:56:47 --> Utf8 Class Initialized
INFO - 2021-01-16 03:56:47 --> URI Class Initialized
INFO - 2021-01-16 03:56:47 --> Router Class Initialized
INFO - 2021-01-16 03:56:47 --> Output Class Initialized
INFO - 2021-01-16 03:56:47 --> Security Class Initialized
DEBUG - 2021-01-16 03:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:56:47 --> Input Class Initialized
INFO - 2021-01-16 03:56:47 --> Language Class Initialized
INFO - 2021-01-16 03:56:47 --> Language Class Initialized
INFO - 2021-01-16 03:56:47 --> Config Class Initialized
INFO - 2021-01-16 03:56:47 --> Loader Class Initialized
INFO - 2021-01-16 03:56:47 --> Helper loaded: url_helper
INFO - 2021-01-16 03:56:47 --> Helper loaded: file_helper
INFO - 2021-01-16 03:56:47 --> Helper loaded: form_helper
INFO - 2021-01-16 03:56:47 --> Helper loaded: my_helper
INFO - 2021-01-16 03:56:47 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:56:47 --> Controller Class Initialized
DEBUG - 2021-01-16 03:56:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:56:47 --> Final output sent to browser
DEBUG - 2021-01-16 03:56:47 --> Total execution time: 0.3204
INFO - 2021-01-16 03:57:28 --> Config Class Initialized
INFO - 2021-01-16 03:57:28 --> Hooks Class Initialized
DEBUG - 2021-01-16 03:57:28 --> UTF-8 Support Enabled
INFO - 2021-01-16 03:57:28 --> Utf8 Class Initialized
INFO - 2021-01-16 03:57:28 --> URI Class Initialized
INFO - 2021-01-16 03:57:28 --> Router Class Initialized
INFO - 2021-01-16 03:57:28 --> Output Class Initialized
INFO - 2021-01-16 03:57:28 --> Security Class Initialized
DEBUG - 2021-01-16 03:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 03:57:28 --> Input Class Initialized
INFO - 2021-01-16 03:57:28 --> Language Class Initialized
INFO - 2021-01-16 03:57:28 --> Language Class Initialized
INFO - 2021-01-16 03:57:28 --> Config Class Initialized
INFO - 2021-01-16 03:57:28 --> Loader Class Initialized
INFO - 2021-01-16 03:57:28 --> Helper loaded: url_helper
INFO - 2021-01-16 03:57:28 --> Helper loaded: file_helper
INFO - 2021-01-16 03:57:28 --> Helper loaded: form_helper
INFO - 2021-01-16 03:57:28 --> Helper loaded: my_helper
INFO - 2021-01-16 03:57:28 --> Database Driver Class Initialized
DEBUG - 2021-01-16 03:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 03:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 03:57:28 --> Controller Class Initialized
DEBUG - 2021-01-16 03:57:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 03:57:28 --> Final output sent to browser
DEBUG - 2021-01-16 03:57:28 --> Total execution time: 0.3261
INFO - 2021-01-16 04:00:16 --> Config Class Initialized
INFO - 2021-01-16 04:00:16 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:00:16 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:00:16 --> Utf8 Class Initialized
INFO - 2021-01-16 04:00:16 --> URI Class Initialized
INFO - 2021-01-16 04:00:16 --> Router Class Initialized
INFO - 2021-01-16 04:00:16 --> Output Class Initialized
INFO - 2021-01-16 04:00:16 --> Security Class Initialized
DEBUG - 2021-01-16 04:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:00:16 --> Input Class Initialized
INFO - 2021-01-16 04:00:16 --> Language Class Initialized
INFO - 2021-01-16 04:00:16 --> Language Class Initialized
INFO - 2021-01-16 04:00:16 --> Config Class Initialized
INFO - 2021-01-16 04:00:16 --> Loader Class Initialized
INFO - 2021-01-16 04:00:16 --> Helper loaded: url_helper
INFO - 2021-01-16 04:00:16 --> Helper loaded: file_helper
INFO - 2021-01-16 04:00:16 --> Helper loaded: form_helper
INFO - 2021-01-16 04:00:16 --> Helper loaded: my_helper
INFO - 2021-01-16 04:00:16 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:00:16 --> Controller Class Initialized
DEBUG - 2021-01-16 04:00:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:00:16 --> Final output sent to browser
DEBUG - 2021-01-16 04:00:16 --> Total execution time: 0.3236
INFO - 2021-01-16 04:01:02 --> Config Class Initialized
INFO - 2021-01-16 04:01:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:01:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:01:02 --> Utf8 Class Initialized
INFO - 2021-01-16 04:01:02 --> URI Class Initialized
INFO - 2021-01-16 04:01:02 --> Router Class Initialized
INFO - 2021-01-16 04:01:02 --> Output Class Initialized
INFO - 2021-01-16 04:01:02 --> Security Class Initialized
DEBUG - 2021-01-16 04:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:01:02 --> Input Class Initialized
INFO - 2021-01-16 04:01:02 --> Language Class Initialized
INFO - 2021-01-16 04:01:02 --> Language Class Initialized
INFO - 2021-01-16 04:01:02 --> Config Class Initialized
INFO - 2021-01-16 04:01:02 --> Loader Class Initialized
INFO - 2021-01-16 04:01:02 --> Helper loaded: url_helper
INFO - 2021-01-16 04:01:02 --> Helper loaded: file_helper
INFO - 2021-01-16 04:01:02 --> Helper loaded: form_helper
INFO - 2021-01-16 04:01:02 --> Helper loaded: my_helper
INFO - 2021-01-16 04:01:02 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:01:02 --> Controller Class Initialized
DEBUG - 2021-01-16 04:01:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:01:02 --> Final output sent to browser
DEBUG - 2021-01-16 04:01:02 --> Total execution time: 0.3228
INFO - 2021-01-16 04:01:22 --> Config Class Initialized
INFO - 2021-01-16 04:01:22 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:01:22 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:01:22 --> Utf8 Class Initialized
INFO - 2021-01-16 04:01:22 --> URI Class Initialized
INFO - 2021-01-16 04:01:22 --> Router Class Initialized
INFO - 2021-01-16 04:01:23 --> Output Class Initialized
INFO - 2021-01-16 04:01:23 --> Security Class Initialized
DEBUG - 2021-01-16 04:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:01:23 --> Input Class Initialized
INFO - 2021-01-16 04:01:23 --> Language Class Initialized
INFO - 2021-01-16 04:01:23 --> Language Class Initialized
INFO - 2021-01-16 04:01:23 --> Config Class Initialized
INFO - 2021-01-16 04:01:23 --> Loader Class Initialized
INFO - 2021-01-16 04:01:23 --> Helper loaded: url_helper
INFO - 2021-01-16 04:01:23 --> Helper loaded: file_helper
INFO - 2021-01-16 04:01:23 --> Helper loaded: form_helper
INFO - 2021-01-16 04:01:23 --> Helper loaded: my_helper
INFO - 2021-01-16 04:01:23 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:01:23 --> Controller Class Initialized
DEBUG - 2021-01-16 04:01:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:01:23 --> Final output sent to browser
DEBUG - 2021-01-16 04:01:23 --> Total execution time: 0.3271
INFO - 2021-01-16 04:02:32 --> Config Class Initialized
INFO - 2021-01-16 04:02:32 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:02:32 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:02:32 --> Utf8 Class Initialized
INFO - 2021-01-16 04:02:32 --> URI Class Initialized
INFO - 2021-01-16 04:02:32 --> Router Class Initialized
INFO - 2021-01-16 04:02:32 --> Output Class Initialized
INFO - 2021-01-16 04:02:32 --> Security Class Initialized
DEBUG - 2021-01-16 04:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:02:32 --> Input Class Initialized
INFO - 2021-01-16 04:02:32 --> Language Class Initialized
INFO - 2021-01-16 04:02:32 --> Language Class Initialized
INFO - 2021-01-16 04:02:32 --> Config Class Initialized
INFO - 2021-01-16 04:02:32 --> Loader Class Initialized
INFO - 2021-01-16 04:02:32 --> Helper loaded: url_helper
INFO - 2021-01-16 04:02:32 --> Helper loaded: file_helper
INFO - 2021-01-16 04:02:32 --> Helper loaded: form_helper
INFO - 2021-01-16 04:02:32 --> Helper loaded: my_helper
INFO - 2021-01-16 04:02:32 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:02:32 --> Controller Class Initialized
DEBUG - 2021-01-16 04:02:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:02:33 --> Final output sent to browser
DEBUG - 2021-01-16 04:02:33 --> Total execution time: 0.3295
INFO - 2021-01-16 04:02:48 --> Config Class Initialized
INFO - 2021-01-16 04:02:48 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:02:48 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:02:48 --> Utf8 Class Initialized
INFO - 2021-01-16 04:02:48 --> URI Class Initialized
INFO - 2021-01-16 04:02:48 --> Router Class Initialized
INFO - 2021-01-16 04:02:48 --> Output Class Initialized
INFO - 2021-01-16 04:02:48 --> Security Class Initialized
DEBUG - 2021-01-16 04:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:02:48 --> Input Class Initialized
INFO - 2021-01-16 04:02:48 --> Language Class Initialized
INFO - 2021-01-16 04:02:48 --> Language Class Initialized
INFO - 2021-01-16 04:02:48 --> Config Class Initialized
INFO - 2021-01-16 04:02:48 --> Loader Class Initialized
INFO - 2021-01-16 04:02:48 --> Helper loaded: url_helper
INFO - 2021-01-16 04:02:48 --> Helper loaded: file_helper
INFO - 2021-01-16 04:02:49 --> Helper loaded: form_helper
INFO - 2021-01-16 04:02:49 --> Helper loaded: my_helper
INFO - 2021-01-16 04:02:49 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:02:49 --> Controller Class Initialized
DEBUG - 2021-01-16 04:02:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:02:49 --> Final output sent to browser
DEBUG - 2021-01-16 04:02:49 --> Total execution time: 0.3305
INFO - 2021-01-16 04:13:06 --> Config Class Initialized
INFO - 2021-01-16 04:13:06 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:13:06 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:13:06 --> Utf8 Class Initialized
INFO - 2021-01-16 04:13:06 --> URI Class Initialized
INFO - 2021-01-16 04:13:07 --> Router Class Initialized
INFO - 2021-01-16 04:13:07 --> Output Class Initialized
INFO - 2021-01-16 04:13:07 --> Security Class Initialized
DEBUG - 2021-01-16 04:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:13:07 --> Input Class Initialized
INFO - 2021-01-16 04:13:07 --> Language Class Initialized
INFO - 2021-01-16 04:13:07 --> Language Class Initialized
INFO - 2021-01-16 04:13:07 --> Config Class Initialized
INFO - 2021-01-16 04:13:07 --> Loader Class Initialized
INFO - 2021-01-16 04:13:07 --> Helper loaded: url_helper
INFO - 2021-01-16 04:13:07 --> Helper loaded: file_helper
INFO - 2021-01-16 04:13:07 --> Helper loaded: form_helper
INFO - 2021-01-16 04:13:07 --> Helper loaded: my_helper
INFO - 2021-01-16 04:13:07 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:13:07 --> Controller Class Initialized
DEBUG - 2021-01-16 04:13:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-16 04:13:07 --> Final output sent to browser
DEBUG - 2021-01-16 04:13:07 --> Total execution time: 0.3387
INFO - 2021-01-16 04:13:12 --> Config Class Initialized
INFO - 2021-01-16 04:13:12 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:13:12 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:13:12 --> Utf8 Class Initialized
INFO - 2021-01-16 04:13:12 --> URI Class Initialized
INFO - 2021-01-16 04:13:12 --> Router Class Initialized
INFO - 2021-01-16 04:13:12 --> Output Class Initialized
INFO - 2021-01-16 04:13:12 --> Security Class Initialized
DEBUG - 2021-01-16 04:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:13:12 --> Input Class Initialized
INFO - 2021-01-16 04:13:12 --> Language Class Initialized
INFO - 2021-01-16 04:13:12 --> Language Class Initialized
INFO - 2021-01-16 04:13:12 --> Config Class Initialized
INFO - 2021-01-16 04:13:12 --> Loader Class Initialized
INFO - 2021-01-16 04:13:12 --> Helper loaded: url_helper
INFO - 2021-01-16 04:13:12 --> Helper loaded: file_helper
INFO - 2021-01-16 04:13:12 --> Helper loaded: form_helper
INFO - 2021-01-16 04:13:12 --> Helper loaded: my_helper
INFO - 2021-01-16 04:13:12 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:13:13 --> Controller Class Initialized
DEBUG - 2021-01-16 04:13:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-16 04:13:13 --> Final output sent to browser
DEBUG - 2021-01-16 04:13:13 --> Total execution time: 0.3790
INFO - 2021-01-16 04:13:31 --> Config Class Initialized
INFO - 2021-01-16 04:13:31 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:13:31 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:13:31 --> Utf8 Class Initialized
INFO - 2021-01-16 04:13:31 --> URI Class Initialized
INFO - 2021-01-16 04:13:31 --> Router Class Initialized
INFO - 2021-01-16 04:13:31 --> Output Class Initialized
INFO - 2021-01-16 04:13:31 --> Security Class Initialized
DEBUG - 2021-01-16 04:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:13:31 --> Input Class Initialized
INFO - 2021-01-16 04:13:31 --> Language Class Initialized
INFO - 2021-01-16 04:13:31 --> Language Class Initialized
INFO - 2021-01-16 04:13:31 --> Config Class Initialized
INFO - 2021-01-16 04:13:31 --> Loader Class Initialized
INFO - 2021-01-16 04:13:31 --> Helper loaded: url_helper
INFO - 2021-01-16 04:13:31 --> Helper loaded: file_helper
INFO - 2021-01-16 04:13:31 --> Helper loaded: form_helper
INFO - 2021-01-16 04:13:31 --> Helper loaded: my_helper
INFO - 2021-01-16 04:13:31 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:13:31 --> Controller Class Initialized
INFO - 2021-01-16 04:13:31 --> Helper loaded: cookie_helper
INFO - 2021-01-16 04:13:31 --> Config Class Initialized
INFO - 2021-01-16 04:13:31 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:13:31 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:13:31 --> Utf8 Class Initialized
INFO - 2021-01-16 04:13:31 --> URI Class Initialized
INFO - 2021-01-16 04:13:31 --> Router Class Initialized
INFO - 2021-01-16 04:13:31 --> Output Class Initialized
INFO - 2021-01-16 04:13:31 --> Security Class Initialized
DEBUG - 2021-01-16 04:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:13:31 --> Input Class Initialized
INFO - 2021-01-16 04:13:31 --> Language Class Initialized
INFO - 2021-01-16 04:13:31 --> Language Class Initialized
INFO - 2021-01-16 04:13:31 --> Config Class Initialized
INFO - 2021-01-16 04:13:31 --> Loader Class Initialized
INFO - 2021-01-16 04:13:31 --> Helper loaded: url_helper
INFO - 2021-01-16 04:13:31 --> Helper loaded: file_helper
INFO - 2021-01-16 04:13:31 --> Helper loaded: form_helper
INFO - 2021-01-16 04:13:31 --> Helper loaded: my_helper
INFO - 2021-01-16 04:13:31 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:13:31 --> Controller Class Initialized
DEBUG - 2021-01-16 04:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 04:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:13:31 --> Final output sent to browser
DEBUG - 2021-01-16 04:13:31 --> Total execution time: 0.3419
INFO - 2021-01-16 04:13:36 --> Config Class Initialized
INFO - 2021-01-16 04:13:36 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:13:36 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:13:36 --> Utf8 Class Initialized
INFO - 2021-01-16 04:13:36 --> URI Class Initialized
INFO - 2021-01-16 04:13:36 --> Router Class Initialized
INFO - 2021-01-16 04:13:36 --> Output Class Initialized
INFO - 2021-01-16 04:13:36 --> Security Class Initialized
DEBUG - 2021-01-16 04:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:13:36 --> Input Class Initialized
INFO - 2021-01-16 04:13:36 --> Language Class Initialized
INFO - 2021-01-16 04:13:36 --> Language Class Initialized
INFO - 2021-01-16 04:13:36 --> Config Class Initialized
INFO - 2021-01-16 04:13:36 --> Loader Class Initialized
INFO - 2021-01-16 04:13:36 --> Helper loaded: url_helper
INFO - 2021-01-16 04:13:36 --> Helper loaded: file_helper
INFO - 2021-01-16 04:13:36 --> Helper loaded: form_helper
INFO - 2021-01-16 04:13:36 --> Helper loaded: my_helper
INFO - 2021-01-16 04:13:36 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:13:36 --> Controller Class Initialized
INFO - 2021-01-16 04:13:36 --> Helper loaded: cookie_helper
INFO - 2021-01-16 04:13:36 --> Final output sent to browser
DEBUG - 2021-01-16 04:13:36 --> Total execution time: 0.3985
INFO - 2021-01-16 04:13:36 --> Config Class Initialized
INFO - 2021-01-16 04:13:36 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:13:36 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:13:36 --> Utf8 Class Initialized
INFO - 2021-01-16 04:13:36 --> URI Class Initialized
INFO - 2021-01-16 04:13:36 --> Router Class Initialized
INFO - 2021-01-16 04:13:36 --> Output Class Initialized
INFO - 2021-01-16 04:13:36 --> Security Class Initialized
DEBUG - 2021-01-16 04:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:13:36 --> Input Class Initialized
INFO - 2021-01-16 04:13:36 --> Language Class Initialized
INFO - 2021-01-16 04:13:36 --> Language Class Initialized
INFO - 2021-01-16 04:13:36 --> Config Class Initialized
INFO - 2021-01-16 04:13:36 --> Loader Class Initialized
INFO - 2021-01-16 04:13:36 --> Helper loaded: url_helper
INFO - 2021-01-16 04:13:36 --> Helper loaded: file_helper
INFO - 2021-01-16 04:13:36 --> Helper loaded: form_helper
INFO - 2021-01-16 04:13:36 --> Helper loaded: my_helper
INFO - 2021-01-16 04:13:36 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:13:36 --> Controller Class Initialized
DEBUG - 2021-01-16 04:13:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 04:13:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:13:37 --> Final output sent to browser
DEBUG - 2021-01-16 04:13:37 --> Total execution time: 0.4310
INFO - 2021-01-16 04:13:38 --> Config Class Initialized
INFO - 2021-01-16 04:13:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:13:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:13:38 --> Utf8 Class Initialized
INFO - 2021-01-16 04:13:38 --> URI Class Initialized
INFO - 2021-01-16 04:13:38 --> Router Class Initialized
INFO - 2021-01-16 04:13:38 --> Output Class Initialized
INFO - 2021-01-16 04:13:38 --> Security Class Initialized
DEBUG - 2021-01-16 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:13:38 --> Input Class Initialized
INFO - 2021-01-16 04:13:38 --> Language Class Initialized
INFO - 2021-01-16 04:13:38 --> Language Class Initialized
INFO - 2021-01-16 04:13:38 --> Config Class Initialized
INFO - 2021-01-16 04:13:38 --> Loader Class Initialized
INFO - 2021-01-16 04:13:38 --> Helper loaded: url_helper
INFO - 2021-01-16 04:13:38 --> Helper loaded: file_helper
INFO - 2021-01-16 04:13:38 --> Helper loaded: form_helper
INFO - 2021-01-16 04:13:38 --> Helper loaded: my_helper
INFO - 2021-01-16 04:13:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:13:38 --> Controller Class Initialized
DEBUG - 2021-01-16 04:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-16 04:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:13:38 --> Final output sent to browser
DEBUG - 2021-01-16 04:13:38 --> Total execution time: 0.4155
INFO - 2021-01-16 04:13:40 --> Config Class Initialized
INFO - 2021-01-16 04:13:40 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:13:40 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:13:40 --> Utf8 Class Initialized
INFO - 2021-01-16 04:13:40 --> URI Class Initialized
INFO - 2021-01-16 04:13:40 --> Router Class Initialized
INFO - 2021-01-16 04:13:40 --> Output Class Initialized
INFO - 2021-01-16 04:13:40 --> Security Class Initialized
DEBUG - 2021-01-16 04:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:13:40 --> Input Class Initialized
INFO - 2021-01-16 04:13:40 --> Language Class Initialized
INFO - 2021-01-16 04:13:40 --> Language Class Initialized
INFO - 2021-01-16 04:13:40 --> Config Class Initialized
INFO - 2021-01-16 04:13:40 --> Loader Class Initialized
INFO - 2021-01-16 04:13:40 --> Helper loaded: url_helper
INFO - 2021-01-16 04:13:40 --> Helper loaded: file_helper
INFO - 2021-01-16 04:13:40 --> Helper loaded: form_helper
INFO - 2021-01-16 04:13:40 --> Helper loaded: my_helper
INFO - 2021-01-16 04:13:40 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:13:40 --> Controller Class Initialized
DEBUG - 2021-01-16 04:13:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-16 04:13:40 --> Final output sent to browser
DEBUG - 2021-01-16 04:13:40 --> Total execution time: 0.3547
INFO - 2021-01-16 04:14:02 --> Config Class Initialized
INFO - 2021-01-16 04:14:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:14:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:14:03 --> Utf8 Class Initialized
INFO - 2021-01-16 04:14:03 --> URI Class Initialized
INFO - 2021-01-16 04:14:03 --> Router Class Initialized
INFO - 2021-01-16 04:14:03 --> Output Class Initialized
INFO - 2021-01-16 04:14:03 --> Security Class Initialized
DEBUG - 2021-01-16 04:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:14:03 --> Input Class Initialized
INFO - 2021-01-16 04:14:03 --> Language Class Initialized
INFO - 2021-01-16 04:14:03 --> Language Class Initialized
INFO - 2021-01-16 04:14:03 --> Config Class Initialized
INFO - 2021-01-16 04:14:03 --> Loader Class Initialized
INFO - 2021-01-16 04:14:03 --> Helper loaded: url_helper
INFO - 2021-01-16 04:14:03 --> Helper loaded: file_helper
INFO - 2021-01-16 04:14:03 --> Helper loaded: form_helper
INFO - 2021-01-16 04:14:03 --> Helper loaded: my_helper
INFO - 2021-01-16 04:14:03 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:14:03 --> Controller Class Initialized
DEBUG - 2021-01-16 04:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:14:03 --> Final output sent to browser
DEBUG - 2021-01-16 04:14:03 --> Total execution time: 0.2998
INFO - 2021-01-16 04:14:07 --> Config Class Initialized
INFO - 2021-01-16 04:14:07 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:14:07 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:14:07 --> Utf8 Class Initialized
INFO - 2021-01-16 04:14:07 --> URI Class Initialized
INFO - 2021-01-16 04:14:07 --> Router Class Initialized
INFO - 2021-01-16 04:14:07 --> Output Class Initialized
INFO - 2021-01-16 04:14:07 --> Security Class Initialized
DEBUG - 2021-01-16 04:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:14:07 --> Input Class Initialized
INFO - 2021-01-16 04:14:07 --> Language Class Initialized
INFO - 2021-01-16 04:14:07 --> Language Class Initialized
INFO - 2021-01-16 04:14:07 --> Config Class Initialized
INFO - 2021-01-16 04:14:07 --> Loader Class Initialized
INFO - 2021-01-16 04:14:07 --> Helper loaded: url_helper
INFO - 2021-01-16 04:14:07 --> Helper loaded: file_helper
INFO - 2021-01-16 04:14:07 --> Helper loaded: form_helper
INFO - 2021-01-16 04:14:07 --> Helper loaded: my_helper
INFO - 2021-01-16 04:14:07 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:14:07 --> Controller Class Initialized
INFO - 2021-01-16 04:14:07 --> Helper loaded: cookie_helper
INFO - 2021-01-16 04:14:07 --> Config Class Initialized
INFO - 2021-01-16 04:14:07 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:14:07 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:14:07 --> Utf8 Class Initialized
INFO - 2021-01-16 04:14:07 --> URI Class Initialized
INFO - 2021-01-16 04:14:07 --> Router Class Initialized
INFO - 2021-01-16 04:14:07 --> Output Class Initialized
INFO - 2021-01-16 04:14:07 --> Security Class Initialized
DEBUG - 2021-01-16 04:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:14:07 --> Input Class Initialized
INFO - 2021-01-16 04:14:07 --> Language Class Initialized
INFO - 2021-01-16 04:14:08 --> Language Class Initialized
INFO - 2021-01-16 04:14:08 --> Config Class Initialized
INFO - 2021-01-16 04:14:08 --> Loader Class Initialized
INFO - 2021-01-16 04:14:08 --> Helper loaded: url_helper
INFO - 2021-01-16 04:14:08 --> Helper loaded: file_helper
INFO - 2021-01-16 04:14:08 --> Helper loaded: form_helper
INFO - 2021-01-16 04:14:08 --> Helper loaded: my_helper
INFO - 2021-01-16 04:14:08 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:14:08 --> Controller Class Initialized
DEBUG - 2021-01-16 04:14:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 04:14:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:14:08 --> Final output sent to browser
DEBUG - 2021-01-16 04:14:08 --> Total execution time: 0.3418
INFO - 2021-01-16 04:14:52 --> Config Class Initialized
INFO - 2021-01-16 04:14:52 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:14:52 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:14:52 --> Utf8 Class Initialized
INFO - 2021-01-16 04:14:52 --> URI Class Initialized
INFO - 2021-01-16 04:14:52 --> Router Class Initialized
INFO - 2021-01-16 04:14:52 --> Output Class Initialized
INFO - 2021-01-16 04:14:52 --> Security Class Initialized
DEBUG - 2021-01-16 04:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:14:52 --> Input Class Initialized
INFO - 2021-01-16 04:14:52 --> Language Class Initialized
INFO - 2021-01-16 04:14:53 --> Language Class Initialized
INFO - 2021-01-16 04:14:53 --> Config Class Initialized
INFO - 2021-01-16 04:14:53 --> Loader Class Initialized
INFO - 2021-01-16 04:14:53 --> Helper loaded: url_helper
INFO - 2021-01-16 04:14:53 --> Helper loaded: file_helper
INFO - 2021-01-16 04:14:53 --> Helper loaded: form_helper
INFO - 2021-01-16 04:14:53 --> Helper loaded: my_helper
INFO - 2021-01-16 04:14:53 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:14:53 --> Controller Class Initialized
INFO - 2021-01-16 04:14:53 --> Final output sent to browser
DEBUG - 2021-01-16 04:14:53 --> Total execution time: 0.4593
INFO - 2021-01-16 04:14:59 --> Config Class Initialized
INFO - 2021-01-16 04:14:59 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:14:59 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:14:59 --> Utf8 Class Initialized
INFO - 2021-01-16 04:14:59 --> URI Class Initialized
INFO - 2021-01-16 04:14:59 --> Router Class Initialized
INFO - 2021-01-16 04:14:59 --> Output Class Initialized
INFO - 2021-01-16 04:14:59 --> Security Class Initialized
DEBUG - 2021-01-16 04:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:14:59 --> Input Class Initialized
INFO - 2021-01-16 04:14:59 --> Language Class Initialized
INFO - 2021-01-16 04:14:59 --> Language Class Initialized
INFO - 2021-01-16 04:14:59 --> Config Class Initialized
INFO - 2021-01-16 04:14:59 --> Loader Class Initialized
INFO - 2021-01-16 04:14:59 --> Helper loaded: url_helper
INFO - 2021-01-16 04:14:59 --> Helper loaded: file_helper
INFO - 2021-01-16 04:14:59 --> Helper loaded: form_helper
INFO - 2021-01-16 04:14:59 --> Helper loaded: my_helper
INFO - 2021-01-16 04:14:59 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:14:59 --> Controller Class Initialized
INFO - 2021-01-16 04:14:59 --> Helper loaded: cookie_helper
INFO - 2021-01-16 04:14:59 --> Final output sent to browser
DEBUG - 2021-01-16 04:14:59 --> Total execution time: 0.4224
INFO - 2021-01-16 04:14:59 --> Config Class Initialized
INFO - 2021-01-16 04:14:59 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:00 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:00 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:00 --> URI Class Initialized
INFO - 2021-01-16 04:15:00 --> Router Class Initialized
INFO - 2021-01-16 04:15:00 --> Output Class Initialized
INFO - 2021-01-16 04:15:00 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:00 --> Input Class Initialized
INFO - 2021-01-16 04:15:00 --> Language Class Initialized
INFO - 2021-01-16 04:15:00 --> Language Class Initialized
INFO - 2021-01-16 04:15:00 --> Config Class Initialized
INFO - 2021-01-16 04:15:00 --> Loader Class Initialized
INFO - 2021-01-16 04:15:00 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:00 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:00 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:00 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:00 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:00 --> Controller Class Initialized
DEBUG - 2021-01-16 04:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 04:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:15:00 --> Final output sent to browser
DEBUG - 2021-01-16 04:15:00 --> Total execution time: 0.4538
INFO - 2021-01-16 04:15:15 --> Config Class Initialized
INFO - 2021-01-16 04:15:15 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:15 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:15 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:15 --> URI Class Initialized
INFO - 2021-01-16 04:15:15 --> Router Class Initialized
INFO - 2021-01-16 04:15:15 --> Output Class Initialized
INFO - 2021-01-16 04:15:15 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:15 --> Input Class Initialized
INFO - 2021-01-16 04:15:15 --> Language Class Initialized
INFO - 2021-01-16 04:15:15 --> Language Class Initialized
INFO - 2021-01-16 04:15:15 --> Config Class Initialized
INFO - 2021-01-16 04:15:15 --> Loader Class Initialized
INFO - 2021-01-16 04:15:15 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:15 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:15 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:15 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:15 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:16 --> Controller Class Initialized
DEBUG - 2021-01-16 04:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-16 04:15:16 --> Final output sent to browser
DEBUG - 2021-01-16 04:15:16 --> Total execution time: 0.2975
INFO - 2021-01-16 04:15:38 --> Config Class Initialized
INFO - 2021-01-16 04:15:38 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:38 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:38 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:38 --> URI Class Initialized
INFO - 2021-01-16 04:15:38 --> Router Class Initialized
INFO - 2021-01-16 04:15:38 --> Output Class Initialized
INFO - 2021-01-16 04:15:38 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:38 --> Input Class Initialized
INFO - 2021-01-16 04:15:38 --> Language Class Initialized
INFO - 2021-01-16 04:15:38 --> Language Class Initialized
INFO - 2021-01-16 04:15:38 --> Config Class Initialized
INFO - 2021-01-16 04:15:38 --> Loader Class Initialized
INFO - 2021-01-16 04:15:38 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:38 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:38 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:38 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:38 --> Controller Class Initialized
DEBUG - 2021-01-16 04:15:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-16 04:15:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:15:39 --> Final output sent to browser
DEBUG - 2021-01-16 04:15:39 --> Total execution time: 0.3541
INFO - 2021-01-16 04:15:39 --> Config Class Initialized
INFO - 2021-01-16 04:15:39 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:39 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:39 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:39 --> URI Class Initialized
INFO - 2021-01-16 04:15:39 --> Router Class Initialized
INFO - 2021-01-16 04:15:39 --> Output Class Initialized
INFO - 2021-01-16 04:15:39 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:39 --> Input Class Initialized
INFO - 2021-01-16 04:15:39 --> Language Class Initialized
INFO - 2021-01-16 04:15:39 --> Language Class Initialized
INFO - 2021-01-16 04:15:39 --> Config Class Initialized
INFO - 2021-01-16 04:15:39 --> Loader Class Initialized
INFO - 2021-01-16 04:15:39 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:39 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:39 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:39 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:39 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:39 --> Controller Class Initialized
INFO - 2021-01-16 04:15:44 --> Config Class Initialized
INFO - 2021-01-16 04:15:44 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:44 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:44 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:44 --> URI Class Initialized
INFO - 2021-01-16 04:15:45 --> Router Class Initialized
INFO - 2021-01-16 04:15:45 --> Output Class Initialized
INFO - 2021-01-16 04:15:45 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:45 --> Input Class Initialized
INFO - 2021-01-16 04:15:45 --> Language Class Initialized
INFO - 2021-01-16 04:15:45 --> Language Class Initialized
INFO - 2021-01-16 04:15:45 --> Config Class Initialized
INFO - 2021-01-16 04:15:45 --> Loader Class Initialized
INFO - 2021-01-16 04:15:45 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:45 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:45 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:45 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:45 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:45 --> Controller Class Initialized
INFO - 2021-01-16 04:15:45 --> Config Class Initialized
INFO - 2021-01-16 04:15:45 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:45 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:45 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:45 --> URI Class Initialized
INFO - 2021-01-16 04:15:45 --> Router Class Initialized
INFO - 2021-01-16 04:15:45 --> Output Class Initialized
INFO - 2021-01-16 04:15:45 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:45 --> Input Class Initialized
INFO - 2021-01-16 04:15:45 --> Language Class Initialized
INFO - 2021-01-16 04:15:45 --> Language Class Initialized
INFO - 2021-01-16 04:15:45 --> Config Class Initialized
INFO - 2021-01-16 04:15:45 --> Loader Class Initialized
INFO - 2021-01-16 04:15:45 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:45 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:45 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:45 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:45 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:45 --> Controller Class Initialized
INFO - 2021-01-16 04:15:46 --> Config Class Initialized
INFO - 2021-01-16 04:15:46 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:46 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:46 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:46 --> URI Class Initialized
INFO - 2021-01-16 04:15:46 --> Router Class Initialized
INFO - 2021-01-16 04:15:46 --> Output Class Initialized
INFO - 2021-01-16 04:15:46 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:46 --> Input Class Initialized
INFO - 2021-01-16 04:15:46 --> Language Class Initialized
INFO - 2021-01-16 04:15:47 --> Language Class Initialized
INFO - 2021-01-16 04:15:47 --> Config Class Initialized
INFO - 2021-01-16 04:15:47 --> Loader Class Initialized
INFO - 2021-01-16 04:15:47 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:47 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:47 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:47 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:47 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:47 --> Controller Class Initialized
INFO - 2021-01-16 04:15:47 --> Config Class Initialized
INFO - 2021-01-16 04:15:47 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:47 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:47 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:47 --> URI Class Initialized
INFO - 2021-01-16 04:15:47 --> Router Class Initialized
INFO - 2021-01-16 04:15:47 --> Output Class Initialized
INFO - 2021-01-16 04:15:47 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:47 --> Input Class Initialized
INFO - 2021-01-16 04:15:47 --> Language Class Initialized
INFO - 2021-01-16 04:15:47 --> Language Class Initialized
INFO - 2021-01-16 04:15:47 --> Config Class Initialized
INFO - 2021-01-16 04:15:47 --> Loader Class Initialized
INFO - 2021-01-16 04:15:47 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:47 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:47 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:47 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:47 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:47 --> Controller Class Initialized
INFO - 2021-01-16 04:15:49 --> Config Class Initialized
INFO - 2021-01-16 04:15:49 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:49 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:49 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:49 --> URI Class Initialized
INFO - 2021-01-16 04:15:49 --> Router Class Initialized
INFO - 2021-01-16 04:15:49 --> Output Class Initialized
INFO - 2021-01-16 04:15:49 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:49 --> Input Class Initialized
INFO - 2021-01-16 04:15:49 --> Language Class Initialized
INFO - 2021-01-16 04:15:49 --> Language Class Initialized
INFO - 2021-01-16 04:15:49 --> Config Class Initialized
INFO - 2021-01-16 04:15:49 --> Loader Class Initialized
INFO - 2021-01-16 04:15:49 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:49 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:49 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:49 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:49 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:49 --> Controller Class Initialized
INFO - 2021-01-16 04:15:49 --> Config Class Initialized
INFO - 2021-01-16 04:15:49 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:49 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:49 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:49 --> URI Class Initialized
INFO - 2021-01-16 04:15:49 --> Router Class Initialized
INFO - 2021-01-16 04:15:49 --> Output Class Initialized
INFO - 2021-01-16 04:15:49 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:50 --> Input Class Initialized
INFO - 2021-01-16 04:15:50 --> Language Class Initialized
INFO - 2021-01-16 04:15:50 --> Language Class Initialized
INFO - 2021-01-16 04:15:50 --> Config Class Initialized
INFO - 2021-01-16 04:15:50 --> Loader Class Initialized
INFO - 2021-01-16 04:15:50 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:50 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:50 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:50 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:50 --> Controller Class Initialized
INFO - 2021-01-16 04:15:50 --> Config Class Initialized
INFO - 2021-01-16 04:15:50 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:50 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:50 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:50 --> URI Class Initialized
INFO - 2021-01-16 04:15:50 --> Router Class Initialized
INFO - 2021-01-16 04:15:50 --> Output Class Initialized
INFO - 2021-01-16 04:15:50 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:50 --> Input Class Initialized
INFO - 2021-01-16 04:15:50 --> Language Class Initialized
INFO - 2021-01-16 04:15:50 --> Language Class Initialized
INFO - 2021-01-16 04:15:50 --> Config Class Initialized
INFO - 2021-01-16 04:15:50 --> Loader Class Initialized
INFO - 2021-01-16 04:15:50 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:50 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:50 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:50 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:50 --> Controller Class Initialized
INFO - 2021-01-16 04:15:54 --> Config Class Initialized
INFO - 2021-01-16 04:15:54 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:54 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:54 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:54 --> URI Class Initialized
INFO - 2021-01-16 04:15:54 --> Router Class Initialized
INFO - 2021-01-16 04:15:54 --> Output Class Initialized
INFO - 2021-01-16 04:15:54 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:54 --> Input Class Initialized
INFO - 2021-01-16 04:15:54 --> Language Class Initialized
INFO - 2021-01-16 04:15:54 --> Language Class Initialized
INFO - 2021-01-16 04:15:54 --> Config Class Initialized
INFO - 2021-01-16 04:15:54 --> Loader Class Initialized
INFO - 2021-01-16 04:15:54 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:54 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:54 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:54 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:55 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:55 --> Controller Class Initialized
INFO - 2021-01-16 04:15:55 --> Config Class Initialized
INFO - 2021-01-16 04:15:55 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:55 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:55 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:55 --> URI Class Initialized
INFO - 2021-01-16 04:15:55 --> Router Class Initialized
INFO - 2021-01-16 04:15:55 --> Output Class Initialized
INFO - 2021-01-16 04:15:55 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:55 --> Input Class Initialized
INFO - 2021-01-16 04:15:55 --> Language Class Initialized
INFO - 2021-01-16 04:15:55 --> Language Class Initialized
INFO - 2021-01-16 04:15:55 --> Config Class Initialized
INFO - 2021-01-16 04:15:55 --> Loader Class Initialized
INFO - 2021-01-16 04:15:55 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:55 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:55 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:55 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:55 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:55 --> Controller Class Initialized
INFO - 2021-01-16 04:15:56 --> Config Class Initialized
INFO - 2021-01-16 04:15:56 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:56 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:56 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:56 --> URI Class Initialized
INFO - 2021-01-16 04:15:56 --> Router Class Initialized
INFO - 2021-01-16 04:15:56 --> Output Class Initialized
INFO - 2021-01-16 04:15:56 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:56 --> Input Class Initialized
INFO - 2021-01-16 04:15:56 --> Language Class Initialized
INFO - 2021-01-16 04:15:56 --> Language Class Initialized
INFO - 2021-01-16 04:15:56 --> Config Class Initialized
INFO - 2021-01-16 04:15:56 --> Loader Class Initialized
INFO - 2021-01-16 04:15:56 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:56 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:56 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:56 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:56 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:56 --> Controller Class Initialized
INFO - 2021-01-16 04:15:58 --> Config Class Initialized
INFO - 2021-01-16 04:15:58 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:15:58 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:15:58 --> Utf8 Class Initialized
INFO - 2021-01-16 04:15:58 --> URI Class Initialized
INFO - 2021-01-16 04:15:58 --> Router Class Initialized
INFO - 2021-01-16 04:15:58 --> Output Class Initialized
INFO - 2021-01-16 04:15:58 --> Security Class Initialized
DEBUG - 2021-01-16 04:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:15:58 --> Input Class Initialized
INFO - 2021-01-16 04:15:58 --> Language Class Initialized
INFO - 2021-01-16 04:15:58 --> Language Class Initialized
INFO - 2021-01-16 04:15:58 --> Config Class Initialized
INFO - 2021-01-16 04:15:58 --> Loader Class Initialized
INFO - 2021-01-16 04:15:58 --> Helper loaded: url_helper
INFO - 2021-01-16 04:15:58 --> Helper loaded: file_helper
INFO - 2021-01-16 04:15:58 --> Helper loaded: form_helper
INFO - 2021-01-16 04:15:58 --> Helper loaded: my_helper
INFO - 2021-01-16 04:15:58 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:15:58 --> Controller Class Initialized
DEBUG - 2021-01-16 04:15:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-16 04:15:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:15:58 --> Final output sent to browser
DEBUG - 2021-01-16 04:15:58 --> Total execution time: 0.4281
INFO - 2021-01-16 04:16:08 --> Config Class Initialized
INFO - 2021-01-16 04:16:08 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:08 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:08 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:08 --> URI Class Initialized
INFO - 2021-01-16 04:16:08 --> Router Class Initialized
INFO - 2021-01-16 04:16:08 --> Output Class Initialized
INFO - 2021-01-16 04:16:08 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:08 --> Input Class Initialized
INFO - 2021-01-16 04:16:08 --> Language Class Initialized
INFO - 2021-01-16 04:16:08 --> Language Class Initialized
INFO - 2021-01-16 04:16:08 --> Config Class Initialized
INFO - 2021-01-16 04:16:08 --> Loader Class Initialized
INFO - 2021-01-16 04:16:08 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:08 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:08 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:08 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:08 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:08 --> Controller Class Initialized
INFO - 2021-01-16 04:16:08 --> Config Class Initialized
INFO - 2021-01-16 04:16:08 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:08 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:08 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:08 --> URI Class Initialized
INFO - 2021-01-16 04:16:08 --> Router Class Initialized
INFO - 2021-01-16 04:16:08 --> Output Class Initialized
INFO - 2021-01-16 04:16:08 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:08 --> Input Class Initialized
INFO - 2021-01-16 04:16:08 --> Language Class Initialized
INFO - 2021-01-16 04:16:08 --> Language Class Initialized
INFO - 2021-01-16 04:16:08 --> Config Class Initialized
INFO - 2021-01-16 04:16:08 --> Loader Class Initialized
INFO - 2021-01-16 04:16:08 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:08 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:08 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:08 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:08 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:08 --> Controller Class Initialized
DEBUG - 2021-01-16 04:16:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-16 04:16:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:16:08 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:09 --> Total execution time: 0.3169
INFO - 2021-01-16 04:16:09 --> Config Class Initialized
INFO - 2021-01-16 04:16:09 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:09 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:09 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:09 --> URI Class Initialized
INFO - 2021-01-16 04:16:09 --> Router Class Initialized
INFO - 2021-01-16 04:16:09 --> Output Class Initialized
INFO - 2021-01-16 04:16:09 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:09 --> Input Class Initialized
INFO - 2021-01-16 04:16:09 --> Language Class Initialized
INFO - 2021-01-16 04:16:09 --> Language Class Initialized
INFO - 2021-01-16 04:16:09 --> Config Class Initialized
INFO - 2021-01-16 04:16:09 --> Loader Class Initialized
INFO - 2021-01-16 04:16:09 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:09 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:09 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:09 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:09 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:09 --> Controller Class Initialized
INFO - 2021-01-16 04:16:15 --> Config Class Initialized
INFO - 2021-01-16 04:16:15 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:15 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:15 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:15 --> URI Class Initialized
INFO - 2021-01-16 04:16:15 --> Router Class Initialized
INFO - 2021-01-16 04:16:15 --> Output Class Initialized
INFO - 2021-01-16 04:16:15 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:15 --> Input Class Initialized
INFO - 2021-01-16 04:16:15 --> Language Class Initialized
INFO - 2021-01-16 04:16:15 --> Language Class Initialized
INFO - 2021-01-16 04:16:15 --> Config Class Initialized
INFO - 2021-01-16 04:16:15 --> Loader Class Initialized
INFO - 2021-01-16 04:16:15 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:15 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:15 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:15 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:15 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:15 --> Controller Class Initialized
INFO - 2021-01-16 04:16:15 --> Helper loaded: cookie_helper
INFO - 2021-01-16 04:16:15 --> Config Class Initialized
INFO - 2021-01-16 04:16:15 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:15 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:15 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:15 --> URI Class Initialized
INFO - 2021-01-16 04:16:16 --> Router Class Initialized
INFO - 2021-01-16 04:16:16 --> Output Class Initialized
INFO - 2021-01-16 04:16:16 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:16 --> Input Class Initialized
INFO - 2021-01-16 04:16:16 --> Language Class Initialized
INFO - 2021-01-16 04:16:16 --> Language Class Initialized
INFO - 2021-01-16 04:16:16 --> Config Class Initialized
INFO - 2021-01-16 04:16:16 --> Loader Class Initialized
INFO - 2021-01-16 04:16:16 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:16 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:16 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:16 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:16 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:16 --> Controller Class Initialized
DEBUG - 2021-01-16 04:16:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 04:16:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:16:16 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:16 --> Total execution time: 0.3402
INFO - 2021-01-16 04:16:20 --> Config Class Initialized
INFO - 2021-01-16 04:16:20 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:20 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:20 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:20 --> URI Class Initialized
INFO - 2021-01-16 04:16:20 --> Router Class Initialized
INFO - 2021-01-16 04:16:20 --> Output Class Initialized
INFO - 2021-01-16 04:16:20 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:20 --> Input Class Initialized
INFO - 2021-01-16 04:16:20 --> Language Class Initialized
INFO - 2021-01-16 04:16:20 --> Language Class Initialized
INFO - 2021-01-16 04:16:20 --> Config Class Initialized
INFO - 2021-01-16 04:16:20 --> Loader Class Initialized
INFO - 2021-01-16 04:16:20 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:20 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:20 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:20 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:20 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:20 --> Controller Class Initialized
INFO - 2021-01-16 04:16:20 --> Helper loaded: cookie_helper
INFO - 2021-01-16 04:16:20 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:20 --> Total execution time: 0.4244
INFO - 2021-01-16 04:16:21 --> Config Class Initialized
INFO - 2021-01-16 04:16:21 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:21 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:21 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:21 --> URI Class Initialized
INFO - 2021-01-16 04:16:21 --> Router Class Initialized
INFO - 2021-01-16 04:16:21 --> Output Class Initialized
INFO - 2021-01-16 04:16:21 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:21 --> Input Class Initialized
INFO - 2021-01-16 04:16:21 --> Language Class Initialized
INFO - 2021-01-16 04:16:21 --> Language Class Initialized
INFO - 2021-01-16 04:16:21 --> Config Class Initialized
INFO - 2021-01-16 04:16:21 --> Loader Class Initialized
INFO - 2021-01-16 04:16:21 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:21 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:21 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:21 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:21 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:21 --> Controller Class Initialized
DEBUG - 2021-01-16 04:16:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 04:16:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:16:21 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:21 --> Total execution time: 0.4950
INFO - 2021-01-16 04:16:23 --> Config Class Initialized
INFO - 2021-01-16 04:16:23 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:23 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:23 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:23 --> URI Class Initialized
INFO - 2021-01-16 04:16:23 --> Router Class Initialized
INFO - 2021-01-16 04:16:23 --> Output Class Initialized
INFO - 2021-01-16 04:16:23 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:23 --> Input Class Initialized
INFO - 2021-01-16 04:16:23 --> Language Class Initialized
INFO - 2021-01-16 04:16:23 --> Language Class Initialized
INFO - 2021-01-16 04:16:23 --> Config Class Initialized
INFO - 2021-01-16 04:16:23 --> Loader Class Initialized
INFO - 2021-01-16 04:16:23 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:23 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:23 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:23 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:23 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:23 --> Controller Class Initialized
DEBUG - 2021-01-16 04:16:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:16:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:16:23 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:23 --> Total execution time: 0.3848
INFO - 2021-01-16 04:16:25 --> Config Class Initialized
INFO - 2021-01-16 04:16:25 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:25 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:25 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:25 --> URI Class Initialized
INFO - 2021-01-16 04:16:25 --> Router Class Initialized
INFO - 2021-01-16 04:16:25 --> Output Class Initialized
INFO - 2021-01-16 04:16:25 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:25 --> Input Class Initialized
INFO - 2021-01-16 04:16:25 --> Language Class Initialized
INFO - 2021-01-16 04:16:25 --> Language Class Initialized
INFO - 2021-01-16 04:16:25 --> Config Class Initialized
INFO - 2021-01-16 04:16:25 --> Loader Class Initialized
INFO - 2021-01-16 04:16:25 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:25 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:25 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:25 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:25 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:25 --> Controller Class Initialized
DEBUG - 2021-01-16 04:16:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-16 04:16:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:16:25 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:25 --> Total execution time: 0.3523
INFO - 2021-01-16 04:16:25 --> Config Class Initialized
INFO - 2021-01-16 04:16:25 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:25 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:25 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:25 --> URI Class Initialized
INFO - 2021-01-16 04:16:25 --> Router Class Initialized
INFO - 2021-01-16 04:16:25 --> Output Class Initialized
INFO - 2021-01-16 04:16:25 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:25 --> Input Class Initialized
INFO - 2021-01-16 04:16:25 --> Language Class Initialized
INFO - 2021-01-16 04:16:25 --> Language Class Initialized
INFO - 2021-01-16 04:16:25 --> Config Class Initialized
INFO - 2021-01-16 04:16:25 --> Loader Class Initialized
INFO - 2021-01-16 04:16:25 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:25 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:25 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:25 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:25 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:25 --> Controller Class Initialized
INFO - 2021-01-16 04:16:26 --> Config Class Initialized
INFO - 2021-01-16 04:16:26 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:26 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:26 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:26 --> URI Class Initialized
INFO - 2021-01-16 04:16:26 --> Router Class Initialized
INFO - 2021-01-16 04:16:26 --> Output Class Initialized
INFO - 2021-01-16 04:16:26 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:26 --> Input Class Initialized
INFO - 2021-01-16 04:16:26 --> Language Class Initialized
INFO - 2021-01-16 04:16:26 --> Language Class Initialized
INFO - 2021-01-16 04:16:26 --> Config Class Initialized
INFO - 2021-01-16 04:16:26 --> Loader Class Initialized
INFO - 2021-01-16 04:16:26 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:26 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:26 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:26 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:26 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:26 --> Controller Class Initialized
INFO - 2021-01-16 04:16:26 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:26 --> Total execution time: 0.3361
INFO - 2021-01-16 04:16:42 --> Config Class Initialized
INFO - 2021-01-16 04:16:42 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:42 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:42 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:42 --> URI Class Initialized
INFO - 2021-01-16 04:16:42 --> Router Class Initialized
INFO - 2021-01-16 04:16:42 --> Output Class Initialized
INFO - 2021-01-16 04:16:42 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:42 --> Input Class Initialized
INFO - 2021-01-16 04:16:42 --> Language Class Initialized
INFO - 2021-01-16 04:16:42 --> Language Class Initialized
INFO - 2021-01-16 04:16:42 --> Config Class Initialized
INFO - 2021-01-16 04:16:42 --> Loader Class Initialized
INFO - 2021-01-16 04:16:42 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:42 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:42 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:42 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:42 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:42 --> Controller Class Initialized
INFO - 2021-01-16 04:16:42 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:42 --> Total execution time: 0.3898
INFO - 2021-01-16 04:16:42 --> Config Class Initialized
INFO - 2021-01-16 04:16:42 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:42 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:42 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:42 --> URI Class Initialized
INFO - 2021-01-16 04:16:42 --> Router Class Initialized
INFO - 2021-01-16 04:16:42 --> Output Class Initialized
INFO - 2021-01-16 04:16:42 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:42 --> Input Class Initialized
INFO - 2021-01-16 04:16:42 --> Language Class Initialized
INFO - 2021-01-16 04:16:42 --> Language Class Initialized
INFO - 2021-01-16 04:16:42 --> Config Class Initialized
INFO - 2021-01-16 04:16:42 --> Loader Class Initialized
INFO - 2021-01-16 04:16:42 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:42 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:42 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:42 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:42 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:43 --> Controller Class Initialized
INFO - 2021-01-16 04:16:44 --> Config Class Initialized
INFO - 2021-01-16 04:16:44 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:44 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:44 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:44 --> URI Class Initialized
INFO - 2021-01-16 04:16:44 --> Router Class Initialized
INFO - 2021-01-16 04:16:44 --> Output Class Initialized
INFO - 2021-01-16 04:16:44 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:44 --> Input Class Initialized
INFO - 2021-01-16 04:16:44 --> Language Class Initialized
INFO - 2021-01-16 04:16:44 --> Language Class Initialized
INFO - 2021-01-16 04:16:44 --> Config Class Initialized
INFO - 2021-01-16 04:16:44 --> Loader Class Initialized
INFO - 2021-01-16 04:16:44 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:44 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:44 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:44 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:44 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:44 --> Controller Class Initialized
INFO - 2021-01-16 04:16:44 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:44 --> Total execution time: 0.2901
INFO - 2021-01-16 04:16:48 --> Config Class Initialized
INFO - 2021-01-16 04:16:48 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:48 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:48 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:48 --> URI Class Initialized
INFO - 2021-01-16 04:16:48 --> Router Class Initialized
INFO - 2021-01-16 04:16:48 --> Output Class Initialized
INFO - 2021-01-16 04:16:48 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:48 --> Input Class Initialized
INFO - 2021-01-16 04:16:48 --> Language Class Initialized
INFO - 2021-01-16 04:16:48 --> Language Class Initialized
INFO - 2021-01-16 04:16:48 --> Config Class Initialized
INFO - 2021-01-16 04:16:48 --> Loader Class Initialized
INFO - 2021-01-16 04:16:48 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:48 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:48 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:48 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:48 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:48 --> Controller Class Initialized
INFO - 2021-01-16 04:16:49 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:49 --> Total execution time: 0.5091
INFO - 2021-01-16 04:16:51 --> Config Class Initialized
INFO - 2021-01-16 04:16:51 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:51 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:51 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:51 --> URI Class Initialized
INFO - 2021-01-16 04:16:51 --> Router Class Initialized
INFO - 2021-01-16 04:16:51 --> Output Class Initialized
INFO - 2021-01-16 04:16:51 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:51 --> Input Class Initialized
INFO - 2021-01-16 04:16:51 --> Language Class Initialized
INFO - 2021-01-16 04:16:51 --> Language Class Initialized
INFO - 2021-01-16 04:16:51 --> Config Class Initialized
INFO - 2021-01-16 04:16:51 --> Loader Class Initialized
INFO - 2021-01-16 04:16:51 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:51 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:51 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:51 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:51 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:51 --> Controller Class Initialized
INFO - 2021-01-16 04:16:51 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:51 --> Total execution time: 0.2740
INFO - 2021-01-16 04:16:55 --> Config Class Initialized
INFO - 2021-01-16 04:16:55 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:55 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:55 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:55 --> URI Class Initialized
INFO - 2021-01-16 04:16:55 --> Router Class Initialized
INFO - 2021-01-16 04:16:55 --> Output Class Initialized
INFO - 2021-01-16 04:16:55 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:55 --> Input Class Initialized
INFO - 2021-01-16 04:16:55 --> Language Class Initialized
INFO - 2021-01-16 04:16:55 --> Language Class Initialized
INFO - 2021-01-16 04:16:55 --> Config Class Initialized
INFO - 2021-01-16 04:16:55 --> Loader Class Initialized
INFO - 2021-01-16 04:16:55 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:55 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:55 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:55 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:55 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:55 --> Controller Class Initialized
INFO - 2021-01-16 04:16:55 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:55 --> Total execution time: 0.4958
INFO - 2021-01-16 04:16:57 --> Config Class Initialized
INFO - 2021-01-16 04:16:57 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:16:57 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:16:57 --> Utf8 Class Initialized
INFO - 2021-01-16 04:16:57 --> URI Class Initialized
INFO - 2021-01-16 04:16:57 --> Router Class Initialized
INFO - 2021-01-16 04:16:57 --> Output Class Initialized
INFO - 2021-01-16 04:16:57 --> Security Class Initialized
DEBUG - 2021-01-16 04:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:16:57 --> Input Class Initialized
INFO - 2021-01-16 04:16:57 --> Language Class Initialized
INFO - 2021-01-16 04:16:57 --> Language Class Initialized
INFO - 2021-01-16 04:16:58 --> Config Class Initialized
INFO - 2021-01-16 04:16:58 --> Loader Class Initialized
INFO - 2021-01-16 04:16:58 --> Helper loaded: url_helper
INFO - 2021-01-16 04:16:58 --> Helper loaded: file_helper
INFO - 2021-01-16 04:16:58 --> Helper loaded: form_helper
INFO - 2021-01-16 04:16:58 --> Helper loaded: my_helper
INFO - 2021-01-16 04:16:58 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:16:58 --> Controller Class Initialized
INFO - 2021-01-16 04:16:58 --> Final output sent to browser
DEBUG - 2021-01-16 04:16:58 --> Total execution time: 0.2866
INFO - 2021-01-16 04:17:02 --> Config Class Initialized
INFO - 2021-01-16 04:17:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:02 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:02 --> URI Class Initialized
INFO - 2021-01-16 04:17:02 --> Router Class Initialized
INFO - 2021-01-16 04:17:02 --> Output Class Initialized
INFO - 2021-01-16 04:17:02 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:02 --> Input Class Initialized
INFO - 2021-01-16 04:17:02 --> Language Class Initialized
INFO - 2021-01-16 04:17:02 --> Language Class Initialized
INFO - 2021-01-16 04:17:02 --> Config Class Initialized
INFO - 2021-01-16 04:17:02 --> Loader Class Initialized
INFO - 2021-01-16 04:17:02 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:02 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:02 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:02 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:02 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:02 --> Controller Class Initialized
INFO - 2021-01-16 04:17:02 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:02 --> Total execution time: 0.5288
INFO - 2021-01-16 04:17:05 --> Config Class Initialized
INFO - 2021-01-16 04:17:05 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:05 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:05 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:05 --> URI Class Initialized
INFO - 2021-01-16 04:17:05 --> Router Class Initialized
INFO - 2021-01-16 04:17:05 --> Output Class Initialized
INFO - 2021-01-16 04:17:05 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:05 --> Input Class Initialized
INFO - 2021-01-16 04:17:05 --> Language Class Initialized
INFO - 2021-01-16 04:17:05 --> Language Class Initialized
INFO - 2021-01-16 04:17:05 --> Config Class Initialized
INFO - 2021-01-16 04:17:05 --> Loader Class Initialized
INFO - 2021-01-16 04:17:05 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:05 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:05 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:05 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:05 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:05 --> Controller Class Initialized
DEBUG - 2021-01-16 04:17:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:17:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:17:05 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:05 --> Total execution time: 0.3977
INFO - 2021-01-16 04:17:06 --> Config Class Initialized
INFO - 2021-01-16 04:17:06 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:06 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:06 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:06 --> URI Class Initialized
INFO - 2021-01-16 04:17:06 --> Router Class Initialized
INFO - 2021-01-16 04:17:06 --> Output Class Initialized
INFO - 2021-01-16 04:17:06 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:06 --> Input Class Initialized
INFO - 2021-01-16 04:17:06 --> Language Class Initialized
INFO - 2021-01-16 04:17:06 --> Language Class Initialized
INFO - 2021-01-16 04:17:06 --> Config Class Initialized
INFO - 2021-01-16 04:17:06 --> Loader Class Initialized
INFO - 2021-01-16 04:17:06 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:06 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:06 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:06 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:06 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:06 --> Controller Class Initialized
DEBUG - 2021-01-16 04:17:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 04:17:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:17:07 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:07 --> Total execution time: 0.3573
INFO - 2021-01-16 04:17:07 --> Config Class Initialized
INFO - 2021-01-16 04:17:08 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:08 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:08 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:08 --> URI Class Initialized
INFO - 2021-01-16 04:17:08 --> Router Class Initialized
INFO - 2021-01-16 04:17:08 --> Output Class Initialized
INFO - 2021-01-16 04:17:08 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:08 --> Input Class Initialized
INFO - 2021-01-16 04:17:08 --> Language Class Initialized
INFO - 2021-01-16 04:17:08 --> Language Class Initialized
INFO - 2021-01-16 04:17:08 --> Config Class Initialized
INFO - 2021-01-16 04:17:08 --> Loader Class Initialized
INFO - 2021-01-16 04:17:08 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:08 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:08 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:08 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:08 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:08 --> Controller Class Initialized
INFO - 2021-01-16 04:17:08 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:08 --> Total execution time: 0.3336
INFO - 2021-01-16 04:17:19 --> Config Class Initialized
INFO - 2021-01-16 04:17:19 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:19 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:19 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:19 --> URI Class Initialized
INFO - 2021-01-16 04:17:19 --> Router Class Initialized
INFO - 2021-01-16 04:17:19 --> Output Class Initialized
INFO - 2021-01-16 04:17:19 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:19 --> Input Class Initialized
INFO - 2021-01-16 04:17:19 --> Language Class Initialized
INFO - 2021-01-16 04:17:19 --> Language Class Initialized
INFO - 2021-01-16 04:17:19 --> Config Class Initialized
INFO - 2021-01-16 04:17:19 --> Loader Class Initialized
INFO - 2021-01-16 04:17:19 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:19 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:19 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:19 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:19 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:19 --> Controller Class Initialized
INFO - 2021-01-16 04:17:19 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:19 --> Total execution time: 0.3389
INFO - 2021-01-16 04:17:19 --> Config Class Initialized
INFO - 2021-01-16 04:17:19 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:19 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:19 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:19 --> URI Class Initialized
INFO - 2021-01-16 04:17:19 --> Router Class Initialized
INFO - 2021-01-16 04:17:19 --> Output Class Initialized
INFO - 2021-01-16 04:17:19 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:19 --> Input Class Initialized
INFO - 2021-01-16 04:17:19 --> Language Class Initialized
INFO - 2021-01-16 04:17:19 --> Language Class Initialized
INFO - 2021-01-16 04:17:20 --> Config Class Initialized
INFO - 2021-01-16 04:17:20 --> Loader Class Initialized
INFO - 2021-01-16 04:17:20 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:20 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:20 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:20 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:20 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:20 --> Controller Class Initialized
DEBUG - 2021-01-16 04:17:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 04:17:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:17:20 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:20 --> Total execution time: 0.4974
INFO - 2021-01-16 04:17:20 --> Config Class Initialized
INFO - 2021-01-16 04:17:20 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:20 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:20 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:20 --> URI Class Initialized
INFO - 2021-01-16 04:17:20 --> Router Class Initialized
INFO - 2021-01-16 04:17:20 --> Output Class Initialized
INFO - 2021-01-16 04:17:20 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:20 --> Input Class Initialized
INFO - 2021-01-16 04:17:20 --> Language Class Initialized
INFO - 2021-01-16 04:17:20 --> Language Class Initialized
INFO - 2021-01-16 04:17:20 --> Config Class Initialized
INFO - 2021-01-16 04:17:20 --> Loader Class Initialized
INFO - 2021-01-16 04:17:20 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:20 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:20 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:20 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:20 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:20 --> Controller Class Initialized
INFO - 2021-01-16 04:17:20 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:20 --> Total execution time: 0.2981
INFO - 2021-01-16 04:17:29 --> Config Class Initialized
INFO - 2021-01-16 04:17:29 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:29 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:29 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:29 --> URI Class Initialized
INFO - 2021-01-16 04:17:29 --> Router Class Initialized
INFO - 2021-01-16 04:17:29 --> Output Class Initialized
INFO - 2021-01-16 04:17:29 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:29 --> Input Class Initialized
INFO - 2021-01-16 04:17:29 --> Language Class Initialized
INFO - 2021-01-16 04:17:29 --> Language Class Initialized
INFO - 2021-01-16 04:17:29 --> Config Class Initialized
INFO - 2021-01-16 04:17:29 --> Loader Class Initialized
INFO - 2021-01-16 04:17:29 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:29 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:29 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:29 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:29 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:29 --> Controller Class Initialized
INFO - 2021-01-16 04:17:29 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:29 --> Total execution time: 0.3751
INFO - 2021-01-16 04:17:29 --> Config Class Initialized
INFO - 2021-01-16 04:17:29 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:29 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:29 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:29 --> URI Class Initialized
INFO - 2021-01-16 04:17:29 --> Router Class Initialized
INFO - 2021-01-16 04:17:29 --> Output Class Initialized
INFO - 2021-01-16 04:17:29 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:29 --> Input Class Initialized
INFO - 2021-01-16 04:17:29 --> Language Class Initialized
INFO - 2021-01-16 04:17:29 --> Language Class Initialized
INFO - 2021-01-16 04:17:29 --> Config Class Initialized
INFO - 2021-01-16 04:17:29 --> Loader Class Initialized
INFO - 2021-01-16 04:17:29 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:29 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:29 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:29 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:29 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:29 --> Controller Class Initialized
DEBUG - 2021-01-16 04:17:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 04:17:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:17:29 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:30 --> Total execution time: 0.5067
INFO - 2021-01-16 04:17:30 --> Config Class Initialized
INFO - 2021-01-16 04:17:30 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:30 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:30 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:30 --> URI Class Initialized
INFO - 2021-01-16 04:17:30 --> Router Class Initialized
INFO - 2021-01-16 04:17:30 --> Output Class Initialized
INFO - 2021-01-16 04:17:30 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:30 --> Input Class Initialized
INFO - 2021-01-16 04:17:30 --> Language Class Initialized
INFO - 2021-01-16 04:17:30 --> Language Class Initialized
INFO - 2021-01-16 04:17:30 --> Config Class Initialized
INFO - 2021-01-16 04:17:30 --> Loader Class Initialized
INFO - 2021-01-16 04:17:31 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:31 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:31 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:31 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:31 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:31 --> Controller Class Initialized
INFO - 2021-01-16 04:17:31 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:31 --> Total execution time: 0.2837
INFO - 2021-01-16 04:17:35 --> Config Class Initialized
INFO - 2021-01-16 04:17:35 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:35 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:35 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:35 --> URI Class Initialized
INFO - 2021-01-16 04:17:35 --> Router Class Initialized
INFO - 2021-01-16 04:17:35 --> Output Class Initialized
INFO - 2021-01-16 04:17:35 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:35 --> Input Class Initialized
INFO - 2021-01-16 04:17:35 --> Language Class Initialized
INFO - 2021-01-16 04:17:35 --> Language Class Initialized
INFO - 2021-01-16 04:17:35 --> Config Class Initialized
INFO - 2021-01-16 04:17:35 --> Loader Class Initialized
INFO - 2021-01-16 04:17:35 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:36 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:36 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:36 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:36 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:36 --> Controller Class Initialized
INFO - 2021-01-16 04:17:36 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:36 --> Total execution time: 0.4271
INFO - 2021-01-16 04:17:37 --> Config Class Initialized
INFO - 2021-01-16 04:17:37 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:37 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:37 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:37 --> URI Class Initialized
INFO - 2021-01-16 04:17:38 --> Router Class Initialized
INFO - 2021-01-16 04:17:38 --> Output Class Initialized
INFO - 2021-01-16 04:17:38 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:38 --> Input Class Initialized
INFO - 2021-01-16 04:17:38 --> Language Class Initialized
INFO - 2021-01-16 04:17:38 --> Language Class Initialized
INFO - 2021-01-16 04:17:38 --> Config Class Initialized
INFO - 2021-01-16 04:17:38 --> Loader Class Initialized
INFO - 2021-01-16 04:17:38 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:38 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:38 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:38 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:38 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:38 --> Controller Class Initialized
INFO - 2021-01-16 04:17:38 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:38 --> Total execution time: 0.3793
INFO - 2021-01-16 04:17:44 --> Config Class Initialized
INFO - 2021-01-16 04:17:44 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:44 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:44 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:44 --> URI Class Initialized
INFO - 2021-01-16 04:17:44 --> Router Class Initialized
INFO - 2021-01-16 04:17:44 --> Output Class Initialized
INFO - 2021-01-16 04:17:44 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:44 --> Input Class Initialized
INFO - 2021-01-16 04:17:44 --> Language Class Initialized
INFO - 2021-01-16 04:17:44 --> Language Class Initialized
INFO - 2021-01-16 04:17:44 --> Config Class Initialized
INFO - 2021-01-16 04:17:44 --> Loader Class Initialized
INFO - 2021-01-16 04:17:44 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:44 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:44 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:44 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:44 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:44 --> Controller Class Initialized
INFO - 2021-01-16 04:17:44 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:44 --> Total execution time: 0.4081
INFO - 2021-01-16 04:17:51 --> Config Class Initialized
INFO - 2021-01-16 04:17:51 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:51 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:51 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:51 --> URI Class Initialized
INFO - 2021-01-16 04:17:51 --> Router Class Initialized
INFO - 2021-01-16 04:17:51 --> Output Class Initialized
INFO - 2021-01-16 04:17:51 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:51 --> Input Class Initialized
INFO - 2021-01-16 04:17:51 --> Language Class Initialized
INFO - 2021-01-16 04:17:51 --> Language Class Initialized
INFO - 2021-01-16 04:17:51 --> Config Class Initialized
INFO - 2021-01-16 04:17:51 --> Loader Class Initialized
INFO - 2021-01-16 04:17:51 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:51 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:51 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:51 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:51 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:51 --> Controller Class Initialized
DEBUG - 2021-01-16 04:17:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:17:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:17:51 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:51 --> Total execution time: 0.3918
INFO - 2021-01-16 04:17:52 --> Config Class Initialized
INFO - 2021-01-16 04:17:52 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:52 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:52 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:52 --> URI Class Initialized
INFO - 2021-01-16 04:17:52 --> Router Class Initialized
INFO - 2021-01-16 04:17:52 --> Output Class Initialized
INFO - 2021-01-16 04:17:52 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:52 --> Input Class Initialized
INFO - 2021-01-16 04:17:52 --> Language Class Initialized
INFO - 2021-01-16 04:17:52 --> Language Class Initialized
INFO - 2021-01-16 04:17:52 --> Config Class Initialized
INFO - 2021-01-16 04:17:52 --> Loader Class Initialized
INFO - 2021-01-16 04:17:52 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:52 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:52 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:52 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:52 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:52 --> Controller Class Initialized
INFO - 2021-01-16 04:17:52 --> Helper loaded: cookie_helper
INFO - 2021-01-16 04:17:52 --> Config Class Initialized
INFO - 2021-01-16 04:17:52 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:52 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:52 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:53 --> URI Class Initialized
INFO - 2021-01-16 04:17:53 --> Router Class Initialized
INFO - 2021-01-16 04:17:53 --> Output Class Initialized
INFO - 2021-01-16 04:17:53 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:53 --> Input Class Initialized
INFO - 2021-01-16 04:17:53 --> Language Class Initialized
INFO - 2021-01-16 04:17:53 --> Language Class Initialized
INFO - 2021-01-16 04:17:53 --> Config Class Initialized
INFO - 2021-01-16 04:17:53 --> Loader Class Initialized
INFO - 2021-01-16 04:17:53 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:53 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:53 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:53 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:53 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:53 --> Controller Class Initialized
DEBUG - 2021-01-16 04:17:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-16 04:17:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:17:53 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:53 --> Total execution time: 0.3490
INFO - 2021-01-16 04:17:57 --> Config Class Initialized
INFO - 2021-01-16 04:17:57 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:57 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:57 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:57 --> URI Class Initialized
INFO - 2021-01-16 04:17:57 --> Router Class Initialized
INFO - 2021-01-16 04:17:57 --> Output Class Initialized
INFO - 2021-01-16 04:17:57 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:57 --> Input Class Initialized
INFO - 2021-01-16 04:17:57 --> Language Class Initialized
INFO - 2021-01-16 04:17:57 --> Language Class Initialized
INFO - 2021-01-16 04:17:57 --> Config Class Initialized
INFO - 2021-01-16 04:17:57 --> Loader Class Initialized
INFO - 2021-01-16 04:17:57 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:57 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:57 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:57 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:57 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:57 --> Controller Class Initialized
INFO - 2021-01-16 04:17:57 --> Helper loaded: cookie_helper
INFO - 2021-01-16 04:17:57 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:57 --> Total execution time: 0.4336
INFO - 2021-01-16 04:17:58 --> Config Class Initialized
INFO - 2021-01-16 04:17:58 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:17:58 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:17:58 --> Utf8 Class Initialized
INFO - 2021-01-16 04:17:58 --> URI Class Initialized
INFO - 2021-01-16 04:17:58 --> Router Class Initialized
INFO - 2021-01-16 04:17:58 --> Output Class Initialized
INFO - 2021-01-16 04:17:58 --> Security Class Initialized
DEBUG - 2021-01-16 04:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:17:58 --> Input Class Initialized
INFO - 2021-01-16 04:17:58 --> Language Class Initialized
INFO - 2021-01-16 04:17:58 --> Language Class Initialized
INFO - 2021-01-16 04:17:58 --> Config Class Initialized
INFO - 2021-01-16 04:17:58 --> Loader Class Initialized
INFO - 2021-01-16 04:17:58 --> Helper loaded: url_helper
INFO - 2021-01-16 04:17:58 --> Helper loaded: file_helper
INFO - 2021-01-16 04:17:58 --> Helper loaded: form_helper
INFO - 2021-01-16 04:17:58 --> Helper loaded: my_helper
INFO - 2021-01-16 04:17:58 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:17:58 --> Controller Class Initialized
DEBUG - 2021-01-16 04:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-16 04:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:17:58 --> Final output sent to browser
DEBUG - 2021-01-16 04:17:58 --> Total execution time: 0.4591
INFO - 2021-01-16 04:18:00 --> Config Class Initialized
INFO - 2021-01-16 04:18:00 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:00 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:00 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:00 --> URI Class Initialized
INFO - 2021-01-16 04:18:00 --> Router Class Initialized
INFO - 2021-01-16 04:18:00 --> Output Class Initialized
INFO - 2021-01-16 04:18:00 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:00 --> Input Class Initialized
INFO - 2021-01-16 04:18:00 --> Language Class Initialized
INFO - 2021-01-16 04:18:00 --> Language Class Initialized
INFO - 2021-01-16 04:18:00 --> Config Class Initialized
INFO - 2021-01-16 04:18:00 --> Loader Class Initialized
INFO - 2021-01-16 04:18:00 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:00 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:00 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:00 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:00 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:00 --> Controller Class Initialized
DEBUG - 2021-01-16 04:18:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:18:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:18:00 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:00 --> Total execution time: 0.3326
INFO - 2021-01-16 04:18:02 --> Config Class Initialized
INFO - 2021-01-16 04:18:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:02 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:02 --> URI Class Initialized
INFO - 2021-01-16 04:18:02 --> Router Class Initialized
INFO - 2021-01-16 04:18:02 --> Output Class Initialized
INFO - 2021-01-16 04:18:02 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:02 --> Input Class Initialized
INFO - 2021-01-16 04:18:02 --> Language Class Initialized
INFO - 2021-01-16 04:18:02 --> Language Class Initialized
INFO - 2021-01-16 04:18:02 --> Config Class Initialized
INFO - 2021-01-16 04:18:02 --> Loader Class Initialized
INFO - 2021-01-16 04:18:02 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:02 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:02 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:02 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:02 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:02 --> Controller Class Initialized
DEBUG - 2021-01-16 04:18:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-16 04:18:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:18:02 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:02 --> Total execution time: 0.3386
INFO - 2021-01-16 04:18:02 --> Config Class Initialized
INFO - 2021-01-16 04:18:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:02 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:02 --> URI Class Initialized
INFO - 2021-01-16 04:18:02 --> Router Class Initialized
INFO - 2021-01-16 04:18:02 --> Output Class Initialized
INFO - 2021-01-16 04:18:02 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:02 --> Input Class Initialized
INFO - 2021-01-16 04:18:02 --> Language Class Initialized
INFO - 2021-01-16 04:18:02 --> Language Class Initialized
INFO - 2021-01-16 04:18:02 --> Config Class Initialized
INFO - 2021-01-16 04:18:02 --> Loader Class Initialized
INFO - 2021-01-16 04:18:03 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:03 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:03 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:03 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:03 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:03 --> Controller Class Initialized
INFO - 2021-01-16 04:18:04 --> Config Class Initialized
INFO - 2021-01-16 04:18:04 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:04 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:04 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:04 --> URI Class Initialized
INFO - 2021-01-16 04:18:05 --> Router Class Initialized
INFO - 2021-01-16 04:18:05 --> Output Class Initialized
INFO - 2021-01-16 04:18:05 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:05 --> Input Class Initialized
INFO - 2021-01-16 04:18:05 --> Language Class Initialized
INFO - 2021-01-16 04:18:05 --> Language Class Initialized
INFO - 2021-01-16 04:18:05 --> Config Class Initialized
INFO - 2021-01-16 04:18:05 --> Loader Class Initialized
INFO - 2021-01-16 04:18:05 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:05 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:05 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:05 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:05 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:05 --> Controller Class Initialized
INFO - 2021-01-16 04:18:05 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:05 --> Total execution time: 0.3452
INFO - 2021-01-16 04:18:13 --> Config Class Initialized
INFO - 2021-01-16 04:18:13 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:13 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:13 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:13 --> URI Class Initialized
INFO - 2021-01-16 04:18:13 --> Router Class Initialized
INFO - 2021-01-16 04:18:13 --> Output Class Initialized
INFO - 2021-01-16 04:18:13 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:13 --> Input Class Initialized
INFO - 2021-01-16 04:18:13 --> Language Class Initialized
INFO - 2021-01-16 04:18:13 --> Language Class Initialized
INFO - 2021-01-16 04:18:13 --> Config Class Initialized
INFO - 2021-01-16 04:18:13 --> Loader Class Initialized
INFO - 2021-01-16 04:18:13 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:13 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:13 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:13 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:13 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:13 --> Controller Class Initialized
DEBUG - 2021-01-16 04:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:18:13 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:13 --> Total execution time: 0.3856
INFO - 2021-01-16 04:18:15 --> Config Class Initialized
INFO - 2021-01-16 04:18:15 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:15 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:15 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:15 --> URI Class Initialized
INFO - 2021-01-16 04:18:15 --> Router Class Initialized
INFO - 2021-01-16 04:18:15 --> Output Class Initialized
INFO - 2021-01-16 04:18:15 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:16 --> Input Class Initialized
INFO - 2021-01-16 04:18:16 --> Language Class Initialized
INFO - 2021-01-16 04:18:16 --> Language Class Initialized
INFO - 2021-01-16 04:18:16 --> Config Class Initialized
INFO - 2021-01-16 04:18:16 --> Loader Class Initialized
INFO - 2021-01-16 04:18:16 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:16 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:16 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:16 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:16 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:16 --> Controller Class Initialized
DEBUG - 2021-01-16 04:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-16 04:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:18:16 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:16 --> Total execution time: 0.3442
INFO - 2021-01-16 04:18:16 --> Config Class Initialized
INFO - 2021-01-16 04:18:16 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:16 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:16 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:16 --> URI Class Initialized
INFO - 2021-01-16 04:18:16 --> Router Class Initialized
INFO - 2021-01-16 04:18:16 --> Output Class Initialized
INFO - 2021-01-16 04:18:16 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:16 --> Input Class Initialized
INFO - 2021-01-16 04:18:16 --> Language Class Initialized
INFO - 2021-01-16 04:18:16 --> Language Class Initialized
INFO - 2021-01-16 04:18:16 --> Config Class Initialized
INFO - 2021-01-16 04:18:16 --> Loader Class Initialized
INFO - 2021-01-16 04:18:16 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:16 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:16 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:16 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:16 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:16 --> Controller Class Initialized
INFO - 2021-01-16 04:18:18 --> Config Class Initialized
INFO - 2021-01-16 04:18:18 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:18 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:18 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:18 --> URI Class Initialized
INFO - 2021-01-16 04:18:18 --> Router Class Initialized
INFO - 2021-01-16 04:18:18 --> Output Class Initialized
INFO - 2021-01-16 04:18:18 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:18 --> Input Class Initialized
INFO - 2021-01-16 04:18:18 --> Language Class Initialized
INFO - 2021-01-16 04:18:18 --> Language Class Initialized
INFO - 2021-01-16 04:18:18 --> Config Class Initialized
INFO - 2021-01-16 04:18:18 --> Loader Class Initialized
INFO - 2021-01-16 04:18:18 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:19 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:19 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:19 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:19 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:19 --> Controller Class Initialized
DEBUG - 2021-01-16 04:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:18:19 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:19 --> Total execution time: 0.4109
INFO - 2021-01-16 04:18:21 --> Config Class Initialized
INFO - 2021-01-16 04:18:21 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:21 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:21 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:21 --> URI Class Initialized
INFO - 2021-01-16 04:18:21 --> Router Class Initialized
INFO - 2021-01-16 04:18:22 --> Output Class Initialized
INFO - 2021-01-16 04:18:22 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:22 --> Input Class Initialized
INFO - 2021-01-16 04:18:22 --> Language Class Initialized
INFO - 2021-01-16 04:18:22 --> Language Class Initialized
INFO - 2021-01-16 04:18:22 --> Config Class Initialized
INFO - 2021-01-16 04:18:22 --> Loader Class Initialized
INFO - 2021-01-16 04:18:22 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:22 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:22 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:22 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:22 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:22 --> Controller Class Initialized
DEBUG - 2021-01-16 04:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 04:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:18:22 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:22 --> Total execution time: 0.3307
INFO - 2021-01-16 04:18:24 --> Config Class Initialized
INFO - 2021-01-16 04:18:24 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:24 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:24 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:24 --> URI Class Initialized
INFO - 2021-01-16 04:18:24 --> Router Class Initialized
INFO - 2021-01-16 04:18:24 --> Output Class Initialized
INFO - 2021-01-16 04:18:24 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:24 --> Input Class Initialized
INFO - 2021-01-16 04:18:24 --> Language Class Initialized
INFO - 2021-01-16 04:18:24 --> Language Class Initialized
INFO - 2021-01-16 04:18:24 --> Config Class Initialized
INFO - 2021-01-16 04:18:24 --> Loader Class Initialized
INFO - 2021-01-16 04:18:24 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:24 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:24 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:24 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:24 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:24 --> Controller Class Initialized
DEBUG - 2021-01-16 04:18:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:18:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:18:24 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:24 --> Total execution time: 0.3960
INFO - 2021-01-16 04:18:25 --> Config Class Initialized
INFO - 2021-01-16 04:18:25 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:25 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:25 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:25 --> URI Class Initialized
INFO - 2021-01-16 04:18:25 --> Router Class Initialized
INFO - 2021-01-16 04:18:25 --> Output Class Initialized
INFO - 2021-01-16 04:18:25 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:25 --> Input Class Initialized
INFO - 2021-01-16 04:18:25 --> Language Class Initialized
INFO - 2021-01-16 04:18:25 --> Language Class Initialized
INFO - 2021-01-16 04:18:25 --> Config Class Initialized
INFO - 2021-01-16 04:18:25 --> Loader Class Initialized
INFO - 2021-01-16 04:18:25 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:25 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:25 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:25 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:25 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:25 --> Controller Class Initialized
DEBUG - 2021-01-16 04:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-16 04:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:18:25 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:25 --> Total execution time: 0.3619
INFO - 2021-01-16 04:18:25 --> Config Class Initialized
INFO - 2021-01-16 04:18:25 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:25 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:25 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:25 --> URI Class Initialized
INFO - 2021-01-16 04:18:26 --> Router Class Initialized
INFO - 2021-01-16 04:18:26 --> Output Class Initialized
INFO - 2021-01-16 04:18:26 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:26 --> Input Class Initialized
INFO - 2021-01-16 04:18:26 --> Language Class Initialized
INFO - 2021-01-16 04:18:26 --> Language Class Initialized
INFO - 2021-01-16 04:18:26 --> Config Class Initialized
INFO - 2021-01-16 04:18:26 --> Loader Class Initialized
INFO - 2021-01-16 04:18:26 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:26 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:26 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:26 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:26 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:26 --> Controller Class Initialized
INFO - 2021-01-16 04:18:26 --> Config Class Initialized
INFO - 2021-01-16 04:18:26 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:26 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:26 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:26 --> URI Class Initialized
INFO - 2021-01-16 04:18:26 --> Router Class Initialized
INFO - 2021-01-16 04:18:26 --> Output Class Initialized
INFO - 2021-01-16 04:18:26 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:26 --> Input Class Initialized
INFO - 2021-01-16 04:18:26 --> Language Class Initialized
INFO - 2021-01-16 04:18:27 --> Language Class Initialized
INFO - 2021-01-16 04:18:27 --> Config Class Initialized
INFO - 2021-01-16 04:18:27 --> Loader Class Initialized
INFO - 2021-01-16 04:18:27 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:27 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:27 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:27 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:27 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:27 --> Controller Class Initialized
INFO - 2021-01-16 04:18:27 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:27 --> Total execution time: 0.3114
INFO - 2021-01-16 04:18:41 --> Config Class Initialized
INFO - 2021-01-16 04:18:41 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:41 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:41 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:41 --> URI Class Initialized
INFO - 2021-01-16 04:18:41 --> Router Class Initialized
INFO - 2021-01-16 04:18:41 --> Output Class Initialized
INFO - 2021-01-16 04:18:41 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:41 --> Input Class Initialized
INFO - 2021-01-16 04:18:41 --> Language Class Initialized
INFO - 2021-01-16 04:18:41 --> Language Class Initialized
INFO - 2021-01-16 04:18:41 --> Config Class Initialized
INFO - 2021-01-16 04:18:41 --> Loader Class Initialized
INFO - 2021-01-16 04:18:41 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:41 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:41 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:42 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:42 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:42 --> Controller Class Initialized
INFO - 2021-01-16 04:18:42 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:42 --> Total execution time: 0.4159
INFO - 2021-01-16 04:18:42 --> Config Class Initialized
INFO - 2021-01-16 04:18:42 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:42 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:42 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:42 --> URI Class Initialized
INFO - 2021-01-16 04:18:42 --> Router Class Initialized
INFO - 2021-01-16 04:18:42 --> Output Class Initialized
INFO - 2021-01-16 04:18:42 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:42 --> Input Class Initialized
INFO - 2021-01-16 04:18:42 --> Language Class Initialized
INFO - 2021-01-16 04:18:42 --> Language Class Initialized
INFO - 2021-01-16 04:18:42 --> Config Class Initialized
INFO - 2021-01-16 04:18:42 --> Loader Class Initialized
INFO - 2021-01-16 04:18:42 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:42 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:42 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:42 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:42 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:42 --> Controller Class Initialized
INFO - 2021-01-16 04:18:43 --> Config Class Initialized
INFO - 2021-01-16 04:18:43 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:43 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:43 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:43 --> URI Class Initialized
INFO - 2021-01-16 04:18:43 --> Router Class Initialized
INFO - 2021-01-16 04:18:43 --> Output Class Initialized
INFO - 2021-01-16 04:18:43 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:43 --> Input Class Initialized
INFO - 2021-01-16 04:18:43 --> Language Class Initialized
INFO - 2021-01-16 04:18:43 --> Language Class Initialized
INFO - 2021-01-16 04:18:43 --> Config Class Initialized
INFO - 2021-01-16 04:18:43 --> Loader Class Initialized
INFO - 2021-01-16 04:18:43 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:43 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:43 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:43 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:43 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:43 --> Controller Class Initialized
INFO - 2021-01-16 04:18:43 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:43 --> Total execution time: 0.3339
INFO - 2021-01-16 04:18:47 --> Config Class Initialized
INFO - 2021-01-16 04:18:47 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:48 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:48 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:48 --> URI Class Initialized
INFO - 2021-01-16 04:18:48 --> Router Class Initialized
INFO - 2021-01-16 04:18:48 --> Output Class Initialized
INFO - 2021-01-16 04:18:48 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:48 --> Input Class Initialized
INFO - 2021-01-16 04:18:48 --> Language Class Initialized
INFO - 2021-01-16 04:18:48 --> Language Class Initialized
INFO - 2021-01-16 04:18:48 --> Config Class Initialized
INFO - 2021-01-16 04:18:48 --> Loader Class Initialized
INFO - 2021-01-16 04:18:48 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:48 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:48 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:48 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:48 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:48 --> Controller Class Initialized
INFO - 2021-01-16 04:18:48 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:48 --> Total execution time: 0.4984
INFO - 2021-01-16 04:18:50 --> Config Class Initialized
INFO - 2021-01-16 04:18:50 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:50 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:50 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:50 --> URI Class Initialized
INFO - 2021-01-16 04:18:50 --> Router Class Initialized
INFO - 2021-01-16 04:18:50 --> Output Class Initialized
INFO - 2021-01-16 04:18:50 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:50 --> Input Class Initialized
INFO - 2021-01-16 04:18:50 --> Language Class Initialized
INFO - 2021-01-16 04:18:50 --> Language Class Initialized
INFO - 2021-01-16 04:18:50 --> Config Class Initialized
INFO - 2021-01-16 04:18:50 --> Loader Class Initialized
INFO - 2021-01-16 04:18:50 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:50 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:50 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:50 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:50 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:50 --> Controller Class Initialized
INFO - 2021-01-16 04:18:50 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:50 --> Total execution time: 0.3128
INFO - 2021-01-16 04:18:54 --> Config Class Initialized
INFO - 2021-01-16 04:18:54 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:54 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:54 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:54 --> URI Class Initialized
INFO - 2021-01-16 04:18:54 --> Router Class Initialized
INFO - 2021-01-16 04:18:54 --> Output Class Initialized
INFO - 2021-01-16 04:18:54 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:54 --> Input Class Initialized
INFO - 2021-01-16 04:18:54 --> Language Class Initialized
INFO - 2021-01-16 04:18:54 --> Language Class Initialized
INFO - 2021-01-16 04:18:54 --> Config Class Initialized
INFO - 2021-01-16 04:18:54 --> Loader Class Initialized
INFO - 2021-01-16 04:18:54 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:54 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:54 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:54 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:54 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:54 --> Controller Class Initialized
INFO - 2021-01-16 04:18:55 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:55 --> Total execution time: 0.5363
INFO - 2021-01-16 04:18:56 --> Config Class Initialized
INFO - 2021-01-16 04:18:56 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:18:56 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:18:56 --> Utf8 Class Initialized
INFO - 2021-01-16 04:18:56 --> URI Class Initialized
INFO - 2021-01-16 04:18:56 --> Router Class Initialized
INFO - 2021-01-16 04:18:56 --> Output Class Initialized
INFO - 2021-01-16 04:18:56 --> Security Class Initialized
DEBUG - 2021-01-16 04:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:18:56 --> Input Class Initialized
INFO - 2021-01-16 04:18:56 --> Language Class Initialized
INFO - 2021-01-16 04:18:56 --> Language Class Initialized
INFO - 2021-01-16 04:18:56 --> Config Class Initialized
INFO - 2021-01-16 04:18:56 --> Loader Class Initialized
INFO - 2021-01-16 04:18:56 --> Helper loaded: url_helper
INFO - 2021-01-16 04:18:56 --> Helper loaded: file_helper
INFO - 2021-01-16 04:18:56 --> Helper loaded: form_helper
INFO - 2021-01-16 04:18:56 --> Helper loaded: my_helper
INFO - 2021-01-16 04:18:56 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:18:57 --> Controller Class Initialized
INFO - 2021-01-16 04:18:57 --> Final output sent to browser
DEBUG - 2021-01-16 04:18:57 --> Total execution time: 0.3113
INFO - 2021-01-16 04:19:01 --> Config Class Initialized
INFO - 2021-01-16 04:19:01 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:01 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:01 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:01 --> URI Class Initialized
INFO - 2021-01-16 04:19:01 --> Router Class Initialized
INFO - 2021-01-16 04:19:01 --> Output Class Initialized
INFO - 2021-01-16 04:19:01 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:01 --> Input Class Initialized
INFO - 2021-01-16 04:19:01 --> Language Class Initialized
INFO - 2021-01-16 04:19:01 --> Language Class Initialized
INFO - 2021-01-16 04:19:01 --> Config Class Initialized
INFO - 2021-01-16 04:19:01 --> Loader Class Initialized
INFO - 2021-01-16 04:19:01 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:01 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:01 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:01 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:01 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:01 --> Controller Class Initialized
INFO - 2021-01-16 04:19:01 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:01 --> Total execution time: 0.5236
INFO - 2021-01-16 04:19:06 --> Config Class Initialized
INFO - 2021-01-16 04:19:06 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:06 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:06 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:06 --> URI Class Initialized
INFO - 2021-01-16 04:19:06 --> Router Class Initialized
INFO - 2021-01-16 04:19:06 --> Output Class Initialized
INFO - 2021-01-16 04:19:06 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:06 --> Input Class Initialized
INFO - 2021-01-16 04:19:06 --> Language Class Initialized
INFO - 2021-01-16 04:19:06 --> Language Class Initialized
INFO - 2021-01-16 04:19:06 --> Config Class Initialized
INFO - 2021-01-16 04:19:06 --> Loader Class Initialized
INFO - 2021-01-16 04:19:06 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:06 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:06 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:06 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:06 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:06 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:19:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:06 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:06 --> Total execution time: 0.3846
INFO - 2021-01-16 04:19:07 --> Config Class Initialized
INFO - 2021-01-16 04:19:07 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:07 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:07 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:07 --> URI Class Initialized
INFO - 2021-01-16 04:19:07 --> Router Class Initialized
INFO - 2021-01-16 04:19:07 --> Output Class Initialized
INFO - 2021-01-16 04:19:07 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:07 --> Input Class Initialized
INFO - 2021-01-16 04:19:07 --> Language Class Initialized
INFO - 2021-01-16 04:19:07 --> Language Class Initialized
INFO - 2021-01-16 04:19:07 --> Config Class Initialized
INFO - 2021-01-16 04:19:07 --> Loader Class Initialized
INFO - 2021-01-16 04:19:08 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:08 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:08 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:08 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:08 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:08 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 04:19:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:08 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:08 --> Total execution time: 0.3557
INFO - 2021-01-16 04:19:09 --> Config Class Initialized
INFO - 2021-01-16 04:19:09 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:09 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:09 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:09 --> URI Class Initialized
INFO - 2021-01-16 04:19:09 --> Router Class Initialized
INFO - 2021-01-16 04:19:09 --> Output Class Initialized
INFO - 2021-01-16 04:19:09 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:09 --> Input Class Initialized
INFO - 2021-01-16 04:19:09 --> Language Class Initialized
INFO - 2021-01-16 04:19:09 --> Language Class Initialized
INFO - 2021-01-16 04:19:09 --> Config Class Initialized
INFO - 2021-01-16 04:19:09 --> Loader Class Initialized
INFO - 2021-01-16 04:19:09 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:09 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:09 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:09 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:09 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:09 --> Controller Class Initialized
INFO - 2021-01-16 04:19:09 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:09 --> Total execution time: 0.3513
INFO - 2021-01-16 04:19:17 --> Config Class Initialized
INFO - 2021-01-16 04:19:17 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:17 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:17 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:17 --> URI Class Initialized
INFO - 2021-01-16 04:19:17 --> Router Class Initialized
INFO - 2021-01-16 04:19:17 --> Output Class Initialized
INFO - 2021-01-16 04:19:17 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:17 --> Input Class Initialized
INFO - 2021-01-16 04:19:17 --> Language Class Initialized
INFO - 2021-01-16 04:19:17 --> Language Class Initialized
INFO - 2021-01-16 04:19:17 --> Config Class Initialized
INFO - 2021-01-16 04:19:17 --> Loader Class Initialized
INFO - 2021-01-16 04:19:17 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:17 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:17 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:17 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:17 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:17 --> Controller Class Initialized
INFO - 2021-01-16 04:19:17 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:17 --> Total execution time: 0.3488
INFO - 2021-01-16 04:19:17 --> Config Class Initialized
INFO - 2021-01-16 04:19:18 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:18 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:18 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:18 --> URI Class Initialized
INFO - 2021-01-16 04:19:18 --> Router Class Initialized
INFO - 2021-01-16 04:19:18 --> Output Class Initialized
INFO - 2021-01-16 04:19:18 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:18 --> Input Class Initialized
INFO - 2021-01-16 04:19:18 --> Language Class Initialized
INFO - 2021-01-16 04:19:18 --> Language Class Initialized
INFO - 2021-01-16 04:19:18 --> Config Class Initialized
INFO - 2021-01-16 04:19:18 --> Loader Class Initialized
INFO - 2021-01-16 04:19:18 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:18 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:18 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:18 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:18 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:18 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 04:19:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:18 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:18 --> Total execution time: 0.5011
INFO - 2021-01-16 04:19:19 --> Config Class Initialized
INFO - 2021-01-16 04:19:19 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:19 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:19 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:19 --> URI Class Initialized
INFO - 2021-01-16 04:19:19 --> Router Class Initialized
INFO - 2021-01-16 04:19:19 --> Output Class Initialized
INFO - 2021-01-16 04:19:19 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:19 --> Input Class Initialized
INFO - 2021-01-16 04:19:19 --> Language Class Initialized
INFO - 2021-01-16 04:19:19 --> Language Class Initialized
INFO - 2021-01-16 04:19:19 --> Config Class Initialized
INFO - 2021-01-16 04:19:19 --> Loader Class Initialized
INFO - 2021-01-16 04:19:19 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:19 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:19 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:19 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:19 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:19 --> Controller Class Initialized
INFO - 2021-01-16 04:19:19 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:19 --> Total execution time: 0.3547
INFO - 2021-01-16 04:19:31 --> Config Class Initialized
INFO - 2021-01-16 04:19:31 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:31 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:31 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:31 --> URI Class Initialized
INFO - 2021-01-16 04:19:31 --> Router Class Initialized
INFO - 2021-01-16 04:19:31 --> Output Class Initialized
INFO - 2021-01-16 04:19:31 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:31 --> Input Class Initialized
INFO - 2021-01-16 04:19:31 --> Language Class Initialized
INFO - 2021-01-16 04:19:31 --> Language Class Initialized
INFO - 2021-01-16 04:19:31 --> Config Class Initialized
INFO - 2021-01-16 04:19:31 --> Loader Class Initialized
INFO - 2021-01-16 04:19:31 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:31 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:31 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:31 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:31 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:32 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:32 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:32 --> Total execution time: 0.4108
INFO - 2021-01-16 04:19:34 --> Config Class Initialized
INFO - 2021-01-16 04:19:34 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:34 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:34 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:34 --> URI Class Initialized
INFO - 2021-01-16 04:19:34 --> Router Class Initialized
INFO - 2021-01-16 04:19:34 --> Output Class Initialized
INFO - 2021-01-16 04:19:34 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:34 --> Input Class Initialized
INFO - 2021-01-16 04:19:34 --> Language Class Initialized
INFO - 2021-01-16 04:19:34 --> Language Class Initialized
INFO - 2021-01-16 04:19:34 --> Config Class Initialized
INFO - 2021-01-16 04:19:34 --> Loader Class Initialized
INFO - 2021-01-16 04:19:34 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:34 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:34 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:34 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:34 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:34 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-16 04:19:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:34 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:34 --> Total execution time: 0.3696
INFO - 2021-01-16 04:19:34 --> Config Class Initialized
INFO - 2021-01-16 04:19:34 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:34 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:34 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:34 --> URI Class Initialized
INFO - 2021-01-16 04:19:34 --> Router Class Initialized
INFO - 2021-01-16 04:19:34 --> Output Class Initialized
INFO - 2021-01-16 04:19:34 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:34 --> Input Class Initialized
INFO - 2021-01-16 04:19:34 --> Language Class Initialized
INFO - 2021-01-16 04:19:34 --> Language Class Initialized
INFO - 2021-01-16 04:19:34 --> Config Class Initialized
INFO - 2021-01-16 04:19:34 --> Loader Class Initialized
INFO - 2021-01-16 04:19:34 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:34 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:34 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:34 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:34 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:34 --> Controller Class Initialized
INFO - 2021-01-16 04:19:36 --> Config Class Initialized
INFO - 2021-01-16 04:19:36 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:36 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:36 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:36 --> URI Class Initialized
INFO - 2021-01-16 04:19:36 --> Router Class Initialized
INFO - 2021-01-16 04:19:36 --> Output Class Initialized
INFO - 2021-01-16 04:19:36 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:36 --> Input Class Initialized
INFO - 2021-01-16 04:19:36 --> Language Class Initialized
INFO - 2021-01-16 04:19:36 --> Language Class Initialized
INFO - 2021-01-16 04:19:36 --> Config Class Initialized
INFO - 2021-01-16 04:19:36 --> Loader Class Initialized
INFO - 2021-01-16 04:19:36 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:36 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:36 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:36 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:37 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:37 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:37 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:37 --> Total execution time: 0.4111
INFO - 2021-01-16 04:19:39 --> Config Class Initialized
INFO - 2021-01-16 04:19:39 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:39 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:39 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:39 --> URI Class Initialized
INFO - 2021-01-16 04:19:39 --> Router Class Initialized
INFO - 2021-01-16 04:19:39 --> Output Class Initialized
INFO - 2021-01-16 04:19:39 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:39 --> Input Class Initialized
INFO - 2021-01-16 04:19:39 --> Language Class Initialized
INFO - 2021-01-16 04:19:39 --> Language Class Initialized
INFO - 2021-01-16 04:19:39 --> Config Class Initialized
INFO - 2021-01-16 04:19:39 --> Loader Class Initialized
INFO - 2021-01-16 04:19:39 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:39 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:39 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:39 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:39 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:39 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 04:19:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:39 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:39 --> Total execution time: 0.3425
INFO - 2021-01-16 04:19:41 --> Config Class Initialized
INFO - 2021-01-16 04:19:41 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:41 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:41 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:41 --> URI Class Initialized
INFO - 2021-01-16 04:19:41 --> Router Class Initialized
INFO - 2021-01-16 04:19:41 --> Output Class Initialized
INFO - 2021-01-16 04:19:41 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:41 --> Input Class Initialized
INFO - 2021-01-16 04:19:41 --> Language Class Initialized
INFO - 2021-01-16 04:19:41 --> Language Class Initialized
INFO - 2021-01-16 04:19:41 --> Config Class Initialized
INFO - 2021-01-16 04:19:41 --> Loader Class Initialized
INFO - 2021-01-16 04:19:41 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:41 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:41 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:41 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:41 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:41 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-16 04:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:41 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:41 --> Total execution time: 0.3901
INFO - 2021-01-16 04:19:42 --> Config Class Initialized
INFO - 2021-01-16 04:19:42 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:42 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:42 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:42 --> URI Class Initialized
INFO - 2021-01-16 04:19:42 --> Router Class Initialized
INFO - 2021-01-16 04:19:42 --> Output Class Initialized
INFO - 2021-01-16 04:19:42 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:42 --> Input Class Initialized
INFO - 2021-01-16 04:19:42 --> Language Class Initialized
INFO - 2021-01-16 04:19:42 --> Language Class Initialized
INFO - 2021-01-16 04:19:42 --> Config Class Initialized
INFO - 2021-01-16 04:19:42 --> Loader Class Initialized
INFO - 2021-01-16 04:19:42 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:42 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:42 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:42 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:42 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:42 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 04:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:42 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:42 --> Total execution time: 0.3807
INFO - 2021-01-16 04:19:44 --> Config Class Initialized
INFO - 2021-01-16 04:19:44 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:44 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:44 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:44 --> URI Class Initialized
INFO - 2021-01-16 04:19:44 --> Router Class Initialized
INFO - 2021-01-16 04:19:44 --> Output Class Initialized
INFO - 2021-01-16 04:19:44 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:44 --> Input Class Initialized
INFO - 2021-01-16 04:19:44 --> Language Class Initialized
INFO - 2021-01-16 04:19:44 --> Language Class Initialized
INFO - 2021-01-16 04:19:44 --> Config Class Initialized
INFO - 2021-01-16 04:19:44 --> Loader Class Initialized
INFO - 2021-01-16 04:19:44 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:44 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:44 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:44 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:44 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:44 --> Controller Class Initialized
INFO - 2021-01-16 04:19:44 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:44 --> Total execution time: 0.3584
INFO - 2021-01-16 04:19:51 --> Config Class Initialized
INFO - 2021-01-16 04:19:51 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:51 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:51 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:51 --> URI Class Initialized
INFO - 2021-01-16 04:19:51 --> Router Class Initialized
INFO - 2021-01-16 04:19:51 --> Output Class Initialized
INFO - 2021-01-16 04:19:51 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:51 --> Input Class Initialized
INFO - 2021-01-16 04:19:51 --> Language Class Initialized
INFO - 2021-01-16 04:19:51 --> Language Class Initialized
INFO - 2021-01-16 04:19:51 --> Config Class Initialized
INFO - 2021-01-16 04:19:51 --> Loader Class Initialized
INFO - 2021-01-16 04:19:51 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:51 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:51 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:51 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:51 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:51 --> Controller Class Initialized
INFO - 2021-01-16 04:19:51 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:51 --> Total execution time: 0.3886
INFO - 2021-01-16 04:19:51 --> Config Class Initialized
INFO - 2021-01-16 04:19:51 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:51 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:51 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:51 --> URI Class Initialized
INFO - 2021-01-16 04:19:51 --> Router Class Initialized
INFO - 2021-01-16 04:19:51 --> Output Class Initialized
INFO - 2021-01-16 04:19:51 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:51 --> Input Class Initialized
INFO - 2021-01-16 04:19:51 --> Language Class Initialized
INFO - 2021-01-16 04:19:51 --> Language Class Initialized
INFO - 2021-01-16 04:19:51 --> Config Class Initialized
INFO - 2021-01-16 04:19:51 --> Loader Class Initialized
INFO - 2021-01-16 04:19:51 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:52 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:52 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:52 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:52 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:52 --> Controller Class Initialized
DEBUG - 2021-01-16 04:19:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-16 04:19:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-16 04:19:52 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:52 --> Total execution time: 0.5259
INFO - 2021-01-16 04:19:53 --> Config Class Initialized
INFO - 2021-01-16 04:19:53 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:53 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:53 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:53 --> URI Class Initialized
INFO - 2021-01-16 04:19:53 --> Router Class Initialized
INFO - 2021-01-16 04:19:53 --> Output Class Initialized
INFO - 2021-01-16 04:19:53 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:53 --> Input Class Initialized
INFO - 2021-01-16 04:19:53 --> Language Class Initialized
INFO - 2021-01-16 04:19:53 --> Language Class Initialized
INFO - 2021-01-16 04:19:53 --> Config Class Initialized
INFO - 2021-01-16 04:19:53 --> Loader Class Initialized
INFO - 2021-01-16 04:19:53 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:53 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:53 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:53 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:53 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:53 --> Controller Class Initialized
INFO - 2021-01-16 04:19:53 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:53 --> Total execution time: 0.3112
INFO - 2021-01-16 04:19:57 --> Config Class Initialized
INFO - 2021-01-16 04:19:57 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:57 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:57 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:57 --> URI Class Initialized
INFO - 2021-01-16 04:19:57 --> Router Class Initialized
INFO - 2021-01-16 04:19:57 --> Output Class Initialized
INFO - 2021-01-16 04:19:57 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:57 --> Input Class Initialized
INFO - 2021-01-16 04:19:57 --> Language Class Initialized
INFO - 2021-01-16 04:19:57 --> Language Class Initialized
INFO - 2021-01-16 04:19:57 --> Config Class Initialized
INFO - 2021-01-16 04:19:57 --> Loader Class Initialized
INFO - 2021-01-16 04:19:57 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:57 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:57 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:57 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:57 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:57 --> Controller Class Initialized
INFO - 2021-01-16 04:19:57 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:57 --> Total execution time: 0.4399
INFO - 2021-01-16 04:19:59 --> Config Class Initialized
INFO - 2021-01-16 04:19:59 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:19:59 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:19:59 --> Utf8 Class Initialized
INFO - 2021-01-16 04:19:59 --> URI Class Initialized
INFO - 2021-01-16 04:19:59 --> Router Class Initialized
INFO - 2021-01-16 04:19:59 --> Output Class Initialized
INFO - 2021-01-16 04:19:59 --> Security Class Initialized
DEBUG - 2021-01-16 04:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:19:59 --> Input Class Initialized
INFO - 2021-01-16 04:19:59 --> Language Class Initialized
INFO - 2021-01-16 04:19:59 --> Language Class Initialized
INFO - 2021-01-16 04:19:59 --> Config Class Initialized
INFO - 2021-01-16 04:19:59 --> Loader Class Initialized
INFO - 2021-01-16 04:19:59 --> Helper loaded: url_helper
INFO - 2021-01-16 04:19:59 --> Helper loaded: file_helper
INFO - 2021-01-16 04:19:59 --> Helper loaded: form_helper
INFO - 2021-01-16 04:19:59 --> Helper loaded: my_helper
INFO - 2021-01-16 04:19:59 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:19:59 --> Controller Class Initialized
INFO - 2021-01-16 04:19:59 --> Final output sent to browser
DEBUG - 2021-01-16 04:19:59 --> Total execution time: 0.3536
INFO - 2021-01-16 04:20:02 --> Config Class Initialized
INFO - 2021-01-16 04:20:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:20:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:20:02 --> Utf8 Class Initialized
INFO - 2021-01-16 04:20:02 --> URI Class Initialized
INFO - 2021-01-16 04:20:02 --> Router Class Initialized
INFO - 2021-01-16 04:20:02 --> Output Class Initialized
INFO - 2021-01-16 04:20:02 --> Security Class Initialized
DEBUG - 2021-01-16 04:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:20:02 --> Input Class Initialized
INFO - 2021-01-16 04:20:02 --> Language Class Initialized
INFO - 2021-01-16 04:20:02 --> Language Class Initialized
INFO - 2021-01-16 04:20:02 --> Config Class Initialized
INFO - 2021-01-16 04:20:02 --> Loader Class Initialized
INFO - 2021-01-16 04:20:02 --> Helper loaded: url_helper
INFO - 2021-01-16 04:20:02 --> Helper loaded: file_helper
INFO - 2021-01-16 04:20:02 --> Helper loaded: form_helper
INFO - 2021-01-16 04:20:02 --> Helper loaded: my_helper
INFO - 2021-01-16 04:20:02 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:20:02 --> Controller Class Initialized
INFO - 2021-01-16 04:20:02 --> Final output sent to browser
DEBUG - 2021-01-16 04:20:02 --> Total execution time: 0.4252
INFO - 2021-01-16 04:20:07 --> Config Class Initialized
INFO - 2021-01-16 04:20:07 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:20:07 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:20:07 --> Utf8 Class Initialized
INFO - 2021-01-16 04:20:07 --> URI Class Initialized
INFO - 2021-01-16 04:20:07 --> Router Class Initialized
INFO - 2021-01-16 04:20:07 --> Output Class Initialized
INFO - 2021-01-16 04:20:07 --> Security Class Initialized
DEBUG - 2021-01-16 04:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:20:07 --> Input Class Initialized
INFO - 2021-01-16 04:20:07 --> Language Class Initialized
INFO - 2021-01-16 04:20:07 --> Language Class Initialized
INFO - 2021-01-16 04:20:07 --> Config Class Initialized
INFO - 2021-01-16 04:20:07 --> Loader Class Initialized
INFO - 2021-01-16 04:20:07 --> Helper loaded: url_helper
INFO - 2021-01-16 04:20:07 --> Helper loaded: file_helper
INFO - 2021-01-16 04:20:07 --> Helper loaded: form_helper
INFO - 2021-01-16 04:20:07 --> Helper loaded: my_helper
INFO - 2021-01-16 04:20:07 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:20:07 --> Controller Class Initialized
DEBUG - 2021-01-16 04:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-16 04:20:07 --> Final output sent to browser
DEBUG - 2021-01-16 04:20:07 --> Total execution time: 0.3430
INFO - 2021-01-16 04:29:24 --> Config Class Initialized
INFO - 2021-01-16 04:29:24 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:29:24 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:29:24 --> Utf8 Class Initialized
INFO - 2021-01-16 04:29:24 --> URI Class Initialized
INFO - 2021-01-16 04:29:24 --> Router Class Initialized
INFO - 2021-01-16 04:29:24 --> Output Class Initialized
INFO - 2021-01-16 04:29:24 --> Security Class Initialized
DEBUG - 2021-01-16 04:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:29:24 --> Input Class Initialized
INFO - 2021-01-16 04:29:24 --> Language Class Initialized
INFO - 2021-01-16 04:29:24 --> Language Class Initialized
INFO - 2021-01-16 04:29:24 --> Config Class Initialized
INFO - 2021-01-16 04:29:24 --> Loader Class Initialized
INFO - 2021-01-16 04:29:24 --> Helper loaded: url_helper
INFO - 2021-01-16 04:29:24 --> Helper loaded: file_helper
INFO - 2021-01-16 04:29:24 --> Helper loaded: form_helper
INFO - 2021-01-16 04:29:24 --> Helper loaded: my_helper
INFO - 2021-01-16 04:29:24 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:29:24 --> Controller Class Initialized
DEBUG - 2021-01-16 04:29:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:29:24 --> Final output sent to browser
DEBUG - 2021-01-16 04:29:24 --> Total execution time: 0.3648
INFO - 2021-01-16 04:30:20 --> Config Class Initialized
INFO - 2021-01-16 04:30:20 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:30:20 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:30:20 --> Utf8 Class Initialized
INFO - 2021-01-16 04:30:20 --> URI Class Initialized
INFO - 2021-01-16 04:30:20 --> Router Class Initialized
INFO - 2021-01-16 04:30:20 --> Output Class Initialized
INFO - 2021-01-16 04:30:20 --> Security Class Initialized
DEBUG - 2021-01-16 04:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:30:20 --> Input Class Initialized
INFO - 2021-01-16 04:30:20 --> Language Class Initialized
INFO - 2021-01-16 04:30:20 --> Language Class Initialized
INFO - 2021-01-16 04:30:20 --> Config Class Initialized
INFO - 2021-01-16 04:30:20 --> Loader Class Initialized
INFO - 2021-01-16 04:30:20 --> Helper loaded: url_helper
INFO - 2021-01-16 04:30:20 --> Helper loaded: file_helper
INFO - 2021-01-16 04:30:20 --> Helper loaded: form_helper
INFO - 2021-01-16 04:30:20 --> Helper loaded: my_helper
INFO - 2021-01-16 04:30:20 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:30:21 --> Controller Class Initialized
DEBUG - 2021-01-16 04:30:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:30:21 --> Final output sent to browser
DEBUG - 2021-01-16 04:30:21 --> Total execution time: 0.4074
INFO - 2021-01-16 04:30:29 --> Config Class Initialized
INFO - 2021-01-16 04:30:29 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:30:29 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:30:29 --> Utf8 Class Initialized
INFO - 2021-01-16 04:30:29 --> URI Class Initialized
INFO - 2021-01-16 04:30:29 --> Router Class Initialized
INFO - 2021-01-16 04:30:29 --> Output Class Initialized
INFO - 2021-01-16 04:30:29 --> Security Class Initialized
DEBUG - 2021-01-16 04:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:30:29 --> Input Class Initialized
INFO - 2021-01-16 04:30:29 --> Language Class Initialized
INFO - 2021-01-16 04:30:29 --> Language Class Initialized
INFO - 2021-01-16 04:30:29 --> Config Class Initialized
INFO - 2021-01-16 04:30:29 --> Loader Class Initialized
INFO - 2021-01-16 04:30:29 --> Helper loaded: url_helper
INFO - 2021-01-16 04:30:29 --> Helper loaded: file_helper
INFO - 2021-01-16 04:30:29 --> Helper loaded: form_helper
INFO - 2021-01-16 04:30:29 --> Helper loaded: my_helper
INFO - 2021-01-16 04:30:30 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:30:30 --> Controller Class Initialized
DEBUG - 2021-01-16 04:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-16 04:30:30 --> Final output sent to browser
DEBUG - 2021-01-16 04:30:30 --> Total execution time: 0.3847
INFO - 2021-01-16 04:30:31 --> Config Class Initialized
INFO - 2021-01-16 04:30:31 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:30:31 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:30:32 --> Utf8 Class Initialized
INFO - 2021-01-16 04:30:32 --> URI Class Initialized
INFO - 2021-01-16 04:30:32 --> Router Class Initialized
INFO - 2021-01-16 04:30:32 --> Output Class Initialized
INFO - 2021-01-16 04:30:32 --> Security Class Initialized
DEBUG - 2021-01-16 04:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:30:32 --> Input Class Initialized
INFO - 2021-01-16 04:30:32 --> Language Class Initialized
INFO - 2021-01-16 04:30:32 --> Language Class Initialized
INFO - 2021-01-16 04:30:32 --> Config Class Initialized
INFO - 2021-01-16 04:30:32 --> Loader Class Initialized
INFO - 2021-01-16 04:30:32 --> Helper loaded: url_helper
INFO - 2021-01-16 04:30:32 --> Helper loaded: file_helper
INFO - 2021-01-16 04:30:32 --> Helper loaded: form_helper
INFO - 2021-01-16 04:30:32 --> Helper loaded: my_helper
INFO - 2021-01-16 04:30:32 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:30:32 --> Controller Class Initialized
DEBUG - 2021-01-16 04:30:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:30:32 --> Final output sent to browser
DEBUG - 2021-01-16 04:30:32 --> Total execution time: 0.3651
INFO - 2021-01-16 04:31:02 --> Config Class Initialized
INFO - 2021-01-16 04:31:02 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:31:02 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:31:02 --> Utf8 Class Initialized
INFO - 2021-01-16 04:31:02 --> URI Class Initialized
INFO - 2021-01-16 04:31:02 --> Router Class Initialized
INFO - 2021-01-16 04:31:02 --> Output Class Initialized
INFO - 2021-01-16 04:31:02 --> Security Class Initialized
DEBUG - 2021-01-16 04:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:31:02 --> Input Class Initialized
INFO - 2021-01-16 04:31:02 --> Language Class Initialized
INFO - 2021-01-16 04:31:02 --> Language Class Initialized
INFO - 2021-01-16 04:31:02 --> Config Class Initialized
INFO - 2021-01-16 04:31:02 --> Loader Class Initialized
INFO - 2021-01-16 04:31:02 --> Helper loaded: url_helper
INFO - 2021-01-16 04:31:02 --> Helper loaded: file_helper
INFO - 2021-01-16 04:31:02 --> Helper loaded: form_helper
INFO - 2021-01-16 04:31:02 --> Helper loaded: my_helper
INFO - 2021-01-16 04:31:02 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:31:02 --> Controller Class Initialized
DEBUG - 2021-01-16 04:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-16 04:31:02 --> Final output sent to browser
DEBUG - 2021-01-16 04:31:02 --> Total execution time: 0.3580
INFO - 2021-01-16 04:31:08 --> Config Class Initialized
INFO - 2021-01-16 04:31:08 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:31:08 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:31:08 --> Utf8 Class Initialized
INFO - 2021-01-16 04:31:08 --> URI Class Initialized
INFO - 2021-01-16 04:31:08 --> Router Class Initialized
INFO - 2021-01-16 04:31:08 --> Output Class Initialized
INFO - 2021-01-16 04:31:08 --> Security Class Initialized
DEBUG - 2021-01-16 04:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:31:08 --> Input Class Initialized
INFO - 2021-01-16 04:31:08 --> Language Class Initialized
INFO - 2021-01-16 04:31:08 --> Language Class Initialized
INFO - 2021-01-16 04:31:08 --> Config Class Initialized
INFO - 2021-01-16 04:31:08 --> Loader Class Initialized
INFO - 2021-01-16 04:31:08 --> Helper loaded: url_helper
INFO - 2021-01-16 04:31:08 --> Helper loaded: file_helper
INFO - 2021-01-16 04:31:08 --> Helper loaded: form_helper
INFO - 2021-01-16 04:31:08 --> Helper loaded: my_helper
INFO - 2021-01-16 04:31:08 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:31:08 --> Controller Class Initialized
DEBUG - 2021-01-16 04:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:31:08 --> Final output sent to browser
DEBUG - 2021-01-16 04:31:08 --> Total execution time: 0.3737
INFO - 2021-01-16 04:32:00 --> Config Class Initialized
INFO - 2021-01-16 04:32:00 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:32:00 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:32:00 --> Utf8 Class Initialized
INFO - 2021-01-16 04:32:00 --> URI Class Initialized
INFO - 2021-01-16 04:32:00 --> Router Class Initialized
INFO - 2021-01-16 04:32:00 --> Output Class Initialized
INFO - 2021-01-16 04:32:00 --> Security Class Initialized
DEBUG - 2021-01-16 04:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:32:00 --> Input Class Initialized
INFO - 2021-01-16 04:32:00 --> Language Class Initialized
INFO - 2021-01-16 04:32:00 --> Language Class Initialized
INFO - 2021-01-16 04:32:00 --> Config Class Initialized
INFO - 2021-01-16 04:32:00 --> Loader Class Initialized
INFO - 2021-01-16 04:32:00 --> Helper loaded: url_helper
INFO - 2021-01-16 04:32:00 --> Helper loaded: file_helper
INFO - 2021-01-16 04:32:00 --> Helper loaded: form_helper
INFO - 2021-01-16 04:32:00 --> Helper loaded: my_helper
INFO - 2021-01-16 04:32:00 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:32:00 --> Controller Class Initialized
ERROR - 2021-01-16 04:32:00 --> Severity: Notice --> Undefined variable: nilai_akhir_a1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 4489
DEBUG - 2021-01-16 04:32:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:32:00 --> Final output sent to browser
DEBUG - 2021-01-16 04:32:00 --> Total execution time: 0.3777
INFO - 2021-01-16 04:32:26 --> Config Class Initialized
INFO - 2021-01-16 04:32:26 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:32:26 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:32:26 --> Utf8 Class Initialized
INFO - 2021-01-16 04:32:26 --> URI Class Initialized
INFO - 2021-01-16 04:32:26 --> Router Class Initialized
INFO - 2021-01-16 04:32:26 --> Output Class Initialized
INFO - 2021-01-16 04:32:26 --> Security Class Initialized
DEBUG - 2021-01-16 04:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:32:26 --> Input Class Initialized
INFO - 2021-01-16 04:32:26 --> Language Class Initialized
INFO - 2021-01-16 04:32:26 --> Language Class Initialized
INFO - 2021-01-16 04:32:26 --> Config Class Initialized
INFO - 2021-01-16 04:32:26 --> Loader Class Initialized
INFO - 2021-01-16 04:32:26 --> Helper loaded: url_helper
INFO - 2021-01-16 04:32:26 --> Helper loaded: file_helper
INFO - 2021-01-16 04:32:26 --> Helper loaded: form_helper
INFO - 2021-01-16 04:32:26 --> Helper loaded: my_helper
INFO - 2021-01-16 04:32:26 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:32:26 --> Controller Class Initialized
DEBUG - 2021-01-16 04:32:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:32:27 --> Final output sent to browser
DEBUG - 2021-01-16 04:32:27 --> Total execution time: 0.3635
INFO - 2021-01-16 04:33:24 --> Config Class Initialized
INFO - 2021-01-16 04:33:24 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:33:24 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:33:24 --> Utf8 Class Initialized
INFO - 2021-01-16 04:33:24 --> URI Class Initialized
INFO - 2021-01-16 04:33:24 --> Router Class Initialized
INFO - 2021-01-16 04:33:24 --> Output Class Initialized
INFO - 2021-01-16 04:33:24 --> Security Class Initialized
DEBUG - 2021-01-16 04:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:33:24 --> Input Class Initialized
INFO - 2021-01-16 04:33:24 --> Language Class Initialized
INFO - 2021-01-16 04:33:24 --> Language Class Initialized
INFO - 2021-01-16 04:33:24 --> Config Class Initialized
INFO - 2021-01-16 04:33:24 --> Loader Class Initialized
INFO - 2021-01-16 04:33:24 --> Helper loaded: url_helper
INFO - 2021-01-16 04:33:24 --> Helper loaded: file_helper
INFO - 2021-01-16 04:33:24 --> Helper loaded: form_helper
INFO - 2021-01-16 04:33:24 --> Helper loaded: my_helper
INFO - 2021-01-16 04:33:24 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:33:24 --> Controller Class Initialized
DEBUG - 2021-01-16 04:33:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-16 04:33:24 --> Final output sent to browser
DEBUG - 2021-01-16 04:33:24 --> Total execution time: 0.3773
INFO - 2021-01-16 04:33:27 --> Config Class Initialized
INFO - 2021-01-16 04:33:27 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:33:27 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:33:27 --> Utf8 Class Initialized
INFO - 2021-01-16 04:33:27 --> URI Class Initialized
INFO - 2021-01-16 04:33:27 --> Router Class Initialized
INFO - 2021-01-16 04:33:27 --> Output Class Initialized
INFO - 2021-01-16 04:33:27 --> Security Class Initialized
DEBUG - 2021-01-16 04:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:33:27 --> Input Class Initialized
INFO - 2021-01-16 04:33:27 --> Language Class Initialized
INFO - 2021-01-16 04:33:27 --> Language Class Initialized
INFO - 2021-01-16 04:33:27 --> Config Class Initialized
INFO - 2021-01-16 04:33:27 --> Loader Class Initialized
INFO - 2021-01-16 04:33:27 --> Helper loaded: url_helper
INFO - 2021-01-16 04:33:27 --> Helper loaded: file_helper
INFO - 2021-01-16 04:33:27 --> Helper loaded: form_helper
INFO - 2021-01-16 04:33:27 --> Helper loaded: my_helper
INFO - 2021-01-16 04:33:27 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:33:27 --> Controller Class Initialized
DEBUG - 2021-01-16 04:33:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:33:27 --> Final output sent to browser
DEBUG - 2021-01-16 04:33:27 --> Total execution time: 0.3713
INFO - 2021-01-16 04:33:59 --> Config Class Initialized
INFO - 2021-01-16 04:33:59 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:33:59 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:33:59 --> Utf8 Class Initialized
INFO - 2021-01-16 04:33:59 --> URI Class Initialized
INFO - 2021-01-16 04:33:59 --> Router Class Initialized
INFO - 2021-01-16 04:33:59 --> Output Class Initialized
INFO - 2021-01-16 04:33:59 --> Security Class Initialized
DEBUG - 2021-01-16 04:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:33:59 --> Input Class Initialized
INFO - 2021-01-16 04:33:59 --> Language Class Initialized
INFO - 2021-01-16 04:33:59 --> Language Class Initialized
INFO - 2021-01-16 04:33:59 --> Config Class Initialized
INFO - 2021-01-16 04:33:59 --> Loader Class Initialized
INFO - 2021-01-16 04:33:59 --> Helper loaded: url_helper
INFO - 2021-01-16 04:33:59 --> Helper loaded: file_helper
INFO - 2021-01-16 04:33:59 --> Helper loaded: form_helper
INFO - 2021-01-16 04:33:59 --> Helper loaded: my_helper
INFO - 2021-01-16 04:33:59 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:33:59 --> Controller Class Initialized
DEBUG - 2021-01-16 04:33:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:33:59 --> Final output sent to browser
DEBUG - 2021-01-16 04:33:59 --> Total execution time: 0.3757
INFO - 2021-01-16 04:34:09 --> Config Class Initialized
INFO - 2021-01-16 04:34:09 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:34:09 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:34:09 --> Utf8 Class Initialized
INFO - 2021-01-16 04:34:09 --> URI Class Initialized
INFO - 2021-01-16 04:34:09 --> Router Class Initialized
INFO - 2021-01-16 04:34:09 --> Output Class Initialized
INFO - 2021-01-16 04:34:09 --> Security Class Initialized
DEBUG - 2021-01-16 04:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:34:09 --> Input Class Initialized
INFO - 2021-01-16 04:34:09 --> Language Class Initialized
INFO - 2021-01-16 04:34:09 --> Language Class Initialized
INFO - 2021-01-16 04:34:09 --> Config Class Initialized
INFO - 2021-01-16 04:34:09 --> Loader Class Initialized
INFO - 2021-01-16 04:34:09 --> Helper loaded: url_helper
INFO - 2021-01-16 04:34:09 --> Helper loaded: file_helper
INFO - 2021-01-16 04:34:09 --> Helper loaded: form_helper
INFO - 2021-01-16 04:34:09 --> Helper loaded: my_helper
INFO - 2021-01-16 04:34:09 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:34:09 --> Controller Class Initialized
DEBUG - 2021-01-16 04:34:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:34:09 --> Final output sent to browser
DEBUG - 2021-01-16 04:34:09 --> Total execution time: 0.3602
INFO - 2021-01-16 04:36:44 --> Config Class Initialized
INFO - 2021-01-16 04:36:44 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:36:44 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:36:44 --> Utf8 Class Initialized
INFO - 2021-01-16 04:36:44 --> URI Class Initialized
INFO - 2021-01-16 04:36:44 --> Router Class Initialized
INFO - 2021-01-16 04:36:44 --> Output Class Initialized
INFO - 2021-01-16 04:36:44 --> Security Class Initialized
DEBUG - 2021-01-16 04:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:36:44 --> Input Class Initialized
INFO - 2021-01-16 04:36:44 --> Language Class Initialized
INFO - 2021-01-16 04:36:44 --> Language Class Initialized
INFO - 2021-01-16 04:36:44 --> Config Class Initialized
INFO - 2021-01-16 04:36:44 --> Loader Class Initialized
INFO - 2021-01-16 04:36:44 --> Helper loaded: url_helper
INFO - 2021-01-16 04:36:44 --> Helper loaded: file_helper
INFO - 2021-01-16 04:36:44 --> Helper loaded: form_helper
INFO - 2021-01-16 04:36:44 --> Helper loaded: my_helper
INFO - 2021-01-16 04:36:44 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:36:44 --> Controller Class Initialized
DEBUG - 2021-01-16 04:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-16 04:36:44 --> Final output sent to browser
DEBUG - 2021-01-16 04:36:44 --> Total execution time: 0.4375
INFO - 2021-01-16 04:37:14 --> Config Class Initialized
INFO - 2021-01-16 04:37:14 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:37:14 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:37:14 --> Utf8 Class Initialized
INFO - 2021-01-16 04:37:14 --> URI Class Initialized
INFO - 2021-01-16 04:37:14 --> Router Class Initialized
INFO - 2021-01-16 04:37:14 --> Output Class Initialized
INFO - 2021-01-16 04:37:14 --> Security Class Initialized
DEBUG - 2021-01-16 04:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:37:14 --> Input Class Initialized
INFO - 2021-01-16 04:37:14 --> Language Class Initialized
INFO - 2021-01-16 04:37:14 --> Language Class Initialized
INFO - 2021-01-16 04:37:14 --> Config Class Initialized
INFO - 2021-01-16 04:37:14 --> Loader Class Initialized
INFO - 2021-01-16 04:37:14 --> Helper loaded: url_helper
INFO - 2021-01-16 04:37:14 --> Helper loaded: file_helper
INFO - 2021-01-16 04:37:14 --> Helper loaded: form_helper
INFO - 2021-01-16 04:37:14 --> Helper loaded: my_helper
INFO - 2021-01-16 04:37:14 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:37:14 --> Controller Class Initialized
DEBUG - 2021-01-16 04:37:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:37:14 --> Final output sent to browser
DEBUG - 2021-01-16 04:37:14 --> Total execution time: 0.3586
INFO - 2021-01-16 04:56:33 --> Config Class Initialized
INFO - 2021-01-16 04:56:33 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:56:33 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:56:33 --> Utf8 Class Initialized
INFO - 2021-01-16 04:56:33 --> URI Class Initialized
INFO - 2021-01-16 04:56:33 --> Router Class Initialized
INFO - 2021-01-16 04:56:33 --> Output Class Initialized
INFO - 2021-01-16 04:56:33 --> Security Class Initialized
DEBUG - 2021-01-16 04:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:56:33 --> Input Class Initialized
INFO - 2021-01-16 04:56:33 --> Language Class Initialized
INFO - 2021-01-16 04:56:33 --> Language Class Initialized
INFO - 2021-01-16 04:56:33 --> Config Class Initialized
INFO - 2021-01-16 04:56:33 --> Loader Class Initialized
INFO - 2021-01-16 04:56:33 --> Helper loaded: url_helper
INFO - 2021-01-16 04:56:33 --> Helper loaded: file_helper
INFO - 2021-01-16 04:56:33 --> Helper loaded: form_helper
INFO - 2021-01-16 04:56:33 --> Helper loaded: my_helper
INFO - 2021-01-16 04:56:33 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:56:33 --> Controller Class Initialized
DEBUG - 2021-01-16 04:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:56:33 --> Final output sent to browser
DEBUG - 2021-01-16 04:56:33 --> Total execution time: 0.3465
INFO - 2021-01-16 04:56:35 --> Config Class Initialized
INFO - 2021-01-16 04:56:35 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:56:35 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:56:35 --> Utf8 Class Initialized
INFO - 2021-01-16 04:56:35 --> URI Class Initialized
INFO - 2021-01-16 04:56:35 --> Router Class Initialized
INFO - 2021-01-16 04:56:35 --> Output Class Initialized
INFO - 2021-01-16 04:56:35 --> Security Class Initialized
DEBUG - 2021-01-16 04:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:56:35 --> Input Class Initialized
INFO - 2021-01-16 04:56:35 --> Language Class Initialized
INFO - 2021-01-16 04:56:35 --> Language Class Initialized
INFO - 2021-01-16 04:56:35 --> Config Class Initialized
INFO - 2021-01-16 04:56:35 --> Loader Class Initialized
INFO - 2021-01-16 04:56:35 --> Helper loaded: url_helper
INFO - 2021-01-16 04:56:35 --> Helper loaded: file_helper
INFO - 2021-01-16 04:56:35 --> Helper loaded: form_helper
INFO - 2021-01-16 04:56:35 --> Helper loaded: my_helper
INFO - 2021-01-16 04:56:35 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:56:35 --> Controller Class Initialized
DEBUG - 2021-01-16 04:56:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:56:35 --> Final output sent to browser
DEBUG - 2021-01-16 04:56:35 --> Total execution time: 0.3795
INFO - 2021-01-16 04:56:46 --> Config Class Initialized
INFO - 2021-01-16 04:56:46 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:56:46 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:56:46 --> Utf8 Class Initialized
INFO - 2021-01-16 04:56:46 --> URI Class Initialized
INFO - 2021-01-16 04:56:46 --> Router Class Initialized
INFO - 2021-01-16 04:56:46 --> Output Class Initialized
INFO - 2021-01-16 04:56:46 --> Security Class Initialized
DEBUG - 2021-01-16 04:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:56:46 --> Input Class Initialized
INFO - 2021-01-16 04:56:46 --> Language Class Initialized
INFO - 2021-01-16 04:56:46 --> Language Class Initialized
INFO - 2021-01-16 04:56:46 --> Config Class Initialized
INFO - 2021-01-16 04:56:46 --> Loader Class Initialized
INFO - 2021-01-16 04:56:46 --> Helper loaded: url_helper
INFO - 2021-01-16 04:56:46 --> Helper loaded: file_helper
INFO - 2021-01-16 04:56:46 --> Helper loaded: form_helper
INFO - 2021-01-16 04:56:46 --> Helper loaded: my_helper
INFO - 2021-01-16 04:56:46 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:56:46 --> Controller Class Initialized
DEBUG - 2021-01-16 04:56:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-16 04:56:46 --> Final output sent to browser
DEBUG - 2021-01-16 04:56:46 --> Total execution time: 0.3598
INFO - 2021-01-16 04:59:12 --> Config Class Initialized
INFO - 2021-01-16 04:59:12 --> Hooks Class Initialized
DEBUG - 2021-01-16 04:59:13 --> UTF-8 Support Enabled
INFO - 2021-01-16 04:59:13 --> Utf8 Class Initialized
INFO - 2021-01-16 04:59:13 --> URI Class Initialized
INFO - 2021-01-16 04:59:13 --> Router Class Initialized
INFO - 2021-01-16 04:59:13 --> Output Class Initialized
INFO - 2021-01-16 04:59:13 --> Security Class Initialized
DEBUG - 2021-01-16 04:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-16 04:59:13 --> Input Class Initialized
INFO - 2021-01-16 04:59:13 --> Language Class Initialized
INFO - 2021-01-16 04:59:13 --> Language Class Initialized
INFO - 2021-01-16 04:59:13 --> Config Class Initialized
INFO - 2021-01-16 04:59:13 --> Loader Class Initialized
INFO - 2021-01-16 04:59:13 --> Helper loaded: url_helper
INFO - 2021-01-16 04:59:13 --> Helper loaded: file_helper
INFO - 2021-01-16 04:59:13 --> Helper loaded: form_helper
INFO - 2021-01-16 04:59:13 --> Helper loaded: my_helper
INFO - 2021-01-16 04:59:13 --> Database Driver Class Initialized
DEBUG - 2021-01-16 04:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-16 04:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-16 04:59:13 --> Controller Class Initialized
DEBUG - 2021-01-16 04:59:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-16 04:59:13 --> Final output sent to browser
DEBUG - 2021-01-16 04:59:13 --> Total execution time: 0.3634
