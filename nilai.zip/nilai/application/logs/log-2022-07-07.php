<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-07 04:30:51 --> Config Class Initialized
INFO - 2022-07-07 04:30:51 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:30:51 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:30:51 --> Utf8 Class Initialized
INFO - 2022-07-07 04:30:51 --> URI Class Initialized
DEBUG - 2022-07-07 04:30:51 --> No URI present. Default controller set.
INFO - 2022-07-07 04:30:51 --> Router Class Initialized
INFO - 2022-07-07 04:30:51 --> Output Class Initialized
INFO - 2022-07-07 04:30:51 --> Security Class Initialized
DEBUG - 2022-07-07 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:30:51 --> Input Class Initialized
INFO - 2022-07-07 04:30:51 --> Language Class Initialized
INFO - 2022-07-07 04:30:51 --> Language Class Initialized
INFO - 2022-07-07 04:30:51 --> Config Class Initialized
INFO - 2022-07-07 04:30:51 --> Loader Class Initialized
INFO - 2022-07-07 04:30:51 --> Helper loaded: url_helper
INFO - 2022-07-07 04:30:51 --> Helper loaded: file_helper
INFO - 2022-07-07 04:30:51 --> Helper loaded: form_helper
INFO - 2022-07-07 04:30:51 --> Helper loaded: my_helper
INFO - 2022-07-07 04:30:51 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:30:51 --> Controller Class Initialized
INFO - 2022-07-07 04:30:51 --> Config Class Initialized
INFO - 2022-07-07 04:30:51 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:30:51 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:30:51 --> Utf8 Class Initialized
INFO - 2022-07-07 04:30:51 --> URI Class Initialized
INFO - 2022-07-07 04:30:51 --> Router Class Initialized
INFO - 2022-07-07 04:30:51 --> Output Class Initialized
INFO - 2022-07-07 04:30:51 --> Security Class Initialized
DEBUG - 2022-07-07 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:30:51 --> Input Class Initialized
INFO - 2022-07-07 04:30:51 --> Language Class Initialized
INFO - 2022-07-07 04:30:51 --> Language Class Initialized
INFO - 2022-07-07 04:30:51 --> Config Class Initialized
INFO - 2022-07-07 04:30:51 --> Loader Class Initialized
INFO - 2022-07-07 04:30:51 --> Helper loaded: url_helper
INFO - 2022-07-07 04:30:51 --> Helper loaded: file_helper
INFO - 2022-07-07 04:30:51 --> Helper loaded: form_helper
INFO - 2022-07-07 04:30:51 --> Helper loaded: my_helper
INFO - 2022-07-07 04:30:51 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:30:51 --> Controller Class Initialized
DEBUG - 2022-07-07 04:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-07 04:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 04:30:51 --> Final output sent to browser
DEBUG - 2022-07-07 04:30:51 --> Total execution time: 0.0448
INFO - 2022-07-07 04:30:59 --> Config Class Initialized
INFO - 2022-07-07 04:30:59 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:30:59 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:30:59 --> Utf8 Class Initialized
INFO - 2022-07-07 04:30:59 --> URI Class Initialized
INFO - 2022-07-07 04:30:59 --> Router Class Initialized
INFO - 2022-07-07 04:30:59 --> Output Class Initialized
INFO - 2022-07-07 04:30:59 --> Security Class Initialized
DEBUG - 2022-07-07 04:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:30:59 --> Input Class Initialized
INFO - 2022-07-07 04:30:59 --> Language Class Initialized
INFO - 2022-07-07 04:30:59 --> Language Class Initialized
INFO - 2022-07-07 04:30:59 --> Config Class Initialized
INFO - 2022-07-07 04:30:59 --> Loader Class Initialized
INFO - 2022-07-07 04:30:59 --> Helper loaded: url_helper
INFO - 2022-07-07 04:30:59 --> Helper loaded: file_helper
INFO - 2022-07-07 04:30:59 --> Helper loaded: form_helper
INFO - 2022-07-07 04:30:59 --> Helper loaded: my_helper
INFO - 2022-07-07 04:30:59 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:30:59 --> Controller Class Initialized
INFO - 2022-07-07 04:30:59 --> Helper loaded: cookie_helper
INFO - 2022-07-07 04:30:59 --> Final output sent to browser
DEBUG - 2022-07-07 04:30:59 --> Total execution time: 0.0755
INFO - 2022-07-07 04:31:01 --> Config Class Initialized
INFO - 2022-07-07 04:31:01 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:31:01 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:31:01 --> Utf8 Class Initialized
INFO - 2022-07-07 04:31:01 --> URI Class Initialized
INFO - 2022-07-07 04:31:01 --> Router Class Initialized
INFO - 2022-07-07 04:31:01 --> Output Class Initialized
INFO - 2022-07-07 04:31:01 --> Security Class Initialized
DEBUG - 2022-07-07 04:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:31:01 --> Input Class Initialized
INFO - 2022-07-07 04:31:01 --> Language Class Initialized
INFO - 2022-07-07 04:31:01 --> Language Class Initialized
INFO - 2022-07-07 04:31:01 --> Config Class Initialized
INFO - 2022-07-07 04:31:01 --> Loader Class Initialized
INFO - 2022-07-07 04:31:01 --> Helper loaded: url_helper
INFO - 2022-07-07 04:31:01 --> Helper loaded: file_helper
INFO - 2022-07-07 04:31:01 --> Helper loaded: form_helper
INFO - 2022-07-07 04:31:01 --> Helper loaded: my_helper
INFO - 2022-07-07 04:31:01 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:31:01 --> Controller Class Initialized
DEBUG - 2022-07-07 04:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-07 04:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 04:31:02 --> Final output sent to browser
DEBUG - 2022-07-07 04:31:02 --> Total execution time: 0.6280
INFO - 2022-07-07 04:31:05 --> Config Class Initialized
INFO - 2022-07-07 04:31:05 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:31:05 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:31:05 --> Utf8 Class Initialized
INFO - 2022-07-07 04:31:05 --> URI Class Initialized
INFO - 2022-07-07 04:31:05 --> Router Class Initialized
INFO - 2022-07-07 04:31:05 --> Output Class Initialized
INFO - 2022-07-07 04:31:05 --> Security Class Initialized
DEBUG - 2022-07-07 04:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:31:05 --> Input Class Initialized
INFO - 2022-07-07 04:31:05 --> Language Class Initialized
INFO - 2022-07-07 04:31:05 --> Language Class Initialized
INFO - 2022-07-07 04:31:05 --> Config Class Initialized
INFO - 2022-07-07 04:31:05 --> Loader Class Initialized
INFO - 2022-07-07 04:31:05 --> Helper loaded: url_helper
INFO - 2022-07-07 04:31:05 --> Helper loaded: file_helper
INFO - 2022-07-07 04:31:05 --> Helper loaded: form_helper
INFO - 2022-07-07 04:31:05 --> Helper loaded: my_helper
INFO - 2022-07-07 04:31:05 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:31:05 --> Controller Class Initialized
DEBUG - 2022-07-07 04:31:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-07 04:31:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 04:31:05 --> Final output sent to browser
DEBUG - 2022-07-07 04:31:05 --> Total execution time: 0.0895
INFO - 2022-07-07 04:40:46 --> Config Class Initialized
INFO - 2022-07-07 04:40:46 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:40:46 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:40:46 --> Utf8 Class Initialized
INFO - 2022-07-07 04:40:46 --> URI Class Initialized
INFO - 2022-07-07 04:40:46 --> Router Class Initialized
INFO - 2022-07-07 04:40:46 --> Output Class Initialized
INFO - 2022-07-07 04:40:46 --> Security Class Initialized
DEBUG - 2022-07-07 04:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:40:46 --> Input Class Initialized
INFO - 2022-07-07 04:40:46 --> Language Class Initialized
INFO - 2022-07-07 04:40:46 --> Language Class Initialized
INFO - 2022-07-07 04:40:46 --> Config Class Initialized
INFO - 2022-07-07 04:40:46 --> Loader Class Initialized
INFO - 2022-07-07 04:40:46 --> Helper loaded: url_helper
INFO - 2022-07-07 04:40:46 --> Helper loaded: file_helper
INFO - 2022-07-07 04:40:46 --> Helper loaded: form_helper
INFO - 2022-07-07 04:40:46 --> Helper loaded: my_helper
INFO - 2022-07-07 04:40:46 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:40:46 --> Controller Class Initialized
INFO - 2022-07-07 04:40:46 --> Final output sent to browser
DEBUG - 2022-07-07 04:40:46 --> Total execution time: 0.0840
INFO - 2022-07-07 04:41:03 --> Config Class Initialized
INFO - 2022-07-07 04:41:03 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:41:03 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:41:03 --> Utf8 Class Initialized
INFO - 2022-07-07 04:41:03 --> URI Class Initialized
INFO - 2022-07-07 04:41:03 --> Router Class Initialized
INFO - 2022-07-07 04:41:03 --> Output Class Initialized
INFO - 2022-07-07 04:41:03 --> Security Class Initialized
DEBUG - 2022-07-07 04:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:41:03 --> Input Class Initialized
INFO - 2022-07-07 04:41:03 --> Language Class Initialized
INFO - 2022-07-07 04:41:03 --> Language Class Initialized
INFO - 2022-07-07 04:41:03 --> Config Class Initialized
INFO - 2022-07-07 04:41:03 --> Loader Class Initialized
INFO - 2022-07-07 04:41:03 --> Helper loaded: url_helper
INFO - 2022-07-07 04:41:03 --> Helper loaded: file_helper
INFO - 2022-07-07 04:41:03 --> Helper loaded: form_helper
INFO - 2022-07-07 04:41:03 --> Helper loaded: my_helper
INFO - 2022-07-07 04:41:03 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:41:03 --> Controller Class Initialized
INFO - 2022-07-07 04:41:03 --> Helper loaded: cookie_helper
INFO - 2022-07-07 04:41:03 --> Config Class Initialized
INFO - 2022-07-07 04:41:03 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:41:03 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:41:03 --> Utf8 Class Initialized
INFO - 2022-07-07 04:41:03 --> URI Class Initialized
INFO - 2022-07-07 04:41:03 --> Router Class Initialized
INFO - 2022-07-07 04:41:03 --> Output Class Initialized
INFO - 2022-07-07 04:41:03 --> Security Class Initialized
DEBUG - 2022-07-07 04:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:41:03 --> Input Class Initialized
INFO - 2022-07-07 04:41:03 --> Language Class Initialized
INFO - 2022-07-07 04:41:03 --> Language Class Initialized
INFO - 2022-07-07 04:41:03 --> Config Class Initialized
INFO - 2022-07-07 04:41:03 --> Loader Class Initialized
INFO - 2022-07-07 04:41:03 --> Helper loaded: url_helper
INFO - 2022-07-07 04:41:03 --> Helper loaded: file_helper
INFO - 2022-07-07 04:41:03 --> Helper loaded: form_helper
INFO - 2022-07-07 04:41:03 --> Helper loaded: my_helper
INFO - 2022-07-07 04:41:03 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:41:03 --> Controller Class Initialized
DEBUG - 2022-07-07 04:41:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-07 04:41:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 04:41:03 --> Final output sent to browser
DEBUG - 2022-07-07 04:41:03 --> Total execution time: 0.0547
INFO - 2022-07-07 04:43:25 --> Config Class Initialized
INFO - 2022-07-07 04:43:25 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:43:25 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:43:25 --> Utf8 Class Initialized
INFO - 2022-07-07 04:43:25 --> URI Class Initialized
DEBUG - 2022-07-07 04:43:25 --> No URI present. Default controller set.
INFO - 2022-07-07 04:43:25 --> Router Class Initialized
INFO - 2022-07-07 04:43:25 --> Output Class Initialized
INFO - 2022-07-07 04:43:25 --> Security Class Initialized
DEBUG - 2022-07-07 04:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:43:25 --> Input Class Initialized
INFO - 2022-07-07 04:43:26 --> Language Class Initialized
INFO - 2022-07-07 04:43:26 --> Language Class Initialized
INFO - 2022-07-07 04:43:26 --> Config Class Initialized
INFO - 2022-07-07 04:43:26 --> Loader Class Initialized
INFO - 2022-07-07 04:43:26 --> Helper loaded: url_helper
INFO - 2022-07-07 04:43:26 --> Helper loaded: file_helper
INFO - 2022-07-07 04:43:26 --> Helper loaded: form_helper
INFO - 2022-07-07 04:43:26 --> Helper loaded: my_helper
INFO - 2022-07-07 04:43:26 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:43:26 --> Controller Class Initialized
INFO - 2022-07-07 04:43:26 --> Config Class Initialized
INFO - 2022-07-07 04:43:26 --> Hooks Class Initialized
DEBUG - 2022-07-07 04:43:26 --> UTF-8 Support Enabled
INFO - 2022-07-07 04:43:26 --> Utf8 Class Initialized
INFO - 2022-07-07 04:43:26 --> URI Class Initialized
INFO - 2022-07-07 04:43:26 --> Router Class Initialized
INFO - 2022-07-07 04:43:26 --> Output Class Initialized
INFO - 2022-07-07 04:43:26 --> Security Class Initialized
DEBUG - 2022-07-07 04:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 04:43:26 --> Input Class Initialized
INFO - 2022-07-07 04:43:26 --> Language Class Initialized
INFO - 2022-07-07 04:43:26 --> Language Class Initialized
INFO - 2022-07-07 04:43:26 --> Config Class Initialized
INFO - 2022-07-07 04:43:26 --> Loader Class Initialized
INFO - 2022-07-07 04:43:26 --> Helper loaded: url_helper
INFO - 2022-07-07 04:43:26 --> Helper loaded: file_helper
INFO - 2022-07-07 04:43:26 --> Helper loaded: form_helper
INFO - 2022-07-07 04:43:26 --> Helper loaded: my_helper
INFO - 2022-07-07 04:43:26 --> Database Driver Class Initialized
DEBUG - 2022-07-07 04:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 04:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 04:43:26 --> Controller Class Initialized
DEBUG - 2022-07-07 04:43:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-07 04:43:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 04:43:26 --> Final output sent to browser
DEBUG - 2022-07-07 04:43:26 --> Total execution time: 0.0828
INFO - 2022-07-07 05:47:21 --> Config Class Initialized
INFO - 2022-07-07 05:47:21 --> Hooks Class Initialized
DEBUG - 2022-07-07 05:47:21 --> UTF-8 Support Enabled
INFO - 2022-07-07 05:47:21 --> Utf8 Class Initialized
INFO - 2022-07-07 05:47:21 --> URI Class Initialized
INFO - 2022-07-07 05:47:21 --> Router Class Initialized
INFO - 2022-07-07 05:47:21 --> Output Class Initialized
INFO - 2022-07-07 05:47:21 --> Security Class Initialized
DEBUG - 2022-07-07 05:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 05:47:21 --> Input Class Initialized
INFO - 2022-07-07 05:47:21 --> Language Class Initialized
INFO - 2022-07-07 05:47:21 --> Language Class Initialized
INFO - 2022-07-07 05:47:21 --> Config Class Initialized
INFO - 2022-07-07 05:47:21 --> Loader Class Initialized
INFO - 2022-07-07 05:47:21 --> Helper loaded: url_helper
INFO - 2022-07-07 05:47:21 --> Helper loaded: file_helper
INFO - 2022-07-07 05:47:21 --> Helper loaded: form_helper
INFO - 2022-07-07 05:47:21 --> Helper loaded: my_helper
INFO - 2022-07-07 05:47:21 --> Database Driver Class Initialized
DEBUG - 2022-07-07 05:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 05:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 05:47:21 --> Controller Class Initialized
INFO - 2022-07-07 05:47:21 --> Helper loaded: cookie_helper
INFO - 2022-07-07 05:47:21 --> Final output sent to browser
DEBUG - 2022-07-07 05:47:21 --> Total execution time: 0.0684
INFO - 2022-07-07 05:47:21 --> Config Class Initialized
INFO - 2022-07-07 05:47:21 --> Hooks Class Initialized
DEBUG - 2022-07-07 05:47:21 --> UTF-8 Support Enabled
INFO - 2022-07-07 05:47:21 --> Utf8 Class Initialized
INFO - 2022-07-07 05:47:21 --> URI Class Initialized
INFO - 2022-07-07 05:47:21 --> Router Class Initialized
INFO - 2022-07-07 05:47:21 --> Output Class Initialized
INFO - 2022-07-07 05:47:21 --> Security Class Initialized
DEBUG - 2022-07-07 05:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 05:47:21 --> Input Class Initialized
INFO - 2022-07-07 05:47:21 --> Language Class Initialized
INFO - 2022-07-07 05:47:21 --> Language Class Initialized
INFO - 2022-07-07 05:47:21 --> Config Class Initialized
INFO - 2022-07-07 05:47:21 --> Loader Class Initialized
INFO - 2022-07-07 05:47:21 --> Helper loaded: url_helper
INFO - 2022-07-07 05:47:21 --> Helper loaded: file_helper
INFO - 2022-07-07 05:47:21 --> Helper loaded: form_helper
INFO - 2022-07-07 05:47:21 --> Helper loaded: my_helper
INFO - 2022-07-07 05:47:21 --> Database Driver Class Initialized
DEBUG - 2022-07-07 05:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 05:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 05:47:22 --> Controller Class Initialized
DEBUG - 2022-07-07 05:47:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-07 05:47:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 05:47:22 --> Final output sent to browser
DEBUG - 2022-07-07 05:47:22 --> Total execution time: 0.6502
INFO - 2022-07-07 06:21:35 --> Config Class Initialized
INFO - 2022-07-07 06:21:35 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:21:35 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:21:35 --> Utf8 Class Initialized
INFO - 2022-07-07 06:21:35 --> URI Class Initialized
INFO - 2022-07-07 06:21:35 --> Router Class Initialized
INFO - 2022-07-07 06:21:35 --> Output Class Initialized
INFO - 2022-07-07 06:21:35 --> Security Class Initialized
DEBUG - 2022-07-07 06:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:21:35 --> Input Class Initialized
INFO - 2022-07-07 06:21:35 --> Language Class Initialized
INFO - 2022-07-07 06:21:35 --> Language Class Initialized
INFO - 2022-07-07 06:21:35 --> Config Class Initialized
INFO - 2022-07-07 06:21:35 --> Loader Class Initialized
INFO - 2022-07-07 06:21:35 --> Helper loaded: url_helper
INFO - 2022-07-07 06:21:35 --> Helper loaded: file_helper
INFO - 2022-07-07 06:21:35 --> Helper loaded: form_helper
INFO - 2022-07-07 06:21:35 --> Helper loaded: my_helper
INFO - 2022-07-07 06:21:35 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:21:35 --> Controller Class Initialized
DEBUG - 2022-07-07 06:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-07 06:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 06:21:35 --> Final output sent to browser
DEBUG - 2022-07-07 06:21:35 --> Total execution time: 0.0751
INFO - 2022-07-07 06:21:35 --> Config Class Initialized
INFO - 2022-07-07 06:21:35 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:21:35 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:21:35 --> Utf8 Class Initialized
INFO - 2022-07-07 06:21:35 --> URI Class Initialized
INFO - 2022-07-07 06:21:35 --> Router Class Initialized
INFO - 2022-07-07 06:21:35 --> Output Class Initialized
INFO - 2022-07-07 06:21:35 --> Security Class Initialized
DEBUG - 2022-07-07 06:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:21:35 --> Input Class Initialized
INFO - 2022-07-07 06:21:35 --> Language Class Initialized
INFO - 2022-07-07 06:21:35 --> Language Class Initialized
INFO - 2022-07-07 06:21:35 --> Config Class Initialized
INFO - 2022-07-07 06:21:35 --> Loader Class Initialized
INFO - 2022-07-07 06:21:35 --> Helper loaded: url_helper
INFO - 2022-07-07 06:21:35 --> Helper loaded: file_helper
INFO - 2022-07-07 06:21:35 --> Helper loaded: form_helper
INFO - 2022-07-07 06:21:35 --> Helper loaded: my_helper
INFO - 2022-07-07 06:21:35 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:21:35 --> Controller Class Initialized
DEBUG - 2022-07-07 06:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-07 06:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 06:21:35 --> Final output sent to browser
DEBUG - 2022-07-07 06:21:35 --> Total execution time: 0.0417
INFO - 2022-07-07 06:21:35 --> Config Class Initialized
INFO - 2022-07-07 06:21:35 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:21:35 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:21:35 --> Utf8 Class Initialized
INFO - 2022-07-07 06:21:35 --> URI Class Initialized
INFO - 2022-07-07 06:21:35 --> Router Class Initialized
INFO - 2022-07-07 06:21:35 --> Output Class Initialized
INFO - 2022-07-07 06:21:35 --> Security Class Initialized
DEBUG - 2022-07-07 06:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:21:35 --> Input Class Initialized
INFO - 2022-07-07 06:21:35 --> Language Class Initialized
INFO - 2022-07-07 06:21:35 --> Language Class Initialized
INFO - 2022-07-07 06:21:35 --> Config Class Initialized
INFO - 2022-07-07 06:21:35 --> Loader Class Initialized
INFO - 2022-07-07 06:21:35 --> Helper loaded: url_helper
INFO - 2022-07-07 06:21:35 --> Helper loaded: file_helper
INFO - 2022-07-07 06:21:35 --> Helper loaded: form_helper
INFO - 2022-07-07 06:21:35 --> Helper loaded: my_helper
INFO - 2022-07-07 06:21:35 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:21:35 --> Controller Class Initialized
INFO - 2022-07-07 06:21:37 --> Config Class Initialized
INFO - 2022-07-07 06:21:37 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:21:37 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:21:37 --> Utf8 Class Initialized
INFO - 2022-07-07 06:21:37 --> URI Class Initialized
INFO - 2022-07-07 06:21:37 --> Router Class Initialized
INFO - 2022-07-07 06:21:37 --> Output Class Initialized
INFO - 2022-07-07 06:21:37 --> Security Class Initialized
DEBUG - 2022-07-07 06:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:21:37 --> Input Class Initialized
INFO - 2022-07-07 06:21:37 --> Language Class Initialized
INFO - 2022-07-07 06:21:37 --> Language Class Initialized
INFO - 2022-07-07 06:21:37 --> Config Class Initialized
INFO - 2022-07-07 06:21:37 --> Loader Class Initialized
INFO - 2022-07-07 06:21:37 --> Helper loaded: url_helper
INFO - 2022-07-07 06:21:37 --> Helper loaded: file_helper
INFO - 2022-07-07 06:21:37 --> Helper loaded: form_helper
INFO - 2022-07-07 06:21:37 --> Helper loaded: my_helper
INFO - 2022-07-07 06:21:37 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:21:37 --> Controller Class Initialized
DEBUG - 2022-07-07 06:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2022-07-07 06:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 06:21:37 --> Final output sent to browser
DEBUG - 2022-07-07 06:21:37 --> Total execution time: 0.0885
INFO - 2022-07-07 06:21:37 --> Config Class Initialized
INFO - 2022-07-07 06:21:37 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:21:37 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:21:37 --> Utf8 Class Initialized
INFO - 2022-07-07 06:21:37 --> URI Class Initialized
INFO - 2022-07-07 06:21:37 --> Router Class Initialized
INFO - 2022-07-07 06:21:37 --> Output Class Initialized
INFO - 2022-07-07 06:21:37 --> Security Class Initialized
DEBUG - 2022-07-07 06:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:21:37 --> Input Class Initialized
INFO - 2022-07-07 06:21:37 --> Language Class Initialized
INFO - 2022-07-07 06:21:37 --> Language Class Initialized
INFO - 2022-07-07 06:21:37 --> Config Class Initialized
INFO - 2022-07-07 06:21:37 --> Loader Class Initialized
INFO - 2022-07-07 06:21:37 --> Helper loaded: url_helper
INFO - 2022-07-07 06:21:37 --> Helper loaded: file_helper
INFO - 2022-07-07 06:21:37 --> Helper loaded: form_helper
INFO - 2022-07-07 06:21:37 --> Helper loaded: my_helper
INFO - 2022-07-07 06:21:37 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:21:37 --> Controller Class Initialized
INFO - 2022-07-07 06:21:39 --> Config Class Initialized
INFO - 2022-07-07 06:21:39 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:21:39 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:21:39 --> Utf8 Class Initialized
INFO - 2022-07-07 06:21:39 --> URI Class Initialized
INFO - 2022-07-07 06:21:39 --> Router Class Initialized
INFO - 2022-07-07 06:21:39 --> Output Class Initialized
INFO - 2022-07-07 06:21:39 --> Security Class Initialized
DEBUG - 2022-07-07 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:21:39 --> Input Class Initialized
INFO - 2022-07-07 06:21:39 --> Language Class Initialized
INFO - 2022-07-07 06:21:39 --> Language Class Initialized
INFO - 2022-07-07 06:21:39 --> Config Class Initialized
INFO - 2022-07-07 06:21:39 --> Loader Class Initialized
INFO - 2022-07-07 06:21:39 --> Helper loaded: url_helper
INFO - 2022-07-07 06:21:39 --> Helper loaded: file_helper
INFO - 2022-07-07 06:21:39 --> Helper loaded: form_helper
INFO - 2022-07-07 06:21:39 --> Helper loaded: my_helper
INFO - 2022-07-07 06:21:39 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:21:39 --> Controller Class Initialized
DEBUG - 2022-07-07 06:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-07-07 06:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 06:21:39 --> Final output sent to browser
DEBUG - 2022-07-07 06:21:39 --> Total execution time: 0.0992
INFO - 2022-07-07 06:21:39 --> Config Class Initialized
INFO - 2022-07-07 06:21:39 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:21:39 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:21:39 --> Utf8 Class Initialized
INFO - 2022-07-07 06:21:39 --> URI Class Initialized
INFO - 2022-07-07 06:21:39 --> Router Class Initialized
INFO - 2022-07-07 06:21:39 --> Output Class Initialized
INFO - 2022-07-07 06:21:39 --> Security Class Initialized
DEBUG - 2022-07-07 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:21:39 --> Input Class Initialized
INFO - 2022-07-07 06:21:39 --> Language Class Initialized
INFO - 2022-07-07 06:21:39 --> Language Class Initialized
INFO - 2022-07-07 06:21:39 --> Config Class Initialized
INFO - 2022-07-07 06:21:39 --> Loader Class Initialized
INFO - 2022-07-07 06:21:39 --> Helper loaded: url_helper
INFO - 2022-07-07 06:21:39 --> Helper loaded: file_helper
INFO - 2022-07-07 06:21:39 --> Helper loaded: form_helper
INFO - 2022-07-07 06:21:39 --> Helper loaded: my_helper
INFO - 2022-07-07 06:21:39 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:21:39 --> Controller Class Initialized
DEBUG - 2022-07-07 06:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-07-07 06:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 06:21:39 --> Final output sent to browser
DEBUG - 2022-07-07 06:21:39 --> Total execution time: 0.0679
INFO - 2022-07-07 06:30:48 --> Config Class Initialized
INFO - 2022-07-07 06:30:48 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:30:48 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:30:48 --> Utf8 Class Initialized
INFO - 2022-07-07 06:30:48 --> URI Class Initialized
INFO - 2022-07-07 06:30:48 --> Router Class Initialized
INFO - 2022-07-07 06:30:48 --> Output Class Initialized
INFO - 2022-07-07 06:30:48 --> Security Class Initialized
DEBUG - 2022-07-07 06:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:30:48 --> Input Class Initialized
INFO - 2022-07-07 06:30:48 --> Language Class Initialized
INFO - 2022-07-07 06:30:48 --> Language Class Initialized
INFO - 2022-07-07 06:30:48 --> Config Class Initialized
INFO - 2022-07-07 06:30:48 --> Loader Class Initialized
INFO - 2022-07-07 06:30:48 --> Helper loaded: url_helper
INFO - 2022-07-07 06:30:48 --> Helper loaded: file_helper
INFO - 2022-07-07 06:30:48 --> Helper loaded: form_helper
INFO - 2022-07-07 06:30:48 --> Helper loaded: my_helper
INFO - 2022-07-07 06:30:48 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:30:48 --> Controller Class Initialized
DEBUG - 2022-07-07 06:30:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-07 06:30:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 06:30:48 --> Final output sent to browser
DEBUG - 2022-07-07 06:30:48 --> Total execution time: 0.0433
INFO - 2022-07-07 06:30:48 --> Config Class Initialized
INFO - 2022-07-07 06:30:48 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:30:48 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:30:48 --> Utf8 Class Initialized
INFO - 2022-07-07 06:30:48 --> URI Class Initialized
INFO - 2022-07-07 06:30:48 --> Router Class Initialized
INFO - 2022-07-07 06:30:48 --> Output Class Initialized
INFO - 2022-07-07 06:30:48 --> Security Class Initialized
DEBUG - 2022-07-07 06:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:30:48 --> Input Class Initialized
INFO - 2022-07-07 06:30:48 --> Language Class Initialized
INFO - 2022-07-07 06:30:48 --> Language Class Initialized
INFO - 2022-07-07 06:30:48 --> Config Class Initialized
INFO - 2022-07-07 06:30:48 --> Loader Class Initialized
INFO - 2022-07-07 06:30:48 --> Helper loaded: url_helper
INFO - 2022-07-07 06:30:48 --> Helper loaded: file_helper
INFO - 2022-07-07 06:30:48 --> Helper loaded: form_helper
INFO - 2022-07-07 06:30:48 --> Helper loaded: my_helper
INFO - 2022-07-07 06:30:48 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:30:48 --> Controller Class Initialized
INFO - 2022-07-07 06:30:50 --> Config Class Initialized
INFO - 2022-07-07 06:30:50 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:30:50 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:30:50 --> Utf8 Class Initialized
INFO - 2022-07-07 06:30:50 --> URI Class Initialized
INFO - 2022-07-07 06:30:50 --> Router Class Initialized
INFO - 2022-07-07 06:30:50 --> Output Class Initialized
INFO - 2022-07-07 06:30:50 --> Security Class Initialized
DEBUG - 2022-07-07 06:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:30:50 --> Input Class Initialized
INFO - 2022-07-07 06:30:50 --> Language Class Initialized
INFO - 2022-07-07 06:30:50 --> Language Class Initialized
INFO - 2022-07-07 06:30:50 --> Config Class Initialized
INFO - 2022-07-07 06:30:50 --> Loader Class Initialized
INFO - 2022-07-07 06:30:50 --> Helper loaded: url_helper
INFO - 2022-07-07 06:30:50 --> Helper loaded: file_helper
INFO - 2022-07-07 06:30:50 --> Helper loaded: form_helper
INFO - 2022-07-07 06:30:50 --> Helper loaded: my_helper
INFO - 2022-07-07 06:30:50 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:30:50 --> Controller Class Initialized
INFO - 2022-07-07 06:30:51 --> Config Class Initialized
INFO - 2022-07-07 06:30:51 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:30:51 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:30:51 --> Utf8 Class Initialized
INFO - 2022-07-07 06:30:51 --> URI Class Initialized
INFO - 2022-07-07 06:30:51 --> Router Class Initialized
INFO - 2022-07-07 06:30:51 --> Output Class Initialized
INFO - 2022-07-07 06:30:51 --> Security Class Initialized
DEBUG - 2022-07-07 06:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:30:51 --> Input Class Initialized
INFO - 2022-07-07 06:30:51 --> Language Class Initialized
INFO - 2022-07-07 06:30:51 --> Language Class Initialized
INFO - 2022-07-07 06:30:51 --> Config Class Initialized
INFO - 2022-07-07 06:30:51 --> Loader Class Initialized
INFO - 2022-07-07 06:30:51 --> Helper loaded: url_helper
INFO - 2022-07-07 06:30:51 --> Helper loaded: file_helper
INFO - 2022-07-07 06:30:51 --> Helper loaded: form_helper
INFO - 2022-07-07 06:30:51 --> Helper loaded: my_helper
INFO - 2022-07-07 06:30:51 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:30:51 --> Controller Class Initialized
INFO - 2022-07-07 06:30:51 --> Config Class Initialized
INFO - 2022-07-07 06:30:51 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:30:51 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:30:51 --> Utf8 Class Initialized
INFO - 2022-07-07 06:30:51 --> URI Class Initialized
INFO - 2022-07-07 06:30:51 --> Router Class Initialized
INFO - 2022-07-07 06:30:51 --> Output Class Initialized
INFO - 2022-07-07 06:30:51 --> Security Class Initialized
DEBUG - 2022-07-07 06:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:30:51 --> Input Class Initialized
INFO - 2022-07-07 06:30:51 --> Language Class Initialized
INFO - 2022-07-07 06:30:51 --> Language Class Initialized
INFO - 2022-07-07 06:30:51 --> Config Class Initialized
INFO - 2022-07-07 06:30:51 --> Loader Class Initialized
INFO - 2022-07-07 06:30:51 --> Helper loaded: url_helper
INFO - 2022-07-07 06:30:51 --> Helper loaded: file_helper
INFO - 2022-07-07 06:30:51 --> Helper loaded: form_helper
INFO - 2022-07-07 06:30:51 --> Helper loaded: my_helper
INFO - 2022-07-07 06:30:51 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:30:51 --> Controller Class Initialized
INFO - 2022-07-07 06:32:44 --> Config Class Initialized
INFO - 2022-07-07 06:32:44 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:44 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:44 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:44 --> URI Class Initialized
INFO - 2022-07-07 06:32:44 --> Router Class Initialized
INFO - 2022-07-07 06:32:44 --> Output Class Initialized
INFO - 2022-07-07 06:32:44 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:44 --> Input Class Initialized
INFO - 2022-07-07 06:32:44 --> Language Class Initialized
INFO - 2022-07-07 06:32:44 --> Language Class Initialized
INFO - 2022-07-07 06:32:44 --> Config Class Initialized
INFO - 2022-07-07 06:32:44 --> Loader Class Initialized
INFO - 2022-07-07 06:32:44 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:44 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:44 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:44 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:44 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:44 --> Controller Class Initialized
INFO - 2022-07-07 06:32:45 --> Config Class Initialized
INFO - 2022-07-07 06:32:45 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:45 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:45 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:45 --> URI Class Initialized
INFO - 2022-07-07 06:32:45 --> Router Class Initialized
INFO - 2022-07-07 06:32:45 --> Output Class Initialized
INFO - 2022-07-07 06:32:45 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:45 --> Input Class Initialized
INFO - 2022-07-07 06:32:45 --> Language Class Initialized
INFO - 2022-07-07 06:32:45 --> Language Class Initialized
INFO - 2022-07-07 06:32:45 --> Config Class Initialized
INFO - 2022-07-07 06:32:45 --> Loader Class Initialized
INFO - 2022-07-07 06:32:45 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:45 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:45 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:45 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:45 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:45 --> Controller Class Initialized
INFO - 2022-07-07 06:32:46 --> Config Class Initialized
INFO - 2022-07-07 06:32:46 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:46 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:46 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:46 --> URI Class Initialized
INFO - 2022-07-07 06:32:46 --> Router Class Initialized
INFO - 2022-07-07 06:32:46 --> Output Class Initialized
INFO - 2022-07-07 06:32:46 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:46 --> Input Class Initialized
INFO - 2022-07-07 06:32:46 --> Language Class Initialized
INFO - 2022-07-07 06:32:46 --> Language Class Initialized
INFO - 2022-07-07 06:32:46 --> Config Class Initialized
INFO - 2022-07-07 06:32:46 --> Loader Class Initialized
INFO - 2022-07-07 06:32:46 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:46 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:46 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:46 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:46 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:46 --> Controller Class Initialized
INFO - 2022-07-07 06:32:46 --> Config Class Initialized
INFO - 2022-07-07 06:32:46 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:46 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:46 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:46 --> URI Class Initialized
INFO - 2022-07-07 06:32:46 --> Router Class Initialized
INFO - 2022-07-07 06:32:46 --> Output Class Initialized
INFO - 2022-07-07 06:32:46 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:46 --> Input Class Initialized
INFO - 2022-07-07 06:32:46 --> Language Class Initialized
INFO - 2022-07-07 06:32:46 --> Language Class Initialized
INFO - 2022-07-07 06:32:46 --> Config Class Initialized
INFO - 2022-07-07 06:32:46 --> Loader Class Initialized
INFO - 2022-07-07 06:32:46 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:46 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:46 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:46 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:46 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:46 --> Controller Class Initialized
INFO - 2022-07-07 06:32:48 --> Config Class Initialized
INFO - 2022-07-07 06:32:48 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:48 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:48 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:48 --> URI Class Initialized
INFO - 2022-07-07 06:32:48 --> Router Class Initialized
INFO - 2022-07-07 06:32:48 --> Output Class Initialized
INFO - 2022-07-07 06:32:48 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:48 --> Input Class Initialized
INFO - 2022-07-07 06:32:48 --> Language Class Initialized
INFO - 2022-07-07 06:32:48 --> Language Class Initialized
INFO - 2022-07-07 06:32:48 --> Config Class Initialized
INFO - 2022-07-07 06:32:48 --> Loader Class Initialized
INFO - 2022-07-07 06:32:48 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:48 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:48 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:48 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:48 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:48 --> Controller Class Initialized
INFO - 2022-07-07 06:32:49 --> Config Class Initialized
INFO - 2022-07-07 06:32:49 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:49 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:49 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:49 --> URI Class Initialized
INFO - 2022-07-07 06:32:49 --> Router Class Initialized
INFO - 2022-07-07 06:32:49 --> Output Class Initialized
INFO - 2022-07-07 06:32:49 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:49 --> Input Class Initialized
INFO - 2022-07-07 06:32:49 --> Language Class Initialized
INFO - 2022-07-07 06:32:49 --> Language Class Initialized
INFO - 2022-07-07 06:32:49 --> Config Class Initialized
INFO - 2022-07-07 06:32:49 --> Loader Class Initialized
INFO - 2022-07-07 06:32:49 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:49 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:49 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:49 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:49 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:49 --> Controller Class Initialized
INFO - 2022-07-07 06:32:49 --> Config Class Initialized
INFO - 2022-07-07 06:32:49 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:49 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:49 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:49 --> URI Class Initialized
INFO - 2022-07-07 06:32:49 --> Router Class Initialized
INFO - 2022-07-07 06:32:49 --> Output Class Initialized
INFO - 2022-07-07 06:32:49 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:49 --> Input Class Initialized
INFO - 2022-07-07 06:32:49 --> Language Class Initialized
INFO - 2022-07-07 06:32:49 --> Language Class Initialized
INFO - 2022-07-07 06:32:49 --> Config Class Initialized
INFO - 2022-07-07 06:32:49 --> Loader Class Initialized
INFO - 2022-07-07 06:32:49 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:49 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:49 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:49 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:49 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:50 --> Controller Class Initialized
INFO - 2022-07-07 06:32:50 --> Config Class Initialized
INFO - 2022-07-07 06:32:50 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:50 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:50 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:50 --> URI Class Initialized
INFO - 2022-07-07 06:32:50 --> Router Class Initialized
INFO - 2022-07-07 06:32:50 --> Output Class Initialized
INFO - 2022-07-07 06:32:50 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:50 --> Input Class Initialized
INFO - 2022-07-07 06:32:50 --> Language Class Initialized
INFO - 2022-07-07 06:32:50 --> Language Class Initialized
INFO - 2022-07-07 06:32:50 --> Config Class Initialized
INFO - 2022-07-07 06:32:50 --> Loader Class Initialized
INFO - 2022-07-07 06:32:50 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:50 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:50 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:50 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:50 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:50 --> Controller Class Initialized
INFO - 2022-07-07 06:32:50 --> Config Class Initialized
INFO - 2022-07-07 06:32:50 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:50 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:50 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:50 --> URI Class Initialized
INFO - 2022-07-07 06:32:50 --> Router Class Initialized
INFO - 2022-07-07 06:32:50 --> Output Class Initialized
INFO - 2022-07-07 06:32:50 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:50 --> Input Class Initialized
INFO - 2022-07-07 06:32:50 --> Language Class Initialized
INFO - 2022-07-07 06:32:50 --> Language Class Initialized
INFO - 2022-07-07 06:32:50 --> Config Class Initialized
INFO - 2022-07-07 06:32:50 --> Loader Class Initialized
INFO - 2022-07-07 06:32:50 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:50 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:50 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:50 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:50 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:50 --> Controller Class Initialized
INFO - 2022-07-07 06:32:51 --> Config Class Initialized
INFO - 2022-07-07 06:32:51 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:51 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:51 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:51 --> URI Class Initialized
INFO - 2022-07-07 06:32:51 --> Router Class Initialized
INFO - 2022-07-07 06:32:51 --> Output Class Initialized
INFO - 2022-07-07 06:32:51 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:51 --> Input Class Initialized
INFO - 2022-07-07 06:32:51 --> Language Class Initialized
INFO - 2022-07-07 06:32:51 --> Language Class Initialized
INFO - 2022-07-07 06:32:51 --> Config Class Initialized
INFO - 2022-07-07 06:32:51 --> Loader Class Initialized
INFO - 2022-07-07 06:32:51 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:51 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:51 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:51 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:51 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:51 --> Controller Class Initialized
INFO - 2022-07-07 06:32:51 --> Config Class Initialized
INFO - 2022-07-07 06:32:51 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:32:51 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:32:51 --> Utf8 Class Initialized
INFO - 2022-07-07 06:32:51 --> URI Class Initialized
INFO - 2022-07-07 06:32:51 --> Router Class Initialized
INFO - 2022-07-07 06:32:51 --> Output Class Initialized
INFO - 2022-07-07 06:32:51 --> Security Class Initialized
DEBUG - 2022-07-07 06:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:32:51 --> Input Class Initialized
INFO - 2022-07-07 06:32:51 --> Language Class Initialized
INFO - 2022-07-07 06:32:51 --> Language Class Initialized
INFO - 2022-07-07 06:32:51 --> Config Class Initialized
INFO - 2022-07-07 06:32:51 --> Loader Class Initialized
INFO - 2022-07-07 06:32:51 --> Helper loaded: url_helper
INFO - 2022-07-07 06:32:51 --> Helper loaded: file_helper
INFO - 2022-07-07 06:32:51 --> Helper loaded: form_helper
INFO - 2022-07-07 06:32:51 --> Helper loaded: my_helper
INFO - 2022-07-07 06:32:51 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:32:51 --> Controller Class Initialized
INFO - 2022-07-07 06:33:49 --> Config Class Initialized
INFO - 2022-07-07 06:33:49 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:49 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:49 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:49 --> URI Class Initialized
INFO - 2022-07-07 06:33:49 --> Router Class Initialized
INFO - 2022-07-07 06:33:49 --> Output Class Initialized
INFO - 2022-07-07 06:33:49 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:49 --> Input Class Initialized
INFO - 2022-07-07 06:33:49 --> Language Class Initialized
INFO - 2022-07-07 06:33:49 --> Language Class Initialized
INFO - 2022-07-07 06:33:49 --> Config Class Initialized
INFO - 2022-07-07 06:33:49 --> Loader Class Initialized
INFO - 2022-07-07 06:33:49 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:49 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:49 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:49 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:49 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:49 --> Controller Class Initialized
INFO - 2022-07-07 06:33:49 --> Config Class Initialized
INFO - 2022-07-07 06:33:49 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:49 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:49 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:49 --> URI Class Initialized
INFO - 2022-07-07 06:33:49 --> Router Class Initialized
INFO - 2022-07-07 06:33:49 --> Output Class Initialized
INFO - 2022-07-07 06:33:49 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:49 --> Input Class Initialized
INFO - 2022-07-07 06:33:49 --> Language Class Initialized
INFO - 2022-07-07 06:33:49 --> Language Class Initialized
INFO - 2022-07-07 06:33:49 --> Config Class Initialized
INFO - 2022-07-07 06:33:49 --> Loader Class Initialized
INFO - 2022-07-07 06:33:49 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:49 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:49 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:49 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:49 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:49 --> Controller Class Initialized
INFO - 2022-07-07 06:33:50 --> Config Class Initialized
INFO - 2022-07-07 06:33:50 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:50 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:50 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:50 --> URI Class Initialized
INFO - 2022-07-07 06:33:50 --> Router Class Initialized
INFO - 2022-07-07 06:33:50 --> Output Class Initialized
INFO - 2022-07-07 06:33:50 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:50 --> Input Class Initialized
INFO - 2022-07-07 06:33:50 --> Language Class Initialized
INFO - 2022-07-07 06:33:50 --> Language Class Initialized
INFO - 2022-07-07 06:33:50 --> Config Class Initialized
INFO - 2022-07-07 06:33:50 --> Loader Class Initialized
INFO - 2022-07-07 06:33:50 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:50 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:50 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:50 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:50 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:50 --> Controller Class Initialized
INFO - 2022-07-07 06:33:52 --> Config Class Initialized
INFO - 2022-07-07 06:33:52 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:52 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:52 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:52 --> URI Class Initialized
INFO - 2022-07-07 06:33:52 --> Router Class Initialized
INFO - 2022-07-07 06:33:52 --> Output Class Initialized
INFO - 2022-07-07 06:33:52 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:52 --> Input Class Initialized
INFO - 2022-07-07 06:33:52 --> Language Class Initialized
INFO - 2022-07-07 06:33:52 --> Language Class Initialized
INFO - 2022-07-07 06:33:52 --> Config Class Initialized
INFO - 2022-07-07 06:33:52 --> Loader Class Initialized
INFO - 2022-07-07 06:33:52 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:52 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:52 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:52 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:52 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:52 --> Controller Class Initialized
INFO - 2022-07-07 06:33:53 --> Config Class Initialized
INFO - 2022-07-07 06:33:53 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:53 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:53 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:53 --> URI Class Initialized
INFO - 2022-07-07 06:33:53 --> Router Class Initialized
INFO - 2022-07-07 06:33:53 --> Output Class Initialized
INFO - 2022-07-07 06:33:53 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:53 --> Input Class Initialized
INFO - 2022-07-07 06:33:53 --> Language Class Initialized
INFO - 2022-07-07 06:33:53 --> Language Class Initialized
INFO - 2022-07-07 06:33:53 --> Config Class Initialized
INFO - 2022-07-07 06:33:53 --> Loader Class Initialized
INFO - 2022-07-07 06:33:53 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:53 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:53 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:53 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:53 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:53 --> Controller Class Initialized
INFO - 2022-07-07 06:33:54 --> Config Class Initialized
INFO - 2022-07-07 06:33:54 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:54 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:54 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:54 --> URI Class Initialized
INFO - 2022-07-07 06:33:54 --> Router Class Initialized
INFO - 2022-07-07 06:33:54 --> Output Class Initialized
INFO - 2022-07-07 06:33:54 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:54 --> Input Class Initialized
INFO - 2022-07-07 06:33:54 --> Language Class Initialized
INFO - 2022-07-07 06:33:54 --> Language Class Initialized
INFO - 2022-07-07 06:33:54 --> Config Class Initialized
INFO - 2022-07-07 06:33:54 --> Loader Class Initialized
INFO - 2022-07-07 06:33:54 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:54 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:54 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:54 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:54 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:54 --> Controller Class Initialized
INFO - 2022-07-07 06:33:54 --> Config Class Initialized
INFO - 2022-07-07 06:33:54 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:54 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:54 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:54 --> URI Class Initialized
INFO - 2022-07-07 06:33:54 --> Router Class Initialized
INFO - 2022-07-07 06:33:54 --> Output Class Initialized
INFO - 2022-07-07 06:33:54 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:54 --> Input Class Initialized
INFO - 2022-07-07 06:33:54 --> Language Class Initialized
INFO - 2022-07-07 06:33:54 --> Language Class Initialized
INFO - 2022-07-07 06:33:54 --> Config Class Initialized
INFO - 2022-07-07 06:33:54 --> Loader Class Initialized
INFO - 2022-07-07 06:33:54 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:54 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:54 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:54 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:54 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:54 --> Controller Class Initialized
INFO - 2022-07-07 06:33:54 --> Config Class Initialized
INFO - 2022-07-07 06:33:54 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:54 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:54 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:54 --> URI Class Initialized
INFO - 2022-07-07 06:33:54 --> Router Class Initialized
INFO - 2022-07-07 06:33:54 --> Output Class Initialized
INFO - 2022-07-07 06:33:54 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:54 --> Input Class Initialized
INFO - 2022-07-07 06:33:54 --> Language Class Initialized
INFO - 2022-07-07 06:33:54 --> Language Class Initialized
INFO - 2022-07-07 06:33:54 --> Config Class Initialized
INFO - 2022-07-07 06:33:54 --> Loader Class Initialized
INFO - 2022-07-07 06:33:54 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:54 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:54 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:54 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:54 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:54 --> Controller Class Initialized
INFO - 2022-07-07 06:33:55 --> Config Class Initialized
INFO - 2022-07-07 06:33:55 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:55 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:55 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:55 --> URI Class Initialized
INFO - 2022-07-07 06:33:55 --> Router Class Initialized
INFO - 2022-07-07 06:33:55 --> Output Class Initialized
INFO - 2022-07-07 06:33:55 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:55 --> Input Class Initialized
INFO - 2022-07-07 06:33:55 --> Language Class Initialized
INFO - 2022-07-07 06:33:55 --> Language Class Initialized
INFO - 2022-07-07 06:33:55 --> Config Class Initialized
INFO - 2022-07-07 06:33:55 --> Loader Class Initialized
INFO - 2022-07-07 06:33:55 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:55 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:55 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:55 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:55 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:55 --> Controller Class Initialized
INFO - 2022-07-07 06:33:58 --> Config Class Initialized
INFO - 2022-07-07 06:33:58 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:58 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:58 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:58 --> URI Class Initialized
INFO - 2022-07-07 06:33:58 --> Router Class Initialized
INFO - 2022-07-07 06:33:58 --> Output Class Initialized
INFO - 2022-07-07 06:33:58 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:58 --> Input Class Initialized
INFO - 2022-07-07 06:33:58 --> Language Class Initialized
INFO - 2022-07-07 06:33:58 --> Language Class Initialized
INFO - 2022-07-07 06:33:58 --> Config Class Initialized
INFO - 2022-07-07 06:33:58 --> Loader Class Initialized
INFO - 2022-07-07 06:33:58 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:58 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:58 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:58 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:58 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:58 --> Controller Class Initialized
ERROR - 2022-07-07 06:33:58 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-07 06:33:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-07 06:33:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 06:33:58 --> Final output sent to browser
DEBUG - 2022-07-07 06:33:58 --> Total execution time: 0.1290
INFO - 2022-07-07 06:33:58 --> Config Class Initialized
INFO - 2022-07-07 06:33:58 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:33:58 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:33:58 --> Utf8 Class Initialized
INFO - 2022-07-07 06:33:58 --> URI Class Initialized
INFO - 2022-07-07 06:33:58 --> Router Class Initialized
INFO - 2022-07-07 06:33:58 --> Output Class Initialized
INFO - 2022-07-07 06:33:58 --> Security Class Initialized
DEBUG - 2022-07-07 06:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:33:58 --> Input Class Initialized
INFO - 2022-07-07 06:33:58 --> Language Class Initialized
INFO - 2022-07-07 06:33:58 --> Language Class Initialized
INFO - 2022-07-07 06:33:58 --> Config Class Initialized
INFO - 2022-07-07 06:33:58 --> Loader Class Initialized
INFO - 2022-07-07 06:33:58 --> Helper loaded: url_helper
INFO - 2022-07-07 06:33:58 --> Helper loaded: file_helper
INFO - 2022-07-07 06:33:58 --> Helper loaded: form_helper
INFO - 2022-07-07 06:33:58 --> Helper loaded: my_helper
INFO - 2022-07-07 06:33:58 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:33:58 --> Controller Class Initialized
ERROR - 2022-07-07 06:33:58 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-07 06:33:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-07 06:33:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 06:33:58 --> Final output sent to browser
DEBUG - 2022-07-07 06:33:58 --> Total execution time: 0.0458
INFO - 2022-07-07 06:35:26 --> Config Class Initialized
INFO - 2022-07-07 06:35:26 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:35:26 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:35:26 --> Utf8 Class Initialized
INFO - 2022-07-07 06:35:26 --> URI Class Initialized
INFO - 2022-07-07 06:35:26 --> Router Class Initialized
INFO - 2022-07-07 06:35:26 --> Output Class Initialized
INFO - 2022-07-07 06:35:26 --> Security Class Initialized
DEBUG - 2022-07-07 06:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:35:26 --> Input Class Initialized
INFO - 2022-07-07 06:35:26 --> Language Class Initialized
INFO - 2022-07-07 06:35:26 --> Language Class Initialized
INFO - 2022-07-07 06:35:26 --> Config Class Initialized
INFO - 2022-07-07 06:35:26 --> Loader Class Initialized
INFO - 2022-07-07 06:35:26 --> Helper loaded: url_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: file_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: form_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: my_helper
INFO - 2022-07-07 06:35:26 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:35:26 --> Controller Class Initialized
INFO - 2022-07-07 06:35:26 --> Upload Class Initialized
INFO - 2022-07-07 06:35:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-07 06:35:26 --> The upload path does not appear to be valid.
INFO - 2022-07-07 06:35:26 --> Config Class Initialized
INFO - 2022-07-07 06:35:26 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:35:26 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:35:26 --> Utf8 Class Initialized
INFO - 2022-07-07 06:35:26 --> URI Class Initialized
INFO - 2022-07-07 06:35:26 --> Router Class Initialized
INFO - 2022-07-07 06:35:26 --> Output Class Initialized
INFO - 2022-07-07 06:35:26 --> Security Class Initialized
DEBUG - 2022-07-07 06:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:35:26 --> Input Class Initialized
INFO - 2022-07-07 06:35:26 --> Language Class Initialized
INFO - 2022-07-07 06:35:26 --> Language Class Initialized
INFO - 2022-07-07 06:35:26 --> Config Class Initialized
INFO - 2022-07-07 06:35:26 --> Loader Class Initialized
INFO - 2022-07-07 06:35:26 --> Helper loaded: url_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: file_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: form_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: my_helper
INFO - 2022-07-07 06:35:26 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:35:26 --> Controller Class Initialized
INFO - 2022-07-07 06:35:26 --> Upload Class Initialized
INFO - 2022-07-07 06:35:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-07 06:35:26 --> The upload path does not appear to be valid.
INFO - 2022-07-07 06:35:26 --> Config Class Initialized
INFO - 2022-07-07 06:35:26 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:35:26 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:35:26 --> Utf8 Class Initialized
INFO - 2022-07-07 06:35:26 --> URI Class Initialized
INFO - 2022-07-07 06:35:26 --> Router Class Initialized
INFO - 2022-07-07 06:35:26 --> Output Class Initialized
INFO - 2022-07-07 06:35:26 --> Security Class Initialized
DEBUG - 2022-07-07 06:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:35:26 --> Input Class Initialized
INFO - 2022-07-07 06:35:26 --> Language Class Initialized
INFO - 2022-07-07 06:35:26 --> Language Class Initialized
INFO - 2022-07-07 06:35:26 --> Config Class Initialized
INFO - 2022-07-07 06:35:26 --> Loader Class Initialized
INFO - 2022-07-07 06:35:26 --> Helper loaded: url_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: file_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: form_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: my_helper
INFO - 2022-07-07 06:35:26 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:35:26 --> Controller Class Initialized
DEBUG - 2022-07-07 06:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-07 06:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 06:35:26 --> Final output sent to browser
DEBUG - 2022-07-07 06:35:26 --> Total execution time: 0.0530
INFO - 2022-07-07 06:35:26 --> Config Class Initialized
INFO - 2022-07-07 06:35:26 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:35:26 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:35:26 --> Utf8 Class Initialized
INFO - 2022-07-07 06:35:26 --> URI Class Initialized
INFO - 2022-07-07 06:35:26 --> Router Class Initialized
INFO - 2022-07-07 06:35:26 --> Output Class Initialized
INFO - 2022-07-07 06:35:26 --> Security Class Initialized
DEBUG - 2022-07-07 06:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:35:26 --> Input Class Initialized
INFO - 2022-07-07 06:35:26 --> Language Class Initialized
INFO - 2022-07-07 06:35:26 --> Language Class Initialized
INFO - 2022-07-07 06:35:26 --> Config Class Initialized
INFO - 2022-07-07 06:35:26 --> Loader Class Initialized
INFO - 2022-07-07 06:35:26 --> Helper loaded: url_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: file_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: form_helper
INFO - 2022-07-07 06:35:26 --> Helper loaded: my_helper
INFO - 2022-07-07 06:35:26 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:35:26 --> Controller Class Initialized
INFO - 2022-07-07 06:59:16 --> Config Class Initialized
INFO - 2022-07-07 06:59:16 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:59:16 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:59:16 --> Utf8 Class Initialized
INFO - 2022-07-07 06:59:16 --> URI Class Initialized
INFO - 2022-07-07 06:59:16 --> Router Class Initialized
INFO - 2022-07-07 06:59:16 --> Output Class Initialized
INFO - 2022-07-07 06:59:16 --> Security Class Initialized
DEBUG - 2022-07-07 06:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:59:16 --> Input Class Initialized
INFO - 2022-07-07 06:59:16 --> Language Class Initialized
INFO - 2022-07-07 06:59:16 --> Language Class Initialized
INFO - 2022-07-07 06:59:16 --> Config Class Initialized
INFO - 2022-07-07 06:59:16 --> Loader Class Initialized
INFO - 2022-07-07 06:59:16 --> Helper loaded: url_helper
INFO - 2022-07-07 06:59:16 --> Helper loaded: file_helper
INFO - 2022-07-07 06:59:16 --> Helper loaded: form_helper
INFO - 2022-07-07 06:59:16 --> Helper loaded: my_helper
INFO - 2022-07-07 06:59:16 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:59:16 --> Controller Class Initialized
INFO - 2022-07-07 06:59:16 --> Config Class Initialized
INFO - 2022-07-07 06:59:16 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:59:16 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:59:16 --> Utf8 Class Initialized
INFO - 2022-07-07 06:59:16 --> URI Class Initialized
INFO - 2022-07-07 06:59:16 --> Router Class Initialized
INFO - 2022-07-07 06:59:16 --> Output Class Initialized
INFO - 2022-07-07 06:59:16 --> Security Class Initialized
DEBUG - 2022-07-07 06:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:59:16 --> Input Class Initialized
INFO - 2022-07-07 06:59:16 --> Language Class Initialized
INFO - 2022-07-07 06:59:16 --> Language Class Initialized
INFO - 2022-07-07 06:59:16 --> Config Class Initialized
INFO - 2022-07-07 06:59:16 --> Loader Class Initialized
INFO - 2022-07-07 06:59:16 --> Helper loaded: url_helper
INFO - 2022-07-07 06:59:16 --> Helper loaded: file_helper
INFO - 2022-07-07 06:59:16 --> Helper loaded: form_helper
INFO - 2022-07-07 06:59:16 --> Helper loaded: my_helper
INFO - 2022-07-07 06:59:16 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:59:16 --> Controller Class Initialized
INFO - 2022-07-07 06:59:49 --> Config Class Initialized
INFO - 2022-07-07 06:59:49 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:59:49 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:59:49 --> Utf8 Class Initialized
INFO - 2022-07-07 06:59:49 --> URI Class Initialized
INFO - 2022-07-07 06:59:49 --> Router Class Initialized
INFO - 2022-07-07 06:59:49 --> Output Class Initialized
INFO - 2022-07-07 06:59:49 --> Security Class Initialized
DEBUG - 2022-07-07 06:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:59:49 --> Input Class Initialized
INFO - 2022-07-07 06:59:49 --> Language Class Initialized
INFO - 2022-07-07 06:59:49 --> Language Class Initialized
INFO - 2022-07-07 06:59:49 --> Config Class Initialized
INFO - 2022-07-07 06:59:49 --> Loader Class Initialized
INFO - 2022-07-07 06:59:49 --> Helper loaded: url_helper
INFO - 2022-07-07 06:59:49 --> Helper loaded: file_helper
INFO - 2022-07-07 06:59:49 --> Helper loaded: form_helper
INFO - 2022-07-07 06:59:49 --> Helper loaded: my_helper
INFO - 2022-07-07 06:59:49 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:59:49 --> Controller Class Initialized
INFO - 2022-07-07 06:59:49 --> Config Class Initialized
INFO - 2022-07-07 06:59:49 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:59:49 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:59:49 --> Utf8 Class Initialized
INFO - 2022-07-07 06:59:49 --> URI Class Initialized
INFO - 2022-07-07 06:59:49 --> Router Class Initialized
INFO - 2022-07-07 06:59:49 --> Output Class Initialized
INFO - 2022-07-07 06:59:49 --> Security Class Initialized
DEBUG - 2022-07-07 06:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:59:49 --> Input Class Initialized
INFO - 2022-07-07 06:59:49 --> Language Class Initialized
INFO - 2022-07-07 06:59:49 --> Language Class Initialized
INFO - 2022-07-07 06:59:49 --> Config Class Initialized
INFO - 2022-07-07 06:59:49 --> Loader Class Initialized
INFO - 2022-07-07 06:59:49 --> Helper loaded: url_helper
INFO - 2022-07-07 06:59:49 --> Helper loaded: file_helper
INFO - 2022-07-07 06:59:49 --> Helper loaded: form_helper
INFO - 2022-07-07 06:59:49 --> Helper loaded: my_helper
INFO - 2022-07-07 06:59:49 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:59:49 --> Controller Class Initialized
INFO - 2022-07-07 06:59:50 --> Config Class Initialized
INFO - 2022-07-07 06:59:50 --> Hooks Class Initialized
DEBUG - 2022-07-07 06:59:50 --> UTF-8 Support Enabled
INFO - 2022-07-07 06:59:50 --> Utf8 Class Initialized
INFO - 2022-07-07 06:59:50 --> URI Class Initialized
INFO - 2022-07-07 06:59:50 --> Router Class Initialized
INFO - 2022-07-07 06:59:50 --> Output Class Initialized
INFO - 2022-07-07 06:59:50 --> Security Class Initialized
DEBUG - 2022-07-07 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 06:59:50 --> Input Class Initialized
INFO - 2022-07-07 06:59:50 --> Language Class Initialized
INFO - 2022-07-07 06:59:50 --> Language Class Initialized
INFO - 2022-07-07 06:59:50 --> Config Class Initialized
INFO - 2022-07-07 06:59:50 --> Loader Class Initialized
INFO - 2022-07-07 06:59:50 --> Helper loaded: url_helper
INFO - 2022-07-07 06:59:50 --> Helper loaded: file_helper
INFO - 2022-07-07 06:59:50 --> Helper loaded: form_helper
INFO - 2022-07-07 06:59:50 --> Helper loaded: my_helper
INFO - 2022-07-07 06:59:50 --> Database Driver Class Initialized
DEBUG - 2022-07-07 06:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 06:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 06:59:50 --> Controller Class Initialized
INFO - 2022-07-07 07:00:02 --> Config Class Initialized
INFO - 2022-07-07 07:00:02 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:02 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:02 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:02 --> URI Class Initialized
INFO - 2022-07-07 07:00:02 --> Router Class Initialized
INFO - 2022-07-07 07:00:02 --> Output Class Initialized
INFO - 2022-07-07 07:00:02 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:02 --> Input Class Initialized
INFO - 2022-07-07 07:00:02 --> Language Class Initialized
INFO - 2022-07-07 07:00:02 --> Language Class Initialized
INFO - 2022-07-07 07:00:02 --> Config Class Initialized
INFO - 2022-07-07 07:00:02 --> Loader Class Initialized
INFO - 2022-07-07 07:00:02 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:02 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:02 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:02 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:02 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:02 --> Controller Class Initialized
INFO - 2022-07-07 07:00:02 --> Config Class Initialized
INFO - 2022-07-07 07:00:02 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:02 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:02 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:02 --> URI Class Initialized
INFO - 2022-07-07 07:00:02 --> Router Class Initialized
INFO - 2022-07-07 07:00:02 --> Output Class Initialized
INFO - 2022-07-07 07:00:02 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:02 --> Input Class Initialized
INFO - 2022-07-07 07:00:02 --> Language Class Initialized
INFO - 2022-07-07 07:00:02 --> Language Class Initialized
INFO - 2022-07-07 07:00:02 --> Config Class Initialized
INFO - 2022-07-07 07:00:02 --> Loader Class Initialized
INFO - 2022-07-07 07:00:02 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:02 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:02 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:02 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:02 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:02 --> Controller Class Initialized
INFO - 2022-07-07 07:00:03 --> Config Class Initialized
INFO - 2022-07-07 07:00:03 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:03 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:03 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:03 --> URI Class Initialized
INFO - 2022-07-07 07:00:03 --> Router Class Initialized
INFO - 2022-07-07 07:00:03 --> Output Class Initialized
INFO - 2022-07-07 07:00:03 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:03 --> Input Class Initialized
INFO - 2022-07-07 07:00:03 --> Language Class Initialized
INFO - 2022-07-07 07:00:03 --> Language Class Initialized
INFO - 2022-07-07 07:00:03 --> Config Class Initialized
INFO - 2022-07-07 07:00:03 --> Loader Class Initialized
INFO - 2022-07-07 07:00:03 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:03 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:03 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:03 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:03 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:03 --> Controller Class Initialized
INFO - 2022-07-07 07:00:03 --> Config Class Initialized
INFO - 2022-07-07 07:00:03 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:03 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:03 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:03 --> URI Class Initialized
INFO - 2022-07-07 07:00:03 --> Router Class Initialized
INFO - 2022-07-07 07:00:03 --> Output Class Initialized
INFO - 2022-07-07 07:00:03 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:03 --> Input Class Initialized
INFO - 2022-07-07 07:00:03 --> Language Class Initialized
INFO - 2022-07-07 07:00:03 --> Language Class Initialized
INFO - 2022-07-07 07:00:03 --> Config Class Initialized
INFO - 2022-07-07 07:00:03 --> Loader Class Initialized
INFO - 2022-07-07 07:00:03 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:03 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:03 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:03 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:03 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:03 --> Controller Class Initialized
INFO - 2022-07-07 07:00:04 --> Config Class Initialized
INFO - 2022-07-07 07:00:04 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:04 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:04 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:04 --> URI Class Initialized
INFO - 2022-07-07 07:00:04 --> Router Class Initialized
INFO - 2022-07-07 07:00:04 --> Output Class Initialized
INFO - 2022-07-07 07:00:04 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:04 --> Input Class Initialized
INFO - 2022-07-07 07:00:04 --> Language Class Initialized
INFO - 2022-07-07 07:00:04 --> Language Class Initialized
INFO - 2022-07-07 07:00:04 --> Config Class Initialized
INFO - 2022-07-07 07:00:04 --> Loader Class Initialized
INFO - 2022-07-07 07:00:04 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:04 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:04 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:04 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:04 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:04 --> Controller Class Initialized
INFO - 2022-07-07 07:00:04 --> Config Class Initialized
INFO - 2022-07-07 07:00:04 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:04 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:04 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:04 --> URI Class Initialized
INFO - 2022-07-07 07:00:04 --> Router Class Initialized
INFO - 2022-07-07 07:00:04 --> Output Class Initialized
INFO - 2022-07-07 07:00:04 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:04 --> Input Class Initialized
INFO - 2022-07-07 07:00:04 --> Language Class Initialized
INFO - 2022-07-07 07:00:04 --> Language Class Initialized
INFO - 2022-07-07 07:00:04 --> Config Class Initialized
INFO - 2022-07-07 07:00:04 --> Loader Class Initialized
INFO - 2022-07-07 07:00:04 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:04 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:04 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:04 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:04 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:05 --> Controller Class Initialized
INFO - 2022-07-07 07:00:06 --> Config Class Initialized
INFO - 2022-07-07 07:00:06 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:06 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:06 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:06 --> URI Class Initialized
INFO - 2022-07-07 07:00:06 --> Router Class Initialized
INFO - 2022-07-07 07:00:06 --> Output Class Initialized
INFO - 2022-07-07 07:00:06 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:06 --> Input Class Initialized
INFO - 2022-07-07 07:00:06 --> Language Class Initialized
INFO - 2022-07-07 07:00:06 --> Language Class Initialized
INFO - 2022-07-07 07:00:06 --> Config Class Initialized
INFO - 2022-07-07 07:00:06 --> Loader Class Initialized
INFO - 2022-07-07 07:00:06 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:06 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:06 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:06 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:06 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:06 --> Controller Class Initialized
INFO - 2022-07-07 07:00:07 --> Config Class Initialized
INFO - 2022-07-07 07:00:07 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:07 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:07 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:07 --> URI Class Initialized
INFO - 2022-07-07 07:00:07 --> Router Class Initialized
INFO - 2022-07-07 07:00:07 --> Output Class Initialized
INFO - 2022-07-07 07:00:07 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:07 --> Input Class Initialized
INFO - 2022-07-07 07:00:07 --> Language Class Initialized
INFO - 2022-07-07 07:00:07 --> Language Class Initialized
INFO - 2022-07-07 07:00:07 --> Config Class Initialized
INFO - 2022-07-07 07:00:07 --> Loader Class Initialized
INFO - 2022-07-07 07:00:07 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:07 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:07 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:07 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:07 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:07 --> Controller Class Initialized
INFO - 2022-07-07 07:00:07 --> Config Class Initialized
INFO - 2022-07-07 07:00:07 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:07 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:07 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:07 --> URI Class Initialized
INFO - 2022-07-07 07:00:07 --> Router Class Initialized
INFO - 2022-07-07 07:00:07 --> Output Class Initialized
INFO - 2022-07-07 07:00:07 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:07 --> Input Class Initialized
INFO - 2022-07-07 07:00:07 --> Language Class Initialized
INFO - 2022-07-07 07:00:07 --> Language Class Initialized
INFO - 2022-07-07 07:00:07 --> Config Class Initialized
INFO - 2022-07-07 07:00:07 --> Loader Class Initialized
INFO - 2022-07-07 07:00:07 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:07 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:07 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:07 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:07 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:07 --> Controller Class Initialized
INFO - 2022-07-07 07:00:24 --> Config Class Initialized
INFO - 2022-07-07 07:00:24 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:24 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:24 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:24 --> URI Class Initialized
INFO - 2022-07-07 07:00:24 --> Router Class Initialized
INFO - 2022-07-07 07:00:24 --> Output Class Initialized
INFO - 2022-07-07 07:00:24 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:24 --> Input Class Initialized
INFO - 2022-07-07 07:00:24 --> Language Class Initialized
INFO - 2022-07-07 07:00:24 --> Language Class Initialized
INFO - 2022-07-07 07:00:24 --> Config Class Initialized
INFO - 2022-07-07 07:00:24 --> Loader Class Initialized
INFO - 2022-07-07 07:00:24 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:24 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:24 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:24 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:24 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:24 --> Controller Class Initialized
INFO - 2022-07-07 07:00:24 --> Helper loaded: cookie_helper
INFO - 2022-07-07 07:00:24 --> Config Class Initialized
INFO - 2022-07-07 07:00:24 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:00:24 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:00:24 --> Utf8 Class Initialized
INFO - 2022-07-07 07:00:24 --> URI Class Initialized
INFO - 2022-07-07 07:00:24 --> Router Class Initialized
INFO - 2022-07-07 07:00:24 --> Output Class Initialized
INFO - 2022-07-07 07:00:24 --> Security Class Initialized
DEBUG - 2022-07-07 07:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:00:24 --> Input Class Initialized
INFO - 2022-07-07 07:00:24 --> Language Class Initialized
INFO - 2022-07-07 07:00:24 --> Language Class Initialized
INFO - 2022-07-07 07:00:24 --> Config Class Initialized
INFO - 2022-07-07 07:00:24 --> Loader Class Initialized
INFO - 2022-07-07 07:00:24 --> Helper loaded: url_helper
INFO - 2022-07-07 07:00:24 --> Helper loaded: file_helper
INFO - 2022-07-07 07:00:24 --> Helper loaded: form_helper
INFO - 2022-07-07 07:00:24 --> Helper loaded: my_helper
INFO - 2022-07-07 07:00:24 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:00:24 --> Controller Class Initialized
DEBUG - 2022-07-07 07:00:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-07 07:00:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:00:24 --> Final output sent to browser
DEBUG - 2022-07-07 07:00:24 --> Total execution time: 0.0548
INFO - 2022-07-07 07:01:53 --> Config Class Initialized
INFO - 2022-07-07 07:01:53 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:01:53 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:01:53 --> Utf8 Class Initialized
INFO - 2022-07-07 07:01:53 --> URI Class Initialized
INFO - 2022-07-07 07:01:53 --> Router Class Initialized
INFO - 2022-07-07 07:01:53 --> Output Class Initialized
INFO - 2022-07-07 07:01:53 --> Security Class Initialized
DEBUG - 2022-07-07 07:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:01:53 --> Input Class Initialized
INFO - 2022-07-07 07:01:53 --> Language Class Initialized
INFO - 2022-07-07 07:01:53 --> Language Class Initialized
INFO - 2022-07-07 07:01:53 --> Config Class Initialized
INFO - 2022-07-07 07:01:53 --> Loader Class Initialized
INFO - 2022-07-07 07:01:53 --> Helper loaded: url_helper
INFO - 2022-07-07 07:01:53 --> Helper loaded: file_helper
INFO - 2022-07-07 07:01:53 --> Helper loaded: form_helper
INFO - 2022-07-07 07:01:53 --> Helper loaded: my_helper
INFO - 2022-07-07 07:01:53 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:01:53 --> Controller Class Initialized
INFO - 2022-07-07 07:01:53 --> Helper loaded: cookie_helper
INFO - 2022-07-07 07:01:53 --> Final output sent to browser
DEBUG - 2022-07-07 07:01:53 --> Total execution time: 0.0636
INFO - 2022-07-07 07:01:53 --> Config Class Initialized
INFO - 2022-07-07 07:01:53 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:01:53 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:01:53 --> Utf8 Class Initialized
INFO - 2022-07-07 07:01:53 --> URI Class Initialized
INFO - 2022-07-07 07:01:53 --> Router Class Initialized
INFO - 2022-07-07 07:01:53 --> Output Class Initialized
INFO - 2022-07-07 07:01:53 --> Security Class Initialized
DEBUG - 2022-07-07 07:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:01:53 --> Input Class Initialized
INFO - 2022-07-07 07:01:53 --> Language Class Initialized
INFO - 2022-07-07 07:01:53 --> Language Class Initialized
INFO - 2022-07-07 07:01:53 --> Config Class Initialized
INFO - 2022-07-07 07:01:53 --> Loader Class Initialized
INFO - 2022-07-07 07:01:53 --> Helper loaded: url_helper
INFO - 2022-07-07 07:01:53 --> Helper loaded: file_helper
INFO - 2022-07-07 07:01:53 --> Helper loaded: form_helper
INFO - 2022-07-07 07:01:53 --> Helper loaded: my_helper
INFO - 2022-07-07 07:01:53 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:01:53 --> Controller Class Initialized
DEBUG - 2022-07-07 07:01:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-07 07:01:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:01:54 --> Final output sent to browser
DEBUG - 2022-07-07 07:01:54 --> Total execution time: 0.5376
INFO - 2022-07-07 07:02:23 --> Config Class Initialized
INFO - 2022-07-07 07:02:23 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:02:23 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:02:23 --> Utf8 Class Initialized
INFO - 2022-07-07 07:02:23 --> URI Class Initialized
INFO - 2022-07-07 07:02:23 --> Router Class Initialized
INFO - 2022-07-07 07:02:23 --> Output Class Initialized
INFO - 2022-07-07 07:02:23 --> Security Class Initialized
DEBUG - 2022-07-07 07:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:02:23 --> Input Class Initialized
INFO - 2022-07-07 07:02:23 --> Language Class Initialized
INFO - 2022-07-07 07:02:23 --> Language Class Initialized
INFO - 2022-07-07 07:02:23 --> Config Class Initialized
INFO - 2022-07-07 07:02:23 --> Loader Class Initialized
INFO - 2022-07-07 07:02:23 --> Helper loaded: url_helper
INFO - 2022-07-07 07:02:23 --> Helper loaded: file_helper
INFO - 2022-07-07 07:02:23 --> Helper loaded: form_helper
INFO - 2022-07-07 07:02:23 --> Helper loaded: my_helper
INFO - 2022-07-07 07:02:23 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:02:23 --> Controller Class Initialized
DEBUG - 2022-07-07 07:02:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-07 07:02:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:02:23 --> Final output sent to browser
DEBUG - 2022-07-07 07:02:23 --> Total execution time: 0.0866
INFO - 2022-07-07 07:02:27 --> Config Class Initialized
INFO - 2022-07-07 07:02:27 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:02:27 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:02:27 --> Utf8 Class Initialized
INFO - 2022-07-07 07:02:27 --> URI Class Initialized
INFO - 2022-07-07 07:02:27 --> Router Class Initialized
INFO - 2022-07-07 07:02:27 --> Output Class Initialized
INFO - 2022-07-07 07:02:27 --> Security Class Initialized
DEBUG - 2022-07-07 07:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:02:27 --> Input Class Initialized
INFO - 2022-07-07 07:02:27 --> Language Class Initialized
INFO - 2022-07-07 07:02:27 --> Language Class Initialized
INFO - 2022-07-07 07:02:27 --> Config Class Initialized
INFO - 2022-07-07 07:02:27 --> Loader Class Initialized
INFO - 2022-07-07 07:02:27 --> Helper loaded: url_helper
INFO - 2022-07-07 07:02:27 --> Helper loaded: file_helper
INFO - 2022-07-07 07:02:27 --> Helper loaded: form_helper
INFO - 2022-07-07 07:02:27 --> Helper loaded: my_helper
INFO - 2022-07-07 07:02:27 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:02:27 --> Controller Class Initialized
DEBUG - 2022-07-07 07:02:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:02:27 --> Final output sent to browser
DEBUG - 2022-07-07 07:02:27 --> Total execution time: 0.3180
INFO - 2022-07-07 07:11:55 --> Config Class Initialized
INFO - 2022-07-07 07:11:55 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:11:55 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:11:55 --> Utf8 Class Initialized
INFO - 2022-07-07 07:11:55 --> URI Class Initialized
INFO - 2022-07-07 07:11:55 --> Router Class Initialized
INFO - 2022-07-07 07:11:55 --> Output Class Initialized
INFO - 2022-07-07 07:11:55 --> Security Class Initialized
DEBUG - 2022-07-07 07:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:11:55 --> Input Class Initialized
INFO - 2022-07-07 07:11:55 --> Language Class Initialized
INFO - 2022-07-07 07:11:56 --> Language Class Initialized
INFO - 2022-07-07 07:11:56 --> Config Class Initialized
INFO - 2022-07-07 07:11:56 --> Loader Class Initialized
INFO - 2022-07-07 07:11:56 --> Helper loaded: url_helper
INFO - 2022-07-07 07:11:56 --> Helper loaded: file_helper
INFO - 2022-07-07 07:11:56 --> Helper loaded: form_helper
INFO - 2022-07-07 07:11:56 --> Helper loaded: my_helper
INFO - 2022-07-07 07:11:56 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:11:56 --> Controller Class Initialized
DEBUG - 2022-07-07 07:11:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-07 07:11:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:11:56 --> Final output sent to browser
DEBUG - 2022-07-07 07:11:56 --> Total execution time: 0.1299
INFO - 2022-07-07 07:12:00 --> Config Class Initialized
INFO - 2022-07-07 07:12:00 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:12:00 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:12:00 --> Utf8 Class Initialized
INFO - 2022-07-07 07:12:00 --> URI Class Initialized
INFO - 2022-07-07 07:12:00 --> Router Class Initialized
INFO - 2022-07-07 07:12:00 --> Output Class Initialized
INFO - 2022-07-07 07:12:00 --> Security Class Initialized
DEBUG - 2022-07-07 07:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:12:00 --> Input Class Initialized
INFO - 2022-07-07 07:12:00 --> Language Class Initialized
INFO - 2022-07-07 07:12:00 --> Language Class Initialized
INFO - 2022-07-07 07:12:00 --> Config Class Initialized
INFO - 2022-07-07 07:12:00 --> Loader Class Initialized
INFO - 2022-07-07 07:12:00 --> Helper loaded: url_helper
INFO - 2022-07-07 07:12:00 --> Helper loaded: file_helper
INFO - 2022-07-07 07:12:00 --> Helper loaded: form_helper
INFO - 2022-07-07 07:12:00 --> Helper loaded: my_helper
INFO - 2022-07-07 07:12:00 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:12:00 --> Controller Class Initialized
DEBUG - 2022-07-07 07:12:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:12:01 --> Final output sent to browser
DEBUG - 2022-07-07 07:12:01 --> Total execution time: 0.2722
INFO - 2022-07-07 07:12:03 --> Config Class Initialized
INFO - 2022-07-07 07:12:03 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:12:03 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:12:03 --> Utf8 Class Initialized
INFO - 2022-07-07 07:12:03 --> URI Class Initialized
INFO - 2022-07-07 07:12:03 --> Router Class Initialized
INFO - 2022-07-07 07:12:03 --> Output Class Initialized
INFO - 2022-07-07 07:12:03 --> Security Class Initialized
DEBUG - 2022-07-07 07:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:12:03 --> Input Class Initialized
INFO - 2022-07-07 07:12:03 --> Language Class Initialized
INFO - 2022-07-07 07:12:03 --> Language Class Initialized
INFO - 2022-07-07 07:12:03 --> Config Class Initialized
INFO - 2022-07-07 07:12:03 --> Loader Class Initialized
INFO - 2022-07-07 07:12:03 --> Helper loaded: url_helper
INFO - 2022-07-07 07:12:03 --> Helper loaded: file_helper
INFO - 2022-07-07 07:12:03 --> Helper loaded: form_helper
INFO - 2022-07-07 07:12:03 --> Helper loaded: my_helper
INFO - 2022-07-07 07:12:03 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:12:03 --> Controller Class Initialized
DEBUG - 2022-07-07 07:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:12:03 --> Final output sent to browser
DEBUG - 2022-07-07 07:12:03 --> Total execution time: 0.2188
INFO - 2022-07-07 07:12:31 --> Config Class Initialized
INFO - 2022-07-07 07:12:31 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:12:31 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:12:31 --> Utf8 Class Initialized
INFO - 2022-07-07 07:12:31 --> URI Class Initialized
INFO - 2022-07-07 07:12:31 --> Router Class Initialized
INFO - 2022-07-07 07:12:31 --> Output Class Initialized
INFO - 2022-07-07 07:12:31 --> Security Class Initialized
DEBUG - 2022-07-07 07:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:12:31 --> Input Class Initialized
INFO - 2022-07-07 07:12:31 --> Language Class Initialized
INFO - 2022-07-07 07:12:31 --> Language Class Initialized
INFO - 2022-07-07 07:12:31 --> Config Class Initialized
INFO - 2022-07-07 07:12:31 --> Loader Class Initialized
INFO - 2022-07-07 07:12:31 --> Helper loaded: url_helper
INFO - 2022-07-07 07:12:31 --> Helper loaded: file_helper
INFO - 2022-07-07 07:12:31 --> Helper loaded: form_helper
INFO - 2022-07-07 07:12:31 --> Helper loaded: my_helper
INFO - 2022-07-07 07:12:31 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:12:31 --> Controller Class Initialized
DEBUG - 2022-07-07 07:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:12:31 --> Final output sent to browser
DEBUG - 2022-07-07 07:12:31 --> Total execution time: 0.1442
INFO - 2022-07-07 07:12:45 --> Config Class Initialized
INFO - 2022-07-07 07:12:45 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:12:45 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:12:45 --> Utf8 Class Initialized
INFO - 2022-07-07 07:12:45 --> URI Class Initialized
INFO - 2022-07-07 07:12:45 --> Router Class Initialized
INFO - 2022-07-07 07:12:45 --> Output Class Initialized
INFO - 2022-07-07 07:12:45 --> Security Class Initialized
DEBUG - 2022-07-07 07:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:12:45 --> Input Class Initialized
INFO - 2022-07-07 07:12:45 --> Language Class Initialized
INFO - 2022-07-07 07:12:45 --> Language Class Initialized
INFO - 2022-07-07 07:12:45 --> Config Class Initialized
INFO - 2022-07-07 07:12:45 --> Loader Class Initialized
INFO - 2022-07-07 07:12:45 --> Helper loaded: url_helper
INFO - 2022-07-07 07:12:45 --> Helper loaded: file_helper
INFO - 2022-07-07 07:12:45 --> Helper loaded: form_helper
INFO - 2022-07-07 07:12:45 --> Helper loaded: my_helper
INFO - 2022-07-07 07:12:45 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:12:45 --> Controller Class Initialized
DEBUG - 2022-07-07 07:12:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:12:45 --> Final output sent to browser
DEBUG - 2022-07-07 07:12:45 --> Total execution time: 0.1816
INFO - 2022-07-07 07:12:48 --> Config Class Initialized
INFO - 2022-07-07 07:12:48 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:12:48 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:12:48 --> Utf8 Class Initialized
INFO - 2022-07-07 07:12:48 --> URI Class Initialized
INFO - 2022-07-07 07:12:48 --> Router Class Initialized
INFO - 2022-07-07 07:12:48 --> Output Class Initialized
INFO - 2022-07-07 07:12:48 --> Security Class Initialized
DEBUG - 2022-07-07 07:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:12:48 --> Input Class Initialized
INFO - 2022-07-07 07:12:48 --> Language Class Initialized
INFO - 2022-07-07 07:12:48 --> Language Class Initialized
INFO - 2022-07-07 07:12:48 --> Config Class Initialized
INFO - 2022-07-07 07:12:48 --> Loader Class Initialized
INFO - 2022-07-07 07:12:48 --> Helper loaded: url_helper
INFO - 2022-07-07 07:12:48 --> Helper loaded: file_helper
INFO - 2022-07-07 07:12:48 --> Helper loaded: form_helper
INFO - 2022-07-07 07:12:48 --> Helper loaded: my_helper
INFO - 2022-07-07 07:12:48 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:12:48 --> Controller Class Initialized
DEBUG - 2022-07-07 07:12:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:12:48 --> Final output sent to browser
DEBUG - 2022-07-07 07:12:48 --> Total execution time: 0.1450
INFO - 2022-07-07 07:12:51 --> Config Class Initialized
INFO - 2022-07-07 07:12:51 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:12:51 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:12:51 --> Utf8 Class Initialized
INFO - 2022-07-07 07:12:51 --> URI Class Initialized
INFO - 2022-07-07 07:12:51 --> Router Class Initialized
INFO - 2022-07-07 07:12:51 --> Output Class Initialized
INFO - 2022-07-07 07:12:51 --> Security Class Initialized
DEBUG - 2022-07-07 07:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:12:51 --> Input Class Initialized
INFO - 2022-07-07 07:12:51 --> Language Class Initialized
INFO - 2022-07-07 07:12:51 --> Language Class Initialized
INFO - 2022-07-07 07:12:51 --> Config Class Initialized
INFO - 2022-07-07 07:12:51 --> Loader Class Initialized
INFO - 2022-07-07 07:12:51 --> Helper loaded: url_helper
INFO - 2022-07-07 07:12:51 --> Helper loaded: file_helper
INFO - 2022-07-07 07:12:51 --> Helper loaded: form_helper
INFO - 2022-07-07 07:12:51 --> Helper loaded: my_helper
INFO - 2022-07-07 07:12:51 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:12:51 --> Controller Class Initialized
DEBUG - 2022-07-07 07:12:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:12:51 --> Final output sent to browser
DEBUG - 2022-07-07 07:12:51 --> Total execution time: 0.1505
INFO - 2022-07-07 07:12:53 --> Config Class Initialized
INFO - 2022-07-07 07:12:53 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:12:53 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:12:53 --> Utf8 Class Initialized
INFO - 2022-07-07 07:12:53 --> URI Class Initialized
INFO - 2022-07-07 07:12:53 --> Router Class Initialized
INFO - 2022-07-07 07:12:53 --> Output Class Initialized
INFO - 2022-07-07 07:12:53 --> Security Class Initialized
DEBUG - 2022-07-07 07:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:12:53 --> Input Class Initialized
INFO - 2022-07-07 07:12:53 --> Language Class Initialized
INFO - 2022-07-07 07:12:53 --> Language Class Initialized
INFO - 2022-07-07 07:12:53 --> Config Class Initialized
INFO - 2022-07-07 07:12:53 --> Loader Class Initialized
INFO - 2022-07-07 07:12:53 --> Helper loaded: url_helper
INFO - 2022-07-07 07:12:53 --> Helper loaded: file_helper
INFO - 2022-07-07 07:12:53 --> Helper loaded: form_helper
INFO - 2022-07-07 07:12:53 --> Helper loaded: my_helper
INFO - 2022-07-07 07:12:53 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:12:53 --> Controller Class Initialized
DEBUG - 2022-07-07 07:12:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:12:53 --> Final output sent to browser
DEBUG - 2022-07-07 07:12:53 --> Total execution time: 0.1907
INFO - 2022-07-07 07:12:56 --> Config Class Initialized
INFO - 2022-07-07 07:12:56 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:12:56 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:12:56 --> Utf8 Class Initialized
INFO - 2022-07-07 07:12:56 --> URI Class Initialized
INFO - 2022-07-07 07:12:56 --> Router Class Initialized
INFO - 2022-07-07 07:12:56 --> Output Class Initialized
INFO - 2022-07-07 07:12:56 --> Security Class Initialized
DEBUG - 2022-07-07 07:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:12:56 --> Input Class Initialized
INFO - 2022-07-07 07:12:56 --> Language Class Initialized
INFO - 2022-07-07 07:12:56 --> Language Class Initialized
INFO - 2022-07-07 07:12:56 --> Config Class Initialized
INFO - 2022-07-07 07:12:56 --> Loader Class Initialized
INFO - 2022-07-07 07:12:56 --> Helper loaded: url_helper
INFO - 2022-07-07 07:12:56 --> Helper loaded: file_helper
INFO - 2022-07-07 07:12:56 --> Helper loaded: form_helper
INFO - 2022-07-07 07:12:56 --> Helper loaded: my_helper
INFO - 2022-07-07 07:12:56 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:12:56 --> Controller Class Initialized
DEBUG - 2022-07-07 07:12:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:12:56 --> Final output sent to browser
DEBUG - 2022-07-07 07:12:56 --> Total execution time: 0.1482
INFO - 2022-07-07 07:12:58 --> Config Class Initialized
INFO - 2022-07-07 07:12:58 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:12:58 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:12:58 --> Utf8 Class Initialized
INFO - 2022-07-07 07:12:58 --> URI Class Initialized
INFO - 2022-07-07 07:12:58 --> Router Class Initialized
INFO - 2022-07-07 07:12:58 --> Output Class Initialized
INFO - 2022-07-07 07:12:58 --> Security Class Initialized
DEBUG - 2022-07-07 07:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:12:58 --> Input Class Initialized
INFO - 2022-07-07 07:12:58 --> Language Class Initialized
INFO - 2022-07-07 07:12:58 --> Language Class Initialized
INFO - 2022-07-07 07:12:58 --> Config Class Initialized
INFO - 2022-07-07 07:12:58 --> Loader Class Initialized
INFO - 2022-07-07 07:12:58 --> Helper loaded: url_helper
INFO - 2022-07-07 07:12:58 --> Helper loaded: file_helper
INFO - 2022-07-07 07:12:58 --> Helper loaded: form_helper
INFO - 2022-07-07 07:12:58 --> Helper loaded: my_helper
INFO - 2022-07-07 07:12:58 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:12:58 --> Controller Class Initialized
DEBUG - 2022-07-07 07:12:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:12:58 --> Final output sent to browser
DEBUG - 2022-07-07 07:12:58 --> Total execution time: 0.1421
INFO - 2022-07-07 07:13:00 --> Config Class Initialized
INFO - 2022-07-07 07:13:00 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:00 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:00 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:00 --> URI Class Initialized
INFO - 2022-07-07 07:13:00 --> Router Class Initialized
INFO - 2022-07-07 07:13:00 --> Output Class Initialized
INFO - 2022-07-07 07:13:00 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:00 --> Input Class Initialized
INFO - 2022-07-07 07:13:00 --> Language Class Initialized
INFO - 2022-07-07 07:13:00 --> Language Class Initialized
INFO - 2022-07-07 07:13:00 --> Config Class Initialized
INFO - 2022-07-07 07:13:00 --> Loader Class Initialized
INFO - 2022-07-07 07:13:00 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:00 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:00 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:00 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:00 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:00 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:00 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:00 --> Total execution time: 0.1413
INFO - 2022-07-07 07:13:02 --> Config Class Initialized
INFO - 2022-07-07 07:13:02 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:02 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:02 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:02 --> URI Class Initialized
INFO - 2022-07-07 07:13:02 --> Router Class Initialized
INFO - 2022-07-07 07:13:02 --> Output Class Initialized
INFO - 2022-07-07 07:13:02 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:02 --> Input Class Initialized
INFO - 2022-07-07 07:13:02 --> Language Class Initialized
INFO - 2022-07-07 07:13:02 --> Language Class Initialized
INFO - 2022-07-07 07:13:02 --> Config Class Initialized
INFO - 2022-07-07 07:13:02 --> Loader Class Initialized
INFO - 2022-07-07 07:13:02 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:02 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:02 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:02 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:02 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:02 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:02 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:02 --> Total execution time: 0.1435
INFO - 2022-07-07 07:13:02 --> Config Class Initialized
INFO - 2022-07-07 07:13:02 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:02 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:02 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:02 --> URI Class Initialized
INFO - 2022-07-07 07:13:02 --> Router Class Initialized
INFO - 2022-07-07 07:13:02 --> Output Class Initialized
INFO - 2022-07-07 07:13:02 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:02 --> Input Class Initialized
INFO - 2022-07-07 07:13:02 --> Language Class Initialized
INFO - 2022-07-07 07:13:02 --> Language Class Initialized
INFO - 2022-07-07 07:13:02 --> Config Class Initialized
INFO - 2022-07-07 07:13:02 --> Loader Class Initialized
INFO - 2022-07-07 07:13:02 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:02 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:02 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:02 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:02 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:02 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:02 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:02 --> Total execution time: 0.1059
INFO - 2022-07-07 07:13:10 --> Config Class Initialized
INFO - 2022-07-07 07:13:10 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:10 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:10 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:10 --> URI Class Initialized
INFO - 2022-07-07 07:13:10 --> Router Class Initialized
INFO - 2022-07-07 07:13:10 --> Output Class Initialized
INFO - 2022-07-07 07:13:10 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:10 --> Input Class Initialized
INFO - 2022-07-07 07:13:10 --> Language Class Initialized
INFO - 2022-07-07 07:13:10 --> Language Class Initialized
INFO - 2022-07-07 07:13:10 --> Config Class Initialized
INFO - 2022-07-07 07:13:10 --> Loader Class Initialized
INFO - 2022-07-07 07:13:10 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:10 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:10 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:10 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:10 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:10 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:11 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:11 --> Total execution time: 0.1731
INFO - 2022-07-07 07:13:14 --> Config Class Initialized
INFO - 2022-07-07 07:13:14 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:14 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:14 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:14 --> URI Class Initialized
INFO - 2022-07-07 07:13:14 --> Router Class Initialized
INFO - 2022-07-07 07:13:14 --> Output Class Initialized
INFO - 2022-07-07 07:13:14 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:14 --> Input Class Initialized
INFO - 2022-07-07 07:13:14 --> Language Class Initialized
INFO - 2022-07-07 07:13:14 --> Language Class Initialized
INFO - 2022-07-07 07:13:14 --> Config Class Initialized
INFO - 2022-07-07 07:13:14 --> Loader Class Initialized
INFO - 2022-07-07 07:13:14 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:14 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:14 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:14 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:14 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:14 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:14 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:14 --> Total execution time: 0.1448
INFO - 2022-07-07 07:13:19 --> Config Class Initialized
INFO - 2022-07-07 07:13:19 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:19 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:19 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:19 --> URI Class Initialized
INFO - 2022-07-07 07:13:19 --> Router Class Initialized
INFO - 2022-07-07 07:13:19 --> Output Class Initialized
INFO - 2022-07-07 07:13:19 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:19 --> Input Class Initialized
INFO - 2022-07-07 07:13:19 --> Language Class Initialized
INFO - 2022-07-07 07:13:19 --> Language Class Initialized
INFO - 2022-07-07 07:13:19 --> Config Class Initialized
INFO - 2022-07-07 07:13:19 --> Loader Class Initialized
INFO - 2022-07-07 07:13:19 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:19 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:19 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:19 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:19 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:19 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:19 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:19 --> Total execution time: 0.1627
INFO - 2022-07-07 07:13:19 --> Config Class Initialized
INFO - 2022-07-07 07:13:19 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:19 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:19 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:19 --> URI Class Initialized
INFO - 2022-07-07 07:13:19 --> Router Class Initialized
INFO - 2022-07-07 07:13:19 --> Output Class Initialized
INFO - 2022-07-07 07:13:19 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:19 --> Input Class Initialized
INFO - 2022-07-07 07:13:19 --> Language Class Initialized
INFO - 2022-07-07 07:13:19 --> Language Class Initialized
INFO - 2022-07-07 07:13:19 --> Config Class Initialized
INFO - 2022-07-07 07:13:19 --> Loader Class Initialized
INFO - 2022-07-07 07:13:19 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:19 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:19 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:19 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:19 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:19 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:19 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:19 --> Total execution time: 0.1079
INFO - 2022-07-07 07:13:29 --> Config Class Initialized
INFO - 2022-07-07 07:13:29 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:29 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:29 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:29 --> URI Class Initialized
INFO - 2022-07-07 07:13:29 --> Router Class Initialized
INFO - 2022-07-07 07:13:29 --> Output Class Initialized
INFO - 2022-07-07 07:13:29 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:29 --> Input Class Initialized
INFO - 2022-07-07 07:13:29 --> Language Class Initialized
INFO - 2022-07-07 07:13:29 --> Language Class Initialized
INFO - 2022-07-07 07:13:29 --> Config Class Initialized
INFO - 2022-07-07 07:13:29 --> Loader Class Initialized
INFO - 2022-07-07 07:13:29 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:29 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:29 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:29 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:29 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:29 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:29 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:29 --> Total execution time: 0.1534
INFO - 2022-07-07 07:13:31 --> Config Class Initialized
INFO - 2022-07-07 07:13:31 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:31 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:31 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:31 --> URI Class Initialized
INFO - 2022-07-07 07:13:31 --> Router Class Initialized
INFO - 2022-07-07 07:13:31 --> Output Class Initialized
INFO - 2022-07-07 07:13:31 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:31 --> Input Class Initialized
INFO - 2022-07-07 07:13:31 --> Language Class Initialized
INFO - 2022-07-07 07:13:31 --> Language Class Initialized
INFO - 2022-07-07 07:13:31 --> Config Class Initialized
INFO - 2022-07-07 07:13:31 --> Loader Class Initialized
INFO - 2022-07-07 07:13:31 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:31 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:31 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:31 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:31 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:31 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:31 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:31 --> Total execution time: 0.1480
INFO - 2022-07-07 07:13:33 --> Config Class Initialized
INFO - 2022-07-07 07:13:33 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:33 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:33 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:33 --> URI Class Initialized
INFO - 2022-07-07 07:13:33 --> Router Class Initialized
INFO - 2022-07-07 07:13:33 --> Output Class Initialized
INFO - 2022-07-07 07:13:33 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:33 --> Input Class Initialized
INFO - 2022-07-07 07:13:33 --> Language Class Initialized
INFO - 2022-07-07 07:13:33 --> Language Class Initialized
INFO - 2022-07-07 07:13:33 --> Config Class Initialized
INFO - 2022-07-07 07:13:33 --> Loader Class Initialized
INFO - 2022-07-07 07:13:33 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:33 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:33 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:33 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:33 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:33 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:33 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:33 --> Total execution time: 0.1467
INFO - 2022-07-07 07:13:35 --> Config Class Initialized
INFO - 2022-07-07 07:13:35 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:35 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:35 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:35 --> URI Class Initialized
INFO - 2022-07-07 07:13:35 --> Router Class Initialized
INFO - 2022-07-07 07:13:35 --> Output Class Initialized
INFO - 2022-07-07 07:13:35 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:35 --> Input Class Initialized
INFO - 2022-07-07 07:13:35 --> Language Class Initialized
INFO - 2022-07-07 07:13:35 --> Language Class Initialized
INFO - 2022-07-07 07:13:35 --> Config Class Initialized
INFO - 2022-07-07 07:13:35 --> Loader Class Initialized
INFO - 2022-07-07 07:13:35 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:35 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:35 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:35 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:35 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:35 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:36 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:36 --> Total execution time: 0.1438
INFO - 2022-07-07 07:13:37 --> Config Class Initialized
INFO - 2022-07-07 07:13:37 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:37 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:37 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:37 --> URI Class Initialized
INFO - 2022-07-07 07:13:37 --> Router Class Initialized
INFO - 2022-07-07 07:13:37 --> Output Class Initialized
INFO - 2022-07-07 07:13:37 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:37 --> Input Class Initialized
INFO - 2022-07-07 07:13:37 --> Language Class Initialized
INFO - 2022-07-07 07:13:37 --> Language Class Initialized
INFO - 2022-07-07 07:13:37 --> Config Class Initialized
INFO - 2022-07-07 07:13:37 --> Loader Class Initialized
INFO - 2022-07-07 07:13:37 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:37 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:37 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:37 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:37 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:37 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:38 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:38 --> Total execution time: 0.1651
INFO - 2022-07-07 07:13:38 --> Config Class Initialized
INFO - 2022-07-07 07:13:38 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:38 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:38 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:38 --> URI Class Initialized
INFO - 2022-07-07 07:13:38 --> Router Class Initialized
INFO - 2022-07-07 07:13:38 --> Output Class Initialized
INFO - 2022-07-07 07:13:38 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:38 --> Input Class Initialized
INFO - 2022-07-07 07:13:38 --> Language Class Initialized
INFO - 2022-07-07 07:13:38 --> Language Class Initialized
INFO - 2022-07-07 07:13:38 --> Config Class Initialized
INFO - 2022-07-07 07:13:38 --> Loader Class Initialized
INFO - 2022-07-07 07:13:38 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:38 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:38 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:38 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:38 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:38 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2022-07-07 07:13:38 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:38 --> Total execution time: 0.1629
INFO - 2022-07-07 07:13:43 --> Config Class Initialized
INFO - 2022-07-07 07:13:43 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:43 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:43 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:43 --> URI Class Initialized
INFO - 2022-07-07 07:13:43 --> Router Class Initialized
INFO - 2022-07-07 07:13:43 --> Output Class Initialized
INFO - 2022-07-07 07:13:43 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:43 --> Input Class Initialized
INFO - 2022-07-07 07:13:43 --> Language Class Initialized
INFO - 2022-07-07 07:13:43 --> Language Class Initialized
INFO - 2022-07-07 07:13:43 --> Config Class Initialized
INFO - 2022-07-07 07:13:43 --> Loader Class Initialized
INFO - 2022-07-07 07:13:43 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:43 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:43 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:43 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:43 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:43 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:43 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:43 --> Total execution time: 0.1649
INFO - 2022-07-07 07:13:46 --> Config Class Initialized
INFO - 2022-07-07 07:13:46 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:46 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:46 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:46 --> URI Class Initialized
INFO - 2022-07-07 07:13:46 --> Router Class Initialized
INFO - 2022-07-07 07:13:46 --> Output Class Initialized
INFO - 2022-07-07 07:13:46 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:46 --> Input Class Initialized
INFO - 2022-07-07 07:13:46 --> Language Class Initialized
INFO - 2022-07-07 07:13:46 --> Language Class Initialized
INFO - 2022-07-07 07:13:46 --> Config Class Initialized
INFO - 2022-07-07 07:13:46 --> Loader Class Initialized
INFO - 2022-07-07 07:13:46 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:46 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:46 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:46 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:46 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:46 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:46 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:46 --> Total execution time: 0.1499
INFO - 2022-07-07 07:13:48 --> Config Class Initialized
INFO - 2022-07-07 07:13:48 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:48 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:48 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:48 --> URI Class Initialized
INFO - 2022-07-07 07:13:48 --> Router Class Initialized
INFO - 2022-07-07 07:13:48 --> Output Class Initialized
INFO - 2022-07-07 07:13:48 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:48 --> Input Class Initialized
INFO - 2022-07-07 07:13:48 --> Language Class Initialized
INFO - 2022-07-07 07:13:48 --> Language Class Initialized
INFO - 2022-07-07 07:13:48 --> Config Class Initialized
INFO - 2022-07-07 07:13:48 --> Loader Class Initialized
INFO - 2022-07-07 07:13:48 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:48 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:48 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:48 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:48 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:48 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:48 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:48 --> Total execution time: 0.1427
INFO - 2022-07-07 07:13:51 --> Config Class Initialized
INFO - 2022-07-07 07:13:51 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:51 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:51 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:51 --> URI Class Initialized
INFO - 2022-07-07 07:13:51 --> Router Class Initialized
INFO - 2022-07-07 07:13:51 --> Output Class Initialized
INFO - 2022-07-07 07:13:51 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:51 --> Input Class Initialized
INFO - 2022-07-07 07:13:51 --> Language Class Initialized
INFO - 2022-07-07 07:13:51 --> Language Class Initialized
INFO - 2022-07-07 07:13:51 --> Config Class Initialized
INFO - 2022-07-07 07:13:51 --> Loader Class Initialized
INFO - 2022-07-07 07:13:51 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:51 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:51 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:51 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:51 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:51 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:51 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:51 --> Total execution time: 0.1488
INFO - 2022-07-07 07:13:54 --> Config Class Initialized
INFO - 2022-07-07 07:13:54 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:13:54 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:13:54 --> Utf8 Class Initialized
INFO - 2022-07-07 07:13:54 --> URI Class Initialized
INFO - 2022-07-07 07:13:54 --> Router Class Initialized
INFO - 2022-07-07 07:13:54 --> Output Class Initialized
INFO - 2022-07-07 07:13:54 --> Security Class Initialized
DEBUG - 2022-07-07 07:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:13:54 --> Input Class Initialized
INFO - 2022-07-07 07:13:54 --> Language Class Initialized
INFO - 2022-07-07 07:13:54 --> Language Class Initialized
INFO - 2022-07-07 07:13:54 --> Config Class Initialized
INFO - 2022-07-07 07:13:54 --> Loader Class Initialized
INFO - 2022-07-07 07:13:54 --> Helper loaded: url_helper
INFO - 2022-07-07 07:13:54 --> Helper loaded: file_helper
INFO - 2022-07-07 07:13:54 --> Helper loaded: form_helper
INFO - 2022-07-07 07:13:54 --> Helper loaded: my_helper
INFO - 2022-07-07 07:13:54 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:13:54 --> Controller Class Initialized
DEBUG - 2022-07-07 07:13:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:13:54 --> Final output sent to browser
DEBUG - 2022-07-07 07:13:54 --> Total execution time: 0.1437
INFO - 2022-07-07 07:19:44 --> Config Class Initialized
INFO - 2022-07-07 07:19:44 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:19:44 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:19:44 --> Utf8 Class Initialized
INFO - 2022-07-07 07:19:44 --> URI Class Initialized
INFO - 2022-07-07 07:19:44 --> Router Class Initialized
INFO - 2022-07-07 07:19:44 --> Output Class Initialized
INFO - 2022-07-07 07:19:44 --> Security Class Initialized
DEBUG - 2022-07-07 07:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:19:44 --> Input Class Initialized
INFO - 2022-07-07 07:19:44 --> Language Class Initialized
INFO - 2022-07-07 07:19:44 --> Language Class Initialized
INFO - 2022-07-07 07:19:44 --> Config Class Initialized
INFO - 2022-07-07 07:19:44 --> Loader Class Initialized
INFO - 2022-07-07 07:19:44 --> Helper loaded: url_helper
INFO - 2022-07-07 07:19:44 --> Helper loaded: file_helper
INFO - 2022-07-07 07:19:44 --> Helper loaded: form_helper
INFO - 2022-07-07 07:19:45 --> Helper loaded: my_helper
INFO - 2022-07-07 07:19:45 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:19:45 --> Controller Class Initialized
INFO - 2022-07-07 07:19:45 --> Helper loaded: cookie_helper
INFO - 2022-07-07 07:19:45 --> Config Class Initialized
INFO - 2022-07-07 07:19:45 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:19:45 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:19:45 --> Utf8 Class Initialized
INFO - 2022-07-07 07:19:45 --> URI Class Initialized
INFO - 2022-07-07 07:19:45 --> Router Class Initialized
INFO - 2022-07-07 07:19:45 --> Output Class Initialized
INFO - 2022-07-07 07:19:45 --> Security Class Initialized
DEBUG - 2022-07-07 07:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:19:45 --> Input Class Initialized
INFO - 2022-07-07 07:19:45 --> Language Class Initialized
INFO - 2022-07-07 07:19:45 --> Language Class Initialized
INFO - 2022-07-07 07:19:45 --> Config Class Initialized
INFO - 2022-07-07 07:19:45 --> Loader Class Initialized
INFO - 2022-07-07 07:19:45 --> Helper loaded: url_helper
INFO - 2022-07-07 07:19:45 --> Helper loaded: file_helper
INFO - 2022-07-07 07:19:45 --> Helper loaded: form_helper
INFO - 2022-07-07 07:19:45 --> Helper loaded: my_helper
INFO - 2022-07-07 07:19:45 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:19:45 --> Controller Class Initialized
DEBUG - 2022-07-07 07:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-07 07:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:19:45 --> Final output sent to browser
DEBUG - 2022-07-07 07:19:45 --> Total execution time: 0.0418
INFO - 2022-07-07 07:19:53 --> Config Class Initialized
INFO - 2022-07-07 07:19:53 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:19:53 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:19:53 --> Utf8 Class Initialized
INFO - 2022-07-07 07:19:53 --> URI Class Initialized
INFO - 2022-07-07 07:19:53 --> Router Class Initialized
INFO - 2022-07-07 07:19:53 --> Output Class Initialized
INFO - 2022-07-07 07:19:53 --> Security Class Initialized
DEBUG - 2022-07-07 07:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:19:53 --> Input Class Initialized
INFO - 2022-07-07 07:19:53 --> Language Class Initialized
INFO - 2022-07-07 07:19:53 --> Language Class Initialized
INFO - 2022-07-07 07:19:53 --> Config Class Initialized
INFO - 2022-07-07 07:19:53 --> Loader Class Initialized
INFO - 2022-07-07 07:19:53 --> Helper loaded: url_helper
INFO - 2022-07-07 07:19:53 --> Helper loaded: file_helper
INFO - 2022-07-07 07:19:53 --> Helper loaded: form_helper
INFO - 2022-07-07 07:19:53 --> Helper loaded: my_helper
INFO - 2022-07-07 07:19:53 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:19:53 --> Controller Class Initialized
INFO - 2022-07-07 07:19:53 --> Helper loaded: cookie_helper
INFO - 2022-07-07 07:19:53 --> Final output sent to browser
DEBUG - 2022-07-07 07:19:53 --> Total execution time: 0.0617
INFO - 2022-07-07 07:19:53 --> Config Class Initialized
INFO - 2022-07-07 07:19:53 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:19:53 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:19:53 --> Utf8 Class Initialized
INFO - 2022-07-07 07:19:53 --> URI Class Initialized
INFO - 2022-07-07 07:19:53 --> Router Class Initialized
INFO - 2022-07-07 07:19:53 --> Output Class Initialized
INFO - 2022-07-07 07:19:53 --> Security Class Initialized
DEBUG - 2022-07-07 07:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:19:53 --> Input Class Initialized
INFO - 2022-07-07 07:19:53 --> Language Class Initialized
INFO - 2022-07-07 07:19:53 --> Language Class Initialized
INFO - 2022-07-07 07:19:53 --> Config Class Initialized
INFO - 2022-07-07 07:19:53 --> Loader Class Initialized
INFO - 2022-07-07 07:19:53 --> Helper loaded: url_helper
INFO - 2022-07-07 07:19:53 --> Helper loaded: file_helper
INFO - 2022-07-07 07:19:53 --> Helper loaded: form_helper
INFO - 2022-07-07 07:19:53 --> Helper loaded: my_helper
INFO - 2022-07-07 07:19:53 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:19:53 --> Controller Class Initialized
DEBUG - 2022-07-07 07:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-07 07:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:19:53 --> Final output sent to browser
DEBUG - 2022-07-07 07:19:53 --> Total execution time: 0.5668
INFO - 2022-07-07 07:19:59 --> Config Class Initialized
INFO - 2022-07-07 07:19:59 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:19:59 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:19:59 --> Utf8 Class Initialized
INFO - 2022-07-07 07:19:59 --> URI Class Initialized
INFO - 2022-07-07 07:19:59 --> Router Class Initialized
INFO - 2022-07-07 07:19:59 --> Output Class Initialized
INFO - 2022-07-07 07:19:59 --> Security Class Initialized
DEBUG - 2022-07-07 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:19:59 --> Input Class Initialized
INFO - 2022-07-07 07:19:59 --> Language Class Initialized
INFO - 2022-07-07 07:19:59 --> Language Class Initialized
INFO - 2022-07-07 07:19:59 --> Config Class Initialized
INFO - 2022-07-07 07:19:59 --> Loader Class Initialized
INFO - 2022-07-07 07:19:59 --> Helper loaded: url_helper
INFO - 2022-07-07 07:19:59 --> Helper loaded: file_helper
INFO - 2022-07-07 07:19:59 --> Helper loaded: form_helper
INFO - 2022-07-07 07:19:59 --> Helper loaded: my_helper
INFO - 2022-07-07 07:19:59 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:19:59 --> Controller Class Initialized
DEBUG - 2022-07-07 07:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-07 07:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:19:59 --> Final output sent to browser
DEBUG - 2022-07-07 07:19:59 --> Total execution time: 0.0516
INFO - 2022-07-07 07:20:00 --> Config Class Initialized
INFO - 2022-07-07 07:20:00 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:20:00 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:20:00 --> Utf8 Class Initialized
INFO - 2022-07-07 07:20:00 --> URI Class Initialized
INFO - 2022-07-07 07:20:00 --> Router Class Initialized
INFO - 2022-07-07 07:20:00 --> Output Class Initialized
INFO - 2022-07-07 07:20:00 --> Security Class Initialized
DEBUG - 2022-07-07 07:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:20:00 --> Input Class Initialized
INFO - 2022-07-07 07:20:00 --> Language Class Initialized
INFO - 2022-07-07 07:20:00 --> Language Class Initialized
INFO - 2022-07-07 07:20:00 --> Config Class Initialized
INFO - 2022-07-07 07:20:00 --> Loader Class Initialized
INFO - 2022-07-07 07:20:00 --> Helper loaded: url_helper
INFO - 2022-07-07 07:20:00 --> Helper loaded: file_helper
INFO - 2022-07-07 07:20:00 --> Helper loaded: form_helper
INFO - 2022-07-07 07:20:00 --> Helper loaded: my_helper
INFO - 2022-07-07 07:20:00 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:20:00 --> Controller Class Initialized
DEBUG - 2022-07-07 07:20:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-07 07:20:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:20:00 --> Final output sent to browser
DEBUG - 2022-07-07 07:20:00 --> Total execution time: 0.0721
INFO - 2022-07-07 07:20:03 --> Config Class Initialized
INFO - 2022-07-07 07:20:03 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:20:03 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:20:03 --> Utf8 Class Initialized
INFO - 2022-07-07 07:20:03 --> URI Class Initialized
INFO - 2022-07-07 07:20:03 --> Router Class Initialized
INFO - 2022-07-07 07:20:03 --> Output Class Initialized
INFO - 2022-07-07 07:20:03 --> Security Class Initialized
DEBUG - 2022-07-07 07:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:20:03 --> Input Class Initialized
INFO - 2022-07-07 07:20:03 --> Language Class Initialized
INFO - 2022-07-07 07:20:03 --> Language Class Initialized
INFO - 2022-07-07 07:20:03 --> Config Class Initialized
INFO - 2022-07-07 07:20:03 --> Loader Class Initialized
INFO - 2022-07-07 07:20:03 --> Helper loaded: url_helper
INFO - 2022-07-07 07:20:03 --> Helper loaded: file_helper
INFO - 2022-07-07 07:20:03 --> Helper loaded: form_helper
INFO - 2022-07-07 07:20:03 --> Helper loaded: my_helper
INFO - 2022-07-07 07:20:03 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:20:03 --> Controller Class Initialized
DEBUG - 2022-07-07 07:20:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:20:03 --> Final output sent to browser
DEBUG - 2022-07-07 07:20:03 --> Total execution time: 0.3171
INFO - 2022-07-07 07:20:22 --> Config Class Initialized
INFO - 2022-07-07 07:20:22 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:20:22 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:20:22 --> Utf8 Class Initialized
INFO - 2022-07-07 07:20:22 --> URI Class Initialized
INFO - 2022-07-07 07:20:22 --> Router Class Initialized
INFO - 2022-07-07 07:20:22 --> Output Class Initialized
INFO - 2022-07-07 07:20:22 --> Security Class Initialized
DEBUG - 2022-07-07 07:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:20:22 --> Input Class Initialized
INFO - 2022-07-07 07:20:22 --> Language Class Initialized
INFO - 2022-07-07 07:20:22 --> Language Class Initialized
INFO - 2022-07-07 07:20:22 --> Config Class Initialized
INFO - 2022-07-07 07:20:22 --> Loader Class Initialized
INFO - 2022-07-07 07:20:22 --> Helper loaded: url_helper
INFO - 2022-07-07 07:20:22 --> Helper loaded: file_helper
INFO - 2022-07-07 07:20:22 --> Helper loaded: form_helper
INFO - 2022-07-07 07:20:22 --> Helper loaded: my_helper
INFO - 2022-07-07 07:20:22 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:20:22 --> Controller Class Initialized
DEBUG - 2022-07-07 07:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-07 07:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:20:22 --> Final output sent to browser
DEBUG - 2022-07-07 07:20:22 --> Total execution time: 0.0657
INFO - 2022-07-07 07:20:22 --> Config Class Initialized
INFO - 2022-07-07 07:20:22 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:20:22 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:20:22 --> Utf8 Class Initialized
INFO - 2022-07-07 07:20:22 --> URI Class Initialized
INFO - 2022-07-07 07:20:22 --> Router Class Initialized
INFO - 2022-07-07 07:20:22 --> Output Class Initialized
INFO - 2022-07-07 07:20:22 --> Security Class Initialized
DEBUG - 2022-07-07 07:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:20:22 --> Input Class Initialized
INFO - 2022-07-07 07:20:22 --> Language Class Initialized
INFO - 2022-07-07 07:20:22 --> Language Class Initialized
INFO - 2022-07-07 07:20:22 --> Config Class Initialized
INFO - 2022-07-07 07:20:22 --> Loader Class Initialized
INFO - 2022-07-07 07:20:22 --> Helper loaded: url_helper
INFO - 2022-07-07 07:20:22 --> Helper loaded: file_helper
INFO - 2022-07-07 07:20:22 --> Helper loaded: form_helper
INFO - 2022-07-07 07:20:22 --> Helper loaded: my_helper
INFO - 2022-07-07 07:20:22 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:20:22 --> Controller Class Initialized
DEBUG - 2022-07-07 07:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-07 07:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:20:22 --> Final output sent to browser
DEBUG - 2022-07-07 07:20:22 --> Total execution time: 0.0498
INFO - 2022-07-07 07:20:25 --> Config Class Initialized
INFO - 2022-07-07 07:20:25 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:20:25 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:20:25 --> Utf8 Class Initialized
INFO - 2022-07-07 07:20:25 --> URI Class Initialized
INFO - 2022-07-07 07:20:25 --> Router Class Initialized
INFO - 2022-07-07 07:20:25 --> Output Class Initialized
INFO - 2022-07-07 07:20:25 --> Security Class Initialized
DEBUG - 2022-07-07 07:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:20:25 --> Input Class Initialized
INFO - 2022-07-07 07:20:25 --> Language Class Initialized
INFO - 2022-07-07 07:20:25 --> Language Class Initialized
INFO - 2022-07-07 07:20:25 --> Config Class Initialized
INFO - 2022-07-07 07:20:25 --> Loader Class Initialized
INFO - 2022-07-07 07:20:25 --> Helper loaded: url_helper
INFO - 2022-07-07 07:20:25 --> Helper loaded: file_helper
INFO - 2022-07-07 07:20:25 --> Helper loaded: form_helper
INFO - 2022-07-07 07:20:25 --> Helper loaded: my_helper
INFO - 2022-07-07 07:20:25 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:20:25 --> Controller Class Initialized
DEBUG - 2022-07-07 07:20:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:20:25 --> Final output sent to browser
DEBUG - 2022-07-07 07:20:25 --> Total execution time: 0.1487
INFO - 2022-07-07 07:20:33 --> Config Class Initialized
INFO - 2022-07-07 07:20:33 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:20:33 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:20:33 --> Utf8 Class Initialized
INFO - 2022-07-07 07:20:33 --> URI Class Initialized
INFO - 2022-07-07 07:20:33 --> Router Class Initialized
INFO - 2022-07-07 07:20:33 --> Output Class Initialized
INFO - 2022-07-07 07:20:33 --> Security Class Initialized
DEBUG - 2022-07-07 07:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:20:33 --> Input Class Initialized
INFO - 2022-07-07 07:20:33 --> Language Class Initialized
INFO - 2022-07-07 07:20:33 --> Language Class Initialized
INFO - 2022-07-07 07:20:33 --> Config Class Initialized
INFO - 2022-07-07 07:20:33 --> Loader Class Initialized
INFO - 2022-07-07 07:20:33 --> Helper loaded: url_helper
INFO - 2022-07-07 07:20:33 --> Helper loaded: file_helper
INFO - 2022-07-07 07:20:33 --> Helper loaded: form_helper
INFO - 2022-07-07 07:20:33 --> Helper loaded: my_helper
INFO - 2022-07-07 07:20:33 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:20:33 --> Controller Class Initialized
DEBUG - 2022-07-07 07:20:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:20:33 --> Final output sent to browser
DEBUG - 2022-07-07 07:20:33 --> Total execution time: 0.1562
INFO - 2022-07-07 07:20:35 --> Config Class Initialized
INFO - 2022-07-07 07:20:35 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:20:35 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:20:35 --> Utf8 Class Initialized
INFO - 2022-07-07 07:20:35 --> URI Class Initialized
INFO - 2022-07-07 07:20:35 --> Router Class Initialized
INFO - 2022-07-07 07:20:35 --> Output Class Initialized
INFO - 2022-07-07 07:20:35 --> Security Class Initialized
DEBUG - 2022-07-07 07:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:20:35 --> Input Class Initialized
INFO - 2022-07-07 07:20:35 --> Language Class Initialized
INFO - 2022-07-07 07:20:35 --> Language Class Initialized
INFO - 2022-07-07 07:20:35 --> Config Class Initialized
INFO - 2022-07-07 07:20:35 --> Loader Class Initialized
INFO - 2022-07-07 07:20:35 --> Helper loaded: url_helper
INFO - 2022-07-07 07:20:35 --> Helper loaded: file_helper
INFO - 2022-07-07 07:20:35 --> Helper loaded: form_helper
INFO - 2022-07-07 07:20:35 --> Helper loaded: my_helper
INFO - 2022-07-07 07:20:35 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:20:35 --> Controller Class Initialized
DEBUG - 2022-07-07 07:20:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:20:35 --> Final output sent to browser
DEBUG - 2022-07-07 07:20:35 --> Total execution time: 0.1544
INFO - 2022-07-07 07:20:38 --> Config Class Initialized
INFO - 2022-07-07 07:20:38 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:20:38 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:20:38 --> Utf8 Class Initialized
INFO - 2022-07-07 07:20:38 --> URI Class Initialized
INFO - 2022-07-07 07:20:38 --> Router Class Initialized
INFO - 2022-07-07 07:20:38 --> Output Class Initialized
INFO - 2022-07-07 07:20:38 --> Security Class Initialized
DEBUG - 2022-07-07 07:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:20:38 --> Input Class Initialized
INFO - 2022-07-07 07:20:38 --> Language Class Initialized
INFO - 2022-07-07 07:20:38 --> Language Class Initialized
INFO - 2022-07-07 07:20:38 --> Config Class Initialized
INFO - 2022-07-07 07:20:38 --> Loader Class Initialized
INFO - 2022-07-07 07:20:38 --> Helper loaded: url_helper
INFO - 2022-07-07 07:20:38 --> Helper loaded: file_helper
INFO - 2022-07-07 07:20:38 --> Helper loaded: form_helper
INFO - 2022-07-07 07:20:38 --> Helper loaded: my_helper
INFO - 2022-07-07 07:20:38 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:20:38 --> Controller Class Initialized
DEBUG - 2022-07-07 07:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:20:38 --> Final output sent to browser
DEBUG - 2022-07-07 07:20:38 --> Total execution time: 0.1692
INFO - 2022-07-07 07:20:41 --> Config Class Initialized
INFO - 2022-07-07 07:20:41 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:20:41 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:20:41 --> Utf8 Class Initialized
INFO - 2022-07-07 07:20:41 --> URI Class Initialized
INFO - 2022-07-07 07:20:41 --> Router Class Initialized
INFO - 2022-07-07 07:20:41 --> Output Class Initialized
INFO - 2022-07-07 07:20:41 --> Security Class Initialized
DEBUG - 2022-07-07 07:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:20:41 --> Input Class Initialized
INFO - 2022-07-07 07:20:41 --> Language Class Initialized
INFO - 2022-07-07 07:20:41 --> Language Class Initialized
INFO - 2022-07-07 07:20:41 --> Config Class Initialized
INFO - 2022-07-07 07:20:41 --> Loader Class Initialized
INFO - 2022-07-07 07:20:41 --> Helper loaded: url_helper
INFO - 2022-07-07 07:20:41 --> Helper loaded: file_helper
INFO - 2022-07-07 07:20:41 --> Helper loaded: form_helper
INFO - 2022-07-07 07:20:41 --> Helper loaded: my_helper
INFO - 2022-07-07 07:20:41 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:20:41 --> Controller Class Initialized
DEBUG - 2022-07-07 07:20:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2022-07-07 07:20:41 --> Final output sent to browser
DEBUG - 2022-07-07 07:20:41 --> Total execution time: 0.2184
INFO - 2022-07-07 07:22:02 --> Config Class Initialized
INFO - 2022-07-07 07:22:02 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:02 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:02 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:02 --> URI Class Initialized
INFO - 2022-07-07 07:22:02 --> Router Class Initialized
INFO - 2022-07-07 07:22:02 --> Output Class Initialized
INFO - 2022-07-07 07:22:02 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:02 --> Input Class Initialized
INFO - 2022-07-07 07:22:02 --> Language Class Initialized
INFO - 2022-07-07 07:22:02 --> Language Class Initialized
INFO - 2022-07-07 07:22:02 --> Config Class Initialized
INFO - 2022-07-07 07:22:02 --> Loader Class Initialized
INFO - 2022-07-07 07:22:02 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:02 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:02 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:02 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:02 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:02 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:02 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:02 --> Total execution time: 0.1473
INFO - 2022-07-07 07:22:04 --> Config Class Initialized
INFO - 2022-07-07 07:22:04 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:04 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:04 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:04 --> URI Class Initialized
INFO - 2022-07-07 07:22:04 --> Router Class Initialized
INFO - 2022-07-07 07:22:04 --> Output Class Initialized
INFO - 2022-07-07 07:22:04 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:04 --> Input Class Initialized
INFO - 2022-07-07 07:22:04 --> Language Class Initialized
INFO - 2022-07-07 07:22:04 --> Language Class Initialized
INFO - 2022-07-07 07:22:04 --> Config Class Initialized
INFO - 2022-07-07 07:22:04 --> Loader Class Initialized
INFO - 2022-07-07 07:22:04 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:04 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:04 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:04 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:04 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:04 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:05 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:05 --> Total execution time: 0.1531
INFO - 2022-07-07 07:22:07 --> Config Class Initialized
INFO - 2022-07-07 07:22:07 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:07 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:07 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:07 --> URI Class Initialized
INFO - 2022-07-07 07:22:07 --> Router Class Initialized
INFO - 2022-07-07 07:22:07 --> Output Class Initialized
INFO - 2022-07-07 07:22:07 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:07 --> Input Class Initialized
INFO - 2022-07-07 07:22:07 --> Language Class Initialized
INFO - 2022-07-07 07:22:07 --> Language Class Initialized
INFO - 2022-07-07 07:22:07 --> Config Class Initialized
INFO - 2022-07-07 07:22:07 --> Loader Class Initialized
INFO - 2022-07-07 07:22:07 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:07 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:07 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:07 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:07 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:07 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:07 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:07 --> Total execution time: 0.1450
INFO - 2022-07-07 07:22:08 --> Config Class Initialized
INFO - 2022-07-07 07:22:08 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:08 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:08 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:08 --> URI Class Initialized
INFO - 2022-07-07 07:22:08 --> Router Class Initialized
INFO - 2022-07-07 07:22:08 --> Output Class Initialized
INFO - 2022-07-07 07:22:08 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:08 --> Input Class Initialized
INFO - 2022-07-07 07:22:08 --> Language Class Initialized
INFO - 2022-07-07 07:22:08 --> Language Class Initialized
INFO - 2022-07-07 07:22:08 --> Config Class Initialized
INFO - 2022-07-07 07:22:08 --> Loader Class Initialized
INFO - 2022-07-07 07:22:08 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:08 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:08 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:08 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:08 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:08 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:08 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:08 --> Total execution time: 0.1430
INFO - 2022-07-07 07:22:11 --> Config Class Initialized
INFO - 2022-07-07 07:22:11 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:11 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:11 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:11 --> URI Class Initialized
INFO - 2022-07-07 07:22:11 --> Router Class Initialized
INFO - 2022-07-07 07:22:11 --> Output Class Initialized
INFO - 2022-07-07 07:22:11 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:11 --> Input Class Initialized
INFO - 2022-07-07 07:22:11 --> Language Class Initialized
INFO - 2022-07-07 07:22:11 --> Language Class Initialized
INFO - 2022-07-07 07:22:11 --> Config Class Initialized
INFO - 2022-07-07 07:22:11 --> Loader Class Initialized
INFO - 2022-07-07 07:22:11 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:11 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:11 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:11 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:11 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:11 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:11 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:11 --> Total execution time: 0.1460
INFO - 2022-07-07 07:22:13 --> Config Class Initialized
INFO - 2022-07-07 07:22:13 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:13 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:13 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:13 --> URI Class Initialized
INFO - 2022-07-07 07:22:13 --> Router Class Initialized
INFO - 2022-07-07 07:22:13 --> Output Class Initialized
INFO - 2022-07-07 07:22:13 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:13 --> Input Class Initialized
INFO - 2022-07-07 07:22:13 --> Language Class Initialized
INFO - 2022-07-07 07:22:13 --> Language Class Initialized
INFO - 2022-07-07 07:22:13 --> Config Class Initialized
INFO - 2022-07-07 07:22:13 --> Loader Class Initialized
INFO - 2022-07-07 07:22:13 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:13 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:13 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:13 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:13 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:13 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:13 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:13 --> Total execution time: 0.1439
INFO - 2022-07-07 07:22:15 --> Config Class Initialized
INFO - 2022-07-07 07:22:15 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:15 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:15 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:15 --> URI Class Initialized
INFO - 2022-07-07 07:22:15 --> Router Class Initialized
INFO - 2022-07-07 07:22:15 --> Output Class Initialized
INFO - 2022-07-07 07:22:15 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:15 --> Input Class Initialized
INFO - 2022-07-07 07:22:15 --> Language Class Initialized
INFO - 2022-07-07 07:22:15 --> Language Class Initialized
INFO - 2022-07-07 07:22:15 --> Config Class Initialized
INFO - 2022-07-07 07:22:15 --> Loader Class Initialized
INFO - 2022-07-07 07:22:15 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:15 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:15 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:15 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:15 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:15 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:15 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:15 --> Total execution time: 0.1449
INFO - 2022-07-07 07:22:19 --> Config Class Initialized
INFO - 2022-07-07 07:22:19 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:19 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:19 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:19 --> URI Class Initialized
INFO - 2022-07-07 07:22:19 --> Router Class Initialized
INFO - 2022-07-07 07:22:19 --> Output Class Initialized
INFO - 2022-07-07 07:22:19 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:19 --> Input Class Initialized
INFO - 2022-07-07 07:22:19 --> Language Class Initialized
INFO - 2022-07-07 07:22:19 --> Language Class Initialized
INFO - 2022-07-07 07:22:19 --> Config Class Initialized
INFO - 2022-07-07 07:22:19 --> Loader Class Initialized
INFO - 2022-07-07 07:22:19 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:19 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:19 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:19 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:19 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:19 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:19 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:19 --> Total execution time: 0.1438
INFO - 2022-07-07 07:22:22 --> Config Class Initialized
INFO - 2022-07-07 07:22:22 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:22 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:22 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:22 --> URI Class Initialized
INFO - 2022-07-07 07:22:22 --> Router Class Initialized
INFO - 2022-07-07 07:22:22 --> Output Class Initialized
INFO - 2022-07-07 07:22:22 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:22 --> Input Class Initialized
INFO - 2022-07-07 07:22:22 --> Language Class Initialized
INFO - 2022-07-07 07:22:22 --> Language Class Initialized
INFO - 2022-07-07 07:22:22 --> Config Class Initialized
INFO - 2022-07-07 07:22:22 --> Loader Class Initialized
INFO - 2022-07-07 07:22:22 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:22 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:22 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:22 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:22 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:22 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:22 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:22 --> Total execution time: 0.1467
INFO - 2022-07-07 07:22:25 --> Config Class Initialized
INFO - 2022-07-07 07:22:25 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:25 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:25 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:25 --> URI Class Initialized
INFO - 2022-07-07 07:22:25 --> Router Class Initialized
INFO - 2022-07-07 07:22:25 --> Output Class Initialized
INFO - 2022-07-07 07:22:25 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:25 --> Input Class Initialized
INFO - 2022-07-07 07:22:25 --> Language Class Initialized
INFO - 2022-07-07 07:22:25 --> Language Class Initialized
INFO - 2022-07-07 07:22:25 --> Config Class Initialized
INFO - 2022-07-07 07:22:25 --> Loader Class Initialized
INFO - 2022-07-07 07:22:25 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:25 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:25 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:25 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:25 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:25 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:25 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:25 --> Total execution time: 0.1455
INFO - 2022-07-07 07:22:26 --> Config Class Initialized
INFO - 2022-07-07 07:22:26 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:26 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:26 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:26 --> URI Class Initialized
INFO - 2022-07-07 07:22:26 --> Router Class Initialized
INFO - 2022-07-07 07:22:26 --> Output Class Initialized
INFO - 2022-07-07 07:22:26 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:26 --> Input Class Initialized
INFO - 2022-07-07 07:22:26 --> Language Class Initialized
INFO - 2022-07-07 07:22:26 --> Language Class Initialized
INFO - 2022-07-07 07:22:26 --> Config Class Initialized
INFO - 2022-07-07 07:22:26 --> Loader Class Initialized
INFO - 2022-07-07 07:22:26 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:26 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:26 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:26 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:26 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:26 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:26 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:26 --> Total execution time: 0.1411
INFO - 2022-07-07 07:22:28 --> Config Class Initialized
INFO - 2022-07-07 07:22:28 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:28 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:28 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:28 --> URI Class Initialized
INFO - 2022-07-07 07:22:28 --> Router Class Initialized
INFO - 2022-07-07 07:22:28 --> Output Class Initialized
INFO - 2022-07-07 07:22:28 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:28 --> Input Class Initialized
INFO - 2022-07-07 07:22:28 --> Language Class Initialized
INFO - 2022-07-07 07:22:28 --> Language Class Initialized
INFO - 2022-07-07 07:22:28 --> Config Class Initialized
INFO - 2022-07-07 07:22:28 --> Loader Class Initialized
INFO - 2022-07-07 07:22:28 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:28 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:28 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:28 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:28 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:28 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:28 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:28 --> Total execution time: 0.1439
INFO - 2022-07-07 07:22:31 --> Config Class Initialized
INFO - 2022-07-07 07:22:31 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:31 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:31 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:31 --> URI Class Initialized
INFO - 2022-07-07 07:22:31 --> Router Class Initialized
INFO - 2022-07-07 07:22:31 --> Output Class Initialized
INFO - 2022-07-07 07:22:31 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:31 --> Input Class Initialized
INFO - 2022-07-07 07:22:31 --> Language Class Initialized
INFO - 2022-07-07 07:22:31 --> Language Class Initialized
INFO - 2022-07-07 07:22:31 --> Config Class Initialized
INFO - 2022-07-07 07:22:31 --> Loader Class Initialized
INFO - 2022-07-07 07:22:31 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:31 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:31 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:31 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:31 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:31 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:31 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:31 --> Total execution time: 0.1420
INFO - 2022-07-07 07:22:34 --> Config Class Initialized
INFO - 2022-07-07 07:22:34 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:34 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:34 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:34 --> URI Class Initialized
INFO - 2022-07-07 07:22:34 --> Router Class Initialized
INFO - 2022-07-07 07:22:34 --> Output Class Initialized
INFO - 2022-07-07 07:22:34 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:34 --> Input Class Initialized
INFO - 2022-07-07 07:22:34 --> Language Class Initialized
INFO - 2022-07-07 07:22:34 --> Language Class Initialized
INFO - 2022-07-07 07:22:34 --> Config Class Initialized
INFO - 2022-07-07 07:22:34 --> Loader Class Initialized
INFO - 2022-07-07 07:22:34 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:34 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:34 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:34 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:34 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:34 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:34 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:34 --> Total execution time: 0.1438
INFO - 2022-07-07 07:22:36 --> Config Class Initialized
INFO - 2022-07-07 07:22:36 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:22:36 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:22:36 --> Utf8 Class Initialized
INFO - 2022-07-07 07:22:36 --> URI Class Initialized
INFO - 2022-07-07 07:22:36 --> Router Class Initialized
INFO - 2022-07-07 07:22:36 --> Output Class Initialized
INFO - 2022-07-07 07:22:36 --> Security Class Initialized
DEBUG - 2022-07-07 07:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:22:36 --> Input Class Initialized
INFO - 2022-07-07 07:22:36 --> Language Class Initialized
INFO - 2022-07-07 07:22:36 --> Language Class Initialized
INFO - 2022-07-07 07:22:36 --> Config Class Initialized
INFO - 2022-07-07 07:22:36 --> Loader Class Initialized
INFO - 2022-07-07 07:22:36 --> Helper loaded: url_helper
INFO - 2022-07-07 07:22:36 --> Helper loaded: file_helper
INFO - 2022-07-07 07:22:36 --> Helper loaded: form_helper
INFO - 2022-07-07 07:22:36 --> Helper loaded: my_helper
INFO - 2022-07-07 07:22:36 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:22:36 --> Controller Class Initialized
DEBUG - 2022-07-07 07:22:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:22:36 --> Final output sent to browser
DEBUG - 2022-07-07 07:22:36 --> Total execution time: 0.1505
INFO - 2022-07-07 07:32:58 --> Config Class Initialized
INFO - 2022-07-07 07:32:58 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:32:58 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:32:58 --> Utf8 Class Initialized
INFO - 2022-07-07 07:32:58 --> URI Class Initialized
INFO - 2022-07-07 07:32:58 --> Router Class Initialized
INFO - 2022-07-07 07:32:58 --> Output Class Initialized
INFO - 2022-07-07 07:32:58 --> Security Class Initialized
DEBUG - 2022-07-07 07:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:32:58 --> Input Class Initialized
INFO - 2022-07-07 07:32:58 --> Language Class Initialized
INFO - 2022-07-07 07:32:58 --> Language Class Initialized
INFO - 2022-07-07 07:32:58 --> Config Class Initialized
INFO - 2022-07-07 07:32:58 --> Loader Class Initialized
INFO - 2022-07-07 07:32:58 --> Helper loaded: url_helper
INFO - 2022-07-07 07:32:58 --> Helper loaded: file_helper
INFO - 2022-07-07 07:32:58 --> Helper loaded: form_helper
INFO - 2022-07-07 07:32:58 --> Helper loaded: my_helper
INFO - 2022-07-07 07:32:58 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:32:58 --> Controller Class Initialized
DEBUG - 2022-07-07 07:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-07 07:32:58 --> Final output sent to browser
DEBUG - 2022-07-07 07:32:58 --> Total execution time: 0.1409
INFO - 2022-07-07 07:36:11 --> Config Class Initialized
INFO - 2022-07-07 07:36:11 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:11 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:11 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:11 --> URI Class Initialized
INFO - 2022-07-07 07:36:11 --> Router Class Initialized
INFO - 2022-07-07 07:36:11 --> Output Class Initialized
INFO - 2022-07-07 07:36:11 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:11 --> Input Class Initialized
INFO - 2022-07-07 07:36:11 --> Language Class Initialized
INFO - 2022-07-07 07:36:11 --> Language Class Initialized
INFO - 2022-07-07 07:36:11 --> Config Class Initialized
INFO - 2022-07-07 07:36:11 --> Loader Class Initialized
INFO - 2022-07-07 07:36:11 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:11 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:11 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:11 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:11 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:11 --> Controller Class Initialized
INFO - 2022-07-07 07:36:11 --> Helper loaded: cookie_helper
INFO - 2022-07-07 07:36:11 --> Config Class Initialized
INFO - 2022-07-07 07:36:11 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:11 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:11 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:11 --> URI Class Initialized
INFO - 2022-07-07 07:36:11 --> Router Class Initialized
INFO - 2022-07-07 07:36:11 --> Output Class Initialized
INFO - 2022-07-07 07:36:11 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:11 --> Input Class Initialized
INFO - 2022-07-07 07:36:11 --> Language Class Initialized
INFO - 2022-07-07 07:36:11 --> Language Class Initialized
INFO - 2022-07-07 07:36:11 --> Config Class Initialized
INFO - 2022-07-07 07:36:11 --> Loader Class Initialized
INFO - 2022-07-07 07:36:11 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:11 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:11 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:11 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:11 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:11 --> Controller Class Initialized
DEBUG - 2022-07-07 07:36:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-07 07:36:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:36:11 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:11 --> Total execution time: 0.0426
INFO - 2022-07-07 07:36:15 --> Config Class Initialized
INFO - 2022-07-07 07:36:15 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:15 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:15 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:15 --> URI Class Initialized
INFO - 2022-07-07 07:36:15 --> Router Class Initialized
INFO - 2022-07-07 07:36:15 --> Output Class Initialized
INFO - 2022-07-07 07:36:15 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:15 --> Input Class Initialized
INFO - 2022-07-07 07:36:15 --> Language Class Initialized
INFO - 2022-07-07 07:36:15 --> Language Class Initialized
INFO - 2022-07-07 07:36:15 --> Config Class Initialized
INFO - 2022-07-07 07:36:15 --> Loader Class Initialized
INFO - 2022-07-07 07:36:15 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:15 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:15 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:15 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:15 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:15 --> Controller Class Initialized
INFO - 2022-07-07 07:36:15 --> Helper loaded: cookie_helper
INFO - 2022-07-07 07:36:15 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:15 --> Total execution time: 0.0561
INFO - 2022-07-07 07:36:15 --> Config Class Initialized
INFO - 2022-07-07 07:36:15 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:15 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:15 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:15 --> URI Class Initialized
INFO - 2022-07-07 07:36:15 --> Router Class Initialized
INFO - 2022-07-07 07:36:15 --> Output Class Initialized
INFO - 2022-07-07 07:36:15 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:15 --> Input Class Initialized
INFO - 2022-07-07 07:36:15 --> Language Class Initialized
INFO - 2022-07-07 07:36:15 --> Language Class Initialized
INFO - 2022-07-07 07:36:15 --> Config Class Initialized
INFO - 2022-07-07 07:36:15 --> Loader Class Initialized
INFO - 2022-07-07 07:36:15 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:15 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:15 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:15 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:15 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:15 --> Controller Class Initialized
DEBUG - 2022-07-07 07:36:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-07 07:36:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:36:15 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:15 --> Total execution time: 0.5589
INFO - 2022-07-07 07:36:17 --> Config Class Initialized
INFO - 2022-07-07 07:36:17 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:17 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:17 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:17 --> URI Class Initialized
INFO - 2022-07-07 07:36:17 --> Router Class Initialized
INFO - 2022-07-07 07:36:17 --> Output Class Initialized
INFO - 2022-07-07 07:36:17 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:17 --> Input Class Initialized
INFO - 2022-07-07 07:36:17 --> Language Class Initialized
INFO - 2022-07-07 07:36:17 --> Language Class Initialized
INFO - 2022-07-07 07:36:17 --> Config Class Initialized
INFO - 2022-07-07 07:36:17 --> Loader Class Initialized
INFO - 2022-07-07 07:36:17 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:17 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:17 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:17 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:17 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:17 --> Controller Class Initialized
DEBUG - 2022-07-07 07:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-07-07 07:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:36:17 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:17 --> Total execution time: 0.1101
INFO - 2022-07-07 07:36:19 --> Config Class Initialized
INFO - 2022-07-07 07:36:19 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:19 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:19 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:19 --> URI Class Initialized
INFO - 2022-07-07 07:36:19 --> Router Class Initialized
INFO - 2022-07-07 07:36:19 --> Output Class Initialized
INFO - 2022-07-07 07:36:19 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:19 --> Input Class Initialized
INFO - 2022-07-07 07:36:19 --> Language Class Initialized
INFO - 2022-07-07 07:36:19 --> Language Class Initialized
INFO - 2022-07-07 07:36:19 --> Config Class Initialized
INFO - 2022-07-07 07:36:19 --> Loader Class Initialized
INFO - 2022-07-07 07:36:19 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:19 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:19 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:19 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:19 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:19 --> Controller Class Initialized
DEBUG - 2022-07-07 07:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-07 07:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:36:19 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:19 --> Total execution time: 0.1031
INFO - 2022-07-07 07:36:19 --> Config Class Initialized
INFO - 2022-07-07 07:36:19 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:19 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:19 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:19 --> URI Class Initialized
INFO - 2022-07-07 07:36:19 --> Router Class Initialized
INFO - 2022-07-07 07:36:19 --> Output Class Initialized
INFO - 2022-07-07 07:36:19 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:19 --> Input Class Initialized
INFO - 2022-07-07 07:36:19 --> Language Class Initialized
INFO - 2022-07-07 07:36:19 --> Language Class Initialized
INFO - 2022-07-07 07:36:19 --> Config Class Initialized
INFO - 2022-07-07 07:36:19 --> Loader Class Initialized
INFO - 2022-07-07 07:36:19 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:19 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:19 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:19 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:19 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:19 --> Controller Class Initialized
DEBUG - 2022-07-07 07:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-07 07:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:36:19 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:19 --> Total execution time: 0.0458
INFO - 2022-07-07 07:36:21 --> Config Class Initialized
INFO - 2022-07-07 07:36:21 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:21 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:21 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:21 --> URI Class Initialized
INFO - 2022-07-07 07:36:21 --> Router Class Initialized
INFO - 2022-07-07 07:36:21 --> Output Class Initialized
INFO - 2022-07-07 07:36:21 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:21 --> Input Class Initialized
INFO - 2022-07-07 07:36:21 --> Language Class Initialized
INFO - 2022-07-07 07:36:21 --> Language Class Initialized
INFO - 2022-07-07 07:36:21 --> Config Class Initialized
INFO - 2022-07-07 07:36:21 --> Loader Class Initialized
INFO - 2022-07-07 07:36:21 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:21 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:21 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:21 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:21 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:21 --> Controller Class Initialized
DEBUG - 2022-07-07 07:36:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-07 07:36:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:36:21 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:21 --> Total execution time: 0.0624
INFO - 2022-07-07 07:36:24 --> Config Class Initialized
INFO - 2022-07-07 07:36:24 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:24 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:24 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:24 --> URI Class Initialized
INFO - 2022-07-07 07:36:24 --> Router Class Initialized
INFO - 2022-07-07 07:36:24 --> Output Class Initialized
INFO - 2022-07-07 07:36:24 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:24 --> Input Class Initialized
INFO - 2022-07-07 07:36:24 --> Language Class Initialized
INFO - 2022-07-07 07:36:24 --> Language Class Initialized
INFO - 2022-07-07 07:36:24 --> Config Class Initialized
INFO - 2022-07-07 07:36:24 --> Loader Class Initialized
INFO - 2022-07-07 07:36:24 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:24 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:24 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:24 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:24 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:24 --> Controller Class Initialized
DEBUG - 2022-07-07 07:36:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2022-07-07 07:36:24 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:24 --> Total execution time: 0.2506
INFO - 2022-07-07 07:36:54 --> Config Class Initialized
INFO - 2022-07-07 07:36:54 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:54 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:54 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:54 --> URI Class Initialized
INFO - 2022-07-07 07:36:54 --> Router Class Initialized
INFO - 2022-07-07 07:36:54 --> Output Class Initialized
INFO - 2022-07-07 07:36:54 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:54 --> Input Class Initialized
INFO - 2022-07-07 07:36:54 --> Language Class Initialized
INFO - 2022-07-07 07:36:54 --> Language Class Initialized
INFO - 2022-07-07 07:36:54 --> Config Class Initialized
INFO - 2022-07-07 07:36:54 --> Loader Class Initialized
INFO - 2022-07-07 07:36:54 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:54 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:54 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:54 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:54 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:54 --> Controller Class Initialized
INFO - 2022-07-07 07:36:54 --> Helper loaded: cookie_helper
INFO - 2022-07-07 07:36:54 --> Config Class Initialized
INFO - 2022-07-07 07:36:54 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:54 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:54 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:54 --> URI Class Initialized
INFO - 2022-07-07 07:36:54 --> Router Class Initialized
INFO - 2022-07-07 07:36:54 --> Output Class Initialized
INFO - 2022-07-07 07:36:54 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:54 --> Input Class Initialized
INFO - 2022-07-07 07:36:54 --> Language Class Initialized
INFO - 2022-07-07 07:36:54 --> Language Class Initialized
INFO - 2022-07-07 07:36:54 --> Config Class Initialized
INFO - 2022-07-07 07:36:54 --> Loader Class Initialized
INFO - 2022-07-07 07:36:54 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:54 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:54 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:54 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:54 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:54 --> Controller Class Initialized
DEBUG - 2022-07-07 07:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-07 07:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:36:54 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:54 --> Total execution time: 0.0410
INFO - 2022-07-07 07:36:59 --> Config Class Initialized
INFO - 2022-07-07 07:36:59 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:59 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:59 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:59 --> URI Class Initialized
INFO - 2022-07-07 07:36:59 --> Router Class Initialized
INFO - 2022-07-07 07:36:59 --> Output Class Initialized
INFO - 2022-07-07 07:36:59 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:59 --> Input Class Initialized
INFO - 2022-07-07 07:36:59 --> Language Class Initialized
INFO - 2022-07-07 07:36:59 --> Language Class Initialized
INFO - 2022-07-07 07:36:59 --> Config Class Initialized
INFO - 2022-07-07 07:36:59 --> Loader Class Initialized
INFO - 2022-07-07 07:36:59 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:59 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:59 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:59 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:59 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:59 --> Controller Class Initialized
INFO - 2022-07-07 07:36:59 --> Helper loaded: cookie_helper
INFO - 2022-07-07 07:36:59 --> Final output sent to browser
DEBUG - 2022-07-07 07:36:59 --> Total execution time: 0.0614
INFO - 2022-07-07 07:36:59 --> Config Class Initialized
INFO - 2022-07-07 07:36:59 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:36:59 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:36:59 --> Utf8 Class Initialized
INFO - 2022-07-07 07:36:59 --> URI Class Initialized
INFO - 2022-07-07 07:36:59 --> Router Class Initialized
INFO - 2022-07-07 07:36:59 --> Output Class Initialized
INFO - 2022-07-07 07:36:59 --> Security Class Initialized
DEBUG - 2022-07-07 07:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:36:59 --> Input Class Initialized
INFO - 2022-07-07 07:36:59 --> Language Class Initialized
INFO - 2022-07-07 07:36:59 --> Language Class Initialized
INFO - 2022-07-07 07:36:59 --> Config Class Initialized
INFO - 2022-07-07 07:36:59 --> Loader Class Initialized
INFO - 2022-07-07 07:36:59 --> Helper loaded: url_helper
INFO - 2022-07-07 07:36:59 --> Helper loaded: file_helper
INFO - 2022-07-07 07:36:59 --> Helper loaded: form_helper
INFO - 2022-07-07 07:36:59 --> Helper loaded: my_helper
INFO - 2022-07-07 07:36:59 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:36:59 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-07 07:37:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:37:00 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:00 --> Total execution time: 0.5772
INFO - 2022-07-07 07:37:01 --> Config Class Initialized
INFO - 2022-07-07 07:37:01 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:01 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:01 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:01 --> URI Class Initialized
INFO - 2022-07-07 07:37:01 --> Router Class Initialized
INFO - 2022-07-07 07:37:01 --> Output Class Initialized
INFO - 2022-07-07 07:37:01 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:01 --> Input Class Initialized
INFO - 2022-07-07 07:37:01 --> Language Class Initialized
INFO - 2022-07-07 07:37:01 --> Language Class Initialized
INFO - 2022-07-07 07:37:01 --> Config Class Initialized
INFO - 2022-07-07 07:37:01 --> Loader Class Initialized
INFO - 2022-07-07 07:37:01 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:01 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:01 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:01 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:01 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:01 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-07 07:37:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:37:01 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:01 --> Total execution time: 0.0580
INFO - 2022-07-07 07:37:01 --> Config Class Initialized
INFO - 2022-07-07 07:37:01 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:01 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:01 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:01 --> URI Class Initialized
INFO - 2022-07-07 07:37:01 --> Router Class Initialized
INFO - 2022-07-07 07:37:01 --> Output Class Initialized
INFO - 2022-07-07 07:37:01 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:01 --> Input Class Initialized
INFO - 2022-07-07 07:37:01 --> Language Class Initialized
INFO - 2022-07-07 07:37:01 --> Language Class Initialized
INFO - 2022-07-07 07:37:01 --> Config Class Initialized
INFO - 2022-07-07 07:37:01 --> Loader Class Initialized
INFO - 2022-07-07 07:37:01 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:01 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:01 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:01 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:01 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:01 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-07 07:37:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:37:01 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:01 --> Total execution time: 0.0508
INFO - 2022-07-07 07:37:03 --> Config Class Initialized
INFO - 2022-07-07 07:37:03 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:03 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:03 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:03 --> URI Class Initialized
INFO - 2022-07-07 07:37:03 --> Router Class Initialized
INFO - 2022-07-07 07:37:03 --> Output Class Initialized
INFO - 2022-07-07 07:37:03 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:03 --> Input Class Initialized
INFO - 2022-07-07 07:37:03 --> Language Class Initialized
INFO - 2022-07-07 07:37:03 --> Language Class Initialized
INFO - 2022-07-07 07:37:03 --> Config Class Initialized
INFO - 2022-07-07 07:37:03 --> Loader Class Initialized
INFO - 2022-07-07 07:37:03 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:03 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:03 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:03 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:03 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:03 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:03 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:03 --> Total execution time: 0.3086
INFO - 2022-07-07 07:37:23 --> Config Class Initialized
INFO - 2022-07-07 07:37:23 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:23 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:23 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:23 --> URI Class Initialized
INFO - 2022-07-07 07:37:23 --> Router Class Initialized
INFO - 2022-07-07 07:37:23 --> Output Class Initialized
INFO - 2022-07-07 07:37:23 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:23 --> Input Class Initialized
INFO - 2022-07-07 07:37:23 --> Language Class Initialized
INFO - 2022-07-07 07:37:23 --> Language Class Initialized
INFO - 2022-07-07 07:37:23 --> Config Class Initialized
INFO - 2022-07-07 07:37:23 --> Loader Class Initialized
INFO - 2022-07-07 07:37:23 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:23 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:23 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:23 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:23 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:23 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-07 07:37:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-07 07:37:23 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:23 --> Total execution time: 0.0721
INFO - 2022-07-07 07:37:28 --> Config Class Initialized
INFO - 2022-07-07 07:37:28 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:28 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:28 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:28 --> URI Class Initialized
INFO - 2022-07-07 07:37:28 --> Router Class Initialized
INFO - 2022-07-07 07:37:28 --> Output Class Initialized
INFO - 2022-07-07 07:37:28 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:28 --> Input Class Initialized
INFO - 2022-07-07 07:37:28 --> Language Class Initialized
INFO - 2022-07-07 07:37:28 --> Language Class Initialized
INFO - 2022-07-07 07:37:28 --> Config Class Initialized
INFO - 2022-07-07 07:37:28 --> Loader Class Initialized
INFO - 2022-07-07 07:37:28 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:28 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:28 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:28 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:28 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:28 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:28 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:28 --> Total execution time: 0.2080
INFO - 2022-07-07 07:37:30 --> Config Class Initialized
INFO - 2022-07-07 07:37:30 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:30 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:30 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:30 --> URI Class Initialized
INFO - 2022-07-07 07:37:30 --> Router Class Initialized
INFO - 2022-07-07 07:37:30 --> Output Class Initialized
INFO - 2022-07-07 07:37:30 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:30 --> Input Class Initialized
INFO - 2022-07-07 07:37:30 --> Language Class Initialized
INFO - 2022-07-07 07:37:30 --> Language Class Initialized
INFO - 2022-07-07 07:37:30 --> Config Class Initialized
INFO - 2022-07-07 07:37:30 --> Loader Class Initialized
INFO - 2022-07-07 07:37:30 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:30 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:30 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:30 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:30 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:30 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:30 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:30 --> Total execution time: 0.1564
INFO - 2022-07-07 07:37:32 --> Config Class Initialized
INFO - 2022-07-07 07:37:32 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:32 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:32 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:32 --> URI Class Initialized
INFO - 2022-07-07 07:37:32 --> Router Class Initialized
INFO - 2022-07-07 07:37:32 --> Output Class Initialized
INFO - 2022-07-07 07:37:32 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:32 --> Input Class Initialized
INFO - 2022-07-07 07:37:32 --> Language Class Initialized
INFO - 2022-07-07 07:37:32 --> Language Class Initialized
INFO - 2022-07-07 07:37:32 --> Config Class Initialized
INFO - 2022-07-07 07:37:32 --> Loader Class Initialized
INFO - 2022-07-07 07:37:32 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:32 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:32 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:32 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:32 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:32 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:32 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:32 --> Total execution time: 0.1499
INFO - 2022-07-07 07:37:35 --> Config Class Initialized
INFO - 2022-07-07 07:37:35 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:35 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:35 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:35 --> URI Class Initialized
INFO - 2022-07-07 07:37:35 --> Router Class Initialized
INFO - 2022-07-07 07:37:35 --> Output Class Initialized
INFO - 2022-07-07 07:37:35 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:35 --> Input Class Initialized
INFO - 2022-07-07 07:37:35 --> Language Class Initialized
INFO - 2022-07-07 07:37:35 --> Language Class Initialized
INFO - 2022-07-07 07:37:35 --> Config Class Initialized
INFO - 2022-07-07 07:37:35 --> Loader Class Initialized
INFO - 2022-07-07 07:37:35 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:35 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:35 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:35 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:35 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:35 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:35 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:35 --> Total execution time: 0.1460
INFO - 2022-07-07 07:37:36 --> Config Class Initialized
INFO - 2022-07-07 07:37:36 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:36 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:36 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:36 --> URI Class Initialized
INFO - 2022-07-07 07:37:36 --> Router Class Initialized
INFO - 2022-07-07 07:37:36 --> Output Class Initialized
INFO - 2022-07-07 07:37:36 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:36 --> Input Class Initialized
INFO - 2022-07-07 07:37:36 --> Language Class Initialized
INFO - 2022-07-07 07:37:36 --> Language Class Initialized
INFO - 2022-07-07 07:37:36 --> Config Class Initialized
INFO - 2022-07-07 07:37:36 --> Loader Class Initialized
INFO - 2022-07-07 07:37:36 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:36 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:36 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:36 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:36 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:37 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:37 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:37 --> Total execution time: 0.1453
INFO - 2022-07-07 07:37:41 --> Config Class Initialized
INFO - 2022-07-07 07:37:41 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:41 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:41 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:41 --> URI Class Initialized
INFO - 2022-07-07 07:37:41 --> Router Class Initialized
INFO - 2022-07-07 07:37:41 --> Output Class Initialized
INFO - 2022-07-07 07:37:41 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:41 --> Input Class Initialized
INFO - 2022-07-07 07:37:41 --> Language Class Initialized
INFO - 2022-07-07 07:37:41 --> Language Class Initialized
INFO - 2022-07-07 07:37:41 --> Config Class Initialized
INFO - 2022-07-07 07:37:41 --> Loader Class Initialized
INFO - 2022-07-07 07:37:41 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:41 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:41 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:41 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:41 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:41 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:41 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:41 --> Total execution time: 0.1445
INFO - 2022-07-07 07:37:43 --> Config Class Initialized
INFO - 2022-07-07 07:37:43 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:43 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:43 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:43 --> URI Class Initialized
INFO - 2022-07-07 07:37:43 --> Router Class Initialized
INFO - 2022-07-07 07:37:43 --> Output Class Initialized
INFO - 2022-07-07 07:37:43 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:43 --> Input Class Initialized
INFO - 2022-07-07 07:37:43 --> Language Class Initialized
INFO - 2022-07-07 07:37:44 --> Language Class Initialized
INFO - 2022-07-07 07:37:44 --> Config Class Initialized
INFO - 2022-07-07 07:37:44 --> Loader Class Initialized
INFO - 2022-07-07 07:37:44 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:44 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:44 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:44 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:44 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:44 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:44 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:44 --> Total execution time: 0.1497
INFO - 2022-07-07 07:37:46 --> Config Class Initialized
INFO - 2022-07-07 07:37:46 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:46 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:46 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:46 --> URI Class Initialized
INFO - 2022-07-07 07:37:46 --> Router Class Initialized
INFO - 2022-07-07 07:37:46 --> Output Class Initialized
INFO - 2022-07-07 07:37:46 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:46 --> Input Class Initialized
INFO - 2022-07-07 07:37:46 --> Language Class Initialized
INFO - 2022-07-07 07:37:46 --> Language Class Initialized
INFO - 2022-07-07 07:37:46 --> Config Class Initialized
INFO - 2022-07-07 07:37:46 --> Loader Class Initialized
INFO - 2022-07-07 07:37:46 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:46 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:46 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:46 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:46 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:46 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:46 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:46 --> Total execution time: 0.1501
INFO - 2022-07-07 07:37:47 --> Config Class Initialized
INFO - 2022-07-07 07:37:47 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:47 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:47 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:47 --> URI Class Initialized
INFO - 2022-07-07 07:37:47 --> Router Class Initialized
INFO - 2022-07-07 07:37:47 --> Output Class Initialized
INFO - 2022-07-07 07:37:47 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:47 --> Input Class Initialized
INFO - 2022-07-07 07:37:47 --> Language Class Initialized
INFO - 2022-07-07 07:37:47 --> Language Class Initialized
INFO - 2022-07-07 07:37:47 --> Config Class Initialized
INFO - 2022-07-07 07:37:47 --> Loader Class Initialized
INFO - 2022-07-07 07:37:47 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:47 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:47 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:47 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:47 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:47 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:48 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:48 --> Total execution time: 0.1618
INFO - 2022-07-07 07:37:50 --> Config Class Initialized
INFO - 2022-07-07 07:37:50 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:50 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:50 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:50 --> URI Class Initialized
INFO - 2022-07-07 07:37:50 --> Router Class Initialized
INFO - 2022-07-07 07:37:50 --> Output Class Initialized
INFO - 2022-07-07 07:37:50 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:50 --> Input Class Initialized
INFO - 2022-07-07 07:37:50 --> Language Class Initialized
INFO - 2022-07-07 07:37:50 --> Language Class Initialized
INFO - 2022-07-07 07:37:50 --> Config Class Initialized
INFO - 2022-07-07 07:37:50 --> Loader Class Initialized
INFO - 2022-07-07 07:37:50 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:50 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:50 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:50 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:50 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:50 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:50 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:50 --> Total execution time: 0.1447
INFO - 2022-07-07 07:37:52 --> Config Class Initialized
INFO - 2022-07-07 07:37:52 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:52 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:52 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:52 --> URI Class Initialized
INFO - 2022-07-07 07:37:53 --> Router Class Initialized
INFO - 2022-07-07 07:37:53 --> Output Class Initialized
INFO - 2022-07-07 07:37:53 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:53 --> Input Class Initialized
INFO - 2022-07-07 07:37:53 --> Language Class Initialized
INFO - 2022-07-07 07:37:53 --> Language Class Initialized
INFO - 2022-07-07 07:37:53 --> Config Class Initialized
INFO - 2022-07-07 07:37:53 --> Loader Class Initialized
INFO - 2022-07-07 07:37:53 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:53 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:53 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:53 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:53 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:53 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:53 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:53 --> Total execution time: 0.1441
INFO - 2022-07-07 07:37:55 --> Config Class Initialized
INFO - 2022-07-07 07:37:55 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:55 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:55 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:55 --> URI Class Initialized
INFO - 2022-07-07 07:37:55 --> Router Class Initialized
INFO - 2022-07-07 07:37:55 --> Output Class Initialized
INFO - 2022-07-07 07:37:55 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:55 --> Input Class Initialized
INFO - 2022-07-07 07:37:55 --> Language Class Initialized
INFO - 2022-07-07 07:37:55 --> Language Class Initialized
INFO - 2022-07-07 07:37:55 --> Config Class Initialized
INFO - 2022-07-07 07:37:55 --> Loader Class Initialized
INFO - 2022-07-07 07:37:55 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:55 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:55 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:55 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:55 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:55 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:55 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:55 --> Total execution time: 0.1406
INFO - 2022-07-07 07:37:57 --> Config Class Initialized
INFO - 2022-07-07 07:37:57 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:57 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:57 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:57 --> URI Class Initialized
INFO - 2022-07-07 07:37:57 --> Router Class Initialized
INFO - 2022-07-07 07:37:57 --> Output Class Initialized
INFO - 2022-07-07 07:37:57 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:57 --> Input Class Initialized
INFO - 2022-07-07 07:37:57 --> Language Class Initialized
INFO - 2022-07-07 07:37:57 --> Language Class Initialized
INFO - 2022-07-07 07:37:57 --> Config Class Initialized
INFO - 2022-07-07 07:37:57 --> Loader Class Initialized
INFO - 2022-07-07 07:37:57 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:57 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:57 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:57 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:57 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:57 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:57 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:57 --> Total execution time: 0.1446
INFO - 2022-07-07 07:37:59 --> Config Class Initialized
INFO - 2022-07-07 07:37:59 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:37:59 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:37:59 --> Utf8 Class Initialized
INFO - 2022-07-07 07:37:59 --> URI Class Initialized
INFO - 2022-07-07 07:37:59 --> Router Class Initialized
INFO - 2022-07-07 07:37:59 --> Output Class Initialized
INFO - 2022-07-07 07:37:59 --> Security Class Initialized
DEBUG - 2022-07-07 07:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:37:59 --> Input Class Initialized
INFO - 2022-07-07 07:37:59 --> Language Class Initialized
INFO - 2022-07-07 07:37:59 --> Language Class Initialized
INFO - 2022-07-07 07:37:59 --> Config Class Initialized
INFO - 2022-07-07 07:37:59 --> Loader Class Initialized
INFO - 2022-07-07 07:37:59 --> Helper loaded: url_helper
INFO - 2022-07-07 07:37:59 --> Helper loaded: file_helper
INFO - 2022-07-07 07:37:59 --> Helper loaded: form_helper
INFO - 2022-07-07 07:37:59 --> Helper loaded: my_helper
INFO - 2022-07-07 07:37:59 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:37:59 --> Controller Class Initialized
DEBUG - 2022-07-07 07:37:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:37:59 --> Final output sent to browser
DEBUG - 2022-07-07 07:37:59 --> Total execution time: 0.1388
INFO - 2022-07-07 07:38:01 --> Config Class Initialized
INFO - 2022-07-07 07:38:01 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:01 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:01 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:01 --> URI Class Initialized
INFO - 2022-07-07 07:38:01 --> Router Class Initialized
INFO - 2022-07-07 07:38:01 --> Output Class Initialized
INFO - 2022-07-07 07:38:01 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:01 --> Input Class Initialized
INFO - 2022-07-07 07:38:01 --> Language Class Initialized
INFO - 2022-07-07 07:38:01 --> Language Class Initialized
INFO - 2022-07-07 07:38:01 --> Config Class Initialized
INFO - 2022-07-07 07:38:01 --> Loader Class Initialized
INFO - 2022-07-07 07:38:01 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:01 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:01 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:01 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:01 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:01 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:01 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:01 --> Total execution time: 0.1523
INFO - 2022-07-07 07:38:01 --> Config Class Initialized
INFO - 2022-07-07 07:38:01 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:01 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:01 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:01 --> URI Class Initialized
INFO - 2022-07-07 07:38:01 --> Router Class Initialized
INFO - 2022-07-07 07:38:01 --> Output Class Initialized
INFO - 2022-07-07 07:38:01 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:01 --> Input Class Initialized
INFO - 2022-07-07 07:38:01 --> Language Class Initialized
INFO - 2022-07-07 07:38:01 --> Language Class Initialized
INFO - 2022-07-07 07:38:01 --> Config Class Initialized
INFO - 2022-07-07 07:38:01 --> Loader Class Initialized
INFO - 2022-07-07 07:38:01 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:01 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:01 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:01 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:01 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:01 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:01 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:01 --> Total execution time: 0.1185
INFO - 2022-07-07 07:38:10 --> Config Class Initialized
INFO - 2022-07-07 07:38:10 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:10 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:10 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:10 --> URI Class Initialized
INFO - 2022-07-07 07:38:10 --> Router Class Initialized
INFO - 2022-07-07 07:38:10 --> Output Class Initialized
INFO - 2022-07-07 07:38:10 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:10 --> Input Class Initialized
INFO - 2022-07-07 07:38:10 --> Language Class Initialized
INFO - 2022-07-07 07:38:10 --> Language Class Initialized
INFO - 2022-07-07 07:38:10 --> Config Class Initialized
INFO - 2022-07-07 07:38:10 --> Loader Class Initialized
INFO - 2022-07-07 07:38:10 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:10 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:10 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:10 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:10 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:10 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:11 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:11 --> Total execution time: 0.1802
INFO - 2022-07-07 07:38:11 --> Config Class Initialized
INFO - 2022-07-07 07:38:11 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:11 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:11 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:11 --> URI Class Initialized
INFO - 2022-07-07 07:38:11 --> Router Class Initialized
INFO - 2022-07-07 07:38:11 --> Output Class Initialized
INFO - 2022-07-07 07:38:11 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:11 --> Input Class Initialized
INFO - 2022-07-07 07:38:11 --> Language Class Initialized
INFO - 2022-07-07 07:38:11 --> Language Class Initialized
INFO - 2022-07-07 07:38:11 --> Config Class Initialized
INFO - 2022-07-07 07:38:11 --> Loader Class Initialized
INFO - 2022-07-07 07:38:11 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:11 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:11 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:11 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:11 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:11 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:11 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:11 --> Total execution time: 0.1344
INFO - 2022-07-07 07:38:17 --> Config Class Initialized
INFO - 2022-07-07 07:38:17 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:17 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:17 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:17 --> URI Class Initialized
INFO - 2022-07-07 07:38:17 --> Router Class Initialized
INFO - 2022-07-07 07:38:17 --> Output Class Initialized
INFO - 2022-07-07 07:38:17 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:17 --> Input Class Initialized
INFO - 2022-07-07 07:38:17 --> Language Class Initialized
INFO - 2022-07-07 07:38:17 --> Language Class Initialized
INFO - 2022-07-07 07:38:17 --> Config Class Initialized
INFO - 2022-07-07 07:38:17 --> Loader Class Initialized
INFO - 2022-07-07 07:38:17 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:17 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:17 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:17 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:17 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:17 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:17 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:17 --> Total execution time: 0.1420
INFO - 2022-07-07 07:38:27 --> Config Class Initialized
INFO - 2022-07-07 07:38:27 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:27 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:27 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:27 --> URI Class Initialized
INFO - 2022-07-07 07:38:27 --> Router Class Initialized
INFO - 2022-07-07 07:38:27 --> Output Class Initialized
INFO - 2022-07-07 07:38:27 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:27 --> Input Class Initialized
INFO - 2022-07-07 07:38:27 --> Language Class Initialized
INFO - 2022-07-07 07:38:27 --> Language Class Initialized
INFO - 2022-07-07 07:38:27 --> Config Class Initialized
INFO - 2022-07-07 07:38:27 --> Loader Class Initialized
INFO - 2022-07-07 07:38:27 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:27 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:27 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:27 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:27 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:27 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:27 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:27 --> Total execution time: 0.1461
INFO - 2022-07-07 07:38:29 --> Config Class Initialized
INFO - 2022-07-07 07:38:29 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:29 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:29 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:29 --> URI Class Initialized
INFO - 2022-07-07 07:38:29 --> Router Class Initialized
INFO - 2022-07-07 07:38:29 --> Output Class Initialized
INFO - 2022-07-07 07:38:29 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:29 --> Input Class Initialized
INFO - 2022-07-07 07:38:29 --> Language Class Initialized
INFO - 2022-07-07 07:38:29 --> Language Class Initialized
INFO - 2022-07-07 07:38:29 --> Config Class Initialized
INFO - 2022-07-07 07:38:29 --> Loader Class Initialized
INFO - 2022-07-07 07:38:29 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:29 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:29 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:29 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:29 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:29 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:29 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:29 --> Total execution time: 0.1458
INFO - 2022-07-07 07:38:32 --> Config Class Initialized
INFO - 2022-07-07 07:38:32 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:32 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:32 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:32 --> URI Class Initialized
INFO - 2022-07-07 07:38:32 --> Router Class Initialized
INFO - 2022-07-07 07:38:32 --> Output Class Initialized
INFO - 2022-07-07 07:38:32 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:32 --> Input Class Initialized
INFO - 2022-07-07 07:38:32 --> Language Class Initialized
INFO - 2022-07-07 07:38:32 --> Language Class Initialized
INFO - 2022-07-07 07:38:32 --> Config Class Initialized
INFO - 2022-07-07 07:38:32 --> Loader Class Initialized
INFO - 2022-07-07 07:38:32 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:32 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:32 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:32 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:32 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:32 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:32 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:32 --> Total execution time: 0.1452
INFO - 2022-07-07 07:38:35 --> Config Class Initialized
INFO - 2022-07-07 07:38:35 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:35 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:35 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:35 --> URI Class Initialized
INFO - 2022-07-07 07:38:35 --> Router Class Initialized
INFO - 2022-07-07 07:38:35 --> Output Class Initialized
INFO - 2022-07-07 07:38:35 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:35 --> Input Class Initialized
INFO - 2022-07-07 07:38:35 --> Language Class Initialized
INFO - 2022-07-07 07:38:35 --> Language Class Initialized
INFO - 2022-07-07 07:38:35 --> Config Class Initialized
INFO - 2022-07-07 07:38:35 --> Loader Class Initialized
INFO - 2022-07-07 07:38:35 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:35 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:35 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:35 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:35 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:35 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:35 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:35 --> Total execution time: 0.1481
INFO - 2022-07-07 07:38:37 --> Config Class Initialized
INFO - 2022-07-07 07:38:37 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:37 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:37 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:37 --> URI Class Initialized
INFO - 2022-07-07 07:38:37 --> Router Class Initialized
INFO - 2022-07-07 07:38:37 --> Output Class Initialized
INFO - 2022-07-07 07:38:37 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:37 --> Input Class Initialized
INFO - 2022-07-07 07:38:37 --> Language Class Initialized
INFO - 2022-07-07 07:38:37 --> Language Class Initialized
INFO - 2022-07-07 07:38:37 --> Config Class Initialized
INFO - 2022-07-07 07:38:37 --> Loader Class Initialized
INFO - 2022-07-07 07:38:37 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:37 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:37 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:37 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:37 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:37 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:37 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:37 --> Total execution time: 0.1444
INFO - 2022-07-07 07:38:39 --> Config Class Initialized
INFO - 2022-07-07 07:38:39 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:39 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:39 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:39 --> URI Class Initialized
INFO - 2022-07-07 07:38:39 --> Router Class Initialized
INFO - 2022-07-07 07:38:39 --> Output Class Initialized
INFO - 2022-07-07 07:38:39 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:39 --> Input Class Initialized
INFO - 2022-07-07 07:38:39 --> Language Class Initialized
INFO - 2022-07-07 07:38:39 --> Language Class Initialized
INFO - 2022-07-07 07:38:39 --> Config Class Initialized
INFO - 2022-07-07 07:38:39 --> Loader Class Initialized
INFO - 2022-07-07 07:38:39 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:39 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:39 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:39 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:39 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:39 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:39 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:39 --> Total execution time: 0.1512
INFO - 2022-07-07 07:38:41 --> Config Class Initialized
INFO - 2022-07-07 07:38:41 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:41 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:41 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:41 --> URI Class Initialized
INFO - 2022-07-07 07:38:41 --> Router Class Initialized
INFO - 2022-07-07 07:38:41 --> Output Class Initialized
INFO - 2022-07-07 07:38:41 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:41 --> Input Class Initialized
INFO - 2022-07-07 07:38:41 --> Language Class Initialized
INFO - 2022-07-07 07:38:41 --> Language Class Initialized
INFO - 2022-07-07 07:38:41 --> Config Class Initialized
INFO - 2022-07-07 07:38:41 --> Loader Class Initialized
INFO - 2022-07-07 07:38:41 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:41 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:41 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:41 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:41 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:41 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:41 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:41 --> Total execution time: 0.1490
INFO - 2022-07-07 07:38:43 --> Config Class Initialized
INFO - 2022-07-07 07:38:43 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:43 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:43 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:43 --> URI Class Initialized
INFO - 2022-07-07 07:38:43 --> Router Class Initialized
INFO - 2022-07-07 07:38:43 --> Output Class Initialized
INFO - 2022-07-07 07:38:43 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:43 --> Input Class Initialized
INFO - 2022-07-07 07:38:43 --> Language Class Initialized
INFO - 2022-07-07 07:38:43 --> Language Class Initialized
INFO - 2022-07-07 07:38:43 --> Config Class Initialized
INFO - 2022-07-07 07:38:43 --> Loader Class Initialized
INFO - 2022-07-07 07:38:43 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:43 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:43 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:43 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:43 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:43 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:43 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:43 --> Total execution time: 0.1482
INFO - 2022-07-07 07:38:45 --> Config Class Initialized
INFO - 2022-07-07 07:38:45 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:45 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:45 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:45 --> URI Class Initialized
INFO - 2022-07-07 07:38:45 --> Router Class Initialized
INFO - 2022-07-07 07:38:45 --> Output Class Initialized
INFO - 2022-07-07 07:38:45 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:45 --> Input Class Initialized
INFO - 2022-07-07 07:38:45 --> Language Class Initialized
INFO - 2022-07-07 07:38:45 --> Language Class Initialized
INFO - 2022-07-07 07:38:45 --> Config Class Initialized
INFO - 2022-07-07 07:38:45 --> Loader Class Initialized
INFO - 2022-07-07 07:38:45 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:45 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:46 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:46 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:46 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:46 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:46 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:46 --> Total execution time: 0.1480
INFO - 2022-07-07 07:38:48 --> Config Class Initialized
INFO - 2022-07-07 07:38:48 --> Hooks Class Initialized
DEBUG - 2022-07-07 07:38:48 --> UTF-8 Support Enabled
INFO - 2022-07-07 07:38:48 --> Utf8 Class Initialized
INFO - 2022-07-07 07:38:48 --> URI Class Initialized
INFO - 2022-07-07 07:38:48 --> Router Class Initialized
INFO - 2022-07-07 07:38:48 --> Output Class Initialized
INFO - 2022-07-07 07:38:48 --> Security Class Initialized
DEBUG - 2022-07-07 07:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-07 07:38:48 --> Input Class Initialized
INFO - 2022-07-07 07:38:48 --> Language Class Initialized
INFO - 2022-07-07 07:38:48 --> Language Class Initialized
INFO - 2022-07-07 07:38:48 --> Config Class Initialized
INFO - 2022-07-07 07:38:48 --> Loader Class Initialized
INFO - 2022-07-07 07:38:48 --> Helper loaded: url_helper
INFO - 2022-07-07 07:38:48 --> Helper loaded: file_helper
INFO - 2022-07-07 07:38:48 --> Helper loaded: form_helper
INFO - 2022-07-07 07:38:48 --> Helper loaded: my_helper
INFO - 2022-07-07 07:38:48 --> Database Driver Class Initialized
DEBUG - 2022-07-07 07:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-07 07:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-07 07:38:48 --> Controller Class Initialized
DEBUG - 2022-07-07 07:38:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-07 07:38:48 --> Final output sent to browser
DEBUG - 2022-07-07 07:38:48 --> Total execution time: 0.1481
