<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-11 02:02:01 --> Config Class Initialized
INFO - 2021-01-11 02:02:01 --> Hooks Class Initialized
DEBUG - 2021-01-11 02:02:01 --> UTF-8 Support Enabled
INFO - 2021-01-11 02:02:01 --> Utf8 Class Initialized
INFO - 2021-01-11 02:02:01 --> URI Class Initialized
DEBUG - 2021-01-11 02:02:01 --> No URI present. Default controller set.
INFO - 2021-01-11 02:02:01 --> Router Class Initialized
INFO - 2021-01-11 02:02:01 --> Output Class Initialized
INFO - 2021-01-11 02:02:01 --> Security Class Initialized
DEBUG - 2021-01-11 02:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 02:02:01 --> Input Class Initialized
INFO - 2021-01-11 02:02:01 --> Language Class Initialized
INFO - 2021-01-11 02:02:01 --> Language Class Initialized
INFO - 2021-01-11 02:02:01 --> Config Class Initialized
INFO - 2021-01-11 02:02:01 --> Loader Class Initialized
INFO - 2021-01-11 02:02:01 --> Helper loaded: url_helper
INFO - 2021-01-11 02:02:01 --> Helper loaded: file_helper
INFO - 2021-01-11 02:02:01 --> Helper loaded: form_helper
INFO - 2021-01-11 02:02:01 --> Helper loaded: my_helper
INFO - 2021-01-11 02:02:01 --> Database Driver Class Initialized
DEBUG - 2021-01-11 02:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 02:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 02:02:01 --> Controller Class Initialized
INFO - 2021-01-11 02:02:01 --> Config Class Initialized
INFO - 2021-01-11 02:02:01 --> Hooks Class Initialized
DEBUG - 2021-01-11 02:02:01 --> UTF-8 Support Enabled
INFO - 2021-01-11 02:02:01 --> Utf8 Class Initialized
INFO - 2021-01-11 02:02:01 --> URI Class Initialized
INFO - 2021-01-11 02:02:01 --> Router Class Initialized
INFO - 2021-01-11 02:02:01 --> Output Class Initialized
INFO - 2021-01-11 02:02:01 --> Security Class Initialized
DEBUG - 2021-01-11 02:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 02:02:01 --> Input Class Initialized
INFO - 2021-01-11 02:02:01 --> Language Class Initialized
INFO - 2021-01-11 02:02:01 --> Language Class Initialized
INFO - 2021-01-11 02:02:01 --> Config Class Initialized
INFO - 2021-01-11 02:02:01 --> Loader Class Initialized
INFO - 2021-01-11 02:02:01 --> Helper loaded: url_helper
INFO - 2021-01-11 02:02:01 --> Helper loaded: file_helper
INFO - 2021-01-11 02:02:01 --> Helper loaded: form_helper
INFO - 2021-01-11 02:02:01 --> Helper loaded: my_helper
INFO - 2021-01-11 02:02:01 --> Database Driver Class Initialized
DEBUG - 2021-01-11 02:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 02:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 02:02:01 --> Controller Class Initialized
DEBUG - 2021-01-11 02:02:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-11 02:02:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 02:02:02 --> Final output sent to browser
DEBUG - 2021-01-11 02:02:02 --> Total execution time: 0.2408
INFO - 2021-01-11 02:02:10 --> Config Class Initialized
INFO - 2021-01-11 02:02:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 02:02:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 02:02:10 --> Utf8 Class Initialized
INFO - 2021-01-11 02:02:10 --> URI Class Initialized
INFO - 2021-01-11 02:02:10 --> Router Class Initialized
INFO - 2021-01-11 02:02:10 --> Output Class Initialized
INFO - 2021-01-11 02:02:10 --> Security Class Initialized
DEBUG - 2021-01-11 02:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 02:02:10 --> Input Class Initialized
INFO - 2021-01-11 02:02:10 --> Language Class Initialized
INFO - 2021-01-11 02:02:10 --> Language Class Initialized
INFO - 2021-01-11 02:02:10 --> Config Class Initialized
INFO - 2021-01-11 02:02:10 --> Loader Class Initialized
INFO - 2021-01-11 02:02:10 --> Helper loaded: url_helper
INFO - 2021-01-11 02:02:10 --> Helper loaded: file_helper
INFO - 2021-01-11 02:02:10 --> Helper loaded: form_helper
INFO - 2021-01-11 02:02:10 --> Helper loaded: my_helper
INFO - 2021-01-11 02:02:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 02:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 02:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 02:02:10 --> Controller Class Initialized
INFO - 2021-01-11 02:02:11 --> Helper loaded: cookie_helper
INFO - 2021-01-11 02:02:11 --> Final output sent to browser
DEBUG - 2021-01-11 02:02:11 --> Total execution time: 0.3041
INFO - 2021-01-11 02:02:11 --> Config Class Initialized
INFO - 2021-01-11 02:02:11 --> Hooks Class Initialized
DEBUG - 2021-01-11 02:02:11 --> UTF-8 Support Enabled
INFO - 2021-01-11 02:02:11 --> Utf8 Class Initialized
INFO - 2021-01-11 02:02:11 --> URI Class Initialized
INFO - 2021-01-11 02:02:11 --> Router Class Initialized
INFO - 2021-01-11 02:02:11 --> Output Class Initialized
INFO - 2021-01-11 02:02:11 --> Security Class Initialized
DEBUG - 2021-01-11 02:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 02:02:11 --> Input Class Initialized
INFO - 2021-01-11 02:02:11 --> Language Class Initialized
INFO - 2021-01-11 02:02:11 --> Language Class Initialized
INFO - 2021-01-11 02:02:11 --> Config Class Initialized
INFO - 2021-01-11 02:02:11 --> Loader Class Initialized
INFO - 2021-01-11 02:02:11 --> Helper loaded: url_helper
INFO - 2021-01-11 02:02:11 --> Helper loaded: file_helper
INFO - 2021-01-11 02:02:11 --> Helper loaded: form_helper
INFO - 2021-01-11 02:02:11 --> Helper loaded: my_helper
INFO - 2021-01-11 02:02:11 --> Database Driver Class Initialized
DEBUG - 2021-01-11 02:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 02:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 02:02:11 --> Controller Class Initialized
DEBUG - 2021-01-11 02:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-11 02:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 02:02:11 --> Final output sent to browser
DEBUG - 2021-01-11 02:02:11 --> Total execution time: 0.3909
INFO - 2021-01-11 02:02:13 --> Config Class Initialized
INFO - 2021-01-11 02:02:13 --> Hooks Class Initialized
DEBUG - 2021-01-11 02:02:13 --> UTF-8 Support Enabled
INFO - 2021-01-11 02:02:13 --> Utf8 Class Initialized
INFO - 2021-01-11 02:02:13 --> URI Class Initialized
INFO - 2021-01-11 02:02:13 --> Router Class Initialized
INFO - 2021-01-11 02:02:13 --> Output Class Initialized
INFO - 2021-01-11 02:02:13 --> Security Class Initialized
DEBUG - 2021-01-11 02:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 02:02:13 --> Input Class Initialized
INFO - 2021-01-11 02:02:13 --> Language Class Initialized
ERROR - 2021-01-11 02:02:13 --> Severity: Parsing Error --> syntax error, unexpected '$d' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 490
INFO - 2021-01-11 02:02:59 --> Config Class Initialized
INFO - 2021-01-11 02:02:59 --> Hooks Class Initialized
DEBUG - 2021-01-11 02:02:59 --> UTF-8 Support Enabled
INFO - 2021-01-11 02:02:59 --> Utf8 Class Initialized
INFO - 2021-01-11 02:02:59 --> URI Class Initialized
INFO - 2021-01-11 02:02:59 --> Router Class Initialized
INFO - 2021-01-11 02:02:59 --> Output Class Initialized
INFO - 2021-01-11 02:02:59 --> Security Class Initialized
DEBUG - 2021-01-11 02:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 02:02:59 --> Input Class Initialized
INFO - 2021-01-11 02:02:59 --> Language Class Initialized
INFO - 2021-01-11 02:02:59 --> Language Class Initialized
INFO - 2021-01-11 02:02:59 --> Config Class Initialized
INFO - 2021-01-11 02:02:59 --> Loader Class Initialized
INFO - 2021-01-11 02:02:59 --> Helper loaded: url_helper
INFO - 2021-01-11 02:02:59 --> Helper loaded: file_helper
INFO - 2021-01-11 02:02:59 --> Helper loaded: form_helper
INFO - 2021-01-11 02:02:59 --> Helper loaded: my_helper
INFO - 2021-01-11 02:02:59 --> Database Driver Class Initialized
DEBUG - 2021-01-11 02:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 02:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 02:02:59 --> Controller Class Initialized
DEBUG - 2021-01-11 02:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 02:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 02:02:59 --> Final output sent to browser
DEBUG - 2021-01-11 02:02:59 --> Total execution time: 0.2191
INFO - 2021-01-11 02:03:02 --> Config Class Initialized
INFO - 2021-01-11 02:03:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 02:03:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 02:03:02 --> Utf8 Class Initialized
INFO - 2021-01-11 02:03:02 --> URI Class Initialized
INFO - 2021-01-11 02:03:02 --> Router Class Initialized
INFO - 2021-01-11 02:03:02 --> Output Class Initialized
INFO - 2021-01-11 02:03:02 --> Security Class Initialized
DEBUG - 2021-01-11 02:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 02:03:02 --> Input Class Initialized
INFO - 2021-01-11 02:03:02 --> Language Class Initialized
INFO - 2021-01-11 02:03:02 --> Language Class Initialized
INFO - 2021-01-11 02:03:02 --> Config Class Initialized
INFO - 2021-01-11 02:03:02 --> Loader Class Initialized
INFO - 2021-01-11 02:03:02 --> Helper loaded: url_helper
INFO - 2021-01-11 02:03:02 --> Helper loaded: file_helper
INFO - 2021-01-11 02:03:02 --> Helper loaded: form_helper
INFO - 2021-01-11 02:03:02 --> Helper loaded: my_helper
INFO - 2021-01-11 02:03:02 --> Database Driver Class Initialized
DEBUG - 2021-01-11 02:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 02:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 02:03:02 --> Controller Class Initialized
DEBUG - 2021-01-11 02:03:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-11 02:03:02 --> Final output sent to browser
DEBUG - 2021-01-11 02:03:02 --> Total execution time: 0.2715
INFO - 2021-01-11 02:03:06 --> Config Class Initialized
INFO - 2021-01-11 02:03:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 02:03:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 02:03:06 --> Utf8 Class Initialized
INFO - 2021-01-11 02:03:06 --> URI Class Initialized
INFO - 2021-01-11 02:03:06 --> Router Class Initialized
INFO - 2021-01-11 02:03:06 --> Output Class Initialized
INFO - 2021-01-11 02:03:06 --> Security Class Initialized
DEBUG - 2021-01-11 02:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 02:03:06 --> Input Class Initialized
INFO - 2021-01-11 02:03:06 --> Language Class Initialized
ERROR - 2021-01-11 02:03:06 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/cetak
INFO - 2021-01-11 08:01:16 --> Config Class Initialized
INFO - 2021-01-11 08:01:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:16 --> URI Class Initialized
INFO - 2021-01-11 08:01:16 --> Router Class Initialized
INFO - 2021-01-11 08:01:17 --> Output Class Initialized
INFO - 2021-01-11 08:01:17 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:17 --> Input Class Initialized
INFO - 2021-01-11 08:01:17 --> Language Class Initialized
INFO - 2021-01-11 08:01:17 --> Language Class Initialized
INFO - 2021-01-11 08:01:17 --> Config Class Initialized
INFO - 2021-01-11 08:01:17 --> Loader Class Initialized
INFO - 2021-01-11 08:01:17 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:17 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:17 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:17 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:17 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:17 --> Controller Class Initialized
INFO - 2021-01-11 08:01:17 --> Helper loaded: cookie_helper
INFO - 2021-01-11 08:01:17 --> Config Class Initialized
INFO - 2021-01-11 08:01:17 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:17 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:17 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:17 --> URI Class Initialized
INFO - 2021-01-11 08:01:17 --> Router Class Initialized
INFO - 2021-01-11 08:01:17 --> Output Class Initialized
INFO - 2021-01-11 08:01:17 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:17 --> Input Class Initialized
INFO - 2021-01-11 08:01:17 --> Language Class Initialized
INFO - 2021-01-11 08:01:17 --> Language Class Initialized
INFO - 2021-01-11 08:01:17 --> Config Class Initialized
INFO - 2021-01-11 08:01:17 --> Loader Class Initialized
INFO - 2021-01-11 08:01:17 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:17 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:17 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:17 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:17 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:17 --> Controller Class Initialized
DEBUG - 2021-01-11 08:01:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-11 08:01:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:01:17 --> Final output sent to browser
DEBUG - 2021-01-11 08:01:17 --> Total execution time: 0.2825
INFO - 2021-01-11 08:01:23 --> Config Class Initialized
INFO - 2021-01-11 08:01:23 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:23 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:23 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:23 --> URI Class Initialized
INFO - 2021-01-11 08:01:23 --> Router Class Initialized
INFO - 2021-01-11 08:01:23 --> Output Class Initialized
INFO - 2021-01-11 08:01:23 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:23 --> Input Class Initialized
INFO - 2021-01-11 08:01:23 --> Language Class Initialized
INFO - 2021-01-11 08:01:23 --> Language Class Initialized
INFO - 2021-01-11 08:01:23 --> Config Class Initialized
INFO - 2021-01-11 08:01:23 --> Loader Class Initialized
INFO - 2021-01-11 08:01:23 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:23 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:23 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:23 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:23 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:23 --> Controller Class Initialized
INFO - 2021-01-11 08:01:23 --> Helper loaded: cookie_helper
INFO - 2021-01-11 08:01:23 --> Final output sent to browser
DEBUG - 2021-01-11 08:01:23 --> Total execution time: 0.2945
INFO - 2021-01-11 08:01:23 --> Config Class Initialized
INFO - 2021-01-11 08:01:23 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:23 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:23 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:24 --> URI Class Initialized
INFO - 2021-01-11 08:01:24 --> Router Class Initialized
INFO - 2021-01-11 08:01:24 --> Output Class Initialized
INFO - 2021-01-11 08:01:24 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:24 --> Input Class Initialized
INFO - 2021-01-11 08:01:24 --> Language Class Initialized
INFO - 2021-01-11 08:01:24 --> Language Class Initialized
INFO - 2021-01-11 08:01:24 --> Config Class Initialized
INFO - 2021-01-11 08:01:24 --> Loader Class Initialized
INFO - 2021-01-11 08:01:24 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:24 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:24 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:24 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:24 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:24 --> Controller Class Initialized
DEBUG - 2021-01-11 08:01:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-11 08:01:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:01:24 --> Final output sent to browser
DEBUG - 2021-01-11 08:01:24 --> Total execution time: 0.3182
INFO - 2021-01-11 08:01:32 --> Config Class Initialized
INFO - 2021-01-11 08:01:32 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:32 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:32 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:32 --> URI Class Initialized
INFO - 2021-01-11 08:01:32 --> Router Class Initialized
INFO - 2021-01-11 08:01:32 --> Output Class Initialized
INFO - 2021-01-11 08:01:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:32 --> Input Class Initialized
INFO - 2021-01-11 08:01:32 --> Language Class Initialized
INFO - 2021-01-11 08:01:32 --> Language Class Initialized
INFO - 2021-01-11 08:01:32 --> Config Class Initialized
INFO - 2021-01-11 08:01:32 --> Loader Class Initialized
INFO - 2021-01-11 08:01:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:32 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:32 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:32 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:32 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:32 --> Controller Class Initialized
DEBUG - 2021-01-11 08:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:01:32 --> Final output sent to browser
DEBUG - 2021-01-11 08:01:32 --> Total execution time: 0.2772
INFO - 2021-01-11 08:01:35 --> Config Class Initialized
INFO - 2021-01-11 08:01:35 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:35 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:35 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:35 --> URI Class Initialized
INFO - 2021-01-11 08:01:35 --> Router Class Initialized
INFO - 2021-01-11 08:01:35 --> Output Class Initialized
INFO - 2021-01-11 08:01:35 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:35 --> Input Class Initialized
INFO - 2021-01-11 08:01:35 --> Language Class Initialized
INFO - 2021-01-11 08:01:35 --> Language Class Initialized
INFO - 2021-01-11 08:01:35 --> Config Class Initialized
INFO - 2021-01-11 08:01:35 --> Loader Class Initialized
INFO - 2021-01-11 08:01:35 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:35 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:35 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:35 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:35 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:35 --> Controller Class Initialized
DEBUG - 2021-01-11 08:01:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:01:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:01:35 --> Final output sent to browser
DEBUG - 2021-01-11 08:01:35 --> Total execution time: 0.2150
INFO - 2021-01-11 08:01:35 --> Config Class Initialized
INFO - 2021-01-11 08:01:35 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:35 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:35 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:35 --> URI Class Initialized
INFO - 2021-01-11 08:01:35 --> Router Class Initialized
INFO - 2021-01-11 08:01:35 --> Output Class Initialized
INFO - 2021-01-11 08:01:35 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:35 --> Input Class Initialized
INFO - 2021-01-11 08:01:35 --> Language Class Initialized
INFO - 2021-01-11 08:01:35 --> Language Class Initialized
INFO - 2021-01-11 08:01:35 --> Config Class Initialized
INFO - 2021-01-11 08:01:35 --> Loader Class Initialized
INFO - 2021-01-11 08:01:35 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:35 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:35 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:35 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:35 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:36 --> Controller Class Initialized
INFO - 2021-01-11 08:01:37 --> Config Class Initialized
INFO - 2021-01-11 08:01:37 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:37 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:37 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:37 --> URI Class Initialized
INFO - 2021-01-11 08:01:37 --> Router Class Initialized
INFO - 2021-01-11 08:01:37 --> Output Class Initialized
INFO - 2021-01-11 08:01:37 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:37 --> Input Class Initialized
INFO - 2021-01-11 08:01:37 --> Language Class Initialized
INFO - 2021-01-11 08:01:37 --> Language Class Initialized
INFO - 2021-01-11 08:01:37 --> Config Class Initialized
INFO - 2021-01-11 08:01:37 --> Loader Class Initialized
INFO - 2021-01-11 08:01:37 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:37 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:37 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:37 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:37 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:37 --> Controller Class Initialized
INFO - 2021-01-11 08:01:37 --> Final output sent to browser
DEBUG - 2021-01-11 08:01:37 --> Total execution time: 0.1724
INFO - 2021-01-11 08:01:38 --> Config Class Initialized
INFO - 2021-01-11 08:01:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:39 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:39 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:39 --> URI Class Initialized
INFO - 2021-01-11 08:01:39 --> Router Class Initialized
INFO - 2021-01-11 08:01:39 --> Output Class Initialized
INFO - 2021-01-11 08:01:39 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:39 --> Input Class Initialized
INFO - 2021-01-11 08:01:39 --> Language Class Initialized
INFO - 2021-01-11 08:01:39 --> Language Class Initialized
INFO - 2021-01-11 08:01:39 --> Config Class Initialized
INFO - 2021-01-11 08:01:39 --> Loader Class Initialized
INFO - 2021-01-11 08:01:39 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:39 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:39 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:39 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:39 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:39 --> Controller Class Initialized
DEBUG - 2021-01-11 08:01:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:01:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:01:39 --> Final output sent to browser
DEBUG - 2021-01-11 08:01:39 --> Total execution time: 0.2452
INFO - 2021-01-11 08:01:40 --> Config Class Initialized
INFO - 2021-01-11 08:01:40 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:40 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:40 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:40 --> URI Class Initialized
INFO - 2021-01-11 08:01:40 --> Router Class Initialized
INFO - 2021-01-11 08:01:40 --> Output Class Initialized
INFO - 2021-01-11 08:01:40 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:40 --> Input Class Initialized
INFO - 2021-01-11 08:01:40 --> Language Class Initialized
INFO - 2021-01-11 08:01:40 --> Language Class Initialized
INFO - 2021-01-11 08:01:40 --> Config Class Initialized
INFO - 2021-01-11 08:01:40 --> Loader Class Initialized
INFO - 2021-01-11 08:01:40 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:40 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:40 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:40 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:40 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:40 --> Controller Class Initialized
DEBUG - 2021-01-11 08:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:01:40 --> Final output sent to browser
DEBUG - 2021-01-11 08:01:40 --> Total execution time: 0.2464
INFO - 2021-01-11 08:01:40 --> Config Class Initialized
INFO - 2021-01-11 08:01:40 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:40 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:40 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:41 --> URI Class Initialized
INFO - 2021-01-11 08:01:41 --> Router Class Initialized
INFO - 2021-01-11 08:01:41 --> Output Class Initialized
INFO - 2021-01-11 08:01:41 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:41 --> Input Class Initialized
INFO - 2021-01-11 08:01:41 --> Language Class Initialized
INFO - 2021-01-11 08:01:41 --> Language Class Initialized
INFO - 2021-01-11 08:01:41 --> Config Class Initialized
INFO - 2021-01-11 08:01:41 --> Loader Class Initialized
INFO - 2021-01-11 08:01:41 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:41 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:41 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:41 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:41 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:41 --> Controller Class Initialized
INFO - 2021-01-11 08:01:42 --> Config Class Initialized
INFO - 2021-01-11 08:01:42 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:01:42 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:01:42 --> Utf8 Class Initialized
INFO - 2021-01-11 08:01:42 --> URI Class Initialized
INFO - 2021-01-11 08:01:42 --> Router Class Initialized
INFO - 2021-01-11 08:01:43 --> Output Class Initialized
INFO - 2021-01-11 08:01:43 --> Security Class Initialized
DEBUG - 2021-01-11 08:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:01:43 --> Input Class Initialized
INFO - 2021-01-11 08:01:43 --> Language Class Initialized
INFO - 2021-01-11 08:01:43 --> Language Class Initialized
INFO - 2021-01-11 08:01:43 --> Config Class Initialized
INFO - 2021-01-11 08:01:43 --> Loader Class Initialized
INFO - 2021-01-11 08:01:43 --> Helper loaded: url_helper
INFO - 2021-01-11 08:01:43 --> Helper loaded: file_helper
INFO - 2021-01-11 08:01:43 --> Helper loaded: form_helper
INFO - 2021-01-11 08:01:43 --> Helper loaded: my_helper
INFO - 2021-01-11 08:01:43 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:01:43 --> Controller Class Initialized
INFO - 2021-01-11 08:01:43 --> Final output sent to browser
DEBUG - 2021-01-11 08:01:43 --> Total execution time: 0.1733
INFO - 2021-01-11 08:02:10 --> Config Class Initialized
INFO - 2021-01-11 08:02:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:02:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:02:10 --> Utf8 Class Initialized
INFO - 2021-01-11 08:02:10 --> URI Class Initialized
INFO - 2021-01-11 08:02:10 --> Router Class Initialized
INFO - 2021-01-11 08:02:10 --> Output Class Initialized
INFO - 2021-01-11 08:02:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:02:10 --> Input Class Initialized
INFO - 2021-01-11 08:02:10 --> Language Class Initialized
INFO - 2021-01-11 08:02:10 --> Language Class Initialized
INFO - 2021-01-11 08:02:10 --> Config Class Initialized
INFO - 2021-01-11 08:02:10 --> Loader Class Initialized
INFO - 2021-01-11 08:02:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:02:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:02:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:02:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:02:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:02:10 --> Controller Class Initialized
INFO - 2021-01-11 08:02:10 --> Final output sent to browser
DEBUG - 2021-01-11 08:02:10 --> Total execution time: 0.2905
INFO - 2021-01-11 08:02:14 --> Config Class Initialized
INFO - 2021-01-11 08:02:15 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:02:15 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:02:15 --> Utf8 Class Initialized
INFO - 2021-01-11 08:02:15 --> URI Class Initialized
INFO - 2021-01-11 08:02:15 --> Router Class Initialized
INFO - 2021-01-11 08:02:15 --> Output Class Initialized
INFO - 2021-01-11 08:02:15 --> Security Class Initialized
DEBUG - 2021-01-11 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:02:15 --> Input Class Initialized
INFO - 2021-01-11 08:02:15 --> Language Class Initialized
INFO - 2021-01-11 08:02:15 --> Language Class Initialized
INFO - 2021-01-11 08:02:15 --> Config Class Initialized
INFO - 2021-01-11 08:02:15 --> Loader Class Initialized
INFO - 2021-01-11 08:02:15 --> Helper loaded: url_helper
INFO - 2021-01-11 08:02:15 --> Helper loaded: file_helper
INFO - 2021-01-11 08:02:15 --> Helper loaded: form_helper
INFO - 2021-01-11 08:02:15 --> Helper loaded: my_helper
INFO - 2021-01-11 08:02:15 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:02:15 --> Controller Class Initialized
INFO - 2021-01-11 08:02:15 --> Final output sent to browser
DEBUG - 2021-01-11 08:02:15 --> Total execution time: 0.1824
INFO - 2021-01-11 08:02:21 --> Config Class Initialized
INFO - 2021-01-11 08:02:21 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:02:21 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:02:21 --> Utf8 Class Initialized
INFO - 2021-01-11 08:02:21 --> URI Class Initialized
INFO - 2021-01-11 08:02:21 --> Router Class Initialized
INFO - 2021-01-11 08:02:21 --> Output Class Initialized
INFO - 2021-01-11 08:02:21 --> Security Class Initialized
DEBUG - 2021-01-11 08:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:02:21 --> Input Class Initialized
INFO - 2021-01-11 08:02:21 --> Language Class Initialized
INFO - 2021-01-11 08:02:21 --> Language Class Initialized
INFO - 2021-01-11 08:02:21 --> Config Class Initialized
INFO - 2021-01-11 08:02:21 --> Loader Class Initialized
INFO - 2021-01-11 08:02:21 --> Helper loaded: url_helper
INFO - 2021-01-11 08:02:21 --> Helper loaded: file_helper
INFO - 2021-01-11 08:02:21 --> Helper loaded: form_helper
INFO - 2021-01-11 08:02:21 --> Helper loaded: my_helper
INFO - 2021-01-11 08:02:21 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:02:21 --> Controller Class Initialized
INFO - 2021-01-11 08:02:21 --> Final output sent to browser
DEBUG - 2021-01-11 08:02:21 --> Total execution time: 0.3248
INFO - 2021-01-11 08:02:30 --> Config Class Initialized
INFO - 2021-01-11 08:02:30 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:02:30 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:02:30 --> Utf8 Class Initialized
INFO - 2021-01-11 08:02:30 --> URI Class Initialized
INFO - 2021-01-11 08:02:30 --> Router Class Initialized
INFO - 2021-01-11 08:02:30 --> Output Class Initialized
INFO - 2021-01-11 08:02:30 --> Security Class Initialized
DEBUG - 2021-01-11 08:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:02:30 --> Input Class Initialized
INFO - 2021-01-11 08:02:30 --> Language Class Initialized
INFO - 2021-01-11 08:02:30 --> Language Class Initialized
INFO - 2021-01-11 08:02:30 --> Config Class Initialized
INFO - 2021-01-11 08:02:30 --> Loader Class Initialized
INFO - 2021-01-11 08:02:30 --> Helper loaded: url_helper
INFO - 2021-01-11 08:02:30 --> Helper loaded: file_helper
INFO - 2021-01-11 08:02:30 --> Helper loaded: form_helper
INFO - 2021-01-11 08:02:30 --> Helper loaded: my_helper
INFO - 2021-01-11 08:02:30 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:02:30 --> Controller Class Initialized
INFO - 2021-01-11 08:02:30 --> Final output sent to browser
DEBUG - 2021-01-11 08:02:30 --> Total execution time: 0.1794
INFO - 2021-01-11 08:02:38 --> Config Class Initialized
INFO - 2021-01-11 08:02:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:02:38 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:02:38 --> Utf8 Class Initialized
INFO - 2021-01-11 08:02:38 --> URI Class Initialized
INFO - 2021-01-11 08:02:38 --> Router Class Initialized
INFO - 2021-01-11 08:02:38 --> Output Class Initialized
INFO - 2021-01-11 08:02:38 --> Security Class Initialized
DEBUG - 2021-01-11 08:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:02:38 --> Input Class Initialized
INFO - 2021-01-11 08:02:38 --> Language Class Initialized
INFO - 2021-01-11 08:02:38 --> Language Class Initialized
INFO - 2021-01-11 08:02:38 --> Config Class Initialized
INFO - 2021-01-11 08:02:38 --> Loader Class Initialized
INFO - 2021-01-11 08:02:38 --> Helper loaded: url_helper
INFO - 2021-01-11 08:02:38 --> Helper loaded: file_helper
INFO - 2021-01-11 08:02:38 --> Helper loaded: form_helper
INFO - 2021-01-11 08:02:38 --> Helper loaded: my_helper
INFO - 2021-01-11 08:02:38 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:02:38 --> Controller Class Initialized
INFO - 2021-01-11 08:02:38 --> Final output sent to browser
DEBUG - 2021-01-11 08:02:38 --> Total execution time: 0.3236
INFO - 2021-01-11 08:02:41 --> Config Class Initialized
INFO - 2021-01-11 08:02:41 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:02:41 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:02:41 --> Utf8 Class Initialized
INFO - 2021-01-11 08:02:41 --> URI Class Initialized
INFO - 2021-01-11 08:02:41 --> Router Class Initialized
INFO - 2021-01-11 08:02:41 --> Output Class Initialized
INFO - 2021-01-11 08:02:41 --> Security Class Initialized
DEBUG - 2021-01-11 08:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:02:41 --> Input Class Initialized
INFO - 2021-01-11 08:02:41 --> Language Class Initialized
INFO - 2021-01-11 08:02:41 --> Language Class Initialized
INFO - 2021-01-11 08:02:41 --> Config Class Initialized
INFO - 2021-01-11 08:02:41 --> Loader Class Initialized
INFO - 2021-01-11 08:02:41 --> Helper loaded: url_helper
INFO - 2021-01-11 08:02:41 --> Helper loaded: file_helper
INFO - 2021-01-11 08:02:41 --> Helper loaded: form_helper
INFO - 2021-01-11 08:02:41 --> Helper loaded: my_helper
INFO - 2021-01-11 08:02:41 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:02:41 --> Controller Class Initialized
INFO - 2021-01-11 08:02:41 --> Final output sent to browser
DEBUG - 2021-01-11 08:02:41 --> Total execution time: 0.2035
INFO - 2021-01-11 08:02:51 --> Config Class Initialized
INFO - 2021-01-11 08:02:51 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:02:51 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:02:51 --> Utf8 Class Initialized
INFO - 2021-01-11 08:02:51 --> URI Class Initialized
INFO - 2021-01-11 08:02:51 --> Router Class Initialized
INFO - 2021-01-11 08:02:51 --> Output Class Initialized
INFO - 2021-01-11 08:02:51 --> Security Class Initialized
DEBUG - 2021-01-11 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:02:51 --> Input Class Initialized
INFO - 2021-01-11 08:02:51 --> Language Class Initialized
INFO - 2021-01-11 08:02:51 --> Language Class Initialized
INFO - 2021-01-11 08:02:51 --> Config Class Initialized
INFO - 2021-01-11 08:02:51 --> Loader Class Initialized
INFO - 2021-01-11 08:02:51 --> Helper loaded: url_helper
INFO - 2021-01-11 08:02:51 --> Helper loaded: file_helper
INFO - 2021-01-11 08:02:51 --> Helper loaded: form_helper
INFO - 2021-01-11 08:02:51 --> Helper loaded: my_helper
INFO - 2021-01-11 08:02:51 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:02:51 --> Controller Class Initialized
INFO - 2021-01-11 08:02:51 --> Final output sent to browser
DEBUG - 2021-01-11 08:02:51 --> Total execution time: 0.2841
INFO - 2021-01-11 08:02:59 --> Config Class Initialized
INFO - 2021-01-11 08:02:59 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:02:59 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:02:59 --> Utf8 Class Initialized
INFO - 2021-01-11 08:02:59 --> URI Class Initialized
INFO - 2021-01-11 08:02:59 --> Router Class Initialized
INFO - 2021-01-11 08:02:59 --> Output Class Initialized
INFO - 2021-01-11 08:02:59 --> Security Class Initialized
DEBUG - 2021-01-11 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:02:59 --> Input Class Initialized
INFO - 2021-01-11 08:02:59 --> Language Class Initialized
INFO - 2021-01-11 08:02:59 --> Language Class Initialized
INFO - 2021-01-11 08:02:59 --> Config Class Initialized
INFO - 2021-01-11 08:02:59 --> Loader Class Initialized
INFO - 2021-01-11 08:02:59 --> Helper loaded: url_helper
INFO - 2021-01-11 08:02:59 --> Helper loaded: file_helper
INFO - 2021-01-11 08:02:59 --> Helper loaded: form_helper
INFO - 2021-01-11 08:02:59 --> Helper loaded: my_helper
INFO - 2021-01-11 08:02:59 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:02:59 --> Controller Class Initialized
INFO - 2021-01-11 08:02:59 --> Final output sent to browser
DEBUG - 2021-01-11 08:02:59 --> Total execution time: 0.2431
INFO - 2021-01-11 08:03:03 --> Config Class Initialized
INFO - 2021-01-11 08:03:04 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:03:04 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:03:04 --> Utf8 Class Initialized
INFO - 2021-01-11 08:03:04 --> URI Class Initialized
INFO - 2021-01-11 08:03:04 --> Router Class Initialized
INFO - 2021-01-11 08:03:04 --> Output Class Initialized
INFO - 2021-01-11 08:03:04 --> Security Class Initialized
DEBUG - 2021-01-11 08:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:03:04 --> Input Class Initialized
INFO - 2021-01-11 08:03:04 --> Language Class Initialized
INFO - 2021-01-11 08:03:04 --> Language Class Initialized
INFO - 2021-01-11 08:03:04 --> Config Class Initialized
INFO - 2021-01-11 08:03:04 --> Loader Class Initialized
INFO - 2021-01-11 08:03:04 --> Helper loaded: url_helper
INFO - 2021-01-11 08:03:04 --> Helper loaded: file_helper
INFO - 2021-01-11 08:03:04 --> Helper loaded: form_helper
INFO - 2021-01-11 08:03:04 --> Helper loaded: my_helper
INFO - 2021-01-11 08:03:04 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:03:04 --> Controller Class Initialized
DEBUG - 2021-01-11 08:03:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:03:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:03:04 --> Final output sent to browser
DEBUG - 2021-01-11 08:03:04 --> Total execution time: 0.2664
INFO - 2021-01-11 08:03:06 --> Config Class Initialized
INFO - 2021-01-11 08:03:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:03:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:03:06 --> Utf8 Class Initialized
INFO - 2021-01-11 08:03:06 --> URI Class Initialized
INFO - 2021-01-11 08:03:06 --> Router Class Initialized
INFO - 2021-01-11 08:03:06 --> Output Class Initialized
INFO - 2021-01-11 08:03:06 --> Security Class Initialized
DEBUG - 2021-01-11 08:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:03:06 --> Input Class Initialized
INFO - 2021-01-11 08:03:06 --> Language Class Initialized
INFO - 2021-01-11 08:03:06 --> Language Class Initialized
INFO - 2021-01-11 08:03:06 --> Config Class Initialized
INFO - 2021-01-11 08:03:06 --> Loader Class Initialized
INFO - 2021-01-11 08:03:06 --> Helper loaded: url_helper
INFO - 2021-01-11 08:03:06 --> Helper loaded: file_helper
INFO - 2021-01-11 08:03:06 --> Helper loaded: form_helper
INFO - 2021-01-11 08:03:06 --> Helper loaded: my_helper
INFO - 2021-01-11 08:03:06 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:03:06 --> Controller Class Initialized
DEBUG - 2021-01-11 08:03:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:03:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:03:06 --> Final output sent to browser
DEBUG - 2021-01-11 08:03:06 --> Total execution time: 0.2331
INFO - 2021-01-11 08:03:07 --> Config Class Initialized
INFO - 2021-01-11 08:03:07 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:03:08 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:03:08 --> Utf8 Class Initialized
INFO - 2021-01-11 08:03:08 --> URI Class Initialized
INFO - 2021-01-11 08:03:08 --> Router Class Initialized
INFO - 2021-01-11 08:03:08 --> Output Class Initialized
INFO - 2021-01-11 08:03:08 --> Security Class Initialized
DEBUG - 2021-01-11 08:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:03:08 --> Input Class Initialized
INFO - 2021-01-11 08:03:08 --> Language Class Initialized
INFO - 2021-01-11 08:03:08 --> Language Class Initialized
INFO - 2021-01-11 08:03:08 --> Config Class Initialized
INFO - 2021-01-11 08:03:08 --> Loader Class Initialized
INFO - 2021-01-11 08:03:08 --> Helper loaded: url_helper
INFO - 2021-01-11 08:03:08 --> Helper loaded: file_helper
INFO - 2021-01-11 08:03:08 --> Helper loaded: form_helper
INFO - 2021-01-11 08:03:08 --> Helper loaded: my_helper
INFO - 2021-01-11 08:03:08 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:03:08 --> Controller Class Initialized
INFO - 2021-01-11 08:03:08 --> Final output sent to browser
DEBUG - 2021-01-11 08:03:08 --> Total execution time: 0.1815
INFO - 2021-01-11 08:03:16 --> Config Class Initialized
INFO - 2021-01-11 08:03:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:03:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:03:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:03:16 --> URI Class Initialized
INFO - 2021-01-11 08:03:16 --> Router Class Initialized
INFO - 2021-01-11 08:03:16 --> Output Class Initialized
INFO - 2021-01-11 08:03:16 --> Security Class Initialized
DEBUG - 2021-01-11 08:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:03:16 --> Input Class Initialized
INFO - 2021-01-11 08:03:16 --> Language Class Initialized
INFO - 2021-01-11 08:03:16 --> Language Class Initialized
INFO - 2021-01-11 08:03:16 --> Config Class Initialized
INFO - 2021-01-11 08:03:16 --> Loader Class Initialized
INFO - 2021-01-11 08:03:16 --> Helper loaded: url_helper
INFO - 2021-01-11 08:03:16 --> Helper loaded: file_helper
INFO - 2021-01-11 08:03:16 --> Helper loaded: form_helper
INFO - 2021-01-11 08:03:16 --> Helper loaded: my_helper
INFO - 2021-01-11 08:03:16 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:03:16 --> Controller Class Initialized
INFO - 2021-01-11 08:03:16 --> Final output sent to browser
DEBUG - 2021-01-11 08:03:16 --> Total execution time: 0.2918
INFO - 2021-01-11 08:03:20 --> Config Class Initialized
INFO - 2021-01-11 08:03:21 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:03:21 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:03:21 --> Utf8 Class Initialized
INFO - 2021-01-11 08:03:21 --> URI Class Initialized
INFO - 2021-01-11 08:03:21 --> Router Class Initialized
INFO - 2021-01-11 08:03:21 --> Output Class Initialized
INFO - 2021-01-11 08:03:21 --> Security Class Initialized
DEBUG - 2021-01-11 08:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:03:21 --> Input Class Initialized
INFO - 2021-01-11 08:03:21 --> Language Class Initialized
INFO - 2021-01-11 08:03:21 --> Language Class Initialized
INFO - 2021-01-11 08:03:21 --> Config Class Initialized
INFO - 2021-01-11 08:03:21 --> Loader Class Initialized
INFO - 2021-01-11 08:03:21 --> Helper loaded: url_helper
INFO - 2021-01-11 08:03:21 --> Helper loaded: file_helper
INFO - 2021-01-11 08:03:21 --> Helper loaded: form_helper
INFO - 2021-01-11 08:03:21 --> Helper loaded: my_helper
INFO - 2021-01-11 08:03:21 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:03:21 --> Controller Class Initialized
INFO - 2021-01-11 08:03:21 --> Final output sent to browser
DEBUG - 2021-01-11 08:03:21 --> Total execution time: 0.1824
INFO - 2021-01-11 08:03:29 --> Config Class Initialized
INFO - 2021-01-11 08:03:29 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:03:29 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:03:29 --> Utf8 Class Initialized
INFO - 2021-01-11 08:03:29 --> URI Class Initialized
INFO - 2021-01-11 08:03:29 --> Router Class Initialized
INFO - 2021-01-11 08:03:29 --> Output Class Initialized
INFO - 2021-01-11 08:03:29 --> Security Class Initialized
DEBUG - 2021-01-11 08:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:03:29 --> Input Class Initialized
INFO - 2021-01-11 08:03:29 --> Language Class Initialized
INFO - 2021-01-11 08:03:29 --> Language Class Initialized
INFO - 2021-01-11 08:03:29 --> Config Class Initialized
INFO - 2021-01-11 08:03:29 --> Loader Class Initialized
INFO - 2021-01-11 08:03:29 --> Helper loaded: url_helper
INFO - 2021-01-11 08:03:29 --> Helper loaded: file_helper
INFO - 2021-01-11 08:03:29 --> Helper loaded: form_helper
INFO - 2021-01-11 08:03:29 --> Helper loaded: my_helper
INFO - 2021-01-11 08:03:29 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:03:29 --> Controller Class Initialized
INFO - 2021-01-11 08:03:29 --> Final output sent to browser
DEBUG - 2021-01-11 08:03:29 --> Total execution time: 0.2783
INFO - 2021-01-11 08:03:58 --> Config Class Initialized
INFO - 2021-01-11 08:03:58 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:03:58 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:03:59 --> Utf8 Class Initialized
INFO - 2021-01-11 08:03:59 --> URI Class Initialized
INFO - 2021-01-11 08:03:59 --> Router Class Initialized
INFO - 2021-01-11 08:03:59 --> Output Class Initialized
INFO - 2021-01-11 08:03:59 --> Security Class Initialized
DEBUG - 2021-01-11 08:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:03:59 --> Input Class Initialized
INFO - 2021-01-11 08:03:59 --> Language Class Initialized
INFO - 2021-01-11 08:03:59 --> Language Class Initialized
INFO - 2021-01-11 08:03:59 --> Config Class Initialized
INFO - 2021-01-11 08:03:59 --> Loader Class Initialized
INFO - 2021-01-11 08:03:59 --> Helper loaded: url_helper
INFO - 2021-01-11 08:03:59 --> Helper loaded: file_helper
INFO - 2021-01-11 08:03:59 --> Helper loaded: form_helper
INFO - 2021-01-11 08:03:59 --> Helper loaded: my_helper
INFO - 2021-01-11 08:03:59 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:03:59 --> Controller Class Initialized
INFO - 2021-01-11 08:03:59 --> Final output sent to browser
DEBUG - 2021-01-11 08:03:59 --> Total execution time: 0.3048
INFO - 2021-01-11 08:04:02 --> Config Class Initialized
INFO - 2021-01-11 08:04:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:02 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:02 --> URI Class Initialized
INFO - 2021-01-11 08:04:02 --> Router Class Initialized
INFO - 2021-01-11 08:04:02 --> Output Class Initialized
INFO - 2021-01-11 08:04:02 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:02 --> Input Class Initialized
INFO - 2021-01-11 08:04:02 --> Language Class Initialized
INFO - 2021-01-11 08:04:02 --> Language Class Initialized
INFO - 2021-01-11 08:04:02 --> Config Class Initialized
INFO - 2021-01-11 08:04:02 --> Loader Class Initialized
INFO - 2021-01-11 08:04:02 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:02 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:02 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:02 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:02 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:02 --> Controller Class Initialized
DEBUG - 2021-01-11 08:04:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:04:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:04:02 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:02 --> Total execution time: 0.2559
INFO - 2021-01-11 08:04:18 --> Config Class Initialized
INFO - 2021-01-11 08:04:18 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:18 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:18 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:18 --> URI Class Initialized
INFO - 2021-01-11 08:04:18 --> Router Class Initialized
INFO - 2021-01-11 08:04:18 --> Output Class Initialized
INFO - 2021-01-11 08:04:18 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:18 --> Input Class Initialized
INFO - 2021-01-11 08:04:18 --> Language Class Initialized
INFO - 2021-01-11 08:04:18 --> Language Class Initialized
INFO - 2021-01-11 08:04:18 --> Config Class Initialized
INFO - 2021-01-11 08:04:18 --> Loader Class Initialized
INFO - 2021-01-11 08:04:18 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:18 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:18 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:18 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:18 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:18 --> Controller Class Initialized
DEBUG - 2021-01-11 08:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:04:18 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:18 --> Total execution time: 0.2332
INFO - 2021-01-11 08:04:18 --> Config Class Initialized
INFO - 2021-01-11 08:04:18 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:18 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:18 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:18 --> URI Class Initialized
INFO - 2021-01-11 08:04:18 --> Router Class Initialized
INFO - 2021-01-11 08:04:18 --> Output Class Initialized
INFO - 2021-01-11 08:04:18 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:18 --> Input Class Initialized
INFO - 2021-01-11 08:04:18 --> Language Class Initialized
INFO - 2021-01-11 08:04:18 --> Language Class Initialized
INFO - 2021-01-11 08:04:18 --> Config Class Initialized
INFO - 2021-01-11 08:04:18 --> Loader Class Initialized
INFO - 2021-01-11 08:04:18 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:18 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:18 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:18 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:18 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:18 --> Controller Class Initialized
INFO - 2021-01-11 08:04:23 --> Config Class Initialized
INFO - 2021-01-11 08:04:23 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:23 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:23 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:23 --> URI Class Initialized
INFO - 2021-01-11 08:04:23 --> Router Class Initialized
INFO - 2021-01-11 08:04:23 --> Output Class Initialized
INFO - 2021-01-11 08:04:23 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:23 --> Input Class Initialized
INFO - 2021-01-11 08:04:23 --> Language Class Initialized
INFO - 2021-01-11 08:04:23 --> Language Class Initialized
INFO - 2021-01-11 08:04:23 --> Config Class Initialized
INFO - 2021-01-11 08:04:23 --> Loader Class Initialized
INFO - 2021-01-11 08:04:23 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:23 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:23 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:23 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:23 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:23 --> Controller Class Initialized
INFO - 2021-01-11 08:04:23 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:23 --> Total execution time: 0.1909
INFO - 2021-01-11 08:04:30 --> Config Class Initialized
INFO - 2021-01-11 08:04:30 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:30 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:30 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:31 --> URI Class Initialized
INFO - 2021-01-11 08:04:31 --> Router Class Initialized
INFO - 2021-01-11 08:04:31 --> Output Class Initialized
INFO - 2021-01-11 08:04:31 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:31 --> Input Class Initialized
INFO - 2021-01-11 08:04:31 --> Language Class Initialized
INFO - 2021-01-11 08:04:31 --> Language Class Initialized
INFO - 2021-01-11 08:04:31 --> Config Class Initialized
INFO - 2021-01-11 08:04:31 --> Loader Class Initialized
INFO - 2021-01-11 08:04:31 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:31 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:31 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:31 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:31 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:31 --> Controller Class Initialized
INFO - 2021-01-11 08:04:31 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:31 --> Total execution time: 0.2898
INFO - 2021-01-11 08:04:34 --> Config Class Initialized
INFO - 2021-01-11 08:04:34 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:34 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:34 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:34 --> URI Class Initialized
INFO - 2021-01-11 08:04:34 --> Router Class Initialized
INFO - 2021-01-11 08:04:34 --> Output Class Initialized
INFO - 2021-01-11 08:04:34 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:34 --> Input Class Initialized
INFO - 2021-01-11 08:04:34 --> Language Class Initialized
INFO - 2021-01-11 08:04:34 --> Language Class Initialized
INFO - 2021-01-11 08:04:34 --> Config Class Initialized
INFO - 2021-01-11 08:04:34 --> Loader Class Initialized
INFO - 2021-01-11 08:04:34 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:34 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:34 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:34 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:34 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:34 --> Controller Class Initialized
INFO - 2021-01-11 08:04:34 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:34 --> Total execution time: 0.1983
INFO - 2021-01-11 08:04:40 --> Config Class Initialized
INFO - 2021-01-11 08:04:40 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:40 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:40 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:40 --> URI Class Initialized
INFO - 2021-01-11 08:04:40 --> Router Class Initialized
INFO - 2021-01-11 08:04:40 --> Output Class Initialized
INFO - 2021-01-11 08:04:40 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:40 --> Input Class Initialized
INFO - 2021-01-11 08:04:40 --> Language Class Initialized
INFO - 2021-01-11 08:04:40 --> Language Class Initialized
INFO - 2021-01-11 08:04:40 --> Config Class Initialized
INFO - 2021-01-11 08:04:40 --> Loader Class Initialized
INFO - 2021-01-11 08:04:40 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:40 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:40 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:40 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:40 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:40 --> Controller Class Initialized
INFO - 2021-01-11 08:04:41 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:41 --> Total execution time: 0.3186
INFO - 2021-01-11 08:04:44 --> Config Class Initialized
INFO - 2021-01-11 08:04:44 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:44 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:44 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:44 --> URI Class Initialized
INFO - 2021-01-11 08:04:44 --> Router Class Initialized
INFO - 2021-01-11 08:04:44 --> Output Class Initialized
INFO - 2021-01-11 08:04:44 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:44 --> Input Class Initialized
INFO - 2021-01-11 08:04:44 --> Language Class Initialized
INFO - 2021-01-11 08:04:44 --> Language Class Initialized
INFO - 2021-01-11 08:04:44 --> Config Class Initialized
INFO - 2021-01-11 08:04:44 --> Loader Class Initialized
INFO - 2021-01-11 08:04:44 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:44 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:44 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:44 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:44 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:44 --> Controller Class Initialized
INFO - 2021-01-11 08:04:44 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:44 --> Total execution time: 0.1878
INFO - 2021-01-11 08:04:50 --> Config Class Initialized
INFO - 2021-01-11 08:04:50 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:50 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:50 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:50 --> URI Class Initialized
INFO - 2021-01-11 08:04:50 --> Router Class Initialized
INFO - 2021-01-11 08:04:50 --> Output Class Initialized
INFO - 2021-01-11 08:04:50 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:50 --> Input Class Initialized
INFO - 2021-01-11 08:04:50 --> Language Class Initialized
INFO - 2021-01-11 08:04:50 --> Language Class Initialized
INFO - 2021-01-11 08:04:50 --> Config Class Initialized
INFO - 2021-01-11 08:04:50 --> Loader Class Initialized
INFO - 2021-01-11 08:04:50 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:50 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:50 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:50 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:50 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:50 --> Controller Class Initialized
INFO - 2021-01-11 08:04:50 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:50 --> Total execution time: 0.3257
INFO - 2021-01-11 08:04:54 --> Config Class Initialized
INFO - 2021-01-11 08:04:54 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:54 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:54 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:54 --> URI Class Initialized
INFO - 2021-01-11 08:04:54 --> Router Class Initialized
INFO - 2021-01-11 08:04:54 --> Output Class Initialized
INFO - 2021-01-11 08:04:54 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:54 --> Input Class Initialized
INFO - 2021-01-11 08:04:54 --> Language Class Initialized
INFO - 2021-01-11 08:04:54 --> Language Class Initialized
INFO - 2021-01-11 08:04:54 --> Config Class Initialized
INFO - 2021-01-11 08:04:54 --> Loader Class Initialized
INFO - 2021-01-11 08:04:54 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:54 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:54 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:54 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:54 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:54 --> Controller Class Initialized
INFO - 2021-01-11 08:04:54 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:54 --> Total execution time: 0.2032
INFO - 2021-01-11 08:04:59 --> Config Class Initialized
INFO - 2021-01-11 08:04:59 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:04:59 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:04:59 --> Utf8 Class Initialized
INFO - 2021-01-11 08:04:59 --> URI Class Initialized
INFO - 2021-01-11 08:04:59 --> Router Class Initialized
INFO - 2021-01-11 08:04:59 --> Output Class Initialized
INFO - 2021-01-11 08:04:59 --> Security Class Initialized
DEBUG - 2021-01-11 08:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:04:59 --> Input Class Initialized
INFO - 2021-01-11 08:04:59 --> Language Class Initialized
INFO - 2021-01-11 08:04:59 --> Language Class Initialized
INFO - 2021-01-11 08:04:59 --> Config Class Initialized
INFO - 2021-01-11 08:04:59 --> Loader Class Initialized
INFO - 2021-01-11 08:04:59 --> Helper loaded: url_helper
INFO - 2021-01-11 08:04:59 --> Helper loaded: file_helper
INFO - 2021-01-11 08:04:59 --> Helper loaded: form_helper
INFO - 2021-01-11 08:04:59 --> Helper loaded: my_helper
INFO - 2021-01-11 08:04:59 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:04:59 --> Controller Class Initialized
INFO - 2021-01-11 08:04:59 --> Final output sent to browser
DEBUG - 2021-01-11 08:04:59 --> Total execution time: 0.2890
INFO - 2021-01-11 08:05:05 --> Config Class Initialized
INFO - 2021-01-11 08:05:05 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:05:05 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:05:05 --> Utf8 Class Initialized
INFO - 2021-01-11 08:05:05 --> URI Class Initialized
INFO - 2021-01-11 08:05:05 --> Router Class Initialized
INFO - 2021-01-11 08:05:05 --> Output Class Initialized
INFO - 2021-01-11 08:05:05 --> Security Class Initialized
DEBUG - 2021-01-11 08:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:05:05 --> Input Class Initialized
INFO - 2021-01-11 08:05:05 --> Language Class Initialized
INFO - 2021-01-11 08:05:05 --> Language Class Initialized
INFO - 2021-01-11 08:05:05 --> Config Class Initialized
INFO - 2021-01-11 08:05:05 --> Loader Class Initialized
INFO - 2021-01-11 08:05:05 --> Helper loaded: url_helper
INFO - 2021-01-11 08:05:05 --> Helper loaded: file_helper
INFO - 2021-01-11 08:05:05 --> Helper loaded: form_helper
INFO - 2021-01-11 08:05:05 --> Helper loaded: my_helper
INFO - 2021-01-11 08:05:05 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:05:05 --> Controller Class Initialized
DEBUG - 2021-01-11 08:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:05:05 --> Final output sent to browser
DEBUG - 2021-01-11 08:05:05 --> Total execution time: 0.2643
INFO - 2021-01-11 08:05:07 --> Config Class Initialized
INFO - 2021-01-11 08:05:07 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:05:07 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:05:07 --> Utf8 Class Initialized
INFO - 2021-01-11 08:05:07 --> URI Class Initialized
INFO - 2021-01-11 08:05:07 --> Router Class Initialized
INFO - 2021-01-11 08:05:07 --> Output Class Initialized
INFO - 2021-01-11 08:05:07 --> Security Class Initialized
DEBUG - 2021-01-11 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:05:07 --> Input Class Initialized
INFO - 2021-01-11 08:05:07 --> Language Class Initialized
INFO - 2021-01-11 08:05:07 --> Language Class Initialized
INFO - 2021-01-11 08:05:07 --> Config Class Initialized
INFO - 2021-01-11 08:05:07 --> Loader Class Initialized
INFO - 2021-01-11 08:05:07 --> Helper loaded: url_helper
INFO - 2021-01-11 08:05:07 --> Helper loaded: file_helper
INFO - 2021-01-11 08:05:07 --> Helper loaded: form_helper
INFO - 2021-01-11 08:05:07 --> Helper loaded: my_helper
INFO - 2021-01-11 08:05:07 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:05:07 --> Controller Class Initialized
DEBUG - 2021-01-11 08:05:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:05:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:05:07 --> Final output sent to browser
DEBUG - 2021-01-11 08:05:07 --> Total execution time: 0.2413
INFO - 2021-01-11 08:05:09 --> Config Class Initialized
INFO - 2021-01-11 08:05:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:05:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:05:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:05:09 --> URI Class Initialized
INFO - 2021-01-11 08:05:09 --> Router Class Initialized
INFO - 2021-01-11 08:05:10 --> Output Class Initialized
INFO - 2021-01-11 08:05:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:05:10 --> Input Class Initialized
INFO - 2021-01-11 08:05:10 --> Language Class Initialized
INFO - 2021-01-11 08:05:10 --> Language Class Initialized
INFO - 2021-01-11 08:05:10 --> Config Class Initialized
INFO - 2021-01-11 08:05:10 --> Loader Class Initialized
INFO - 2021-01-11 08:05:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:05:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:05:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:05:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:05:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:05:10 --> Controller Class Initialized
INFO - 2021-01-11 08:05:10 --> Final output sent to browser
DEBUG - 2021-01-11 08:05:10 --> Total execution time: 0.1958
INFO - 2021-01-11 08:05:15 --> Config Class Initialized
INFO - 2021-01-11 08:05:15 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:05:15 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:05:15 --> Utf8 Class Initialized
INFO - 2021-01-11 08:05:15 --> URI Class Initialized
INFO - 2021-01-11 08:05:15 --> Router Class Initialized
INFO - 2021-01-11 08:05:15 --> Output Class Initialized
INFO - 2021-01-11 08:05:15 --> Security Class Initialized
DEBUG - 2021-01-11 08:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:05:15 --> Input Class Initialized
INFO - 2021-01-11 08:05:15 --> Language Class Initialized
INFO - 2021-01-11 08:05:15 --> Language Class Initialized
INFO - 2021-01-11 08:05:15 --> Config Class Initialized
INFO - 2021-01-11 08:05:15 --> Loader Class Initialized
INFO - 2021-01-11 08:05:15 --> Helper loaded: url_helper
INFO - 2021-01-11 08:05:15 --> Helper loaded: file_helper
INFO - 2021-01-11 08:05:15 --> Helper loaded: form_helper
INFO - 2021-01-11 08:05:15 --> Helper loaded: my_helper
INFO - 2021-01-11 08:05:15 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:05:15 --> Controller Class Initialized
INFO - 2021-01-11 08:05:15 --> Final output sent to browser
DEBUG - 2021-01-11 08:05:15 --> Total execution time: 0.2756
INFO - 2021-01-11 08:05:18 --> Config Class Initialized
INFO - 2021-01-11 08:05:18 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:05:18 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:05:18 --> Utf8 Class Initialized
INFO - 2021-01-11 08:05:18 --> URI Class Initialized
INFO - 2021-01-11 08:05:18 --> Router Class Initialized
INFO - 2021-01-11 08:05:18 --> Output Class Initialized
INFO - 2021-01-11 08:05:18 --> Security Class Initialized
DEBUG - 2021-01-11 08:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:05:18 --> Input Class Initialized
INFO - 2021-01-11 08:05:18 --> Language Class Initialized
INFO - 2021-01-11 08:05:18 --> Language Class Initialized
INFO - 2021-01-11 08:05:18 --> Config Class Initialized
INFO - 2021-01-11 08:05:18 --> Loader Class Initialized
INFO - 2021-01-11 08:05:18 --> Helper loaded: url_helper
INFO - 2021-01-11 08:05:18 --> Helper loaded: file_helper
INFO - 2021-01-11 08:05:18 --> Helper loaded: form_helper
INFO - 2021-01-11 08:05:18 --> Helper loaded: my_helper
INFO - 2021-01-11 08:05:18 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:05:18 --> Controller Class Initialized
INFO - 2021-01-11 08:05:18 --> Final output sent to browser
DEBUG - 2021-01-11 08:05:18 --> Total execution time: 0.1897
INFO - 2021-01-11 08:05:26 --> Config Class Initialized
INFO - 2021-01-11 08:05:26 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:05:26 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:05:26 --> Utf8 Class Initialized
INFO - 2021-01-11 08:05:26 --> URI Class Initialized
INFO - 2021-01-11 08:05:26 --> Router Class Initialized
INFO - 2021-01-11 08:05:26 --> Output Class Initialized
INFO - 2021-01-11 08:05:26 --> Security Class Initialized
DEBUG - 2021-01-11 08:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:05:26 --> Input Class Initialized
INFO - 2021-01-11 08:05:26 --> Language Class Initialized
INFO - 2021-01-11 08:05:26 --> Language Class Initialized
INFO - 2021-01-11 08:05:26 --> Config Class Initialized
INFO - 2021-01-11 08:05:26 --> Loader Class Initialized
INFO - 2021-01-11 08:05:26 --> Helper loaded: url_helper
INFO - 2021-01-11 08:05:26 --> Helper loaded: file_helper
INFO - 2021-01-11 08:05:26 --> Helper loaded: form_helper
INFO - 2021-01-11 08:05:26 --> Helper loaded: my_helper
INFO - 2021-01-11 08:05:26 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:05:26 --> Controller Class Initialized
INFO - 2021-01-11 08:05:27 --> Final output sent to browser
DEBUG - 2021-01-11 08:05:27 --> Total execution time: 0.2909
INFO - 2021-01-11 08:06:05 --> Config Class Initialized
INFO - 2021-01-11 08:06:05 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:06:05 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:06:05 --> Utf8 Class Initialized
INFO - 2021-01-11 08:06:05 --> URI Class Initialized
INFO - 2021-01-11 08:06:05 --> Router Class Initialized
INFO - 2021-01-11 08:06:05 --> Output Class Initialized
INFO - 2021-01-11 08:06:05 --> Security Class Initialized
DEBUG - 2021-01-11 08:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:06:05 --> Input Class Initialized
INFO - 2021-01-11 08:06:05 --> Language Class Initialized
INFO - 2021-01-11 08:06:05 --> Language Class Initialized
INFO - 2021-01-11 08:06:05 --> Config Class Initialized
INFO - 2021-01-11 08:06:05 --> Loader Class Initialized
INFO - 2021-01-11 08:06:05 --> Helper loaded: url_helper
INFO - 2021-01-11 08:06:05 --> Helper loaded: file_helper
INFO - 2021-01-11 08:06:05 --> Helper loaded: form_helper
INFO - 2021-01-11 08:06:05 --> Helper loaded: my_helper
INFO - 2021-01-11 08:06:05 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:06:05 --> Controller Class Initialized
INFO - 2021-01-11 08:06:05 --> Final output sent to browser
DEBUG - 2021-01-11 08:06:05 --> Total execution time: 0.1918
INFO - 2021-01-11 08:06:07 --> Config Class Initialized
INFO - 2021-01-11 08:06:07 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:06:07 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:06:07 --> Utf8 Class Initialized
INFO - 2021-01-11 08:06:07 --> URI Class Initialized
INFO - 2021-01-11 08:06:07 --> Router Class Initialized
INFO - 2021-01-11 08:06:07 --> Output Class Initialized
INFO - 2021-01-11 08:06:07 --> Security Class Initialized
DEBUG - 2021-01-11 08:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:06:07 --> Input Class Initialized
INFO - 2021-01-11 08:06:07 --> Language Class Initialized
INFO - 2021-01-11 08:06:07 --> Language Class Initialized
INFO - 2021-01-11 08:06:07 --> Config Class Initialized
INFO - 2021-01-11 08:06:07 --> Loader Class Initialized
INFO - 2021-01-11 08:06:07 --> Helper loaded: url_helper
INFO - 2021-01-11 08:06:07 --> Helper loaded: file_helper
INFO - 2021-01-11 08:06:07 --> Helper loaded: form_helper
INFO - 2021-01-11 08:06:07 --> Helper loaded: my_helper
INFO - 2021-01-11 08:06:07 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:06:07 --> Controller Class Initialized
INFO - 2021-01-11 08:06:07 --> Final output sent to browser
DEBUG - 2021-01-11 08:06:07 --> Total execution time: 0.1961
INFO - 2021-01-11 08:06:10 --> Config Class Initialized
INFO - 2021-01-11 08:06:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:06:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:06:10 --> Utf8 Class Initialized
INFO - 2021-01-11 08:06:10 --> URI Class Initialized
INFO - 2021-01-11 08:06:10 --> Router Class Initialized
INFO - 2021-01-11 08:06:10 --> Output Class Initialized
INFO - 2021-01-11 08:06:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:06:10 --> Input Class Initialized
INFO - 2021-01-11 08:06:10 --> Language Class Initialized
INFO - 2021-01-11 08:06:10 --> Language Class Initialized
INFO - 2021-01-11 08:06:10 --> Config Class Initialized
INFO - 2021-01-11 08:06:10 --> Loader Class Initialized
INFO - 2021-01-11 08:06:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:06:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:06:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:06:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:06:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:06:10 --> Controller Class Initialized
DEBUG - 2021-01-11 08:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:06:10 --> Final output sent to browser
DEBUG - 2021-01-11 08:06:10 --> Total execution time: 0.3001
INFO - 2021-01-11 08:06:55 --> Config Class Initialized
INFO - 2021-01-11 08:06:55 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:06:55 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:06:55 --> Utf8 Class Initialized
INFO - 2021-01-11 08:06:55 --> URI Class Initialized
INFO - 2021-01-11 08:06:55 --> Router Class Initialized
INFO - 2021-01-11 08:06:55 --> Output Class Initialized
INFO - 2021-01-11 08:06:55 --> Security Class Initialized
DEBUG - 2021-01-11 08:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:06:55 --> Input Class Initialized
INFO - 2021-01-11 08:06:55 --> Language Class Initialized
INFO - 2021-01-11 08:06:55 --> Language Class Initialized
INFO - 2021-01-11 08:06:55 --> Config Class Initialized
INFO - 2021-01-11 08:06:55 --> Loader Class Initialized
INFO - 2021-01-11 08:06:55 --> Helper loaded: url_helper
INFO - 2021-01-11 08:06:55 --> Helper loaded: file_helper
INFO - 2021-01-11 08:06:55 --> Helper loaded: form_helper
INFO - 2021-01-11 08:06:55 --> Helper loaded: my_helper
INFO - 2021-01-11 08:06:55 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:06:55 --> Controller Class Initialized
DEBUG - 2021-01-11 08:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:06:55 --> Final output sent to browser
DEBUG - 2021-01-11 08:06:55 --> Total execution time: 0.2370
INFO - 2021-01-11 08:06:55 --> Config Class Initialized
INFO - 2021-01-11 08:06:55 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:06:55 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:06:55 --> Utf8 Class Initialized
INFO - 2021-01-11 08:06:55 --> URI Class Initialized
INFO - 2021-01-11 08:06:55 --> Router Class Initialized
INFO - 2021-01-11 08:06:55 --> Output Class Initialized
INFO - 2021-01-11 08:06:55 --> Security Class Initialized
DEBUG - 2021-01-11 08:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:06:55 --> Input Class Initialized
INFO - 2021-01-11 08:06:55 --> Language Class Initialized
INFO - 2021-01-11 08:06:55 --> Language Class Initialized
INFO - 2021-01-11 08:06:55 --> Config Class Initialized
INFO - 2021-01-11 08:06:55 --> Loader Class Initialized
INFO - 2021-01-11 08:06:55 --> Helper loaded: url_helper
INFO - 2021-01-11 08:06:55 --> Helper loaded: file_helper
INFO - 2021-01-11 08:06:55 --> Helper loaded: form_helper
INFO - 2021-01-11 08:06:56 --> Helper loaded: my_helper
INFO - 2021-01-11 08:06:56 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:06:56 --> Controller Class Initialized
INFO - 2021-01-11 08:07:00 --> Config Class Initialized
INFO - 2021-01-11 08:07:00 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:00 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:00 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:00 --> URI Class Initialized
INFO - 2021-01-11 08:07:00 --> Router Class Initialized
INFO - 2021-01-11 08:07:00 --> Output Class Initialized
INFO - 2021-01-11 08:07:00 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:00 --> Input Class Initialized
INFO - 2021-01-11 08:07:00 --> Language Class Initialized
INFO - 2021-01-11 08:07:00 --> Language Class Initialized
INFO - 2021-01-11 08:07:00 --> Config Class Initialized
INFO - 2021-01-11 08:07:00 --> Loader Class Initialized
INFO - 2021-01-11 08:07:00 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:00 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:00 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:00 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:00 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:00 --> Controller Class Initialized
INFO - 2021-01-11 08:07:00 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:00 --> Total execution time: 0.1977
INFO - 2021-01-11 08:07:10 --> Config Class Initialized
INFO - 2021-01-11 08:07:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:10 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:10 --> URI Class Initialized
INFO - 2021-01-11 08:07:10 --> Router Class Initialized
INFO - 2021-01-11 08:07:10 --> Output Class Initialized
INFO - 2021-01-11 08:07:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:10 --> Input Class Initialized
INFO - 2021-01-11 08:07:10 --> Language Class Initialized
INFO - 2021-01-11 08:07:10 --> Language Class Initialized
INFO - 2021-01-11 08:07:10 --> Config Class Initialized
INFO - 2021-01-11 08:07:10 --> Loader Class Initialized
INFO - 2021-01-11 08:07:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:10 --> Controller Class Initialized
INFO - 2021-01-11 08:07:10 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:10 --> Total execution time: 0.3138
INFO - 2021-01-11 08:07:13 --> Config Class Initialized
INFO - 2021-01-11 08:07:13 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:13 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:13 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:13 --> URI Class Initialized
INFO - 2021-01-11 08:07:13 --> Router Class Initialized
INFO - 2021-01-11 08:07:13 --> Output Class Initialized
INFO - 2021-01-11 08:07:13 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:13 --> Input Class Initialized
INFO - 2021-01-11 08:07:13 --> Language Class Initialized
INFO - 2021-01-11 08:07:14 --> Language Class Initialized
INFO - 2021-01-11 08:07:14 --> Config Class Initialized
INFO - 2021-01-11 08:07:14 --> Loader Class Initialized
INFO - 2021-01-11 08:07:14 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:14 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:14 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:14 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:14 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:14 --> Controller Class Initialized
INFO - 2021-01-11 08:07:14 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:14 --> Total execution time: 0.2073
INFO - 2021-01-11 08:07:21 --> Config Class Initialized
INFO - 2021-01-11 08:07:21 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:21 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:21 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:21 --> URI Class Initialized
INFO - 2021-01-11 08:07:21 --> Router Class Initialized
INFO - 2021-01-11 08:07:21 --> Output Class Initialized
INFO - 2021-01-11 08:07:21 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:21 --> Input Class Initialized
INFO - 2021-01-11 08:07:21 --> Language Class Initialized
INFO - 2021-01-11 08:07:21 --> Language Class Initialized
INFO - 2021-01-11 08:07:21 --> Config Class Initialized
INFO - 2021-01-11 08:07:21 --> Loader Class Initialized
INFO - 2021-01-11 08:07:21 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:21 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:21 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:21 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:21 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:21 --> Controller Class Initialized
INFO - 2021-01-11 08:07:22 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:22 --> Total execution time: 0.3262
INFO - 2021-01-11 08:07:24 --> Config Class Initialized
INFO - 2021-01-11 08:07:24 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:24 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:24 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:24 --> URI Class Initialized
INFO - 2021-01-11 08:07:24 --> Router Class Initialized
INFO - 2021-01-11 08:07:24 --> Output Class Initialized
INFO - 2021-01-11 08:07:24 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:24 --> Input Class Initialized
INFO - 2021-01-11 08:07:24 --> Language Class Initialized
INFO - 2021-01-11 08:07:24 --> Language Class Initialized
INFO - 2021-01-11 08:07:24 --> Config Class Initialized
INFO - 2021-01-11 08:07:24 --> Loader Class Initialized
INFO - 2021-01-11 08:07:24 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:24 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:24 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:24 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:24 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:24 --> Controller Class Initialized
INFO - 2021-01-11 08:07:24 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:24 --> Total execution time: 0.1928
INFO - 2021-01-11 08:07:31 --> Config Class Initialized
INFO - 2021-01-11 08:07:31 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:31 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:31 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:31 --> URI Class Initialized
INFO - 2021-01-11 08:07:31 --> Router Class Initialized
INFO - 2021-01-11 08:07:31 --> Output Class Initialized
INFO - 2021-01-11 08:07:31 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:31 --> Input Class Initialized
INFO - 2021-01-11 08:07:31 --> Language Class Initialized
INFO - 2021-01-11 08:07:31 --> Language Class Initialized
INFO - 2021-01-11 08:07:31 --> Config Class Initialized
INFO - 2021-01-11 08:07:31 --> Loader Class Initialized
INFO - 2021-01-11 08:07:31 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:31 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:31 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:31 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:31 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:31 --> Controller Class Initialized
INFO - 2021-01-11 08:07:31 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:31 --> Total execution time: 0.3121
INFO - 2021-01-11 08:07:34 --> Config Class Initialized
INFO - 2021-01-11 08:07:34 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:34 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:34 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:34 --> URI Class Initialized
INFO - 2021-01-11 08:07:34 --> Router Class Initialized
INFO - 2021-01-11 08:07:34 --> Output Class Initialized
INFO - 2021-01-11 08:07:34 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:34 --> Input Class Initialized
INFO - 2021-01-11 08:07:34 --> Language Class Initialized
INFO - 2021-01-11 08:07:34 --> Language Class Initialized
INFO - 2021-01-11 08:07:35 --> Config Class Initialized
INFO - 2021-01-11 08:07:35 --> Loader Class Initialized
INFO - 2021-01-11 08:07:35 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:35 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:35 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:35 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:35 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:35 --> Controller Class Initialized
INFO - 2021-01-11 08:07:35 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:35 --> Total execution time: 0.1944
INFO - 2021-01-11 08:07:43 --> Config Class Initialized
INFO - 2021-01-11 08:07:43 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:43 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:43 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:43 --> URI Class Initialized
INFO - 2021-01-11 08:07:43 --> Router Class Initialized
INFO - 2021-01-11 08:07:43 --> Output Class Initialized
INFO - 2021-01-11 08:07:43 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:43 --> Input Class Initialized
INFO - 2021-01-11 08:07:43 --> Language Class Initialized
INFO - 2021-01-11 08:07:43 --> Language Class Initialized
INFO - 2021-01-11 08:07:43 --> Config Class Initialized
INFO - 2021-01-11 08:07:44 --> Loader Class Initialized
INFO - 2021-01-11 08:07:44 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:44 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:44 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:44 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:44 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:44 --> Controller Class Initialized
INFO - 2021-01-11 08:07:44 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:44 --> Total execution time: 0.3378
INFO - 2021-01-11 08:07:49 --> Config Class Initialized
INFO - 2021-01-11 08:07:49 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:49 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:49 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:49 --> URI Class Initialized
INFO - 2021-01-11 08:07:49 --> Router Class Initialized
INFO - 2021-01-11 08:07:49 --> Output Class Initialized
INFO - 2021-01-11 08:07:49 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:49 --> Input Class Initialized
INFO - 2021-01-11 08:07:49 --> Language Class Initialized
INFO - 2021-01-11 08:07:49 --> Language Class Initialized
INFO - 2021-01-11 08:07:49 --> Config Class Initialized
INFO - 2021-01-11 08:07:49 --> Loader Class Initialized
INFO - 2021-01-11 08:07:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:49 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:49 --> Controller Class Initialized
DEBUG - 2021-01-11 08:07:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:07:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:07:49 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:49 --> Total execution time: 0.2760
INFO - 2021-01-11 08:07:52 --> Config Class Initialized
INFO - 2021-01-11 08:07:52 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:52 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:52 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:52 --> URI Class Initialized
INFO - 2021-01-11 08:07:52 --> Router Class Initialized
INFO - 2021-01-11 08:07:52 --> Output Class Initialized
INFO - 2021-01-11 08:07:52 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:52 --> Input Class Initialized
INFO - 2021-01-11 08:07:52 --> Language Class Initialized
INFO - 2021-01-11 08:07:52 --> Language Class Initialized
INFO - 2021-01-11 08:07:52 --> Config Class Initialized
INFO - 2021-01-11 08:07:52 --> Loader Class Initialized
INFO - 2021-01-11 08:07:52 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:52 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:52 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:52 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:52 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:52 --> Controller Class Initialized
DEBUG - 2021-01-11 08:07:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:07:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:07:52 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:52 --> Total execution time: 0.2511
INFO - 2021-01-11 08:07:54 --> Config Class Initialized
INFO - 2021-01-11 08:07:54 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:07:54 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:07:54 --> Utf8 Class Initialized
INFO - 2021-01-11 08:07:54 --> URI Class Initialized
INFO - 2021-01-11 08:07:54 --> Router Class Initialized
INFO - 2021-01-11 08:07:54 --> Output Class Initialized
INFO - 2021-01-11 08:07:54 --> Security Class Initialized
DEBUG - 2021-01-11 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:07:54 --> Input Class Initialized
INFO - 2021-01-11 08:07:54 --> Language Class Initialized
INFO - 2021-01-11 08:07:54 --> Language Class Initialized
INFO - 2021-01-11 08:07:54 --> Config Class Initialized
INFO - 2021-01-11 08:07:54 --> Loader Class Initialized
INFO - 2021-01-11 08:07:54 --> Helper loaded: url_helper
INFO - 2021-01-11 08:07:54 --> Helper loaded: file_helper
INFO - 2021-01-11 08:07:54 --> Helper loaded: form_helper
INFO - 2021-01-11 08:07:54 --> Helper loaded: my_helper
INFO - 2021-01-11 08:07:54 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:07:54 --> Controller Class Initialized
INFO - 2021-01-11 08:07:54 --> Final output sent to browser
DEBUG - 2021-01-11 08:07:54 --> Total execution time: 0.2164
INFO - 2021-01-11 08:08:11 --> Config Class Initialized
INFO - 2021-01-11 08:08:11 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:08:11 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:08:11 --> Utf8 Class Initialized
INFO - 2021-01-11 08:08:12 --> URI Class Initialized
INFO - 2021-01-11 08:08:12 --> Router Class Initialized
INFO - 2021-01-11 08:08:12 --> Output Class Initialized
INFO - 2021-01-11 08:08:12 --> Security Class Initialized
DEBUG - 2021-01-11 08:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:08:12 --> Input Class Initialized
INFO - 2021-01-11 08:08:12 --> Language Class Initialized
INFO - 2021-01-11 08:08:12 --> Language Class Initialized
INFO - 2021-01-11 08:08:12 --> Config Class Initialized
INFO - 2021-01-11 08:08:12 --> Loader Class Initialized
INFO - 2021-01-11 08:08:12 --> Helper loaded: url_helper
INFO - 2021-01-11 08:08:12 --> Helper loaded: file_helper
INFO - 2021-01-11 08:08:12 --> Helper loaded: form_helper
INFO - 2021-01-11 08:08:12 --> Helper loaded: my_helper
INFO - 2021-01-11 08:08:12 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:08:12 --> Controller Class Initialized
INFO - 2021-01-11 08:08:12 --> Final output sent to browser
DEBUG - 2021-01-11 08:08:12 --> Total execution time: 0.3423
INFO - 2021-01-11 08:08:16 --> Config Class Initialized
INFO - 2021-01-11 08:08:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:08:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:08:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:08:16 --> URI Class Initialized
INFO - 2021-01-11 08:08:16 --> Router Class Initialized
INFO - 2021-01-11 08:08:16 --> Output Class Initialized
INFO - 2021-01-11 08:08:16 --> Security Class Initialized
DEBUG - 2021-01-11 08:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:08:16 --> Input Class Initialized
INFO - 2021-01-11 08:08:16 --> Language Class Initialized
INFO - 2021-01-11 08:08:16 --> Language Class Initialized
INFO - 2021-01-11 08:08:16 --> Config Class Initialized
INFO - 2021-01-11 08:08:17 --> Loader Class Initialized
INFO - 2021-01-11 08:08:17 --> Helper loaded: url_helper
INFO - 2021-01-11 08:08:17 --> Helper loaded: file_helper
INFO - 2021-01-11 08:08:17 --> Helper loaded: form_helper
INFO - 2021-01-11 08:08:17 --> Helper loaded: my_helper
INFO - 2021-01-11 08:08:17 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:08:17 --> Controller Class Initialized
INFO - 2021-01-11 08:08:17 --> Final output sent to browser
DEBUG - 2021-01-11 08:08:17 --> Total execution time: 0.2104
INFO - 2021-01-11 08:08:23 --> Config Class Initialized
INFO - 2021-01-11 08:08:23 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:08:23 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:08:24 --> Utf8 Class Initialized
INFO - 2021-01-11 08:08:24 --> URI Class Initialized
INFO - 2021-01-11 08:08:24 --> Router Class Initialized
INFO - 2021-01-11 08:08:24 --> Output Class Initialized
INFO - 2021-01-11 08:08:24 --> Security Class Initialized
DEBUG - 2021-01-11 08:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:08:24 --> Input Class Initialized
INFO - 2021-01-11 08:08:24 --> Language Class Initialized
INFO - 2021-01-11 08:08:24 --> Language Class Initialized
INFO - 2021-01-11 08:08:24 --> Config Class Initialized
INFO - 2021-01-11 08:08:24 --> Loader Class Initialized
INFO - 2021-01-11 08:08:24 --> Helper loaded: url_helper
INFO - 2021-01-11 08:08:24 --> Helper loaded: file_helper
INFO - 2021-01-11 08:08:24 --> Helper loaded: form_helper
INFO - 2021-01-11 08:08:24 --> Helper loaded: my_helper
INFO - 2021-01-11 08:08:24 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:08:24 --> Controller Class Initialized
INFO - 2021-01-11 08:08:24 --> Final output sent to browser
DEBUG - 2021-01-11 08:08:24 --> Total execution time: 0.3202
INFO - 2021-01-11 08:08:33 --> Config Class Initialized
INFO - 2021-01-11 08:08:33 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:08:33 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:08:33 --> Utf8 Class Initialized
INFO - 2021-01-11 08:08:33 --> URI Class Initialized
INFO - 2021-01-11 08:08:33 --> Router Class Initialized
INFO - 2021-01-11 08:08:33 --> Output Class Initialized
INFO - 2021-01-11 08:08:33 --> Security Class Initialized
DEBUG - 2021-01-11 08:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:08:33 --> Input Class Initialized
INFO - 2021-01-11 08:08:33 --> Language Class Initialized
INFO - 2021-01-11 08:08:33 --> Language Class Initialized
INFO - 2021-01-11 08:08:33 --> Config Class Initialized
INFO - 2021-01-11 08:08:33 --> Loader Class Initialized
INFO - 2021-01-11 08:08:33 --> Helper loaded: url_helper
INFO - 2021-01-11 08:08:33 --> Helper loaded: file_helper
INFO - 2021-01-11 08:08:33 --> Helper loaded: form_helper
INFO - 2021-01-11 08:08:33 --> Helper loaded: my_helper
INFO - 2021-01-11 08:08:33 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:08:33 --> Controller Class Initialized
DEBUG - 2021-01-11 08:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:08:33 --> Final output sent to browser
DEBUG - 2021-01-11 08:08:33 --> Total execution time: 0.2722
INFO - 2021-01-11 08:08:37 --> Config Class Initialized
INFO - 2021-01-11 08:08:37 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:08:37 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:08:37 --> Utf8 Class Initialized
INFO - 2021-01-11 08:08:37 --> URI Class Initialized
INFO - 2021-01-11 08:08:37 --> Router Class Initialized
INFO - 2021-01-11 08:08:37 --> Output Class Initialized
INFO - 2021-01-11 08:08:37 --> Security Class Initialized
DEBUG - 2021-01-11 08:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:08:37 --> Input Class Initialized
INFO - 2021-01-11 08:08:37 --> Language Class Initialized
INFO - 2021-01-11 08:08:37 --> Language Class Initialized
INFO - 2021-01-11 08:08:37 --> Config Class Initialized
INFO - 2021-01-11 08:08:37 --> Loader Class Initialized
INFO - 2021-01-11 08:08:37 --> Helper loaded: url_helper
INFO - 2021-01-11 08:08:37 --> Helper loaded: file_helper
INFO - 2021-01-11 08:08:37 --> Helper loaded: form_helper
INFO - 2021-01-11 08:08:37 --> Helper loaded: my_helper
INFO - 2021-01-11 08:08:37 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:08:37 --> Controller Class Initialized
DEBUG - 2021-01-11 08:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:08:37 --> Final output sent to browser
DEBUG - 2021-01-11 08:08:37 --> Total execution time: 0.2371
INFO - 2021-01-11 08:08:37 --> Config Class Initialized
INFO - 2021-01-11 08:08:37 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:08:37 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:08:37 --> Utf8 Class Initialized
INFO - 2021-01-11 08:08:37 --> URI Class Initialized
INFO - 2021-01-11 08:08:37 --> Router Class Initialized
INFO - 2021-01-11 08:08:37 --> Output Class Initialized
INFO - 2021-01-11 08:08:37 --> Security Class Initialized
DEBUG - 2021-01-11 08:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:08:37 --> Input Class Initialized
INFO - 2021-01-11 08:08:37 --> Language Class Initialized
INFO - 2021-01-11 08:08:37 --> Language Class Initialized
INFO - 2021-01-11 08:08:37 --> Config Class Initialized
INFO - 2021-01-11 08:08:37 --> Loader Class Initialized
INFO - 2021-01-11 08:08:37 --> Helper loaded: url_helper
INFO - 2021-01-11 08:08:37 --> Helper loaded: file_helper
INFO - 2021-01-11 08:08:37 --> Helper loaded: form_helper
INFO - 2021-01-11 08:08:37 --> Helper loaded: my_helper
INFO - 2021-01-11 08:08:37 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:08:37 --> Controller Class Initialized
INFO - 2021-01-11 08:08:39 --> Config Class Initialized
INFO - 2021-01-11 08:08:39 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:08:39 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:08:39 --> Utf8 Class Initialized
INFO - 2021-01-11 08:08:39 --> URI Class Initialized
INFO - 2021-01-11 08:08:39 --> Router Class Initialized
INFO - 2021-01-11 08:08:39 --> Output Class Initialized
INFO - 2021-01-11 08:08:39 --> Security Class Initialized
DEBUG - 2021-01-11 08:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:08:39 --> Input Class Initialized
INFO - 2021-01-11 08:08:39 --> Language Class Initialized
INFO - 2021-01-11 08:08:39 --> Language Class Initialized
INFO - 2021-01-11 08:08:39 --> Config Class Initialized
INFO - 2021-01-11 08:08:39 --> Loader Class Initialized
INFO - 2021-01-11 08:08:39 --> Helper loaded: url_helper
INFO - 2021-01-11 08:08:39 --> Helper loaded: file_helper
INFO - 2021-01-11 08:08:39 --> Helper loaded: form_helper
INFO - 2021-01-11 08:08:39 --> Helper loaded: my_helper
INFO - 2021-01-11 08:08:39 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:08:39 --> Controller Class Initialized
INFO - 2021-01-11 08:08:40 --> Final output sent to browser
DEBUG - 2021-01-11 08:08:40 --> Total execution time: 0.1963
INFO - 2021-01-11 08:08:55 --> Config Class Initialized
INFO - 2021-01-11 08:08:55 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:08:55 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:08:55 --> Utf8 Class Initialized
INFO - 2021-01-11 08:08:55 --> URI Class Initialized
INFO - 2021-01-11 08:08:55 --> Router Class Initialized
INFO - 2021-01-11 08:08:55 --> Output Class Initialized
INFO - 2021-01-11 08:08:55 --> Security Class Initialized
DEBUG - 2021-01-11 08:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:08:55 --> Input Class Initialized
INFO - 2021-01-11 08:08:55 --> Language Class Initialized
INFO - 2021-01-11 08:08:55 --> Language Class Initialized
INFO - 2021-01-11 08:08:55 --> Config Class Initialized
INFO - 2021-01-11 08:08:55 --> Loader Class Initialized
INFO - 2021-01-11 08:08:55 --> Helper loaded: url_helper
INFO - 2021-01-11 08:08:55 --> Helper loaded: file_helper
INFO - 2021-01-11 08:08:55 --> Helper loaded: form_helper
INFO - 2021-01-11 08:08:55 --> Helper loaded: my_helper
INFO - 2021-01-11 08:08:56 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:08:56 --> Controller Class Initialized
INFO - 2021-01-11 08:08:56 --> Final output sent to browser
DEBUG - 2021-01-11 08:08:56 --> Total execution time: 0.2848
INFO - 2021-01-11 08:08:59 --> Config Class Initialized
INFO - 2021-01-11 08:08:59 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:08:59 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:08:59 --> Utf8 Class Initialized
INFO - 2021-01-11 08:08:59 --> URI Class Initialized
INFO - 2021-01-11 08:08:59 --> Router Class Initialized
INFO - 2021-01-11 08:08:59 --> Output Class Initialized
INFO - 2021-01-11 08:08:59 --> Security Class Initialized
DEBUG - 2021-01-11 08:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:08:59 --> Input Class Initialized
INFO - 2021-01-11 08:08:59 --> Language Class Initialized
INFO - 2021-01-11 08:08:59 --> Language Class Initialized
INFO - 2021-01-11 08:08:59 --> Config Class Initialized
INFO - 2021-01-11 08:08:59 --> Loader Class Initialized
INFO - 2021-01-11 08:08:59 --> Helper loaded: url_helper
INFO - 2021-01-11 08:08:59 --> Helper loaded: file_helper
INFO - 2021-01-11 08:08:59 --> Helper loaded: form_helper
INFO - 2021-01-11 08:08:59 --> Helper loaded: my_helper
INFO - 2021-01-11 08:08:59 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:08:59 --> Controller Class Initialized
INFO - 2021-01-11 08:08:59 --> Final output sent to browser
DEBUG - 2021-01-11 08:08:59 --> Total execution time: 0.2143
INFO - 2021-01-11 08:09:06 --> Config Class Initialized
INFO - 2021-01-11 08:09:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:06 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:06 --> URI Class Initialized
INFO - 2021-01-11 08:09:06 --> Router Class Initialized
INFO - 2021-01-11 08:09:06 --> Output Class Initialized
INFO - 2021-01-11 08:09:06 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:06 --> Input Class Initialized
INFO - 2021-01-11 08:09:06 --> Language Class Initialized
INFO - 2021-01-11 08:09:06 --> Language Class Initialized
INFO - 2021-01-11 08:09:06 --> Config Class Initialized
INFO - 2021-01-11 08:09:06 --> Loader Class Initialized
INFO - 2021-01-11 08:09:06 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:06 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:06 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:06 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:06 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:06 --> Controller Class Initialized
INFO - 2021-01-11 08:09:06 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:06 --> Total execution time: 0.3057
INFO - 2021-01-11 08:09:09 --> Config Class Initialized
INFO - 2021-01-11 08:09:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:09 --> URI Class Initialized
INFO - 2021-01-11 08:09:09 --> Router Class Initialized
INFO - 2021-01-11 08:09:09 --> Output Class Initialized
INFO - 2021-01-11 08:09:09 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:09 --> Input Class Initialized
INFO - 2021-01-11 08:09:09 --> Language Class Initialized
INFO - 2021-01-11 08:09:09 --> Language Class Initialized
INFO - 2021-01-11 08:09:09 --> Config Class Initialized
INFO - 2021-01-11 08:09:09 --> Loader Class Initialized
INFO - 2021-01-11 08:09:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:09 --> Controller Class Initialized
INFO - 2021-01-11 08:09:09 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:09 --> Total execution time: 0.1999
INFO - 2021-01-11 08:09:16 --> Config Class Initialized
INFO - 2021-01-11 08:09:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:16 --> URI Class Initialized
INFO - 2021-01-11 08:09:16 --> Router Class Initialized
INFO - 2021-01-11 08:09:16 --> Output Class Initialized
INFO - 2021-01-11 08:09:16 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:17 --> Input Class Initialized
INFO - 2021-01-11 08:09:17 --> Language Class Initialized
INFO - 2021-01-11 08:09:17 --> Language Class Initialized
INFO - 2021-01-11 08:09:17 --> Config Class Initialized
INFO - 2021-01-11 08:09:17 --> Loader Class Initialized
INFO - 2021-01-11 08:09:17 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:17 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:17 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:17 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:17 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:17 --> Controller Class Initialized
INFO - 2021-01-11 08:09:17 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:17 --> Total execution time: 0.2881
INFO - 2021-01-11 08:09:20 --> Config Class Initialized
INFO - 2021-01-11 08:09:20 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:20 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:20 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:20 --> URI Class Initialized
INFO - 2021-01-11 08:09:20 --> Router Class Initialized
INFO - 2021-01-11 08:09:20 --> Output Class Initialized
INFO - 2021-01-11 08:09:20 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:20 --> Input Class Initialized
INFO - 2021-01-11 08:09:20 --> Language Class Initialized
INFO - 2021-01-11 08:09:20 --> Language Class Initialized
INFO - 2021-01-11 08:09:20 --> Config Class Initialized
INFO - 2021-01-11 08:09:20 --> Loader Class Initialized
INFO - 2021-01-11 08:09:20 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:20 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:20 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:20 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:20 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:20 --> Controller Class Initialized
INFO - 2021-01-11 08:09:20 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:20 --> Total execution time: 0.2116
INFO - 2021-01-11 08:09:25 --> Config Class Initialized
INFO - 2021-01-11 08:09:25 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:25 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:25 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:25 --> URI Class Initialized
INFO - 2021-01-11 08:09:25 --> Router Class Initialized
INFO - 2021-01-11 08:09:25 --> Output Class Initialized
INFO - 2021-01-11 08:09:25 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:25 --> Input Class Initialized
INFO - 2021-01-11 08:09:25 --> Language Class Initialized
INFO - 2021-01-11 08:09:25 --> Language Class Initialized
INFO - 2021-01-11 08:09:25 --> Config Class Initialized
INFO - 2021-01-11 08:09:25 --> Loader Class Initialized
INFO - 2021-01-11 08:09:26 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:26 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:26 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:26 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:26 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:26 --> Controller Class Initialized
INFO - 2021-01-11 08:09:26 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:26 --> Total execution time: 0.2871
INFO - 2021-01-11 08:09:30 --> Config Class Initialized
INFO - 2021-01-11 08:09:30 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:30 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:30 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:30 --> URI Class Initialized
INFO - 2021-01-11 08:09:30 --> Router Class Initialized
INFO - 2021-01-11 08:09:30 --> Output Class Initialized
INFO - 2021-01-11 08:09:30 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:30 --> Input Class Initialized
INFO - 2021-01-11 08:09:30 --> Language Class Initialized
INFO - 2021-01-11 08:09:30 --> Language Class Initialized
INFO - 2021-01-11 08:09:30 --> Config Class Initialized
INFO - 2021-01-11 08:09:30 --> Loader Class Initialized
INFO - 2021-01-11 08:09:30 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:30 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:30 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:30 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:30 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:30 --> Controller Class Initialized
DEBUG - 2021-01-11 08:09:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:09:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:09:30 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:30 --> Total execution time: 0.2881
INFO - 2021-01-11 08:09:33 --> Config Class Initialized
INFO - 2021-01-11 08:09:33 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:33 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:33 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:33 --> URI Class Initialized
INFO - 2021-01-11 08:09:33 --> Router Class Initialized
INFO - 2021-01-11 08:09:33 --> Output Class Initialized
INFO - 2021-01-11 08:09:33 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:33 --> Input Class Initialized
INFO - 2021-01-11 08:09:33 --> Language Class Initialized
INFO - 2021-01-11 08:09:33 --> Language Class Initialized
INFO - 2021-01-11 08:09:33 --> Config Class Initialized
INFO - 2021-01-11 08:09:33 --> Loader Class Initialized
INFO - 2021-01-11 08:09:33 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:33 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:33 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:33 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:33 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:33 --> Controller Class Initialized
DEBUG - 2021-01-11 08:09:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:09:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:09:33 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:33 --> Total execution time: 0.2519
INFO - 2021-01-11 08:09:33 --> Config Class Initialized
INFO - 2021-01-11 08:09:33 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:33 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:33 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:33 --> URI Class Initialized
INFO - 2021-01-11 08:09:33 --> Router Class Initialized
INFO - 2021-01-11 08:09:33 --> Output Class Initialized
INFO - 2021-01-11 08:09:33 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:33 --> Input Class Initialized
INFO - 2021-01-11 08:09:33 --> Language Class Initialized
INFO - 2021-01-11 08:09:33 --> Language Class Initialized
INFO - 2021-01-11 08:09:33 --> Config Class Initialized
INFO - 2021-01-11 08:09:33 --> Loader Class Initialized
INFO - 2021-01-11 08:09:33 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:33 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:33 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:33 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:33 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:33 --> Controller Class Initialized
INFO - 2021-01-11 08:09:35 --> Config Class Initialized
INFO - 2021-01-11 08:09:35 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:35 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:35 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:35 --> URI Class Initialized
INFO - 2021-01-11 08:09:35 --> Router Class Initialized
INFO - 2021-01-11 08:09:35 --> Output Class Initialized
INFO - 2021-01-11 08:09:35 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:35 --> Input Class Initialized
INFO - 2021-01-11 08:09:35 --> Language Class Initialized
INFO - 2021-01-11 08:09:35 --> Language Class Initialized
INFO - 2021-01-11 08:09:35 --> Config Class Initialized
INFO - 2021-01-11 08:09:35 --> Loader Class Initialized
INFO - 2021-01-11 08:09:35 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:35 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:35 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:35 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:35 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:35 --> Controller Class Initialized
INFO - 2021-01-11 08:09:35 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:35 --> Total execution time: 0.2005
INFO - 2021-01-11 08:09:36 --> Config Class Initialized
INFO - 2021-01-11 08:09:36 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:36 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:36 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:36 --> URI Class Initialized
INFO - 2021-01-11 08:09:36 --> Router Class Initialized
INFO - 2021-01-11 08:09:36 --> Output Class Initialized
INFO - 2021-01-11 08:09:36 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:36 --> Input Class Initialized
INFO - 2021-01-11 08:09:36 --> Language Class Initialized
INFO - 2021-01-11 08:09:36 --> Language Class Initialized
INFO - 2021-01-11 08:09:36 --> Config Class Initialized
INFO - 2021-01-11 08:09:36 --> Loader Class Initialized
INFO - 2021-01-11 08:09:36 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:36 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:36 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:36 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:36 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:36 --> Controller Class Initialized
DEBUG - 2021-01-11 08:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:09:36 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:36 --> Total execution time: 0.2982
INFO - 2021-01-11 08:09:38 --> Config Class Initialized
INFO - 2021-01-11 08:09:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:38 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:38 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:38 --> URI Class Initialized
INFO - 2021-01-11 08:09:38 --> Router Class Initialized
INFO - 2021-01-11 08:09:38 --> Output Class Initialized
INFO - 2021-01-11 08:09:38 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:38 --> Input Class Initialized
INFO - 2021-01-11 08:09:38 --> Language Class Initialized
INFO - 2021-01-11 08:09:38 --> Language Class Initialized
INFO - 2021-01-11 08:09:38 --> Config Class Initialized
INFO - 2021-01-11 08:09:38 --> Loader Class Initialized
INFO - 2021-01-11 08:09:38 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:38 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:38 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:38 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:38 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:38 --> Controller Class Initialized
DEBUG - 2021-01-11 08:09:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:09:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:09:38 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:38 --> Total execution time: 0.2488
INFO - 2021-01-11 08:09:41 --> Config Class Initialized
INFO - 2021-01-11 08:09:41 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:41 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:41 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:41 --> URI Class Initialized
INFO - 2021-01-11 08:09:41 --> Router Class Initialized
INFO - 2021-01-11 08:09:41 --> Output Class Initialized
INFO - 2021-01-11 08:09:41 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:41 --> Input Class Initialized
INFO - 2021-01-11 08:09:41 --> Language Class Initialized
INFO - 2021-01-11 08:09:41 --> Language Class Initialized
INFO - 2021-01-11 08:09:41 --> Config Class Initialized
INFO - 2021-01-11 08:09:41 --> Loader Class Initialized
INFO - 2021-01-11 08:09:41 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:41 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:41 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:41 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:41 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:41 --> Controller Class Initialized
INFO - 2021-01-11 08:09:41 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:41 --> Total execution time: 0.2027
INFO - 2021-01-11 08:09:48 --> Config Class Initialized
INFO - 2021-01-11 08:09:48 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:48 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:48 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:48 --> URI Class Initialized
INFO - 2021-01-11 08:09:48 --> Router Class Initialized
INFO - 2021-01-11 08:09:48 --> Output Class Initialized
INFO - 2021-01-11 08:09:48 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:48 --> Input Class Initialized
INFO - 2021-01-11 08:09:48 --> Language Class Initialized
INFO - 2021-01-11 08:09:48 --> Language Class Initialized
INFO - 2021-01-11 08:09:49 --> Config Class Initialized
INFO - 2021-01-11 08:09:49 --> Loader Class Initialized
INFO - 2021-01-11 08:09:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:49 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:49 --> Controller Class Initialized
INFO - 2021-01-11 08:09:49 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:49 --> Total execution time: 0.3089
INFO - 2021-01-11 08:09:51 --> Config Class Initialized
INFO - 2021-01-11 08:09:51 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:51 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:51 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:51 --> URI Class Initialized
INFO - 2021-01-11 08:09:51 --> Router Class Initialized
INFO - 2021-01-11 08:09:51 --> Output Class Initialized
INFO - 2021-01-11 08:09:51 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:51 --> Input Class Initialized
INFO - 2021-01-11 08:09:51 --> Language Class Initialized
INFO - 2021-01-11 08:09:52 --> Language Class Initialized
INFO - 2021-01-11 08:09:52 --> Config Class Initialized
INFO - 2021-01-11 08:09:52 --> Loader Class Initialized
INFO - 2021-01-11 08:09:52 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:52 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:52 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:52 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:52 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:52 --> Controller Class Initialized
INFO - 2021-01-11 08:09:52 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:52 --> Total execution time: 0.2606
INFO - 2021-01-11 08:09:57 --> Config Class Initialized
INFO - 2021-01-11 08:09:57 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:09:57 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:09:57 --> Utf8 Class Initialized
INFO - 2021-01-11 08:09:57 --> URI Class Initialized
INFO - 2021-01-11 08:09:57 --> Router Class Initialized
INFO - 2021-01-11 08:09:57 --> Output Class Initialized
INFO - 2021-01-11 08:09:57 --> Security Class Initialized
DEBUG - 2021-01-11 08:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:09:57 --> Input Class Initialized
INFO - 2021-01-11 08:09:57 --> Language Class Initialized
INFO - 2021-01-11 08:09:57 --> Language Class Initialized
INFO - 2021-01-11 08:09:57 --> Config Class Initialized
INFO - 2021-01-11 08:09:57 --> Loader Class Initialized
INFO - 2021-01-11 08:09:57 --> Helper loaded: url_helper
INFO - 2021-01-11 08:09:57 --> Helper loaded: file_helper
INFO - 2021-01-11 08:09:57 --> Helper loaded: form_helper
INFO - 2021-01-11 08:09:57 --> Helper loaded: my_helper
INFO - 2021-01-11 08:09:57 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:09:57 --> Controller Class Initialized
INFO - 2021-01-11 08:09:58 --> Final output sent to browser
DEBUG - 2021-01-11 08:09:58 --> Total execution time: 0.3028
INFO - 2021-01-11 08:10:06 --> Config Class Initialized
INFO - 2021-01-11 08:10:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:07 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:07 --> URI Class Initialized
INFO - 2021-01-11 08:10:07 --> Router Class Initialized
INFO - 2021-01-11 08:10:07 --> Output Class Initialized
INFO - 2021-01-11 08:10:07 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:07 --> Input Class Initialized
INFO - 2021-01-11 08:10:07 --> Language Class Initialized
INFO - 2021-01-11 08:10:07 --> Language Class Initialized
INFO - 2021-01-11 08:10:07 --> Config Class Initialized
INFO - 2021-01-11 08:10:07 --> Loader Class Initialized
INFO - 2021-01-11 08:10:07 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:07 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:07 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:07 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:07 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:07 --> Controller Class Initialized
DEBUG - 2021-01-11 08:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:10:07 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:07 --> Total execution time: 0.2851
INFO - 2021-01-11 08:10:14 --> Config Class Initialized
INFO - 2021-01-11 08:10:14 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:14 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:14 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:14 --> URI Class Initialized
INFO - 2021-01-11 08:10:14 --> Router Class Initialized
INFO - 2021-01-11 08:10:14 --> Output Class Initialized
INFO - 2021-01-11 08:10:14 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:14 --> Input Class Initialized
INFO - 2021-01-11 08:10:14 --> Language Class Initialized
INFO - 2021-01-11 08:10:14 --> Language Class Initialized
INFO - 2021-01-11 08:10:14 --> Config Class Initialized
INFO - 2021-01-11 08:10:14 --> Loader Class Initialized
INFO - 2021-01-11 08:10:14 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:14 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:14 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:14 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:14 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:14 --> Controller Class Initialized
DEBUG - 2021-01-11 08:10:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:10:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:10:14 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:14 --> Total execution time: 0.2616
INFO - 2021-01-11 08:10:14 --> Config Class Initialized
INFO - 2021-01-11 08:10:14 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:14 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:14 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:14 --> URI Class Initialized
INFO - 2021-01-11 08:10:14 --> Router Class Initialized
INFO - 2021-01-11 08:10:14 --> Output Class Initialized
INFO - 2021-01-11 08:10:14 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:14 --> Input Class Initialized
INFO - 2021-01-11 08:10:14 --> Language Class Initialized
INFO - 2021-01-11 08:10:14 --> Language Class Initialized
INFO - 2021-01-11 08:10:14 --> Config Class Initialized
INFO - 2021-01-11 08:10:14 --> Loader Class Initialized
INFO - 2021-01-11 08:10:14 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:14 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:14 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:14 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:14 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:14 --> Controller Class Initialized
INFO - 2021-01-11 08:10:16 --> Config Class Initialized
INFO - 2021-01-11 08:10:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:16 --> URI Class Initialized
INFO - 2021-01-11 08:10:16 --> Router Class Initialized
INFO - 2021-01-11 08:10:16 --> Output Class Initialized
INFO - 2021-01-11 08:10:16 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:16 --> Input Class Initialized
INFO - 2021-01-11 08:10:16 --> Language Class Initialized
INFO - 2021-01-11 08:10:16 --> Language Class Initialized
INFO - 2021-01-11 08:10:16 --> Config Class Initialized
INFO - 2021-01-11 08:10:16 --> Loader Class Initialized
INFO - 2021-01-11 08:10:16 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:16 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:16 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:16 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:16 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:16 --> Controller Class Initialized
INFO - 2021-01-11 08:10:16 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:16 --> Total execution time: 0.2159
INFO - 2021-01-11 08:10:22 --> Config Class Initialized
INFO - 2021-01-11 08:10:22 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:22 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:22 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:22 --> URI Class Initialized
INFO - 2021-01-11 08:10:22 --> Router Class Initialized
INFO - 2021-01-11 08:10:22 --> Output Class Initialized
INFO - 2021-01-11 08:10:22 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:22 --> Input Class Initialized
INFO - 2021-01-11 08:10:22 --> Language Class Initialized
INFO - 2021-01-11 08:10:22 --> Language Class Initialized
INFO - 2021-01-11 08:10:22 --> Config Class Initialized
INFO - 2021-01-11 08:10:22 --> Loader Class Initialized
INFO - 2021-01-11 08:10:22 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:22 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:22 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:22 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:22 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:22 --> Controller Class Initialized
INFO - 2021-01-11 08:10:23 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:23 --> Total execution time: 0.2912
INFO - 2021-01-11 08:10:27 --> Config Class Initialized
INFO - 2021-01-11 08:10:27 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:27 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:27 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:27 --> URI Class Initialized
INFO - 2021-01-11 08:10:27 --> Router Class Initialized
INFO - 2021-01-11 08:10:27 --> Output Class Initialized
INFO - 2021-01-11 08:10:27 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:27 --> Input Class Initialized
INFO - 2021-01-11 08:10:27 --> Language Class Initialized
INFO - 2021-01-11 08:10:27 --> Language Class Initialized
INFO - 2021-01-11 08:10:27 --> Config Class Initialized
INFO - 2021-01-11 08:10:27 --> Loader Class Initialized
INFO - 2021-01-11 08:10:27 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:27 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:27 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:27 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:27 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:27 --> Controller Class Initialized
INFO - 2021-01-11 08:10:27 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:27 --> Total execution time: 0.2282
INFO - 2021-01-11 08:10:32 --> Config Class Initialized
INFO - 2021-01-11 08:10:32 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:32 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:32 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:32 --> URI Class Initialized
INFO - 2021-01-11 08:10:32 --> Router Class Initialized
INFO - 2021-01-11 08:10:32 --> Output Class Initialized
INFO - 2021-01-11 08:10:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:32 --> Input Class Initialized
INFO - 2021-01-11 08:10:32 --> Language Class Initialized
INFO - 2021-01-11 08:10:32 --> Language Class Initialized
INFO - 2021-01-11 08:10:32 --> Config Class Initialized
INFO - 2021-01-11 08:10:32 --> Loader Class Initialized
INFO - 2021-01-11 08:10:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:32 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:32 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:32 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:32 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:32 --> Controller Class Initialized
INFO - 2021-01-11 08:10:32 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:32 --> Total execution time: 0.2757
INFO - 2021-01-11 08:10:36 --> Config Class Initialized
INFO - 2021-01-11 08:10:36 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:36 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:36 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:36 --> URI Class Initialized
INFO - 2021-01-11 08:10:36 --> Router Class Initialized
INFO - 2021-01-11 08:10:36 --> Output Class Initialized
INFO - 2021-01-11 08:10:36 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:36 --> Input Class Initialized
INFO - 2021-01-11 08:10:36 --> Language Class Initialized
INFO - 2021-01-11 08:10:36 --> Language Class Initialized
INFO - 2021-01-11 08:10:36 --> Config Class Initialized
INFO - 2021-01-11 08:10:36 --> Loader Class Initialized
INFO - 2021-01-11 08:10:36 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:36 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:36 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:36 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:36 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:36 --> Controller Class Initialized
INFO - 2021-01-11 08:10:36 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:36 --> Total execution time: 0.2462
INFO - 2021-01-11 08:10:37 --> Config Class Initialized
INFO - 2021-01-11 08:10:37 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:37 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:37 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:37 --> URI Class Initialized
INFO - 2021-01-11 08:10:37 --> Router Class Initialized
INFO - 2021-01-11 08:10:37 --> Output Class Initialized
INFO - 2021-01-11 08:10:37 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:37 --> Input Class Initialized
INFO - 2021-01-11 08:10:37 --> Language Class Initialized
INFO - 2021-01-11 08:10:37 --> Language Class Initialized
INFO - 2021-01-11 08:10:37 --> Config Class Initialized
INFO - 2021-01-11 08:10:37 --> Loader Class Initialized
INFO - 2021-01-11 08:10:37 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:37 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:37 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:37 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:37 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:37 --> Controller Class Initialized
DEBUG - 2021-01-11 08:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:10:37 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:37 --> Total execution time: 0.3442
INFO - 2021-01-11 08:10:44 --> Config Class Initialized
INFO - 2021-01-11 08:10:44 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:44 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:44 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:44 --> URI Class Initialized
INFO - 2021-01-11 08:10:44 --> Router Class Initialized
INFO - 2021-01-11 08:10:44 --> Output Class Initialized
INFO - 2021-01-11 08:10:44 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:44 --> Input Class Initialized
INFO - 2021-01-11 08:10:44 --> Language Class Initialized
INFO - 2021-01-11 08:10:44 --> Language Class Initialized
INFO - 2021-01-11 08:10:44 --> Config Class Initialized
INFO - 2021-01-11 08:10:44 --> Loader Class Initialized
INFO - 2021-01-11 08:10:44 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:44 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:44 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:44 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:44 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:44 --> Controller Class Initialized
DEBUG - 2021-01-11 08:10:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:10:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:10:44 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:44 --> Total execution time: 0.2582
INFO - 2021-01-11 08:10:44 --> Config Class Initialized
INFO - 2021-01-11 08:10:44 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:44 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:44 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:44 --> URI Class Initialized
INFO - 2021-01-11 08:10:44 --> Router Class Initialized
INFO - 2021-01-11 08:10:44 --> Output Class Initialized
INFO - 2021-01-11 08:10:45 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:45 --> Input Class Initialized
INFO - 2021-01-11 08:10:45 --> Language Class Initialized
INFO - 2021-01-11 08:10:45 --> Language Class Initialized
INFO - 2021-01-11 08:10:45 --> Config Class Initialized
INFO - 2021-01-11 08:10:45 --> Loader Class Initialized
INFO - 2021-01-11 08:10:45 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:45 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:45 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:45 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:45 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:45 --> Controller Class Initialized
INFO - 2021-01-11 08:10:47 --> Config Class Initialized
INFO - 2021-01-11 08:10:47 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:47 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:47 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:47 --> URI Class Initialized
INFO - 2021-01-11 08:10:47 --> Router Class Initialized
INFO - 2021-01-11 08:10:47 --> Output Class Initialized
INFO - 2021-01-11 08:10:47 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:47 --> Input Class Initialized
INFO - 2021-01-11 08:10:47 --> Language Class Initialized
INFO - 2021-01-11 08:10:47 --> Language Class Initialized
INFO - 2021-01-11 08:10:47 --> Config Class Initialized
INFO - 2021-01-11 08:10:47 --> Loader Class Initialized
INFO - 2021-01-11 08:10:47 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:47 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:47 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:47 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:47 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:47 --> Controller Class Initialized
INFO - 2021-01-11 08:10:47 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:47 --> Total execution time: 0.2098
INFO - 2021-01-11 08:10:49 --> Config Class Initialized
INFO - 2021-01-11 08:10:49 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:49 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:49 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:49 --> URI Class Initialized
INFO - 2021-01-11 08:10:49 --> Router Class Initialized
INFO - 2021-01-11 08:10:49 --> Output Class Initialized
INFO - 2021-01-11 08:10:49 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:49 --> Input Class Initialized
INFO - 2021-01-11 08:10:49 --> Language Class Initialized
INFO - 2021-01-11 08:10:49 --> Language Class Initialized
INFO - 2021-01-11 08:10:49 --> Config Class Initialized
INFO - 2021-01-11 08:10:49 --> Loader Class Initialized
INFO - 2021-01-11 08:10:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:49 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:49 --> Controller Class Initialized
INFO - 2021-01-11 08:10:49 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:49 --> Total execution time: 0.2094
INFO - 2021-01-11 08:10:56 --> Config Class Initialized
INFO - 2021-01-11 08:10:56 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:10:56 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:10:56 --> Utf8 Class Initialized
INFO - 2021-01-11 08:10:56 --> URI Class Initialized
INFO - 2021-01-11 08:10:56 --> Router Class Initialized
INFO - 2021-01-11 08:10:56 --> Output Class Initialized
INFO - 2021-01-11 08:10:56 --> Security Class Initialized
DEBUG - 2021-01-11 08:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:10:56 --> Input Class Initialized
INFO - 2021-01-11 08:10:56 --> Language Class Initialized
INFO - 2021-01-11 08:10:56 --> Language Class Initialized
INFO - 2021-01-11 08:10:56 --> Config Class Initialized
INFO - 2021-01-11 08:10:56 --> Loader Class Initialized
INFO - 2021-01-11 08:10:56 --> Helper loaded: url_helper
INFO - 2021-01-11 08:10:56 --> Helper loaded: file_helper
INFO - 2021-01-11 08:10:56 --> Helper loaded: form_helper
INFO - 2021-01-11 08:10:56 --> Helper loaded: my_helper
INFO - 2021-01-11 08:10:56 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:10:56 --> Controller Class Initialized
INFO - 2021-01-11 08:10:56 --> Final output sent to browser
DEBUG - 2021-01-11 08:10:56 --> Total execution time: 0.2956
INFO - 2021-01-11 08:11:01 --> Config Class Initialized
INFO - 2021-01-11 08:11:01 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:11:01 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:11:01 --> Utf8 Class Initialized
INFO - 2021-01-11 08:11:01 --> URI Class Initialized
INFO - 2021-01-11 08:11:01 --> Router Class Initialized
INFO - 2021-01-11 08:11:01 --> Output Class Initialized
INFO - 2021-01-11 08:11:01 --> Security Class Initialized
DEBUG - 2021-01-11 08:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:11:01 --> Input Class Initialized
INFO - 2021-01-11 08:11:01 --> Language Class Initialized
INFO - 2021-01-11 08:11:01 --> Language Class Initialized
INFO - 2021-01-11 08:11:01 --> Config Class Initialized
INFO - 2021-01-11 08:11:01 --> Loader Class Initialized
INFO - 2021-01-11 08:11:01 --> Helper loaded: url_helper
INFO - 2021-01-11 08:11:01 --> Helper loaded: file_helper
INFO - 2021-01-11 08:11:01 --> Helper loaded: form_helper
INFO - 2021-01-11 08:11:01 --> Helper loaded: my_helper
INFO - 2021-01-11 08:11:01 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:11:01 --> Controller Class Initialized
INFO - 2021-01-11 08:11:01 --> Final output sent to browser
DEBUG - 2021-01-11 08:11:01 --> Total execution time: 0.2106
INFO - 2021-01-11 08:11:07 --> Config Class Initialized
INFO - 2021-01-11 08:11:07 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:11:07 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:11:07 --> Utf8 Class Initialized
INFO - 2021-01-11 08:11:07 --> URI Class Initialized
INFO - 2021-01-11 08:11:07 --> Router Class Initialized
INFO - 2021-01-11 08:11:08 --> Output Class Initialized
INFO - 2021-01-11 08:11:08 --> Security Class Initialized
DEBUG - 2021-01-11 08:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:11:08 --> Input Class Initialized
INFO - 2021-01-11 08:11:08 --> Language Class Initialized
INFO - 2021-01-11 08:11:08 --> Language Class Initialized
INFO - 2021-01-11 08:11:08 --> Config Class Initialized
INFO - 2021-01-11 08:11:08 --> Loader Class Initialized
INFO - 2021-01-11 08:11:08 --> Helper loaded: url_helper
INFO - 2021-01-11 08:11:08 --> Helper loaded: file_helper
INFO - 2021-01-11 08:11:08 --> Helper loaded: form_helper
INFO - 2021-01-11 08:11:08 --> Helper loaded: my_helper
INFO - 2021-01-11 08:11:08 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:11:08 --> Controller Class Initialized
INFO - 2021-01-11 08:11:08 --> Final output sent to browser
DEBUG - 2021-01-11 08:11:08 --> Total execution time: 0.3007
INFO - 2021-01-11 08:11:21 --> Config Class Initialized
INFO - 2021-01-11 08:11:21 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:11:21 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:11:21 --> Utf8 Class Initialized
INFO - 2021-01-11 08:11:21 --> URI Class Initialized
INFO - 2021-01-11 08:11:22 --> Router Class Initialized
INFO - 2021-01-11 08:11:22 --> Output Class Initialized
INFO - 2021-01-11 08:11:22 --> Security Class Initialized
DEBUG - 2021-01-11 08:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:11:22 --> Input Class Initialized
INFO - 2021-01-11 08:11:22 --> Language Class Initialized
INFO - 2021-01-11 08:11:22 --> Language Class Initialized
INFO - 2021-01-11 08:11:22 --> Config Class Initialized
INFO - 2021-01-11 08:11:22 --> Loader Class Initialized
INFO - 2021-01-11 08:11:22 --> Helper loaded: url_helper
INFO - 2021-01-11 08:11:22 --> Helper loaded: file_helper
INFO - 2021-01-11 08:11:22 --> Helper loaded: form_helper
INFO - 2021-01-11 08:11:22 --> Helper loaded: my_helper
INFO - 2021-01-11 08:11:22 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:11:22 --> Controller Class Initialized
DEBUG - 2021-01-11 08:11:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:11:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:11:22 --> Final output sent to browser
DEBUG - 2021-01-11 08:11:22 --> Total execution time: 0.2893
INFO - 2021-01-11 08:11:26 --> Config Class Initialized
INFO - 2021-01-11 08:11:26 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:11:26 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:11:26 --> Utf8 Class Initialized
INFO - 2021-01-11 08:11:26 --> URI Class Initialized
INFO - 2021-01-11 08:11:26 --> Router Class Initialized
INFO - 2021-01-11 08:11:26 --> Output Class Initialized
INFO - 2021-01-11 08:11:26 --> Security Class Initialized
DEBUG - 2021-01-11 08:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:11:26 --> Input Class Initialized
INFO - 2021-01-11 08:11:26 --> Language Class Initialized
INFO - 2021-01-11 08:11:26 --> Language Class Initialized
INFO - 2021-01-11 08:11:26 --> Config Class Initialized
INFO - 2021-01-11 08:11:26 --> Loader Class Initialized
INFO - 2021-01-11 08:11:26 --> Helper loaded: url_helper
INFO - 2021-01-11 08:11:26 --> Helper loaded: file_helper
INFO - 2021-01-11 08:11:26 --> Helper loaded: form_helper
INFO - 2021-01-11 08:11:26 --> Helper loaded: my_helper
INFO - 2021-01-11 08:11:26 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:11:26 --> Controller Class Initialized
DEBUG - 2021-01-11 08:11:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:11:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:11:26 --> Final output sent to browser
DEBUG - 2021-01-11 08:11:26 --> Total execution time: 0.2745
INFO - 2021-01-11 08:11:28 --> Config Class Initialized
INFO - 2021-01-11 08:11:28 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:11:28 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:11:28 --> Utf8 Class Initialized
INFO - 2021-01-11 08:11:28 --> URI Class Initialized
INFO - 2021-01-11 08:11:28 --> Router Class Initialized
INFO - 2021-01-11 08:11:28 --> Output Class Initialized
INFO - 2021-01-11 08:11:28 --> Security Class Initialized
DEBUG - 2021-01-11 08:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:11:28 --> Input Class Initialized
INFO - 2021-01-11 08:11:28 --> Language Class Initialized
INFO - 2021-01-11 08:11:28 --> Language Class Initialized
INFO - 2021-01-11 08:11:28 --> Config Class Initialized
INFO - 2021-01-11 08:11:28 --> Loader Class Initialized
INFO - 2021-01-11 08:11:28 --> Helper loaded: url_helper
INFO - 2021-01-11 08:11:28 --> Helper loaded: file_helper
INFO - 2021-01-11 08:11:28 --> Helper loaded: form_helper
INFO - 2021-01-11 08:11:28 --> Helper loaded: my_helper
INFO - 2021-01-11 08:11:28 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:11:28 --> Controller Class Initialized
INFO - 2021-01-11 08:11:28 --> Final output sent to browser
DEBUG - 2021-01-11 08:11:28 --> Total execution time: 0.2147
INFO - 2021-01-11 08:11:42 --> Config Class Initialized
INFO - 2021-01-11 08:11:42 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:11:42 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:11:42 --> Utf8 Class Initialized
INFO - 2021-01-11 08:11:42 --> URI Class Initialized
INFO - 2021-01-11 08:11:42 --> Router Class Initialized
INFO - 2021-01-11 08:11:42 --> Output Class Initialized
INFO - 2021-01-11 08:11:42 --> Security Class Initialized
DEBUG - 2021-01-11 08:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:11:42 --> Input Class Initialized
INFO - 2021-01-11 08:11:42 --> Language Class Initialized
INFO - 2021-01-11 08:11:42 --> Language Class Initialized
INFO - 2021-01-11 08:11:42 --> Config Class Initialized
INFO - 2021-01-11 08:11:42 --> Loader Class Initialized
INFO - 2021-01-11 08:11:42 --> Helper loaded: url_helper
INFO - 2021-01-11 08:11:42 --> Helper loaded: file_helper
INFO - 2021-01-11 08:11:42 --> Helper loaded: form_helper
INFO - 2021-01-11 08:11:42 --> Helper loaded: my_helper
INFO - 2021-01-11 08:11:42 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:11:42 --> Controller Class Initialized
INFO - 2021-01-11 08:11:42 --> Final output sent to browser
DEBUG - 2021-01-11 08:11:42 --> Total execution time: 0.2936
INFO - 2021-01-11 08:11:45 --> Config Class Initialized
INFO - 2021-01-11 08:11:45 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:11:45 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:11:45 --> Utf8 Class Initialized
INFO - 2021-01-11 08:11:45 --> URI Class Initialized
INFO - 2021-01-11 08:11:45 --> Router Class Initialized
INFO - 2021-01-11 08:11:45 --> Output Class Initialized
INFO - 2021-01-11 08:11:45 --> Security Class Initialized
DEBUG - 2021-01-11 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:11:45 --> Input Class Initialized
INFO - 2021-01-11 08:11:45 --> Language Class Initialized
INFO - 2021-01-11 08:11:45 --> Language Class Initialized
INFO - 2021-01-11 08:11:45 --> Config Class Initialized
INFO - 2021-01-11 08:11:45 --> Loader Class Initialized
INFO - 2021-01-11 08:11:45 --> Helper loaded: url_helper
INFO - 2021-01-11 08:11:45 --> Helper loaded: file_helper
INFO - 2021-01-11 08:11:45 --> Helper loaded: form_helper
INFO - 2021-01-11 08:11:45 --> Helper loaded: my_helper
INFO - 2021-01-11 08:11:46 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:11:46 --> Controller Class Initialized
INFO - 2021-01-11 08:11:46 --> Final output sent to browser
DEBUG - 2021-01-11 08:11:46 --> Total execution time: 0.2152
INFO - 2021-01-11 08:11:52 --> Config Class Initialized
INFO - 2021-01-11 08:11:52 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:11:52 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:11:52 --> Utf8 Class Initialized
INFO - 2021-01-11 08:11:52 --> URI Class Initialized
INFO - 2021-01-11 08:11:52 --> Router Class Initialized
INFO - 2021-01-11 08:11:52 --> Output Class Initialized
INFO - 2021-01-11 08:11:52 --> Security Class Initialized
DEBUG - 2021-01-11 08:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:11:52 --> Input Class Initialized
INFO - 2021-01-11 08:11:52 --> Language Class Initialized
INFO - 2021-01-11 08:11:52 --> Language Class Initialized
INFO - 2021-01-11 08:11:52 --> Config Class Initialized
INFO - 2021-01-11 08:11:52 --> Loader Class Initialized
INFO - 2021-01-11 08:11:52 --> Helper loaded: url_helper
INFO - 2021-01-11 08:11:52 --> Helper loaded: file_helper
INFO - 2021-01-11 08:11:52 --> Helper loaded: form_helper
INFO - 2021-01-11 08:11:52 --> Helper loaded: my_helper
INFO - 2021-01-11 08:11:52 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:11:52 --> Controller Class Initialized
INFO - 2021-01-11 08:11:53 --> Final output sent to browser
DEBUG - 2021-01-11 08:11:53 --> Total execution time: 0.2795
INFO - 2021-01-11 08:12:25 --> Config Class Initialized
INFO - 2021-01-11 08:12:26 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:12:26 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:12:26 --> Utf8 Class Initialized
INFO - 2021-01-11 08:12:26 --> URI Class Initialized
INFO - 2021-01-11 08:12:26 --> Router Class Initialized
INFO - 2021-01-11 08:12:26 --> Output Class Initialized
INFO - 2021-01-11 08:12:26 --> Security Class Initialized
DEBUG - 2021-01-11 08:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:12:26 --> Input Class Initialized
INFO - 2021-01-11 08:12:26 --> Language Class Initialized
INFO - 2021-01-11 08:12:26 --> Language Class Initialized
INFO - 2021-01-11 08:12:26 --> Config Class Initialized
INFO - 2021-01-11 08:12:26 --> Loader Class Initialized
INFO - 2021-01-11 08:12:26 --> Helper loaded: url_helper
INFO - 2021-01-11 08:12:26 --> Helper loaded: file_helper
INFO - 2021-01-11 08:12:26 --> Helper loaded: form_helper
INFO - 2021-01-11 08:12:26 --> Helper loaded: my_helper
INFO - 2021-01-11 08:12:26 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:12:26 --> Controller Class Initialized
DEBUG - 2021-01-11 08:12:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:12:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:12:26 --> Final output sent to browser
DEBUG - 2021-01-11 08:12:26 --> Total execution time: 0.3065
INFO - 2021-01-11 08:12:30 --> Config Class Initialized
INFO - 2021-01-11 08:12:30 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:12:30 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:12:30 --> Utf8 Class Initialized
INFO - 2021-01-11 08:12:30 --> URI Class Initialized
INFO - 2021-01-11 08:12:30 --> Router Class Initialized
INFO - 2021-01-11 08:12:30 --> Output Class Initialized
INFO - 2021-01-11 08:12:30 --> Security Class Initialized
DEBUG - 2021-01-11 08:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:12:30 --> Input Class Initialized
INFO - 2021-01-11 08:12:30 --> Language Class Initialized
INFO - 2021-01-11 08:12:30 --> Language Class Initialized
INFO - 2021-01-11 08:12:30 --> Config Class Initialized
INFO - 2021-01-11 08:12:30 --> Loader Class Initialized
INFO - 2021-01-11 08:12:30 --> Helper loaded: url_helper
INFO - 2021-01-11 08:12:30 --> Helper loaded: file_helper
INFO - 2021-01-11 08:12:30 --> Helper loaded: form_helper
INFO - 2021-01-11 08:12:30 --> Helper loaded: my_helper
INFO - 2021-01-11 08:12:30 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:12:30 --> Controller Class Initialized
DEBUG - 2021-01-11 08:12:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:12:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:12:30 --> Final output sent to browser
DEBUG - 2021-01-11 08:12:30 --> Total execution time: 0.2613
INFO - 2021-01-11 08:12:30 --> Config Class Initialized
INFO - 2021-01-11 08:12:30 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:12:30 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:12:30 --> Utf8 Class Initialized
INFO - 2021-01-11 08:12:30 --> URI Class Initialized
INFO - 2021-01-11 08:12:30 --> Router Class Initialized
INFO - 2021-01-11 08:12:30 --> Output Class Initialized
INFO - 2021-01-11 08:12:30 --> Security Class Initialized
DEBUG - 2021-01-11 08:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:12:30 --> Input Class Initialized
INFO - 2021-01-11 08:12:30 --> Language Class Initialized
INFO - 2021-01-11 08:12:30 --> Language Class Initialized
INFO - 2021-01-11 08:12:30 --> Config Class Initialized
INFO - 2021-01-11 08:12:30 --> Loader Class Initialized
INFO - 2021-01-11 08:12:30 --> Helper loaded: url_helper
INFO - 2021-01-11 08:12:30 --> Helper loaded: file_helper
INFO - 2021-01-11 08:12:30 --> Helper loaded: form_helper
INFO - 2021-01-11 08:12:30 --> Helper loaded: my_helper
INFO - 2021-01-11 08:12:31 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:12:31 --> Controller Class Initialized
INFO - 2021-01-11 08:12:33 --> Config Class Initialized
INFO - 2021-01-11 08:12:33 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:12:33 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:12:33 --> Utf8 Class Initialized
INFO - 2021-01-11 08:12:33 --> URI Class Initialized
INFO - 2021-01-11 08:12:33 --> Router Class Initialized
INFO - 2021-01-11 08:12:33 --> Output Class Initialized
INFO - 2021-01-11 08:12:33 --> Security Class Initialized
DEBUG - 2021-01-11 08:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:12:33 --> Input Class Initialized
INFO - 2021-01-11 08:12:33 --> Language Class Initialized
INFO - 2021-01-11 08:12:33 --> Language Class Initialized
INFO - 2021-01-11 08:12:33 --> Config Class Initialized
INFO - 2021-01-11 08:12:33 --> Loader Class Initialized
INFO - 2021-01-11 08:12:33 --> Helper loaded: url_helper
INFO - 2021-01-11 08:12:33 --> Helper loaded: file_helper
INFO - 2021-01-11 08:12:33 --> Helper loaded: form_helper
INFO - 2021-01-11 08:12:33 --> Helper loaded: my_helper
INFO - 2021-01-11 08:12:33 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:12:33 --> Controller Class Initialized
DEBUG - 2021-01-11 08:12:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:12:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:12:33 --> Final output sent to browser
DEBUG - 2021-01-11 08:12:33 --> Total execution time: 0.3074
INFO - 2021-01-11 08:12:38 --> Config Class Initialized
INFO - 2021-01-11 08:12:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:12:38 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:12:38 --> Utf8 Class Initialized
INFO - 2021-01-11 08:12:38 --> URI Class Initialized
INFO - 2021-01-11 08:12:38 --> Router Class Initialized
INFO - 2021-01-11 08:12:38 --> Output Class Initialized
INFO - 2021-01-11 08:12:38 --> Security Class Initialized
DEBUG - 2021-01-11 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:12:38 --> Input Class Initialized
INFO - 2021-01-11 08:12:38 --> Language Class Initialized
INFO - 2021-01-11 08:12:38 --> Language Class Initialized
INFO - 2021-01-11 08:12:38 --> Config Class Initialized
INFO - 2021-01-11 08:12:38 --> Loader Class Initialized
INFO - 2021-01-11 08:12:38 --> Helper loaded: url_helper
INFO - 2021-01-11 08:12:38 --> Helper loaded: file_helper
INFO - 2021-01-11 08:12:38 --> Helper loaded: form_helper
INFO - 2021-01-11 08:12:38 --> Helper loaded: my_helper
INFO - 2021-01-11 08:12:38 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:12:38 --> Controller Class Initialized
DEBUG - 2021-01-11 08:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:12:38 --> Final output sent to browser
DEBUG - 2021-01-11 08:12:38 --> Total execution time: 0.3182
INFO - 2021-01-11 08:12:38 --> Config Class Initialized
INFO - 2021-01-11 08:12:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:12:38 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:12:38 --> Utf8 Class Initialized
INFO - 2021-01-11 08:12:38 --> URI Class Initialized
INFO - 2021-01-11 08:12:38 --> Router Class Initialized
INFO - 2021-01-11 08:12:39 --> Output Class Initialized
INFO - 2021-01-11 08:12:39 --> Security Class Initialized
DEBUG - 2021-01-11 08:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:12:39 --> Input Class Initialized
INFO - 2021-01-11 08:12:39 --> Language Class Initialized
INFO - 2021-01-11 08:12:39 --> Language Class Initialized
INFO - 2021-01-11 08:12:39 --> Config Class Initialized
INFO - 2021-01-11 08:12:39 --> Loader Class Initialized
INFO - 2021-01-11 08:12:39 --> Helper loaded: url_helper
INFO - 2021-01-11 08:12:39 --> Helper loaded: file_helper
INFO - 2021-01-11 08:12:39 --> Helper loaded: form_helper
INFO - 2021-01-11 08:12:39 --> Helper loaded: my_helper
INFO - 2021-01-11 08:12:39 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:12:39 --> Controller Class Initialized
INFO - 2021-01-11 08:12:46 --> Config Class Initialized
INFO - 2021-01-11 08:12:46 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:12:46 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:12:46 --> Utf8 Class Initialized
INFO - 2021-01-11 08:12:46 --> URI Class Initialized
INFO - 2021-01-11 08:12:46 --> Router Class Initialized
INFO - 2021-01-11 08:12:46 --> Output Class Initialized
INFO - 2021-01-11 08:12:46 --> Security Class Initialized
DEBUG - 2021-01-11 08:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:12:46 --> Input Class Initialized
INFO - 2021-01-11 08:12:46 --> Language Class Initialized
INFO - 2021-01-11 08:12:46 --> Language Class Initialized
INFO - 2021-01-11 08:12:46 --> Config Class Initialized
INFO - 2021-01-11 08:12:46 --> Loader Class Initialized
INFO - 2021-01-11 08:12:46 --> Helper loaded: url_helper
INFO - 2021-01-11 08:12:46 --> Helper loaded: file_helper
INFO - 2021-01-11 08:12:46 --> Helper loaded: form_helper
INFO - 2021-01-11 08:12:46 --> Helper loaded: my_helper
INFO - 2021-01-11 08:12:46 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:12:46 --> Controller Class Initialized
INFO - 2021-01-11 08:12:46 --> Final output sent to browser
DEBUG - 2021-01-11 08:12:46 --> Total execution time: 0.2168
INFO - 2021-01-11 08:12:54 --> Config Class Initialized
INFO - 2021-01-11 08:12:54 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:12:54 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:12:54 --> Utf8 Class Initialized
INFO - 2021-01-11 08:12:54 --> URI Class Initialized
INFO - 2021-01-11 08:12:54 --> Router Class Initialized
INFO - 2021-01-11 08:12:54 --> Output Class Initialized
INFO - 2021-01-11 08:12:54 --> Security Class Initialized
DEBUG - 2021-01-11 08:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:12:54 --> Input Class Initialized
INFO - 2021-01-11 08:12:54 --> Language Class Initialized
INFO - 2021-01-11 08:12:54 --> Language Class Initialized
INFO - 2021-01-11 08:12:54 --> Config Class Initialized
INFO - 2021-01-11 08:12:54 --> Loader Class Initialized
INFO - 2021-01-11 08:12:54 --> Helper loaded: url_helper
INFO - 2021-01-11 08:12:54 --> Helper loaded: file_helper
INFO - 2021-01-11 08:12:54 --> Helper loaded: form_helper
INFO - 2021-01-11 08:12:54 --> Helper loaded: my_helper
INFO - 2021-01-11 08:12:54 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:12:54 --> Controller Class Initialized
INFO - 2021-01-11 08:12:54 --> Final output sent to browser
DEBUG - 2021-01-11 08:12:54 --> Total execution time: 0.2885
INFO - 2021-01-11 08:12:56 --> Config Class Initialized
INFO - 2021-01-11 08:12:56 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:12:56 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:12:56 --> Utf8 Class Initialized
INFO - 2021-01-11 08:12:56 --> URI Class Initialized
INFO - 2021-01-11 08:12:56 --> Router Class Initialized
INFO - 2021-01-11 08:12:56 --> Output Class Initialized
INFO - 2021-01-11 08:12:56 --> Security Class Initialized
DEBUG - 2021-01-11 08:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:12:56 --> Input Class Initialized
INFO - 2021-01-11 08:12:56 --> Language Class Initialized
INFO - 2021-01-11 08:12:56 --> Language Class Initialized
INFO - 2021-01-11 08:12:56 --> Config Class Initialized
INFO - 2021-01-11 08:12:56 --> Loader Class Initialized
INFO - 2021-01-11 08:12:56 --> Helper loaded: url_helper
INFO - 2021-01-11 08:12:56 --> Helper loaded: file_helper
INFO - 2021-01-11 08:12:56 --> Helper loaded: form_helper
INFO - 2021-01-11 08:12:56 --> Helper loaded: my_helper
INFO - 2021-01-11 08:12:56 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:12:56 --> Controller Class Initialized
INFO - 2021-01-11 08:12:56 --> Final output sent to browser
DEBUG - 2021-01-11 08:12:56 --> Total execution time: 0.2904
INFO - 2021-01-11 08:13:02 --> Config Class Initialized
INFO - 2021-01-11 08:13:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:02 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:02 --> URI Class Initialized
INFO - 2021-01-11 08:13:02 --> Router Class Initialized
INFO - 2021-01-11 08:13:02 --> Output Class Initialized
INFO - 2021-01-11 08:13:02 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:02 --> Input Class Initialized
INFO - 2021-01-11 08:13:02 --> Language Class Initialized
INFO - 2021-01-11 08:13:02 --> Language Class Initialized
INFO - 2021-01-11 08:13:02 --> Config Class Initialized
INFO - 2021-01-11 08:13:02 --> Loader Class Initialized
INFO - 2021-01-11 08:13:02 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:02 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:02 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:02 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:02 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:02 --> Controller Class Initialized
INFO - 2021-01-11 08:13:03 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:03 --> Total execution time: 0.2674
INFO - 2021-01-11 08:13:05 --> Config Class Initialized
INFO - 2021-01-11 08:13:05 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:05 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:05 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:05 --> URI Class Initialized
INFO - 2021-01-11 08:13:05 --> Router Class Initialized
INFO - 2021-01-11 08:13:05 --> Output Class Initialized
INFO - 2021-01-11 08:13:05 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:05 --> Input Class Initialized
INFO - 2021-01-11 08:13:05 --> Language Class Initialized
INFO - 2021-01-11 08:13:05 --> Language Class Initialized
INFO - 2021-01-11 08:13:05 --> Config Class Initialized
INFO - 2021-01-11 08:13:05 --> Loader Class Initialized
INFO - 2021-01-11 08:13:05 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:05 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:05 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:05 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:05 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:05 --> Controller Class Initialized
INFO - 2021-01-11 08:13:05 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:05 --> Total execution time: 0.2204
INFO - 2021-01-11 08:13:12 --> Config Class Initialized
INFO - 2021-01-11 08:13:12 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:12 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:12 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:12 --> URI Class Initialized
INFO - 2021-01-11 08:13:12 --> Router Class Initialized
INFO - 2021-01-11 08:13:12 --> Output Class Initialized
INFO - 2021-01-11 08:13:12 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:12 --> Input Class Initialized
INFO - 2021-01-11 08:13:12 --> Language Class Initialized
INFO - 2021-01-11 08:13:12 --> Language Class Initialized
INFO - 2021-01-11 08:13:12 --> Config Class Initialized
INFO - 2021-01-11 08:13:12 --> Loader Class Initialized
INFO - 2021-01-11 08:13:12 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:12 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:12 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:12 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:12 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:12 --> Controller Class Initialized
INFO - 2021-01-11 08:13:12 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:12 --> Total execution time: 0.2858
INFO - 2021-01-11 08:13:15 --> Config Class Initialized
INFO - 2021-01-11 08:13:15 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:15 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:15 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:15 --> URI Class Initialized
INFO - 2021-01-11 08:13:15 --> Router Class Initialized
INFO - 2021-01-11 08:13:15 --> Output Class Initialized
INFO - 2021-01-11 08:13:15 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:15 --> Input Class Initialized
INFO - 2021-01-11 08:13:15 --> Language Class Initialized
INFO - 2021-01-11 08:13:15 --> Language Class Initialized
INFO - 2021-01-11 08:13:15 --> Config Class Initialized
INFO - 2021-01-11 08:13:15 --> Loader Class Initialized
INFO - 2021-01-11 08:13:15 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:15 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:15 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:15 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:15 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:15 --> Controller Class Initialized
INFO - 2021-01-11 08:13:15 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:15 --> Total execution time: 0.2262
INFO - 2021-01-11 08:13:24 --> Config Class Initialized
INFO - 2021-01-11 08:13:24 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:24 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:24 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:24 --> URI Class Initialized
INFO - 2021-01-11 08:13:24 --> Router Class Initialized
INFO - 2021-01-11 08:13:24 --> Output Class Initialized
INFO - 2021-01-11 08:13:24 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:24 --> Input Class Initialized
INFO - 2021-01-11 08:13:24 --> Language Class Initialized
INFO - 2021-01-11 08:13:24 --> Language Class Initialized
INFO - 2021-01-11 08:13:24 --> Config Class Initialized
INFO - 2021-01-11 08:13:24 --> Loader Class Initialized
INFO - 2021-01-11 08:13:24 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:24 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:25 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:25 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:25 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:25 --> Controller Class Initialized
INFO - 2021-01-11 08:13:25 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:25 --> Total execution time: 0.2745
INFO - 2021-01-11 08:13:34 --> Config Class Initialized
INFO - 2021-01-11 08:13:34 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:34 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:34 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:34 --> URI Class Initialized
INFO - 2021-01-11 08:13:34 --> Router Class Initialized
INFO - 2021-01-11 08:13:34 --> Output Class Initialized
INFO - 2021-01-11 08:13:34 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:34 --> Input Class Initialized
INFO - 2021-01-11 08:13:34 --> Language Class Initialized
INFO - 2021-01-11 08:13:34 --> Language Class Initialized
INFO - 2021-01-11 08:13:34 --> Config Class Initialized
INFO - 2021-01-11 08:13:34 --> Loader Class Initialized
INFO - 2021-01-11 08:13:34 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:34 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:34 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:34 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:34 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:34 --> Controller Class Initialized
DEBUG - 2021-01-11 08:13:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:13:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:13:34 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:34 --> Total execution time: 0.2791
INFO - 2021-01-11 08:13:39 --> Config Class Initialized
INFO - 2021-01-11 08:13:39 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:39 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:39 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:39 --> URI Class Initialized
INFO - 2021-01-11 08:13:39 --> Router Class Initialized
INFO - 2021-01-11 08:13:39 --> Output Class Initialized
INFO - 2021-01-11 08:13:39 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:39 --> Input Class Initialized
INFO - 2021-01-11 08:13:39 --> Language Class Initialized
INFO - 2021-01-11 08:13:39 --> Language Class Initialized
INFO - 2021-01-11 08:13:39 --> Config Class Initialized
INFO - 2021-01-11 08:13:39 --> Loader Class Initialized
INFO - 2021-01-11 08:13:39 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:39 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:39 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:39 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:39 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:39 --> Controller Class Initialized
DEBUG - 2021-01-11 08:13:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:13:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:13:39 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:39 --> Total execution time: 0.3349
INFO - 2021-01-11 08:13:39 --> Config Class Initialized
INFO - 2021-01-11 08:13:39 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:39 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:39 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:39 --> URI Class Initialized
INFO - 2021-01-11 08:13:39 --> Router Class Initialized
INFO - 2021-01-11 08:13:39 --> Output Class Initialized
INFO - 2021-01-11 08:13:39 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:39 --> Input Class Initialized
INFO - 2021-01-11 08:13:39 --> Language Class Initialized
INFO - 2021-01-11 08:13:39 --> Language Class Initialized
INFO - 2021-01-11 08:13:39 --> Config Class Initialized
INFO - 2021-01-11 08:13:39 --> Loader Class Initialized
INFO - 2021-01-11 08:13:39 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:40 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:40 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:40 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:40 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:40 --> Controller Class Initialized
INFO - 2021-01-11 08:13:41 --> Config Class Initialized
INFO - 2021-01-11 08:13:41 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:41 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:41 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:41 --> URI Class Initialized
INFO - 2021-01-11 08:13:41 --> Router Class Initialized
INFO - 2021-01-11 08:13:41 --> Output Class Initialized
INFO - 2021-01-11 08:13:41 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:41 --> Input Class Initialized
INFO - 2021-01-11 08:13:41 --> Language Class Initialized
INFO - 2021-01-11 08:13:41 --> Language Class Initialized
INFO - 2021-01-11 08:13:41 --> Config Class Initialized
INFO - 2021-01-11 08:13:41 --> Loader Class Initialized
INFO - 2021-01-11 08:13:41 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:41 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:41 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:41 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:41 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:41 --> Controller Class Initialized
INFO - 2021-01-11 08:13:41 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:41 --> Total execution time: 0.2209
INFO - 2021-01-11 08:13:48 --> Config Class Initialized
INFO - 2021-01-11 08:13:48 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:48 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:48 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:48 --> URI Class Initialized
INFO - 2021-01-11 08:13:48 --> Router Class Initialized
INFO - 2021-01-11 08:13:48 --> Output Class Initialized
INFO - 2021-01-11 08:13:48 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:48 --> Input Class Initialized
INFO - 2021-01-11 08:13:48 --> Language Class Initialized
INFO - 2021-01-11 08:13:48 --> Language Class Initialized
INFO - 2021-01-11 08:13:48 --> Config Class Initialized
INFO - 2021-01-11 08:13:48 --> Loader Class Initialized
INFO - 2021-01-11 08:13:48 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:48 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:48 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:48 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:48 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:48 --> Controller Class Initialized
DEBUG - 2021-01-11 08:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:13:48 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:48 --> Total execution time: 0.3147
INFO - 2021-01-11 08:13:51 --> Config Class Initialized
INFO - 2021-01-11 08:13:51 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:51 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:51 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:51 --> URI Class Initialized
INFO - 2021-01-11 08:13:51 --> Router Class Initialized
INFO - 2021-01-11 08:13:51 --> Output Class Initialized
INFO - 2021-01-11 08:13:51 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:51 --> Input Class Initialized
INFO - 2021-01-11 08:13:51 --> Language Class Initialized
INFO - 2021-01-11 08:13:51 --> Language Class Initialized
INFO - 2021-01-11 08:13:51 --> Config Class Initialized
INFO - 2021-01-11 08:13:51 --> Loader Class Initialized
INFO - 2021-01-11 08:13:51 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:51 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:51 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:51 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:51 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:51 --> Controller Class Initialized
DEBUG - 2021-01-11 08:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:13:51 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:51 --> Total execution time: 0.2758
INFO - 2021-01-11 08:13:51 --> Config Class Initialized
INFO - 2021-01-11 08:13:51 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:51 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:51 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:51 --> URI Class Initialized
INFO - 2021-01-11 08:13:51 --> Router Class Initialized
INFO - 2021-01-11 08:13:51 --> Output Class Initialized
INFO - 2021-01-11 08:13:51 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:51 --> Input Class Initialized
INFO - 2021-01-11 08:13:51 --> Language Class Initialized
INFO - 2021-01-11 08:13:51 --> Language Class Initialized
INFO - 2021-01-11 08:13:51 --> Config Class Initialized
INFO - 2021-01-11 08:13:51 --> Loader Class Initialized
INFO - 2021-01-11 08:13:51 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:51 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:51 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:51 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:51 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:51 --> Controller Class Initialized
INFO - 2021-01-11 08:13:53 --> Config Class Initialized
INFO - 2021-01-11 08:13:53 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:53 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:53 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:53 --> URI Class Initialized
INFO - 2021-01-11 08:13:53 --> Router Class Initialized
INFO - 2021-01-11 08:13:53 --> Output Class Initialized
INFO - 2021-01-11 08:13:53 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:53 --> Input Class Initialized
INFO - 2021-01-11 08:13:53 --> Language Class Initialized
INFO - 2021-01-11 08:13:53 --> Language Class Initialized
INFO - 2021-01-11 08:13:53 --> Config Class Initialized
INFO - 2021-01-11 08:13:53 --> Loader Class Initialized
INFO - 2021-01-11 08:13:53 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:53 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:53 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:53 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:53 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:53 --> Controller Class Initialized
DEBUG - 2021-01-11 08:13:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:13:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:13:53 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:53 --> Total execution time: 0.2843
INFO - 2021-01-11 08:13:56 --> Config Class Initialized
INFO - 2021-01-11 08:13:56 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:13:56 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:13:56 --> Utf8 Class Initialized
INFO - 2021-01-11 08:13:56 --> URI Class Initialized
INFO - 2021-01-11 08:13:56 --> Router Class Initialized
INFO - 2021-01-11 08:13:56 --> Output Class Initialized
INFO - 2021-01-11 08:13:56 --> Security Class Initialized
DEBUG - 2021-01-11 08:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:13:56 --> Input Class Initialized
INFO - 2021-01-11 08:13:56 --> Language Class Initialized
INFO - 2021-01-11 08:13:56 --> Language Class Initialized
INFO - 2021-01-11 08:13:56 --> Config Class Initialized
INFO - 2021-01-11 08:13:56 --> Loader Class Initialized
INFO - 2021-01-11 08:13:56 --> Helper loaded: url_helper
INFO - 2021-01-11 08:13:56 --> Helper loaded: file_helper
INFO - 2021-01-11 08:13:56 --> Helper loaded: form_helper
INFO - 2021-01-11 08:13:56 --> Helper loaded: my_helper
INFO - 2021-01-11 08:13:56 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:13:56 --> Controller Class Initialized
INFO - 2021-01-11 08:13:56 --> Final output sent to browser
DEBUG - 2021-01-11 08:13:56 --> Total execution time: 0.2289
INFO - 2021-01-11 08:14:02 --> Config Class Initialized
INFO - 2021-01-11 08:14:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:02 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:02 --> URI Class Initialized
INFO - 2021-01-11 08:14:02 --> Router Class Initialized
INFO - 2021-01-11 08:14:02 --> Output Class Initialized
INFO - 2021-01-11 08:14:02 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:02 --> Input Class Initialized
INFO - 2021-01-11 08:14:02 --> Language Class Initialized
INFO - 2021-01-11 08:14:03 --> Language Class Initialized
INFO - 2021-01-11 08:14:03 --> Config Class Initialized
INFO - 2021-01-11 08:14:03 --> Loader Class Initialized
INFO - 2021-01-11 08:14:03 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:03 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:03 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:03 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:03 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:03 --> Controller Class Initialized
INFO - 2021-01-11 08:14:03 --> Final output sent to browser
DEBUG - 2021-01-11 08:14:03 --> Total execution time: 0.3213
INFO - 2021-01-11 08:14:06 --> Config Class Initialized
INFO - 2021-01-11 08:14:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:06 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:06 --> URI Class Initialized
INFO - 2021-01-11 08:14:06 --> Router Class Initialized
INFO - 2021-01-11 08:14:06 --> Output Class Initialized
INFO - 2021-01-11 08:14:06 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:06 --> Input Class Initialized
INFO - 2021-01-11 08:14:06 --> Language Class Initialized
INFO - 2021-01-11 08:14:06 --> Language Class Initialized
INFO - 2021-01-11 08:14:06 --> Config Class Initialized
INFO - 2021-01-11 08:14:06 --> Loader Class Initialized
INFO - 2021-01-11 08:14:06 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:06 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:06 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:06 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:06 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:06 --> Controller Class Initialized
INFO - 2021-01-11 08:14:06 --> Final output sent to browser
DEBUG - 2021-01-11 08:14:06 --> Total execution time: 0.2739
INFO - 2021-01-11 08:14:15 --> Config Class Initialized
INFO - 2021-01-11 08:14:15 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:15 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:15 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:15 --> URI Class Initialized
INFO - 2021-01-11 08:14:15 --> Router Class Initialized
INFO - 2021-01-11 08:14:15 --> Output Class Initialized
INFO - 2021-01-11 08:14:15 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:15 --> Input Class Initialized
INFO - 2021-01-11 08:14:15 --> Language Class Initialized
INFO - 2021-01-11 08:14:15 --> Language Class Initialized
INFO - 2021-01-11 08:14:15 --> Config Class Initialized
INFO - 2021-01-11 08:14:15 --> Loader Class Initialized
INFO - 2021-01-11 08:14:15 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:15 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:15 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:15 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:15 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:15 --> Controller Class Initialized
INFO - 2021-01-11 08:14:15 --> Final output sent to browser
DEBUG - 2021-01-11 08:14:15 --> Total execution time: 0.2906
INFO - 2021-01-11 08:14:42 --> Config Class Initialized
INFO - 2021-01-11 08:14:42 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:42 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:42 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:42 --> URI Class Initialized
INFO - 2021-01-11 08:14:42 --> Router Class Initialized
INFO - 2021-01-11 08:14:42 --> Output Class Initialized
INFO - 2021-01-11 08:14:42 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:42 --> Input Class Initialized
INFO - 2021-01-11 08:14:42 --> Language Class Initialized
INFO - 2021-01-11 08:14:42 --> Language Class Initialized
INFO - 2021-01-11 08:14:42 --> Config Class Initialized
INFO - 2021-01-11 08:14:42 --> Loader Class Initialized
INFO - 2021-01-11 08:14:42 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:42 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:42 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:42 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:42 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:42 --> Controller Class Initialized
DEBUG - 2021-01-11 08:14:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:14:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:14:42 --> Final output sent to browser
DEBUG - 2021-01-11 08:14:42 --> Total execution time: 0.3738
INFO - 2021-01-11 08:14:42 --> Config Class Initialized
INFO - 2021-01-11 08:14:42 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:42 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:42 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:42 --> URI Class Initialized
INFO - 2021-01-11 08:14:42 --> Router Class Initialized
INFO - 2021-01-11 08:14:42 --> Output Class Initialized
INFO - 2021-01-11 08:14:42 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:42 --> Input Class Initialized
INFO - 2021-01-11 08:14:42 --> Language Class Initialized
INFO - 2021-01-11 08:14:42 --> Language Class Initialized
INFO - 2021-01-11 08:14:42 --> Config Class Initialized
INFO - 2021-01-11 08:14:42 --> Loader Class Initialized
INFO - 2021-01-11 08:14:42 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:42 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:42 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:42 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:43 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:43 --> Controller Class Initialized
INFO - 2021-01-11 08:14:45 --> Config Class Initialized
INFO - 2021-01-11 08:14:45 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:45 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:45 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:45 --> URI Class Initialized
INFO - 2021-01-11 08:14:45 --> Router Class Initialized
INFO - 2021-01-11 08:14:45 --> Output Class Initialized
INFO - 2021-01-11 08:14:45 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:45 --> Input Class Initialized
INFO - 2021-01-11 08:14:45 --> Language Class Initialized
INFO - 2021-01-11 08:14:45 --> Language Class Initialized
INFO - 2021-01-11 08:14:45 --> Config Class Initialized
INFO - 2021-01-11 08:14:45 --> Loader Class Initialized
INFO - 2021-01-11 08:14:45 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:45 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:45 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:45 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:45 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:45 --> Controller Class Initialized
DEBUG - 2021-01-11 08:14:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:14:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:14:45 --> Final output sent to browser
DEBUG - 2021-01-11 08:14:45 --> Total execution time: 0.3530
INFO - 2021-01-11 08:14:49 --> Config Class Initialized
INFO - 2021-01-11 08:14:49 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:49 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:49 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:49 --> URI Class Initialized
INFO - 2021-01-11 08:14:49 --> Router Class Initialized
INFO - 2021-01-11 08:14:49 --> Output Class Initialized
INFO - 2021-01-11 08:14:49 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:49 --> Input Class Initialized
INFO - 2021-01-11 08:14:49 --> Language Class Initialized
INFO - 2021-01-11 08:14:49 --> Language Class Initialized
INFO - 2021-01-11 08:14:49 --> Config Class Initialized
INFO - 2021-01-11 08:14:49 --> Loader Class Initialized
INFO - 2021-01-11 08:14:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:49 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:49 --> Controller Class Initialized
DEBUG - 2021-01-11 08:14:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:14:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:14:49 --> Final output sent to browser
DEBUG - 2021-01-11 08:14:49 --> Total execution time: 0.3538
INFO - 2021-01-11 08:14:49 --> Config Class Initialized
INFO - 2021-01-11 08:14:49 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:49 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:49 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:49 --> URI Class Initialized
INFO - 2021-01-11 08:14:49 --> Router Class Initialized
INFO - 2021-01-11 08:14:49 --> Output Class Initialized
INFO - 2021-01-11 08:14:49 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:49 --> Input Class Initialized
INFO - 2021-01-11 08:14:49 --> Language Class Initialized
INFO - 2021-01-11 08:14:49 --> Language Class Initialized
INFO - 2021-01-11 08:14:49 --> Config Class Initialized
INFO - 2021-01-11 08:14:49 --> Loader Class Initialized
INFO - 2021-01-11 08:14:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:49 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:49 --> Controller Class Initialized
INFO - 2021-01-11 08:14:51 --> Config Class Initialized
INFO - 2021-01-11 08:14:51 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:51 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:51 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:51 --> URI Class Initialized
INFO - 2021-01-11 08:14:51 --> Router Class Initialized
INFO - 2021-01-11 08:14:51 --> Output Class Initialized
INFO - 2021-01-11 08:14:51 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:51 --> Input Class Initialized
INFO - 2021-01-11 08:14:51 --> Language Class Initialized
INFO - 2021-01-11 08:14:51 --> Language Class Initialized
INFO - 2021-01-11 08:14:51 --> Config Class Initialized
INFO - 2021-01-11 08:14:51 --> Loader Class Initialized
INFO - 2021-01-11 08:14:51 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:51 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:51 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:51 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:51 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:51 --> Controller Class Initialized
DEBUG - 2021-01-11 08:14:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:14:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:14:51 --> Final output sent to browser
DEBUG - 2021-01-11 08:14:51 --> Total execution time: 0.3483
INFO - 2021-01-11 08:14:54 --> Config Class Initialized
INFO - 2021-01-11 08:14:54 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:54 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:54 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:54 --> URI Class Initialized
INFO - 2021-01-11 08:14:54 --> Router Class Initialized
INFO - 2021-01-11 08:14:54 --> Output Class Initialized
INFO - 2021-01-11 08:14:54 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:54 --> Input Class Initialized
INFO - 2021-01-11 08:14:54 --> Language Class Initialized
INFO - 2021-01-11 08:14:54 --> Language Class Initialized
INFO - 2021-01-11 08:14:54 --> Config Class Initialized
INFO - 2021-01-11 08:14:54 --> Loader Class Initialized
INFO - 2021-01-11 08:14:54 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:54 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:54 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:54 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:54 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:54 --> Controller Class Initialized
DEBUG - 2021-01-11 08:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:14:54 --> Final output sent to browser
DEBUG - 2021-01-11 08:14:54 --> Total execution time: 0.3445
INFO - 2021-01-11 08:14:54 --> Config Class Initialized
INFO - 2021-01-11 08:14:54 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:54 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:54 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:54 --> URI Class Initialized
INFO - 2021-01-11 08:14:55 --> Router Class Initialized
INFO - 2021-01-11 08:14:55 --> Output Class Initialized
INFO - 2021-01-11 08:14:55 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:55 --> Input Class Initialized
INFO - 2021-01-11 08:14:55 --> Language Class Initialized
INFO - 2021-01-11 08:14:55 --> Language Class Initialized
INFO - 2021-01-11 08:14:55 --> Config Class Initialized
INFO - 2021-01-11 08:14:55 --> Loader Class Initialized
INFO - 2021-01-11 08:14:55 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:55 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:55 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:55 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:55 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:55 --> Controller Class Initialized
INFO - 2021-01-11 08:14:57 --> Config Class Initialized
INFO - 2021-01-11 08:14:57 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:14:57 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:14:57 --> Utf8 Class Initialized
INFO - 2021-01-11 08:14:57 --> URI Class Initialized
INFO - 2021-01-11 08:14:57 --> Router Class Initialized
INFO - 2021-01-11 08:14:57 --> Output Class Initialized
INFO - 2021-01-11 08:14:57 --> Security Class Initialized
DEBUG - 2021-01-11 08:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:14:57 --> Input Class Initialized
INFO - 2021-01-11 08:14:57 --> Language Class Initialized
INFO - 2021-01-11 08:14:57 --> Language Class Initialized
INFO - 2021-01-11 08:14:57 --> Config Class Initialized
INFO - 2021-01-11 08:14:57 --> Loader Class Initialized
INFO - 2021-01-11 08:14:57 --> Helper loaded: url_helper
INFO - 2021-01-11 08:14:57 --> Helper loaded: file_helper
INFO - 2021-01-11 08:14:57 --> Helper loaded: form_helper
INFO - 2021-01-11 08:14:57 --> Helper loaded: my_helper
INFO - 2021-01-11 08:14:57 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:14:57 --> Controller Class Initialized
DEBUG - 2021-01-11 08:14:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:14:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:14:57 --> Final output sent to browser
DEBUG - 2021-01-11 08:14:57 --> Total execution time: 0.3498
INFO - 2021-01-11 08:15:02 --> Config Class Initialized
INFO - 2021-01-11 08:15:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:02 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:03 --> URI Class Initialized
INFO - 2021-01-11 08:15:03 --> Router Class Initialized
INFO - 2021-01-11 08:15:03 --> Output Class Initialized
INFO - 2021-01-11 08:15:03 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:03 --> Input Class Initialized
INFO - 2021-01-11 08:15:03 --> Language Class Initialized
INFO - 2021-01-11 08:15:03 --> Language Class Initialized
INFO - 2021-01-11 08:15:03 --> Config Class Initialized
INFO - 2021-01-11 08:15:03 --> Loader Class Initialized
INFO - 2021-01-11 08:15:03 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:03 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:03 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:03 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:03 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:03 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:15:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:03 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:03 --> Total execution time: 0.3408
INFO - 2021-01-11 08:15:03 --> Config Class Initialized
INFO - 2021-01-11 08:15:03 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:03 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:03 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:03 --> URI Class Initialized
INFO - 2021-01-11 08:15:03 --> Router Class Initialized
INFO - 2021-01-11 08:15:03 --> Output Class Initialized
INFO - 2021-01-11 08:15:03 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:03 --> Input Class Initialized
INFO - 2021-01-11 08:15:03 --> Language Class Initialized
INFO - 2021-01-11 08:15:03 --> Language Class Initialized
INFO - 2021-01-11 08:15:03 --> Config Class Initialized
INFO - 2021-01-11 08:15:03 --> Loader Class Initialized
INFO - 2021-01-11 08:15:03 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:03 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:03 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:03 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:03 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:03 --> Controller Class Initialized
INFO - 2021-01-11 08:15:05 --> Config Class Initialized
INFO - 2021-01-11 08:15:05 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:05 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:05 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:05 --> URI Class Initialized
INFO - 2021-01-11 08:15:05 --> Router Class Initialized
INFO - 2021-01-11 08:15:05 --> Output Class Initialized
INFO - 2021-01-11 08:15:05 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:05 --> Input Class Initialized
INFO - 2021-01-11 08:15:05 --> Language Class Initialized
INFO - 2021-01-11 08:15:05 --> Language Class Initialized
INFO - 2021-01-11 08:15:05 --> Config Class Initialized
INFO - 2021-01-11 08:15:05 --> Loader Class Initialized
INFO - 2021-01-11 08:15:05 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:05 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:05 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:05 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:05 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:05 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:05 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:05 --> Total execution time: 0.3537
INFO - 2021-01-11 08:15:09 --> Config Class Initialized
INFO - 2021-01-11 08:15:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:09 --> URI Class Initialized
INFO - 2021-01-11 08:15:09 --> Router Class Initialized
INFO - 2021-01-11 08:15:09 --> Output Class Initialized
INFO - 2021-01-11 08:15:09 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:09 --> Input Class Initialized
INFO - 2021-01-11 08:15:09 --> Language Class Initialized
INFO - 2021-01-11 08:15:09 --> Language Class Initialized
INFO - 2021-01-11 08:15:09 --> Config Class Initialized
INFO - 2021-01-11 08:15:09 --> Loader Class Initialized
INFO - 2021-01-11 08:15:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:10 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:15:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:10 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:10 --> Total execution time: 0.3905
INFO - 2021-01-11 08:15:10 --> Config Class Initialized
INFO - 2021-01-11 08:15:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:10 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:10 --> URI Class Initialized
INFO - 2021-01-11 08:15:10 --> Router Class Initialized
INFO - 2021-01-11 08:15:10 --> Output Class Initialized
INFO - 2021-01-11 08:15:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:10 --> Input Class Initialized
INFO - 2021-01-11 08:15:10 --> Language Class Initialized
INFO - 2021-01-11 08:15:10 --> Language Class Initialized
INFO - 2021-01-11 08:15:10 --> Config Class Initialized
INFO - 2021-01-11 08:15:10 --> Loader Class Initialized
INFO - 2021-01-11 08:15:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:10 --> Controller Class Initialized
INFO - 2021-01-11 08:15:12 --> Config Class Initialized
INFO - 2021-01-11 08:15:12 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:12 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:12 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:12 --> URI Class Initialized
INFO - 2021-01-11 08:15:12 --> Router Class Initialized
INFO - 2021-01-11 08:15:12 --> Output Class Initialized
INFO - 2021-01-11 08:15:12 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:12 --> Input Class Initialized
INFO - 2021-01-11 08:15:12 --> Language Class Initialized
INFO - 2021-01-11 08:15:12 --> Language Class Initialized
INFO - 2021-01-11 08:15:12 --> Config Class Initialized
INFO - 2021-01-11 08:15:12 --> Loader Class Initialized
INFO - 2021-01-11 08:15:12 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:12 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:12 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:12 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:12 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:12 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:12 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:12 --> Total execution time: 0.3578
INFO - 2021-01-11 08:15:15 --> Config Class Initialized
INFO - 2021-01-11 08:15:15 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:15 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:15 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:15 --> URI Class Initialized
INFO - 2021-01-11 08:15:15 --> Router Class Initialized
INFO - 2021-01-11 08:15:15 --> Output Class Initialized
INFO - 2021-01-11 08:15:15 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:15 --> Input Class Initialized
INFO - 2021-01-11 08:15:15 --> Language Class Initialized
INFO - 2021-01-11 08:15:15 --> Language Class Initialized
INFO - 2021-01-11 08:15:15 --> Config Class Initialized
INFO - 2021-01-11 08:15:15 --> Loader Class Initialized
INFO - 2021-01-11 08:15:15 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:15 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:15 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:16 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:16 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:16 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:16 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:16 --> Total execution time: 0.3864
INFO - 2021-01-11 08:15:16 --> Config Class Initialized
INFO - 2021-01-11 08:15:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:16 --> URI Class Initialized
INFO - 2021-01-11 08:15:16 --> Router Class Initialized
INFO - 2021-01-11 08:15:16 --> Output Class Initialized
INFO - 2021-01-11 08:15:16 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:16 --> Input Class Initialized
INFO - 2021-01-11 08:15:16 --> Language Class Initialized
INFO - 2021-01-11 08:15:16 --> Language Class Initialized
INFO - 2021-01-11 08:15:16 --> Config Class Initialized
INFO - 2021-01-11 08:15:16 --> Loader Class Initialized
INFO - 2021-01-11 08:15:16 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:16 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:16 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:16 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:16 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:16 --> Controller Class Initialized
INFO - 2021-01-11 08:15:18 --> Config Class Initialized
INFO - 2021-01-11 08:15:18 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:18 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:18 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:18 --> URI Class Initialized
INFO - 2021-01-11 08:15:18 --> Router Class Initialized
INFO - 2021-01-11 08:15:18 --> Output Class Initialized
INFO - 2021-01-11 08:15:18 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:18 --> Input Class Initialized
INFO - 2021-01-11 08:15:18 --> Language Class Initialized
INFO - 2021-01-11 08:15:18 --> Language Class Initialized
INFO - 2021-01-11 08:15:18 --> Config Class Initialized
INFO - 2021-01-11 08:15:18 --> Loader Class Initialized
INFO - 2021-01-11 08:15:18 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:18 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:18 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:18 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:18 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:18 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:15:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:18 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:18 --> Total execution time: 0.3459
INFO - 2021-01-11 08:15:22 --> Config Class Initialized
INFO - 2021-01-11 08:15:22 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:22 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:22 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:22 --> URI Class Initialized
INFO - 2021-01-11 08:15:22 --> Router Class Initialized
INFO - 2021-01-11 08:15:22 --> Output Class Initialized
INFO - 2021-01-11 08:15:22 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:22 --> Input Class Initialized
INFO - 2021-01-11 08:15:22 --> Language Class Initialized
INFO - 2021-01-11 08:15:22 --> Language Class Initialized
INFO - 2021-01-11 08:15:22 --> Config Class Initialized
INFO - 2021-01-11 08:15:22 --> Loader Class Initialized
INFO - 2021-01-11 08:15:22 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:22 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:22 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:22 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:22 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:22 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:22 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:22 --> Total execution time: 0.4063
INFO - 2021-01-11 08:15:22 --> Config Class Initialized
INFO - 2021-01-11 08:15:22 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:22 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:22 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:22 --> URI Class Initialized
INFO - 2021-01-11 08:15:22 --> Router Class Initialized
INFO - 2021-01-11 08:15:22 --> Output Class Initialized
INFO - 2021-01-11 08:15:22 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:22 --> Input Class Initialized
INFO - 2021-01-11 08:15:22 --> Language Class Initialized
INFO - 2021-01-11 08:15:22 --> Language Class Initialized
INFO - 2021-01-11 08:15:23 --> Config Class Initialized
INFO - 2021-01-11 08:15:23 --> Loader Class Initialized
INFO - 2021-01-11 08:15:23 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:23 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:23 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:23 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:23 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:23 --> Controller Class Initialized
INFO - 2021-01-11 08:15:25 --> Config Class Initialized
INFO - 2021-01-11 08:15:25 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:25 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:25 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:25 --> URI Class Initialized
INFO - 2021-01-11 08:15:25 --> Router Class Initialized
INFO - 2021-01-11 08:15:25 --> Output Class Initialized
INFO - 2021-01-11 08:15:25 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:25 --> Input Class Initialized
INFO - 2021-01-11 08:15:25 --> Language Class Initialized
INFO - 2021-01-11 08:15:25 --> Language Class Initialized
INFO - 2021-01-11 08:15:25 --> Config Class Initialized
INFO - 2021-01-11 08:15:25 --> Loader Class Initialized
INFO - 2021-01-11 08:15:25 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:25 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:25 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:25 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:25 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:25 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:15:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:25 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:25 --> Total execution time: 0.3761
INFO - 2021-01-11 08:15:29 --> Config Class Initialized
INFO - 2021-01-11 08:15:29 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:29 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:29 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:29 --> URI Class Initialized
INFO - 2021-01-11 08:15:29 --> Router Class Initialized
INFO - 2021-01-11 08:15:29 --> Output Class Initialized
INFO - 2021-01-11 08:15:29 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:29 --> Input Class Initialized
INFO - 2021-01-11 08:15:29 --> Language Class Initialized
INFO - 2021-01-11 08:15:29 --> Language Class Initialized
INFO - 2021-01-11 08:15:29 --> Config Class Initialized
INFO - 2021-01-11 08:15:29 --> Loader Class Initialized
INFO - 2021-01-11 08:15:29 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:29 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:29 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:29 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:29 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:29 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:29 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:29 --> Total execution time: 0.3796
INFO - 2021-01-11 08:15:29 --> Config Class Initialized
INFO - 2021-01-11 08:15:29 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:29 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:29 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:29 --> URI Class Initialized
INFO - 2021-01-11 08:15:29 --> Router Class Initialized
INFO - 2021-01-11 08:15:29 --> Output Class Initialized
INFO - 2021-01-11 08:15:29 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:29 --> Input Class Initialized
INFO - 2021-01-11 08:15:29 --> Language Class Initialized
INFO - 2021-01-11 08:15:29 --> Language Class Initialized
INFO - 2021-01-11 08:15:29 --> Config Class Initialized
INFO - 2021-01-11 08:15:29 --> Loader Class Initialized
INFO - 2021-01-11 08:15:29 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:29 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:29 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:29 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:29 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:29 --> Controller Class Initialized
INFO - 2021-01-11 08:15:32 --> Config Class Initialized
INFO - 2021-01-11 08:15:32 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:15:32 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:15:32 --> Utf8 Class Initialized
INFO - 2021-01-11 08:15:32 --> URI Class Initialized
INFO - 2021-01-11 08:15:32 --> Router Class Initialized
INFO - 2021-01-11 08:15:32 --> Output Class Initialized
INFO - 2021-01-11 08:15:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:15:32 --> Input Class Initialized
INFO - 2021-01-11 08:15:32 --> Language Class Initialized
INFO - 2021-01-11 08:15:32 --> Language Class Initialized
INFO - 2021-01-11 08:15:32 --> Config Class Initialized
INFO - 2021-01-11 08:15:32 --> Loader Class Initialized
INFO - 2021-01-11 08:15:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:15:32 --> Helper loaded: file_helper
INFO - 2021-01-11 08:15:32 --> Helper loaded: form_helper
INFO - 2021-01-11 08:15:32 --> Helper loaded: my_helper
INFO - 2021-01-11 08:15:32 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:15:32 --> Controller Class Initialized
DEBUG - 2021-01-11 08:15:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:15:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:15:32 --> Final output sent to browser
DEBUG - 2021-01-11 08:15:32 --> Total execution time: 0.3594
INFO - 2021-01-11 08:16:02 --> Config Class Initialized
INFO - 2021-01-11 08:16:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:02 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:02 --> URI Class Initialized
INFO - 2021-01-11 08:16:03 --> Router Class Initialized
INFO - 2021-01-11 08:16:03 --> Output Class Initialized
INFO - 2021-01-11 08:16:03 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:03 --> Input Class Initialized
INFO - 2021-01-11 08:16:03 --> Language Class Initialized
INFO - 2021-01-11 08:16:03 --> Language Class Initialized
INFO - 2021-01-11 08:16:03 --> Config Class Initialized
INFO - 2021-01-11 08:16:03 --> Loader Class Initialized
INFO - 2021-01-11 08:16:03 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:03 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:03 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:03 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:03 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:03 --> Controller Class Initialized
INFO - 2021-01-11 08:16:03 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:03 --> Total execution time: 0.2471
INFO - 2021-01-11 08:16:08 --> Config Class Initialized
INFO - 2021-01-11 08:16:08 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:08 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:08 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:08 --> URI Class Initialized
INFO - 2021-01-11 08:16:08 --> Router Class Initialized
INFO - 2021-01-11 08:16:08 --> Output Class Initialized
INFO - 2021-01-11 08:16:08 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:08 --> Input Class Initialized
INFO - 2021-01-11 08:16:08 --> Language Class Initialized
INFO - 2021-01-11 08:16:08 --> Language Class Initialized
INFO - 2021-01-11 08:16:08 --> Config Class Initialized
INFO - 2021-01-11 08:16:08 --> Loader Class Initialized
INFO - 2021-01-11 08:16:08 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:08 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:08 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:08 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:08 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:08 --> Controller Class Initialized
INFO - 2021-01-11 08:16:08 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:08 --> Total execution time: 0.2568
INFO - 2021-01-11 08:16:14 --> Config Class Initialized
INFO - 2021-01-11 08:16:14 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:14 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:14 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:14 --> URI Class Initialized
INFO - 2021-01-11 08:16:14 --> Router Class Initialized
INFO - 2021-01-11 08:16:14 --> Output Class Initialized
INFO - 2021-01-11 08:16:14 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:14 --> Input Class Initialized
INFO - 2021-01-11 08:16:14 --> Language Class Initialized
INFO - 2021-01-11 08:16:14 --> Language Class Initialized
INFO - 2021-01-11 08:16:14 --> Config Class Initialized
INFO - 2021-01-11 08:16:14 --> Loader Class Initialized
INFO - 2021-01-11 08:16:14 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:14 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:14 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:14 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:14 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:14 --> Controller Class Initialized
INFO - 2021-01-11 08:16:14 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:14 --> Total execution time: 0.2377
INFO - 2021-01-11 08:16:19 --> Config Class Initialized
INFO - 2021-01-11 08:16:19 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:19 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:19 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:19 --> URI Class Initialized
INFO - 2021-01-11 08:16:19 --> Router Class Initialized
INFO - 2021-01-11 08:16:19 --> Output Class Initialized
INFO - 2021-01-11 08:16:19 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:19 --> Input Class Initialized
INFO - 2021-01-11 08:16:19 --> Language Class Initialized
INFO - 2021-01-11 08:16:19 --> Language Class Initialized
INFO - 2021-01-11 08:16:19 --> Config Class Initialized
INFO - 2021-01-11 08:16:19 --> Loader Class Initialized
INFO - 2021-01-11 08:16:19 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:19 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:19 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:19 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:19 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:19 --> Controller Class Initialized
INFO - 2021-01-11 08:16:19 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:19 --> Total execution time: 0.2589
INFO - 2021-01-11 08:16:26 --> Config Class Initialized
INFO - 2021-01-11 08:16:26 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:26 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:26 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:26 --> URI Class Initialized
INFO - 2021-01-11 08:16:26 --> Router Class Initialized
INFO - 2021-01-11 08:16:26 --> Output Class Initialized
INFO - 2021-01-11 08:16:26 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:26 --> Input Class Initialized
INFO - 2021-01-11 08:16:26 --> Language Class Initialized
INFO - 2021-01-11 08:16:26 --> Language Class Initialized
INFO - 2021-01-11 08:16:26 --> Config Class Initialized
INFO - 2021-01-11 08:16:26 --> Loader Class Initialized
INFO - 2021-01-11 08:16:26 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:26 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:26 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:26 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:26 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:26 --> Controller Class Initialized
INFO - 2021-01-11 08:16:26 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:26 --> Total execution time: 0.3552
INFO - 2021-01-11 08:16:29 --> Config Class Initialized
INFO - 2021-01-11 08:16:29 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:29 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:29 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:29 --> URI Class Initialized
INFO - 2021-01-11 08:16:29 --> Router Class Initialized
INFO - 2021-01-11 08:16:29 --> Output Class Initialized
INFO - 2021-01-11 08:16:29 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:29 --> Input Class Initialized
INFO - 2021-01-11 08:16:29 --> Language Class Initialized
INFO - 2021-01-11 08:16:29 --> Language Class Initialized
INFO - 2021-01-11 08:16:29 --> Config Class Initialized
INFO - 2021-01-11 08:16:29 --> Loader Class Initialized
INFO - 2021-01-11 08:16:29 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:29 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:29 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:29 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:29 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:29 --> Controller Class Initialized
INFO - 2021-01-11 08:16:29 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:29 --> Total execution time: 0.2523
INFO - 2021-01-11 08:16:35 --> Config Class Initialized
INFO - 2021-01-11 08:16:35 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:35 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:35 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:35 --> URI Class Initialized
INFO - 2021-01-11 08:16:35 --> Router Class Initialized
INFO - 2021-01-11 08:16:35 --> Output Class Initialized
INFO - 2021-01-11 08:16:35 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:35 --> Input Class Initialized
INFO - 2021-01-11 08:16:35 --> Language Class Initialized
INFO - 2021-01-11 08:16:35 --> Language Class Initialized
INFO - 2021-01-11 08:16:35 --> Config Class Initialized
INFO - 2021-01-11 08:16:35 --> Loader Class Initialized
INFO - 2021-01-11 08:16:35 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:35 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:35 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:35 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:35 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:35 --> Controller Class Initialized
INFO - 2021-01-11 08:16:35 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:35 --> Total execution time: 0.3806
INFO - 2021-01-11 08:16:39 --> Config Class Initialized
INFO - 2021-01-11 08:16:39 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:39 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:39 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:39 --> URI Class Initialized
INFO - 2021-01-11 08:16:39 --> Router Class Initialized
INFO - 2021-01-11 08:16:39 --> Output Class Initialized
INFO - 2021-01-11 08:16:39 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:39 --> Input Class Initialized
INFO - 2021-01-11 08:16:39 --> Language Class Initialized
INFO - 2021-01-11 08:16:39 --> Language Class Initialized
INFO - 2021-01-11 08:16:39 --> Config Class Initialized
INFO - 2021-01-11 08:16:39 --> Loader Class Initialized
INFO - 2021-01-11 08:16:39 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:39 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:39 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:39 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:39 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:39 --> Controller Class Initialized
INFO - 2021-01-11 08:16:39 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:39 --> Total execution time: 0.2383
INFO - 2021-01-11 08:16:46 --> Config Class Initialized
INFO - 2021-01-11 08:16:46 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:46 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:46 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:46 --> URI Class Initialized
INFO - 2021-01-11 08:16:46 --> Router Class Initialized
INFO - 2021-01-11 08:16:47 --> Output Class Initialized
INFO - 2021-01-11 08:16:47 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:47 --> Input Class Initialized
INFO - 2021-01-11 08:16:47 --> Language Class Initialized
INFO - 2021-01-11 08:16:47 --> Language Class Initialized
INFO - 2021-01-11 08:16:47 --> Config Class Initialized
INFO - 2021-01-11 08:16:47 --> Loader Class Initialized
INFO - 2021-01-11 08:16:47 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:47 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:47 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:47 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:47 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:47 --> Controller Class Initialized
INFO - 2021-01-11 08:16:47 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:47 --> Total execution time: 0.3663
INFO - 2021-01-11 08:16:53 --> Config Class Initialized
INFO - 2021-01-11 08:16:53 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:16:53 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:16:53 --> Utf8 Class Initialized
INFO - 2021-01-11 08:16:53 --> URI Class Initialized
INFO - 2021-01-11 08:16:53 --> Router Class Initialized
INFO - 2021-01-11 08:16:53 --> Output Class Initialized
INFO - 2021-01-11 08:16:53 --> Security Class Initialized
DEBUG - 2021-01-11 08:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:16:53 --> Input Class Initialized
INFO - 2021-01-11 08:16:53 --> Language Class Initialized
INFO - 2021-01-11 08:16:53 --> Language Class Initialized
INFO - 2021-01-11 08:16:53 --> Config Class Initialized
INFO - 2021-01-11 08:16:53 --> Loader Class Initialized
INFO - 2021-01-11 08:16:53 --> Helper loaded: url_helper
INFO - 2021-01-11 08:16:53 --> Helper loaded: file_helper
INFO - 2021-01-11 08:16:53 --> Helper loaded: form_helper
INFO - 2021-01-11 08:16:53 --> Helper loaded: my_helper
INFO - 2021-01-11 08:16:53 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:16:53 --> Controller Class Initialized
INFO - 2021-01-11 08:16:53 --> Final output sent to browser
DEBUG - 2021-01-11 08:16:53 --> Total execution time: 0.3506
INFO - 2021-01-11 08:17:00 --> Config Class Initialized
INFO - 2021-01-11 08:17:00 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:00 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:00 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:00 --> URI Class Initialized
INFO - 2021-01-11 08:17:00 --> Router Class Initialized
INFO - 2021-01-11 08:17:00 --> Output Class Initialized
INFO - 2021-01-11 08:17:00 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:00 --> Input Class Initialized
INFO - 2021-01-11 08:17:00 --> Language Class Initialized
INFO - 2021-01-11 08:17:00 --> Language Class Initialized
INFO - 2021-01-11 08:17:00 --> Config Class Initialized
INFO - 2021-01-11 08:17:00 --> Loader Class Initialized
INFO - 2021-01-11 08:17:00 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:00 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:01 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:01 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:01 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:01 --> Controller Class Initialized
INFO - 2021-01-11 08:17:01 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:01 --> Total execution time: 0.3399
INFO - 2021-01-11 08:17:06 --> Config Class Initialized
INFO - 2021-01-11 08:17:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:06 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:06 --> URI Class Initialized
INFO - 2021-01-11 08:17:06 --> Router Class Initialized
INFO - 2021-01-11 08:17:06 --> Output Class Initialized
INFO - 2021-01-11 08:17:06 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:06 --> Input Class Initialized
INFO - 2021-01-11 08:17:06 --> Language Class Initialized
INFO - 2021-01-11 08:17:06 --> Language Class Initialized
INFO - 2021-01-11 08:17:06 --> Config Class Initialized
INFO - 2021-01-11 08:17:06 --> Loader Class Initialized
INFO - 2021-01-11 08:17:06 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:06 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:06 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:06 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:06 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:06 --> Controller Class Initialized
INFO - 2021-01-11 08:17:07 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:07 --> Total execution time: 0.2512
INFO - 2021-01-11 08:17:08 --> Config Class Initialized
INFO - 2021-01-11 08:17:08 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:08 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:08 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:08 --> URI Class Initialized
INFO - 2021-01-11 08:17:08 --> Router Class Initialized
INFO - 2021-01-11 08:17:08 --> Output Class Initialized
INFO - 2021-01-11 08:17:08 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:08 --> Input Class Initialized
INFO - 2021-01-11 08:17:08 --> Language Class Initialized
INFO - 2021-01-11 08:17:08 --> Language Class Initialized
INFO - 2021-01-11 08:17:09 --> Config Class Initialized
INFO - 2021-01-11 08:17:09 --> Loader Class Initialized
INFO - 2021-01-11 08:17:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:09 --> Controller Class Initialized
INFO - 2021-01-11 08:17:09 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:09 --> Total execution time: 0.2503
INFO - 2021-01-11 08:17:10 --> Config Class Initialized
INFO - 2021-01-11 08:17:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:10 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:10 --> URI Class Initialized
INFO - 2021-01-11 08:17:10 --> Router Class Initialized
INFO - 2021-01-11 08:17:10 --> Output Class Initialized
INFO - 2021-01-11 08:17:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:10 --> Input Class Initialized
INFO - 2021-01-11 08:17:10 --> Language Class Initialized
INFO - 2021-01-11 08:17:10 --> Language Class Initialized
INFO - 2021-01-11 08:17:10 --> Config Class Initialized
INFO - 2021-01-11 08:17:10 --> Loader Class Initialized
INFO - 2021-01-11 08:17:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:10 --> Controller Class Initialized
INFO - 2021-01-11 08:17:10 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:10 --> Total execution time: 0.2483
INFO - 2021-01-11 08:17:12 --> Config Class Initialized
INFO - 2021-01-11 08:17:12 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:12 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:12 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:12 --> URI Class Initialized
INFO - 2021-01-11 08:17:12 --> Router Class Initialized
INFO - 2021-01-11 08:17:12 --> Output Class Initialized
INFO - 2021-01-11 08:17:12 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:12 --> Input Class Initialized
INFO - 2021-01-11 08:17:12 --> Language Class Initialized
INFO - 2021-01-11 08:17:12 --> Language Class Initialized
INFO - 2021-01-11 08:17:12 --> Config Class Initialized
INFO - 2021-01-11 08:17:12 --> Loader Class Initialized
INFO - 2021-01-11 08:17:12 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:12 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:12 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:12 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:12 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:12 --> Controller Class Initialized
INFO - 2021-01-11 08:17:12 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:12 --> Total execution time: 0.2681
INFO - 2021-01-11 08:17:22 --> Config Class Initialized
INFO - 2021-01-11 08:17:22 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:22 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:22 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:22 --> URI Class Initialized
INFO - 2021-01-11 08:17:22 --> Router Class Initialized
INFO - 2021-01-11 08:17:22 --> Output Class Initialized
INFO - 2021-01-11 08:17:22 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:22 --> Input Class Initialized
INFO - 2021-01-11 08:17:22 --> Language Class Initialized
INFO - 2021-01-11 08:17:22 --> Language Class Initialized
INFO - 2021-01-11 08:17:22 --> Config Class Initialized
INFO - 2021-01-11 08:17:22 --> Loader Class Initialized
INFO - 2021-01-11 08:17:22 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:22 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:22 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:23 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:23 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:23 --> Controller Class Initialized
INFO - 2021-01-11 08:17:23 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:23 --> Total execution time: 0.2724
INFO - 2021-01-11 08:17:30 --> Config Class Initialized
INFO - 2021-01-11 08:17:30 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:30 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:30 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:30 --> URI Class Initialized
INFO - 2021-01-11 08:17:30 --> Router Class Initialized
INFO - 2021-01-11 08:17:30 --> Output Class Initialized
INFO - 2021-01-11 08:17:30 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:30 --> Input Class Initialized
INFO - 2021-01-11 08:17:30 --> Language Class Initialized
INFO - 2021-01-11 08:17:30 --> Language Class Initialized
INFO - 2021-01-11 08:17:30 --> Config Class Initialized
INFO - 2021-01-11 08:17:30 --> Loader Class Initialized
INFO - 2021-01-11 08:17:30 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:30 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:30 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:30 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:30 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:30 --> Controller Class Initialized
INFO - 2021-01-11 08:17:30 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:30 --> Total execution time: 0.3419
INFO - 2021-01-11 08:17:33 --> Config Class Initialized
INFO - 2021-01-11 08:17:33 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:33 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:33 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:33 --> URI Class Initialized
INFO - 2021-01-11 08:17:33 --> Router Class Initialized
INFO - 2021-01-11 08:17:33 --> Output Class Initialized
INFO - 2021-01-11 08:17:33 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:33 --> Input Class Initialized
INFO - 2021-01-11 08:17:33 --> Language Class Initialized
INFO - 2021-01-11 08:17:33 --> Language Class Initialized
INFO - 2021-01-11 08:17:33 --> Config Class Initialized
INFO - 2021-01-11 08:17:33 --> Loader Class Initialized
INFO - 2021-01-11 08:17:33 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:33 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:33 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:33 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:33 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:33 --> Controller Class Initialized
INFO - 2021-01-11 08:17:33 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:33 --> Total execution time: 0.2631
INFO - 2021-01-11 08:17:38 --> Config Class Initialized
INFO - 2021-01-11 08:17:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:38 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:38 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:38 --> URI Class Initialized
INFO - 2021-01-11 08:17:38 --> Router Class Initialized
INFO - 2021-01-11 08:17:38 --> Output Class Initialized
INFO - 2021-01-11 08:17:38 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:38 --> Input Class Initialized
INFO - 2021-01-11 08:17:38 --> Language Class Initialized
INFO - 2021-01-11 08:17:38 --> Language Class Initialized
INFO - 2021-01-11 08:17:38 --> Config Class Initialized
INFO - 2021-01-11 08:17:38 --> Loader Class Initialized
INFO - 2021-01-11 08:17:38 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:38 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:38 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:38 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:38 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:38 --> Controller Class Initialized
INFO - 2021-01-11 08:17:38 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:38 --> Total execution time: 0.3488
INFO - 2021-01-11 08:17:41 --> Config Class Initialized
INFO - 2021-01-11 08:17:41 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:41 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:41 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:41 --> URI Class Initialized
INFO - 2021-01-11 08:17:41 --> Router Class Initialized
INFO - 2021-01-11 08:17:41 --> Output Class Initialized
INFO - 2021-01-11 08:17:41 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:41 --> Input Class Initialized
INFO - 2021-01-11 08:17:41 --> Language Class Initialized
INFO - 2021-01-11 08:17:41 --> Language Class Initialized
INFO - 2021-01-11 08:17:41 --> Config Class Initialized
INFO - 2021-01-11 08:17:41 --> Loader Class Initialized
INFO - 2021-01-11 08:17:41 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:41 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:41 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:41 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:41 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:41 --> Controller Class Initialized
INFO - 2021-01-11 08:17:41 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:41 --> Total execution time: 0.2857
INFO - 2021-01-11 08:17:46 --> Config Class Initialized
INFO - 2021-01-11 08:17:46 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:46 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:46 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:46 --> URI Class Initialized
INFO - 2021-01-11 08:17:46 --> Router Class Initialized
INFO - 2021-01-11 08:17:46 --> Output Class Initialized
INFO - 2021-01-11 08:17:46 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:46 --> Input Class Initialized
INFO - 2021-01-11 08:17:46 --> Language Class Initialized
INFO - 2021-01-11 08:17:46 --> Language Class Initialized
INFO - 2021-01-11 08:17:46 --> Config Class Initialized
INFO - 2021-01-11 08:17:46 --> Loader Class Initialized
INFO - 2021-01-11 08:17:46 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:46 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:46 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:46 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:46 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:46 --> Controller Class Initialized
INFO - 2021-01-11 08:17:46 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:46 --> Total execution time: 0.2590
INFO - 2021-01-11 08:17:52 --> Config Class Initialized
INFO - 2021-01-11 08:17:52 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:52 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:52 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:52 --> URI Class Initialized
INFO - 2021-01-11 08:17:52 --> Router Class Initialized
INFO - 2021-01-11 08:17:52 --> Output Class Initialized
INFO - 2021-01-11 08:17:52 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:52 --> Input Class Initialized
INFO - 2021-01-11 08:17:52 --> Language Class Initialized
INFO - 2021-01-11 08:17:52 --> Language Class Initialized
INFO - 2021-01-11 08:17:52 --> Config Class Initialized
INFO - 2021-01-11 08:17:52 --> Loader Class Initialized
INFO - 2021-01-11 08:17:52 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:52 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:52 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:52 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:52 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:52 --> Controller Class Initialized
INFO - 2021-01-11 08:17:52 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:52 --> Total execution time: 0.3752
INFO - 2021-01-11 08:17:55 --> Config Class Initialized
INFO - 2021-01-11 08:17:55 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:17:55 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:17:55 --> Utf8 Class Initialized
INFO - 2021-01-11 08:17:55 --> URI Class Initialized
INFO - 2021-01-11 08:17:55 --> Router Class Initialized
INFO - 2021-01-11 08:17:55 --> Output Class Initialized
INFO - 2021-01-11 08:17:55 --> Security Class Initialized
DEBUG - 2021-01-11 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:17:55 --> Input Class Initialized
INFO - 2021-01-11 08:17:55 --> Language Class Initialized
INFO - 2021-01-11 08:17:55 --> Language Class Initialized
INFO - 2021-01-11 08:17:55 --> Config Class Initialized
INFO - 2021-01-11 08:17:55 --> Loader Class Initialized
INFO - 2021-01-11 08:17:55 --> Helper loaded: url_helper
INFO - 2021-01-11 08:17:55 --> Helper loaded: file_helper
INFO - 2021-01-11 08:17:55 --> Helper loaded: form_helper
INFO - 2021-01-11 08:17:55 --> Helper loaded: my_helper
INFO - 2021-01-11 08:17:55 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:17:55 --> Controller Class Initialized
INFO - 2021-01-11 08:17:55 --> Final output sent to browser
DEBUG - 2021-01-11 08:17:55 --> Total execution time: 0.2754
INFO - 2021-01-11 08:18:01 --> Config Class Initialized
INFO - 2021-01-11 08:18:01 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:01 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:01 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:01 --> URI Class Initialized
INFO - 2021-01-11 08:18:01 --> Router Class Initialized
INFO - 2021-01-11 08:18:01 --> Output Class Initialized
INFO - 2021-01-11 08:18:01 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:01 --> Input Class Initialized
INFO - 2021-01-11 08:18:01 --> Language Class Initialized
INFO - 2021-01-11 08:18:01 --> Language Class Initialized
INFO - 2021-01-11 08:18:01 --> Config Class Initialized
INFO - 2021-01-11 08:18:01 --> Loader Class Initialized
INFO - 2021-01-11 08:18:01 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:01 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:01 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:01 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:01 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:01 --> Controller Class Initialized
INFO - 2021-01-11 08:18:01 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:01 --> Total execution time: 0.3465
INFO - 2021-01-11 08:18:06 --> Config Class Initialized
INFO - 2021-01-11 08:18:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:06 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:06 --> URI Class Initialized
INFO - 2021-01-11 08:18:06 --> Router Class Initialized
INFO - 2021-01-11 08:18:06 --> Output Class Initialized
INFO - 2021-01-11 08:18:06 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:06 --> Input Class Initialized
INFO - 2021-01-11 08:18:06 --> Language Class Initialized
INFO - 2021-01-11 08:18:06 --> Language Class Initialized
INFO - 2021-01-11 08:18:06 --> Config Class Initialized
INFO - 2021-01-11 08:18:06 --> Loader Class Initialized
INFO - 2021-01-11 08:18:06 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:06 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:06 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:06 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:06 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:06 --> Controller Class Initialized
INFO - 2021-01-11 08:18:06 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:06 --> Total execution time: 0.2436
INFO - 2021-01-11 08:18:11 --> Config Class Initialized
INFO - 2021-01-11 08:18:11 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:11 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:11 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:11 --> URI Class Initialized
INFO - 2021-01-11 08:18:11 --> Router Class Initialized
INFO - 2021-01-11 08:18:11 --> Output Class Initialized
INFO - 2021-01-11 08:18:11 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:11 --> Input Class Initialized
INFO - 2021-01-11 08:18:11 --> Language Class Initialized
INFO - 2021-01-11 08:18:11 --> Language Class Initialized
INFO - 2021-01-11 08:18:11 --> Config Class Initialized
INFO - 2021-01-11 08:18:11 --> Loader Class Initialized
INFO - 2021-01-11 08:18:12 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:12 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:12 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:12 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:12 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:12 --> Controller Class Initialized
INFO - 2021-01-11 08:18:12 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:12 --> Total execution time: 0.3498
INFO - 2021-01-11 08:18:14 --> Config Class Initialized
INFO - 2021-01-11 08:18:14 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:14 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:14 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:14 --> URI Class Initialized
INFO - 2021-01-11 08:18:14 --> Router Class Initialized
INFO - 2021-01-11 08:18:14 --> Output Class Initialized
INFO - 2021-01-11 08:18:14 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:14 --> Input Class Initialized
INFO - 2021-01-11 08:18:14 --> Language Class Initialized
INFO - 2021-01-11 08:18:14 --> Language Class Initialized
INFO - 2021-01-11 08:18:14 --> Config Class Initialized
INFO - 2021-01-11 08:18:14 --> Loader Class Initialized
INFO - 2021-01-11 08:18:14 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:14 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:14 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:14 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:14 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:15 --> Controller Class Initialized
INFO - 2021-01-11 08:18:15 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:15 --> Total execution time: 0.2609
INFO - 2021-01-11 08:18:19 --> Config Class Initialized
INFO - 2021-01-11 08:18:19 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:19 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:19 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:19 --> URI Class Initialized
INFO - 2021-01-11 08:18:19 --> Router Class Initialized
INFO - 2021-01-11 08:18:19 --> Output Class Initialized
INFO - 2021-01-11 08:18:19 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:19 --> Input Class Initialized
INFO - 2021-01-11 08:18:19 --> Language Class Initialized
INFO - 2021-01-11 08:18:19 --> Language Class Initialized
INFO - 2021-01-11 08:18:19 --> Config Class Initialized
INFO - 2021-01-11 08:18:19 --> Loader Class Initialized
INFO - 2021-01-11 08:18:19 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:19 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:19 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:19 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:19 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:19 --> Controller Class Initialized
INFO - 2021-01-11 08:18:19 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:19 --> Total execution time: 0.3419
INFO - 2021-01-11 08:18:23 --> Config Class Initialized
INFO - 2021-01-11 08:18:23 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:23 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:23 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:23 --> URI Class Initialized
INFO - 2021-01-11 08:18:23 --> Router Class Initialized
INFO - 2021-01-11 08:18:23 --> Output Class Initialized
INFO - 2021-01-11 08:18:23 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:23 --> Input Class Initialized
INFO - 2021-01-11 08:18:23 --> Language Class Initialized
INFO - 2021-01-11 08:18:23 --> Language Class Initialized
INFO - 2021-01-11 08:18:23 --> Config Class Initialized
INFO - 2021-01-11 08:18:23 --> Loader Class Initialized
INFO - 2021-01-11 08:18:23 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:23 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:23 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:23 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:23 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:23 --> Controller Class Initialized
INFO - 2021-01-11 08:18:23 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:23 --> Total execution time: 0.2575
INFO - 2021-01-11 08:18:34 --> Config Class Initialized
INFO - 2021-01-11 08:18:34 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:34 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:34 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:34 --> URI Class Initialized
INFO - 2021-01-11 08:18:34 --> Router Class Initialized
INFO - 2021-01-11 08:18:34 --> Output Class Initialized
INFO - 2021-01-11 08:18:34 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:34 --> Input Class Initialized
INFO - 2021-01-11 08:18:34 --> Language Class Initialized
INFO - 2021-01-11 08:18:34 --> Language Class Initialized
INFO - 2021-01-11 08:18:34 --> Config Class Initialized
INFO - 2021-01-11 08:18:34 --> Loader Class Initialized
INFO - 2021-01-11 08:18:34 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:34 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:34 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:34 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:34 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:34 --> Controller Class Initialized
INFO - 2021-01-11 08:18:34 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:34 --> Total execution time: 0.2660
INFO - 2021-01-11 08:18:39 --> Config Class Initialized
INFO - 2021-01-11 08:18:39 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:39 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:40 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:40 --> URI Class Initialized
INFO - 2021-01-11 08:18:40 --> Router Class Initialized
INFO - 2021-01-11 08:18:40 --> Output Class Initialized
INFO - 2021-01-11 08:18:40 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:40 --> Input Class Initialized
INFO - 2021-01-11 08:18:40 --> Language Class Initialized
INFO - 2021-01-11 08:18:40 --> Language Class Initialized
INFO - 2021-01-11 08:18:40 --> Config Class Initialized
INFO - 2021-01-11 08:18:40 --> Loader Class Initialized
INFO - 2021-01-11 08:18:40 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:40 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:40 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:40 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:40 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:40 --> Controller Class Initialized
INFO - 2021-01-11 08:18:40 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:40 --> Total execution time: 0.2607
INFO - 2021-01-11 08:18:45 --> Config Class Initialized
INFO - 2021-01-11 08:18:45 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:45 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:45 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:45 --> URI Class Initialized
INFO - 2021-01-11 08:18:45 --> Router Class Initialized
INFO - 2021-01-11 08:18:45 --> Output Class Initialized
INFO - 2021-01-11 08:18:45 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:45 --> Input Class Initialized
INFO - 2021-01-11 08:18:45 --> Language Class Initialized
INFO - 2021-01-11 08:18:45 --> Language Class Initialized
INFO - 2021-01-11 08:18:45 --> Config Class Initialized
INFO - 2021-01-11 08:18:45 --> Loader Class Initialized
INFO - 2021-01-11 08:18:45 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:45 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:45 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:45 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:45 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:45 --> Controller Class Initialized
DEBUG - 2021-01-11 08:18:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:18:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:18:45 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:45 --> Total execution time: 0.3225
INFO - 2021-01-11 08:18:51 --> Config Class Initialized
INFO - 2021-01-11 08:18:51 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:51 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:51 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:51 --> URI Class Initialized
INFO - 2021-01-11 08:18:51 --> Router Class Initialized
INFO - 2021-01-11 08:18:51 --> Output Class Initialized
INFO - 2021-01-11 08:18:51 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:51 --> Input Class Initialized
INFO - 2021-01-11 08:18:51 --> Language Class Initialized
INFO - 2021-01-11 08:18:51 --> Language Class Initialized
INFO - 2021-01-11 08:18:51 --> Config Class Initialized
INFO - 2021-01-11 08:18:51 --> Loader Class Initialized
INFO - 2021-01-11 08:18:51 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:51 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:51 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:51 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:51 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:51 --> Controller Class Initialized
DEBUG - 2021-01-11 08:18:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:18:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:18:51 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:51 --> Total execution time: 0.3448
INFO - 2021-01-11 08:18:51 --> Config Class Initialized
INFO - 2021-01-11 08:18:51 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:51 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:51 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:51 --> URI Class Initialized
INFO - 2021-01-11 08:18:51 --> Router Class Initialized
INFO - 2021-01-11 08:18:51 --> Output Class Initialized
INFO - 2021-01-11 08:18:51 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:51 --> Input Class Initialized
INFO - 2021-01-11 08:18:51 --> Language Class Initialized
INFO - 2021-01-11 08:18:51 --> Language Class Initialized
INFO - 2021-01-11 08:18:51 --> Config Class Initialized
INFO - 2021-01-11 08:18:51 --> Loader Class Initialized
INFO - 2021-01-11 08:18:51 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:51 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:51 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:51 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:51 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:51 --> Controller Class Initialized
INFO - 2021-01-11 08:18:53 --> Config Class Initialized
INFO - 2021-01-11 08:18:53 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:53 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:53 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:53 --> URI Class Initialized
INFO - 2021-01-11 08:18:53 --> Router Class Initialized
INFO - 2021-01-11 08:18:53 --> Output Class Initialized
INFO - 2021-01-11 08:18:53 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:53 --> Input Class Initialized
INFO - 2021-01-11 08:18:53 --> Language Class Initialized
INFO - 2021-01-11 08:18:53 --> Language Class Initialized
INFO - 2021-01-11 08:18:53 --> Config Class Initialized
INFO - 2021-01-11 08:18:54 --> Loader Class Initialized
INFO - 2021-01-11 08:18:54 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:54 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:54 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:54 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:54 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:18:54 --> Controller Class Initialized
INFO - 2021-01-11 08:18:54 --> Final output sent to browser
DEBUG - 2021-01-11 08:18:54 --> Total execution time: 0.2870
INFO - 2021-01-11 08:18:59 --> Config Class Initialized
INFO - 2021-01-11 08:18:59 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:18:59 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:18:59 --> Utf8 Class Initialized
INFO - 2021-01-11 08:18:59 --> URI Class Initialized
INFO - 2021-01-11 08:18:59 --> Router Class Initialized
INFO - 2021-01-11 08:18:59 --> Output Class Initialized
INFO - 2021-01-11 08:18:59 --> Security Class Initialized
DEBUG - 2021-01-11 08:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:18:59 --> Input Class Initialized
INFO - 2021-01-11 08:18:59 --> Language Class Initialized
INFO - 2021-01-11 08:18:59 --> Language Class Initialized
INFO - 2021-01-11 08:18:59 --> Config Class Initialized
INFO - 2021-01-11 08:18:59 --> Loader Class Initialized
INFO - 2021-01-11 08:18:59 --> Helper loaded: url_helper
INFO - 2021-01-11 08:18:59 --> Helper loaded: file_helper
INFO - 2021-01-11 08:18:59 --> Helper loaded: form_helper
INFO - 2021-01-11 08:18:59 --> Helper loaded: my_helper
INFO - 2021-01-11 08:18:59 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:00 --> Controller Class Initialized
DEBUG - 2021-01-11 08:19:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:19:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:19:00 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:00 --> Total execution time: 0.3621
INFO - 2021-01-11 08:19:07 --> Config Class Initialized
INFO - 2021-01-11 08:19:07 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:07 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:07 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:07 --> URI Class Initialized
INFO - 2021-01-11 08:19:07 --> Router Class Initialized
INFO - 2021-01-11 08:19:07 --> Output Class Initialized
INFO - 2021-01-11 08:19:07 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:07 --> Input Class Initialized
INFO - 2021-01-11 08:19:07 --> Language Class Initialized
INFO - 2021-01-11 08:19:07 --> Language Class Initialized
INFO - 2021-01-11 08:19:07 --> Config Class Initialized
INFO - 2021-01-11 08:19:07 --> Loader Class Initialized
INFO - 2021-01-11 08:19:07 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:07 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:07 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:07 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:07 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:07 --> Controller Class Initialized
DEBUG - 2021-01-11 08:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:19:07 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:07 --> Total execution time: 0.3356
INFO - 2021-01-11 08:19:08 --> Config Class Initialized
INFO - 2021-01-11 08:19:08 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:08 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:08 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:08 --> URI Class Initialized
INFO - 2021-01-11 08:19:08 --> Router Class Initialized
INFO - 2021-01-11 08:19:08 --> Output Class Initialized
INFO - 2021-01-11 08:19:08 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:08 --> Input Class Initialized
INFO - 2021-01-11 08:19:08 --> Language Class Initialized
INFO - 2021-01-11 08:19:08 --> Language Class Initialized
INFO - 2021-01-11 08:19:08 --> Config Class Initialized
INFO - 2021-01-11 08:19:08 --> Loader Class Initialized
INFO - 2021-01-11 08:19:08 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:08 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:08 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:08 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:08 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:08 --> Controller Class Initialized
INFO - 2021-01-11 08:19:09 --> Config Class Initialized
INFO - 2021-01-11 08:19:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:10 --> URI Class Initialized
INFO - 2021-01-11 08:19:10 --> Router Class Initialized
INFO - 2021-01-11 08:19:10 --> Output Class Initialized
INFO - 2021-01-11 08:19:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:10 --> Input Class Initialized
INFO - 2021-01-11 08:19:10 --> Language Class Initialized
INFO - 2021-01-11 08:19:10 --> Language Class Initialized
INFO - 2021-01-11 08:19:10 --> Config Class Initialized
INFO - 2021-01-11 08:19:10 --> Loader Class Initialized
INFO - 2021-01-11 08:19:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:10 --> Controller Class Initialized
INFO - 2021-01-11 08:19:10 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:10 --> Total execution time: 0.2831
INFO - 2021-01-11 08:19:17 --> Config Class Initialized
INFO - 2021-01-11 08:19:17 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:17 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:17 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:17 --> URI Class Initialized
INFO - 2021-01-11 08:19:17 --> Router Class Initialized
INFO - 2021-01-11 08:19:17 --> Output Class Initialized
INFO - 2021-01-11 08:19:17 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:17 --> Input Class Initialized
INFO - 2021-01-11 08:19:17 --> Language Class Initialized
INFO - 2021-01-11 08:19:17 --> Language Class Initialized
INFO - 2021-01-11 08:19:17 --> Config Class Initialized
INFO - 2021-01-11 08:19:17 --> Loader Class Initialized
INFO - 2021-01-11 08:19:18 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:18 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:18 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:18 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:18 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:18 --> Controller Class Initialized
DEBUG - 2021-01-11 08:19:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:19:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:19:18 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:18 --> Total execution time: 0.3522
INFO - 2021-01-11 08:19:22 --> Config Class Initialized
INFO - 2021-01-11 08:19:22 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:22 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:22 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:22 --> URI Class Initialized
INFO - 2021-01-11 08:19:22 --> Router Class Initialized
INFO - 2021-01-11 08:19:22 --> Output Class Initialized
INFO - 2021-01-11 08:19:22 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:22 --> Input Class Initialized
INFO - 2021-01-11 08:19:22 --> Language Class Initialized
INFO - 2021-01-11 08:19:22 --> Language Class Initialized
INFO - 2021-01-11 08:19:22 --> Config Class Initialized
INFO - 2021-01-11 08:19:22 --> Loader Class Initialized
INFO - 2021-01-11 08:19:22 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:22 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:22 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:22 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:22 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:22 --> Controller Class Initialized
DEBUG - 2021-01-11 08:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:19:22 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:22 --> Total execution time: 0.3058
INFO - 2021-01-11 08:19:25 --> Config Class Initialized
INFO - 2021-01-11 08:19:25 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:25 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:25 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:25 --> URI Class Initialized
INFO - 2021-01-11 08:19:25 --> Router Class Initialized
INFO - 2021-01-11 08:19:25 --> Output Class Initialized
INFO - 2021-01-11 08:19:26 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:26 --> Input Class Initialized
INFO - 2021-01-11 08:19:26 --> Language Class Initialized
INFO - 2021-01-11 08:19:26 --> Language Class Initialized
INFO - 2021-01-11 08:19:26 --> Config Class Initialized
INFO - 2021-01-11 08:19:26 --> Loader Class Initialized
INFO - 2021-01-11 08:19:26 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:26 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:26 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:26 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:26 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:26 --> Controller Class Initialized
DEBUG - 2021-01-11 08:19:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:19:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:19:26 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:26 --> Total execution time: 0.3590
INFO - 2021-01-11 08:19:32 --> Config Class Initialized
INFO - 2021-01-11 08:19:32 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:32 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:32 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:32 --> URI Class Initialized
INFO - 2021-01-11 08:19:32 --> Router Class Initialized
INFO - 2021-01-11 08:19:32 --> Output Class Initialized
INFO - 2021-01-11 08:19:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:32 --> Input Class Initialized
INFO - 2021-01-11 08:19:32 --> Language Class Initialized
INFO - 2021-01-11 08:19:32 --> Language Class Initialized
INFO - 2021-01-11 08:19:32 --> Config Class Initialized
INFO - 2021-01-11 08:19:32 --> Loader Class Initialized
INFO - 2021-01-11 08:19:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:32 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:32 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:32 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:32 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:32 --> Controller Class Initialized
DEBUG - 2021-01-11 08:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:19:32 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:32 --> Total execution time: 0.3147
INFO - 2021-01-11 08:19:32 --> Config Class Initialized
INFO - 2021-01-11 08:19:32 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:32 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:32 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:32 --> URI Class Initialized
INFO - 2021-01-11 08:19:32 --> Router Class Initialized
INFO - 2021-01-11 08:19:32 --> Output Class Initialized
INFO - 2021-01-11 08:19:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:32 --> Input Class Initialized
INFO - 2021-01-11 08:19:32 --> Language Class Initialized
INFO - 2021-01-11 08:19:32 --> Language Class Initialized
INFO - 2021-01-11 08:19:32 --> Config Class Initialized
INFO - 2021-01-11 08:19:32 --> Loader Class Initialized
INFO - 2021-01-11 08:19:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:32 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:32 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:32 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:32 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:32 --> Controller Class Initialized
INFO - 2021-01-11 08:19:35 --> Config Class Initialized
INFO - 2021-01-11 08:19:35 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:35 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:35 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:35 --> URI Class Initialized
INFO - 2021-01-11 08:19:35 --> Router Class Initialized
INFO - 2021-01-11 08:19:35 --> Output Class Initialized
INFO - 2021-01-11 08:19:35 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:35 --> Input Class Initialized
INFO - 2021-01-11 08:19:35 --> Language Class Initialized
INFO - 2021-01-11 08:19:35 --> Language Class Initialized
INFO - 2021-01-11 08:19:35 --> Config Class Initialized
INFO - 2021-01-11 08:19:35 --> Loader Class Initialized
INFO - 2021-01-11 08:19:35 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:35 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:35 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:35 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:35 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:35 --> Controller Class Initialized
INFO - 2021-01-11 08:19:35 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:35 --> Total execution time: 0.3279
INFO - 2021-01-11 08:19:44 --> Config Class Initialized
INFO - 2021-01-11 08:19:44 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:44 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:44 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:44 --> URI Class Initialized
INFO - 2021-01-11 08:19:44 --> Router Class Initialized
INFO - 2021-01-11 08:19:44 --> Output Class Initialized
INFO - 2021-01-11 08:19:44 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:44 --> Input Class Initialized
INFO - 2021-01-11 08:19:44 --> Language Class Initialized
INFO - 2021-01-11 08:19:44 --> Language Class Initialized
INFO - 2021-01-11 08:19:44 --> Config Class Initialized
INFO - 2021-01-11 08:19:44 --> Loader Class Initialized
INFO - 2021-01-11 08:19:44 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:44 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:44 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:44 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:45 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:45 --> Controller Class Initialized
INFO - 2021-01-11 08:19:45 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:45 --> Total execution time: 0.3061
INFO - 2021-01-11 08:19:45 --> Config Class Initialized
INFO - 2021-01-11 08:19:45 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:45 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:45 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:45 --> URI Class Initialized
INFO - 2021-01-11 08:19:45 --> Router Class Initialized
INFO - 2021-01-11 08:19:45 --> Output Class Initialized
INFO - 2021-01-11 08:19:45 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:45 --> Input Class Initialized
INFO - 2021-01-11 08:19:45 --> Language Class Initialized
INFO - 2021-01-11 08:19:45 --> Language Class Initialized
INFO - 2021-01-11 08:19:45 --> Config Class Initialized
INFO - 2021-01-11 08:19:45 --> Loader Class Initialized
INFO - 2021-01-11 08:19:45 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:45 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:45 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:45 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:45 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:45 --> Controller Class Initialized
INFO - 2021-01-11 08:19:46 --> Config Class Initialized
INFO - 2021-01-11 08:19:46 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:19:46 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:19:46 --> Utf8 Class Initialized
INFO - 2021-01-11 08:19:46 --> URI Class Initialized
INFO - 2021-01-11 08:19:46 --> Router Class Initialized
INFO - 2021-01-11 08:19:46 --> Output Class Initialized
INFO - 2021-01-11 08:19:46 --> Security Class Initialized
DEBUG - 2021-01-11 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:19:46 --> Input Class Initialized
INFO - 2021-01-11 08:19:46 --> Language Class Initialized
INFO - 2021-01-11 08:19:46 --> Language Class Initialized
INFO - 2021-01-11 08:19:46 --> Config Class Initialized
INFO - 2021-01-11 08:19:46 --> Loader Class Initialized
INFO - 2021-01-11 08:19:46 --> Helper loaded: url_helper
INFO - 2021-01-11 08:19:46 --> Helper loaded: file_helper
INFO - 2021-01-11 08:19:46 --> Helper loaded: form_helper
INFO - 2021-01-11 08:19:46 --> Helper loaded: my_helper
INFO - 2021-01-11 08:19:46 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:19:46 --> Controller Class Initialized
INFO - 2021-01-11 08:19:46 --> Final output sent to browser
DEBUG - 2021-01-11 08:19:46 --> Total execution time: 0.3074
INFO - 2021-01-11 08:20:00 --> Config Class Initialized
INFO - 2021-01-11 08:20:00 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:00 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:00 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:00 --> URI Class Initialized
INFO - 2021-01-11 08:20:00 --> Router Class Initialized
INFO - 2021-01-11 08:20:00 --> Output Class Initialized
INFO - 2021-01-11 08:20:00 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:00 --> Input Class Initialized
INFO - 2021-01-11 08:20:00 --> Language Class Initialized
INFO - 2021-01-11 08:20:00 --> Language Class Initialized
INFO - 2021-01-11 08:20:00 --> Config Class Initialized
INFO - 2021-01-11 08:20:00 --> Loader Class Initialized
INFO - 2021-01-11 08:20:00 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:00 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:00 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:00 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:00 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:00 --> Controller Class Initialized
INFO - 2021-01-11 08:20:00 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:00 --> Total execution time: 0.3273
INFO - 2021-01-11 08:20:00 --> Config Class Initialized
INFO - 2021-01-11 08:20:00 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:00 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:00 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:00 --> URI Class Initialized
INFO - 2021-01-11 08:20:00 --> Router Class Initialized
INFO - 2021-01-11 08:20:00 --> Output Class Initialized
INFO - 2021-01-11 08:20:00 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:00 --> Input Class Initialized
INFO - 2021-01-11 08:20:00 --> Language Class Initialized
INFO - 2021-01-11 08:20:00 --> Language Class Initialized
INFO - 2021-01-11 08:20:00 --> Config Class Initialized
INFO - 2021-01-11 08:20:00 --> Loader Class Initialized
INFO - 2021-01-11 08:20:00 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:00 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:00 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:00 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:00 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:01 --> Controller Class Initialized
INFO - 2021-01-11 08:20:04 --> Config Class Initialized
INFO - 2021-01-11 08:20:04 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:04 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:04 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:04 --> URI Class Initialized
INFO - 2021-01-11 08:20:04 --> Router Class Initialized
INFO - 2021-01-11 08:20:04 --> Output Class Initialized
INFO - 2021-01-11 08:20:04 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:04 --> Input Class Initialized
INFO - 2021-01-11 08:20:04 --> Language Class Initialized
INFO - 2021-01-11 08:20:04 --> Language Class Initialized
INFO - 2021-01-11 08:20:04 --> Config Class Initialized
INFO - 2021-01-11 08:20:04 --> Loader Class Initialized
INFO - 2021-01-11 08:20:04 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:04 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:04 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:04 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:04 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:04 --> Controller Class Initialized
INFO - 2021-01-11 08:20:04 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:04 --> Total execution time: 0.2693
INFO - 2021-01-11 08:20:10 --> Config Class Initialized
INFO - 2021-01-11 08:20:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:10 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:10 --> URI Class Initialized
INFO - 2021-01-11 08:20:10 --> Router Class Initialized
INFO - 2021-01-11 08:20:10 --> Output Class Initialized
INFO - 2021-01-11 08:20:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:10 --> Input Class Initialized
INFO - 2021-01-11 08:20:10 --> Language Class Initialized
INFO - 2021-01-11 08:20:10 --> Language Class Initialized
INFO - 2021-01-11 08:20:10 --> Config Class Initialized
INFO - 2021-01-11 08:20:11 --> Loader Class Initialized
INFO - 2021-01-11 08:20:11 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:11 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:11 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:11 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:11 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:11 --> Controller Class Initialized
INFO - 2021-01-11 08:20:11 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:11 --> Total execution time: 0.3848
INFO - 2021-01-11 08:20:15 --> Config Class Initialized
INFO - 2021-01-11 08:20:15 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:15 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:15 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:15 --> URI Class Initialized
INFO - 2021-01-11 08:20:15 --> Router Class Initialized
INFO - 2021-01-11 08:20:15 --> Output Class Initialized
INFO - 2021-01-11 08:20:15 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:15 --> Input Class Initialized
INFO - 2021-01-11 08:20:15 --> Language Class Initialized
INFO - 2021-01-11 08:20:15 --> Language Class Initialized
INFO - 2021-01-11 08:20:15 --> Config Class Initialized
INFO - 2021-01-11 08:20:15 --> Loader Class Initialized
INFO - 2021-01-11 08:20:15 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:15 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:15 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:15 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:15 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:15 --> Controller Class Initialized
INFO - 2021-01-11 08:20:15 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:15 --> Total execution time: 0.2610
INFO - 2021-01-11 08:20:20 --> Config Class Initialized
INFO - 2021-01-11 08:20:20 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:20 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:20 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:20 --> URI Class Initialized
INFO - 2021-01-11 08:20:20 --> Router Class Initialized
INFO - 2021-01-11 08:20:20 --> Output Class Initialized
INFO - 2021-01-11 08:20:20 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:20 --> Input Class Initialized
INFO - 2021-01-11 08:20:20 --> Language Class Initialized
INFO - 2021-01-11 08:20:20 --> Language Class Initialized
INFO - 2021-01-11 08:20:20 --> Config Class Initialized
INFO - 2021-01-11 08:20:20 --> Loader Class Initialized
INFO - 2021-01-11 08:20:20 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:20 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:20 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:20 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:20 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:20 --> Controller Class Initialized
INFO - 2021-01-11 08:20:21 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:21 --> Total execution time: 0.3180
INFO - 2021-01-11 08:20:23 --> Config Class Initialized
INFO - 2021-01-11 08:20:23 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:23 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:23 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:23 --> URI Class Initialized
INFO - 2021-01-11 08:20:23 --> Router Class Initialized
INFO - 2021-01-11 08:20:23 --> Output Class Initialized
INFO - 2021-01-11 08:20:23 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:23 --> Input Class Initialized
INFO - 2021-01-11 08:20:23 --> Language Class Initialized
INFO - 2021-01-11 08:20:23 --> Language Class Initialized
INFO - 2021-01-11 08:20:23 --> Config Class Initialized
INFO - 2021-01-11 08:20:23 --> Loader Class Initialized
INFO - 2021-01-11 08:20:23 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:23 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:23 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:23 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:23 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:23 --> Controller Class Initialized
INFO - 2021-01-11 08:20:23 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:23 --> Total execution time: 0.2739
INFO - 2021-01-11 08:20:31 --> Config Class Initialized
INFO - 2021-01-11 08:20:31 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:31 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:31 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:31 --> URI Class Initialized
INFO - 2021-01-11 08:20:32 --> Router Class Initialized
INFO - 2021-01-11 08:20:32 --> Output Class Initialized
INFO - 2021-01-11 08:20:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:32 --> Input Class Initialized
INFO - 2021-01-11 08:20:32 --> Language Class Initialized
INFO - 2021-01-11 08:20:32 --> Language Class Initialized
INFO - 2021-01-11 08:20:32 --> Config Class Initialized
INFO - 2021-01-11 08:20:32 --> Loader Class Initialized
INFO - 2021-01-11 08:20:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:32 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:32 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:32 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:32 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:32 --> Controller Class Initialized
INFO - 2021-01-11 08:20:32 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:32 --> Total execution time: 0.3825
INFO - 2021-01-11 08:20:35 --> Config Class Initialized
INFO - 2021-01-11 08:20:35 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:35 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:35 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:35 --> URI Class Initialized
INFO - 2021-01-11 08:20:35 --> Router Class Initialized
INFO - 2021-01-11 08:20:35 --> Output Class Initialized
INFO - 2021-01-11 08:20:35 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:35 --> Input Class Initialized
INFO - 2021-01-11 08:20:35 --> Language Class Initialized
INFO - 2021-01-11 08:20:35 --> Language Class Initialized
INFO - 2021-01-11 08:20:35 --> Config Class Initialized
INFO - 2021-01-11 08:20:35 --> Loader Class Initialized
INFO - 2021-01-11 08:20:35 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:35 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:35 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:35 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:35 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:35 --> Controller Class Initialized
INFO - 2021-01-11 08:20:35 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:35 --> Total execution time: 0.3061
INFO - 2021-01-11 08:20:41 --> Config Class Initialized
INFO - 2021-01-11 08:20:41 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:41 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:41 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:41 --> URI Class Initialized
INFO - 2021-01-11 08:20:41 --> Router Class Initialized
INFO - 2021-01-11 08:20:41 --> Output Class Initialized
INFO - 2021-01-11 08:20:41 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:41 --> Input Class Initialized
INFO - 2021-01-11 08:20:41 --> Language Class Initialized
INFO - 2021-01-11 08:20:41 --> Language Class Initialized
INFO - 2021-01-11 08:20:41 --> Config Class Initialized
INFO - 2021-01-11 08:20:41 --> Loader Class Initialized
INFO - 2021-01-11 08:20:41 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:41 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:41 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:41 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:41 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:41 --> Controller Class Initialized
INFO - 2021-01-11 08:20:41 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:41 --> Total execution time: 0.3501
INFO - 2021-01-11 08:20:48 --> Config Class Initialized
INFO - 2021-01-11 08:20:48 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:48 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:48 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:48 --> URI Class Initialized
INFO - 2021-01-11 08:20:48 --> Router Class Initialized
INFO - 2021-01-11 08:20:48 --> Output Class Initialized
INFO - 2021-01-11 08:20:48 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:48 --> Input Class Initialized
INFO - 2021-01-11 08:20:48 --> Language Class Initialized
INFO - 2021-01-11 08:20:48 --> Language Class Initialized
INFO - 2021-01-11 08:20:48 --> Config Class Initialized
INFO - 2021-01-11 08:20:48 --> Loader Class Initialized
INFO - 2021-01-11 08:20:48 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:48 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:48 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:48 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:48 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:48 --> Controller Class Initialized
DEBUG - 2021-01-11 08:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:20:48 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:48 --> Total execution time: 0.4800
INFO - 2021-01-11 08:20:52 --> Config Class Initialized
INFO - 2021-01-11 08:20:52 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:52 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:53 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:53 --> URI Class Initialized
INFO - 2021-01-11 08:20:53 --> Router Class Initialized
INFO - 2021-01-11 08:20:53 --> Output Class Initialized
INFO - 2021-01-11 08:20:53 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:53 --> Input Class Initialized
INFO - 2021-01-11 08:20:53 --> Language Class Initialized
INFO - 2021-01-11 08:20:53 --> Language Class Initialized
INFO - 2021-01-11 08:20:53 --> Config Class Initialized
INFO - 2021-01-11 08:20:53 --> Loader Class Initialized
INFO - 2021-01-11 08:20:53 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:53 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:53 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:53 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:53 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:53 --> Controller Class Initialized
DEBUG - 2021-01-11 08:20:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:20:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:20:53 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:53 --> Total execution time: 0.3188
INFO - 2021-01-11 08:20:55 --> Config Class Initialized
INFO - 2021-01-11 08:20:55 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:20:55 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:20:55 --> Utf8 Class Initialized
INFO - 2021-01-11 08:20:55 --> URI Class Initialized
INFO - 2021-01-11 08:20:55 --> Router Class Initialized
INFO - 2021-01-11 08:20:55 --> Output Class Initialized
INFO - 2021-01-11 08:20:55 --> Security Class Initialized
DEBUG - 2021-01-11 08:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:20:55 --> Input Class Initialized
INFO - 2021-01-11 08:20:55 --> Language Class Initialized
INFO - 2021-01-11 08:20:55 --> Language Class Initialized
INFO - 2021-01-11 08:20:55 --> Config Class Initialized
INFO - 2021-01-11 08:20:55 --> Loader Class Initialized
INFO - 2021-01-11 08:20:55 --> Helper loaded: url_helper
INFO - 2021-01-11 08:20:55 --> Helper loaded: file_helper
INFO - 2021-01-11 08:20:55 --> Helper loaded: form_helper
INFO - 2021-01-11 08:20:55 --> Helper loaded: my_helper
INFO - 2021-01-11 08:20:55 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:20:55 --> Controller Class Initialized
INFO - 2021-01-11 08:20:55 --> Final output sent to browser
DEBUG - 2021-01-11 08:20:55 --> Total execution time: 0.3150
INFO - 2021-01-11 08:21:09 --> Config Class Initialized
INFO - 2021-01-11 08:21:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:09 --> URI Class Initialized
INFO - 2021-01-11 08:21:09 --> Router Class Initialized
INFO - 2021-01-11 08:21:09 --> Output Class Initialized
INFO - 2021-01-11 08:21:09 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:09 --> Input Class Initialized
INFO - 2021-01-11 08:21:09 --> Language Class Initialized
INFO - 2021-01-11 08:21:09 --> Language Class Initialized
INFO - 2021-01-11 08:21:09 --> Config Class Initialized
INFO - 2021-01-11 08:21:09 --> Loader Class Initialized
INFO - 2021-01-11 08:21:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:09 --> Controller Class Initialized
INFO - 2021-01-11 08:21:09 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:09 --> Total execution time: 0.3147
INFO - 2021-01-11 08:21:09 --> Config Class Initialized
INFO - 2021-01-11 08:21:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:09 --> URI Class Initialized
INFO - 2021-01-11 08:21:10 --> Router Class Initialized
INFO - 2021-01-11 08:21:10 --> Output Class Initialized
INFO - 2021-01-11 08:21:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:10 --> Input Class Initialized
INFO - 2021-01-11 08:21:10 --> Language Class Initialized
INFO - 2021-01-11 08:21:10 --> Language Class Initialized
INFO - 2021-01-11 08:21:10 --> Config Class Initialized
INFO - 2021-01-11 08:21:10 --> Loader Class Initialized
INFO - 2021-01-11 08:21:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:10 --> Controller Class Initialized
DEBUG - 2021-01-11 08:21:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:21:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:21:10 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:10 --> Total execution time: 0.5254
INFO - 2021-01-11 08:21:11 --> Config Class Initialized
INFO - 2021-01-11 08:21:11 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:11 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:11 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:11 --> URI Class Initialized
INFO - 2021-01-11 08:21:11 --> Router Class Initialized
INFO - 2021-01-11 08:21:11 --> Output Class Initialized
INFO - 2021-01-11 08:21:11 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:11 --> Input Class Initialized
INFO - 2021-01-11 08:21:11 --> Language Class Initialized
INFO - 2021-01-11 08:21:11 --> Language Class Initialized
INFO - 2021-01-11 08:21:11 --> Config Class Initialized
INFO - 2021-01-11 08:21:11 --> Loader Class Initialized
INFO - 2021-01-11 08:21:11 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:11 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:11 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:11 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:11 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:11 --> Controller Class Initialized
INFO - 2021-01-11 08:21:11 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:11 --> Total execution time: 0.3010
INFO - 2021-01-11 08:21:20 --> Config Class Initialized
INFO - 2021-01-11 08:21:20 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:20 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:20 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:20 --> URI Class Initialized
INFO - 2021-01-11 08:21:20 --> Router Class Initialized
INFO - 2021-01-11 08:21:20 --> Output Class Initialized
INFO - 2021-01-11 08:21:20 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:20 --> Input Class Initialized
INFO - 2021-01-11 08:21:20 --> Language Class Initialized
INFO - 2021-01-11 08:21:20 --> Language Class Initialized
INFO - 2021-01-11 08:21:20 --> Config Class Initialized
INFO - 2021-01-11 08:21:20 --> Loader Class Initialized
INFO - 2021-01-11 08:21:20 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:20 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:20 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:20 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:20 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:20 --> Controller Class Initialized
INFO - 2021-01-11 08:21:20 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:20 --> Total execution time: 0.3025
INFO - 2021-01-11 08:21:21 --> Config Class Initialized
INFO - 2021-01-11 08:21:21 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:21 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:21 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:21 --> URI Class Initialized
INFO - 2021-01-11 08:21:21 --> Router Class Initialized
INFO - 2021-01-11 08:21:21 --> Output Class Initialized
INFO - 2021-01-11 08:21:21 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:21 --> Input Class Initialized
INFO - 2021-01-11 08:21:21 --> Language Class Initialized
INFO - 2021-01-11 08:21:21 --> Language Class Initialized
INFO - 2021-01-11 08:21:21 --> Config Class Initialized
INFO - 2021-01-11 08:21:21 --> Loader Class Initialized
INFO - 2021-01-11 08:21:21 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:21 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:21 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:21 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:21 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:21 --> Controller Class Initialized
DEBUG - 2021-01-11 08:21:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:21:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:21:21 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:21 --> Total execution time: 0.4734
INFO - 2021-01-11 08:21:22 --> Config Class Initialized
INFO - 2021-01-11 08:21:22 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:22 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:22 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:22 --> URI Class Initialized
INFO - 2021-01-11 08:21:22 --> Router Class Initialized
INFO - 2021-01-11 08:21:22 --> Output Class Initialized
INFO - 2021-01-11 08:21:22 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:22 --> Input Class Initialized
INFO - 2021-01-11 08:21:22 --> Language Class Initialized
INFO - 2021-01-11 08:21:22 --> Language Class Initialized
INFO - 2021-01-11 08:21:22 --> Config Class Initialized
INFO - 2021-01-11 08:21:22 --> Loader Class Initialized
INFO - 2021-01-11 08:21:22 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:22 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:22 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:22 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:22 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:22 --> Controller Class Initialized
INFO - 2021-01-11 08:21:22 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:23 --> Total execution time: 0.2552
INFO - 2021-01-11 08:21:29 --> Config Class Initialized
INFO - 2021-01-11 08:21:29 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:29 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:29 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:29 --> URI Class Initialized
INFO - 2021-01-11 08:21:29 --> Router Class Initialized
INFO - 2021-01-11 08:21:29 --> Output Class Initialized
INFO - 2021-01-11 08:21:29 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:29 --> Input Class Initialized
INFO - 2021-01-11 08:21:29 --> Language Class Initialized
INFO - 2021-01-11 08:21:29 --> Language Class Initialized
INFO - 2021-01-11 08:21:29 --> Config Class Initialized
INFO - 2021-01-11 08:21:29 --> Loader Class Initialized
INFO - 2021-01-11 08:21:29 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:29 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:29 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:29 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:29 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:29 --> Controller Class Initialized
INFO - 2021-01-11 08:21:29 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:29 --> Total execution time: 0.4006
INFO - 2021-01-11 08:21:32 --> Config Class Initialized
INFO - 2021-01-11 08:21:32 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:32 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:32 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:32 --> URI Class Initialized
INFO - 2021-01-11 08:21:32 --> Router Class Initialized
INFO - 2021-01-11 08:21:32 --> Output Class Initialized
INFO - 2021-01-11 08:21:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:32 --> Input Class Initialized
INFO - 2021-01-11 08:21:32 --> Language Class Initialized
INFO - 2021-01-11 08:21:32 --> Language Class Initialized
INFO - 2021-01-11 08:21:32 --> Config Class Initialized
INFO - 2021-01-11 08:21:32 --> Loader Class Initialized
INFO - 2021-01-11 08:21:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:32 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:32 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:32 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:32 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:32 --> Controller Class Initialized
INFO - 2021-01-11 08:21:32 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:32 --> Total execution time: 0.2983
INFO - 2021-01-11 08:21:39 --> Config Class Initialized
INFO - 2021-01-11 08:21:39 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:39 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:39 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:39 --> URI Class Initialized
INFO - 2021-01-11 08:21:39 --> Router Class Initialized
INFO - 2021-01-11 08:21:39 --> Output Class Initialized
INFO - 2021-01-11 08:21:39 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:39 --> Input Class Initialized
INFO - 2021-01-11 08:21:39 --> Language Class Initialized
INFO - 2021-01-11 08:21:39 --> Language Class Initialized
INFO - 2021-01-11 08:21:39 --> Config Class Initialized
INFO - 2021-01-11 08:21:39 --> Loader Class Initialized
INFO - 2021-01-11 08:21:39 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:39 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:39 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:39 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:39 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:39 --> Controller Class Initialized
INFO - 2021-01-11 08:21:39 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:39 --> Total execution time: 0.3473
INFO - 2021-01-11 08:21:50 --> Config Class Initialized
INFO - 2021-01-11 08:21:50 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:50 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:50 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:50 --> URI Class Initialized
INFO - 2021-01-11 08:21:50 --> Router Class Initialized
INFO - 2021-01-11 08:21:50 --> Output Class Initialized
INFO - 2021-01-11 08:21:50 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:50 --> Input Class Initialized
INFO - 2021-01-11 08:21:50 --> Language Class Initialized
INFO - 2021-01-11 08:21:50 --> Language Class Initialized
INFO - 2021-01-11 08:21:50 --> Config Class Initialized
INFO - 2021-01-11 08:21:50 --> Loader Class Initialized
INFO - 2021-01-11 08:21:50 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:50 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:50 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:50 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:50 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:50 --> Controller Class Initialized
DEBUG - 2021-01-11 08:21:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:21:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:21:50 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:50 --> Total execution time: 0.3619
INFO - 2021-01-11 08:21:54 --> Config Class Initialized
INFO - 2021-01-11 08:21:54 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:54 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:54 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:54 --> URI Class Initialized
INFO - 2021-01-11 08:21:54 --> Router Class Initialized
INFO - 2021-01-11 08:21:54 --> Output Class Initialized
INFO - 2021-01-11 08:21:54 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:54 --> Input Class Initialized
INFO - 2021-01-11 08:21:54 --> Language Class Initialized
INFO - 2021-01-11 08:21:54 --> Language Class Initialized
INFO - 2021-01-11 08:21:54 --> Config Class Initialized
INFO - 2021-01-11 08:21:54 --> Loader Class Initialized
INFO - 2021-01-11 08:21:54 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:54 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:54 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:54 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:54 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:54 --> Controller Class Initialized
DEBUG - 2021-01-11 08:21:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:21:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:21:54 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:54 --> Total execution time: 0.3161
INFO - 2021-01-11 08:21:54 --> Config Class Initialized
INFO - 2021-01-11 08:21:54 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:54 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:54 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:54 --> URI Class Initialized
INFO - 2021-01-11 08:21:54 --> Router Class Initialized
INFO - 2021-01-11 08:21:54 --> Output Class Initialized
INFO - 2021-01-11 08:21:54 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:54 --> Input Class Initialized
INFO - 2021-01-11 08:21:54 --> Language Class Initialized
INFO - 2021-01-11 08:21:55 --> Language Class Initialized
INFO - 2021-01-11 08:21:55 --> Config Class Initialized
INFO - 2021-01-11 08:21:55 --> Loader Class Initialized
INFO - 2021-01-11 08:21:55 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:55 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:55 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:55 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:55 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:55 --> Controller Class Initialized
INFO - 2021-01-11 08:21:56 --> Config Class Initialized
INFO - 2021-01-11 08:21:56 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:56 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:56 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:56 --> URI Class Initialized
INFO - 2021-01-11 08:21:56 --> Router Class Initialized
INFO - 2021-01-11 08:21:57 --> Output Class Initialized
INFO - 2021-01-11 08:21:57 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:57 --> Input Class Initialized
INFO - 2021-01-11 08:21:57 --> Language Class Initialized
INFO - 2021-01-11 08:21:57 --> Language Class Initialized
INFO - 2021-01-11 08:21:57 --> Config Class Initialized
INFO - 2021-01-11 08:21:57 --> Loader Class Initialized
INFO - 2021-01-11 08:21:57 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:57 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:57 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:57 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:57 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:57 --> Controller Class Initialized
INFO - 2021-01-11 08:21:57 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:57 --> Total execution time: 0.2782
INFO - 2021-01-11 08:21:58 --> Config Class Initialized
INFO - 2021-01-11 08:21:58 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:21:58 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:21:58 --> Utf8 Class Initialized
INFO - 2021-01-11 08:21:58 --> URI Class Initialized
INFO - 2021-01-11 08:21:58 --> Router Class Initialized
INFO - 2021-01-11 08:21:58 --> Output Class Initialized
INFO - 2021-01-11 08:21:58 --> Security Class Initialized
DEBUG - 2021-01-11 08:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:21:58 --> Input Class Initialized
INFO - 2021-01-11 08:21:58 --> Language Class Initialized
INFO - 2021-01-11 08:21:58 --> Language Class Initialized
INFO - 2021-01-11 08:21:58 --> Config Class Initialized
INFO - 2021-01-11 08:21:58 --> Loader Class Initialized
INFO - 2021-01-11 08:21:58 --> Helper loaded: url_helper
INFO - 2021-01-11 08:21:58 --> Helper loaded: file_helper
INFO - 2021-01-11 08:21:58 --> Helper loaded: form_helper
INFO - 2021-01-11 08:21:59 --> Helper loaded: my_helper
INFO - 2021-01-11 08:21:59 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:21:59 --> Controller Class Initialized
DEBUG - 2021-01-11 08:21:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:21:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:21:59 --> Final output sent to browser
DEBUG - 2021-01-11 08:21:59 --> Total execution time: 0.3592
INFO - 2021-01-11 08:22:02 --> Config Class Initialized
INFO - 2021-01-11 08:22:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:02 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:02 --> URI Class Initialized
INFO - 2021-01-11 08:22:02 --> Router Class Initialized
INFO - 2021-01-11 08:22:02 --> Output Class Initialized
INFO - 2021-01-11 08:22:02 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:02 --> Input Class Initialized
INFO - 2021-01-11 08:22:02 --> Language Class Initialized
INFO - 2021-01-11 08:22:02 --> Language Class Initialized
INFO - 2021-01-11 08:22:02 --> Config Class Initialized
INFO - 2021-01-11 08:22:02 --> Loader Class Initialized
INFO - 2021-01-11 08:22:02 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:02 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:02 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:02 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:02 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:02 --> Controller Class Initialized
DEBUG - 2021-01-11 08:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:22:02 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:02 --> Total execution time: 0.3309
INFO - 2021-01-11 08:22:02 --> Config Class Initialized
INFO - 2021-01-11 08:22:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:02 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:02 --> URI Class Initialized
INFO - 2021-01-11 08:22:02 --> Router Class Initialized
INFO - 2021-01-11 08:22:02 --> Output Class Initialized
INFO - 2021-01-11 08:22:02 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:03 --> Input Class Initialized
INFO - 2021-01-11 08:22:03 --> Language Class Initialized
INFO - 2021-01-11 08:22:03 --> Language Class Initialized
INFO - 2021-01-11 08:22:03 --> Config Class Initialized
INFO - 2021-01-11 08:22:03 --> Loader Class Initialized
INFO - 2021-01-11 08:22:03 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:03 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:03 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:03 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:03 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:03 --> Controller Class Initialized
INFO - 2021-01-11 08:22:04 --> Config Class Initialized
INFO - 2021-01-11 08:22:04 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:04 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:04 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:04 --> URI Class Initialized
INFO - 2021-01-11 08:22:04 --> Router Class Initialized
INFO - 2021-01-11 08:22:04 --> Output Class Initialized
INFO - 2021-01-11 08:22:04 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:04 --> Input Class Initialized
INFO - 2021-01-11 08:22:04 --> Language Class Initialized
INFO - 2021-01-11 08:22:04 --> Language Class Initialized
INFO - 2021-01-11 08:22:04 --> Config Class Initialized
INFO - 2021-01-11 08:22:04 --> Loader Class Initialized
INFO - 2021-01-11 08:22:04 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:04 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:04 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:04 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:04 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:05 --> Controller Class Initialized
DEBUG - 2021-01-11 08:22:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:22:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:22:05 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:05 --> Total execution time: 0.4264
INFO - 2021-01-11 08:22:09 --> Config Class Initialized
INFO - 2021-01-11 08:22:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:09 --> URI Class Initialized
INFO - 2021-01-11 08:22:09 --> Router Class Initialized
INFO - 2021-01-11 08:22:09 --> Output Class Initialized
INFO - 2021-01-11 08:22:09 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:09 --> Input Class Initialized
INFO - 2021-01-11 08:22:09 --> Language Class Initialized
INFO - 2021-01-11 08:22:09 --> Language Class Initialized
INFO - 2021-01-11 08:22:09 --> Config Class Initialized
INFO - 2021-01-11 08:22:09 --> Loader Class Initialized
INFO - 2021-01-11 08:22:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:09 --> Controller Class Initialized
DEBUG - 2021-01-11 08:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:22:09 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:09 --> Total execution time: 0.4518
INFO - 2021-01-11 08:22:09 --> Config Class Initialized
INFO - 2021-01-11 08:22:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:09 --> URI Class Initialized
INFO - 2021-01-11 08:22:09 --> Router Class Initialized
INFO - 2021-01-11 08:22:09 --> Output Class Initialized
INFO - 2021-01-11 08:22:09 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:09 --> Input Class Initialized
INFO - 2021-01-11 08:22:10 --> Language Class Initialized
INFO - 2021-01-11 08:22:10 --> Language Class Initialized
INFO - 2021-01-11 08:22:10 --> Config Class Initialized
INFO - 2021-01-11 08:22:10 --> Loader Class Initialized
INFO - 2021-01-11 08:22:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:10 --> Controller Class Initialized
INFO - 2021-01-11 08:22:12 --> Config Class Initialized
INFO - 2021-01-11 08:22:12 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:12 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:12 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:12 --> URI Class Initialized
INFO - 2021-01-11 08:22:12 --> Router Class Initialized
INFO - 2021-01-11 08:22:12 --> Output Class Initialized
INFO - 2021-01-11 08:22:12 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:12 --> Input Class Initialized
INFO - 2021-01-11 08:22:12 --> Language Class Initialized
INFO - 2021-01-11 08:22:12 --> Language Class Initialized
INFO - 2021-01-11 08:22:12 --> Config Class Initialized
INFO - 2021-01-11 08:22:12 --> Loader Class Initialized
INFO - 2021-01-11 08:22:12 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:12 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:12 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:12 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:12 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:12 --> Controller Class Initialized
INFO - 2021-01-11 08:22:12 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:12 --> Total execution time: 0.2673
INFO - 2021-01-11 08:22:19 --> Config Class Initialized
INFO - 2021-01-11 08:22:19 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:20 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:20 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:20 --> URI Class Initialized
INFO - 2021-01-11 08:22:20 --> Router Class Initialized
INFO - 2021-01-11 08:22:20 --> Output Class Initialized
INFO - 2021-01-11 08:22:20 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:20 --> Input Class Initialized
INFO - 2021-01-11 08:22:20 --> Language Class Initialized
INFO - 2021-01-11 08:22:20 --> Language Class Initialized
INFO - 2021-01-11 08:22:20 --> Config Class Initialized
INFO - 2021-01-11 08:22:20 --> Loader Class Initialized
INFO - 2021-01-11 08:22:20 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:20 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:20 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:20 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:20 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:20 --> Controller Class Initialized
DEBUG - 2021-01-11 08:22:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:22:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:22:20 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:20 --> Total execution time: 0.4627
INFO - 2021-01-11 08:22:20 --> Config Class Initialized
INFO - 2021-01-11 08:22:20 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:20 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:20 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:20 --> URI Class Initialized
INFO - 2021-01-11 08:22:20 --> Router Class Initialized
INFO - 2021-01-11 08:22:20 --> Output Class Initialized
INFO - 2021-01-11 08:22:20 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:20 --> Input Class Initialized
INFO - 2021-01-11 08:22:20 --> Language Class Initialized
INFO - 2021-01-11 08:22:20 --> Language Class Initialized
INFO - 2021-01-11 08:22:20 --> Config Class Initialized
INFO - 2021-01-11 08:22:20 --> Loader Class Initialized
INFO - 2021-01-11 08:22:20 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:20 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:20 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:20 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:20 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:20 --> Controller Class Initialized
INFO - 2021-01-11 08:22:22 --> Config Class Initialized
INFO - 2021-01-11 08:22:22 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:22 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:22 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:22 --> URI Class Initialized
INFO - 2021-01-11 08:22:22 --> Router Class Initialized
INFO - 2021-01-11 08:22:22 --> Output Class Initialized
INFO - 2021-01-11 08:22:22 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:22 --> Input Class Initialized
INFO - 2021-01-11 08:22:22 --> Language Class Initialized
INFO - 2021-01-11 08:22:22 --> Language Class Initialized
INFO - 2021-01-11 08:22:22 --> Config Class Initialized
INFO - 2021-01-11 08:22:22 --> Loader Class Initialized
INFO - 2021-01-11 08:22:22 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:22 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:22 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:22 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:22 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:22 --> Controller Class Initialized
DEBUG - 2021-01-11 08:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:22:23 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:23 --> Total execution time: 0.4677
INFO - 2021-01-11 08:22:25 --> Config Class Initialized
INFO - 2021-01-11 08:22:25 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:25 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:25 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:25 --> URI Class Initialized
INFO - 2021-01-11 08:22:25 --> Router Class Initialized
INFO - 2021-01-11 08:22:25 --> Output Class Initialized
INFO - 2021-01-11 08:22:25 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:25 --> Input Class Initialized
INFO - 2021-01-11 08:22:25 --> Language Class Initialized
INFO - 2021-01-11 08:22:25 --> Language Class Initialized
INFO - 2021-01-11 08:22:25 --> Config Class Initialized
INFO - 2021-01-11 08:22:25 --> Loader Class Initialized
INFO - 2021-01-11 08:22:25 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:25 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:25 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:25 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:25 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:25 --> Controller Class Initialized
INFO - 2021-01-11 08:22:25 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:25 --> Total execution time: 0.2715
INFO - 2021-01-11 08:22:28 --> Config Class Initialized
INFO - 2021-01-11 08:22:28 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:28 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:28 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:28 --> URI Class Initialized
INFO - 2021-01-11 08:22:28 --> Router Class Initialized
INFO - 2021-01-11 08:22:28 --> Output Class Initialized
INFO - 2021-01-11 08:22:28 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:28 --> Input Class Initialized
INFO - 2021-01-11 08:22:28 --> Language Class Initialized
INFO - 2021-01-11 08:22:28 --> Language Class Initialized
INFO - 2021-01-11 08:22:28 --> Config Class Initialized
INFO - 2021-01-11 08:22:28 --> Loader Class Initialized
INFO - 2021-01-11 08:22:28 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:28 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:28 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:28 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:28 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:29 --> Controller Class Initialized
INFO - 2021-01-11 08:22:29 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:29 --> Total execution time: 0.2713
INFO - 2021-01-11 08:22:34 --> Config Class Initialized
INFO - 2021-01-11 08:22:34 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:34 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:34 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:34 --> URI Class Initialized
INFO - 2021-01-11 08:22:34 --> Router Class Initialized
INFO - 2021-01-11 08:22:34 --> Output Class Initialized
INFO - 2021-01-11 08:22:34 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:34 --> Input Class Initialized
INFO - 2021-01-11 08:22:34 --> Language Class Initialized
INFO - 2021-01-11 08:22:34 --> Language Class Initialized
INFO - 2021-01-11 08:22:34 --> Config Class Initialized
INFO - 2021-01-11 08:22:34 --> Loader Class Initialized
INFO - 2021-01-11 08:22:34 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:34 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:34 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:34 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:34 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:34 --> Controller Class Initialized
INFO - 2021-01-11 08:22:34 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:34 --> Total execution time: 0.3383
INFO - 2021-01-11 08:22:38 --> Config Class Initialized
INFO - 2021-01-11 08:22:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:38 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:38 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:38 --> URI Class Initialized
INFO - 2021-01-11 08:22:38 --> Router Class Initialized
INFO - 2021-01-11 08:22:38 --> Output Class Initialized
INFO - 2021-01-11 08:22:38 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:38 --> Input Class Initialized
INFO - 2021-01-11 08:22:38 --> Language Class Initialized
INFO - 2021-01-11 08:22:38 --> Language Class Initialized
INFO - 2021-01-11 08:22:38 --> Config Class Initialized
INFO - 2021-01-11 08:22:38 --> Loader Class Initialized
INFO - 2021-01-11 08:22:38 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:38 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:38 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:38 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:38 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:38 --> Controller Class Initialized
INFO - 2021-01-11 08:22:38 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:38 --> Total execution time: 0.2692
INFO - 2021-01-11 08:22:48 --> Config Class Initialized
INFO - 2021-01-11 08:22:48 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:22:48 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:22:48 --> Utf8 Class Initialized
INFO - 2021-01-11 08:22:48 --> URI Class Initialized
INFO - 2021-01-11 08:22:48 --> Router Class Initialized
INFO - 2021-01-11 08:22:48 --> Output Class Initialized
INFO - 2021-01-11 08:22:48 --> Security Class Initialized
DEBUG - 2021-01-11 08:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:22:48 --> Input Class Initialized
INFO - 2021-01-11 08:22:48 --> Language Class Initialized
INFO - 2021-01-11 08:22:49 --> Language Class Initialized
INFO - 2021-01-11 08:22:49 --> Config Class Initialized
INFO - 2021-01-11 08:22:49 --> Loader Class Initialized
INFO - 2021-01-11 08:22:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:22:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:22:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:22:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:22:49 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:22:49 --> Controller Class Initialized
INFO - 2021-01-11 08:22:49 --> Final output sent to browser
DEBUG - 2021-01-11 08:22:49 --> Total execution time: 0.3497
INFO - 2021-01-11 08:23:01 --> Config Class Initialized
INFO - 2021-01-11 08:23:01 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:01 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:01 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:01 --> URI Class Initialized
INFO - 2021-01-11 08:23:01 --> Router Class Initialized
INFO - 2021-01-11 08:23:01 --> Output Class Initialized
INFO - 2021-01-11 08:23:01 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:01 --> Input Class Initialized
INFO - 2021-01-11 08:23:01 --> Language Class Initialized
INFO - 2021-01-11 08:23:01 --> Language Class Initialized
INFO - 2021-01-11 08:23:01 --> Config Class Initialized
INFO - 2021-01-11 08:23:01 --> Loader Class Initialized
INFO - 2021-01-11 08:23:01 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:01 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:02 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:02 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:02 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:02 --> Controller Class Initialized
INFO - 2021-01-11 08:23:02 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:02 --> Total execution time: 0.3981
INFO - 2021-01-11 08:23:04 --> Config Class Initialized
INFO - 2021-01-11 08:23:04 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:04 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:04 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:04 --> URI Class Initialized
INFO - 2021-01-11 08:23:04 --> Router Class Initialized
INFO - 2021-01-11 08:23:04 --> Output Class Initialized
INFO - 2021-01-11 08:23:04 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:04 --> Input Class Initialized
INFO - 2021-01-11 08:23:04 --> Language Class Initialized
INFO - 2021-01-11 08:23:04 --> Language Class Initialized
INFO - 2021-01-11 08:23:04 --> Config Class Initialized
INFO - 2021-01-11 08:23:04 --> Loader Class Initialized
INFO - 2021-01-11 08:23:04 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:04 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:04 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:04 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:04 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:04 --> Controller Class Initialized
INFO - 2021-01-11 08:23:04 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:04 --> Total execution time: 0.2731
INFO - 2021-01-11 08:23:06 --> Config Class Initialized
INFO - 2021-01-11 08:23:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:06 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:06 --> URI Class Initialized
INFO - 2021-01-11 08:23:06 --> Router Class Initialized
INFO - 2021-01-11 08:23:06 --> Output Class Initialized
INFO - 2021-01-11 08:23:06 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:06 --> Input Class Initialized
INFO - 2021-01-11 08:23:06 --> Language Class Initialized
INFO - 2021-01-11 08:23:06 --> Language Class Initialized
INFO - 2021-01-11 08:23:06 --> Config Class Initialized
INFO - 2021-01-11 08:23:06 --> Loader Class Initialized
INFO - 2021-01-11 08:23:06 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:06 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:06 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:06 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:06 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:06 --> Controller Class Initialized
INFO - 2021-01-11 08:23:06 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:06 --> Total execution time: 0.2858
INFO - 2021-01-11 08:23:08 --> Config Class Initialized
INFO - 2021-01-11 08:23:08 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:08 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:08 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:08 --> URI Class Initialized
INFO - 2021-01-11 08:23:08 --> Router Class Initialized
INFO - 2021-01-11 08:23:08 --> Output Class Initialized
INFO - 2021-01-11 08:23:08 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:09 --> Input Class Initialized
INFO - 2021-01-11 08:23:09 --> Language Class Initialized
INFO - 2021-01-11 08:23:09 --> Language Class Initialized
INFO - 2021-01-11 08:23:09 --> Config Class Initialized
INFO - 2021-01-11 08:23:09 --> Loader Class Initialized
INFO - 2021-01-11 08:23:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:09 --> Controller Class Initialized
INFO - 2021-01-11 08:23:09 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:09 --> Total execution time: 0.4300
INFO - 2021-01-11 08:23:15 --> Config Class Initialized
INFO - 2021-01-11 08:23:15 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:15 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:15 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:15 --> URI Class Initialized
INFO - 2021-01-11 08:23:15 --> Router Class Initialized
INFO - 2021-01-11 08:23:15 --> Output Class Initialized
INFO - 2021-01-11 08:23:15 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:15 --> Input Class Initialized
INFO - 2021-01-11 08:23:15 --> Language Class Initialized
INFO - 2021-01-11 08:23:15 --> Language Class Initialized
INFO - 2021-01-11 08:23:15 --> Config Class Initialized
INFO - 2021-01-11 08:23:15 --> Loader Class Initialized
INFO - 2021-01-11 08:23:15 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:15 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:15 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:15 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:15 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:15 --> Controller Class Initialized
INFO - 2021-01-11 08:23:15 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:15 --> Total execution time: 0.3419
INFO - 2021-01-11 08:23:18 --> Config Class Initialized
INFO - 2021-01-11 08:23:18 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:18 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:18 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:18 --> URI Class Initialized
INFO - 2021-01-11 08:23:18 --> Router Class Initialized
INFO - 2021-01-11 08:23:18 --> Output Class Initialized
INFO - 2021-01-11 08:23:18 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:18 --> Input Class Initialized
INFO - 2021-01-11 08:23:18 --> Language Class Initialized
INFO - 2021-01-11 08:23:18 --> Language Class Initialized
INFO - 2021-01-11 08:23:18 --> Config Class Initialized
INFO - 2021-01-11 08:23:18 --> Loader Class Initialized
INFO - 2021-01-11 08:23:18 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:18 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:18 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:18 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:18 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:18 --> Controller Class Initialized
INFO - 2021-01-11 08:23:18 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:18 --> Total execution time: 0.2770
INFO - 2021-01-11 08:23:23 --> Config Class Initialized
INFO - 2021-01-11 08:23:23 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:23 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:23 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:23 --> URI Class Initialized
INFO - 2021-01-11 08:23:23 --> Router Class Initialized
INFO - 2021-01-11 08:23:23 --> Output Class Initialized
INFO - 2021-01-11 08:23:24 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:24 --> Input Class Initialized
INFO - 2021-01-11 08:23:24 --> Language Class Initialized
INFO - 2021-01-11 08:23:24 --> Language Class Initialized
INFO - 2021-01-11 08:23:24 --> Config Class Initialized
INFO - 2021-01-11 08:23:24 --> Loader Class Initialized
INFO - 2021-01-11 08:23:24 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:24 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:24 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:24 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:24 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:24 --> Controller Class Initialized
INFO - 2021-01-11 08:23:24 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:24 --> Total execution time: 0.3935
INFO - 2021-01-11 08:23:25 --> Config Class Initialized
INFO - 2021-01-11 08:23:25 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:25 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:25 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:25 --> URI Class Initialized
INFO - 2021-01-11 08:23:25 --> Router Class Initialized
INFO - 2021-01-11 08:23:25 --> Output Class Initialized
INFO - 2021-01-11 08:23:25 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:25 --> Input Class Initialized
INFO - 2021-01-11 08:23:25 --> Language Class Initialized
INFO - 2021-01-11 08:23:25 --> Language Class Initialized
INFO - 2021-01-11 08:23:25 --> Config Class Initialized
INFO - 2021-01-11 08:23:25 --> Loader Class Initialized
INFO - 2021-01-11 08:23:25 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:25 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:25 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:25 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:25 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:25 --> Controller Class Initialized
INFO - 2021-01-11 08:23:25 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:25 --> Total execution time: 0.3417
INFO - 2021-01-11 08:23:32 --> Config Class Initialized
INFO - 2021-01-11 08:23:32 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:32 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:32 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:32 --> URI Class Initialized
INFO - 2021-01-11 08:23:32 --> Router Class Initialized
INFO - 2021-01-11 08:23:32 --> Output Class Initialized
INFO - 2021-01-11 08:23:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:32 --> Input Class Initialized
INFO - 2021-01-11 08:23:32 --> Language Class Initialized
INFO - 2021-01-11 08:23:32 --> Language Class Initialized
INFO - 2021-01-11 08:23:32 --> Config Class Initialized
INFO - 2021-01-11 08:23:32 --> Loader Class Initialized
INFO - 2021-01-11 08:23:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:33 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:33 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:33 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:33 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:33 --> Controller Class Initialized
INFO - 2021-01-11 08:23:33 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:33 --> Total execution time: 0.3516
INFO - 2021-01-11 08:23:42 --> Config Class Initialized
INFO - 2021-01-11 08:23:42 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:42 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:42 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:42 --> URI Class Initialized
INFO - 2021-01-11 08:23:42 --> Router Class Initialized
INFO - 2021-01-11 08:23:42 --> Output Class Initialized
INFO - 2021-01-11 08:23:42 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:42 --> Input Class Initialized
INFO - 2021-01-11 08:23:42 --> Language Class Initialized
INFO - 2021-01-11 08:23:42 --> Language Class Initialized
INFO - 2021-01-11 08:23:42 --> Config Class Initialized
INFO - 2021-01-11 08:23:42 --> Loader Class Initialized
INFO - 2021-01-11 08:23:42 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:42 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:42 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:42 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:42 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:42 --> Controller Class Initialized
DEBUG - 2021-01-11 08:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:23:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:23:43 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:43 --> Total execution time: 0.4445
INFO - 2021-01-11 08:23:43 --> Config Class Initialized
INFO - 2021-01-11 08:23:43 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:43 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:43 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:43 --> URI Class Initialized
INFO - 2021-01-11 08:23:43 --> Router Class Initialized
INFO - 2021-01-11 08:23:43 --> Output Class Initialized
INFO - 2021-01-11 08:23:43 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:43 --> Input Class Initialized
INFO - 2021-01-11 08:23:43 --> Language Class Initialized
INFO - 2021-01-11 08:23:43 --> Language Class Initialized
INFO - 2021-01-11 08:23:43 --> Config Class Initialized
INFO - 2021-01-11 08:23:43 --> Loader Class Initialized
INFO - 2021-01-11 08:23:43 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:43 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:43 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:43 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:43 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:43 --> Controller Class Initialized
INFO - 2021-01-11 08:23:45 --> Config Class Initialized
INFO - 2021-01-11 08:23:45 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:45 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:45 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:45 --> URI Class Initialized
INFO - 2021-01-11 08:23:45 --> Router Class Initialized
INFO - 2021-01-11 08:23:45 --> Output Class Initialized
INFO - 2021-01-11 08:23:45 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:45 --> Input Class Initialized
INFO - 2021-01-11 08:23:46 --> Language Class Initialized
INFO - 2021-01-11 08:23:46 --> Language Class Initialized
INFO - 2021-01-11 08:23:46 --> Config Class Initialized
INFO - 2021-01-11 08:23:46 --> Loader Class Initialized
INFO - 2021-01-11 08:23:46 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:46 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:46 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:46 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:46 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:46 --> Controller Class Initialized
DEBUG - 2021-01-11 08:23:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:23:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:23:46 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:46 --> Total execution time: 0.4166
INFO - 2021-01-11 08:23:48 --> Config Class Initialized
INFO - 2021-01-11 08:23:48 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:48 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:48 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:48 --> URI Class Initialized
INFO - 2021-01-11 08:23:49 --> Router Class Initialized
INFO - 2021-01-11 08:23:49 --> Output Class Initialized
INFO - 2021-01-11 08:23:49 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:49 --> Input Class Initialized
INFO - 2021-01-11 08:23:49 --> Language Class Initialized
INFO - 2021-01-11 08:23:49 --> Language Class Initialized
INFO - 2021-01-11 08:23:49 --> Config Class Initialized
INFO - 2021-01-11 08:23:49 --> Loader Class Initialized
INFO - 2021-01-11 08:23:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:49 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:49 --> Controller Class Initialized
INFO - 2021-01-11 08:23:49 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:49 --> Total execution time: 0.3074
INFO - 2021-01-11 08:23:57 --> Config Class Initialized
INFO - 2021-01-11 08:23:57 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:23:57 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:23:57 --> Utf8 Class Initialized
INFO - 2021-01-11 08:23:57 --> URI Class Initialized
INFO - 2021-01-11 08:23:57 --> Router Class Initialized
INFO - 2021-01-11 08:23:57 --> Output Class Initialized
INFO - 2021-01-11 08:23:57 --> Security Class Initialized
DEBUG - 2021-01-11 08:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:23:57 --> Input Class Initialized
INFO - 2021-01-11 08:23:57 --> Language Class Initialized
INFO - 2021-01-11 08:23:57 --> Language Class Initialized
INFO - 2021-01-11 08:23:57 --> Config Class Initialized
INFO - 2021-01-11 08:23:57 --> Loader Class Initialized
INFO - 2021-01-11 08:23:57 --> Helper loaded: url_helper
INFO - 2021-01-11 08:23:57 --> Helper loaded: file_helper
INFO - 2021-01-11 08:23:57 --> Helper loaded: form_helper
INFO - 2021-01-11 08:23:57 --> Helper loaded: my_helper
INFO - 2021-01-11 08:23:57 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:23:57 --> Controller Class Initialized
INFO - 2021-01-11 08:23:57 --> Final output sent to browser
DEBUG - 2021-01-11 08:23:57 --> Total execution time: 0.3618
INFO - 2021-01-11 08:24:01 --> Config Class Initialized
INFO - 2021-01-11 08:24:01 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:24:01 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:24:01 --> Utf8 Class Initialized
INFO - 2021-01-11 08:24:01 --> URI Class Initialized
INFO - 2021-01-11 08:24:01 --> Router Class Initialized
INFO - 2021-01-11 08:24:01 --> Output Class Initialized
INFO - 2021-01-11 08:24:01 --> Security Class Initialized
DEBUG - 2021-01-11 08:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:24:01 --> Input Class Initialized
INFO - 2021-01-11 08:24:01 --> Language Class Initialized
INFO - 2021-01-11 08:24:01 --> Language Class Initialized
INFO - 2021-01-11 08:24:01 --> Config Class Initialized
INFO - 2021-01-11 08:24:01 --> Loader Class Initialized
INFO - 2021-01-11 08:24:01 --> Helper loaded: url_helper
INFO - 2021-01-11 08:24:01 --> Helper loaded: file_helper
INFO - 2021-01-11 08:24:01 --> Helper loaded: form_helper
INFO - 2021-01-11 08:24:01 --> Helper loaded: my_helper
INFO - 2021-01-11 08:24:01 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:24:01 --> Controller Class Initialized
INFO - 2021-01-11 08:24:01 --> Final output sent to browser
DEBUG - 2021-01-11 08:24:01 --> Total execution time: 0.2797
INFO - 2021-01-11 08:24:18 --> Config Class Initialized
INFO - 2021-01-11 08:24:18 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:24:18 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:24:18 --> Utf8 Class Initialized
INFO - 2021-01-11 08:24:18 --> URI Class Initialized
INFO - 2021-01-11 08:24:18 --> Router Class Initialized
INFO - 2021-01-11 08:24:18 --> Output Class Initialized
INFO - 2021-01-11 08:24:18 --> Security Class Initialized
DEBUG - 2021-01-11 08:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:24:18 --> Input Class Initialized
INFO - 2021-01-11 08:24:18 --> Language Class Initialized
INFO - 2021-01-11 08:24:18 --> Language Class Initialized
INFO - 2021-01-11 08:24:18 --> Config Class Initialized
INFO - 2021-01-11 08:24:18 --> Loader Class Initialized
INFO - 2021-01-11 08:24:19 --> Helper loaded: url_helper
INFO - 2021-01-11 08:24:19 --> Helper loaded: file_helper
INFO - 2021-01-11 08:24:19 --> Helper loaded: form_helper
INFO - 2021-01-11 08:24:19 --> Helper loaded: my_helper
INFO - 2021-01-11 08:24:19 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:24:19 --> Controller Class Initialized
INFO - 2021-01-11 08:24:19 --> Final output sent to browser
DEBUG - 2021-01-11 08:24:19 --> Total execution time: 0.3833
INFO - 2021-01-11 08:24:28 --> Config Class Initialized
INFO - 2021-01-11 08:24:28 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:24:28 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:24:28 --> Utf8 Class Initialized
INFO - 2021-01-11 08:24:28 --> URI Class Initialized
INFO - 2021-01-11 08:24:28 --> Router Class Initialized
INFO - 2021-01-11 08:24:28 --> Output Class Initialized
INFO - 2021-01-11 08:24:28 --> Security Class Initialized
DEBUG - 2021-01-11 08:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:24:28 --> Input Class Initialized
INFO - 2021-01-11 08:24:28 --> Language Class Initialized
INFO - 2021-01-11 08:24:28 --> Language Class Initialized
INFO - 2021-01-11 08:24:28 --> Config Class Initialized
INFO - 2021-01-11 08:24:28 --> Loader Class Initialized
INFO - 2021-01-11 08:24:28 --> Helper loaded: url_helper
INFO - 2021-01-11 08:24:28 --> Helper loaded: file_helper
INFO - 2021-01-11 08:24:28 --> Helper loaded: form_helper
INFO - 2021-01-11 08:24:28 --> Helper loaded: my_helper
INFO - 2021-01-11 08:24:28 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:24:28 --> Controller Class Initialized
INFO - 2021-01-11 08:24:28 --> Final output sent to browser
DEBUG - 2021-01-11 08:24:28 --> Total execution time: 0.2926
INFO - 2021-01-11 08:24:34 --> Config Class Initialized
INFO - 2021-01-11 08:24:34 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:24:34 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:24:34 --> Utf8 Class Initialized
INFO - 2021-01-11 08:24:34 --> URI Class Initialized
INFO - 2021-01-11 08:24:34 --> Router Class Initialized
INFO - 2021-01-11 08:24:34 --> Output Class Initialized
INFO - 2021-01-11 08:24:34 --> Security Class Initialized
DEBUG - 2021-01-11 08:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:24:34 --> Input Class Initialized
INFO - 2021-01-11 08:24:34 --> Language Class Initialized
INFO - 2021-01-11 08:24:34 --> Language Class Initialized
INFO - 2021-01-11 08:24:34 --> Config Class Initialized
INFO - 2021-01-11 08:24:34 --> Loader Class Initialized
INFO - 2021-01-11 08:24:34 --> Helper loaded: url_helper
INFO - 2021-01-11 08:24:34 --> Helper loaded: file_helper
INFO - 2021-01-11 08:24:34 --> Helper loaded: form_helper
INFO - 2021-01-11 08:24:34 --> Helper loaded: my_helper
INFO - 2021-01-11 08:24:34 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:24:34 --> Controller Class Initialized
INFO - 2021-01-11 08:24:34 --> Final output sent to browser
DEBUG - 2021-01-11 08:24:34 --> Total execution time: 0.5382
INFO - 2021-01-11 08:24:37 --> Config Class Initialized
INFO - 2021-01-11 08:24:37 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:24:37 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:24:37 --> Utf8 Class Initialized
INFO - 2021-01-11 08:24:37 --> URI Class Initialized
INFO - 2021-01-11 08:24:37 --> Router Class Initialized
INFO - 2021-01-11 08:24:37 --> Output Class Initialized
INFO - 2021-01-11 08:24:37 --> Security Class Initialized
DEBUG - 2021-01-11 08:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:24:37 --> Input Class Initialized
INFO - 2021-01-11 08:24:37 --> Language Class Initialized
INFO - 2021-01-11 08:24:37 --> Language Class Initialized
INFO - 2021-01-11 08:24:37 --> Config Class Initialized
INFO - 2021-01-11 08:24:37 --> Loader Class Initialized
INFO - 2021-01-11 08:24:37 --> Helper loaded: url_helper
INFO - 2021-01-11 08:24:37 --> Helper loaded: file_helper
INFO - 2021-01-11 08:24:37 --> Helper loaded: form_helper
INFO - 2021-01-11 08:24:37 --> Helper loaded: my_helper
INFO - 2021-01-11 08:24:37 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:24:37 --> Controller Class Initialized
INFO - 2021-01-11 08:24:37 --> Final output sent to browser
DEBUG - 2021-01-11 08:24:37 --> Total execution time: 0.2788
INFO - 2021-01-11 08:24:46 --> Config Class Initialized
INFO - 2021-01-11 08:24:46 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:24:46 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:24:46 --> Utf8 Class Initialized
INFO - 2021-01-11 08:24:46 --> URI Class Initialized
INFO - 2021-01-11 08:24:46 --> Router Class Initialized
INFO - 2021-01-11 08:24:46 --> Output Class Initialized
INFO - 2021-01-11 08:24:46 --> Security Class Initialized
DEBUG - 2021-01-11 08:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:24:46 --> Input Class Initialized
INFO - 2021-01-11 08:24:46 --> Language Class Initialized
INFO - 2021-01-11 08:24:46 --> Language Class Initialized
INFO - 2021-01-11 08:24:46 --> Config Class Initialized
INFO - 2021-01-11 08:24:46 --> Loader Class Initialized
INFO - 2021-01-11 08:24:46 --> Helper loaded: url_helper
INFO - 2021-01-11 08:24:46 --> Helper loaded: file_helper
INFO - 2021-01-11 08:24:46 --> Helper loaded: form_helper
INFO - 2021-01-11 08:24:46 --> Helper loaded: my_helper
INFO - 2021-01-11 08:24:46 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:24:46 --> Controller Class Initialized
INFO - 2021-01-11 08:24:46 --> Final output sent to browser
DEBUG - 2021-01-11 08:24:46 --> Total execution time: 0.3857
INFO - 2021-01-11 08:24:50 --> Config Class Initialized
INFO - 2021-01-11 08:24:50 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:24:50 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:24:50 --> Utf8 Class Initialized
INFO - 2021-01-11 08:24:50 --> URI Class Initialized
INFO - 2021-01-11 08:24:50 --> Router Class Initialized
INFO - 2021-01-11 08:24:50 --> Output Class Initialized
INFO - 2021-01-11 08:24:50 --> Security Class Initialized
DEBUG - 2021-01-11 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:24:50 --> Input Class Initialized
INFO - 2021-01-11 08:24:50 --> Language Class Initialized
INFO - 2021-01-11 08:24:50 --> Language Class Initialized
INFO - 2021-01-11 08:24:50 --> Config Class Initialized
INFO - 2021-01-11 08:24:50 --> Loader Class Initialized
INFO - 2021-01-11 08:24:50 --> Helper loaded: url_helper
INFO - 2021-01-11 08:24:50 --> Helper loaded: file_helper
INFO - 2021-01-11 08:24:50 --> Helper loaded: form_helper
INFO - 2021-01-11 08:24:50 --> Helper loaded: my_helper
INFO - 2021-01-11 08:24:50 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:24:50 --> Controller Class Initialized
INFO - 2021-01-11 08:24:50 --> Final output sent to browser
DEBUG - 2021-01-11 08:24:50 --> Total execution time: 0.2787
INFO - 2021-01-11 08:24:57 --> Config Class Initialized
INFO - 2021-01-11 08:24:57 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:24:57 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:24:58 --> Utf8 Class Initialized
INFO - 2021-01-11 08:24:58 --> URI Class Initialized
INFO - 2021-01-11 08:24:58 --> Router Class Initialized
INFO - 2021-01-11 08:24:58 --> Output Class Initialized
INFO - 2021-01-11 08:24:58 --> Security Class Initialized
DEBUG - 2021-01-11 08:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:24:58 --> Input Class Initialized
INFO - 2021-01-11 08:24:58 --> Language Class Initialized
INFO - 2021-01-11 08:24:58 --> Language Class Initialized
INFO - 2021-01-11 08:24:58 --> Config Class Initialized
INFO - 2021-01-11 08:24:58 --> Loader Class Initialized
INFO - 2021-01-11 08:24:58 --> Helper loaded: url_helper
INFO - 2021-01-11 08:24:58 --> Helper loaded: file_helper
INFO - 2021-01-11 08:24:58 --> Helper loaded: form_helper
INFO - 2021-01-11 08:24:58 --> Helper loaded: my_helper
INFO - 2021-01-11 08:24:58 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:24:58 --> Controller Class Initialized
INFO - 2021-01-11 08:24:58 --> Final output sent to browser
DEBUG - 2021-01-11 08:24:58 --> Total execution time: 0.4032
INFO - 2021-01-11 08:25:01 --> Config Class Initialized
INFO - 2021-01-11 08:25:01 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:25:01 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:25:01 --> Utf8 Class Initialized
INFO - 2021-01-11 08:25:01 --> URI Class Initialized
INFO - 2021-01-11 08:25:01 --> Router Class Initialized
INFO - 2021-01-11 08:25:01 --> Output Class Initialized
INFO - 2021-01-11 08:25:01 --> Security Class Initialized
DEBUG - 2021-01-11 08:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:25:01 --> Input Class Initialized
INFO - 2021-01-11 08:25:01 --> Language Class Initialized
INFO - 2021-01-11 08:25:01 --> Language Class Initialized
INFO - 2021-01-11 08:25:01 --> Config Class Initialized
INFO - 2021-01-11 08:25:01 --> Loader Class Initialized
INFO - 2021-01-11 08:25:01 --> Helper loaded: url_helper
INFO - 2021-01-11 08:25:01 --> Helper loaded: file_helper
INFO - 2021-01-11 08:25:01 --> Helper loaded: form_helper
INFO - 2021-01-11 08:25:01 --> Helper loaded: my_helper
INFO - 2021-01-11 08:25:01 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:25:01 --> Controller Class Initialized
INFO - 2021-01-11 08:25:01 --> Final output sent to browser
DEBUG - 2021-01-11 08:25:01 --> Total execution time: 0.2827
INFO - 2021-01-11 08:25:07 --> Config Class Initialized
INFO - 2021-01-11 08:25:07 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:25:07 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:25:07 --> Utf8 Class Initialized
INFO - 2021-01-11 08:25:07 --> URI Class Initialized
INFO - 2021-01-11 08:25:07 --> Router Class Initialized
INFO - 2021-01-11 08:25:07 --> Output Class Initialized
INFO - 2021-01-11 08:25:07 --> Security Class Initialized
DEBUG - 2021-01-11 08:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:25:07 --> Input Class Initialized
INFO - 2021-01-11 08:25:07 --> Language Class Initialized
INFO - 2021-01-11 08:25:07 --> Language Class Initialized
INFO - 2021-01-11 08:25:07 --> Config Class Initialized
INFO - 2021-01-11 08:25:07 --> Loader Class Initialized
INFO - 2021-01-11 08:25:07 --> Helper loaded: url_helper
INFO - 2021-01-11 08:25:07 --> Helper loaded: file_helper
INFO - 2021-01-11 08:25:07 --> Helper loaded: form_helper
INFO - 2021-01-11 08:25:07 --> Helper loaded: my_helper
INFO - 2021-01-11 08:25:07 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:25:07 --> Controller Class Initialized
INFO - 2021-01-11 08:25:07 --> Final output sent to browser
DEBUG - 2021-01-11 08:25:07 --> Total execution time: 0.3907
INFO - 2021-01-11 08:28:08 --> Config Class Initialized
INFO - 2021-01-11 08:28:08 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:08 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:08 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:08 --> URI Class Initialized
INFO - 2021-01-11 08:28:08 --> Router Class Initialized
INFO - 2021-01-11 08:28:08 --> Output Class Initialized
INFO - 2021-01-11 08:28:08 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:08 --> Input Class Initialized
INFO - 2021-01-11 08:28:09 --> Language Class Initialized
INFO - 2021-01-11 08:28:09 --> Language Class Initialized
INFO - 2021-01-11 08:28:09 --> Config Class Initialized
INFO - 2021-01-11 08:28:09 --> Loader Class Initialized
INFO - 2021-01-11 08:28:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:09 --> Controller Class Initialized
DEBUG - 2021-01-11 08:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:28:09 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:09 --> Total execution time: 0.3799
INFO - 2021-01-11 08:28:11 --> Config Class Initialized
INFO - 2021-01-11 08:28:11 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:11 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:11 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:11 --> URI Class Initialized
INFO - 2021-01-11 08:28:11 --> Router Class Initialized
INFO - 2021-01-11 08:28:11 --> Output Class Initialized
INFO - 2021-01-11 08:28:11 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:11 --> Input Class Initialized
INFO - 2021-01-11 08:28:11 --> Language Class Initialized
INFO - 2021-01-11 08:28:11 --> Language Class Initialized
INFO - 2021-01-11 08:28:11 --> Config Class Initialized
INFO - 2021-01-11 08:28:11 --> Loader Class Initialized
INFO - 2021-01-11 08:28:11 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:11 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:11 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:11 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:11 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:11 --> Controller Class Initialized
INFO - 2021-01-11 08:28:11 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:11 --> Total execution time: 0.3107
INFO - 2021-01-11 08:28:12 --> Config Class Initialized
INFO - 2021-01-11 08:28:12 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:12 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:12 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:12 --> URI Class Initialized
INFO - 2021-01-11 08:28:12 --> Router Class Initialized
INFO - 2021-01-11 08:28:12 --> Output Class Initialized
INFO - 2021-01-11 08:28:12 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:12 --> Input Class Initialized
INFO - 2021-01-11 08:28:12 --> Language Class Initialized
INFO - 2021-01-11 08:28:12 --> Language Class Initialized
INFO - 2021-01-11 08:28:13 --> Config Class Initialized
INFO - 2021-01-11 08:28:13 --> Loader Class Initialized
INFO - 2021-01-11 08:28:13 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:13 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:13 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:13 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:13 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:13 --> Controller Class Initialized
DEBUG - 2021-01-11 08:28:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:28:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:28:13 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:13 --> Total execution time: 0.4067
INFO - 2021-01-11 08:28:16 --> Config Class Initialized
INFO - 2021-01-11 08:28:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:16 --> URI Class Initialized
INFO - 2021-01-11 08:28:16 --> Router Class Initialized
INFO - 2021-01-11 08:28:16 --> Output Class Initialized
INFO - 2021-01-11 08:28:16 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:16 --> Input Class Initialized
INFO - 2021-01-11 08:28:16 --> Language Class Initialized
INFO - 2021-01-11 08:28:16 --> Language Class Initialized
INFO - 2021-01-11 08:28:16 --> Config Class Initialized
INFO - 2021-01-11 08:28:16 --> Loader Class Initialized
INFO - 2021-01-11 08:28:16 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:16 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:16 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:16 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:16 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:16 --> Controller Class Initialized
DEBUG - 2021-01-11 08:28:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:28:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:28:17 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:17 --> Total execution time: 0.3703
INFO - 2021-01-11 08:28:17 --> Config Class Initialized
INFO - 2021-01-11 08:28:17 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:17 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:17 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:17 --> URI Class Initialized
INFO - 2021-01-11 08:28:17 --> Router Class Initialized
INFO - 2021-01-11 08:28:17 --> Output Class Initialized
INFO - 2021-01-11 08:28:17 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:17 --> Input Class Initialized
INFO - 2021-01-11 08:28:17 --> Language Class Initialized
INFO - 2021-01-11 08:28:17 --> Language Class Initialized
INFO - 2021-01-11 08:28:17 --> Config Class Initialized
INFO - 2021-01-11 08:28:17 --> Loader Class Initialized
INFO - 2021-01-11 08:28:17 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:17 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:17 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:17 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:17 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:17 --> Controller Class Initialized
INFO - 2021-01-11 08:28:18 --> Config Class Initialized
INFO - 2021-01-11 08:28:18 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:18 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:18 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:18 --> URI Class Initialized
INFO - 2021-01-11 08:28:18 --> Router Class Initialized
INFO - 2021-01-11 08:28:18 --> Output Class Initialized
INFO - 2021-01-11 08:28:18 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:18 --> Input Class Initialized
INFO - 2021-01-11 08:28:18 --> Language Class Initialized
INFO - 2021-01-11 08:28:18 --> Language Class Initialized
INFO - 2021-01-11 08:28:18 --> Config Class Initialized
INFO - 2021-01-11 08:28:18 --> Loader Class Initialized
INFO - 2021-01-11 08:28:18 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:18 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:18 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:18 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:18 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:18 --> Controller Class Initialized
INFO - 2021-01-11 08:28:18 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:18 --> Total execution time: 0.2785
INFO - 2021-01-11 08:28:20 --> Config Class Initialized
INFO - 2021-01-11 08:28:20 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:20 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:20 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:20 --> URI Class Initialized
INFO - 2021-01-11 08:28:20 --> Router Class Initialized
INFO - 2021-01-11 08:28:20 --> Output Class Initialized
INFO - 2021-01-11 08:28:20 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:20 --> Input Class Initialized
INFO - 2021-01-11 08:28:20 --> Language Class Initialized
INFO - 2021-01-11 08:28:20 --> Language Class Initialized
INFO - 2021-01-11 08:28:20 --> Config Class Initialized
INFO - 2021-01-11 08:28:20 --> Loader Class Initialized
INFO - 2021-01-11 08:28:20 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:20 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:20 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:20 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:20 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:20 --> Controller Class Initialized
DEBUG - 2021-01-11 08:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:28:20 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:20 --> Total execution time: 0.3667
INFO - 2021-01-11 08:28:25 --> Config Class Initialized
INFO - 2021-01-11 08:28:25 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:25 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:25 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:25 --> URI Class Initialized
INFO - 2021-01-11 08:28:25 --> Router Class Initialized
INFO - 2021-01-11 08:28:25 --> Output Class Initialized
INFO - 2021-01-11 08:28:25 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:25 --> Input Class Initialized
INFO - 2021-01-11 08:28:25 --> Language Class Initialized
INFO - 2021-01-11 08:28:25 --> Language Class Initialized
INFO - 2021-01-11 08:28:25 --> Config Class Initialized
INFO - 2021-01-11 08:28:25 --> Loader Class Initialized
INFO - 2021-01-11 08:28:25 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:25 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:25 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:25 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:25 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:25 --> Controller Class Initialized
DEBUG - 2021-01-11 08:28:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:28:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:28:25 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:25 --> Total execution time: 0.3515
INFO - 2021-01-11 08:28:25 --> Config Class Initialized
INFO - 2021-01-11 08:28:25 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:25 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:25 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:25 --> URI Class Initialized
INFO - 2021-01-11 08:28:25 --> Router Class Initialized
INFO - 2021-01-11 08:28:25 --> Output Class Initialized
INFO - 2021-01-11 08:28:25 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:25 --> Input Class Initialized
INFO - 2021-01-11 08:28:25 --> Language Class Initialized
INFO - 2021-01-11 08:28:26 --> Language Class Initialized
INFO - 2021-01-11 08:28:26 --> Config Class Initialized
INFO - 2021-01-11 08:28:26 --> Loader Class Initialized
INFO - 2021-01-11 08:28:26 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:26 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:26 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:26 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:26 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:26 --> Controller Class Initialized
INFO - 2021-01-11 08:28:27 --> Config Class Initialized
INFO - 2021-01-11 08:28:27 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:27 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:27 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:27 --> URI Class Initialized
INFO - 2021-01-11 08:28:27 --> Router Class Initialized
INFO - 2021-01-11 08:28:27 --> Output Class Initialized
INFO - 2021-01-11 08:28:27 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:27 --> Input Class Initialized
INFO - 2021-01-11 08:28:27 --> Language Class Initialized
INFO - 2021-01-11 08:28:27 --> Language Class Initialized
INFO - 2021-01-11 08:28:27 --> Config Class Initialized
INFO - 2021-01-11 08:28:27 --> Loader Class Initialized
INFO - 2021-01-11 08:28:27 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:27 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:27 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:27 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:27 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:27 --> Controller Class Initialized
INFO - 2021-01-11 08:28:27 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:27 --> Total execution time: 0.3018
INFO - 2021-01-11 08:28:33 --> Config Class Initialized
INFO - 2021-01-11 08:28:33 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:33 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:33 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:33 --> URI Class Initialized
INFO - 2021-01-11 08:28:33 --> Router Class Initialized
INFO - 2021-01-11 08:28:33 --> Output Class Initialized
INFO - 2021-01-11 08:28:33 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:33 --> Input Class Initialized
INFO - 2021-01-11 08:28:33 --> Language Class Initialized
INFO - 2021-01-11 08:28:33 --> Language Class Initialized
INFO - 2021-01-11 08:28:33 --> Config Class Initialized
INFO - 2021-01-11 08:28:33 --> Loader Class Initialized
INFO - 2021-01-11 08:28:33 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:33 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:33 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:33 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:33 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:33 --> Controller Class Initialized
INFO - 2021-01-11 08:28:33 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:33 --> Total execution time: 0.4339
INFO - 2021-01-11 08:28:36 --> Config Class Initialized
INFO - 2021-01-11 08:28:36 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:36 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:36 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:36 --> URI Class Initialized
INFO - 2021-01-11 08:28:36 --> Router Class Initialized
INFO - 2021-01-11 08:28:36 --> Output Class Initialized
INFO - 2021-01-11 08:28:36 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:36 --> Input Class Initialized
INFO - 2021-01-11 08:28:36 --> Language Class Initialized
INFO - 2021-01-11 08:28:36 --> Language Class Initialized
INFO - 2021-01-11 08:28:36 --> Config Class Initialized
INFO - 2021-01-11 08:28:36 --> Loader Class Initialized
INFO - 2021-01-11 08:28:36 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:36 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:36 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:36 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:36 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:36 --> Controller Class Initialized
INFO - 2021-01-11 08:28:36 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:36 --> Total execution time: 0.3122
INFO - 2021-01-11 08:28:43 --> Config Class Initialized
INFO - 2021-01-11 08:28:43 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:43 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:43 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:43 --> URI Class Initialized
INFO - 2021-01-11 08:28:43 --> Router Class Initialized
INFO - 2021-01-11 08:28:43 --> Output Class Initialized
INFO - 2021-01-11 08:28:43 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:43 --> Input Class Initialized
INFO - 2021-01-11 08:28:43 --> Language Class Initialized
INFO - 2021-01-11 08:28:43 --> Language Class Initialized
INFO - 2021-01-11 08:28:43 --> Config Class Initialized
INFO - 2021-01-11 08:28:43 --> Loader Class Initialized
INFO - 2021-01-11 08:28:43 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:43 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:43 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:43 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:43 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:43 --> Controller Class Initialized
INFO - 2021-01-11 08:28:43 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:43 --> Total execution time: 0.4105
INFO - 2021-01-11 08:28:47 --> Config Class Initialized
INFO - 2021-01-11 08:28:47 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:47 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:47 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:47 --> URI Class Initialized
INFO - 2021-01-11 08:28:47 --> Router Class Initialized
INFO - 2021-01-11 08:28:47 --> Output Class Initialized
INFO - 2021-01-11 08:28:47 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:47 --> Input Class Initialized
INFO - 2021-01-11 08:28:47 --> Language Class Initialized
INFO - 2021-01-11 08:28:47 --> Language Class Initialized
INFO - 2021-01-11 08:28:47 --> Config Class Initialized
INFO - 2021-01-11 08:28:47 --> Loader Class Initialized
INFO - 2021-01-11 08:28:47 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:47 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:47 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:47 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:47 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:47 --> Controller Class Initialized
INFO - 2021-01-11 08:28:47 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:47 --> Total execution time: 0.2851
INFO - 2021-01-11 08:28:56 --> Config Class Initialized
INFO - 2021-01-11 08:28:56 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:28:56 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:28:56 --> Utf8 Class Initialized
INFO - 2021-01-11 08:28:56 --> URI Class Initialized
INFO - 2021-01-11 08:28:57 --> Router Class Initialized
INFO - 2021-01-11 08:28:57 --> Output Class Initialized
INFO - 2021-01-11 08:28:57 --> Security Class Initialized
DEBUG - 2021-01-11 08:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:28:57 --> Input Class Initialized
INFO - 2021-01-11 08:28:57 --> Language Class Initialized
INFO - 2021-01-11 08:28:57 --> Language Class Initialized
INFO - 2021-01-11 08:28:57 --> Config Class Initialized
INFO - 2021-01-11 08:28:57 --> Loader Class Initialized
INFO - 2021-01-11 08:28:57 --> Helper loaded: url_helper
INFO - 2021-01-11 08:28:57 --> Helper loaded: file_helper
INFO - 2021-01-11 08:28:57 --> Helper loaded: form_helper
INFO - 2021-01-11 08:28:57 --> Helper loaded: my_helper
INFO - 2021-01-11 08:28:57 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:28:57 --> Controller Class Initialized
INFO - 2021-01-11 08:28:57 --> Final output sent to browser
DEBUG - 2021-01-11 08:28:57 --> Total execution time: 0.4486
INFO - 2021-01-11 08:29:02 --> Config Class Initialized
INFO - 2021-01-11 08:29:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:02 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:02 --> URI Class Initialized
INFO - 2021-01-11 08:29:02 --> Router Class Initialized
INFO - 2021-01-11 08:29:02 --> Output Class Initialized
INFO - 2021-01-11 08:29:02 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:02 --> Input Class Initialized
INFO - 2021-01-11 08:29:02 --> Language Class Initialized
INFO - 2021-01-11 08:29:02 --> Language Class Initialized
INFO - 2021-01-11 08:29:02 --> Config Class Initialized
INFO - 2021-01-11 08:29:02 --> Loader Class Initialized
INFO - 2021-01-11 08:29:02 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:02 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:02 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:02 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:02 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:02 --> Controller Class Initialized
INFO - 2021-01-11 08:29:02 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:02 --> Total execution time: 0.3067
INFO - 2021-01-11 08:29:09 --> Config Class Initialized
INFO - 2021-01-11 08:29:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:09 --> URI Class Initialized
INFO - 2021-01-11 08:29:09 --> Router Class Initialized
INFO - 2021-01-11 08:29:09 --> Output Class Initialized
INFO - 2021-01-11 08:29:09 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:09 --> Input Class Initialized
INFO - 2021-01-11 08:29:09 --> Language Class Initialized
INFO - 2021-01-11 08:29:09 --> Language Class Initialized
INFO - 2021-01-11 08:29:09 --> Config Class Initialized
INFO - 2021-01-11 08:29:09 --> Loader Class Initialized
INFO - 2021-01-11 08:29:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:09 --> Controller Class Initialized
INFO - 2021-01-11 08:29:09 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:09 --> Total execution time: 0.3753
INFO - 2021-01-11 08:29:19 --> Config Class Initialized
INFO - 2021-01-11 08:29:19 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:19 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:19 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:19 --> URI Class Initialized
INFO - 2021-01-11 08:29:19 --> Router Class Initialized
INFO - 2021-01-11 08:29:19 --> Output Class Initialized
INFO - 2021-01-11 08:29:19 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:19 --> Input Class Initialized
INFO - 2021-01-11 08:29:19 --> Language Class Initialized
INFO - 2021-01-11 08:29:19 --> Language Class Initialized
INFO - 2021-01-11 08:29:19 --> Config Class Initialized
INFO - 2021-01-11 08:29:19 --> Loader Class Initialized
INFO - 2021-01-11 08:29:19 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:19 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:19 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:19 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:19 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:19 --> Controller Class Initialized
DEBUG - 2021-01-11 08:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:29:19 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:19 --> Total execution time: 0.4173
INFO - 2021-01-11 08:29:19 --> Config Class Initialized
INFO - 2021-01-11 08:29:19 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:19 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:19 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:19 --> URI Class Initialized
INFO - 2021-01-11 08:29:19 --> Router Class Initialized
INFO - 2021-01-11 08:29:19 --> Output Class Initialized
INFO - 2021-01-11 08:29:19 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:19 --> Input Class Initialized
INFO - 2021-01-11 08:29:19 --> Language Class Initialized
INFO - 2021-01-11 08:29:19 --> Language Class Initialized
INFO - 2021-01-11 08:29:20 --> Config Class Initialized
INFO - 2021-01-11 08:29:20 --> Loader Class Initialized
INFO - 2021-01-11 08:29:20 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:20 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:20 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:20 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:20 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:20 --> Controller Class Initialized
INFO - 2021-01-11 08:29:23 --> Config Class Initialized
INFO - 2021-01-11 08:29:23 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:23 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:23 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:23 --> URI Class Initialized
INFO - 2021-01-11 08:29:23 --> Router Class Initialized
INFO - 2021-01-11 08:29:23 --> Output Class Initialized
INFO - 2021-01-11 08:29:23 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:23 --> Input Class Initialized
INFO - 2021-01-11 08:29:23 --> Language Class Initialized
INFO - 2021-01-11 08:29:23 --> Language Class Initialized
INFO - 2021-01-11 08:29:23 --> Config Class Initialized
INFO - 2021-01-11 08:29:23 --> Loader Class Initialized
INFO - 2021-01-11 08:29:23 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:23 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:23 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:23 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:23 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:23 --> Controller Class Initialized
INFO - 2021-01-11 08:29:23 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:23 --> Total execution time: 0.3284
INFO - 2021-01-11 08:29:25 --> Config Class Initialized
INFO - 2021-01-11 08:29:25 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:25 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:25 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:25 --> URI Class Initialized
INFO - 2021-01-11 08:29:25 --> Router Class Initialized
INFO - 2021-01-11 08:29:25 --> Output Class Initialized
INFO - 2021-01-11 08:29:25 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:25 --> Input Class Initialized
INFO - 2021-01-11 08:29:25 --> Language Class Initialized
INFO - 2021-01-11 08:29:25 --> Language Class Initialized
INFO - 2021-01-11 08:29:25 --> Config Class Initialized
INFO - 2021-01-11 08:29:25 --> Loader Class Initialized
INFO - 2021-01-11 08:29:25 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:25 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:25 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:25 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:25 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:25 --> Controller Class Initialized
DEBUG - 2021-01-11 08:29:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:29:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:29:25 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:25 --> Total execution time: 0.3973
INFO - 2021-01-11 08:29:30 --> Config Class Initialized
INFO - 2021-01-11 08:29:30 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:30 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:30 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:30 --> URI Class Initialized
INFO - 2021-01-11 08:29:30 --> Router Class Initialized
INFO - 2021-01-11 08:29:30 --> Output Class Initialized
INFO - 2021-01-11 08:29:30 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:30 --> Input Class Initialized
INFO - 2021-01-11 08:29:30 --> Language Class Initialized
INFO - 2021-01-11 08:29:30 --> Language Class Initialized
INFO - 2021-01-11 08:29:30 --> Config Class Initialized
INFO - 2021-01-11 08:29:30 --> Loader Class Initialized
INFO - 2021-01-11 08:29:30 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:30 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:30 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:30 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:30 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:30 --> Controller Class Initialized
DEBUG - 2021-01-11 08:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:29:30 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:30 --> Total execution time: 0.3460
INFO - 2021-01-11 08:29:32 --> Config Class Initialized
INFO - 2021-01-11 08:29:32 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:32 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:32 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:32 --> URI Class Initialized
INFO - 2021-01-11 08:29:32 --> Router Class Initialized
INFO - 2021-01-11 08:29:32 --> Output Class Initialized
INFO - 2021-01-11 08:29:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:32 --> Input Class Initialized
INFO - 2021-01-11 08:29:32 --> Language Class Initialized
INFO - 2021-01-11 08:29:32 --> Language Class Initialized
INFO - 2021-01-11 08:29:32 --> Config Class Initialized
INFO - 2021-01-11 08:29:32 --> Loader Class Initialized
INFO - 2021-01-11 08:29:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:32 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:32 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:32 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:32 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:32 --> Controller Class Initialized
INFO - 2021-01-11 08:29:32 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:32 --> Total execution time: 0.3218
INFO - 2021-01-11 08:29:38 --> Config Class Initialized
INFO - 2021-01-11 08:29:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:38 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:38 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:38 --> URI Class Initialized
INFO - 2021-01-11 08:29:38 --> Router Class Initialized
INFO - 2021-01-11 08:29:38 --> Output Class Initialized
INFO - 2021-01-11 08:29:38 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:38 --> Input Class Initialized
INFO - 2021-01-11 08:29:38 --> Language Class Initialized
INFO - 2021-01-11 08:29:39 --> Language Class Initialized
INFO - 2021-01-11 08:29:39 --> Config Class Initialized
INFO - 2021-01-11 08:29:39 --> Loader Class Initialized
INFO - 2021-01-11 08:29:39 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:39 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:39 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:39 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:39 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:39 --> Controller Class Initialized
INFO - 2021-01-11 08:29:39 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:39 --> Total execution time: 0.4020
INFO - 2021-01-11 08:29:42 --> Config Class Initialized
INFO - 2021-01-11 08:29:42 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:42 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:42 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:42 --> URI Class Initialized
INFO - 2021-01-11 08:29:42 --> Router Class Initialized
INFO - 2021-01-11 08:29:42 --> Output Class Initialized
INFO - 2021-01-11 08:29:42 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:42 --> Input Class Initialized
INFO - 2021-01-11 08:29:42 --> Language Class Initialized
INFO - 2021-01-11 08:29:42 --> Language Class Initialized
INFO - 2021-01-11 08:29:42 --> Config Class Initialized
INFO - 2021-01-11 08:29:42 --> Loader Class Initialized
INFO - 2021-01-11 08:29:42 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:42 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:42 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:42 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:42 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:42 --> Controller Class Initialized
INFO - 2021-01-11 08:29:42 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:42 --> Total execution time: 0.3099
INFO - 2021-01-11 08:29:48 --> Config Class Initialized
INFO - 2021-01-11 08:29:48 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:48 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:48 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:48 --> URI Class Initialized
INFO - 2021-01-11 08:29:48 --> Router Class Initialized
INFO - 2021-01-11 08:29:48 --> Output Class Initialized
INFO - 2021-01-11 08:29:48 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:48 --> Input Class Initialized
INFO - 2021-01-11 08:29:48 --> Language Class Initialized
INFO - 2021-01-11 08:29:48 --> Language Class Initialized
INFO - 2021-01-11 08:29:48 --> Config Class Initialized
INFO - 2021-01-11 08:29:48 --> Loader Class Initialized
INFO - 2021-01-11 08:29:48 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:48 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:48 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:48 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:48 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:48 --> Controller Class Initialized
INFO - 2021-01-11 08:29:48 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:48 --> Total execution time: 0.4039
INFO - 2021-01-11 08:29:59 --> Config Class Initialized
INFO - 2021-01-11 08:29:59 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:29:59 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:29:59 --> Utf8 Class Initialized
INFO - 2021-01-11 08:29:59 --> URI Class Initialized
INFO - 2021-01-11 08:29:59 --> Router Class Initialized
INFO - 2021-01-11 08:29:59 --> Output Class Initialized
INFO - 2021-01-11 08:29:59 --> Security Class Initialized
DEBUG - 2021-01-11 08:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:29:59 --> Input Class Initialized
INFO - 2021-01-11 08:29:59 --> Language Class Initialized
INFO - 2021-01-11 08:29:59 --> Language Class Initialized
INFO - 2021-01-11 08:29:59 --> Config Class Initialized
INFO - 2021-01-11 08:29:59 --> Loader Class Initialized
INFO - 2021-01-11 08:29:59 --> Helper loaded: url_helper
INFO - 2021-01-11 08:29:59 --> Helper loaded: file_helper
INFO - 2021-01-11 08:29:59 --> Helper loaded: form_helper
INFO - 2021-01-11 08:29:59 --> Helper loaded: my_helper
INFO - 2021-01-11 08:29:59 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:29:59 --> Controller Class Initialized
DEBUG - 2021-01-11 08:29:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:29:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:29:59 --> Final output sent to browser
DEBUG - 2021-01-11 08:29:59 --> Total execution time: 0.4322
INFO - 2021-01-11 08:30:07 --> Config Class Initialized
INFO - 2021-01-11 08:30:07 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:07 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:07 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:07 --> URI Class Initialized
INFO - 2021-01-11 08:30:07 --> Router Class Initialized
INFO - 2021-01-11 08:30:07 --> Output Class Initialized
INFO - 2021-01-11 08:30:07 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:07 --> Input Class Initialized
INFO - 2021-01-11 08:30:07 --> Language Class Initialized
INFO - 2021-01-11 08:30:07 --> Language Class Initialized
INFO - 2021-01-11 08:30:07 --> Config Class Initialized
INFO - 2021-01-11 08:30:07 --> Loader Class Initialized
INFO - 2021-01-11 08:30:07 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:07 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:07 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:07 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:07 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:07 --> Controller Class Initialized
DEBUG - 2021-01-11 08:30:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:30:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:30:07 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:07 --> Total execution time: 0.3618
INFO - 2021-01-11 08:30:09 --> Config Class Initialized
INFO - 2021-01-11 08:30:09 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:09 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:09 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:09 --> URI Class Initialized
INFO - 2021-01-11 08:30:09 --> Router Class Initialized
INFO - 2021-01-11 08:30:09 --> Output Class Initialized
INFO - 2021-01-11 08:30:09 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:09 --> Input Class Initialized
INFO - 2021-01-11 08:30:09 --> Language Class Initialized
INFO - 2021-01-11 08:30:09 --> Language Class Initialized
INFO - 2021-01-11 08:30:09 --> Config Class Initialized
INFO - 2021-01-11 08:30:09 --> Loader Class Initialized
INFO - 2021-01-11 08:30:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:09 --> Controller Class Initialized
INFO - 2021-01-11 08:30:09 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:09 --> Total execution time: 0.3011
INFO - 2021-01-11 08:30:11 --> Config Class Initialized
INFO - 2021-01-11 08:30:11 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:11 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:11 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:11 --> URI Class Initialized
INFO - 2021-01-11 08:30:11 --> Router Class Initialized
INFO - 2021-01-11 08:30:11 --> Output Class Initialized
INFO - 2021-01-11 08:30:11 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:11 --> Input Class Initialized
INFO - 2021-01-11 08:30:11 --> Language Class Initialized
INFO - 2021-01-11 08:30:11 --> Language Class Initialized
INFO - 2021-01-11 08:30:11 --> Config Class Initialized
INFO - 2021-01-11 08:30:11 --> Loader Class Initialized
INFO - 2021-01-11 08:30:11 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:11 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:11 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:11 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:11 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:11 --> Controller Class Initialized
DEBUG - 2021-01-11 08:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:30:11 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:11 --> Total execution time: 0.4240
INFO - 2021-01-11 08:30:15 --> Config Class Initialized
INFO - 2021-01-11 08:30:15 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:15 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:15 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:15 --> URI Class Initialized
INFO - 2021-01-11 08:30:15 --> Router Class Initialized
INFO - 2021-01-11 08:30:15 --> Output Class Initialized
INFO - 2021-01-11 08:30:15 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:15 --> Input Class Initialized
INFO - 2021-01-11 08:30:15 --> Language Class Initialized
INFO - 2021-01-11 08:30:15 --> Language Class Initialized
INFO - 2021-01-11 08:30:15 --> Config Class Initialized
INFO - 2021-01-11 08:30:15 --> Loader Class Initialized
INFO - 2021-01-11 08:30:15 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:15 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:15 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:15 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:15 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:15 --> Controller Class Initialized
DEBUG - 2021-01-11 08:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:30:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:30:15 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:15 --> Total execution time: 0.3811
INFO - 2021-01-11 08:30:16 --> Config Class Initialized
INFO - 2021-01-11 08:30:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:16 --> URI Class Initialized
INFO - 2021-01-11 08:30:16 --> Router Class Initialized
INFO - 2021-01-11 08:30:16 --> Output Class Initialized
INFO - 2021-01-11 08:30:16 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:16 --> Input Class Initialized
INFO - 2021-01-11 08:30:16 --> Language Class Initialized
INFO - 2021-01-11 08:30:16 --> Language Class Initialized
INFO - 2021-01-11 08:30:16 --> Config Class Initialized
INFO - 2021-01-11 08:30:16 --> Loader Class Initialized
INFO - 2021-01-11 08:30:16 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:16 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:16 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:16 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:16 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:16 --> Controller Class Initialized
INFO - 2021-01-11 08:30:21 --> Config Class Initialized
INFO - 2021-01-11 08:30:21 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:21 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:21 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:21 --> URI Class Initialized
INFO - 2021-01-11 08:30:21 --> Router Class Initialized
INFO - 2021-01-11 08:30:21 --> Output Class Initialized
INFO - 2021-01-11 08:30:21 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:21 --> Input Class Initialized
INFO - 2021-01-11 08:30:21 --> Language Class Initialized
INFO - 2021-01-11 08:30:21 --> Language Class Initialized
INFO - 2021-01-11 08:30:21 --> Config Class Initialized
INFO - 2021-01-11 08:30:21 --> Loader Class Initialized
INFO - 2021-01-11 08:30:21 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:21 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:21 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:21 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:21 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:21 --> Controller Class Initialized
INFO - 2021-01-11 08:30:21 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:21 --> Total execution time: 0.3157
INFO - 2021-01-11 08:30:34 --> Config Class Initialized
INFO - 2021-01-11 08:30:34 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:34 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:34 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:34 --> URI Class Initialized
INFO - 2021-01-11 08:30:34 --> Router Class Initialized
INFO - 2021-01-11 08:30:34 --> Output Class Initialized
INFO - 2021-01-11 08:30:34 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:34 --> Input Class Initialized
INFO - 2021-01-11 08:30:34 --> Language Class Initialized
INFO - 2021-01-11 08:30:34 --> Language Class Initialized
INFO - 2021-01-11 08:30:34 --> Config Class Initialized
INFO - 2021-01-11 08:30:34 --> Loader Class Initialized
INFO - 2021-01-11 08:30:35 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:35 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:35 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:35 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:35 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:35 --> Controller Class Initialized
INFO - 2021-01-11 08:30:35 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:35 --> Total execution time: 0.4045
INFO - 2021-01-11 08:30:38 --> Config Class Initialized
INFO - 2021-01-11 08:30:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:38 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:38 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:38 --> URI Class Initialized
INFO - 2021-01-11 08:30:38 --> Router Class Initialized
INFO - 2021-01-11 08:30:38 --> Output Class Initialized
INFO - 2021-01-11 08:30:38 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:38 --> Input Class Initialized
INFO - 2021-01-11 08:30:38 --> Language Class Initialized
INFO - 2021-01-11 08:30:38 --> Language Class Initialized
INFO - 2021-01-11 08:30:38 --> Config Class Initialized
INFO - 2021-01-11 08:30:38 --> Loader Class Initialized
INFO - 2021-01-11 08:30:38 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:38 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:38 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:38 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:38 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:38 --> Controller Class Initialized
INFO - 2021-01-11 08:30:38 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:38 --> Total execution time: 0.3027
INFO - 2021-01-11 08:30:43 --> Config Class Initialized
INFO - 2021-01-11 08:30:43 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:43 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:43 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:43 --> URI Class Initialized
INFO - 2021-01-11 08:30:43 --> Router Class Initialized
INFO - 2021-01-11 08:30:43 --> Output Class Initialized
INFO - 2021-01-11 08:30:43 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:43 --> Input Class Initialized
INFO - 2021-01-11 08:30:43 --> Language Class Initialized
INFO - 2021-01-11 08:30:43 --> Language Class Initialized
INFO - 2021-01-11 08:30:43 --> Config Class Initialized
INFO - 2021-01-11 08:30:43 --> Loader Class Initialized
INFO - 2021-01-11 08:30:43 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:43 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:43 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:43 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:43 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:43 --> Controller Class Initialized
INFO - 2021-01-11 08:30:44 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:44 --> Total execution time: 0.4115
INFO - 2021-01-11 08:30:46 --> Config Class Initialized
INFO - 2021-01-11 08:30:46 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:46 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:46 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:46 --> URI Class Initialized
INFO - 2021-01-11 08:30:46 --> Router Class Initialized
INFO - 2021-01-11 08:30:46 --> Output Class Initialized
INFO - 2021-01-11 08:30:46 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:46 --> Input Class Initialized
INFO - 2021-01-11 08:30:47 --> Language Class Initialized
INFO - 2021-01-11 08:30:47 --> Language Class Initialized
INFO - 2021-01-11 08:30:47 --> Config Class Initialized
INFO - 2021-01-11 08:30:47 --> Loader Class Initialized
INFO - 2021-01-11 08:30:47 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:47 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:47 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:47 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:47 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:47 --> Controller Class Initialized
INFO - 2021-01-11 08:30:47 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:47 --> Total execution time: 0.3150
INFO - 2021-01-11 08:30:50 --> Config Class Initialized
INFO - 2021-01-11 08:30:50 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:50 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:50 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:50 --> URI Class Initialized
INFO - 2021-01-11 08:30:50 --> Router Class Initialized
INFO - 2021-01-11 08:30:50 --> Output Class Initialized
INFO - 2021-01-11 08:30:50 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:51 --> Input Class Initialized
INFO - 2021-01-11 08:30:51 --> Language Class Initialized
INFO - 2021-01-11 08:30:51 --> Language Class Initialized
INFO - 2021-01-11 08:30:51 --> Config Class Initialized
INFO - 2021-01-11 08:30:51 --> Loader Class Initialized
INFO - 2021-01-11 08:30:51 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:51 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:51 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:51 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:51 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:51 --> Controller Class Initialized
INFO - 2021-01-11 08:30:51 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:51 --> Total execution time: 0.4032
INFO - 2021-01-11 08:30:53 --> Config Class Initialized
INFO - 2021-01-11 08:30:53 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:30:53 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:30:53 --> Utf8 Class Initialized
INFO - 2021-01-11 08:30:53 --> URI Class Initialized
INFO - 2021-01-11 08:30:53 --> Router Class Initialized
INFO - 2021-01-11 08:30:53 --> Output Class Initialized
INFO - 2021-01-11 08:30:53 --> Security Class Initialized
DEBUG - 2021-01-11 08:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:30:53 --> Input Class Initialized
INFO - 2021-01-11 08:30:53 --> Language Class Initialized
INFO - 2021-01-11 08:30:53 --> Language Class Initialized
INFO - 2021-01-11 08:30:53 --> Config Class Initialized
INFO - 2021-01-11 08:30:53 --> Loader Class Initialized
INFO - 2021-01-11 08:30:53 --> Helper loaded: url_helper
INFO - 2021-01-11 08:30:53 --> Helper loaded: file_helper
INFO - 2021-01-11 08:30:53 --> Helper loaded: form_helper
INFO - 2021-01-11 08:30:53 --> Helper loaded: my_helper
INFO - 2021-01-11 08:30:53 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:30:53 --> Controller Class Initialized
INFO - 2021-01-11 08:30:53 --> Final output sent to browser
DEBUG - 2021-01-11 08:30:53 --> Total execution time: 0.2878
INFO - 2021-01-11 08:31:07 --> Config Class Initialized
INFO - 2021-01-11 08:31:07 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:07 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:07 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:07 --> URI Class Initialized
INFO - 2021-01-11 08:31:07 --> Router Class Initialized
INFO - 2021-01-11 08:31:07 --> Output Class Initialized
INFO - 2021-01-11 08:31:07 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:07 --> Input Class Initialized
INFO - 2021-01-11 08:31:07 --> Language Class Initialized
INFO - 2021-01-11 08:31:07 --> Language Class Initialized
INFO - 2021-01-11 08:31:07 --> Config Class Initialized
INFO - 2021-01-11 08:31:07 --> Loader Class Initialized
INFO - 2021-01-11 08:31:07 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:07 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:07 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:07 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:07 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:07 --> Controller Class Initialized
INFO - 2021-01-11 08:31:07 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:07 --> Total execution time: 0.4176
INFO - 2021-01-11 08:31:10 --> Config Class Initialized
INFO - 2021-01-11 08:31:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:10 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:10 --> URI Class Initialized
INFO - 2021-01-11 08:31:10 --> Router Class Initialized
INFO - 2021-01-11 08:31:10 --> Output Class Initialized
INFO - 2021-01-11 08:31:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:10 --> Input Class Initialized
INFO - 2021-01-11 08:31:10 --> Language Class Initialized
INFO - 2021-01-11 08:31:10 --> Language Class Initialized
INFO - 2021-01-11 08:31:10 --> Config Class Initialized
INFO - 2021-01-11 08:31:10 --> Loader Class Initialized
INFO - 2021-01-11 08:31:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:10 --> Controller Class Initialized
INFO - 2021-01-11 08:31:10 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:10 --> Total execution time: 0.3003
INFO - 2021-01-11 08:31:17 --> Config Class Initialized
INFO - 2021-01-11 08:31:17 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:17 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:17 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:17 --> URI Class Initialized
INFO - 2021-01-11 08:31:17 --> Router Class Initialized
INFO - 2021-01-11 08:31:18 --> Output Class Initialized
INFO - 2021-01-11 08:31:18 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:18 --> Input Class Initialized
INFO - 2021-01-11 08:31:18 --> Language Class Initialized
INFO - 2021-01-11 08:31:18 --> Language Class Initialized
INFO - 2021-01-11 08:31:18 --> Config Class Initialized
INFO - 2021-01-11 08:31:18 --> Loader Class Initialized
INFO - 2021-01-11 08:31:18 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:18 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:18 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:18 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:18 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:18 --> Controller Class Initialized
INFO - 2021-01-11 08:31:18 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:18 --> Total execution time: 0.3861
INFO - 2021-01-11 08:31:23 --> Config Class Initialized
INFO - 2021-01-11 08:31:23 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:23 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:23 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:23 --> URI Class Initialized
INFO - 2021-01-11 08:31:23 --> Router Class Initialized
INFO - 2021-01-11 08:31:23 --> Output Class Initialized
INFO - 2021-01-11 08:31:23 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:23 --> Input Class Initialized
INFO - 2021-01-11 08:31:23 --> Language Class Initialized
INFO - 2021-01-11 08:31:23 --> Language Class Initialized
INFO - 2021-01-11 08:31:23 --> Config Class Initialized
INFO - 2021-01-11 08:31:23 --> Loader Class Initialized
INFO - 2021-01-11 08:31:23 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:23 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:23 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:23 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:23 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:23 --> Controller Class Initialized
INFO - 2021-01-11 08:31:23 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:23 --> Total execution time: 0.3602
INFO - 2021-01-11 08:31:26 --> Config Class Initialized
INFO - 2021-01-11 08:31:26 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:26 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:26 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:26 --> URI Class Initialized
INFO - 2021-01-11 08:31:26 --> Router Class Initialized
INFO - 2021-01-11 08:31:26 --> Output Class Initialized
INFO - 2021-01-11 08:31:26 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:26 --> Input Class Initialized
INFO - 2021-01-11 08:31:26 --> Language Class Initialized
INFO - 2021-01-11 08:31:26 --> Language Class Initialized
INFO - 2021-01-11 08:31:26 --> Config Class Initialized
INFO - 2021-01-11 08:31:26 --> Loader Class Initialized
INFO - 2021-01-11 08:31:26 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:26 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:26 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:26 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:26 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:26 --> Controller Class Initialized
DEBUG - 2021-01-11 08:31:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:31:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:31:26 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:26 --> Total execution time: 0.3937
INFO - 2021-01-11 08:31:30 --> Config Class Initialized
INFO - 2021-01-11 08:31:30 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:30 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:30 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:30 --> URI Class Initialized
INFO - 2021-01-11 08:31:30 --> Router Class Initialized
INFO - 2021-01-11 08:31:30 --> Output Class Initialized
INFO - 2021-01-11 08:31:30 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:30 --> Input Class Initialized
INFO - 2021-01-11 08:31:30 --> Language Class Initialized
INFO - 2021-01-11 08:31:30 --> Language Class Initialized
INFO - 2021-01-11 08:31:30 --> Config Class Initialized
INFO - 2021-01-11 08:31:30 --> Loader Class Initialized
INFO - 2021-01-11 08:31:30 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:30 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:30 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:30 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:30 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:30 --> Controller Class Initialized
DEBUG - 2021-01-11 08:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-11 08:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:31:30 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:30 --> Total execution time: 0.3578
INFO - 2021-01-11 08:31:32 --> Config Class Initialized
INFO - 2021-01-11 08:31:32 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:32 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:32 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:32 --> URI Class Initialized
INFO - 2021-01-11 08:31:32 --> Router Class Initialized
INFO - 2021-01-11 08:31:32 --> Output Class Initialized
INFO - 2021-01-11 08:31:32 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:32 --> Input Class Initialized
INFO - 2021-01-11 08:31:32 --> Language Class Initialized
INFO - 2021-01-11 08:31:32 --> Language Class Initialized
INFO - 2021-01-11 08:31:32 --> Config Class Initialized
INFO - 2021-01-11 08:31:32 --> Loader Class Initialized
INFO - 2021-01-11 08:31:32 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:32 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:32 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:32 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:32 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:32 --> Controller Class Initialized
INFO - 2021-01-11 08:31:32 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:32 --> Total execution time: 0.3357
INFO - 2021-01-11 08:31:38 --> Config Class Initialized
INFO - 2021-01-11 08:31:38 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:38 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:38 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:38 --> URI Class Initialized
INFO - 2021-01-11 08:31:38 --> Router Class Initialized
INFO - 2021-01-11 08:31:38 --> Output Class Initialized
INFO - 2021-01-11 08:31:38 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:38 --> Input Class Initialized
INFO - 2021-01-11 08:31:38 --> Language Class Initialized
INFO - 2021-01-11 08:31:38 --> Language Class Initialized
INFO - 2021-01-11 08:31:38 --> Config Class Initialized
INFO - 2021-01-11 08:31:38 --> Loader Class Initialized
INFO - 2021-01-11 08:31:38 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:38 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:38 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:38 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:38 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:38 --> Controller Class Initialized
INFO - 2021-01-11 08:31:38 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:38 --> Total execution time: 0.4108
INFO - 2021-01-11 08:31:40 --> Config Class Initialized
INFO - 2021-01-11 08:31:40 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:40 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:40 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:40 --> URI Class Initialized
INFO - 2021-01-11 08:31:40 --> Router Class Initialized
INFO - 2021-01-11 08:31:40 --> Output Class Initialized
INFO - 2021-01-11 08:31:41 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:41 --> Input Class Initialized
INFO - 2021-01-11 08:31:41 --> Language Class Initialized
INFO - 2021-01-11 08:31:41 --> Language Class Initialized
INFO - 2021-01-11 08:31:41 --> Config Class Initialized
INFO - 2021-01-11 08:31:41 --> Loader Class Initialized
INFO - 2021-01-11 08:31:41 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:41 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:41 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:41 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:41 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:41 --> Controller Class Initialized
INFO - 2021-01-11 08:31:41 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:41 --> Total execution time: 0.3263
INFO - 2021-01-11 08:31:49 --> Config Class Initialized
INFO - 2021-01-11 08:31:49 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:31:49 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:31:49 --> Utf8 Class Initialized
INFO - 2021-01-11 08:31:49 --> URI Class Initialized
INFO - 2021-01-11 08:31:49 --> Router Class Initialized
INFO - 2021-01-11 08:31:49 --> Output Class Initialized
INFO - 2021-01-11 08:31:49 --> Security Class Initialized
DEBUG - 2021-01-11 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:31:49 --> Input Class Initialized
INFO - 2021-01-11 08:31:49 --> Language Class Initialized
INFO - 2021-01-11 08:31:49 --> Language Class Initialized
INFO - 2021-01-11 08:31:49 --> Config Class Initialized
INFO - 2021-01-11 08:31:49 --> Loader Class Initialized
INFO - 2021-01-11 08:31:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:31:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:31:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:31:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:31:49 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:31:49 --> Controller Class Initialized
INFO - 2021-01-11 08:31:49 --> Final output sent to browser
DEBUG - 2021-01-11 08:31:49 --> Total execution time: 0.3876
INFO - 2021-01-11 08:37:51 --> Config Class Initialized
INFO - 2021-01-11 08:37:51 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:37:51 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:37:51 --> Utf8 Class Initialized
INFO - 2021-01-11 08:37:51 --> URI Class Initialized
INFO - 2021-01-11 08:37:51 --> Router Class Initialized
INFO - 2021-01-11 08:37:51 --> Output Class Initialized
INFO - 2021-01-11 08:37:51 --> Security Class Initialized
DEBUG - 2021-01-11 08:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:37:51 --> Input Class Initialized
INFO - 2021-01-11 08:37:51 --> Language Class Initialized
ERROR - 2021-01-11 08:37:51 --> Severity: Parsing Error --> syntax error, unexpected '$d' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 3176
INFO - 2021-01-11 08:38:16 --> Config Class Initialized
INFO - 2021-01-11 08:38:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:38:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:38:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:38:16 --> URI Class Initialized
INFO - 2021-01-11 08:38:17 --> Router Class Initialized
INFO - 2021-01-11 08:38:17 --> Output Class Initialized
INFO - 2021-01-11 08:38:17 --> Security Class Initialized
DEBUG - 2021-01-11 08:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:38:17 --> Input Class Initialized
INFO - 2021-01-11 08:38:17 --> Language Class Initialized
INFO - 2021-01-11 08:38:17 --> Language Class Initialized
INFO - 2021-01-11 08:38:17 --> Config Class Initialized
INFO - 2021-01-11 08:38:17 --> Loader Class Initialized
INFO - 2021-01-11 08:38:17 --> Helper loaded: url_helper
INFO - 2021-01-11 08:38:17 --> Helper loaded: file_helper
INFO - 2021-01-11 08:38:17 --> Helper loaded: form_helper
INFO - 2021-01-11 08:38:17 --> Helper loaded: my_helper
INFO - 2021-01-11 08:38:17 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:38:17 --> Controller Class Initialized
DEBUG - 2021-01-11 08:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:38:17 --> Final output sent to browser
DEBUG - 2021-01-11 08:38:17 --> Total execution time: 0.3798
INFO - 2021-01-11 08:41:10 --> Config Class Initialized
INFO - 2021-01-11 08:41:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:41:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:41:10 --> Utf8 Class Initialized
INFO - 2021-01-11 08:41:10 --> URI Class Initialized
INFO - 2021-01-11 08:41:10 --> Router Class Initialized
INFO - 2021-01-11 08:41:10 --> Output Class Initialized
INFO - 2021-01-11 08:41:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:41:10 --> Input Class Initialized
INFO - 2021-01-11 08:41:10 --> Language Class Initialized
INFO - 2021-01-11 08:41:10 --> Language Class Initialized
INFO - 2021-01-11 08:41:10 --> Config Class Initialized
INFO - 2021-01-11 08:41:10 --> Loader Class Initialized
INFO - 2021-01-11 08:41:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:41:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:41:10 --> Helper loaded: form_helper
INFO - 2021-01-11 08:41:10 --> Helper loaded: my_helper
INFO - 2021-01-11 08:41:10 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:41:10 --> Controller Class Initialized
DEBUG - 2021-01-11 08:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:41:11 --> Final output sent to browser
DEBUG - 2021-01-11 08:41:11 --> Total execution time: 0.3839
INFO - 2021-01-11 08:45:20 --> Config Class Initialized
INFO - 2021-01-11 08:45:20 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:45:20 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:45:20 --> Utf8 Class Initialized
INFO - 2021-01-11 08:45:20 --> URI Class Initialized
INFO - 2021-01-11 08:45:20 --> Router Class Initialized
INFO - 2021-01-11 08:45:20 --> Output Class Initialized
INFO - 2021-01-11 08:45:20 --> Security Class Initialized
DEBUG - 2021-01-11 08:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:45:20 --> Input Class Initialized
INFO - 2021-01-11 08:45:20 --> Language Class Initialized
INFO - 2021-01-11 08:45:20 --> Language Class Initialized
INFO - 2021-01-11 08:45:20 --> Config Class Initialized
INFO - 2021-01-11 08:45:20 --> Loader Class Initialized
INFO - 2021-01-11 08:45:20 --> Helper loaded: url_helper
INFO - 2021-01-11 08:45:20 --> Helper loaded: file_helper
INFO - 2021-01-11 08:45:20 --> Helper loaded: form_helper
INFO - 2021-01-11 08:45:20 --> Helper loaded: my_helper
INFO - 2021-01-11 08:45:20 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:45:20 --> Controller Class Initialized
DEBUG - 2021-01-11 08:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:45:20 --> Final output sent to browser
DEBUG - 2021-01-11 08:45:20 --> Total execution time: 0.3840
INFO - 2021-01-11 08:47:33 --> Config Class Initialized
INFO - 2021-01-11 08:47:33 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:47:33 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:47:33 --> Utf8 Class Initialized
INFO - 2021-01-11 08:47:33 --> URI Class Initialized
INFO - 2021-01-11 08:47:33 --> Router Class Initialized
INFO - 2021-01-11 08:47:33 --> Output Class Initialized
INFO - 2021-01-11 08:47:33 --> Security Class Initialized
DEBUG - 2021-01-11 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:47:33 --> Input Class Initialized
INFO - 2021-01-11 08:47:33 --> Language Class Initialized
INFO - 2021-01-11 08:47:33 --> Language Class Initialized
INFO - 2021-01-11 08:47:33 --> Config Class Initialized
INFO - 2021-01-11 08:47:33 --> Loader Class Initialized
INFO - 2021-01-11 08:47:33 --> Helper loaded: url_helper
INFO - 2021-01-11 08:47:33 --> Helper loaded: file_helper
INFO - 2021-01-11 08:47:33 --> Helper loaded: form_helper
INFO - 2021-01-11 08:47:33 --> Helper loaded: my_helper
INFO - 2021-01-11 08:47:33 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:47:33 --> Controller Class Initialized
DEBUG - 2021-01-11 08:47:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:47:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:47:33 --> Final output sent to browser
DEBUG - 2021-01-11 08:47:33 --> Total execution time: 0.3567
INFO - 2021-01-11 08:48:06 --> Config Class Initialized
INFO - 2021-01-11 08:48:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:48:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:48:06 --> Utf8 Class Initialized
INFO - 2021-01-11 08:48:06 --> URI Class Initialized
INFO - 2021-01-11 08:48:06 --> Router Class Initialized
INFO - 2021-01-11 08:48:06 --> Output Class Initialized
INFO - 2021-01-11 08:48:06 --> Security Class Initialized
DEBUG - 2021-01-11 08:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:48:06 --> Input Class Initialized
INFO - 2021-01-11 08:48:06 --> Language Class Initialized
INFO - 2021-01-11 08:48:06 --> Language Class Initialized
INFO - 2021-01-11 08:48:06 --> Config Class Initialized
INFO - 2021-01-11 08:48:06 --> Loader Class Initialized
INFO - 2021-01-11 08:48:06 --> Helper loaded: url_helper
INFO - 2021-01-11 08:48:06 --> Helper loaded: file_helper
INFO - 2021-01-11 08:48:06 --> Helper loaded: form_helper
INFO - 2021-01-11 08:48:06 --> Helper loaded: my_helper
INFO - 2021-01-11 08:48:06 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:48:06 --> Controller Class Initialized
DEBUG - 2021-01-11 08:48:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:48:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:48:06 --> Final output sent to browser
DEBUG - 2021-01-11 08:48:06 --> Total execution time: 0.3824
INFO - 2021-01-11 08:48:08 --> Config Class Initialized
INFO - 2021-01-11 08:48:08 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:48:08 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:48:08 --> Utf8 Class Initialized
INFO - 2021-01-11 08:48:08 --> URI Class Initialized
INFO - 2021-01-11 08:48:08 --> Router Class Initialized
INFO - 2021-01-11 08:48:08 --> Output Class Initialized
INFO - 2021-01-11 08:48:08 --> Security Class Initialized
DEBUG - 2021-01-11 08:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:48:08 --> Input Class Initialized
INFO - 2021-01-11 08:48:08 --> Language Class Initialized
INFO - 2021-01-11 08:48:08 --> Language Class Initialized
INFO - 2021-01-11 08:48:08 --> Config Class Initialized
INFO - 2021-01-11 08:48:08 --> Loader Class Initialized
INFO - 2021-01-11 08:48:08 --> Helper loaded: url_helper
INFO - 2021-01-11 08:48:08 --> Helper loaded: file_helper
INFO - 2021-01-11 08:48:08 --> Helper loaded: form_helper
INFO - 2021-01-11 08:48:08 --> Helper loaded: my_helper
INFO - 2021-01-11 08:48:08 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:48:08 --> Controller Class Initialized
DEBUG - 2021-01-11 08:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:48:08 --> Final output sent to browser
DEBUG - 2021-01-11 08:48:08 --> Total execution time: 0.3617
INFO - 2021-01-11 08:48:08 --> Config Class Initialized
INFO - 2021-01-11 08:48:08 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:48:08 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:48:08 --> Utf8 Class Initialized
INFO - 2021-01-11 08:48:08 --> URI Class Initialized
INFO - 2021-01-11 08:48:08 --> Router Class Initialized
INFO - 2021-01-11 08:48:08 --> Output Class Initialized
INFO - 2021-01-11 08:48:08 --> Security Class Initialized
DEBUG - 2021-01-11 08:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:48:08 --> Input Class Initialized
INFO - 2021-01-11 08:48:08 --> Language Class Initialized
INFO - 2021-01-11 08:48:08 --> Language Class Initialized
INFO - 2021-01-11 08:48:08 --> Config Class Initialized
INFO - 2021-01-11 08:48:08 --> Loader Class Initialized
INFO - 2021-01-11 08:48:09 --> Helper loaded: url_helper
INFO - 2021-01-11 08:48:09 --> Helper loaded: file_helper
INFO - 2021-01-11 08:48:09 --> Helper loaded: form_helper
INFO - 2021-01-11 08:48:09 --> Helper loaded: my_helper
INFO - 2021-01-11 08:48:09 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:48:09 --> Controller Class Initialized
INFO - 2021-01-11 08:49:30 --> Config Class Initialized
INFO - 2021-01-11 08:49:30 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:49:30 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:49:30 --> Utf8 Class Initialized
INFO - 2021-01-11 08:49:30 --> URI Class Initialized
INFO - 2021-01-11 08:49:30 --> Router Class Initialized
INFO - 2021-01-11 08:49:30 --> Output Class Initialized
INFO - 2021-01-11 08:49:30 --> Security Class Initialized
DEBUG - 2021-01-11 08:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:49:30 --> Input Class Initialized
INFO - 2021-01-11 08:49:30 --> Language Class Initialized
INFO - 2021-01-11 08:49:30 --> Language Class Initialized
INFO - 2021-01-11 08:49:30 --> Config Class Initialized
INFO - 2021-01-11 08:49:30 --> Loader Class Initialized
INFO - 2021-01-11 08:49:30 --> Helper loaded: url_helper
INFO - 2021-01-11 08:49:30 --> Helper loaded: file_helper
INFO - 2021-01-11 08:49:30 --> Helper loaded: form_helper
INFO - 2021-01-11 08:49:30 --> Helper loaded: my_helper
INFO - 2021-01-11 08:49:30 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:49:30 --> Controller Class Initialized
DEBUG - 2021-01-11 08:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:49:30 --> Final output sent to browser
DEBUG - 2021-01-11 08:49:30 --> Total execution time: 0.3876
INFO - 2021-01-11 08:49:46 --> Config Class Initialized
INFO - 2021-01-11 08:49:46 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:49:46 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:49:46 --> Utf8 Class Initialized
INFO - 2021-01-11 08:49:46 --> URI Class Initialized
INFO - 2021-01-11 08:49:46 --> Router Class Initialized
INFO - 2021-01-11 08:49:46 --> Output Class Initialized
INFO - 2021-01-11 08:49:46 --> Security Class Initialized
DEBUG - 2021-01-11 08:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:49:46 --> Input Class Initialized
INFO - 2021-01-11 08:49:46 --> Language Class Initialized
INFO - 2021-01-11 08:49:46 --> Language Class Initialized
INFO - 2021-01-11 08:49:46 --> Config Class Initialized
INFO - 2021-01-11 08:49:46 --> Loader Class Initialized
INFO - 2021-01-11 08:49:46 --> Helper loaded: url_helper
INFO - 2021-01-11 08:49:46 --> Helper loaded: file_helper
INFO - 2021-01-11 08:49:46 --> Helper loaded: form_helper
INFO - 2021-01-11 08:49:46 --> Helper loaded: my_helper
INFO - 2021-01-11 08:49:46 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:49:46 --> Controller Class Initialized
DEBUG - 2021-01-11 08:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 08:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:49:46 --> Final output sent to browser
DEBUG - 2021-01-11 08:49:46 --> Total execution time: 0.4455
INFO - 2021-01-11 08:49:48 --> Config Class Initialized
INFO - 2021-01-11 08:49:48 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:49:48 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:49:48 --> Utf8 Class Initialized
INFO - 2021-01-11 08:49:48 --> URI Class Initialized
INFO - 2021-01-11 08:49:48 --> Router Class Initialized
INFO - 2021-01-11 08:49:48 --> Output Class Initialized
INFO - 2021-01-11 08:49:48 --> Security Class Initialized
DEBUG - 2021-01-11 08:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:49:48 --> Input Class Initialized
INFO - 2021-01-11 08:49:48 --> Language Class Initialized
INFO - 2021-01-11 08:49:48 --> Language Class Initialized
INFO - 2021-01-11 08:49:48 --> Config Class Initialized
INFO - 2021-01-11 08:49:48 --> Loader Class Initialized
INFO - 2021-01-11 08:49:48 --> Helper loaded: url_helper
INFO - 2021-01-11 08:49:48 --> Helper loaded: file_helper
INFO - 2021-01-11 08:49:48 --> Helper loaded: form_helper
INFO - 2021-01-11 08:49:48 --> Helper loaded: my_helper
INFO - 2021-01-11 08:49:48 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:49:48 --> Controller Class Initialized
DEBUG - 2021-01-11 08:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 08:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:49:48 --> Final output sent to browser
DEBUG - 2021-01-11 08:49:48 --> Total execution time: 0.3761
INFO - 2021-01-11 08:49:48 --> Config Class Initialized
INFO - 2021-01-11 08:49:48 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:49:48 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:49:48 --> Utf8 Class Initialized
INFO - 2021-01-11 08:49:48 --> URI Class Initialized
INFO - 2021-01-11 08:49:48 --> Router Class Initialized
INFO - 2021-01-11 08:49:48 --> Output Class Initialized
INFO - 2021-01-11 08:49:48 --> Security Class Initialized
DEBUG - 2021-01-11 08:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:49:48 --> Input Class Initialized
INFO - 2021-01-11 08:49:48 --> Language Class Initialized
INFO - 2021-01-11 08:49:48 --> Language Class Initialized
INFO - 2021-01-11 08:49:48 --> Config Class Initialized
INFO - 2021-01-11 08:49:48 --> Loader Class Initialized
INFO - 2021-01-11 08:49:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:49:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:49:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:49:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:49:49 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:49:49 --> Controller Class Initialized
INFO - 2021-01-11 08:50:44 --> Config Class Initialized
INFO - 2021-01-11 08:50:44 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:50:44 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:50:44 --> Utf8 Class Initialized
INFO - 2021-01-11 08:50:44 --> URI Class Initialized
INFO - 2021-01-11 08:50:44 --> Router Class Initialized
INFO - 2021-01-11 08:50:44 --> Output Class Initialized
INFO - 2021-01-11 08:50:44 --> Security Class Initialized
DEBUG - 2021-01-11 08:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:50:44 --> Input Class Initialized
INFO - 2021-01-11 08:50:44 --> Language Class Initialized
INFO - 2021-01-11 08:50:44 --> Language Class Initialized
INFO - 2021-01-11 08:50:44 --> Config Class Initialized
INFO - 2021-01-11 08:50:44 --> Loader Class Initialized
INFO - 2021-01-11 08:50:44 --> Helper loaded: url_helper
INFO - 2021-01-11 08:50:44 --> Helper loaded: file_helper
INFO - 2021-01-11 08:50:44 --> Helper loaded: form_helper
INFO - 2021-01-11 08:50:44 --> Helper loaded: my_helper
INFO - 2021-01-11 08:50:44 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:50:44 --> Controller Class Initialized
DEBUG - 2021-01-11 08:50:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:50:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:50:44 --> Final output sent to browser
DEBUG - 2021-01-11 08:50:44 --> Total execution time: 0.5080
INFO - 2021-01-11 08:51:46 --> Config Class Initialized
INFO - 2021-01-11 08:51:46 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:51:46 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:51:46 --> Utf8 Class Initialized
INFO - 2021-01-11 08:51:46 --> URI Class Initialized
INFO - 2021-01-11 08:51:46 --> Router Class Initialized
INFO - 2021-01-11 08:51:46 --> Output Class Initialized
INFO - 2021-01-11 08:51:46 --> Security Class Initialized
DEBUG - 2021-01-11 08:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:51:46 --> Input Class Initialized
INFO - 2021-01-11 08:51:46 --> Language Class Initialized
INFO - 2021-01-11 08:51:46 --> Language Class Initialized
INFO - 2021-01-11 08:51:46 --> Config Class Initialized
INFO - 2021-01-11 08:51:46 --> Loader Class Initialized
INFO - 2021-01-11 08:51:46 --> Helper loaded: url_helper
INFO - 2021-01-11 08:51:46 --> Helper loaded: file_helper
INFO - 2021-01-11 08:51:46 --> Helper loaded: form_helper
INFO - 2021-01-11 08:51:46 --> Helper loaded: my_helper
INFO - 2021-01-11 08:51:46 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:51:46 --> Controller Class Initialized
DEBUG - 2021-01-11 08:51:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:51:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:51:46 --> Final output sent to browser
DEBUG - 2021-01-11 08:51:46 --> Total execution time: 0.3723
INFO - 2021-01-11 08:52:24 --> Config Class Initialized
INFO - 2021-01-11 08:52:24 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:52:24 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:52:24 --> Utf8 Class Initialized
INFO - 2021-01-11 08:52:24 --> URI Class Initialized
INFO - 2021-01-11 08:52:24 --> Router Class Initialized
INFO - 2021-01-11 08:52:24 --> Output Class Initialized
INFO - 2021-01-11 08:52:24 --> Security Class Initialized
DEBUG - 2021-01-11 08:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:52:24 --> Input Class Initialized
INFO - 2021-01-11 08:52:24 --> Language Class Initialized
INFO - 2021-01-11 08:52:24 --> Language Class Initialized
INFO - 2021-01-11 08:52:24 --> Config Class Initialized
INFO - 2021-01-11 08:52:24 --> Loader Class Initialized
INFO - 2021-01-11 08:52:24 --> Helper loaded: url_helper
INFO - 2021-01-11 08:52:24 --> Helper loaded: file_helper
INFO - 2021-01-11 08:52:24 --> Helper loaded: form_helper
INFO - 2021-01-11 08:52:24 --> Helper loaded: my_helper
INFO - 2021-01-11 08:52:24 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:52:24 --> Controller Class Initialized
DEBUG - 2021-01-11 08:52:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:52:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:52:24 --> Final output sent to browser
DEBUG - 2021-01-11 08:52:24 --> Total execution time: 0.3915
INFO - 2021-01-11 08:52:39 --> Config Class Initialized
INFO - 2021-01-11 08:52:39 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:52:39 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:52:39 --> Utf8 Class Initialized
INFO - 2021-01-11 08:52:39 --> URI Class Initialized
INFO - 2021-01-11 08:52:39 --> Router Class Initialized
INFO - 2021-01-11 08:52:39 --> Output Class Initialized
INFO - 2021-01-11 08:52:39 --> Security Class Initialized
DEBUG - 2021-01-11 08:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:52:39 --> Input Class Initialized
INFO - 2021-01-11 08:52:39 --> Language Class Initialized
INFO - 2021-01-11 08:52:39 --> Language Class Initialized
INFO - 2021-01-11 08:52:39 --> Config Class Initialized
INFO - 2021-01-11 08:52:39 --> Loader Class Initialized
INFO - 2021-01-11 08:52:39 --> Helper loaded: url_helper
INFO - 2021-01-11 08:52:39 --> Helper loaded: file_helper
INFO - 2021-01-11 08:52:39 --> Helper loaded: form_helper
INFO - 2021-01-11 08:52:39 --> Helper loaded: my_helper
INFO - 2021-01-11 08:52:39 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:52:39 --> Controller Class Initialized
DEBUG - 2021-01-11 08:52:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:52:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:52:39 --> Final output sent to browser
DEBUG - 2021-01-11 08:52:39 --> Total execution time: 0.3963
INFO - 2021-01-11 08:52:45 --> Config Class Initialized
INFO - 2021-01-11 08:52:45 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:52:45 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:52:45 --> Utf8 Class Initialized
INFO - 2021-01-11 08:52:45 --> URI Class Initialized
INFO - 2021-01-11 08:52:45 --> Router Class Initialized
INFO - 2021-01-11 08:52:45 --> Output Class Initialized
INFO - 2021-01-11 08:52:45 --> Security Class Initialized
DEBUG - 2021-01-11 08:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:52:45 --> Input Class Initialized
INFO - 2021-01-11 08:52:45 --> Language Class Initialized
INFO - 2021-01-11 08:52:45 --> Language Class Initialized
INFO - 2021-01-11 08:52:45 --> Config Class Initialized
INFO - 2021-01-11 08:52:45 --> Loader Class Initialized
INFO - 2021-01-11 08:52:45 --> Helper loaded: url_helper
INFO - 2021-01-11 08:52:45 --> Helper loaded: file_helper
INFO - 2021-01-11 08:52:45 --> Helper loaded: form_helper
INFO - 2021-01-11 08:52:45 --> Helper loaded: my_helper
INFO - 2021-01-11 08:52:45 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:52:45 --> Controller Class Initialized
DEBUG - 2021-01-11 08:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:52:45 --> Final output sent to browser
DEBUG - 2021-01-11 08:52:45 --> Total execution time: 0.4026
INFO - 2021-01-11 08:55:10 --> Config Class Initialized
INFO - 2021-01-11 08:55:10 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:55:10 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:55:10 --> Utf8 Class Initialized
INFO - 2021-01-11 08:55:10 --> URI Class Initialized
INFO - 2021-01-11 08:55:10 --> Router Class Initialized
INFO - 2021-01-11 08:55:10 --> Output Class Initialized
INFO - 2021-01-11 08:55:10 --> Security Class Initialized
DEBUG - 2021-01-11 08:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:55:10 --> Input Class Initialized
INFO - 2021-01-11 08:55:10 --> Language Class Initialized
INFO - 2021-01-11 08:55:10 --> Language Class Initialized
INFO - 2021-01-11 08:55:10 --> Config Class Initialized
INFO - 2021-01-11 08:55:10 --> Loader Class Initialized
INFO - 2021-01-11 08:55:10 --> Helper loaded: url_helper
INFO - 2021-01-11 08:55:10 --> Helper loaded: file_helper
INFO - 2021-01-11 08:55:11 --> Helper loaded: form_helper
INFO - 2021-01-11 08:55:11 --> Helper loaded: my_helper
INFO - 2021-01-11 08:55:11 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:55:11 --> Controller Class Initialized
DEBUG - 2021-01-11 08:55:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-11 08:55:11 --> Final output sent to browser
DEBUG - 2021-01-11 08:55:11 --> Total execution time: 0.4713
INFO - 2021-01-11 08:55:16 --> Config Class Initialized
INFO - 2021-01-11 08:55:16 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:55:16 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:55:16 --> Utf8 Class Initialized
INFO - 2021-01-11 08:55:16 --> URI Class Initialized
INFO - 2021-01-11 08:55:16 --> Router Class Initialized
INFO - 2021-01-11 08:55:16 --> Output Class Initialized
INFO - 2021-01-11 08:55:16 --> Security Class Initialized
DEBUG - 2021-01-11 08:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:55:16 --> Input Class Initialized
INFO - 2021-01-11 08:55:16 --> Language Class Initialized
INFO - 2021-01-11 08:55:16 --> Language Class Initialized
INFO - 2021-01-11 08:55:16 --> Config Class Initialized
INFO - 2021-01-11 08:55:16 --> Loader Class Initialized
INFO - 2021-01-11 08:55:16 --> Helper loaded: url_helper
INFO - 2021-01-11 08:55:16 --> Helper loaded: file_helper
INFO - 2021-01-11 08:55:16 --> Helper loaded: form_helper
INFO - 2021-01-11 08:55:16 --> Helper loaded: my_helper
INFO - 2021-01-11 08:55:16 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:55:16 --> Controller Class Initialized
DEBUG - 2021-01-11 08:55:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-11 08:55:16 --> Final output sent to browser
DEBUG - 2021-01-11 08:55:16 --> Total execution time: 0.4621
INFO - 2021-01-11 08:55:52 --> Config Class Initialized
INFO - 2021-01-11 08:55:52 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:55:52 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:55:52 --> Utf8 Class Initialized
INFO - 2021-01-11 08:55:52 --> URI Class Initialized
INFO - 2021-01-11 08:55:52 --> Router Class Initialized
INFO - 2021-01-11 08:55:52 --> Output Class Initialized
INFO - 2021-01-11 08:55:52 --> Security Class Initialized
DEBUG - 2021-01-11 08:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:55:52 --> Input Class Initialized
INFO - 2021-01-11 08:55:52 --> Language Class Initialized
INFO - 2021-01-11 08:55:52 --> Language Class Initialized
INFO - 2021-01-11 08:55:52 --> Config Class Initialized
INFO - 2021-01-11 08:55:52 --> Loader Class Initialized
INFO - 2021-01-11 08:55:53 --> Helper loaded: url_helper
INFO - 2021-01-11 08:55:53 --> Helper loaded: file_helper
INFO - 2021-01-11 08:55:53 --> Helper loaded: form_helper
INFO - 2021-01-11 08:55:53 --> Helper loaded: my_helper
INFO - 2021-01-11 08:55:53 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:55:53 --> Controller Class Initialized
DEBUG - 2021-01-11 08:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-11 08:55:53 --> Final output sent to browser
DEBUG - 2021-01-11 08:55:53 --> Total execution time: 0.3830
INFO - 2021-01-11 08:55:57 --> Config Class Initialized
INFO - 2021-01-11 08:55:57 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:55:57 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:55:57 --> Utf8 Class Initialized
INFO - 2021-01-11 08:55:57 --> URI Class Initialized
INFO - 2021-01-11 08:55:57 --> Router Class Initialized
INFO - 2021-01-11 08:55:57 --> Output Class Initialized
INFO - 2021-01-11 08:55:57 --> Security Class Initialized
DEBUG - 2021-01-11 08:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:55:57 --> Input Class Initialized
INFO - 2021-01-11 08:55:57 --> Language Class Initialized
INFO - 2021-01-11 08:55:57 --> Language Class Initialized
INFO - 2021-01-11 08:55:57 --> Config Class Initialized
INFO - 2021-01-11 08:55:58 --> Loader Class Initialized
INFO - 2021-01-11 08:55:58 --> Helper loaded: url_helper
INFO - 2021-01-11 08:55:58 --> Helper loaded: file_helper
INFO - 2021-01-11 08:55:58 --> Helper loaded: form_helper
INFO - 2021-01-11 08:55:58 --> Helper loaded: my_helper
INFO - 2021-01-11 08:55:58 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:55:58 --> Controller Class Initialized
DEBUG - 2021-01-11 08:55:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-11 08:55:58 --> Final output sent to browser
DEBUG - 2021-01-11 08:55:58 --> Total execution time: 0.3808
INFO - 2021-01-11 08:56:01 --> Config Class Initialized
INFO - 2021-01-11 08:56:01 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:56:01 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:56:01 --> Utf8 Class Initialized
INFO - 2021-01-11 08:56:01 --> URI Class Initialized
INFO - 2021-01-11 08:56:01 --> Router Class Initialized
INFO - 2021-01-11 08:56:01 --> Output Class Initialized
INFO - 2021-01-11 08:56:01 --> Security Class Initialized
DEBUG - 2021-01-11 08:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:56:01 --> Input Class Initialized
INFO - 2021-01-11 08:56:01 --> Language Class Initialized
INFO - 2021-01-11 08:56:01 --> Language Class Initialized
INFO - 2021-01-11 08:56:01 --> Config Class Initialized
INFO - 2021-01-11 08:56:01 --> Loader Class Initialized
INFO - 2021-01-11 08:56:01 --> Helper loaded: url_helper
INFO - 2021-01-11 08:56:01 --> Helper loaded: file_helper
INFO - 2021-01-11 08:56:01 --> Helper loaded: form_helper
INFO - 2021-01-11 08:56:01 --> Helper loaded: my_helper
INFO - 2021-01-11 08:56:01 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:56:01 --> Controller Class Initialized
DEBUG - 2021-01-11 08:56:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-11 08:56:01 --> Final output sent to browser
DEBUG - 2021-01-11 08:56:01 --> Total execution time: 0.3924
INFO - 2021-01-11 08:58:49 --> Config Class Initialized
INFO - 2021-01-11 08:58:49 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:58:49 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:58:49 --> Utf8 Class Initialized
INFO - 2021-01-11 08:58:49 --> URI Class Initialized
INFO - 2021-01-11 08:58:49 --> Router Class Initialized
INFO - 2021-01-11 08:58:49 --> Output Class Initialized
INFO - 2021-01-11 08:58:49 --> Security Class Initialized
DEBUG - 2021-01-11 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:58:49 --> Input Class Initialized
INFO - 2021-01-11 08:58:49 --> Language Class Initialized
INFO - 2021-01-11 08:58:49 --> Language Class Initialized
INFO - 2021-01-11 08:58:49 --> Config Class Initialized
INFO - 2021-01-11 08:58:49 --> Loader Class Initialized
INFO - 2021-01-11 08:58:49 --> Helper loaded: url_helper
INFO - 2021-01-11 08:58:49 --> Helper loaded: file_helper
INFO - 2021-01-11 08:58:49 --> Helper loaded: form_helper
INFO - 2021-01-11 08:58:49 --> Helper loaded: my_helper
INFO - 2021-01-11 08:58:50 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:58:50 --> Controller Class Initialized
DEBUG - 2021-01-11 08:58:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-11 08:58:50 --> Final output sent to browser
DEBUG - 2021-01-11 08:58:50 --> Total execution time: 0.3863
INFO - 2021-01-11 08:59:53 --> Config Class Initialized
INFO - 2021-01-11 08:59:53 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:59:53 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:59:53 --> Utf8 Class Initialized
INFO - 2021-01-11 08:59:53 --> URI Class Initialized
INFO - 2021-01-11 08:59:53 --> Router Class Initialized
INFO - 2021-01-11 08:59:53 --> Output Class Initialized
INFO - 2021-01-11 08:59:53 --> Security Class Initialized
DEBUG - 2021-01-11 08:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:59:53 --> Input Class Initialized
INFO - 2021-01-11 08:59:53 --> Language Class Initialized
INFO - 2021-01-11 08:59:53 --> Language Class Initialized
INFO - 2021-01-11 08:59:53 --> Config Class Initialized
INFO - 2021-01-11 08:59:53 --> Loader Class Initialized
INFO - 2021-01-11 08:59:53 --> Helper loaded: url_helper
INFO - 2021-01-11 08:59:53 --> Helper loaded: file_helper
INFO - 2021-01-11 08:59:53 --> Helper loaded: form_helper
INFO - 2021-01-11 08:59:53 --> Helper loaded: my_helper
INFO - 2021-01-11 08:59:53 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:59:53 --> Controller Class Initialized
DEBUG - 2021-01-11 08:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-11 08:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:59:53 --> Final output sent to browser
DEBUG - 2021-01-11 08:59:53 --> Total execution time: 0.4031
INFO - 2021-01-11 08:59:54 --> Config Class Initialized
INFO - 2021-01-11 08:59:54 --> Hooks Class Initialized
DEBUG - 2021-01-11 08:59:54 --> UTF-8 Support Enabled
INFO - 2021-01-11 08:59:54 --> Utf8 Class Initialized
INFO - 2021-01-11 08:59:54 --> URI Class Initialized
INFO - 2021-01-11 08:59:54 --> Router Class Initialized
INFO - 2021-01-11 08:59:54 --> Output Class Initialized
INFO - 2021-01-11 08:59:54 --> Security Class Initialized
DEBUG - 2021-01-11 08:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 08:59:54 --> Input Class Initialized
INFO - 2021-01-11 08:59:54 --> Language Class Initialized
INFO - 2021-01-11 08:59:54 --> Language Class Initialized
INFO - 2021-01-11 08:59:54 --> Config Class Initialized
INFO - 2021-01-11 08:59:54 --> Loader Class Initialized
INFO - 2021-01-11 08:59:54 --> Helper loaded: url_helper
INFO - 2021-01-11 08:59:54 --> Helper loaded: file_helper
INFO - 2021-01-11 08:59:54 --> Helper loaded: form_helper
INFO - 2021-01-11 08:59:54 --> Helper loaded: my_helper
INFO - 2021-01-11 08:59:55 --> Database Driver Class Initialized
DEBUG - 2021-01-11 08:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 08:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 08:59:55 --> Controller Class Initialized
DEBUG - 2021-01-11 08:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 08:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 08:59:55 --> Final output sent to browser
DEBUG - 2021-01-11 08:59:55 --> Total execution time: 0.3917
INFO - 2021-01-11 09:00:55 --> Config Class Initialized
INFO - 2021-01-11 09:00:55 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:00:55 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:00:55 --> Utf8 Class Initialized
INFO - 2021-01-11 09:00:55 --> URI Class Initialized
INFO - 2021-01-11 09:00:55 --> Router Class Initialized
INFO - 2021-01-11 09:00:55 --> Output Class Initialized
INFO - 2021-01-11 09:00:55 --> Security Class Initialized
DEBUG - 2021-01-11 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:00:55 --> Input Class Initialized
INFO - 2021-01-11 09:00:55 --> Language Class Initialized
INFO - 2021-01-11 09:00:55 --> Language Class Initialized
INFO - 2021-01-11 09:00:55 --> Config Class Initialized
INFO - 2021-01-11 09:00:55 --> Loader Class Initialized
INFO - 2021-01-11 09:00:55 --> Helper loaded: url_helper
INFO - 2021-01-11 09:00:55 --> Helper loaded: file_helper
INFO - 2021-01-11 09:00:55 --> Helper loaded: form_helper
INFO - 2021-01-11 09:00:55 --> Helper loaded: my_helper
INFO - 2021-01-11 09:00:55 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:00:55 --> Controller Class Initialized
DEBUG - 2021-01-11 09:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 09:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 09:00:55 --> Final output sent to browser
DEBUG - 2021-01-11 09:00:55 --> Total execution time: 0.3535
INFO - 2021-01-11 09:00:59 --> Config Class Initialized
INFO - 2021-01-11 09:00:59 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:00:59 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:00:59 --> Utf8 Class Initialized
INFO - 2021-01-11 09:00:59 --> URI Class Initialized
INFO - 2021-01-11 09:00:59 --> Router Class Initialized
INFO - 2021-01-11 09:00:59 --> Output Class Initialized
INFO - 2021-01-11 09:00:59 --> Security Class Initialized
DEBUG - 2021-01-11 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:00:59 --> Input Class Initialized
INFO - 2021-01-11 09:00:59 --> Language Class Initialized
INFO - 2021-01-11 09:00:59 --> Language Class Initialized
INFO - 2021-01-11 09:00:59 --> Config Class Initialized
INFO - 2021-01-11 09:00:59 --> Loader Class Initialized
INFO - 2021-01-11 09:00:59 --> Helper loaded: url_helper
INFO - 2021-01-11 09:00:59 --> Helper loaded: file_helper
INFO - 2021-01-11 09:00:59 --> Helper loaded: form_helper
INFO - 2021-01-11 09:00:59 --> Helper loaded: my_helper
INFO - 2021-01-11 09:00:59 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:00:59 --> Controller Class Initialized
DEBUG - 2021-01-11 09:00:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 09:00:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 09:00:59 --> Final output sent to browser
DEBUG - 2021-01-11 09:00:59 --> Total execution time: 0.3601
INFO - 2021-01-11 09:00:59 --> Config Class Initialized
INFO - 2021-01-11 09:00:59 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:01:00 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:01:00 --> Utf8 Class Initialized
INFO - 2021-01-11 09:01:00 --> URI Class Initialized
INFO - 2021-01-11 09:01:00 --> Router Class Initialized
INFO - 2021-01-11 09:01:00 --> Output Class Initialized
INFO - 2021-01-11 09:01:00 --> Security Class Initialized
DEBUG - 2021-01-11 09:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:01:00 --> Input Class Initialized
INFO - 2021-01-11 09:01:00 --> Language Class Initialized
INFO - 2021-01-11 09:01:00 --> Language Class Initialized
INFO - 2021-01-11 09:01:00 --> Config Class Initialized
INFO - 2021-01-11 09:01:00 --> Loader Class Initialized
INFO - 2021-01-11 09:01:00 --> Helper loaded: url_helper
INFO - 2021-01-11 09:01:00 --> Helper loaded: file_helper
INFO - 2021-01-11 09:01:00 --> Helper loaded: form_helper
INFO - 2021-01-11 09:01:00 --> Helper loaded: my_helper
INFO - 2021-01-11 09:01:00 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:01:00 --> Controller Class Initialized
INFO - 2021-01-11 09:01:02 --> Config Class Initialized
INFO - 2021-01-11 09:01:02 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:01:02 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:01:02 --> Utf8 Class Initialized
INFO - 2021-01-11 09:01:02 --> URI Class Initialized
INFO - 2021-01-11 09:01:02 --> Router Class Initialized
INFO - 2021-01-11 09:01:02 --> Output Class Initialized
INFO - 2021-01-11 09:01:02 --> Security Class Initialized
DEBUG - 2021-01-11 09:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:01:02 --> Input Class Initialized
INFO - 2021-01-11 09:01:02 --> Language Class Initialized
INFO - 2021-01-11 09:01:02 --> Language Class Initialized
INFO - 2021-01-11 09:01:02 --> Config Class Initialized
INFO - 2021-01-11 09:01:02 --> Loader Class Initialized
INFO - 2021-01-11 09:01:02 --> Helper loaded: url_helper
INFO - 2021-01-11 09:01:02 --> Helper loaded: file_helper
INFO - 2021-01-11 09:01:02 --> Helper loaded: form_helper
INFO - 2021-01-11 09:01:02 --> Helper loaded: my_helper
INFO - 2021-01-11 09:01:02 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:01:02 --> Controller Class Initialized
DEBUG - 2021-01-11 09:01:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-11 09:01:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 09:01:02 --> Final output sent to browser
DEBUG - 2021-01-11 09:01:02 --> Total execution time: 0.3698
INFO - 2021-01-11 09:01:04 --> Config Class Initialized
INFO - 2021-01-11 09:01:04 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:01:04 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:01:04 --> Utf8 Class Initialized
INFO - 2021-01-11 09:01:04 --> URI Class Initialized
INFO - 2021-01-11 09:01:04 --> Router Class Initialized
INFO - 2021-01-11 09:01:04 --> Output Class Initialized
INFO - 2021-01-11 09:01:04 --> Security Class Initialized
DEBUG - 2021-01-11 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:01:04 --> Input Class Initialized
INFO - 2021-01-11 09:01:04 --> Language Class Initialized
INFO - 2021-01-11 09:01:04 --> Language Class Initialized
INFO - 2021-01-11 09:01:04 --> Config Class Initialized
INFO - 2021-01-11 09:01:04 --> Loader Class Initialized
INFO - 2021-01-11 09:01:04 --> Helper loaded: url_helper
INFO - 2021-01-11 09:01:04 --> Helper loaded: file_helper
INFO - 2021-01-11 09:01:04 --> Helper loaded: form_helper
INFO - 2021-01-11 09:01:04 --> Helper loaded: my_helper
INFO - 2021-01-11 09:01:04 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:01:04 --> Controller Class Initialized
DEBUG - 2021-01-11 09:01:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-11 09:01:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 09:01:05 --> Final output sent to browser
DEBUG - 2021-01-11 09:01:05 --> Total execution time: 0.3546
INFO - 2021-01-11 09:01:05 --> Config Class Initialized
INFO - 2021-01-11 09:01:05 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:01:05 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:01:05 --> Utf8 Class Initialized
INFO - 2021-01-11 09:01:05 --> URI Class Initialized
INFO - 2021-01-11 09:01:05 --> Router Class Initialized
INFO - 2021-01-11 09:01:05 --> Output Class Initialized
INFO - 2021-01-11 09:01:05 --> Security Class Initialized
DEBUG - 2021-01-11 09:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:01:05 --> Input Class Initialized
INFO - 2021-01-11 09:01:05 --> Language Class Initialized
INFO - 2021-01-11 09:01:05 --> Language Class Initialized
INFO - 2021-01-11 09:01:05 --> Config Class Initialized
INFO - 2021-01-11 09:01:05 --> Loader Class Initialized
INFO - 2021-01-11 09:01:05 --> Helper loaded: url_helper
INFO - 2021-01-11 09:01:05 --> Helper loaded: file_helper
INFO - 2021-01-11 09:01:05 --> Helper loaded: form_helper
INFO - 2021-01-11 09:01:05 --> Helper loaded: my_helper
INFO - 2021-01-11 09:01:05 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:01:05 --> Controller Class Initialized
INFO - 2021-01-11 09:11:12 --> Config Class Initialized
INFO - 2021-01-11 09:11:12 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:11:12 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:11:12 --> Utf8 Class Initialized
INFO - 2021-01-11 09:11:12 --> URI Class Initialized
INFO - 2021-01-11 09:11:12 --> Router Class Initialized
INFO - 2021-01-11 09:11:12 --> Output Class Initialized
INFO - 2021-01-11 09:11:12 --> Security Class Initialized
DEBUG - 2021-01-11 09:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:11:12 --> Input Class Initialized
INFO - 2021-01-11 09:11:12 --> Language Class Initialized
INFO - 2021-01-11 09:11:12 --> Language Class Initialized
INFO - 2021-01-11 09:11:12 --> Config Class Initialized
INFO - 2021-01-11 09:11:12 --> Loader Class Initialized
INFO - 2021-01-11 09:11:12 --> Helper loaded: url_helper
INFO - 2021-01-11 09:11:12 --> Helper loaded: file_helper
INFO - 2021-01-11 09:11:12 --> Helper loaded: form_helper
INFO - 2021-01-11 09:11:12 --> Helper loaded: my_helper
INFO - 2021-01-11 09:11:12 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:11:12 --> Controller Class Initialized
DEBUG - 2021-01-11 09:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 09:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 09:11:12 --> Final output sent to browser
DEBUG - 2021-01-11 09:11:12 --> Total execution time: 0.3581
INFO - 2021-01-11 09:11:14 --> Config Class Initialized
INFO - 2021-01-11 09:11:14 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:11:14 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:11:14 --> Utf8 Class Initialized
INFO - 2021-01-11 09:11:14 --> URI Class Initialized
INFO - 2021-01-11 09:11:14 --> Router Class Initialized
INFO - 2021-01-11 09:11:14 --> Output Class Initialized
INFO - 2021-01-11 09:11:14 --> Security Class Initialized
DEBUG - 2021-01-11 09:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:11:14 --> Input Class Initialized
INFO - 2021-01-11 09:11:14 --> Language Class Initialized
INFO - 2021-01-11 09:11:14 --> Language Class Initialized
INFO - 2021-01-11 09:11:14 --> Config Class Initialized
INFO - 2021-01-11 09:11:14 --> Loader Class Initialized
INFO - 2021-01-11 09:11:14 --> Helper loaded: url_helper
INFO - 2021-01-11 09:11:14 --> Helper loaded: file_helper
INFO - 2021-01-11 09:11:14 --> Helper loaded: form_helper
INFO - 2021-01-11 09:11:14 --> Helper loaded: my_helper
INFO - 2021-01-11 09:11:14 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:11:14 --> Controller Class Initialized
DEBUG - 2021-01-11 09:11:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-01-11 09:11:14 --> Final output sent to browser
DEBUG - 2021-01-11 09:11:14 --> Total execution time: 0.3853
INFO - 2021-01-11 09:11:53 --> Config Class Initialized
INFO - 2021-01-11 09:11:53 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:11:53 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:11:53 --> Utf8 Class Initialized
INFO - 2021-01-11 09:11:53 --> URI Class Initialized
INFO - 2021-01-11 09:11:53 --> Router Class Initialized
INFO - 2021-01-11 09:11:53 --> Output Class Initialized
INFO - 2021-01-11 09:11:53 --> Security Class Initialized
DEBUG - 2021-01-11 09:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:11:53 --> Input Class Initialized
INFO - 2021-01-11 09:11:53 --> Language Class Initialized
INFO - 2021-01-11 09:11:53 --> Language Class Initialized
INFO - 2021-01-11 09:11:53 --> Config Class Initialized
INFO - 2021-01-11 09:11:53 --> Loader Class Initialized
INFO - 2021-01-11 09:11:53 --> Helper loaded: url_helper
INFO - 2021-01-11 09:11:53 --> Helper loaded: file_helper
INFO - 2021-01-11 09:11:53 --> Helper loaded: form_helper
INFO - 2021-01-11 09:11:53 --> Helper loaded: my_helper
INFO - 2021-01-11 09:11:53 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:11:53 --> Controller Class Initialized
DEBUG - 2021-01-11 09:11:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-11 09:11:53 --> Final output sent to browser
DEBUG - 2021-01-11 09:11:53 --> Total execution time: 0.3809
INFO - 2021-01-11 09:12:06 --> Config Class Initialized
INFO - 2021-01-11 09:12:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:12:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:12:06 --> Utf8 Class Initialized
INFO - 2021-01-11 09:12:06 --> URI Class Initialized
INFO - 2021-01-11 09:12:06 --> Router Class Initialized
INFO - 2021-01-11 09:12:06 --> Output Class Initialized
INFO - 2021-01-11 09:12:06 --> Security Class Initialized
DEBUG - 2021-01-11 09:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:12:06 --> Input Class Initialized
INFO - 2021-01-11 09:12:06 --> Language Class Initialized
INFO - 2021-01-11 09:12:06 --> Language Class Initialized
INFO - 2021-01-11 09:12:06 --> Config Class Initialized
INFO - 2021-01-11 09:12:06 --> Loader Class Initialized
INFO - 2021-01-11 09:12:06 --> Helper loaded: url_helper
INFO - 2021-01-11 09:12:06 --> Helper loaded: file_helper
INFO - 2021-01-11 09:12:06 --> Helper loaded: form_helper
INFO - 2021-01-11 09:12:06 --> Helper loaded: my_helper
INFO - 2021-01-11 09:12:06 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:12:06 --> Controller Class Initialized
INFO - 2021-01-11 09:12:06 --> Helper loaded: cookie_helper
INFO - 2021-01-11 09:12:06 --> Config Class Initialized
INFO - 2021-01-11 09:12:06 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:12:06 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:12:06 --> Utf8 Class Initialized
INFO - 2021-01-11 09:12:06 --> URI Class Initialized
INFO - 2021-01-11 09:12:06 --> Router Class Initialized
INFO - 2021-01-11 09:12:06 --> Output Class Initialized
INFO - 2021-01-11 09:12:06 --> Security Class Initialized
DEBUG - 2021-01-11 09:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:12:06 --> Input Class Initialized
INFO - 2021-01-11 09:12:06 --> Language Class Initialized
INFO - 2021-01-11 09:12:06 --> Language Class Initialized
INFO - 2021-01-11 09:12:06 --> Config Class Initialized
INFO - 2021-01-11 09:12:06 --> Loader Class Initialized
INFO - 2021-01-11 09:12:06 --> Helper loaded: url_helper
INFO - 2021-01-11 09:12:06 --> Helper loaded: file_helper
INFO - 2021-01-11 09:12:06 --> Helper loaded: form_helper
INFO - 2021-01-11 09:12:06 --> Helper loaded: my_helper
INFO - 2021-01-11 09:12:06 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:12:07 --> Controller Class Initialized
DEBUG - 2021-01-11 09:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-11 09:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 09:12:07 --> Final output sent to browser
DEBUG - 2021-01-11 09:12:07 --> Total execution time: 0.3995
INFO - 2021-01-11 09:12:11 --> Config Class Initialized
INFO - 2021-01-11 09:12:11 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:12:11 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:12:11 --> Utf8 Class Initialized
INFO - 2021-01-11 09:12:11 --> URI Class Initialized
INFO - 2021-01-11 09:12:11 --> Router Class Initialized
INFO - 2021-01-11 09:12:11 --> Output Class Initialized
INFO - 2021-01-11 09:12:11 --> Security Class Initialized
DEBUG - 2021-01-11 09:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:12:11 --> Input Class Initialized
INFO - 2021-01-11 09:12:11 --> Language Class Initialized
INFO - 2021-01-11 09:12:11 --> Language Class Initialized
INFO - 2021-01-11 09:12:11 --> Config Class Initialized
INFO - 2021-01-11 09:12:11 --> Loader Class Initialized
INFO - 2021-01-11 09:12:11 --> Helper loaded: url_helper
INFO - 2021-01-11 09:12:11 --> Helper loaded: file_helper
INFO - 2021-01-11 09:12:11 --> Helper loaded: form_helper
INFO - 2021-01-11 09:12:11 --> Helper loaded: my_helper
INFO - 2021-01-11 09:12:12 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:12:12 --> Controller Class Initialized
INFO - 2021-01-11 09:12:12 --> Helper loaded: cookie_helper
INFO - 2021-01-11 09:12:12 --> Final output sent to browser
DEBUG - 2021-01-11 09:12:12 --> Total execution time: 0.4981
INFO - 2021-01-11 09:12:12 --> Config Class Initialized
INFO - 2021-01-11 09:12:12 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:12:12 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:12:12 --> Utf8 Class Initialized
INFO - 2021-01-11 09:12:12 --> URI Class Initialized
INFO - 2021-01-11 09:12:12 --> Router Class Initialized
INFO - 2021-01-11 09:12:12 --> Output Class Initialized
INFO - 2021-01-11 09:12:12 --> Security Class Initialized
DEBUG - 2021-01-11 09:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:12:12 --> Input Class Initialized
INFO - 2021-01-11 09:12:12 --> Language Class Initialized
INFO - 2021-01-11 09:12:12 --> Language Class Initialized
INFO - 2021-01-11 09:12:12 --> Config Class Initialized
INFO - 2021-01-11 09:12:12 --> Loader Class Initialized
INFO - 2021-01-11 09:12:12 --> Helper loaded: url_helper
INFO - 2021-01-11 09:12:12 --> Helper loaded: file_helper
INFO - 2021-01-11 09:12:12 --> Helper loaded: form_helper
INFO - 2021-01-11 09:12:12 --> Helper loaded: my_helper
INFO - 2021-01-11 09:12:12 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:12:13 --> Controller Class Initialized
DEBUG - 2021-01-11 09:12:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-11 09:12:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 09:12:13 --> Final output sent to browser
DEBUG - 2021-01-11 09:12:13 --> Total execution time: 0.5260
INFO - 2021-01-11 09:12:14 --> Config Class Initialized
INFO - 2021-01-11 09:12:14 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:12:14 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:12:14 --> Utf8 Class Initialized
INFO - 2021-01-11 09:12:14 --> URI Class Initialized
INFO - 2021-01-11 09:12:14 --> Router Class Initialized
INFO - 2021-01-11 09:12:14 --> Output Class Initialized
INFO - 2021-01-11 09:12:14 --> Security Class Initialized
DEBUG - 2021-01-11 09:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:12:14 --> Input Class Initialized
INFO - 2021-01-11 09:12:14 --> Language Class Initialized
INFO - 2021-01-11 09:12:14 --> Language Class Initialized
INFO - 2021-01-11 09:12:14 --> Config Class Initialized
INFO - 2021-01-11 09:12:14 --> Loader Class Initialized
INFO - 2021-01-11 09:12:14 --> Helper loaded: url_helper
INFO - 2021-01-11 09:12:14 --> Helper loaded: file_helper
INFO - 2021-01-11 09:12:14 --> Helper loaded: form_helper
INFO - 2021-01-11 09:12:14 --> Helper loaded: my_helper
INFO - 2021-01-11 09:12:14 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:12:15 --> Controller Class Initialized
DEBUG - 2021-01-11 09:12:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-11 09:12:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-11 09:12:15 --> Final output sent to browser
DEBUG - 2021-01-11 09:12:15 --> Total execution time: 0.3795
INFO - 2021-01-11 09:12:17 --> Config Class Initialized
INFO - 2021-01-11 09:12:17 --> Hooks Class Initialized
DEBUG - 2021-01-11 09:12:17 --> UTF-8 Support Enabled
INFO - 2021-01-11 09:12:18 --> Utf8 Class Initialized
INFO - 2021-01-11 09:12:18 --> URI Class Initialized
INFO - 2021-01-11 09:12:18 --> Router Class Initialized
INFO - 2021-01-11 09:12:18 --> Output Class Initialized
INFO - 2021-01-11 09:12:18 --> Security Class Initialized
DEBUG - 2021-01-11 09:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-11 09:12:18 --> Input Class Initialized
INFO - 2021-01-11 09:12:18 --> Language Class Initialized
INFO - 2021-01-11 09:12:18 --> Language Class Initialized
INFO - 2021-01-11 09:12:18 --> Config Class Initialized
INFO - 2021-01-11 09:12:18 --> Loader Class Initialized
INFO - 2021-01-11 09:12:18 --> Helper loaded: url_helper
INFO - 2021-01-11 09:12:18 --> Helper loaded: file_helper
INFO - 2021-01-11 09:12:18 --> Helper loaded: form_helper
INFO - 2021-01-11 09:12:18 --> Helper loaded: my_helper
INFO - 2021-01-11 09:12:18 --> Database Driver Class Initialized
DEBUG - 2021-01-11 09:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-11 09:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-11 09:12:18 --> Controller Class Initialized
DEBUG - 2021-01-11 09:12:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-11 09:12:18 --> Final output sent to browser
DEBUG - 2021-01-11 09:12:18 --> Total execution time: 0.3888
