<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-11-16 08:17:55 --> Config Class Initialized
INFO - 2022-11-16 08:17:55 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:17:55 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:17:55 --> Utf8 Class Initialized
INFO - 2022-11-16 08:17:55 --> URI Class Initialized
DEBUG - 2022-11-16 08:17:55 --> No URI present. Default controller set.
INFO - 2022-11-16 08:17:55 --> Router Class Initialized
INFO - 2022-11-16 08:17:55 --> Output Class Initialized
INFO - 2022-11-16 08:17:55 --> Security Class Initialized
DEBUG - 2022-11-16 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:17:55 --> Input Class Initialized
INFO - 2022-11-16 08:17:55 --> Language Class Initialized
INFO - 2022-11-16 08:17:55 --> Language Class Initialized
INFO - 2022-11-16 08:17:55 --> Config Class Initialized
INFO - 2022-11-16 08:17:55 --> Loader Class Initialized
INFO - 2022-11-16 08:17:55 --> Helper loaded: url_helper
INFO - 2022-11-16 08:17:55 --> Helper loaded: file_helper
INFO - 2022-11-16 08:17:55 --> Helper loaded: form_helper
INFO - 2022-11-16 08:17:55 --> Helper loaded: my_helper
INFO - 2022-11-16 08:17:56 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:17:56 --> Controller Class Initialized
INFO - 2022-11-16 08:17:56 --> Config Class Initialized
INFO - 2022-11-16 08:17:56 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:17:56 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:17:56 --> Utf8 Class Initialized
INFO - 2022-11-16 08:17:56 --> URI Class Initialized
INFO - 2022-11-16 08:17:56 --> Router Class Initialized
INFO - 2022-11-16 08:17:56 --> Output Class Initialized
INFO - 2022-11-16 08:17:56 --> Security Class Initialized
DEBUG - 2022-11-16 08:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:17:56 --> Input Class Initialized
INFO - 2022-11-16 08:17:56 --> Language Class Initialized
INFO - 2022-11-16 08:17:56 --> Language Class Initialized
INFO - 2022-11-16 08:17:56 --> Config Class Initialized
INFO - 2022-11-16 08:17:56 --> Loader Class Initialized
INFO - 2022-11-16 08:17:56 --> Helper loaded: url_helper
INFO - 2022-11-16 08:17:56 --> Helper loaded: file_helper
INFO - 2022-11-16 08:17:56 --> Helper loaded: form_helper
INFO - 2022-11-16 08:17:56 --> Helper loaded: my_helper
INFO - 2022-11-16 08:17:56 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:17:56 --> Controller Class Initialized
DEBUG - 2022-11-16 08:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-11-16 08:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:17:56 --> Final output sent to browser
DEBUG - 2022-11-16 08:17:56 --> Total execution time: 0.1010
INFO - 2022-11-16 08:18:02 --> Config Class Initialized
INFO - 2022-11-16 08:18:02 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:18:02 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:18:02 --> Utf8 Class Initialized
INFO - 2022-11-16 08:18:02 --> URI Class Initialized
INFO - 2022-11-16 08:18:02 --> Router Class Initialized
INFO - 2022-11-16 08:18:02 --> Output Class Initialized
INFO - 2022-11-16 08:18:02 --> Security Class Initialized
DEBUG - 2022-11-16 08:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:18:02 --> Input Class Initialized
INFO - 2022-11-16 08:18:02 --> Language Class Initialized
INFO - 2022-11-16 08:18:02 --> Language Class Initialized
INFO - 2022-11-16 08:18:02 --> Config Class Initialized
INFO - 2022-11-16 08:18:02 --> Loader Class Initialized
INFO - 2022-11-16 08:18:02 --> Helper loaded: url_helper
INFO - 2022-11-16 08:18:02 --> Helper loaded: file_helper
INFO - 2022-11-16 08:18:02 --> Helper loaded: form_helper
INFO - 2022-11-16 08:18:02 --> Helper loaded: my_helper
INFO - 2022-11-16 08:18:02 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:18:02 --> Controller Class Initialized
INFO - 2022-11-16 08:18:02 --> Helper loaded: cookie_helper
INFO - 2022-11-16 08:18:02 --> Final output sent to browser
DEBUG - 2022-11-16 08:18:02 --> Total execution time: 0.0719
INFO - 2022-11-16 08:18:02 --> Config Class Initialized
INFO - 2022-11-16 08:18:02 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:18:02 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:18:02 --> Utf8 Class Initialized
INFO - 2022-11-16 08:18:02 --> URI Class Initialized
INFO - 2022-11-16 08:18:02 --> Router Class Initialized
INFO - 2022-11-16 08:18:02 --> Output Class Initialized
INFO - 2022-11-16 08:18:02 --> Security Class Initialized
DEBUG - 2022-11-16 08:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:18:02 --> Input Class Initialized
INFO - 2022-11-16 08:18:02 --> Language Class Initialized
INFO - 2022-11-16 08:18:02 --> Language Class Initialized
INFO - 2022-11-16 08:18:02 --> Config Class Initialized
INFO - 2022-11-16 08:18:02 --> Loader Class Initialized
INFO - 2022-11-16 08:18:02 --> Helper loaded: url_helper
INFO - 2022-11-16 08:18:02 --> Helper loaded: file_helper
INFO - 2022-11-16 08:18:02 --> Helper loaded: form_helper
INFO - 2022-11-16 08:18:02 --> Helper loaded: my_helper
INFO - 2022-11-16 08:18:02 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:18:02 --> Controller Class Initialized
DEBUG - 2022-11-16 08:18:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-11-16 08:18:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:18:02 --> Final output sent to browser
DEBUG - 2022-11-16 08:18:02 --> Total execution time: 0.1904
INFO - 2022-11-16 08:23:19 --> Config Class Initialized
INFO - 2022-11-16 08:23:19 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:23:19 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:23:19 --> Utf8 Class Initialized
INFO - 2022-11-16 08:23:19 --> URI Class Initialized
INFO - 2022-11-16 08:23:19 --> Router Class Initialized
INFO - 2022-11-16 08:23:19 --> Output Class Initialized
INFO - 2022-11-16 08:23:20 --> Security Class Initialized
DEBUG - 2022-11-16 08:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:23:20 --> Input Class Initialized
INFO - 2022-11-16 08:23:20 --> Language Class Initialized
INFO - 2022-11-16 08:23:20 --> Language Class Initialized
INFO - 2022-11-16 08:23:20 --> Config Class Initialized
INFO - 2022-11-16 08:23:20 --> Loader Class Initialized
INFO - 2022-11-16 08:23:20 --> Helper loaded: url_helper
INFO - 2022-11-16 08:23:20 --> Helper loaded: file_helper
INFO - 2022-11-16 08:23:20 --> Helper loaded: form_helper
INFO - 2022-11-16 08:23:20 --> Helper loaded: my_helper
INFO - 2022-11-16 08:23:20 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:23:20 --> Controller Class Initialized
INFO - 2022-11-16 08:23:20 --> Helper loaded: cookie_helper
INFO - 2022-11-16 08:23:20 --> Config Class Initialized
INFO - 2022-11-16 08:23:20 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:23:20 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:23:20 --> Utf8 Class Initialized
INFO - 2022-11-16 08:23:20 --> URI Class Initialized
INFO - 2022-11-16 08:23:20 --> Router Class Initialized
INFO - 2022-11-16 08:23:20 --> Output Class Initialized
INFO - 2022-11-16 08:23:20 --> Security Class Initialized
DEBUG - 2022-11-16 08:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:23:20 --> Input Class Initialized
INFO - 2022-11-16 08:23:20 --> Language Class Initialized
INFO - 2022-11-16 08:23:20 --> Language Class Initialized
INFO - 2022-11-16 08:23:20 --> Config Class Initialized
INFO - 2022-11-16 08:23:20 --> Loader Class Initialized
INFO - 2022-11-16 08:23:20 --> Helper loaded: url_helper
INFO - 2022-11-16 08:23:20 --> Helper loaded: file_helper
INFO - 2022-11-16 08:23:20 --> Helper loaded: form_helper
INFO - 2022-11-16 08:23:20 --> Helper loaded: my_helper
INFO - 2022-11-16 08:23:20 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:23:20 --> Controller Class Initialized
DEBUG - 2022-11-16 08:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-11-16 08:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:23:20 --> Final output sent to browser
DEBUG - 2022-11-16 08:23:20 --> Total execution time: 0.0533
INFO - 2022-11-16 08:23:26 --> Config Class Initialized
INFO - 2022-11-16 08:23:26 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:23:26 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:23:26 --> Utf8 Class Initialized
INFO - 2022-11-16 08:23:26 --> URI Class Initialized
INFO - 2022-11-16 08:23:26 --> Router Class Initialized
INFO - 2022-11-16 08:23:26 --> Output Class Initialized
INFO - 2022-11-16 08:23:26 --> Security Class Initialized
DEBUG - 2022-11-16 08:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:23:26 --> Input Class Initialized
INFO - 2022-11-16 08:23:26 --> Language Class Initialized
INFO - 2022-11-16 08:23:26 --> Language Class Initialized
INFO - 2022-11-16 08:23:26 --> Config Class Initialized
INFO - 2022-11-16 08:23:26 --> Loader Class Initialized
INFO - 2022-11-16 08:23:26 --> Helper loaded: url_helper
INFO - 2022-11-16 08:23:26 --> Helper loaded: file_helper
INFO - 2022-11-16 08:23:26 --> Helper loaded: form_helper
INFO - 2022-11-16 08:23:26 --> Helper loaded: my_helper
INFO - 2022-11-16 08:23:26 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:23:26 --> Controller Class Initialized
INFO - 2022-11-16 08:23:26 --> Helper loaded: cookie_helper
INFO - 2022-11-16 08:23:26 --> Final output sent to browser
DEBUG - 2022-11-16 08:23:26 --> Total execution time: 0.0540
INFO - 2022-11-16 08:23:26 --> Config Class Initialized
INFO - 2022-11-16 08:23:26 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:23:26 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:23:26 --> Utf8 Class Initialized
INFO - 2022-11-16 08:23:26 --> URI Class Initialized
INFO - 2022-11-16 08:23:26 --> Router Class Initialized
INFO - 2022-11-16 08:23:26 --> Output Class Initialized
INFO - 2022-11-16 08:23:26 --> Security Class Initialized
DEBUG - 2022-11-16 08:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:23:26 --> Input Class Initialized
INFO - 2022-11-16 08:23:26 --> Language Class Initialized
INFO - 2022-11-16 08:23:26 --> Language Class Initialized
INFO - 2022-11-16 08:23:26 --> Config Class Initialized
INFO - 2022-11-16 08:23:26 --> Loader Class Initialized
INFO - 2022-11-16 08:23:26 --> Helper loaded: url_helper
INFO - 2022-11-16 08:23:26 --> Helper loaded: file_helper
INFO - 2022-11-16 08:23:26 --> Helper loaded: form_helper
INFO - 2022-11-16 08:23:26 --> Helper loaded: my_helper
INFO - 2022-11-16 08:23:26 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:23:26 --> Controller Class Initialized
DEBUG - 2022-11-16 08:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-11-16 08:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:23:26 --> Final output sent to browser
DEBUG - 2022-11-16 08:23:26 --> Total execution time: 0.0963
INFO - 2022-11-16 08:23:30 --> Config Class Initialized
INFO - 2022-11-16 08:23:30 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:23:30 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:23:30 --> Utf8 Class Initialized
INFO - 2022-11-16 08:23:30 --> URI Class Initialized
INFO - 2022-11-16 08:23:30 --> Router Class Initialized
INFO - 2022-11-16 08:23:30 --> Output Class Initialized
INFO - 2022-11-16 08:23:30 --> Security Class Initialized
DEBUG - 2022-11-16 08:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:23:30 --> Input Class Initialized
INFO - 2022-11-16 08:23:30 --> Language Class Initialized
INFO - 2022-11-16 08:23:30 --> Language Class Initialized
INFO - 2022-11-16 08:23:30 --> Config Class Initialized
INFO - 2022-11-16 08:23:30 --> Loader Class Initialized
INFO - 2022-11-16 08:23:30 --> Helper loaded: url_helper
INFO - 2022-11-16 08:23:30 --> Helper loaded: file_helper
INFO - 2022-11-16 08:23:30 --> Helper loaded: form_helper
INFO - 2022-11-16 08:23:30 --> Helper loaded: my_helper
INFO - 2022-11-16 08:23:30 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:23:30 --> Controller Class Initialized
DEBUG - 2022-11-16 08:23:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-11-16 08:23:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:23:30 --> Final output sent to browser
DEBUG - 2022-11-16 08:23:30 --> Total execution time: 0.1070
INFO - 2022-11-16 08:23:31 --> Config Class Initialized
INFO - 2022-11-16 08:23:31 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:23:31 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:23:31 --> Utf8 Class Initialized
INFO - 2022-11-16 08:23:31 --> URI Class Initialized
INFO - 2022-11-16 08:23:31 --> Router Class Initialized
INFO - 2022-11-16 08:23:31 --> Output Class Initialized
INFO - 2022-11-16 08:23:31 --> Security Class Initialized
DEBUG - 2022-11-16 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:23:31 --> Input Class Initialized
INFO - 2022-11-16 08:23:31 --> Language Class Initialized
INFO - 2022-11-16 08:23:31 --> Language Class Initialized
INFO - 2022-11-16 08:23:31 --> Config Class Initialized
INFO - 2022-11-16 08:23:31 --> Loader Class Initialized
INFO - 2022-11-16 08:23:31 --> Helper loaded: url_helper
INFO - 2022-11-16 08:23:31 --> Helper loaded: file_helper
INFO - 2022-11-16 08:23:31 --> Helper loaded: form_helper
INFO - 2022-11-16 08:23:31 --> Helper loaded: my_helper
INFO - 2022-11-16 08:23:31 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:23:31 --> Controller Class Initialized
DEBUG - 2022-11-16 08:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-11-16 08:23:32 --> Final output sent to browser
DEBUG - 2022-11-16 08:23:32 --> Total execution time: 0.1379
INFO - 2022-11-16 08:23:47 --> Config Class Initialized
INFO - 2022-11-16 08:23:47 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:23:47 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:23:47 --> Utf8 Class Initialized
INFO - 2022-11-16 08:23:47 --> URI Class Initialized
INFO - 2022-11-16 08:23:47 --> Router Class Initialized
INFO - 2022-11-16 08:23:47 --> Output Class Initialized
INFO - 2022-11-16 08:23:47 --> Security Class Initialized
DEBUG - 2022-11-16 08:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:23:47 --> Input Class Initialized
INFO - 2022-11-16 08:23:47 --> Language Class Initialized
INFO - 2022-11-16 08:23:47 --> Language Class Initialized
INFO - 2022-11-16 08:23:47 --> Config Class Initialized
INFO - 2022-11-16 08:23:47 --> Loader Class Initialized
INFO - 2022-11-16 08:23:47 --> Helper loaded: url_helper
INFO - 2022-11-16 08:23:47 --> Helper loaded: file_helper
INFO - 2022-11-16 08:23:47 --> Helper loaded: form_helper
INFO - 2022-11-16 08:23:47 --> Helper loaded: my_helper
INFO - 2022-11-16 08:23:47 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:23:47 --> Controller Class Initialized
ERROR - 2022-11-16 08:23:47 --> Severity: Notice --> Undefined index: ekstra C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 156
ERROR - 2022-11-16 08:23:47 --> Severity: Notice --> Undefined index: nilai C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 156
ERROR - 2022-11-16 08:23:47 --> Severity: Notice --> Undefined index: ekstra2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
ERROR - 2022-11-16 08:23:47 --> Severity: Notice --> Undefined index: nilai2 C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 157
DEBUG - 2022-11-16 08:23:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2022-11-16 08:23:47 --> Final output sent to browser
DEBUG - 2022-11-16 08:23:47 --> Total execution time: 0.1043
INFO - 2022-11-16 08:35:49 --> Config Class Initialized
INFO - 2022-11-16 08:35:49 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:35:49 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:35:49 --> Utf8 Class Initialized
INFO - 2022-11-16 08:35:49 --> URI Class Initialized
INFO - 2022-11-16 08:35:49 --> Router Class Initialized
INFO - 2022-11-16 08:35:49 --> Output Class Initialized
INFO - 2022-11-16 08:35:49 --> Security Class Initialized
DEBUG - 2022-11-16 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:35:49 --> Input Class Initialized
INFO - 2022-11-16 08:35:49 --> Language Class Initialized
INFO - 2022-11-16 08:35:49 --> Language Class Initialized
INFO - 2022-11-16 08:35:49 --> Config Class Initialized
INFO - 2022-11-16 08:35:49 --> Loader Class Initialized
INFO - 2022-11-16 08:35:49 --> Helper loaded: url_helper
INFO - 2022-11-16 08:35:49 --> Helper loaded: file_helper
INFO - 2022-11-16 08:35:49 --> Helper loaded: form_helper
INFO - 2022-11-16 08:35:49 --> Helper loaded: my_helper
INFO - 2022-11-16 08:35:49 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:35:49 --> Controller Class Initialized
INFO - 2022-11-16 08:35:49 --> Helper loaded: cookie_helper
INFO - 2022-11-16 08:35:49 --> Config Class Initialized
INFO - 2022-11-16 08:35:49 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:35:49 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:35:49 --> Utf8 Class Initialized
INFO - 2022-11-16 08:35:49 --> URI Class Initialized
INFO - 2022-11-16 08:35:49 --> Router Class Initialized
INFO - 2022-11-16 08:35:49 --> Output Class Initialized
INFO - 2022-11-16 08:35:49 --> Security Class Initialized
DEBUG - 2022-11-16 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:35:49 --> Input Class Initialized
INFO - 2022-11-16 08:35:49 --> Language Class Initialized
INFO - 2022-11-16 08:35:49 --> Language Class Initialized
INFO - 2022-11-16 08:35:49 --> Config Class Initialized
INFO - 2022-11-16 08:35:49 --> Loader Class Initialized
INFO - 2022-11-16 08:35:49 --> Helper loaded: url_helper
INFO - 2022-11-16 08:35:49 --> Helper loaded: file_helper
INFO - 2022-11-16 08:35:49 --> Helper loaded: form_helper
INFO - 2022-11-16 08:35:49 --> Helper loaded: my_helper
INFO - 2022-11-16 08:35:49 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:35:49 --> Controller Class Initialized
DEBUG - 2022-11-16 08:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-11-16 08:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:35:49 --> Final output sent to browser
DEBUG - 2022-11-16 08:35:49 --> Total execution time: 0.0694
INFO - 2022-11-16 08:35:59 --> Config Class Initialized
INFO - 2022-11-16 08:35:59 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:35:59 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:35:59 --> Utf8 Class Initialized
INFO - 2022-11-16 08:35:59 --> URI Class Initialized
INFO - 2022-11-16 08:35:59 --> Router Class Initialized
INFO - 2022-11-16 08:35:59 --> Output Class Initialized
INFO - 2022-11-16 08:35:59 --> Security Class Initialized
DEBUG - 2022-11-16 08:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:35:59 --> Input Class Initialized
INFO - 2022-11-16 08:35:59 --> Language Class Initialized
INFO - 2022-11-16 08:35:59 --> Language Class Initialized
INFO - 2022-11-16 08:35:59 --> Config Class Initialized
INFO - 2022-11-16 08:35:59 --> Loader Class Initialized
INFO - 2022-11-16 08:35:59 --> Helper loaded: url_helper
INFO - 2022-11-16 08:35:59 --> Helper loaded: file_helper
INFO - 2022-11-16 08:35:59 --> Helper loaded: form_helper
INFO - 2022-11-16 08:35:59 --> Helper loaded: my_helper
INFO - 2022-11-16 08:35:59 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:35:59 --> Controller Class Initialized
INFO - 2022-11-16 08:35:59 --> Helper loaded: cookie_helper
INFO - 2022-11-16 08:35:59 --> Final output sent to browser
DEBUG - 2022-11-16 08:35:59 --> Total execution time: 0.0663
INFO - 2022-11-16 08:35:59 --> Config Class Initialized
INFO - 2022-11-16 08:35:59 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:35:59 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:35:59 --> Utf8 Class Initialized
INFO - 2022-11-16 08:35:59 --> URI Class Initialized
INFO - 2022-11-16 08:35:59 --> Router Class Initialized
INFO - 2022-11-16 08:35:59 --> Output Class Initialized
INFO - 2022-11-16 08:35:59 --> Security Class Initialized
DEBUG - 2022-11-16 08:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:35:59 --> Input Class Initialized
INFO - 2022-11-16 08:35:59 --> Language Class Initialized
INFO - 2022-11-16 08:35:59 --> Language Class Initialized
INFO - 2022-11-16 08:35:59 --> Config Class Initialized
INFO - 2022-11-16 08:35:59 --> Loader Class Initialized
INFO - 2022-11-16 08:35:59 --> Helper loaded: url_helper
INFO - 2022-11-16 08:35:59 --> Helper loaded: file_helper
INFO - 2022-11-16 08:35:59 --> Helper loaded: form_helper
INFO - 2022-11-16 08:35:59 --> Helper loaded: my_helper
INFO - 2022-11-16 08:35:59 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:35:59 --> Controller Class Initialized
DEBUG - 2022-11-16 08:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-11-16 08:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:35:59 --> Final output sent to browser
DEBUG - 2022-11-16 08:35:59 --> Total execution time: 0.1034
INFO - 2022-11-16 08:36:01 --> Config Class Initialized
INFO - 2022-11-16 08:36:01 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:01 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:01 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:01 --> URI Class Initialized
INFO - 2022-11-16 08:36:01 --> Router Class Initialized
INFO - 2022-11-16 08:36:01 --> Output Class Initialized
INFO - 2022-11-16 08:36:01 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:01 --> Input Class Initialized
INFO - 2022-11-16 08:36:01 --> Language Class Initialized
INFO - 2022-11-16 08:36:01 --> Language Class Initialized
INFO - 2022-11-16 08:36:01 --> Config Class Initialized
INFO - 2022-11-16 08:36:01 --> Loader Class Initialized
INFO - 2022-11-16 08:36:01 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:01 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:01 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:01 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:01 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:01 --> Controller Class Initialized
DEBUG - 2022-11-16 08:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-11-16 08:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:36:01 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:01 --> Total execution time: 0.0846
INFO - 2022-11-16 08:36:01 --> Config Class Initialized
INFO - 2022-11-16 08:36:01 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:01 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:01 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:01 --> URI Class Initialized
INFO - 2022-11-16 08:36:01 --> Router Class Initialized
INFO - 2022-11-16 08:36:01 --> Output Class Initialized
INFO - 2022-11-16 08:36:01 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:01 --> Input Class Initialized
INFO - 2022-11-16 08:36:02 --> Language Class Initialized
INFO - 2022-11-16 08:36:02 --> Language Class Initialized
INFO - 2022-11-16 08:36:02 --> Config Class Initialized
INFO - 2022-11-16 08:36:02 --> Loader Class Initialized
INFO - 2022-11-16 08:36:02 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:02 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:02 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:02 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:02 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:02 --> Controller Class Initialized
INFO - 2022-11-16 08:36:06 --> Config Class Initialized
INFO - 2022-11-16 08:36:06 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:06 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:06 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:06 --> URI Class Initialized
INFO - 2022-11-16 08:36:06 --> Router Class Initialized
INFO - 2022-11-16 08:36:06 --> Output Class Initialized
INFO - 2022-11-16 08:36:06 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:06 --> Input Class Initialized
INFO - 2022-11-16 08:36:06 --> Language Class Initialized
INFO - 2022-11-16 08:36:06 --> Language Class Initialized
INFO - 2022-11-16 08:36:06 --> Config Class Initialized
INFO - 2022-11-16 08:36:06 --> Loader Class Initialized
INFO - 2022-11-16 08:36:06 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:06 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:06 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:06 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:06 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:06 --> Controller Class Initialized
INFO - 2022-11-16 08:36:06 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:06 --> Total execution time: 0.0573
INFO - 2022-11-16 08:36:06 --> Config Class Initialized
INFO - 2022-11-16 08:36:06 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:06 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:06 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:06 --> URI Class Initialized
INFO - 2022-11-16 08:36:06 --> Router Class Initialized
INFO - 2022-11-16 08:36:06 --> Output Class Initialized
INFO - 2022-11-16 08:36:06 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:06 --> Input Class Initialized
INFO - 2022-11-16 08:36:06 --> Language Class Initialized
INFO - 2022-11-16 08:36:06 --> Language Class Initialized
INFO - 2022-11-16 08:36:06 --> Config Class Initialized
INFO - 2022-11-16 08:36:06 --> Loader Class Initialized
INFO - 2022-11-16 08:36:06 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:06 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:06 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:06 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:06 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:06 --> Controller Class Initialized
INFO - 2022-11-16 08:36:08 --> Config Class Initialized
INFO - 2022-11-16 08:36:08 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:08 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:08 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:08 --> URI Class Initialized
INFO - 2022-11-16 08:36:08 --> Router Class Initialized
INFO - 2022-11-16 08:36:08 --> Output Class Initialized
INFO - 2022-11-16 08:36:08 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:08 --> Input Class Initialized
INFO - 2022-11-16 08:36:08 --> Language Class Initialized
INFO - 2022-11-16 08:36:08 --> Language Class Initialized
INFO - 2022-11-16 08:36:08 --> Config Class Initialized
INFO - 2022-11-16 08:36:08 --> Loader Class Initialized
INFO - 2022-11-16 08:36:08 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:08 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:08 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:08 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:08 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:08 --> Controller Class Initialized
INFO - 2022-11-16 08:36:08 --> Helper loaded: cookie_helper
INFO - 2022-11-16 08:36:08 --> Config Class Initialized
INFO - 2022-11-16 08:36:08 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:08 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:08 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:08 --> URI Class Initialized
INFO - 2022-11-16 08:36:08 --> Router Class Initialized
INFO - 2022-11-16 08:36:08 --> Output Class Initialized
INFO - 2022-11-16 08:36:08 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:08 --> Input Class Initialized
INFO - 2022-11-16 08:36:08 --> Language Class Initialized
INFO - 2022-11-16 08:36:08 --> Language Class Initialized
INFO - 2022-11-16 08:36:08 --> Config Class Initialized
INFO - 2022-11-16 08:36:08 --> Loader Class Initialized
INFO - 2022-11-16 08:36:08 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:08 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:08 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:08 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:08 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:08 --> Controller Class Initialized
DEBUG - 2022-11-16 08:36:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-11-16 08:36:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:36:08 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:08 --> Total execution time: 0.0542
INFO - 2022-11-16 08:36:14 --> Config Class Initialized
INFO - 2022-11-16 08:36:14 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:14 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:14 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:14 --> URI Class Initialized
INFO - 2022-11-16 08:36:14 --> Router Class Initialized
INFO - 2022-11-16 08:36:14 --> Output Class Initialized
INFO - 2022-11-16 08:36:14 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:14 --> Input Class Initialized
INFO - 2022-11-16 08:36:14 --> Language Class Initialized
INFO - 2022-11-16 08:36:14 --> Language Class Initialized
INFO - 2022-11-16 08:36:14 --> Config Class Initialized
INFO - 2022-11-16 08:36:14 --> Loader Class Initialized
INFO - 2022-11-16 08:36:14 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:14 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:14 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:14 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:14 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:14 --> Controller Class Initialized
INFO - 2022-11-16 08:36:14 --> Helper loaded: cookie_helper
INFO - 2022-11-16 08:36:14 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:14 --> Total execution time: 0.0443
INFO - 2022-11-16 08:36:14 --> Config Class Initialized
INFO - 2022-11-16 08:36:14 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:14 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:14 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:14 --> URI Class Initialized
INFO - 2022-11-16 08:36:14 --> Router Class Initialized
INFO - 2022-11-16 08:36:14 --> Output Class Initialized
INFO - 2022-11-16 08:36:14 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:14 --> Input Class Initialized
INFO - 2022-11-16 08:36:14 --> Language Class Initialized
INFO - 2022-11-16 08:36:14 --> Language Class Initialized
INFO - 2022-11-16 08:36:14 --> Config Class Initialized
INFO - 2022-11-16 08:36:14 --> Loader Class Initialized
INFO - 2022-11-16 08:36:14 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:14 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:14 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:14 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:14 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:14 --> Controller Class Initialized
DEBUG - 2022-11-16 08:36:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-11-16 08:36:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:36:14 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:14 --> Total execution time: 0.5187
INFO - 2022-11-16 08:36:15 --> Config Class Initialized
INFO - 2022-11-16 08:36:15 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:15 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:15 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:15 --> URI Class Initialized
INFO - 2022-11-16 08:36:15 --> Router Class Initialized
INFO - 2022-11-16 08:36:15 --> Output Class Initialized
INFO - 2022-11-16 08:36:15 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:15 --> Input Class Initialized
INFO - 2022-11-16 08:36:15 --> Language Class Initialized
INFO - 2022-11-16 08:36:15 --> Language Class Initialized
INFO - 2022-11-16 08:36:15 --> Config Class Initialized
INFO - 2022-11-16 08:36:15 --> Loader Class Initialized
INFO - 2022-11-16 08:36:15 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:15 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:15 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:15 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:15 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:15 --> Controller Class Initialized
DEBUG - 2022-11-16 08:36:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-11-16 08:36:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:36:15 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:15 --> Total execution time: 0.1075
INFO - 2022-11-16 08:36:19 --> Config Class Initialized
INFO - 2022-11-16 08:36:19 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:19 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:19 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:19 --> URI Class Initialized
INFO - 2022-11-16 08:36:19 --> Router Class Initialized
INFO - 2022-11-16 08:36:19 --> Output Class Initialized
INFO - 2022-11-16 08:36:19 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:19 --> Input Class Initialized
INFO - 2022-11-16 08:36:19 --> Language Class Initialized
INFO - 2022-11-16 08:36:19 --> Language Class Initialized
INFO - 2022-11-16 08:36:19 --> Config Class Initialized
INFO - 2022-11-16 08:36:19 --> Loader Class Initialized
INFO - 2022-11-16 08:36:19 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:19 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:19 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:19 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:19 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:19 --> Controller Class Initialized
DEBUG - 2022-11-16 08:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-11-16 08:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-11-16 08:36:19 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:19 --> Total execution time: 0.0658
INFO - 2022-11-16 08:36:21 --> Config Class Initialized
INFO - 2022-11-16 08:36:21 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:21 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:21 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:21 --> URI Class Initialized
INFO - 2022-11-16 08:36:21 --> Router Class Initialized
INFO - 2022-11-16 08:36:21 --> Output Class Initialized
INFO - 2022-11-16 08:36:21 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:21 --> Input Class Initialized
INFO - 2022-11-16 08:36:21 --> Language Class Initialized
INFO - 2022-11-16 08:36:21 --> Language Class Initialized
INFO - 2022-11-16 08:36:22 --> Config Class Initialized
INFO - 2022-11-16 08:36:22 --> Loader Class Initialized
INFO - 2022-11-16 08:36:22 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:22 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:22 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:22 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:22 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:22 --> Controller Class Initialized
DEBUG - 2022-11-16 08:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-11-16 08:36:22 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:22 --> Total execution time: 0.2002
INFO - 2022-11-16 08:36:30 --> Config Class Initialized
INFO - 2022-11-16 08:36:30 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:30 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:30 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:30 --> URI Class Initialized
INFO - 2022-11-16 08:36:30 --> Router Class Initialized
INFO - 2022-11-16 08:36:30 --> Output Class Initialized
INFO - 2022-11-16 08:36:30 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:30 --> Input Class Initialized
INFO - 2022-11-16 08:36:30 --> Language Class Initialized
INFO - 2022-11-16 08:36:30 --> Language Class Initialized
INFO - 2022-11-16 08:36:30 --> Config Class Initialized
INFO - 2022-11-16 08:36:30 --> Loader Class Initialized
INFO - 2022-11-16 08:36:30 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:30 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:30 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:30 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:30 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:30 --> Controller Class Initialized
DEBUG - 2022-11-16 08:36:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-11-16 08:36:31 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:31 --> Total execution time: 0.1558
INFO - 2022-11-16 08:36:34 --> Config Class Initialized
INFO - 2022-11-16 08:36:34 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:34 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:34 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:34 --> URI Class Initialized
INFO - 2022-11-16 08:36:34 --> Router Class Initialized
INFO - 2022-11-16 08:36:34 --> Output Class Initialized
INFO - 2022-11-16 08:36:34 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:34 --> Input Class Initialized
INFO - 2022-11-16 08:36:34 --> Language Class Initialized
INFO - 2022-11-16 08:36:34 --> Language Class Initialized
INFO - 2022-11-16 08:36:34 --> Config Class Initialized
INFO - 2022-11-16 08:36:34 --> Loader Class Initialized
INFO - 2022-11-16 08:36:34 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:34 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:34 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:34 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:34 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:34 --> Controller Class Initialized
DEBUG - 2022-11-16 08:36:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-11-16 08:36:34 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:34 --> Total execution time: 0.1237
INFO - 2022-11-16 08:36:41 --> Config Class Initialized
INFO - 2022-11-16 08:36:41 --> Hooks Class Initialized
DEBUG - 2022-11-16 08:36:41 --> UTF-8 Support Enabled
INFO - 2022-11-16 08:36:41 --> Utf8 Class Initialized
INFO - 2022-11-16 08:36:41 --> URI Class Initialized
INFO - 2022-11-16 08:36:41 --> Router Class Initialized
INFO - 2022-11-16 08:36:41 --> Output Class Initialized
INFO - 2022-11-16 08:36:41 --> Security Class Initialized
DEBUG - 2022-11-16 08:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-11-16 08:36:41 --> Input Class Initialized
INFO - 2022-11-16 08:36:41 --> Language Class Initialized
INFO - 2022-11-16 08:36:41 --> Language Class Initialized
INFO - 2022-11-16 08:36:41 --> Config Class Initialized
INFO - 2022-11-16 08:36:41 --> Loader Class Initialized
INFO - 2022-11-16 08:36:41 --> Helper loaded: url_helper
INFO - 2022-11-16 08:36:41 --> Helper loaded: file_helper
INFO - 2022-11-16 08:36:41 --> Helper loaded: form_helper
INFO - 2022-11-16 08:36:41 --> Helper loaded: my_helper
INFO - 2022-11-16 08:36:41 --> Database Driver Class Initialized
DEBUG - 2022-11-16 08:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-11-16 08:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-11-16 08:36:41 --> Controller Class Initialized
DEBUG - 2022-11-16 08:36:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-11-16 08:36:41 --> Final output sent to browser
DEBUG - 2022-11-16 08:36:41 --> Total execution time: 0.1319
