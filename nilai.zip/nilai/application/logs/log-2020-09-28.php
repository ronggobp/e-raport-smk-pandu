<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-28 05:30:53 --> Config Class Initialized
INFO - 2020-09-28 05:30:54 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:30:54 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:30:54 --> Utf8 Class Initialized
INFO - 2020-09-28 05:30:54 --> URI Class Initialized
DEBUG - 2020-09-28 05:30:54 --> No URI present. Default controller set.
INFO - 2020-09-28 05:30:54 --> Router Class Initialized
INFO - 2020-09-28 05:30:54 --> Output Class Initialized
INFO - 2020-09-28 05:30:54 --> Security Class Initialized
DEBUG - 2020-09-28 05:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:30:54 --> Input Class Initialized
INFO - 2020-09-28 05:30:54 --> Language Class Initialized
INFO - 2020-09-28 05:30:54 --> Language Class Initialized
INFO - 2020-09-28 05:30:54 --> Config Class Initialized
INFO - 2020-09-28 05:30:54 --> Loader Class Initialized
INFO - 2020-09-28 05:30:54 --> Helper loaded: url_helper
INFO - 2020-09-28 05:30:54 --> Helper loaded: file_helper
INFO - 2020-09-28 05:30:54 --> Helper loaded: form_helper
INFO - 2020-09-28 05:30:54 --> Helper loaded: my_helper
INFO - 2020-09-28 05:30:54 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:30:54 --> Controller Class Initialized
INFO - 2020-09-28 05:30:54 --> Config Class Initialized
INFO - 2020-09-28 05:30:54 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:30:54 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:30:54 --> Utf8 Class Initialized
INFO - 2020-09-28 05:30:54 --> URI Class Initialized
INFO - 2020-09-28 05:30:54 --> Router Class Initialized
INFO - 2020-09-28 05:30:54 --> Output Class Initialized
INFO - 2020-09-28 05:30:54 --> Security Class Initialized
DEBUG - 2020-09-28 05:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:30:54 --> Input Class Initialized
INFO - 2020-09-28 05:30:54 --> Language Class Initialized
INFO - 2020-09-28 05:30:54 --> Language Class Initialized
INFO - 2020-09-28 05:30:54 --> Config Class Initialized
INFO - 2020-09-28 05:30:54 --> Loader Class Initialized
INFO - 2020-09-28 05:30:54 --> Helper loaded: url_helper
INFO - 2020-09-28 05:30:54 --> Helper loaded: file_helper
INFO - 2020-09-28 05:30:54 --> Helper loaded: form_helper
INFO - 2020-09-28 05:30:54 --> Helper loaded: my_helper
INFO - 2020-09-28 05:30:54 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:30:54 --> Controller Class Initialized
DEBUG - 2020-09-28 05:30:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-28 05:30:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:30:54 --> Final output sent to browser
DEBUG - 2020-09-28 05:30:54 --> Total execution time: 0.2459
INFO - 2020-09-28 05:45:03 --> Config Class Initialized
INFO - 2020-09-28 05:45:03 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:45:03 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:45:03 --> Utf8 Class Initialized
INFO - 2020-09-28 05:45:03 --> URI Class Initialized
INFO - 2020-09-28 05:45:03 --> Router Class Initialized
INFO - 2020-09-28 05:45:03 --> Output Class Initialized
INFO - 2020-09-28 05:45:03 --> Security Class Initialized
DEBUG - 2020-09-28 05:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:45:03 --> Input Class Initialized
INFO - 2020-09-28 05:45:03 --> Language Class Initialized
INFO - 2020-09-28 05:45:03 --> Language Class Initialized
INFO - 2020-09-28 05:45:03 --> Config Class Initialized
INFO - 2020-09-28 05:45:03 --> Loader Class Initialized
INFO - 2020-09-28 05:45:03 --> Helper loaded: url_helper
INFO - 2020-09-28 05:45:03 --> Helper loaded: file_helper
INFO - 2020-09-28 05:45:03 --> Helper loaded: form_helper
INFO - 2020-09-28 05:45:03 --> Helper loaded: my_helper
INFO - 2020-09-28 05:45:03 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:45:03 --> Controller Class Initialized
DEBUG - 2020-09-28 05:45:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-28 05:45:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:45:03 --> Final output sent to browser
DEBUG - 2020-09-28 05:45:03 --> Total execution time: 0.2267
INFO - 2020-09-28 05:45:08 --> Config Class Initialized
INFO - 2020-09-28 05:45:08 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:45:08 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:45:08 --> Utf8 Class Initialized
INFO - 2020-09-28 05:45:08 --> URI Class Initialized
INFO - 2020-09-28 05:45:08 --> Router Class Initialized
INFO - 2020-09-28 05:45:08 --> Output Class Initialized
INFO - 2020-09-28 05:45:08 --> Security Class Initialized
DEBUG - 2020-09-28 05:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:45:08 --> Input Class Initialized
INFO - 2020-09-28 05:45:08 --> Language Class Initialized
ERROR - 2020-09-28 05:45:08 --> 404 Page Not Found: /index
INFO - 2020-09-28 05:49:00 --> Config Class Initialized
INFO - 2020-09-28 05:49:00 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:49:00 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:49:00 --> Utf8 Class Initialized
INFO - 2020-09-28 05:49:00 --> URI Class Initialized
INFO - 2020-09-28 05:49:00 --> Router Class Initialized
INFO - 2020-09-28 05:49:00 --> Output Class Initialized
INFO - 2020-09-28 05:49:00 --> Security Class Initialized
DEBUG - 2020-09-28 05:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:49:00 --> Input Class Initialized
INFO - 2020-09-28 05:49:00 --> Language Class Initialized
INFO - 2020-09-28 05:49:00 --> Language Class Initialized
INFO - 2020-09-28 05:49:00 --> Config Class Initialized
INFO - 2020-09-28 05:49:00 --> Loader Class Initialized
INFO - 2020-09-28 05:49:00 --> Helper loaded: url_helper
INFO - 2020-09-28 05:49:00 --> Helper loaded: file_helper
INFO - 2020-09-28 05:49:00 --> Helper loaded: form_helper
INFO - 2020-09-28 05:49:00 --> Helper loaded: my_helper
INFO - 2020-09-28 05:49:00 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:49:00 --> Controller Class Initialized
DEBUG - 2020-09-28 05:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-28 05:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:49:00 --> Final output sent to browser
DEBUG - 2020-09-28 05:49:00 --> Total execution time: 0.2185
INFO - 2020-09-28 05:49:51 --> Config Class Initialized
INFO - 2020-09-28 05:49:51 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:49:51 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:49:51 --> Utf8 Class Initialized
INFO - 2020-09-28 05:49:51 --> URI Class Initialized
INFO - 2020-09-28 05:49:51 --> Router Class Initialized
INFO - 2020-09-28 05:49:51 --> Output Class Initialized
INFO - 2020-09-28 05:49:51 --> Security Class Initialized
DEBUG - 2020-09-28 05:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:49:51 --> Input Class Initialized
INFO - 2020-09-28 05:49:51 --> Language Class Initialized
INFO - 2020-09-28 05:49:51 --> Language Class Initialized
INFO - 2020-09-28 05:49:51 --> Config Class Initialized
INFO - 2020-09-28 05:49:51 --> Loader Class Initialized
INFO - 2020-09-28 05:49:51 --> Helper loaded: url_helper
INFO - 2020-09-28 05:49:51 --> Helper loaded: file_helper
INFO - 2020-09-28 05:49:51 --> Helper loaded: form_helper
INFO - 2020-09-28 05:49:51 --> Helper loaded: my_helper
INFO - 2020-09-28 05:49:51 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:49:51 --> Controller Class Initialized
DEBUG - 2020-09-28 05:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-28 05:49:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:49:51 --> Final output sent to browser
DEBUG - 2020-09-28 05:49:51 --> Total execution time: 0.3212
INFO - 2020-09-28 05:50:16 --> Config Class Initialized
INFO - 2020-09-28 05:50:16 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:50:16 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:50:16 --> Utf8 Class Initialized
INFO - 2020-09-28 05:50:16 --> URI Class Initialized
INFO - 2020-09-28 05:50:16 --> Router Class Initialized
INFO - 2020-09-28 05:50:16 --> Output Class Initialized
INFO - 2020-09-28 05:50:16 --> Security Class Initialized
DEBUG - 2020-09-28 05:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:50:16 --> Input Class Initialized
INFO - 2020-09-28 05:50:16 --> Language Class Initialized
INFO - 2020-09-28 05:50:16 --> Language Class Initialized
INFO - 2020-09-28 05:50:16 --> Config Class Initialized
INFO - 2020-09-28 05:50:16 --> Loader Class Initialized
INFO - 2020-09-28 05:50:16 --> Helper loaded: url_helper
INFO - 2020-09-28 05:50:16 --> Helper loaded: file_helper
INFO - 2020-09-28 05:50:16 --> Helper loaded: form_helper
INFO - 2020-09-28 05:50:17 --> Helper loaded: my_helper
INFO - 2020-09-28 05:50:17 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:50:17 --> Controller Class Initialized
DEBUG - 2020-09-28 05:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-28 05:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:50:17 --> Final output sent to browser
DEBUG - 2020-09-28 05:50:17 --> Total execution time: 0.2505
INFO - 2020-09-28 05:50:32 --> Config Class Initialized
INFO - 2020-09-28 05:50:32 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:50:32 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:50:32 --> Utf8 Class Initialized
INFO - 2020-09-28 05:50:32 --> URI Class Initialized
INFO - 2020-09-28 05:50:32 --> Router Class Initialized
INFO - 2020-09-28 05:50:32 --> Output Class Initialized
INFO - 2020-09-28 05:50:32 --> Security Class Initialized
DEBUG - 2020-09-28 05:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:50:32 --> Input Class Initialized
INFO - 2020-09-28 05:50:32 --> Language Class Initialized
INFO - 2020-09-28 05:50:32 --> Language Class Initialized
INFO - 2020-09-28 05:50:32 --> Config Class Initialized
INFO - 2020-09-28 05:50:32 --> Loader Class Initialized
INFO - 2020-09-28 05:50:32 --> Helper loaded: url_helper
INFO - 2020-09-28 05:50:32 --> Helper loaded: file_helper
INFO - 2020-09-28 05:50:32 --> Helper loaded: form_helper
INFO - 2020-09-28 05:50:32 --> Helper loaded: my_helper
INFO - 2020-09-28 05:50:32 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:50:32 --> Controller Class Initialized
DEBUG - 2020-09-28 05:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-28 05:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:50:32 --> Final output sent to browser
DEBUG - 2020-09-28 05:50:32 --> Total execution time: 0.2529
INFO - 2020-09-28 05:50:47 --> Config Class Initialized
INFO - 2020-09-28 05:50:47 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:50:47 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:50:47 --> Utf8 Class Initialized
INFO - 2020-09-28 05:50:47 --> URI Class Initialized
INFO - 2020-09-28 05:50:47 --> Router Class Initialized
INFO - 2020-09-28 05:50:47 --> Output Class Initialized
INFO - 2020-09-28 05:50:47 --> Security Class Initialized
DEBUG - 2020-09-28 05:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:50:47 --> Input Class Initialized
INFO - 2020-09-28 05:50:47 --> Language Class Initialized
INFO - 2020-09-28 05:50:47 --> Language Class Initialized
INFO - 2020-09-28 05:50:47 --> Config Class Initialized
INFO - 2020-09-28 05:50:47 --> Loader Class Initialized
INFO - 2020-09-28 05:50:47 --> Helper loaded: url_helper
INFO - 2020-09-28 05:50:47 --> Helper loaded: file_helper
INFO - 2020-09-28 05:50:47 --> Helper loaded: form_helper
INFO - 2020-09-28 05:50:47 --> Helper loaded: my_helper
INFO - 2020-09-28 05:50:47 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:50:47 --> Controller Class Initialized
DEBUG - 2020-09-28 05:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-28 05:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:50:47 --> Final output sent to browser
DEBUG - 2020-09-28 05:50:47 --> Total execution time: 0.2205
INFO - 2020-09-28 05:51:08 --> Config Class Initialized
INFO - 2020-09-28 05:51:08 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:51:08 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:51:08 --> Utf8 Class Initialized
INFO - 2020-09-28 05:51:08 --> URI Class Initialized
INFO - 2020-09-28 05:51:08 --> Router Class Initialized
INFO - 2020-09-28 05:51:08 --> Output Class Initialized
INFO - 2020-09-28 05:51:08 --> Security Class Initialized
DEBUG - 2020-09-28 05:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:51:08 --> Input Class Initialized
INFO - 2020-09-28 05:51:08 --> Language Class Initialized
INFO - 2020-09-28 05:51:08 --> Language Class Initialized
INFO - 2020-09-28 05:51:08 --> Config Class Initialized
INFO - 2020-09-28 05:51:08 --> Loader Class Initialized
INFO - 2020-09-28 05:51:08 --> Helper loaded: url_helper
INFO - 2020-09-28 05:51:08 --> Helper loaded: file_helper
INFO - 2020-09-28 05:51:08 --> Helper loaded: form_helper
INFO - 2020-09-28 05:51:08 --> Helper loaded: my_helper
INFO - 2020-09-28 05:51:08 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:51:08 --> Controller Class Initialized
DEBUG - 2020-09-28 05:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-28 05:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:51:08 --> Final output sent to browser
DEBUG - 2020-09-28 05:51:08 --> Total execution time: 0.2221
INFO - 2020-09-28 05:52:33 --> Config Class Initialized
INFO - 2020-09-28 05:52:33 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:52:33 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:52:33 --> Utf8 Class Initialized
INFO - 2020-09-28 05:52:33 --> URI Class Initialized
INFO - 2020-09-28 05:52:33 --> Router Class Initialized
INFO - 2020-09-28 05:52:33 --> Output Class Initialized
INFO - 2020-09-28 05:52:33 --> Security Class Initialized
DEBUG - 2020-09-28 05:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:52:33 --> Input Class Initialized
INFO - 2020-09-28 05:52:33 --> Language Class Initialized
INFO - 2020-09-28 05:52:33 --> Language Class Initialized
INFO - 2020-09-28 05:52:33 --> Config Class Initialized
INFO - 2020-09-28 05:52:33 --> Loader Class Initialized
INFO - 2020-09-28 05:52:33 --> Helper loaded: url_helper
INFO - 2020-09-28 05:52:33 --> Helper loaded: file_helper
INFO - 2020-09-28 05:52:33 --> Helper loaded: form_helper
INFO - 2020-09-28 05:52:33 --> Helper loaded: my_helper
INFO - 2020-09-28 05:52:33 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:52:33 --> Controller Class Initialized
DEBUG - 2020-09-28 05:52:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-28 05:52:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:52:33 --> Final output sent to browser
DEBUG - 2020-09-28 05:52:33 --> Total execution time: 0.2303
INFO - 2020-09-28 05:54:00 --> Config Class Initialized
INFO - 2020-09-28 05:54:00 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:00 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:00 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:00 --> URI Class Initialized
INFO - 2020-09-28 05:54:00 --> Router Class Initialized
INFO - 2020-09-28 05:54:00 --> Output Class Initialized
INFO - 2020-09-28 05:54:00 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:00 --> Input Class Initialized
INFO - 2020-09-28 05:54:00 --> Language Class Initialized
INFO - 2020-09-28 05:54:00 --> Language Class Initialized
INFO - 2020-09-28 05:54:00 --> Config Class Initialized
INFO - 2020-09-28 05:54:00 --> Loader Class Initialized
INFO - 2020-09-28 05:54:00 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:00 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:00 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:00 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:00 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:01 --> Controller Class Initialized
INFO - 2020-09-28 05:54:01 --> Helper loaded: cookie_helper
INFO - 2020-09-28 05:54:01 --> Final output sent to browser
DEBUG - 2020-09-28 05:54:01 --> Total execution time: 0.3184
INFO - 2020-09-28 05:54:13 --> Config Class Initialized
INFO - 2020-09-28 05:54:13 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:13 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:13 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:13 --> URI Class Initialized
INFO - 2020-09-28 05:54:13 --> Router Class Initialized
INFO - 2020-09-28 05:54:13 --> Output Class Initialized
INFO - 2020-09-28 05:54:13 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:13 --> Input Class Initialized
INFO - 2020-09-28 05:54:13 --> Language Class Initialized
INFO - 2020-09-28 05:54:13 --> Language Class Initialized
INFO - 2020-09-28 05:54:13 --> Config Class Initialized
INFO - 2020-09-28 05:54:13 --> Loader Class Initialized
INFO - 2020-09-28 05:54:13 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:13 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:13 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:13 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:13 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:13 --> Controller Class Initialized
DEBUG - 2020-09-28 05:54:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-28 05:54:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:54:13 --> Final output sent to browser
DEBUG - 2020-09-28 05:54:13 --> Total execution time: 0.4011
INFO - 2020-09-28 05:54:16 --> Config Class Initialized
INFO - 2020-09-28 05:54:16 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:16 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:16 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:16 --> URI Class Initialized
INFO - 2020-09-28 05:54:16 --> Router Class Initialized
INFO - 2020-09-28 05:54:16 --> Output Class Initialized
INFO - 2020-09-28 05:54:16 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:16 --> Input Class Initialized
INFO - 2020-09-28 05:54:16 --> Language Class Initialized
INFO - 2020-09-28 05:54:16 --> Language Class Initialized
INFO - 2020-09-28 05:54:16 --> Config Class Initialized
INFO - 2020-09-28 05:54:16 --> Loader Class Initialized
INFO - 2020-09-28 05:54:16 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:16 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:17 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:17 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:17 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:17 --> Controller Class Initialized
INFO - 2020-09-28 05:54:17 --> Helper loaded: cookie_helper
INFO - 2020-09-28 05:54:17 --> Config Class Initialized
INFO - 2020-09-28 05:54:17 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:17 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:17 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:17 --> URI Class Initialized
INFO - 2020-09-28 05:54:17 --> Router Class Initialized
INFO - 2020-09-28 05:54:17 --> Output Class Initialized
INFO - 2020-09-28 05:54:17 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:17 --> Input Class Initialized
INFO - 2020-09-28 05:54:17 --> Language Class Initialized
INFO - 2020-09-28 05:54:17 --> Language Class Initialized
INFO - 2020-09-28 05:54:17 --> Config Class Initialized
INFO - 2020-09-28 05:54:17 --> Loader Class Initialized
INFO - 2020-09-28 05:54:17 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:17 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:17 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:17 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:17 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:17 --> Controller Class Initialized
DEBUG - 2020-09-28 05:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-28 05:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:54:17 --> Final output sent to browser
DEBUG - 2020-09-28 05:54:17 --> Total execution time: 0.2348
INFO - 2020-09-28 05:54:19 --> Config Class Initialized
INFO - 2020-09-28 05:54:19 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:19 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:19 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:19 --> URI Class Initialized
INFO - 2020-09-28 05:54:19 --> Router Class Initialized
INFO - 2020-09-28 05:54:19 --> Output Class Initialized
INFO - 2020-09-28 05:54:19 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:19 --> Input Class Initialized
INFO - 2020-09-28 05:54:19 --> Language Class Initialized
INFO - 2020-09-28 05:54:19 --> Language Class Initialized
INFO - 2020-09-28 05:54:19 --> Config Class Initialized
INFO - 2020-09-28 05:54:19 --> Loader Class Initialized
INFO - 2020-09-28 05:54:19 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:19 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:19 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:19 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:19 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:19 --> Controller Class Initialized
INFO - 2020-09-28 05:54:19 --> Helper loaded: cookie_helper
INFO - 2020-09-28 05:54:19 --> Config Class Initialized
INFO - 2020-09-28 05:54:19 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:19 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:19 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:19 --> URI Class Initialized
INFO - 2020-09-28 05:54:19 --> Router Class Initialized
INFO - 2020-09-28 05:54:19 --> Output Class Initialized
INFO - 2020-09-28 05:54:19 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:19 --> Input Class Initialized
INFO - 2020-09-28 05:54:19 --> Language Class Initialized
INFO - 2020-09-28 05:54:19 --> Language Class Initialized
INFO - 2020-09-28 05:54:19 --> Config Class Initialized
INFO - 2020-09-28 05:54:19 --> Loader Class Initialized
INFO - 2020-09-28 05:54:19 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:19 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:19 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:19 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:19 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:19 --> Controller Class Initialized
DEBUG - 2020-09-28 05:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-28 05:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:54:19 --> Final output sent to browser
DEBUG - 2020-09-28 05:54:19 --> Total execution time: 0.2342
INFO - 2020-09-28 05:54:20 --> Config Class Initialized
INFO - 2020-09-28 05:54:20 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:20 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:20 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:20 --> URI Class Initialized
INFO - 2020-09-28 05:54:20 --> Router Class Initialized
INFO - 2020-09-28 05:54:20 --> Output Class Initialized
INFO - 2020-09-28 05:54:20 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:20 --> Input Class Initialized
INFO - 2020-09-28 05:54:20 --> Language Class Initialized
INFO - 2020-09-28 05:54:20 --> Language Class Initialized
INFO - 2020-09-28 05:54:20 --> Config Class Initialized
INFO - 2020-09-28 05:54:20 --> Loader Class Initialized
INFO - 2020-09-28 05:54:20 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:20 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:20 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:20 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:20 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:20 --> Controller Class Initialized
INFO - 2020-09-28 05:54:20 --> Helper loaded: cookie_helper
INFO - 2020-09-28 05:54:20 --> Config Class Initialized
INFO - 2020-09-28 05:54:20 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:20 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:20 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:20 --> URI Class Initialized
INFO - 2020-09-28 05:54:20 --> Router Class Initialized
INFO - 2020-09-28 05:54:20 --> Output Class Initialized
INFO - 2020-09-28 05:54:20 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:20 --> Input Class Initialized
INFO - 2020-09-28 05:54:20 --> Language Class Initialized
INFO - 2020-09-28 05:54:20 --> Language Class Initialized
INFO - 2020-09-28 05:54:20 --> Config Class Initialized
INFO - 2020-09-28 05:54:20 --> Loader Class Initialized
INFO - 2020-09-28 05:54:20 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:20 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:20 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:20 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:21 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:21 --> Controller Class Initialized
DEBUG - 2020-09-28 05:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-28 05:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:54:21 --> Final output sent to browser
DEBUG - 2020-09-28 05:54:21 --> Total execution time: 0.2175
INFO - 2020-09-28 05:54:28 --> Config Class Initialized
INFO - 2020-09-28 05:54:28 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:28 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:28 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:28 --> URI Class Initialized
INFO - 2020-09-28 05:54:28 --> Router Class Initialized
INFO - 2020-09-28 05:54:28 --> Output Class Initialized
INFO - 2020-09-28 05:54:28 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:28 --> Input Class Initialized
INFO - 2020-09-28 05:54:28 --> Language Class Initialized
INFO - 2020-09-28 05:54:28 --> Language Class Initialized
INFO - 2020-09-28 05:54:28 --> Config Class Initialized
INFO - 2020-09-28 05:54:28 --> Loader Class Initialized
INFO - 2020-09-28 05:54:28 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:28 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:28 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:28 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:28 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:28 --> Controller Class Initialized
INFO - 2020-09-28 05:54:28 --> Helper loaded: cookie_helper
INFO - 2020-09-28 05:54:28 --> Config Class Initialized
INFO - 2020-09-28 05:54:28 --> Hooks Class Initialized
DEBUG - 2020-09-28 05:54:28 --> UTF-8 Support Enabled
INFO - 2020-09-28 05:54:28 --> Utf8 Class Initialized
INFO - 2020-09-28 05:54:28 --> URI Class Initialized
INFO - 2020-09-28 05:54:28 --> Router Class Initialized
INFO - 2020-09-28 05:54:29 --> Output Class Initialized
INFO - 2020-09-28 05:54:29 --> Security Class Initialized
DEBUG - 2020-09-28 05:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-28 05:54:29 --> Input Class Initialized
INFO - 2020-09-28 05:54:29 --> Language Class Initialized
INFO - 2020-09-28 05:54:29 --> Language Class Initialized
INFO - 2020-09-28 05:54:29 --> Config Class Initialized
INFO - 2020-09-28 05:54:29 --> Loader Class Initialized
INFO - 2020-09-28 05:54:29 --> Helper loaded: url_helper
INFO - 2020-09-28 05:54:29 --> Helper loaded: file_helper
INFO - 2020-09-28 05:54:29 --> Helper loaded: form_helper
INFO - 2020-09-28 05:54:29 --> Helper loaded: my_helper
INFO - 2020-09-28 05:54:29 --> Database Driver Class Initialized
DEBUG - 2020-09-28 05:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-28 05:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-28 05:54:29 --> Controller Class Initialized
DEBUG - 2020-09-28 05:54:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-28 05:54:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-28 05:54:29 --> Final output sent to browser
DEBUG - 2020-09-28 05:54:29 --> Total execution time: 0.2359
