<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-17 03:35:59 --> Config Class Initialized
INFO - 2020-10-17 03:35:59 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:35:59 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:35:59 --> Utf8 Class Initialized
INFO - 2020-10-17 03:35:59 --> URI Class Initialized
DEBUG - 2020-10-17 03:35:59 --> No URI present. Default controller set.
INFO - 2020-10-17 03:35:59 --> Router Class Initialized
INFO - 2020-10-17 03:35:59 --> Output Class Initialized
INFO - 2020-10-17 03:35:59 --> Security Class Initialized
DEBUG - 2020-10-17 03:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:35:59 --> Input Class Initialized
INFO - 2020-10-17 03:35:59 --> Language Class Initialized
INFO - 2020-10-17 03:35:59 --> Language Class Initialized
INFO - 2020-10-17 03:35:59 --> Config Class Initialized
INFO - 2020-10-17 03:35:59 --> Loader Class Initialized
INFO - 2020-10-17 03:35:59 --> Helper loaded: url_helper
INFO - 2020-10-17 03:35:59 --> Helper loaded: file_helper
INFO - 2020-10-17 03:35:59 --> Helper loaded: form_helper
INFO - 2020-10-17 03:35:59 --> Helper loaded: my_helper
INFO - 2020-10-17 03:35:59 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:35:59 --> Controller Class Initialized
INFO - 2020-10-17 03:35:59 --> Config Class Initialized
INFO - 2020-10-17 03:35:59 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:35:59 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:35:59 --> Utf8 Class Initialized
INFO - 2020-10-17 03:35:59 --> URI Class Initialized
INFO - 2020-10-17 03:35:59 --> Router Class Initialized
INFO - 2020-10-17 03:35:59 --> Output Class Initialized
INFO - 2020-10-17 03:35:59 --> Security Class Initialized
DEBUG - 2020-10-17 03:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:35:59 --> Input Class Initialized
INFO - 2020-10-17 03:35:59 --> Language Class Initialized
INFO - 2020-10-17 03:35:59 --> Language Class Initialized
INFO - 2020-10-17 03:35:59 --> Config Class Initialized
INFO - 2020-10-17 03:35:59 --> Loader Class Initialized
INFO - 2020-10-17 03:35:59 --> Helper loaded: url_helper
INFO - 2020-10-17 03:35:59 --> Helper loaded: file_helper
INFO - 2020-10-17 03:35:59 --> Helper loaded: form_helper
INFO - 2020-10-17 03:35:59 --> Helper loaded: my_helper
INFO - 2020-10-17 03:35:59 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:35:59 --> Controller Class Initialized
DEBUG - 2020-10-17 03:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 03:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 03:35:59 --> Final output sent to browser
DEBUG - 2020-10-17 03:36:00 --> Total execution time: 0.2551
INFO - 2020-10-17 03:36:12 --> Config Class Initialized
INFO - 2020-10-17 03:36:12 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:36:12 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:36:12 --> Utf8 Class Initialized
INFO - 2020-10-17 03:36:12 --> URI Class Initialized
INFO - 2020-10-17 03:36:12 --> Router Class Initialized
INFO - 2020-10-17 03:36:12 --> Output Class Initialized
INFO - 2020-10-17 03:36:12 --> Security Class Initialized
DEBUG - 2020-10-17 03:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:36:13 --> Input Class Initialized
INFO - 2020-10-17 03:36:13 --> Language Class Initialized
INFO - 2020-10-17 03:36:13 --> Language Class Initialized
INFO - 2020-10-17 03:36:13 --> Config Class Initialized
INFO - 2020-10-17 03:36:13 --> Loader Class Initialized
INFO - 2020-10-17 03:36:13 --> Helper loaded: url_helper
INFO - 2020-10-17 03:36:13 --> Helper loaded: file_helper
INFO - 2020-10-17 03:36:13 --> Helper loaded: form_helper
INFO - 2020-10-17 03:36:13 --> Helper loaded: my_helper
INFO - 2020-10-17 03:36:13 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:36:13 --> Controller Class Initialized
INFO - 2020-10-17 03:36:13 --> Helper loaded: cookie_helper
INFO - 2020-10-17 03:36:13 --> Final output sent to browser
DEBUG - 2020-10-17 03:36:13 --> Total execution time: 0.3260
INFO - 2020-10-17 03:36:14 --> Config Class Initialized
INFO - 2020-10-17 03:36:14 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:36:14 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:36:14 --> Utf8 Class Initialized
INFO - 2020-10-17 03:36:14 --> URI Class Initialized
INFO - 2020-10-17 03:36:14 --> Router Class Initialized
INFO - 2020-10-17 03:36:14 --> Output Class Initialized
INFO - 2020-10-17 03:36:14 --> Security Class Initialized
DEBUG - 2020-10-17 03:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:36:14 --> Input Class Initialized
INFO - 2020-10-17 03:36:14 --> Language Class Initialized
INFO - 2020-10-17 03:36:14 --> Language Class Initialized
INFO - 2020-10-17 03:36:14 --> Config Class Initialized
INFO - 2020-10-17 03:36:14 --> Loader Class Initialized
INFO - 2020-10-17 03:36:14 --> Helper loaded: url_helper
INFO - 2020-10-17 03:36:14 --> Helper loaded: file_helper
INFO - 2020-10-17 03:36:15 --> Helper loaded: form_helper
INFO - 2020-10-17 03:36:15 --> Helper loaded: my_helper
INFO - 2020-10-17 03:36:15 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:36:15 --> Controller Class Initialized
DEBUG - 2020-10-17 03:36:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 03:36:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 03:36:15 --> Final output sent to browser
DEBUG - 2020-10-17 03:36:15 --> Total execution time: 0.3714
INFO - 2020-10-17 03:36:16 --> Config Class Initialized
INFO - 2020-10-17 03:36:16 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:36:16 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:36:16 --> Utf8 Class Initialized
INFO - 2020-10-17 03:36:16 --> URI Class Initialized
INFO - 2020-10-17 03:36:16 --> Router Class Initialized
INFO - 2020-10-17 03:36:16 --> Output Class Initialized
INFO - 2020-10-17 03:36:16 --> Security Class Initialized
DEBUG - 2020-10-17 03:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:36:16 --> Input Class Initialized
INFO - 2020-10-17 03:36:16 --> Language Class Initialized
INFO - 2020-10-17 03:36:16 --> Language Class Initialized
INFO - 2020-10-17 03:36:16 --> Config Class Initialized
INFO - 2020-10-17 03:36:16 --> Loader Class Initialized
INFO - 2020-10-17 03:36:16 --> Helper loaded: url_helper
INFO - 2020-10-17 03:36:16 --> Helper loaded: file_helper
INFO - 2020-10-17 03:36:16 --> Helper loaded: form_helper
INFO - 2020-10-17 03:36:16 --> Helper loaded: my_helper
INFO - 2020-10-17 03:36:16 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:36:17 --> Controller Class Initialized
INFO - 2020-10-17 03:36:17 --> Helper loaded: cookie_helper
INFO - 2020-10-17 03:36:17 --> Config Class Initialized
INFO - 2020-10-17 03:36:17 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:36:17 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:36:17 --> Utf8 Class Initialized
INFO - 2020-10-17 03:36:17 --> URI Class Initialized
INFO - 2020-10-17 03:36:17 --> Router Class Initialized
INFO - 2020-10-17 03:36:17 --> Output Class Initialized
INFO - 2020-10-17 03:36:17 --> Security Class Initialized
DEBUG - 2020-10-17 03:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:36:17 --> Input Class Initialized
INFO - 2020-10-17 03:36:17 --> Language Class Initialized
INFO - 2020-10-17 03:36:17 --> Language Class Initialized
INFO - 2020-10-17 03:36:17 --> Config Class Initialized
INFO - 2020-10-17 03:36:17 --> Loader Class Initialized
INFO - 2020-10-17 03:36:17 --> Helper loaded: url_helper
INFO - 2020-10-17 03:36:17 --> Helper loaded: file_helper
INFO - 2020-10-17 03:36:17 --> Helper loaded: form_helper
INFO - 2020-10-17 03:36:17 --> Helper loaded: my_helper
INFO - 2020-10-17 03:36:17 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:36:17 --> Controller Class Initialized
DEBUG - 2020-10-17 03:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 03:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 03:36:17 --> Final output sent to browser
DEBUG - 2020-10-17 03:36:17 --> Total execution time: 0.2227
INFO - 2020-10-17 03:36:28 --> Config Class Initialized
INFO - 2020-10-17 03:36:28 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:36:28 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:36:28 --> Utf8 Class Initialized
INFO - 2020-10-17 03:36:28 --> URI Class Initialized
INFO - 2020-10-17 03:36:28 --> Router Class Initialized
INFO - 2020-10-17 03:36:28 --> Output Class Initialized
INFO - 2020-10-17 03:36:28 --> Security Class Initialized
DEBUG - 2020-10-17 03:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:36:28 --> Input Class Initialized
INFO - 2020-10-17 03:36:28 --> Language Class Initialized
INFO - 2020-10-17 03:36:28 --> Language Class Initialized
INFO - 2020-10-17 03:36:28 --> Config Class Initialized
INFO - 2020-10-17 03:36:28 --> Loader Class Initialized
INFO - 2020-10-17 03:36:28 --> Helper loaded: url_helper
INFO - 2020-10-17 03:36:28 --> Helper loaded: file_helper
INFO - 2020-10-17 03:36:28 --> Helper loaded: form_helper
INFO - 2020-10-17 03:36:28 --> Helper loaded: my_helper
INFO - 2020-10-17 03:36:28 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:36:28 --> Controller Class Initialized
INFO - 2020-10-17 03:36:28 --> Final output sent to browser
DEBUG - 2020-10-17 03:36:28 --> Total execution time: 0.2691
INFO - 2020-10-17 03:36:36 --> Config Class Initialized
INFO - 2020-10-17 03:36:36 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:36:36 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:36:36 --> Utf8 Class Initialized
INFO - 2020-10-17 03:36:36 --> URI Class Initialized
INFO - 2020-10-17 03:36:36 --> Router Class Initialized
INFO - 2020-10-17 03:36:36 --> Output Class Initialized
INFO - 2020-10-17 03:36:36 --> Security Class Initialized
DEBUG - 2020-10-17 03:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:36:36 --> Input Class Initialized
INFO - 2020-10-17 03:36:36 --> Language Class Initialized
INFO - 2020-10-17 03:36:36 --> Language Class Initialized
INFO - 2020-10-17 03:36:36 --> Config Class Initialized
INFO - 2020-10-17 03:36:36 --> Loader Class Initialized
INFO - 2020-10-17 03:36:36 --> Helper loaded: url_helper
INFO - 2020-10-17 03:36:36 --> Helper loaded: file_helper
INFO - 2020-10-17 03:36:36 --> Helper loaded: form_helper
INFO - 2020-10-17 03:36:36 --> Helper loaded: my_helper
INFO - 2020-10-17 03:36:36 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:36:36 --> Controller Class Initialized
INFO - 2020-10-17 03:36:36 --> Helper loaded: cookie_helper
INFO - 2020-10-17 03:36:36 --> Final output sent to browser
DEBUG - 2020-10-17 03:36:36 --> Total execution time: 0.2635
INFO - 2020-10-17 03:36:37 --> Config Class Initialized
INFO - 2020-10-17 03:36:37 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:36:37 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:36:37 --> Utf8 Class Initialized
INFO - 2020-10-17 03:36:37 --> URI Class Initialized
INFO - 2020-10-17 03:36:37 --> Router Class Initialized
INFO - 2020-10-17 03:36:37 --> Output Class Initialized
INFO - 2020-10-17 03:36:37 --> Security Class Initialized
DEBUG - 2020-10-17 03:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:36:37 --> Input Class Initialized
INFO - 2020-10-17 03:36:37 --> Language Class Initialized
INFO - 2020-10-17 03:36:37 --> Language Class Initialized
INFO - 2020-10-17 03:36:37 --> Config Class Initialized
INFO - 2020-10-17 03:36:37 --> Loader Class Initialized
INFO - 2020-10-17 03:36:37 --> Helper loaded: url_helper
INFO - 2020-10-17 03:36:37 --> Helper loaded: file_helper
INFO - 2020-10-17 03:36:37 --> Helper loaded: form_helper
INFO - 2020-10-17 03:36:37 --> Helper loaded: my_helper
INFO - 2020-10-17 03:36:37 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:36:37 --> Controller Class Initialized
DEBUG - 2020-10-17 03:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 03:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 03:36:37 --> Final output sent to browser
DEBUG - 2020-10-17 03:36:38 --> Total execution time: 0.3344
INFO - 2020-10-17 03:36:39 --> Config Class Initialized
INFO - 2020-10-17 03:36:39 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:36:39 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:36:39 --> Utf8 Class Initialized
INFO - 2020-10-17 03:36:39 --> URI Class Initialized
INFO - 2020-10-17 03:36:39 --> Router Class Initialized
INFO - 2020-10-17 03:36:39 --> Output Class Initialized
INFO - 2020-10-17 03:36:39 --> Security Class Initialized
DEBUG - 2020-10-17 03:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:36:39 --> Input Class Initialized
INFO - 2020-10-17 03:36:39 --> Language Class Initialized
INFO - 2020-10-17 03:36:39 --> Language Class Initialized
INFO - 2020-10-17 03:36:39 --> Config Class Initialized
INFO - 2020-10-17 03:36:39 --> Loader Class Initialized
INFO - 2020-10-17 03:36:39 --> Helper loaded: url_helper
INFO - 2020-10-17 03:36:39 --> Helper loaded: file_helper
INFO - 2020-10-17 03:36:39 --> Helper loaded: form_helper
INFO - 2020-10-17 03:36:39 --> Helper loaded: my_helper
INFO - 2020-10-17 03:36:39 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:36:39 --> Controller Class Initialized
INFO - 2020-10-17 03:36:39 --> Helper loaded: cookie_helper
INFO - 2020-10-17 03:36:39 --> Config Class Initialized
INFO - 2020-10-17 03:36:39 --> Hooks Class Initialized
DEBUG - 2020-10-17 03:36:39 --> UTF-8 Support Enabled
INFO - 2020-10-17 03:36:39 --> Utf8 Class Initialized
INFO - 2020-10-17 03:36:39 --> URI Class Initialized
INFO - 2020-10-17 03:36:39 --> Router Class Initialized
INFO - 2020-10-17 03:36:39 --> Output Class Initialized
INFO - 2020-10-17 03:36:39 --> Security Class Initialized
DEBUG - 2020-10-17 03:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 03:36:39 --> Input Class Initialized
INFO - 2020-10-17 03:36:39 --> Language Class Initialized
INFO - 2020-10-17 03:36:39 --> Language Class Initialized
INFO - 2020-10-17 03:36:39 --> Config Class Initialized
INFO - 2020-10-17 03:36:39 --> Loader Class Initialized
INFO - 2020-10-17 03:36:39 --> Helper loaded: url_helper
INFO - 2020-10-17 03:36:39 --> Helper loaded: file_helper
INFO - 2020-10-17 03:36:39 --> Helper loaded: form_helper
INFO - 2020-10-17 03:36:39 --> Helper loaded: my_helper
INFO - 2020-10-17 03:36:39 --> Database Driver Class Initialized
DEBUG - 2020-10-17 03:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 03:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 03:36:39 --> Controller Class Initialized
DEBUG - 2020-10-17 03:36:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 03:36:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 03:36:39 --> Final output sent to browser
DEBUG - 2020-10-17 03:36:39 --> Total execution time: 0.2436
INFO - 2020-10-17 05:00:07 --> Config Class Initialized
INFO - 2020-10-17 05:00:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:00:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:00:07 --> Utf8 Class Initialized
INFO - 2020-10-17 05:00:07 --> URI Class Initialized
INFO - 2020-10-17 05:00:07 --> Router Class Initialized
INFO - 2020-10-17 05:00:07 --> Output Class Initialized
INFO - 2020-10-17 05:00:07 --> Security Class Initialized
DEBUG - 2020-10-17 05:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:00:07 --> Input Class Initialized
INFO - 2020-10-17 05:00:07 --> Language Class Initialized
INFO - 2020-10-17 05:00:07 --> Language Class Initialized
INFO - 2020-10-17 05:00:07 --> Config Class Initialized
INFO - 2020-10-17 05:00:07 --> Loader Class Initialized
INFO - 2020-10-17 05:00:07 --> Helper loaded: url_helper
INFO - 2020-10-17 05:00:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:00:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:00:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:00:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:00:07 --> Controller Class Initialized
INFO - 2020-10-17 05:00:07 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:00:07 --> Final output sent to browser
DEBUG - 2020-10-17 05:00:07 --> Total execution time: 0.3206
INFO - 2020-10-17 05:00:08 --> Config Class Initialized
INFO - 2020-10-17 05:00:08 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:00:09 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:00:09 --> Utf8 Class Initialized
INFO - 2020-10-17 05:00:09 --> URI Class Initialized
INFO - 2020-10-17 05:00:09 --> Router Class Initialized
INFO - 2020-10-17 05:00:09 --> Output Class Initialized
INFO - 2020-10-17 05:00:09 --> Security Class Initialized
DEBUG - 2020-10-17 05:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:00:09 --> Input Class Initialized
INFO - 2020-10-17 05:00:09 --> Language Class Initialized
INFO - 2020-10-17 05:00:09 --> Language Class Initialized
INFO - 2020-10-17 05:00:09 --> Config Class Initialized
INFO - 2020-10-17 05:00:09 --> Loader Class Initialized
INFO - 2020-10-17 05:00:09 --> Helper loaded: url_helper
INFO - 2020-10-17 05:00:09 --> Helper loaded: file_helper
INFO - 2020-10-17 05:00:09 --> Helper loaded: form_helper
INFO - 2020-10-17 05:00:09 --> Helper loaded: my_helper
INFO - 2020-10-17 05:00:09 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:00:09 --> Controller Class Initialized
DEBUG - 2020-10-17 05:00:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:00:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:00:09 --> Final output sent to browser
DEBUG - 2020-10-17 05:00:09 --> Total execution time: 0.3594
INFO - 2020-10-17 05:00:10 --> Config Class Initialized
INFO - 2020-10-17 05:00:10 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:00:10 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:00:10 --> Utf8 Class Initialized
INFO - 2020-10-17 05:00:10 --> URI Class Initialized
INFO - 2020-10-17 05:00:10 --> Router Class Initialized
INFO - 2020-10-17 05:00:10 --> Output Class Initialized
INFO - 2020-10-17 05:00:10 --> Security Class Initialized
DEBUG - 2020-10-17 05:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:00:10 --> Input Class Initialized
INFO - 2020-10-17 05:00:10 --> Language Class Initialized
INFO - 2020-10-17 05:00:10 --> Language Class Initialized
INFO - 2020-10-17 05:00:10 --> Config Class Initialized
INFO - 2020-10-17 05:00:10 --> Loader Class Initialized
INFO - 2020-10-17 05:00:10 --> Helper loaded: url_helper
INFO - 2020-10-17 05:00:10 --> Helper loaded: file_helper
INFO - 2020-10-17 05:00:10 --> Helper loaded: form_helper
INFO - 2020-10-17 05:00:10 --> Helper loaded: my_helper
INFO - 2020-10-17 05:00:10 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:00:10 --> Controller Class Initialized
INFO - 2020-10-17 05:00:10 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:00:10 --> Config Class Initialized
INFO - 2020-10-17 05:00:10 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:00:10 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:00:10 --> Utf8 Class Initialized
INFO - 2020-10-17 05:00:10 --> URI Class Initialized
INFO - 2020-10-17 05:00:10 --> Router Class Initialized
INFO - 2020-10-17 05:00:10 --> Output Class Initialized
INFO - 2020-10-17 05:00:10 --> Security Class Initialized
DEBUG - 2020-10-17 05:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:00:10 --> Input Class Initialized
INFO - 2020-10-17 05:00:10 --> Language Class Initialized
INFO - 2020-10-17 05:00:10 --> Language Class Initialized
INFO - 2020-10-17 05:00:10 --> Config Class Initialized
INFO - 2020-10-17 05:00:10 --> Loader Class Initialized
INFO - 2020-10-17 05:00:10 --> Helper loaded: url_helper
INFO - 2020-10-17 05:00:10 --> Helper loaded: file_helper
INFO - 2020-10-17 05:00:10 --> Helper loaded: form_helper
INFO - 2020-10-17 05:00:10 --> Helper loaded: my_helper
INFO - 2020-10-17 05:00:10 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:00:10 --> Controller Class Initialized
DEBUG - 2020-10-17 05:00:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:00:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:00:10 --> Final output sent to browser
DEBUG - 2020-10-17 05:00:10 --> Total execution time: 0.2294
INFO - 2020-10-17 05:00:26 --> Config Class Initialized
INFO - 2020-10-17 05:00:26 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:00:26 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:00:26 --> Utf8 Class Initialized
INFO - 2020-10-17 05:00:26 --> URI Class Initialized
INFO - 2020-10-17 05:00:26 --> Router Class Initialized
INFO - 2020-10-17 05:00:26 --> Output Class Initialized
INFO - 2020-10-17 05:00:26 --> Security Class Initialized
DEBUG - 2020-10-17 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:00:26 --> Input Class Initialized
INFO - 2020-10-17 05:00:26 --> Language Class Initialized
INFO - 2020-10-17 05:00:26 --> Language Class Initialized
INFO - 2020-10-17 05:00:26 --> Config Class Initialized
INFO - 2020-10-17 05:00:26 --> Loader Class Initialized
INFO - 2020-10-17 05:00:26 --> Helper loaded: url_helper
INFO - 2020-10-17 05:00:26 --> Helper loaded: file_helper
INFO - 2020-10-17 05:00:26 --> Helper loaded: form_helper
INFO - 2020-10-17 05:00:27 --> Helper loaded: my_helper
INFO - 2020-10-17 05:00:27 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:00:27 --> Controller Class Initialized
DEBUG - 2020-10-17 05:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:00:27 --> Final output sent to browser
DEBUG - 2020-10-17 05:00:27 --> Total execution time: 1.2192
INFO - 2020-10-17 05:03:19 --> Config Class Initialized
INFO - 2020-10-17 05:03:19 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:03:19 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:03:20 --> Utf8 Class Initialized
INFO - 2020-10-17 05:03:20 --> URI Class Initialized
INFO - 2020-10-17 05:03:20 --> Router Class Initialized
INFO - 2020-10-17 05:03:20 --> Output Class Initialized
INFO - 2020-10-17 05:03:20 --> Security Class Initialized
DEBUG - 2020-10-17 05:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:03:20 --> Input Class Initialized
INFO - 2020-10-17 05:03:20 --> Language Class Initialized
INFO - 2020-10-17 05:03:20 --> Language Class Initialized
INFO - 2020-10-17 05:03:20 --> Config Class Initialized
INFO - 2020-10-17 05:03:20 --> Loader Class Initialized
INFO - 2020-10-17 05:03:20 --> Helper loaded: url_helper
INFO - 2020-10-17 05:03:20 --> Helper loaded: file_helper
INFO - 2020-10-17 05:03:20 --> Helper loaded: form_helper
INFO - 2020-10-17 05:03:20 --> Helper loaded: my_helper
INFO - 2020-10-17 05:03:20 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:03:20 --> Controller Class Initialized
DEBUG - 2020-10-17 05:03:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:03:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:03:20 --> Final output sent to browser
DEBUG - 2020-10-17 05:03:20 --> Total execution time: 1.0356
INFO - 2020-10-17 05:03:21 --> Config Class Initialized
INFO - 2020-10-17 05:03:21 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:03:21 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:03:21 --> Utf8 Class Initialized
INFO - 2020-10-17 05:03:22 --> URI Class Initialized
INFO - 2020-10-17 05:03:22 --> Router Class Initialized
INFO - 2020-10-17 05:03:22 --> Output Class Initialized
INFO - 2020-10-17 05:03:22 --> Security Class Initialized
DEBUG - 2020-10-17 05:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:03:22 --> Input Class Initialized
INFO - 2020-10-17 05:03:22 --> Language Class Initialized
INFO - 2020-10-17 05:03:22 --> Language Class Initialized
INFO - 2020-10-17 05:03:22 --> Config Class Initialized
INFO - 2020-10-17 05:03:22 --> Loader Class Initialized
INFO - 2020-10-17 05:03:22 --> Helper loaded: url_helper
INFO - 2020-10-17 05:03:22 --> Helper loaded: file_helper
INFO - 2020-10-17 05:03:22 --> Helper loaded: form_helper
INFO - 2020-10-17 05:03:22 --> Helper loaded: my_helper
INFO - 2020-10-17 05:03:22 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:03:22 --> Controller Class Initialized
INFO - 2020-10-17 05:03:22 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:03:22 --> Config Class Initialized
INFO - 2020-10-17 05:03:22 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:03:22 --> Utf8 Class Initialized
INFO - 2020-10-17 05:03:22 --> URI Class Initialized
INFO - 2020-10-17 05:03:22 --> Router Class Initialized
INFO - 2020-10-17 05:03:22 --> Output Class Initialized
INFO - 2020-10-17 05:03:23 --> Security Class Initialized
DEBUG - 2020-10-17 05:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:03:23 --> Input Class Initialized
INFO - 2020-10-17 05:03:23 --> Language Class Initialized
INFO - 2020-10-17 05:03:23 --> Language Class Initialized
INFO - 2020-10-17 05:03:23 --> Config Class Initialized
INFO - 2020-10-17 05:03:23 --> Loader Class Initialized
INFO - 2020-10-17 05:03:23 --> Helper loaded: url_helper
INFO - 2020-10-17 05:03:23 --> Helper loaded: file_helper
INFO - 2020-10-17 05:03:23 --> Helper loaded: form_helper
INFO - 2020-10-17 05:03:23 --> Helper loaded: my_helper
INFO - 2020-10-17 05:03:23 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:03:23 --> Controller Class Initialized
DEBUG - 2020-10-17 05:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:03:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:03:23 --> Final output sent to browser
DEBUG - 2020-10-17 05:03:23 --> Total execution time: 0.8611
INFO - 2020-10-17 05:11:30 --> Config Class Initialized
INFO - 2020-10-17 05:11:30 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:11:30 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:11:30 --> Utf8 Class Initialized
INFO - 2020-10-17 05:11:30 --> URI Class Initialized
INFO - 2020-10-17 05:11:30 --> Router Class Initialized
INFO - 2020-10-17 05:11:30 --> Output Class Initialized
INFO - 2020-10-17 05:11:30 --> Security Class Initialized
DEBUG - 2020-10-17 05:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:11:30 --> Input Class Initialized
INFO - 2020-10-17 05:11:30 --> Language Class Initialized
INFO - 2020-10-17 05:11:30 --> Language Class Initialized
INFO - 2020-10-17 05:11:30 --> Config Class Initialized
INFO - 2020-10-17 05:11:30 --> Loader Class Initialized
INFO - 2020-10-17 05:11:30 --> Helper loaded: url_helper
INFO - 2020-10-17 05:11:30 --> Helper loaded: file_helper
INFO - 2020-10-17 05:11:30 --> Helper loaded: form_helper
INFO - 2020-10-17 05:11:30 --> Helper loaded: my_helper
INFO - 2020-10-17 05:11:30 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:11:31 --> Controller Class Initialized
DEBUG - 2020-10-17 05:11:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:11:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:11:31 --> Final output sent to browser
DEBUG - 2020-10-17 05:11:31 --> Total execution time: 1.0576
INFO - 2020-10-17 05:11:32 --> Config Class Initialized
INFO - 2020-10-17 05:11:32 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:11:32 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:11:32 --> Utf8 Class Initialized
INFO - 2020-10-17 05:11:32 --> URI Class Initialized
INFO - 2020-10-17 05:11:32 --> Router Class Initialized
INFO - 2020-10-17 05:11:32 --> Output Class Initialized
INFO - 2020-10-17 05:11:32 --> Security Class Initialized
DEBUG - 2020-10-17 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:11:32 --> Input Class Initialized
INFO - 2020-10-17 05:11:32 --> Language Class Initialized
INFO - 2020-10-17 05:11:32 --> Language Class Initialized
INFO - 2020-10-17 05:11:32 --> Config Class Initialized
INFO - 2020-10-17 05:11:32 --> Loader Class Initialized
INFO - 2020-10-17 05:11:32 --> Helper loaded: url_helper
INFO - 2020-10-17 05:11:32 --> Helper loaded: file_helper
INFO - 2020-10-17 05:11:32 --> Helper loaded: form_helper
INFO - 2020-10-17 05:11:32 --> Helper loaded: my_helper
INFO - 2020-10-17 05:11:32 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:11:32 --> Controller Class Initialized
INFO - 2020-10-17 05:11:32 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:11:32 --> Config Class Initialized
INFO - 2020-10-17 05:11:32 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:11:32 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:11:33 --> Utf8 Class Initialized
INFO - 2020-10-17 05:11:33 --> URI Class Initialized
INFO - 2020-10-17 05:11:33 --> Router Class Initialized
INFO - 2020-10-17 05:11:33 --> Output Class Initialized
INFO - 2020-10-17 05:11:33 --> Security Class Initialized
DEBUG - 2020-10-17 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:11:33 --> Input Class Initialized
INFO - 2020-10-17 05:11:33 --> Language Class Initialized
INFO - 2020-10-17 05:11:33 --> Language Class Initialized
INFO - 2020-10-17 05:11:33 --> Config Class Initialized
INFO - 2020-10-17 05:11:33 --> Loader Class Initialized
INFO - 2020-10-17 05:11:33 --> Helper loaded: url_helper
INFO - 2020-10-17 05:11:33 --> Helper loaded: file_helper
INFO - 2020-10-17 05:11:33 --> Helper loaded: form_helper
INFO - 2020-10-17 05:11:33 --> Helper loaded: my_helper
INFO - 2020-10-17 05:11:33 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:11:33 --> Controller Class Initialized
DEBUG - 2020-10-17 05:11:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:11:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:11:33 --> Final output sent to browser
DEBUG - 2020-10-17 05:11:33 --> Total execution time: 0.7017
INFO - 2020-10-17 05:12:36 --> Config Class Initialized
INFO - 2020-10-17 05:12:36 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:12:36 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:12:36 --> Utf8 Class Initialized
INFO - 2020-10-17 05:12:36 --> URI Class Initialized
DEBUG - 2020-10-17 05:12:36 --> No URI present. Default controller set.
INFO - 2020-10-17 05:12:36 --> Router Class Initialized
INFO - 2020-10-17 05:12:36 --> Output Class Initialized
INFO - 2020-10-17 05:12:36 --> Security Class Initialized
DEBUG - 2020-10-17 05:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:12:36 --> Input Class Initialized
INFO - 2020-10-17 05:12:36 --> Language Class Initialized
INFO - 2020-10-17 05:12:36 --> Language Class Initialized
INFO - 2020-10-17 05:12:36 --> Config Class Initialized
INFO - 2020-10-17 05:12:36 --> Loader Class Initialized
INFO - 2020-10-17 05:12:36 --> Helper loaded: url_helper
INFO - 2020-10-17 05:12:36 --> Helper loaded: file_helper
INFO - 2020-10-17 05:12:36 --> Helper loaded: form_helper
INFO - 2020-10-17 05:12:36 --> Helper loaded: my_helper
INFO - 2020-10-17 05:12:36 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:12:37 --> Controller Class Initialized
DEBUG - 2020-10-17 05:12:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:12:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:12:37 --> Final output sent to browser
DEBUG - 2020-10-17 05:12:37 --> Total execution time: 0.7383
INFO - 2020-10-17 05:12:39 --> Config Class Initialized
INFO - 2020-10-17 05:12:39 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:12:39 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:12:39 --> Utf8 Class Initialized
INFO - 2020-10-17 05:12:39 --> URI Class Initialized
INFO - 2020-10-17 05:12:39 --> Router Class Initialized
INFO - 2020-10-17 05:12:39 --> Output Class Initialized
INFO - 2020-10-17 05:12:39 --> Security Class Initialized
DEBUG - 2020-10-17 05:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:12:39 --> Input Class Initialized
INFO - 2020-10-17 05:12:39 --> Language Class Initialized
INFO - 2020-10-17 05:12:39 --> Language Class Initialized
INFO - 2020-10-17 05:12:39 --> Config Class Initialized
INFO - 2020-10-17 05:12:39 --> Loader Class Initialized
INFO - 2020-10-17 05:12:39 --> Helper loaded: url_helper
INFO - 2020-10-17 05:12:39 --> Helper loaded: file_helper
INFO - 2020-10-17 05:12:39 --> Helper loaded: form_helper
INFO - 2020-10-17 05:12:39 --> Helper loaded: my_helper
INFO - 2020-10-17 05:12:39 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:12:40 --> Controller Class Initialized
INFO - 2020-10-17 05:12:40 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:12:40 --> Config Class Initialized
INFO - 2020-10-17 05:12:40 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:12:40 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:12:40 --> Utf8 Class Initialized
INFO - 2020-10-17 05:12:40 --> URI Class Initialized
INFO - 2020-10-17 05:12:40 --> Router Class Initialized
INFO - 2020-10-17 05:12:40 --> Output Class Initialized
INFO - 2020-10-17 05:12:40 --> Security Class Initialized
DEBUG - 2020-10-17 05:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:12:40 --> Input Class Initialized
INFO - 2020-10-17 05:12:40 --> Language Class Initialized
INFO - 2020-10-17 05:12:40 --> Language Class Initialized
INFO - 2020-10-17 05:12:40 --> Config Class Initialized
INFO - 2020-10-17 05:12:40 --> Loader Class Initialized
INFO - 2020-10-17 05:12:40 --> Helper loaded: url_helper
INFO - 2020-10-17 05:12:40 --> Helper loaded: file_helper
INFO - 2020-10-17 05:12:40 --> Helper loaded: form_helper
INFO - 2020-10-17 05:12:40 --> Helper loaded: my_helper
INFO - 2020-10-17 05:12:40 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:12:41 --> Controller Class Initialized
DEBUG - 2020-10-17 05:12:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:12:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:12:41 --> Final output sent to browser
DEBUG - 2020-10-17 05:12:41 --> Total execution time: 0.9748
INFO - 2020-10-17 05:12:47 --> Config Class Initialized
INFO - 2020-10-17 05:12:47 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:12:48 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:12:48 --> Utf8 Class Initialized
INFO - 2020-10-17 05:12:48 --> URI Class Initialized
DEBUG - 2020-10-17 05:12:48 --> No URI present. Default controller set.
INFO - 2020-10-17 05:12:48 --> Router Class Initialized
INFO - 2020-10-17 05:12:48 --> Output Class Initialized
INFO - 2020-10-17 05:12:48 --> Security Class Initialized
DEBUG - 2020-10-17 05:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:12:48 --> Input Class Initialized
INFO - 2020-10-17 05:12:48 --> Language Class Initialized
INFO - 2020-10-17 05:12:48 --> Language Class Initialized
INFO - 2020-10-17 05:12:48 --> Config Class Initialized
INFO - 2020-10-17 05:12:48 --> Loader Class Initialized
INFO - 2020-10-17 05:12:48 --> Helper loaded: url_helper
INFO - 2020-10-17 05:12:48 --> Helper loaded: file_helper
INFO - 2020-10-17 05:12:48 --> Helper loaded: form_helper
INFO - 2020-10-17 05:12:48 --> Helper loaded: my_helper
INFO - 2020-10-17 05:12:48 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:12:48 --> Controller Class Initialized
INFO - 2020-10-17 05:12:48 --> Config Class Initialized
INFO - 2020-10-17 05:12:48 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:12:48 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:12:48 --> Utf8 Class Initialized
INFO - 2020-10-17 05:12:48 --> URI Class Initialized
INFO - 2020-10-17 05:12:48 --> Router Class Initialized
INFO - 2020-10-17 05:12:48 --> Output Class Initialized
INFO - 2020-10-17 05:12:48 --> Security Class Initialized
DEBUG - 2020-10-17 05:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:12:48 --> Input Class Initialized
INFO - 2020-10-17 05:12:48 --> Language Class Initialized
INFO - 2020-10-17 05:12:48 --> Language Class Initialized
INFO - 2020-10-17 05:12:48 --> Config Class Initialized
INFO - 2020-10-17 05:12:48 --> Loader Class Initialized
INFO - 2020-10-17 05:12:48 --> Helper loaded: url_helper
INFO - 2020-10-17 05:12:48 --> Helper loaded: file_helper
INFO - 2020-10-17 05:12:48 --> Helper loaded: form_helper
INFO - 2020-10-17 05:12:48 --> Helper loaded: my_helper
INFO - 2020-10-17 05:12:48 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:12:48 --> Controller Class Initialized
DEBUG - 2020-10-17 05:12:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:12:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:12:49 --> Final output sent to browser
DEBUG - 2020-10-17 05:12:49 --> Total execution time: 0.6552
INFO - 2020-10-17 05:13:49 --> Config Class Initialized
INFO - 2020-10-17 05:13:49 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:13:49 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:13:49 --> Utf8 Class Initialized
INFO - 2020-10-17 05:13:49 --> URI Class Initialized
INFO - 2020-10-17 05:13:49 --> Router Class Initialized
INFO - 2020-10-17 05:13:49 --> Output Class Initialized
INFO - 2020-10-17 05:13:49 --> Security Class Initialized
DEBUG - 2020-10-17 05:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:13:49 --> Input Class Initialized
INFO - 2020-10-17 05:13:49 --> Language Class Initialized
INFO - 2020-10-17 05:13:49 --> Language Class Initialized
INFO - 2020-10-17 05:13:49 --> Config Class Initialized
INFO - 2020-10-17 05:13:49 --> Loader Class Initialized
INFO - 2020-10-17 05:13:49 --> Helper loaded: url_helper
INFO - 2020-10-17 05:13:49 --> Helper loaded: file_helper
INFO - 2020-10-17 05:13:49 --> Helper loaded: form_helper
INFO - 2020-10-17 05:13:49 --> Helper loaded: my_helper
INFO - 2020-10-17 05:13:49 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:13:49 --> Controller Class Initialized
INFO - 2020-10-17 05:13:50 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:13:50 --> Final output sent to browser
DEBUG - 2020-10-17 05:13:50 --> Total execution time: 0.6944
INFO - 2020-10-17 05:13:51 --> Config Class Initialized
INFO - 2020-10-17 05:13:51 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:13:51 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:13:51 --> Utf8 Class Initialized
INFO - 2020-10-17 05:13:51 --> URI Class Initialized
INFO - 2020-10-17 05:13:51 --> Router Class Initialized
INFO - 2020-10-17 05:13:51 --> Output Class Initialized
INFO - 2020-10-17 05:13:51 --> Security Class Initialized
DEBUG - 2020-10-17 05:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:13:51 --> Input Class Initialized
INFO - 2020-10-17 05:13:51 --> Language Class Initialized
INFO - 2020-10-17 05:13:51 --> Language Class Initialized
INFO - 2020-10-17 05:13:51 --> Config Class Initialized
INFO - 2020-10-17 05:13:51 --> Loader Class Initialized
INFO - 2020-10-17 05:13:51 --> Helper loaded: url_helper
INFO - 2020-10-17 05:13:51 --> Helper loaded: file_helper
INFO - 2020-10-17 05:13:51 --> Helper loaded: form_helper
INFO - 2020-10-17 05:13:51 --> Helper loaded: my_helper
INFO - 2020-10-17 05:13:51 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:13:51 --> Controller Class Initialized
DEBUG - 2020-10-17 05:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:13:51 --> Final output sent to browser
DEBUG - 2020-10-17 05:13:51 --> Total execution time: 0.6136
INFO - 2020-10-17 05:13:52 --> Config Class Initialized
INFO - 2020-10-17 05:13:52 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:13:52 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:13:52 --> Utf8 Class Initialized
INFO - 2020-10-17 05:13:52 --> URI Class Initialized
INFO - 2020-10-17 05:13:52 --> Router Class Initialized
INFO - 2020-10-17 05:13:53 --> Output Class Initialized
INFO - 2020-10-17 05:13:53 --> Security Class Initialized
DEBUG - 2020-10-17 05:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:13:53 --> Input Class Initialized
INFO - 2020-10-17 05:13:53 --> Language Class Initialized
INFO - 2020-10-17 05:13:53 --> Language Class Initialized
INFO - 2020-10-17 05:13:53 --> Config Class Initialized
INFO - 2020-10-17 05:13:53 --> Loader Class Initialized
INFO - 2020-10-17 05:13:53 --> Helper loaded: url_helper
INFO - 2020-10-17 05:13:53 --> Helper loaded: file_helper
INFO - 2020-10-17 05:13:53 --> Helper loaded: form_helper
INFO - 2020-10-17 05:13:53 --> Helper loaded: my_helper
INFO - 2020-10-17 05:13:53 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:13:53 --> Controller Class Initialized
INFO - 2020-10-17 05:13:53 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:13:53 --> Config Class Initialized
INFO - 2020-10-17 05:13:53 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:13:53 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:13:53 --> Utf8 Class Initialized
INFO - 2020-10-17 05:13:53 --> URI Class Initialized
INFO - 2020-10-17 05:13:53 --> Router Class Initialized
INFO - 2020-10-17 05:13:53 --> Output Class Initialized
INFO - 2020-10-17 05:13:53 --> Security Class Initialized
DEBUG - 2020-10-17 05:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:13:54 --> Input Class Initialized
INFO - 2020-10-17 05:13:54 --> Language Class Initialized
INFO - 2020-10-17 05:13:54 --> Language Class Initialized
INFO - 2020-10-17 05:13:54 --> Config Class Initialized
INFO - 2020-10-17 05:13:54 --> Loader Class Initialized
INFO - 2020-10-17 05:13:54 --> Helper loaded: url_helper
INFO - 2020-10-17 05:13:54 --> Helper loaded: file_helper
INFO - 2020-10-17 05:13:54 --> Helper loaded: form_helper
INFO - 2020-10-17 05:13:54 --> Helper loaded: my_helper
INFO - 2020-10-17 05:13:54 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:13:54 --> Controller Class Initialized
DEBUG - 2020-10-17 05:13:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:13:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:13:54 --> Final output sent to browser
DEBUG - 2020-10-17 05:13:54 --> Total execution time: 0.9133
INFO - 2020-10-17 05:14:00 --> Config Class Initialized
INFO - 2020-10-17 05:14:00 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:14:00 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:14:00 --> Utf8 Class Initialized
INFO - 2020-10-17 05:14:00 --> URI Class Initialized
INFO - 2020-10-17 05:14:00 --> Router Class Initialized
INFO - 2020-10-17 05:14:00 --> Output Class Initialized
INFO - 2020-10-17 05:14:00 --> Security Class Initialized
DEBUG - 2020-10-17 05:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:14:00 --> Input Class Initialized
INFO - 2020-10-17 05:14:00 --> Language Class Initialized
INFO - 2020-10-17 05:14:00 --> Language Class Initialized
INFO - 2020-10-17 05:14:00 --> Config Class Initialized
INFO - 2020-10-17 05:14:00 --> Loader Class Initialized
INFO - 2020-10-17 05:14:00 --> Helper loaded: url_helper
INFO - 2020-10-17 05:14:00 --> Helper loaded: file_helper
INFO - 2020-10-17 05:14:00 --> Helper loaded: form_helper
INFO - 2020-10-17 05:14:01 --> Helper loaded: my_helper
INFO - 2020-10-17 05:14:01 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:14:01 --> Controller Class Initialized
INFO - 2020-10-17 05:14:01 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:14:01 --> Final output sent to browser
DEBUG - 2020-10-17 05:14:01 --> Total execution time: 0.9267
INFO - 2020-10-17 05:14:02 --> Config Class Initialized
INFO - 2020-10-17 05:14:02 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:14:02 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:14:02 --> Utf8 Class Initialized
INFO - 2020-10-17 05:14:02 --> URI Class Initialized
INFO - 2020-10-17 05:14:02 --> Router Class Initialized
INFO - 2020-10-17 05:14:02 --> Output Class Initialized
INFO - 2020-10-17 05:14:02 --> Security Class Initialized
DEBUG - 2020-10-17 05:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:14:02 --> Input Class Initialized
INFO - 2020-10-17 05:14:02 --> Language Class Initialized
INFO - 2020-10-17 05:14:02 --> Language Class Initialized
INFO - 2020-10-17 05:14:02 --> Config Class Initialized
INFO - 2020-10-17 05:14:02 --> Loader Class Initialized
INFO - 2020-10-17 05:14:03 --> Helper loaded: url_helper
INFO - 2020-10-17 05:14:03 --> Helper loaded: file_helper
INFO - 2020-10-17 05:14:03 --> Helper loaded: form_helper
INFO - 2020-10-17 05:14:03 --> Helper loaded: my_helper
INFO - 2020-10-17 05:14:03 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:14:03 --> Controller Class Initialized
DEBUG - 2020-10-17 05:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:14:03 --> Final output sent to browser
DEBUG - 2020-10-17 05:14:03 --> Total execution time: 0.8563
INFO - 2020-10-17 05:14:47 --> Config Class Initialized
INFO - 2020-10-17 05:14:47 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:14:47 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:14:47 --> Utf8 Class Initialized
INFO - 2020-10-17 05:14:47 --> URI Class Initialized
INFO - 2020-10-17 05:14:47 --> Router Class Initialized
INFO - 2020-10-17 05:14:47 --> Output Class Initialized
INFO - 2020-10-17 05:14:47 --> Security Class Initialized
DEBUG - 2020-10-17 05:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:14:47 --> Input Class Initialized
INFO - 2020-10-17 05:14:47 --> Language Class Initialized
INFO - 2020-10-17 05:14:47 --> Language Class Initialized
INFO - 2020-10-17 05:14:47 --> Config Class Initialized
INFO - 2020-10-17 05:14:47 --> Loader Class Initialized
INFO - 2020-10-17 05:14:47 --> Helper loaded: url_helper
INFO - 2020-10-17 05:14:47 --> Helper loaded: file_helper
INFO - 2020-10-17 05:14:47 --> Helper loaded: form_helper
INFO - 2020-10-17 05:14:47 --> Helper loaded: my_helper
INFO - 2020-10-17 05:14:47 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:14:47 --> Controller Class Initialized
INFO - 2020-10-17 05:14:47 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:14:47 --> Config Class Initialized
INFO - 2020-10-17 05:14:47 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:14:47 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:14:47 --> Utf8 Class Initialized
INFO - 2020-10-17 05:14:47 --> URI Class Initialized
INFO - 2020-10-17 05:14:48 --> Router Class Initialized
INFO - 2020-10-17 05:14:48 --> Output Class Initialized
INFO - 2020-10-17 05:14:48 --> Security Class Initialized
DEBUG - 2020-10-17 05:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:14:48 --> Input Class Initialized
INFO - 2020-10-17 05:14:48 --> Language Class Initialized
INFO - 2020-10-17 05:14:48 --> Language Class Initialized
INFO - 2020-10-17 05:14:48 --> Config Class Initialized
INFO - 2020-10-17 05:14:48 --> Loader Class Initialized
INFO - 2020-10-17 05:14:48 --> Helper loaded: url_helper
INFO - 2020-10-17 05:14:48 --> Helper loaded: file_helper
INFO - 2020-10-17 05:14:48 --> Helper loaded: form_helper
INFO - 2020-10-17 05:14:48 --> Helper loaded: my_helper
INFO - 2020-10-17 05:14:48 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:14:48 --> Controller Class Initialized
DEBUG - 2020-10-17 05:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:14:48 --> Final output sent to browser
DEBUG - 2020-10-17 05:14:48 --> Total execution time: 0.7289
INFO - 2020-10-17 05:14:54 --> Config Class Initialized
INFO - 2020-10-17 05:14:54 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:14:54 --> Utf8 Class Initialized
INFO - 2020-10-17 05:14:54 --> URI Class Initialized
INFO - 2020-10-17 05:14:54 --> Router Class Initialized
INFO - 2020-10-17 05:14:54 --> Output Class Initialized
INFO - 2020-10-17 05:14:54 --> Security Class Initialized
DEBUG - 2020-10-17 05:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:14:55 --> Input Class Initialized
INFO - 2020-10-17 05:14:55 --> Language Class Initialized
INFO - 2020-10-17 05:14:55 --> Language Class Initialized
INFO - 2020-10-17 05:14:55 --> Config Class Initialized
INFO - 2020-10-17 05:14:55 --> Loader Class Initialized
INFO - 2020-10-17 05:14:55 --> Helper loaded: url_helper
INFO - 2020-10-17 05:14:55 --> Helper loaded: file_helper
INFO - 2020-10-17 05:14:55 --> Helper loaded: form_helper
INFO - 2020-10-17 05:14:55 --> Helper loaded: my_helper
INFO - 2020-10-17 05:14:55 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:14:55 --> Controller Class Initialized
INFO - 2020-10-17 05:14:55 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:14:55 --> Final output sent to browser
DEBUG - 2020-10-17 05:14:55 --> Total execution time: 0.5824
INFO - 2020-10-17 05:14:58 --> Config Class Initialized
INFO - 2020-10-17 05:14:58 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:14:58 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:14:58 --> Utf8 Class Initialized
INFO - 2020-10-17 05:14:58 --> URI Class Initialized
INFO - 2020-10-17 05:14:58 --> Router Class Initialized
INFO - 2020-10-17 05:14:58 --> Output Class Initialized
INFO - 2020-10-17 05:14:58 --> Security Class Initialized
DEBUG - 2020-10-17 05:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:14:58 --> Input Class Initialized
INFO - 2020-10-17 05:14:58 --> Language Class Initialized
INFO - 2020-10-17 05:14:58 --> Language Class Initialized
INFO - 2020-10-17 05:14:58 --> Config Class Initialized
INFO - 2020-10-17 05:14:58 --> Loader Class Initialized
INFO - 2020-10-17 05:14:58 --> Helper loaded: url_helper
INFO - 2020-10-17 05:14:58 --> Helper loaded: file_helper
INFO - 2020-10-17 05:14:58 --> Helper loaded: form_helper
INFO - 2020-10-17 05:14:58 --> Helper loaded: my_helper
INFO - 2020-10-17 05:14:59 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:14:59 --> Controller Class Initialized
DEBUG - 2020-10-17 05:14:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:14:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:14:59 --> Final output sent to browser
DEBUG - 2020-10-17 05:14:59 --> Total execution time: 0.6186
INFO - 2020-10-17 05:15:11 --> Config Class Initialized
INFO - 2020-10-17 05:15:11 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:15:11 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:15:11 --> Utf8 Class Initialized
INFO - 2020-10-17 05:15:11 --> URI Class Initialized
INFO - 2020-10-17 05:15:11 --> Router Class Initialized
INFO - 2020-10-17 05:15:11 --> Output Class Initialized
INFO - 2020-10-17 05:15:11 --> Security Class Initialized
DEBUG - 2020-10-17 05:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:15:11 --> Input Class Initialized
INFO - 2020-10-17 05:15:11 --> Language Class Initialized
INFO - 2020-10-17 05:15:11 --> Language Class Initialized
INFO - 2020-10-17 05:15:11 --> Config Class Initialized
INFO - 2020-10-17 05:15:11 --> Loader Class Initialized
INFO - 2020-10-17 05:15:11 --> Helper loaded: url_helper
INFO - 2020-10-17 05:15:11 --> Helper loaded: file_helper
INFO - 2020-10-17 05:15:11 --> Helper loaded: form_helper
INFO - 2020-10-17 05:15:11 --> Helper loaded: my_helper
INFO - 2020-10-17 05:15:11 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:15:11 --> Controller Class Initialized
DEBUG - 2020-10-17 05:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-17 05:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:15:12 --> Final output sent to browser
DEBUG - 2020-10-17 05:15:12 --> Total execution time: 0.7245
INFO - 2020-10-17 05:15:16 --> Config Class Initialized
INFO - 2020-10-17 05:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:15:16 --> Utf8 Class Initialized
INFO - 2020-10-17 05:15:16 --> URI Class Initialized
INFO - 2020-10-17 05:15:16 --> Router Class Initialized
INFO - 2020-10-17 05:15:16 --> Output Class Initialized
INFO - 2020-10-17 05:15:16 --> Security Class Initialized
DEBUG - 2020-10-17 05:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:15:16 --> Input Class Initialized
INFO - 2020-10-17 05:15:16 --> Language Class Initialized
INFO - 2020-10-17 05:15:16 --> Language Class Initialized
INFO - 2020-10-17 05:15:16 --> Config Class Initialized
INFO - 2020-10-17 05:15:16 --> Loader Class Initialized
INFO - 2020-10-17 05:15:16 --> Helper loaded: url_helper
INFO - 2020-10-17 05:15:16 --> Helper loaded: file_helper
INFO - 2020-10-17 05:15:16 --> Helper loaded: form_helper
INFO - 2020-10-17 05:15:16 --> Helper loaded: my_helper
INFO - 2020-10-17 05:15:16 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:15:16 --> Controller Class Initialized
DEBUG - 2020-10-17 05:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-17 05:15:16 --> Final output sent to browser
DEBUG - 2020-10-17 05:15:16 --> Total execution time: 0.7882
INFO - 2020-10-17 05:15:24 --> Config Class Initialized
INFO - 2020-10-17 05:15:24 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:15:24 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:15:24 --> Utf8 Class Initialized
INFO - 2020-10-17 05:15:24 --> URI Class Initialized
INFO - 2020-10-17 05:15:24 --> Router Class Initialized
INFO - 2020-10-17 05:15:24 --> Output Class Initialized
INFO - 2020-10-17 05:15:24 --> Security Class Initialized
DEBUG - 2020-10-17 05:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:15:24 --> Input Class Initialized
INFO - 2020-10-17 05:15:24 --> Language Class Initialized
INFO - 2020-10-17 05:15:24 --> Language Class Initialized
INFO - 2020-10-17 05:15:24 --> Config Class Initialized
INFO - 2020-10-17 05:15:24 --> Loader Class Initialized
INFO - 2020-10-17 05:15:24 --> Helper loaded: url_helper
INFO - 2020-10-17 05:15:24 --> Helper loaded: file_helper
INFO - 2020-10-17 05:15:24 --> Helper loaded: form_helper
INFO - 2020-10-17 05:15:24 --> Helper loaded: my_helper
INFO - 2020-10-17 05:15:24 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:15:24 --> Controller Class Initialized
DEBUG - 2020-10-17 05:15:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-17 05:15:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:15:25 --> Final output sent to browser
DEBUG - 2020-10-17 05:15:25 --> Total execution time: 1.0102
INFO - 2020-10-17 05:15:29 --> Config Class Initialized
INFO - 2020-10-17 05:15:29 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:15:29 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:15:29 --> Utf8 Class Initialized
INFO - 2020-10-17 05:15:29 --> URI Class Initialized
DEBUG - 2020-10-17 05:15:29 --> No URI present. Default controller set.
INFO - 2020-10-17 05:15:29 --> Router Class Initialized
INFO - 2020-10-17 05:15:29 --> Output Class Initialized
INFO - 2020-10-17 05:15:30 --> Security Class Initialized
DEBUG - 2020-10-17 05:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:15:30 --> Input Class Initialized
INFO - 2020-10-17 05:15:30 --> Language Class Initialized
INFO - 2020-10-17 05:15:30 --> Language Class Initialized
INFO - 2020-10-17 05:15:30 --> Config Class Initialized
INFO - 2020-10-17 05:15:30 --> Loader Class Initialized
INFO - 2020-10-17 05:15:30 --> Helper loaded: url_helper
INFO - 2020-10-17 05:15:30 --> Helper loaded: file_helper
INFO - 2020-10-17 05:15:30 --> Helper loaded: form_helper
INFO - 2020-10-17 05:15:30 --> Helper loaded: my_helper
INFO - 2020-10-17 05:15:30 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:15:30 --> Controller Class Initialized
DEBUG - 2020-10-17 05:15:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:15:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:15:30 --> Final output sent to browser
DEBUG - 2020-10-17 05:15:30 --> Total execution time: 0.9174
INFO - 2020-10-17 05:15:33 --> Config Class Initialized
INFO - 2020-10-17 05:15:33 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:15:33 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:15:33 --> Utf8 Class Initialized
INFO - 2020-10-17 05:15:33 --> URI Class Initialized
INFO - 2020-10-17 05:15:33 --> Router Class Initialized
INFO - 2020-10-17 05:15:33 --> Output Class Initialized
INFO - 2020-10-17 05:15:33 --> Security Class Initialized
DEBUG - 2020-10-17 05:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:15:33 --> Input Class Initialized
INFO - 2020-10-17 05:15:33 --> Language Class Initialized
INFO - 2020-10-17 05:15:33 --> Language Class Initialized
INFO - 2020-10-17 05:15:33 --> Config Class Initialized
INFO - 2020-10-17 05:15:33 --> Loader Class Initialized
INFO - 2020-10-17 05:15:33 --> Helper loaded: url_helper
INFO - 2020-10-17 05:15:33 --> Helper loaded: file_helper
INFO - 2020-10-17 05:15:33 --> Helper loaded: form_helper
INFO - 2020-10-17 05:15:33 --> Helper loaded: my_helper
INFO - 2020-10-17 05:15:33 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:15:33 --> Controller Class Initialized
INFO - 2020-10-17 05:15:33 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:15:33 --> Config Class Initialized
INFO - 2020-10-17 05:15:33 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:15:33 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:15:33 --> Utf8 Class Initialized
INFO - 2020-10-17 05:15:33 --> URI Class Initialized
INFO - 2020-10-17 05:15:33 --> Router Class Initialized
INFO - 2020-10-17 05:15:33 --> Output Class Initialized
INFO - 2020-10-17 05:15:33 --> Security Class Initialized
DEBUG - 2020-10-17 05:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:15:34 --> Input Class Initialized
INFO - 2020-10-17 05:15:34 --> Language Class Initialized
INFO - 2020-10-17 05:15:34 --> Language Class Initialized
INFO - 2020-10-17 05:15:34 --> Config Class Initialized
INFO - 2020-10-17 05:15:34 --> Loader Class Initialized
INFO - 2020-10-17 05:15:34 --> Helper loaded: url_helper
INFO - 2020-10-17 05:15:34 --> Helper loaded: file_helper
INFO - 2020-10-17 05:15:34 --> Helper loaded: form_helper
INFO - 2020-10-17 05:15:34 --> Helper loaded: my_helper
INFO - 2020-10-17 05:15:34 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:15:34 --> Controller Class Initialized
DEBUG - 2020-10-17 05:15:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:15:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:15:34 --> Final output sent to browser
DEBUG - 2020-10-17 05:15:34 --> Total execution time: 0.8303
INFO - 2020-10-17 05:15:42 --> Config Class Initialized
INFO - 2020-10-17 05:15:42 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:15:42 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:15:42 --> Utf8 Class Initialized
INFO - 2020-10-17 05:15:42 --> URI Class Initialized
INFO - 2020-10-17 05:15:42 --> Router Class Initialized
INFO - 2020-10-17 05:15:42 --> Output Class Initialized
INFO - 2020-10-17 05:15:42 --> Security Class Initialized
DEBUG - 2020-10-17 05:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:15:42 --> Input Class Initialized
INFO - 2020-10-17 05:15:42 --> Language Class Initialized
INFO - 2020-10-17 05:15:42 --> Language Class Initialized
INFO - 2020-10-17 05:15:42 --> Config Class Initialized
INFO - 2020-10-17 05:15:42 --> Loader Class Initialized
INFO - 2020-10-17 05:15:42 --> Helper loaded: url_helper
INFO - 2020-10-17 05:15:42 --> Helper loaded: file_helper
INFO - 2020-10-17 05:15:42 --> Helper loaded: form_helper
INFO - 2020-10-17 05:15:42 --> Helper loaded: my_helper
INFO - 2020-10-17 05:15:42 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:15:42 --> Controller Class Initialized
INFO - 2020-10-17 05:15:42 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:15:42 --> Final output sent to browser
DEBUG - 2020-10-17 05:15:42 --> Total execution time: 0.7129
INFO - 2020-10-17 05:15:44 --> Config Class Initialized
INFO - 2020-10-17 05:15:44 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:15:44 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:15:44 --> Utf8 Class Initialized
INFO - 2020-10-17 05:15:44 --> URI Class Initialized
INFO - 2020-10-17 05:15:44 --> Router Class Initialized
INFO - 2020-10-17 05:15:44 --> Output Class Initialized
INFO - 2020-10-17 05:15:44 --> Security Class Initialized
DEBUG - 2020-10-17 05:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:15:44 --> Input Class Initialized
INFO - 2020-10-17 05:15:44 --> Language Class Initialized
INFO - 2020-10-17 05:15:44 --> Language Class Initialized
INFO - 2020-10-17 05:15:44 --> Config Class Initialized
INFO - 2020-10-17 05:15:44 --> Loader Class Initialized
INFO - 2020-10-17 05:15:45 --> Helper loaded: url_helper
INFO - 2020-10-17 05:15:45 --> Helper loaded: file_helper
INFO - 2020-10-17 05:15:45 --> Helper loaded: form_helper
INFO - 2020-10-17 05:15:45 --> Helper loaded: my_helper
INFO - 2020-10-17 05:15:45 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:15:45 --> Controller Class Initialized
DEBUG - 2020-10-17 05:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:15:45 --> Final output sent to browser
DEBUG - 2020-10-17 05:15:45 --> Total execution time: 1.0046
INFO - 2020-10-17 05:18:35 --> Config Class Initialized
INFO - 2020-10-17 05:18:35 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:18:35 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:18:35 --> Utf8 Class Initialized
INFO - 2020-10-17 05:18:35 --> URI Class Initialized
INFO - 2020-10-17 05:18:35 --> Router Class Initialized
INFO - 2020-10-17 05:18:35 --> Output Class Initialized
INFO - 2020-10-17 05:18:35 --> Security Class Initialized
DEBUG - 2020-10-17 05:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:18:36 --> Input Class Initialized
INFO - 2020-10-17 05:18:36 --> Language Class Initialized
INFO - 2020-10-17 05:18:36 --> Language Class Initialized
INFO - 2020-10-17 05:18:36 --> Config Class Initialized
INFO - 2020-10-17 05:18:36 --> Loader Class Initialized
INFO - 2020-10-17 05:18:36 --> Helper loaded: url_helper
INFO - 2020-10-17 05:18:36 --> Helper loaded: file_helper
INFO - 2020-10-17 05:18:36 --> Helper loaded: form_helper
INFO - 2020-10-17 05:18:36 --> Helper loaded: my_helper
INFO - 2020-10-17 05:18:36 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:18:36 --> Controller Class Initialized
DEBUG - 2020-10-17 05:18:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:18:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:18:36 --> Final output sent to browser
DEBUG - 2020-10-17 05:18:36 --> Total execution time: 0.8963
INFO - 2020-10-17 05:18:36 --> Config Class Initialized
INFO - 2020-10-17 05:18:37 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:18:37 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:18:37 --> Utf8 Class Initialized
INFO - 2020-10-17 05:18:37 --> URI Class Initialized
INFO - 2020-10-17 05:18:37 --> Router Class Initialized
INFO - 2020-10-17 05:18:37 --> Output Class Initialized
INFO - 2020-10-17 05:18:37 --> Security Class Initialized
DEBUG - 2020-10-17 05:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:18:37 --> Input Class Initialized
INFO - 2020-10-17 05:18:37 --> Language Class Initialized
INFO - 2020-10-17 05:18:37 --> Language Class Initialized
INFO - 2020-10-17 05:18:37 --> Config Class Initialized
INFO - 2020-10-17 05:18:37 --> Loader Class Initialized
INFO - 2020-10-17 05:18:37 --> Helper loaded: url_helper
INFO - 2020-10-17 05:18:37 --> Helper loaded: file_helper
INFO - 2020-10-17 05:18:37 --> Helper loaded: form_helper
INFO - 2020-10-17 05:18:37 --> Helper loaded: my_helper
INFO - 2020-10-17 05:18:37 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:18:37 --> Controller Class Initialized
INFO - 2020-10-17 05:18:39 --> Config Class Initialized
INFO - 2020-10-17 05:18:39 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:18:39 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:18:39 --> Utf8 Class Initialized
INFO - 2020-10-17 05:18:39 --> URI Class Initialized
INFO - 2020-10-17 05:18:39 --> Router Class Initialized
INFO - 2020-10-17 05:18:39 --> Output Class Initialized
INFO - 2020-10-17 05:18:39 --> Security Class Initialized
DEBUG - 2020-10-17 05:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:18:40 --> Input Class Initialized
INFO - 2020-10-17 05:18:40 --> Language Class Initialized
INFO - 2020-10-17 05:18:40 --> Language Class Initialized
INFO - 2020-10-17 05:18:40 --> Config Class Initialized
INFO - 2020-10-17 05:18:40 --> Loader Class Initialized
INFO - 2020-10-17 05:18:40 --> Helper loaded: url_helper
INFO - 2020-10-17 05:18:40 --> Helper loaded: file_helper
INFO - 2020-10-17 05:18:40 --> Helper loaded: form_helper
INFO - 2020-10-17 05:18:40 --> Helper loaded: my_helper
INFO - 2020-10-17 05:18:40 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:18:40 --> Controller Class Initialized
INFO - 2020-10-17 05:18:40 --> Final output sent to browser
DEBUG - 2020-10-17 05:18:40 --> Total execution time: 0.7825
INFO - 2020-10-17 05:18:50 --> Config Class Initialized
INFO - 2020-10-17 05:18:50 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:18:50 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:18:50 --> Utf8 Class Initialized
INFO - 2020-10-17 05:18:50 --> URI Class Initialized
INFO - 2020-10-17 05:18:50 --> Router Class Initialized
INFO - 2020-10-17 05:18:50 --> Output Class Initialized
INFO - 2020-10-17 05:18:50 --> Security Class Initialized
DEBUG - 2020-10-17 05:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:18:50 --> Input Class Initialized
INFO - 2020-10-17 05:18:51 --> Language Class Initialized
INFO - 2020-10-17 05:18:51 --> Language Class Initialized
INFO - 2020-10-17 05:18:51 --> Config Class Initialized
INFO - 2020-10-17 05:18:51 --> Loader Class Initialized
INFO - 2020-10-17 05:18:51 --> Helper loaded: url_helper
INFO - 2020-10-17 05:18:51 --> Helper loaded: file_helper
INFO - 2020-10-17 05:18:51 --> Helper loaded: form_helper
INFO - 2020-10-17 05:18:51 --> Helper loaded: my_helper
INFO - 2020-10-17 05:18:51 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:18:51 --> Controller Class Initialized
DEBUG - 2020-10-17 05:18:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:18:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:18:51 --> Final output sent to browser
DEBUG - 2020-10-17 05:18:51 --> Total execution time: 0.9949
INFO - 2020-10-17 05:18:51 --> Config Class Initialized
INFO - 2020-10-17 05:18:52 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:18:52 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:18:52 --> Utf8 Class Initialized
INFO - 2020-10-17 05:18:52 --> URI Class Initialized
INFO - 2020-10-17 05:18:52 --> Router Class Initialized
INFO - 2020-10-17 05:18:52 --> Output Class Initialized
INFO - 2020-10-17 05:18:52 --> Security Class Initialized
DEBUG - 2020-10-17 05:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:18:52 --> Input Class Initialized
INFO - 2020-10-17 05:18:52 --> Language Class Initialized
INFO - 2020-10-17 05:18:52 --> Language Class Initialized
INFO - 2020-10-17 05:18:52 --> Config Class Initialized
INFO - 2020-10-17 05:18:52 --> Loader Class Initialized
INFO - 2020-10-17 05:18:52 --> Helper loaded: url_helper
INFO - 2020-10-17 05:18:52 --> Helper loaded: file_helper
INFO - 2020-10-17 05:18:52 --> Helper loaded: form_helper
INFO - 2020-10-17 05:18:52 --> Helper loaded: my_helper
INFO - 2020-10-17 05:18:52 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:18:52 --> Controller Class Initialized
INFO - 2020-10-17 05:19:00 --> Config Class Initialized
INFO - 2020-10-17 05:19:00 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:00 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:00 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:00 --> URI Class Initialized
INFO - 2020-10-17 05:19:00 --> Router Class Initialized
INFO - 2020-10-17 05:19:00 --> Output Class Initialized
INFO - 2020-10-17 05:19:00 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:00 --> Input Class Initialized
INFO - 2020-10-17 05:19:00 --> Language Class Initialized
INFO - 2020-10-17 05:19:00 --> Language Class Initialized
INFO - 2020-10-17 05:19:00 --> Config Class Initialized
INFO - 2020-10-17 05:19:00 --> Loader Class Initialized
INFO - 2020-10-17 05:19:00 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:00 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:00 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:00 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:00 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:00 --> Controller Class Initialized
ERROR - 2020-10-17 05:19:00 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '338'
INFO - 2020-10-17 05:19:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:19:03 --> Config Class Initialized
INFO - 2020-10-17 05:19:03 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:03 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:03 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:03 --> URI Class Initialized
INFO - 2020-10-17 05:19:03 --> Router Class Initialized
INFO - 2020-10-17 05:19:03 --> Output Class Initialized
INFO - 2020-10-17 05:19:03 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:03 --> Input Class Initialized
INFO - 2020-10-17 05:19:03 --> Language Class Initialized
INFO - 2020-10-17 05:19:03 --> Language Class Initialized
INFO - 2020-10-17 05:19:03 --> Config Class Initialized
INFO - 2020-10-17 05:19:03 --> Loader Class Initialized
INFO - 2020-10-17 05:19:04 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:04 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:04 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:04 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:04 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:04 --> Controller Class Initialized
ERROR - 2020-10-17 05:19:04 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '338'
INFO - 2020-10-17 05:19:04 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:19:06 --> Config Class Initialized
INFO - 2020-10-17 05:19:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:06 --> URI Class Initialized
INFO - 2020-10-17 05:19:06 --> Router Class Initialized
INFO - 2020-10-17 05:19:06 --> Output Class Initialized
INFO - 2020-10-17 05:19:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:06 --> Input Class Initialized
INFO - 2020-10-17 05:19:06 --> Language Class Initialized
INFO - 2020-10-17 05:19:06 --> Language Class Initialized
INFO - 2020-10-17 05:19:06 --> Config Class Initialized
INFO - 2020-10-17 05:19:06 --> Loader Class Initialized
INFO - 2020-10-17 05:19:06 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:06 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:06 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:06 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:06 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:06 --> Controller Class Initialized
ERROR - 2020-10-17 05:19:06 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '339'
INFO - 2020-10-17 05:19:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:19:07 --> Config Class Initialized
INFO - 2020-10-17 05:19:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:08 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:08 --> URI Class Initialized
INFO - 2020-10-17 05:19:08 --> Router Class Initialized
INFO - 2020-10-17 05:19:08 --> Output Class Initialized
INFO - 2020-10-17 05:19:08 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:08 --> Input Class Initialized
INFO - 2020-10-17 05:19:08 --> Language Class Initialized
INFO - 2020-10-17 05:19:08 --> Language Class Initialized
INFO - 2020-10-17 05:19:08 --> Config Class Initialized
INFO - 2020-10-17 05:19:08 --> Loader Class Initialized
INFO - 2020-10-17 05:19:08 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:08 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:08 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:08 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:08 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:08 --> Controller Class Initialized
ERROR - 2020-10-17 05:19:08 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_kelas_siswa`, CONSTRAINT `t_kelas_siswa_ibfk_2` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '340'
INFO - 2020-10-17 05:19:08 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:19:09 --> Config Class Initialized
INFO - 2020-10-17 05:19:09 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:09 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:09 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:09 --> URI Class Initialized
INFO - 2020-10-17 05:19:09 --> Router Class Initialized
INFO - 2020-10-17 05:19:09 --> Output Class Initialized
INFO - 2020-10-17 05:19:09 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:09 --> Input Class Initialized
INFO - 2020-10-17 05:19:09 --> Language Class Initialized
INFO - 2020-10-17 05:19:09 --> Language Class Initialized
INFO - 2020-10-17 05:19:09 --> Config Class Initialized
INFO - 2020-10-17 05:19:09 --> Loader Class Initialized
INFO - 2020-10-17 05:19:09 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:09 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:09 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:09 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:09 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:10 --> Controller Class Initialized
ERROR - 2020-10-17 05:19:10 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_kelas_siswa`, CONSTRAINT `t_kelas_siswa_ibfk_2` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '341'
INFO - 2020-10-17 05:19:10 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:19:12 --> Config Class Initialized
INFO - 2020-10-17 05:19:12 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:12 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:12 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:12 --> URI Class Initialized
INFO - 2020-10-17 05:19:12 --> Router Class Initialized
INFO - 2020-10-17 05:19:12 --> Output Class Initialized
INFO - 2020-10-17 05:19:12 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:12 --> Input Class Initialized
INFO - 2020-10-17 05:19:12 --> Language Class Initialized
INFO - 2020-10-17 05:19:12 --> Language Class Initialized
INFO - 2020-10-17 05:19:12 --> Config Class Initialized
INFO - 2020-10-17 05:19:12 --> Loader Class Initialized
INFO - 2020-10-17 05:19:12 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:12 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:12 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:12 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:12 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:12 --> Controller Class Initialized
DEBUG - 2020-10-17 05:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:19:12 --> Final output sent to browser
DEBUG - 2020-10-17 05:19:12 --> Total execution time: 0.7660
INFO - 2020-10-17 05:19:13 --> Config Class Initialized
INFO - 2020-10-17 05:19:13 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:13 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:13 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:13 --> URI Class Initialized
INFO - 2020-10-17 05:19:13 --> Router Class Initialized
INFO - 2020-10-17 05:19:13 --> Output Class Initialized
INFO - 2020-10-17 05:19:13 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:13 --> Input Class Initialized
INFO - 2020-10-17 05:19:13 --> Language Class Initialized
INFO - 2020-10-17 05:19:13 --> Language Class Initialized
INFO - 2020-10-17 05:19:13 --> Config Class Initialized
INFO - 2020-10-17 05:19:13 --> Loader Class Initialized
INFO - 2020-10-17 05:19:13 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:13 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:13 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:13 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:13 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:13 --> Controller Class Initialized
INFO - 2020-10-17 05:19:33 --> Config Class Initialized
INFO - 2020-10-17 05:19:33 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:33 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:33 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:33 --> URI Class Initialized
INFO - 2020-10-17 05:19:33 --> Router Class Initialized
INFO - 2020-10-17 05:19:33 --> Output Class Initialized
INFO - 2020-10-17 05:19:33 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:33 --> Input Class Initialized
INFO - 2020-10-17 05:19:33 --> Language Class Initialized
INFO - 2020-10-17 05:19:33 --> Language Class Initialized
INFO - 2020-10-17 05:19:33 --> Config Class Initialized
INFO - 2020-10-17 05:19:33 --> Loader Class Initialized
INFO - 2020-10-17 05:19:33 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:33 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:33 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:33 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:33 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:33 --> Controller Class Initialized
INFO - 2020-10-17 05:19:34 --> Final output sent to browser
DEBUG - 2020-10-17 05:19:34 --> Total execution time: 0.8223
INFO - 2020-10-17 05:19:34 --> Config Class Initialized
INFO - 2020-10-17 05:19:34 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:34 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:34 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:34 --> URI Class Initialized
INFO - 2020-10-17 05:19:34 --> Router Class Initialized
INFO - 2020-10-17 05:19:34 --> Output Class Initialized
INFO - 2020-10-17 05:19:34 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:34 --> Input Class Initialized
INFO - 2020-10-17 05:19:34 --> Language Class Initialized
INFO - 2020-10-17 05:19:34 --> Language Class Initialized
INFO - 2020-10-17 05:19:34 --> Config Class Initialized
INFO - 2020-10-17 05:19:34 --> Loader Class Initialized
INFO - 2020-10-17 05:19:35 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:35 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:35 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:35 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:35 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:35 --> Controller Class Initialized
INFO - 2020-10-17 05:19:37 --> Config Class Initialized
INFO - 2020-10-17 05:19:37 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:37 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:37 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:38 --> URI Class Initialized
INFO - 2020-10-17 05:19:38 --> Router Class Initialized
INFO - 2020-10-17 05:19:38 --> Output Class Initialized
INFO - 2020-10-17 05:19:38 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:38 --> Input Class Initialized
INFO - 2020-10-17 05:19:38 --> Language Class Initialized
INFO - 2020-10-17 05:19:38 --> Language Class Initialized
INFO - 2020-10-17 05:19:38 --> Config Class Initialized
INFO - 2020-10-17 05:19:38 --> Loader Class Initialized
INFO - 2020-10-17 05:19:38 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:38 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:38 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:38 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:38 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:38 --> Controller Class Initialized
ERROR - 2020-10-17 05:19:38 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '338'
INFO - 2020-10-17 05:19:38 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:19:41 --> Config Class Initialized
INFO - 2020-10-17 05:19:41 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:41 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:41 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:41 --> URI Class Initialized
INFO - 2020-10-17 05:19:41 --> Router Class Initialized
INFO - 2020-10-17 05:19:41 --> Output Class Initialized
INFO - 2020-10-17 05:19:41 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:41 --> Input Class Initialized
INFO - 2020-10-17 05:19:41 --> Language Class Initialized
INFO - 2020-10-17 05:19:41 --> Language Class Initialized
INFO - 2020-10-17 05:19:41 --> Config Class Initialized
INFO - 2020-10-17 05:19:41 --> Loader Class Initialized
INFO - 2020-10-17 05:19:41 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:41 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:41 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:41 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:41 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:41 --> Controller Class Initialized
ERROR - 2020-10-17 05:19:41 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '338'
INFO - 2020-10-17 05:19:41 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:19:42 --> Config Class Initialized
INFO - 2020-10-17 05:19:42 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:42 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:42 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:42 --> URI Class Initialized
INFO - 2020-10-17 05:19:42 --> Router Class Initialized
INFO - 2020-10-17 05:19:42 --> Output Class Initialized
INFO - 2020-10-17 05:19:42 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:42 --> Input Class Initialized
INFO - 2020-10-17 05:19:42 --> Language Class Initialized
INFO - 2020-10-17 05:19:42 --> Language Class Initialized
INFO - 2020-10-17 05:19:42 --> Config Class Initialized
INFO - 2020-10-17 05:19:42 --> Loader Class Initialized
INFO - 2020-10-17 05:19:42 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:42 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:42 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:42 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:42 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:43 --> Controller Class Initialized
ERROR - 2020-10-17 05:19:43 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-17 05:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-17 05:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:19:43 --> Final output sent to browser
DEBUG - 2020-10-17 05:19:43 --> Total execution time: 1.1871
INFO - 2020-10-17 05:19:46 --> Config Class Initialized
INFO - 2020-10-17 05:19:46 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:46 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:46 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:46 --> URI Class Initialized
INFO - 2020-10-17 05:19:46 --> Router Class Initialized
INFO - 2020-10-17 05:19:46 --> Output Class Initialized
INFO - 2020-10-17 05:19:46 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:46 --> Input Class Initialized
INFO - 2020-10-17 05:19:46 --> Language Class Initialized
INFO - 2020-10-17 05:19:47 --> Language Class Initialized
INFO - 2020-10-17 05:19:47 --> Config Class Initialized
INFO - 2020-10-17 05:19:47 --> Loader Class Initialized
INFO - 2020-10-17 05:19:47 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:47 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:47 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:47 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:47 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:47 --> Controller Class Initialized
DEBUG - 2020-10-17 05:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:19:47 --> Final output sent to browser
DEBUG - 2020-10-17 05:19:47 --> Total execution time: 0.9760
INFO - 2020-10-17 05:19:47 --> Config Class Initialized
INFO - 2020-10-17 05:19:47 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:19:47 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:19:47 --> Utf8 Class Initialized
INFO - 2020-10-17 05:19:47 --> URI Class Initialized
INFO - 2020-10-17 05:19:47 --> Router Class Initialized
INFO - 2020-10-17 05:19:47 --> Output Class Initialized
INFO - 2020-10-17 05:19:47 --> Security Class Initialized
DEBUG - 2020-10-17 05:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:19:48 --> Input Class Initialized
INFO - 2020-10-17 05:19:48 --> Language Class Initialized
INFO - 2020-10-17 05:19:48 --> Language Class Initialized
INFO - 2020-10-17 05:19:48 --> Config Class Initialized
INFO - 2020-10-17 05:19:48 --> Loader Class Initialized
INFO - 2020-10-17 05:19:48 --> Helper loaded: url_helper
INFO - 2020-10-17 05:19:48 --> Helper loaded: file_helper
INFO - 2020-10-17 05:19:48 --> Helper loaded: form_helper
INFO - 2020-10-17 05:19:48 --> Helper loaded: my_helper
INFO - 2020-10-17 05:19:48 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:19:48 --> Controller Class Initialized
INFO - 2020-10-17 05:20:00 --> Config Class Initialized
INFO - 2020-10-17 05:20:00 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:00 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:00 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:00 --> URI Class Initialized
INFO - 2020-10-17 05:20:00 --> Router Class Initialized
INFO - 2020-10-17 05:20:00 --> Output Class Initialized
INFO - 2020-10-17 05:20:00 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:00 --> Input Class Initialized
INFO - 2020-10-17 05:20:00 --> Language Class Initialized
INFO - 2020-10-17 05:20:00 --> Language Class Initialized
INFO - 2020-10-17 05:20:00 --> Config Class Initialized
INFO - 2020-10-17 05:20:00 --> Loader Class Initialized
INFO - 2020-10-17 05:20:00 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:00 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:00 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:00 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:00 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:01 --> Controller Class Initialized
ERROR - 2020-10-17 05:20:01 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '339'
INFO - 2020-10-17 05:20:01 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:20:04 --> Config Class Initialized
INFO - 2020-10-17 05:20:04 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:04 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:04 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:04 --> URI Class Initialized
INFO - 2020-10-17 05:20:04 --> Router Class Initialized
INFO - 2020-10-17 05:20:04 --> Output Class Initialized
INFO - 2020-10-17 05:20:04 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:04 --> Input Class Initialized
INFO - 2020-10-17 05:20:04 --> Language Class Initialized
INFO - 2020-10-17 05:20:04 --> Language Class Initialized
INFO - 2020-10-17 05:20:04 --> Config Class Initialized
INFO - 2020-10-17 05:20:04 --> Loader Class Initialized
INFO - 2020-10-17 05:20:04 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:05 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:05 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:05 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:05 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:05 --> Controller Class Initialized
ERROR - 2020-10-17 05:20:05 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-17 05:20:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-17 05:20:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:20:05 --> Final output sent to browser
DEBUG - 2020-10-17 05:20:05 --> Total execution time: 0.9020
INFO - 2020-10-17 05:20:07 --> Config Class Initialized
INFO - 2020-10-17 05:20:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:07 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:07 --> URI Class Initialized
INFO - 2020-10-17 05:20:07 --> Router Class Initialized
INFO - 2020-10-17 05:20:07 --> Output Class Initialized
INFO - 2020-10-17 05:20:07 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:07 --> Input Class Initialized
INFO - 2020-10-17 05:20:07 --> Language Class Initialized
INFO - 2020-10-17 05:20:07 --> Language Class Initialized
INFO - 2020-10-17 05:20:07 --> Config Class Initialized
INFO - 2020-10-17 05:20:07 --> Loader Class Initialized
INFO - 2020-10-17 05:20:07 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:08 --> Controller Class Initialized
DEBUG - 2020-10-17 05:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:20:08 --> Final output sent to browser
DEBUG - 2020-10-17 05:20:08 --> Total execution time: 1.0396
INFO - 2020-10-17 05:20:08 --> Config Class Initialized
INFO - 2020-10-17 05:20:08 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:08 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:08 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:08 --> URI Class Initialized
INFO - 2020-10-17 05:20:08 --> Router Class Initialized
INFO - 2020-10-17 05:20:08 --> Output Class Initialized
INFO - 2020-10-17 05:20:08 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:08 --> Input Class Initialized
INFO - 2020-10-17 05:20:08 --> Language Class Initialized
INFO - 2020-10-17 05:20:08 --> Language Class Initialized
INFO - 2020-10-17 05:20:09 --> Config Class Initialized
INFO - 2020-10-17 05:20:09 --> Loader Class Initialized
INFO - 2020-10-17 05:20:09 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:09 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:09 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:09 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:09 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:09 --> Controller Class Initialized
INFO - 2020-10-17 05:20:11 --> Config Class Initialized
INFO - 2020-10-17 05:20:11 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:11 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:11 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:12 --> URI Class Initialized
INFO - 2020-10-17 05:20:12 --> Router Class Initialized
INFO - 2020-10-17 05:20:12 --> Output Class Initialized
INFO - 2020-10-17 05:20:12 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:12 --> Input Class Initialized
INFO - 2020-10-17 05:20:12 --> Language Class Initialized
INFO - 2020-10-17 05:20:12 --> Language Class Initialized
INFO - 2020-10-17 05:20:12 --> Config Class Initialized
INFO - 2020-10-17 05:20:12 --> Loader Class Initialized
INFO - 2020-10-17 05:20:12 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:12 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:12 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:12 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:12 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:12 --> Controller Class Initialized
DEBUG - 2020-10-17 05:20:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:20:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:20:12 --> Final output sent to browser
DEBUG - 2020-10-17 05:20:12 --> Total execution time: 0.9667
INFO - 2020-10-17 05:20:13 --> Config Class Initialized
INFO - 2020-10-17 05:20:13 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:13 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:13 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:13 --> URI Class Initialized
INFO - 2020-10-17 05:20:13 --> Router Class Initialized
INFO - 2020-10-17 05:20:13 --> Output Class Initialized
INFO - 2020-10-17 05:20:13 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:13 --> Input Class Initialized
INFO - 2020-10-17 05:20:13 --> Language Class Initialized
INFO - 2020-10-17 05:20:13 --> Language Class Initialized
INFO - 2020-10-17 05:20:13 --> Config Class Initialized
INFO - 2020-10-17 05:20:13 --> Loader Class Initialized
INFO - 2020-10-17 05:20:13 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:13 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:13 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:13 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:13 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:14 --> Controller Class Initialized
INFO - 2020-10-17 05:20:19 --> Config Class Initialized
INFO - 2020-10-17 05:20:19 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:19 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:19 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:19 --> URI Class Initialized
INFO - 2020-10-17 05:20:19 --> Router Class Initialized
INFO - 2020-10-17 05:20:19 --> Output Class Initialized
INFO - 2020-10-17 05:20:19 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:19 --> Input Class Initialized
INFO - 2020-10-17 05:20:20 --> Language Class Initialized
INFO - 2020-10-17 05:20:20 --> Language Class Initialized
INFO - 2020-10-17 05:20:20 --> Config Class Initialized
INFO - 2020-10-17 05:20:20 --> Loader Class Initialized
INFO - 2020-10-17 05:20:20 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:20 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:20 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:20 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:20 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:20 --> Controller Class Initialized
ERROR - 2020-10-17 05:20:20 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-17 05:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-17 05:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:20:20 --> Final output sent to browser
DEBUG - 2020-10-17 05:20:20 --> Total execution time: 0.9558
INFO - 2020-10-17 05:20:25 --> Config Class Initialized
INFO - 2020-10-17 05:20:25 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:25 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:25 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:25 --> URI Class Initialized
INFO - 2020-10-17 05:20:25 --> Router Class Initialized
INFO - 2020-10-17 05:20:25 --> Output Class Initialized
INFO - 2020-10-17 05:20:25 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:25 --> Input Class Initialized
INFO - 2020-10-17 05:20:25 --> Language Class Initialized
INFO - 2020-10-17 05:20:25 --> Language Class Initialized
INFO - 2020-10-17 05:20:25 --> Config Class Initialized
INFO - 2020-10-17 05:20:25 --> Loader Class Initialized
INFO - 2020-10-17 05:20:25 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:26 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:26 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:26 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:26 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:26 --> Controller Class Initialized
DEBUG - 2020-10-17 05:20:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-17 05:20:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:20:26 --> Final output sent to browser
DEBUG - 2020-10-17 05:20:26 --> Total execution time: 1.0403
INFO - 2020-10-17 05:20:26 --> Config Class Initialized
INFO - 2020-10-17 05:20:26 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:26 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:26 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:26 --> URI Class Initialized
INFO - 2020-10-17 05:20:26 --> Router Class Initialized
INFO - 2020-10-17 05:20:26 --> Output Class Initialized
INFO - 2020-10-17 05:20:26 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:26 --> Input Class Initialized
INFO - 2020-10-17 05:20:26 --> Language Class Initialized
INFO - 2020-10-17 05:20:26 --> Language Class Initialized
INFO - 2020-10-17 05:20:26 --> Config Class Initialized
INFO - 2020-10-17 05:20:26 --> Loader Class Initialized
INFO - 2020-10-17 05:20:26 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:26 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:26 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:26 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:27 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:27 --> Controller Class Initialized
INFO - 2020-10-17 05:20:31 --> Config Class Initialized
INFO - 2020-10-17 05:20:31 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:31 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:31 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:31 --> URI Class Initialized
INFO - 2020-10-17 05:20:31 --> Router Class Initialized
INFO - 2020-10-17 05:20:31 --> Output Class Initialized
INFO - 2020-10-17 05:20:31 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:31 --> Input Class Initialized
INFO - 2020-10-17 05:20:31 --> Language Class Initialized
INFO - 2020-10-17 05:20:31 --> Language Class Initialized
INFO - 2020-10-17 05:20:31 --> Config Class Initialized
INFO - 2020-10-17 05:20:31 --> Loader Class Initialized
INFO - 2020-10-17 05:20:31 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:31 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:31 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:31 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:31 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:31 --> Controller Class Initialized
ERROR - 2020-10-17 05:20:31 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-10-17 05:20:31 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:20:35 --> Config Class Initialized
INFO - 2020-10-17 05:20:35 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:20:35 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:20:35 --> Utf8 Class Initialized
INFO - 2020-10-17 05:20:35 --> URI Class Initialized
INFO - 2020-10-17 05:20:35 --> Router Class Initialized
INFO - 2020-10-17 05:20:35 --> Output Class Initialized
INFO - 2020-10-17 05:20:35 --> Security Class Initialized
DEBUG - 2020-10-17 05:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:20:35 --> Input Class Initialized
INFO - 2020-10-17 05:20:35 --> Language Class Initialized
INFO - 2020-10-17 05:20:35 --> Language Class Initialized
INFO - 2020-10-17 05:20:35 --> Config Class Initialized
INFO - 2020-10-17 05:20:35 --> Loader Class Initialized
INFO - 2020-10-17 05:20:35 --> Helper loaded: url_helper
INFO - 2020-10-17 05:20:35 --> Helper loaded: file_helper
INFO - 2020-10-17 05:20:35 --> Helper loaded: form_helper
INFO - 2020-10-17 05:20:35 --> Helper loaded: my_helper
INFO - 2020-10-17 05:20:35 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:20:36 --> Controller Class Initialized
INFO - 2020-10-17 05:20:36 --> Final output sent to browser
DEBUG - 2020-10-17 05:20:36 --> Total execution time: 0.7008
INFO - 2020-10-17 05:21:06 --> Config Class Initialized
INFO - 2020-10-17 05:21:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:21:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:21:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:21:06 --> URI Class Initialized
INFO - 2020-10-17 05:21:06 --> Router Class Initialized
INFO - 2020-10-17 05:21:06 --> Output Class Initialized
INFO - 2020-10-17 05:21:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:21:06 --> Input Class Initialized
INFO - 2020-10-17 05:21:06 --> Language Class Initialized
INFO - 2020-10-17 05:21:06 --> Language Class Initialized
INFO - 2020-10-17 05:21:06 --> Config Class Initialized
INFO - 2020-10-17 05:21:06 --> Loader Class Initialized
INFO - 2020-10-17 05:21:06 --> Helper loaded: url_helper
INFO - 2020-10-17 05:21:06 --> Helper loaded: file_helper
INFO - 2020-10-17 05:21:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:21:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:21:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:21:07 --> Controller Class Initialized
DEBUG - 2020-10-17 05:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:21:07 --> Final output sent to browser
DEBUG - 2020-10-17 05:21:07 --> Total execution time: 0.9163
INFO - 2020-10-17 05:21:07 --> Config Class Initialized
INFO - 2020-10-17 05:21:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:21:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:21:07 --> Utf8 Class Initialized
INFO - 2020-10-17 05:21:07 --> URI Class Initialized
INFO - 2020-10-17 05:21:07 --> Router Class Initialized
INFO - 2020-10-17 05:21:07 --> Output Class Initialized
INFO - 2020-10-17 05:21:07 --> Security Class Initialized
DEBUG - 2020-10-17 05:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:21:07 --> Input Class Initialized
INFO - 2020-10-17 05:21:07 --> Language Class Initialized
INFO - 2020-10-17 05:21:07 --> Language Class Initialized
INFO - 2020-10-17 05:21:07 --> Config Class Initialized
INFO - 2020-10-17 05:21:07 --> Loader Class Initialized
INFO - 2020-10-17 05:21:08 --> Helper loaded: url_helper
INFO - 2020-10-17 05:21:08 --> Helper loaded: file_helper
INFO - 2020-10-17 05:21:08 --> Helper loaded: form_helper
INFO - 2020-10-17 05:21:08 --> Helper loaded: my_helper
INFO - 2020-10-17 05:21:08 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:21:08 --> Controller Class Initialized
INFO - 2020-10-17 05:21:09 --> Config Class Initialized
INFO - 2020-10-17 05:21:09 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:21:09 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:21:09 --> Utf8 Class Initialized
INFO - 2020-10-17 05:21:09 --> URI Class Initialized
INFO - 2020-10-17 05:21:09 --> Router Class Initialized
INFO - 2020-10-17 05:21:09 --> Output Class Initialized
INFO - 2020-10-17 05:21:09 --> Security Class Initialized
DEBUG - 2020-10-17 05:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:21:09 --> Input Class Initialized
INFO - 2020-10-17 05:21:09 --> Language Class Initialized
INFO - 2020-10-17 05:21:09 --> Language Class Initialized
INFO - 2020-10-17 05:21:10 --> Config Class Initialized
INFO - 2020-10-17 05:21:10 --> Loader Class Initialized
INFO - 2020-10-17 05:21:10 --> Helper loaded: url_helper
INFO - 2020-10-17 05:21:10 --> Helper loaded: file_helper
INFO - 2020-10-17 05:21:10 --> Helper loaded: form_helper
INFO - 2020-10-17 05:21:10 --> Helper loaded: my_helper
INFO - 2020-10-17 05:21:10 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:21:10 --> Controller Class Initialized
DEBUG - 2020-10-17 05:21:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-17 05:21:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:21:10 --> Final output sent to browser
DEBUG - 2020-10-17 05:21:10 --> Total execution time: 0.6701
INFO - 2020-10-17 05:21:10 --> Config Class Initialized
INFO - 2020-10-17 05:21:10 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:21:10 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:21:10 --> Utf8 Class Initialized
INFO - 2020-10-17 05:21:10 --> URI Class Initialized
INFO - 2020-10-17 05:21:10 --> Router Class Initialized
INFO - 2020-10-17 05:21:10 --> Output Class Initialized
INFO - 2020-10-17 05:21:10 --> Security Class Initialized
DEBUG - 2020-10-17 05:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:21:10 --> Input Class Initialized
INFO - 2020-10-17 05:21:10 --> Language Class Initialized
INFO - 2020-10-17 05:21:10 --> Language Class Initialized
INFO - 2020-10-17 05:21:10 --> Config Class Initialized
INFO - 2020-10-17 05:21:11 --> Loader Class Initialized
INFO - 2020-10-17 05:21:11 --> Helper loaded: url_helper
INFO - 2020-10-17 05:21:11 --> Helper loaded: file_helper
INFO - 2020-10-17 05:21:11 --> Helper loaded: form_helper
INFO - 2020-10-17 05:21:11 --> Helper loaded: my_helper
INFO - 2020-10-17 05:21:11 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:21:11 --> Controller Class Initialized
INFO - 2020-10-17 05:21:13 --> Config Class Initialized
INFO - 2020-10-17 05:21:13 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:21:13 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:21:13 --> Utf8 Class Initialized
INFO - 2020-10-17 05:21:13 --> URI Class Initialized
INFO - 2020-10-17 05:21:13 --> Router Class Initialized
INFO - 2020-10-17 05:21:13 --> Output Class Initialized
INFO - 2020-10-17 05:21:13 --> Security Class Initialized
DEBUG - 2020-10-17 05:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:21:13 --> Input Class Initialized
INFO - 2020-10-17 05:21:13 --> Language Class Initialized
INFO - 2020-10-17 05:21:13 --> Language Class Initialized
INFO - 2020-10-17 05:21:13 --> Config Class Initialized
INFO - 2020-10-17 05:21:13 --> Loader Class Initialized
INFO - 2020-10-17 05:21:13 --> Helper loaded: url_helper
INFO - 2020-10-17 05:21:13 --> Helper loaded: file_helper
INFO - 2020-10-17 05:21:13 --> Helper loaded: form_helper
INFO - 2020-10-17 05:21:13 --> Helper loaded: my_helper
INFO - 2020-10-17 05:21:13 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:21:13 --> Controller Class Initialized
INFO - 2020-10-17 05:21:13 --> Final output sent to browser
DEBUG - 2020-10-17 05:21:13 --> Total execution time: 0.6616
INFO - 2020-10-17 05:21:36 --> Config Class Initialized
INFO - 2020-10-17 05:21:36 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:21:36 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:21:36 --> Utf8 Class Initialized
INFO - 2020-10-17 05:21:36 --> URI Class Initialized
INFO - 2020-10-17 05:21:36 --> Router Class Initialized
INFO - 2020-10-17 05:21:36 --> Output Class Initialized
INFO - 2020-10-17 05:21:36 --> Security Class Initialized
DEBUG - 2020-10-17 05:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:21:36 --> Input Class Initialized
INFO - 2020-10-17 05:21:36 --> Language Class Initialized
INFO - 2020-10-17 05:21:36 --> Language Class Initialized
INFO - 2020-10-17 05:21:36 --> Config Class Initialized
INFO - 2020-10-17 05:21:36 --> Loader Class Initialized
INFO - 2020-10-17 05:21:37 --> Helper loaded: url_helper
INFO - 2020-10-17 05:21:37 --> Helper loaded: file_helper
INFO - 2020-10-17 05:21:37 --> Helper loaded: form_helper
INFO - 2020-10-17 05:21:37 --> Helper loaded: my_helper
INFO - 2020-10-17 05:21:37 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:21:37 --> Controller Class Initialized
INFO - 2020-10-17 05:21:37 --> Final output sent to browser
DEBUG - 2020-10-17 05:21:37 --> Total execution time: 0.7966
INFO - 2020-10-17 05:21:37 --> Config Class Initialized
INFO - 2020-10-17 05:21:37 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:21:37 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:21:37 --> Utf8 Class Initialized
INFO - 2020-10-17 05:21:37 --> URI Class Initialized
INFO - 2020-10-17 05:21:37 --> Router Class Initialized
INFO - 2020-10-17 05:21:37 --> Output Class Initialized
INFO - 2020-10-17 05:21:37 --> Security Class Initialized
DEBUG - 2020-10-17 05:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:21:38 --> Input Class Initialized
INFO - 2020-10-17 05:21:38 --> Language Class Initialized
INFO - 2020-10-17 05:21:38 --> Language Class Initialized
INFO - 2020-10-17 05:21:38 --> Config Class Initialized
INFO - 2020-10-17 05:21:38 --> Loader Class Initialized
INFO - 2020-10-17 05:21:38 --> Helper loaded: url_helper
INFO - 2020-10-17 05:21:38 --> Helper loaded: file_helper
INFO - 2020-10-17 05:21:38 --> Helper loaded: form_helper
INFO - 2020-10-17 05:21:38 --> Helper loaded: my_helper
INFO - 2020-10-17 05:21:38 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:21:38 --> Controller Class Initialized
INFO - 2020-10-17 05:21:50 --> Config Class Initialized
INFO - 2020-10-17 05:21:50 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:21:50 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:21:50 --> Utf8 Class Initialized
INFO - 2020-10-17 05:21:50 --> URI Class Initialized
INFO - 2020-10-17 05:21:50 --> Router Class Initialized
INFO - 2020-10-17 05:21:50 --> Output Class Initialized
INFO - 2020-10-17 05:21:50 --> Security Class Initialized
DEBUG - 2020-10-17 05:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:21:50 --> Input Class Initialized
INFO - 2020-10-17 05:21:51 --> Language Class Initialized
INFO - 2020-10-17 05:21:51 --> Language Class Initialized
INFO - 2020-10-17 05:21:51 --> Config Class Initialized
INFO - 2020-10-17 05:21:51 --> Loader Class Initialized
INFO - 2020-10-17 05:21:51 --> Helper loaded: url_helper
INFO - 2020-10-17 05:21:51 --> Helper loaded: file_helper
INFO - 2020-10-17 05:21:51 --> Helper loaded: form_helper
INFO - 2020-10-17 05:21:51 --> Helper loaded: my_helper
INFO - 2020-10-17 05:21:51 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:21:51 --> Controller Class Initialized
DEBUG - 2020-10-17 05:21:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:21:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:21:51 --> Final output sent to browser
DEBUG - 2020-10-17 05:21:51 --> Total execution time: 0.9498
INFO - 2020-10-17 05:21:51 --> Config Class Initialized
INFO - 2020-10-17 05:21:51 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:21:51 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:21:52 --> Utf8 Class Initialized
INFO - 2020-10-17 05:21:52 --> URI Class Initialized
INFO - 2020-10-17 05:21:52 --> Router Class Initialized
INFO - 2020-10-17 05:21:52 --> Output Class Initialized
INFO - 2020-10-17 05:21:52 --> Security Class Initialized
DEBUG - 2020-10-17 05:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:21:52 --> Input Class Initialized
INFO - 2020-10-17 05:21:52 --> Language Class Initialized
INFO - 2020-10-17 05:21:52 --> Language Class Initialized
INFO - 2020-10-17 05:21:52 --> Config Class Initialized
INFO - 2020-10-17 05:21:52 --> Loader Class Initialized
INFO - 2020-10-17 05:21:52 --> Helper loaded: url_helper
INFO - 2020-10-17 05:21:52 --> Helper loaded: file_helper
INFO - 2020-10-17 05:21:52 --> Helper loaded: form_helper
INFO - 2020-10-17 05:21:52 --> Helper loaded: my_helper
INFO - 2020-10-17 05:21:52 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:21:52 --> Controller Class Initialized
INFO - 2020-10-17 05:22:37 --> Config Class Initialized
INFO - 2020-10-17 05:22:37 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:22:37 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:22:37 --> Utf8 Class Initialized
INFO - 2020-10-17 05:22:37 --> URI Class Initialized
INFO - 2020-10-17 05:22:37 --> Router Class Initialized
INFO - 2020-10-17 05:22:37 --> Output Class Initialized
INFO - 2020-10-17 05:22:37 --> Security Class Initialized
DEBUG - 2020-10-17 05:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:22:37 --> Input Class Initialized
INFO - 2020-10-17 05:22:38 --> Language Class Initialized
INFO - 2020-10-17 05:22:38 --> Language Class Initialized
INFO - 2020-10-17 05:22:38 --> Config Class Initialized
INFO - 2020-10-17 05:22:38 --> Loader Class Initialized
INFO - 2020-10-17 05:22:38 --> Helper loaded: url_helper
INFO - 2020-10-17 05:22:38 --> Helper loaded: file_helper
INFO - 2020-10-17 05:22:38 --> Helper loaded: form_helper
INFO - 2020-10-17 05:22:38 --> Helper loaded: my_helper
INFO - 2020-10-17 05:22:38 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:22:38 --> Controller Class Initialized
DEBUG - 2020-10-17 05:22:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:22:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:22:38 --> Final output sent to browser
DEBUG - 2020-10-17 05:22:38 --> Total execution time: 0.9417
INFO - 2020-10-17 05:22:38 --> Config Class Initialized
INFO - 2020-10-17 05:22:38 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:22:39 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:22:39 --> Utf8 Class Initialized
INFO - 2020-10-17 05:22:39 --> URI Class Initialized
INFO - 2020-10-17 05:22:39 --> Router Class Initialized
INFO - 2020-10-17 05:22:39 --> Output Class Initialized
INFO - 2020-10-17 05:22:39 --> Security Class Initialized
DEBUG - 2020-10-17 05:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:22:39 --> Input Class Initialized
INFO - 2020-10-17 05:22:39 --> Language Class Initialized
INFO - 2020-10-17 05:22:39 --> Language Class Initialized
INFO - 2020-10-17 05:22:39 --> Config Class Initialized
INFO - 2020-10-17 05:22:39 --> Loader Class Initialized
INFO - 2020-10-17 05:22:39 --> Helper loaded: url_helper
INFO - 2020-10-17 05:22:39 --> Helper loaded: file_helper
INFO - 2020-10-17 05:22:39 --> Helper loaded: form_helper
INFO - 2020-10-17 05:22:39 --> Helper loaded: my_helper
INFO - 2020-10-17 05:22:39 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:22:39 --> Controller Class Initialized
INFO - 2020-10-17 05:22:40 --> Config Class Initialized
INFO - 2020-10-17 05:22:40 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:22:40 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:22:40 --> Utf8 Class Initialized
INFO - 2020-10-17 05:22:40 --> URI Class Initialized
INFO - 2020-10-17 05:22:40 --> Router Class Initialized
INFO - 2020-10-17 05:22:40 --> Output Class Initialized
INFO - 2020-10-17 05:22:40 --> Security Class Initialized
DEBUG - 2020-10-17 05:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:22:40 --> Input Class Initialized
INFO - 2020-10-17 05:22:40 --> Language Class Initialized
INFO - 2020-10-17 05:22:40 --> Language Class Initialized
INFO - 2020-10-17 05:22:40 --> Config Class Initialized
INFO - 2020-10-17 05:22:40 --> Loader Class Initialized
INFO - 2020-10-17 05:22:40 --> Helper loaded: url_helper
INFO - 2020-10-17 05:22:41 --> Helper loaded: file_helper
INFO - 2020-10-17 05:22:41 --> Helper loaded: form_helper
INFO - 2020-10-17 05:22:41 --> Helper loaded: my_helper
INFO - 2020-10-17 05:22:41 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:22:41 --> Controller Class Initialized
DEBUG - 2020-10-17 05:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-17 05:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:22:41 --> Final output sent to browser
DEBUG - 2020-10-17 05:22:41 --> Total execution time: 0.8873
INFO - 2020-10-17 05:22:41 --> Config Class Initialized
INFO - 2020-10-17 05:22:41 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:22:41 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:22:41 --> Utf8 Class Initialized
INFO - 2020-10-17 05:22:41 --> URI Class Initialized
INFO - 2020-10-17 05:22:41 --> Router Class Initialized
INFO - 2020-10-17 05:22:41 --> Output Class Initialized
INFO - 2020-10-17 05:22:41 --> Security Class Initialized
DEBUG - 2020-10-17 05:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:22:41 --> Input Class Initialized
INFO - 2020-10-17 05:22:41 --> Language Class Initialized
INFO - 2020-10-17 05:22:42 --> Language Class Initialized
INFO - 2020-10-17 05:22:42 --> Config Class Initialized
INFO - 2020-10-17 05:22:42 --> Loader Class Initialized
INFO - 2020-10-17 05:22:42 --> Helper loaded: url_helper
INFO - 2020-10-17 05:22:42 --> Helper loaded: file_helper
INFO - 2020-10-17 05:22:42 --> Helper loaded: form_helper
INFO - 2020-10-17 05:22:42 --> Helper loaded: my_helper
INFO - 2020-10-17 05:22:42 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:22:42 --> Controller Class Initialized
INFO - 2020-10-17 05:24:32 --> Config Class Initialized
INFO - 2020-10-17 05:24:32 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:24:32 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:24:33 --> Utf8 Class Initialized
INFO - 2020-10-17 05:24:33 --> URI Class Initialized
INFO - 2020-10-17 05:24:33 --> Router Class Initialized
INFO - 2020-10-17 05:24:33 --> Output Class Initialized
INFO - 2020-10-17 05:24:33 --> Security Class Initialized
DEBUG - 2020-10-17 05:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:24:33 --> Input Class Initialized
INFO - 2020-10-17 05:24:33 --> Language Class Initialized
INFO - 2020-10-17 05:24:33 --> Language Class Initialized
INFO - 2020-10-17 05:24:33 --> Config Class Initialized
INFO - 2020-10-17 05:24:33 --> Loader Class Initialized
INFO - 2020-10-17 05:24:33 --> Helper loaded: url_helper
INFO - 2020-10-17 05:24:33 --> Helper loaded: file_helper
INFO - 2020-10-17 05:24:33 --> Helper loaded: form_helper
INFO - 2020-10-17 05:24:33 --> Helper loaded: my_helper
INFO - 2020-10-17 05:24:33 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:24:33 --> Controller Class Initialized
DEBUG - 2020-10-17 05:24:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:24:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:24:33 --> Final output sent to browser
DEBUG - 2020-10-17 05:24:33 --> Total execution time: 1.0079
INFO - 2020-10-17 05:24:34 --> Config Class Initialized
INFO - 2020-10-17 05:24:34 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:24:34 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:24:34 --> Utf8 Class Initialized
INFO - 2020-10-17 05:24:34 --> URI Class Initialized
INFO - 2020-10-17 05:24:34 --> Router Class Initialized
INFO - 2020-10-17 05:24:34 --> Output Class Initialized
INFO - 2020-10-17 05:24:34 --> Security Class Initialized
DEBUG - 2020-10-17 05:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:24:34 --> Input Class Initialized
INFO - 2020-10-17 05:24:34 --> Language Class Initialized
INFO - 2020-10-17 05:24:34 --> Language Class Initialized
INFO - 2020-10-17 05:24:34 --> Config Class Initialized
INFO - 2020-10-17 05:24:34 --> Loader Class Initialized
INFO - 2020-10-17 05:24:34 --> Helper loaded: url_helper
INFO - 2020-10-17 05:24:34 --> Helper loaded: file_helper
INFO - 2020-10-17 05:24:34 --> Helper loaded: form_helper
INFO - 2020-10-17 05:24:34 --> Helper loaded: my_helper
INFO - 2020-10-17 05:24:34 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:24:34 --> Controller Class Initialized
INFO - 2020-10-17 05:24:35 --> Config Class Initialized
INFO - 2020-10-17 05:24:35 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:24:35 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:24:35 --> Utf8 Class Initialized
INFO - 2020-10-17 05:24:35 --> URI Class Initialized
INFO - 2020-10-17 05:24:35 --> Router Class Initialized
INFO - 2020-10-17 05:24:35 --> Output Class Initialized
INFO - 2020-10-17 05:24:35 --> Security Class Initialized
DEBUG - 2020-10-17 05:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:24:35 --> Input Class Initialized
INFO - 2020-10-17 05:24:35 --> Language Class Initialized
INFO - 2020-10-17 05:24:35 --> Language Class Initialized
INFO - 2020-10-17 05:24:35 --> Config Class Initialized
INFO - 2020-10-17 05:24:35 --> Loader Class Initialized
INFO - 2020-10-17 05:24:35 --> Helper loaded: url_helper
INFO - 2020-10-17 05:24:35 --> Helper loaded: file_helper
INFO - 2020-10-17 05:24:35 --> Helper loaded: form_helper
INFO - 2020-10-17 05:24:35 --> Helper loaded: my_helper
INFO - 2020-10-17 05:24:35 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:24:35 --> Controller Class Initialized
ERROR - 2020-10-17 05:24:35 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-17 05:24:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-17 05:24:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:24:35 --> Final output sent to browser
DEBUG - 2020-10-17 05:24:35 --> Total execution time: 0.7769
INFO - 2020-10-17 05:25:03 --> Config Class Initialized
INFO - 2020-10-17 05:25:03 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:25:03 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:25:03 --> Utf8 Class Initialized
INFO - 2020-10-17 05:25:03 --> URI Class Initialized
INFO - 2020-10-17 05:25:03 --> Router Class Initialized
INFO - 2020-10-17 05:25:03 --> Output Class Initialized
INFO - 2020-10-17 05:25:03 --> Security Class Initialized
DEBUG - 2020-10-17 05:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:25:03 --> Input Class Initialized
INFO - 2020-10-17 05:25:03 --> Language Class Initialized
INFO - 2020-10-17 05:25:04 --> Language Class Initialized
INFO - 2020-10-17 05:25:04 --> Config Class Initialized
INFO - 2020-10-17 05:25:04 --> Loader Class Initialized
INFO - 2020-10-17 05:25:04 --> Helper loaded: url_helper
INFO - 2020-10-17 05:25:04 --> Helper loaded: file_helper
INFO - 2020-10-17 05:25:04 --> Helper loaded: form_helper
INFO - 2020-10-17 05:25:04 --> Helper loaded: my_helper
INFO - 2020-10-17 05:25:04 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:25:04 --> Controller Class Initialized
DEBUG - 2020-10-17 05:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-17 05:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:25:04 --> Final output sent to browser
DEBUG - 2020-10-17 05:25:04 --> Total execution time: 0.9754
INFO - 2020-10-17 05:25:04 --> Config Class Initialized
INFO - 2020-10-17 05:25:04 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:25:04 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:25:04 --> Utf8 Class Initialized
INFO - 2020-10-17 05:25:05 --> URI Class Initialized
INFO - 2020-10-17 05:25:05 --> Router Class Initialized
INFO - 2020-10-17 05:25:05 --> Output Class Initialized
INFO - 2020-10-17 05:25:05 --> Security Class Initialized
DEBUG - 2020-10-17 05:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:25:05 --> Input Class Initialized
INFO - 2020-10-17 05:25:05 --> Language Class Initialized
INFO - 2020-10-17 05:25:05 --> Language Class Initialized
INFO - 2020-10-17 05:25:05 --> Config Class Initialized
INFO - 2020-10-17 05:25:05 --> Loader Class Initialized
INFO - 2020-10-17 05:25:05 --> Helper loaded: url_helper
INFO - 2020-10-17 05:25:05 --> Helper loaded: file_helper
INFO - 2020-10-17 05:25:05 --> Helper loaded: form_helper
INFO - 2020-10-17 05:25:05 --> Helper loaded: my_helper
INFO - 2020-10-17 05:25:05 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:25:05 --> Controller Class Initialized
INFO - 2020-10-17 05:25:48 --> Config Class Initialized
INFO - 2020-10-17 05:25:48 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:25:48 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:25:48 --> Utf8 Class Initialized
INFO - 2020-10-17 05:25:48 --> URI Class Initialized
INFO - 2020-10-17 05:25:48 --> Router Class Initialized
INFO - 2020-10-17 05:25:48 --> Output Class Initialized
INFO - 2020-10-17 05:25:48 --> Security Class Initialized
DEBUG - 2020-10-17 05:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:25:48 --> Input Class Initialized
INFO - 2020-10-17 05:25:48 --> Language Class Initialized
INFO - 2020-10-17 05:25:48 --> Language Class Initialized
INFO - 2020-10-17 05:25:48 --> Config Class Initialized
INFO - 2020-10-17 05:25:48 --> Loader Class Initialized
INFO - 2020-10-17 05:25:48 --> Helper loaded: url_helper
INFO - 2020-10-17 05:25:48 --> Helper loaded: file_helper
INFO - 2020-10-17 05:25:48 --> Helper loaded: form_helper
INFO - 2020-10-17 05:25:48 --> Helper loaded: my_helper
INFO - 2020-10-17 05:25:48 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:25:48 --> Controller Class Initialized
DEBUG - 2020-10-17 05:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-17 05:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:25:48 --> Final output sent to browser
DEBUG - 2020-10-17 05:25:48 --> Total execution time: 0.7536
INFO - 2020-10-17 05:25:49 --> Config Class Initialized
INFO - 2020-10-17 05:25:49 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:25:49 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:25:49 --> Utf8 Class Initialized
INFO - 2020-10-17 05:25:49 --> URI Class Initialized
INFO - 2020-10-17 05:25:49 --> Router Class Initialized
INFO - 2020-10-17 05:25:49 --> Output Class Initialized
INFO - 2020-10-17 05:25:49 --> Security Class Initialized
DEBUG - 2020-10-17 05:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:25:49 --> Input Class Initialized
INFO - 2020-10-17 05:25:49 --> Language Class Initialized
INFO - 2020-10-17 05:25:49 --> Language Class Initialized
INFO - 2020-10-17 05:25:49 --> Config Class Initialized
INFO - 2020-10-17 05:25:49 --> Loader Class Initialized
INFO - 2020-10-17 05:25:49 --> Helper loaded: url_helper
INFO - 2020-10-17 05:25:49 --> Helper loaded: file_helper
INFO - 2020-10-17 05:25:49 --> Helper loaded: form_helper
INFO - 2020-10-17 05:25:49 --> Helper loaded: my_helper
INFO - 2020-10-17 05:25:49 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:25:49 --> Controller Class Initialized
INFO - 2020-10-17 05:25:53 --> Config Class Initialized
INFO - 2020-10-17 05:25:53 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:25:53 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:25:53 --> Utf8 Class Initialized
INFO - 2020-10-17 05:25:53 --> URI Class Initialized
INFO - 2020-10-17 05:25:53 --> Router Class Initialized
INFO - 2020-10-17 05:25:53 --> Output Class Initialized
INFO - 2020-10-17 05:25:53 --> Security Class Initialized
DEBUG - 2020-10-17 05:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:25:54 --> Input Class Initialized
INFO - 2020-10-17 05:25:54 --> Language Class Initialized
INFO - 2020-10-17 05:25:54 --> Language Class Initialized
INFO - 2020-10-17 05:25:54 --> Config Class Initialized
INFO - 2020-10-17 05:25:54 --> Loader Class Initialized
INFO - 2020-10-17 05:25:54 --> Helper loaded: url_helper
INFO - 2020-10-17 05:25:54 --> Helper loaded: file_helper
INFO - 2020-10-17 05:25:54 --> Helper loaded: form_helper
INFO - 2020-10-17 05:25:54 --> Helper loaded: my_helper
INFO - 2020-10-17 05:25:54 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:25:54 --> Controller Class Initialized
INFO - 2020-10-17 05:25:54 --> Final output sent to browser
DEBUG - 2020-10-17 05:25:54 --> Total execution time: 0.9086
INFO - 2020-10-17 05:26:05 --> Config Class Initialized
INFO - 2020-10-17 05:26:05 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:26:05 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:26:05 --> Utf8 Class Initialized
INFO - 2020-10-17 05:26:05 --> URI Class Initialized
INFO - 2020-10-17 05:26:05 --> Router Class Initialized
INFO - 2020-10-17 05:26:05 --> Output Class Initialized
INFO - 2020-10-17 05:26:05 --> Security Class Initialized
DEBUG - 2020-10-17 05:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:26:05 --> Input Class Initialized
INFO - 2020-10-17 05:26:05 --> Language Class Initialized
INFO - 2020-10-17 05:26:05 --> Language Class Initialized
INFO - 2020-10-17 05:26:05 --> Config Class Initialized
INFO - 2020-10-17 05:26:05 --> Loader Class Initialized
INFO - 2020-10-17 05:26:05 --> Helper loaded: url_helper
INFO - 2020-10-17 05:26:05 --> Helper loaded: file_helper
INFO - 2020-10-17 05:26:05 --> Helper loaded: form_helper
INFO - 2020-10-17 05:26:05 --> Helper loaded: my_helper
INFO - 2020-10-17 05:26:05 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:26:06 --> Controller Class Initialized
INFO - 2020-10-17 05:26:06 --> Final output sent to browser
DEBUG - 2020-10-17 05:26:06 --> Total execution time: 0.7933
INFO - 2020-10-17 05:26:06 --> Config Class Initialized
INFO - 2020-10-17 05:26:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:26:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:26:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:26:06 --> URI Class Initialized
INFO - 2020-10-17 05:26:06 --> Router Class Initialized
INFO - 2020-10-17 05:26:06 --> Output Class Initialized
INFO - 2020-10-17 05:26:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:26:06 --> Input Class Initialized
INFO - 2020-10-17 05:26:06 --> Language Class Initialized
INFO - 2020-10-17 05:26:06 --> Language Class Initialized
INFO - 2020-10-17 05:26:06 --> Config Class Initialized
INFO - 2020-10-17 05:26:06 --> Loader Class Initialized
INFO - 2020-10-17 05:26:07 --> Helper loaded: url_helper
INFO - 2020-10-17 05:26:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:26:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:26:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:26:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:26:07 --> Controller Class Initialized
INFO - 2020-10-17 05:26:30 --> Config Class Initialized
INFO - 2020-10-17 05:26:30 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:26:30 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:26:30 --> Utf8 Class Initialized
INFO - 2020-10-17 05:26:30 --> URI Class Initialized
INFO - 2020-10-17 05:26:30 --> Router Class Initialized
INFO - 2020-10-17 05:26:30 --> Output Class Initialized
INFO - 2020-10-17 05:26:30 --> Security Class Initialized
DEBUG - 2020-10-17 05:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:26:30 --> Input Class Initialized
INFO - 2020-10-17 05:26:30 --> Language Class Initialized
INFO - 2020-10-17 05:26:31 --> Language Class Initialized
INFO - 2020-10-17 05:26:31 --> Config Class Initialized
INFO - 2020-10-17 05:26:31 --> Loader Class Initialized
INFO - 2020-10-17 05:26:31 --> Helper loaded: url_helper
INFO - 2020-10-17 05:26:31 --> Helper loaded: file_helper
INFO - 2020-10-17 05:26:31 --> Helper loaded: form_helper
INFO - 2020-10-17 05:26:31 --> Helper loaded: my_helper
INFO - 2020-10-17 05:26:31 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:26:31 --> Controller Class Initialized
DEBUG - 2020-10-17 05:26:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:26:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:26:31 --> Final output sent to browser
DEBUG - 2020-10-17 05:26:31 --> Total execution time: 1.0538
INFO - 2020-10-17 05:26:31 --> Config Class Initialized
INFO - 2020-10-17 05:26:31 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:26:32 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:26:32 --> Utf8 Class Initialized
INFO - 2020-10-17 05:26:32 --> URI Class Initialized
INFO - 2020-10-17 05:26:32 --> Router Class Initialized
INFO - 2020-10-17 05:26:32 --> Output Class Initialized
INFO - 2020-10-17 05:26:32 --> Security Class Initialized
DEBUG - 2020-10-17 05:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:26:32 --> Input Class Initialized
INFO - 2020-10-17 05:26:32 --> Language Class Initialized
INFO - 2020-10-17 05:26:32 --> Language Class Initialized
INFO - 2020-10-17 05:26:32 --> Config Class Initialized
INFO - 2020-10-17 05:26:32 --> Loader Class Initialized
INFO - 2020-10-17 05:26:32 --> Helper loaded: url_helper
INFO - 2020-10-17 05:26:32 --> Helper loaded: file_helper
INFO - 2020-10-17 05:26:32 --> Helper loaded: form_helper
INFO - 2020-10-17 05:26:32 --> Helper loaded: my_helper
INFO - 2020-10-17 05:26:32 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:26:32 --> Controller Class Initialized
INFO - 2020-10-17 05:26:53 --> Config Class Initialized
INFO - 2020-10-17 05:26:53 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:26:53 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:26:53 --> Utf8 Class Initialized
INFO - 2020-10-17 05:26:53 --> URI Class Initialized
INFO - 2020-10-17 05:26:53 --> Router Class Initialized
INFO - 2020-10-17 05:26:53 --> Output Class Initialized
INFO - 2020-10-17 05:26:53 --> Security Class Initialized
DEBUG - 2020-10-17 05:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:26:53 --> Input Class Initialized
INFO - 2020-10-17 05:26:53 --> Language Class Initialized
INFO - 2020-10-17 05:26:53 --> Language Class Initialized
INFO - 2020-10-17 05:26:53 --> Config Class Initialized
INFO - 2020-10-17 05:26:53 --> Loader Class Initialized
INFO - 2020-10-17 05:26:53 --> Helper loaded: url_helper
INFO - 2020-10-17 05:26:53 --> Helper loaded: file_helper
INFO - 2020-10-17 05:26:53 --> Helper loaded: form_helper
INFO - 2020-10-17 05:26:53 --> Helper loaded: my_helper
INFO - 2020-10-17 05:26:53 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:26:53 --> Controller Class Initialized
DEBUG - 2020-10-17 05:26:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-17 05:26:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:26:53 --> Final output sent to browser
DEBUG - 2020-10-17 05:26:54 --> Total execution time: 0.6712
INFO - 2020-10-17 05:26:54 --> Config Class Initialized
INFO - 2020-10-17 05:26:54 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:26:54 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:26:54 --> Utf8 Class Initialized
INFO - 2020-10-17 05:26:54 --> URI Class Initialized
INFO - 2020-10-17 05:26:54 --> Router Class Initialized
INFO - 2020-10-17 05:26:54 --> Output Class Initialized
INFO - 2020-10-17 05:26:54 --> Security Class Initialized
DEBUG - 2020-10-17 05:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:26:54 --> Input Class Initialized
INFO - 2020-10-17 05:26:54 --> Language Class Initialized
INFO - 2020-10-17 05:26:54 --> Language Class Initialized
INFO - 2020-10-17 05:26:54 --> Config Class Initialized
INFO - 2020-10-17 05:26:54 --> Loader Class Initialized
INFO - 2020-10-17 05:26:54 --> Helper loaded: url_helper
INFO - 2020-10-17 05:26:54 --> Helper loaded: file_helper
INFO - 2020-10-17 05:26:54 --> Helper loaded: form_helper
INFO - 2020-10-17 05:26:54 --> Helper loaded: my_helper
INFO - 2020-10-17 05:26:54 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:26:54 --> Controller Class Initialized
INFO - 2020-10-17 05:26:56 --> Config Class Initialized
INFO - 2020-10-17 05:26:56 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:26:56 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:26:56 --> Utf8 Class Initialized
INFO - 2020-10-17 05:26:56 --> URI Class Initialized
INFO - 2020-10-17 05:26:56 --> Router Class Initialized
INFO - 2020-10-17 05:26:56 --> Output Class Initialized
INFO - 2020-10-17 05:26:56 --> Security Class Initialized
DEBUG - 2020-10-17 05:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:26:57 --> Input Class Initialized
INFO - 2020-10-17 05:26:57 --> Language Class Initialized
INFO - 2020-10-17 05:26:57 --> Language Class Initialized
INFO - 2020-10-17 05:26:57 --> Config Class Initialized
INFO - 2020-10-17 05:26:57 --> Loader Class Initialized
INFO - 2020-10-17 05:26:57 --> Helper loaded: url_helper
INFO - 2020-10-17 05:26:57 --> Helper loaded: file_helper
INFO - 2020-10-17 05:26:57 --> Helper loaded: form_helper
INFO - 2020-10-17 05:26:57 --> Helper loaded: my_helper
INFO - 2020-10-17 05:26:57 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:26:57 --> Controller Class Initialized
DEBUG - 2020-10-17 05:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:26:57 --> Final output sent to browser
DEBUG - 2020-10-17 05:26:57 --> Total execution time: 0.9620
INFO - 2020-10-17 05:26:57 --> Config Class Initialized
INFO - 2020-10-17 05:26:57 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:26:57 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:26:57 --> Utf8 Class Initialized
INFO - 2020-10-17 05:26:58 --> URI Class Initialized
INFO - 2020-10-17 05:26:58 --> Router Class Initialized
INFO - 2020-10-17 05:26:58 --> Output Class Initialized
INFO - 2020-10-17 05:26:58 --> Security Class Initialized
DEBUG - 2020-10-17 05:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:26:58 --> Input Class Initialized
INFO - 2020-10-17 05:26:58 --> Language Class Initialized
INFO - 2020-10-17 05:26:58 --> Language Class Initialized
INFO - 2020-10-17 05:26:58 --> Config Class Initialized
INFO - 2020-10-17 05:26:58 --> Loader Class Initialized
INFO - 2020-10-17 05:26:58 --> Helper loaded: url_helper
INFO - 2020-10-17 05:26:58 --> Helper loaded: file_helper
INFO - 2020-10-17 05:26:58 --> Helper loaded: form_helper
INFO - 2020-10-17 05:26:58 --> Helper loaded: my_helper
INFO - 2020-10-17 05:26:58 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:26:58 --> Controller Class Initialized
INFO - 2020-10-17 05:27:23 --> Config Class Initialized
INFO - 2020-10-17 05:27:23 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:27:23 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:27:23 --> Utf8 Class Initialized
INFO - 2020-10-17 05:27:23 --> URI Class Initialized
INFO - 2020-10-17 05:27:23 --> Router Class Initialized
INFO - 2020-10-17 05:27:23 --> Output Class Initialized
INFO - 2020-10-17 05:27:23 --> Security Class Initialized
DEBUG - 2020-10-17 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:27:23 --> Input Class Initialized
INFO - 2020-10-17 05:27:23 --> Language Class Initialized
INFO - 2020-10-17 05:27:23 --> Language Class Initialized
INFO - 2020-10-17 05:27:23 --> Config Class Initialized
INFO - 2020-10-17 05:27:23 --> Loader Class Initialized
INFO - 2020-10-17 05:27:23 --> Helper loaded: url_helper
INFO - 2020-10-17 05:27:23 --> Helper loaded: file_helper
INFO - 2020-10-17 05:27:23 --> Helper loaded: form_helper
INFO - 2020-10-17 05:27:23 --> Helper loaded: my_helper
INFO - 2020-10-17 05:27:24 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:27:24 --> Controller Class Initialized
DEBUG - 2020-10-17 05:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:27:24 --> Final output sent to browser
DEBUG - 2020-10-17 05:27:24 --> Total execution time: 0.8882
INFO - 2020-10-17 05:27:24 --> Config Class Initialized
INFO - 2020-10-17 05:27:24 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:27:24 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:27:24 --> Utf8 Class Initialized
INFO - 2020-10-17 05:27:24 --> URI Class Initialized
INFO - 2020-10-17 05:27:24 --> Router Class Initialized
INFO - 2020-10-17 05:27:24 --> Output Class Initialized
INFO - 2020-10-17 05:27:24 --> Security Class Initialized
DEBUG - 2020-10-17 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:27:24 --> Input Class Initialized
INFO - 2020-10-17 05:27:24 --> Language Class Initialized
INFO - 2020-10-17 05:27:24 --> Language Class Initialized
INFO - 2020-10-17 05:27:24 --> Config Class Initialized
INFO - 2020-10-17 05:27:24 --> Loader Class Initialized
INFO - 2020-10-17 05:27:24 --> Helper loaded: url_helper
INFO - 2020-10-17 05:27:24 --> Helper loaded: file_helper
INFO - 2020-10-17 05:27:24 --> Helper loaded: form_helper
INFO - 2020-10-17 05:27:24 --> Helper loaded: my_helper
INFO - 2020-10-17 05:27:24 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:27:25 --> Controller Class Initialized
INFO - 2020-10-17 05:28:56 --> Config Class Initialized
INFO - 2020-10-17 05:28:56 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:28:56 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:28:56 --> Utf8 Class Initialized
INFO - 2020-10-17 05:28:56 --> URI Class Initialized
INFO - 2020-10-17 05:28:56 --> Router Class Initialized
INFO - 2020-10-17 05:28:56 --> Output Class Initialized
INFO - 2020-10-17 05:28:56 --> Security Class Initialized
DEBUG - 2020-10-17 05:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:28:56 --> Input Class Initialized
INFO - 2020-10-17 05:28:56 --> Language Class Initialized
INFO - 2020-10-17 05:28:56 --> Language Class Initialized
INFO - 2020-10-17 05:28:56 --> Config Class Initialized
INFO - 2020-10-17 05:28:56 --> Loader Class Initialized
INFO - 2020-10-17 05:28:56 --> Helper loaded: url_helper
INFO - 2020-10-17 05:28:56 --> Helper loaded: file_helper
INFO - 2020-10-17 05:28:56 --> Helper loaded: form_helper
INFO - 2020-10-17 05:28:56 --> Helper loaded: my_helper
INFO - 2020-10-17 05:28:56 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:28:57 --> Controller Class Initialized
DEBUG - 2020-10-17 05:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:28:57 --> Final output sent to browser
DEBUG - 2020-10-17 05:28:57 --> Total execution time: 1.0418
INFO - 2020-10-17 05:28:57 --> Config Class Initialized
INFO - 2020-10-17 05:28:57 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:28:57 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:28:57 --> Utf8 Class Initialized
INFO - 2020-10-17 05:28:57 --> URI Class Initialized
INFO - 2020-10-17 05:28:57 --> Router Class Initialized
INFO - 2020-10-17 05:28:57 --> Output Class Initialized
INFO - 2020-10-17 05:28:57 --> Security Class Initialized
DEBUG - 2020-10-17 05:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:28:57 --> Input Class Initialized
INFO - 2020-10-17 05:28:57 --> Language Class Initialized
INFO - 2020-10-17 05:28:57 --> Language Class Initialized
INFO - 2020-10-17 05:28:57 --> Config Class Initialized
INFO - 2020-10-17 05:28:57 --> Loader Class Initialized
INFO - 2020-10-17 05:28:58 --> Helper loaded: url_helper
INFO - 2020-10-17 05:28:58 --> Helper loaded: file_helper
INFO - 2020-10-17 05:28:58 --> Helper loaded: form_helper
INFO - 2020-10-17 05:28:58 --> Helper loaded: my_helper
INFO - 2020-10-17 05:28:58 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:28:58 --> Controller Class Initialized
INFO - 2020-10-17 05:29:08 --> Config Class Initialized
INFO - 2020-10-17 05:29:09 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:29:09 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:29:09 --> Utf8 Class Initialized
INFO - 2020-10-17 05:29:09 --> URI Class Initialized
INFO - 2020-10-17 05:29:09 --> Router Class Initialized
INFO - 2020-10-17 05:29:09 --> Output Class Initialized
INFO - 2020-10-17 05:29:09 --> Security Class Initialized
DEBUG - 2020-10-17 05:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:29:09 --> Input Class Initialized
INFO - 2020-10-17 05:29:09 --> Language Class Initialized
INFO - 2020-10-17 05:29:09 --> Language Class Initialized
INFO - 2020-10-17 05:29:09 --> Config Class Initialized
INFO - 2020-10-17 05:29:09 --> Loader Class Initialized
INFO - 2020-10-17 05:29:09 --> Helper loaded: url_helper
INFO - 2020-10-17 05:29:09 --> Helper loaded: file_helper
INFO - 2020-10-17 05:29:09 --> Helper loaded: form_helper
INFO - 2020-10-17 05:29:09 --> Helper loaded: my_helper
INFO - 2020-10-17 05:29:09 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:29:09 --> Controller Class Initialized
INFO - 2020-10-17 05:29:13 --> Config Class Initialized
INFO - 2020-10-17 05:29:13 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:29:13 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:29:13 --> Utf8 Class Initialized
INFO - 2020-10-17 05:29:14 --> URI Class Initialized
INFO - 2020-10-17 05:29:14 --> Router Class Initialized
INFO - 2020-10-17 05:29:14 --> Output Class Initialized
INFO - 2020-10-17 05:29:14 --> Security Class Initialized
DEBUG - 2020-10-17 05:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:29:14 --> Input Class Initialized
INFO - 2020-10-17 05:29:14 --> Language Class Initialized
INFO - 2020-10-17 05:29:14 --> Language Class Initialized
INFO - 2020-10-17 05:29:14 --> Config Class Initialized
INFO - 2020-10-17 05:29:14 --> Loader Class Initialized
INFO - 2020-10-17 05:29:14 --> Helper loaded: url_helper
INFO - 2020-10-17 05:29:14 --> Helper loaded: file_helper
INFO - 2020-10-17 05:29:14 --> Helper loaded: form_helper
INFO - 2020-10-17 05:29:14 --> Helper loaded: my_helper
INFO - 2020-10-17 05:29:14 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:29:14 --> Controller Class Initialized
INFO - 2020-10-17 05:29:26 --> Config Class Initialized
INFO - 2020-10-17 05:29:26 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:29:26 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:29:26 --> Utf8 Class Initialized
INFO - 2020-10-17 05:29:27 --> URI Class Initialized
INFO - 2020-10-17 05:29:27 --> Router Class Initialized
INFO - 2020-10-17 05:29:27 --> Output Class Initialized
INFO - 2020-10-17 05:29:27 --> Security Class Initialized
DEBUG - 2020-10-17 05:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:29:27 --> Input Class Initialized
INFO - 2020-10-17 05:29:27 --> Language Class Initialized
INFO - 2020-10-17 05:29:27 --> Language Class Initialized
INFO - 2020-10-17 05:29:27 --> Config Class Initialized
INFO - 2020-10-17 05:29:27 --> Loader Class Initialized
INFO - 2020-10-17 05:29:27 --> Helper loaded: url_helper
INFO - 2020-10-17 05:29:27 --> Helper loaded: file_helper
INFO - 2020-10-17 05:29:27 --> Helper loaded: form_helper
INFO - 2020-10-17 05:29:27 --> Helper loaded: my_helper
INFO - 2020-10-17 05:29:27 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:29:27 --> Controller Class Initialized
DEBUG - 2020-10-17 05:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-17 05:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:29:27 --> Final output sent to browser
DEBUG - 2020-10-17 05:29:27 --> Total execution time: 1.0042
INFO - 2020-10-17 05:29:28 --> Config Class Initialized
INFO - 2020-10-17 05:29:28 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:29:28 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:29:28 --> Utf8 Class Initialized
INFO - 2020-10-17 05:29:28 --> URI Class Initialized
INFO - 2020-10-17 05:29:28 --> Router Class Initialized
INFO - 2020-10-17 05:29:28 --> Output Class Initialized
INFO - 2020-10-17 05:29:28 --> Security Class Initialized
DEBUG - 2020-10-17 05:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:29:28 --> Input Class Initialized
INFO - 2020-10-17 05:29:28 --> Language Class Initialized
INFO - 2020-10-17 05:29:28 --> Language Class Initialized
INFO - 2020-10-17 05:29:28 --> Config Class Initialized
INFO - 2020-10-17 05:29:28 --> Loader Class Initialized
INFO - 2020-10-17 05:29:28 --> Helper loaded: url_helper
INFO - 2020-10-17 05:29:28 --> Helper loaded: file_helper
INFO - 2020-10-17 05:29:28 --> Helper loaded: form_helper
INFO - 2020-10-17 05:29:28 --> Helper loaded: my_helper
INFO - 2020-10-17 05:29:28 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:29:28 --> Controller Class Initialized
INFO - 2020-10-17 05:29:32 --> Config Class Initialized
INFO - 2020-10-17 05:29:32 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:29:32 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:29:32 --> Utf8 Class Initialized
INFO - 2020-10-17 05:29:32 --> URI Class Initialized
INFO - 2020-10-17 05:29:32 --> Router Class Initialized
INFO - 2020-10-17 05:29:32 --> Output Class Initialized
INFO - 2020-10-17 05:29:32 --> Security Class Initialized
DEBUG - 2020-10-17 05:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:29:32 --> Input Class Initialized
INFO - 2020-10-17 05:29:32 --> Language Class Initialized
INFO - 2020-10-17 05:29:32 --> Language Class Initialized
INFO - 2020-10-17 05:29:32 --> Config Class Initialized
INFO - 2020-10-17 05:29:32 --> Loader Class Initialized
INFO - 2020-10-17 05:29:32 --> Helper loaded: url_helper
INFO - 2020-10-17 05:29:32 --> Helper loaded: file_helper
INFO - 2020-10-17 05:29:33 --> Helper loaded: form_helper
INFO - 2020-10-17 05:29:33 --> Helper loaded: my_helper
INFO - 2020-10-17 05:29:33 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:29:33 --> Controller Class Initialized
DEBUG - 2020-10-17 05:29:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-17 05:29:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:29:33 --> Final output sent to browser
DEBUG - 2020-10-17 05:29:33 --> Total execution time: 1.0319
INFO - 2020-10-17 05:29:33 --> Config Class Initialized
INFO - 2020-10-17 05:29:33 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:29:33 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:29:33 --> Utf8 Class Initialized
INFO - 2020-10-17 05:29:33 --> URI Class Initialized
INFO - 2020-10-17 05:29:33 --> Router Class Initialized
INFO - 2020-10-17 05:29:33 --> Output Class Initialized
INFO - 2020-10-17 05:29:33 --> Security Class Initialized
DEBUG - 2020-10-17 05:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:29:33 --> Input Class Initialized
INFO - 2020-10-17 05:29:33 --> Language Class Initialized
INFO - 2020-10-17 05:29:34 --> Language Class Initialized
INFO - 2020-10-17 05:29:34 --> Config Class Initialized
INFO - 2020-10-17 05:29:34 --> Loader Class Initialized
INFO - 2020-10-17 05:29:34 --> Helper loaded: url_helper
INFO - 2020-10-17 05:29:34 --> Helper loaded: file_helper
INFO - 2020-10-17 05:29:34 --> Helper loaded: form_helper
INFO - 2020-10-17 05:29:34 --> Helper loaded: my_helper
INFO - 2020-10-17 05:29:34 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:29:34 --> Controller Class Initialized
INFO - 2020-10-17 05:29:36 --> Config Class Initialized
INFO - 2020-10-17 05:29:36 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:29:36 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:29:36 --> Utf8 Class Initialized
INFO - 2020-10-17 05:29:36 --> URI Class Initialized
INFO - 2020-10-17 05:29:37 --> Router Class Initialized
INFO - 2020-10-17 05:29:37 --> Output Class Initialized
INFO - 2020-10-17 05:29:37 --> Security Class Initialized
DEBUG - 2020-10-17 05:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:29:37 --> Input Class Initialized
INFO - 2020-10-17 05:29:37 --> Language Class Initialized
INFO - 2020-10-17 05:29:37 --> Language Class Initialized
INFO - 2020-10-17 05:29:37 --> Config Class Initialized
INFO - 2020-10-17 05:29:37 --> Loader Class Initialized
INFO - 2020-10-17 05:29:37 --> Helper loaded: url_helper
INFO - 2020-10-17 05:29:37 --> Helper loaded: file_helper
INFO - 2020-10-17 05:29:37 --> Helper loaded: form_helper
INFO - 2020-10-17 05:29:37 --> Helper loaded: my_helper
INFO - 2020-10-17 05:29:37 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:29:37 --> Controller Class Initialized
INFO - 2020-10-17 05:29:37 --> Final output sent to browser
DEBUG - 2020-10-17 05:29:37 --> Total execution time: 0.6261
INFO - 2020-10-17 05:30:16 --> Config Class Initialized
INFO - 2020-10-17 05:30:16 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:30:16 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:30:16 --> Utf8 Class Initialized
INFO - 2020-10-17 05:30:16 --> URI Class Initialized
INFO - 2020-10-17 05:30:17 --> Router Class Initialized
INFO - 2020-10-17 05:30:17 --> Output Class Initialized
INFO - 2020-10-17 05:30:17 --> Security Class Initialized
DEBUG - 2020-10-17 05:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:30:17 --> Input Class Initialized
INFO - 2020-10-17 05:30:17 --> Language Class Initialized
INFO - 2020-10-17 05:30:17 --> Language Class Initialized
INFO - 2020-10-17 05:30:17 --> Config Class Initialized
INFO - 2020-10-17 05:30:17 --> Loader Class Initialized
INFO - 2020-10-17 05:30:17 --> Helper loaded: url_helper
INFO - 2020-10-17 05:30:17 --> Helper loaded: file_helper
INFO - 2020-10-17 05:30:17 --> Helper loaded: form_helper
INFO - 2020-10-17 05:30:17 --> Helper loaded: my_helper
INFO - 2020-10-17 05:30:17 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:30:17 --> Controller Class Initialized
INFO - 2020-10-17 05:30:17 --> Final output sent to browser
DEBUG - 2020-10-17 05:30:17 --> Total execution time: 0.6869
INFO - 2020-10-17 05:30:47 --> Config Class Initialized
INFO - 2020-10-17 05:30:47 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:30:47 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:30:47 --> Utf8 Class Initialized
INFO - 2020-10-17 05:30:47 --> URI Class Initialized
INFO - 2020-10-17 05:30:47 --> Router Class Initialized
INFO - 2020-10-17 05:30:47 --> Output Class Initialized
INFO - 2020-10-17 05:30:47 --> Security Class Initialized
DEBUG - 2020-10-17 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:30:47 --> Input Class Initialized
INFO - 2020-10-17 05:30:47 --> Language Class Initialized
INFO - 2020-10-17 05:30:47 --> Language Class Initialized
INFO - 2020-10-17 05:30:47 --> Config Class Initialized
INFO - 2020-10-17 05:30:47 --> Loader Class Initialized
INFO - 2020-10-17 05:30:47 --> Helper loaded: url_helper
INFO - 2020-10-17 05:30:47 --> Helper loaded: file_helper
INFO - 2020-10-17 05:30:47 --> Helper loaded: form_helper
INFO - 2020-10-17 05:30:47 --> Helper loaded: my_helper
INFO - 2020-10-17 05:30:47 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:30:48 --> Controller Class Initialized
INFO - 2020-10-17 05:30:48 --> Final output sent to browser
DEBUG - 2020-10-17 05:30:48 --> Total execution time: 0.8427
INFO - 2020-10-17 05:30:48 --> Config Class Initialized
INFO - 2020-10-17 05:30:48 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:30:48 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:30:48 --> Utf8 Class Initialized
INFO - 2020-10-17 05:30:48 --> URI Class Initialized
INFO - 2020-10-17 05:30:48 --> Router Class Initialized
INFO - 2020-10-17 05:30:48 --> Output Class Initialized
INFO - 2020-10-17 05:30:48 --> Security Class Initialized
DEBUG - 2020-10-17 05:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:30:48 --> Input Class Initialized
INFO - 2020-10-17 05:30:48 --> Language Class Initialized
INFO - 2020-10-17 05:30:48 --> Language Class Initialized
INFO - 2020-10-17 05:30:48 --> Config Class Initialized
INFO - 2020-10-17 05:30:48 --> Loader Class Initialized
INFO - 2020-10-17 05:30:48 --> Helper loaded: url_helper
INFO - 2020-10-17 05:30:48 --> Helper loaded: file_helper
INFO - 2020-10-17 05:30:48 --> Helper loaded: form_helper
INFO - 2020-10-17 05:30:48 --> Helper loaded: my_helper
INFO - 2020-10-17 05:30:48 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:30:49 --> Controller Class Initialized
INFO - 2020-10-17 05:30:53 --> Config Class Initialized
INFO - 2020-10-17 05:30:53 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:30:53 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:30:54 --> Utf8 Class Initialized
INFO - 2020-10-17 05:30:54 --> URI Class Initialized
INFO - 2020-10-17 05:30:54 --> Router Class Initialized
INFO - 2020-10-17 05:30:54 --> Output Class Initialized
INFO - 2020-10-17 05:30:54 --> Security Class Initialized
DEBUG - 2020-10-17 05:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:30:54 --> Input Class Initialized
INFO - 2020-10-17 05:30:54 --> Language Class Initialized
INFO - 2020-10-17 05:30:54 --> Language Class Initialized
INFO - 2020-10-17 05:30:54 --> Config Class Initialized
INFO - 2020-10-17 05:30:54 --> Loader Class Initialized
INFO - 2020-10-17 05:30:54 --> Helper loaded: url_helper
INFO - 2020-10-17 05:30:54 --> Helper loaded: file_helper
INFO - 2020-10-17 05:30:54 --> Helper loaded: form_helper
INFO - 2020-10-17 05:30:54 --> Helper loaded: my_helper
INFO - 2020-10-17 05:30:54 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:30:54 --> Controller Class Initialized
INFO - 2020-10-17 05:30:54 --> Final output sent to browser
DEBUG - 2020-10-17 05:30:54 --> Total execution time: 0.6883
INFO - 2020-10-17 05:31:03 --> Config Class Initialized
INFO - 2020-10-17 05:31:03 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:31:03 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:31:03 --> Utf8 Class Initialized
INFO - 2020-10-17 05:31:03 --> URI Class Initialized
INFO - 2020-10-17 05:31:03 --> Router Class Initialized
INFO - 2020-10-17 05:31:03 --> Output Class Initialized
INFO - 2020-10-17 05:31:03 --> Security Class Initialized
DEBUG - 2020-10-17 05:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:31:04 --> Input Class Initialized
INFO - 2020-10-17 05:31:04 --> Language Class Initialized
INFO - 2020-10-17 05:31:04 --> Language Class Initialized
INFO - 2020-10-17 05:31:04 --> Config Class Initialized
INFO - 2020-10-17 05:31:04 --> Loader Class Initialized
INFO - 2020-10-17 05:31:04 --> Helper loaded: url_helper
INFO - 2020-10-17 05:31:04 --> Helper loaded: file_helper
INFO - 2020-10-17 05:31:04 --> Helper loaded: form_helper
INFO - 2020-10-17 05:31:04 --> Helper loaded: my_helper
INFO - 2020-10-17 05:31:04 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:31:04 --> Controller Class Initialized
DEBUG - 2020-10-17 05:31:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-17 05:31:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:31:04 --> Final output sent to browser
DEBUG - 2020-10-17 05:31:04 --> Total execution time: 1.0793
INFO - 2020-10-17 05:31:16 --> Config Class Initialized
INFO - 2020-10-17 05:31:16 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:31:16 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:31:16 --> Utf8 Class Initialized
INFO - 2020-10-17 05:31:16 --> URI Class Initialized
INFO - 2020-10-17 05:31:16 --> Router Class Initialized
INFO - 2020-10-17 05:31:16 --> Output Class Initialized
INFO - 2020-10-17 05:31:16 --> Security Class Initialized
DEBUG - 2020-10-17 05:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:31:16 --> Input Class Initialized
INFO - 2020-10-17 05:31:16 --> Language Class Initialized
INFO - 2020-10-17 05:31:16 --> Language Class Initialized
INFO - 2020-10-17 05:31:16 --> Config Class Initialized
INFO - 2020-10-17 05:31:16 --> Loader Class Initialized
INFO - 2020-10-17 05:31:16 --> Helper loaded: url_helper
INFO - 2020-10-17 05:31:16 --> Helper loaded: file_helper
INFO - 2020-10-17 05:31:16 --> Helper loaded: form_helper
INFO - 2020-10-17 05:31:16 --> Helper loaded: my_helper
INFO - 2020-10-17 05:31:16 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:31:16 --> Controller Class Initialized
DEBUG - 2020-10-17 05:31:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-17 05:31:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:31:17 --> Final output sent to browser
DEBUG - 2020-10-17 05:31:17 --> Total execution time: 1.0208
INFO - 2020-10-17 05:31:17 --> Config Class Initialized
INFO - 2020-10-17 05:31:17 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:31:17 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:31:17 --> Utf8 Class Initialized
INFO - 2020-10-17 05:31:17 --> URI Class Initialized
INFO - 2020-10-17 05:31:17 --> Router Class Initialized
INFO - 2020-10-17 05:31:17 --> Output Class Initialized
INFO - 2020-10-17 05:31:17 --> Security Class Initialized
DEBUG - 2020-10-17 05:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:31:17 --> Input Class Initialized
INFO - 2020-10-17 05:31:17 --> Language Class Initialized
INFO - 2020-10-17 05:31:17 --> Language Class Initialized
INFO - 2020-10-17 05:31:17 --> Config Class Initialized
INFO - 2020-10-17 05:31:17 --> Loader Class Initialized
INFO - 2020-10-17 05:31:17 --> Helper loaded: url_helper
INFO - 2020-10-17 05:31:17 --> Helper loaded: file_helper
INFO - 2020-10-17 05:31:17 --> Helper loaded: form_helper
INFO - 2020-10-17 05:31:17 --> Helper loaded: my_helper
INFO - 2020-10-17 05:31:18 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:31:18 --> Controller Class Initialized
INFO - 2020-10-17 05:31:22 --> Config Class Initialized
INFO - 2020-10-17 05:31:22 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:31:22 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:31:22 --> Utf8 Class Initialized
INFO - 2020-10-17 05:31:22 --> URI Class Initialized
INFO - 2020-10-17 05:31:22 --> Router Class Initialized
INFO - 2020-10-17 05:31:22 --> Output Class Initialized
INFO - 2020-10-17 05:31:22 --> Security Class Initialized
DEBUG - 2020-10-17 05:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:31:22 --> Input Class Initialized
INFO - 2020-10-17 05:31:22 --> Language Class Initialized
INFO - 2020-10-17 05:31:22 --> Language Class Initialized
INFO - 2020-10-17 05:31:22 --> Config Class Initialized
INFO - 2020-10-17 05:31:22 --> Loader Class Initialized
INFO - 2020-10-17 05:31:22 --> Helper loaded: url_helper
INFO - 2020-10-17 05:31:22 --> Helper loaded: file_helper
INFO - 2020-10-17 05:31:22 --> Helper loaded: form_helper
INFO - 2020-10-17 05:31:22 --> Helper loaded: my_helper
INFO - 2020-10-17 05:31:22 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:31:23 --> Controller Class Initialized
DEBUG - 2020-10-17 05:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-17 05:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:31:23 --> Final output sent to browser
DEBUG - 2020-10-17 05:31:23 --> Total execution time: 1.1144
INFO - 2020-10-17 05:31:23 --> Config Class Initialized
INFO - 2020-10-17 05:31:23 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:31:23 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:31:23 --> Utf8 Class Initialized
INFO - 2020-10-17 05:31:23 --> URI Class Initialized
INFO - 2020-10-17 05:31:23 --> Router Class Initialized
INFO - 2020-10-17 05:31:23 --> Output Class Initialized
INFO - 2020-10-17 05:31:23 --> Security Class Initialized
DEBUG - 2020-10-17 05:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:31:23 --> Input Class Initialized
INFO - 2020-10-17 05:31:23 --> Language Class Initialized
INFO - 2020-10-17 05:31:23 --> Language Class Initialized
INFO - 2020-10-17 05:31:24 --> Config Class Initialized
INFO - 2020-10-17 05:31:24 --> Loader Class Initialized
INFO - 2020-10-17 05:31:24 --> Helper loaded: url_helper
INFO - 2020-10-17 05:31:24 --> Helper loaded: file_helper
INFO - 2020-10-17 05:31:24 --> Helper loaded: form_helper
INFO - 2020-10-17 05:31:24 --> Helper loaded: my_helper
INFO - 2020-10-17 05:31:24 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:31:24 --> Controller Class Initialized
INFO - 2020-10-17 05:31:30 --> Config Class Initialized
INFO - 2020-10-17 05:31:30 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:31:30 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:31:30 --> Utf8 Class Initialized
INFO - 2020-10-17 05:31:30 --> URI Class Initialized
INFO - 2020-10-17 05:31:30 --> Router Class Initialized
INFO - 2020-10-17 05:31:30 --> Output Class Initialized
INFO - 2020-10-17 05:31:30 --> Security Class Initialized
DEBUG - 2020-10-17 05:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:31:30 --> Input Class Initialized
INFO - 2020-10-17 05:31:30 --> Language Class Initialized
INFO - 2020-10-17 05:31:30 --> Language Class Initialized
INFO - 2020-10-17 05:31:30 --> Config Class Initialized
INFO - 2020-10-17 05:31:30 --> Loader Class Initialized
INFO - 2020-10-17 05:31:30 --> Helper loaded: url_helper
INFO - 2020-10-17 05:31:30 --> Helper loaded: file_helper
INFO - 2020-10-17 05:31:31 --> Helper loaded: form_helper
INFO - 2020-10-17 05:31:31 --> Helper loaded: my_helper
INFO - 2020-10-17 05:31:31 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:31:31 --> Controller Class Initialized
DEBUG - 2020-10-17 05:31:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-17 05:31:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:31:31 --> Final output sent to browser
DEBUG - 2020-10-17 05:31:31 --> Total execution time: 1.1019
INFO - 2020-10-17 05:33:32 --> Config Class Initialized
INFO - 2020-10-17 05:33:32 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:33:32 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:33:32 --> Utf8 Class Initialized
INFO - 2020-10-17 05:33:32 --> URI Class Initialized
INFO - 2020-10-17 05:33:32 --> Router Class Initialized
INFO - 2020-10-17 05:33:32 --> Output Class Initialized
INFO - 2020-10-17 05:33:32 --> Security Class Initialized
DEBUG - 2020-10-17 05:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:33:33 --> Input Class Initialized
INFO - 2020-10-17 05:33:33 --> Language Class Initialized
INFO - 2020-10-17 05:33:33 --> Language Class Initialized
INFO - 2020-10-17 05:33:33 --> Config Class Initialized
INFO - 2020-10-17 05:33:33 --> Loader Class Initialized
INFO - 2020-10-17 05:33:33 --> Helper loaded: url_helper
INFO - 2020-10-17 05:33:33 --> Helper loaded: file_helper
INFO - 2020-10-17 05:33:33 --> Helper loaded: form_helper
INFO - 2020-10-17 05:33:33 --> Helper loaded: my_helper
INFO - 2020-10-17 05:33:33 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:33:33 --> Controller Class Initialized
DEBUG - 2020-10-17 05:33:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:33:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:33:33 --> Final output sent to browser
DEBUG - 2020-10-17 05:33:33 --> Total execution time: 1.0839
INFO - 2020-10-17 05:33:34 --> Config Class Initialized
INFO - 2020-10-17 05:33:34 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:33:34 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:33:34 --> Utf8 Class Initialized
INFO - 2020-10-17 05:33:34 --> URI Class Initialized
INFO - 2020-10-17 05:33:34 --> Router Class Initialized
INFO - 2020-10-17 05:33:34 --> Output Class Initialized
INFO - 2020-10-17 05:33:34 --> Security Class Initialized
DEBUG - 2020-10-17 05:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:33:34 --> Input Class Initialized
INFO - 2020-10-17 05:33:34 --> Language Class Initialized
INFO - 2020-10-17 05:33:34 --> Language Class Initialized
INFO - 2020-10-17 05:33:34 --> Config Class Initialized
INFO - 2020-10-17 05:33:34 --> Loader Class Initialized
INFO - 2020-10-17 05:33:34 --> Helper loaded: url_helper
INFO - 2020-10-17 05:33:34 --> Helper loaded: file_helper
INFO - 2020-10-17 05:33:34 --> Helper loaded: form_helper
INFO - 2020-10-17 05:33:34 --> Helper loaded: my_helper
INFO - 2020-10-17 05:33:34 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:33:35 --> Controller Class Initialized
INFO - 2020-10-17 05:36:01 --> Config Class Initialized
INFO - 2020-10-17 05:36:01 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:01 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:01 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:01 --> URI Class Initialized
INFO - 2020-10-17 05:36:01 --> Router Class Initialized
INFO - 2020-10-17 05:36:01 --> Output Class Initialized
INFO - 2020-10-17 05:36:01 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:01 --> Input Class Initialized
INFO - 2020-10-17 05:36:01 --> Language Class Initialized
INFO - 2020-10-17 05:36:02 --> Language Class Initialized
INFO - 2020-10-17 05:36:02 --> Config Class Initialized
INFO - 2020-10-17 05:36:02 --> Loader Class Initialized
INFO - 2020-10-17 05:36:02 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:02 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:02 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:02 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:02 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:02 --> Controller Class Initialized
INFO - 2020-10-17 05:36:02 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:02 --> Total execution time: 0.8759
INFO - 2020-10-17 05:36:02 --> Config Class Initialized
INFO - 2020-10-17 05:36:02 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:02 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:02 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:02 --> URI Class Initialized
INFO - 2020-10-17 05:36:03 --> Router Class Initialized
INFO - 2020-10-17 05:36:03 --> Output Class Initialized
INFO - 2020-10-17 05:36:03 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:03 --> Input Class Initialized
INFO - 2020-10-17 05:36:03 --> Language Class Initialized
INFO - 2020-10-17 05:36:03 --> Language Class Initialized
INFO - 2020-10-17 05:36:03 --> Config Class Initialized
INFO - 2020-10-17 05:36:03 --> Loader Class Initialized
INFO - 2020-10-17 05:36:03 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:03 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:03 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:03 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:03 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:03 --> Controller Class Initialized
INFO - 2020-10-17 05:36:06 --> Config Class Initialized
INFO - 2020-10-17 05:36:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:06 --> URI Class Initialized
INFO - 2020-10-17 05:36:06 --> Router Class Initialized
INFO - 2020-10-17 05:36:06 --> Output Class Initialized
INFO - 2020-10-17 05:36:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:06 --> Input Class Initialized
INFO - 2020-10-17 05:36:06 --> Language Class Initialized
INFO - 2020-10-17 05:36:06 --> Language Class Initialized
INFO - 2020-10-17 05:36:06 --> Config Class Initialized
INFO - 2020-10-17 05:36:06 --> Loader Class Initialized
INFO - 2020-10-17 05:36:06 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:06 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:06 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:06 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:06 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:07 --> Controller Class Initialized
INFO - 2020-10-17 05:36:07 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:07 --> Total execution time: 0.9021
INFO - 2020-10-17 05:36:07 --> Config Class Initialized
INFO - 2020-10-17 05:36:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:07 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:07 --> URI Class Initialized
INFO - 2020-10-17 05:36:07 --> Router Class Initialized
INFO - 2020-10-17 05:36:07 --> Output Class Initialized
INFO - 2020-10-17 05:36:07 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:07 --> Input Class Initialized
INFO - 2020-10-17 05:36:07 --> Language Class Initialized
INFO - 2020-10-17 05:36:07 --> Language Class Initialized
INFO - 2020-10-17 05:36:08 --> Config Class Initialized
INFO - 2020-10-17 05:36:08 --> Loader Class Initialized
INFO - 2020-10-17 05:36:08 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:08 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:08 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:08 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:08 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:08 --> Controller Class Initialized
INFO - 2020-10-17 05:36:10 --> Config Class Initialized
INFO - 2020-10-17 05:36:10 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:10 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:10 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:10 --> URI Class Initialized
INFO - 2020-10-17 05:36:10 --> Router Class Initialized
INFO - 2020-10-17 05:36:10 --> Output Class Initialized
INFO - 2020-10-17 05:36:10 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:10 --> Input Class Initialized
INFO - 2020-10-17 05:36:10 --> Language Class Initialized
INFO - 2020-10-17 05:36:10 --> Language Class Initialized
INFO - 2020-10-17 05:36:10 --> Config Class Initialized
INFO - 2020-10-17 05:36:10 --> Loader Class Initialized
INFO - 2020-10-17 05:36:10 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:10 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:10 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:10 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:10 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:11 --> Controller Class Initialized
INFO - 2020-10-17 05:36:11 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:11 --> Total execution time: 0.8067
INFO - 2020-10-17 05:36:11 --> Config Class Initialized
INFO - 2020-10-17 05:36:11 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:11 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:11 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:11 --> URI Class Initialized
INFO - 2020-10-17 05:36:11 --> Router Class Initialized
INFO - 2020-10-17 05:36:11 --> Output Class Initialized
INFO - 2020-10-17 05:36:11 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:11 --> Input Class Initialized
INFO - 2020-10-17 05:36:11 --> Language Class Initialized
INFO - 2020-10-17 05:36:11 --> Language Class Initialized
INFO - 2020-10-17 05:36:11 --> Config Class Initialized
INFO - 2020-10-17 05:36:11 --> Loader Class Initialized
INFO - 2020-10-17 05:36:12 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:12 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:12 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:12 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:12 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:12 --> Controller Class Initialized
INFO - 2020-10-17 05:36:12 --> Config Class Initialized
INFO - 2020-10-17 05:36:12 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:12 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:12 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:12 --> URI Class Initialized
INFO - 2020-10-17 05:36:13 --> Router Class Initialized
INFO - 2020-10-17 05:36:13 --> Output Class Initialized
INFO - 2020-10-17 05:36:13 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:13 --> Input Class Initialized
INFO - 2020-10-17 05:36:13 --> Language Class Initialized
INFO - 2020-10-17 05:36:13 --> Language Class Initialized
INFO - 2020-10-17 05:36:13 --> Config Class Initialized
INFO - 2020-10-17 05:36:13 --> Loader Class Initialized
INFO - 2020-10-17 05:36:13 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:13 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:13 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:13 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:13 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:13 --> Controller Class Initialized
INFO - 2020-10-17 05:36:13 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:13 --> Total execution time: 0.8036
INFO - 2020-10-17 05:36:13 --> Config Class Initialized
INFO - 2020-10-17 05:36:13 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:14 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:14 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:14 --> URI Class Initialized
INFO - 2020-10-17 05:36:14 --> Router Class Initialized
INFO - 2020-10-17 05:36:14 --> Output Class Initialized
INFO - 2020-10-17 05:36:14 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:14 --> Input Class Initialized
INFO - 2020-10-17 05:36:14 --> Language Class Initialized
INFO - 2020-10-17 05:36:14 --> Language Class Initialized
INFO - 2020-10-17 05:36:14 --> Config Class Initialized
INFO - 2020-10-17 05:36:14 --> Loader Class Initialized
INFO - 2020-10-17 05:36:14 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:14 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:14 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:14 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:14 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:14 --> Controller Class Initialized
INFO - 2020-10-17 05:36:15 --> Config Class Initialized
INFO - 2020-10-17 05:36:15 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:15 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:15 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:15 --> URI Class Initialized
INFO - 2020-10-17 05:36:15 --> Router Class Initialized
INFO - 2020-10-17 05:36:15 --> Output Class Initialized
INFO - 2020-10-17 05:36:15 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:16 --> Input Class Initialized
INFO - 2020-10-17 05:36:16 --> Language Class Initialized
INFO - 2020-10-17 05:36:16 --> Language Class Initialized
INFO - 2020-10-17 05:36:16 --> Config Class Initialized
INFO - 2020-10-17 05:36:16 --> Loader Class Initialized
INFO - 2020-10-17 05:36:16 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:16 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:16 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:16 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:16 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:16 --> Controller Class Initialized
INFO - 2020-10-17 05:36:16 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:16 --> Total execution time: 0.8208
INFO - 2020-10-17 05:36:16 --> Config Class Initialized
INFO - 2020-10-17 05:36:16 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:16 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:16 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:17 --> URI Class Initialized
INFO - 2020-10-17 05:36:17 --> Router Class Initialized
INFO - 2020-10-17 05:36:17 --> Output Class Initialized
INFO - 2020-10-17 05:36:17 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:17 --> Input Class Initialized
INFO - 2020-10-17 05:36:17 --> Language Class Initialized
INFO - 2020-10-17 05:36:17 --> Language Class Initialized
INFO - 2020-10-17 05:36:17 --> Config Class Initialized
INFO - 2020-10-17 05:36:17 --> Loader Class Initialized
INFO - 2020-10-17 05:36:17 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:17 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:17 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:17 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:17 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:18 --> Controller Class Initialized
INFO - 2020-10-17 05:36:18 --> Config Class Initialized
INFO - 2020-10-17 05:36:18 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:18 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:18 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:18 --> URI Class Initialized
INFO - 2020-10-17 05:36:18 --> Router Class Initialized
INFO - 2020-10-17 05:36:19 --> Output Class Initialized
INFO - 2020-10-17 05:36:19 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:19 --> Input Class Initialized
INFO - 2020-10-17 05:36:19 --> Language Class Initialized
INFO - 2020-10-17 05:36:19 --> Language Class Initialized
INFO - 2020-10-17 05:36:19 --> Config Class Initialized
INFO - 2020-10-17 05:36:19 --> Loader Class Initialized
INFO - 2020-10-17 05:36:19 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:19 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:19 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:19 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:19 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:19 --> Controller Class Initialized
INFO - 2020-10-17 05:36:19 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:19 --> Total execution time: 0.8215
INFO - 2020-10-17 05:36:19 --> Config Class Initialized
INFO - 2020-10-17 05:36:19 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:19 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:20 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:20 --> URI Class Initialized
INFO - 2020-10-17 05:36:20 --> Router Class Initialized
INFO - 2020-10-17 05:36:20 --> Output Class Initialized
INFO - 2020-10-17 05:36:20 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:20 --> Input Class Initialized
INFO - 2020-10-17 05:36:20 --> Language Class Initialized
INFO - 2020-10-17 05:36:20 --> Language Class Initialized
INFO - 2020-10-17 05:36:20 --> Config Class Initialized
INFO - 2020-10-17 05:36:20 --> Loader Class Initialized
INFO - 2020-10-17 05:36:20 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:20 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:20 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:20 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:20 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:20 --> Controller Class Initialized
INFO - 2020-10-17 05:36:21 --> Config Class Initialized
INFO - 2020-10-17 05:36:21 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:21 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:21 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:21 --> URI Class Initialized
INFO - 2020-10-17 05:36:21 --> Router Class Initialized
INFO - 2020-10-17 05:36:21 --> Output Class Initialized
INFO - 2020-10-17 05:36:21 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:21 --> Input Class Initialized
INFO - 2020-10-17 05:36:21 --> Language Class Initialized
INFO - 2020-10-17 05:36:21 --> Language Class Initialized
INFO - 2020-10-17 05:36:21 --> Config Class Initialized
INFO - 2020-10-17 05:36:21 --> Loader Class Initialized
INFO - 2020-10-17 05:36:21 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:21 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:21 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:21 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:22 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:22 --> Controller Class Initialized
INFO - 2020-10-17 05:36:22 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:22 --> Total execution time: 0.9951
INFO - 2020-10-17 05:36:22 --> Config Class Initialized
INFO - 2020-10-17 05:36:22 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:22 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:22 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:22 --> URI Class Initialized
INFO - 2020-10-17 05:36:22 --> Router Class Initialized
INFO - 2020-10-17 05:36:22 --> Output Class Initialized
INFO - 2020-10-17 05:36:22 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:23 --> Input Class Initialized
INFO - 2020-10-17 05:36:23 --> Language Class Initialized
INFO - 2020-10-17 05:36:23 --> Language Class Initialized
INFO - 2020-10-17 05:36:23 --> Config Class Initialized
INFO - 2020-10-17 05:36:23 --> Loader Class Initialized
INFO - 2020-10-17 05:36:23 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:23 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:23 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:23 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:23 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:23 --> Controller Class Initialized
INFO - 2020-10-17 05:36:24 --> Config Class Initialized
INFO - 2020-10-17 05:36:24 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:24 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:24 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:24 --> URI Class Initialized
INFO - 2020-10-17 05:36:24 --> Router Class Initialized
INFO - 2020-10-17 05:36:24 --> Output Class Initialized
INFO - 2020-10-17 05:36:24 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:24 --> Input Class Initialized
INFO - 2020-10-17 05:36:24 --> Language Class Initialized
INFO - 2020-10-17 05:36:24 --> Language Class Initialized
INFO - 2020-10-17 05:36:24 --> Config Class Initialized
INFO - 2020-10-17 05:36:24 --> Loader Class Initialized
INFO - 2020-10-17 05:36:24 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:24 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:24 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:24 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:24 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:24 --> Controller Class Initialized
INFO - 2020-10-17 05:36:24 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:24 --> Total execution time: 0.6746
INFO - 2020-10-17 05:36:24 --> Config Class Initialized
INFO - 2020-10-17 05:36:24 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:24 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:24 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:24 --> URI Class Initialized
INFO - 2020-10-17 05:36:24 --> Router Class Initialized
INFO - 2020-10-17 05:36:24 --> Output Class Initialized
INFO - 2020-10-17 05:36:25 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:25 --> Input Class Initialized
INFO - 2020-10-17 05:36:25 --> Language Class Initialized
INFO - 2020-10-17 05:36:25 --> Language Class Initialized
INFO - 2020-10-17 05:36:25 --> Config Class Initialized
INFO - 2020-10-17 05:36:25 --> Loader Class Initialized
INFO - 2020-10-17 05:36:25 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:25 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:25 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:25 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:25 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:25 --> Controller Class Initialized
INFO - 2020-10-17 05:36:27 --> Config Class Initialized
INFO - 2020-10-17 05:36:27 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:27 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:27 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:27 --> URI Class Initialized
INFO - 2020-10-17 05:36:27 --> Router Class Initialized
INFO - 2020-10-17 05:36:27 --> Output Class Initialized
INFO - 2020-10-17 05:36:27 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:28 --> Input Class Initialized
INFO - 2020-10-17 05:36:28 --> Language Class Initialized
INFO - 2020-10-17 05:36:28 --> Language Class Initialized
INFO - 2020-10-17 05:36:28 --> Config Class Initialized
INFO - 2020-10-17 05:36:28 --> Loader Class Initialized
INFO - 2020-10-17 05:36:28 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:28 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:28 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:28 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:28 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:28 --> Controller Class Initialized
ERROR - 2020-10-17 05:36:28 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '11'
INFO - 2020-10-17 05:36:28 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:36:30 --> Config Class Initialized
INFO - 2020-10-17 05:36:30 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:30 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:30 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:31 --> URI Class Initialized
INFO - 2020-10-17 05:36:31 --> Router Class Initialized
INFO - 2020-10-17 05:36:31 --> Output Class Initialized
INFO - 2020-10-17 05:36:31 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:31 --> Input Class Initialized
INFO - 2020-10-17 05:36:31 --> Language Class Initialized
INFO - 2020-10-17 05:36:31 --> Language Class Initialized
INFO - 2020-10-17 05:36:31 --> Config Class Initialized
INFO - 2020-10-17 05:36:31 --> Loader Class Initialized
INFO - 2020-10-17 05:36:31 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:31 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:31 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:31 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:31 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:31 --> Controller Class Initialized
ERROR - 2020-10-17 05:36:31 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '11'
INFO - 2020-10-17 05:36:31 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:36:34 --> Config Class Initialized
INFO - 2020-10-17 05:36:34 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:34 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:34 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:34 --> URI Class Initialized
INFO - 2020-10-17 05:36:34 --> Router Class Initialized
INFO - 2020-10-17 05:36:34 --> Output Class Initialized
INFO - 2020-10-17 05:36:34 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:34 --> Input Class Initialized
INFO - 2020-10-17 05:36:34 --> Language Class Initialized
INFO - 2020-10-17 05:36:34 --> Language Class Initialized
INFO - 2020-10-17 05:36:34 --> Config Class Initialized
INFO - 2020-10-17 05:36:34 --> Loader Class Initialized
INFO - 2020-10-17 05:36:34 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:34 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:34 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:34 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:34 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:34 --> Controller Class Initialized
ERROR - 2020-10-17 05:36:34 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '11'
INFO - 2020-10-17 05:36:34 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:36:36 --> Config Class Initialized
INFO - 2020-10-17 05:36:36 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:36 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:36 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:36 --> URI Class Initialized
INFO - 2020-10-17 05:36:36 --> Router Class Initialized
INFO - 2020-10-17 05:36:36 --> Output Class Initialized
INFO - 2020-10-17 05:36:36 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:36 --> Input Class Initialized
INFO - 2020-10-17 05:36:36 --> Language Class Initialized
INFO - 2020-10-17 05:36:36 --> Language Class Initialized
INFO - 2020-10-17 05:36:36 --> Config Class Initialized
INFO - 2020-10-17 05:36:37 --> Loader Class Initialized
INFO - 2020-10-17 05:36:37 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:37 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:37 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:37 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:37 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:37 --> Controller Class Initialized
ERROR - 2020-10-17 05:36:37 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '11'
INFO - 2020-10-17 05:36:37 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:36:38 --> Config Class Initialized
INFO - 2020-10-17 05:36:38 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:38 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:38 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:38 --> URI Class Initialized
INFO - 2020-10-17 05:36:38 --> Router Class Initialized
INFO - 2020-10-17 05:36:38 --> Output Class Initialized
INFO - 2020-10-17 05:36:38 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:38 --> Input Class Initialized
INFO - 2020-10-17 05:36:38 --> Language Class Initialized
INFO - 2020-10-17 05:36:38 --> Language Class Initialized
INFO - 2020-10-17 05:36:38 --> Config Class Initialized
INFO - 2020-10-17 05:36:38 --> Loader Class Initialized
INFO - 2020-10-17 05:36:38 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:38 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:38 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:39 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:39 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:39 --> Controller Class Initialized
ERROR - 2020-10-17 05:36:39 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '10'
INFO - 2020-10-17 05:36:39 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:36:42 --> Config Class Initialized
INFO - 2020-10-17 05:36:42 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:42 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:42 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:43 --> URI Class Initialized
INFO - 2020-10-17 05:36:43 --> Router Class Initialized
INFO - 2020-10-17 05:36:43 --> Output Class Initialized
INFO - 2020-10-17 05:36:43 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:43 --> Input Class Initialized
INFO - 2020-10-17 05:36:43 --> Language Class Initialized
INFO - 2020-10-17 05:36:43 --> Language Class Initialized
INFO - 2020-10-17 05:36:43 --> Config Class Initialized
INFO - 2020-10-17 05:36:43 --> Loader Class Initialized
INFO - 2020-10-17 05:36:43 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:43 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:43 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:43 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:43 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:43 --> Controller Class Initialized
DEBUG - 2020-10-17 05:36:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-17 05:36:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:36:43 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:43 --> Total execution time: 1.0325
INFO - 2020-10-17 05:36:44 --> Config Class Initialized
INFO - 2020-10-17 05:36:44 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:44 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:44 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:44 --> URI Class Initialized
INFO - 2020-10-17 05:36:44 --> Router Class Initialized
INFO - 2020-10-17 05:36:44 --> Output Class Initialized
INFO - 2020-10-17 05:36:44 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:44 --> Input Class Initialized
INFO - 2020-10-17 05:36:44 --> Language Class Initialized
INFO - 2020-10-17 05:36:44 --> Language Class Initialized
INFO - 2020-10-17 05:36:44 --> Config Class Initialized
INFO - 2020-10-17 05:36:44 --> Loader Class Initialized
INFO - 2020-10-17 05:36:44 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:44 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:44 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:44 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:45 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:45 --> Controller Class Initialized
INFO - 2020-10-17 05:36:47 --> Config Class Initialized
INFO - 2020-10-17 05:36:47 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:47 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:47 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:47 --> URI Class Initialized
INFO - 2020-10-17 05:36:47 --> Router Class Initialized
INFO - 2020-10-17 05:36:47 --> Output Class Initialized
INFO - 2020-10-17 05:36:47 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:48 --> Input Class Initialized
INFO - 2020-10-17 05:36:48 --> Language Class Initialized
INFO - 2020-10-17 05:36:48 --> Language Class Initialized
INFO - 2020-10-17 05:36:48 --> Config Class Initialized
INFO - 2020-10-17 05:36:48 --> Loader Class Initialized
INFO - 2020-10-17 05:36:48 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:48 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:48 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:48 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:48 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:48 --> Controller Class Initialized
INFO - 2020-10-17 05:36:48 --> Final output sent to browser
DEBUG - 2020-10-17 05:36:48 --> Total execution time: 0.9708
INFO - 2020-10-17 05:36:48 --> Config Class Initialized
INFO - 2020-10-17 05:36:48 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:49 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:49 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:49 --> URI Class Initialized
INFO - 2020-10-17 05:36:49 --> Router Class Initialized
INFO - 2020-10-17 05:36:49 --> Output Class Initialized
INFO - 2020-10-17 05:36:49 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:49 --> Input Class Initialized
INFO - 2020-10-17 05:36:49 --> Language Class Initialized
INFO - 2020-10-17 05:36:49 --> Language Class Initialized
INFO - 2020-10-17 05:36:49 --> Config Class Initialized
INFO - 2020-10-17 05:36:49 --> Loader Class Initialized
INFO - 2020-10-17 05:36:49 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:49 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:49 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:49 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:49 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:50 --> Controller Class Initialized
INFO - 2020-10-17 05:36:55 --> Config Class Initialized
INFO - 2020-10-17 05:36:55 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:55 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:56 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:56 --> URI Class Initialized
INFO - 2020-10-17 05:36:56 --> Router Class Initialized
INFO - 2020-10-17 05:36:56 --> Output Class Initialized
INFO - 2020-10-17 05:36:56 --> Security Class Initialized
DEBUG - 2020-10-17 05:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:36:56 --> Input Class Initialized
INFO - 2020-10-17 05:36:56 --> Language Class Initialized
INFO - 2020-10-17 05:36:56 --> Language Class Initialized
INFO - 2020-10-17 05:36:56 --> Config Class Initialized
INFO - 2020-10-17 05:36:56 --> Loader Class Initialized
INFO - 2020-10-17 05:36:56 --> Helper loaded: url_helper
INFO - 2020-10-17 05:36:56 --> Helper loaded: file_helper
INFO - 2020-10-17 05:36:56 --> Helper loaded: form_helper
INFO - 2020-10-17 05:36:56 --> Helper loaded: my_helper
INFO - 2020-10-17 05:36:56 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:36:56 --> Controller Class Initialized
ERROR - 2020-10-17 05:36:56 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-10-17 05:36:56 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:36:59 --> Config Class Initialized
INFO - 2020-10-17 05:36:59 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:36:59 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:36:59 --> Utf8 Class Initialized
INFO - 2020-10-17 05:36:59 --> URI Class Initialized
INFO - 2020-10-17 05:36:59 --> Router Class Initialized
INFO - 2020-10-17 05:36:59 --> Output Class Initialized
INFO - 2020-10-17 05:36:59 --> Security Class Initialized
DEBUG - 2020-10-17 05:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:37:00 --> Input Class Initialized
INFO - 2020-10-17 05:37:00 --> Language Class Initialized
INFO - 2020-10-17 05:37:00 --> Language Class Initialized
INFO - 2020-10-17 05:37:00 --> Config Class Initialized
INFO - 2020-10-17 05:37:00 --> Loader Class Initialized
INFO - 2020-10-17 05:37:00 --> Helper loaded: url_helper
INFO - 2020-10-17 05:37:00 --> Helper loaded: file_helper
INFO - 2020-10-17 05:37:00 --> Helper loaded: form_helper
INFO - 2020-10-17 05:37:00 --> Helper loaded: my_helper
INFO - 2020-10-17 05:37:00 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:37:00 --> Controller Class Initialized
ERROR - 2020-10-17 05:37:00 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '9'
INFO - 2020-10-17 05:37:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:37:02 --> Config Class Initialized
INFO - 2020-10-17 05:37:02 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:37:02 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:37:03 --> Utf8 Class Initialized
INFO - 2020-10-17 05:37:03 --> URI Class Initialized
INFO - 2020-10-17 05:37:03 --> Router Class Initialized
INFO - 2020-10-17 05:37:03 --> Output Class Initialized
INFO - 2020-10-17 05:37:03 --> Security Class Initialized
DEBUG - 2020-10-17 05:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:37:03 --> Input Class Initialized
INFO - 2020-10-17 05:37:03 --> Language Class Initialized
INFO - 2020-10-17 05:37:03 --> Language Class Initialized
INFO - 2020-10-17 05:37:03 --> Config Class Initialized
INFO - 2020-10-17 05:37:03 --> Loader Class Initialized
INFO - 2020-10-17 05:37:03 --> Helper loaded: url_helper
INFO - 2020-10-17 05:37:03 --> Helper loaded: file_helper
INFO - 2020-10-17 05:37:03 --> Helper loaded: form_helper
INFO - 2020-10-17 05:37:03 --> Helper loaded: my_helper
INFO - 2020-10-17 05:37:03 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:37:03 --> Controller Class Initialized
DEBUG - 2020-10-17 05:37:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:37:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:37:03 --> Final output sent to browser
DEBUG - 2020-10-17 05:37:03 --> Total execution time: 0.8596
INFO - 2020-10-17 05:37:04 --> Config Class Initialized
INFO - 2020-10-17 05:37:04 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:37:04 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:37:04 --> Utf8 Class Initialized
INFO - 2020-10-17 05:37:04 --> URI Class Initialized
INFO - 2020-10-17 05:37:04 --> Router Class Initialized
INFO - 2020-10-17 05:37:04 --> Output Class Initialized
INFO - 2020-10-17 05:37:04 --> Security Class Initialized
DEBUG - 2020-10-17 05:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:37:04 --> Input Class Initialized
INFO - 2020-10-17 05:37:04 --> Language Class Initialized
INFO - 2020-10-17 05:37:04 --> Language Class Initialized
INFO - 2020-10-17 05:37:04 --> Config Class Initialized
INFO - 2020-10-17 05:37:04 --> Loader Class Initialized
INFO - 2020-10-17 05:37:04 --> Helper loaded: url_helper
INFO - 2020-10-17 05:37:04 --> Helper loaded: file_helper
INFO - 2020-10-17 05:37:04 --> Helper loaded: form_helper
INFO - 2020-10-17 05:37:04 --> Helper loaded: my_helper
INFO - 2020-10-17 05:37:04 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:37:05 --> Controller Class Initialized
INFO - 2020-10-17 05:37:46 --> Config Class Initialized
INFO - 2020-10-17 05:37:46 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:37:46 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:37:46 --> Utf8 Class Initialized
INFO - 2020-10-17 05:37:46 --> URI Class Initialized
INFO - 2020-10-17 05:37:46 --> Router Class Initialized
INFO - 2020-10-17 05:37:46 --> Output Class Initialized
INFO - 2020-10-17 05:37:46 --> Security Class Initialized
DEBUG - 2020-10-17 05:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:37:46 --> Input Class Initialized
INFO - 2020-10-17 05:37:46 --> Language Class Initialized
INFO - 2020-10-17 05:37:46 --> Language Class Initialized
INFO - 2020-10-17 05:37:46 --> Config Class Initialized
INFO - 2020-10-17 05:37:46 --> Loader Class Initialized
INFO - 2020-10-17 05:37:46 --> Helper loaded: url_helper
INFO - 2020-10-17 05:37:46 --> Helper loaded: file_helper
INFO - 2020-10-17 05:37:46 --> Helper loaded: form_helper
INFO - 2020-10-17 05:37:47 --> Helper loaded: my_helper
INFO - 2020-10-17 05:37:47 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:37:47 --> Controller Class Initialized
DEBUG - 2020-10-17 05:37:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-17 05:37:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:37:47 --> Final output sent to browser
DEBUG - 2020-10-17 05:37:47 --> Total execution time: 1.0608
INFO - 2020-10-17 05:37:47 --> Config Class Initialized
INFO - 2020-10-17 05:37:47 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:37:47 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:37:47 --> Utf8 Class Initialized
INFO - 2020-10-17 05:37:47 --> URI Class Initialized
INFO - 2020-10-17 05:37:47 --> Router Class Initialized
INFO - 2020-10-17 05:37:47 --> Output Class Initialized
INFO - 2020-10-17 05:37:47 --> Security Class Initialized
DEBUG - 2020-10-17 05:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:37:47 --> Input Class Initialized
INFO - 2020-10-17 05:37:47 --> Language Class Initialized
INFO - 2020-10-17 05:37:47 --> Language Class Initialized
INFO - 2020-10-17 05:37:47 --> Config Class Initialized
INFO - 2020-10-17 05:37:47 --> Loader Class Initialized
INFO - 2020-10-17 05:37:48 --> Helper loaded: url_helper
INFO - 2020-10-17 05:37:48 --> Helper loaded: file_helper
INFO - 2020-10-17 05:37:48 --> Helper loaded: form_helper
INFO - 2020-10-17 05:37:48 --> Helper loaded: my_helper
INFO - 2020-10-17 05:37:48 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:37:48 --> Controller Class Initialized
INFO - 2020-10-17 05:38:01 --> Config Class Initialized
INFO - 2020-10-17 05:38:01 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:01 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:01 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:01 --> URI Class Initialized
INFO - 2020-10-17 05:38:01 --> Router Class Initialized
INFO - 2020-10-17 05:38:01 --> Output Class Initialized
INFO - 2020-10-17 05:38:01 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:01 --> Input Class Initialized
INFO - 2020-10-17 05:38:01 --> Language Class Initialized
INFO - 2020-10-17 05:38:01 --> Language Class Initialized
INFO - 2020-10-17 05:38:01 --> Config Class Initialized
INFO - 2020-10-17 05:38:01 --> Loader Class Initialized
INFO - 2020-10-17 05:38:02 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:02 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:02 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:02 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:02 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:02 --> Controller Class Initialized
DEBUG - 2020-10-17 05:38:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:38:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:38:02 --> Final output sent to browser
DEBUG - 2020-10-17 05:38:02 --> Total execution time: 1.0602
INFO - 2020-10-17 05:38:02 --> Config Class Initialized
INFO - 2020-10-17 05:38:02 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:02 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:02 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:02 --> URI Class Initialized
INFO - 2020-10-17 05:38:02 --> Router Class Initialized
INFO - 2020-10-17 05:38:03 --> Output Class Initialized
INFO - 2020-10-17 05:38:03 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:03 --> Input Class Initialized
INFO - 2020-10-17 05:38:03 --> Language Class Initialized
INFO - 2020-10-17 05:38:03 --> Language Class Initialized
INFO - 2020-10-17 05:38:03 --> Config Class Initialized
INFO - 2020-10-17 05:38:03 --> Loader Class Initialized
INFO - 2020-10-17 05:38:03 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:03 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:03 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:03 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:03 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:03 --> Controller Class Initialized
INFO - 2020-10-17 05:38:07 --> Config Class Initialized
INFO - 2020-10-17 05:38:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:07 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:07 --> URI Class Initialized
INFO - 2020-10-17 05:38:07 --> Router Class Initialized
INFO - 2020-10-17 05:38:07 --> Output Class Initialized
INFO - 2020-10-17 05:38:07 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:07 --> Input Class Initialized
INFO - 2020-10-17 05:38:07 --> Language Class Initialized
INFO - 2020-10-17 05:38:07 --> Language Class Initialized
INFO - 2020-10-17 05:38:07 --> Config Class Initialized
INFO - 2020-10-17 05:38:07 --> Loader Class Initialized
INFO - 2020-10-17 05:38:07 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:07 --> Controller Class Initialized
ERROR - 2020-10-17 05:38:08 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '8'
INFO - 2020-10-17 05:38:08 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:38:17 --> Config Class Initialized
INFO - 2020-10-17 05:38:17 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:17 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:17 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:17 --> URI Class Initialized
INFO - 2020-10-17 05:38:17 --> Router Class Initialized
INFO - 2020-10-17 05:38:17 --> Output Class Initialized
INFO - 2020-10-17 05:38:17 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:17 --> Input Class Initialized
INFO - 2020-10-17 05:38:17 --> Language Class Initialized
INFO - 2020-10-17 05:38:17 --> Language Class Initialized
INFO - 2020-10-17 05:38:17 --> Config Class Initialized
INFO - 2020-10-17 05:38:17 --> Loader Class Initialized
INFO - 2020-10-17 05:38:17 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:17 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:17 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:17 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:18 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:18 --> Controller Class Initialized
DEBUG - 2020-10-17 05:38:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:38:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:38:18 --> Final output sent to browser
DEBUG - 2020-10-17 05:38:18 --> Total execution time: 1.1290
INFO - 2020-10-17 05:38:18 --> Config Class Initialized
INFO - 2020-10-17 05:38:18 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:18 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:18 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:18 --> URI Class Initialized
INFO - 2020-10-17 05:38:18 --> Router Class Initialized
INFO - 2020-10-17 05:38:18 --> Output Class Initialized
INFO - 2020-10-17 05:38:18 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:18 --> Input Class Initialized
INFO - 2020-10-17 05:38:18 --> Language Class Initialized
INFO - 2020-10-17 05:38:18 --> Language Class Initialized
INFO - 2020-10-17 05:38:18 --> Config Class Initialized
INFO - 2020-10-17 05:38:18 --> Loader Class Initialized
INFO - 2020-10-17 05:38:19 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:19 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:19 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:19 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:19 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:19 --> Controller Class Initialized
INFO - 2020-10-17 05:38:21 --> Config Class Initialized
INFO - 2020-10-17 05:38:21 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:21 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:21 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:21 --> URI Class Initialized
INFO - 2020-10-17 05:38:21 --> Router Class Initialized
INFO - 2020-10-17 05:38:21 --> Output Class Initialized
INFO - 2020-10-17 05:38:21 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:22 --> Input Class Initialized
INFO - 2020-10-17 05:38:22 --> Language Class Initialized
INFO - 2020-10-17 05:38:22 --> Language Class Initialized
INFO - 2020-10-17 05:38:22 --> Config Class Initialized
INFO - 2020-10-17 05:38:22 --> Loader Class Initialized
INFO - 2020-10-17 05:38:22 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:22 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:22 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:22 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:22 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:22 --> Controller Class Initialized
ERROR - 2020-10-17 05:38:22 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '10'
INFO - 2020-10-17 05:38:22 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:38:34 --> Config Class Initialized
INFO - 2020-10-17 05:38:34 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:34 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:34 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:35 --> URI Class Initialized
INFO - 2020-10-17 05:38:35 --> Router Class Initialized
INFO - 2020-10-17 05:38:35 --> Output Class Initialized
INFO - 2020-10-17 05:38:35 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:35 --> Input Class Initialized
INFO - 2020-10-17 05:38:35 --> Language Class Initialized
INFO - 2020-10-17 05:38:35 --> Language Class Initialized
INFO - 2020-10-17 05:38:35 --> Config Class Initialized
INFO - 2020-10-17 05:38:35 --> Loader Class Initialized
INFO - 2020-10-17 05:38:35 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:35 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:35 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:35 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:35 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:35 --> Controller Class Initialized
DEBUG - 2020-10-17 05:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:38:36 --> Final output sent to browser
DEBUG - 2020-10-17 05:38:36 --> Total execution time: 1.0920
INFO - 2020-10-17 05:38:36 --> Config Class Initialized
INFO - 2020-10-17 05:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:36 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:36 --> URI Class Initialized
INFO - 2020-10-17 05:38:36 --> Router Class Initialized
INFO - 2020-10-17 05:38:36 --> Output Class Initialized
INFO - 2020-10-17 05:38:36 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:36 --> Input Class Initialized
INFO - 2020-10-17 05:38:36 --> Language Class Initialized
INFO - 2020-10-17 05:38:36 --> Language Class Initialized
INFO - 2020-10-17 05:38:36 --> Config Class Initialized
INFO - 2020-10-17 05:38:36 --> Loader Class Initialized
INFO - 2020-10-17 05:38:36 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:36 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:36 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:36 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:36 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:36 --> Controller Class Initialized
INFO - 2020-10-17 05:38:39 --> Config Class Initialized
INFO - 2020-10-17 05:38:39 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:39 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:39 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:39 --> URI Class Initialized
INFO - 2020-10-17 05:38:39 --> Router Class Initialized
INFO - 2020-10-17 05:38:39 --> Output Class Initialized
INFO - 2020-10-17 05:38:39 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:39 --> Input Class Initialized
INFO - 2020-10-17 05:38:39 --> Language Class Initialized
INFO - 2020-10-17 05:38:39 --> Language Class Initialized
INFO - 2020-10-17 05:38:39 --> Config Class Initialized
INFO - 2020-10-17 05:38:39 --> Loader Class Initialized
INFO - 2020-10-17 05:38:39 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:39 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:39 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:39 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:39 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:39 --> Controller Class Initialized
ERROR - 2020-10-17 05:38:40 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '10'
INFO - 2020-10-17 05:38:40 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:38:42 --> Config Class Initialized
INFO - 2020-10-17 05:38:42 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:42 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:42 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:42 --> URI Class Initialized
INFO - 2020-10-17 05:38:42 --> Router Class Initialized
INFO - 2020-10-17 05:38:42 --> Output Class Initialized
INFO - 2020-10-17 05:38:42 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:42 --> Input Class Initialized
INFO - 2020-10-17 05:38:42 --> Language Class Initialized
INFO - 2020-10-17 05:38:42 --> Language Class Initialized
INFO - 2020-10-17 05:38:42 --> Config Class Initialized
INFO - 2020-10-17 05:38:42 --> Loader Class Initialized
INFO - 2020-10-17 05:38:42 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:42 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:42 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:42 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:42 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:42 --> Controller Class Initialized
ERROR - 2020-10-17 05:38:42 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '11'
INFO - 2020-10-17 05:38:42 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:38:44 --> Config Class Initialized
INFO - 2020-10-17 05:38:44 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:44 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:44 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:44 --> URI Class Initialized
INFO - 2020-10-17 05:38:44 --> Router Class Initialized
INFO - 2020-10-17 05:38:44 --> Output Class Initialized
INFO - 2020-10-17 05:38:44 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:44 --> Input Class Initialized
INFO - 2020-10-17 05:38:44 --> Language Class Initialized
INFO - 2020-10-17 05:38:44 --> Language Class Initialized
INFO - 2020-10-17 05:38:44 --> Config Class Initialized
INFO - 2020-10-17 05:38:44 --> Loader Class Initialized
INFO - 2020-10-17 05:38:44 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:44 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:44 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:44 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:45 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:45 --> Controller Class Initialized
INFO - 2020-10-17 05:38:47 --> Config Class Initialized
INFO - 2020-10-17 05:38:47 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:47 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:47 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:47 --> URI Class Initialized
INFO - 2020-10-17 05:38:47 --> Router Class Initialized
INFO - 2020-10-17 05:38:47 --> Output Class Initialized
INFO - 2020-10-17 05:38:47 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:47 --> Input Class Initialized
INFO - 2020-10-17 05:38:47 --> Language Class Initialized
INFO - 2020-10-17 05:38:47 --> Language Class Initialized
INFO - 2020-10-17 05:38:47 --> Config Class Initialized
INFO - 2020-10-17 05:38:47 --> Loader Class Initialized
INFO - 2020-10-17 05:38:47 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:47 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:47 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:47 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:47 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:48 --> Controller Class Initialized
INFO - 2020-10-17 05:38:48 --> Final output sent to browser
DEBUG - 2020-10-17 05:38:48 --> Total execution time: 0.8210
INFO - 2020-10-17 05:38:48 --> Config Class Initialized
INFO - 2020-10-17 05:38:48 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:48 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:48 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:48 --> URI Class Initialized
INFO - 2020-10-17 05:38:48 --> Router Class Initialized
INFO - 2020-10-17 05:38:48 --> Output Class Initialized
INFO - 2020-10-17 05:38:48 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:48 --> Input Class Initialized
INFO - 2020-10-17 05:38:48 --> Language Class Initialized
INFO - 2020-10-17 05:38:48 --> Language Class Initialized
INFO - 2020-10-17 05:38:49 --> Config Class Initialized
INFO - 2020-10-17 05:38:49 --> Loader Class Initialized
INFO - 2020-10-17 05:38:49 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:49 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:49 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:49 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:49 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:49 --> Controller Class Initialized
INFO - 2020-10-17 05:38:52 --> Config Class Initialized
INFO - 2020-10-17 05:38:52 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:52 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:52 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:52 --> URI Class Initialized
INFO - 2020-10-17 05:38:52 --> Router Class Initialized
INFO - 2020-10-17 05:38:52 --> Output Class Initialized
INFO - 2020-10-17 05:38:52 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:52 --> Input Class Initialized
INFO - 2020-10-17 05:38:52 --> Language Class Initialized
INFO - 2020-10-17 05:38:52 --> Language Class Initialized
INFO - 2020-10-17 05:38:52 --> Config Class Initialized
INFO - 2020-10-17 05:38:52 --> Loader Class Initialized
INFO - 2020-10-17 05:38:52 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:53 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:53 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:53 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:53 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:53 --> Controller Class Initialized
ERROR - 2020-10-17 05:38:53 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '11'
INFO - 2020-10-17 05:38:53 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:38:57 --> Config Class Initialized
INFO - 2020-10-17 05:38:57 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:57 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:57 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:57 --> URI Class Initialized
INFO - 2020-10-17 05:38:57 --> Router Class Initialized
INFO - 2020-10-17 05:38:57 --> Output Class Initialized
INFO - 2020-10-17 05:38:57 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:57 --> Input Class Initialized
INFO - 2020-10-17 05:38:57 --> Language Class Initialized
INFO - 2020-10-17 05:38:57 --> Language Class Initialized
INFO - 2020-10-17 05:38:57 --> Config Class Initialized
INFO - 2020-10-17 05:38:57 --> Loader Class Initialized
INFO - 2020-10-17 05:38:57 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:57 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:57 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:57 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:57 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:58 --> Controller Class Initialized
INFO - 2020-10-17 05:38:58 --> Final output sent to browser
DEBUG - 2020-10-17 05:38:58 --> Total execution time: 0.8725
INFO - 2020-10-17 05:38:58 --> Config Class Initialized
INFO - 2020-10-17 05:38:58 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:38:58 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:38:58 --> Utf8 Class Initialized
INFO - 2020-10-17 05:38:58 --> URI Class Initialized
INFO - 2020-10-17 05:38:58 --> Router Class Initialized
INFO - 2020-10-17 05:38:58 --> Output Class Initialized
INFO - 2020-10-17 05:38:58 --> Security Class Initialized
DEBUG - 2020-10-17 05:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:38:58 --> Input Class Initialized
INFO - 2020-10-17 05:38:58 --> Language Class Initialized
INFO - 2020-10-17 05:38:58 --> Language Class Initialized
INFO - 2020-10-17 05:38:58 --> Config Class Initialized
INFO - 2020-10-17 05:38:58 --> Loader Class Initialized
INFO - 2020-10-17 05:38:58 --> Helper loaded: url_helper
INFO - 2020-10-17 05:38:58 --> Helper loaded: file_helper
INFO - 2020-10-17 05:38:58 --> Helper loaded: form_helper
INFO - 2020-10-17 05:38:58 --> Helper loaded: my_helper
INFO - 2020-10-17 05:38:59 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:38:59 --> Controller Class Initialized
INFO - 2020-10-17 05:39:01 --> Config Class Initialized
INFO - 2020-10-17 05:39:01 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:01 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:01 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:01 --> URI Class Initialized
INFO - 2020-10-17 05:39:01 --> Router Class Initialized
INFO - 2020-10-17 05:39:01 --> Output Class Initialized
INFO - 2020-10-17 05:39:01 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:01 --> Input Class Initialized
INFO - 2020-10-17 05:39:01 --> Language Class Initialized
INFO - 2020-10-17 05:39:01 --> Language Class Initialized
INFO - 2020-10-17 05:39:01 --> Config Class Initialized
INFO - 2020-10-17 05:39:01 --> Loader Class Initialized
INFO - 2020-10-17 05:39:02 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:02 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:02 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:02 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:02 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:02 --> Controller Class Initialized
INFO - 2020-10-17 05:39:02 --> Final output sent to browser
DEBUG - 2020-10-17 05:39:02 --> Total execution time: 0.6837
INFO - 2020-10-17 05:39:02 --> Config Class Initialized
INFO - 2020-10-17 05:39:02 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:02 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:02 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:02 --> URI Class Initialized
INFO - 2020-10-17 05:39:02 --> Router Class Initialized
INFO - 2020-10-17 05:39:02 --> Output Class Initialized
INFO - 2020-10-17 05:39:02 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:02 --> Input Class Initialized
INFO - 2020-10-17 05:39:02 --> Language Class Initialized
INFO - 2020-10-17 05:39:02 --> Language Class Initialized
INFO - 2020-10-17 05:39:02 --> Config Class Initialized
INFO - 2020-10-17 05:39:02 --> Loader Class Initialized
INFO - 2020-10-17 05:39:02 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:03 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:03 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:03 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:03 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:03 --> Controller Class Initialized
INFO - 2020-10-17 05:39:05 --> Config Class Initialized
INFO - 2020-10-17 05:39:05 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:05 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:05 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:05 --> URI Class Initialized
INFO - 2020-10-17 05:39:05 --> Router Class Initialized
INFO - 2020-10-17 05:39:05 --> Output Class Initialized
INFO - 2020-10-17 05:39:05 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:06 --> Input Class Initialized
INFO - 2020-10-17 05:39:06 --> Language Class Initialized
INFO - 2020-10-17 05:39:06 --> Language Class Initialized
INFO - 2020-10-17 05:39:06 --> Config Class Initialized
INFO - 2020-10-17 05:39:06 --> Loader Class Initialized
INFO - 2020-10-17 05:39:06 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:06 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:06 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:06 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:06 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:06 --> Controller Class Initialized
ERROR - 2020-10-17 05:39:06 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '6'
INFO - 2020-10-17 05:39:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:39:09 --> Config Class Initialized
INFO - 2020-10-17 05:39:09 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:09 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:09 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:09 --> URI Class Initialized
INFO - 2020-10-17 05:39:09 --> Router Class Initialized
INFO - 2020-10-17 05:39:09 --> Output Class Initialized
INFO - 2020-10-17 05:39:09 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:09 --> Input Class Initialized
INFO - 2020-10-17 05:39:09 --> Language Class Initialized
INFO - 2020-10-17 05:39:09 --> Language Class Initialized
INFO - 2020-10-17 05:39:09 --> Config Class Initialized
INFO - 2020-10-17 05:39:09 --> Loader Class Initialized
INFO - 2020-10-17 05:39:09 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:09 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:09 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:09 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:09 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:09 --> Controller Class Initialized
ERROR - 2020-10-17 05:39:09 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '11'
INFO - 2020-10-17 05:39:10 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:39:11 --> Config Class Initialized
INFO - 2020-10-17 05:39:11 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:11 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:11 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:11 --> URI Class Initialized
INFO - 2020-10-17 05:39:11 --> Router Class Initialized
INFO - 2020-10-17 05:39:11 --> Output Class Initialized
INFO - 2020-10-17 05:39:11 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:11 --> Input Class Initialized
INFO - 2020-10-17 05:39:11 --> Language Class Initialized
INFO - 2020-10-17 05:39:11 --> Language Class Initialized
INFO - 2020-10-17 05:39:11 --> Config Class Initialized
INFO - 2020-10-17 05:39:11 --> Loader Class Initialized
INFO - 2020-10-17 05:39:11 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:11 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:11 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:11 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:11 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:12 --> Controller Class Initialized
ERROR - 2020-10-17 05:39:12 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '10'
INFO - 2020-10-17 05:39:12 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:39:13 --> Config Class Initialized
INFO - 2020-10-17 05:39:13 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:13 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:13 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:13 --> URI Class Initialized
INFO - 2020-10-17 05:39:13 --> Router Class Initialized
INFO - 2020-10-17 05:39:13 --> Output Class Initialized
INFO - 2020-10-17 05:39:13 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:13 --> Input Class Initialized
INFO - 2020-10-17 05:39:13 --> Language Class Initialized
INFO - 2020-10-17 05:39:13 --> Language Class Initialized
INFO - 2020-10-17 05:39:13 --> Config Class Initialized
INFO - 2020-10-17 05:39:13 --> Loader Class Initialized
INFO - 2020-10-17 05:39:13 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:13 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:13 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:13 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:13 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:13 --> Controller Class Initialized
ERROR - 2020-10-17 05:39:13 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '9'
INFO - 2020-10-17 05:39:13 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:39:15 --> Config Class Initialized
INFO - 2020-10-17 05:39:15 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:15 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:15 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:15 --> URI Class Initialized
INFO - 2020-10-17 05:39:15 --> Router Class Initialized
INFO - 2020-10-17 05:39:15 --> Output Class Initialized
INFO - 2020-10-17 05:39:15 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:15 --> Input Class Initialized
INFO - 2020-10-17 05:39:15 --> Language Class Initialized
INFO - 2020-10-17 05:39:15 --> Language Class Initialized
INFO - 2020-10-17 05:39:15 --> Config Class Initialized
INFO - 2020-10-17 05:39:15 --> Loader Class Initialized
INFO - 2020-10-17 05:39:15 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:15 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:15 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:15 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:15 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:15 --> Controller Class Initialized
ERROR - 2020-10-17 05:39:15 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '8'
INFO - 2020-10-17 05:39:15 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:39:17 --> Config Class Initialized
INFO - 2020-10-17 05:39:17 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:17 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:17 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:17 --> URI Class Initialized
INFO - 2020-10-17 05:39:17 --> Router Class Initialized
INFO - 2020-10-17 05:39:17 --> Output Class Initialized
INFO - 2020-10-17 05:39:17 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:17 --> Input Class Initialized
INFO - 2020-10-17 05:39:17 --> Language Class Initialized
INFO - 2020-10-17 05:39:17 --> Language Class Initialized
INFO - 2020-10-17 05:39:17 --> Config Class Initialized
INFO - 2020-10-17 05:39:18 --> Loader Class Initialized
INFO - 2020-10-17 05:39:18 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:18 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:18 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:18 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:18 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:18 --> Controller Class Initialized
INFO - 2020-10-17 05:39:18 --> Final output sent to browser
DEBUG - 2020-10-17 05:39:18 --> Total execution time: 1.0542
INFO - 2020-10-17 05:39:18 --> Config Class Initialized
INFO - 2020-10-17 05:39:18 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:18 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:18 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:18 --> URI Class Initialized
INFO - 2020-10-17 05:39:19 --> Router Class Initialized
INFO - 2020-10-17 05:39:19 --> Output Class Initialized
INFO - 2020-10-17 05:39:19 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:19 --> Input Class Initialized
INFO - 2020-10-17 05:39:19 --> Language Class Initialized
INFO - 2020-10-17 05:39:19 --> Language Class Initialized
INFO - 2020-10-17 05:39:19 --> Config Class Initialized
INFO - 2020-10-17 05:39:19 --> Loader Class Initialized
INFO - 2020-10-17 05:39:19 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:19 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:19 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:19 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:19 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:19 --> Controller Class Initialized
INFO - 2020-10-17 05:39:23 --> Config Class Initialized
INFO - 2020-10-17 05:39:23 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:23 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:23 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:23 --> URI Class Initialized
INFO - 2020-10-17 05:39:23 --> Router Class Initialized
INFO - 2020-10-17 05:39:23 --> Output Class Initialized
INFO - 2020-10-17 05:39:23 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:23 --> Input Class Initialized
INFO - 2020-10-17 05:39:23 --> Language Class Initialized
INFO - 2020-10-17 05:39:23 --> Language Class Initialized
INFO - 2020-10-17 05:39:23 --> Config Class Initialized
INFO - 2020-10-17 05:39:23 --> Loader Class Initialized
INFO - 2020-10-17 05:39:23 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:23 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:23 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:24 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:24 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:24 --> Controller Class Initialized
ERROR - 2020-10-17 05:39:24 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '6'
INFO - 2020-10-17 05:39:24 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:39:25 --> Config Class Initialized
INFO - 2020-10-17 05:39:25 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:25 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:25 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:25 --> URI Class Initialized
INFO - 2020-10-17 05:39:25 --> Router Class Initialized
INFO - 2020-10-17 05:39:25 --> Output Class Initialized
INFO - 2020-10-17 05:39:25 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:26 --> Input Class Initialized
INFO - 2020-10-17 05:39:26 --> Language Class Initialized
INFO - 2020-10-17 05:39:26 --> Language Class Initialized
INFO - 2020-10-17 05:39:26 --> Config Class Initialized
INFO - 2020-10-17 05:39:26 --> Loader Class Initialized
INFO - 2020-10-17 05:39:26 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:26 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:26 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:26 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:26 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:26 --> Controller Class Initialized
INFO - 2020-10-17 05:39:26 --> Final output sent to browser
DEBUG - 2020-10-17 05:39:26 --> Total execution time: 0.7767
INFO - 2020-10-17 05:39:26 --> Config Class Initialized
INFO - 2020-10-17 05:39:26 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:26 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:26 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:26 --> URI Class Initialized
INFO - 2020-10-17 05:39:27 --> Router Class Initialized
INFO - 2020-10-17 05:39:27 --> Output Class Initialized
INFO - 2020-10-17 05:39:27 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:27 --> Input Class Initialized
INFO - 2020-10-17 05:39:27 --> Language Class Initialized
INFO - 2020-10-17 05:39:27 --> Language Class Initialized
INFO - 2020-10-17 05:39:27 --> Config Class Initialized
INFO - 2020-10-17 05:39:27 --> Loader Class Initialized
INFO - 2020-10-17 05:39:27 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:27 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:27 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:27 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:27 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:27 --> Controller Class Initialized
INFO - 2020-10-17 05:39:29 --> Config Class Initialized
INFO - 2020-10-17 05:39:29 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:29 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:29 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:29 --> URI Class Initialized
INFO - 2020-10-17 05:39:29 --> Router Class Initialized
INFO - 2020-10-17 05:39:29 --> Output Class Initialized
INFO - 2020-10-17 05:39:29 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:29 --> Input Class Initialized
INFO - 2020-10-17 05:39:29 --> Language Class Initialized
INFO - 2020-10-17 05:39:29 --> Language Class Initialized
INFO - 2020-10-17 05:39:29 --> Config Class Initialized
INFO - 2020-10-17 05:39:29 --> Loader Class Initialized
INFO - 2020-10-17 05:39:29 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:29 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:29 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:29 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:29 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:30 --> Controller Class Initialized
INFO - 2020-10-17 05:39:30 --> Final output sent to browser
DEBUG - 2020-10-17 05:39:30 --> Total execution time: 0.9971
INFO - 2020-10-17 05:39:30 --> Config Class Initialized
INFO - 2020-10-17 05:39:30 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:30 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:30 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:30 --> URI Class Initialized
INFO - 2020-10-17 05:39:30 --> Router Class Initialized
INFO - 2020-10-17 05:39:30 --> Output Class Initialized
INFO - 2020-10-17 05:39:30 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:30 --> Input Class Initialized
INFO - 2020-10-17 05:39:30 --> Language Class Initialized
INFO - 2020-10-17 05:39:30 --> Language Class Initialized
INFO - 2020-10-17 05:39:30 --> Config Class Initialized
INFO - 2020-10-17 05:39:30 --> Loader Class Initialized
INFO - 2020-10-17 05:39:30 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:30 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:30 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:30 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:30 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:31 --> Controller Class Initialized
INFO - 2020-10-17 05:39:33 --> Config Class Initialized
INFO - 2020-10-17 05:39:33 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:39:33 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:39:33 --> Utf8 Class Initialized
INFO - 2020-10-17 05:39:33 --> URI Class Initialized
INFO - 2020-10-17 05:39:33 --> Router Class Initialized
INFO - 2020-10-17 05:39:33 --> Output Class Initialized
INFO - 2020-10-17 05:39:33 --> Security Class Initialized
DEBUG - 2020-10-17 05:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:39:33 --> Input Class Initialized
INFO - 2020-10-17 05:39:33 --> Language Class Initialized
INFO - 2020-10-17 05:39:33 --> Language Class Initialized
INFO - 2020-10-17 05:39:33 --> Config Class Initialized
INFO - 2020-10-17 05:39:33 --> Loader Class Initialized
INFO - 2020-10-17 05:39:33 --> Helper loaded: url_helper
INFO - 2020-10-17 05:39:33 --> Helper loaded: file_helper
INFO - 2020-10-17 05:39:34 --> Helper loaded: form_helper
INFO - 2020-10-17 05:39:34 --> Helper loaded: my_helper
INFO - 2020-10-17 05:39:34 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:39:34 --> Controller Class Initialized
ERROR - 2020-10-17 05:39:34 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '6'
INFO - 2020-10-17 05:39:34 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:41:03 --> Config Class Initialized
INFO - 2020-10-17 05:41:03 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:03 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:03 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:03 --> URI Class Initialized
INFO - 2020-10-17 05:41:03 --> Router Class Initialized
INFO - 2020-10-17 05:41:03 --> Output Class Initialized
INFO - 2020-10-17 05:41:03 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:03 --> Input Class Initialized
INFO - 2020-10-17 05:41:04 --> Language Class Initialized
INFO - 2020-10-17 05:41:04 --> Language Class Initialized
INFO - 2020-10-17 05:41:04 --> Config Class Initialized
INFO - 2020-10-17 05:41:04 --> Loader Class Initialized
INFO - 2020-10-17 05:41:04 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:04 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:04 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:04 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:04 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:04 --> Controller Class Initialized
DEBUG - 2020-10-17 05:41:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-17 05:41:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:41:04 --> Final output sent to browser
DEBUG - 2020-10-17 05:41:04 --> Total execution time: 1.1579
INFO - 2020-10-17 05:41:05 --> Config Class Initialized
INFO - 2020-10-17 05:41:05 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:05 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:05 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:05 --> URI Class Initialized
INFO - 2020-10-17 05:41:05 --> Router Class Initialized
INFO - 2020-10-17 05:41:05 --> Output Class Initialized
INFO - 2020-10-17 05:41:05 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:05 --> Input Class Initialized
INFO - 2020-10-17 05:41:05 --> Language Class Initialized
INFO - 2020-10-17 05:41:05 --> Language Class Initialized
INFO - 2020-10-17 05:41:05 --> Config Class Initialized
INFO - 2020-10-17 05:41:05 --> Loader Class Initialized
INFO - 2020-10-17 05:41:05 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:05 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:05 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:05 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:05 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:05 --> Controller Class Initialized
INFO - 2020-10-17 05:41:10 --> Config Class Initialized
INFO - 2020-10-17 05:41:10 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:10 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:10 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:10 --> URI Class Initialized
INFO - 2020-10-17 05:41:10 --> Router Class Initialized
INFO - 2020-10-17 05:41:10 --> Output Class Initialized
INFO - 2020-10-17 05:41:10 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:10 --> Input Class Initialized
INFO - 2020-10-17 05:41:10 --> Language Class Initialized
INFO - 2020-10-17 05:41:10 --> Language Class Initialized
INFO - 2020-10-17 05:41:11 --> Config Class Initialized
INFO - 2020-10-17 05:41:11 --> Loader Class Initialized
INFO - 2020-10-17 05:41:11 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:11 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:11 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:11 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:11 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:11 --> Controller Class Initialized
DEBUG - 2020-10-17 05:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-17 05:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:41:11 --> Final output sent to browser
DEBUG - 2020-10-17 05:41:11 --> Total execution time: 0.7719
INFO - 2020-10-17 05:41:11 --> Config Class Initialized
INFO - 2020-10-17 05:41:11 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:11 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:11 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:11 --> URI Class Initialized
INFO - 2020-10-17 05:41:11 --> Router Class Initialized
INFO - 2020-10-17 05:41:11 --> Output Class Initialized
INFO - 2020-10-17 05:41:11 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:11 --> Input Class Initialized
INFO - 2020-10-17 05:41:12 --> Language Class Initialized
INFO - 2020-10-17 05:41:12 --> Language Class Initialized
INFO - 2020-10-17 05:41:12 --> Config Class Initialized
INFO - 2020-10-17 05:41:12 --> Loader Class Initialized
INFO - 2020-10-17 05:41:12 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:12 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:12 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:12 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:12 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:12 --> Controller Class Initialized
INFO - 2020-10-17 05:41:31 --> Config Class Initialized
INFO - 2020-10-17 05:41:31 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:31 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:31 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:31 --> URI Class Initialized
INFO - 2020-10-17 05:41:31 --> Router Class Initialized
INFO - 2020-10-17 05:41:31 --> Output Class Initialized
INFO - 2020-10-17 05:41:31 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:32 --> Input Class Initialized
INFO - 2020-10-17 05:41:32 --> Language Class Initialized
INFO - 2020-10-17 05:41:32 --> Language Class Initialized
INFO - 2020-10-17 05:41:32 --> Config Class Initialized
INFO - 2020-10-17 05:41:32 --> Loader Class Initialized
INFO - 2020-10-17 05:41:32 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:32 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:32 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:32 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:32 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:32 --> Controller Class Initialized
DEBUG - 2020-10-17 05:41:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-17 05:41:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:41:32 --> Final output sent to browser
DEBUG - 2020-10-17 05:41:32 --> Total execution time: 1.0533
INFO - 2020-10-17 05:41:33 --> Config Class Initialized
INFO - 2020-10-17 05:41:33 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:33 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:33 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:33 --> URI Class Initialized
INFO - 2020-10-17 05:41:33 --> Router Class Initialized
INFO - 2020-10-17 05:41:33 --> Output Class Initialized
INFO - 2020-10-17 05:41:33 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:33 --> Input Class Initialized
INFO - 2020-10-17 05:41:33 --> Language Class Initialized
INFO - 2020-10-17 05:41:33 --> Language Class Initialized
INFO - 2020-10-17 05:41:33 --> Config Class Initialized
INFO - 2020-10-17 05:41:33 --> Loader Class Initialized
INFO - 2020-10-17 05:41:33 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:33 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:33 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:33 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:33 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:33 --> Controller Class Initialized
INFO - 2020-10-17 05:41:40 --> Config Class Initialized
INFO - 2020-10-17 05:41:40 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:40 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:40 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:40 --> URI Class Initialized
INFO - 2020-10-17 05:41:40 --> Router Class Initialized
INFO - 2020-10-17 05:41:40 --> Output Class Initialized
INFO - 2020-10-17 05:41:40 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:41 --> Input Class Initialized
INFO - 2020-10-17 05:41:41 --> Language Class Initialized
INFO - 2020-10-17 05:41:41 --> Language Class Initialized
INFO - 2020-10-17 05:41:41 --> Config Class Initialized
INFO - 2020-10-17 05:41:41 --> Loader Class Initialized
INFO - 2020-10-17 05:41:41 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:41 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:41 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:41 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:41 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:41 --> Controller Class Initialized
DEBUG - 2020-10-17 05:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-17 05:41:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:41:41 --> Final output sent to browser
DEBUG - 2020-10-17 05:41:41 --> Total execution time: 1.1342
INFO - 2020-10-17 05:41:42 --> Config Class Initialized
INFO - 2020-10-17 05:41:42 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:42 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:42 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:42 --> URI Class Initialized
INFO - 2020-10-17 05:41:42 --> Router Class Initialized
INFO - 2020-10-17 05:41:42 --> Output Class Initialized
INFO - 2020-10-17 05:41:42 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:42 --> Input Class Initialized
INFO - 2020-10-17 05:41:42 --> Language Class Initialized
INFO - 2020-10-17 05:41:42 --> Language Class Initialized
INFO - 2020-10-17 05:41:42 --> Config Class Initialized
INFO - 2020-10-17 05:41:42 --> Loader Class Initialized
INFO - 2020-10-17 05:41:42 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:42 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:42 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:42 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:42 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:43 --> Controller Class Initialized
INFO - 2020-10-17 05:41:49 --> Config Class Initialized
INFO - 2020-10-17 05:41:49 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:49 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:49 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:49 --> URI Class Initialized
INFO - 2020-10-17 05:41:49 --> Router Class Initialized
INFO - 2020-10-17 05:41:49 --> Output Class Initialized
INFO - 2020-10-17 05:41:49 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:49 --> Input Class Initialized
INFO - 2020-10-17 05:41:49 --> Language Class Initialized
INFO - 2020-10-17 05:41:49 --> Language Class Initialized
INFO - 2020-10-17 05:41:50 --> Config Class Initialized
INFO - 2020-10-17 05:41:50 --> Loader Class Initialized
INFO - 2020-10-17 05:41:50 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:50 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:50 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:50 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:50 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:50 --> Controller Class Initialized
ERROR - 2020-10-17 05:41:50 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-10-17 05:41:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-17 05:41:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:41:50 --> Final output sent to browser
DEBUG - 2020-10-17 05:41:50 --> Total execution time: 1.2608
INFO - 2020-10-17 05:41:53 --> Config Class Initialized
INFO - 2020-10-17 05:41:53 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:53 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:53 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:53 --> URI Class Initialized
INFO - 2020-10-17 05:41:53 --> Router Class Initialized
INFO - 2020-10-17 05:41:53 --> Output Class Initialized
INFO - 2020-10-17 05:41:53 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:53 --> Input Class Initialized
INFO - 2020-10-17 05:41:53 --> Language Class Initialized
INFO - 2020-10-17 05:41:53 --> Language Class Initialized
INFO - 2020-10-17 05:41:53 --> Config Class Initialized
INFO - 2020-10-17 05:41:53 --> Loader Class Initialized
INFO - 2020-10-17 05:41:53 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:53 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:53 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:53 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:53 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:54 --> Controller Class Initialized
DEBUG - 2020-10-17 05:41:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-17 05:41:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:41:54 --> Final output sent to browser
DEBUG - 2020-10-17 05:41:54 --> Total execution time: 1.1543
INFO - 2020-10-17 05:41:54 --> Config Class Initialized
INFO - 2020-10-17 05:41:54 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:41:54 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:41:54 --> Utf8 Class Initialized
INFO - 2020-10-17 05:41:54 --> URI Class Initialized
INFO - 2020-10-17 05:41:54 --> Router Class Initialized
INFO - 2020-10-17 05:41:54 --> Output Class Initialized
INFO - 2020-10-17 05:41:54 --> Security Class Initialized
DEBUG - 2020-10-17 05:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:41:54 --> Input Class Initialized
INFO - 2020-10-17 05:41:54 --> Language Class Initialized
INFO - 2020-10-17 05:41:54 --> Language Class Initialized
INFO - 2020-10-17 05:41:54 --> Config Class Initialized
INFO - 2020-10-17 05:41:54 --> Loader Class Initialized
INFO - 2020-10-17 05:41:54 --> Helper loaded: url_helper
INFO - 2020-10-17 05:41:55 --> Helper loaded: file_helper
INFO - 2020-10-17 05:41:55 --> Helper loaded: form_helper
INFO - 2020-10-17 05:41:55 --> Helper loaded: my_helper
INFO - 2020-10-17 05:41:55 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:41:55 --> Controller Class Initialized
INFO - 2020-10-17 05:42:01 --> Config Class Initialized
INFO - 2020-10-17 05:42:01 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:42:02 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:42:02 --> Utf8 Class Initialized
INFO - 2020-10-17 05:42:02 --> URI Class Initialized
INFO - 2020-10-17 05:42:02 --> Router Class Initialized
INFO - 2020-10-17 05:42:02 --> Output Class Initialized
INFO - 2020-10-17 05:42:02 --> Security Class Initialized
DEBUG - 2020-10-17 05:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:42:02 --> Input Class Initialized
INFO - 2020-10-17 05:42:02 --> Language Class Initialized
INFO - 2020-10-17 05:42:02 --> Language Class Initialized
INFO - 2020-10-17 05:42:02 --> Config Class Initialized
INFO - 2020-10-17 05:42:02 --> Loader Class Initialized
INFO - 2020-10-17 05:42:02 --> Helper loaded: url_helper
INFO - 2020-10-17 05:42:02 --> Helper loaded: file_helper
INFO - 2020-10-17 05:42:02 --> Helper loaded: form_helper
INFO - 2020-10-17 05:42:02 --> Helper loaded: my_helper
INFO - 2020-10-17 05:42:02 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:42:02 --> Controller Class Initialized
INFO - 2020-10-17 05:42:03 --> Final output sent to browser
DEBUG - 2020-10-17 05:42:03 --> Total execution time: 1.0517
INFO - 2020-10-17 05:42:03 --> Config Class Initialized
INFO - 2020-10-17 05:42:03 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:42:03 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:42:03 --> Utf8 Class Initialized
INFO - 2020-10-17 05:42:03 --> URI Class Initialized
INFO - 2020-10-17 05:42:03 --> Router Class Initialized
INFO - 2020-10-17 05:42:03 --> Output Class Initialized
INFO - 2020-10-17 05:42:03 --> Security Class Initialized
DEBUG - 2020-10-17 05:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:42:03 --> Input Class Initialized
INFO - 2020-10-17 05:42:03 --> Language Class Initialized
INFO - 2020-10-17 05:42:03 --> Language Class Initialized
INFO - 2020-10-17 05:42:03 --> Config Class Initialized
INFO - 2020-10-17 05:42:03 --> Loader Class Initialized
INFO - 2020-10-17 05:42:03 --> Helper loaded: url_helper
INFO - 2020-10-17 05:42:03 --> Helper loaded: file_helper
INFO - 2020-10-17 05:42:03 --> Helper loaded: form_helper
INFO - 2020-10-17 05:42:03 --> Helper loaded: my_helper
INFO - 2020-10-17 05:42:04 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:42:04 --> Controller Class Initialized
INFO - 2020-10-17 05:42:06 --> Config Class Initialized
INFO - 2020-10-17 05:42:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:42:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:42:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:42:06 --> URI Class Initialized
INFO - 2020-10-17 05:42:06 --> Router Class Initialized
INFO - 2020-10-17 05:42:06 --> Output Class Initialized
INFO - 2020-10-17 05:42:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:42:06 --> Input Class Initialized
INFO - 2020-10-17 05:42:06 --> Language Class Initialized
INFO - 2020-10-17 05:42:06 --> Language Class Initialized
INFO - 2020-10-17 05:42:06 --> Config Class Initialized
INFO - 2020-10-17 05:42:06 --> Loader Class Initialized
INFO - 2020-10-17 05:42:06 --> Helper loaded: url_helper
INFO - 2020-10-17 05:42:06 --> Helper loaded: file_helper
INFO - 2020-10-17 05:42:06 --> Helper loaded: form_helper
INFO - 2020-10-17 05:42:06 --> Helper loaded: my_helper
INFO - 2020-10-17 05:42:06 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:42:07 --> Controller Class Initialized
INFO - 2020-10-17 05:42:07 --> Final output sent to browser
DEBUG - 2020-10-17 05:42:07 --> Total execution time: 1.0578
INFO - 2020-10-17 05:42:07 --> Config Class Initialized
INFO - 2020-10-17 05:42:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:42:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:42:07 --> Utf8 Class Initialized
INFO - 2020-10-17 05:42:07 --> URI Class Initialized
INFO - 2020-10-17 05:42:07 --> Router Class Initialized
INFO - 2020-10-17 05:42:07 --> Output Class Initialized
INFO - 2020-10-17 05:42:07 --> Security Class Initialized
DEBUG - 2020-10-17 05:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:42:07 --> Input Class Initialized
INFO - 2020-10-17 05:42:07 --> Language Class Initialized
INFO - 2020-10-17 05:42:07 --> Language Class Initialized
INFO - 2020-10-17 05:42:08 --> Config Class Initialized
INFO - 2020-10-17 05:42:08 --> Loader Class Initialized
INFO - 2020-10-17 05:42:08 --> Helper loaded: url_helper
INFO - 2020-10-17 05:42:08 --> Helper loaded: file_helper
INFO - 2020-10-17 05:42:08 --> Helper loaded: form_helper
INFO - 2020-10-17 05:42:08 --> Helper loaded: my_helper
INFO - 2020-10-17 05:42:08 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:42:08 --> Controller Class Initialized
INFO - 2020-10-17 05:42:50 --> Config Class Initialized
INFO - 2020-10-17 05:42:50 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:42:50 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:42:50 --> Utf8 Class Initialized
INFO - 2020-10-17 05:42:50 --> URI Class Initialized
INFO - 2020-10-17 05:42:50 --> Router Class Initialized
INFO - 2020-10-17 05:42:50 --> Output Class Initialized
INFO - 2020-10-17 05:42:50 --> Security Class Initialized
DEBUG - 2020-10-17 05:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:42:50 --> Input Class Initialized
INFO - 2020-10-17 05:42:50 --> Language Class Initialized
INFO - 2020-10-17 05:42:50 --> Language Class Initialized
INFO - 2020-10-17 05:42:50 --> Config Class Initialized
INFO - 2020-10-17 05:42:50 --> Loader Class Initialized
INFO - 2020-10-17 05:42:50 --> Helper loaded: url_helper
INFO - 2020-10-17 05:42:50 --> Helper loaded: file_helper
INFO - 2020-10-17 05:42:50 --> Helper loaded: form_helper
INFO - 2020-10-17 05:42:51 --> Helper loaded: my_helper
INFO - 2020-10-17 05:42:51 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:42:51 --> Controller Class Initialized
INFO - 2020-10-17 05:42:51 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:42:51 --> Config Class Initialized
INFO - 2020-10-17 05:42:51 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:42:51 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:42:51 --> Utf8 Class Initialized
INFO - 2020-10-17 05:42:51 --> URI Class Initialized
INFO - 2020-10-17 05:42:51 --> Router Class Initialized
INFO - 2020-10-17 05:42:51 --> Output Class Initialized
INFO - 2020-10-17 05:42:51 --> Security Class Initialized
DEBUG - 2020-10-17 05:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:42:51 --> Input Class Initialized
INFO - 2020-10-17 05:42:51 --> Language Class Initialized
INFO - 2020-10-17 05:42:52 --> Language Class Initialized
INFO - 2020-10-17 05:42:52 --> Config Class Initialized
INFO - 2020-10-17 05:42:52 --> Loader Class Initialized
INFO - 2020-10-17 05:42:52 --> Helper loaded: url_helper
INFO - 2020-10-17 05:42:52 --> Helper loaded: file_helper
INFO - 2020-10-17 05:42:52 --> Helper loaded: form_helper
INFO - 2020-10-17 05:42:52 --> Helper loaded: my_helper
INFO - 2020-10-17 05:42:52 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:42:52 --> Controller Class Initialized
DEBUG - 2020-10-17 05:42:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:42:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:42:52 --> Final output sent to browser
DEBUG - 2020-10-17 05:42:52 --> Total execution time: 1.2887
INFO - 2020-10-17 05:42:59 --> Config Class Initialized
INFO - 2020-10-17 05:42:59 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:42:59 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:42:59 --> Utf8 Class Initialized
INFO - 2020-10-17 05:42:59 --> URI Class Initialized
INFO - 2020-10-17 05:42:59 --> Router Class Initialized
INFO - 2020-10-17 05:42:59 --> Output Class Initialized
INFO - 2020-10-17 05:42:59 --> Security Class Initialized
DEBUG - 2020-10-17 05:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:42:59 --> Input Class Initialized
INFO - 2020-10-17 05:42:59 --> Language Class Initialized
INFO - 2020-10-17 05:42:59 --> Language Class Initialized
INFO - 2020-10-17 05:42:59 --> Config Class Initialized
INFO - 2020-10-17 05:43:00 --> Loader Class Initialized
INFO - 2020-10-17 05:43:00 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:00 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:00 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:00 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:00 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:00 --> Controller Class Initialized
INFO - 2020-10-17 05:43:00 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:43:00 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:00 --> Total execution time: 1.1636
INFO - 2020-10-17 05:43:01 --> Config Class Initialized
INFO - 2020-10-17 05:43:01 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:02 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:02 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:02 --> URI Class Initialized
INFO - 2020-10-17 05:43:02 --> Router Class Initialized
INFO - 2020-10-17 05:43:02 --> Output Class Initialized
INFO - 2020-10-17 05:43:02 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:02 --> Input Class Initialized
INFO - 2020-10-17 05:43:02 --> Language Class Initialized
INFO - 2020-10-17 05:43:02 --> Language Class Initialized
INFO - 2020-10-17 05:43:02 --> Config Class Initialized
INFO - 2020-10-17 05:43:02 --> Loader Class Initialized
INFO - 2020-10-17 05:43:02 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:02 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:02 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:02 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:02 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:03 --> Controller Class Initialized
DEBUG - 2020-10-17 05:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:43:03 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:03 --> Total execution time: 1.3868
INFO - 2020-10-17 05:43:06 --> Config Class Initialized
INFO - 2020-10-17 05:43:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:06 --> URI Class Initialized
INFO - 2020-10-17 05:43:06 --> Router Class Initialized
INFO - 2020-10-17 05:43:06 --> Output Class Initialized
INFO - 2020-10-17 05:43:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:06 --> Input Class Initialized
INFO - 2020-10-17 05:43:06 --> Language Class Initialized
INFO - 2020-10-17 05:43:06 --> Language Class Initialized
INFO - 2020-10-17 05:43:07 --> Config Class Initialized
INFO - 2020-10-17 05:43:07 --> Loader Class Initialized
INFO - 2020-10-17 05:43:07 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:07 --> Controller Class Initialized
INFO - 2020-10-17 05:43:07 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:43:07 --> Config Class Initialized
INFO - 2020-10-17 05:43:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:07 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:07 --> URI Class Initialized
INFO - 2020-10-17 05:43:07 --> Router Class Initialized
INFO - 2020-10-17 05:43:08 --> Output Class Initialized
INFO - 2020-10-17 05:43:08 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:08 --> Input Class Initialized
INFO - 2020-10-17 05:43:08 --> Language Class Initialized
INFO - 2020-10-17 05:43:08 --> Language Class Initialized
INFO - 2020-10-17 05:43:08 --> Config Class Initialized
INFO - 2020-10-17 05:43:08 --> Loader Class Initialized
INFO - 2020-10-17 05:43:08 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:08 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:08 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:08 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:08 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:08 --> Controller Class Initialized
DEBUG - 2020-10-17 05:43:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:43:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:43:08 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:08 --> Total execution time: 0.9465
INFO - 2020-10-17 05:43:14 --> Config Class Initialized
INFO - 2020-10-17 05:43:14 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:14 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:14 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:14 --> URI Class Initialized
INFO - 2020-10-17 05:43:14 --> Router Class Initialized
INFO - 2020-10-17 05:43:14 --> Output Class Initialized
INFO - 2020-10-17 05:43:14 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:14 --> Input Class Initialized
INFO - 2020-10-17 05:43:14 --> Language Class Initialized
INFO - 2020-10-17 05:43:14 --> Language Class Initialized
INFO - 2020-10-17 05:43:14 --> Config Class Initialized
INFO - 2020-10-17 05:43:14 --> Loader Class Initialized
INFO - 2020-10-17 05:43:14 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:14 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:14 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:15 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:15 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:15 --> Controller Class Initialized
INFO - 2020-10-17 05:43:15 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:43:15 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:15 --> Total execution time: 1.0442
INFO - 2020-10-17 05:43:16 --> Config Class Initialized
INFO - 2020-10-17 05:43:16 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:16 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:16 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:16 --> URI Class Initialized
INFO - 2020-10-17 05:43:16 --> Router Class Initialized
INFO - 2020-10-17 05:43:16 --> Output Class Initialized
INFO - 2020-10-17 05:43:16 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:16 --> Input Class Initialized
INFO - 2020-10-17 05:43:16 --> Language Class Initialized
INFO - 2020-10-17 05:43:16 --> Language Class Initialized
INFO - 2020-10-17 05:43:17 --> Config Class Initialized
INFO - 2020-10-17 05:43:17 --> Loader Class Initialized
INFO - 2020-10-17 05:43:17 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:17 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:17 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:17 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:17 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:17 --> Controller Class Initialized
DEBUG - 2020-10-17 05:43:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:43:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:43:17 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:17 --> Total execution time: 1.2926
INFO - 2020-10-17 05:43:20 --> Config Class Initialized
INFO - 2020-10-17 05:43:20 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:20 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:20 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:20 --> URI Class Initialized
INFO - 2020-10-17 05:43:20 --> Router Class Initialized
INFO - 2020-10-17 05:43:20 --> Output Class Initialized
INFO - 2020-10-17 05:43:20 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:20 --> Input Class Initialized
INFO - 2020-10-17 05:43:20 --> Language Class Initialized
INFO - 2020-10-17 05:43:20 --> Language Class Initialized
INFO - 2020-10-17 05:43:20 --> Config Class Initialized
INFO - 2020-10-17 05:43:21 --> Loader Class Initialized
INFO - 2020-10-17 05:43:21 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:21 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:21 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:21 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:21 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:21 --> Controller Class Initialized
INFO - 2020-10-17 05:43:21 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:43:21 --> Config Class Initialized
INFO - 2020-10-17 05:43:21 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:21 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:21 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:21 --> URI Class Initialized
INFO - 2020-10-17 05:43:21 --> Router Class Initialized
INFO - 2020-10-17 05:43:21 --> Output Class Initialized
INFO - 2020-10-17 05:43:21 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:22 --> Input Class Initialized
INFO - 2020-10-17 05:43:22 --> Language Class Initialized
INFO - 2020-10-17 05:43:22 --> Language Class Initialized
INFO - 2020-10-17 05:43:22 --> Config Class Initialized
INFO - 2020-10-17 05:43:22 --> Loader Class Initialized
INFO - 2020-10-17 05:43:22 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:22 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:22 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:22 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:22 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:22 --> Controller Class Initialized
DEBUG - 2020-10-17 05:43:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:43:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:43:22 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:22 --> Total execution time: 1.3102
INFO - 2020-10-17 05:43:28 --> Config Class Initialized
INFO - 2020-10-17 05:43:28 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:28 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:28 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:28 --> URI Class Initialized
INFO - 2020-10-17 05:43:28 --> Router Class Initialized
INFO - 2020-10-17 05:43:28 --> Output Class Initialized
INFO - 2020-10-17 05:43:28 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:29 --> Input Class Initialized
INFO - 2020-10-17 05:43:29 --> Language Class Initialized
INFO - 2020-10-17 05:43:29 --> Language Class Initialized
INFO - 2020-10-17 05:43:29 --> Config Class Initialized
INFO - 2020-10-17 05:43:29 --> Loader Class Initialized
INFO - 2020-10-17 05:43:29 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:29 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:29 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:29 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:29 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:29 --> Controller Class Initialized
INFO - 2020-10-17 05:43:29 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:43:29 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:29 --> Total execution time: 1.1507
INFO - 2020-10-17 05:43:31 --> Config Class Initialized
INFO - 2020-10-17 05:43:31 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:31 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:31 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:31 --> URI Class Initialized
INFO - 2020-10-17 05:43:31 --> Router Class Initialized
INFO - 2020-10-17 05:43:31 --> Output Class Initialized
INFO - 2020-10-17 05:43:31 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:31 --> Input Class Initialized
INFO - 2020-10-17 05:43:31 --> Language Class Initialized
INFO - 2020-10-17 05:43:31 --> Language Class Initialized
INFO - 2020-10-17 05:43:31 --> Config Class Initialized
INFO - 2020-10-17 05:43:31 --> Loader Class Initialized
INFO - 2020-10-17 05:43:31 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:31 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:31 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:31 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:31 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:32 --> Controller Class Initialized
DEBUG - 2020-10-17 05:43:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:43:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:43:32 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:32 --> Total execution time: 1.2522
INFO - 2020-10-17 05:43:35 --> Config Class Initialized
INFO - 2020-10-17 05:43:35 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:35 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:35 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:35 --> URI Class Initialized
INFO - 2020-10-17 05:43:35 --> Router Class Initialized
INFO - 2020-10-17 05:43:35 --> Output Class Initialized
INFO - 2020-10-17 05:43:35 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:35 --> Input Class Initialized
INFO - 2020-10-17 05:43:35 --> Language Class Initialized
INFO - 2020-10-17 05:43:35 --> Language Class Initialized
INFO - 2020-10-17 05:43:35 --> Config Class Initialized
INFO - 2020-10-17 05:43:35 --> Loader Class Initialized
INFO - 2020-10-17 05:43:35 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:36 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:36 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:36 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:36 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:36 --> Controller Class Initialized
DEBUG - 2020-10-17 05:43:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-17 05:43:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:43:36 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:36 --> Total execution time: 1.0185
INFO - 2020-10-17 05:43:36 --> Config Class Initialized
INFO - 2020-10-17 05:43:36 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:36 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:36 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:36 --> URI Class Initialized
INFO - 2020-10-17 05:43:36 --> Router Class Initialized
INFO - 2020-10-17 05:43:37 --> Output Class Initialized
INFO - 2020-10-17 05:43:37 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:37 --> Input Class Initialized
INFO - 2020-10-17 05:43:37 --> Language Class Initialized
INFO - 2020-10-17 05:43:37 --> Language Class Initialized
INFO - 2020-10-17 05:43:37 --> Config Class Initialized
INFO - 2020-10-17 05:43:37 --> Loader Class Initialized
INFO - 2020-10-17 05:43:37 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:37 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:37 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:37 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:37 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:37 --> Controller Class Initialized
INFO - 2020-10-17 05:43:38 --> Config Class Initialized
INFO - 2020-10-17 05:43:38 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:38 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:38 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:38 --> URI Class Initialized
INFO - 2020-10-17 05:43:38 --> Router Class Initialized
INFO - 2020-10-17 05:43:38 --> Output Class Initialized
INFO - 2020-10-17 05:43:38 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:39 --> Input Class Initialized
INFO - 2020-10-17 05:43:39 --> Language Class Initialized
INFO - 2020-10-17 05:43:39 --> Language Class Initialized
INFO - 2020-10-17 05:43:39 --> Config Class Initialized
INFO - 2020-10-17 05:43:39 --> Loader Class Initialized
INFO - 2020-10-17 05:43:39 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:39 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:39 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:39 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:39 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:39 --> Controller Class Initialized
INFO - 2020-10-17 05:43:39 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:39 --> Total execution time: 0.9660
INFO - 2020-10-17 05:43:44 --> Config Class Initialized
INFO - 2020-10-17 05:43:44 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:44 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:44 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:44 --> URI Class Initialized
INFO - 2020-10-17 05:43:44 --> Router Class Initialized
INFO - 2020-10-17 05:43:44 --> Output Class Initialized
INFO - 2020-10-17 05:43:44 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:44 --> Input Class Initialized
INFO - 2020-10-17 05:43:44 --> Language Class Initialized
INFO - 2020-10-17 05:43:44 --> Language Class Initialized
INFO - 2020-10-17 05:43:44 --> Config Class Initialized
INFO - 2020-10-17 05:43:44 --> Loader Class Initialized
INFO - 2020-10-17 05:43:44 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:44 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:44 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:44 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:44 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:44 --> Controller Class Initialized
INFO - 2020-10-17 05:43:45 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:45 --> Total execution time: 1.0265
INFO - 2020-10-17 05:43:45 --> Config Class Initialized
INFO - 2020-10-17 05:43:45 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:45 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:45 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:45 --> URI Class Initialized
INFO - 2020-10-17 05:43:45 --> Router Class Initialized
INFO - 2020-10-17 05:43:45 --> Output Class Initialized
INFO - 2020-10-17 05:43:45 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:45 --> Input Class Initialized
INFO - 2020-10-17 05:43:45 --> Language Class Initialized
INFO - 2020-10-17 05:43:45 --> Language Class Initialized
INFO - 2020-10-17 05:43:46 --> Config Class Initialized
INFO - 2020-10-17 05:43:46 --> Loader Class Initialized
INFO - 2020-10-17 05:43:46 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:46 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:46 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:46 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:46 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:46 --> Controller Class Initialized
INFO - 2020-10-17 05:43:49 --> Config Class Initialized
INFO - 2020-10-17 05:43:49 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:49 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:49 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:49 --> URI Class Initialized
INFO - 2020-10-17 05:43:49 --> Router Class Initialized
INFO - 2020-10-17 05:43:49 --> Output Class Initialized
INFO - 2020-10-17 05:43:49 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:49 --> Input Class Initialized
INFO - 2020-10-17 05:43:49 --> Language Class Initialized
INFO - 2020-10-17 05:43:49 --> Language Class Initialized
INFO - 2020-10-17 05:43:49 --> Config Class Initialized
INFO - 2020-10-17 05:43:49 --> Loader Class Initialized
INFO - 2020-10-17 05:43:49 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:49 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:49 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:49 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:49 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:49 --> Controller Class Initialized
INFO - 2020-10-17 05:43:49 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:49 --> Total execution time: 0.8741
INFO - 2020-10-17 05:43:52 --> Config Class Initialized
INFO - 2020-10-17 05:43:52 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:52 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:52 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:52 --> URI Class Initialized
INFO - 2020-10-17 05:43:52 --> Router Class Initialized
INFO - 2020-10-17 05:43:52 --> Output Class Initialized
INFO - 2020-10-17 05:43:52 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:52 --> Input Class Initialized
INFO - 2020-10-17 05:43:52 --> Language Class Initialized
INFO - 2020-10-17 05:43:52 --> Language Class Initialized
INFO - 2020-10-17 05:43:52 --> Config Class Initialized
INFO - 2020-10-17 05:43:52 --> Loader Class Initialized
INFO - 2020-10-17 05:43:52 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:52 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:52 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:52 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:52 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:53 --> Controller Class Initialized
INFO - 2020-10-17 05:43:53 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:43:53 --> Config Class Initialized
INFO - 2020-10-17 05:43:53 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:43:53 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:43:53 --> Utf8 Class Initialized
INFO - 2020-10-17 05:43:53 --> URI Class Initialized
INFO - 2020-10-17 05:43:53 --> Router Class Initialized
INFO - 2020-10-17 05:43:53 --> Output Class Initialized
INFO - 2020-10-17 05:43:53 --> Security Class Initialized
DEBUG - 2020-10-17 05:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:43:53 --> Input Class Initialized
INFO - 2020-10-17 05:43:53 --> Language Class Initialized
INFO - 2020-10-17 05:43:53 --> Language Class Initialized
INFO - 2020-10-17 05:43:53 --> Config Class Initialized
INFO - 2020-10-17 05:43:53 --> Loader Class Initialized
INFO - 2020-10-17 05:43:54 --> Helper loaded: url_helper
INFO - 2020-10-17 05:43:54 --> Helper loaded: file_helper
INFO - 2020-10-17 05:43:54 --> Helper loaded: form_helper
INFO - 2020-10-17 05:43:54 --> Helper loaded: my_helper
INFO - 2020-10-17 05:43:54 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:43:54 --> Controller Class Initialized
DEBUG - 2020-10-17 05:43:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:43:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:43:54 --> Final output sent to browser
DEBUG - 2020-10-17 05:43:54 --> Total execution time: 1.3418
INFO - 2020-10-17 05:44:00 --> Config Class Initialized
INFO - 2020-10-17 05:44:00 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:44:00 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:44:00 --> Utf8 Class Initialized
INFO - 2020-10-17 05:44:00 --> URI Class Initialized
INFO - 2020-10-17 05:44:00 --> Router Class Initialized
INFO - 2020-10-17 05:44:01 --> Output Class Initialized
INFO - 2020-10-17 05:44:01 --> Security Class Initialized
DEBUG - 2020-10-17 05:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:44:01 --> Input Class Initialized
INFO - 2020-10-17 05:44:01 --> Language Class Initialized
INFO - 2020-10-17 05:44:01 --> Language Class Initialized
INFO - 2020-10-17 05:44:01 --> Config Class Initialized
INFO - 2020-10-17 05:44:01 --> Loader Class Initialized
INFO - 2020-10-17 05:44:01 --> Helper loaded: url_helper
INFO - 2020-10-17 05:44:01 --> Helper loaded: file_helper
INFO - 2020-10-17 05:44:01 --> Helper loaded: form_helper
INFO - 2020-10-17 05:44:01 --> Helper loaded: my_helper
INFO - 2020-10-17 05:44:01 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:44:01 --> Controller Class Initialized
INFO - 2020-10-17 05:44:01 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:44:01 --> Final output sent to browser
DEBUG - 2020-10-17 05:44:01 --> Total execution time: 1.0007
INFO - 2020-10-17 05:44:03 --> Config Class Initialized
INFO - 2020-10-17 05:44:03 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:44:03 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:44:03 --> Utf8 Class Initialized
INFO - 2020-10-17 05:44:03 --> URI Class Initialized
INFO - 2020-10-17 05:44:03 --> Router Class Initialized
INFO - 2020-10-17 05:44:03 --> Output Class Initialized
INFO - 2020-10-17 05:44:03 --> Security Class Initialized
DEBUG - 2020-10-17 05:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:44:03 --> Input Class Initialized
INFO - 2020-10-17 05:44:03 --> Language Class Initialized
INFO - 2020-10-17 05:44:03 --> Language Class Initialized
INFO - 2020-10-17 05:44:03 --> Config Class Initialized
INFO - 2020-10-17 05:44:03 --> Loader Class Initialized
INFO - 2020-10-17 05:44:03 --> Helper loaded: url_helper
INFO - 2020-10-17 05:44:03 --> Helper loaded: file_helper
INFO - 2020-10-17 05:44:03 --> Helper loaded: form_helper
INFO - 2020-10-17 05:44:03 --> Helper loaded: my_helper
INFO - 2020-10-17 05:44:03 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:44:03 --> Controller Class Initialized
DEBUG - 2020-10-17 05:44:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:44:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:44:03 --> Final output sent to browser
DEBUG - 2020-10-17 05:44:03 --> Total execution time: 0.8665
INFO - 2020-10-17 05:44:06 --> Config Class Initialized
INFO - 2020-10-17 05:44:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:44:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:44:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:44:06 --> URI Class Initialized
INFO - 2020-10-17 05:44:06 --> Router Class Initialized
INFO - 2020-10-17 05:44:06 --> Output Class Initialized
INFO - 2020-10-17 05:44:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:44:07 --> Input Class Initialized
INFO - 2020-10-17 05:44:07 --> Language Class Initialized
INFO - 2020-10-17 05:44:07 --> Language Class Initialized
INFO - 2020-10-17 05:44:07 --> Config Class Initialized
INFO - 2020-10-17 05:44:07 --> Loader Class Initialized
INFO - 2020-10-17 05:44:07 --> Helper loaded: url_helper
INFO - 2020-10-17 05:44:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:44:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:44:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:44:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:44:07 --> Controller Class Initialized
INFO - 2020-10-17 05:44:07 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:44:07 --> Config Class Initialized
INFO - 2020-10-17 05:44:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:44:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:44:08 --> Utf8 Class Initialized
INFO - 2020-10-17 05:44:08 --> URI Class Initialized
INFO - 2020-10-17 05:44:08 --> Router Class Initialized
INFO - 2020-10-17 05:44:08 --> Output Class Initialized
INFO - 2020-10-17 05:44:08 --> Security Class Initialized
DEBUG - 2020-10-17 05:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:44:08 --> Input Class Initialized
INFO - 2020-10-17 05:44:08 --> Language Class Initialized
INFO - 2020-10-17 05:44:08 --> Language Class Initialized
INFO - 2020-10-17 05:44:08 --> Config Class Initialized
INFO - 2020-10-17 05:44:08 --> Loader Class Initialized
INFO - 2020-10-17 05:44:08 --> Helper loaded: url_helper
INFO - 2020-10-17 05:44:08 --> Helper loaded: file_helper
INFO - 2020-10-17 05:44:08 --> Helper loaded: form_helper
INFO - 2020-10-17 05:44:08 --> Helper loaded: my_helper
INFO - 2020-10-17 05:44:08 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:44:09 --> Controller Class Initialized
DEBUG - 2020-10-17 05:44:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:44:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:44:09 --> Final output sent to browser
DEBUG - 2020-10-17 05:44:09 --> Total execution time: 1.3464
INFO - 2020-10-17 05:44:15 --> Config Class Initialized
INFO - 2020-10-17 05:44:15 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:44:15 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:44:15 --> Utf8 Class Initialized
INFO - 2020-10-17 05:44:15 --> URI Class Initialized
INFO - 2020-10-17 05:44:15 --> Router Class Initialized
INFO - 2020-10-17 05:44:15 --> Output Class Initialized
INFO - 2020-10-17 05:44:15 --> Security Class Initialized
DEBUG - 2020-10-17 05:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:44:15 --> Input Class Initialized
INFO - 2020-10-17 05:44:15 --> Language Class Initialized
INFO - 2020-10-17 05:44:15 --> Language Class Initialized
INFO - 2020-10-17 05:44:16 --> Config Class Initialized
INFO - 2020-10-17 05:44:16 --> Loader Class Initialized
INFO - 2020-10-17 05:44:16 --> Helper loaded: url_helper
INFO - 2020-10-17 05:44:16 --> Helper loaded: file_helper
INFO - 2020-10-17 05:44:16 --> Helper loaded: form_helper
INFO - 2020-10-17 05:44:16 --> Helper loaded: my_helper
INFO - 2020-10-17 05:44:16 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:44:16 --> Controller Class Initialized
INFO - 2020-10-17 05:44:16 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:44:16 --> Final output sent to browser
DEBUG - 2020-10-17 05:44:16 --> Total execution time: 0.9285
INFO - 2020-10-17 05:44:17 --> Config Class Initialized
INFO - 2020-10-17 05:44:17 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:44:17 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:44:17 --> Utf8 Class Initialized
INFO - 2020-10-17 05:44:17 --> URI Class Initialized
INFO - 2020-10-17 05:44:18 --> Router Class Initialized
INFO - 2020-10-17 05:44:18 --> Output Class Initialized
INFO - 2020-10-17 05:44:18 --> Security Class Initialized
DEBUG - 2020-10-17 05:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:44:18 --> Input Class Initialized
INFO - 2020-10-17 05:44:18 --> Language Class Initialized
INFO - 2020-10-17 05:44:18 --> Language Class Initialized
INFO - 2020-10-17 05:44:18 --> Config Class Initialized
INFO - 2020-10-17 05:44:18 --> Loader Class Initialized
INFO - 2020-10-17 05:44:18 --> Helper loaded: url_helper
INFO - 2020-10-17 05:44:18 --> Helper loaded: file_helper
INFO - 2020-10-17 05:44:18 --> Helper loaded: form_helper
INFO - 2020-10-17 05:44:18 --> Helper loaded: my_helper
INFO - 2020-10-17 05:44:18 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:44:18 --> Controller Class Initialized
DEBUG - 2020-10-17 05:44:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:44:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:44:18 --> Final output sent to browser
DEBUG - 2020-10-17 05:44:18 --> Total execution time: 0.9995
INFO - 2020-10-17 05:44:24 --> Config Class Initialized
INFO - 2020-10-17 05:44:24 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:44:24 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:44:24 --> Utf8 Class Initialized
INFO - 2020-10-17 05:44:24 --> URI Class Initialized
INFO - 2020-10-17 05:44:24 --> Router Class Initialized
INFO - 2020-10-17 05:44:24 --> Output Class Initialized
INFO - 2020-10-17 05:44:24 --> Security Class Initialized
DEBUG - 2020-10-17 05:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:44:24 --> Input Class Initialized
INFO - 2020-10-17 05:44:24 --> Language Class Initialized
INFO - 2020-10-17 05:44:24 --> Language Class Initialized
INFO - 2020-10-17 05:44:24 --> Config Class Initialized
INFO - 2020-10-17 05:44:24 --> Loader Class Initialized
INFO - 2020-10-17 05:44:24 --> Helper loaded: url_helper
INFO - 2020-10-17 05:44:24 --> Helper loaded: file_helper
INFO - 2020-10-17 05:44:25 --> Helper loaded: form_helper
INFO - 2020-10-17 05:44:25 --> Helper loaded: my_helper
INFO - 2020-10-17 05:44:25 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:44:25 --> Controller Class Initialized
INFO - 2020-10-17 05:44:25 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:44:25 --> Config Class Initialized
INFO - 2020-10-17 05:44:25 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:44:25 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:44:25 --> Utf8 Class Initialized
INFO - 2020-10-17 05:44:25 --> URI Class Initialized
INFO - 2020-10-17 05:44:25 --> Router Class Initialized
INFO - 2020-10-17 05:44:25 --> Output Class Initialized
INFO - 2020-10-17 05:44:25 --> Security Class Initialized
DEBUG - 2020-10-17 05:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:44:25 --> Input Class Initialized
INFO - 2020-10-17 05:44:25 --> Language Class Initialized
INFO - 2020-10-17 05:44:26 --> Language Class Initialized
INFO - 2020-10-17 05:44:26 --> Config Class Initialized
INFO - 2020-10-17 05:44:26 --> Loader Class Initialized
INFO - 2020-10-17 05:44:26 --> Helper loaded: url_helper
INFO - 2020-10-17 05:44:26 --> Helper loaded: file_helper
INFO - 2020-10-17 05:44:26 --> Helper loaded: form_helper
INFO - 2020-10-17 05:44:26 --> Helper loaded: my_helper
INFO - 2020-10-17 05:44:26 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:44:26 --> Controller Class Initialized
DEBUG - 2020-10-17 05:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:44:26 --> Final output sent to browser
DEBUG - 2020-10-17 05:44:26 --> Total execution time: 1.2778
INFO - 2020-10-17 05:48:52 --> Config Class Initialized
INFO - 2020-10-17 05:48:52 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:48:52 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:48:52 --> Utf8 Class Initialized
INFO - 2020-10-17 05:48:52 --> URI Class Initialized
INFO - 2020-10-17 05:48:52 --> Router Class Initialized
INFO - 2020-10-17 05:48:52 --> Output Class Initialized
INFO - 2020-10-17 05:48:53 --> Security Class Initialized
DEBUG - 2020-10-17 05:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:48:53 --> Input Class Initialized
INFO - 2020-10-17 05:48:53 --> Language Class Initialized
INFO - 2020-10-17 05:48:53 --> Language Class Initialized
INFO - 2020-10-17 05:48:53 --> Config Class Initialized
INFO - 2020-10-17 05:48:53 --> Loader Class Initialized
INFO - 2020-10-17 05:48:53 --> Helper loaded: url_helper
INFO - 2020-10-17 05:48:53 --> Helper loaded: file_helper
INFO - 2020-10-17 05:48:53 --> Helper loaded: form_helper
INFO - 2020-10-17 05:48:53 --> Helper loaded: my_helper
INFO - 2020-10-17 05:48:53 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:48:53 --> Controller Class Initialized
INFO - 2020-10-17 05:48:53 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:48:53 --> Final output sent to browser
DEBUG - 2020-10-17 05:48:53 --> Total execution time: 0.9748
INFO - 2020-10-17 05:48:54 --> Config Class Initialized
INFO - 2020-10-17 05:48:55 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:48:55 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:48:55 --> Utf8 Class Initialized
INFO - 2020-10-17 05:48:55 --> URI Class Initialized
INFO - 2020-10-17 05:48:55 --> Router Class Initialized
INFO - 2020-10-17 05:48:55 --> Output Class Initialized
INFO - 2020-10-17 05:48:55 --> Security Class Initialized
DEBUG - 2020-10-17 05:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:48:55 --> Input Class Initialized
INFO - 2020-10-17 05:48:55 --> Language Class Initialized
INFO - 2020-10-17 05:48:55 --> Language Class Initialized
INFO - 2020-10-17 05:48:55 --> Config Class Initialized
INFO - 2020-10-17 05:48:55 --> Loader Class Initialized
INFO - 2020-10-17 05:48:55 --> Helper loaded: url_helper
INFO - 2020-10-17 05:48:55 --> Helper loaded: file_helper
INFO - 2020-10-17 05:48:55 --> Helper loaded: form_helper
INFO - 2020-10-17 05:48:55 --> Helper loaded: my_helper
INFO - 2020-10-17 05:48:55 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:48:56 --> Controller Class Initialized
DEBUG - 2020-10-17 05:48:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:48:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:48:56 --> Final output sent to browser
DEBUG - 2020-10-17 05:48:56 --> Total execution time: 1.3852
INFO - 2020-10-17 05:49:07 --> Config Class Initialized
INFO - 2020-10-17 05:49:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:49:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:49:07 --> Utf8 Class Initialized
INFO - 2020-10-17 05:49:07 --> URI Class Initialized
INFO - 2020-10-17 05:49:07 --> Router Class Initialized
INFO - 2020-10-17 05:49:07 --> Output Class Initialized
INFO - 2020-10-17 05:49:07 --> Security Class Initialized
DEBUG - 2020-10-17 05:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:49:07 --> Input Class Initialized
INFO - 2020-10-17 05:49:07 --> Language Class Initialized
INFO - 2020-10-17 05:49:07 --> Language Class Initialized
INFO - 2020-10-17 05:49:07 --> Config Class Initialized
INFO - 2020-10-17 05:49:07 --> Loader Class Initialized
INFO - 2020-10-17 05:49:07 --> Helper loaded: url_helper
INFO - 2020-10-17 05:49:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:49:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:49:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:49:08 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:49:08 --> Controller Class Initialized
DEBUG - 2020-10-17 05:49:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:49:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:49:08 --> Final output sent to browser
DEBUG - 2020-10-17 05:49:08 --> Total execution time: 1.2790
INFO - 2020-10-17 05:49:08 --> Config Class Initialized
INFO - 2020-10-17 05:49:08 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:49:08 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:49:08 --> Utf8 Class Initialized
INFO - 2020-10-17 05:49:08 --> URI Class Initialized
INFO - 2020-10-17 05:49:09 --> Router Class Initialized
INFO - 2020-10-17 05:49:09 --> Output Class Initialized
INFO - 2020-10-17 05:49:09 --> Security Class Initialized
DEBUG - 2020-10-17 05:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:49:09 --> Input Class Initialized
INFO - 2020-10-17 05:49:09 --> Language Class Initialized
INFO - 2020-10-17 05:49:09 --> Language Class Initialized
INFO - 2020-10-17 05:49:09 --> Config Class Initialized
INFO - 2020-10-17 05:49:09 --> Loader Class Initialized
INFO - 2020-10-17 05:49:09 --> Helper loaded: url_helper
INFO - 2020-10-17 05:49:09 --> Helper loaded: file_helper
INFO - 2020-10-17 05:49:09 --> Helper loaded: form_helper
INFO - 2020-10-17 05:49:09 --> Helper loaded: my_helper
INFO - 2020-10-17 05:49:09 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:49:09 --> Controller Class Initialized
INFO - 2020-10-17 05:50:05 --> Config Class Initialized
INFO - 2020-10-17 05:50:05 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:50:05 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:50:05 --> Utf8 Class Initialized
INFO - 2020-10-17 05:50:05 --> URI Class Initialized
INFO - 2020-10-17 05:50:05 --> Router Class Initialized
INFO - 2020-10-17 05:50:05 --> Output Class Initialized
INFO - 2020-10-17 05:50:05 --> Security Class Initialized
DEBUG - 2020-10-17 05:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:50:05 --> Input Class Initialized
INFO - 2020-10-17 05:50:05 --> Language Class Initialized
INFO - 2020-10-17 05:50:05 --> Language Class Initialized
INFO - 2020-10-17 05:50:05 --> Config Class Initialized
INFO - 2020-10-17 05:50:05 --> Loader Class Initialized
INFO - 2020-10-17 05:50:05 --> Helper loaded: url_helper
INFO - 2020-10-17 05:50:05 --> Helper loaded: file_helper
INFO - 2020-10-17 05:50:05 --> Helper loaded: form_helper
INFO - 2020-10-17 05:50:05 --> Helper loaded: my_helper
INFO - 2020-10-17 05:50:06 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:50:06 --> Controller Class Initialized
INFO - 2020-10-17 05:50:06 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:50:06 --> Config Class Initialized
INFO - 2020-10-17 05:50:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:50:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:50:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:50:06 --> URI Class Initialized
INFO - 2020-10-17 05:50:06 --> Router Class Initialized
INFO - 2020-10-17 05:50:06 --> Output Class Initialized
INFO - 2020-10-17 05:50:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:50:06 --> Input Class Initialized
INFO - 2020-10-17 05:50:06 --> Language Class Initialized
INFO - 2020-10-17 05:50:07 --> Language Class Initialized
INFO - 2020-10-17 05:50:07 --> Config Class Initialized
INFO - 2020-10-17 05:50:07 --> Loader Class Initialized
INFO - 2020-10-17 05:50:07 --> Helper loaded: url_helper
INFO - 2020-10-17 05:50:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:50:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:50:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:50:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:50:07 --> Controller Class Initialized
DEBUG - 2020-10-17 05:50:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:50:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:50:07 --> Final output sent to browser
DEBUG - 2020-10-17 05:50:07 --> Total execution time: 1.4065
INFO - 2020-10-17 05:50:12 --> Config Class Initialized
INFO - 2020-10-17 05:50:13 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:50:13 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:50:13 --> Utf8 Class Initialized
INFO - 2020-10-17 05:50:13 --> URI Class Initialized
INFO - 2020-10-17 05:50:13 --> Router Class Initialized
INFO - 2020-10-17 05:50:13 --> Output Class Initialized
INFO - 2020-10-17 05:50:13 --> Security Class Initialized
DEBUG - 2020-10-17 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:50:13 --> Input Class Initialized
INFO - 2020-10-17 05:50:13 --> Language Class Initialized
INFO - 2020-10-17 05:50:13 --> Language Class Initialized
INFO - 2020-10-17 05:50:13 --> Config Class Initialized
INFO - 2020-10-17 05:50:13 --> Loader Class Initialized
INFO - 2020-10-17 05:50:13 --> Helper loaded: url_helper
INFO - 2020-10-17 05:50:13 --> Helper loaded: file_helper
INFO - 2020-10-17 05:50:13 --> Helper loaded: form_helper
INFO - 2020-10-17 05:50:13 --> Helper loaded: my_helper
INFO - 2020-10-17 05:50:13 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:50:14 --> Controller Class Initialized
INFO - 2020-10-17 05:50:14 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:50:14 --> Final output sent to browser
DEBUG - 2020-10-17 05:50:14 --> Total execution time: 1.2501
INFO - 2020-10-17 05:50:15 --> Config Class Initialized
INFO - 2020-10-17 05:50:15 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:50:15 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:50:15 --> Utf8 Class Initialized
INFO - 2020-10-17 05:50:15 --> URI Class Initialized
INFO - 2020-10-17 05:50:15 --> Router Class Initialized
INFO - 2020-10-17 05:50:15 --> Output Class Initialized
INFO - 2020-10-17 05:50:15 --> Security Class Initialized
DEBUG - 2020-10-17 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:50:15 --> Input Class Initialized
INFO - 2020-10-17 05:50:15 --> Language Class Initialized
INFO - 2020-10-17 05:50:15 --> Language Class Initialized
INFO - 2020-10-17 05:50:16 --> Config Class Initialized
INFO - 2020-10-17 05:50:16 --> Loader Class Initialized
INFO - 2020-10-17 05:50:16 --> Helper loaded: url_helper
INFO - 2020-10-17 05:50:16 --> Helper loaded: file_helper
INFO - 2020-10-17 05:50:16 --> Helper loaded: form_helper
INFO - 2020-10-17 05:50:16 --> Helper loaded: my_helper
INFO - 2020-10-17 05:50:16 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:50:16 --> Controller Class Initialized
DEBUG - 2020-10-17 05:50:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:50:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:50:16 --> Final output sent to browser
DEBUG - 2020-10-17 05:50:16 --> Total execution time: 1.0042
INFO - 2020-10-17 05:50:19 --> Config Class Initialized
INFO - 2020-10-17 05:50:19 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:50:19 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:50:19 --> Utf8 Class Initialized
INFO - 2020-10-17 05:50:19 --> URI Class Initialized
INFO - 2020-10-17 05:50:19 --> Router Class Initialized
INFO - 2020-10-17 05:50:19 --> Output Class Initialized
INFO - 2020-10-17 05:50:19 --> Security Class Initialized
DEBUG - 2020-10-17 05:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:50:19 --> Input Class Initialized
INFO - 2020-10-17 05:50:19 --> Language Class Initialized
INFO - 2020-10-17 05:50:19 --> Language Class Initialized
INFO - 2020-10-17 05:50:19 --> Config Class Initialized
INFO - 2020-10-17 05:50:19 --> Loader Class Initialized
INFO - 2020-10-17 05:50:19 --> Helper loaded: url_helper
INFO - 2020-10-17 05:50:19 --> Helper loaded: file_helper
INFO - 2020-10-17 05:50:19 --> Helper loaded: form_helper
INFO - 2020-10-17 05:50:19 --> Helper loaded: my_helper
INFO - 2020-10-17 05:50:20 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:50:20 --> Controller Class Initialized
DEBUG - 2020-10-17 05:50:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-17 05:50:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:50:20 --> Final output sent to browser
DEBUG - 2020-10-17 05:50:20 --> Total execution time: 1.2835
INFO - 2020-10-17 05:50:39 --> Config Class Initialized
INFO - 2020-10-17 05:50:39 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:50:39 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:50:39 --> Utf8 Class Initialized
INFO - 2020-10-17 05:50:39 --> URI Class Initialized
INFO - 2020-10-17 05:50:39 --> Router Class Initialized
INFO - 2020-10-17 05:50:39 --> Output Class Initialized
INFO - 2020-10-17 05:50:40 --> Security Class Initialized
DEBUG - 2020-10-17 05:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:50:40 --> Input Class Initialized
INFO - 2020-10-17 05:50:40 --> Language Class Initialized
INFO - 2020-10-17 05:50:40 --> Language Class Initialized
INFO - 2020-10-17 05:50:40 --> Config Class Initialized
INFO - 2020-10-17 05:50:40 --> Loader Class Initialized
INFO - 2020-10-17 05:50:40 --> Helper loaded: url_helper
INFO - 2020-10-17 05:50:40 --> Helper loaded: file_helper
INFO - 2020-10-17 05:50:40 --> Helper loaded: form_helper
INFO - 2020-10-17 05:50:40 --> Helper loaded: my_helper
INFO - 2020-10-17 05:50:40 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:50:40 --> Controller Class Initialized
ERROR - 2020-10-17 05:50:41 --> Severity: Notice --> Undefined variable: kelompok C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 57
ERROR - 2020-10-17 05:50:41 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\nilai\application\helpers\my_helper.php 134
ERROR - 2020-10-17 05:50:41 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\nilai\application\helpers\my_helper.php 135
ERROR - 2020-10-17 05:50:41 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\nilai\application\helpers\my_helper.php 144
DEBUG - 2020-10-17 05:50:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-17 05:50:41 --> Final output sent to browser
DEBUG - 2020-10-17 05:50:41 --> Total execution time: 1.5410
INFO - 2020-10-17 05:50:58 --> Config Class Initialized
INFO - 2020-10-17 05:50:58 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:50:58 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:50:58 --> Utf8 Class Initialized
INFO - 2020-10-17 05:50:58 --> URI Class Initialized
INFO - 2020-10-17 05:50:58 --> Router Class Initialized
INFO - 2020-10-17 05:50:58 --> Output Class Initialized
INFO - 2020-10-17 05:50:58 --> Security Class Initialized
DEBUG - 2020-10-17 05:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:50:59 --> Input Class Initialized
INFO - 2020-10-17 05:50:59 --> Language Class Initialized
INFO - 2020-10-17 05:50:59 --> Language Class Initialized
INFO - 2020-10-17 05:50:59 --> Config Class Initialized
INFO - 2020-10-17 05:50:59 --> Loader Class Initialized
INFO - 2020-10-17 05:50:59 --> Helper loaded: url_helper
INFO - 2020-10-17 05:50:59 --> Helper loaded: file_helper
INFO - 2020-10-17 05:50:59 --> Helper loaded: form_helper
INFO - 2020-10-17 05:50:59 --> Helper loaded: my_helper
INFO - 2020-10-17 05:50:59 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:50:59 --> Controller Class Initialized
INFO - 2020-10-17 05:50:59 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:50:59 --> Config Class Initialized
INFO - 2020-10-17 05:51:00 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:51:00 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:51:00 --> Utf8 Class Initialized
INFO - 2020-10-17 05:51:00 --> URI Class Initialized
INFO - 2020-10-17 05:51:00 --> Router Class Initialized
INFO - 2020-10-17 05:51:00 --> Output Class Initialized
INFO - 2020-10-17 05:51:00 --> Security Class Initialized
DEBUG - 2020-10-17 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:51:00 --> Input Class Initialized
INFO - 2020-10-17 05:51:00 --> Language Class Initialized
INFO - 2020-10-17 05:51:00 --> Language Class Initialized
INFO - 2020-10-17 05:51:00 --> Config Class Initialized
INFO - 2020-10-17 05:51:00 --> Loader Class Initialized
INFO - 2020-10-17 05:51:00 --> Helper loaded: url_helper
INFO - 2020-10-17 05:51:00 --> Helper loaded: file_helper
INFO - 2020-10-17 05:51:00 --> Helper loaded: form_helper
INFO - 2020-10-17 05:51:00 --> Helper loaded: my_helper
INFO - 2020-10-17 05:51:00 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:51:01 --> Controller Class Initialized
DEBUG - 2020-10-17 05:51:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 05:51:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:51:01 --> Final output sent to browser
DEBUG - 2020-10-17 05:51:01 --> Total execution time: 1.3262
INFO - 2020-10-17 05:52:33 --> Config Class Initialized
INFO - 2020-10-17 05:52:33 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:52:33 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:52:33 --> Utf8 Class Initialized
INFO - 2020-10-17 05:52:33 --> URI Class Initialized
INFO - 2020-10-17 05:52:33 --> Router Class Initialized
INFO - 2020-10-17 05:52:33 --> Output Class Initialized
INFO - 2020-10-17 05:52:33 --> Security Class Initialized
DEBUG - 2020-10-17 05:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:52:33 --> Input Class Initialized
INFO - 2020-10-17 05:52:33 --> Language Class Initialized
INFO - 2020-10-17 05:52:33 --> Language Class Initialized
INFO - 2020-10-17 05:52:33 --> Config Class Initialized
INFO - 2020-10-17 05:52:33 --> Loader Class Initialized
INFO - 2020-10-17 05:52:34 --> Helper loaded: url_helper
INFO - 2020-10-17 05:52:34 --> Helper loaded: file_helper
INFO - 2020-10-17 05:52:34 --> Helper loaded: form_helper
INFO - 2020-10-17 05:52:34 --> Helper loaded: my_helper
INFO - 2020-10-17 05:52:34 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:52:34 --> Controller Class Initialized
INFO - 2020-10-17 05:52:34 --> Helper loaded: cookie_helper
INFO - 2020-10-17 05:52:34 --> Final output sent to browser
DEBUG - 2020-10-17 05:52:34 --> Total execution time: 1.1688
INFO - 2020-10-17 05:52:36 --> Config Class Initialized
INFO - 2020-10-17 05:52:36 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:52:36 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:52:36 --> Utf8 Class Initialized
INFO - 2020-10-17 05:52:36 --> URI Class Initialized
INFO - 2020-10-17 05:52:36 --> Router Class Initialized
INFO - 2020-10-17 05:52:36 --> Output Class Initialized
INFO - 2020-10-17 05:52:36 --> Security Class Initialized
DEBUG - 2020-10-17 05:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:52:36 --> Input Class Initialized
INFO - 2020-10-17 05:52:36 --> Language Class Initialized
INFO - 2020-10-17 05:52:37 --> Language Class Initialized
INFO - 2020-10-17 05:52:37 --> Config Class Initialized
INFO - 2020-10-17 05:52:37 --> Loader Class Initialized
INFO - 2020-10-17 05:52:37 --> Helper loaded: url_helper
INFO - 2020-10-17 05:52:37 --> Helper loaded: file_helper
INFO - 2020-10-17 05:52:37 --> Helper loaded: form_helper
INFO - 2020-10-17 05:52:37 --> Helper loaded: my_helper
INFO - 2020-10-17 05:52:37 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:52:37 --> Controller Class Initialized
DEBUG - 2020-10-17 05:52:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 05:52:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:52:37 --> Final output sent to browser
DEBUG - 2020-10-17 05:52:37 --> Total execution time: 1.4267
INFO - 2020-10-17 05:52:39 --> Config Class Initialized
INFO - 2020-10-17 05:52:39 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:52:39 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:52:40 --> Utf8 Class Initialized
INFO - 2020-10-17 05:52:40 --> URI Class Initialized
INFO - 2020-10-17 05:52:40 --> Router Class Initialized
INFO - 2020-10-17 05:52:40 --> Output Class Initialized
INFO - 2020-10-17 05:52:40 --> Security Class Initialized
DEBUG - 2020-10-17 05:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:52:40 --> Input Class Initialized
INFO - 2020-10-17 05:52:40 --> Language Class Initialized
INFO - 2020-10-17 05:52:40 --> Language Class Initialized
INFO - 2020-10-17 05:52:40 --> Config Class Initialized
INFO - 2020-10-17 05:52:40 --> Loader Class Initialized
INFO - 2020-10-17 05:52:40 --> Helper loaded: url_helper
INFO - 2020-10-17 05:52:40 --> Helper loaded: file_helper
INFO - 2020-10-17 05:52:40 --> Helper loaded: form_helper
INFO - 2020-10-17 05:52:40 --> Helper loaded: my_helper
INFO - 2020-10-17 05:52:40 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:52:40 --> Controller Class Initialized
DEBUG - 2020-10-17 05:52:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:52:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:52:40 --> Final output sent to browser
DEBUG - 2020-10-17 05:52:40 --> Total execution time: 0.8271
INFO - 2020-10-17 05:52:40 --> Config Class Initialized
INFO - 2020-10-17 05:52:40 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:52:41 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:52:41 --> Utf8 Class Initialized
INFO - 2020-10-17 05:52:41 --> URI Class Initialized
INFO - 2020-10-17 05:52:41 --> Router Class Initialized
INFO - 2020-10-17 05:52:41 --> Output Class Initialized
INFO - 2020-10-17 05:52:41 --> Security Class Initialized
DEBUG - 2020-10-17 05:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:52:41 --> Input Class Initialized
INFO - 2020-10-17 05:52:41 --> Language Class Initialized
INFO - 2020-10-17 05:52:41 --> Language Class Initialized
INFO - 2020-10-17 05:52:41 --> Config Class Initialized
INFO - 2020-10-17 05:52:41 --> Loader Class Initialized
INFO - 2020-10-17 05:52:41 --> Helper loaded: url_helper
INFO - 2020-10-17 05:52:41 --> Helper loaded: file_helper
INFO - 2020-10-17 05:52:41 --> Helper loaded: form_helper
INFO - 2020-10-17 05:52:41 --> Helper loaded: my_helper
INFO - 2020-10-17 05:52:41 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:52:41 --> Controller Class Initialized
INFO - 2020-10-17 05:53:06 --> Config Class Initialized
INFO - 2020-10-17 05:53:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:53:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:53:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:53:06 --> URI Class Initialized
INFO - 2020-10-17 05:53:06 --> Router Class Initialized
INFO - 2020-10-17 05:53:06 --> Output Class Initialized
INFO - 2020-10-17 05:53:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:53:06 --> Input Class Initialized
INFO - 2020-10-17 05:53:06 --> Language Class Initialized
INFO - 2020-10-17 05:53:07 --> Language Class Initialized
INFO - 2020-10-17 05:53:07 --> Config Class Initialized
INFO - 2020-10-17 05:53:07 --> Loader Class Initialized
INFO - 2020-10-17 05:53:07 --> Helper loaded: url_helper
INFO - 2020-10-17 05:53:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:53:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:53:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:53:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:53:07 --> Controller Class Initialized
DEBUG - 2020-10-17 05:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-17 05:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:53:07 --> Final output sent to browser
DEBUG - 2020-10-17 05:53:07 --> Total execution time: 1.3132
INFO - 2020-10-17 05:53:07 --> Config Class Initialized
INFO - 2020-10-17 05:53:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:53:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:53:08 --> Utf8 Class Initialized
INFO - 2020-10-17 05:53:08 --> URI Class Initialized
INFO - 2020-10-17 05:53:08 --> Router Class Initialized
INFO - 2020-10-17 05:53:08 --> Output Class Initialized
INFO - 2020-10-17 05:53:08 --> Security Class Initialized
DEBUG - 2020-10-17 05:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:53:08 --> Input Class Initialized
INFO - 2020-10-17 05:53:08 --> Language Class Initialized
INFO - 2020-10-17 05:53:08 --> Language Class Initialized
INFO - 2020-10-17 05:53:08 --> Config Class Initialized
INFO - 2020-10-17 05:53:08 --> Loader Class Initialized
INFO - 2020-10-17 05:53:08 --> Helper loaded: url_helper
INFO - 2020-10-17 05:53:08 --> Helper loaded: file_helper
INFO - 2020-10-17 05:53:08 --> Helper loaded: form_helper
INFO - 2020-10-17 05:53:08 --> Helper loaded: my_helper
INFO - 2020-10-17 05:53:08 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:53:08 --> Controller Class Initialized
INFO - 2020-10-17 05:53:11 --> Config Class Initialized
INFO - 2020-10-17 05:53:11 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:53:11 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:53:11 --> Utf8 Class Initialized
INFO - 2020-10-17 05:53:11 --> URI Class Initialized
INFO - 2020-10-17 05:53:11 --> Router Class Initialized
INFO - 2020-10-17 05:53:11 --> Output Class Initialized
INFO - 2020-10-17 05:53:11 --> Security Class Initialized
DEBUG - 2020-10-17 05:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:53:11 --> Input Class Initialized
INFO - 2020-10-17 05:53:11 --> Language Class Initialized
INFO - 2020-10-17 05:53:11 --> Language Class Initialized
INFO - 2020-10-17 05:53:11 --> Config Class Initialized
INFO - 2020-10-17 05:53:12 --> Loader Class Initialized
INFO - 2020-10-17 05:53:12 --> Helper loaded: url_helper
INFO - 2020-10-17 05:53:12 --> Helper loaded: file_helper
INFO - 2020-10-17 05:53:12 --> Helper loaded: form_helper
INFO - 2020-10-17 05:53:12 --> Helper loaded: my_helper
INFO - 2020-10-17 05:53:12 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:53:12 --> Controller Class Initialized
ERROR - 2020-10-17 05:53:12 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-10-17 05:53:12 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-17 05:54:06 --> Config Class Initialized
INFO - 2020-10-17 05:54:06 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:54:06 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:54:06 --> Utf8 Class Initialized
INFO - 2020-10-17 05:54:06 --> URI Class Initialized
INFO - 2020-10-17 05:54:06 --> Router Class Initialized
INFO - 2020-10-17 05:54:06 --> Output Class Initialized
INFO - 2020-10-17 05:54:06 --> Security Class Initialized
DEBUG - 2020-10-17 05:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:54:06 --> Input Class Initialized
INFO - 2020-10-17 05:54:06 --> Language Class Initialized
INFO - 2020-10-17 05:54:06 --> Language Class Initialized
INFO - 2020-10-17 05:54:06 --> Config Class Initialized
INFO - 2020-10-17 05:54:06 --> Loader Class Initialized
INFO - 2020-10-17 05:54:06 --> Helper loaded: url_helper
INFO - 2020-10-17 05:54:07 --> Helper loaded: file_helper
INFO - 2020-10-17 05:54:07 --> Helper loaded: form_helper
INFO - 2020-10-17 05:54:07 --> Helper loaded: my_helper
INFO - 2020-10-17 05:54:07 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:54:07 --> Controller Class Initialized
DEBUG - 2020-10-17 05:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-17 05:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:54:07 --> Final output sent to browser
DEBUG - 2020-10-17 05:54:07 --> Total execution time: 1.2219
INFO - 2020-10-17 05:54:07 --> Config Class Initialized
INFO - 2020-10-17 05:54:07 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:54:07 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:54:07 --> Utf8 Class Initialized
INFO - 2020-10-17 05:54:08 --> URI Class Initialized
INFO - 2020-10-17 05:54:08 --> Router Class Initialized
INFO - 2020-10-17 05:54:08 --> Output Class Initialized
INFO - 2020-10-17 05:54:08 --> Security Class Initialized
DEBUG - 2020-10-17 05:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:54:08 --> Input Class Initialized
INFO - 2020-10-17 05:54:08 --> Language Class Initialized
INFO - 2020-10-17 05:54:08 --> Language Class Initialized
INFO - 2020-10-17 05:54:08 --> Config Class Initialized
INFO - 2020-10-17 05:54:08 --> Loader Class Initialized
INFO - 2020-10-17 05:54:08 --> Helper loaded: url_helper
INFO - 2020-10-17 05:54:08 --> Helper loaded: file_helper
INFO - 2020-10-17 05:54:08 --> Helper loaded: form_helper
INFO - 2020-10-17 05:54:08 --> Helper loaded: my_helper
INFO - 2020-10-17 05:54:08 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:54:08 --> Controller Class Initialized
INFO - 2020-10-17 05:54:11 --> Config Class Initialized
INFO - 2020-10-17 05:54:12 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:54:12 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:54:12 --> Utf8 Class Initialized
INFO - 2020-10-17 05:54:12 --> URI Class Initialized
INFO - 2020-10-17 05:54:12 --> Router Class Initialized
INFO - 2020-10-17 05:54:12 --> Output Class Initialized
INFO - 2020-10-17 05:54:12 --> Security Class Initialized
DEBUG - 2020-10-17 05:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:54:12 --> Input Class Initialized
INFO - 2020-10-17 05:54:12 --> Language Class Initialized
INFO - 2020-10-17 05:54:12 --> Language Class Initialized
INFO - 2020-10-17 05:54:12 --> Config Class Initialized
INFO - 2020-10-17 05:54:12 --> Loader Class Initialized
INFO - 2020-10-17 05:54:12 --> Helper loaded: url_helper
INFO - 2020-10-17 05:54:12 --> Helper loaded: file_helper
INFO - 2020-10-17 05:54:12 --> Helper loaded: form_helper
INFO - 2020-10-17 05:54:12 --> Helper loaded: my_helper
INFO - 2020-10-17 05:54:13 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:54:13 --> Controller Class Initialized
DEBUG - 2020-10-17 05:54:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-17 05:54:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:54:13 --> Final output sent to browser
DEBUG - 2020-10-17 05:54:13 --> Total execution time: 1.4089
INFO - 2020-10-17 05:54:13 --> Config Class Initialized
INFO - 2020-10-17 05:54:13 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:54:13 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:54:13 --> Utf8 Class Initialized
INFO - 2020-10-17 05:54:13 --> URI Class Initialized
INFO - 2020-10-17 05:54:13 --> Router Class Initialized
INFO - 2020-10-17 05:54:13 --> Output Class Initialized
INFO - 2020-10-17 05:54:14 --> Security Class Initialized
DEBUG - 2020-10-17 05:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:54:14 --> Input Class Initialized
INFO - 2020-10-17 05:54:14 --> Language Class Initialized
INFO - 2020-10-17 05:54:14 --> Language Class Initialized
INFO - 2020-10-17 05:54:14 --> Config Class Initialized
INFO - 2020-10-17 05:54:14 --> Loader Class Initialized
INFO - 2020-10-17 05:54:14 --> Helper loaded: url_helper
INFO - 2020-10-17 05:54:14 --> Helper loaded: file_helper
INFO - 2020-10-17 05:54:14 --> Helper loaded: form_helper
INFO - 2020-10-17 05:54:14 --> Helper loaded: my_helper
INFO - 2020-10-17 05:54:14 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:54:14 --> Controller Class Initialized
INFO - 2020-10-17 05:55:35 --> Config Class Initialized
INFO - 2020-10-17 05:55:35 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:55:35 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:55:35 --> Utf8 Class Initialized
INFO - 2020-10-17 05:55:35 --> URI Class Initialized
INFO - 2020-10-17 05:55:35 --> Router Class Initialized
INFO - 2020-10-17 05:55:35 --> Output Class Initialized
INFO - 2020-10-17 05:55:35 --> Security Class Initialized
DEBUG - 2020-10-17 05:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:55:35 --> Input Class Initialized
INFO - 2020-10-17 05:55:35 --> Language Class Initialized
INFO - 2020-10-17 05:55:35 --> Language Class Initialized
INFO - 2020-10-17 05:55:35 --> Config Class Initialized
INFO - 2020-10-17 05:55:35 --> Loader Class Initialized
INFO - 2020-10-17 05:55:36 --> Helper loaded: url_helper
INFO - 2020-10-17 05:55:36 --> Helper loaded: file_helper
INFO - 2020-10-17 05:55:36 --> Helper loaded: form_helper
INFO - 2020-10-17 05:55:36 --> Helper loaded: my_helper
INFO - 2020-10-17 05:55:36 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:55:36 --> Controller Class Initialized
DEBUG - 2020-10-17 05:55:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-17 05:55:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:55:36 --> Final output sent to browser
DEBUG - 2020-10-17 05:55:36 --> Total execution time: 1.1427
INFO - 2020-10-17 05:59:34 --> Config Class Initialized
INFO - 2020-10-17 05:59:34 --> Hooks Class Initialized
DEBUG - 2020-10-17 05:59:34 --> UTF-8 Support Enabled
INFO - 2020-10-17 05:59:35 --> Utf8 Class Initialized
INFO - 2020-10-17 05:59:35 --> URI Class Initialized
INFO - 2020-10-17 05:59:35 --> Router Class Initialized
INFO - 2020-10-17 05:59:35 --> Output Class Initialized
INFO - 2020-10-17 05:59:35 --> Security Class Initialized
DEBUG - 2020-10-17 05:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 05:59:35 --> Input Class Initialized
INFO - 2020-10-17 05:59:35 --> Language Class Initialized
INFO - 2020-10-17 05:59:35 --> Language Class Initialized
INFO - 2020-10-17 05:59:35 --> Config Class Initialized
INFO - 2020-10-17 05:59:35 --> Loader Class Initialized
INFO - 2020-10-17 05:59:35 --> Helper loaded: url_helper
INFO - 2020-10-17 05:59:35 --> Helper loaded: file_helper
INFO - 2020-10-17 05:59:35 --> Helper loaded: form_helper
INFO - 2020-10-17 05:59:35 --> Helper loaded: my_helper
INFO - 2020-10-17 05:59:35 --> Database Driver Class Initialized
DEBUG - 2020-10-17 05:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 05:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 05:59:36 --> Controller Class Initialized
DEBUG - 2020-10-17 05:59:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-17 05:59:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 05:59:36 --> Final output sent to browser
DEBUG - 2020-10-17 05:59:36 --> Total execution time: 1.2919
INFO - 2020-10-17 06:01:31 --> Config Class Initialized
INFO - 2020-10-17 06:01:31 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:01:31 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:01:31 --> Utf8 Class Initialized
INFO - 2020-10-17 06:01:31 --> URI Class Initialized
INFO - 2020-10-17 06:01:31 --> Router Class Initialized
INFO - 2020-10-17 06:01:31 --> Output Class Initialized
INFO - 2020-10-17 06:01:31 --> Security Class Initialized
DEBUG - 2020-10-17 06:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:01:31 --> Input Class Initialized
INFO - 2020-10-17 06:01:31 --> Language Class Initialized
INFO - 2020-10-17 06:01:31 --> Language Class Initialized
INFO - 2020-10-17 06:01:31 --> Config Class Initialized
INFO - 2020-10-17 06:01:31 --> Loader Class Initialized
INFO - 2020-10-17 06:01:31 --> Helper loaded: url_helper
INFO - 2020-10-17 06:01:31 --> Helper loaded: file_helper
INFO - 2020-10-17 06:01:31 --> Helper loaded: form_helper
INFO - 2020-10-17 06:01:31 --> Helper loaded: my_helper
INFO - 2020-10-17 06:01:31 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:01:31 --> Controller Class Initialized
DEBUG - 2020-10-17 06:01:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-17 06:01:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:01:32 --> Final output sent to browser
DEBUG - 2020-10-17 06:01:32 --> Total execution time: 0.9238
INFO - 2020-10-17 06:01:32 --> Config Class Initialized
INFO - 2020-10-17 06:01:32 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:01:32 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:01:32 --> Utf8 Class Initialized
INFO - 2020-10-17 06:01:32 --> URI Class Initialized
INFO - 2020-10-17 06:01:32 --> Router Class Initialized
INFO - 2020-10-17 06:01:32 --> Output Class Initialized
INFO - 2020-10-17 06:01:32 --> Security Class Initialized
DEBUG - 2020-10-17 06:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:01:32 --> Input Class Initialized
INFO - 2020-10-17 06:01:32 --> Language Class Initialized
INFO - 2020-10-17 06:01:32 --> Language Class Initialized
INFO - 2020-10-17 06:01:32 --> Config Class Initialized
INFO - 2020-10-17 06:01:32 --> Loader Class Initialized
INFO - 2020-10-17 06:01:32 --> Helper loaded: url_helper
INFO - 2020-10-17 06:01:32 --> Helper loaded: file_helper
INFO - 2020-10-17 06:01:32 --> Helper loaded: form_helper
INFO - 2020-10-17 06:01:32 --> Helper loaded: my_helper
INFO - 2020-10-17 06:01:32 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:01:33 --> Controller Class Initialized
INFO - 2020-10-17 06:01:34 --> Config Class Initialized
INFO - 2020-10-17 06:01:34 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:01:34 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:01:34 --> Utf8 Class Initialized
INFO - 2020-10-17 06:01:34 --> URI Class Initialized
INFO - 2020-10-17 06:01:34 --> Router Class Initialized
INFO - 2020-10-17 06:01:34 --> Output Class Initialized
INFO - 2020-10-17 06:01:34 --> Security Class Initialized
DEBUG - 2020-10-17 06:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:01:34 --> Input Class Initialized
INFO - 2020-10-17 06:01:34 --> Language Class Initialized
INFO - 2020-10-17 06:01:34 --> Language Class Initialized
INFO - 2020-10-17 06:01:34 --> Config Class Initialized
INFO - 2020-10-17 06:01:35 --> Loader Class Initialized
INFO - 2020-10-17 06:01:35 --> Helper loaded: url_helper
INFO - 2020-10-17 06:01:35 --> Helper loaded: file_helper
INFO - 2020-10-17 06:01:35 --> Helper loaded: form_helper
INFO - 2020-10-17 06:01:35 --> Helper loaded: my_helper
INFO - 2020-10-17 06:01:35 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:01:35 --> Controller Class Initialized
INFO - 2020-10-17 06:01:35 --> Final output sent to browser
DEBUG - 2020-10-17 06:01:35 --> Total execution time: 0.7490
INFO - 2020-10-17 06:02:00 --> Config Class Initialized
INFO - 2020-10-17 06:02:00 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:02:00 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:02:00 --> Utf8 Class Initialized
INFO - 2020-10-17 06:02:00 --> URI Class Initialized
INFO - 2020-10-17 06:02:00 --> Router Class Initialized
INFO - 2020-10-17 06:02:00 --> Output Class Initialized
INFO - 2020-10-17 06:02:00 --> Security Class Initialized
DEBUG - 2020-10-17 06:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:02:00 --> Input Class Initialized
INFO - 2020-10-17 06:02:00 --> Language Class Initialized
INFO - 2020-10-17 06:02:00 --> Language Class Initialized
INFO - 2020-10-17 06:02:00 --> Config Class Initialized
INFO - 2020-10-17 06:02:00 --> Loader Class Initialized
INFO - 2020-10-17 06:02:00 --> Helper loaded: url_helper
INFO - 2020-10-17 06:02:00 --> Helper loaded: file_helper
INFO - 2020-10-17 06:02:00 --> Helper loaded: form_helper
INFO - 2020-10-17 06:02:00 --> Helper loaded: my_helper
INFO - 2020-10-17 06:02:00 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:02:00 --> Controller Class Initialized
INFO - 2020-10-17 06:02:00 --> Final output sent to browser
DEBUG - 2020-10-17 06:02:01 --> Total execution time: 0.9698
INFO - 2020-10-17 06:02:01 --> Config Class Initialized
INFO - 2020-10-17 06:02:01 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:02:01 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:02:01 --> Utf8 Class Initialized
INFO - 2020-10-17 06:02:01 --> URI Class Initialized
INFO - 2020-10-17 06:02:01 --> Router Class Initialized
INFO - 2020-10-17 06:02:01 --> Output Class Initialized
INFO - 2020-10-17 06:02:01 --> Security Class Initialized
DEBUG - 2020-10-17 06:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:02:01 --> Input Class Initialized
INFO - 2020-10-17 06:02:01 --> Language Class Initialized
INFO - 2020-10-17 06:02:01 --> Language Class Initialized
INFO - 2020-10-17 06:02:01 --> Config Class Initialized
INFO - 2020-10-17 06:02:01 --> Loader Class Initialized
INFO - 2020-10-17 06:02:01 --> Helper loaded: url_helper
INFO - 2020-10-17 06:02:01 --> Helper loaded: file_helper
INFO - 2020-10-17 06:02:02 --> Helper loaded: form_helper
INFO - 2020-10-17 06:02:02 --> Helper loaded: my_helper
INFO - 2020-10-17 06:02:02 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:02:02 --> Controller Class Initialized
INFO - 2020-10-17 06:02:42 --> Config Class Initialized
INFO - 2020-10-17 06:02:42 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:02:42 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:02:42 --> Utf8 Class Initialized
INFO - 2020-10-17 06:02:42 --> URI Class Initialized
INFO - 2020-10-17 06:02:42 --> Router Class Initialized
INFO - 2020-10-17 06:02:42 --> Output Class Initialized
INFO - 2020-10-17 06:02:42 --> Security Class Initialized
DEBUG - 2020-10-17 06:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:02:42 --> Input Class Initialized
INFO - 2020-10-17 06:02:42 --> Language Class Initialized
INFO - 2020-10-17 06:02:42 --> Language Class Initialized
INFO - 2020-10-17 06:02:43 --> Config Class Initialized
INFO - 2020-10-17 06:02:43 --> Loader Class Initialized
INFO - 2020-10-17 06:02:43 --> Helper loaded: url_helper
INFO - 2020-10-17 06:02:43 --> Helper loaded: file_helper
INFO - 2020-10-17 06:02:43 --> Helper loaded: form_helper
INFO - 2020-10-17 06:02:43 --> Helper loaded: my_helper
INFO - 2020-10-17 06:02:43 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:02:43 --> Controller Class Initialized
INFO - 2020-10-17 06:02:43 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:02:43 --> Config Class Initialized
INFO - 2020-10-17 06:02:43 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:02:43 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:02:43 --> Utf8 Class Initialized
INFO - 2020-10-17 06:02:43 --> URI Class Initialized
INFO - 2020-10-17 06:02:43 --> Router Class Initialized
INFO - 2020-10-17 06:02:44 --> Output Class Initialized
INFO - 2020-10-17 06:02:44 --> Security Class Initialized
DEBUG - 2020-10-17 06:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:02:44 --> Input Class Initialized
INFO - 2020-10-17 06:02:44 --> Language Class Initialized
INFO - 2020-10-17 06:02:44 --> Language Class Initialized
INFO - 2020-10-17 06:02:44 --> Config Class Initialized
INFO - 2020-10-17 06:02:44 --> Loader Class Initialized
INFO - 2020-10-17 06:02:44 --> Helper loaded: url_helper
INFO - 2020-10-17 06:02:44 --> Helper loaded: file_helper
INFO - 2020-10-17 06:02:44 --> Helper loaded: form_helper
INFO - 2020-10-17 06:02:44 --> Helper loaded: my_helper
INFO - 2020-10-17 06:02:44 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:02:44 --> Controller Class Initialized
DEBUG - 2020-10-17 06:02:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 06:02:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:02:45 --> Final output sent to browser
DEBUG - 2020-10-17 06:02:45 --> Total execution time: 1.3222
INFO - 2020-10-17 06:02:51 --> Config Class Initialized
INFO - 2020-10-17 06:02:51 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:02:51 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:02:51 --> Utf8 Class Initialized
INFO - 2020-10-17 06:02:51 --> URI Class Initialized
INFO - 2020-10-17 06:02:51 --> Router Class Initialized
INFO - 2020-10-17 06:02:51 --> Output Class Initialized
INFO - 2020-10-17 06:02:51 --> Security Class Initialized
DEBUG - 2020-10-17 06:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:02:51 --> Input Class Initialized
INFO - 2020-10-17 06:02:51 --> Language Class Initialized
INFO - 2020-10-17 06:02:51 --> Language Class Initialized
INFO - 2020-10-17 06:02:51 --> Config Class Initialized
INFO - 2020-10-17 06:02:51 --> Loader Class Initialized
INFO - 2020-10-17 06:02:51 --> Helper loaded: url_helper
INFO - 2020-10-17 06:02:51 --> Helper loaded: file_helper
INFO - 2020-10-17 06:02:51 --> Helper loaded: form_helper
INFO - 2020-10-17 06:02:51 --> Helper loaded: my_helper
INFO - 2020-10-17 06:02:51 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:02:52 --> Controller Class Initialized
INFO - 2020-10-17 06:02:52 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:02:52 --> Final output sent to browser
DEBUG - 2020-10-17 06:02:52 --> Total execution time: 1.3070
INFO - 2020-10-17 06:02:53 --> Config Class Initialized
INFO - 2020-10-17 06:02:53 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:02:53 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:02:53 --> Utf8 Class Initialized
INFO - 2020-10-17 06:02:53 --> URI Class Initialized
INFO - 2020-10-17 06:02:53 --> Router Class Initialized
INFO - 2020-10-17 06:02:53 --> Output Class Initialized
INFO - 2020-10-17 06:02:53 --> Security Class Initialized
DEBUG - 2020-10-17 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:02:54 --> Input Class Initialized
INFO - 2020-10-17 06:02:54 --> Language Class Initialized
INFO - 2020-10-17 06:02:54 --> Language Class Initialized
INFO - 2020-10-17 06:02:54 --> Config Class Initialized
INFO - 2020-10-17 06:02:54 --> Loader Class Initialized
INFO - 2020-10-17 06:02:54 --> Helper loaded: url_helper
INFO - 2020-10-17 06:02:54 --> Helper loaded: file_helper
INFO - 2020-10-17 06:02:54 --> Helper loaded: form_helper
INFO - 2020-10-17 06:02:54 --> Helper loaded: my_helper
INFO - 2020-10-17 06:02:54 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:02:54 --> Controller Class Initialized
DEBUG - 2020-10-17 06:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 06:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:02:54 --> Final output sent to browser
DEBUG - 2020-10-17 06:02:55 --> Total execution time: 1.4367
INFO - 2020-10-17 06:02:57 --> Config Class Initialized
INFO - 2020-10-17 06:02:57 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:02:57 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:02:57 --> Utf8 Class Initialized
INFO - 2020-10-17 06:02:57 --> URI Class Initialized
INFO - 2020-10-17 06:02:57 --> Router Class Initialized
INFO - 2020-10-17 06:02:57 --> Output Class Initialized
INFO - 2020-10-17 06:02:58 --> Security Class Initialized
DEBUG - 2020-10-17 06:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:02:58 --> Input Class Initialized
INFO - 2020-10-17 06:02:58 --> Language Class Initialized
INFO - 2020-10-17 06:02:58 --> Language Class Initialized
INFO - 2020-10-17 06:02:58 --> Config Class Initialized
INFO - 2020-10-17 06:02:58 --> Loader Class Initialized
INFO - 2020-10-17 06:02:58 --> Helper loaded: url_helper
INFO - 2020-10-17 06:02:58 --> Helper loaded: file_helper
INFO - 2020-10-17 06:02:58 --> Helper loaded: form_helper
INFO - 2020-10-17 06:02:58 --> Helper loaded: my_helper
INFO - 2020-10-17 06:02:58 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:02:58 --> Controller Class Initialized
INFO - 2020-10-17 06:02:58 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:02:58 --> Config Class Initialized
INFO - 2020-10-17 06:02:58 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:02:59 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:02:59 --> Utf8 Class Initialized
INFO - 2020-10-17 06:02:59 --> URI Class Initialized
INFO - 2020-10-17 06:02:59 --> Router Class Initialized
INFO - 2020-10-17 06:02:59 --> Output Class Initialized
INFO - 2020-10-17 06:02:59 --> Security Class Initialized
DEBUG - 2020-10-17 06:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:02:59 --> Input Class Initialized
INFO - 2020-10-17 06:02:59 --> Language Class Initialized
INFO - 2020-10-17 06:02:59 --> Language Class Initialized
INFO - 2020-10-17 06:02:59 --> Config Class Initialized
INFO - 2020-10-17 06:02:59 --> Loader Class Initialized
INFO - 2020-10-17 06:02:59 --> Helper loaded: url_helper
INFO - 2020-10-17 06:02:59 --> Helper loaded: file_helper
INFO - 2020-10-17 06:02:59 --> Helper loaded: form_helper
INFO - 2020-10-17 06:02:59 --> Helper loaded: my_helper
INFO - 2020-10-17 06:02:59 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:00 --> Controller Class Initialized
DEBUG - 2020-10-17 06:03:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 06:03:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:03:00 --> Final output sent to browser
DEBUG - 2020-10-17 06:03:00 --> Total execution time: 1.4187
INFO - 2020-10-17 06:03:09 --> Config Class Initialized
INFO - 2020-10-17 06:03:09 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:03:09 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:03:09 --> Utf8 Class Initialized
INFO - 2020-10-17 06:03:09 --> URI Class Initialized
INFO - 2020-10-17 06:03:09 --> Router Class Initialized
INFO - 2020-10-17 06:03:09 --> Output Class Initialized
INFO - 2020-10-17 06:03:09 --> Security Class Initialized
DEBUG - 2020-10-17 06:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:03:09 --> Input Class Initialized
INFO - 2020-10-17 06:03:10 --> Language Class Initialized
INFO - 2020-10-17 06:03:10 --> Language Class Initialized
INFO - 2020-10-17 06:03:10 --> Config Class Initialized
INFO - 2020-10-17 06:03:10 --> Loader Class Initialized
INFO - 2020-10-17 06:03:10 --> Helper loaded: url_helper
INFO - 2020-10-17 06:03:10 --> Helper loaded: file_helper
INFO - 2020-10-17 06:03:10 --> Helper loaded: form_helper
INFO - 2020-10-17 06:03:10 --> Helper loaded: my_helper
INFO - 2020-10-17 06:03:10 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:10 --> Controller Class Initialized
INFO - 2020-10-17 06:03:10 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:03:10 --> Final output sent to browser
DEBUG - 2020-10-17 06:03:10 --> Total execution time: 1.0615
INFO - 2020-10-17 06:03:12 --> Config Class Initialized
INFO - 2020-10-17 06:03:12 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:03:12 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:03:12 --> Utf8 Class Initialized
INFO - 2020-10-17 06:03:12 --> URI Class Initialized
INFO - 2020-10-17 06:03:12 --> Router Class Initialized
INFO - 2020-10-17 06:03:12 --> Output Class Initialized
INFO - 2020-10-17 06:03:12 --> Security Class Initialized
DEBUG - 2020-10-17 06:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:03:12 --> Input Class Initialized
INFO - 2020-10-17 06:03:12 --> Language Class Initialized
INFO - 2020-10-17 06:03:12 --> Language Class Initialized
INFO - 2020-10-17 06:03:12 --> Config Class Initialized
INFO - 2020-10-17 06:03:12 --> Loader Class Initialized
INFO - 2020-10-17 06:03:12 --> Helper loaded: url_helper
INFO - 2020-10-17 06:03:12 --> Helper loaded: file_helper
INFO - 2020-10-17 06:03:12 --> Helper loaded: form_helper
INFO - 2020-10-17 06:03:12 --> Helper loaded: my_helper
INFO - 2020-10-17 06:03:12 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:12 --> Controller Class Initialized
DEBUG - 2020-10-17 06:03:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 06:03:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:03:13 --> Final output sent to browser
DEBUG - 2020-10-17 06:03:13 --> Total execution time: 0.9446
INFO - 2020-10-17 06:03:15 --> Config Class Initialized
INFO - 2020-10-17 06:03:15 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:03:15 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:03:15 --> Utf8 Class Initialized
INFO - 2020-10-17 06:03:15 --> URI Class Initialized
INFO - 2020-10-17 06:03:15 --> Router Class Initialized
INFO - 2020-10-17 06:03:15 --> Output Class Initialized
INFO - 2020-10-17 06:03:15 --> Security Class Initialized
DEBUG - 2020-10-17 06:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:03:15 --> Input Class Initialized
INFO - 2020-10-17 06:03:15 --> Language Class Initialized
INFO - 2020-10-17 06:03:15 --> Language Class Initialized
INFO - 2020-10-17 06:03:16 --> Config Class Initialized
INFO - 2020-10-17 06:03:16 --> Loader Class Initialized
INFO - 2020-10-17 06:03:16 --> Helper loaded: url_helper
INFO - 2020-10-17 06:03:16 --> Helper loaded: file_helper
INFO - 2020-10-17 06:03:16 --> Helper loaded: form_helper
INFO - 2020-10-17 06:03:16 --> Helper loaded: my_helper
INFO - 2020-10-17 06:03:16 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:16 --> Controller Class Initialized
DEBUG - 2020-10-17 06:03:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-17 06:03:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:03:16 --> Final output sent to browser
DEBUG - 2020-10-17 06:03:16 --> Total execution time: 1.2627
INFO - 2020-10-17 06:03:16 --> Config Class Initialized
INFO - 2020-10-17 06:03:16 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:03:17 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:03:17 --> Utf8 Class Initialized
INFO - 2020-10-17 06:03:17 --> URI Class Initialized
INFO - 2020-10-17 06:03:17 --> Router Class Initialized
INFO - 2020-10-17 06:03:17 --> Output Class Initialized
INFO - 2020-10-17 06:03:17 --> Security Class Initialized
DEBUG - 2020-10-17 06:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:03:17 --> Input Class Initialized
INFO - 2020-10-17 06:03:17 --> Language Class Initialized
INFO - 2020-10-17 06:03:17 --> Language Class Initialized
INFO - 2020-10-17 06:03:17 --> Config Class Initialized
INFO - 2020-10-17 06:03:17 --> Loader Class Initialized
INFO - 2020-10-17 06:03:17 --> Helper loaded: url_helper
INFO - 2020-10-17 06:03:17 --> Helper loaded: file_helper
INFO - 2020-10-17 06:03:17 --> Helper loaded: form_helper
INFO - 2020-10-17 06:03:17 --> Helper loaded: my_helper
INFO - 2020-10-17 06:03:17 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:17 --> Controller Class Initialized
INFO - 2020-10-17 06:03:28 --> Config Class Initialized
INFO - 2020-10-17 06:03:28 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:03:28 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:03:28 --> Utf8 Class Initialized
INFO - 2020-10-17 06:03:28 --> URI Class Initialized
INFO - 2020-10-17 06:03:28 --> Router Class Initialized
INFO - 2020-10-17 06:03:28 --> Output Class Initialized
INFO - 2020-10-17 06:03:28 --> Security Class Initialized
DEBUG - 2020-10-17 06:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:03:28 --> Input Class Initialized
INFO - 2020-10-17 06:03:29 --> Language Class Initialized
INFO - 2020-10-17 06:03:29 --> Language Class Initialized
INFO - 2020-10-17 06:03:29 --> Config Class Initialized
INFO - 2020-10-17 06:03:29 --> Loader Class Initialized
INFO - 2020-10-17 06:03:29 --> Helper loaded: url_helper
INFO - 2020-10-17 06:03:29 --> Helper loaded: file_helper
INFO - 2020-10-17 06:03:29 --> Helper loaded: form_helper
INFO - 2020-10-17 06:03:29 --> Helper loaded: my_helper
INFO - 2020-10-17 06:03:29 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:29 --> Controller Class Initialized
INFO - 2020-10-17 06:03:29 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:03:29 --> Config Class Initialized
INFO - 2020-10-17 06:03:29 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:03:29 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:03:30 --> Utf8 Class Initialized
INFO - 2020-10-17 06:03:30 --> URI Class Initialized
INFO - 2020-10-17 06:03:30 --> Router Class Initialized
INFO - 2020-10-17 06:03:30 --> Output Class Initialized
INFO - 2020-10-17 06:03:30 --> Security Class Initialized
DEBUG - 2020-10-17 06:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:03:30 --> Input Class Initialized
INFO - 2020-10-17 06:03:30 --> Language Class Initialized
INFO - 2020-10-17 06:03:30 --> Language Class Initialized
INFO - 2020-10-17 06:03:30 --> Config Class Initialized
INFO - 2020-10-17 06:03:30 --> Loader Class Initialized
INFO - 2020-10-17 06:03:30 --> Helper loaded: url_helper
INFO - 2020-10-17 06:03:30 --> Helper loaded: file_helper
INFO - 2020-10-17 06:03:30 --> Helper loaded: form_helper
INFO - 2020-10-17 06:03:30 --> Helper loaded: my_helper
INFO - 2020-10-17 06:03:30 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:31 --> Controller Class Initialized
DEBUG - 2020-10-17 06:03:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 06:03:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:03:31 --> Final output sent to browser
DEBUG - 2020-10-17 06:03:31 --> Total execution time: 1.4325
INFO - 2020-10-17 06:03:50 --> Config Class Initialized
INFO - 2020-10-17 06:03:50 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:03:51 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:03:51 --> Utf8 Class Initialized
INFO - 2020-10-17 06:03:51 --> URI Class Initialized
INFO - 2020-10-17 06:03:51 --> Router Class Initialized
INFO - 2020-10-17 06:03:51 --> Output Class Initialized
INFO - 2020-10-17 06:03:51 --> Security Class Initialized
DEBUG - 2020-10-17 06:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:03:51 --> Input Class Initialized
INFO - 2020-10-17 06:03:51 --> Language Class Initialized
INFO - 2020-10-17 06:03:51 --> Language Class Initialized
INFO - 2020-10-17 06:03:51 --> Config Class Initialized
INFO - 2020-10-17 06:03:51 --> Loader Class Initialized
INFO - 2020-10-17 06:03:51 --> Helper loaded: url_helper
INFO - 2020-10-17 06:03:51 --> Helper loaded: file_helper
INFO - 2020-10-17 06:03:52 --> Helper loaded: form_helper
INFO - 2020-10-17 06:03:52 --> Helper loaded: my_helper
INFO - 2020-10-17 06:03:52 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:52 --> Controller Class Initialized
INFO - 2020-10-17 06:03:52 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:03:52 --> Final output sent to browser
DEBUG - 2020-10-17 06:03:52 --> Total execution time: 1.5125
INFO - 2020-10-17 06:03:53 --> Config Class Initialized
INFO - 2020-10-17 06:03:53 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:03:53 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:03:53 --> Utf8 Class Initialized
INFO - 2020-10-17 06:03:53 --> URI Class Initialized
INFO - 2020-10-17 06:03:53 --> Router Class Initialized
INFO - 2020-10-17 06:03:53 --> Output Class Initialized
INFO - 2020-10-17 06:03:53 --> Security Class Initialized
DEBUG - 2020-10-17 06:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:03:53 --> Input Class Initialized
INFO - 2020-10-17 06:03:53 --> Language Class Initialized
INFO - 2020-10-17 06:03:53 --> Language Class Initialized
INFO - 2020-10-17 06:03:53 --> Config Class Initialized
INFO - 2020-10-17 06:03:53 --> Loader Class Initialized
INFO - 2020-10-17 06:03:53 --> Helper loaded: url_helper
INFO - 2020-10-17 06:03:53 --> Helper loaded: file_helper
INFO - 2020-10-17 06:03:54 --> Helper loaded: form_helper
INFO - 2020-10-17 06:03:54 --> Helper loaded: my_helper
INFO - 2020-10-17 06:03:54 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:54 --> Controller Class Initialized
DEBUG - 2020-10-17 06:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 06:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:03:54 --> Final output sent to browser
DEBUG - 2020-10-17 06:03:54 --> Total execution time: 1.2201
INFO - 2020-10-17 06:03:58 --> Config Class Initialized
INFO - 2020-10-17 06:03:58 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:03:58 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:03:58 --> Utf8 Class Initialized
INFO - 2020-10-17 06:03:58 --> URI Class Initialized
INFO - 2020-10-17 06:03:58 --> Router Class Initialized
INFO - 2020-10-17 06:03:58 --> Output Class Initialized
INFO - 2020-10-17 06:03:58 --> Security Class Initialized
DEBUG - 2020-10-17 06:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:03:58 --> Input Class Initialized
INFO - 2020-10-17 06:03:58 --> Language Class Initialized
INFO - 2020-10-17 06:03:58 --> Language Class Initialized
INFO - 2020-10-17 06:03:58 --> Config Class Initialized
INFO - 2020-10-17 06:03:58 --> Loader Class Initialized
INFO - 2020-10-17 06:03:58 --> Helper loaded: url_helper
INFO - 2020-10-17 06:03:58 --> Helper loaded: file_helper
INFO - 2020-10-17 06:03:58 --> Helper loaded: form_helper
INFO - 2020-10-17 06:03:59 --> Helper loaded: my_helper
INFO - 2020-10-17 06:03:59 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:03:59 --> Controller Class Initialized
DEBUG - 2020-10-17 06:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-10-17 06:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:03:59 --> Final output sent to browser
DEBUG - 2020-10-17 06:03:59 --> Total execution time: 1.3984
INFO - 2020-10-17 06:04:18 --> Config Class Initialized
INFO - 2020-10-17 06:04:18 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:04:18 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:04:18 --> Utf8 Class Initialized
INFO - 2020-10-17 06:04:18 --> URI Class Initialized
INFO - 2020-10-17 06:04:18 --> Router Class Initialized
INFO - 2020-10-17 06:04:18 --> Output Class Initialized
INFO - 2020-10-17 06:04:18 --> Security Class Initialized
DEBUG - 2020-10-17 06:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:04:18 --> Input Class Initialized
INFO - 2020-10-17 06:04:18 --> Language Class Initialized
INFO - 2020-10-17 06:04:18 --> Language Class Initialized
INFO - 2020-10-17 06:04:18 --> Config Class Initialized
INFO - 2020-10-17 06:04:18 --> Loader Class Initialized
INFO - 2020-10-17 06:04:18 --> Helper loaded: url_helper
INFO - 2020-10-17 06:04:18 --> Helper loaded: file_helper
INFO - 2020-10-17 06:04:18 --> Helper loaded: form_helper
INFO - 2020-10-17 06:04:18 --> Helper loaded: my_helper
INFO - 2020-10-17 06:04:19 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:04:19 --> Controller Class Initialized
INFO - 2020-10-17 06:04:37 --> Config Class Initialized
INFO - 2020-10-17 06:04:37 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:04:37 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:04:37 --> Utf8 Class Initialized
INFO - 2020-10-17 06:04:37 --> URI Class Initialized
INFO - 2020-10-17 06:04:37 --> Router Class Initialized
INFO - 2020-10-17 06:04:37 --> Output Class Initialized
INFO - 2020-10-17 06:04:37 --> Security Class Initialized
DEBUG - 2020-10-17 06:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:04:37 --> Input Class Initialized
INFO - 2020-10-17 06:04:37 --> Language Class Initialized
INFO - 2020-10-17 06:04:37 --> Language Class Initialized
INFO - 2020-10-17 06:04:37 --> Config Class Initialized
INFO - 2020-10-17 06:04:37 --> Loader Class Initialized
INFO - 2020-10-17 06:04:38 --> Helper loaded: url_helper
INFO - 2020-10-17 06:04:38 --> Helper loaded: file_helper
INFO - 2020-10-17 06:04:38 --> Helper loaded: form_helper
INFO - 2020-10-17 06:04:38 --> Helper loaded: my_helper
INFO - 2020-10-17 06:04:38 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:04:38 --> Controller Class Initialized
INFO - 2020-10-17 06:04:38 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:04:38 --> Config Class Initialized
INFO - 2020-10-17 06:04:38 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:04:38 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:04:38 --> Utf8 Class Initialized
INFO - 2020-10-17 06:04:38 --> URI Class Initialized
INFO - 2020-10-17 06:04:38 --> Router Class Initialized
INFO - 2020-10-17 06:04:38 --> Output Class Initialized
INFO - 2020-10-17 06:04:38 --> Security Class Initialized
DEBUG - 2020-10-17 06:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:04:39 --> Input Class Initialized
INFO - 2020-10-17 06:04:39 --> Language Class Initialized
INFO - 2020-10-17 06:04:39 --> Language Class Initialized
INFO - 2020-10-17 06:04:39 --> Config Class Initialized
INFO - 2020-10-17 06:04:39 --> Loader Class Initialized
INFO - 2020-10-17 06:04:39 --> Helper loaded: url_helper
INFO - 2020-10-17 06:04:39 --> Helper loaded: file_helper
INFO - 2020-10-17 06:04:39 --> Helper loaded: form_helper
INFO - 2020-10-17 06:04:39 --> Helper loaded: my_helper
INFO - 2020-10-17 06:04:39 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:04:39 --> Controller Class Initialized
DEBUG - 2020-10-17 06:04:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 06:04:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:04:39 --> Final output sent to browser
DEBUG - 2020-10-17 06:04:39 --> Total execution time: 1.2228
INFO - 2020-10-17 06:04:46 --> Config Class Initialized
INFO - 2020-10-17 06:04:46 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:04:46 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:04:46 --> Utf8 Class Initialized
INFO - 2020-10-17 06:04:46 --> URI Class Initialized
INFO - 2020-10-17 06:04:46 --> Router Class Initialized
INFO - 2020-10-17 06:04:46 --> Output Class Initialized
INFO - 2020-10-17 06:04:46 --> Security Class Initialized
DEBUG - 2020-10-17 06:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:04:46 --> Input Class Initialized
INFO - 2020-10-17 06:04:46 --> Language Class Initialized
INFO - 2020-10-17 06:04:46 --> Language Class Initialized
INFO - 2020-10-17 06:04:46 --> Config Class Initialized
INFO - 2020-10-17 06:04:46 --> Loader Class Initialized
INFO - 2020-10-17 06:04:46 --> Helper loaded: url_helper
INFO - 2020-10-17 06:04:46 --> Helper loaded: file_helper
INFO - 2020-10-17 06:04:47 --> Helper loaded: form_helper
INFO - 2020-10-17 06:04:47 --> Helper loaded: my_helper
INFO - 2020-10-17 06:04:47 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:04:47 --> Controller Class Initialized
INFO - 2020-10-17 06:04:47 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:04:47 --> Final output sent to browser
DEBUG - 2020-10-17 06:04:47 --> Total execution time: 1.1629
INFO - 2020-10-17 06:04:48 --> Config Class Initialized
INFO - 2020-10-17 06:04:48 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:04:49 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:04:49 --> Utf8 Class Initialized
INFO - 2020-10-17 06:04:49 --> URI Class Initialized
INFO - 2020-10-17 06:04:49 --> Router Class Initialized
INFO - 2020-10-17 06:04:49 --> Output Class Initialized
INFO - 2020-10-17 06:04:49 --> Security Class Initialized
DEBUG - 2020-10-17 06:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:04:49 --> Input Class Initialized
INFO - 2020-10-17 06:04:49 --> Language Class Initialized
INFO - 2020-10-17 06:04:49 --> Language Class Initialized
INFO - 2020-10-17 06:04:49 --> Config Class Initialized
INFO - 2020-10-17 06:04:49 --> Loader Class Initialized
INFO - 2020-10-17 06:04:49 --> Helper loaded: url_helper
INFO - 2020-10-17 06:04:49 --> Helper loaded: file_helper
INFO - 2020-10-17 06:04:49 --> Helper loaded: form_helper
INFO - 2020-10-17 06:04:49 --> Helper loaded: my_helper
INFO - 2020-10-17 06:04:49 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:04:49 --> Controller Class Initialized
DEBUG - 2020-10-17 06:04:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 06:04:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:04:49 --> Final output sent to browser
DEBUG - 2020-10-17 06:04:49 --> Total execution time: 0.9438
INFO - 2020-10-17 06:04:50 --> Config Class Initialized
INFO - 2020-10-17 06:04:50 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:04:50 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:04:50 --> Utf8 Class Initialized
INFO - 2020-10-17 06:04:50 --> URI Class Initialized
INFO - 2020-10-17 06:04:50 --> Router Class Initialized
INFO - 2020-10-17 06:04:50 --> Output Class Initialized
INFO - 2020-10-17 06:04:51 --> Security Class Initialized
DEBUG - 2020-10-17 06:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:04:51 --> Input Class Initialized
INFO - 2020-10-17 06:04:51 --> Language Class Initialized
INFO - 2020-10-17 06:04:51 --> Language Class Initialized
INFO - 2020-10-17 06:04:51 --> Config Class Initialized
INFO - 2020-10-17 06:04:51 --> Loader Class Initialized
INFO - 2020-10-17 06:04:51 --> Helper loaded: url_helper
INFO - 2020-10-17 06:04:51 --> Helper loaded: file_helper
INFO - 2020-10-17 06:04:51 --> Helper loaded: form_helper
INFO - 2020-10-17 06:04:51 --> Helper loaded: my_helper
INFO - 2020-10-17 06:04:51 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:04:51 --> Controller Class Initialized
INFO - 2020-10-17 06:04:51 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:04:51 --> Config Class Initialized
INFO - 2020-10-17 06:04:51 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:04:51 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:04:52 --> Utf8 Class Initialized
INFO - 2020-10-17 06:04:52 --> URI Class Initialized
INFO - 2020-10-17 06:04:52 --> Router Class Initialized
INFO - 2020-10-17 06:04:52 --> Output Class Initialized
INFO - 2020-10-17 06:04:52 --> Security Class Initialized
DEBUG - 2020-10-17 06:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:04:52 --> Input Class Initialized
INFO - 2020-10-17 06:04:52 --> Language Class Initialized
INFO - 2020-10-17 06:04:52 --> Language Class Initialized
INFO - 2020-10-17 06:04:52 --> Config Class Initialized
INFO - 2020-10-17 06:04:52 --> Loader Class Initialized
INFO - 2020-10-17 06:04:52 --> Helper loaded: url_helper
INFO - 2020-10-17 06:04:52 --> Helper loaded: file_helper
INFO - 2020-10-17 06:04:52 --> Helper loaded: form_helper
INFO - 2020-10-17 06:04:52 --> Helper loaded: my_helper
INFO - 2020-10-17 06:04:52 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:04:53 --> Controller Class Initialized
DEBUG - 2020-10-17 06:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-17 06:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:04:53 --> Final output sent to browser
DEBUG - 2020-10-17 06:04:53 --> Total execution time: 1.4127
INFO - 2020-10-17 06:20:28 --> Config Class Initialized
INFO - 2020-10-17 06:20:28 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:20:28 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:20:28 --> Utf8 Class Initialized
INFO - 2020-10-17 06:20:28 --> URI Class Initialized
INFO - 2020-10-17 06:20:28 --> Router Class Initialized
INFO - 2020-10-17 06:20:28 --> Output Class Initialized
INFO - 2020-10-17 06:20:28 --> Security Class Initialized
DEBUG - 2020-10-17 06:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:20:29 --> Input Class Initialized
INFO - 2020-10-17 06:20:29 --> Language Class Initialized
INFO - 2020-10-17 06:20:29 --> Language Class Initialized
INFO - 2020-10-17 06:20:29 --> Config Class Initialized
INFO - 2020-10-17 06:20:29 --> Loader Class Initialized
INFO - 2020-10-17 06:20:29 --> Helper loaded: url_helper
INFO - 2020-10-17 06:20:29 --> Helper loaded: file_helper
INFO - 2020-10-17 06:20:29 --> Helper loaded: form_helper
INFO - 2020-10-17 06:20:29 --> Helper loaded: my_helper
INFO - 2020-10-17 06:20:29 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:20:29 --> Controller Class Initialized
INFO - 2020-10-17 06:20:29 --> Helper loaded: cookie_helper
INFO - 2020-10-17 06:20:29 --> Final output sent to browser
DEBUG - 2020-10-17 06:20:29 --> Total execution time: 0.6534
INFO - 2020-10-17 06:20:30 --> Config Class Initialized
INFO - 2020-10-17 06:20:30 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:20:30 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:20:30 --> Utf8 Class Initialized
INFO - 2020-10-17 06:20:30 --> URI Class Initialized
INFO - 2020-10-17 06:20:30 --> Router Class Initialized
INFO - 2020-10-17 06:20:31 --> Output Class Initialized
INFO - 2020-10-17 06:20:31 --> Security Class Initialized
DEBUG - 2020-10-17 06:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:20:31 --> Input Class Initialized
INFO - 2020-10-17 06:20:31 --> Language Class Initialized
INFO - 2020-10-17 06:20:31 --> Language Class Initialized
INFO - 2020-10-17 06:20:31 --> Config Class Initialized
INFO - 2020-10-17 06:20:31 --> Loader Class Initialized
INFO - 2020-10-17 06:20:31 --> Helper loaded: url_helper
INFO - 2020-10-17 06:20:31 --> Helper loaded: file_helper
INFO - 2020-10-17 06:20:31 --> Helper loaded: form_helper
INFO - 2020-10-17 06:20:31 --> Helper loaded: my_helper
INFO - 2020-10-17 06:20:31 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:20:32 --> Controller Class Initialized
DEBUG - 2020-10-17 06:20:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-17 06:20:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:20:32 --> Final output sent to browser
DEBUG - 2020-10-17 06:20:32 --> Total execution time: 1.4237
INFO - 2020-10-17 06:20:35 --> Config Class Initialized
INFO - 2020-10-17 06:20:35 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:20:35 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:20:35 --> Utf8 Class Initialized
INFO - 2020-10-17 06:20:35 --> URI Class Initialized
INFO - 2020-10-17 06:20:35 --> Router Class Initialized
INFO - 2020-10-17 06:20:35 --> Output Class Initialized
INFO - 2020-10-17 06:20:35 --> Security Class Initialized
DEBUG - 2020-10-17 06:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:20:35 --> Input Class Initialized
INFO - 2020-10-17 06:20:35 --> Language Class Initialized
INFO - 2020-10-17 06:20:35 --> Language Class Initialized
INFO - 2020-10-17 06:20:35 --> Config Class Initialized
INFO - 2020-10-17 06:20:35 --> Loader Class Initialized
INFO - 2020-10-17 06:20:35 --> Helper loaded: url_helper
INFO - 2020-10-17 06:20:35 --> Helper loaded: file_helper
INFO - 2020-10-17 06:20:35 --> Helper loaded: form_helper
INFO - 2020-10-17 06:20:35 --> Helper loaded: my_helper
INFO - 2020-10-17 06:20:35 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:20:35 --> Controller Class Initialized
DEBUG - 2020-10-17 06:20:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-17 06:20:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-17 06:20:35 --> Final output sent to browser
DEBUG - 2020-10-17 06:20:35 --> Total execution time: 0.5629
INFO - 2020-10-17 06:20:35 --> Config Class Initialized
INFO - 2020-10-17 06:20:35 --> Hooks Class Initialized
DEBUG - 2020-10-17 06:20:36 --> UTF-8 Support Enabled
INFO - 2020-10-17 06:20:36 --> Utf8 Class Initialized
INFO - 2020-10-17 06:20:36 --> URI Class Initialized
INFO - 2020-10-17 06:20:36 --> Router Class Initialized
INFO - 2020-10-17 06:20:36 --> Output Class Initialized
INFO - 2020-10-17 06:20:36 --> Security Class Initialized
DEBUG - 2020-10-17 06:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 06:20:36 --> Input Class Initialized
INFO - 2020-10-17 06:20:36 --> Language Class Initialized
INFO - 2020-10-17 06:20:36 --> Language Class Initialized
INFO - 2020-10-17 06:20:36 --> Config Class Initialized
INFO - 2020-10-17 06:20:36 --> Loader Class Initialized
INFO - 2020-10-17 06:20:36 --> Helper loaded: url_helper
INFO - 2020-10-17 06:20:36 --> Helper loaded: file_helper
INFO - 2020-10-17 06:20:36 --> Helper loaded: form_helper
INFO - 2020-10-17 06:20:36 --> Helper loaded: my_helper
INFO - 2020-10-17 06:20:36 --> Database Driver Class Initialized
DEBUG - 2020-10-17 06:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-17 06:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 06:20:36 --> Controller Class Initialized
