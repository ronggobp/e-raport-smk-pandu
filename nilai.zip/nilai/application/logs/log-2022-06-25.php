<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-25 03:18:44 --> Config Class Initialized
INFO - 2022-06-25 03:18:44 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:18:44 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:18:44 --> Utf8 Class Initialized
INFO - 2022-06-25 03:18:44 --> URI Class Initialized
DEBUG - 2022-06-25 03:18:44 --> No URI present. Default controller set.
INFO - 2022-06-25 03:18:44 --> Router Class Initialized
INFO - 2022-06-25 03:18:44 --> Output Class Initialized
INFO - 2022-06-25 03:18:44 --> Security Class Initialized
DEBUG - 2022-06-25 03:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:18:44 --> Input Class Initialized
INFO - 2022-06-25 03:18:44 --> Language Class Initialized
INFO - 2022-06-25 03:18:44 --> Language Class Initialized
INFO - 2022-06-25 03:18:44 --> Config Class Initialized
INFO - 2022-06-25 03:18:44 --> Loader Class Initialized
INFO - 2022-06-25 03:18:44 --> Helper loaded: url_helper
INFO - 2022-06-25 03:18:44 --> Helper loaded: file_helper
INFO - 2022-06-25 03:18:44 --> Helper loaded: form_helper
INFO - 2022-06-25 03:18:44 --> Helper loaded: my_helper
INFO - 2022-06-25 03:18:44 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:18:44 --> Controller Class Initialized
INFO - 2022-06-25 03:18:44 --> Config Class Initialized
INFO - 2022-06-25 03:18:44 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:18:44 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:18:44 --> Utf8 Class Initialized
INFO - 2022-06-25 03:18:44 --> URI Class Initialized
INFO - 2022-06-25 03:18:44 --> Router Class Initialized
INFO - 2022-06-25 03:18:44 --> Output Class Initialized
INFO - 2022-06-25 03:18:45 --> Security Class Initialized
DEBUG - 2022-06-25 03:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:18:45 --> Input Class Initialized
INFO - 2022-06-25 03:18:45 --> Language Class Initialized
INFO - 2022-06-25 03:18:45 --> Language Class Initialized
INFO - 2022-06-25 03:18:45 --> Config Class Initialized
INFO - 2022-06-25 03:18:45 --> Loader Class Initialized
INFO - 2022-06-25 03:18:45 --> Helper loaded: url_helper
INFO - 2022-06-25 03:18:45 --> Helper loaded: file_helper
INFO - 2022-06-25 03:18:45 --> Helper loaded: form_helper
INFO - 2022-06-25 03:18:45 --> Helper loaded: my_helper
INFO - 2022-06-25 03:18:45 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:18:45 --> Controller Class Initialized
DEBUG - 2022-06-25 03:18:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-25 03:18:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:18:45 --> Final output sent to browser
DEBUG - 2022-06-25 03:18:45 --> Total execution time: 0.0536
INFO - 2022-06-25 03:18:54 --> Config Class Initialized
INFO - 2022-06-25 03:18:54 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:18:54 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:18:54 --> Utf8 Class Initialized
INFO - 2022-06-25 03:18:54 --> URI Class Initialized
INFO - 2022-06-25 03:18:54 --> Router Class Initialized
INFO - 2022-06-25 03:18:54 --> Output Class Initialized
INFO - 2022-06-25 03:18:54 --> Security Class Initialized
DEBUG - 2022-06-25 03:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:18:54 --> Input Class Initialized
INFO - 2022-06-25 03:18:54 --> Language Class Initialized
INFO - 2022-06-25 03:18:54 --> Language Class Initialized
INFO - 2022-06-25 03:18:54 --> Config Class Initialized
INFO - 2022-06-25 03:18:54 --> Loader Class Initialized
INFO - 2022-06-25 03:18:54 --> Helper loaded: url_helper
INFO - 2022-06-25 03:18:54 --> Helper loaded: file_helper
INFO - 2022-06-25 03:18:54 --> Helper loaded: form_helper
INFO - 2022-06-25 03:18:54 --> Helper loaded: my_helper
INFO - 2022-06-25 03:18:54 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:18:54 --> Controller Class Initialized
INFO - 2022-06-25 03:18:54 --> Final output sent to browser
DEBUG - 2022-06-25 03:18:54 --> Total execution time: 0.0527
INFO - 2022-06-25 03:18:58 --> Config Class Initialized
INFO - 2022-06-25 03:18:58 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:18:58 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:18:58 --> Utf8 Class Initialized
INFO - 2022-06-25 03:18:58 --> URI Class Initialized
INFO - 2022-06-25 03:18:58 --> Router Class Initialized
INFO - 2022-06-25 03:18:58 --> Output Class Initialized
INFO - 2022-06-25 03:18:58 --> Security Class Initialized
DEBUG - 2022-06-25 03:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:18:58 --> Input Class Initialized
INFO - 2022-06-25 03:18:58 --> Language Class Initialized
INFO - 2022-06-25 03:18:58 --> Language Class Initialized
INFO - 2022-06-25 03:18:58 --> Config Class Initialized
INFO - 2022-06-25 03:18:58 --> Loader Class Initialized
INFO - 2022-06-25 03:18:58 --> Helper loaded: url_helper
INFO - 2022-06-25 03:18:58 --> Helper loaded: file_helper
INFO - 2022-06-25 03:18:58 --> Helper loaded: form_helper
INFO - 2022-06-25 03:18:58 --> Helper loaded: my_helper
INFO - 2022-06-25 03:18:58 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:18:58 --> Controller Class Initialized
INFO - 2022-06-25 03:18:58 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:18:58 --> Final output sent to browser
DEBUG - 2022-06-25 03:18:58 --> Total execution time: 0.0665
INFO - 2022-06-25 03:18:58 --> Config Class Initialized
INFO - 2022-06-25 03:18:58 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:18:58 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:18:58 --> Utf8 Class Initialized
INFO - 2022-06-25 03:18:58 --> URI Class Initialized
INFO - 2022-06-25 03:18:58 --> Router Class Initialized
INFO - 2022-06-25 03:18:58 --> Output Class Initialized
INFO - 2022-06-25 03:18:58 --> Security Class Initialized
DEBUG - 2022-06-25 03:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:18:58 --> Input Class Initialized
INFO - 2022-06-25 03:18:58 --> Language Class Initialized
INFO - 2022-06-25 03:18:58 --> Language Class Initialized
INFO - 2022-06-25 03:18:58 --> Config Class Initialized
INFO - 2022-06-25 03:18:58 --> Loader Class Initialized
INFO - 2022-06-25 03:18:58 --> Helper loaded: url_helper
INFO - 2022-06-25 03:18:58 --> Helper loaded: file_helper
INFO - 2022-06-25 03:18:58 --> Helper loaded: form_helper
INFO - 2022-06-25 03:18:58 --> Helper loaded: my_helper
INFO - 2022-06-25 03:18:58 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:18:58 --> Controller Class Initialized
DEBUG - 2022-06-25 03:18:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-25 03:18:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:18:59 --> Final output sent to browser
DEBUG - 2022-06-25 03:18:59 --> Total execution time: 0.6144
INFO - 2022-06-25 03:19:00 --> Config Class Initialized
INFO - 2022-06-25 03:19:00 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:00 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:00 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:00 --> URI Class Initialized
INFO - 2022-06-25 03:19:00 --> Router Class Initialized
INFO - 2022-06-25 03:19:00 --> Output Class Initialized
INFO - 2022-06-25 03:19:00 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:00 --> Input Class Initialized
INFO - 2022-06-25 03:19:00 --> Language Class Initialized
INFO - 2022-06-25 03:19:00 --> Language Class Initialized
INFO - 2022-06-25 03:19:00 --> Config Class Initialized
INFO - 2022-06-25 03:19:00 --> Loader Class Initialized
INFO - 2022-06-25 03:19:00 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:00 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:00 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:00 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:00 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:00 --> Controller Class Initialized
DEBUG - 2022-06-25 03:19:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-25 03:19:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:19:00 --> Final output sent to browser
DEBUG - 2022-06-25 03:19:00 --> Total execution time: 0.0840
INFO - 2022-06-25 03:19:30 --> Config Class Initialized
INFO - 2022-06-25 03:19:30 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:30 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:30 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:30 --> URI Class Initialized
INFO - 2022-06-25 03:19:31 --> Router Class Initialized
INFO - 2022-06-25 03:19:31 --> Output Class Initialized
INFO - 2022-06-25 03:19:31 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:31 --> Input Class Initialized
INFO - 2022-06-25 03:19:31 --> Language Class Initialized
INFO - 2022-06-25 03:19:31 --> Language Class Initialized
INFO - 2022-06-25 03:19:31 --> Config Class Initialized
INFO - 2022-06-25 03:19:31 --> Loader Class Initialized
INFO - 2022-06-25 03:19:31 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:31 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:31 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:31 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:31 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:31 --> Controller Class Initialized
DEBUG - 2022-06-25 03:19:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:19:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:19:31 --> Final output sent to browser
DEBUG - 2022-06-25 03:19:31 --> Total execution time: 0.0624
INFO - 2022-06-25 03:19:31 --> Config Class Initialized
INFO - 2022-06-25 03:19:31 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:31 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:31 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:31 --> URI Class Initialized
INFO - 2022-06-25 03:19:31 --> Router Class Initialized
INFO - 2022-06-25 03:19:31 --> Output Class Initialized
INFO - 2022-06-25 03:19:31 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:31 --> Input Class Initialized
INFO - 2022-06-25 03:19:31 --> Language Class Initialized
INFO - 2022-06-25 03:19:31 --> Language Class Initialized
INFO - 2022-06-25 03:19:31 --> Config Class Initialized
INFO - 2022-06-25 03:19:31 --> Loader Class Initialized
INFO - 2022-06-25 03:19:31 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:31 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:31 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:31 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:31 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:31 --> Controller Class Initialized
INFO - 2022-06-25 03:19:32 --> Config Class Initialized
INFO - 2022-06-25 03:19:32 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:32 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:32 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:32 --> URI Class Initialized
INFO - 2022-06-25 03:19:32 --> Router Class Initialized
INFO - 2022-06-25 03:19:32 --> Output Class Initialized
INFO - 2022-06-25 03:19:32 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:32 --> Input Class Initialized
INFO - 2022-06-25 03:19:32 --> Language Class Initialized
INFO - 2022-06-25 03:19:32 --> Language Class Initialized
INFO - 2022-06-25 03:19:32 --> Config Class Initialized
INFO - 2022-06-25 03:19:32 --> Loader Class Initialized
INFO - 2022-06-25 03:19:32 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:32 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:32 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:32 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:32 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:32 --> Controller Class Initialized
DEBUG - 2022-06-25 03:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:19:32 --> Final output sent to browser
DEBUG - 2022-06-25 03:19:32 --> Total execution time: 0.0517
INFO - 2022-06-25 03:19:33 --> Config Class Initialized
INFO - 2022-06-25 03:19:33 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:33 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:33 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:33 --> URI Class Initialized
INFO - 2022-06-25 03:19:33 --> Router Class Initialized
INFO - 2022-06-25 03:19:33 --> Output Class Initialized
INFO - 2022-06-25 03:19:33 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:33 --> Input Class Initialized
INFO - 2022-06-25 03:19:33 --> Language Class Initialized
INFO - 2022-06-25 03:19:33 --> Language Class Initialized
INFO - 2022-06-25 03:19:33 --> Config Class Initialized
INFO - 2022-06-25 03:19:33 --> Loader Class Initialized
INFO - 2022-06-25 03:19:33 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:33 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:33 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:33 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:33 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:33 --> Controller Class Initialized
DEBUG - 2022-06-25 03:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:19:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:19:33 --> Final output sent to browser
DEBUG - 2022-06-25 03:19:33 --> Total execution time: 0.0491
INFO - 2022-06-25 03:19:34 --> Config Class Initialized
INFO - 2022-06-25 03:19:34 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:34 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:34 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:34 --> URI Class Initialized
INFO - 2022-06-25 03:19:34 --> Router Class Initialized
INFO - 2022-06-25 03:19:34 --> Output Class Initialized
INFO - 2022-06-25 03:19:34 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:34 --> Input Class Initialized
INFO - 2022-06-25 03:19:34 --> Language Class Initialized
INFO - 2022-06-25 03:19:34 --> Language Class Initialized
INFO - 2022-06-25 03:19:34 --> Config Class Initialized
INFO - 2022-06-25 03:19:34 --> Loader Class Initialized
INFO - 2022-06-25 03:19:34 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:34 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:34 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:34 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:34 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:34 --> Controller Class Initialized
INFO - 2022-06-25 03:19:34 --> Config Class Initialized
INFO - 2022-06-25 03:19:34 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:34 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:34 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:34 --> URI Class Initialized
INFO - 2022-06-25 03:19:34 --> Router Class Initialized
INFO - 2022-06-25 03:19:34 --> Output Class Initialized
INFO - 2022-06-25 03:19:34 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:34 --> Input Class Initialized
INFO - 2022-06-25 03:19:34 --> Language Class Initialized
INFO - 2022-06-25 03:19:34 --> Language Class Initialized
INFO - 2022-06-25 03:19:34 --> Config Class Initialized
INFO - 2022-06-25 03:19:34 --> Loader Class Initialized
INFO - 2022-06-25 03:19:34 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:34 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:34 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:34 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:34 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:34 --> Controller Class Initialized
DEBUG - 2022-06-25 03:19:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:19:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:19:34 --> Final output sent to browser
DEBUG - 2022-06-25 03:19:34 --> Total execution time: 0.0474
INFO - 2022-06-25 03:19:36 --> Config Class Initialized
INFO - 2022-06-25 03:19:36 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:36 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:36 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:36 --> URI Class Initialized
INFO - 2022-06-25 03:19:36 --> Router Class Initialized
INFO - 2022-06-25 03:19:36 --> Output Class Initialized
INFO - 2022-06-25 03:19:36 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:36 --> Input Class Initialized
INFO - 2022-06-25 03:19:36 --> Language Class Initialized
INFO - 2022-06-25 03:19:36 --> Language Class Initialized
INFO - 2022-06-25 03:19:36 --> Config Class Initialized
INFO - 2022-06-25 03:19:36 --> Loader Class Initialized
INFO - 2022-06-25 03:19:36 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:36 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:36 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:36 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:36 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:36 --> Controller Class Initialized
INFO - 2022-06-25 03:19:41 --> Config Class Initialized
INFO - 2022-06-25 03:19:41 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:41 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:41 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:41 --> URI Class Initialized
INFO - 2022-06-25 03:19:41 --> Router Class Initialized
INFO - 2022-06-25 03:19:41 --> Output Class Initialized
INFO - 2022-06-25 03:19:41 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:41 --> Input Class Initialized
INFO - 2022-06-25 03:19:41 --> Language Class Initialized
INFO - 2022-06-25 03:19:41 --> Language Class Initialized
INFO - 2022-06-25 03:19:41 --> Config Class Initialized
INFO - 2022-06-25 03:19:41 --> Loader Class Initialized
INFO - 2022-06-25 03:19:41 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:41 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:41 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:41 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:41 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:41 --> Controller Class Initialized
INFO - 2022-06-25 03:19:43 --> Config Class Initialized
INFO - 2022-06-25 03:19:43 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:43 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:43 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:43 --> URI Class Initialized
INFO - 2022-06-25 03:19:43 --> Router Class Initialized
INFO - 2022-06-25 03:19:43 --> Output Class Initialized
INFO - 2022-06-25 03:19:43 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:43 --> Input Class Initialized
INFO - 2022-06-25 03:19:43 --> Language Class Initialized
INFO - 2022-06-25 03:19:43 --> Language Class Initialized
INFO - 2022-06-25 03:19:43 --> Config Class Initialized
INFO - 2022-06-25 03:19:43 --> Loader Class Initialized
INFO - 2022-06-25 03:19:43 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:43 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:43 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:43 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:43 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:43 --> Controller Class Initialized
INFO - 2022-06-25 03:19:46 --> Config Class Initialized
INFO - 2022-06-25 03:19:46 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:46 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:46 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:46 --> URI Class Initialized
INFO - 2022-06-25 03:19:46 --> Router Class Initialized
INFO - 2022-06-25 03:19:46 --> Output Class Initialized
INFO - 2022-06-25 03:19:46 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:46 --> Input Class Initialized
INFO - 2022-06-25 03:19:46 --> Language Class Initialized
INFO - 2022-06-25 03:19:46 --> Language Class Initialized
INFO - 2022-06-25 03:19:46 --> Config Class Initialized
INFO - 2022-06-25 03:19:46 --> Loader Class Initialized
INFO - 2022-06-25 03:19:46 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:46 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:46 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:46 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:46 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:46 --> Controller Class Initialized
INFO - 2022-06-25 03:19:57 --> Config Class Initialized
INFO - 2022-06-25 03:19:57 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:57 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:57 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:57 --> URI Class Initialized
INFO - 2022-06-25 03:19:57 --> Router Class Initialized
INFO - 2022-06-25 03:19:57 --> Output Class Initialized
INFO - 2022-06-25 03:19:57 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:57 --> Input Class Initialized
INFO - 2022-06-25 03:19:57 --> Language Class Initialized
INFO - 2022-06-25 03:19:57 --> Language Class Initialized
INFO - 2022-06-25 03:19:57 --> Config Class Initialized
INFO - 2022-06-25 03:19:57 --> Loader Class Initialized
INFO - 2022-06-25 03:19:57 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:57 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:57 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:57 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:57 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:57 --> Controller Class Initialized
INFO - 2022-06-25 03:19:57 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:19:57 --> Config Class Initialized
INFO - 2022-06-25 03:19:57 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:19:57 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:19:57 --> Utf8 Class Initialized
INFO - 2022-06-25 03:19:57 --> URI Class Initialized
INFO - 2022-06-25 03:19:57 --> Router Class Initialized
INFO - 2022-06-25 03:19:57 --> Output Class Initialized
INFO - 2022-06-25 03:19:57 --> Security Class Initialized
DEBUG - 2022-06-25 03:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:19:57 --> Input Class Initialized
INFO - 2022-06-25 03:19:57 --> Language Class Initialized
INFO - 2022-06-25 03:19:57 --> Language Class Initialized
INFO - 2022-06-25 03:19:57 --> Config Class Initialized
INFO - 2022-06-25 03:19:57 --> Loader Class Initialized
INFO - 2022-06-25 03:19:57 --> Helper loaded: url_helper
INFO - 2022-06-25 03:19:57 --> Helper loaded: file_helper
INFO - 2022-06-25 03:19:57 --> Helper loaded: form_helper
INFO - 2022-06-25 03:19:57 --> Helper loaded: my_helper
INFO - 2022-06-25 03:19:57 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:19:57 --> Controller Class Initialized
DEBUG - 2022-06-25 03:19:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-25 03:19:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:19:57 --> Final output sent to browser
DEBUG - 2022-06-25 03:19:57 --> Total execution time: 0.0413
INFO - 2022-06-25 03:20:06 --> Config Class Initialized
INFO - 2022-06-25 03:20:06 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:06 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:06 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:06 --> URI Class Initialized
INFO - 2022-06-25 03:20:06 --> Router Class Initialized
INFO - 2022-06-25 03:20:06 --> Output Class Initialized
INFO - 2022-06-25 03:20:06 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:06 --> Input Class Initialized
INFO - 2022-06-25 03:20:06 --> Language Class Initialized
INFO - 2022-06-25 03:20:06 --> Language Class Initialized
INFO - 2022-06-25 03:20:06 --> Config Class Initialized
INFO - 2022-06-25 03:20:06 --> Loader Class Initialized
INFO - 2022-06-25 03:20:06 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:06 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:06 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:06 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:06 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:06 --> Controller Class Initialized
INFO - 2022-06-25 03:20:06 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:20:06 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:06 --> Total execution time: 0.0467
INFO - 2022-06-25 03:20:07 --> Config Class Initialized
INFO - 2022-06-25 03:20:07 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:07 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:07 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:07 --> URI Class Initialized
INFO - 2022-06-25 03:20:07 --> Router Class Initialized
INFO - 2022-06-25 03:20:07 --> Output Class Initialized
INFO - 2022-06-25 03:20:07 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:07 --> Input Class Initialized
INFO - 2022-06-25 03:20:07 --> Language Class Initialized
INFO - 2022-06-25 03:20:07 --> Language Class Initialized
INFO - 2022-06-25 03:20:07 --> Config Class Initialized
INFO - 2022-06-25 03:20:07 --> Loader Class Initialized
INFO - 2022-06-25 03:20:07 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:07 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:07 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:07 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:07 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:07 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-25 03:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:07 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:07 --> Total execution time: 0.5718
INFO - 2022-06-25 03:20:09 --> Config Class Initialized
INFO - 2022-06-25 03:20:09 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:09 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:09 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:09 --> URI Class Initialized
INFO - 2022-06-25 03:20:09 --> Router Class Initialized
INFO - 2022-06-25 03:20:09 --> Output Class Initialized
INFO - 2022-06-25 03:20:09 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:09 --> Input Class Initialized
INFO - 2022-06-25 03:20:09 --> Language Class Initialized
INFO - 2022-06-25 03:20:09 --> Language Class Initialized
INFO - 2022-06-25 03:20:09 --> Config Class Initialized
INFO - 2022-06-25 03:20:09 --> Loader Class Initialized
INFO - 2022-06-25 03:20:09 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:09 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:09 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:09 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:09 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:09 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-25 03:20:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:09 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:09 --> Total execution time: 0.0698
INFO - 2022-06-25 03:20:12 --> Config Class Initialized
INFO - 2022-06-25 03:20:12 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:12 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:12 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:12 --> URI Class Initialized
INFO - 2022-06-25 03:20:12 --> Router Class Initialized
INFO - 2022-06-25 03:20:12 --> Output Class Initialized
INFO - 2022-06-25 03:20:12 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:12 --> Input Class Initialized
INFO - 2022-06-25 03:20:12 --> Language Class Initialized
INFO - 2022-06-25 03:20:12 --> Language Class Initialized
INFO - 2022-06-25 03:20:12 --> Config Class Initialized
INFO - 2022-06-25 03:20:12 --> Loader Class Initialized
INFO - 2022-06-25 03:20:12 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:12 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:12 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:12 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:12 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:12 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:20:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:12 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:12 --> Total execution time: 0.0503
INFO - 2022-06-25 03:20:12 --> Config Class Initialized
INFO - 2022-06-25 03:20:12 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:12 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:12 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:12 --> URI Class Initialized
INFO - 2022-06-25 03:20:12 --> Router Class Initialized
INFO - 2022-06-25 03:20:12 --> Output Class Initialized
INFO - 2022-06-25 03:20:12 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:12 --> Input Class Initialized
INFO - 2022-06-25 03:20:12 --> Language Class Initialized
INFO - 2022-06-25 03:20:12 --> Language Class Initialized
INFO - 2022-06-25 03:20:12 --> Config Class Initialized
INFO - 2022-06-25 03:20:12 --> Loader Class Initialized
INFO - 2022-06-25 03:20:12 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:12 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:12 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:12 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:12 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:12 --> Controller Class Initialized
INFO - 2022-06-25 03:20:14 --> Config Class Initialized
INFO - 2022-06-25 03:20:14 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:14 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:14 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:14 --> URI Class Initialized
INFO - 2022-06-25 03:20:14 --> Router Class Initialized
INFO - 2022-06-25 03:20:14 --> Output Class Initialized
INFO - 2022-06-25 03:20:14 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:14 --> Input Class Initialized
INFO - 2022-06-25 03:20:14 --> Language Class Initialized
INFO - 2022-06-25 03:20:14 --> Language Class Initialized
INFO - 2022-06-25 03:20:14 --> Config Class Initialized
INFO - 2022-06-25 03:20:14 --> Loader Class Initialized
INFO - 2022-06-25 03:20:14 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:14 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:14 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:14 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:14 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:14 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:20:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:14 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:14 --> Total execution time: 0.0494
INFO - 2022-06-25 03:20:15 --> Config Class Initialized
INFO - 2022-06-25 03:20:15 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:15 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:15 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:15 --> URI Class Initialized
INFO - 2022-06-25 03:20:15 --> Router Class Initialized
INFO - 2022-06-25 03:20:15 --> Output Class Initialized
INFO - 2022-06-25 03:20:15 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:15 --> Input Class Initialized
INFO - 2022-06-25 03:20:15 --> Language Class Initialized
INFO - 2022-06-25 03:20:15 --> Language Class Initialized
INFO - 2022-06-25 03:20:15 --> Config Class Initialized
INFO - 2022-06-25 03:20:15 --> Loader Class Initialized
INFO - 2022-06-25 03:20:15 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:15 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:15 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:15 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:15 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:15 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:20:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:15 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:15 --> Total execution time: 0.0491
INFO - 2022-06-25 03:20:15 --> Config Class Initialized
INFO - 2022-06-25 03:20:15 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:15 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:15 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:15 --> URI Class Initialized
INFO - 2022-06-25 03:20:15 --> Router Class Initialized
INFO - 2022-06-25 03:20:15 --> Output Class Initialized
INFO - 2022-06-25 03:20:15 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:15 --> Input Class Initialized
INFO - 2022-06-25 03:20:15 --> Language Class Initialized
INFO - 2022-06-25 03:20:15 --> Language Class Initialized
INFO - 2022-06-25 03:20:15 --> Config Class Initialized
INFO - 2022-06-25 03:20:15 --> Loader Class Initialized
INFO - 2022-06-25 03:20:15 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:15 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:15 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:15 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:15 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:15 --> Controller Class Initialized
INFO - 2022-06-25 03:20:16 --> Config Class Initialized
INFO - 2022-06-25 03:20:16 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:16 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:16 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:16 --> URI Class Initialized
INFO - 2022-06-25 03:20:16 --> Router Class Initialized
INFO - 2022-06-25 03:20:16 --> Output Class Initialized
INFO - 2022-06-25 03:20:16 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:16 --> Input Class Initialized
INFO - 2022-06-25 03:20:16 --> Language Class Initialized
INFO - 2022-06-25 03:20:16 --> Language Class Initialized
INFO - 2022-06-25 03:20:16 --> Config Class Initialized
INFO - 2022-06-25 03:20:16 --> Loader Class Initialized
INFO - 2022-06-25 03:20:16 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:16 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:16 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:16 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:16 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:16 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:16 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:16 --> Total execution time: 0.0496
INFO - 2022-06-25 03:20:21 --> Config Class Initialized
INFO - 2022-06-25 03:20:21 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:21 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:21 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:21 --> URI Class Initialized
INFO - 2022-06-25 03:20:21 --> Router Class Initialized
INFO - 2022-06-25 03:20:21 --> Output Class Initialized
INFO - 2022-06-25 03:20:21 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:21 --> Input Class Initialized
INFO - 2022-06-25 03:20:21 --> Language Class Initialized
INFO - 2022-06-25 03:20:21 --> Language Class Initialized
INFO - 2022-06-25 03:20:21 --> Config Class Initialized
INFO - 2022-06-25 03:20:21 --> Loader Class Initialized
INFO - 2022-06-25 03:20:21 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:21 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:21 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:21 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:21 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:21 --> Controller Class Initialized
INFO - 2022-06-25 03:20:23 --> Config Class Initialized
INFO - 2022-06-25 03:20:23 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:23 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:23 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:23 --> URI Class Initialized
INFO - 2022-06-25 03:20:23 --> Router Class Initialized
INFO - 2022-06-25 03:20:23 --> Output Class Initialized
INFO - 2022-06-25 03:20:23 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:23 --> Input Class Initialized
INFO - 2022-06-25 03:20:23 --> Language Class Initialized
INFO - 2022-06-25 03:20:23 --> Language Class Initialized
INFO - 2022-06-25 03:20:23 --> Config Class Initialized
INFO - 2022-06-25 03:20:23 --> Loader Class Initialized
INFO - 2022-06-25 03:20:23 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:23 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:23 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:23 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:23 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:23 --> Controller Class Initialized
INFO - 2022-06-25 03:20:24 --> Config Class Initialized
INFO - 2022-06-25 03:20:24 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:24 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:24 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:24 --> URI Class Initialized
INFO - 2022-06-25 03:20:24 --> Router Class Initialized
INFO - 2022-06-25 03:20:24 --> Output Class Initialized
INFO - 2022-06-25 03:20:24 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:24 --> Input Class Initialized
INFO - 2022-06-25 03:20:24 --> Language Class Initialized
INFO - 2022-06-25 03:20:24 --> Language Class Initialized
INFO - 2022-06-25 03:20:24 --> Config Class Initialized
INFO - 2022-06-25 03:20:24 --> Loader Class Initialized
INFO - 2022-06-25 03:20:24 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:24 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:24 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:24 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:24 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:24 --> Controller Class Initialized
INFO - 2022-06-25 03:20:25 --> Config Class Initialized
INFO - 2022-06-25 03:20:25 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:25 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:25 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:25 --> URI Class Initialized
INFO - 2022-06-25 03:20:25 --> Router Class Initialized
INFO - 2022-06-25 03:20:25 --> Output Class Initialized
INFO - 2022-06-25 03:20:25 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:25 --> Input Class Initialized
INFO - 2022-06-25 03:20:25 --> Language Class Initialized
INFO - 2022-06-25 03:20:25 --> Language Class Initialized
INFO - 2022-06-25 03:20:25 --> Config Class Initialized
INFO - 2022-06-25 03:20:25 --> Loader Class Initialized
INFO - 2022-06-25 03:20:25 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:25 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:25 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:25 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:25 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:25 --> Controller Class Initialized
INFO - 2022-06-25 03:20:49 --> Config Class Initialized
INFO - 2022-06-25 03:20:49 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:49 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:49 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:49 --> URI Class Initialized
INFO - 2022-06-25 03:20:49 --> Router Class Initialized
INFO - 2022-06-25 03:20:49 --> Output Class Initialized
INFO - 2022-06-25 03:20:49 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:49 --> Input Class Initialized
INFO - 2022-06-25 03:20:49 --> Language Class Initialized
INFO - 2022-06-25 03:20:49 --> Language Class Initialized
INFO - 2022-06-25 03:20:49 --> Config Class Initialized
INFO - 2022-06-25 03:20:49 --> Loader Class Initialized
INFO - 2022-06-25 03:20:49 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:49 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:49 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:49 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:49 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:49 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:20:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:49 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:49 --> Total execution time: 0.0508
INFO - 2022-06-25 03:20:49 --> Config Class Initialized
INFO - 2022-06-25 03:20:49 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:49 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:49 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:49 --> URI Class Initialized
INFO - 2022-06-25 03:20:49 --> Router Class Initialized
INFO - 2022-06-25 03:20:49 --> Output Class Initialized
INFO - 2022-06-25 03:20:49 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:49 --> Input Class Initialized
INFO - 2022-06-25 03:20:49 --> Language Class Initialized
INFO - 2022-06-25 03:20:49 --> Language Class Initialized
INFO - 2022-06-25 03:20:49 --> Config Class Initialized
INFO - 2022-06-25 03:20:49 --> Loader Class Initialized
INFO - 2022-06-25 03:20:49 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:49 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:49 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:49 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:49 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:49 --> Controller Class Initialized
INFO - 2022-06-25 03:20:50 --> Config Class Initialized
INFO - 2022-06-25 03:20:50 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:50 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:50 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:50 --> URI Class Initialized
INFO - 2022-06-25 03:20:50 --> Router Class Initialized
INFO - 2022-06-25 03:20:50 --> Output Class Initialized
INFO - 2022-06-25 03:20:50 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:50 --> Input Class Initialized
INFO - 2022-06-25 03:20:50 --> Language Class Initialized
INFO - 2022-06-25 03:20:50 --> Language Class Initialized
INFO - 2022-06-25 03:20:50 --> Config Class Initialized
INFO - 2022-06-25 03:20:50 --> Loader Class Initialized
INFO - 2022-06-25 03:20:50 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:50 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:50 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:50 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:50 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:50 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:50 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:50 --> Total execution time: 0.0496
INFO - 2022-06-25 03:20:52 --> Config Class Initialized
INFO - 2022-06-25 03:20:52 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:52 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:52 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:52 --> URI Class Initialized
INFO - 2022-06-25 03:20:52 --> Router Class Initialized
INFO - 2022-06-25 03:20:52 --> Output Class Initialized
INFO - 2022-06-25 03:20:52 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:52 --> Input Class Initialized
INFO - 2022-06-25 03:20:52 --> Language Class Initialized
INFO - 2022-06-25 03:20:52 --> Language Class Initialized
INFO - 2022-06-25 03:20:52 --> Config Class Initialized
INFO - 2022-06-25 03:20:52 --> Loader Class Initialized
INFO - 2022-06-25 03:20:52 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:52 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:52 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:52 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:52 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:52 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:52 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:52 --> Total execution time: 0.0486
INFO - 2022-06-25 03:20:53 --> Config Class Initialized
INFO - 2022-06-25 03:20:53 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:53 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:53 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:53 --> URI Class Initialized
INFO - 2022-06-25 03:20:53 --> Router Class Initialized
INFO - 2022-06-25 03:20:53 --> Output Class Initialized
INFO - 2022-06-25 03:20:53 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:53 --> Input Class Initialized
INFO - 2022-06-25 03:20:53 --> Language Class Initialized
INFO - 2022-06-25 03:20:53 --> Language Class Initialized
INFO - 2022-06-25 03:20:53 --> Config Class Initialized
INFO - 2022-06-25 03:20:53 --> Loader Class Initialized
INFO - 2022-06-25 03:20:53 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:53 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:53 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:53 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:53 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:53 --> Controller Class Initialized
INFO - 2022-06-25 03:20:54 --> Config Class Initialized
INFO - 2022-06-25 03:20:54 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:54 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:54 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:54 --> URI Class Initialized
INFO - 2022-06-25 03:20:54 --> Router Class Initialized
INFO - 2022-06-25 03:20:54 --> Output Class Initialized
INFO - 2022-06-25 03:20:54 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:54 --> Input Class Initialized
INFO - 2022-06-25 03:20:54 --> Language Class Initialized
INFO - 2022-06-25 03:20:54 --> Language Class Initialized
INFO - 2022-06-25 03:20:54 --> Config Class Initialized
INFO - 2022-06-25 03:20:54 --> Loader Class Initialized
INFO - 2022-06-25 03:20:54 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:54 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:54 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:54 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:54 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:54 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:54 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:54 --> Total execution time: 0.0481
INFO - 2022-06-25 03:20:59 --> Config Class Initialized
INFO - 2022-06-25 03:20:59 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:59 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:59 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:59 --> URI Class Initialized
INFO - 2022-06-25 03:20:59 --> Router Class Initialized
INFO - 2022-06-25 03:20:59 --> Output Class Initialized
INFO - 2022-06-25 03:20:59 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:59 --> Input Class Initialized
INFO - 2022-06-25 03:20:59 --> Language Class Initialized
INFO - 2022-06-25 03:20:59 --> Language Class Initialized
INFO - 2022-06-25 03:20:59 --> Config Class Initialized
INFO - 2022-06-25 03:20:59 --> Loader Class Initialized
INFO - 2022-06-25 03:20:59 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:59 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:59 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:59 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:59 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:20:59 --> Controller Class Initialized
DEBUG - 2022-06-25 03:20:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:20:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:20:59 --> Final output sent to browser
DEBUG - 2022-06-25 03:20:59 --> Total execution time: 0.0509
INFO - 2022-06-25 03:20:59 --> Config Class Initialized
INFO - 2022-06-25 03:20:59 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:20:59 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:20:59 --> Utf8 Class Initialized
INFO - 2022-06-25 03:20:59 --> URI Class Initialized
INFO - 2022-06-25 03:20:59 --> Router Class Initialized
INFO - 2022-06-25 03:20:59 --> Output Class Initialized
INFO - 2022-06-25 03:20:59 --> Security Class Initialized
DEBUG - 2022-06-25 03:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:20:59 --> Input Class Initialized
INFO - 2022-06-25 03:20:59 --> Language Class Initialized
INFO - 2022-06-25 03:20:59 --> Language Class Initialized
INFO - 2022-06-25 03:20:59 --> Config Class Initialized
INFO - 2022-06-25 03:20:59 --> Loader Class Initialized
INFO - 2022-06-25 03:20:59 --> Helper loaded: url_helper
INFO - 2022-06-25 03:20:59 --> Helper loaded: file_helper
INFO - 2022-06-25 03:20:59 --> Helper loaded: form_helper
INFO - 2022-06-25 03:20:59 --> Helper loaded: my_helper
INFO - 2022-06-25 03:20:59 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:00 --> Controller Class Initialized
INFO - 2022-06-25 03:21:01 --> Config Class Initialized
INFO - 2022-06-25 03:21:01 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:01 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:01 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:01 --> URI Class Initialized
INFO - 2022-06-25 03:21:01 --> Router Class Initialized
INFO - 2022-06-25 03:21:01 --> Output Class Initialized
INFO - 2022-06-25 03:21:01 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:01 --> Input Class Initialized
INFO - 2022-06-25 03:21:01 --> Language Class Initialized
INFO - 2022-06-25 03:21:01 --> Language Class Initialized
INFO - 2022-06-25 03:21:01 --> Config Class Initialized
INFO - 2022-06-25 03:21:01 --> Loader Class Initialized
INFO - 2022-06-25 03:21:01 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:01 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:01 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:01 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:01 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:01 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:01 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:01 --> Total execution time: 0.0494
INFO - 2022-06-25 03:21:03 --> Config Class Initialized
INFO - 2022-06-25 03:21:03 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:03 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:03 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:03 --> URI Class Initialized
INFO - 2022-06-25 03:21:03 --> Router Class Initialized
INFO - 2022-06-25 03:21:03 --> Output Class Initialized
INFO - 2022-06-25 03:21:03 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:03 --> Input Class Initialized
INFO - 2022-06-25 03:21:03 --> Language Class Initialized
INFO - 2022-06-25 03:21:03 --> Language Class Initialized
INFO - 2022-06-25 03:21:03 --> Config Class Initialized
INFO - 2022-06-25 03:21:03 --> Loader Class Initialized
INFO - 2022-06-25 03:21:03 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:03 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:03 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:03 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:03 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:03 --> Controller Class Initialized
INFO - 2022-06-25 03:21:05 --> Config Class Initialized
INFO - 2022-06-25 03:21:05 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:05 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:05 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:05 --> URI Class Initialized
INFO - 2022-06-25 03:21:05 --> Router Class Initialized
INFO - 2022-06-25 03:21:05 --> Output Class Initialized
INFO - 2022-06-25 03:21:05 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:05 --> Input Class Initialized
INFO - 2022-06-25 03:21:05 --> Language Class Initialized
INFO - 2022-06-25 03:21:05 --> Language Class Initialized
INFO - 2022-06-25 03:21:05 --> Config Class Initialized
INFO - 2022-06-25 03:21:05 --> Loader Class Initialized
INFO - 2022-06-25 03:21:05 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:05 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:05 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:05 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:05 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:05 --> Controller Class Initialized
INFO - 2022-06-25 03:21:06 --> Config Class Initialized
INFO - 2022-06-25 03:21:06 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:06 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:06 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:06 --> URI Class Initialized
INFO - 2022-06-25 03:21:06 --> Router Class Initialized
INFO - 2022-06-25 03:21:06 --> Output Class Initialized
INFO - 2022-06-25 03:21:06 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:06 --> Input Class Initialized
INFO - 2022-06-25 03:21:06 --> Language Class Initialized
INFO - 2022-06-25 03:21:06 --> Language Class Initialized
INFO - 2022-06-25 03:21:06 --> Config Class Initialized
INFO - 2022-06-25 03:21:06 --> Loader Class Initialized
INFO - 2022-06-25 03:21:06 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:06 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:06 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:06 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:06 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:06 --> Controller Class Initialized
INFO - 2022-06-25 03:21:08 --> Config Class Initialized
INFO - 2022-06-25 03:21:08 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:08 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:08 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:08 --> URI Class Initialized
INFO - 2022-06-25 03:21:08 --> Router Class Initialized
INFO - 2022-06-25 03:21:08 --> Output Class Initialized
INFO - 2022-06-25 03:21:08 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:08 --> Input Class Initialized
INFO - 2022-06-25 03:21:08 --> Language Class Initialized
INFO - 2022-06-25 03:21:08 --> Language Class Initialized
INFO - 2022-06-25 03:21:08 --> Config Class Initialized
INFO - 2022-06-25 03:21:08 --> Loader Class Initialized
INFO - 2022-06-25 03:21:08 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:08 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:08 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:08 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:08 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:08 --> Controller Class Initialized
INFO - 2022-06-25 03:21:09 --> Config Class Initialized
INFO - 2022-06-25 03:21:09 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:09 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:09 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:09 --> URI Class Initialized
INFO - 2022-06-25 03:21:09 --> Router Class Initialized
INFO - 2022-06-25 03:21:09 --> Output Class Initialized
INFO - 2022-06-25 03:21:09 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:09 --> Input Class Initialized
INFO - 2022-06-25 03:21:09 --> Language Class Initialized
INFO - 2022-06-25 03:21:09 --> Language Class Initialized
INFO - 2022-06-25 03:21:09 --> Config Class Initialized
INFO - 2022-06-25 03:21:09 --> Loader Class Initialized
INFO - 2022-06-25 03:21:09 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:09 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:09 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:09 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:09 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:09 --> Controller Class Initialized
INFO - 2022-06-25 03:21:11 --> Config Class Initialized
INFO - 2022-06-25 03:21:11 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:11 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:11 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:11 --> URI Class Initialized
INFO - 2022-06-25 03:21:11 --> Router Class Initialized
INFO - 2022-06-25 03:21:11 --> Output Class Initialized
INFO - 2022-06-25 03:21:11 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:11 --> Input Class Initialized
INFO - 2022-06-25 03:21:11 --> Language Class Initialized
INFO - 2022-06-25 03:21:11 --> Language Class Initialized
INFO - 2022-06-25 03:21:11 --> Config Class Initialized
INFO - 2022-06-25 03:21:11 --> Loader Class Initialized
INFO - 2022-06-25 03:21:11 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:11 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:11 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:11 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:11 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:11 --> Controller Class Initialized
INFO - 2022-06-25 03:21:15 --> Config Class Initialized
INFO - 2022-06-25 03:21:15 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:15 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:15 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:15 --> URI Class Initialized
INFO - 2022-06-25 03:21:15 --> Router Class Initialized
INFO - 2022-06-25 03:21:15 --> Output Class Initialized
INFO - 2022-06-25 03:21:15 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:15 --> Input Class Initialized
INFO - 2022-06-25 03:21:15 --> Language Class Initialized
INFO - 2022-06-25 03:21:15 --> Language Class Initialized
INFO - 2022-06-25 03:21:15 --> Config Class Initialized
INFO - 2022-06-25 03:21:15 --> Loader Class Initialized
INFO - 2022-06-25 03:21:15 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:15 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:15 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:15 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:15 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:15 --> Controller Class Initialized
INFO - 2022-06-25 03:21:15 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:21:15 --> Config Class Initialized
INFO - 2022-06-25 03:21:15 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:15 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:15 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:15 --> URI Class Initialized
INFO - 2022-06-25 03:21:15 --> Router Class Initialized
INFO - 2022-06-25 03:21:15 --> Output Class Initialized
INFO - 2022-06-25 03:21:15 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:15 --> Input Class Initialized
INFO - 2022-06-25 03:21:15 --> Language Class Initialized
INFO - 2022-06-25 03:21:15 --> Language Class Initialized
INFO - 2022-06-25 03:21:15 --> Config Class Initialized
INFO - 2022-06-25 03:21:15 --> Loader Class Initialized
INFO - 2022-06-25 03:21:15 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:15 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:15 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:15 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:15 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:15 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-25 03:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:15 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:15 --> Total execution time: 0.0545
INFO - 2022-06-25 03:21:19 --> Config Class Initialized
INFO - 2022-06-25 03:21:19 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:19 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:19 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:19 --> URI Class Initialized
INFO - 2022-06-25 03:21:19 --> Router Class Initialized
INFO - 2022-06-25 03:21:19 --> Output Class Initialized
INFO - 2022-06-25 03:21:19 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:19 --> Input Class Initialized
INFO - 2022-06-25 03:21:19 --> Language Class Initialized
INFO - 2022-06-25 03:21:19 --> Language Class Initialized
INFO - 2022-06-25 03:21:19 --> Config Class Initialized
INFO - 2022-06-25 03:21:19 --> Loader Class Initialized
INFO - 2022-06-25 03:21:19 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:19 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:19 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:19 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:19 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:19 --> Controller Class Initialized
INFO - 2022-06-25 03:21:19 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:21:19 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:19 --> Total execution time: 0.0462
INFO - 2022-06-25 03:21:19 --> Config Class Initialized
INFO - 2022-06-25 03:21:19 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:19 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:19 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:19 --> URI Class Initialized
INFO - 2022-06-25 03:21:19 --> Router Class Initialized
INFO - 2022-06-25 03:21:19 --> Output Class Initialized
INFO - 2022-06-25 03:21:19 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:19 --> Input Class Initialized
INFO - 2022-06-25 03:21:19 --> Language Class Initialized
INFO - 2022-06-25 03:21:19 --> Language Class Initialized
INFO - 2022-06-25 03:21:19 --> Config Class Initialized
INFO - 2022-06-25 03:21:19 --> Loader Class Initialized
INFO - 2022-06-25 03:21:19 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:19 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:19 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:19 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:19 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:19 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-25 03:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:19 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:19 --> Total execution time: 0.5585
INFO - 2022-06-25 03:21:20 --> Config Class Initialized
INFO - 2022-06-25 03:21:20 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:20 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:20 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:20 --> URI Class Initialized
INFO - 2022-06-25 03:21:20 --> Router Class Initialized
INFO - 2022-06-25 03:21:20 --> Output Class Initialized
INFO - 2022-06-25 03:21:20 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:20 --> Input Class Initialized
INFO - 2022-06-25 03:21:20 --> Language Class Initialized
INFO - 2022-06-25 03:21:20 --> Language Class Initialized
INFO - 2022-06-25 03:21:20 --> Config Class Initialized
INFO - 2022-06-25 03:21:20 --> Loader Class Initialized
INFO - 2022-06-25 03:21:20 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:20 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:20 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:20 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:20 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:20 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-25 03:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:20 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:20 --> Total execution time: 0.0462
INFO - 2022-06-25 03:21:23 --> Config Class Initialized
INFO - 2022-06-25 03:21:23 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:23 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:23 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:23 --> URI Class Initialized
INFO - 2022-06-25 03:21:23 --> Router Class Initialized
INFO - 2022-06-25 03:21:24 --> Output Class Initialized
INFO - 2022-06-25 03:21:24 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:24 --> Input Class Initialized
INFO - 2022-06-25 03:21:24 --> Language Class Initialized
INFO - 2022-06-25 03:21:24 --> Language Class Initialized
INFO - 2022-06-25 03:21:24 --> Config Class Initialized
INFO - 2022-06-25 03:21:24 --> Loader Class Initialized
INFO - 2022-06-25 03:21:24 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:24 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:24 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:24 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:24 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:24 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:21:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:24 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:24 --> Total execution time: 0.0507
INFO - 2022-06-25 03:21:24 --> Config Class Initialized
INFO - 2022-06-25 03:21:24 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:24 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:24 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:24 --> URI Class Initialized
INFO - 2022-06-25 03:21:24 --> Router Class Initialized
INFO - 2022-06-25 03:21:24 --> Output Class Initialized
INFO - 2022-06-25 03:21:24 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:24 --> Input Class Initialized
INFO - 2022-06-25 03:21:24 --> Language Class Initialized
INFO - 2022-06-25 03:21:24 --> Language Class Initialized
INFO - 2022-06-25 03:21:24 --> Config Class Initialized
INFO - 2022-06-25 03:21:24 --> Loader Class Initialized
INFO - 2022-06-25 03:21:24 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:24 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:24 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:24 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:24 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:24 --> Controller Class Initialized
INFO - 2022-06-25 03:21:25 --> Config Class Initialized
INFO - 2022-06-25 03:21:25 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:25 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:25 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:25 --> URI Class Initialized
INFO - 2022-06-25 03:21:25 --> Router Class Initialized
INFO - 2022-06-25 03:21:25 --> Output Class Initialized
INFO - 2022-06-25 03:21:25 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:25 --> Input Class Initialized
INFO - 2022-06-25 03:21:25 --> Language Class Initialized
INFO - 2022-06-25 03:21:25 --> Language Class Initialized
INFO - 2022-06-25 03:21:25 --> Config Class Initialized
INFO - 2022-06-25 03:21:25 --> Loader Class Initialized
INFO - 2022-06-25 03:21:25 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:25 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:25 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:25 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:25 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:25 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:25 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:25 --> Total execution time: 0.0487
INFO - 2022-06-25 03:21:27 --> Config Class Initialized
INFO - 2022-06-25 03:21:27 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:27 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:27 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:27 --> URI Class Initialized
INFO - 2022-06-25 03:21:27 --> Router Class Initialized
INFO - 2022-06-25 03:21:27 --> Output Class Initialized
INFO - 2022-06-25 03:21:27 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:27 --> Input Class Initialized
INFO - 2022-06-25 03:21:27 --> Language Class Initialized
INFO - 2022-06-25 03:21:27 --> Language Class Initialized
INFO - 2022-06-25 03:21:27 --> Config Class Initialized
INFO - 2022-06-25 03:21:27 --> Loader Class Initialized
INFO - 2022-06-25 03:21:27 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:27 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:27 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:27 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:27 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:27 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:21:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:27 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:27 --> Total execution time: 0.0482
INFO - 2022-06-25 03:21:27 --> Config Class Initialized
INFO - 2022-06-25 03:21:27 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:27 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:27 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:27 --> URI Class Initialized
INFO - 2022-06-25 03:21:27 --> Router Class Initialized
INFO - 2022-06-25 03:21:27 --> Output Class Initialized
INFO - 2022-06-25 03:21:27 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:27 --> Input Class Initialized
INFO - 2022-06-25 03:21:27 --> Language Class Initialized
INFO - 2022-06-25 03:21:27 --> Language Class Initialized
INFO - 2022-06-25 03:21:27 --> Config Class Initialized
INFO - 2022-06-25 03:21:27 --> Loader Class Initialized
INFO - 2022-06-25 03:21:27 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:27 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:27 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:27 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:27 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:27 --> Controller Class Initialized
INFO - 2022-06-25 03:21:29 --> Config Class Initialized
INFO - 2022-06-25 03:21:29 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:29 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:29 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:29 --> URI Class Initialized
INFO - 2022-06-25 03:21:29 --> Router Class Initialized
INFO - 2022-06-25 03:21:29 --> Output Class Initialized
INFO - 2022-06-25 03:21:29 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:29 --> Input Class Initialized
INFO - 2022-06-25 03:21:29 --> Language Class Initialized
INFO - 2022-06-25 03:21:29 --> Language Class Initialized
INFO - 2022-06-25 03:21:29 --> Config Class Initialized
INFO - 2022-06-25 03:21:29 --> Loader Class Initialized
INFO - 2022-06-25 03:21:29 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:29 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:29 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:29 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:29 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:29 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:29 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:29 --> Total execution time: 0.0491
INFO - 2022-06-25 03:21:30 --> Config Class Initialized
INFO - 2022-06-25 03:21:30 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:30 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:30 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:30 --> URI Class Initialized
INFO - 2022-06-25 03:21:30 --> Router Class Initialized
INFO - 2022-06-25 03:21:30 --> Output Class Initialized
INFO - 2022-06-25 03:21:30 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:30 --> Input Class Initialized
INFO - 2022-06-25 03:21:30 --> Language Class Initialized
INFO - 2022-06-25 03:21:30 --> Language Class Initialized
INFO - 2022-06-25 03:21:30 --> Config Class Initialized
INFO - 2022-06-25 03:21:30 --> Loader Class Initialized
INFO - 2022-06-25 03:21:30 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:30 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:30 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:30 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:30 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:30 --> Controller Class Initialized
INFO - 2022-06-25 03:21:32 --> Config Class Initialized
INFO - 2022-06-25 03:21:32 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:32 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:32 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:32 --> URI Class Initialized
INFO - 2022-06-25 03:21:32 --> Router Class Initialized
INFO - 2022-06-25 03:21:32 --> Output Class Initialized
INFO - 2022-06-25 03:21:32 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:32 --> Input Class Initialized
INFO - 2022-06-25 03:21:32 --> Language Class Initialized
INFO - 2022-06-25 03:21:32 --> Language Class Initialized
INFO - 2022-06-25 03:21:32 --> Config Class Initialized
INFO - 2022-06-25 03:21:32 --> Loader Class Initialized
INFO - 2022-06-25 03:21:32 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:32 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:32 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:32 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:32 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:32 --> Controller Class Initialized
INFO - 2022-06-25 03:21:33 --> Config Class Initialized
INFO - 2022-06-25 03:21:33 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:33 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:33 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:33 --> URI Class Initialized
INFO - 2022-06-25 03:21:33 --> Router Class Initialized
INFO - 2022-06-25 03:21:33 --> Output Class Initialized
INFO - 2022-06-25 03:21:33 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:33 --> Input Class Initialized
INFO - 2022-06-25 03:21:33 --> Language Class Initialized
INFO - 2022-06-25 03:21:33 --> Language Class Initialized
INFO - 2022-06-25 03:21:33 --> Config Class Initialized
INFO - 2022-06-25 03:21:33 --> Loader Class Initialized
INFO - 2022-06-25 03:21:33 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:33 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:33 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:33 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:33 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:33 --> Controller Class Initialized
INFO - 2022-06-25 03:21:35 --> Config Class Initialized
INFO - 2022-06-25 03:21:35 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:35 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:35 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:35 --> URI Class Initialized
INFO - 2022-06-25 03:21:35 --> Router Class Initialized
INFO - 2022-06-25 03:21:35 --> Output Class Initialized
INFO - 2022-06-25 03:21:35 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:35 --> Input Class Initialized
INFO - 2022-06-25 03:21:35 --> Language Class Initialized
INFO - 2022-06-25 03:21:35 --> Language Class Initialized
INFO - 2022-06-25 03:21:35 --> Config Class Initialized
INFO - 2022-06-25 03:21:35 --> Loader Class Initialized
INFO - 2022-06-25 03:21:35 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:35 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:35 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:35 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:35 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:35 --> Controller Class Initialized
INFO - 2022-06-25 03:21:38 --> Config Class Initialized
INFO - 2022-06-25 03:21:38 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:38 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:38 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:38 --> URI Class Initialized
INFO - 2022-06-25 03:21:38 --> Router Class Initialized
INFO - 2022-06-25 03:21:38 --> Output Class Initialized
INFO - 2022-06-25 03:21:38 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:38 --> Input Class Initialized
INFO - 2022-06-25 03:21:38 --> Language Class Initialized
INFO - 2022-06-25 03:21:38 --> Language Class Initialized
INFO - 2022-06-25 03:21:38 --> Config Class Initialized
INFO - 2022-06-25 03:21:38 --> Loader Class Initialized
INFO - 2022-06-25 03:21:38 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:38 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:38 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:38 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:38 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:38 --> Controller Class Initialized
INFO - 2022-06-25 03:21:38 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:21:38 --> Config Class Initialized
INFO - 2022-06-25 03:21:38 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:38 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:38 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:38 --> URI Class Initialized
INFO - 2022-06-25 03:21:38 --> Router Class Initialized
INFO - 2022-06-25 03:21:38 --> Output Class Initialized
INFO - 2022-06-25 03:21:38 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:38 --> Input Class Initialized
INFO - 2022-06-25 03:21:38 --> Language Class Initialized
INFO - 2022-06-25 03:21:38 --> Language Class Initialized
INFO - 2022-06-25 03:21:38 --> Config Class Initialized
INFO - 2022-06-25 03:21:38 --> Loader Class Initialized
INFO - 2022-06-25 03:21:38 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:38 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:38 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:38 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:38 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:38 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-25 03:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:38 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:38 --> Total execution time: 0.0429
INFO - 2022-06-25 03:21:41 --> Config Class Initialized
INFO - 2022-06-25 03:21:41 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:41 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:41 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:41 --> URI Class Initialized
INFO - 2022-06-25 03:21:41 --> Router Class Initialized
INFO - 2022-06-25 03:21:41 --> Output Class Initialized
INFO - 2022-06-25 03:21:41 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:41 --> Input Class Initialized
INFO - 2022-06-25 03:21:41 --> Language Class Initialized
INFO - 2022-06-25 03:21:41 --> Language Class Initialized
INFO - 2022-06-25 03:21:41 --> Config Class Initialized
INFO - 2022-06-25 03:21:41 --> Loader Class Initialized
INFO - 2022-06-25 03:21:41 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:41 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:41 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:41 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:41 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:41 --> Controller Class Initialized
INFO - 2022-06-25 03:21:41 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:21:41 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:41 --> Total execution time: 0.0639
INFO - 2022-06-25 03:21:41 --> Config Class Initialized
INFO - 2022-06-25 03:21:41 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:41 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:41 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:41 --> URI Class Initialized
INFO - 2022-06-25 03:21:41 --> Router Class Initialized
INFO - 2022-06-25 03:21:41 --> Output Class Initialized
INFO - 2022-06-25 03:21:41 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:41 --> Input Class Initialized
INFO - 2022-06-25 03:21:41 --> Language Class Initialized
INFO - 2022-06-25 03:21:41 --> Language Class Initialized
INFO - 2022-06-25 03:21:41 --> Config Class Initialized
INFO - 2022-06-25 03:21:41 --> Loader Class Initialized
INFO - 2022-06-25 03:21:41 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:41 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:41 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:41 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:41 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:41 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-25 03:21:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:42 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:42 --> Total execution time: 0.5830
INFO - 2022-06-25 03:21:43 --> Config Class Initialized
INFO - 2022-06-25 03:21:43 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:21:43 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:21:43 --> Utf8 Class Initialized
INFO - 2022-06-25 03:21:43 --> URI Class Initialized
INFO - 2022-06-25 03:21:43 --> Router Class Initialized
INFO - 2022-06-25 03:21:43 --> Output Class Initialized
INFO - 2022-06-25 03:21:43 --> Security Class Initialized
DEBUG - 2022-06-25 03:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:21:43 --> Input Class Initialized
INFO - 2022-06-25 03:21:43 --> Language Class Initialized
INFO - 2022-06-25 03:21:43 --> Language Class Initialized
INFO - 2022-06-25 03:21:43 --> Config Class Initialized
INFO - 2022-06-25 03:21:43 --> Loader Class Initialized
INFO - 2022-06-25 03:21:43 --> Helper loaded: url_helper
INFO - 2022-06-25 03:21:43 --> Helper loaded: file_helper
INFO - 2022-06-25 03:21:43 --> Helper loaded: form_helper
INFO - 2022-06-25 03:21:43 --> Helper loaded: my_helper
INFO - 2022-06-25 03:21:43 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:21:43 --> Controller Class Initialized
DEBUG - 2022-06-25 03:21:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-25 03:21:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:21:43 --> Final output sent to browser
DEBUG - 2022-06-25 03:21:43 --> Total execution time: 0.0467
INFO - 2022-06-25 03:22:02 --> Config Class Initialized
INFO - 2022-06-25 03:22:02 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:02 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:02 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:02 --> URI Class Initialized
INFO - 2022-06-25 03:22:02 --> Router Class Initialized
INFO - 2022-06-25 03:22:02 --> Output Class Initialized
INFO - 2022-06-25 03:22:02 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:02 --> Input Class Initialized
INFO - 2022-06-25 03:22:02 --> Language Class Initialized
INFO - 2022-06-25 03:22:02 --> Language Class Initialized
INFO - 2022-06-25 03:22:02 --> Config Class Initialized
INFO - 2022-06-25 03:22:02 --> Loader Class Initialized
INFO - 2022-06-25 03:22:02 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:02 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:02 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:02 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:02 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:02 --> Controller Class Initialized
INFO - 2022-06-25 03:22:02 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:22:02 --> Config Class Initialized
INFO - 2022-06-25 03:22:02 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:02 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:02 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:02 --> URI Class Initialized
INFO - 2022-06-25 03:22:02 --> Router Class Initialized
INFO - 2022-06-25 03:22:02 --> Output Class Initialized
INFO - 2022-06-25 03:22:02 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:02 --> Input Class Initialized
INFO - 2022-06-25 03:22:02 --> Language Class Initialized
INFO - 2022-06-25 03:22:02 --> Language Class Initialized
INFO - 2022-06-25 03:22:02 --> Config Class Initialized
INFO - 2022-06-25 03:22:02 --> Loader Class Initialized
INFO - 2022-06-25 03:22:02 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:02 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:02 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:02 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:02 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:02 --> Controller Class Initialized
DEBUG - 2022-06-25 03:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-25 03:22:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:22:02 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:02 --> Total execution time: 0.0551
INFO - 2022-06-25 03:22:05 --> Config Class Initialized
INFO - 2022-06-25 03:22:05 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:05 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:05 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:05 --> URI Class Initialized
INFO - 2022-06-25 03:22:05 --> Router Class Initialized
INFO - 2022-06-25 03:22:05 --> Output Class Initialized
INFO - 2022-06-25 03:22:05 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:05 --> Input Class Initialized
INFO - 2022-06-25 03:22:05 --> Language Class Initialized
INFO - 2022-06-25 03:22:05 --> Language Class Initialized
INFO - 2022-06-25 03:22:05 --> Config Class Initialized
INFO - 2022-06-25 03:22:05 --> Loader Class Initialized
INFO - 2022-06-25 03:22:05 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:05 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:05 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:05 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:05 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:05 --> Controller Class Initialized
INFO - 2022-06-25 03:22:05 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:22:05 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:05 --> Total execution time: 0.0601
INFO - 2022-06-25 03:22:05 --> Config Class Initialized
INFO - 2022-06-25 03:22:05 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:05 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:05 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:05 --> URI Class Initialized
INFO - 2022-06-25 03:22:05 --> Router Class Initialized
INFO - 2022-06-25 03:22:05 --> Output Class Initialized
INFO - 2022-06-25 03:22:05 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:05 --> Input Class Initialized
INFO - 2022-06-25 03:22:05 --> Language Class Initialized
INFO - 2022-06-25 03:22:05 --> Language Class Initialized
INFO - 2022-06-25 03:22:05 --> Config Class Initialized
INFO - 2022-06-25 03:22:05 --> Loader Class Initialized
INFO - 2022-06-25 03:22:05 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:05 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:05 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:05 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:05 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:05 --> Controller Class Initialized
DEBUG - 2022-06-25 03:22:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-25 03:22:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:22:06 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:06 --> Total execution time: 0.5475
INFO - 2022-06-25 03:22:08 --> Config Class Initialized
INFO - 2022-06-25 03:22:08 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:08 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:08 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:08 --> URI Class Initialized
INFO - 2022-06-25 03:22:08 --> Router Class Initialized
INFO - 2022-06-25 03:22:08 --> Output Class Initialized
INFO - 2022-06-25 03:22:08 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:08 --> Input Class Initialized
INFO - 2022-06-25 03:22:08 --> Language Class Initialized
INFO - 2022-06-25 03:22:08 --> Language Class Initialized
INFO - 2022-06-25 03:22:08 --> Config Class Initialized
INFO - 2022-06-25 03:22:08 --> Loader Class Initialized
INFO - 2022-06-25 03:22:08 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:08 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:08 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:08 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:08 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:08 --> Controller Class Initialized
DEBUG - 2022-06-25 03:22:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-06-25 03:22:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:22:08 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:08 --> Total execution time: 0.0689
INFO - 2022-06-25 03:22:08 --> Config Class Initialized
INFO - 2022-06-25 03:22:08 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:08 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:08 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:08 --> URI Class Initialized
INFO - 2022-06-25 03:22:08 --> Router Class Initialized
INFO - 2022-06-25 03:22:08 --> Output Class Initialized
INFO - 2022-06-25 03:22:08 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:08 --> Input Class Initialized
INFO - 2022-06-25 03:22:08 --> Language Class Initialized
INFO - 2022-06-25 03:22:08 --> Language Class Initialized
INFO - 2022-06-25 03:22:08 --> Config Class Initialized
INFO - 2022-06-25 03:22:08 --> Loader Class Initialized
INFO - 2022-06-25 03:22:08 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:08 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:08 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:08 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:08 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:08 --> Controller Class Initialized
INFO - 2022-06-25 03:22:09 --> Config Class Initialized
INFO - 2022-06-25 03:22:09 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:09 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:09 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:09 --> URI Class Initialized
INFO - 2022-06-25 03:22:09 --> Router Class Initialized
INFO - 2022-06-25 03:22:09 --> Output Class Initialized
INFO - 2022-06-25 03:22:09 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:09 --> Input Class Initialized
INFO - 2022-06-25 03:22:09 --> Language Class Initialized
INFO - 2022-06-25 03:22:09 --> Language Class Initialized
INFO - 2022-06-25 03:22:09 --> Config Class Initialized
INFO - 2022-06-25 03:22:09 --> Loader Class Initialized
INFO - 2022-06-25 03:22:09 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:09 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:09 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:09 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:09 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:09 --> Controller Class Initialized
INFO - 2022-06-25 03:22:10 --> Config Class Initialized
INFO - 2022-06-25 03:22:10 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:10 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:10 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:10 --> URI Class Initialized
INFO - 2022-06-25 03:22:10 --> Router Class Initialized
INFO - 2022-06-25 03:22:10 --> Output Class Initialized
INFO - 2022-06-25 03:22:10 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:10 --> Input Class Initialized
INFO - 2022-06-25 03:22:10 --> Language Class Initialized
INFO - 2022-06-25 03:22:10 --> Language Class Initialized
INFO - 2022-06-25 03:22:10 --> Config Class Initialized
INFO - 2022-06-25 03:22:10 --> Loader Class Initialized
INFO - 2022-06-25 03:22:10 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:10 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:10 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:10 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:10 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:10 --> Controller Class Initialized
INFO - 2022-06-25 03:22:11 --> Config Class Initialized
INFO - 2022-06-25 03:22:11 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:11 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:11 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:11 --> URI Class Initialized
INFO - 2022-06-25 03:22:11 --> Router Class Initialized
INFO - 2022-06-25 03:22:11 --> Output Class Initialized
INFO - 2022-06-25 03:22:11 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:11 --> Input Class Initialized
INFO - 2022-06-25 03:22:11 --> Language Class Initialized
INFO - 2022-06-25 03:22:11 --> Language Class Initialized
INFO - 2022-06-25 03:22:11 --> Config Class Initialized
INFO - 2022-06-25 03:22:11 --> Loader Class Initialized
INFO - 2022-06-25 03:22:11 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:11 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:11 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:11 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:11 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:11 --> Controller Class Initialized
INFO - 2022-06-25 03:22:12 --> Config Class Initialized
INFO - 2022-06-25 03:22:12 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:12 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:12 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:12 --> URI Class Initialized
INFO - 2022-06-25 03:22:12 --> Router Class Initialized
INFO - 2022-06-25 03:22:12 --> Output Class Initialized
INFO - 2022-06-25 03:22:12 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:12 --> Input Class Initialized
INFO - 2022-06-25 03:22:12 --> Language Class Initialized
INFO - 2022-06-25 03:22:12 --> Language Class Initialized
INFO - 2022-06-25 03:22:12 --> Config Class Initialized
INFO - 2022-06-25 03:22:12 --> Loader Class Initialized
INFO - 2022-06-25 03:22:12 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:12 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:12 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:12 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:12 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:12 --> Controller Class Initialized
INFO - 2022-06-25 03:22:13 --> Config Class Initialized
INFO - 2022-06-25 03:22:13 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:13 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:13 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:13 --> URI Class Initialized
INFO - 2022-06-25 03:22:13 --> Router Class Initialized
INFO - 2022-06-25 03:22:13 --> Output Class Initialized
INFO - 2022-06-25 03:22:13 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:13 --> Input Class Initialized
INFO - 2022-06-25 03:22:13 --> Language Class Initialized
INFO - 2022-06-25 03:22:13 --> Language Class Initialized
INFO - 2022-06-25 03:22:13 --> Config Class Initialized
INFO - 2022-06-25 03:22:13 --> Loader Class Initialized
INFO - 2022-06-25 03:22:13 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:13 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:13 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:13 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:13 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:13 --> Controller Class Initialized
INFO - 2022-06-25 03:22:13 --> Config Class Initialized
INFO - 2022-06-25 03:22:13 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:13 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:13 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:13 --> URI Class Initialized
INFO - 2022-06-25 03:22:13 --> Router Class Initialized
INFO - 2022-06-25 03:22:13 --> Output Class Initialized
INFO - 2022-06-25 03:22:13 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:13 --> Input Class Initialized
INFO - 2022-06-25 03:22:13 --> Language Class Initialized
INFO - 2022-06-25 03:22:13 --> Language Class Initialized
INFO - 2022-06-25 03:22:13 --> Config Class Initialized
INFO - 2022-06-25 03:22:13 --> Loader Class Initialized
INFO - 2022-06-25 03:22:13 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:13 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:13 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:13 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:13 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:13 --> Controller Class Initialized
INFO - 2022-06-25 03:22:13 --> Config Class Initialized
INFO - 2022-06-25 03:22:13 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:13 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:13 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:13 --> URI Class Initialized
INFO - 2022-06-25 03:22:13 --> Router Class Initialized
INFO - 2022-06-25 03:22:13 --> Output Class Initialized
INFO - 2022-06-25 03:22:13 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:13 --> Input Class Initialized
INFO - 2022-06-25 03:22:13 --> Language Class Initialized
INFO - 2022-06-25 03:22:13 --> Language Class Initialized
INFO - 2022-06-25 03:22:13 --> Config Class Initialized
INFO - 2022-06-25 03:22:13 --> Loader Class Initialized
INFO - 2022-06-25 03:22:13 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:13 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:13 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:13 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:13 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:13 --> Controller Class Initialized
INFO - 2022-06-25 03:22:17 --> Config Class Initialized
INFO - 2022-06-25 03:22:17 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:17 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:17 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:17 --> URI Class Initialized
INFO - 2022-06-25 03:22:17 --> Router Class Initialized
INFO - 2022-06-25 03:22:17 --> Output Class Initialized
INFO - 2022-06-25 03:22:17 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:17 --> Input Class Initialized
INFO - 2022-06-25 03:22:17 --> Language Class Initialized
INFO - 2022-06-25 03:22:17 --> Language Class Initialized
INFO - 2022-06-25 03:22:17 --> Config Class Initialized
INFO - 2022-06-25 03:22:17 --> Loader Class Initialized
INFO - 2022-06-25 03:22:17 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:17 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:17 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:17 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:17 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:17 --> Controller Class Initialized
INFO - 2022-06-25 03:22:17 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:22:17 --> Config Class Initialized
INFO - 2022-06-25 03:22:17 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:17 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:17 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:17 --> URI Class Initialized
INFO - 2022-06-25 03:22:17 --> Router Class Initialized
INFO - 2022-06-25 03:22:17 --> Output Class Initialized
INFO - 2022-06-25 03:22:17 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:17 --> Input Class Initialized
INFO - 2022-06-25 03:22:17 --> Language Class Initialized
INFO - 2022-06-25 03:22:17 --> Language Class Initialized
INFO - 2022-06-25 03:22:17 --> Config Class Initialized
INFO - 2022-06-25 03:22:17 --> Loader Class Initialized
INFO - 2022-06-25 03:22:17 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:17 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:17 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:17 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:17 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:17 --> Controller Class Initialized
DEBUG - 2022-06-25 03:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-25 03:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:22:17 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:17 --> Total execution time: 0.0423
INFO - 2022-06-25 03:22:20 --> Config Class Initialized
INFO - 2022-06-25 03:22:20 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:20 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:20 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:20 --> URI Class Initialized
INFO - 2022-06-25 03:22:20 --> Router Class Initialized
INFO - 2022-06-25 03:22:20 --> Output Class Initialized
INFO - 2022-06-25 03:22:20 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:20 --> Input Class Initialized
INFO - 2022-06-25 03:22:20 --> Language Class Initialized
INFO - 2022-06-25 03:22:20 --> Language Class Initialized
INFO - 2022-06-25 03:22:20 --> Config Class Initialized
INFO - 2022-06-25 03:22:20 --> Loader Class Initialized
INFO - 2022-06-25 03:22:20 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:20 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:20 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:20 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:20 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:20 --> Controller Class Initialized
INFO - 2022-06-25 03:22:20 --> Helper loaded: cookie_helper
INFO - 2022-06-25 03:22:20 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:20 --> Total execution time: 0.0583
INFO - 2022-06-25 03:22:20 --> Config Class Initialized
INFO - 2022-06-25 03:22:20 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:20 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:20 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:20 --> URI Class Initialized
INFO - 2022-06-25 03:22:20 --> Router Class Initialized
INFO - 2022-06-25 03:22:20 --> Output Class Initialized
INFO - 2022-06-25 03:22:20 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:20 --> Input Class Initialized
INFO - 2022-06-25 03:22:20 --> Language Class Initialized
INFO - 2022-06-25 03:22:20 --> Language Class Initialized
INFO - 2022-06-25 03:22:20 --> Config Class Initialized
INFO - 2022-06-25 03:22:20 --> Loader Class Initialized
INFO - 2022-06-25 03:22:20 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:20 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:20 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:20 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:20 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:20 --> Controller Class Initialized
DEBUG - 2022-06-25 03:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-25 03:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:22:21 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:21 --> Total execution time: 0.5387
INFO - 2022-06-25 03:22:22 --> Config Class Initialized
INFO - 2022-06-25 03:22:22 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:22 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:22 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:22 --> URI Class Initialized
INFO - 2022-06-25 03:22:22 --> Router Class Initialized
INFO - 2022-06-25 03:22:22 --> Output Class Initialized
INFO - 2022-06-25 03:22:22 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:22 --> Input Class Initialized
INFO - 2022-06-25 03:22:22 --> Language Class Initialized
INFO - 2022-06-25 03:22:22 --> Language Class Initialized
INFO - 2022-06-25 03:22:22 --> Config Class Initialized
INFO - 2022-06-25 03:22:22 --> Loader Class Initialized
INFO - 2022-06-25 03:22:22 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:22 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:22 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:22 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:22 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:22 --> Controller Class Initialized
DEBUG - 2022-06-25 03:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-25 03:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:22:22 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:22 --> Total execution time: 0.0591
INFO - 2022-06-25 03:22:28 --> Config Class Initialized
INFO - 2022-06-25 03:22:28 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:28 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:28 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:28 --> URI Class Initialized
INFO - 2022-06-25 03:22:28 --> Router Class Initialized
INFO - 2022-06-25 03:22:28 --> Output Class Initialized
INFO - 2022-06-25 03:22:28 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:28 --> Input Class Initialized
INFO - 2022-06-25 03:22:28 --> Language Class Initialized
INFO - 2022-06-25 03:22:28 --> Language Class Initialized
INFO - 2022-06-25 03:22:28 --> Config Class Initialized
INFO - 2022-06-25 03:22:28 --> Loader Class Initialized
INFO - 2022-06-25 03:22:28 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:28 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:28 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:28 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:28 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:28 --> Controller Class Initialized
DEBUG - 2022-06-25 03:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-25 03:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:22:28 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:28 --> Total execution time: 0.0501
INFO - 2022-06-25 03:22:28 --> Config Class Initialized
INFO - 2022-06-25 03:22:28 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:28 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:28 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:28 --> URI Class Initialized
INFO - 2022-06-25 03:22:28 --> Router Class Initialized
INFO - 2022-06-25 03:22:28 --> Output Class Initialized
INFO - 2022-06-25 03:22:28 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:28 --> Input Class Initialized
INFO - 2022-06-25 03:22:28 --> Language Class Initialized
INFO - 2022-06-25 03:22:28 --> Language Class Initialized
INFO - 2022-06-25 03:22:28 --> Config Class Initialized
INFO - 2022-06-25 03:22:28 --> Loader Class Initialized
INFO - 2022-06-25 03:22:28 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:28 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:28 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:28 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:28 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:28 --> Controller Class Initialized
INFO - 2022-06-25 03:22:29 --> Config Class Initialized
INFO - 2022-06-25 03:22:29 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:29 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:29 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:29 --> URI Class Initialized
INFO - 2022-06-25 03:22:29 --> Router Class Initialized
INFO - 2022-06-25 03:22:29 --> Output Class Initialized
INFO - 2022-06-25 03:22:29 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:29 --> Input Class Initialized
INFO - 2022-06-25 03:22:29 --> Language Class Initialized
INFO - 2022-06-25 03:22:29 --> Language Class Initialized
INFO - 2022-06-25 03:22:29 --> Config Class Initialized
INFO - 2022-06-25 03:22:29 --> Loader Class Initialized
INFO - 2022-06-25 03:22:29 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:29 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:29 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:29 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:29 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:29 --> Controller Class Initialized
DEBUG - 2022-06-25 03:22:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-25 03:22:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-25 03:22:29 --> Final output sent to browser
DEBUG - 2022-06-25 03:22:29 --> Total execution time: 0.0487
INFO - 2022-06-25 03:22:30 --> Config Class Initialized
INFO - 2022-06-25 03:22:30 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:30 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:30 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:30 --> URI Class Initialized
INFO - 2022-06-25 03:22:30 --> Router Class Initialized
INFO - 2022-06-25 03:22:30 --> Output Class Initialized
INFO - 2022-06-25 03:22:30 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:30 --> Input Class Initialized
INFO - 2022-06-25 03:22:30 --> Language Class Initialized
INFO - 2022-06-25 03:22:30 --> Language Class Initialized
INFO - 2022-06-25 03:22:30 --> Config Class Initialized
INFO - 2022-06-25 03:22:30 --> Loader Class Initialized
INFO - 2022-06-25 03:22:30 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:30 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:30 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:30 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:30 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:30 --> Controller Class Initialized
INFO - 2022-06-25 03:22:32 --> Config Class Initialized
INFO - 2022-06-25 03:22:32 --> Hooks Class Initialized
DEBUG - 2022-06-25 03:22:32 --> UTF-8 Support Enabled
INFO - 2022-06-25 03:22:32 --> Utf8 Class Initialized
INFO - 2022-06-25 03:22:32 --> URI Class Initialized
INFO - 2022-06-25 03:22:32 --> Router Class Initialized
INFO - 2022-06-25 03:22:32 --> Output Class Initialized
INFO - 2022-06-25 03:22:32 --> Security Class Initialized
DEBUG - 2022-06-25 03:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-25 03:22:32 --> Input Class Initialized
INFO - 2022-06-25 03:22:32 --> Language Class Initialized
INFO - 2022-06-25 03:22:32 --> Language Class Initialized
INFO - 2022-06-25 03:22:32 --> Config Class Initialized
INFO - 2022-06-25 03:22:32 --> Loader Class Initialized
INFO - 2022-06-25 03:22:32 --> Helper loaded: url_helper
INFO - 2022-06-25 03:22:32 --> Helper loaded: file_helper
INFO - 2022-06-25 03:22:32 --> Helper loaded: form_helper
INFO - 2022-06-25 03:22:32 --> Helper loaded: my_helper
INFO - 2022-06-25 03:22:32 --> Database Driver Class Initialized
DEBUG - 2022-06-25 03:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-25 03:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-25 03:22:32 --> Controller Class Initialized
