<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-02 01:26:48 --> Config Class Initialized
INFO - 2020-12-02 01:26:48 --> Hooks Class Initialized
DEBUG - 2020-12-02 01:26:48 --> UTF-8 Support Enabled
INFO - 2020-12-02 01:26:48 --> Utf8 Class Initialized
INFO - 2020-12-02 01:26:48 --> URI Class Initialized
DEBUG - 2020-12-02 01:26:48 --> No URI present. Default controller set.
INFO - 2020-12-02 01:26:48 --> Router Class Initialized
INFO - 2020-12-02 01:26:48 --> Output Class Initialized
INFO - 2020-12-02 01:26:48 --> Security Class Initialized
DEBUG - 2020-12-02 01:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 01:26:48 --> Input Class Initialized
INFO - 2020-12-02 01:26:48 --> Language Class Initialized
INFO - 2020-12-02 01:26:48 --> Language Class Initialized
INFO - 2020-12-02 01:26:48 --> Config Class Initialized
INFO - 2020-12-02 01:26:48 --> Loader Class Initialized
INFO - 2020-12-02 01:26:48 --> Helper loaded: url_helper
INFO - 2020-12-02 01:26:48 --> Helper loaded: file_helper
INFO - 2020-12-02 01:26:48 --> Helper loaded: form_helper
INFO - 2020-12-02 01:26:48 --> Helper loaded: my_helper
INFO - 2020-12-02 01:26:48 --> Database Driver Class Initialized
DEBUG - 2020-12-02 01:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 01:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 01:26:48 --> Controller Class Initialized
INFO - 2020-12-02 01:26:48 --> Config Class Initialized
INFO - 2020-12-02 01:26:48 --> Hooks Class Initialized
DEBUG - 2020-12-02 01:26:48 --> UTF-8 Support Enabled
INFO - 2020-12-02 01:26:48 --> Utf8 Class Initialized
INFO - 2020-12-02 01:26:48 --> URI Class Initialized
INFO - 2020-12-02 01:26:48 --> Router Class Initialized
INFO - 2020-12-02 01:26:48 --> Output Class Initialized
INFO - 2020-12-02 01:26:48 --> Security Class Initialized
DEBUG - 2020-12-02 01:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 01:26:48 --> Input Class Initialized
INFO - 2020-12-02 01:26:48 --> Language Class Initialized
INFO - 2020-12-02 01:26:49 --> Language Class Initialized
INFO - 2020-12-02 01:26:49 --> Config Class Initialized
INFO - 2020-12-02 01:26:49 --> Loader Class Initialized
INFO - 2020-12-02 01:26:49 --> Helper loaded: url_helper
INFO - 2020-12-02 01:26:49 --> Helper loaded: file_helper
INFO - 2020-12-02 01:26:49 --> Helper loaded: form_helper
INFO - 2020-12-02 01:26:49 --> Helper loaded: my_helper
INFO - 2020-12-02 01:26:49 --> Database Driver Class Initialized
DEBUG - 2020-12-02 01:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 01:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 01:26:49 --> Controller Class Initialized
DEBUG - 2020-12-02 01:26:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-02 01:26:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 01:26:49 --> Final output sent to browser
DEBUG - 2020-12-02 01:26:49 --> Total execution time: 0.2113
INFO - 2020-12-02 05:49:16 --> Config Class Initialized
INFO - 2020-12-02 05:49:16 --> Hooks Class Initialized
DEBUG - 2020-12-02 05:49:16 --> UTF-8 Support Enabled
INFO - 2020-12-02 05:49:16 --> Utf8 Class Initialized
INFO - 2020-12-02 05:49:16 --> URI Class Initialized
INFO - 2020-12-02 05:49:16 --> Router Class Initialized
INFO - 2020-12-02 05:49:16 --> Output Class Initialized
INFO - 2020-12-02 05:49:16 --> Security Class Initialized
DEBUG - 2020-12-02 05:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 05:49:16 --> Input Class Initialized
INFO - 2020-12-02 05:49:16 --> Language Class Initialized
INFO - 2020-12-02 05:49:16 --> Language Class Initialized
INFO - 2020-12-02 05:49:16 --> Config Class Initialized
INFO - 2020-12-02 05:49:16 --> Loader Class Initialized
INFO - 2020-12-02 05:49:16 --> Helper loaded: url_helper
INFO - 2020-12-02 05:49:16 --> Helper loaded: file_helper
INFO - 2020-12-02 05:49:16 --> Helper loaded: form_helper
INFO - 2020-12-02 05:49:16 --> Helper loaded: my_helper
INFO - 2020-12-02 05:49:16 --> Database Driver Class Initialized
DEBUG - 2020-12-02 05:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 05:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 05:49:16 --> Controller Class Initialized
INFO - 2020-12-02 05:49:16 --> Helper loaded: cookie_helper
INFO - 2020-12-02 05:49:16 --> Final output sent to browser
DEBUG - 2020-12-02 05:49:16 --> Total execution time: 0.3264
INFO - 2020-12-02 05:49:17 --> Config Class Initialized
INFO - 2020-12-02 05:49:17 --> Hooks Class Initialized
DEBUG - 2020-12-02 05:49:17 --> UTF-8 Support Enabled
INFO - 2020-12-02 05:49:17 --> Utf8 Class Initialized
INFO - 2020-12-02 05:49:17 --> URI Class Initialized
INFO - 2020-12-02 05:49:17 --> Router Class Initialized
INFO - 2020-12-02 05:49:17 --> Output Class Initialized
INFO - 2020-12-02 05:49:17 --> Security Class Initialized
DEBUG - 2020-12-02 05:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 05:49:17 --> Input Class Initialized
INFO - 2020-12-02 05:49:17 --> Language Class Initialized
INFO - 2020-12-02 05:49:17 --> Language Class Initialized
INFO - 2020-12-02 05:49:17 --> Config Class Initialized
INFO - 2020-12-02 05:49:17 --> Loader Class Initialized
INFO - 2020-12-02 05:49:17 --> Helper loaded: url_helper
INFO - 2020-12-02 05:49:17 --> Helper loaded: file_helper
INFO - 2020-12-02 05:49:17 --> Helper loaded: form_helper
INFO - 2020-12-02 05:49:17 --> Helper loaded: my_helper
INFO - 2020-12-02 05:49:17 --> Database Driver Class Initialized
DEBUG - 2020-12-02 05:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 05:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 05:49:17 --> Controller Class Initialized
DEBUG - 2020-12-02 05:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-02 05:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 05:49:17 --> Final output sent to browser
DEBUG - 2020-12-02 05:49:17 --> Total execution time: 0.1928
INFO - 2020-12-02 07:41:05 --> Config Class Initialized
INFO - 2020-12-02 07:41:05 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:05 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:05 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:05 --> URI Class Initialized
INFO - 2020-12-02 07:41:05 --> Router Class Initialized
INFO - 2020-12-02 07:41:05 --> Output Class Initialized
INFO - 2020-12-02 07:41:05 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:05 --> Input Class Initialized
INFO - 2020-12-02 07:41:05 --> Language Class Initialized
INFO - 2020-12-02 07:41:05 --> Language Class Initialized
INFO - 2020-12-02 07:41:05 --> Config Class Initialized
INFO - 2020-12-02 07:41:05 --> Loader Class Initialized
INFO - 2020-12-02 07:41:05 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:05 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:05 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:05 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:05 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:05 --> Controller Class Initialized
INFO - 2020-12-02 07:41:05 --> Helper loaded: cookie_helper
INFO - 2020-12-02 07:41:05 --> Config Class Initialized
INFO - 2020-12-02 07:41:05 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:05 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:05 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:05 --> URI Class Initialized
INFO - 2020-12-02 07:41:05 --> Router Class Initialized
INFO - 2020-12-02 07:41:05 --> Output Class Initialized
INFO - 2020-12-02 07:41:05 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:05 --> Input Class Initialized
INFO - 2020-12-02 07:41:05 --> Language Class Initialized
INFO - 2020-12-02 07:41:05 --> Language Class Initialized
INFO - 2020-12-02 07:41:05 --> Config Class Initialized
INFO - 2020-12-02 07:41:05 --> Loader Class Initialized
INFO - 2020-12-02 07:41:05 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:05 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:05 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:05 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:05 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:05 --> Controller Class Initialized
DEBUG - 2020-12-02 07:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-02 07:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 07:41:05 --> Final output sent to browser
DEBUG - 2020-12-02 07:41:05 --> Total execution time: 0.1647
INFO - 2020-12-02 07:41:10 --> Config Class Initialized
INFO - 2020-12-02 07:41:10 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:10 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:10 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:10 --> URI Class Initialized
INFO - 2020-12-02 07:41:10 --> Router Class Initialized
INFO - 2020-12-02 07:41:10 --> Output Class Initialized
INFO - 2020-12-02 07:41:10 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:10 --> Input Class Initialized
INFO - 2020-12-02 07:41:10 --> Language Class Initialized
INFO - 2020-12-02 07:41:10 --> Language Class Initialized
INFO - 2020-12-02 07:41:10 --> Config Class Initialized
INFO - 2020-12-02 07:41:10 --> Loader Class Initialized
INFO - 2020-12-02 07:41:10 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:10 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:10 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:10 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:10 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:10 --> Controller Class Initialized
INFO - 2020-12-02 07:41:10 --> Helper loaded: cookie_helper
INFO - 2020-12-02 07:41:10 --> Final output sent to browser
DEBUG - 2020-12-02 07:41:10 --> Total execution time: 0.1682
INFO - 2020-12-02 07:41:11 --> Config Class Initialized
INFO - 2020-12-02 07:41:11 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:11 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:11 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:11 --> URI Class Initialized
INFO - 2020-12-02 07:41:11 --> Router Class Initialized
INFO - 2020-12-02 07:41:11 --> Output Class Initialized
INFO - 2020-12-02 07:41:11 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:11 --> Input Class Initialized
INFO - 2020-12-02 07:41:11 --> Language Class Initialized
INFO - 2020-12-02 07:41:11 --> Language Class Initialized
INFO - 2020-12-02 07:41:11 --> Config Class Initialized
INFO - 2020-12-02 07:41:11 --> Loader Class Initialized
INFO - 2020-12-02 07:41:11 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:11 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:11 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:11 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:11 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:11 --> Controller Class Initialized
DEBUG - 2020-12-02 07:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-02 07:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 07:41:11 --> Final output sent to browser
DEBUG - 2020-12-02 07:41:11 --> Total execution time: 0.1991
INFO - 2020-12-02 07:41:14 --> Config Class Initialized
INFO - 2020-12-02 07:41:14 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:14 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:14 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:14 --> URI Class Initialized
INFO - 2020-12-02 07:41:14 --> Router Class Initialized
INFO - 2020-12-02 07:41:14 --> Output Class Initialized
INFO - 2020-12-02 07:41:14 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:14 --> Input Class Initialized
INFO - 2020-12-02 07:41:14 --> Language Class Initialized
ERROR - 2020-12-02 07:41:14 --> 404 Page Not Found: /index
INFO - 2020-12-02 07:41:19 --> Config Class Initialized
INFO - 2020-12-02 07:41:19 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:19 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:19 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:19 --> URI Class Initialized
INFO - 2020-12-02 07:41:19 --> Router Class Initialized
INFO - 2020-12-02 07:41:19 --> Output Class Initialized
INFO - 2020-12-02 07:41:19 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:19 --> Input Class Initialized
INFO - 2020-12-02 07:41:19 --> Language Class Initialized
INFO - 2020-12-02 07:41:19 --> Language Class Initialized
INFO - 2020-12-02 07:41:19 --> Config Class Initialized
INFO - 2020-12-02 07:41:19 --> Loader Class Initialized
INFO - 2020-12-02 07:41:19 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:19 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:19 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:19 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:19 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:19 --> Controller Class Initialized
DEBUG - 2020-12-02 07:41:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-02 07:41:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 07:41:19 --> Final output sent to browser
DEBUG - 2020-12-02 07:41:19 --> Total execution time: 0.1775
INFO - 2020-12-02 07:41:21 --> Config Class Initialized
INFO - 2020-12-02 07:41:21 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:21 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:21 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:21 --> URI Class Initialized
INFO - 2020-12-02 07:41:21 --> Router Class Initialized
INFO - 2020-12-02 07:41:21 --> Output Class Initialized
INFO - 2020-12-02 07:41:21 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:21 --> Input Class Initialized
INFO - 2020-12-02 07:41:21 --> Language Class Initialized
INFO - 2020-12-02 07:41:21 --> Language Class Initialized
INFO - 2020-12-02 07:41:21 --> Config Class Initialized
INFO - 2020-12-02 07:41:21 --> Loader Class Initialized
INFO - 2020-12-02 07:41:21 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:21 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:21 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:21 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:21 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:21 --> Controller Class Initialized
DEBUG - 2020-12-02 07:41:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-12-02 07:41:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 07:41:21 --> Final output sent to browser
DEBUG - 2020-12-02 07:41:21 --> Total execution time: 0.2124
INFO - 2020-12-02 07:41:21 --> Config Class Initialized
INFO - 2020-12-02 07:41:21 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:21 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:21 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:21 --> URI Class Initialized
INFO - 2020-12-02 07:41:21 --> Router Class Initialized
INFO - 2020-12-02 07:41:21 --> Output Class Initialized
INFO - 2020-12-02 07:41:21 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:21 --> Input Class Initialized
INFO - 2020-12-02 07:41:21 --> Language Class Initialized
INFO - 2020-12-02 07:41:21 --> Language Class Initialized
INFO - 2020-12-02 07:41:21 --> Config Class Initialized
INFO - 2020-12-02 07:41:21 --> Loader Class Initialized
INFO - 2020-12-02 07:41:21 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:21 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:21 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:21 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:21 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:21 --> Controller Class Initialized
INFO - 2020-12-02 07:41:23 --> Config Class Initialized
INFO - 2020-12-02 07:41:23 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:23 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:23 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:23 --> URI Class Initialized
INFO - 2020-12-02 07:41:23 --> Router Class Initialized
INFO - 2020-12-02 07:41:23 --> Output Class Initialized
INFO - 2020-12-02 07:41:23 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:23 --> Input Class Initialized
INFO - 2020-12-02 07:41:23 --> Language Class Initialized
INFO - 2020-12-02 07:41:23 --> Language Class Initialized
INFO - 2020-12-02 07:41:23 --> Config Class Initialized
INFO - 2020-12-02 07:41:23 --> Loader Class Initialized
INFO - 2020-12-02 07:41:23 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:23 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:23 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:23 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:23 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:23 --> Controller Class Initialized
DEBUG - 2020-12-02 07:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-12-02 07:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 07:41:23 --> Final output sent to browser
DEBUG - 2020-12-02 07:41:23 --> Total execution time: 0.1994
INFO - 2020-12-02 07:41:23 --> Config Class Initialized
INFO - 2020-12-02 07:41:23 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:23 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:23 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:23 --> URI Class Initialized
INFO - 2020-12-02 07:41:23 --> Router Class Initialized
INFO - 2020-12-02 07:41:23 --> Output Class Initialized
INFO - 2020-12-02 07:41:23 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:23 --> Input Class Initialized
INFO - 2020-12-02 07:41:23 --> Language Class Initialized
INFO - 2020-12-02 07:41:23 --> Language Class Initialized
INFO - 2020-12-02 07:41:23 --> Config Class Initialized
INFO - 2020-12-02 07:41:23 --> Loader Class Initialized
INFO - 2020-12-02 07:41:23 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:23 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:23 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:23 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:23 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:23 --> Controller Class Initialized
INFO - 2020-12-02 07:41:24 --> Config Class Initialized
INFO - 2020-12-02 07:41:24 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:24 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:24 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:24 --> URI Class Initialized
INFO - 2020-12-02 07:41:24 --> Router Class Initialized
INFO - 2020-12-02 07:41:24 --> Output Class Initialized
INFO - 2020-12-02 07:41:24 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:24 --> Input Class Initialized
INFO - 2020-12-02 07:41:24 --> Language Class Initialized
INFO - 2020-12-02 07:41:24 --> Language Class Initialized
INFO - 2020-12-02 07:41:24 --> Config Class Initialized
INFO - 2020-12-02 07:41:24 --> Loader Class Initialized
INFO - 2020-12-02 07:41:24 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:24 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:24 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:24 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:24 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:24 --> Controller Class Initialized
DEBUG - 2020-12-02 07:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-12-02 07:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 07:41:24 --> Final output sent to browser
DEBUG - 2020-12-02 07:41:24 --> Total execution time: 0.1860
INFO - 2020-12-02 07:41:24 --> Config Class Initialized
INFO - 2020-12-02 07:41:24 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:24 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:24 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:24 --> URI Class Initialized
INFO - 2020-12-02 07:41:24 --> Router Class Initialized
INFO - 2020-12-02 07:41:24 --> Output Class Initialized
INFO - 2020-12-02 07:41:24 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:24 --> Input Class Initialized
INFO - 2020-12-02 07:41:24 --> Language Class Initialized
INFO - 2020-12-02 07:41:24 --> Language Class Initialized
INFO - 2020-12-02 07:41:24 --> Config Class Initialized
INFO - 2020-12-02 07:41:24 --> Loader Class Initialized
INFO - 2020-12-02 07:41:24 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:24 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:24 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:24 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:24 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:24 --> Controller Class Initialized
INFO - 2020-12-02 07:41:25 --> Config Class Initialized
INFO - 2020-12-02 07:41:25 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:41:25 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:41:25 --> Utf8 Class Initialized
INFO - 2020-12-02 07:41:25 --> URI Class Initialized
INFO - 2020-12-02 07:41:25 --> Router Class Initialized
INFO - 2020-12-02 07:41:25 --> Output Class Initialized
INFO - 2020-12-02 07:41:25 --> Security Class Initialized
DEBUG - 2020-12-02 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:41:25 --> Input Class Initialized
INFO - 2020-12-02 07:41:25 --> Language Class Initialized
INFO - 2020-12-02 07:41:25 --> Language Class Initialized
INFO - 2020-12-02 07:41:25 --> Config Class Initialized
INFO - 2020-12-02 07:41:25 --> Loader Class Initialized
INFO - 2020-12-02 07:41:25 --> Helper loaded: url_helper
INFO - 2020-12-02 07:41:25 --> Helper loaded: file_helper
INFO - 2020-12-02 07:41:25 --> Helper loaded: form_helper
INFO - 2020-12-02 07:41:25 --> Helper loaded: my_helper
INFO - 2020-12-02 07:41:25 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:41:25 --> Controller Class Initialized
DEBUG - 2020-12-02 07:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-12-02 07:41:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 07:41:25 --> Final output sent to browser
DEBUG - 2020-12-02 07:41:25 --> Total execution time: 0.2578
INFO - 2020-12-02 07:42:47 --> Config Class Initialized
INFO - 2020-12-02 07:42:47 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:42:47 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:42:47 --> Utf8 Class Initialized
INFO - 2020-12-02 07:42:47 --> URI Class Initialized
INFO - 2020-12-02 07:42:47 --> Router Class Initialized
INFO - 2020-12-02 07:42:47 --> Output Class Initialized
INFO - 2020-12-02 07:42:47 --> Security Class Initialized
DEBUG - 2020-12-02 07:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:42:47 --> Input Class Initialized
INFO - 2020-12-02 07:42:47 --> Language Class Initialized
INFO - 2020-12-02 07:42:47 --> Language Class Initialized
INFO - 2020-12-02 07:42:47 --> Config Class Initialized
INFO - 2020-12-02 07:42:47 --> Loader Class Initialized
INFO - 2020-12-02 07:42:47 --> Helper loaded: url_helper
INFO - 2020-12-02 07:42:47 --> Helper loaded: file_helper
INFO - 2020-12-02 07:42:47 --> Helper loaded: form_helper
INFO - 2020-12-02 07:42:47 --> Helper loaded: my_helper
INFO - 2020-12-02 07:42:47 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:42:47 --> Controller Class Initialized
INFO - 2020-12-02 07:42:47 --> Helper loaded: cookie_helper
INFO - 2020-12-02 07:42:47 --> Config Class Initialized
INFO - 2020-12-02 07:42:47 --> Hooks Class Initialized
DEBUG - 2020-12-02 07:42:47 --> UTF-8 Support Enabled
INFO - 2020-12-02 07:42:47 --> Utf8 Class Initialized
INFO - 2020-12-02 07:42:47 --> URI Class Initialized
INFO - 2020-12-02 07:42:47 --> Router Class Initialized
INFO - 2020-12-02 07:42:47 --> Output Class Initialized
INFO - 2020-12-02 07:42:47 --> Security Class Initialized
DEBUG - 2020-12-02 07:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 07:42:47 --> Input Class Initialized
INFO - 2020-12-02 07:42:47 --> Language Class Initialized
INFO - 2020-12-02 07:42:47 --> Language Class Initialized
INFO - 2020-12-02 07:42:47 --> Config Class Initialized
INFO - 2020-12-02 07:42:47 --> Loader Class Initialized
INFO - 2020-12-02 07:42:47 --> Helper loaded: url_helper
INFO - 2020-12-02 07:42:47 --> Helper loaded: file_helper
INFO - 2020-12-02 07:42:47 --> Helper loaded: form_helper
INFO - 2020-12-02 07:42:47 --> Helper loaded: my_helper
INFO - 2020-12-02 07:42:47 --> Database Driver Class Initialized
DEBUG - 2020-12-02 07:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-02 07:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 07:42:47 --> Controller Class Initialized
DEBUG - 2020-12-02 07:42:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-02 07:42:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-02 07:42:47 --> Final output sent to browser
DEBUG - 2020-12-02 07:42:47 --> Total execution time: 0.1962
