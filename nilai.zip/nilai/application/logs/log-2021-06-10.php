<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-10 05:51:32 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-10 05:51:32 --> Config Class Initialized
INFO - 2021-06-10 05:51:32 --> Hooks Class Initialized
INFO - 2021-06-10 05:51:32 --> Hooks Class Initialized
DEBUG - 2021-06-10 05:51:32 --> UTF-8 Support Enabled
DEBUG - 2021-06-10 05:51:32 --> UTF-8 Support Enabled
INFO - 2021-06-10 05:51:32 --> Utf8 Class Initialized
INFO - 2021-06-10 05:51:32 --> Utf8 Class Initialized
INFO - 2021-06-10 05:51:32 --> URI Class Initialized
INFO - 2021-06-10 05:51:32 --> URI Class Initialized
INFO - 2021-06-10 05:51:32 --> Router Class Initialized
INFO - 2021-06-10 05:51:32 --> Router Class Initialized
INFO - 2021-06-10 05:51:32 --> Output Class Initialized
INFO - 2021-06-10 05:51:32 --> Output Class Initialized
INFO - 2021-06-10 05:51:32 --> Security Class Initialized
INFO - 2021-06-10 05:51:32 --> Security Class Initialized
DEBUG - 2021-06-10 05:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-06-10 05:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-10 05:51:32 --> Input Class Initialized
INFO - 2021-06-10 05:51:32 --> Input Class Initialized
INFO - 2021-06-10 05:51:32 --> Language Class Initialized
INFO - 2021-06-10 05:51:32 --> Language Class Initialized
INFO - 2021-06-10 05:51:32 --> Language Class Initialized
INFO - 2021-06-10 05:51:32 --> Language Class Initialized
INFO - 2021-06-10 05:51:32 --> Config Class Initialized
INFO - 2021-06-10 05:51:32 --> Config Class Initialized
INFO - 2021-06-10 05:51:32 --> Loader Class Initialized
INFO - 2021-06-10 05:51:32 --> Loader Class Initialized
INFO - 2021-06-10 05:51:32 --> Helper loaded: url_helper
INFO - 2021-06-10 05:51:32 --> Helper loaded: url_helper
INFO - 2021-06-10 05:51:32 --> Helper loaded: file_helper
INFO - 2021-06-10 05:51:32 --> Helper loaded: file_helper
INFO - 2021-06-10 05:51:32 --> Helper loaded: form_helper
INFO - 2021-06-10 05:51:32 --> Helper loaded: form_helper
INFO - 2021-06-10 05:51:32 --> Helper loaded: my_helper
INFO - 2021-06-10 05:51:32 --> Helper loaded: my_helper
INFO - 2021-06-10 05:51:32 --> Database Driver Class Initialized
INFO - 2021-06-10 05:51:32 --> Database Driver Class Initialized
DEBUG - 2021-06-10 05:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-06-10 05:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-10 05:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-10 05:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-10 05:51:33 --> Controller Class Initialized
INFO - 2021-06-10 05:51:33 --> Controller Class Initialized
DEBUG - 2021-06-10 05:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-10 05:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-10 05:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
DEBUG - 2021-06-10 05:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-10 05:51:33 --> Final output sent to browser
INFO - 2021-06-10 05:51:33 --> Final output sent to browser
DEBUG - 2021-06-10 05:51:33 --> Total execution time: 0.7206
DEBUG - 2021-06-10 05:51:33 --> Total execution time: 0.7430
INFO - 2021-06-10 05:52:04 --> Config Class Initialized
INFO - 2021-06-10 05:52:04 --> Hooks Class Initialized
DEBUG - 2021-06-10 05:52:04 --> UTF-8 Support Enabled
INFO - 2021-06-10 05:52:04 --> Utf8 Class Initialized
INFO - 2021-06-10 05:52:04 --> URI Class Initialized
INFO - 2021-06-10 05:52:04 --> Router Class Initialized
INFO - 2021-06-10 05:52:04 --> Output Class Initialized
INFO - 2021-06-10 05:52:04 --> Security Class Initialized
DEBUG - 2021-06-10 05:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-10 05:52:04 --> Input Class Initialized
INFO - 2021-06-10 05:52:04 --> Language Class Initialized
INFO - 2021-06-10 05:52:04 --> Language Class Initialized
INFO - 2021-06-10 05:52:04 --> Config Class Initialized
INFO - 2021-06-10 05:52:04 --> Loader Class Initialized
INFO - 2021-06-10 05:52:04 --> Helper loaded: url_helper
INFO - 2021-06-10 05:52:04 --> Helper loaded: file_helper
INFO - 2021-06-10 05:52:04 --> Helper loaded: form_helper
INFO - 2021-06-10 05:52:04 --> Helper loaded: my_helper
INFO - 2021-06-10 05:52:04 --> Database Driver Class Initialized
DEBUG - 2021-06-10 05:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-10 05:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-10 05:52:04 --> Controller Class Initialized
INFO - 2021-06-10 05:52:04 --> Final output sent to browser
DEBUG - 2021-06-10 05:52:04 --> Total execution time: 0.0463
INFO - 2021-06-10 05:52:16 --> Config Class Initialized
INFO - 2021-06-10 05:52:16 --> Hooks Class Initialized
DEBUG - 2021-06-10 05:52:16 --> UTF-8 Support Enabled
INFO - 2021-06-10 05:52:16 --> Utf8 Class Initialized
INFO - 2021-06-10 05:52:16 --> URI Class Initialized
DEBUG - 2021-06-10 05:52:16 --> No URI present. Default controller set.
INFO - 2021-06-10 05:52:16 --> Router Class Initialized
INFO - 2021-06-10 05:52:16 --> Output Class Initialized
INFO - 2021-06-10 05:52:16 --> Security Class Initialized
DEBUG - 2021-06-10 05:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-10 05:52:16 --> Input Class Initialized
INFO - 2021-06-10 05:52:16 --> Language Class Initialized
INFO - 2021-06-10 05:52:16 --> Language Class Initialized
INFO - 2021-06-10 05:52:16 --> Config Class Initialized
INFO - 2021-06-10 05:52:16 --> Loader Class Initialized
INFO - 2021-06-10 05:52:16 --> Helper loaded: url_helper
INFO - 2021-06-10 05:52:16 --> Helper loaded: file_helper
INFO - 2021-06-10 05:52:16 --> Helper loaded: form_helper
INFO - 2021-06-10 05:52:16 --> Helper loaded: my_helper
INFO - 2021-06-10 05:52:16 --> Database Driver Class Initialized
DEBUG - 2021-06-10 05:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-10 05:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-10 05:52:16 --> Controller Class Initialized
INFO - 2021-06-10 05:52:16 --> Config Class Initialized
INFO - 2021-06-10 05:52:16 --> Hooks Class Initialized
DEBUG - 2021-06-10 05:52:16 --> UTF-8 Support Enabled
INFO - 2021-06-10 05:52:16 --> Utf8 Class Initialized
INFO - 2021-06-10 05:52:16 --> URI Class Initialized
INFO - 2021-06-10 05:52:16 --> Router Class Initialized
INFO - 2021-06-10 05:52:16 --> Output Class Initialized
INFO - 2021-06-10 05:52:16 --> Security Class Initialized
DEBUG - 2021-06-10 05:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-10 05:52:16 --> Input Class Initialized
INFO - 2021-06-10 05:52:16 --> Language Class Initialized
INFO - 2021-06-10 05:52:16 --> Language Class Initialized
INFO - 2021-06-10 05:52:16 --> Config Class Initialized
INFO - 2021-06-10 05:52:16 --> Loader Class Initialized
INFO - 2021-06-10 05:52:16 --> Helper loaded: url_helper
INFO - 2021-06-10 05:52:16 --> Helper loaded: file_helper
INFO - 2021-06-10 05:52:16 --> Helper loaded: form_helper
INFO - 2021-06-10 05:52:16 --> Helper loaded: my_helper
INFO - 2021-06-10 05:52:16 --> Database Driver Class Initialized
DEBUG - 2021-06-10 05:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-10 05:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-10 05:52:16 --> Controller Class Initialized
DEBUG - 2021-06-10 05:52:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-10 05:52:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-10 05:52:16 --> Final output sent to browser
DEBUG - 2021-06-10 05:52:16 --> Total execution time: 0.0394
