<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-07 05:21:29 --> Config Class Initialized
INFO - 2021-12-07 05:21:29 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:21:29 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:21:29 --> Utf8 Class Initialized
INFO - 2021-12-07 05:21:29 --> URI Class Initialized
DEBUG - 2021-12-07 05:21:29 --> No URI present. Default controller set.
INFO - 2021-12-07 05:21:29 --> Router Class Initialized
INFO - 2021-12-07 05:21:29 --> Output Class Initialized
INFO - 2021-12-07 05:21:29 --> Security Class Initialized
DEBUG - 2021-12-07 05:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:21:29 --> Input Class Initialized
INFO - 2021-12-07 05:21:29 --> Language Class Initialized
INFO - 2021-12-07 05:21:29 --> Language Class Initialized
INFO - 2021-12-07 05:21:29 --> Config Class Initialized
INFO - 2021-12-07 05:21:29 --> Loader Class Initialized
INFO - 2021-12-07 05:21:29 --> Helper loaded: url_helper
INFO - 2021-12-07 05:21:29 --> Helper loaded: file_helper
INFO - 2021-12-07 05:21:29 --> Helper loaded: form_helper
INFO - 2021-12-07 05:21:29 --> Helper loaded: my_helper
INFO - 2021-12-07 05:21:29 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:21:29 --> Controller Class Initialized
INFO - 2021-12-07 05:21:29 --> Config Class Initialized
INFO - 2021-12-07 05:21:29 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:21:29 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:21:29 --> Utf8 Class Initialized
INFO - 2021-12-07 05:21:29 --> URI Class Initialized
INFO - 2021-12-07 05:21:29 --> Router Class Initialized
INFO - 2021-12-07 05:21:29 --> Output Class Initialized
INFO - 2021-12-07 05:21:29 --> Security Class Initialized
DEBUG - 2021-12-07 05:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:21:29 --> Input Class Initialized
INFO - 2021-12-07 05:21:29 --> Language Class Initialized
INFO - 2021-12-07 05:21:29 --> Language Class Initialized
INFO - 2021-12-07 05:21:29 --> Config Class Initialized
INFO - 2021-12-07 05:21:29 --> Loader Class Initialized
INFO - 2021-12-07 05:21:29 --> Helper loaded: url_helper
INFO - 2021-12-07 05:21:29 --> Helper loaded: file_helper
INFO - 2021-12-07 05:21:29 --> Helper loaded: form_helper
INFO - 2021-12-07 05:21:29 --> Helper loaded: my_helper
INFO - 2021-12-07 05:21:29 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:21:29 --> Controller Class Initialized
DEBUG - 2021-12-07 05:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 05:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 05:21:29 --> Final output sent to browser
DEBUG - 2021-12-07 05:21:29 --> Total execution time: 0.0280
INFO - 2021-12-07 05:21:33 --> Config Class Initialized
INFO - 2021-12-07 05:21:33 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:21:33 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:21:33 --> Utf8 Class Initialized
INFO - 2021-12-07 05:21:34 --> URI Class Initialized
INFO - 2021-12-07 05:21:34 --> Router Class Initialized
INFO - 2021-12-07 05:21:34 --> Output Class Initialized
INFO - 2021-12-07 05:21:34 --> Security Class Initialized
DEBUG - 2021-12-07 05:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:21:34 --> Input Class Initialized
INFO - 2021-12-07 05:21:34 --> Language Class Initialized
INFO - 2021-12-07 05:21:34 --> Language Class Initialized
INFO - 2021-12-07 05:21:34 --> Config Class Initialized
INFO - 2021-12-07 05:21:34 --> Loader Class Initialized
INFO - 2021-12-07 05:21:34 --> Helper loaded: url_helper
INFO - 2021-12-07 05:21:34 --> Helper loaded: file_helper
INFO - 2021-12-07 05:21:34 --> Helper loaded: form_helper
INFO - 2021-12-07 05:21:34 --> Helper loaded: my_helper
INFO - 2021-12-07 05:21:34 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:21:34 --> Controller Class Initialized
INFO - 2021-12-07 05:21:34 --> Helper loaded: cookie_helper
INFO - 2021-12-07 05:21:34 --> Final output sent to browser
DEBUG - 2021-12-07 05:21:34 --> Total execution time: 0.0500
INFO - 2021-12-07 05:21:34 --> Config Class Initialized
INFO - 2021-12-07 05:21:34 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:21:34 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:21:34 --> Utf8 Class Initialized
INFO - 2021-12-07 05:21:34 --> URI Class Initialized
INFO - 2021-12-07 05:21:34 --> Router Class Initialized
INFO - 2021-12-07 05:21:34 --> Output Class Initialized
INFO - 2021-12-07 05:21:34 --> Security Class Initialized
DEBUG - 2021-12-07 05:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:21:34 --> Input Class Initialized
INFO - 2021-12-07 05:21:34 --> Language Class Initialized
INFO - 2021-12-07 05:21:34 --> Language Class Initialized
INFO - 2021-12-07 05:21:34 --> Config Class Initialized
INFO - 2021-12-07 05:21:34 --> Loader Class Initialized
INFO - 2021-12-07 05:21:34 --> Helper loaded: url_helper
INFO - 2021-12-07 05:21:34 --> Helper loaded: file_helper
INFO - 2021-12-07 05:21:34 --> Helper loaded: form_helper
INFO - 2021-12-07 05:21:34 --> Helper loaded: my_helper
INFO - 2021-12-07 05:21:34 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:21:34 --> Controller Class Initialized
DEBUG - 2021-12-07 05:21:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 05:21:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 05:21:34 --> Final output sent to browser
DEBUG - 2021-12-07 05:21:34 --> Total execution time: 0.7670
INFO - 2021-12-07 05:21:38 --> Config Class Initialized
INFO - 2021-12-07 05:21:38 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:21:38 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:21:38 --> Utf8 Class Initialized
INFO - 2021-12-07 05:21:38 --> URI Class Initialized
INFO - 2021-12-07 05:21:38 --> Router Class Initialized
INFO - 2021-12-07 05:21:38 --> Output Class Initialized
INFO - 2021-12-07 05:21:38 --> Security Class Initialized
DEBUG - 2021-12-07 05:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:21:38 --> Input Class Initialized
INFO - 2021-12-07 05:21:38 --> Language Class Initialized
INFO - 2021-12-07 05:21:38 --> Language Class Initialized
INFO - 2021-12-07 05:21:38 --> Config Class Initialized
INFO - 2021-12-07 05:21:38 --> Loader Class Initialized
INFO - 2021-12-07 05:21:38 --> Helper loaded: url_helper
INFO - 2021-12-07 05:21:38 --> Helper loaded: file_helper
INFO - 2021-12-07 05:21:38 --> Helper loaded: form_helper
INFO - 2021-12-07 05:21:38 --> Helper loaded: my_helper
INFO - 2021-12-07 05:21:38 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:21:38 --> Controller Class Initialized
DEBUG - 2021-12-07 05:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-07 05:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 05:21:38 --> Final output sent to browser
DEBUG - 2021-12-07 05:21:38 --> Total execution time: 0.0540
INFO - 2021-12-07 05:21:40 --> Config Class Initialized
INFO - 2021-12-07 05:21:40 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:21:40 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:21:40 --> Utf8 Class Initialized
INFO - 2021-12-07 05:21:40 --> URI Class Initialized
INFO - 2021-12-07 05:21:40 --> Router Class Initialized
INFO - 2021-12-07 05:21:40 --> Output Class Initialized
INFO - 2021-12-07 05:21:40 --> Security Class Initialized
DEBUG - 2021-12-07 05:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:21:40 --> Input Class Initialized
INFO - 2021-12-07 05:21:40 --> Language Class Initialized
INFO - 2021-12-07 05:21:40 --> Language Class Initialized
INFO - 2021-12-07 05:21:40 --> Config Class Initialized
INFO - 2021-12-07 05:21:40 --> Loader Class Initialized
INFO - 2021-12-07 05:21:40 --> Helper loaded: url_helper
INFO - 2021-12-07 05:21:40 --> Helper loaded: file_helper
INFO - 2021-12-07 05:21:40 --> Helper loaded: form_helper
INFO - 2021-12-07 05:21:40 --> Helper loaded: my_helper
INFO - 2021-12-07 05:21:40 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:21:40 --> Controller Class Initialized
DEBUG - 2021-12-07 05:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 05:21:40 --> Final output sent to browser
DEBUG - 2021-12-07 05:21:40 --> Total execution time: 0.1750
INFO - 2021-12-07 05:24:11 --> Config Class Initialized
INFO - 2021-12-07 05:24:11 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:24:11 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:24:11 --> Utf8 Class Initialized
INFO - 2021-12-07 05:24:11 --> URI Class Initialized
DEBUG - 2021-12-07 05:24:11 --> No URI present. Default controller set.
INFO - 2021-12-07 05:24:11 --> Router Class Initialized
INFO - 2021-12-07 05:24:11 --> Output Class Initialized
INFO - 2021-12-07 05:24:11 --> Security Class Initialized
DEBUG - 2021-12-07 05:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:24:11 --> Input Class Initialized
INFO - 2021-12-07 05:24:11 --> Language Class Initialized
INFO - 2021-12-07 05:24:11 --> Language Class Initialized
INFO - 2021-12-07 05:24:11 --> Config Class Initialized
INFO - 2021-12-07 05:24:11 --> Loader Class Initialized
INFO - 2021-12-07 05:24:11 --> Helper loaded: url_helper
INFO - 2021-12-07 05:24:11 --> Helper loaded: file_helper
INFO - 2021-12-07 05:24:11 --> Helper loaded: form_helper
INFO - 2021-12-07 05:24:11 --> Helper loaded: my_helper
INFO - 2021-12-07 05:24:11 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:24:11 --> Controller Class Initialized
INFO - 2021-12-07 05:24:11 --> Config Class Initialized
INFO - 2021-12-07 05:24:11 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:24:11 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:24:11 --> Utf8 Class Initialized
INFO - 2021-12-07 05:24:11 --> URI Class Initialized
INFO - 2021-12-07 05:24:11 --> Router Class Initialized
INFO - 2021-12-07 05:24:11 --> Output Class Initialized
INFO - 2021-12-07 05:24:11 --> Security Class Initialized
DEBUG - 2021-12-07 05:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:24:11 --> Input Class Initialized
INFO - 2021-12-07 05:24:11 --> Language Class Initialized
INFO - 2021-12-07 05:24:11 --> Language Class Initialized
INFO - 2021-12-07 05:24:11 --> Config Class Initialized
INFO - 2021-12-07 05:24:11 --> Loader Class Initialized
INFO - 2021-12-07 05:24:11 --> Helper loaded: url_helper
INFO - 2021-12-07 05:24:11 --> Helper loaded: file_helper
INFO - 2021-12-07 05:24:11 --> Helper loaded: form_helper
INFO - 2021-12-07 05:24:11 --> Helper loaded: my_helper
INFO - 2021-12-07 05:24:11 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:24:11 --> Controller Class Initialized
DEBUG - 2021-12-07 05:24:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 05:24:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 05:24:11 --> Final output sent to browser
DEBUG - 2021-12-07 05:24:11 --> Total execution time: 0.0280
INFO - 2021-12-07 05:24:16 --> Config Class Initialized
INFO - 2021-12-07 05:24:16 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:24:16 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:24:16 --> Utf8 Class Initialized
INFO - 2021-12-07 05:24:16 --> URI Class Initialized
INFO - 2021-12-07 05:24:16 --> Router Class Initialized
INFO - 2021-12-07 05:24:16 --> Output Class Initialized
INFO - 2021-12-07 05:24:16 --> Security Class Initialized
DEBUG - 2021-12-07 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:24:16 --> Input Class Initialized
INFO - 2021-12-07 05:24:16 --> Language Class Initialized
INFO - 2021-12-07 05:24:16 --> Language Class Initialized
INFO - 2021-12-07 05:24:16 --> Config Class Initialized
INFO - 2021-12-07 05:24:16 --> Loader Class Initialized
INFO - 2021-12-07 05:24:16 --> Helper loaded: url_helper
INFO - 2021-12-07 05:24:16 --> Helper loaded: file_helper
INFO - 2021-12-07 05:24:16 --> Helper loaded: form_helper
INFO - 2021-12-07 05:24:16 --> Helper loaded: my_helper
INFO - 2021-12-07 05:24:16 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:24:16 --> Controller Class Initialized
INFO - 2021-12-07 05:24:16 --> Helper loaded: cookie_helper
INFO - 2021-12-07 05:24:16 --> Final output sent to browser
DEBUG - 2021-12-07 05:24:16 --> Total execution time: 0.0440
INFO - 2021-12-07 05:24:16 --> Config Class Initialized
INFO - 2021-12-07 05:24:16 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:24:16 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:24:16 --> Utf8 Class Initialized
INFO - 2021-12-07 05:24:16 --> URI Class Initialized
INFO - 2021-12-07 05:24:16 --> Router Class Initialized
INFO - 2021-12-07 05:24:16 --> Output Class Initialized
INFO - 2021-12-07 05:24:16 --> Security Class Initialized
DEBUG - 2021-12-07 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:24:16 --> Input Class Initialized
INFO - 2021-12-07 05:24:16 --> Language Class Initialized
INFO - 2021-12-07 05:24:16 --> Language Class Initialized
INFO - 2021-12-07 05:24:16 --> Config Class Initialized
INFO - 2021-12-07 05:24:16 --> Loader Class Initialized
INFO - 2021-12-07 05:24:16 --> Helper loaded: url_helper
INFO - 2021-12-07 05:24:16 --> Helper loaded: file_helper
INFO - 2021-12-07 05:24:16 --> Helper loaded: form_helper
INFO - 2021-12-07 05:24:16 --> Helper loaded: my_helper
INFO - 2021-12-07 05:24:16 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:24:16 --> Controller Class Initialized
DEBUG - 2021-12-07 05:24:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 05:24:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 05:24:16 --> Final output sent to browser
DEBUG - 2021-12-07 05:24:16 --> Total execution time: 0.7300
INFO - 2021-12-07 05:24:25 --> Config Class Initialized
INFO - 2021-12-07 05:24:25 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:24:25 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:24:25 --> Utf8 Class Initialized
INFO - 2021-12-07 05:24:25 --> URI Class Initialized
INFO - 2021-12-07 05:24:25 --> Router Class Initialized
INFO - 2021-12-07 05:24:25 --> Output Class Initialized
INFO - 2021-12-07 05:24:25 --> Security Class Initialized
DEBUG - 2021-12-07 05:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:24:25 --> Input Class Initialized
INFO - 2021-12-07 05:24:25 --> Language Class Initialized
INFO - 2021-12-07 05:24:25 --> Language Class Initialized
INFO - 2021-12-07 05:24:25 --> Config Class Initialized
INFO - 2021-12-07 05:24:25 --> Loader Class Initialized
INFO - 2021-12-07 05:24:25 --> Helper loaded: url_helper
INFO - 2021-12-07 05:24:25 --> Helper loaded: file_helper
INFO - 2021-12-07 05:24:25 --> Helper loaded: form_helper
INFO - 2021-12-07 05:24:25 --> Helper loaded: my_helper
INFO - 2021-12-07 05:24:25 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:24:25 --> Controller Class Initialized
DEBUG - 2021-12-07 05:24:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-07 05:24:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 05:24:25 --> Final output sent to browser
DEBUG - 2021-12-07 05:24:25 --> Total execution time: 0.0680
INFO - 2021-12-07 05:24:27 --> Config Class Initialized
INFO - 2021-12-07 05:24:27 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:24:27 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:24:27 --> Utf8 Class Initialized
INFO - 2021-12-07 05:24:27 --> URI Class Initialized
INFO - 2021-12-07 05:24:27 --> Router Class Initialized
INFO - 2021-12-07 05:24:27 --> Output Class Initialized
INFO - 2021-12-07 05:24:27 --> Security Class Initialized
DEBUG - 2021-12-07 05:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:24:27 --> Input Class Initialized
INFO - 2021-12-07 05:24:27 --> Language Class Initialized
INFO - 2021-12-07 05:24:27 --> Language Class Initialized
INFO - 2021-12-07 05:24:27 --> Config Class Initialized
INFO - 2021-12-07 05:24:27 --> Loader Class Initialized
INFO - 2021-12-07 05:24:27 --> Helper loaded: url_helper
INFO - 2021-12-07 05:24:27 --> Helper loaded: file_helper
INFO - 2021-12-07 05:24:27 --> Helper loaded: form_helper
INFO - 2021-12-07 05:24:27 --> Helper loaded: my_helper
INFO - 2021-12-07 05:24:27 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:24:27 --> Controller Class Initialized
DEBUG - 2021-12-07 05:24:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 05:24:27 --> Final output sent to browser
DEBUG - 2021-12-07 05:24:27 --> Total execution time: 0.1860
INFO - 2021-12-07 05:33:02 --> Config Class Initialized
INFO - 2021-12-07 05:33:02 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:33:02 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:33:02 --> Utf8 Class Initialized
INFO - 2021-12-07 05:33:02 --> URI Class Initialized
INFO - 2021-12-07 05:33:02 --> Router Class Initialized
INFO - 2021-12-07 05:33:02 --> Output Class Initialized
INFO - 2021-12-07 05:33:02 --> Security Class Initialized
DEBUG - 2021-12-07 05:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:33:02 --> Input Class Initialized
INFO - 2021-12-07 05:33:02 --> Language Class Initialized
INFO - 2021-12-07 05:33:02 --> Language Class Initialized
INFO - 2021-12-07 05:33:02 --> Config Class Initialized
INFO - 2021-12-07 05:33:02 --> Loader Class Initialized
INFO - 2021-12-07 05:33:02 --> Helper loaded: url_helper
INFO - 2021-12-07 05:33:02 --> Helper loaded: file_helper
INFO - 2021-12-07 05:33:02 --> Helper loaded: form_helper
INFO - 2021-12-07 05:33:02 --> Helper loaded: my_helper
INFO - 2021-12-07 05:33:02 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:33:02 --> Controller Class Initialized
DEBUG - 2021-12-07 05:33:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 05:33:02 --> Final output sent to browser
DEBUG - 2021-12-07 05:33:02 --> Total execution time: 0.1600
INFO - 2021-12-07 05:36:33 --> Config Class Initialized
INFO - 2021-12-07 05:36:33 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:36:33 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:36:33 --> Utf8 Class Initialized
INFO - 2021-12-07 05:36:33 --> URI Class Initialized
INFO - 2021-12-07 05:36:33 --> Router Class Initialized
INFO - 2021-12-07 05:36:33 --> Output Class Initialized
INFO - 2021-12-07 05:36:33 --> Security Class Initialized
DEBUG - 2021-12-07 05:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:36:33 --> Input Class Initialized
INFO - 2021-12-07 05:36:33 --> Language Class Initialized
INFO - 2021-12-07 05:36:33 --> Language Class Initialized
INFO - 2021-12-07 05:36:33 --> Config Class Initialized
INFO - 2021-12-07 05:36:33 --> Loader Class Initialized
INFO - 2021-12-07 05:36:33 --> Helper loaded: url_helper
INFO - 2021-12-07 05:36:33 --> Helper loaded: file_helper
INFO - 2021-12-07 05:36:33 --> Helper loaded: form_helper
INFO - 2021-12-07 05:36:33 --> Helper loaded: my_helper
INFO - 2021-12-07 05:36:33 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:36:33 --> Controller Class Initialized
DEBUG - 2021-12-07 05:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 05:36:33 --> Final output sent to browser
DEBUG - 2021-12-07 05:36:33 --> Total execution time: 0.1400
INFO - 2021-12-07 05:36:40 --> Config Class Initialized
INFO - 2021-12-07 05:36:40 --> Hooks Class Initialized
DEBUG - 2021-12-07 05:36:40 --> UTF-8 Support Enabled
INFO - 2021-12-07 05:36:40 --> Utf8 Class Initialized
INFO - 2021-12-07 05:36:40 --> URI Class Initialized
INFO - 2021-12-07 05:36:40 --> Router Class Initialized
INFO - 2021-12-07 05:36:40 --> Output Class Initialized
INFO - 2021-12-07 05:36:40 --> Security Class Initialized
DEBUG - 2021-12-07 05:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 05:36:40 --> Input Class Initialized
INFO - 2021-12-07 05:36:40 --> Language Class Initialized
INFO - 2021-12-07 05:36:40 --> Language Class Initialized
INFO - 2021-12-07 05:36:40 --> Config Class Initialized
INFO - 2021-12-07 05:36:40 --> Loader Class Initialized
INFO - 2021-12-07 05:36:40 --> Helper loaded: url_helper
INFO - 2021-12-07 05:36:40 --> Helper loaded: file_helper
INFO - 2021-12-07 05:36:40 --> Helper loaded: form_helper
INFO - 2021-12-07 05:36:40 --> Helper loaded: my_helper
INFO - 2021-12-07 05:36:40 --> Database Driver Class Initialized
DEBUG - 2021-12-07 05:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 05:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 05:36:40 --> Controller Class Initialized
DEBUG - 2021-12-07 05:36:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 05:36:40 --> Final output sent to browser
DEBUG - 2021-12-07 05:36:40 --> Total execution time: 0.1360
INFO - 2021-12-07 07:28:15 --> Config Class Initialized
INFO - 2021-12-07 07:28:15 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:28:15 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:28:15 --> Utf8 Class Initialized
INFO - 2021-12-07 07:28:16 --> URI Class Initialized
INFO - 2021-12-07 07:28:16 --> Router Class Initialized
INFO - 2021-12-07 07:28:16 --> Output Class Initialized
INFO - 2021-12-07 07:28:16 --> Security Class Initialized
DEBUG - 2021-12-07 07:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:28:16 --> Input Class Initialized
INFO - 2021-12-07 07:28:16 --> Language Class Initialized
INFO - 2021-12-07 07:28:16 --> Language Class Initialized
INFO - 2021-12-07 07:28:16 --> Config Class Initialized
INFO - 2021-12-07 07:28:16 --> Loader Class Initialized
INFO - 2021-12-07 07:28:16 --> Helper loaded: url_helper
INFO - 2021-12-07 07:28:16 --> Helper loaded: file_helper
INFO - 2021-12-07 07:28:16 --> Helper loaded: form_helper
INFO - 2021-12-07 07:28:16 --> Helper loaded: my_helper
INFO - 2021-12-07 07:28:16 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:28:16 --> Controller Class Initialized
DEBUG - 2021-12-07 07:28:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 07:28:16 --> Final output sent to browser
DEBUG - 2021-12-07 07:28:16 --> Total execution time: 0.1570
INFO - 2021-12-07 07:35:51 --> Config Class Initialized
INFO - 2021-12-07 07:35:51 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:35:51 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:35:51 --> Utf8 Class Initialized
INFO - 2021-12-07 07:35:51 --> URI Class Initialized
INFO - 2021-12-07 07:35:51 --> Router Class Initialized
INFO - 2021-12-07 07:35:51 --> Output Class Initialized
INFO - 2021-12-07 07:35:51 --> Security Class Initialized
DEBUG - 2021-12-07 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:35:51 --> Input Class Initialized
INFO - 2021-12-07 07:35:51 --> Language Class Initialized
INFO - 2021-12-07 07:35:51 --> Language Class Initialized
INFO - 2021-12-07 07:35:51 --> Config Class Initialized
INFO - 2021-12-07 07:35:51 --> Loader Class Initialized
INFO - 2021-12-07 07:35:51 --> Helper loaded: url_helper
INFO - 2021-12-07 07:35:51 --> Helper loaded: file_helper
INFO - 2021-12-07 07:35:51 --> Helper loaded: form_helper
INFO - 2021-12-07 07:35:51 --> Helper loaded: my_helper
INFO - 2021-12-07 07:35:51 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:35:51 --> Controller Class Initialized
DEBUG - 2021-12-07 07:35:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 07:35:51 --> Final output sent to browser
DEBUG - 2021-12-07 07:35:51 --> Total execution time: 0.1270
INFO - 2021-12-07 07:37:41 --> Config Class Initialized
INFO - 2021-12-07 07:37:41 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:37:41 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:37:41 --> Utf8 Class Initialized
INFO - 2021-12-07 07:37:41 --> URI Class Initialized
INFO - 2021-12-07 07:37:41 --> Router Class Initialized
INFO - 2021-12-07 07:37:41 --> Output Class Initialized
INFO - 2021-12-07 07:37:41 --> Security Class Initialized
DEBUG - 2021-12-07 07:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:37:41 --> Input Class Initialized
INFO - 2021-12-07 07:37:41 --> Language Class Initialized
INFO - 2021-12-07 07:37:42 --> Language Class Initialized
INFO - 2021-12-07 07:37:42 --> Config Class Initialized
INFO - 2021-12-07 07:37:42 --> Loader Class Initialized
INFO - 2021-12-07 07:37:42 --> Helper loaded: url_helper
INFO - 2021-12-07 07:37:42 --> Helper loaded: file_helper
INFO - 2021-12-07 07:37:42 --> Helper loaded: form_helper
INFO - 2021-12-07 07:37:42 --> Helper loaded: my_helper
INFO - 2021-12-07 07:37:42 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:37:42 --> Controller Class Initialized
DEBUG - 2021-12-07 07:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 07:37:42 --> Final output sent to browser
DEBUG - 2021-12-07 07:37:42 --> Total execution time: 0.1550
INFO - 2021-12-07 07:38:04 --> Config Class Initialized
INFO - 2021-12-07 07:38:04 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:38:04 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:38:04 --> Utf8 Class Initialized
INFO - 2021-12-07 07:38:04 --> URI Class Initialized
INFO - 2021-12-07 07:38:04 --> Router Class Initialized
INFO - 2021-12-07 07:38:04 --> Output Class Initialized
INFO - 2021-12-07 07:38:04 --> Security Class Initialized
DEBUG - 2021-12-07 07:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:38:04 --> Input Class Initialized
INFO - 2021-12-07 07:38:04 --> Language Class Initialized
INFO - 2021-12-07 07:38:04 --> Language Class Initialized
INFO - 2021-12-07 07:38:04 --> Config Class Initialized
INFO - 2021-12-07 07:38:04 --> Loader Class Initialized
INFO - 2021-12-07 07:38:04 --> Helper loaded: url_helper
INFO - 2021-12-07 07:38:04 --> Helper loaded: file_helper
INFO - 2021-12-07 07:38:04 --> Helper loaded: form_helper
INFO - 2021-12-07 07:38:04 --> Helper loaded: my_helper
INFO - 2021-12-07 07:38:04 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:38:04 --> Controller Class Initialized
DEBUG - 2021-12-07 07:38:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 07:38:04 --> Final output sent to browser
DEBUG - 2021-12-07 07:38:04 --> Total execution time: 0.1330
INFO - 2021-12-07 07:38:27 --> Config Class Initialized
INFO - 2021-12-07 07:38:27 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:38:27 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:38:27 --> Utf8 Class Initialized
INFO - 2021-12-07 07:38:27 --> URI Class Initialized
INFO - 2021-12-07 07:38:27 --> Router Class Initialized
INFO - 2021-12-07 07:38:27 --> Output Class Initialized
INFO - 2021-12-07 07:38:27 --> Security Class Initialized
DEBUG - 2021-12-07 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:38:27 --> Input Class Initialized
INFO - 2021-12-07 07:38:27 --> Language Class Initialized
INFO - 2021-12-07 07:38:27 --> Language Class Initialized
INFO - 2021-12-07 07:38:27 --> Config Class Initialized
INFO - 2021-12-07 07:38:27 --> Loader Class Initialized
INFO - 2021-12-07 07:38:27 --> Helper loaded: url_helper
INFO - 2021-12-07 07:38:27 --> Helper loaded: file_helper
INFO - 2021-12-07 07:38:27 --> Helper loaded: form_helper
INFO - 2021-12-07 07:38:27 --> Helper loaded: my_helper
INFO - 2021-12-07 07:38:27 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:38:27 --> Controller Class Initialized
DEBUG - 2021-12-07 07:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 07:38:27 --> Final output sent to browser
DEBUG - 2021-12-07 07:38:27 --> Total execution time: 0.1470
INFO - 2021-12-07 07:38:52 --> Config Class Initialized
INFO - 2021-12-07 07:38:52 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:38:52 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:38:52 --> Utf8 Class Initialized
INFO - 2021-12-07 07:38:52 --> URI Class Initialized
INFO - 2021-12-07 07:38:52 --> Router Class Initialized
INFO - 2021-12-07 07:38:52 --> Output Class Initialized
INFO - 2021-12-07 07:38:52 --> Security Class Initialized
DEBUG - 2021-12-07 07:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:38:52 --> Input Class Initialized
INFO - 2021-12-07 07:38:52 --> Language Class Initialized
INFO - 2021-12-07 07:38:52 --> Language Class Initialized
INFO - 2021-12-07 07:38:52 --> Config Class Initialized
INFO - 2021-12-07 07:38:52 --> Loader Class Initialized
INFO - 2021-12-07 07:38:52 --> Helper loaded: url_helper
INFO - 2021-12-07 07:38:52 --> Helper loaded: file_helper
INFO - 2021-12-07 07:38:52 --> Helper loaded: form_helper
INFO - 2021-12-07 07:38:52 --> Helper loaded: my_helper
INFO - 2021-12-07 07:38:52 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:38:52 --> Controller Class Initialized
DEBUG - 2021-12-07 07:38:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-07 07:38:52 --> Final output sent to browser
DEBUG - 2021-12-07 07:38:52 --> Total execution time: 0.1440
INFO - 2021-12-07 07:47:04 --> Config Class Initialized
INFO - 2021-12-07 07:47:04 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:47:04 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:47:04 --> Utf8 Class Initialized
INFO - 2021-12-07 07:47:04 --> URI Class Initialized
INFO - 2021-12-07 07:47:04 --> Router Class Initialized
INFO - 2021-12-07 07:47:04 --> Output Class Initialized
INFO - 2021-12-07 07:47:04 --> Security Class Initialized
DEBUG - 2021-12-07 07:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:47:04 --> Input Class Initialized
INFO - 2021-12-07 07:47:04 --> Language Class Initialized
INFO - 2021-12-07 07:47:04 --> Language Class Initialized
INFO - 2021-12-07 07:47:04 --> Config Class Initialized
INFO - 2021-12-07 07:47:04 --> Loader Class Initialized
INFO - 2021-12-07 07:47:04 --> Helper loaded: url_helper
INFO - 2021-12-07 07:47:04 --> Helper loaded: file_helper
INFO - 2021-12-07 07:47:04 --> Helper loaded: form_helper
INFO - 2021-12-07 07:47:04 --> Helper loaded: my_helper
INFO - 2021-12-07 07:47:04 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:47:04 --> Controller Class Initialized
INFO - 2021-12-07 07:47:04 --> Helper loaded: cookie_helper
INFO - 2021-12-07 07:47:04 --> Config Class Initialized
INFO - 2021-12-07 07:47:04 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:47:04 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:47:04 --> Utf8 Class Initialized
INFO - 2021-12-07 07:47:04 --> URI Class Initialized
INFO - 2021-12-07 07:47:04 --> Router Class Initialized
INFO - 2021-12-07 07:47:04 --> Output Class Initialized
INFO - 2021-12-07 07:47:04 --> Security Class Initialized
DEBUG - 2021-12-07 07:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:47:04 --> Input Class Initialized
INFO - 2021-12-07 07:47:04 --> Language Class Initialized
INFO - 2021-12-07 07:47:04 --> Language Class Initialized
INFO - 2021-12-07 07:47:04 --> Config Class Initialized
INFO - 2021-12-07 07:47:04 --> Loader Class Initialized
INFO - 2021-12-07 07:47:04 --> Helper loaded: url_helper
INFO - 2021-12-07 07:47:04 --> Helper loaded: file_helper
INFO - 2021-12-07 07:47:04 --> Helper loaded: form_helper
INFO - 2021-12-07 07:47:04 --> Helper loaded: my_helper
INFO - 2021-12-07 07:47:04 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:47:04 --> Controller Class Initialized
DEBUG - 2021-12-07 07:47:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 07:47:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:47:04 --> Final output sent to browser
DEBUG - 2021-12-07 07:47:04 --> Total execution time: 0.0370
INFO - 2021-12-07 07:47:18 --> Config Class Initialized
INFO - 2021-12-07 07:47:18 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:47:18 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:47:18 --> Utf8 Class Initialized
INFO - 2021-12-07 07:47:18 --> URI Class Initialized
INFO - 2021-12-07 07:47:18 --> Router Class Initialized
INFO - 2021-12-07 07:47:18 --> Output Class Initialized
INFO - 2021-12-07 07:47:18 --> Security Class Initialized
DEBUG - 2021-12-07 07:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:47:18 --> Input Class Initialized
INFO - 2021-12-07 07:47:18 --> Language Class Initialized
INFO - 2021-12-07 07:47:18 --> Language Class Initialized
INFO - 2021-12-07 07:47:18 --> Config Class Initialized
INFO - 2021-12-07 07:47:18 --> Loader Class Initialized
INFO - 2021-12-07 07:47:18 --> Helper loaded: url_helper
INFO - 2021-12-07 07:47:18 --> Helper loaded: file_helper
INFO - 2021-12-07 07:47:18 --> Helper loaded: form_helper
INFO - 2021-12-07 07:47:18 --> Helper loaded: my_helper
INFO - 2021-12-07 07:47:18 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:47:18 --> Controller Class Initialized
INFO - 2021-12-07 07:47:18 --> Helper loaded: cookie_helper
INFO - 2021-12-07 07:47:18 --> Final output sent to browser
DEBUG - 2021-12-07 07:47:18 --> Total execution time: 0.0510
INFO - 2021-12-07 07:47:20 --> Config Class Initialized
INFO - 2021-12-07 07:47:20 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:47:20 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:47:20 --> Utf8 Class Initialized
INFO - 2021-12-07 07:47:20 --> URI Class Initialized
INFO - 2021-12-07 07:47:20 --> Router Class Initialized
INFO - 2021-12-07 07:47:20 --> Output Class Initialized
INFO - 2021-12-07 07:47:20 --> Security Class Initialized
DEBUG - 2021-12-07 07:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:47:20 --> Input Class Initialized
INFO - 2021-12-07 07:47:20 --> Language Class Initialized
INFO - 2021-12-07 07:47:20 --> Language Class Initialized
INFO - 2021-12-07 07:47:20 --> Config Class Initialized
INFO - 2021-12-07 07:47:20 --> Loader Class Initialized
INFO - 2021-12-07 07:47:20 --> Helper loaded: url_helper
INFO - 2021-12-07 07:47:20 --> Helper loaded: file_helper
INFO - 2021-12-07 07:47:20 --> Helper loaded: form_helper
INFO - 2021-12-07 07:47:20 --> Helper loaded: my_helper
INFO - 2021-12-07 07:47:20 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:47:20 --> Controller Class Initialized
DEBUG - 2021-12-07 07:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 07:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:47:21 --> Final output sent to browser
DEBUG - 2021-12-07 07:47:21 --> Total execution time: 0.7450
INFO - 2021-12-07 07:47:25 --> Config Class Initialized
INFO - 2021-12-07 07:47:25 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:47:25 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:47:25 --> Utf8 Class Initialized
INFO - 2021-12-07 07:47:25 --> URI Class Initialized
INFO - 2021-12-07 07:47:25 --> Router Class Initialized
INFO - 2021-12-07 07:47:25 --> Output Class Initialized
INFO - 2021-12-07 07:47:25 --> Security Class Initialized
DEBUG - 2021-12-07 07:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:47:25 --> Input Class Initialized
INFO - 2021-12-07 07:47:25 --> Language Class Initialized
INFO - 2021-12-07 07:47:25 --> Language Class Initialized
INFO - 2021-12-07 07:47:25 --> Config Class Initialized
INFO - 2021-12-07 07:47:25 --> Loader Class Initialized
INFO - 2021-12-07 07:47:25 --> Helper loaded: url_helper
INFO - 2021-12-07 07:47:25 --> Helper loaded: file_helper
INFO - 2021-12-07 07:47:25 --> Helper loaded: form_helper
INFO - 2021-12-07 07:47:25 --> Helper loaded: my_helper
INFO - 2021-12-07 07:47:25 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:47:25 --> Controller Class Initialized
DEBUG - 2021-12-07 07:47:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-07 07:47:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:47:25 --> Final output sent to browser
DEBUG - 2021-12-07 07:47:25 --> Total execution time: 0.0570
INFO - 2021-12-07 07:47:25 --> Config Class Initialized
INFO - 2021-12-07 07:47:25 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:47:25 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:47:25 --> Utf8 Class Initialized
INFO - 2021-12-07 07:47:25 --> URI Class Initialized
INFO - 2021-12-07 07:47:25 --> Router Class Initialized
INFO - 2021-12-07 07:47:25 --> Output Class Initialized
INFO - 2021-12-07 07:47:25 --> Security Class Initialized
DEBUG - 2021-12-07 07:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:47:25 --> Input Class Initialized
INFO - 2021-12-07 07:47:25 --> Language Class Initialized
INFO - 2021-12-07 07:47:25 --> Language Class Initialized
INFO - 2021-12-07 07:47:25 --> Config Class Initialized
INFO - 2021-12-07 07:47:25 --> Loader Class Initialized
INFO - 2021-12-07 07:47:25 --> Helper loaded: url_helper
INFO - 2021-12-07 07:47:25 --> Helper loaded: file_helper
INFO - 2021-12-07 07:47:25 --> Helper loaded: form_helper
INFO - 2021-12-07 07:47:25 --> Helper loaded: my_helper
INFO - 2021-12-07 07:47:25 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:47:25 --> Controller Class Initialized
INFO - 2021-12-07 07:47:45 --> Config Class Initialized
INFO - 2021-12-07 07:47:45 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:47:45 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:47:45 --> Utf8 Class Initialized
INFO - 2021-12-07 07:47:45 --> URI Class Initialized
INFO - 2021-12-07 07:47:45 --> Router Class Initialized
INFO - 2021-12-07 07:47:45 --> Output Class Initialized
INFO - 2021-12-07 07:47:45 --> Security Class Initialized
DEBUG - 2021-12-07 07:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:47:45 --> Input Class Initialized
INFO - 2021-12-07 07:47:45 --> Language Class Initialized
INFO - 2021-12-07 07:47:45 --> Language Class Initialized
INFO - 2021-12-07 07:47:45 --> Config Class Initialized
INFO - 2021-12-07 07:47:45 --> Loader Class Initialized
INFO - 2021-12-07 07:47:45 --> Helper loaded: url_helper
INFO - 2021-12-07 07:47:45 --> Helper loaded: file_helper
INFO - 2021-12-07 07:47:45 --> Helper loaded: form_helper
INFO - 2021-12-07 07:47:45 --> Helper loaded: my_helper
INFO - 2021-12-07 07:47:45 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:47:45 --> Controller Class Initialized
INFO - 2021-12-07 07:47:45 --> Helper loaded: cookie_helper
INFO - 2021-12-07 07:47:45 --> Config Class Initialized
INFO - 2021-12-07 07:47:45 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:47:45 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:47:45 --> Utf8 Class Initialized
INFO - 2021-12-07 07:47:45 --> URI Class Initialized
INFO - 2021-12-07 07:47:45 --> Router Class Initialized
INFO - 2021-12-07 07:47:45 --> Output Class Initialized
INFO - 2021-12-07 07:47:45 --> Security Class Initialized
DEBUG - 2021-12-07 07:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:47:45 --> Input Class Initialized
INFO - 2021-12-07 07:47:45 --> Language Class Initialized
INFO - 2021-12-07 07:47:45 --> Language Class Initialized
INFO - 2021-12-07 07:47:45 --> Config Class Initialized
INFO - 2021-12-07 07:47:45 --> Loader Class Initialized
INFO - 2021-12-07 07:47:45 --> Helper loaded: url_helper
INFO - 2021-12-07 07:47:45 --> Helper loaded: file_helper
INFO - 2021-12-07 07:47:45 --> Helper loaded: form_helper
INFO - 2021-12-07 07:47:45 --> Helper loaded: my_helper
INFO - 2021-12-07 07:47:45 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:47:45 --> Controller Class Initialized
DEBUG - 2021-12-07 07:47:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 07:47:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:47:45 --> Final output sent to browser
DEBUG - 2021-12-07 07:47:45 --> Total execution time: 0.0360
INFO - 2021-12-07 07:48:08 --> Config Class Initialized
INFO - 2021-12-07 07:48:08 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:48:08 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:48:08 --> Utf8 Class Initialized
INFO - 2021-12-07 07:48:08 --> URI Class Initialized
INFO - 2021-12-07 07:48:08 --> Router Class Initialized
INFO - 2021-12-07 07:48:08 --> Output Class Initialized
INFO - 2021-12-07 07:48:08 --> Security Class Initialized
DEBUG - 2021-12-07 07:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:48:08 --> Input Class Initialized
INFO - 2021-12-07 07:48:08 --> Language Class Initialized
INFO - 2021-12-07 07:48:08 --> Language Class Initialized
INFO - 2021-12-07 07:48:08 --> Config Class Initialized
INFO - 2021-12-07 07:48:08 --> Loader Class Initialized
INFO - 2021-12-07 07:48:08 --> Helper loaded: url_helper
INFO - 2021-12-07 07:48:08 --> Helper loaded: file_helper
INFO - 2021-12-07 07:48:08 --> Helper loaded: form_helper
INFO - 2021-12-07 07:48:08 --> Helper loaded: my_helper
INFO - 2021-12-07 07:48:08 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:48:08 --> Controller Class Initialized
INFO - 2021-12-07 07:48:08 --> Helper loaded: cookie_helper
INFO - 2021-12-07 07:48:08 --> Final output sent to browser
DEBUG - 2021-12-07 07:48:08 --> Total execution time: 0.0450
INFO - 2021-12-07 07:48:13 --> Config Class Initialized
INFO - 2021-12-07 07:48:13 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:48:13 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:48:13 --> Utf8 Class Initialized
INFO - 2021-12-07 07:48:13 --> URI Class Initialized
INFO - 2021-12-07 07:48:13 --> Router Class Initialized
INFO - 2021-12-07 07:48:13 --> Output Class Initialized
INFO - 2021-12-07 07:48:13 --> Security Class Initialized
DEBUG - 2021-12-07 07:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:48:13 --> Input Class Initialized
INFO - 2021-12-07 07:48:13 --> Language Class Initialized
INFO - 2021-12-07 07:48:13 --> Language Class Initialized
INFO - 2021-12-07 07:48:13 --> Config Class Initialized
INFO - 2021-12-07 07:48:13 --> Loader Class Initialized
INFO - 2021-12-07 07:48:13 --> Helper loaded: url_helper
INFO - 2021-12-07 07:48:13 --> Helper loaded: file_helper
INFO - 2021-12-07 07:48:13 --> Helper loaded: form_helper
INFO - 2021-12-07 07:48:13 --> Helper loaded: my_helper
INFO - 2021-12-07 07:48:13 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:48:13 --> Controller Class Initialized
DEBUG - 2021-12-07 07:48:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 07:48:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:48:13 --> Final output sent to browser
DEBUG - 2021-12-07 07:48:13 --> Total execution time: 0.6480
INFO - 2021-12-07 07:48:22 --> Config Class Initialized
INFO - 2021-12-07 07:48:22 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:48:22 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:48:22 --> Utf8 Class Initialized
INFO - 2021-12-07 07:48:22 --> URI Class Initialized
INFO - 2021-12-07 07:48:22 --> Router Class Initialized
INFO - 2021-12-07 07:48:22 --> Output Class Initialized
INFO - 2021-12-07 07:48:22 --> Security Class Initialized
DEBUG - 2021-12-07 07:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:48:22 --> Input Class Initialized
INFO - 2021-12-07 07:48:22 --> Language Class Initialized
INFO - 2021-12-07 07:48:22 --> Language Class Initialized
INFO - 2021-12-07 07:48:22 --> Config Class Initialized
INFO - 2021-12-07 07:48:22 --> Loader Class Initialized
INFO - 2021-12-07 07:48:22 --> Helper loaded: url_helper
INFO - 2021-12-07 07:48:22 --> Helper loaded: file_helper
INFO - 2021-12-07 07:48:22 --> Helper loaded: form_helper
INFO - 2021-12-07 07:48:22 --> Helper loaded: my_helper
INFO - 2021-12-07 07:48:22 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:48:22 --> Controller Class Initialized
DEBUG - 2021-12-07 07:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 07:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:48:22 --> Final output sent to browser
DEBUG - 2021-12-07 07:48:22 --> Total execution time: 0.1390
INFO - 2021-12-07 07:48:41 --> Config Class Initialized
INFO - 2021-12-07 07:48:41 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:48:41 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:48:41 --> Utf8 Class Initialized
INFO - 2021-12-07 07:48:41 --> URI Class Initialized
INFO - 2021-12-07 07:48:41 --> Router Class Initialized
INFO - 2021-12-07 07:48:41 --> Output Class Initialized
INFO - 2021-12-07 07:48:41 --> Security Class Initialized
DEBUG - 2021-12-07 07:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:48:41 --> Input Class Initialized
INFO - 2021-12-07 07:48:41 --> Language Class Initialized
INFO - 2021-12-07 07:48:41 --> Language Class Initialized
INFO - 2021-12-07 07:48:41 --> Config Class Initialized
INFO - 2021-12-07 07:48:41 --> Loader Class Initialized
INFO - 2021-12-07 07:48:41 --> Helper loaded: url_helper
INFO - 2021-12-07 07:48:41 --> Helper loaded: file_helper
INFO - 2021-12-07 07:48:41 --> Helper loaded: form_helper
INFO - 2021-12-07 07:48:41 --> Helper loaded: my_helper
INFO - 2021-12-07 07:48:41 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:48:41 --> Controller Class Initialized
DEBUG - 2021-12-07 07:48:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 07:48:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:48:41 --> Final output sent to browser
DEBUG - 2021-12-07 07:48:41 --> Total execution time: 0.7020
INFO - 2021-12-07 07:48:44 --> Config Class Initialized
INFO - 2021-12-07 07:48:44 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:48:44 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:48:44 --> Utf8 Class Initialized
INFO - 2021-12-07 07:48:44 --> URI Class Initialized
INFO - 2021-12-07 07:48:44 --> Router Class Initialized
INFO - 2021-12-07 07:48:44 --> Output Class Initialized
INFO - 2021-12-07 07:48:44 --> Security Class Initialized
DEBUG - 2021-12-07 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:48:44 --> Input Class Initialized
INFO - 2021-12-07 07:48:44 --> Language Class Initialized
INFO - 2021-12-07 07:48:44 --> Language Class Initialized
INFO - 2021-12-07 07:48:44 --> Config Class Initialized
INFO - 2021-12-07 07:48:44 --> Loader Class Initialized
INFO - 2021-12-07 07:48:44 --> Helper loaded: url_helper
INFO - 2021-12-07 07:48:44 --> Helper loaded: file_helper
INFO - 2021-12-07 07:48:44 --> Helper loaded: form_helper
INFO - 2021-12-07 07:48:44 --> Helper loaded: my_helper
INFO - 2021-12-07 07:48:44 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:48:44 --> Controller Class Initialized
DEBUG - 2021-12-07 07:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-07 07:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:48:44 --> Final output sent to browser
DEBUG - 2021-12-07 07:48:44 --> Total execution time: 0.0730
INFO - 2021-12-07 07:49:02 --> Config Class Initialized
INFO - 2021-12-07 07:49:02 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:49:02 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:49:02 --> Utf8 Class Initialized
INFO - 2021-12-07 07:49:02 --> URI Class Initialized
INFO - 2021-12-07 07:49:02 --> Router Class Initialized
INFO - 2021-12-07 07:49:02 --> Output Class Initialized
INFO - 2021-12-07 07:49:02 --> Security Class Initialized
DEBUG - 2021-12-07 07:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:49:02 --> Input Class Initialized
INFO - 2021-12-07 07:49:02 --> Language Class Initialized
INFO - 2021-12-07 07:49:02 --> Language Class Initialized
INFO - 2021-12-07 07:49:02 --> Config Class Initialized
INFO - 2021-12-07 07:49:02 --> Loader Class Initialized
INFO - 2021-12-07 07:49:02 --> Helper loaded: url_helper
INFO - 2021-12-07 07:49:02 --> Helper loaded: file_helper
INFO - 2021-12-07 07:49:02 --> Helper loaded: form_helper
INFO - 2021-12-07 07:49:02 --> Helper loaded: my_helper
INFO - 2021-12-07 07:49:02 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:49:02 --> Controller Class Initialized
DEBUG - 2021-12-07 07:49:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 07:49:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:49:03 --> Final output sent to browser
DEBUG - 2021-12-07 07:49:03 --> Total execution time: 0.6480
INFO - 2021-12-07 07:49:05 --> Config Class Initialized
INFO - 2021-12-07 07:49:05 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:49:05 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:49:05 --> Utf8 Class Initialized
INFO - 2021-12-07 07:49:05 --> URI Class Initialized
INFO - 2021-12-07 07:49:05 --> Router Class Initialized
INFO - 2021-12-07 07:49:05 --> Output Class Initialized
INFO - 2021-12-07 07:49:05 --> Security Class Initialized
DEBUG - 2021-12-07 07:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:49:05 --> Input Class Initialized
INFO - 2021-12-07 07:49:05 --> Language Class Initialized
INFO - 2021-12-07 07:49:05 --> Language Class Initialized
INFO - 2021-12-07 07:49:05 --> Config Class Initialized
INFO - 2021-12-07 07:49:05 --> Loader Class Initialized
INFO - 2021-12-07 07:49:05 --> Helper loaded: url_helper
INFO - 2021-12-07 07:49:05 --> Helper loaded: file_helper
INFO - 2021-12-07 07:49:05 --> Helper loaded: form_helper
INFO - 2021-12-07 07:49:05 --> Helper loaded: my_helper
INFO - 2021-12-07 07:49:05 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:49:05 --> Controller Class Initialized
DEBUG - 2021-12-07 07:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-07 07:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:49:06 --> Final output sent to browser
DEBUG - 2021-12-07 07:49:06 --> Total execution time: 0.0720
INFO - 2021-12-07 07:49:19 --> Config Class Initialized
INFO - 2021-12-07 07:49:19 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:49:19 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:49:19 --> Utf8 Class Initialized
INFO - 2021-12-07 07:49:19 --> URI Class Initialized
INFO - 2021-12-07 07:49:19 --> Router Class Initialized
INFO - 2021-12-07 07:49:19 --> Output Class Initialized
INFO - 2021-12-07 07:49:19 --> Security Class Initialized
DEBUG - 2021-12-07 07:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:49:19 --> Input Class Initialized
INFO - 2021-12-07 07:49:19 --> Language Class Initialized
INFO - 2021-12-07 07:49:19 --> Language Class Initialized
INFO - 2021-12-07 07:49:19 --> Config Class Initialized
INFO - 2021-12-07 07:49:19 --> Loader Class Initialized
INFO - 2021-12-07 07:49:19 --> Helper loaded: url_helper
INFO - 2021-12-07 07:49:19 --> Helper loaded: file_helper
INFO - 2021-12-07 07:49:19 --> Helper loaded: form_helper
INFO - 2021-12-07 07:49:19 --> Helper loaded: my_helper
INFO - 2021-12-07 07:49:19 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:49:19 --> Controller Class Initialized
DEBUG - 2021-12-07 07:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 07:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:49:19 --> Final output sent to browser
DEBUG - 2021-12-07 07:49:19 --> Total execution time: 0.6980
INFO - 2021-12-07 07:49:27 --> Config Class Initialized
INFO - 2021-12-07 07:49:27 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:49:27 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:49:27 --> Utf8 Class Initialized
INFO - 2021-12-07 07:49:27 --> URI Class Initialized
INFO - 2021-12-07 07:49:27 --> Router Class Initialized
INFO - 2021-12-07 07:49:27 --> Output Class Initialized
INFO - 2021-12-07 07:49:27 --> Security Class Initialized
DEBUG - 2021-12-07 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:49:27 --> Input Class Initialized
INFO - 2021-12-07 07:49:27 --> Language Class Initialized
INFO - 2021-12-07 07:49:27 --> Language Class Initialized
INFO - 2021-12-07 07:49:27 --> Config Class Initialized
INFO - 2021-12-07 07:49:27 --> Loader Class Initialized
INFO - 2021-12-07 07:49:27 --> Helper loaded: url_helper
INFO - 2021-12-07 07:49:27 --> Helper loaded: file_helper
INFO - 2021-12-07 07:49:27 --> Helper loaded: form_helper
INFO - 2021-12-07 07:49:27 --> Helper loaded: my_helper
INFO - 2021-12-07 07:49:27 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:49:27 --> Controller Class Initialized
DEBUG - 2021-12-07 07:49:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-07 07:49:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:49:27 --> Final output sent to browser
DEBUG - 2021-12-07 07:49:27 --> Total execution time: 0.0630
INFO - 2021-12-07 07:49:38 --> Config Class Initialized
INFO - 2021-12-07 07:49:38 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:49:38 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:49:38 --> Utf8 Class Initialized
INFO - 2021-12-07 07:49:38 --> URI Class Initialized
INFO - 2021-12-07 07:49:38 --> Router Class Initialized
INFO - 2021-12-07 07:49:38 --> Output Class Initialized
INFO - 2021-12-07 07:49:38 --> Security Class Initialized
DEBUG - 2021-12-07 07:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:49:38 --> Input Class Initialized
INFO - 2021-12-07 07:49:38 --> Language Class Initialized
INFO - 2021-12-07 07:49:38 --> Language Class Initialized
INFO - 2021-12-07 07:49:38 --> Config Class Initialized
INFO - 2021-12-07 07:49:38 --> Loader Class Initialized
INFO - 2021-12-07 07:49:38 --> Helper loaded: url_helper
INFO - 2021-12-07 07:49:38 --> Helper loaded: file_helper
INFO - 2021-12-07 07:49:38 --> Helper loaded: form_helper
INFO - 2021-12-07 07:49:38 --> Helper loaded: my_helper
INFO - 2021-12-07 07:49:38 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:49:38 --> Controller Class Initialized
DEBUG - 2021-12-07 07:49:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-12-07 07:49:38 --> Final output sent to browser
DEBUG - 2021-12-07 07:49:38 --> Total execution time: 0.1810
INFO - 2021-12-07 07:50:14 --> Config Class Initialized
INFO - 2021-12-07 07:50:14 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:50:14 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:50:14 --> Utf8 Class Initialized
INFO - 2021-12-07 07:50:14 --> URI Class Initialized
INFO - 2021-12-07 07:50:14 --> Router Class Initialized
INFO - 2021-12-07 07:50:14 --> Output Class Initialized
INFO - 2021-12-07 07:50:14 --> Security Class Initialized
DEBUG - 2021-12-07 07:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:50:14 --> Input Class Initialized
INFO - 2021-12-07 07:50:14 --> Language Class Initialized
INFO - 2021-12-07 07:50:14 --> Language Class Initialized
INFO - 2021-12-07 07:50:14 --> Config Class Initialized
INFO - 2021-12-07 07:50:14 --> Loader Class Initialized
INFO - 2021-12-07 07:50:14 --> Helper loaded: url_helper
INFO - 2021-12-07 07:50:14 --> Helper loaded: file_helper
INFO - 2021-12-07 07:50:14 --> Helper loaded: form_helper
INFO - 2021-12-07 07:50:14 --> Helper loaded: my_helper
INFO - 2021-12-07 07:50:14 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:50:14 --> Controller Class Initialized
DEBUG - 2021-12-07 07:50:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-12-07 07:50:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:50:14 --> Final output sent to browser
DEBUG - 2021-12-07 07:50:14 --> Total execution time: 0.0510
INFO - 2021-12-07 07:50:21 --> Config Class Initialized
INFO - 2021-12-07 07:50:21 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:50:21 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:50:21 --> Utf8 Class Initialized
INFO - 2021-12-07 07:50:21 --> URI Class Initialized
INFO - 2021-12-07 07:50:21 --> Router Class Initialized
INFO - 2021-12-07 07:50:21 --> Output Class Initialized
INFO - 2021-12-07 07:50:21 --> Security Class Initialized
DEBUG - 2021-12-07 07:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:50:21 --> Input Class Initialized
INFO - 2021-12-07 07:50:21 --> Language Class Initialized
INFO - 2021-12-07 07:50:21 --> Language Class Initialized
INFO - 2021-12-07 07:50:21 --> Config Class Initialized
INFO - 2021-12-07 07:50:21 --> Loader Class Initialized
INFO - 2021-12-07 07:50:21 --> Helper loaded: url_helper
INFO - 2021-12-07 07:50:21 --> Helper loaded: file_helper
INFO - 2021-12-07 07:50:21 --> Helper loaded: form_helper
INFO - 2021-12-07 07:50:21 --> Helper loaded: my_helper
INFO - 2021-12-07 07:50:21 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:50:21 --> Controller Class Initialized
DEBUG - 2021-12-07 07:50:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-12-07 07:50:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:50:21 --> Final output sent to browser
DEBUG - 2021-12-07 07:50:21 --> Total execution time: 0.0550
INFO - 2021-12-07 07:50:21 --> Config Class Initialized
INFO - 2021-12-07 07:50:21 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:50:21 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:50:21 --> Utf8 Class Initialized
INFO - 2021-12-07 07:50:21 --> URI Class Initialized
INFO - 2021-12-07 07:50:21 --> Router Class Initialized
INFO - 2021-12-07 07:50:21 --> Output Class Initialized
INFO - 2021-12-07 07:50:21 --> Security Class Initialized
DEBUG - 2021-12-07 07:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:50:21 --> Input Class Initialized
INFO - 2021-12-07 07:50:21 --> Language Class Initialized
INFO - 2021-12-07 07:50:21 --> Language Class Initialized
INFO - 2021-12-07 07:50:21 --> Config Class Initialized
INFO - 2021-12-07 07:50:21 --> Loader Class Initialized
INFO - 2021-12-07 07:50:21 --> Helper loaded: url_helper
INFO - 2021-12-07 07:50:21 --> Helper loaded: file_helper
INFO - 2021-12-07 07:50:21 --> Helper loaded: form_helper
INFO - 2021-12-07 07:50:21 --> Helper loaded: my_helper
INFO - 2021-12-07 07:50:21 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:50:21 --> Controller Class Initialized
INFO - 2021-12-07 07:50:25 --> Config Class Initialized
INFO - 2021-12-07 07:50:25 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:50:25 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:50:25 --> Utf8 Class Initialized
INFO - 2021-12-07 07:50:25 --> URI Class Initialized
INFO - 2021-12-07 07:50:25 --> Router Class Initialized
INFO - 2021-12-07 07:50:25 --> Output Class Initialized
INFO - 2021-12-07 07:50:25 --> Security Class Initialized
DEBUG - 2021-12-07 07:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:50:25 --> Input Class Initialized
INFO - 2021-12-07 07:50:25 --> Language Class Initialized
INFO - 2021-12-07 07:50:25 --> Language Class Initialized
INFO - 2021-12-07 07:50:25 --> Config Class Initialized
INFO - 2021-12-07 07:50:25 --> Loader Class Initialized
INFO - 2021-12-07 07:50:25 --> Helper loaded: url_helper
INFO - 2021-12-07 07:50:25 --> Helper loaded: file_helper
INFO - 2021-12-07 07:50:25 --> Helper loaded: form_helper
INFO - 2021-12-07 07:50:25 --> Helper loaded: my_helper
INFO - 2021-12-07 07:50:25 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:50:25 --> Controller Class Initialized
INFO - 2021-12-07 07:50:25 --> Final output sent to browser
DEBUG - 2021-12-07 07:50:25 --> Total execution time: 0.0540
INFO - 2021-12-07 07:51:38 --> Config Class Initialized
INFO - 2021-12-07 07:51:38 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:51:38 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:51:38 --> Utf8 Class Initialized
INFO - 2021-12-07 07:51:38 --> URI Class Initialized
DEBUG - 2021-12-07 07:51:38 --> No URI present. Default controller set.
INFO - 2021-12-07 07:51:38 --> Router Class Initialized
INFO - 2021-12-07 07:51:38 --> Output Class Initialized
INFO - 2021-12-07 07:51:38 --> Security Class Initialized
DEBUG - 2021-12-07 07:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:51:38 --> Input Class Initialized
INFO - 2021-12-07 07:51:38 --> Language Class Initialized
INFO - 2021-12-07 07:51:38 --> Language Class Initialized
INFO - 2021-12-07 07:51:38 --> Config Class Initialized
INFO - 2021-12-07 07:51:38 --> Loader Class Initialized
INFO - 2021-12-07 07:51:38 --> Helper loaded: url_helper
INFO - 2021-12-07 07:51:38 --> Helper loaded: file_helper
INFO - 2021-12-07 07:51:38 --> Helper loaded: form_helper
INFO - 2021-12-07 07:51:38 --> Helper loaded: my_helper
INFO - 2021-12-07 07:51:38 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:51:38 --> Controller Class Initialized
DEBUG - 2021-12-07 07:51:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 07:51:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:51:39 --> Final output sent to browser
DEBUG - 2021-12-07 07:51:39 --> Total execution time: 0.7310
INFO - 2021-12-07 07:51:47 --> Config Class Initialized
INFO - 2021-12-07 07:51:47 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:51:47 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:51:47 --> Utf8 Class Initialized
INFO - 2021-12-07 07:51:47 --> URI Class Initialized
INFO - 2021-12-07 07:51:47 --> Router Class Initialized
INFO - 2021-12-07 07:51:47 --> Output Class Initialized
INFO - 2021-12-07 07:51:47 --> Security Class Initialized
DEBUG - 2021-12-07 07:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:51:47 --> Input Class Initialized
INFO - 2021-12-07 07:51:47 --> Language Class Initialized
INFO - 2021-12-07 07:51:47 --> Language Class Initialized
INFO - 2021-12-07 07:51:47 --> Config Class Initialized
INFO - 2021-12-07 07:51:47 --> Loader Class Initialized
INFO - 2021-12-07 07:51:47 --> Helper loaded: url_helper
INFO - 2021-12-07 07:51:47 --> Helper loaded: file_helper
INFO - 2021-12-07 07:51:47 --> Helper loaded: form_helper
INFO - 2021-12-07 07:51:47 --> Helper loaded: my_helper
INFO - 2021-12-07 07:51:47 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:51:47 --> Controller Class Initialized
DEBUG - 2021-12-07 07:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-07 07:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:51:47 --> Final output sent to browser
DEBUG - 2021-12-07 07:51:47 --> Total execution time: 0.0670
INFO - 2021-12-07 07:52:00 --> Config Class Initialized
INFO - 2021-12-07 07:52:00 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:52:00 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:52:00 --> Utf8 Class Initialized
INFO - 2021-12-07 07:52:00 --> URI Class Initialized
INFO - 2021-12-07 07:52:00 --> Router Class Initialized
INFO - 2021-12-07 07:52:00 --> Output Class Initialized
INFO - 2021-12-07 07:52:00 --> Security Class Initialized
DEBUG - 2021-12-07 07:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:52:00 --> Input Class Initialized
INFO - 2021-12-07 07:52:00 --> Language Class Initialized
INFO - 2021-12-07 07:52:00 --> Language Class Initialized
INFO - 2021-12-07 07:52:00 --> Config Class Initialized
INFO - 2021-12-07 07:52:00 --> Loader Class Initialized
INFO - 2021-12-07 07:52:00 --> Helper loaded: url_helper
INFO - 2021-12-07 07:52:00 --> Helper loaded: file_helper
INFO - 2021-12-07 07:52:00 --> Helper loaded: form_helper
INFO - 2021-12-07 07:52:00 --> Helper loaded: my_helper
INFO - 2021-12-07 07:52:00 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:52:00 --> Controller Class Initialized
DEBUG - 2021-12-07 07:52:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-12-07 07:52:00 --> Final output sent to browser
DEBUG - 2021-12-07 07:52:00 --> Total execution time: 0.1770
INFO - 2021-12-07 07:59:50 --> Config Class Initialized
INFO - 2021-12-07 07:59:50 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:59:50 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:59:50 --> Utf8 Class Initialized
INFO - 2021-12-07 07:59:50 --> URI Class Initialized
INFO - 2021-12-07 07:59:50 --> Router Class Initialized
INFO - 2021-12-07 07:59:50 --> Output Class Initialized
INFO - 2021-12-07 07:59:50 --> Security Class Initialized
DEBUG - 2021-12-07 07:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:59:50 --> Input Class Initialized
INFO - 2021-12-07 07:59:50 --> Language Class Initialized
INFO - 2021-12-07 07:59:50 --> Language Class Initialized
INFO - 2021-12-07 07:59:50 --> Config Class Initialized
INFO - 2021-12-07 07:59:50 --> Loader Class Initialized
INFO - 2021-12-07 07:59:50 --> Helper loaded: url_helper
INFO - 2021-12-07 07:59:50 --> Helper loaded: file_helper
INFO - 2021-12-07 07:59:50 --> Helper loaded: form_helper
INFO - 2021-12-07 07:59:50 --> Helper loaded: my_helper
INFO - 2021-12-07 07:59:50 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:59:50 --> Controller Class Initialized
INFO - 2021-12-07 07:59:50 --> Helper loaded: cookie_helper
INFO - 2021-12-07 07:59:50 --> Config Class Initialized
INFO - 2021-12-07 07:59:50 --> Hooks Class Initialized
DEBUG - 2021-12-07 07:59:50 --> UTF-8 Support Enabled
INFO - 2021-12-07 07:59:50 --> Utf8 Class Initialized
INFO - 2021-12-07 07:59:50 --> URI Class Initialized
INFO - 2021-12-07 07:59:50 --> Router Class Initialized
INFO - 2021-12-07 07:59:50 --> Output Class Initialized
INFO - 2021-12-07 07:59:50 --> Security Class Initialized
DEBUG - 2021-12-07 07:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 07:59:50 --> Input Class Initialized
INFO - 2021-12-07 07:59:50 --> Language Class Initialized
INFO - 2021-12-07 07:59:50 --> Language Class Initialized
INFO - 2021-12-07 07:59:50 --> Config Class Initialized
INFO - 2021-12-07 07:59:50 --> Loader Class Initialized
INFO - 2021-12-07 07:59:50 --> Helper loaded: url_helper
INFO - 2021-12-07 07:59:50 --> Helper loaded: file_helper
INFO - 2021-12-07 07:59:50 --> Helper loaded: form_helper
INFO - 2021-12-07 07:59:50 --> Helper loaded: my_helper
INFO - 2021-12-07 07:59:50 --> Database Driver Class Initialized
DEBUG - 2021-12-07 07:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 07:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 07:59:50 --> Controller Class Initialized
DEBUG - 2021-12-07 07:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 07:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 07:59:50 --> Final output sent to browser
DEBUG - 2021-12-07 07:59:50 --> Total execution time: 0.0440
INFO - 2021-12-07 08:00:05 --> Config Class Initialized
INFO - 2021-12-07 08:00:05 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:00:05 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:00:05 --> Utf8 Class Initialized
INFO - 2021-12-07 08:00:05 --> URI Class Initialized
INFO - 2021-12-07 08:00:05 --> Router Class Initialized
INFO - 2021-12-07 08:00:05 --> Output Class Initialized
INFO - 2021-12-07 08:00:05 --> Security Class Initialized
DEBUG - 2021-12-07 08:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:00:05 --> Input Class Initialized
INFO - 2021-12-07 08:00:05 --> Language Class Initialized
INFO - 2021-12-07 08:00:05 --> Language Class Initialized
INFO - 2021-12-07 08:00:05 --> Config Class Initialized
INFO - 2021-12-07 08:00:05 --> Loader Class Initialized
INFO - 2021-12-07 08:00:05 --> Helper loaded: url_helper
INFO - 2021-12-07 08:00:05 --> Helper loaded: file_helper
INFO - 2021-12-07 08:00:05 --> Helper loaded: form_helper
INFO - 2021-12-07 08:00:05 --> Helper loaded: my_helper
INFO - 2021-12-07 08:00:05 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:00:05 --> Controller Class Initialized
INFO - 2021-12-07 08:00:05 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:00:05 --> Final output sent to browser
DEBUG - 2021-12-07 08:00:05 --> Total execution time: 0.0460
INFO - 2021-12-07 08:00:06 --> Config Class Initialized
INFO - 2021-12-07 08:00:06 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:00:06 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:00:06 --> Utf8 Class Initialized
INFO - 2021-12-07 08:00:06 --> URI Class Initialized
INFO - 2021-12-07 08:00:06 --> Router Class Initialized
INFO - 2021-12-07 08:00:06 --> Output Class Initialized
INFO - 2021-12-07 08:00:06 --> Security Class Initialized
DEBUG - 2021-12-07 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:00:06 --> Input Class Initialized
INFO - 2021-12-07 08:00:06 --> Language Class Initialized
INFO - 2021-12-07 08:00:06 --> Language Class Initialized
INFO - 2021-12-07 08:00:06 --> Config Class Initialized
INFO - 2021-12-07 08:00:06 --> Loader Class Initialized
INFO - 2021-12-07 08:00:06 --> Helper loaded: url_helper
INFO - 2021-12-07 08:00:06 --> Helper loaded: file_helper
INFO - 2021-12-07 08:00:06 --> Helper loaded: form_helper
INFO - 2021-12-07 08:00:06 --> Helper loaded: my_helper
INFO - 2021-12-07 08:00:06 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:00:06 --> Controller Class Initialized
DEBUG - 2021-12-07 08:00:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:00:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:00:06 --> Final output sent to browser
DEBUG - 2021-12-07 08:00:06 --> Total execution time: 0.7470
INFO - 2021-12-07 08:00:10 --> Config Class Initialized
INFO - 2021-12-07 08:00:10 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:00:10 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:00:10 --> Utf8 Class Initialized
INFO - 2021-12-07 08:00:10 --> URI Class Initialized
INFO - 2021-12-07 08:00:10 --> Router Class Initialized
INFO - 2021-12-07 08:00:10 --> Output Class Initialized
INFO - 2021-12-07 08:00:10 --> Security Class Initialized
DEBUG - 2021-12-07 08:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:00:10 --> Input Class Initialized
INFO - 2021-12-07 08:00:10 --> Language Class Initialized
INFO - 2021-12-07 08:00:10 --> Language Class Initialized
INFO - 2021-12-07 08:00:10 --> Config Class Initialized
INFO - 2021-12-07 08:00:10 --> Loader Class Initialized
INFO - 2021-12-07 08:00:10 --> Helper loaded: url_helper
INFO - 2021-12-07 08:00:10 --> Helper loaded: file_helper
INFO - 2021-12-07 08:00:10 --> Helper loaded: form_helper
INFO - 2021-12-07 08:00:10 --> Helper loaded: my_helper
INFO - 2021-12-07 08:00:10 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:00:10 --> Controller Class Initialized
DEBUG - 2021-12-07 08:00:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-12-07 08:00:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:00:10 --> Final output sent to browser
DEBUG - 2021-12-07 08:00:10 --> Total execution time: 0.0540
INFO - 2021-12-07 08:00:42 --> Config Class Initialized
INFO - 2021-12-07 08:00:42 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:00:42 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:00:42 --> Utf8 Class Initialized
INFO - 2021-12-07 08:00:42 --> URI Class Initialized
INFO - 2021-12-07 08:00:42 --> Router Class Initialized
INFO - 2021-12-07 08:00:42 --> Output Class Initialized
INFO - 2021-12-07 08:00:42 --> Security Class Initialized
DEBUG - 2021-12-07 08:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:00:42 --> Input Class Initialized
INFO - 2021-12-07 08:00:42 --> Language Class Initialized
INFO - 2021-12-07 08:00:42 --> Language Class Initialized
INFO - 2021-12-07 08:00:42 --> Config Class Initialized
INFO - 2021-12-07 08:00:42 --> Loader Class Initialized
INFO - 2021-12-07 08:00:42 --> Helper loaded: url_helper
INFO - 2021-12-07 08:00:42 --> Helper loaded: file_helper
INFO - 2021-12-07 08:00:42 --> Helper loaded: form_helper
INFO - 2021-12-07 08:00:42 --> Helper loaded: my_helper
INFO - 2021-12-07 08:00:42 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:00:42 --> Controller Class Initialized
DEBUG - 2021-12-07 08:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-12-07 08:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:00:42 --> Final output sent to browser
DEBUG - 2021-12-07 08:00:42 --> Total execution time: 0.0550
INFO - 2021-12-07 08:00:42 --> Config Class Initialized
INFO - 2021-12-07 08:00:42 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:00:42 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:00:42 --> Utf8 Class Initialized
INFO - 2021-12-07 08:00:42 --> URI Class Initialized
INFO - 2021-12-07 08:00:42 --> Router Class Initialized
INFO - 2021-12-07 08:00:42 --> Output Class Initialized
INFO - 2021-12-07 08:00:42 --> Security Class Initialized
DEBUG - 2021-12-07 08:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:00:42 --> Input Class Initialized
INFO - 2021-12-07 08:00:42 --> Language Class Initialized
INFO - 2021-12-07 08:00:42 --> Language Class Initialized
INFO - 2021-12-07 08:00:42 --> Config Class Initialized
INFO - 2021-12-07 08:00:42 --> Loader Class Initialized
INFO - 2021-12-07 08:00:42 --> Helper loaded: url_helper
INFO - 2021-12-07 08:00:42 --> Helper loaded: file_helper
INFO - 2021-12-07 08:00:42 --> Helper loaded: form_helper
INFO - 2021-12-07 08:00:42 --> Helper loaded: my_helper
INFO - 2021-12-07 08:00:42 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:00:42 --> Controller Class Initialized
INFO - 2021-12-07 08:00:44 --> Config Class Initialized
INFO - 2021-12-07 08:00:44 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:00:44 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:00:44 --> Utf8 Class Initialized
INFO - 2021-12-07 08:00:44 --> URI Class Initialized
INFO - 2021-12-07 08:00:44 --> Router Class Initialized
INFO - 2021-12-07 08:00:44 --> Output Class Initialized
INFO - 2021-12-07 08:00:44 --> Security Class Initialized
DEBUG - 2021-12-07 08:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:00:44 --> Input Class Initialized
INFO - 2021-12-07 08:00:44 --> Language Class Initialized
INFO - 2021-12-07 08:00:44 --> Language Class Initialized
INFO - 2021-12-07 08:00:44 --> Config Class Initialized
INFO - 2021-12-07 08:00:44 --> Loader Class Initialized
INFO - 2021-12-07 08:00:44 --> Helper loaded: url_helper
INFO - 2021-12-07 08:00:44 --> Helper loaded: file_helper
INFO - 2021-12-07 08:00:44 --> Helper loaded: form_helper
INFO - 2021-12-07 08:00:44 --> Helper loaded: my_helper
INFO - 2021-12-07 08:00:44 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:00:44 --> Controller Class Initialized
DEBUG - 2021-12-07 08:00:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-12-07 08:00:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:00:44 --> Final output sent to browser
DEBUG - 2021-12-07 08:00:44 --> Total execution time: 0.0480
INFO - 2021-12-07 08:00:46 --> Config Class Initialized
INFO - 2021-12-07 08:00:46 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:00:46 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:00:46 --> Utf8 Class Initialized
INFO - 2021-12-07 08:00:46 --> URI Class Initialized
INFO - 2021-12-07 08:00:46 --> Router Class Initialized
INFO - 2021-12-07 08:00:46 --> Output Class Initialized
INFO - 2021-12-07 08:00:46 --> Security Class Initialized
DEBUG - 2021-12-07 08:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:00:46 --> Input Class Initialized
INFO - 2021-12-07 08:00:46 --> Language Class Initialized
INFO - 2021-12-07 08:00:46 --> Language Class Initialized
INFO - 2021-12-07 08:00:46 --> Config Class Initialized
INFO - 2021-12-07 08:00:46 --> Loader Class Initialized
INFO - 2021-12-07 08:00:46 --> Helper loaded: url_helper
INFO - 2021-12-07 08:00:46 --> Helper loaded: file_helper
INFO - 2021-12-07 08:00:46 --> Helper loaded: form_helper
INFO - 2021-12-07 08:00:46 --> Helper loaded: my_helper
INFO - 2021-12-07 08:00:46 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:00:46 --> Controller Class Initialized
INFO - 2021-12-07 08:00:48 --> Config Class Initialized
INFO - 2021-12-07 08:00:48 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:00:48 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:00:48 --> Utf8 Class Initialized
INFO - 2021-12-07 08:00:48 --> URI Class Initialized
INFO - 2021-12-07 08:00:48 --> Router Class Initialized
INFO - 2021-12-07 08:00:48 --> Output Class Initialized
INFO - 2021-12-07 08:00:48 --> Security Class Initialized
DEBUG - 2021-12-07 08:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:00:48 --> Input Class Initialized
INFO - 2021-12-07 08:00:48 --> Language Class Initialized
INFO - 2021-12-07 08:00:48 --> Language Class Initialized
INFO - 2021-12-07 08:00:48 --> Config Class Initialized
INFO - 2021-12-07 08:00:48 --> Loader Class Initialized
INFO - 2021-12-07 08:00:48 --> Helper loaded: url_helper
INFO - 2021-12-07 08:00:48 --> Helper loaded: file_helper
INFO - 2021-12-07 08:00:48 --> Helper loaded: form_helper
INFO - 2021-12-07 08:00:48 --> Helper loaded: my_helper
INFO - 2021-12-07 08:00:48 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:00:48 --> Controller Class Initialized
INFO - 2021-12-07 08:01:56 --> Config Class Initialized
INFO - 2021-12-07 08:01:56 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:01:56 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:01:56 --> Utf8 Class Initialized
INFO - 2021-12-07 08:01:56 --> URI Class Initialized
INFO - 2021-12-07 08:01:56 --> Router Class Initialized
INFO - 2021-12-07 08:01:56 --> Output Class Initialized
INFO - 2021-12-07 08:01:56 --> Security Class Initialized
DEBUG - 2021-12-07 08:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:01:56 --> Input Class Initialized
INFO - 2021-12-07 08:01:56 --> Language Class Initialized
INFO - 2021-12-07 08:01:56 --> Language Class Initialized
INFO - 2021-12-07 08:01:56 --> Config Class Initialized
INFO - 2021-12-07 08:01:56 --> Loader Class Initialized
INFO - 2021-12-07 08:01:56 --> Helper loaded: url_helper
INFO - 2021-12-07 08:01:56 --> Helper loaded: file_helper
INFO - 2021-12-07 08:01:56 --> Helper loaded: form_helper
INFO - 2021-12-07 08:01:57 --> Helper loaded: my_helper
INFO - 2021-12-07 08:01:57 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:01:57 --> Controller Class Initialized
INFO - 2021-12-07 08:01:57 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:01:57 --> Config Class Initialized
INFO - 2021-12-07 08:01:57 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:01:57 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:01:57 --> Utf8 Class Initialized
INFO - 2021-12-07 08:01:57 --> URI Class Initialized
INFO - 2021-12-07 08:01:57 --> Router Class Initialized
INFO - 2021-12-07 08:01:57 --> Output Class Initialized
INFO - 2021-12-07 08:01:57 --> Security Class Initialized
DEBUG - 2021-12-07 08:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:01:57 --> Input Class Initialized
INFO - 2021-12-07 08:01:57 --> Language Class Initialized
INFO - 2021-12-07 08:01:57 --> Language Class Initialized
INFO - 2021-12-07 08:01:57 --> Config Class Initialized
INFO - 2021-12-07 08:01:57 --> Loader Class Initialized
INFO - 2021-12-07 08:01:57 --> Helper loaded: url_helper
INFO - 2021-12-07 08:01:57 --> Helper loaded: file_helper
INFO - 2021-12-07 08:01:57 --> Helper loaded: form_helper
INFO - 2021-12-07 08:01:57 --> Helper loaded: my_helper
INFO - 2021-12-07 08:01:57 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:01:57 --> Controller Class Initialized
DEBUG - 2021-12-07 08:01:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:01:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:01:57 --> Final output sent to browser
DEBUG - 2021-12-07 08:01:57 --> Total execution time: 0.0390
INFO - 2021-12-07 08:02:09 --> Config Class Initialized
INFO - 2021-12-07 08:02:09 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:02:09 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:02:09 --> Utf8 Class Initialized
INFO - 2021-12-07 08:02:09 --> URI Class Initialized
INFO - 2021-12-07 08:02:09 --> Router Class Initialized
INFO - 2021-12-07 08:02:09 --> Output Class Initialized
INFO - 2021-12-07 08:02:09 --> Security Class Initialized
DEBUG - 2021-12-07 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:02:09 --> Input Class Initialized
INFO - 2021-12-07 08:02:09 --> Language Class Initialized
INFO - 2021-12-07 08:02:09 --> Language Class Initialized
INFO - 2021-12-07 08:02:09 --> Config Class Initialized
INFO - 2021-12-07 08:02:09 --> Loader Class Initialized
INFO - 2021-12-07 08:02:09 --> Helper loaded: url_helper
INFO - 2021-12-07 08:02:09 --> Helper loaded: file_helper
INFO - 2021-12-07 08:02:09 --> Helper loaded: form_helper
INFO - 2021-12-07 08:02:09 --> Helper loaded: my_helper
INFO - 2021-12-07 08:02:09 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:02:09 --> Controller Class Initialized
INFO - 2021-12-07 08:02:09 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:02:09 --> Final output sent to browser
DEBUG - 2021-12-07 08:02:09 --> Total execution time: 0.0510
INFO - 2021-12-07 08:02:09 --> Config Class Initialized
INFO - 2021-12-07 08:02:09 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:02:09 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:02:09 --> Utf8 Class Initialized
INFO - 2021-12-07 08:02:09 --> URI Class Initialized
INFO - 2021-12-07 08:02:09 --> Router Class Initialized
INFO - 2021-12-07 08:02:09 --> Output Class Initialized
INFO - 2021-12-07 08:02:09 --> Security Class Initialized
DEBUG - 2021-12-07 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:02:09 --> Input Class Initialized
INFO - 2021-12-07 08:02:09 --> Language Class Initialized
INFO - 2021-12-07 08:02:09 --> Language Class Initialized
INFO - 2021-12-07 08:02:09 --> Config Class Initialized
INFO - 2021-12-07 08:02:09 --> Loader Class Initialized
INFO - 2021-12-07 08:02:09 --> Helper loaded: url_helper
INFO - 2021-12-07 08:02:09 --> Helper loaded: file_helper
INFO - 2021-12-07 08:02:09 --> Helper loaded: form_helper
INFO - 2021-12-07 08:02:09 --> Helper loaded: my_helper
INFO - 2021-12-07 08:02:09 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:02:09 --> Controller Class Initialized
DEBUG - 2021-12-07 08:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:02:10 --> Final output sent to browser
DEBUG - 2021-12-07 08:02:10 --> Total execution time: 0.7440
INFO - 2021-12-07 08:02:11 --> Config Class Initialized
INFO - 2021-12-07 08:02:11 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:02:11 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:02:11 --> Utf8 Class Initialized
INFO - 2021-12-07 08:02:11 --> URI Class Initialized
INFO - 2021-12-07 08:02:11 --> Router Class Initialized
INFO - 2021-12-07 08:02:11 --> Output Class Initialized
INFO - 2021-12-07 08:02:11 --> Security Class Initialized
DEBUG - 2021-12-07 08:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:02:11 --> Input Class Initialized
INFO - 2021-12-07 08:02:11 --> Language Class Initialized
INFO - 2021-12-07 08:02:11 --> Language Class Initialized
INFO - 2021-12-07 08:02:11 --> Config Class Initialized
INFO - 2021-12-07 08:02:11 --> Loader Class Initialized
INFO - 2021-12-07 08:02:11 --> Helper loaded: url_helper
INFO - 2021-12-07 08:02:11 --> Helper loaded: file_helper
INFO - 2021-12-07 08:02:11 --> Helper loaded: form_helper
INFO - 2021-12-07 08:02:11 --> Helper loaded: my_helper
INFO - 2021-12-07 08:02:11 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:02:11 --> Controller Class Initialized
DEBUG - 2021-12-07 08:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-12-07 08:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:02:11 --> Final output sent to browser
DEBUG - 2021-12-07 08:02:11 --> Total execution time: 0.0620
INFO - 2021-12-07 08:02:30 --> Config Class Initialized
INFO - 2021-12-07 08:02:30 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:02:30 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:02:30 --> Utf8 Class Initialized
INFO - 2021-12-07 08:02:30 --> URI Class Initialized
INFO - 2021-12-07 08:02:30 --> Router Class Initialized
INFO - 2021-12-07 08:02:30 --> Output Class Initialized
INFO - 2021-12-07 08:02:30 --> Security Class Initialized
DEBUG - 2021-12-07 08:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:02:30 --> Input Class Initialized
INFO - 2021-12-07 08:02:30 --> Language Class Initialized
INFO - 2021-12-07 08:02:30 --> Language Class Initialized
INFO - 2021-12-07 08:02:30 --> Config Class Initialized
INFO - 2021-12-07 08:02:30 --> Loader Class Initialized
INFO - 2021-12-07 08:02:30 --> Helper loaded: url_helper
INFO - 2021-12-07 08:02:30 --> Helper loaded: file_helper
INFO - 2021-12-07 08:02:30 --> Helper loaded: form_helper
INFO - 2021-12-07 08:02:30 --> Helper loaded: my_helper
INFO - 2021-12-07 08:02:30 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:02:30 --> Controller Class Initialized
DEBUG - 2021-12-07 08:02:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-12-07 08:02:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:02:30 --> Final output sent to browser
DEBUG - 2021-12-07 08:02:30 --> Total execution time: 0.0530
INFO - 2021-12-07 08:02:30 --> Config Class Initialized
INFO - 2021-12-07 08:02:30 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:02:30 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:02:30 --> Utf8 Class Initialized
INFO - 2021-12-07 08:02:30 --> URI Class Initialized
INFO - 2021-12-07 08:02:30 --> Router Class Initialized
INFO - 2021-12-07 08:02:30 --> Output Class Initialized
INFO - 2021-12-07 08:02:30 --> Security Class Initialized
DEBUG - 2021-12-07 08:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:02:30 --> Input Class Initialized
INFO - 2021-12-07 08:02:30 --> Language Class Initialized
INFO - 2021-12-07 08:02:30 --> Language Class Initialized
INFO - 2021-12-07 08:02:30 --> Config Class Initialized
INFO - 2021-12-07 08:02:30 --> Loader Class Initialized
INFO - 2021-12-07 08:02:30 --> Helper loaded: url_helper
INFO - 2021-12-07 08:02:30 --> Helper loaded: file_helper
INFO - 2021-12-07 08:02:30 --> Helper loaded: form_helper
INFO - 2021-12-07 08:02:30 --> Helper loaded: my_helper
INFO - 2021-12-07 08:02:30 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:02:30 --> Controller Class Initialized
INFO - 2021-12-07 08:02:32 --> Config Class Initialized
INFO - 2021-12-07 08:02:32 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:02:32 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:02:32 --> Utf8 Class Initialized
INFO - 2021-12-07 08:02:32 --> URI Class Initialized
INFO - 2021-12-07 08:02:32 --> Router Class Initialized
INFO - 2021-12-07 08:02:32 --> Output Class Initialized
INFO - 2021-12-07 08:02:32 --> Security Class Initialized
DEBUG - 2021-12-07 08:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:02:32 --> Input Class Initialized
INFO - 2021-12-07 08:02:32 --> Language Class Initialized
INFO - 2021-12-07 08:02:32 --> Language Class Initialized
INFO - 2021-12-07 08:02:32 --> Config Class Initialized
INFO - 2021-12-07 08:02:32 --> Loader Class Initialized
INFO - 2021-12-07 08:02:32 --> Helper loaded: url_helper
INFO - 2021-12-07 08:02:32 --> Helper loaded: file_helper
INFO - 2021-12-07 08:02:32 --> Helper loaded: form_helper
INFO - 2021-12-07 08:02:32 --> Helper loaded: my_helper
INFO - 2021-12-07 08:02:32 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:02:32 --> Controller Class Initialized
DEBUG - 2021-12-07 08:02:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-12-07 08:02:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:02:32 --> Final output sent to browser
DEBUG - 2021-12-07 08:02:32 --> Total execution time: 0.0370
INFO - 2021-12-07 08:02:33 --> Config Class Initialized
INFO - 2021-12-07 08:02:33 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:02:33 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:02:33 --> Utf8 Class Initialized
INFO - 2021-12-07 08:02:33 --> URI Class Initialized
INFO - 2021-12-07 08:02:33 --> Router Class Initialized
INFO - 2021-12-07 08:02:33 --> Output Class Initialized
INFO - 2021-12-07 08:02:33 --> Security Class Initialized
DEBUG - 2021-12-07 08:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:02:33 --> Input Class Initialized
INFO - 2021-12-07 08:02:33 --> Language Class Initialized
INFO - 2021-12-07 08:02:33 --> Language Class Initialized
INFO - 2021-12-07 08:02:33 --> Config Class Initialized
INFO - 2021-12-07 08:02:33 --> Loader Class Initialized
INFO - 2021-12-07 08:02:33 --> Helper loaded: url_helper
INFO - 2021-12-07 08:02:33 --> Helper loaded: file_helper
INFO - 2021-12-07 08:02:33 --> Helper loaded: form_helper
INFO - 2021-12-07 08:02:33 --> Helper loaded: my_helper
INFO - 2021-12-07 08:02:33 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:02:33 --> Controller Class Initialized
INFO - 2021-12-07 08:02:35 --> Config Class Initialized
INFO - 2021-12-07 08:02:35 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:02:35 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:02:35 --> Utf8 Class Initialized
INFO - 2021-12-07 08:02:35 --> URI Class Initialized
INFO - 2021-12-07 08:02:35 --> Router Class Initialized
INFO - 2021-12-07 08:02:35 --> Output Class Initialized
INFO - 2021-12-07 08:02:35 --> Security Class Initialized
DEBUG - 2021-12-07 08:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:02:35 --> Input Class Initialized
INFO - 2021-12-07 08:02:35 --> Language Class Initialized
INFO - 2021-12-07 08:02:35 --> Language Class Initialized
INFO - 2021-12-07 08:02:35 --> Config Class Initialized
INFO - 2021-12-07 08:02:35 --> Loader Class Initialized
INFO - 2021-12-07 08:02:35 --> Helper loaded: url_helper
INFO - 2021-12-07 08:02:35 --> Helper loaded: file_helper
INFO - 2021-12-07 08:02:35 --> Helper loaded: form_helper
INFO - 2021-12-07 08:02:35 --> Helper loaded: my_helper
INFO - 2021-12-07 08:02:35 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:02:35 --> Controller Class Initialized
INFO - 2021-12-07 08:03:33 --> Config Class Initialized
INFO - 2021-12-07 08:03:33 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:03:33 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:03:33 --> Utf8 Class Initialized
INFO - 2021-12-07 08:03:33 --> URI Class Initialized
INFO - 2021-12-07 08:03:33 --> Router Class Initialized
INFO - 2021-12-07 08:03:33 --> Output Class Initialized
INFO - 2021-12-07 08:03:33 --> Security Class Initialized
DEBUG - 2021-12-07 08:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:03:33 --> Input Class Initialized
INFO - 2021-12-07 08:03:33 --> Language Class Initialized
INFO - 2021-12-07 08:03:33 --> Language Class Initialized
INFO - 2021-12-07 08:03:33 --> Config Class Initialized
INFO - 2021-12-07 08:03:33 --> Loader Class Initialized
INFO - 2021-12-07 08:03:33 --> Helper loaded: url_helper
INFO - 2021-12-07 08:03:33 --> Helper loaded: file_helper
INFO - 2021-12-07 08:03:33 --> Helper loaded: form_helper
INFO - 2021-12-07 08:03:33 --> Helper loaded: my_helper
INFO - 2021-12-07 08:03:33 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:03:33 --> Controller Class Initialized
INFO - 2021-12-07 08:03:33 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:03:33 --> Config Class Initialized
INFO - 2021-12-07 08:03:33 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:03:33 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:03:33 --> Utf8 Class Initialized
INFO - 2021-12-07 08:03:33 --> URI Class Initialized
INFO - 2021-12-07 08:03:33 --> Router Class Initialized
INFO - 2021-12-07 08:03:33 --> Output Class Initialized
INFO - 2021-12-07 08:03:33 --> Security Class Initialized
DEBUG - 2021-12-07 08:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:03:33 --> Input Class Initialized
INFO - 2021-12-07 08:03:33 --> Language Class Initialized
INFO - 2021-12-07 08:03:33 --> Language Class Initialized
INFO - 2021-12-07 08:03:33 --> Config Class Initialized
INFO - 2021-12-07 08:03:33 --> Loader Class Initialized
INFO - 2021-12-07 08:03:33 --> Helper loaded: url_helper
INFO - 2021-12-07 08:03:33 --> Helper loaded: file_helper
INFO - 2021-12-07 08:03:33 --> Helper loaded: form_helper
INFO - 2021-12-07 08:03:33 --> Helper loaded: my_helper
INFO - 2021-12-07 08:03:33 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:03:33 --> Controller Class Initialized
DEBUG - 2021-12-07 08:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:03:33 --> Final output sent to browser
DEBUG - 2021-12-07 08:03:33 --> Total execution time: 0.0360
INFO - 2021-12-07 08:03:36 --> Config Class Initialized
INFO - 2021-12-07 08:03:36 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:03:36 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:03:36 --> Utf8 Class Initialized
INFO - 2021-12-07 08:03:36 --> URI Class Initialized
INFO - 2021-12-07 08:03:36 --> Router Class Initialized
INFO - 2021-12-07 08:03:36 --> Output Class Initialized
INFO - 2021-12-07 08:03:36 --> Security Class Initialized
DEBUG - 2021-12-07 08:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:03:36 --> Input Class Initialized
INFO - 2021-12-07 08:03:36 --> Language Class Initialized
INFO - 2021-12-07 08:03:36 --> Language Class Initialized
INFO - 2021-12-07 08:03:36 --> Config Class Initialized
INFO - 2021-12-07 08:03:36 --> Loader Class Initialized
INFO - 2021-12-07 08:03:36 --> Helper loaded: url_helper
INFO - 2021-12-07 08:03:36 --> Helper loaded: file_helper
INFO - 2021-12-07 08:03:36 --> Helper loaded: form_helper
INFO - 2021-12-07 08:03:36 --> Helper loaded: my_helper
INFO - 2021-12-07 08:03:36 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:03:36 --> Controller Class Initialized
INFO - 2021-12-07 08:03:36 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:03:36 --> Final output sent to browser
DEBUG - 2021-12-07 08:03:36 --> Total execution time: 0.0560
INFO - 2021-12-07 08:03:36 --> Config Class Initialized
INFO - 2021-12-07 08:03:36 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:03:36 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:03:36 --> Utf8 Class Initialized
INFO - 2021-12-07 08:03:36 --> URI Class Initialized
INFO - 2021-12-07 08:03:36 --> Router Class Initialized
INFO - 2021-12-07 08:03:36 --> Output Class Initialized
INFO - 2021-12-07 08:03:36 --> Security Class Initialized
DEBUG - 2021-12-07 08:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:03:36 --> Input Class Initialized
INFO - 2021-12-07 08:03:36 --> Language Class Initialized
INFO - 2021-12-07 08:03:36 --> Language Class Initialized
INFO - 2021-12-07 08:03:36 --> Config Class Initialized
INFO - 2021-12-07 08:03:36 --> Loader Class Initialized
INFO - 2021-12-07 08:03:36 --> Helper loaded: url_helper
INFO - 2021-12-07 08:03:36 --> Helper loaded: file_helper
INFO - 2021-12-07 08:03:36 --> Helper loaded: form_helper
INFO - 2021-12-07 08:03:36 --> Helper loaded: my_helper
INFO - 2021-12-07 08:03:36 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:03:36 --> Controller Class Initialized
DEBUG - 2021-12-07 08:03:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:03:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:03:37 --> Final output sent to browser
DEBUG - 2021-12-07 08:03:37 --> Total execution time: 0.7460
INFO - 2021-12-07 08:03:39 --> Config Class Initialized
INFO - 2021-12-07 08:03:39 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:03:39 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:03:39 --> Utf8 Class Initialized
INFO - 2021-12-07 08:03:39 --> URI Class Initialized
INFO - 2021-12-07 08:03:39 --> Router Class Initialized
INFO - 2021-12-07 08:03:39 --> Output Class Initialized
INFO - 2021-12-07 08:03:39 --> Security Class Initialized
DEBUG - 2021-12-07 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:03:39 --> Input Class Initialized
INFO - 2021-12-07 08:03:39 --> Language Class Initialized
INFO - 2021-12-07 08:03:39 --> Language Class Initialized
INFO - 2021-12-07 08:03:39 --> Config Class Initialized
INFO - 2021-12-07 08:03:39 --> Loader Class Initialized
INFO - 2021-12-07 08:03:39 --> Helper loaded: url_helper
INFO - 2021-12-07 08:03:39 --> Helper loaded: file_helper
INFO - 2021-12-07 08:03:39 --> Helper loaded: form_helper
INFO - 2021-12-07 08:03:39 --> Helper loaded: my_helper
INFO - 2021-12-07 08:03:39 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:03:39 --> Controller Class Initialized
DEBUG - 2021-12-07 08:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-07 08:03:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:03:39 --> Final output sent to browser
DEBUG - 2021-12-07 08:03:39 --> Total execution time: 0.0620
INFO - 2021-12-07 08:03:50 --> Config Class Initialized
INFO - 2021-12-07 08:03:50 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:03:50 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:03:50 --> Utf8 Class Initialized
INFO - 2021-12-07 08:03:50 --> URI Class Initialized
INFO - 2021-12-07 08:03:50 --> Router Class Initialized
INFO - 2021-12-07 08:03:50 --> Output Class Initialized
INFO - 2021-12-07 08:03:50 --> Security Class Initialized
DEBUG - 2021-12-07 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:03:50 --> Input Class Initialized
INFO - 2021-12-07 08:03:50 --> Language Class Initialized
INFO - 2021-12-07 08:03:50 --> Language Class Initialized
INFO - 2021-12-07 08:03:50 --> Config Class Initialized
INFO - 2021-12-07 08:03:50 --> Loader Class Initialized
INFO - 2021-12-07 08:03:50 --> Helper loaded: url_helper
INFO - 2021-12-07 08:03:50 --> Helper loaded: file_helper
INFO - 2021-12-07 08:03:50 --> Helper loaded: form_helper
INFO - 2021-12-07 08:03:50 --> Helper loaded: my_helper
INFO - 2021-12-07 08:03:50 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:03:50 --> Controller Class Initialized
DEBUG - 2021-12-07 08:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-12-07 08:03:50 --> Final output sent to browser
DEBUG - 2021-12-07 08:03:50 --> Total execution time: 0.1790
INFO - 2021-12-07 08:04:30 --> Config Class Initialized
INFO - 2021-12-07 08:04:30 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:04:30 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:04:30 --> Utf8 Class Initialized
INFO - 2021-12-07 08:04:30 --> URI Class Initialized
INFO - 2021-12-07 08:04:30 --> Router Class Initialized
INFO - 2021-12-07 08:04:30 --> Output Class Initialized
INFO - 2021-12-07 08:04:30 --> Security Class Initialized
DEBUG - 2021-12-07 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:04:30 --> Input Class Initialized
INFO - 2021-12-07 08:04:30 --> Language Class Initialized
INFO - 2021-12-07 08:04:30 --> Language Class Initialized
INFO - 2021-12-07 08:04:30 --> Config Class Initialized
INFO - 2021-12-07 08:04:30 --> Loader Class Initialized
INFO - 2021-12-07 08:04:30 --> Helper loaded: url_helper
INFO - 2021-12-07 08:04:30 --> Helper loaded: file_helper
INFO - 2021-12-07 08:04:30 --> Helper loaded: form_helper
INFO - 2021-12-07 08:04:30 --> Helper loaded: my_helper
INFO - 2021-12-07 08:04:30 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:04:30 --> Controller Class Initialized
INFO - 2021-12-07 08:04:30 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:04:30 --> Config Class Initialized
INFO - 2021-12-07 08:04:30 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:04:30 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:04:30 --> Utf8 Class Initialized
INFO - 2021-12-07 08:04:30 --> URI Class Initialized
INFO - 2021-12-07 08:04:30 --> Router Class Initialized
INFO - 2021-12-07 08:04:30 --> Output Class Initialized
INFO - 2021-12-07 08:04:30 --> Security Class Initialized
DEBUG - 2021-12-07 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:04:30 --> Input Class Initialized
INFO - 2021-12-07 08:04:30 --> Language Class Initialized
INFO - 2021-12-07 08:04:30 --> Language Class Initialized
INFO - 2021-12-07 08:04:30 --> Config Class Initialized
INFO - 2021-12-07 08:04:30 --> Loader Class Initialized
INFO - 2021-12-07 08:04:30 --> Helper loaded: url_helper
INFO - 2021-12-07 08:04:30 --> Helper loaded: file_helper
INFO - 2021-12-07 08:04:30 --> Helper loaded: form_helper
INFO - 2021-12-07 08:04:30 --> Helper loaded: my_helper
INFO - 2021-12-07 08:04:30 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:04:30 --> Controller Class Initialized
DEBUG - 2021-12-07 08:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:04:30 --> Final output sent to browser
DEBUG - 2021-12-07 08:04:30 --> Total execution time: 0.0410
INFO - 2021-12-07 08:04:37 --> Config Class Initialized
INFO - 2021-12-07 08:04:37 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:04:37 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:04:37 --> Utf8 Class Initialized
INFO - 2021-12-07 08:04:37 --> URI Class Initialized
INFO - 2021-12-07 08:04:37 --> Router Class Initialized
INFO - 2021-12-07 08:04:37 --> Output Class Initialized
INFO - 2021-12-07 08:04:37 --> Security Class Initialized
DEBUG - 2021-12-07 08:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:04:37 --> Input Class Initialized
INFO - 2021-12-07 08:04:37 --> Language Class Initialized
INFO - 2021-12-07 08:04:37 --> Language Class Initialized
INFO - 2021-12-07 08:04:37 --> Config Class Initialized
INFO - 2021-12-07 08:04:37 --> Loader Class Initialized
INFO - 2021-12-07 08:04:37 --> Helper loaded: url_helper
INFO - 2021-12-07 08:04:37 --> Helper loaded: file_helper
INFO - 2021-12-07 08:04:37 --> Helper loaded: form_helper
INFO - 2021-12-07 08:04:37 --> Helper loaded: my_helper
INFO - 2021-12-07 08:04:37 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:04:37 --> Controller Class Initialized
INFO - 2021-12-07 08:04:37 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:04:37 --> Final output sent to browser
DEBUG - 2021-12-07 08:04:37 --> Total execution time: 0.0360
INFO - 2021-12-07 08:04:37 --> Config Class Initialized
INFO - 2021-12-07 08:04:37 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:04:37 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:04:37 --> Utf8 Class Initialized
INFO - 2021-12-07 08:04:37 --> URI Class Initialized
INFO - 2021-12-07 08:04:37 --> Router Class Initialized
INFO - 2021-12-07 08:04:37 --> Output Class Initialized
INFO - 2021-12-07 08:04:37 --> Security Class Initialized
DEBUG - 2021-12-07 08:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:04:37 --> Input Class Initialized
INFO - 2021-12-07 08:04:37 --> Language Class Initialized
INFO - 2021-12-07 08:04:37 --> Language Class Initialized
INFO - 2021-12-07 08:04:37 --> Config Class Initialized
INFO - 2021-12-07 08:04:37 --> Loader Class Initialized
INFO - 2021-12-07 08:04:37 --> Helper loaded: url_helper
INFO - 2021-12-07 08:04:37 --> Helper loaded: file_helper
INFO - 2021-12-07 08:04:37 --> Helper loaded: form_helper
INFO - 2021-12-07 08:04:37 --> Helper loaded: my_helper
INFO - 2021-12-07 08:04:37 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:04:37 --> Controller Class Initialized
DEBUG - 2021-12-07 08:04:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:04:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:04:38 --> Final output sent to browser
DEBUG - 2021-12-07 08:04:38 --> Total execution time: 0.7520
INFO - 2021-12-07 08:04:39 --> Config Class Initialized
INFO - 2021-12-07 08:04:39 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:04:39 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:04:39 --> Utf8 Class Initialized
INFO - 2021-12-07 08:04:39 --> URI Class Initialized
INFO - 2021-12-07 08:04:39 --> Router Class Initialized
INFO - 2021-12-07 08:04:39 --> Output Class Initialized
INFO - 2021-12-07 08:04:39 --> Security Class Initialized
DEBUG - 2021-12-07 08:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:04:39 --> Input Class Initialized
INFO - 2021-12-07 08:04:39 --> Language Class Initialized
INFO - 2021-12-07 08:04:39 --> Language Class Initialized
INFO - 2021-12-07 08:04:39 --> Config Class Initialized
INFO - 2021-12-07 08:04:39 --> Loader Class Initialized
INFO - 2021-12-07 08:04:39 --> Helper loaded: url_helper
INFO - 2021-12-07 08:04:39 --> Helper loaded: file_helper
INFO - 2021-12-07 08:04:39 --> Helper loaded: form_helper
INFO - 2021-12-07 08:04:39 --> Helper loaded: my_helper
INFO - 2021-12-07 08:04:39 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:04:39 --> Controller Class Initialized
DEBUG - 2021-12-07 08:04:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-07 08:04:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:04:39 --> Final output sent to browser
DEBUG - 2021-12-07 08:04:39 --> Total execution time: 0.0620
INFO - 2021-12-07 08:04:49 --> Config Class Initialized
INFO - 2021-12-07 08:04:49 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:04:49 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:04:49 --> Utf8 Class Initialized
INFO - 2021-12-07 08:04:49 --> URI Class Initialized
INFO - 2021-12-07 08:04:49 --> Router Class Initialized
INFO - 2021-12-07 08:04:50 --> Output Class Initialized
INFO - 2021-12-07 08:04:50 --> Security Class Initialized
DEBUG - 2021-12-07 08:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:04:50 --> Input Class Initialized
INFO - 2021-12-07 08:04:50 --> Language Class Initialized
INFO - 2021-12-07 08:04:50 --> Language Class Initialized
INFO - 2021-12-07 08:04:50 --> Config Class Initialized
INFO - 2021-12-07 08:04:50 --> Loader Class Initialized
INFO - 2021-12-07 08:04:50 --> Helper loaded: url_helper
INFO - 2021-12-07 08:04:50 --> Helper loaded: file_helper
INFO - 2021-12-07 08:04:50 --> Helper loaded: form_helper
INFO - 2021-12-07 08:04:50 --> Helper loaded: my_helper
INFO - 2021-12-07 08:04:50 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:04:50 --> Controller Class Initialized
DEBUG - 2021-12-07 08:04:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-12-07 08:04:50 --> Final output sent to browser
DEBUG - 2021-12-07 08:04:50 --> Total execution time: 0.1860
INFO - 2021-12-07 08:07:03 --> Config Class Initialized
INFO - 2021-12-07 08:07:03 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:07:03 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:07:03 --> Utf8 Class Initialized
INFO - 2021-12-07 08:07:03 --> URI Class Initialized
INFO - 2021-12-07 08:07:03 --> Router Class Initialized
INFO - 2021-12-07 08:07:03 --> Output Class Initialized
INFO - 2021-12-07 08:07:03 --> Security Class Initialized
DEBUG - 2021-12-07 08:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:07:03 --> Input Class Initialized
INFO - 2021-12-07 08:07:03 --> Language Class Initialized
INFO - 2021-12-07 08:07:03 --> Language Class Initialized
INFO - 2021-12-07 08:07:03 --> Config Class Initialized
INFO - 2021-12-07 08:07:03 --> Loader Class Initialized
INFO - 2021-12-07 08:07:03 --> Helper loaded: url_helper
INFO - 2021-12-07 08:07:03 --> Helper loaded: file_helper
INFO - 2021-12-07 08:07:03 --> Helper loaded: form_helper
INFO - 2021-12-07 08:07:03 --> Helper loaded: my_helper
INFO - 2021-12-07 08:07:03 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:07:03 --> Controller Class Initialized
DEBUG - 2021-12-07 08:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-12-07 08:07:04 --> Final output sent to browser
DEBUG - 2021-12-07 08:07:04 --> Total execution time: 0.1470
INFO - 2021-12-07 08:07:28 --> Config Class Initialized
INFO - 2021-12-07 08:07:28 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:07:28 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:07:28 --> Utf8 Class Initialized
INFO - 2021-12-07 08:07:28 --> URI Class Initialized
INFO - 2021-12-07 08:07:28 --> Router Class Initialized
INFO - 2021-12-07 08:07:28 --> Output Class Initialized
INFO - 2021-12-07 08:07:28 --> Security Class Initialized
DEBUG - 2021-12-07 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:07:28 --> Input Class Initialized
INFO - 2021-12-07 08:07:28 --> Language Class Initialized
INFO - 2021-12-07 08:07:28 --> Language Class Initialized
INFO - 2021-12-07 08:07:28 --> Config Class Initialized
INFO - 2021-12-07 08:07:28 --> Loader Class Initialized
INFO - 2021-12-07 08:07:28 --> Helper loaded: url_helper
INFO - 2021-12-07 08:07:28 --> Helper loaded: file_helper
INFO - 2021-12-07 08:07:28 --> Helper loaded: form_helper
INFO - 2021-12-07 08:07:28 --> Helper loaded: my_helper
INFO - 2021-12-07 08:07:28 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:07:28 --> Controller Class Initialized
INFO - 2021-12-07 08:07:28 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:07:28 --> Config Class Initialized
INFO - 2021-12-07 08:07:28 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:07:28 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:07:28 --> Utf8 Class Initialized
INFO - 2021-12-07 08:07:28 --> URI Class Initialized
INFO - 2021-12-07 08:07:28 --> Router Class Initialized
INFO - 2021-12-07 08:07:28 --> Output Class Initialized
INFO - 2021-12-07 08:07:28 --> Security Class Initialized
DEBUG - 2021-12-07 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:07:28 --> Input Class Initialized
INFO - 2021-12-07 08:07:28 --> Language Class Initialized
INFO - 2021-12-07 08:07:28 --> Language Class Initialized
INFO - 2021-12-07 08:07:28 --> Config Class Initialized
INFO - 2021-12-07 08:07:28 --> Loader Class Initialized
INFO - 2021-12-07 08:07:28 --> Helper loaded: url_helper
INFO - 2021-12-07 08:07:28 --> Helper loaded: file_helper
INFO - 2021-12-07 08:07:28 --> Helper loaded: form_helper
INFO - 2021-12-07 08:07:28 --> Helper loaded: my_helper
INFO - 2021-12-07 08:07:28 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:07:28 --> Controller Class Initialized
DEBUG - 2021-12-07 08:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:07:28 --> Final output sent to browser
DEBUG - 2021-12-07 08:07:28 --> Total execution time: 0.0350
INFO - 2021-12-07 08:07:32 --> Config Class Initialized
INFO - 2021-12-07 08:07:32 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:07:32 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:07:32 --> Utf8 Class Initialized
INFO - 2021-12-07 08:07:32 --> URI Class Initialized
INFO - 2021-12-07 08:07:32 --> Router Class Initialized
INFO - 2021-12-07 08:07:32 --> Output Class Initialized
INFO - 2021-12-07 08:07:32 --> Security Class Initialized
DEBUG - 2021-12-07 08:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:07:32 --> Input Class Initialized
INFO - 2021-12-07 08:07:32 --> Language Class Initialized
INFO - 2021-12-07 08:07:32 --> Language Class Initialized
INFO - 2021-12-07 08:07:32 --> Config Class Initialized
INFO - 2021-12-07 08:07:32 --> Loader Class Initialized
INFO - 2021-12-07 08:07:32 --> Helper loaded: url_helper
INFO - 2021-12-07 08:07:32 --> Helper loaded: file_helper
INFO - 2021-12-07 08:07:32 --> Helper loaded: form_helper
INFO - 2021-12-07 08:07:32 --> Helper loaded: my_helper
INFO - 2021-12-07 08:07:32 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:07:32 --> Controller Class Initialized
INFO - 2021-12-07 08:07:32 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:07:32 --> Final output sent to browser
DEBUG - 2021-12-07 08:07:32 --> Total execution time: 0.0590
INFO - 2021-12-07 08:07:33 --> Config Class Initialized
INFO - 2021-12-07 08:07:33 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:07:33 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:07:33 --> Utf8 Class Initialized
INFO - 2021-12-07 08:07:33 --> URI Class Initialized
INFO - 2021-12-07 08:07:33 --> Router Class Initialized
INFO - 2021-12-07 08:07:33 --> Output Class Initialized
INFO - 2021-12-07 08:07:33 --> Security Class Initialized
DEBUG - 2021-12-07 08:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:07:33 --> Input Class Initialized
INFO - 2021-12-07 08:07:33 --> Language Class Initialized
INFO - 2021-12-07 08:07:33 --> Language Class Initialized
INFO - 2021-12-07 08:07:33 --> Config Class Initialized
INFO - 2021-12-07 08:07:33 --> Loader Class Initialized
INFO - 2021-12-07 08:07:33 --> Helper loaded: url_helper
INFO - 2021-12-07 08:07:33 --> Helper loaded: file_helper
INFO - 2021-12-07 08:07:33 --> Helper loaded: form_helper
INFO - 2021-12-07 08:07:33 --> Helper loaded: my_helper
INFO - 2021-12-07 08:07:33 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:07:33 --> Controller Class Initialized
DEBUG - 2021-12-07 08:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:07:33 --> Final output sent to browser
DEBUG - 2021-12-07 08:07:33 --> Total execution time: 0.7570
INFO - 2021-12-07 08:07:35 --> Config Class Initialized
INFO - 2021-12-07 08:07:35 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:07:35 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:07:35 --> Utf8 Class Initialized
INFO - 2021-12-07 08:07:35 --> URI Class Initialized
INFO - 2021-12-07 08:07:35 --> Router Class Initialized
INFO - 2021-12-07 08:07:35 --> Output Class Initialized
INFO - 2021-12-07 08:07:35 --> Security Class Initialized
DEBUG - 2021-12-07 08:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:07:35 --> Input Class Initialized
INFO - 2021-12-07 08:07:35 --> Language Class Initialized
INFO - 2021-12-07 08:07:35 --> Language Class Initialized
INFO - 2021-12-07 08:07:35 --> Config Class Initialized
INFO - 2021-12-07 08:07:35 --> Loader Class Initialized
INFO - 2021-12-07 08:07:35 --> Helper loaded: url_helper
INFO - 2021-12-07 08:07:35 --> Helper loaded: file_helper
INFO - 2021-12-07 08:07:35 --> Helper loaded: form_helper
INFO - 2021-12-07 08:07:35 --> Helper loaded: my_helper
INFO - 2021-12-07 08:07:35 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:07:35 --> Controller Class Initialized
DEBUG - 2021-12-07 08:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-07 08:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:07:35 --> Final output sent to browser
DEBUG - 2021-12-07 08:07:35 --> Total execution time: 0.0640
INFO - 2021-12-07 08:07:41 --> Config Class Initialized
INFO - 2021-12-07 08:07:41 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:07:41 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:07:41 --> Utf8 Class Initialized
INFO - 2021-12-07 08:07:41 --> URI Class Initialized
INFO - 2021-12-07 08:07:41 --> Router Class Initialized
INFO - 2021-12-07 08:07:42 --> Output Class Initialized
INFO - 2021-12-07 08:07:42 --> Security Class Initialized
DEBUG - 2021-12-07 08:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:07:42 --> Input Class Initialized
INFO - 2021-12-07 08:07:42 --> Language Class Initialized
INFO - 2021-12-07 08:07:42 --> Language Class Initialized
INFO - 2021-12-07 08:07:42 --> Config Class Initialized
INFO - 2021-12-07 08:07:42 --> Loader Class Initialized
INFO - 2021-12-07 08:07:42 --> Helper loaded: url_helper
INFO - 2021-12-07 08:07:42 --> Helper loaded: file_helper
INFO - 2021-12-07 08:07:42 --> Helper loaded: form_helper
INFO - 2021-12-07 08:07:42 --> Helper loaded: my_helper
INFO - 2021-12-07 08:07:42 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:07:42 --> Controller Class Initialized
DEBUG - 2021-12-07 08:07:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-07 08:07:42 --> Final output sent to browser
DEBUG - 2021-12-07 08:07:42 --> Total execution time: 0.1710
INFO - 2021-12-07 08:09:44 --> Config Class Initialized
INFO - 2021-12-07 08:09:44 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:09:44 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:09:44 --> Utf8 Class Initialized
INFO - 2021-12-07 08:09:44 --> URI Class Initialized
INFO - 2021-12-07 08:09:44 --> Router Class Initialized
INFO - 2021-12-07 08:09:44 --> Output Class Initialized
INFO - 2021-12-07 08:09:44 --> Security Class Initialized
DEBUG - 2021-12-07 08:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:09:44 --> Input Class Initialized
INFO - 2021-12-07 08:09:44 --> Language Class Initialized
INFO - 2021-12-07 08:09:44 --> Language Class Initialized
INFO - 2021-12-07 08:09:44 --> Config Class Initialized
INFO - 2021-12-07 08:09:44 --> Loader Class Initialized
INFO - 2021-12-07 08:09:44 --> Helper loaded: url_helper
INFO - 2021-12-07 08:09:44 --> Helper loaded: file_helper
INFO - 2021-12-07 08:09:44 --> Helper loaded: form_helper
INFO - 2021-12-07 08:09:44 --> Helper loaded: my_helper
INFO - 2021-12-07 08:09:44 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:09:44 --> Controller Class Initialized
INFO - 2021-12-07 08:09:44 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:09:44 --> Config Class Initialized
INFO - 2021-12-07 08:09:44 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:09:44 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:09:44 --> Utf8 Class Initialized
INFO - 2021-12-07 08:09:44 --> URI Class Initialized
INFO - 2021-12-07 08:09:44 --> Router Class Initialized
INFO - 2021-12-07 08:09:44 --> Output Class Initialized
INFO - 2021-12-07 08:09:44 --> Security Class Initialized
DEBUG - 2021-12-07 08:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:09:44 --> Input Class Initialized
INFO - 2021-12-07 08:09:44 --> Language Class Initialized
INFO - 2021-12-07 08:09:44 --> Language Class Initialized
INFO - 2021-12-07 08:09:44 --> Config Class Initialized
INFO - 2021-12-07 08:09:44 --> Loader Class Initialized
INFO - 2021-12-07 08:09:44 --> Helper loaded: url_helper
INFO - 2021-12-07 08:09:44 --> Helper loaded: file_helper
INFO - 2021-12-07 08:09:44 --> Helper loaded: form_helper
INFO - 2021-12-07 08:09:44 --> Helper loaded: my_helper
INFO - 2021-12-07 08:09:44 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:09:44 --> Controller Class Initialized
DEBUG - 2021-12-07 08:09:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:09:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:09:44 --> Final output sent to browser
DEBUG - 2021-12-07 08:09:44 --> Total execution time: 0.0380
INFO - 2021-12-07 08:09:51 --> Config Class Initialized
INFO - 2021-12-07 08:09:51 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:09:51 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:09:51 --> Utf8 Class Initialized
INFO - 2021-12-07 08:09:51 --> URI Class Initialized
INFO - 2021-12-07 08:09:51 --> Router Class Initialized
INFO - 2021-12-07 08:09:51 --> Output Class Initialized
INFO - 2021-12-07 08:09:51 --> Security Class Initialized
DEBUG - 2021-12-07 08:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:09:51 --> Input Class Initialized
INFO - 2021-12-07 08:09:51 --> Language Class Initialized
INFO - 2021-12-07 08:09:51 --> Language Class Initialized
INFO - 2021-12-07 08:09:51 --> Config Class Initialized
INFO - 2021-12-07 08:09:51 --> Loader Class Initialized
INFO - 2021-12-07 08:09:51 --> Helper loaded: url_helper
INFO - 2021-12-07 08:09:51 --> Helper loaded: file_helper
INFO - 2021-12-07 08:09:51 --> Helper loaded: form_helper
INFO - 2021-12-07 08:09:51 --> Helper loaded: my_helper
INFO - 2021-12-07 08:09:51 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:09:51 --> Controller Class Initialized
INFO - 2021-12-07 08:09:51 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:09:51 --> Final output sent to browser
DEBUG - 2021-12-07 08:09:51 --> Total execution time: 0.0480
INFO - 2021-12-07 08:09:51 --> Config Class Initialized
INFO - 2021-12-07 08:09:51 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:09:51 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:09:51 --> Utf8 Class Initialized
INFO - 2021-12-07 08:09:51 --> URI Class Initialized
INFO - 2021-12-07 08:09:51 --> Router Class Initialized
INFO - 2021-12-07 08:09:51 --> Output Class Initialized
INFO - 2021-12-07 08:09:51 --> Security Class Initialized
DEBUG - 2021-12-07 08:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:09:51 --> Input Class Initialized
INFO - 2021-12-07 08:09:51 --> Language Class Initialized
INFO - 2021-12-07 08:09:51 --> Language Class Initialized
INFO - 2021-12-07 08:09:51 --> Config Class Initialized
INFO - 2021-12-07 08:09:51 --> Loader Class Initialized
INFO - 2021-12-07 08:09:51 --> Helper loaded: url_helper
INFO - 2021-12-07 08:09:51 --> Helper loaded: file_helper
INFO - 2021-12-07 08:09:51 --> Helper loaded: form_helper
INFO - 2021-12-07 08:09:51 --> Helper loaded: my_helper
INFO - 2021-12-07 08:09:51 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:09:51 --> Controller Class Initialized
DEBUG - 2021-12-07 08:09:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:09:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:09:52 --> Final output sent to browser
DEBUG - 2021-12-07 08:09:52 --> Total execution time: 0.7430
INFO - 2021-12-07 08:09:54 --> Config Class Initialized
INFO - 2021-12-07 08:09:54 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:09:54 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:09:54 --> Utf8 Class Initialized
INFO - 2021-12-07 08:09:54 --> URI Class Initialized
INFO - 2021-12-07 08:09:54 --> Router Class Initialized
INFO - 2021-12-07 08:09:54 --> Output Class Initialized
INFO - 2021-12-07 08:09:54 --> Security Class Initialized
DEBUG - 2021-12-07 08:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:09:54 --> Input Class Initialized
INFO - 2021-12-07 08:09:54 --> Language Class Initialized
INFO - 2021-12-07 08:09:54 --> Language Class Initialized
INFO - 2021-12-07 08:09:54 --> Config Class Initialized
INFO - 2021-12-07 08:09:54 --> Loader Class Initialized
INFO - 2021-12-07 08:09:54 --> Helper loaded: url_helper
INFO - 2021-12-07 08:09:54 --> Helper loaded: file_helper
INFO - 2021-12-07 08:09:54 --> Helper loaded: form_helper
INFO - 2021-12-07 08:09:54 --> Helper loaded: my_helper
INFO - 2021-12-07 08:09:54 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:09:54 --> Controller Class Initialized
DEBUG - 2021-12-07 08:09:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-07 08:09:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:09:54 --> Final output sent to browser
DEBUG - 2021-12-07 08:09:54 --> Total execution time: 0.0570
INFO - 2021-12-07 08:09:59 --> Config Class Initialized
INFO - 2021-12-07 08:09:59 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:09:59 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:09:59 --> Utf8 Class Initialized
INFO - 2021-12-07 08:09:59 --> URI Class Initialized
INFO - 2021-12-07 08:09:59 --> Router Class Initialized
INFO - 2021-12-07 08:09:59 --> Output Class Initialized
INFO - 2021-12-07 08:09:59 --> Security Class Initialized
DEBUG - 2021-12-07 08:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:09:59 --> Input Class Initialized
INFO - 2021-12-07 08:09:59 --> Language Class Initialized
INFO - 2021-12-07 08:09:59 --> Language Class Initialized
INFO - 2021-12-07 08:09:59 --> Config Class Initialized
INFO - 2021-12-07 08:09:59 --> Loader Class Initialized
INFO - 2021-12-07 08:09:59 --> Helper loaded: url_helper
INFO - 2021-12-07 08:09:59 --> Helper loaded: file_helper
INFO - 2021-12-07 08:09:59 --> Helper loaded: form_helper
INFO - 2021-12-07 08:09:59 --> Helper loaded: my_helper
INFO - 2021-12-07 08:09:59 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:09:59 --> Controller Class Initialized
DEBUG - 2021-12-07 08:09:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-12-07 08:09:59 --> Final output sent to browser
DEBUG - 2021-12-07 08:09:59 --> Total execution time: 0.1950
INFO - 2021-12-07 08:11:23 --> Config Class Initialized
INFO - 2021-12-07 08:11:23 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:11:23 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:11:23 --> Utf8 Class Initialized
INFO - 2021-12-07 08:11:23 --> URI Class Initialized
INFO - 2021-12-07 08:11:23 --> Router Class Initialized
INFO - 2021-12-07 08:11:23 --> Output Class Initialized
INFO - 2021-12-07 08:11:23 --> Security Class Initialized
DEBUG - 2021-12-07 08:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:11:23 --> Input Class Initialized
INFO - 2021-12-07 08:11:23 --> Language Class Initialized
INFO - 2021-12-07 08:11:23 --> Language Class Initialized
INFO - 2021-12-07 08:11:23 --> Config Class Initialized
INFO - 2021-12-07 08:11:23 --> Loader Class Initialized
INFO - 2021-12-07 08:11:23 --> Helper loaded: url_helper
INFO - 2021-12-07 08:11:23 --> Helper loaded: file_helper
INFO - 2021-12-07 08:11:23 --> Helper loaded: form_helper
INFO - 2021-12-07 08:11:23 --> Helper loaded: my_helper
INFO - 2021-12-07 08:11:23 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:11:23 --> Controller Class Initialized
INFO - 2021-12-07 08:11:23 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:11:23 --> Config Class Initialized
INFO - 2021-12-07 08:11:23 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:11:23 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:11:23 --> Utf8 Class Initialized
INFO - 2021-12-07 08:11:23 --> URI Class Initialized
INFO - 2021-12-07 08:11:23 --> Router Class Initialized
INFO - 2021-12-07 08:11:23 --> Output Class Initialized
INFO - 2021-12-07 08:11:23 --> Security Class Initialized
DEBUG - 2021-12-07 08:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:11:23 --> Input Class Initialized
INFO - 2021-12-07 08:11:23 --> Language Class Initialized
INFO - 2021-12-07 08:11:23 --> Language Class Initialized
INFO - 2021-12-07 08:11:23 --> Config Class Initialized
INFO - 2021-12-07 08:11:23 --> Loader Class Initialized
INFO - 2021-12-07 08:11:23 --> Helper loaded: url_helper
INFO - 2021-12-07 08:11:23 --> Helper loaded: file_helper
INFO - 2021-12-07 08:11:23 --> Helper loaded: form_helper
INFO - 2021-12-07 08:11:23 --> Helper loaded: my_helper
INFO - 2021-12-07 08:11:23 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:11:23 --> Controller Class Initialized
DEBUG - 2021-12-07 08:11:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:11:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:11:23 --> Final output sent to browser
DEBUG - 2021-12-07 08:11:23 --> Total execution time: 0.0380
INFO - 2021-12-07 08:13:56 --> Config Class Initialized
INFO - 2021-12-07 08:13:56 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:13:56 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:13:56 --> Utf8 Class Initialized
INFO - 2021-12-07 08:13:56 --> URI Class Initialized
INFO - 2021-12-07 08:13:56 --> Router Class Initialized
INFO - 2021-12-07 08:13:56 --> Output Class Initialized
INFO - 2021-12-07 08:13:56 --> Security Class Initialized
DEBUG - 2021-12-07 08:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:13:56 --> Input Class Initialized
INFO - 2021-12-07 08:13:56 --> Language Class Initialized
INFO - 2021-12-07 08:13:56 --> Language Class Initialized
INFO - 2021-12-07 08:13:56 --> Config Class Initialized
INFO - 2021-12-07 08:13:56 --> Loader Class Initialized
INFO - 2021-12-07 08:13:56 --> Helper loaded: url_helper
INFO - 2021-12-07 08:13:56 --> Helper loaded: file_helper
INFO - 2021-12-07 08:13:56 --> Helper loaded: form_helper
INFO - 2021-12-07 08:13:56 --> Helper loaded: my_helper
INFO - 2021-12-07 08:13:56 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:13:56 --> Controller Class Initialized
INFO - 2021-12-07 08:13:56 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:13:56 --> Final output sent to browser
DEBUG - 2021-12-07 08:13:56 --> Total execution time: 0.0460
INFO - 2021-12-07 08:13:58 --> Config Class Initialized
INFO - 2021-12-07 08:13:58 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:13:58 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:13:58 --> Utf8 Class Initialized
INFO - 2021-12-07 08:13:58 --> URI Class Initialized
INFO - 2021-12-07 08:13:58 --> Router Class Initialized
INFO - 2021-12-07 08:13:58 --> Output Class Initialized
INFO - 2021-12-07 08:13:58 --> Security Class Initialized
DEBUG - 2021-12-07 08:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:13:58 --> Input Class Initialized
INFO - 2021-12-07 08:13:58 --> Language Class Initialized
INFO - 2021-12-07 08:13:58 --> Language Class Initialized
INFO - 2021-12-07 08:13:58 --> Config Class Initialized
INFO - 2021-12-07 08:13:58 --> Loader Class Initialized
INFO - 2021-12-07 08:13:58 --> Helper loaded: url_helper
INFO - 2021-12-07 08:13:58 --> Helper loaded: file_helper
INFO - 2021-12-07 08:13:58 --> Helper loaded: form_helper
INFO - 2021-12-07 08:13:58 --> Helper loaded: my_helper
INFO - 2021-12-07 08:13:58 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:13:58 --> Controller Class Initialized
DEBUG - 2021-12-07 08:13:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:13:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:13:59 --> Final output sent to browser
DEBUG - 2021-12-07 08:13:59 --> Total execution time: 0.7510
INFO - 2021-12-07 08:14:03 --> Config Class Initialized
INFO - 2021-12-07 08:14:03 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:14:03 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:14:03 --> Utf8 Class Initialized
INFO - 2021-12-07 08:14:03 --> URI Class Initialized
INFO - 2021-12-07 08:14:03 --> Router Class Initialized
INFO - 2021-12-07 08:14:03 --> Output Class Initialized
INFO - 2021-12-07 08:14:03 --> Security Class Initialized
DEBUG - 2021-12-07 08:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:14:03 --> Input Class Initialized
INFO - 2021-12-07 08:14:03 --> Language Class Initialized
INFO - 2021-12-07 08:14:03 --> Language Class Initialized
INFO - 2021-12-07 08:14:03 --> Config Class Initialized
INFO - 2021-12-07 08:14:03 --> Loader Class Initialized
INFO - 2021-12-07 08:14:03 --> Helper loaded: url_helper
INFO - 2021-12-07 08:14:03 --> Helper loaded: file_helper
INFO - 2021-12-07 08:14:03 --> Helper loaded: form_helper
INFO - 2021-12-07 08:14:03 --> Helper loaded: my_helper
INFO - 2021-12-07 08:14:03 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:14:03 --> Controller Class Initialized
DEBUG - 2021-12-07 08:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-07 08:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:14:03 --> Final output sent to browser
DEBUG - 2021-12-07 08:14:03 --> Total execution time: 0.0470
INFO - 2021-12-07 08:14:03 --> Config Class Initialized
INFO - 2021-12-07 08:14:03 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:14:03 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:14:03 --> Utf8 Class Initialized
INFO - 2021-12-07 08:14:03 --> URI Class Initialized
INFO - 2021-12-07 08:14:03 --> Router Class Initialized
INFO - 2021-12-07 08:14:03 --> Output Class Initialized
INFO - 2021-12-07 08:14:03 --> Security Class Initialized
DEBUG - 2021-12-07 08:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:14:03 --> Input Class Initialized
INFO - 2021-12-07 08:14:03 --> Language Class Initialized
INFO - 2021-12-07 08:14:03 --> Language Class Initialized
INFO - 2021-12-07 08:14:03 --> Config Class Initialized
INFO - 2021-12-07 08:14:03 --> Loader Class Initialized
INFO - 2021-12-07 08:14:03 --> Helper loaded: url_helper
INFO - 2021-12-07 08:14:03 --> Helper loaded: file_helper
INFO - 2021-12-07 08:14:03 --> Helper loaded: form_helper
INFO - 2021-12-07 08:14:03 --> Helper loaded: my_helper
INFO - 2021-12-07 08:14:03 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:14:03 --> Controller Class Initialized
INFO - 2021-12-07 08:14:24 --> Config Class Initialized
INFO - 2021-12-07 08:14:24 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:14:24 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:14:24 --> Utf8 Class Initialized
INFO - 2021-12-07 08:14:24 --> URI Class Initialized
INFO - 2021-12-07 08:14:24 --> Router Class Initialized
INFO - 2021-12-07 08:14:24 --> Output Class Initialized
INFO - 2021-12-07 08:14:24 --> Security Class Initialized
DEBUG - 2021-12-07 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:14:24 --> Input Class Initialized
INFO - 2021-12-07 08:14:24 --> Language Class Initialized
INFO - 2021-12-07 08:14:24 --> Language Class Initialized
INFO - 2021-12-07 08:14:24 --> Config Class Initialized
INFO - 2021-12-07 08:14:24 --> Loader Class Initialized
INFO - 2021-12-07 08:14:24 --> Helper loaded: url_helper
INFO - 2021-12-07 08:14:24 --> Helper loaded: file_helper
INFO - 2021-12-07 08:14:24 --> Helper loaded: form_helper
INFO - 2021-12-07 08:14:24 --> Helper loaded: my_helper
INFO - 2021-12-07 08:14:24 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:14:24 --> Controller Class Initialized
INFO - 2021-12-07 08:14:24 --> Final output sent to browser
DEBUG - 2021-12-07 08:14:24 --> Total execution time: 0.0670
INFO - 2021-12-07 08:14:24 --> Config Class Initialized
INFO - 2021-12-07 08:14:24 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:14:24 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:14:24 --> Utf8 Class Initialized
INFO - 2021-12-07 08:14:24 --> URI Class Initialized
INFO - 2021-12-07 08:14:24 --> Router Class Initialized
INFO - 2021-12-07 08:14:24 --> Output Class Initialized
INFO - 2021-12-07 08:14:24 --> Security Class Initialized
DEBUG - 2021-12-07 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:14:24 --> Input Class Initialized
INFO - 2021-12-07 08:14:24 --> Language Class Initialized
INFO - 2021-12-07 08:14:24 --> Language Class Initialized
INFO - 2021-12-07 08:14:24 --> Config Class Initialized
INFO - 2021-12-07 08:14:24 --> Loader Class Initialized
INFO - 2021-12-07 08:14:24 --> Helper loaded: url_helper
INFO - 2021-12-07 08:14:24 --> Helper loaded: file_helper
INFO - 2021-12-07 08:14:24 --> Helper loaded: form_helper
INFO - 2021-12-07 08:14:24 --> Helper loaded: my_helper
INFO - 2021-12-07 08:14:24 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:14:24 --> Controller Class Initialized
INFO - 2021-12-07 08:14:39 --> Config Class Initialized
INFO - 2021-12-07 08:14:39 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:14:39 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:14:39 --> Utf8 Class Initialized
INFO - 2021-12-07 08:14:39 --> URI Class Initialized
INFO - 2021-12-07 08:14:39 --> Router Class Initialized
INFO - 2021-12-07 08:14:39 --> Output Class Initialized
INFO - 2021-12-07 08:14:39 --> Security Class Initialized
DEBUG - 2021-12-07 08:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:14:39 --> Input Class Initialized
INFO - 2021-12-07 08:14:39 --> Language Class Initialized
INFO - 2021-12-07 08:14:39 --> Language Class Initialized
INFO - 2021-12-07 08:14:39 --> Config Class Initialized
INFO - 2021-12-07 08:14:39 --> Loader Class Initialized
INFO - 2021-12-07 08:14:39 --> Helper loaded: url_helper
INFO - 2021-12-07 08:14:39 --> Helper loaded: file_helper
INFO - 2021-12-07 08:14:39 --> Helper loaded: form_helper
INFO - 2021-12-07 08:14:39 --> Helper loaded: my_helper
INFO - 2021-12-07 08:14:39 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:14:39 --> Controller Class Initialized
INFO - 2021-12-07 08:14:39 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:14:39 --> Config Class Initialized
INFO - 2021-12-07 08:14:39 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:14:39 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:14:39 --> Utf8 Class Initialized
INFO - 2021-12-07 08:14:39 --> URI Class Initialized
INFO - 2021-12-07 08:14:39 --> Router Class Initialized
INFO - 2021-12-07 08:14:39 --> Output Class Initialized
INFO - 2021-12-07 08:14:39 --> Security Class Initialized
DEBUG - 2021-12-07 08:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:14:39 --> Input Class Initialized
INFO - 2021-12-07 08:14:39 --> Language Class Initialized
INFO - 2021-12-07 08:14:39 --> Language Class Initialized
INFO - 2021-12-07 08:14:39 --> Config Class Initialized
INFO - 2021-12-07 08:14:39 --> Loader Class Initialized
INFO - 2021-12-07 08:14:39 --> Helper loaded: url_helper
INFO - 2021-12-07 08:14:39 --> Helper loaded: file_helper
INFO - 2021-12-07 08:14:39 --> Helper loaded: form_helper
INFO - 2021-12-07 08:14:39 --> Helper loaded: my_helper
INFO - 2021-12-07 08:14:39 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:14:39 --> Controller Class Initialized
DEBUG - 2021-12-07 08:14:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:14:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:14:39 --> Final output sent to browser
DEBUG - 2021-12-07 08:14:39 --> Total execution time: 0.0400
INFO - 2021-12-07 08:14:49 --> Config Class Initialized
INFO - 2021-12-07 08:14:49 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:14:49 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:14:49 --> Utf8 Class Initialized
INFO - 2021-12-07 08:14:49 --> URI Class Initialized
INFO - 2021-12-07 08:14:49 --> Router Class Initialized
INFO - 2021-12-07 08:14:49 --> Output Class Initialized
INFO - 2021-12-07 08:14:49 --> Security Class Initialized
DEBUG - 2021-12-07 08:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:14:49 --> Input Class Initialized
INFO - 2021-12-07 08:14:49 --> Language Class Initialized
INFO - 2021-12-07 08:14:49 --> Language Class Initialized
INFO - 2021-12-07 08:14:49 --> Config Class Initialized
INFO - 2021-12-07 08:14:49 --> Loader Class Initialized
INFO - 2021-12-07 08:14:49 --> Helper loaded: url_helper
INFO - 2021-12-07 08:14:49 --> Helper loaded: file_helper
INFO - 2021-12-07 08:14:49 --> Helper loaded: form_helper
INFO - 2021-12-07 08:14:49 --> Helper loaded: my_helper
INFO - 2021-12-07 08:14:49 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:14:49 --> Controller Class Initialized
INFO - 2021-12-07 08:14:49 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:14:49 --> Final output sent to browser
DEBUG - 2021-12-07 08:14:49 --> Total execution time: 0.0600
INFO - 2021-12-07 08:14:49 --> Config Class Initialized
INFO - 2021-12-07 08:14:49 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:14:49 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:14:49 --> Utf8 Class Initialized
INFO - 2021-12-07 08:14:49 --> URI Class Initialized
INFO - 2021-12-07 08:14:49 --> Router Class Initialized
INFO - 2021-12-07 08:14:49 --> Output Class Initialized
INFO - 2021-12-07 08:14:49 --> Security Class Initialized
DEBUG - 2021-12-07 08:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:14:49 --> Input Class Initialized
INFO - 2021-12-07 08:14:49 --> Language Class Initialized
INFO - 2021-12-07 08:14:49 --> Language Class Initialized
INFO - 2021-12-07 08:14:49 --> Config Class Initialized
INFO - 2021-12-07 08:14:49 --> Loader Class Initialized
INFO - 2021-12-07 08:14:49 --> Helper loaded: url_helper
INFO - 2021-12-07 08:14:49 --> Helper loaded: file_helper
INFO - 2021-12-07 08:14:50 --> Helper loaded: form_helper
INFO - 2021-12-07 08:14:50 --> Helper loaded: my_helper
INFO - 2021-12-07 08:14:50 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:14:50 --> Controller Class Initialized
DEBUG - 2021-12-07 08:14:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:14:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:14:50 --> Final output sent to browser
DEBUG - 2021-12-07 08:14:50 --> Total execution time: 0.1670
INFO - 2021-12-07 08:15:10 --> Config Class Initialized
INFO - 2021-12-07 08:15:10 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:15:10 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:15:10 --> Utf8 Class Initialized
INFO - 2021-12-07 08:15:10 --> URI Class Initialized
INFO - 2021-12-07 08:15:10 --> Router Class Initialized
INFO - 2021-12-07 08:15:10 --> Output Class Initialized
INFO - 2021-12-07 08:15:10 --> Security Class Initialized
DEBUG - 2021-12-07 08:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:15:10 --> Input Class Initialized
INFO - 2021-12-07 08:15:10 --> Language Class Initialized
INFO - 2021-12-07 08:15:10 --> Language Class Initialized
INFO - 2021-12-07 08:15:10 --> Config Class Initialized
INFO - 2021-12-07 08:15:10 --> Loader Class Initialized
INFO - 2021-12-07 08:15:10 --> Helper loaded: url_helper
INFO - 2021-12-07 08:15:10 --> Helper loaded: file_helper
INFO - 2021-12-07 08:15:10 --> Helper loaded: form_helper
INFO - 2021-12-07 08:15:10 --> Helper loaded: my_helper
INFO - 2021-12-07 08:15:10 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:15:10 --> Controller Class Initialized
DEBUG - 2021-12-07 08:15:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-07 08:15:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:15:10 --> Final output sent to browser
DEBUG - 2021-12-07 08:15:10 --> Total execution time: 0.0690
INFO - 2021-12-07 08:17:09 --> Config Class Initialized
INFO - 2021-12-07 08:17:09 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:17:09 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:17:09 --> Utf8 Class Initialized
INFO - 2021-12-07 08:17:09 --> URI Class Initialized
INFO - 2021-12-07 08:17:09 --> Router Class Initialized
INFO - 2021-12-07 08:17:09 --> Output Class Initialized
INFO - 2021-12-07 08:17:09 --> Security Class Initialized
DEBUG - 2021-12-07 08:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:17:09 --> Input Class Initialized
INFO - 2021-12-07 08:17:09 --> Language Class Initialized
INFO - 2021-12-07 08:17:09 --> Language Class Initialized
INFO - 2021-12-07 08:17:09 --> Config Class Initialized
INFO - 2021-12-07 08:17:09 --> Loader Class Initialized
INFO - 2021-12-07 08:17:09 --> Helper loaded: url_helper
INFO - 2021-12-07 08:17:09 --> Helper loaded: file_helper
INFO - 2021-12-07 08:17:09 --> Helper loaded: form_helper
INFO - 2021-12-07 08:17:09 --> Helper loaded: my_helper
INFO - 2021-12-07 08:17:09 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:17:09 --> Controller Class Initialized
INFO - 2021-12-07 08:17:09 --> Final output sent to browser
DEBUG - 2021-12-07 08:17:09 --> Total execution time: 0.0710
INFO - 2021-12-07 08:17:23 --> Config Class Initialized
INFO - 2021-12-07 08:17:23 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:17:23 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:17:23 --> Utf8 Class Initialized
INFO - 2021-12-07 08:17:23 --> URI Class Initialized
INFO - 2021-12-07 08:17:23 --> Router Class Initialized
INFO - 2021-12-07 08:17:23 --> Output Class Initialized
INFO - 2021-12-07 08:17:23 --> Security Class Initialized
DEBUG - 2021-12-07 08:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:17:23 --> Input Class Initialized
INFO - 2021-12-07 08:17:23 --> Language Class Initialized
INFO - 2021-12-07 08:17:23 --> Language Class Initialized
INFO - 2021-12-07 08:17:23 --> Config Class Initialized
INFO - 2021-12-07 08:17:23 --> Loader Class Initialized
INFO - 2021-12-07 08:17:23 --> Helper loaded: url_helper
INFO - 2021-12-07 08:17:23 --> Helper loaded: file_helper
INFO - 2021-12-07 08:17:23 --> Helper loaded: form_helper
INFO - 2021-12-07 08:17:23 --> Helper loaded: my_helper
INFO - 2021-12-07 08:17:23 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:17:23 --> Controller Class Initialized
DEBUG - 2021-12-07 08:17:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 08:17:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:17:23 --> Final output sent to browser
DEBUG - 2021-12-07 08:17:23 --> Total execution time: 0.0900
INFO - 2021-12-07 08:26:32 --> Config Class Initialized
INFO - 2021-12-07 08:26:32 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:26:32 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:26:32 --> Utf8 Class Initialized
INFO - 2021-12-07 08:26:32 --> URI Class Initialized
INFO - 2021-12-07 08:26:32 --> Router Class Initialized
INFO - 2021-12-07 08:26:32 --> Output Class Initialized
INFO - 2021-12-07 08:26:32 --> Security Class Initialized
DEBUG - 2021-12-07 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:26:32 --> Input Class Initialized
INFO - 2021-12-07 08:26:32 --> Language Class Initialized
INFO - 2021-12-07 08:26:32 --> Language Class Initialized
INFO - 2021-12-07 08:26:32 --> Config Class Initialized
INFO - 2021-12-07 08:26:32 --> Loader Class Initialized
INFO - 2021-12-07 08:26:32 --> Helper loaded: url_helper
INFO - 2021-12-07 08:26:32 --> Helper loaded: file_helper
INFO - 2021-12-07 08:26:32 --> Helper loaded: form_helper
INFO - 2021-12-07 08:26:32 --> Helper loaded: my_helper
INFO - 2021-12-07 08:26:32 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:26:32 --> Controller Class Initialized
INFO - 2021-12-07 08:26:32 --> Final output sent to browser
DEBUG - 2021-12-07 08:26:32 --> Total execution time: 0.0500
INFO - 2021-12-07 08:26:36 --> Config Class Initialized
INFO - 2021-12-07 08:26:36 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:26:36 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:26:36 --> Utf8 Class Initialized
INFO - 2021-12-07 08:26:36 --> URI Class Initialized
INFO - 2021-12-07 08:26:36 --> Router Class Initialized
INFO - 2021-12-07 08:26:36 --> Output Class Initialized
INFO - 2021-12-07 08:26:36 --> Security Class Initialized
DEBUG - 2021-12-07 08:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:26:36 --> Input Class Initialized
INFO - 2021-12-07 08:26:36 --> Language Class Initialized
INFO - 2021-12-07 08:26:36 --> Language Class Initialized
INFO - 2021-12-07 08:26:36 --> Config Class Initialized
INFO - 2021-12-07 08:26:36 --> Loader Class Initialized
INFO - 2021-12-07 08:26:36 --> Helper loaded: url_helper
INFO - 2021-12-07 08:26:36 --> Helper loaded: file_helper
INFO - 2021-12-07 08:26:36 --> Helper loaded: form_helper
INFO - 2021-12-07 08:26:36 --> Helper loaded: my_helper
INFO - 2021-12-07 08:26:36 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:26:36 --> Controller Class Initialized
DEBUG - 2021-12-07 08:26:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 08:26:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:26:36 --> Final output sent to browser
DEBUG - 2021-12-07 08:26:36 --> Total execution time: 0.0700
INFO - 2021-12-07 08:26:48 --> Config Class Initialized
INFO - 2021-12-07 08:26:48 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:26:48 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:26:48 --> Utf8 Class Initialized
INFO - 2021-12-07 08:26:48 --> URI Class Initialized
INFO - 2021-12-07 08:26:48 --> Router Class Initialized
INFO - 2021-12-07 08:26:48 --> Output Class Initialized
INFO - 2021-12-07 08:26:48 --> Security Class Initialized
DEBUG - 2021-12-07 08:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:26:48 --> Input Class Initialized
INFO - 2021-12-07 08:26:48 --> Language Class Initialized
INFO - 2021-12-07 08:26:49 --> Language Class Initialized
INFO - 2021-12-07 08:26:49 --> Config Class Initialized
INFO - 2021-12-07 08:26:49 --> Loader Class Initialized
INFO - 2021-12-07 08:26:49 --> Helper loaded: url_helper
INFO - 2021-12-07 08:26:49 --> Helper loaded: file_helper
INFO - 2021-12-07 08:26:49 --> Helper loaded: form_helper
INFO - 2021-12-07 08:26:49 --> Helper loaded: my_helper
INFO - 2021-12-07 08:26:49 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:26:49 --> Controller Class Initialized
INFO - 2021-12-07 08:26:49 --> Final output sent to browser
DEBUG - 2021-12-07 08:26:49 --> Total execution time: 0.1020
INFO - 2021-12-07 08:26:52 --> Config Class Initialized
INFO - 2021-12-07 08:26:52 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:26:52 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:26:52 --> Utf8 Class Initialized
INFO - 2021-12-07 08:26:52 --> URI Class Initialized
INFO - 2021-12-07 08:26:52 --> Router Class Initialized
INFO - 2021-12-07 08:26:52 --> Output Class Initialized
INFO - 2021-12-07 08:26:52 --> Security Class Initialized
DEBUG - 2021-12-07 08:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:26:52 --> Input Class Initialized
INFO - 2021-12-07 08:26:52 --> Language Class Initialized
INFO - 2021-12-07 08:26:52 --> Language Class Initialized
INFO - 2021-12-07 08:26:52 --> Config Class Initialized
INFO - 2021-12-07 08:26:52 --> Loader Class Initialized
INFO - 2021-12-07 08:26:52 --> Helper loaded: url_helper
INFO - 2021-12-07 08:26:52 --> Helper loaded: file_helper
INFO - 2021-12-07 08:26:52 --> Helper loaded: form_helper
INFO - 2021-12-07 08:26:52 --> Helper loaded: my_helper
INFO - 2021-12-07 08:26:52 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:26:52 --> Controller Class Initialized
DEBUG - 2021-12-07 08:26:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 08:26:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:26:52 --> Final output sent to browser
DEBUG - 2021-12-07 08:26:52 --> Total execution time: 0.0820
INFO - 2021-12-07 08:26:54 --> Config Class Initialized
INFO - 2021-12-07 08:26:54 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:26:54 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:26:54 --> Utf8 Class Initialized
INFO - 2021-12-07 08:26:54 --> URI Class Initialized
INFO - 2021-12-07 08:26:54 --> Router Class Initialized
INFO - 2021-12-07 08:26:54 --> Output Class Initialized
INFO - 2021-12-07 08:26:54 --> Security Class Initialized
DEBUG - 2021-12-07 08:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:26:54 --> Input Class Initialized
INFO - 2021-12-07 08:26:54 --> Language Class Initialized
INFO - 2021-12-07 08:26:54 --> Language Class Initialized
INFO - 2021-12-07 08:26:54 --> Config Class Initialized
INFO - 2021-12-07 08:26:54 --> Loader Class Initialized
INFO - 2021-12-07 08:26:54 --> Helper loaded: url_helper
INFO - 2021-12-07 08:26:54 --> Helper loaded: file_helper
INFO - 2021-12-07 08:26:54 --> Helper loaded: form_helper
INFO - 2021-12-07 08:26:54 --> Helper loaded: my_helper
INFO - 2021-12-07 08:26:54 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:26:54 --> Controller Class Initialized
INFO - 2021-12-07 08:26:54 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:26:54 --> Config Class Initialized
INFO - 2021-12-07 08:26:54 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:26:54 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:26:54 --> Utf8 Class Initialized
INFO - 2021-12-07 08:26:54 --> URI Class Initialized
INFO - 2021-12-07 08:26:54 --> Router Class Initialized
INFO - 2021-12-07 08:26:54 --> Output Class Initialized
INFO - 2021-12-07 08:26:54 --> Security Class Initialized
DEBUG - 2021-12-07 08:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:26:54 --> Input Class Initialized
INFO - 2021-12-07 08:26:54 --> Language Class Initialized
INFO - 2021-12-07 08:26:54 --> Language Class Initialized
INFO - 2021-12-07 08:26:54 --> Config Class Initialized
INFO - 2021-12-07 08:26:54 --> Loader Class Initialized
INFO - 2021-12-07 08:26:54 --> Helper loaded: url_helper
INFO - 2021-12-07 08:26:54 --> Helper loaded: file_helper
INFO - 2021-12-07 08:26:54 --> Helper loaded: form_helper
INFO - 2021-12-07 08:26:54 --> Helper loaded: my_helper
INFO - 2021-12-07 08:26:54 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:26:54 --> Controller Class Initialized
DEBUG - 2021-12-07 08:26:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:26:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:26:54 --> Final output sent to browser
DEBUG - 2021-12-07 08:26:54 --> Total execution time: 0.0360
INFO - 2021-12-07 08:27:01 --> Config Class Initialized
INFO - 2021-12-07 08:27:01 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:27:01 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:27:01 --> Utf8 Class Initialized
INFO - 2021-12-07 08:27:01 --> URI Class Initialized
INFO - 2021-12-07 08:27:01 --> Router Class Initialized
INFO - 2021-12-07 08:27:01 --> Output Class Initialized
INFO - 2021-12-07 08:27:01 --> Security Class Initialized
DEBUG - 2021-12-07 08:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:27:01 --> Input Class Initialized
INFO - 2021-12-07 08:27:01 --> Language Class Initialized
INFO - 2021-12-07 08:27:01 --> Language Class Initialized
INFO - 2021-12-07 08:27:01 --> Config Class Initialized
INFO - 2021-12-07 08:27:01 --> Loader Class Initialized
INFO - 2021-12-07 08:27:01 --> Helper loaded: url_helper
INFO - 2021-12-07 08:27:01 --> Helper loaded: file_helper
INFO - 2021-12-07 08:27:01 --> Helper loaded: form_helper
INFO - 2021-12-07 08:27:01 --> Helper loaded: my_helper
INFO - 2021-12-07 08:27:01 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:27:01 --> Controller Class Initialized
INFO - 2021-12-07 08:27:01 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:27:01 --> Final output sent to browser
DEBUG - 2021-12-07 08:27:01 --> Total execution time: 0.0500
INFO - 2021-12-07 08:27:02 --> Config Class Initialized
INFO - 2021-12-07 08:27:02 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:27:02 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:27:02 --> Utf8 Class Initialized
INFO - 2021-12-07 08:27:02 --> URI Class Initialized
INFO - 2021-12-07 08:27:02 --> Router Class Initialized
INFO - 2021-12-07 08:27:02 --> Output Class Initialized
INFO - 2021-12-07 08:27:02 --> Security Class Initialized
DEBUG - 2021-12-07 08:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:27:02 --> Input Class Initialized
INFO - 2021-12-07 08:27:02 --> Language Class Initialized
INFO - 2021-12-07 08:27:02 --> Language Class Initialized
INFO - 2021-12-07 08:27:02 --> Config Class Initialized
INFO - 2021-12-07 08:27:02 --> Loader Class Initialized
INFO - 2021-12-07 08:27:02 --> Helper loaded: url_helper
INFO - 2021-12-07 08:27:02 --> Helper loaded: file_helper
INFO - 2021-12-07 08:27:02 --> Helper loaded: form_helper
INFO - 2021-12-07 08:27:02 --> Helper loaded: my_helper
INFO - 2021-12-07 08:27:02 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:27:02 --> Controller Class Initialized
DEBUG - 2021-12-07 08:27:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:27:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:27:02 --> Final output sent to browser
DEBUG - 2021-12-07 08:27:02 --> Total execution time: 0.2240
INFO - 2021-12-07 08:27:04 --> Config Class Initialized
INFO - 2021-12-07 08:27:04 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:27:04 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:27:04 --> Utf8 Class Initialized
INFO - 2021-12-07 08:27:04 --> URI Class Initialized
INFO - 2021-12-07 08:27:04 --> Router Class Initialized
INFO - 2021-12-07 08:27:04 --> Output Class Initialized
INFO - 2021-12-07 08:27:04 --> Security Class Initialized
DEBUG - 2021-12-07 08:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:27:04 --> Input Class Initialized
INFO - 2021-12-07 08:27:04 --> Language Class Initialized
INFO - 2021-12-07 08:27:04 --> Language Class Initialized
INFO - 2021-12-07 08:27:04 --> Config Class Initialized
INFO - 2021-12-07 08:27:04 --> Loader Class Initialized
INFO - 2021-12-07 08:27:04 --> Helper loaded: url_helper
INFO - 2021-12-07 08:27:04 --> Helper loaded: file_helper
INFO - 2021-12-07 08:27:04 --> Helper loaded: form_helper
INFO - 2021-12-07 08:27:04 --> Helper loaded: my_helper
INFO - 2021-12-07 08:27:04 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:27:04 --> Controller Class Initialized
DEBUG - 2021-12-07 08:27:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 08:27:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:27:04 --> Final output sent to browser
DEBUG - 2021-12-07 08:27:04 --> Total execution time: 0.0930
INFO - 2021-12-07 08:27:12 --> Config Class Initialized
INFO - 2021-12-07 08:27:12 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:27:12 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:27:12 --> Utf8 Class Initialized
INFO - 2021-12-07 08:27:12 --> URI Class Initialized
INFO - 2021-12-07 08:27:12 --> Router Class Initialized
INFO - 2021-12-07 08:27:12 --> Output Class Initialized
INFO - 2021-12-07 08:27:12 --> Security Class Initialized
DEBUG - 2021-12-07 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:27:12 --> Input Class Initialized
INFO - 2021-12-07 08:27:12 --> Language Class Initialized
INFO - 2021-12-07 08:27:12 --> Language Class Initialized
INFO - 2021-12-07 08:27:12 --> Config Class Initialized
INFO - 2021-12-07 08:27:12 --> Loader Class Initialized
INFO - 2021-12-07 08:27:12 --> Helper loaded: url_helper
INFO - 2021-12-07 08:27:12 --> Helper loaded: file_helper
INFO - 2021-12-07 08:27:12 --> Helper loaded: form_helper
INFO - 2021-12-07 08:27:12 --> Helper loaded: my_helper
INFO - 2021-12-07 08:27:12 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:27:12 --> Controller Class Initialized
DEBUG - 2021-12-07 08:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-07 08:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:27:12 --> Final output sent to browser
DEBUG - 2021-12-07 08:27:12 --> Total execution time: 0.0630
INFO - 2021-12-07 08:29:08 --> Config Class Initialized
INFO - 2021-12-07 08:29:08 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:08 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:08 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:08 --> URI Class Initialized
INFO - 2021-12-07 08:29:08 --> Router Class Initialized
INFO - 2021-12-07 08:29:08 --> Output Class Initialized
INFO - 2021-12-07 08:29:08 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:08 --> Input Class Initialized
INFO - 2021-12-07 08:29:08 --> Language Class Initialized
INFO - 2021-12-07 08:29:08 --> Language Class Initialized
INFO - 2021-12-07 08:29:08 --> Config Class Initialized
INFO - 2021-12-07 08:29:08 --> Loader Class Initialized
INFO - 2021-12-07 08:29:08 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:08 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:08 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:08 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:08 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:08 --> Controller Class Initialized
DEBUG - 2021-12-07 08:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 08:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:29:08 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:08 --> Total execution time: 0.0700
INFO - 2021-12-07 08:29:14 --> Config Class Initialized
INFO - 2021-12-07 08:29:14 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:14 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:14 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:14 --> URI Class Initialized
INFO - 2021-12-07 08:29:14 --> Router Class Initialized
INFO - 2021-12-07 08:29:14 --> Output Class Initialized
INFO - 2021-12-07 08:29:14 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:14 --> Input Class Initialized
INFO - 2021-12-07 08:29:14 --> Language Class Initialized
INFO - 2021-12-07 08:29:14 --> Language Class Initialized
INFO - 2021-12-07 08:29:14 --> Config Class Initialized
INFO - 2021-12-07 08:29:14 --> Loader Class Initialized
INFO - 2021-12-07 08:29:14 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:14 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:14 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:14 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:14 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:14 --> Controller Class Initialized
INFO - 2021-12-07 08:29:14 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:29:14 --> Config Class Initialized
INFO - 2021-12-07 08:29:14 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:14 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:14 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:14 --> URI Class Initialized
INFO - 2021-12-07 08:29:14 --> Router Class Initialized
INFO - 2021-12-07 08:29:14 --> Output Class Initialized
INFO - 2021-12-07 08:29:14 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:14 --> Input Class Initialized
INFO - 2021-12-07 08:29:14 --> Language Class Initialized
INFO - 2021-12-07 08:29:14 --> Language Class Initialized
INFO - 2021-12-07 08:29:14 --> Config Class Initialized
INFO - 2021-12-07 08:29:14 --> Loader Class Initialized
INFO - 2021-12-07 08:29:14 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:14 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:14 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:14 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:14 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:14 --> Controller Class Initialized
DEBUG - 2021-12-07 08:29:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:29:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:29:14 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:14 --> Total execution time: 0.0360
INFO - 2021-12-07 08:29:25 --> Config Class Initialized
INFO - 2021-12-07 08:29:25 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:25 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:25 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:25 --> URI Class Initialized
INFO - 2021-12-07 08:29:25 --> Router Class Initialized
INFO - 2021-12-07 08:29:25 --> Output Class Initialized
INFO - 2021-12-07 08:29:25 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:25 --> Input Class Initialized
INFO - 2021-12-07 08:29:25 --> Language Class Initialized
INFO - 2021-12-07 08:29:25 --> Language Class Initialized
INFO - 2021-12-07 08:29:25 --> Config Class Initialized
INFO - 2021-12-07 08:29:25 --> Loader Class Initialized
INFO - 2021-12-07 08:29:25 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:25 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:25 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:25 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:25 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:25 --> Controller Class Initialized
INFO - 2021-12-07 08:29:25 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:29:25 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:25 --> Total execution time: 0.0570
INFO - 2021-12-07 08:29:25 --> Config Class Initialized
INFO - 2021-12-07 08:29:25 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:25 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:25 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:25 --> URI Class Initialized
INFO - 2021-12-07 08:29:25 --> Router Class Initialized
INFO - 2021-12-07 08:29:25 --> Output Class Initialized
INFO - 2021-12-07 08:29:25 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:25 --> Input Class Initialized
INFO - 2021-12-07 08:29:25 --> Language Class Initialized
INFO - 2021-12-07 08:29:25 --> Language Class Initialized
INFO - 2021-12-07 08:29:25 --> Config Class Initialized
INFO - 2021-12-07 08:29:25 --> Loader Class Initialized
INFO - 2021-12-07 08:29:25 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:25 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:25 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:25 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:25 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:25 --> Controller Class Initialized
DEBUG - 2021-12-07 08:29:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:29:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:29:26 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:26 --> Total execution time: 0.1970
INFO - 2021-12-07 08:29:29 --> Config Class Initialized
INFO - 2021-12-07 08:29:29 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:29 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:29 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:29 --> URI Class Initialized
INFO - 2021-12-07 08:29:29 --> Router Class Initialized
INFO - 2021-12-07 08:29:29 --> Output Class Initialized
INFO - 2021-12-07 08:29:29 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:29 --> Input Class Initialized
INFO - 2021-12-07 08:29:29 --> Language Class Initialized
INFO - 2021-12-07 08:29:29 --> Language Class Initialized
INFO - 2021-12-07 08:29:29 --> Config Class Initialized
INFO - 2021-12-07 08:29:29 --> Loader Class Initialized
INFO - 2021-12-07 08:29:29 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:29 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:29 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:29 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:29 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:29 --> Controller Class Initialized
DEBUG - 2021-12-07 08:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-07 08:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:29:29 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:29 --> Total execution time: 0.0540
INFO - 2021-12-07 08:29:29 --> Config Class Initialized
INFO - 2021-12-07 08:29:29 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:29 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:29 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:29 --> URI Class Initialized
INFO - 2021-12-07 08:29:29 --> Router Class Initialized
INFO - 2021-12-07 08:29:29 --> Output Class Initialized
INFO - 2021-12-07 08:29:29 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:29 --> Input Class Initialized
INFO - 2021-12-07 08:29:29 --> Language Class Initialized
INFO - 2021-12-07 08:29:29 --> Language Class Initialized
INFO - 2021-12-07 08:29:29 --> Config Class Initialized
INFO - 2021-12-07 08:29:29 --> Loader Class Initialized
INFO - 2021-12-07 08:29:29 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:29 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:29 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:29 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:29 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:29 --> Controller Class Initialized
INFO - 2021-12-07 08:29:34 --> Config Class Initialized
INFO - 2021-12-07 08:29:34 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:34 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:34 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:34 --> URI Class Initialized
INFO - 2021-12-07 08:29:34 --> Router Class Initialized
INFO - 2021-12-07 08:29:34 --> Output Class Initialized
INFO - 2021-12-07 08:29:34 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:34 --> Input Class Initialized
INFO - 2021-12-07 08:29:34 --> Language Class Initialized
INFO - 2021-12-07 08:29:34 --> Language Class Initialized
INFO - 2021-12-07 08:29:34 --> Config Class Initialized
INFO - 2021-12-07 08:29:34 --> Loader Class Initialized
INFO - 2021-12-07 08:29:34 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:34 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:34 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:34 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:34 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:34 --> Controller Class Initialized
INFO - 2021-12-07 08:29:34 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:34 --> Total execution time: 0.0650
INFO - 2021-12-07 08:29:34 --> Config Class Initialized
INFO - 2021-12-07 08:29:34 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:34 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:34 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:34 --> URI Class Initialized
INFO - 2021-12-07 08:29:34 --> Router Class Initialized
INFO - 2021-12-07 08:29:34 --> Output Class Initialized
INFO - 2021-12-07 08:29:34 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:34 --> Input Class Initialized
INFO - 2021-12-07 08:29:34 --> Language Class Initialized
INFO - 2021-12-07 08:29:34 --> Language Class Initialized
INFO - 2021-12-07 08:29:34 --> Config Class Initialized
INFO - 2021-12-07 08:29:34 --> Loader Class Initialized
INFO - 2021-12-07 08:29:34 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:34 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:34 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:34 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:34 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:34 --> Controller Class Initialized
INFO - 2021-12-07 08:29:41 --> Config Class Initialized
INFO - 2021-12-07 08:29:41 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:41 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:41 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:41 --> URI Class Initialized
INFO - 2021-12-07 08:29:41 --> Router Class Initialized
INFO - 2021-12-07 08:29:41 --> Output Class Initialized
INFO - 2021-12-07 08:29:41 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:41 --> Input Class Initialized
INFO - 2021-12-07 08:29:41 --> Language Class Initialized
INFO - 2021-12-07 08:29:41 --> Language Class Initialized
INFO - 2021-12-07 08:29:41 --> Config Class Initialized
INFO - 2021-12-07 08:29:41 --> Loader Class Initialized
INFO - 2021-12-07 08:29:41 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:41 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:41 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:41 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:41 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:41 --> Controller Class Initialized
INFO - 2021-12-07 08:29:41 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:29:41 --> Config Class Initialized
INFO - 2021-12-07 08:29:41 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:41 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:41 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:41 --> URI Class Initialized
INFO - 2021-12-07 08:29:41 --> Router Class Initialized
INFO - 2021-12-07 08:29:41 --> Output Class Initialized
INFO - 2021-12-07 08:29:41 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:41 --> Input Class Initialized
INFO - 2021-12-07 08:29:41 --> Language Class Initialized
INFO - 2021-12-07 08:29:41 --> Language Class Initialized
INFO - 2021-12-07 08:29:41 --> Config Class Initialized
INFO - 2021-12-07 08:29:41 --> Loader Class Initialized
INFO - 2021-12-07 08:29:41 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:41 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:41 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:41 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:41 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:41 --> Controller Class Initialized
DEBUG - 2021-12-07 08:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:29:41 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:41 --> Total execution time: 0.0410
INFO - 2021-12-07 08:29:48 --> Config Class Initialized
INFO - 2021-12-07 08:29:48 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:48 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:48 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:48 --> URI Class Initialized
INFO - 2021-12-07 08:29:48 --> Router Class Initialized
INFO - 2021-12-07 08:29:48 --> Output Class Initialized
INFO - 2021-12-07 08:29:48 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:48 --> Input Class Initialized
INFO - 2021-12-07 08:29:48 --> Language Class Initialized
INFO - 2021-12-07 08:29:48 --> Language Class Initialized
INFO - 2021-12-07 08:29:48 --> Config Class Initialized
INFO - 2021-12-07 08:29:48 --> Loader Class Initialized
INFO - 2021-12-07 08:29:48 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:48 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:48 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:48 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:48 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:48 --> Controller Class Initialized
INFO - 2021-12-07 08:29:48 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:29:48 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:48 --> Total execution time: 0.0540
INFO - 2021-12-07 08:29:49 --> Config Class Initialized
INFO - 2021-12-07 08:29:49 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:49 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:49 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:49 --> URI Class Initialized
INFO - 2021-12-07 08:29:49 --> Router Class Initialized
INFO - 2021-12-07 08:29:49 --> Output Class Initialized
INFO - 2021-12-07 08:29:49 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:49 --> Input Class Initialized
INFO - 2021-12-07 08:29:49 --> Language Class Initialized
INFO - 2021-12-07 08:29:49 --> Language Class Initialized
INFO - 2021-12-07 08:29:49 --> Config Class Initialized
INFO - 2021-12-07 08:29:49 --> Loader Class Initialized
INFO - 2021-12-07 08:29:49 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:49 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:49 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:49 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:49 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:49 --> Controller Class Initialized
DEBUG - 2021-12-07 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:29:49 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:49 --> Total execution time: 0.1750
INFO - 2021-12-07 08:29:51 --> Config Class Initialized
INFO - 2021-12-07 08:29:51 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:29:51 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:29:51 --> Utf8 Class Initialized
INFO - 2021-12-07 08:29:51 --> URI Class Initialized
INFO - 2021-12-07 08:29:51 --> Router Class Initialized
INFO - 2021-12-07 08:29:51 --> Output Class Initialized
INFO - 2021-12-07 08:29:51 --> Security Class Initialized
DEBUG - 2021-12-07 08:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:29:51 --> Input Class Initialized
INFO - 2021-12-07 08:29:51 --> Language Class Initialized
INFO - 2021-12-07 08:29:51 --> Language Class Initialized
INFO - 2021-12-07 08:29:51 --> Config Class Initialized
INFO - 2021-12-07 08:29:51 --> Loader Class Initialized
INFO - 2021-12-07 08:29:51 --> Helper loaded: url_helper
INFO - 2021-12-07 08:29:51 --> Helper loaded: file_helper
INFO - 2021-12-07 08:29:51 --> Helper loaded: form_helper
INFO - 2021-12-07 08:29:51 --> Helper loaded: my_helper
INFO - 2021-12-07 08:29:51 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:29:51 --> Controller Class Initialized
DEBUG - 2021-12-07 08:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 08:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:29:51 --> Final output sent to browser
DEBUG - 2021-12-07 08:29:51 --> Total execution time: 0.1190
INFO - 2021-12-07 08:45:00 --> Config Class Initialized
INFO - 2021-12-07 08:45:00 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:45:00 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:45:00 --> Utf8 Class Initialized
INFO - 2021-12-07 08:45:00 --> URI Class Initialized
INFO - 2021-12-07 08:45:00 --> Router Class Initialized
INFO - 2021-12-07 08:45:00 --> Output Class Initialized
INFO - 2021-12-07 08:45:00 --> Security Class Initialized
DEBUG - 2021-12-07 08:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:45:00 --> Input Class Initialized
INFO - 2021-12-07 08:45:00 --> Language Class Initialized
INFO - 2021-12-07 08:45:00 --> Language Class Initialized
INFO - 2021-12-07 08:45:00 --> Config Class Initialized
INFO - 2021-12-07 08:45:00 --> Loader Class Initialized
INFO - 2021-12-07 08:45:00 --> Helper loaded: url_helper
INFO - 2021-12-07 08:45:00 --> Helper loaded: file_helper
INFO - 2021-12-07 08:45:00 --> Helper loaded: form_helper
INFO - 2021-12-07 08:45:00 --> Helper loaded: my_helper
INFO - 2021-12-07 08:45:00 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:45:00 --> Controller Class Initialized
INFO - 2021-12-07 08:45:00 --> Final output sent to browser
DEBUG - 2021-12-07 08:45:00 --> Total execution time: 0.0660
INFO - 2021-12-07 08:45:05 --> Config Class Initialized
INFO - 2021-12-07 08:45:05 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:45:05 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:45:05 --> Utf8 Class Initialized
INFO - 2021-12-07 08:45:05 --> URI Class Initialized
INFO - 2021-12-07 08:45:05 --> Router Class Initialized
INFO - 2021-12-07 08:45:05 --> Output Class Initialized
INFO - 2021-12-07 08:45:05 --> Security Class Initialized
DEBUG - 2021-12-07 08:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:45:05 --> Input Class Initialized
INFO - 2021-12-07 08:45:05 --> Language Class Initialized
INFO - 2021-12-07 08:45:05 --> Language Class Initialized
INFO - 2021-12-07 08:45:05 --> Config Class Initialized
INFO - 2021-12-07 08:45:05 --> Loader Class Initialized
INFO - 2021-12-07 08:45:05 --> Helper loaded: url_helper
INFO - 2021-12-07 08:45:05 --> Helper loaded: file_helper
INFO - 2021-12-07 08:45:05 --> Helper loaded: form_helper
INFO - 2021-12-07 08:45:05 --> Helper loaded: my_helper
INFO - 2021-12-07 08:45:05 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:45:05 --> Controller Class Initialized
INFO - 2021-12-07 08:45:05 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:45:05 --> Config Class Initialized
INFO - 2021-12-07 08:45:05 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:45:05 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:45:05 --> Utf8 Class Initialized
INFO - 2021-12-07 08:45:05 --> URI Class Initialized
INFO - 2021-12-07 08:45:05 --> Router Class Initialized
INFO - 2021-12-07 08:45:05 --> Output Class Initialized
INFO - 2021-12-07 08:45:05 --> Security Class Initialized
DEBUG - 2021-12-07 08:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:45:05 --> Input Class Initialized
INFO - 2021-12-07 08:45:05 --> Language Class Initialized
INFO - 2021-12-07 08:45:05 --> Language Class Initialized
INFO - 2021-12-07 08:45:05 --> Config Class Initialized
INFO - 2021-12-07 08:45:05 --> Loader Class Initialized
INFO - 2021-12-07 08:45:05 --> Helper loaded: url_helper
INFO - 2021-12-07 08:45:05 --> Helper loaded: file_helper
INFO - 2021-12-07 08:45:05 --> Helper loaded: form_helper
INFO - 2021-12-07 08:45:05 --> Helper loaded: my_helper
INFO - 2021-12-07 08:45:05 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:45:05 --> Controller Class Initialized
DEBUG - 2021-12-07 08:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:45:05 --> Final output sent to browser
DEBUG - 2021-12-07 08:45:05 --> Total execution time: 0.0360
INFO - 2021-12-07 08:45:13 --> Config Class Initialized
INFO - 2021-12-07 08:45:13 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:45:13 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:45:13 --> Utf8 Class Initialized
INFO - 2021-12-07 08:45:13 --> URI Class Initialized
INFO - 2021-12-07 08:45:13 --> Router Class Initialized
INFO - 2021-12-07 08:45:13 --> Output Class Initialized
INFO - 2021-12-07 08:45:13 --> Security Class Initialized
DEBUG - 2021-12-07 08:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:45:13 --> Input Class Initialized
INFO - 2021-12-07 08:45:13 --> Language Class Initialized
INFO - 2021-12-07 08:45:13 --> Language Class Initialized
INFO - 2021-12-07 08:45:13 --> Config Class Initialized
INFO - 2021-12-07 08:45:13 --> Loader Class Initialized
INFO - 2021-12-07 08:45:13 --> Helper loaded: url_helper
INFO - 2021-12-07 08:45:13 --> Helper loaded: file_helper
INFO - 2021-12-07 08:45:13 --> Helper loaded: form_helper
INFO - 2021-12-07 08:45:13 --> Helper loaded: my_helper
INFO - 2021-12-07 08:45:13 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:45:13 --> Controller Class Initialized
INFO - 2021-12-07 08:45:13 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:45:13 --> Final output sent to browser
DEBUG - 2021-12-07 08:45:13 --> Total execution time: 0.0670
INFO - 2021-12-07 08:45:14 --> Config Class Initialized
INFO - 2021-12-07 08:45:14 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:45:14 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:45:14 --> Utf8 Class Initialized
INFO - 2021-12-07 08:45:14 --> URI Class Initialized
INFO - 2021-12-07 08:45:14 --> Router Class Initialized
INFO - 2021-12-07 08:45:14 --> Output Class Initialized
INFO - 2021-12-07 08:45:14 --> Security Class Initialized
DEBUG - 2021-12-07 08:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:45:14 --> Input Class Initialized
INFO - 2021-12-07 08:45:14 --> Language Class Initialized
INFO - 2021-12-07 08:45:14 --> Language Class Initialized
INFO - 2021-12-07 08:45:14 --> Config Class Initialized
INFO - 2021-12-07 08:45:14 --> Loader Class Initialized
INFO - 2021-12-07 08:45:14 --> Helper loaded: url_helper
INFO - 2021-12-07 08:45:14 --> Helper loaded: file_helper
INFO - 2021-12-07 08:45:14 --> Helper loaded: form_helper
INFO - 2021-12-07 08:45:14 --> Helper loaded: my_helper
INFO - 2021-12-07 08:45:14 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:45:14 --> Controller Class Initialized
DEBUG - 2021-12-07 08:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:45:14 --> Final output sent to browser
DEBUG - 2021-12-07 08:45:14 --> Total execution time: 0.2020
INFO - 2021-12-07 08:45:17 --> Config Class Initialized
INFO - 2021-12-07 08:45:17 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:45:17 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:45:17 --> Utf8 Class Initialized
INFO - 2021-12-07 08:45:17 --> URI Class Initialized
INFO - 2021-12-07 08:45:17 --> Router Class Initialized
INFO - 2021-12-07 08:45:17 --> Output Class Initialized
INFO - 2021-12-07 08:45:17 --> Security Class Initialized
DEBUG - 2021-12-07 08:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:45:17 --> Input Class Initialized
INFO - 2021-12-07 08:45:17 --> Language Class Initialized
INFO - 2021-12-07 08:45:17 --> Language Class Initialized
INFO - 2021-12-07 08:45:17 --> Config Class Initialized
INFO - 2021-12-07 08:45:17 --> Loader Class Initialized
INFO - 2021-12-07 08:45:17 --> Helper loaded: url_helper
INFO - 2021-12-07 08:45:17 --> Helper loaded: file_helper
INFO - 2021-12-07 08:45:17 --> Helper loaded: form_helper
INFO - 2021-12-07 08:45:17 --> Helper loaded: my_helper
INFO - 2021-12-07 08:45:17 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:45:17 --> Controller Class Initialized
DEBUG - 2021-12-07 08:45:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-07 08:45:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:45:17 --> Final output sent to browser
DEBUG - 2021-12-07 08:45:17 --> Total execution time: 0.0590
INFO - 2021-12-07 08:45:17 --> Config Class Initialized
INFO - 2021-12-07 08:45:17 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:45:17 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:45:17 --> Utf8 Class Initialized
INFO - 2021-12-07 08:45:17 --> URI Class Initialized
INFO - 2021-12-07 08:45:17 --> Router Class Initialized
INFO - 2021-12-07 08:45:17 --> Output Class Initialized
INFO - 2021-12-07 08:45:17 --> Security Class Initialized
DEBUG - 2021-12-07 08:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:45:17 --> Input Class Initialized
INFO - 2021-12-07 08:45:17 --> Language Class Initialized
INFO - 2021-12-07 08:45:17 --> Language Class Initialized
INFO - 2021-12-07 08:45:17 --> Config Class Initialized
INFO - 2021-12-07 08:45:17 --> Loader Class Initialized
INFO - 2021-12-07 08:45:17 --> Helper loaded: url_helper
INFO - 2021-12-07 08:45:17 --> Helper loaded: file_helper
INFO - 2021-12-07 08:45:17 --> Helper loaded: form_helper
INFO - 2021-12-07 08:45:17 --> Helper loaded: my_helper
INFO - 2021-12-07 08:45:17 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:45:17 --> Controller Class Initialized
INFO - 2021-12-07 08:46:07 --> Config Class Initialized
INFO - 2021-12-07 08:46:07 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:46:07 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:46:07 --> Utf8 Class Initialized
INFO - 2021-12-07 08:46:07 --> URI Class Initialized
INFO - 2021-12-07 08:46:07 --> Router Class Initialized
INFO - 2021-12-07 08:46:07 --> Output Class Initialized
INFO - 2021-12-07 08:46:07 --> Security Class Initialized
DEBUG - 2021-12-07 08:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:46:07 --> Input Class Initialized
INFO - 2021-12-07 08:46:07 --> Language Class Initialized
INFO - 2021-12-07 08:46:07 --> Language Class Initialized
INFO - 2021-12-07 08:46:07 --> Config Class Initialized
INFO - 2021-12-07 08:46:07 --> Loader Class Initialized
INFO - 2021-12-07 08:46:07 --> Helper loaded: url_helper
INFO - 2021-12-07 08:46:07 --> Helper loaded: file_helper
INFO - 2021-12-07 08:46:07 --> Helper loaded: form_helper
INFO - 2021-12-07 08:46:07 --> Helper loaded: my_helper
INFO - 2021-12-07 08:46:07 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:46:07 --> Controller Class Initialized
INFO - 2021-12-07 08:46:07 --> Final output sent to browser
DEBUG - 2021-12-07 08:46:07 --> Total execution time: 0.0550
INFO - 2021-12-07 08:46:07 --> Config Class Initialized
INFO - 2021-12-07 08:46:07 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:46:07 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:46:07 --> Utf8 Class Initialized
INFO - 2021-12-07 08:46:07 --> URI Class Initialized
INFO - 2021-12-07 08:46:07 --> Router Class Initialized
INFO - 2021-12-07 08:46:07 --> Output Class Initialized
INFO - 2021-12-07 08:46:07 --> Security Class Initialized
DEBUG - 2021-12-07 08:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:46:07 --> Input Class Initialized
INFO - 2021-12-07 08:46:07 --> Language Class Initialized
INFO - 2021-12-07 08:46:07 --> Language Class Initialized
INFO - 2021-12-07 08:46:07 --> Config Class Initialized
INFO - 2021-12-07 08:46:07 --> Loader Class Initialized
INFO - 2021-12-07 08:46:07 --> Helper loaded: url_helper
INFO - 2021-12-07 08:46:07 --> Helper loaded: file_helper
INFO - 2021-12-07 08:46:07 --> Helper loaded: form_helper
INFO - 2021-12-07 08:46:07 --> Helper loaded: my_helper
INFO - 2021-12-07 08:46:07 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:46:07 --> Controller Class Initialized
INFO - 2021-12-07 08:46:14 --> Config Class Initialized
INFO - 2021-12-07 08:46:14 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:46:14 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:46:14 --> Utf8 Class Initialized
INFO - 2021-12-07 08:46:14 --> URI Class Initialized
INFO - 2021-12-07 08:46:14 --> Router Class Initialized
INFO - 2021-12-07 08:46:14 --> Output Class Initialized
INFO - 2021-12-07 08:46:14 --> Security Class Initialized
DEBUG - 2021-12-07 08:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:46:14 --> Input Class Initialized
INFO - 2021-12-07 08:46:14 --> Language Class Initialized
INFO - 2021-12-07 08:46:14 --> Language Class Initialized
INFO - 2021-12-07 08:46:14 --> Config Class Initialized
INFO - 2021-12-07 08:46:14 --> Loader Class Initialized
INFO - 2021-12-07 08:46:14 --> Helper loaded: url_helper
INFO - 2021-12-07 08:46:14 --> Helper loaded: file_helper
INFO - 2021-12-07 08:46:14 --> Helper loaded: form_helper
INFO - 2021-12-07 08:46:14 --> Helper loaded: my_helper
INFO - 2021-12-07 08:46:14 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:46:14 --> Controller Class Initialized
INFO - 2021-12-07 08:46:14 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:46:14 --> Config Class Initialized
INFO - 2021-12-07 08:46:14 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:46:14 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:46:14 --> Utf8 Class Initialized
INFO - 2021-12-07 08:46:14 --> URI Class Initialized
INFO - 2021-12-07 08:46:14 --> Router Class Initialized
INFO - 2021-12-07 08:46:14 --> Output Class Initialized
INFO - 2021-12-07 08:46:14 --> Security Class Initialized
DEBUG - 2021-12-07 08:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:46:14 --> Input Class Initialized
INFO - 2021-12-07 08:46:14 --> Language Class Initialized
INFO - 2021-12-07 08:46:14 --> Language Class Initialized
INFO - 2021-12-07 08:46:14 --> Config Class Initialized
INFO - 2021-12-07 08:46:14 --> Loader Class Initialized
INFO - 2021-12-07 08:46:14 --> Helper loaded: url_helper
INFO - 2021-12-07 08:46:14 --> Helper loaded: file_helper
INFO - 2021-12-07 08:46:14 --> Helper loaded: form_helper
INFO - 2021-12-07 08:46:14 --> Helper loaded: my_helper
INFO - 2021-12-07 08:46:14 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:46:14 --> Controller Class Initialized
DEBUG - 2021-12-07 08:46:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 08:46:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:46:14 --> Final output sent to browser
DEBUG - 2021-12-07 08:46:14 --> Total execution time: 0.0360
INFO - 2021-12-07 08:46:23 --> Config Class Initialized
INFO - 2021-12-07 08:46:23 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:46:23 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:46:23 --> Utf8 Class Initialized
INFO - 2021-12-07 08:46:23 --> URI Class Initialized
INFO - 2021-12-07 08:46:23 --> Router Class Initialized
INFO - 2021-12-07 08:46:23 --> Output Class Initialized
INFO - 2021-12-07 08:46:23 --> Security Class Initialized
DEBUG - 2021-12-07 08:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:46:23 --> Input Class Initialized
INFO - 2021-12-07 08:46:23 --> Language Class Initialized
INFO - 2021-12-07 08:46:23 --> Language Class Initialized
INFO - 2021-12-07 08:46:23 --> Config Class Initialized
INFO - 2021-12-07 08:46:23 --> Loader Class Initialized
INFO - 2021-12-07 08:46:23 --> Helper loaded: url_helper
INFO - 2021-12-07 08:46:23 --> Helper loaded: file_helper
INFO - 2021-12-07 08:46:23 --> Helper loaded: form_helper
INFO - 2021-12-07 08:46:23 --> Helper loaded: my_helper
INFO - 2021-12-07 08:46:23 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:46:23 --> Controller Class Initialized
INFO - 2021-12-07 08:46:23 --> Helper loaded: cookie_helper
INFO - 2021-12-07 08:46:23 --> Final output sent to browser
DEBUG - 2021-12-07 08:46:23 --> Total execution time: 0.0540
INFO - 2021-12-07 08:46:23 --> Config Class Initialized
INFO - 2021-12-07 08:46:23 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:46:23 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:46:23 --> Utf8 Class Initialized
INFO - 2021-12-07 08:46:23 --> URI Class Initialized
INFO - 2021-12-07 08:46:23 --> Router Class Initialized
INFO - 2021-12-07 08:46:23 --> Output Class Initialized
INFO - 2021-12-07 08:46:23 --> Security Class Initialized
DEBUG - 2021-12-07 08:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:46:23 --> Input Class Initialized
INFO - 2021-12-07 08:46:23 --> Language Class Initialized
INFO - 2021-12-07 08:46:23 --> Language Class Initialized
INFO - 2021-12-07 08:46:23 --> Config Class Initialized
INFO - 2021-12-07 08:46:23 --> Loader Class Initialized
INFO - 2021-12-07 08:46:23 --> Helper loaded: url_helper
INFO - 2021-12-07 08:46:23 --> Helper loaded: file_helper
INFO - 2021-12-07 08:46:23 --> Helper loaded: form_helper
INFO - 2021-12-07 08:46:23 --> Helper loaded: my_helper
INFO - 2021-12-07 08:46:23 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:46:23 --> Controller Class Initialized
DEBUG - 2021-12-07 08:46:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 08:46:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:46:23 --> Final output sent to browser
DEBUG - 2021-12-07 08:46:23 --> Total execution time: 0.1470
INFO - 2021-12-07 08:46:26 --> Config Class Initialized
INFO - 2021-12-07 08:46:26 --> Hooks Class Initialized
DEBUG - 2021-12-07 08:46:26 --> UTF-8 Support Enabled
INFO - 2021-12-07 08:46:26 --> Utf8 Class Initialized
INFO - 2021-12-07 08:46:26 --> URI Class Initialized
INFO - 2021-12-07 08:46:26 --> Router Class Initialized
INFO - 2021-12-07 08:46:26 --> Output Class Initialized
INFO - 2021-12-07 08:46:26 --> Security Class Initialized
DEBUG - 2021-12-07 08:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 08:46:26 --> Input Class Initialized
INFO - 2021-12-07 08:46:26 --> Language Class Initialized
INFO - 2021-12-07 08:46:26 --> Language Class Initialized
INFO - 2021-12-07 08:46:26 --> Config Class Initialized
INFO - 2021-12-07 08:46:26 --> Loader Class Initialized
INFO - 2021-12-07 08:46:26 --> Helper loaded: url_helper
INFO - 2021-12-07 08:46:26 --> Helper loaded: file_helper
INFO - 2021-12-07 08:46:26 --> Helper loaded: form_helper
INFO - 2021-12-07 08:46:26 --> Helper loaded: my_helper
INFO - 2021-12-07 08:46:26 --> Database Driver Class Initialized
DEBUG - 2021-12-07 08:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 08:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 08:46:26 --> Controller Class Initialized
DEBUG - 2021-12-07 08:46:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 08:46:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 08:46:26 --> Final output sent to browser
DEBUG - 2021-12-07 08:46:26 --> Total execution time: 0.1340
INFO - 2021-12-07 09:08:46 --> Config Class Initialized
INFO - 2021-12-07 09:08:46 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:08:46 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:08:46 --> Utf8 Class Initialized
INFO - 2021-12-07 09:08:46 --> URI Class Initialized
INFO - 2021-12-07 09:08:46 --> Router Class Initialized
INFO - 2021-12-07 09:08:46 --> Output Class Initialized
INFO - 2021-12-07 09:08:46 --> Security Class Initialized
DEBUG - 2021-12-07 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:08:46 --> Input Class Initialized
INFO - 2021-12-07 09:08:46 --> Language Class Initialized
INFO - 2021-12-07 09:08:46 --> Language Class Initialized
INFO - 2021-12-07 09:08:46 --> Config Class Initialized
INFO - 2021-12-07 09:08:46 --> Loader Class Initialized
INFO - 2021-12-07 09:08:46 --> Helper loaded: url_helper
INFO - 2021-12-07 09:08:46 --> Helper loaded: file_helper
INFO - 2021-12-07 09:08:46 --> Helper loaded: form_helper
INFO - 2021-12-07 09:08:46 --> Helper loaded: my_helper
INFO - 2021-12-07 09:08:46 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:08:46 --> Controller Class Initialized
INFO - 2021-12-07 09:08:46 --> Final output sent to browser
DEBUG - 2021-12-07 09:08:46 --> Total execution time: 0.0940
INFO - 2021-12-07 09:08:52 --> Config Class Initialized
INFO - 2021-12-07 09:08:52 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:08:52 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:08:52 --> Utf8 Class Initialized
INFO - 2021-12-07 09:08:52 --> URI Class Initialized
INFO - 2021-12-07 09:08:52 --> Router Class Initialized
INFO - 2021-12-07 09:08:52 --> Output Class Initialized
INFO - 2021-12-07 09:08:52 --> Security Class Initialized
DEBUG - 2021-12-07 09:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:08:52 --> Input Class Initialized
INFO - 2021-12-07 09:08:52 --> Language Class Initialized
INFO - 2021-12-07 09:08:52 --> Language Class Initialized
INFO - 2021-12-07 09:08:52 --> Config Class Initialized
INFO - 2021-12-07 09:08:52 --> Loader Class Initialized
INFO - 2021-12-07 09:08:52 --> Helper loaded: url_helper
INFO - 2021-12-07 09:08:52 --> Helper loaded: file_helper
INFO - 2021-12-07 09:08:52 --> Helper loaded: form_helper
INFO - 2021-12-07 09:08:52 --> Helper loaded: my_helper
INFO - 2021-12-07 09:08:52 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:08:52 --> Controller Class Initialized
DEBUG - 2021-12-07 09:08:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 09:08:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:08:52 --> Final output sent to browser
DEBUG - 2021-12-07 09:08:52 --> Total execution time: 0.0820
INFO - 2021-12-07 09:08:55 --> Config Class Initialized
INFO - 2021-12-07 09:08:55 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:08:55 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:08:55 --> Utf8 Class Initialized
INFO - 2021-12-07 09:08:55 --> URI Class Initialized
INFO - 2021-12-07 09:08:55 --> Router Class Initialized
INFO - 2021-12-07 09:08:55 --> Output Class Initialized
INFO - 2021-12-07 09:08:55 --> Security Class Initialized
DEBUG - 2021-12-07 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:08:55 --> Input Class Initialized
INFO - 2021-12-07 09:08:55 --> Language Class Initialized
INFO - 2021-12-07 09:08:55 --> Language Class Initialized
INFO - 2021-12-07 09:08:55 --> Config Class Initialized
INFO - 2021-12-07 09:08:55 --> Loader Class Initialized
INFO - 2021-12-07 09:08:55 --> Helper loaded: url_helper
INFO - 2021-12-07 09:08:55 --> Helper loaded: file_helper
INFO - 2021-12-07 09:08:55 --> Helper loaded: form_helper
INFO - 2021-12-07 09:08:55 --> Helper loaded: my_helper
INFO - 2021-12-07 09:08:55 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:08:55 --> Controller Class Initialized
DEBUG - 2021-12-07 09:08:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-07 09:08:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:08:55 --> Final output sent to browser
DEBUG - 2021-12-07 09:08:55 --> Total execution time: 0.0580
INFO - 2021-12-07 09:09:53 --> Config Class Initialized
INFO - 2021-12-07 09:09:53 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:09:53 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:09:53 --> Utf8 Class Initialized
INFO - 2021-12-07 09:09:53 --> URI Class Initialized
INFO - 2021-12-07 09:09:53 --> Router Class Initialized
INFO - 2021-12-07 09:09:53 --> Output Class Initialized
INFO - 2021-12-07 09:09:53 --> Security Class Initialized
DEBUG - 2021-12-07 09:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:09:53 --> Input Class Initialized
INFO - 2021-12-07 09:09:53 --> Language Class Initialized
INFO - 2021-12-07 09:09:53 --> Language Class Initialized
INFO - 2021-12-07 09:09:53 --> Config Class Initialized
INFO - 2021-12-07 09:09:53 --> Loader Class Initialized
INFO - 2021-12-07 09:09:53 --> Helper loaded: url_helper
INFO - 2021-12-07 09:09:53 --> Helper loaded: file_helper
INFO - 2021-12-07 09:09:53 --> Helper loaded: form_helper
INFO - 2021-12-07 09:09:53 --> Helper loaded: my_helper
INFO - 2021-12-07 09:09:53 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:09:53 --> Controller Class Initialized
INFO - 2021-12-07 09:09:53 --> Final output sent to browser
DEBUG - 2021-12-07 09:09:53 --> Total execution time: 0.0860
INFO - 2021-12-07 09:09:55 --> Config Class Initialized
INFO - 2021-12-07 09:09:55 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:09:55 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:09:55 --> Utf8 Class Initialized
INFO - 2021-12-07 09:09:55 --> URI Class Initialized
INFO - 2021-12-07 09:09:55 --> Router Class Initialized
INFO - 2021-12-07 09:09:55 --> Output Class Initialized
INFO - 2021-12-07 09:09:55 --> Security Class Initialized
DEBUG - 2021-12-07 09:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:09:55 --> Input Class Initialized
INFO - 2021-12-07 09:09:55 --> Language Class Initialized
INFO - 2021-12-07 09:09:55 --> Language Class Initialized
INFO - 2021-12-07 09:09:55 --> Config Class Initialized
INFO - 2021-12-07 09:09:55 --> Loader Class Initialized
INFO - 2021-12-07 09:09:55 --> Helper loaded: url_helper
INFO - 2021-12-07 09:09:55 --> Helper loaded: file_helper
INFO - 2021-12-07 09:09:55 --> Helper loaded: form_helper
INFO - 2021-12-07 09:09:55 --> Helper loaded: my_helper
INFO - 2021-12-07 09:09:55 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:09:55 --> Controller Class Initialized
DEBUG - 2021-12-07 09:09:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 09:09:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:09:55 --> Final output sent to browser
DEBUG - 2021-12-07 09:09:55 --> Total execution time: 0.1050
INFO - 2021-12-07 09:10:00 --> Config Class Initialized
INFO - 2021-12-07 09:10:00 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:00 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:00 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:00 --> URI Class Initialized
INFO - 2021-12-07 09:10:00 --> Router Class Initialized
INFO - 2021-12-07 09:10:00 --> Output Class Initialized
INFO - 2021-12-07 09:10:00 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:00 --> Input Class Initialized
INFO - 2021-12-07 09:10:00 --> Language Class Initialized
INFO - 2021-12-07 09:10:00 --> Language Class Initialized
INFO - 2021-12-07 09:10:00 --> Config Class Initialized
INFO - 2021-12-07 09:10:00 --> Loader Class Initialized
INFO - 2021-12-07 09:10:00 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:00 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:00 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:00 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:00 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:00 --> Controller Class Initialized
DEBUG - 2021-12-07 09:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-07 09:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:10:00 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:00 --> Total execution time: 0.0600
INFO - 2021-12-07 09:10:03 --> Config Class Initialized
INFO - 2021-12-07 09:10:03 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:03 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:03 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:03 --> URI Class Initialized
INFO - 2021-12-07 09:10:03 --> Router Class Initialized
INFO - 2021-12-07 09:10:03 --> Output Class Initialized
INFO - 2021-12-07 09:10:03 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:03 --> Input Class Initialized
INFO - 2021-12-07 09:10:03 --> Language Class Initialized
INFO - 2021-12-07 09:10:03 --> Language Class Initialized
INFO - 2021-12-07 09:10:03 --> Config Class Initialized
INFO - 2021-12-07 09:10:03 --> Loader Class Initialized
INFO - 2021-12-07 09:10:03 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:03 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:03 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:03 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:03 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:03 --> Controller Class Initialized
INFO - 2021-12-07 09:10:03 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:10:03 --> Config Class Initialized
INFO - 2021-12-07 09:10:03 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:03 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:03 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:03 --> URI Class Initialized
INFO - 2021-12-07 09:10:03 --> Router Class Initialized
INFO - 2021-12-07 09:10:03 --> Output Class Initialized
INFO - 2021-12-07 09:10:03 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:03 --> Input Class Initialized
INFO - 2021-12-07 09:10:03 --> Language Class Initialized
INFO - 2021-12-07 09:10:03 --> Language Class Initialized
INFO - 2021-12-07 09:10:03 --> Config Class Initialized
INFO - 2021-12-07 09:10:03 --> Loader Class Initialized
INFO - 2021-12-07 09:10:03 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:03 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:03 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:03 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:03 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:03 --> Controller Class Initialized
DEBUG - 2021-12-07 09:10:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 09:10:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:10:03 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:03 --> Total execution time: 0.0270
INFO - 2021-12-07 09:10:11 --> Config Class Initialized
INFO - 2021-12-07 09:10:11 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:11 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:11 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:11 --> URI Class Initialized
INFO - 2021-12-07 09:10:11 --> Router Class Initialized
INFO - 2021-12-07 09:10:11 --> Output Class Initialized
INFO - 2021-12-07 09:10:11 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:11 --> Input Class Initialized
INFO - 2021-12-07 09:10:11 --> Language Class Initialized
INFO - 2021-12-07 09:10:11 --> Language Class Initialized
INFO - 2021-12-07 09:10:11 --> Config Class Initialized
INFO - 2021-12-07 09:10:11 --> Loader Class Initialized
INFO - 2021-12-07 09:10:11 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:11 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:11 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:11 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:11 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:11 --> Controller Class Initialized
INFO - 2021-12-07 09:10:11 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:10:11 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:11 --> Total execution time: 0.0450
INFO - 2021-12-07 09:10:11 --> Config Class Initialized
INFO - 2021-12-07 09:10:11 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:11 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:11 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:11 --> URI Class Initialized
INFO - 2021-12-07 09:10:11 --> Router Class Initialized
INFO - 2021-12-07 09:10:11 --> Output Class Initialized
INFO - 2021-12-07 09:10:11 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:11 --> Input Class Initialized
INFO - 2021-12-07 09:10:11 --> Language Class Initialized
INFO - 2021-12-07 09:10:11 --> Language Class Initialized
INFO - 2021-12-07 09:10:11 --> Config Class Initialized
INFO - 2021-12-07 09:10:11 --> Loader Class Initialized
INFO - 2021-12-07 09:10:11 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:11 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:11 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:11 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:11 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:11 --> Controller Class Initialized
DEBUG - 2021-12-07 09:10:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 09:10:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:10:11 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:11 --> Total execution time: 0.2510
INFO - 2021-12-07 09:10:13 --> Config Class Initialized
INFO - 2021-12-07 09:10:13 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:13 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:13 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:13 --> URI Class Initialized
INFO - 2021-12-07 09:10:13 --> Router Class Initialized
INFO - 2021-12-07 09:10:13 --> Output Class Initialized
INFO - 2021-12-07 09:10:13 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:13 --> Input Class Initialized
INFO - 2021-12-07 09:10:13 --> Language Class Initialized
INFO - 2021-12-07 09:10:13 --> Language Class Initialized
INFO - 2021-12-07 09:10:13 --> Config Class Initialized
INFO - 2021-12-07 09:10:13 --> Loader Class Initialized
INFO - 2021-12-07 09:10:13 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:13 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:13 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:13 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:13 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:13 --> Controller Class Initialized
DEBUG - 2021-12-07 09:10:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-07 09:10:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:10:13 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:13 --> Total execution time: 0.0510
INFO - 2021-12-07 09:10:13 --> Config Class Initialized
INFO - 2021-12-07 09:10:13 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:13 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:13 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:13 --> URI Class Initialized
INFO - 2021-12-07 09:10:13 --> Router Class Initialized
INFO - 2021-12-07 09:10:13 --> Output Class Initialized
INFO - 2021-12-07 09:10:13 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:13 --> Input Class Initialized
INFO - 2021-12-07 09:10:13 --> Language Class Initialized
INFO - 2021-12-07 09:10:13 --> Language Class Initialized
INFO - 2021-12-07 09:10:13 --> Config Class Initialized
INFO - 2021-12-07 09:10:13 --> Loader Class Initialized
INFO - 2021-12-07 09:10:13 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:13 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:13 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:13 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:13 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:13 --> Controller Class Initialized
INFO - 2021-12-07 09:10:18 --> Config Class Initialized
INFO - 2021-12-07 09:10:18 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:18 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:18 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:18 --> URI Class Initialized
INFO - 2021-12-07 09:10:18 --> Router Class Initialized
INFO - 2021-12-07 09:10:18 --> Output Class Initialized
INFO - 2021-12-07 09:10:18 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:18 --> Input Class Initialized
INFO - 2021-12-07 09:10:18 --> Language Class Initialized
INFO - 2021-12-07 09:10:18 --> Language Class Initialized
INFO - 2021-12-07 09:10:18 --> Config Class Initialized
INFO - 2021-12-07 09:10:18 --> Loader Class Initialized
INFO - 2021-12-07 09:10:18 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:18 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:18 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:18 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:18 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:18 --> Controller Class Initialized
INFO - 2021-12-07 09:10:18 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:18 --> Total execution time: 0.0540
INFO - 2021-12-07 09:10:18 --> Config Class Initialized
INFO - 2021-12-07 09:10:18 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:18 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:18 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:18 --> URI Class Initialized
INFO - 2021-12-07 09:10:18 --> Router Class Initialized
INFO - 2021-12-07 09:10:18 --> Output Class Initialized
INFO - 2021-12-07 09:10:18 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:18 --> Input Class Initialized
INFO - 2021-12-07 09:10:18 --> Language Class Initialized
INFO - 2021-12-07 09:10:18 --> Language Class Initialized
INFO - 2021-12-07 09:10:18 --> Config Class Initialized
INFO - 2021-12-07 09:10:18 --> Loader Class Initialized
INFO - 2021-12-07 09:10:18 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:18 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:18 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:18 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:18 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:18 --> Controller Class Initialized
INFO - 2021-12-07 09:10:22 --> Config Class Initialized
INFO - 2021-12-07 09:10:22 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:22 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:22 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:22 --> URI Class Initialized
INFO - 2021-12-07 09:10:22 --> Router Class Initialized
INFO - 2021-12-07 09:10:22 --> Output Class Initialized
INFO - 2021-12-07 09:10:22 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:22 --> Input Class Initialized
INFO - 2021-12-07 09:10:22 --> Language Class Initialized
INFO - 2021-12-07 09:10:22 --> Language Class Initialized
INFO - 2021-12-07 09:10:22 --> Config Class Initialized
INFO - 2021-12-07 09:10:22 --> Loader Class Initialized
INFO - 2021-12-07 09:10:22 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:22 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:22 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:22 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:22 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:22 --> Controller Class Initialized
INFO - 2021-12-07 09:10:22 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:10:22 --> Config Class Initialized
INFO - 2021-12-07 09:10:22 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:22 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:22 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:22 --> URI Class Initialized
INFO - 2021-12-07 09:10:22 --> Router Class Initialized
INFO - 2021-12-07 09:10:22 --> Output Class Initialized
INFO - 2021-12-07 09:10:22 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:22 --> Input Class Initialized
INFO - 2021-12-07 09:10:22 --> Language Class Initialized
INFO - 2021-12-07 09:10:22 --> Language Class Initialized
INFO - 2021-12-07 09:10:22 --> Config Class Initialized
INFO - 2021-12-07 09:10:22 --> Loader Class Initialized
INFO - 2021-12-07 09:10:22 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:22 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:22 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:22 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:22 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:22 --> Controller Class Initialized
DEBUG - 2021-12-07 09:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 09:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:10:22 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:22 --> Total execution time: 0.0360
INFO - 2021-12-07 09:10:29 --> Config Class Initialized
INFO - 2021-12-07 09:10:29 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:29 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:29 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:29 --> URI Class Initialized
INFO - 2021-12-07 09:10:29 --> Router Class Initialized
INFO - 2021-12-07 09:10:29 --> Output Class Initialized
INFO - 2021-12-07 09:10:29 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:29 --> Input Class Initialized
INFO - 2021-12-07 09:10:29 --> Language Class Initialized
INFO - 2021-12-07 09:10:29 --> Language Class Initialized
INFO - 2021-12-07 09:10:29 --> Config Class Initialized
INFO - 2021-12-07 09:10:29 --> Loader Class Initialized
INFO - 2021-12-07 09:10:29 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:29 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:29 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:29 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:29 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:29 --> Controller Class Initialized
INFO - 2021-12-07 09:10:29 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:10:29 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:29 --> Total execution time: 0.0470
INFO - 2021-12-07 09:10:29 --> Config Class Initialized
INFO - 2021-12-07 09:10:29 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:29 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:29 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:29 --> URI Class Initialized
INFO - 2021-12-07 09:10:29 --> Router Class Initialized
INFO - 2021-12-07 09:10:29 --> Output Class Initialized
INFO - 2021-12-07 09:10:29 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:29 --> Input Class Initialized
INFO - 2021-12-07 09:10:29 --> Language Class Initialized
INFO - 2021-12-07 09:10:29 --> Language Class Initialized
INFO - 2021-12-07 09:10:29 --> Config Class Initialized
INFO - 2021-12-07 09:10:29 --> Loader Class Initialized
INFO - 2021-12-07 09:10:29 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:29 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:29 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:29 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:29 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:29 --> Controller Class Initialized
DEBUG - 2021-12-07 09:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 09:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:10:29 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:29 --> Total execution time: 0.1780
INFO - 2021-12-07 09:10:31 --> Config Class Initialized
INFO - 2021-12-07 09:10:31 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:31 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:31 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:31 --> URI Class Initialized
INFO - 2021-12-07 09:10:31 --> Router Class Initialized
INFO - 2021-12-07 09:10:31 --> Output Class Initialized
INFO - 2021-12-07 09:10:31 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:31 --> Input Class Initialized
INFO - 2021-12-07 09:10:31 --> Language Class Initialized
INFO - 2021-12-07 09:10:31 --> Language Class Initialized
INFO - 2021-12-07 09:10:31 --> Config Class Initialized
INFO - 2021-12-07 09:10:31 --> Loader Class Initialized
INFO - 2021-12-07 09:10:31 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:31 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:31 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:31 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:31 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:32 --> Controller Class Initialized
DEBUG - 2021-12-07 09:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 09:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:10:32 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:32 --> Total execution time: 0.0910
INFO - 2021-12-07 09:10:33 --> Config Class Initialized
INFO - 2021-12-07 09:10:33 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:10:33 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:10:33 --> Utf8 Class Initialized
INFO - 2021-12-07 09:10:33 --> URI Class Initialized
INFO - 2021-12-07 09:10:33 --> Router Class Initialized
INFO - 2021-12-07 09:10:33 --> Output Class Initialized
INFO - 2021-12-07 09:10:33 --> Security Class Initialized
DEBUG - 2021-12-07 09:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:10:33 --> Input Class Initialized
INFO - 2021-12-07 09:10:33 --> Language Class Initialized
INFO - 2021-12-07 09:10:33 --> Language Class Initialized
INFO - 2021-12-07 09:10:33 --> Config Class Initialized
INFO - 2021-12-07 09:10:33 --> Loader Class Initialized
INFO - 2021-12-07 09:10:33 --> Helper loaded: url_helper
INFO - 2021-12-07 09:10:33 --> Helper loaded: file_helper
INFO - 2021-12-07 09:10:33 --> Helper loaded: form_helper
INFO - 2021-12-07 09:10:33 --> Helper loaded: my_helper
INFO - 2021-12-07 09:10:33 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:10:33 --> Controller Class Initialized
DEBUG - 2021-12-07 09:10:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-07 09:10:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:10:33 --> Final output sent to browser
DEBUG - 2021-12-07 09:10:33 --> Total execution time: 0.0660
INFO - 2021-12-07 09:11:30 --> Config Class Initialized
INFO - 2021-12-07 09:11:30 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:11:30 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:11:30 --> Utf8 Class Initialized
INFO - 2021-12-07 09:11:30 --> URI Class Initialized
INFO - 2021-12-07 09:11:30 --> Router Class Initialized
INFO - 2021-12-07 09:11:30 --> Output Class Initialized
INFO - 2021-12-07 09:11:30 --> Security Class Initialized
DEBUG - 2021-12-07 09:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:11:30 --> Input Class Initialized
INFO - 2021-12-07 09:11:30 --> Language Class Initialized
INFO - 2021-12-07 09:11:30 --> Language Class Initialized
INFO - 2021-12-07 09:11:30 --> Config Class Initialized
INFO - 2021-12-07 09:11:30 --> Loader Class Initialized
INFO - 2021-12-07 09:11:30 --> Helper loaded: url_helper
INFO - 2021-12-07 09:11:30 --> Helper loaded: file_helper
INFO - 2021-12-07 09:11:30 --> Helper loaded: form_helper
INFO - 2021-12-07 09:11:30 --> Helper loaded: my_helper
INFO - 2021-12-07 09:11:30 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:11:30 --> Controller Class Initialized
INFO - 2021-12-07 09:11:30 --> Final output sent to browser
DEBUG - 2021-12-07 09:11:30 --> Total execution time: 0.0770
INFO - 2021-12-07 09:11:37 --> Config Class Initialized
INFO - 2021-12-07 09:11:37 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:11:37 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:11:37 --> Utf8 Class Initialized
INFO - 2021-12-07 09:11:37 --> URI Class Initialized
INFO - 2021-12-07 09:11:37 --> Router Class Initialized
INFO - 2021-12-07 09:11:37 --> Output Class Initialized
INFO - 2021-12-07 09:11:37 --> Security Class Initialized
DEBUG - 2021-12-07 09:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:11:37 --> Input Class Initialized
INFO - 2021-12-07 09:11:37 --> Language Class Initialized
INFO - 2021-12-07 09:11:37 --> Language Class Initialized
INFO - 2021-12-07 09:11:37 --> Config Class Initialized
INFO - 2021-12-07 09:11:37 --> Loader Class Initialized
INFO - 2021-12-07 09:11:37 --> Helper loaded: url_helper
INFO - 2021-12-07 09:11:37 --> Helper loaded: file_helper
INFO - 2021-12-07 09:11:37 --> Helper loaded: form_helper
INFO - 2021-12-07 09:11:37 --> Helper loaded: my_helper
INFO - 2021-12-07 09:11:37 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:11:37 --> Controller Class Initialized
INFO - 2021-12-07 09:11:37 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:11:37 --> Config Class Initialized
INFO - 2021-12-07 09:11:37 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:11:37 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:11:37 --> Utf8 Class Initialized
INFO - 2021-12-07 09:11:37 --> URI Class Initialized
INFO - 2021-12-07 09:11:37 --> Router Class Initialized
INFO - 2021-12-07 09:11:37 --> Output Class Initialized
INFO - 2021-12-07 09:11:37 --> Security Class Initialized
DEBUG - 2021-12-07 09:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:11:37 --> Input Class Initialized
INFO - 2021-12-07 09:11:37 --> Language Class Initialized
INFO - 2021-12-07 09:11:37 --> Language Class Initialized
INFO - 2021-12-07 09:11:37 --> Config Class Initialized
INFO - 2021-12-07 09:11:37 --> Loader Class Initialized
INFO - 2021-12-07 09:11:37 --> Helper loaded: url_helper
INFO - 2021-12-07 09:11:37 --> Helper loaded: file_helper
INFO - 2021-12-07 09:11:37 --> Helper loaded: form_helper
INFO - 2021-12-07 09:11:37 --> Helper loaded: my_helper
INFO - 2021-12-07 09:11:37 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:11:37 --> Controller Class Initialized
DEBUG - 2021-12-07 09:11:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 09:11:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:11:37 --> Final output sent to browser
DEBUG - 2021-12-07 09:11:37 --> Total execution time: 0.0470
INFO - 2021-12-07 09:11:51 --> Config Class Initialized
INFO - 2021-12-07 09:11:51 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:11:51 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:11:51 --> Utf8 Class Initialized
INFO - 2021-12-07 09:11:51 --> URI Class Initialized
INFO - 2021-12-07 09:11:51 --> Router Class Initialized
INFO - 2021-12-07 09:11:51 --> Output Class Initialized
INFO - 2021-12-07 09:11:51 --> Security Class Initialized
DEBUG - 2021-12-07 09:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:11:51 --> Input Class Initialized
INFO - 2021-12-07 09:11:51 --> Language Class Initialized
INFO - 2021-12-07 09:11:51 --> Language Class Initialized
INFO - 2021-12-07 09:11:51 --> Config Class Initialized
INFO - 2021-12-07 09:11:51 --> Loader Class Initialized
INFO - 2021-12-07 09:11:51 --> Helper loaded: url_helper
INFO - 2021-12-07 09:11:51 --> Helper loaded: file_helper
INFO - 2021-12-07 09:11:51 --> Helper loaded: form_helper
INFO - 2021-12-07 09:11:51 --> Helper loaded: my_helper
INFO - 2021-12-07 09:11:51 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:11:51 --> Controller Class Initialized
INFO - 2021-12-07 09:11:51 --> Final output sent to browser
DEBUG - 2021-12-07 09:11:51 --> Total execution time: 0.0500
INFO - 2021-12-07 09:11:58 --> Config Class Initialized
INFO - 2021-12-07 09:11:58 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:11:58 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:11:58 --> Utf8 Class Initialized
INFO - 2021-12-07 09:11:58 --> URI Class Initialized
INFO - 2021-12-07 09:11:58 --> Router Class Initialized
INFO - 2021-12-07 09:11:58 --> Output Class Initialized
INFO - 2021-12-07 09:11:58 --> Security Class Initialized
DEBUG - 2021-12-07 09:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:11:58 --> Input Class Initialized
INFO - 2021-12-07 09:11:58 --> Language Class Initialized
INFO - 2021-12-07 09:11:58 --> Language Class Initialized
INFO - 2021-12-07 09:11:58 --> Config Class Initialized
INFO - 2021-12-07 09:11:58 --> Loader Class Initialized
INFO - 2021-12-07 09:11:58 --> Helper loaded: url_helper
INFO - 2021-12-07 09:11:58 --> Helper loaded: file_helper
INFO - 2021-12-07 09:11:58 --> Helper loaded: form_helper
INFO - 2021-12-07 09:11:58 --> Helper loaded: my_helper
INFO - 2021-12-07 09:11:58 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:11:58 --> Controller Class Initialized
INFO - 2021-12-07 09:11:58 --> Final output sent to browser
DEBUG - 2021-12-07 09:11:58 --> Total execution time: 0.0460
INFO - 2021-12-07 09:12:24 --> Config Class Initialized
INFO - 2021-12-07 09:12:24 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:24 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:24 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:24 --> URI Class Initialized
INFO - 2021-12-07 09:12:24 --> Router Class Initialized
INFO - 2021-12-07 09:12:24 --> Output Class Initialized
INFO - 2021-12-07 09:12:24 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:24 --> Input Class Initialized
INFO - 2021-12-07 09:12:24 --> Language Class Initialized
INFO - 2021-12-07 09:12:24 --> Language Class Initialized
INFO - 2021-12-07 09:12:24 --> Config Class Initialized
INFO - 2021-12-07 09:12:24 --> Loader Class Initialized
INFO - 2021-12-07 09:12:24 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:24 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:24 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:24 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:24 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:24 --> Controller Class Initialized
INFO - 2021-12-07 09:12:24 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:12:24 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:24 --> Total execution time: 0.0490
INFO - 2021-12-07 09:12:25 --> Config Class Initialized
INFO - 2021-12-07 09:12:25 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:25 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:25 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:25 --> URI Class Initialized
INFO - 2021-12-07 09:12:25 --> Router Class Initialized
INFO - 2021-12-07 09:12:25 --> Output Class Initialized
INFO - 2021-12-07 09:12:25 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:25 --> Input Class Initialized
INFO - 2021-12-07 09:12:25 --> Language Class Initialized
INFO - 2021-12-07 09:12:25 --> Language Class Initialized
INFO - 2021-12-07 09:12:25 --> Config Class Initialized
INFO - 2021-12-07 09:12:25 --> Loader Class Initialized
INFO - 2021-12-07 09:12:25 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:25 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:25 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:25 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:25 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:25 --> Controller Class Initialized
DEBUG - 2021-12-07 09:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 09:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:12:25 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:25 --> Total execution time: 0.2270
INFO - 2021-12-07 09:12:27 --> Config Class Initialized
INFO - 2021-12-07 09:12:27 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:27 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:27 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:27 --> URI Class Initialized
INFO - 2021-12-07 09:12:27 --> Router Class Initialized
INFO - 2021-12-07 09:12:27 --> Output Class Initialized
INFO - 2021-12-07 09:12:27 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:27 --> Input Class Initialized
INFO - 2021-12-07 09:12:27 --> Language Class Initialized
INFO - 2021-12-07 09:12:27 --> Language Class Initialized
INFO - 2021-12-07 09:12:27 --> Config Class Initialized
INFO - 2021-12-07 09:12:27 --> Loader Class Initialized
INFO - 2021-12-07 09:12:27 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:27 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:27 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:27 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:27 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:27 --> Controller Class Initialized
DEBUG - 2021-12-07 09:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-07 09:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:12:27 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:27 --> Total execution time: 0.0530
INFO - 2021-12-07 09:12:28 --> Config Class Initialized
INFO - 2021-12-07 09:12:28 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:28 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:28 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:28 --> URI Class Initialized
INFO - 2021-12-07 09:12:28 --> Router Class Initialized
INFO - 2021-12-07 09:12:28 --> Output Class Initialized
INFO - 2021-12-07 09:12:28 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:28 --> Input Class Initialized
INFO - 2021-12-07 09:12:28 --> Language Class Initialized
INFO - 2021-12-07 09:12:28 --> Language Class Initialized
INFO - 2021-12-07 09:12:28 --> Config Class Initialized
INFO - 2021-12-07 09:12:28 --> Loader Class Initialized
INFO - 2021-12-07 09:12:28 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:28 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:28 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:28 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:28 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:28 --> Controller Class Initialized
INFO - 2021-12-07 09:12:30 --> Config Class Initialized
INFO - 2021-12-07 09:12:30 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:30 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:30 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:30 --> URI Class Initialized
INFO - 2021-12-07 09:12:30 --> Router Class Initialized
INFO - 2021-12-07 09:12:30 --> Output Class Initialized
INFO - 2021-12-07 09:12:30 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:30 --> Input Class Initialized
INFO - 2021-12-07 09:12:30 --> Language Class Initialized
INFO - 2021-12-07 09:12:30 --> Language Class Initialized
INFO - 2021-12-07 09:12:30 --> Config Class Initialized
INFO - 2021-12-07 09:12:30 --> Loader Class Initialized
INFO - 2021-12-07 09:12:30 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:30 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:30 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:30 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:30 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:30 --> Controller Class Initialized
INFO - 2021-12-07 09:12:30 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:30 --> Total execution time: 0.0390
INFO - 2021-12-07 09:12:30 --> Config Class Initialized
INFO - 2021-12-07 09:12:30 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:30 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:30 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:30 --> URI Class Initialized
INFO - 2021-12-07 09:12:30 --> Router Class Initialized
INFO - 2021-12-07 09:12:30 --> Output Class Initialized
INFO - 2021-12-07 09:12:30 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:30 --> Input Class Initialized
INFO - 2021-12-07 09:12:30 --> Language Class Initialized
INFO - 2021-12-07 09:12:30 --> Language Class Initialized
INFO - 2021-12-07 09:12:30 --> Config Class Initialized
INFO - 2021-12-07 09:12:30 --> Loader Class Initialized
INFO - 2021-12-07 09:12:30 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:30 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:30 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:30 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:30 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:30 --> Controller Class Initialized
INFO - 2021-12-07 09:12:32 --> Config Class Initialized
INFO - 2021-12-07 09:12:32 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:32 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:32 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:32 --> URI Class Initialized
INFO - 2021-12-07 09:12:32 --> Router Class Initialized
INFO - 2021-12-07 09:12:32 --> Output Class Initialized
INFO - 2021-12-07 09:12:32 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:32 --> Input Class Initialized
INFO - 2021-12-07 09:12:32 --> Language Class Initialized
INFO - 2021-12-07 09:12:32 --> Language Class Initialized
INFO - 2021-12-07 09:12:32 --> Config Class Initialized
INFO - 2021-12-07 09:12:32 --> Loader Class Initialized
INFO - 2021-12-07 09:12:32 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:32 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:32 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:32 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:32 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:32 --> Controller Class Initialized
INFO - 2021-12-07 09:12:32 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:12:32 --> Config Class Initialized
INFO - 2021-12-07 09:12:32 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:32 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:32 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:32 --> URI Class Initialized
INFO - 2021-12-07 09:12:32 --> Router Class Initialized
INFO - 2021-12-07 09:12:32 --> Output Class Initialized
INFO - 2021-12-07 09:12:32 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:32 --> Input Class Initialized
INFO - 2021-12-07 09:12:32 --> Language Class Initialized
INFO - 2021-12-07 09:12:32 --> Language Class Initialized
INFO - 2021-12-07 09:12:32 --> Config Class Initialized
INFO - 2021-12-07 09:12:32 --> Loader Class Initialized
INFO - 2021-12-07 09:12:32 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:32 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:32 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:32 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:32 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:32 --> Controller Class Initialized
DEBUG - 2021-12-07 09:12:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 09:12:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:12:32 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:32 --> Total execution time: 0.0350
INFO - 2021-12-07 09:12:40 --> Config Class Initialized
INFO - 2021-12-07 09:12:40 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:40 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:40 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:40 --> URI Class Initialized
INFO - 2021-12-07 09:12:40 --> Router Class Initialized
INFO - 2021-12-07 09:12:40 --> Output Class Initialized
INFO - 2021-12-07 09:12:40 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:40 --> Input Class Initialized
INFO - 2021-12-07 09:12:40 --> Language Class Initialized
INFO - 2021-12-07 09:12:40 --> Language Class Initialized
INFO - 2021-12-07 09:12:40 --> Config Class Initialized
INFO - 2021-12-07 09:12:40 --> Loader Class Initialized
INFO - 2021-12-07 09:12:40 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:40 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:40 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:40 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:40 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:40 --> Controller Class Initialized
INFO - 2021-12-07 09:12:40 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:12:40 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:40 --> Total execution time: 0.0450
INFO - 2021-12-07 09:12:41 --> Config Class Initialized
INFO - 2021-12-07 09:12:41 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:41 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:41 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:41 --> URI Class Initialized
INFO - 2021-12-07 09:12:41 --> Router Class Initialized
INFO - 2021-12-07 09:12:41 --> Output Class Initialized
INFO - 2021-12-07 09:12:41 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:41 --> Input Class Initialized
INFO - 2021-12-07 09:12:41 --> Language Class Initialized
INFO - 2021-12-07 09:12:41 --> Language Class Initialized
INFO - 2021-12-07 09:12:41 --> Config Class Initialized
INFO - 2021-12-07 09:12:41 --> Loader Class Initialized
INFO - 2021-12-07 09:12:41 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:41 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:41 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:41 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:41 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:41 --> Controller Class Initialized
DEBUG - 2021-12-07 09:12:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 09:12:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:12:41 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:41 --> Total execution time: 0.1820
INFO - 2021-12-07 09:12:43 --> Config Class Initialized
INFO - 2021-12-07 09:12:43 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:43 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:43 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:43 --> URI Class Initialized
INFO - 2021-12-07 09:12:43 --> Router Class Initialized
INFO - 2021-12-07 09:12:43 --> Output Class Initialized
INFO - 2021-12-07 09:12:43 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:43 --> Input Class Initialized
INFO - 2021-12-07 09:12:43 --> Language Class Initialized
INFO - 2021-12-07 09:12:43 --> Language Class Initialized
INFO - 2021-12-07 09:12:43 --> Config Class Initialized
INFO - 2021-12-07 09:12:43 --> Loader Class Initialized
INFO - 2021-12-07 09:12:43 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:43 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:43 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:43 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:43 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:43 --> Controller Class Initialized
DEBUG - 2021-12-07 09:12:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-07 09:12:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:12:43 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:43 --> Total execution time: 0.0650
INFO - 2021-12-07 09:12:45 --> Config Class Initialized
INFO - 2021-12-07 09:12:45 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:45 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:45 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:45 --> URI Class Initialized
INFO - 2021-12-07 09:12:45 --> Router Class Initialized
INFO - 2021-12-07 09:12:45 --> Output Class Initialized
INFO - 2021-12-07 09:12:45 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:45 --> Input Class Initialized
INFO - 2021-12-07 09:12:45 --> Language Class Initialized
INFO - 2021-12-07 09:12:45 --> Language Class Initialized
INFO - 2021-12-07 09:12:45 --> Config Class Initialized
INFO - 2021-12-07 09:12:45 --> Loader Class Initialized
INFO - 2021-12-07 09:12:45 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:45 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:45 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:45 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:45 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:45 --> Controller Class Initialized
DEBUG - 2021-12-07 09:12:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-07 09:12:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:12:45 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:45 --> Total execution time: 0.0950
INFO - 2021-12-07 09:12:52 --> Config Class Initialized
INFO - 2021-12-07 09:12:52 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:52 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:52 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:52 --> URI Class Initialized
INFO - 2021-12-07 09:12:52 --> Router Class Initialized
INFO - 2021-12-07 09:12:52 --> Output Class Initialized
INFO - 2021-12-07 09:12:52 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:52 --> Input Class Initialized
INFO - 2021-12-07 09:12:52 --> Language Class Initialized
INFO - 2021-12-07 09:12:52 --> Language Class Initialized
INFO - 2021-12-07 09:12:52 --> Config Class Initialized
INFO - 2021-12-07 09:12:52 --> Loader Class Initialized
INFO - 2021-12-07 09:12:52 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:52 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:52 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:52 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:52 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:52 --> Controller Class Initialized
INFO - 2021-12-07 09:12:52 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:12:52 --> Config Class Initialized
INFO - 2021-12-07 09:12:52 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:12:52 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:12:52 --> Utf8 Class Initialized
INFO - 2021-12-07 09:12:52 --> URI Class Initialized
INFO - 2021-12-07 09:12:52 --> Router Class Initialized
INFO - 2021-12-07 09:12:52 --> Output Class Initialized
INFO - 2021-12-07 09:12:52 --> Security Class Initialized
DEBUG - 2021-12-07 09:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:12:52 --> Input Class Initialized
INFO - 2021-12-07 09:12:52 --> Language Class Initialized
INFO - 2021-12-07 09:12:52 --> Language Class Initialized
INFO - 2021-12-07 09:12:52 --> Config Class Initialized
INFO - 2021-12-07 09:12:52 --> Loader Class Initialized
INFO - 2021-12-07 09:12:52 --> Helper loaded: url_helper
INFO - 2021-12-07 09:12:52 --> Helper loaded: file_helper
INFO - 2021-12-07 09:12:52 --> Helper loaded: form_helper
INFO - 2021-12-07 09:12:52 --> Helper loaded: my_helper
INFO - 2021-12-07 09:12:52 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:12:52 --> Controller Class Initialized
DEBUG - 2021-12-07 09:12:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 09:12:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:12:52 --> Final output sent to browser
DEBUG - 2021-12-07 09:12:52 --> Total execution time: 0.0360
INFO - 2021-12-07 09:13:00 --> Config Class Initialized
INFO - 2021-12-07 09:13:00 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:13:00 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:13:00 --> Utf8 Class Initialized
INFO - 2021-12-07 09:13:00 --> URI Class Initialized
INFO - 2021-12-07 09:13:00 --> Router Class Initialized
INFO - 2021-12-07 09:13:00 --> Output Class Initialized
INFO - 2021-12-07 09:13:00 --> Security Class Initialized
DEBUG - 2021-12-07 09:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:13:00 --> Input Class Initialized
INFO - 2021-12-07 09:13:00 --> Language Class Initialized
INFO - 2021-12-07 09:13:00 --> Language Class Initialized
INFO - 2021-12-07 09:13:00 --> Config Class Initialized
INFO - 2021-12-07 09:13:00 --> Loader Class Initialized
INFO - 2021-12-07 09:13:00 --> Helper loaded: url_helper
INFO - 2021-12-07 09:13:00 --> Helper loaded: file_helper
INFO - 2021-12-07 09:13:00 --> Helper loaded: form_helper
INFO - 2021-12-07 09:13:00 --> Helper loaded: my_helper
INFO - 2021-12-07 09:13:00 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:13:00 --> Controller Class Initialized
INFO - 2021-12-07 09:13:00 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:13:00 --> Final output sent to browser
DEBUG - 2021-12-07 09:13:00 --> Total execution time: 0.0520
INFO - 2021-12-07 09:13:01 --> Config Class Initialized
INFO - 2021-12-07 09:13:01 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:13:01 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:13:01 --> Utf8 Class Initialized
INFO - 2021-12-07 09:13:01 --> URI Class Initialized
INFO - 2021-12-07 09:13:01 --> Router Class Initialized
INFO - 2021-12-07 09:13:01 --> Output Class Initialized
INFO - 2021-12-07 09:13:01 --> Security Class Initialized
DEBUG - 2021-12-07 09:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:13:01 --> Input Class Initialized
INFO - 2021-12-07 09:13:01 --> Language Class Initialized
INFO - 2021-12-07 09:13:01 --> Language Class Initialized
INFO - 2021-12-07 09:13:01 --> Config Class Initialized
INFO - 2021-12-07 09:13:01 --> Loader Class Initialized
INFO - 2021-12-07 09:13:01 --> Helper loaded: url_helper
INFO - 2021-12-07 09:13:01 --> Helper loaded: file_helper
INFO - 2021-12-07 09:13:01 --> Helper loaded: form_helper
INFO - 2021-12-07 09:13:01 --> Helper loaded: my_helper
INFO - 2021-12-07 09:13:01 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:13:01 --> Controller Class Initialized
DEBUG - 2021-12-07 09:13:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-07 09:13:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:13:01 --> Final output sent to browser
DEBUG - 2021-12-07 09:13:01 --> Total execution time: 0.2090
INFO - 2021-12-07 09:13:03 --> Config Class Initialized
INFO - 2021-12-07 09:13:03 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:13:03 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:13:03 --> Utf8 Class Initialized
INFO - 2021-12-07 09:13:03 --> URI Class Initialized
INFO - 2021-12-07 09:13:03 --> Router Class Initialized
INFO - 2021-12-07 09:13:03 --> Output Class Initialized
INFO - 2021-12-07 09:13:03 --> Security Class Initialized
DEBUG - 2021-12-07 09:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:13:03 --> Input Class Initialized
INFO - 2021-12-07 09:13:03 --> Language Class Initialized
INFO - 2021-12-07 09:13:03 --> Language Class Initialized
INFO - 2021-12-07 09:13:03 --> Config Class Initialized
INFO - 2021-12-07 09:13:03 --> Loader Class Initialized
INFO - 2021-12-07 09:13:03 --> Helper loaded: url_helper
INFO - 2021-12-07 09:13:03 --> Helper loaded: file_helper
INFO - 2021-12-07 09:13:03 --> Helper loaded: form_helper
INFO - 2021-12-07 09:13:03 --> Helper loaded: my_helper
INFO - 2021-12-07 09:13:03 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:13:03 --> Controller Class Initialized
DEBUG - 2021-12-07 09:13:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-07 09:13:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:13:03 --> Final output sent to browser
DEBUG - 2021-12-07 09:13:03 --> Total execution time: 0.0520
INFO - 2021-12-07 09:13:03 --> Config Class Initialized
INFO - 2021-12-07 09:13:03 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:13:03 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:13:03 --> Utf8 Class Initialized
INFO - 2021-12-07 09:13:03 --> URI Class Initialized
INFO - 2021-12-07 09:13:03 --> Router Class Initialized
INFO - 2021-12-07 09:13:03 --> Output Class Initialized
INFO - 2021-12-07 09:13:03 --> Security Class Initialized
DEBUG - 2021-12-07 09:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:13:03 --> Input Class Initialized
INFO - 2021-12-07 09:13:03 --> Language Class Initialized
INFO - 2021-12-07 09:13:03 --> Language Class Initialized
INFO - 2021-12-07 09:13:03 --> Config Class Initialized
INFO - 2021-12-07 09:13:03 --> Loader Class Initialized
INFO - 2021-12-07 09:13:03 --> Helper loaded: url_helper
INFO - 2021-12-07 09:13:03 --> Helper loaded: file_helper
INFO - 2021-12-07 09:13:03 --> Helper loaded: form_helper
INFO - 2021-12-07 09:13:03 --> Helper loaded: my_helper
INFO - 2021-12-07 09:13:03 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:13:03 --> Controller Class Initialized
INFO - 2021-12-07 09:56:20 --> Config Class Initialized
INFO - 2021-12-07 09:56:20 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:56:20 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:56:20 --> Utf8 Class Initialized
INFO - 2021-12-07 09:56:20 --> URI Class Initialized
INFO - 2021-12-07 09:56:20 --> Router Class Initialized
INFO - 2021-12-07 09:56:20 --> Output Class Initialized
INFO - 2021-12-07 09:56:20 --> Security Class Initialized
DEBUG - 2021-12-07 09:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:56:20 --> Input Class Initialized
INFO - 2021-12-07 09:56:20 --> Language Class Initialized
INFO - 2021-12-07 09:56:20 --> Language Class Initialized
INFO - 2021-12-07 09:56:20 --> Config Class Initialized
INFO - 2021-12-07 09:56:20 --> Loader Class Initialized
INFO - 2021-12-07 09:56:20 --> Helper loaded: url_helper
INFO - 2021-12-07 09:56:20 --> Helper loaded: file_helper
INFO - 2021-12-07 09:56:20 --> Helper loaded: form_helper
INFO - 2021-12-07 09:56:20 --> Helper loaded: my_helper
INFO - 2021-12-07 09:56:20 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:56:20 --> Controller Class Initialized
INFO - 2021-12-07 09:56:20 --> Helper loaded: cookie_helper
INFO - 2021-12-07 09:56:20 --> Config Class Initialized
INFO - 2021-12-07 09:56:20 --> Hooks Class Initialized
DEBUG - 2021-12-07 09:56:20 --> UTF-8 Support Enabled
INFO - 2021-12-07 09:56:20 --> Utf8 Class Initialized
INFO - 2021-12-07 09:56:20 --> URI Class Initialized
INFO - 2021-12-07 09:56:20 --> Router Class Initialized
INFO - 2021-12-07 09:56:20 --> Output Class Initialized
INFO - 2021-12-07 09:56:20 --> Security Class Initialized
DEBUG - 2021-12-07 09:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-07 09:56:20 --> Input Class Initialized
INFO - 2021-12-07 09:56:20 --> Language Class Initialized
INFO - 2021-12-07 09:56:20 --> Language Class Initialized
INFO - 2021-12-07 09:56:20 --> Config Class Initialized
INFO - 2021-12-07 09:56:20 --> Loader Class Initialized
INFO - 2021-12-07 09:56:20 --> Helper loaded: url_helper
INFO - 2021-12-07 09:56:20 --> Helper loaded: file_helper
INFO - 2021-12-07 09:56:20 --> Helper loaded: form_helper
INFO - 2021-12-07 09:56:20 --> Helper loaded: my_helper
INFO - 2021-12-07 09:56:20 --> Database Driver Class Initialized
DEBUG - 2021-12-07 09:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-07 09:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-07 09:56:20 --> Controller Class Initialized
DEBUG - 2021-12-07 09:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-07 09:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-07 09:56:20 --> Final output sent to browser
DEBUG - 2021-12-07 09:56:20 --> Total execution time: 0.0400
