<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-17 03:07:46 --> Config Class Initialized
INFO - 2022-05-17 03:07:46 --> Hooks Class Initialized
DEBUG - 2022-05-17 03:07:46 --> UTF-8 Support Enabled
INFO - 2022-05-17 03:07:46 --> Utf8 Class Initialized
INFO - 2022-05-17 03:07:46 --> URI Class Initialized
DEBUG - 2022-05-17 03:07:47 --> No URI present. Default controller set.
INFO - 2022-05-17 03:07:47 --> Router Class Initialized
INFO - 2022-05-17 03:07:47 --> Output Class Initialized
INFO - 2022-05-17 03:07:47 --> Security Class Initialized
DEBUG - 2022-05-17 03:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-17 03:07:47 --> Input Class Initialized
INFO - 2022-05-17 03:07:47 --> Language Class Initialized
INFO - 2022-05-17 03:07:47 --> Language Class Initialized
INFO - 2022-05-17 03:07:47 --> Config Class Initialized
INFO - 2022-05-17 03:07:47 --> Loader Class Initialized
INFO - 2022-05-17 03:07:47 --> Helper loaded: url_helper
INFO - 2022-05-17 03:07:47 --> Helper loaded: file_helper
INFO - 2022-05-17 03:07:47 --> Helper loaded: form_helper
INFO - 2022-05-17 03:07:47 --> Helper loaded: my_helper
INFO - 2022-05-17 03:07:48 --> Database Driver Class Initialized
DEBUG - 2022-05-17 03:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-17 03:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-17 03:07:48 --> Controller Class Initialized
INFO - 2022-05-17 03:07:48 --> Config Class Initialized
INFO - 2022-05-17 03:07:48 --> Hooks Class Initialized
DEBUG - 2022-05-17 03:07:48 --> UTF-8 Support Enabled
INFO - 2022-05-17 03:07:48 --> Utf8 Class Initialized
INFO - 2022-05-17 03:07:48 --> URI Class Initialized
INFO - 2022-05-17 03:07:48 --> Router Class Initialized
INFO - 2022-05-17 03:07:48 --> Output Class Initialized
INFO - 2022-05-17 03:07:48 --> Security Class Initialized
DEBUG - 2022-05-17 03:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-17 03:07:48 --> Input Class Initialized
INFO - 2022-05-17 03:07:48 --> Language Class Initialized
INFO - 2022-05-17 03:07:48 --> Language Class Initialized
INFO - 2022-05-17 03:07:48 --> Config Class Initialized
INFO - 2022-05-17 03:07:48 --> Loader Class Initialized
INFO - 2022-05-17 03:07:48 --> Helper loaded: url_helper
INFO - 2022-05-17 03:07:48 --> Helper loaded: file_helper
INFO - 2022-05-17 03:07:48 --> Helper loaded: form_helper
INFO - 2022-05-17 03:07:48 --> Helper loaded: my_helper
INFO - 2022-05-17 03:07:48 --> Database Driver Class Initialized
DEBUG - 2022-05-17 03:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-17 03:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-17 03:07:48 --> Controller Class Initialized
DEBUG - 2022-05-17 03:07:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-17 03:07:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-17 03:07:48 --> Final output sent to browser
DEBUG - 2022-05-17 03:07:48 --> Total execution time: 0.2464
