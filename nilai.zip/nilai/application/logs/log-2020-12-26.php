<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-26 01:44:09 --> Config Class Initialized
INFO - 2020-12-26 01:44:09 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:44:09 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:44:09 --> Utf8 Class Initialized
INFO - 2020-12-26 01:44:09 --> URI Class Initialized
DEBUG - 2020-12-26 01:44:09 --> No URI present. Default controller set.
INFO - 2020-12-26 01:44:09 --> Router Class Initialized
INFO - 2020-12-26 01:44:09 --> Output Class Initialized
INFO - 2020-12-26 01:44:09 --> Security Class Initialized
DEBUG - 2020-12-26 01:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:44:09 --> Input Class Initialized
INFO - 2020-12-26 01:44:09 --> Language Class Initialized
INFO - 2020-12-26 01:44:09 --> Language Class Initialized
INFO - 2020-12-26 01:44:09 --> Config Class Initialized
INFO - 2020-12-26 01:44:09 --> Loader Class Initialized
INFO - 2020-12-26 01:44:09 --> Helper loaded: url_helper
INFO - 2020-12-26 01:44:09 --> Helper loaded: file_helper
INFO - 2020-12-26 01:44:09 --> Helper loaded: form_helper
INFO - 2020-12-26 01:44:09 --> Helper loaded: my_helper
INFO - 2020-12-26 01:44:09 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:44:09 --> Controller Class Initialized
INFO - 2020-12-26 01:44:09 --> Config Class Initialized
INFO - 2020-12-26 01:44:09 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:44:09 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:44:09 --> Utf8 Class Initialized
INFO - 2020-12-26 01:44:09 --> URI Class Initialized
INFO - 2020-12-26 01:44:09 --> Router Class Initialized
INFO - 2020-12-26 01:44:09 --> Output Class Initialized
INFO - 2020-12-26 01:44:09 --> Security Class Initialized
DEBUG - 2020-12-26 01:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:44:09 --> Input Class Initialized
INFO - 2020-12-26 01:44:09 --> Language Class Initialized
INFO - 2020-12-26 01:44:09 --> Language Class Initialized
INFO - 2020-12-26 01:44:10 --> Config Class Initialized
INFO - 2020-12-26 01:44:10 --> Loader Class Initialized
INFO - 2020-12-26 01:44:10 --> Helper loaded: url_helper
INFO - 2020-12-26 01:44:10 --> Helper loaded: file_helper
INFO - 2020-12-26 01:44:10 --> Helper loaded: form_helper
INFO - 2020-12-26 01:44:10 --> Helper loaded: my_helper
INFO - 2020-12-26 01:44:10 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:44:10 --> Controller Class Initialized
DEBUG - 2020-12-26 01:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-26 01:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 01:44:10 --> Final output sent to browser
DEBUG - 2020-12-26 01:44:10 --> Total execution time: 0.1934
INFO - 2020-12-26 01:44:16 --> Config Class Initialized
INFO - 2020-12-26 01:44:16 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:44:16 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:44:16 --> Utf8 Class Initialized
INFO - 2020-12-26 01:44:16 --> URI Class Initialized
INFO - 2020-12-26 01:44:16 --> Router Class Initialized
INFO - 2020-12-26 01:44:16 --> Output Class Initialized
INFO - 2020-12-26 01:44:16 --> Security Class Initialized
DEBUG - 2020-12-26 01:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:44:16 --> Input Class Initialized
INFO - 2020-12-26 01:44:16 --> Language Class Initialized
INFO - 2020-12-26 01:44:16 --> Language Class Initialized
INFO - 2020-12-26 01:44:16 --> Config Class Initialized
INFO - 2020-12-26 01:44:16 --> Loader Class Initialized
INFO - 2020-12-26 01:44:16 --> Helper loaded: url_helper
INFO - 2020-12-26 01:44:16 --> Helper loaded: file_helper
INFO - 2020-12-26 01:44:16 --> Helper loaded: form_helper
INFO - 2020-12-26 01:44:16 --> Helper loaded: my_helper
INFO - 2020-12-26 01:44:16 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:44:16 --> Controller Class Initialized
INFO - 2020-12-26 01:44:16 --> Helper loaded: cookie_helper
INFO - 2020-12-26 01:44:16 --> Final output sent to browser
DEBUG - 2020-12-26 01:44:16 --> Total execution time: 0.3036
INFO - 2020-12-26 01:44:17 --> Config Class Initialized
INFO - 2020-12-26 01:44:17 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:44:17 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:44:17 --> Utf8 Class Initialized
INFO - 2020-12-26 01:44:17 --> URI Class Initialized
INFO - 2020-12-26 01:44:17 --> Router Class Initialized
INFO - 2020-12-26 01:44:17 --> Output Class Initialized
INFO - 2020-12-26 01:44:17 --> Security Class Initialized
DEBUG - 2020-12-26 01:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:44:17 --> Input Class Initialized
INFO - 2020-12-26 01:44:17 --> Language Class Initialized
INFO - 2020-12-26 01:44:17 --> Language Class Initialized
INFO - 2020-12-26 01:44:17 --> Config Class Initialized
INFO - 2020-12-26 01:44:17 --> Loader Class Initialized
INFO - 2020-12-26 01:44:17 --> Helper loaded: url_helper
INFO - 2020-12-26 01:44:17 --> Helper loaded: file_helper
INFO - 2020-12-26 01:44:17 --> Helper loaded: form_helper
INFO - 2020-12-26 01:44:17 --> Helper loaded: my_helper
INFO - 2020-12-26 01:44:17 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:44:17 --> Controller Class Initialized
DEBUG - 2020-12-26 01:44:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-26 01:44:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 01:44:17 --> Final output sent to browser
DEBUG - 2020-12-26 01:44:17 --> Total execution time: 0.3716
INFO - 2020-12-26 01:44:24 --> Config Class Initialized
INFO - 2020-12-26 01:44:24 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:44:24 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:44:24 --> Utf8 Class Initialized
INFO - 2020-12-26 01:44:24 --> URI Class Initialized
INFO - 2020-12-26 01:44:24 --> Router Class Initialized
INFO - 2020-12-26 01:44:24 --> Output Class Initialized
INFO - 2020-12-26 01:44:24 --> Security Class Initialized
DEBUG - 2020-12-26 01:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:44:24 --> Input Class Initialized
INFO - 2020-12-26 01:44:24 --> Language Class Initialized
INFO - 2020-12-26 01:44:24 --> Language Class Initialized
INFO - 2020-12-26 01:44:24 --> Config Class Initialized
INFO - 2020-12-26 01:44:24 --> Loader Class Initialized
INFO - 2020-12-26 01:44:24 --> Helper loaded: url_helper
INFO - 2020-12-26 01:44:24 --> Helper loaded: file_helper
INFO - 2020-12-26 01:44:24 --> Helper loaded: form_helper
INFO - 2020-12-26 01:44:24 --> Helper loaded: my_helper
INFO - 2020-12-26 01:44:24 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:44:24 --> Controller Class Initialized
DEBUG - 2020-12-26 01:44:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 01:44:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 01:44:24 --> Final output sent to browser
DEBUG - 2020-12-26 01:44:24 --> Total execution time: 0.2155
INFO - 2020-12-26 01:46:55 --> Config Class Initialized
INFO - 2020-12-26 01:46:55 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:46:55 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:46:55 --> Utf8 Class Initialized
INFO - 2020-12-26 01:46:55 --> URI Class Initialized
INFO - 2020-12-26 01:46:55 --> Router Class Initialized
INFO - 2020-12-26 01:46:55 --> Output Class Initialized
INFO - 2020-12-26 01:46:55 --> Security Class Initialized
DEBUG - 2020-12-26 01:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:46:55 --> Input Class Initialized
INFO - 2020-12-26 01:46:55 --> Language Class Initialized
INFO - 2020-12-26 01:46:55 --> Language Class Initialized
INFO - 2020-12-26 01:46:55 --> Config Class Initialized
INFO - 2020-12-26 01:46:55 --> Loader Class Initialized
INFO - 2020-12-26 01:46:55 --> Helper loaded: url_helper
INFO - 2020-12-26 01:46:55 --> Helper loaded: file_helper
INFO - 2020-12-26 01:46:55 --> Helper loaded: form_helper
INFO - 2020-12-26 01:46:55 --> Helper loaded: my_helper
INFO - 2020-12-26 01:46:55 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:46:55 --> Controller Class Initialized
DEBUG - 2020-12-26 01:46:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 01:46:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 01:46:55 --> Final output sent to browser
DEBUG - 2020-12-26 01:46:55 --> Total execution time: 0.2496
INFO - 2020-12-26 01:51:48 --> Config Class Initialized
INFO - 2020-12-26 01:51:48 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:51:48 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:51:48 --> Utf8 Class Initialized
INFO - 2020-12-26 01:51:48 --> URI Class Initialized
INFO - 2020-12-26 01:51:48 --> Router Class Initialized
INFO - 2020-12-26 01:51:48 --> Output Class Initialized
INFO - 2020-12-26 01:51:48 --> Security Class Initialized
DEBUG - 2020-12-26 01:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:51:48 --> Input Class Initialized
INFO - 2020-12-26 01:51:48 --> Language Class Initialized
INFO - 2020-12-26 01:51:48 --> Language Class Initialized
INFO - 2020-12-26 01:51:48 --> Config Class Initialized
INFO - 2020-12-26 01:51:48 --> Loader Class Initialized
INFO - 2020-12-26 01:51:48 --> Helper loaded: url_helper
INFO - 2020-12-26 01:51:48 --> Helper loaded: file_helper
INFO - 2020-12-26 01:51:48 --> Helper loaded: form_helper
INFO - 2020-12-26 01:51:48 --> Helper loaded: my_helper
INFO - 2020-12-26 01:51:48 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:51:48 --> Controller Class Initialized
DEBUG - 2020-12-26 01:51:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 01:51:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 01:51:48 --> Final output sent to browser
DEBUG - 2020-12-26 01:51:48 --> Total execution time: 0.2049
INFO - 2020-12-26 01:51:50 --> Config Class Initialized
INFO - 2020-12-26 01:51:50 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:51:50 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:51:50 --> Utf8 Class Initialized
INFO - 2020-12-26 01:51:50 --> URI Class Initialized
INFO - 2020-12-26 01:51:50 --> Router Class Initialized
INFO - 2020-12-26 01:51:50 --> Output Class Initialized
INFO - 2020-12-26 01:51:50 --> Security Class Initialized
DEBUG - 2020-12-26 01:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:51:50 --> Input Class Initialized
INFO - 2020-12-26 01:51:50 --> Language Class Initialized
INFO - 2020-12-26 01:51:50 --> Language Class Initialized
INFO - 2020-12-26 01:51:50 --> Config Class Initialized
INFO - 2020-12-26 01:51:50 --> Loader Class Initialized
INFO - 2020-12-26 01:51:50 --> Helper loaded: url_helper
INFO - 2020-12-26 01:51:50 --> Helper loaded: file_helper
INFO - 2020-12-26 01:51:50 --> Helper loaded: form_helper
INFO - 2020-12-26 01:51:50 --> Helper loaded: my_helper
INFO - 2020-12-26 01:51:50 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:51:50 --> Controller Class Initialized
DEBUG - 2020-12-26 01:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 01:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 01:51:50 --> Final output sent to browser
DEBUG - 2020-12-26 01:51:50 --> Total execution time: 0.2007
INFO - 2020-12-26 01:52:17 --> Config Class Initialized
INFO - 2020-12-26 01:52:17 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:52:17 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:52:17 --> Utf8 Class Initialized
INFO - 2020-12-26 01:52:17 --> URI Class Initialized
INFO - 2020-12-26 01:52:17 --> Router Class Initialized
INFO - 2020-12-26 01:52:17 --> Output Class Initialized
INFO - 2020-12-26 01:52:17 --> Security Class Initialized
DEBUG - 2020-12-26 01:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:52:17 --> Input Class Initialized
INFO - 2020-12-26 01:52:17 --> Language Class Initialized
INFO - 2020-12-26 01:52:17 --> Language Class Initialized
INFO - 2020-12-26 01:52:17 --> Config Class Initialized
INFO - 2020-12-26 01:52:17 --> Loader Class Initialized
INFO - 2020-12-26 01:52:17 --> Helper loaded: url_helper
INFO - 2020-12-26 01:52:17 --> Helper loaded: file_helper
INFO - 2020-12-26 01:52:17 --> Helper loaded: form_helper
INFO - 2020-12-26 01:52:17 --> Helper loaded: my_helper
INFO - 2020-12-26 01:52:17 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:52:17 --> Controller Class Initialized
DEBUG - 2020-12-26 01:52:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 01:52:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 01:52:17 --> Final output sent to browser
DEBUG - 2020-12-26 01:52:17 --> Total execution time: 0.2643
INFO - 2020-12-26 01:55:12 --> Config Class Initialized
INFO - 2020-12-26 01:55:12 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:55:12 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:55:12 --> Utf8 Class Initialized
INFO - 2020-12-26 01:55:12 --> URI Class Initialized
INFO - 2020-12-26 01:55:12 --> Router Class Initialized
INFO - 2020-12-26 01:55:12 --> Output Class Initialized
INFO - 2020-12-26 01:55:12 --> Security Class Initialized
DEBUG - 2020-12-26 01:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:55:12 --> Input Class Initialized
INFO - 2020-12-26 01:55:12 --> Language Class Initialized
INFO - 2020-12-26 01:55:12 --> Language Class Initialized
INFO - 2020-12-26 01:55:12 --> Config Class Initialized
INFO - 2020-12-26 01:55:12 --> Loader Class Initialized
INFO - 2020-12-26 01:55:12 --> Helper loaded: url_helper
INFO - 2020-12-26 01:55:12 --> Helper loaded: file_helper
INFO - 2020-12-26 01:55:12 --> Helper loaded: form_helper
INFO - 2020-12-26 01:55:12 --> Helper loaded: my_helper
INFO - 2020-12-26 01:55:12 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:55:12 --> Controller Class Initialized
ERROR - 2020-12-26 01:55:12 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
INFO - 2020-12-26 01:55:30 --> Config Class Initialized
INFO - 2020-12-26 01:55:30 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:55:30 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:55:30 --> Utf8 Class Initialized
INFO - 2020-12-26 01:55:30 --> URI Class Initialized
INFO - 2020-12-26 01:55:30 --> Router Class Initialized
INFO - 2020-12-26 01:55:30 --> Output Class Initialized
INFO - 2020-12-26 01:55:30 --> Security Class Initialized
DEBUG - 2020-12-26 01:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:55:30 --> Input Class Initialized
INFO - 2020-12-26 01:55:30 --> Language Class Initialized
INFO - 2020-12-26 01:55:30 --> Language Class Initialized
INFO - 2020-12-26 01:55:30 --> Config Class Initialized
INFO - 2020-12-26 01:55:30 --> Loader Class Initialized
INFO - 2020-12-26 01:55:30 --> Helper loaded: url_helper
INFO - 2020-12-26 01:55:30 --> Helper loaded: file_helper
INFO - 2020-12-26 01:55:30 --> Helper loaded: form_helper
INFO - 2020-12-26 01:55:30 --> Helper loaded: my_helper
INFO - 2020-12-26 01:55:30 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:55:30 --> Controller Class Initialized
DEBUG - 2020-12-26 01:55:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 01:55:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 01:55:30 --> Final output sent to browser
DEBUG - 2020-12-26 01:55:30 --> Total execution time: 0.2205
INFO - 2020-12-26 01:58:57 --> Config Class Initialized
INFO - 2020-12-26 01:58:58 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:58:58 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:58:58 --> Utf8 Class Initialized
INFO - 2020-12-26 01:58:58 --> URI Class Initialized
INFO - 2020-12-26 01:58:58 --> Router Class Initialized
INFO - 2020-12-26 01:58:58 --> Output Class Initialized
INFO - 2020-12-26 01:58:58 --> Security Class Initialized
DEBUG - 2020-12-26 01:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:58:58 --> Input Class Initialized
INFO - 2020-12-26 01:58:58 --> Language Class Initialized
INFO - 2020-12-26 01:58:58 --> Language Class Initialized
INFO - 2020-12-26 01:58:58 --> Config Class Initialized
INFO - 2020-12-26 01:58:58 --> Loader Class Initialized
INFO - 2020-12-26 01:58:58 --> Helper loaded: url_helper
INFO - 2020-12-26 01:58:58 --> Helper loaded: file_helper
INFO - 2020-12-26 01:58:58 --> Helper loaded: form_helper
INFO - 2020-12-26 01:58:58 --> Helper loaded: my_helper
INFO - 2020-12-26 01:58:58 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:58:58 --> Controller Class Initialized
ERROR - 2020-12-26 01:58:58 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ':' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 71
INFO - 2020-12-26 01:59:25 --> Config Class Initialized
INFO - 2020-12-26 01:59:25 --> Hooks Class Initialized
DEBUG - 2020-12-26 01:59:25 --> UTF-8 Support Enabled
INFO - 2020-12-26 01:59:25 --> Utf8 Class Initialized
INFO - 2020-12-26 01:59:25 --> URI Class Initialized
INFO - 2020-12-26 01:59:25 --> Router Class Initialized
INFO - 2020-12-26 01:59:25 --> Output Class Initialized
INFO - 2020-12-26 01:59:25 --> Security Class Initialized
DEBUG - 2020-12-26 01:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 01:59:25 --> Input Class Initialized
INFO - 2020-12-26 01:59:25 --> Language Class Initialized
INFO - 2020-12-26 01:59:25 --> Language Class Initialized
INFO - 2020-12-26 01:59:25 --> Config Class Initialized
INFO - 2020-12-26 01:59:25 --> Loader Class Initialized
INFO - 2020-12-26 01:59:25 --> Helper loaded: url_helper
INFO - 2020-12-26 01:59:25 --> Helper loaded: file_helper
INFO - 2020-12-26 01:59:25 --> Helper loaded: form_helper
INFO - 2020-12-26 01:59:25 --> Helper loaded: my_helper
INFO - 2020-12-26 01:59:25 --> Database Driver Class Initialized
DEBUG - 2020-12-26 01:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 01:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 01:59:25 --> Controller Class Initialized
DEBUG - 2020-12-26 01:59:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 01:59:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 01:59:25 --> Final output sent to browser
DEBUG - 2020-12-26 01:59:25 --> Total execution time: 0.2238
INFO - 2020-12-26 02:01:19 --> Config Class Initialized
INFO - 2020-12-26 02:01:19 --> Hooks Class Initialized
DEBUG - 2020-12-26 02:01:19 --> UTF-8 Support Enabled
INFO - 2020-12-26 02:01:19 --> Utf8 Class Initialized
INFO - 2020-12-26 02:01:19 --> URI Class Initialized
INFO - 2020-12-26 02:01:19 --> Router Class Initialized
INFO - 2020-12-26 02:01:19 --> Output Class Initialized
INFO - 2020-12-26 02:01:19 --> Security Class Initialized
DEBUG - 2020-12-26 02:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 02:01:19 --> Input Class Initialized
INFO - 2020-12-26 02:01:19 --> Language Class Initialized
INFO - 2020-12-26 02:01:19 --> Language Class Initialized
INFO - 2020-12-26 02:01:19 --> Config Class Initialized
INFO - 2020-12-26 02:01:19 --> Loader Class Initialized
INFO - 2020-12-26 02:01:19 --> Helper loaded: url_helper
INFO - 2020-12-26 02:01:19 --> Helper loaded: file_helper
INFO - 2020-12-26 02:01:19 --> Helper loaded: form_helper
INFO - 2020-12-26 02:01:19 --> Helper loaded: my_helper
INFO - 2020-12-26 02:01:19 --> Database Driver Class Initialized
DEBUG - 2020-12-26 02:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 02:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 02:01:19 --> Controller Class Initialized
DEBUG - 2020-12-26 02:01:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 02:01:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 02:01:19 --> Final output sent to browser
DEBUG - 2020-12-26 02:01:19 --> Total execution time: 0.2563
INFO - 2020-12-26 02:43:32 --> Config Class Initialized
INFO - 2020-12-26 02:43:32 --> Hooks Class Initialized
DEBUG - 2020-12-26 02:43:32 --> UTF-8 Support Enabled
INFO - 2020-12-26 02:43:32 --> Utf8 Class Initialized
INFO - 2020-12-26 02:43:32 --> URI Class Initialized
INFO - 2020-12-26 02:43:32 --> Router Class Initialized
INFO - 2020-12-26 02:43:32 --> Output Class Initialized
INFO - 2020-12-26 02:43:32 --> Security Class Initialized
DEBUG - 2020-12-26 02:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 02:43:32 --> Input Class Initialized
INFO - 2020-12-26 02:43:32 --> Language Class Initialized
ERROR - 2020-12-26 02:43:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 88
INFO - 2020-12-26 02:44:02 --> Config Class Initialized
INFO - 2020-12-26 02:44:02 --> Hooks Class Initialized
DEBUG - 2020-12-26 02:44:02 --> UTF-8 Support Enabled
INFO - 2020-12-26 02:44:02 --> Utf8 Class Initialized
INFO - 2020-12-26 02:44:02 --> URI Class Initialized
INFO - 2020-12-26 02:44:02 --> Router Class Initialized
INFO - 2020-12-26 02:44:02 --> Output Class Initialized
INFO - 2020-12-26 02:44:02 --> Security Class Initialized
DEBUG - 2020-12-26 02:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 02:44:02 --> Input Class Initialized
INFO - 2020-12-26 02:44:02 --> Language Class Initialized
INFO - 2020-12-26 02:44:02 --> Language Class Initialized
INFO - 2020-12-26 02:44:02 --> Config Class Initialized
INFO - 2020-12-26 02:44:02 --> Loader Class Initialized
INFO - 2020-12-26 02:44:02 --> Helper loaded: url_helper
INFO - 2020-12-26 02:44:02 --> Helper loaded: file_helper
INFO - 2020-12-26 02:44:02 --> Helper loaded: form_helper
INFO - 2020-12-26 02:44:02 --> Helper loaded: my_helper
INFO - 2020-12-26 02:44:02 --> Database Driver Class Initialized
DEBUG - 2020-12-26 02:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 02:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 02:44:02 --> Controller Class Initialized
DEBUG - 2020-12-26 02:44:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 02:44:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 02:44:02 --> Final output sent to browser
DEBUG - 2020-12-26 02:44:02 --> Total execution time: 0.2402
INFO - 2020-12-26 15:58:52 --> Config Class Initialized
INFO - 2020-12-26 15:58:52 --> Hooks Class Initialized
DEBUG - 2020-12-26 15:58:52 --> UTF-8 Support Enabled
INFO - 2020-12-26 15:58:52 --> Utf8 Class Initialized
INFO - 2020-12-26 15:58:52 --> URI Class Initialized
DEBUG - 2020-12-26 15:58:52 --> No URI present. Default controller set.
INFO - 2020-12-26 15:58:52 --> Router Class Initialized
INFO - 2020-12-26 15:58:52 --> Output Class Initialized
INFO - 2020-12-26 15:58:52 --> Security Class Initialized
DEBUG - 2020-12-26 15:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 15:58:53 --> Input Class Initialized
INFO - 2020-12-26 15:58:53 --> Language Class Initialized
INFO - 2020-12-26 15:58:53 --> Language Class Initialized
INFO - 2020-12-26 15:58:53 --> Config Class Initialized
INFO - 2020-12-26 15:58:53 --> Loader Class Initialized
INFO - 2020-12-26 15:58:53 --> Helper loaded: url_helper
INFO - 2020-12-26 15:58:53 --> Helper loaded: file_helper
INFO - 2020-12-26 15:58:53 --> Helper loaded: form_helper
INFO - 2020-12-26 15:58:53 --> Helper loaded: my_helper
INFO - 2020-12-26 15:58:53 --> Database Driver Class Initialized
DEBUG - 2020-12-26 15:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 15:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 15:58:53 --> Controller Class Initialized
INFO - 2020-12-26 15:58:53 --> Config Class Initialized
INFO - 2020-12-26 15:58:53 --> Hooks Class Initialized
DEBUG - 2020-12-26 15:58:53 --> UTF-8 Support Enabled
INFO - 2020-12-26 15:58:53 --> Utf8 Class Initialized
INFO - 2020-12-26 15:58:53 --> URI Class Initialized
INFO - 2020-12-26 15:58:53 --> Router Class Initialized
INFO - 2020-12-26 15:58:53 --> Output Class Initialized
INFO - 2020-12-26 15:58:53 --> Security Class Initialized
DEBUG - 2020-12-26 15:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 15:58:53 --> Input Class Initialized
INFO - 2020-12-26 15:58:53 --> Language Class Initialized
INFO - 2020-12-26 15:58:53 --> Language Class Initialized
INFO - 2020-12-26 15:58:53 --> Config Class Initialized
INFO - 2020-12-26 15:58:53 --> Loader Class Initialized
INFO - 2020-12-26 15:58:53 --> Helper loaded: url_helper
INFO - 2020-12-26 15:58:53 --> Helper loaded: file_helper
INFO - 2020-12-26 15:58:53 --> Helper loaded: form_helper
INFO - 2020-12-26 15:58:53 --> Helper loaded: my_helper
INFO - 2020-12-26 15:58:54 --> Database Driver Class Initialized
DEBUG - 2020-12-26 15:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 15:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 15:58:54 --> Controller Class Initialized
DEBUG - 2020-12-26 15:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-26 15:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 15:58:54 --> Final output sent to browser
DEBUG - 2020-12-26 15:58:54 --> Total execution time: 0.8081
INFO - 2020-12-26 15:59:00 --> Config Class Initialized
INFO - 2020-12-26 15:59:00 --> Hooks Class Initialized
DEBUG - 2020-12-26 15:59:00 --> UTF-8 Support Enabled
INFO - 2020-12-26 15:59:00 --> Utf8 Class Initialized
INFO - 2020-12-26 15:59:00 --> URI Class Initialized
INFO - 2020-12-26 15:59:00 --> Router Class Initialized
INFO - 2020-12-26 15:59:00 --> Output Class Initialized
INFO - 2020-12-26 15:59:00 --> Security Class Initialized
DEBUG - 2020-12-26 15:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 15:59:00 --> Input Class Initialized
INFO - 2020-12-26 15:59:00 --> Language Class Initialized
INFO - 2020-12-26 15:59:00 --> Language Class Initialized
INFO - 2020-12-26 15:59:00 --> Config Class Initialized
INFO - 2020-12-26 15:59:00 --> Loader Class Initialized
INFO - 2020-12-26 15:59:00 --> Helper loaded: url_helper
INFO - 2020-12-26 15:59:01 --> Helper loaded: file_helper
INFO - 2020-12-26 15:59:01 --> Helper loaded: form_helper
INFO - 2020-12-26 15:59:01 --> Helper loaded: my_helper
INFO - 2020-12-26 15:59:01 --> Database Driver Class Initialized
DEBUG - 2020-12-26 15:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 15:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 15:59:01 --> Controller Class Initialized
INFO - 2020-12-26 15:59:01 --> Helper loaded: cookie_helper
INFO - 2020-12-26 15:59:01 --> Final output sent to browser
DEBUG - 2020-12-26 15:59:01 --> Total execution time: 0.5782
INFO - 2020-12-26 15:59:06 --> Config Class Initialized
INFO - 2020-12-26 15:59:06 --> Hooks Class Initialized
DEBUG - 2020-12-26 15:59:06 --> UTF-8 Support Enabled
INFO - 2020-12-26 15:59:06 --> Utf8 Class Initialized
INFO - 2020-12-26 15:59:06 --> URI Class Initialized
INFO - 2020-12-26 15:59:06 --> Router Class Initialized
INFO - 2020-12-26 15:59:06 --> Output Class Initialized
INFO - 2020-12-26 15:59:06 --> Security Class Initialized
DEBUG - 2020-12-26 15:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 15:59:06 --> Input Class Initialized
INFO - 2020-12-26 15:59:06 --> Language Class Initialized
INFO - 2020-12-26 15:59:06 --> Language Class Initialized
INFO - 2020-12-26 15:59:06 --> Config Class Initialized
INFO - 2020-12-26 15:59:06 --> Loader Class Initialized
INFO - 2020-12-26 15:59:06 --> Helper loaded: url_helper
INFO - 2020-12-26 15:59:06 --> Helper loaded: file_helper
INFO - 2020-12-26 15:59:06 --> Helper loaded: form_helper
INFO - 2020-12-26 15:59:06 --> Helper loaded: my_helper
INFO - 2020-12-26 15:59:06 --> Database Driver Class Initialized
DEBUG - 2020-12-26 15:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 15:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 15:59:07 --> Controller Class Initialized
DEBUG - 2020-12-26 15:59:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-26 15:59:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 15:59:07 --> Final output sent to browser
DEBUG - 2020-12-26 15:59:07 --> Total execution time: 0.8407
INFO - 2020-12-26 15:59:14 --> Config Class Initialized
INFO - 2020-12-26 15:59:14 --> Hooks Class Initialized
DEBUG - 2020-12-26 15:59:14 --> UTF-8 Support Enabled
INFO - 2020-12-26 15:59:14 --> Utf8 Class Initialized
INFO - 2020-12-26 15:59:14 --> URI Class Initialized
INFO - 2020-12-26 15:59:14 --> Router Class Initialized
INFO - 2020-12-26 15:59:14 --> Output Class Initialized
INFO - 2020-12-26 15:59:15 --> Security Class Initialized
DEBUG - 2020-12-26 15:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 15:59:15 --> Input Class Initialized
INFO - 2020-12-26 15:59:15 --> Language Class Initialized
ERROR - 2020-12-26 15:59:15 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 81
INFO - 2020-12-26 16:00:18 --> Config Class Initialized
INFO - 2020-12-26 16:00:18 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:00:18 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:00:18 --> Utf8 Class Initialized
INFO - 2020-12-26 16:00:18 --> URI Class Initialized
INFO - 2020-12-26 16:00:18 --> Router Class Initialized
INFO - 2020-12-26 16:00:19 --> Output Class Initialized
INFO - 2020-12-26 16:00:19 --> Security Class Initialized
DEBUG - 2020-12-26 16:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:00:19 --> Input Class Initialized
INFO - 2020-12-26 16:00:19 --> Language Class Initialized
INFO - 2020-12-26 16:00:19 --> Language Class Initialized
INFO - 2020-12-26 16:00:19 --> Config Class Initialized
INFO - 2020-12-26 16:00:19 --> Loader Class Initialized
INFO - 2020-12-26 16:00:19 --> Helper loaded: url_helper
INFO - 2020-12-26 16:00:19 --> Helper loaded: file_helper
INFO - 2020-12-26 16:00:19 --> Helper loaded: form_helper
INFO - 2020-12-26 16:00:19 --> Helper loaded: my_helper
INFO - 2020-12-26 16:00:19 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:00:19 --> Controller Class Initialized
DEBUG - 2020-12-26 16:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:00:19 --> Final output sent to browser
DEBUG - 2020-12-26 16:00:19 --> Total execution time: 0.8839
INFO - 2020-12-26 16:02:21 --> Config Class Initialized
INFO - 2020-12-26 16:02:21 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:02:21 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:02:21 --> Utf8 Class Initialized
INFO - 2020-12-26 16:02:21 --> URI Class Initialized
INFO - 2020-12-26 16:02:21 --> Router Class Initialized
INFO - 2020-12-26 16:02:21 --> Output Class Initialized
INFO - 2020-12-26 16:02:21 --> Security Class Initialized
DEBUG - 2020-12-26 16:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:02:21 --> Input Class Initialized
INFO - 2020-12-26 16:02:21 --> Language Class Initialized
INFO - 2020-12-26 16:02:21 --> Language Class Initialized
INFO - 2020-12-26 16:02:21 --> Config Class Initialized
INFO - 2020-12-26 16:02:21 --> Loader Class Initialized
INFO - 2020-12-26 16:02:21 --> Helper loaded: url_helper
INFO - 2020-12-26 16:02:21 --> Helper loaded: file_helper
INFO - 2020-12-26 16:02:21 --> Helper loaded: form_helper
INFO - 2020-12-26 16:02:21 --> Helper loaded: my_helper
INFO - 2020-12-26 16:02:21 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:02:21 --> Controller Class Initialized
DEBUG - 2020-12-26 16:02:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:02:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:02:21 --> Final output sent to browser
DEBUG - 2020-12-26 16:02:21 --> Total execution time: 0.8209
INFO - 2020-12-26 16:03:13 --> Config Class Initialized
INFO - 2020-12-26 16:03:13 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:03:13 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:03:13 --> Utf8 Class Initialized
INFO - 2020-12-26 16:03:13 --> URI Class Initialized
INFO - 2020-12-26 16:03:13 --> Router Class Initialized
INFO - 2020-12-26 16:03:13 --> Output Class Initialized
INFO - 2020-12-26 16:03:13 --> Security Class Initialized
DEBUG - 2020-12-26 16:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:03:13 --> Input Class Initialized
INFO - 2020-12-26 16:03:13 --> Language Class Initialized
INFO - 2020-12-26 16:03:13 --> Language Class Initialized
INFO - 2020-12-26 16:03:13 --> Config Class Initialized
INFO - 2020-12-26 16:03:13 --> Loader Class Initialized
INFO - 2020-12-26 16:03:13 --> Helper loaded: url_helper
INFO - 2020-12-26 16:03:13 --> Helper loaded: file_helper
INFO - 2020-12-26 16:03:13 --> Helper loaded: form_helper
INFO - 2020-12-26 16:03:13 --> Helper loaded: my_helper
INFO - 2020-12-26 16:03:13 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:03:13 --> Controller Class Initialized
DEBUG - 2020-12-26 16:03:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:03:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:03:14 --> Final output sent to browser
DEBUG - 2020-12-26 16:03:14 --> Total execution time: 0.6586
INFO - 2020-12-26 16:04:05 --> Config Class Initialized
INFO - 2020-12-26 16:04:05 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:05 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:05 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:05 --> URI Class Initialized
INFO - 2020-12-26 16:04:05 --> Router Class Initialized
INFO - 2020-12-26 16:04:05 --> Output Class Initialized
INFO - 2020-12-26 16:04:05 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:05 --> Input Class Initialized
INFO - 2020-12-26 16:04:05 --> Language Class Initialized
INFO - 2020-12-26 16:04:05 --> Language Class Initialized
INFO - 2020-12-26 16:04:05 --> Config Class Initialized
INFO - 2020-12-26 16:04:05 --> Loader Class Initialized
INFO - 2020-12-26 16:04:05 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:05 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:05 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:05 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:05 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:05 --> Controller Class Initialized
INFO - 2020-12-26 16:04:05 --> Helper loaded: cookie_helper
INFO - 2020-12-26 16:04:05 --> Config Class Initialized
INFO - 2020-12-26 16:04:05 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:05 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:05 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:05 --> URI Class Initialized
INFO - 2020-12-26 16:04:05 --> Router Class Initialized
INFO - 2020-12-26 16:04:05 --> Output Class Initialized
INFO - 2020-12-26 16:04:05 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:05 --> Input Class Initialized
INFO - 2020-12-26 16:04:05 --> Language Class Initialized
INFO - 2020-12-26 16:04:05 --> Language Class Initialized
INFO - 2020-12-26 16:04:05 --> Config Class Initialized
INFO - 2020-12-26 16:04:05 --> Loader Class Initialized
INFO - 2020-12-26 16:04:05 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:06 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:06 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:06 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:06 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:06 --> Controller Class Initialized
DEBUG - 2020-12-26 16:04:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-26 16:04:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:04:06 --> Final output sent to browser
DEBUG - 2020-12-26 16:04:06 --> Total execution time: 0.7397
INFO - 2020-12-26 16:04:11 --> Config Class Initialized
INFO - 2020-12-26 16:04:11 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:11 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:11 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:11 --> URI Class Initialized
INFO - 2020-12-26 16:04:11 --> Router Class Initialized
INFO - 2020-12-26 16:04:11 --> Output Class Initialized
INFO - 2020-12-26 16:04:11 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:11 --> Input Class Initialized
INFO - 2020-12-26 16:04:11 --> Language Class Initialized
INFO - 2020-12-26 16:04:12 --> Language Class Initialized
INFO - 2020-12-26 16:04:12 --> Config Class Initialized
INFO - 2020-12-26 16:04:12 --> Loader Class Initialized
INFO - 2020-12-26 16:04:12 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:12 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:12 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:12 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:12 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:12 --> Controller Class Initialized
INFO - 2020-12-26 16:04:12 --> Helper loaded: cookie_helper
INFO - 2020-12-26 16:04:12 --> Final output sent to browser
DEBUG - 2020-12-26 16:04:12 --> Total execution time: 0.7005
INFO - 2020-12-26 16:04:13 --> Config Class Initialized
INFO - 2020-12-26 16:04:13 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:13 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:13 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:13 --> URI Class Initialized
INFO - 2020-12-26 16:04:13 --> Router Class Initialized
INFO - 2020-12-26 16:04:13 --> Output Class Initialized
INFO - 2020-12-26 16:04:13 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:13 --> Input Class Initialized
INFO - 2020-12-26 16:04:13 --> Language Class Initialized
INFO - 2020-12-26 16:04:13 --> Language Class Initialized
INFO - 2020-12-26 16:04:13 --> Config Class Initialized
INFO - 2020-12-26 16:04:13 --> Loader Class Initialized
INFO - 2020-12-26 16:04:13 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:13 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:13 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:13 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:13 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:13 --> Controller Class Initialized
DEBUG - 2020-12-26 16:04:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-26 16:04:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:04:13 --> Final output sent to browser
DEBUG - 2020-12-26 16:04:13 --> Total execution time: 0.7213
INFO - 2020-12-26 16:04:15 --> Config Class Initialized
INFO - 2020-12-26 16:04:15 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:15 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:15 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:15 --> URI Class Initialized
INFO - 2020-12-26 16:04:15 --> Router Class Initialized
INFO - 2020-12-26 16:04:15 --> Output Class Initialized
INFO - 2020-12-26 16:04:15 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:15 --> Input Class Initialized
INFO - 2020-12-26 16:04:15 --> Language Class Initialized
INFO - 2020-12-26 16:04:15 --> Language Class Initialized
INFO - 2020-12-26 16:04:16 --> Config Class Initialized
INFO - 2020-12-26 16:04:16 --> Loader Class Initialized
INFO - 2020-12-26 16:04:16 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:16 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:16 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:16 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:16 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:16 --> Controller Class Initialized
DEBUG - 2020-12-26 16:04:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-12-26 16:04:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:04:16 --> Final output sent to browser
DEBUG - 2020-12-26 16:04:16 --> Total execution time: 0.8236
INFO - 2020-12-26 16:04:16 --> Config Class Initialized
INFO - 2020-12-26 16:04:16 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:16 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:17 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:17 --> URI Class Initialized
INFO - 2020-12-26 16:04:17 --> Router Class Initialized
INFO - 2020-12-26 16:04:17 --> Output Class Initialized
INFO - 2020-12-26 16:04:17 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:17 --> Input Class Initialized
INFO - 2020-12-26 16:04:17 --> Language Class Initialized
INFO - 2020-12-26 16:04:17 --> Language Class Initialized
INFO - 2020-12-26 16:04:17 --> Config Class Initialized
INFO - 2020-12-26 16:04:17 --> Loader Class Initialized
INFO - 2020-12-26 16:04:17 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:17 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:17 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:17 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:17 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:17 --> Controller Class Initialized
INFO - 2020-12-26 16:04:19 --> Config Class Initialized
INFO - 2020-12-26 16:04:19 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:19 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:19 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:19 --> URI Class Initialized
INFO - 2020-12-26 16:04:19 --> Router Class Initialized
INFO - 2020-12-26 16:04:19 --> Output Class Initialized
INFO - 2020-12-26 16:04:19 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:19 --> Input Class Initialized
INFO - 2020-12-26 16:04:19 --> Language Class Initialized
INFO - 2020-12-26 16:04:19 --> Language Class Initialized
INFO - 2020-12-26 16:04:19 --> Config Class Initialized
INFO - 2020-12-26 16:04:19 --> Loader Class Initialized
INFO - 2020-12-26 16:04:19 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:19 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:19 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:19 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:19 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:19 --> Controller Class Initialized
INFO - 2020-12-26 16:04:20 --> Final output sent to browser
DEBUG - 2020-12-26 16:04:20 --> Total execution time: 0.6946
INFO - 2020-12-26 16:04:27 --> Config Class Initialized
INFO - 2020-12-26 16:04:27 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:27 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:27 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:27 --> URI Class Initialized
INFO - 2020-12-26 16:04:27 --> Router Class Initialized
INFO - 2020-12-26 16:04:27 --> Output Class Initialized
INFO - 2020-12-26 16:04:27 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:27 --> Input Class Initialized
INFO - 2020-12-26 16:04:27 --> Language Class Initialized
INFO - 2020-12-26 16:04:27 --> Language Class Initialized
INFO - 2020-12-26 16:04:27 --> Config Class Initialized
INFO - 2020-12-26 16:04:27 --> Loader Class Initialized
INFO - 2020-12-26 16:04:27 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:27 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:27 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:27 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:27 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:27 --> Controller Class Initialized
DEBUG - 2020-12-26 16:04:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-26 16:04:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:04:27 --> Final output sent to browser
DEBUG - 2020-12-26 16:04:27 --> Total execution time: 0.6525
INFO - 2020-12-26 16:04:28 --> Config Class Initialized
INFO - 2020-12-26 16:04:28 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:28 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:28 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:28 --> URI Class Initialized
INFO - 2020-12-26 16:04:28 --> Router Class Initialized
INFO - 2020-12-26 16:04:28 --> Output Class Initialized
INFO - 2020-12-26 16:04:28 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:28 --> Input Class Initialized
INFO - 2020-12-26 16:04:28 --> Language Class Initialized
INFO - 2020-12-26 16:04:28 --> Language Class Initialized
INFO - 2020-12-26 16:04:28 --> Config Class Initialized
INFO - 2020-12-26 16:04:28 --> Loader Class Initialized
INFO - 2020-12-26 16:04:28 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:28 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:28 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:28 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:28 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:28 --> Controller Class Initialized
INFO - 2020-12-26 16:04:30 --> Config Class Initialized
INFO - 2020-12-26 16:04:30 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:30 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:30 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:30 --> URI Class Initialized
INFO - 2020-12-26 16:04:30 --> Router Class Initialized
INFO - 2020-12-26 16:04:30 --> Output Class Initialized
INFO - 2020-12-26 16:04:30 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:30 --> Input Class Initialized
INFO - 2020-12-26 16:04:30 --> Language Class Initialized
INFO - 2020-12-26 16:04:30 --> Language Class Initialized
INFO - 2020-12-26 16:04:30 --> Config Class Initialized
INFO - 2020-12-26 16:04:30 --> Loader Class Initialized
INFO - 2020-12-26 16:04:30 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:30 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:30 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:30 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:30 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:30 --> Controller Class Initialized
DEBUG - 2020-12-26 16:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-12-26 16:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:04:31 --> Final output sent to browser
DEBUG - 2020-12-26 16:04:31 --> Total execution time: 0.9729
INFO - 2020-12-26 16:04:31 --> Config Class Initialized
INFO - 2020-12-26 16:04:31 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:31 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:31 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:31 --> URI Class Initialized
INFO - 2020-12-26 16:04:31 --> Router Class Initialized
INFO - 2020-12-26 16:04:31 --> Output Class Initialized
INFO - 2020-12-26 16:04:31 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:31 --> Input Class Initialized
INFO - 2020-12-26 16:04:31 --> Language Class Initialized
INFO - 2020-12-26 16:04:31 --> Language Class Initialized
INFO - 2020-12-26 16:04:31 --> Config Class Initialized
INFO - 2020-12-26 16:04:31 --> Loader Class Initialized
INFO - 2020-12-26 16:04:31 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:31 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:31 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:31 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:31 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:31 --> Controller Class Initialized
INFO - 2020-12-26 16:04:32 --> Config Class Initialized
INFO - 2020-12-26 16:04:32 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:32 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:32 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:32 --> URI Class Initialized
INFO - 2020-12-26 16:04:32 --> Router Class Initialized
INFO - 2020-12-26 16:04:32 --> Output Class Initialized
INFO - 2020-12-26 16:04:32 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:32 --> Input Class Initialized
INFO - 2020-12-26 16:04:32 --> Language Class Initialized
INFO - 2020-12-26 16:04:32 --> Language Class Initialized
INFO - 2020-12-26 16:04:32 --> Config Class Initialized
INFO - 2020-12-26 16:04:32 --> Loader Class Initialized
INFO - 2020-12-26 16:04:32 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:32 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:32 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:32 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:32 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:32 --> Controller Class Initialized
INFO - 2020-12-26 16:04:32 --> Final output sent to browser
DEBUG - 2020-12-26 16:04:32 --> Total execution time: 0.6733
INFO - 2020-12-26 16:04:49 --> Config Class Initialized
INFO - 2020-12-26 16:04:49 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:04:49 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:04:49 --> Utf8 Class Initialized
INFO - 2020-12-26 16:04:49 --> URI Class Initialized
INFO - 2020-12-26 16:04:49 --> Router Class Initialized
INFO - 2020-12-26 16:04:49 --> Output Class Initialized
INFO - 2020-12-26 16:04:49 --> Security Class Initialized
DEBUG - 2020-12-26 16:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:04:50 --> Input Class Initialized
INFO - 2020-12-26 16:04:50 --> Language Class Initialized
INFO - 2020-12-26 16:04:50 --> Language Class Initialized
INFO - 2020-12-26 16:04:50 --> Config Class Initialized
INFO - 2020-12-26 16:04:50 --> Loader Class Initialized
INFO - 2020-12-26 16:04:50 --> Helper loaded: url_helper
INFO - 2020-12-26 16:04:50 --> Helper loaded: file_helper
INFO - 2020-12-26 16:04:50 --> Helper loaded: form_helper
INFO - 2020-12-26 16:04:50 --> Helper loaded: my_helper
INFO - 2020-12-26 16:04:50 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:04:50 --> Controller Class Initialized
INFO - 2020-12-26 16:04:50 --> Final output sent to browser
DEBUG - 2020-12-26 16:04:50 --> Total execution time: 0.6422
INFO - 2020-12-26 16:05:00 --> Config Class Initialized
INFO - 2020-12-26 16:05:00 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:05:00 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:05:00 --> Utf8 Class Initialized
INFO - 2020-12-26 16:05:00 --> URI Class Initialized
INFO - 2020-12-26 16:05:00 --> Router Class Initialized
INFO - 2020-12-26 16:05:00 --> Output Class Initialized
INFO - 2020-12-26 16:05:00 --> Security Class Initialized
DEBUG - 2020-12-26 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:05:00 --> Input Class Initialized
INFO - 2020-12-26 16:05:00 --> Language Class Initialized
INFO - 2020-12-26 16:05:00 --> Language Class Initialized
INFO - 2020-12-26 16:05:00 --> Config Class Initialized
INFO - 2020-12-26 16:05:00 --> Loader Class Initialized
INFO - 2020-12-26 16:05:00 --> Helper loaded: url_helper
INFO - 2020-12-26 16:05:00 --> Helper loaded: file_helper
INFO - 2020-12-26 16:05:00 --> Helper loaded: form_helper
INFO - 2020-12-26 16:05:00 --> Helper loaded: my_helper
INFO - 2020-12-26 16:05:01 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:05:01 --> Controller Class Initialized
DEBUG - 2020-12-26 16:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-26 16:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:05:01 --> Final output sent to browser
DEBUG - 2020-12-26 16:05:01 --> Total execution time: 0.7981
INFO - 2020-12-26 16:05:01 --> Config Class Initialized
INFO - 2020-12-26 16:05:01 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:05:01 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:05:01 --> Utf8 Class Initialized
INFO - 2020-12-26 16:05:01 --> URI Class Initialized
INFO - 2020-12-26 16:05:01 --> Router Class Initialized
INFO - 2020-12-26 16:05:01 --> Output Class Initialized
INFO - 2020-12-26 16:05:01 --> Security Class Initialized
DEBUG - 2020-12-26 16:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:05:01 --> Input Class Initialized
INFO - 2020-12-26 16:05:01 --> Language Class Initialized
INFO - 2020-12-26 16:05:02 --> Language Class Initialized
INFO - 2020-12-26 16:05:02 --> Config Class Initialized
INFO - 2020-12-26 16:05:02 --> Loader Class Initialized
INFO - 2020-12-26 16:05:02 --> Helper loaded: url_helper
INFO - 2020-12-26 16:05:02 --> Helper loaded: file_helper
INFO - 2020-12-26 16:05:02 --> Helper loaded: form_helper
INFO - 2020-12-26 16:05:02 --> Helper loaded: my_helper
INFO - 2020-12-26 16:05:02 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:05:02 --> Controller Class Initialized
INFO - 2020-12-26 16:05:02 --> Config Class Initialized
INFO - 2020-12-26 16:05:02 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:05:02 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:05:02 --> Utf8 Class Initialized
INFO - 2020-12-26 16:05:02 --> URI Class Initialized
INFO - 2020-12-26 16:05:02 --> Router Class Initialized
INFO - 2020-12-26 16:05:02 --> Output Class Initialized
INFO - 2020-12-26 16:05:02 --> Security Class Initialized
DEBUG - 2020-12-26 16:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:05:02 --> Input Class Initialized
INFO - 2020-12-26 16:05:02 --> Language Class Initialized
INFO - 2020-12-26 16:05:02 --> Language Class Initialized
INFO - 2020-12-26 16:05:02 --> Config Class Initialized
INFO - 2020-12-26 16:05:03 --> Loader Class Initialized
INFO - 2020-12-26 16:05:03 --> Helper loaded: url_helper
INFO - 2020-12-26 16:05:03 --> Helper loaded: file_helper
INFO - 2020-12-26 16:05:03 --> Helper loaded: form_helper
INFO - 2020-12-26 16:05:03 --> Helper loaded: my_helper
INFO - 2020-12-26 16:05:03 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:05:03 --> Controller Class Initialized
ERROR - 2020-12-26 16:05:03 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-12-26 16:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-12-26 16:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:05:03 --> Final output sent to browser
DEBUG - 2020-12-26 16:05:03 --> Total execution time: 0.8059
INFO - 2020-12-26 16:05:58 --> Config Class Initialized
INFO - 2020-12-26 16:05:58 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:05:58 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:05:58 --> Utf8 Class Initialized
INFO - 2020-12-26 16:05:58 --> URI Class Initialized
INFO - 2020-12-26 16:05:58 --> Router Class Initialized
INFO - 2020-12-26 16:05:58 --> Output Class Initialized
INFO - 2020-12-26 16:05:58 --> Security Class Initialized
DEBUG - 2020-12-26 16:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:05:58 --> Input Class Initialized
INFO - 2020-12-26 16:05:58 --> Language Class Initialized
INFO - 2020-12-26 16:05:58 --> Language Class Initialized
INFO - 2020-12-26 16:05:58 --> Config Class Initialized
INFO - 2020-12-26 16:05:58 --> Loader Class Initialized
INFO - 2020-12-26 16:05:58 --> Helper loaded: url_helper
INFO - 2020-12-26 16:05:58 --> Helper loaded: file_helper
INFO - 2020-12-26 16:05:58 --> Helper loaded: form_helper
INFO - 2020-12-26 16:05:58 --> Helper loaded: my_helper
INFO - 2020-12-26 16:05:58 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:05:58 --> Controller Class Initialized
INFO - 2020-12-26 16:05:58 --> Helper loaded: cookie_helper
INFO - 2020-12-26 16:05:58 --> Config Class Initialized
INFO - 2020-12-26 16:05:58 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:05:58 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:05:58 --> Utf8 Class Initialized
INFO - 2020-12-26 16:05:59 --> URI Class Initialized
INFO - 2020-12-26 16:05:59 --> Router Class Initialized
INFO - 2020-12-26 16:05:59 --> Output Class Initialized
INFO - 2020-12-26 16:05:59 --> Security Class Initialized
DEBUG - 2020-12-26 16:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:05:59 --> Input Class Initialized
INFO - 2020-12-26 16:05:59 --> Language Class Initialized
INFO - 2020-12-26 16:05:59 --> Language Class Initialized
INFO - 2020-12-26 16:05:59 --> Config Class Initialized
INFO - 2020-12-26 16:05:59 --> Loader Class Initialized
INFO - 2020-12-26 16:05:59 --> Helper loaded: url_helper
INFO - 2020-12-26 16:05:59 --> Helper loaded: file_helper
INFO - 2020-12-26 16:05:59 --> Helper loaded: form_helper
INFO - 2020-12-26 16:05:59 --> Helper loaded: my_helper
INFO - 2020-12-26 16:05:59 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:05:59 --> Controller Class Initialized
DEBUG - 2020-12-26 16:05:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-26 16:05:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:05:59 --> Final output sent to browser
DEBUG - 2020-12-26 16:05:59 --> Total execution time: 0.9835
INFO - 2020-12-26 16:06:06 --> Config Class Initialized
INFO - 2020-12-26 16:06:06 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:06:06 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:06:06 --> Utf8 Class Initialized
INFO - 2020-12-26 16:06:06 --> URI Class Initialized
INFO - 2020-12-26 16:06:06 --> Router Class Initialized
INFO - 2020-12-26 16:06:06 --> Output Class Initialized
INFO - 2020-12-26 16:06:06 --> Security Class Initialized
DEBUG - 2020-12-26 16:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:06:06 --> Input Class Initialized
INFO - 2020-12-26 16:06:06 --> Language Class Initialized
INFO - 2020-12-26 16:06:06 --> Language Class Initialized
INFO - 2020-12-26 16:06:06 --> Config Class Initialized
INFO - 2020-12-26 16:06:06 --> Loader Class Initialized
INFO - 2020-12-26 16:06:06 --> Helper loaded: url_helper
INFO - 2020-12-26 16:06:06 --> Helper loaded: file_helper
INFO - 2020-12-26 16:06:06 --> Helper loaded: form_helper
INFO - 2020-12-26 16:06:06 --> Helper loaded: my_helper
INFO - 2020-12-26 16:06:06 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:06:06 --> Controller Class Initialized
INFO - 2020-12-26 16:06:06 --> Helper loaded: cookie_helper
INFO - 2020-12-26 16:06:07 --> Final output sent to browser
DEBUG - 2020-12-26 16:06:07 --> Total execution time: 0.6203
INFO - 2020-12-26 16:06:07 --> Config Class Initialized
INFO - 2020-12-26 16:06:07 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:06:07 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:06:07 --> Utf8 Class Initialized
INFO - 2020-12-26 16:06:07 --> URI Class Initialized
INFO - 2020-12-26 16:06:07 --> Router Class Initialized
INFO - 2020-12-26 16:06:07 --> Output Class Initialized
INFO - 2020-12-26 16:06:07 --> Security Class Initialized
DEBUG - 2020-12-26 16:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:06:07 --> Input Class Initialized
INFO - 2020-12-26 16:06:07 --> Language Class Initialized
INFO - 2020-12-26 16:06:07 --> Language Class Initialized
INFO - 2020-12-26 16:06:07 --> Config Class Initialized
INFO - 2020-12-26 16:06:07 --> Loader Class Initialized
INFO - 2020-12-26 16:06:08 --> Helper loaded: url_helper
INFO - 2020-12-26 16:06:08 --> Helper loaded: file_helper
INFO - 2020-12-26 16:06:08 --> Helper loaded: form_helper
INFO - 2020-12-26 16:06:08 --> Helper loaded: my_helper
INFO - 2020-12-26 16:06:08 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:06:08 --> Controller Class Initialized
DEBUG - 2020-12-26 16:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-26 16:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:06:08 --> Final output sent to browser
DEBUG - 2020-12-26 16:06:08 --> Total execution time: 0.6444
INFO - 2020-12-26 16:06:13 --> Config Class Initialized
INFO - 2020-12-26 16:06:13 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:06:13 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:06:13 --> Utf8 Class Initialized
INFO - 2020-12-26 16:06:13 --> URI Class Initialized
INFO - 2020-12-26 16:06:13 --> Router Class Initialized
INFO - 2020-12-26 16:06:13 --> Output Class Initialized
INFO - 2020-12-26 16:06:13 --> Security Class Initialized
DEBUG - 2020-12-26 16:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:06:13 --> Input Class Initialized
INFO - 2020-12-26 16:06:13 --> Language Class Initialized
INFO - 2020-12-26 16:06:13 --> Language Class Initialized
INFO - 2020-12-26 16:06:13 --> Config Class Initialized
INFO - 2020-12-26 16:06:13 --> Loader Class Initialized
INFO - 2020-12-26 16:06:14 --> Helper loaded: url_helper
INFO - 2020-12-26 16:06:14 --> Helper loaded: file_helper
INFO - 2020-12-26 16:06:14 --> Helper loaded: form_helper
INFO - 2020-12-26 16:06:14 --> Helper loaded: my_helper
INFO - 2020-12-26 16:06:14 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:06:14 --> Controller Class Initialized
DEBUG - 2020-12-26 16:06:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:06:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:06:14 --> Final output sent to browser
DEBUG - 2020-12-26 16:06:14 --> Total execution time: 0.8867
INFO - 2020-12-26 16:08:04 --> Config Class Initialized
INFO - 2020-12-26 16:08:04 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:08:04 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:08:04 --> Utf8 Class Initialized
INFO - 2020-12-26 16:08:04 --> URI Class Initialized
INFO - 2020-12-26 16:08:04 --> Router Class Initialized
INFO - 2020-12-26 16:08:04 --> Output Class Initialized
INFO - 2020-12-26 16:08:04 --> Security Class Initialized
DEBUG - 2020-12-26 16:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:08:04 --> Input Class Initialized
INFO - 2020-12-26 16:08:04 --> Language Class Initialized
INFO - 2020-12-26 16:08:04 --> Language Class Initialized
INFO - 2020-12-26 16:08:04 --> Config Class Initialized
INFO - 2020-12-26 16:08:04 --> Loader Class Initialized
INFO - 2020-12-26 16:08:04 --> Helper loaded: url_helper
INFO - 2020-12-26 16:08:04 --> Helper loaded: file_helper
INFO - 2020-12-26 16:08:04 --> Helper loaded: form_helper
INFO - 2020-12-26 16:08:04 --> Helper loaded: my_helper
INFO - 2020-12-26 16:08:04 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:08:04 --> Controller Class Initialized
DEBUG - 2020-12-26 16:08:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:08:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:08:04 --> Final output sent to browser
DEBUG - 2020-12-26 16:08:04 --> Total execution time: 0.7013
INFO - 2020-12-26 16:09:00 --> Config Class Initialized
INFO - 2020-12-26 16:09:00 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:09:00 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:09:00 --> Utf8 Class Initialized
INFO - 2020-12-26 16:09:00 --> URI Class Initialized
INFO - 2020-12-26 16:09:00 --> Router Class Initialized
INFO - 2020-12-26 16:09:00 --> Output Class Initialized
INFO - 2020-12-26 16:09:00 --> Security Class Initialized
DEBUG - 2020-12-26 16:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:09:00 --> Input Class Initialized
INFO - 2020-12-26 16:09:01 --> Language Class Initialized
INFO - 2020-12-26 16:09:01 --> Language Class Initialized
INFO - 2020-12-26 16:09:01 --> Config Class Initialized
INFO - 2020-12-26 16:09:01 --> Loader Class Initialized
INFO - 2020-12-26 16:09:01 --> Helper loaded: url_helper
INFO - 2020-12-26 16:09:01 --> Helper loaded: file_helper
INFO - 2020-12-26 16:09:01 --> Helper loaded: form_helper
INFO - 2020-12-26 16:09:01 --> Helper loaded: my_helper
INFO - 2020-12-26 16:09:01 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:09:01 --> Controller Class Initialized
DEBUG - 2020-12-26 16:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-26 16:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:09:01 --> Final output sent to browser
DEBUG - 2020-12-26 16:09:01 --> Total execution time: 0.8404
INFO - 2020-12-26 16:09:03 --> Config Class Initialized
INFO - 2020-12-26 16:09:03 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:09:03 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:09:03 --> Utf8 Class Initialized
INFO - 2020-12-26 16:09:03 --> URI Class Initialized
INFO - 2020-12-26 16:09:04 --> Router Class Initialized
INFO - 2020-12-26 16:09:04 --> Output Class Initialized
INFO - 2020-12-26 16:09:04 --> Security Class Initialized
DEBUG - 2020-12-26 16:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:09:04 --> Input Class Initialized
INFO - 2020-12-26 16:09:04 --> Language Class Initialized
INFO - 2020-12-26 16:09:04 --> Language Class Initialized
INFO - 2020-12-26 16:09:04 --> Config Class Initialized
INFO - 2020-12-26 16:09:04 --> Loader Class Initialized
INFO - 2020-12-26 16:09:04 --> Helper loaded: url_helper
INFO - 2020-12-26 16:09:04 --> Helper loaded: file_helper
INFO - 2020-12-26 16:09:04 --> Helper loaded: form_helper
INFO - 2020-12-26 16:09:04 --> Helper loaded: my_helper
INFO - 2020-12-26 16:09:04 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:09:04 --> Controller Class Initialized
INFO - 2020-12-26 16:09:04 --> Final output sent to browser
DEBUG - 2020-12-26 16:09:04 --> Total execution time: 0.6219
INFO - 2020-12-26 16:10:57 --> Config Class Initialized
INFO - 2020-12-26 16:10:57 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:10:57 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:10:57 --> Utf8 Class Initialized
INFO - 2020-12-26 16:10:57 --> URI Class Initialized
INFO - 2020-12-26 16:10:57 --> Router Class Initialized
INFO - 2020-12-26 16:10:57 --> Output Class Initialized
INFO - 2020-12-26 16:10:57 --> Security Class Initialized
DEBUG - 2020-12-26 16:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:10:58 --> Input Class Initialized
INFO - 2020-12-26 16:10:58 --> Language Class Initialized
INFO - 2020-12-26 16:10:58 --> Language Class Initialized
INFO - 2020-12-26 16:10:58 --> Config Class Initialized
INFO - 2020-12-26 16:10:58 --> Loader Class Initialized
INFO - 2020-12-26 16:10:58 --> Helper loaded: url_helper
INFO - 2020-12-26 16:10:58 --> Helper loaded: file_helper
INFO - 2020-12-26 16:10:58 --> Helper loaded: form_helper
INFO - 2020-12-26 16:10:58 --> Helper loaded: my_helper
INFO - 2020-12-26 16:10:58 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:10:58 --> Controller Class Initialized
DEBUG - 2020-12-26 16:10:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:10:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:10:58 --> Final output sent to browser
DEBUG - 2020-12-26 16:10:58 --> Total execution time: 0.9188
INFO - 2020-12-26 16:11:01 --> Config Class Initialized
INFO - 2020-12-26 16:11:01 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:11:01 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:11:01 --> Utf8 Class Initialized
INFO - 2020-12-26 16:11:01 --> URI Class Initialized
INFO - 2020-12-26 16:11:01 --> Router Class Initialized
INFO - 2020-12-26 16:11:01 --> Output Class Initialized
INFO - 2020-12-26 16:11:01 --> Security Class Initialized
DEBUG - 2020-12-26 16:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:11:01 --> Input Class Initialized
INFO - 2020-12-26 16:11:01 --> Language Class Initialized
INFO - 2020-12-26 16:11:01 --> Language Class Initialized
INFO - 2020-12-26 16:11:01 --> Config Class Initialized
INFO - 2020-12-26 16:11:01 --> Loader Class Initialized
INFO - 2020-12-26 16:11:01 --> Helper loaded: url_helper
INFO - 2020-12-26 16:11:01 --> Helper loaded: file_helper
INFO - 2020-12-26 16:11:01 --> Helper loaded: form_helper
INFO - 2020-12-26 16:11:01 --> Helper loaded: my_helper
INFO - 2020-12-26 16:11:01 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:11:02 --> Controller Class Initialized
DEBUG - 2020-12-26 16:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:11:02 --> Final output sent to browser
DEBUG - 2020-12-26 16:11:02 --> Total execution time: 0.9616
INFO - 2020-12-26 16:11:23 --> Config Class Initialized
INFO - 2020-12-26 16:11:23 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:11:23 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:11:23 --> Utf8 Class Initialized
INFO - 2020-12-26 16:11:23 --> URI Class Initialized
INFO - 2020-12-26 16:11:23 --> Router Class Initialized
INFO - 2020-12-26 16:11:23 --> Output Class Initialized
INFO - 2020-12-26 16:11:23 --> Security Class Initialized
DEBUG - 2020-12-26 16:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:11:23 --> Input Class Initialized
INFO - 2020-12-26 16:11:23 --> Language Class Initialized
INFO - 2020-12-26 16:11:23 --> Language Class Initialized
INFO - 2020-12-26 16:11:23 --> Config Class Initialized
INFO - 2020-12-26 16:11:24 --> Loader Class Initialized
INFO - 2020-12-26 16:11:24 --> Helper loaded: url_helper
INFO - 2020-12-26 16:11:24 --> Helper loaded: file_helper
INFO - 2020-12-26 16:11:24 --> Helper loaded: form_helper
INFO - 2020-12-26 16:11:24 --> Helper loaded: my_helper
INFO - 2020-12-26 16:11:24 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:11:24 --> Controller Class Initialized
INFO - 2020-12-26 16:11:24 --> Final output sent to browser
DEBUG - 2020-12-26 16:11:24 --> Total execution time: 0.8954
INFO - 2020-12-26 16:12:21 --> Config Class Initialized
INFO - 2020-12-26 16:12:21 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:12:21 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:12:21 --> Utf8 Class Initialized
INFO - 2020-12-26 16:12:21 --> URI Class Initialized
INFO - 2020-12-26 16:12:21 --> Router Class Initialized
INFO - 2020-12-26 16:12:21 --> Output Class Initialized
INFO - 2020-12-26 16:12:21 --> Security Class Initialized
DEBUG - 2020-12-26 16:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:12:21 --> Input Class Initialized
INFO - 2020-12-26 16:12:21 --> Language Class Initialized
INFO - 2020-12-26 16:12:21 --> Language Class Initialized
INFO - 2020-12-26 16:12:21 --> Config Class Initialized
INFO - 2020-12-26 16:12:21 --> Loader Class Initialized
INFO - 2020-12-26 16:12:21 --> Helper loaded: url_helper
INFO - 2020-12-26 16:12:21 --> Helper loaded: file_helper
INFO - 2020-12-26 16:12:21 --> Helper loaded: form_helper
INFO - 2020-12-26 16:12:21 --> Helper loaded: my_helper
INFO - 2020-12-26 16:12:21 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:12:21 --> Controller Class Initialized
DEBUG - 2020-12-26 16:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:12:22 --> Final output sent to browser
DEBUG - 2020-12-26 16:12:22 --> Total execution time: 0.9496
INFO - 2020-12-26 16:17:42 --> Config Class Initialized
INFO - 2020-12-26 16:17:42 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:17:42 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:17:42 --> Utf8 Class Initialized
INFO - 2020-12-26 16:17:42 --> URI Class Initialized
INFO - 2020-12-26 16:17:42 --> Router Class Initialized
INFO - 2020-12-26 16:17:42 --> Output Class Initialized
INFO - 2020-12-26 16:17:42 --> Security Class Initialized
DEBUG - 2020-12-26 16:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:17:42 --> Input Class Initialized
INFO - 2020-12-26 16:17:42 --> Language Class Initialized
INFO - 2020-12-26 16:17:42 --> Language Class Initialized
INFO - 2020-12-26 16:17:42 --> Config Class Initialized
INFO - 2020-12-26 16:17:42 --> Loader Class Initialized
INFO - 2020-12-26 16:17:42 --> Helper loaded: url_helper
INFO - 2020-12-26 16:17:42 --> Helper loaded: file_helper
INFO - 2020-12-26 16:17:42 --> Helper loaded: form_helper
INFO - 2020-12-26 16:17:42 --> Helper loaded: my_helper
INFO - 2020-12-26 16:17:42 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:17:42 --> Controller Class Initialized
DEBUG - 2020-12-26 16:17:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:17:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:17:42 --> Final output sent to browser
DEBUG - 2020-12-26 16:17:42 --> Total execution time: 0.2889
INFO - 2020-12-26 16:19:13 --> Config Class Initialized
INFO - 2020-12-26 16:19:13 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:19:13 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:19:13 --> Utf8 Class Initialized
INFO - 2020-12-26 16:19:13 --> URI Class Initialized
INFO - 2020-12-26 16:19:13 --> Router Class Initialized
INFO - 2020-12-26 16:19:13 --> Output Class Initialized
INFO - 2020-12-26 16:19:13 --> Security Class Initialized
DEBUG - 2020-12-26 16:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:19:13 --> Input Class Initialized
INFO - 2020-12-26 16:19:13 --> Language Class Initialized
INFO - 2020-12-26 16:19:13 --> Language Class Initialized
INFO - 2020-12-26 16:19:13 --> Config Class Initialized
INFO - 2020-12-26 16:19:13 --> Loader Class Initialized
INFO - 2020-12-26 16:19:13 --> Helper loaded: url_helper
INFO - 2020-12-26 16:19:13 --> Helper loaded: file_helper
INFO - 2020-12-26 16:19:13 --> Helper loaded: form_helper
INFO - 2020-12-26 16:19:13 --> Helper loaded: my_helper
INFO - 2020-12-26 16:19:13 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:19:13 --> Controller Class Initialized
DEBUG - 2020-12-26 16:19:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:19:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:19:13 --> Final output sent to browser
DEBUG - 2020-12-26 16:19:13 --> Total execution time: 0.2993
INFO - 2020-12-26 16:20:53 --> Config Class Initialized
INFO - 2020-12-26 16:20:53 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:20:53 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:20:53 --> Utf8 Class Initialized
INFO - 2020-12-26 16:20:53 --> URI Class Initialized
INFO - 2020-12-26 16:20:53 --> Router Class Initialized
INFO - 2020-12-26 16:20:53 --> Output Class Initialized
INFO - 2020-12-26 16:20:53 --> Security Class Initialized
DEBUG - 2020-12-26 16:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:20:53 --> Input Class Initialized
INFO - 2020-12-26 16:20:53 --> Language Class Initialized
INFO - 2020-12-26 16:20:53 --> Language Class Initialized
INFO - 2020-12-26 16:20:53 --> Config Class Initialized
INFO - 2020-12-26 16:20:53 --> Loader Class Initialized
INFO - 2020-12-26 16:20:53 --> Helper loaded: url_helper
INFO - 2020-12-26 16:20:53 --> Helper loaded: file_helper
INFO - 2020-12-26 16:20:53 --> Helper loaded: form_helper
INFO - 2020-12-26 16:20:53 --> Helper loaded: my_helper
INFO - 2020-12-26 16:20:53 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:20:53 --> Controller Class Initialized
ERROR - 2020-12-26 16:20:53 --> Severity: Error --> Call to undefined function form() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
INFO - 2020-12-26 16:22:36 --> Config Class Initialized
INFO - 2020-12-26 16:22:36 --> Hooks Class Initialized
DEBUG - 2020-12-26 16:22:36 --> UTF-8 Support Enabled
INFO - 2020-12-26 16:22:36 --> Utf8 Class Initialized
INFO - 2020-12-26 16:22:36 --> URI Class Initialized
INFO - 2020-12-26 16:22:36 --> Router Class Initialized
INFO - 2020-12-26 16:22:36 --> Output Class Initialized
INFO - 2020-12-26 16:22:36 --> Security Class Initialized
DEBUG - 2020-12-26 16:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-26 16:22:36 --> Input Class Initialized
INFO - 2020-12-26 16:22:36 --> Language Class Initialized
INFO - 2020-12-26 16:22:36 --> Language Class Initialized
INFO - 2020-12-26 16:22:36 --> Config Class Initialized
INFO - 2020-12-26 16:22:36 --> Loader Class Initialized
INFO - 2020-12-26 16:22:36 --> Helper loaded: url_helper
INFO - 2020-12-26 16:22:36 --> Helper loaded: file_helper
INFO - 2020-12-26 16:22:36 --> Helper loaded: form_helper
INFO - 2020-12-26 16:22:36 --> Helper loaded: my_helper
INFO - 2020-12-26 16:22:36 --> Database Driver Class Initialized
DEBUG - 2020-12-26 16:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-26 16:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-26 16:22:36 --> Controller Class Initialized
DEBUG - 2020-12-26 16:22:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-26 16:22:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-26 16:22:36 --> Final output sent to browser
DEBUG - 2020-12-26 16:22:36 --> Total execution time: 0.2780
