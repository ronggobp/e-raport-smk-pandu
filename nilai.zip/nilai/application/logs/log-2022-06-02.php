<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-02 09:16:08 --> Config Class Initialized
INFO - 2022-06-02 09:16:08 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:16:08 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:16:08 --> Utf8 Class Initialized
INFO - 2022-06-02 09:16:08 --> URI Class Initialized
DEBUG - 2022-06-02 09:16:09 --> No URI present. Default controller set.
INFO - 2022-06-02 09:16:09 --> Router Class Initialized
INFO - 2022-06-02 09:16:09 --> Output Class Initialized
INFO - 2022-06-02 09:16:09 --> Security Class Initialized
DEBUG - 2022-06-02 09:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:16:09 --> Input Class Initialized
INFO - 2022-06-02 09:16:09 --> Language Class Initialized
INFO - 2022-06-02 09:16:09 --> Language Class Initialized
INFO - 2022-06-02 09:16:09 --> Config Class Initialized
INFO - 2022-06-02 09:16:09 --> Loader Class Initialized
INFO - 2022-06-02 09:16:09 --> Helper loaded: url_helper
INFO - 2022-06-02 09:16:09 --> Helper loaded: file_helper
INFO - 2022-06-02 09:16:09 --> Helper loaded: form_helper
INFO - 2022-06-02 09:16:09 --> Helper loaded: my_helper
INFO - 2022-06-02 09:16:09 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:16:09 --> Controller Class Initialized
INFO - 2022-06-02 09:16:09 --> Config Class Initialized
INFO - 2022-06-02 09:16:09 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:16:09 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:16:09 --> Utf8 Class Initialized
INFO - 2022-06-02 09:16:09 --> URI Class Initialized
INFO - 2022-06-02 09:16:09 --> Router Class Initialized
INFO - 2022-06-02 09:16:09 --> Output Class Initialized
INFO - 2022-06-02 09:16:09 --> Security Class Initialized
DEBUG - 2022-06-02 09:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:16:09 --> Input Class Initialized
INFO - 2022-06-02 09:16:09 --> Language Class Initialized
INFO - 2022-06-02 09:16:09 --> Language Class Initialized
INFO - 2022-06-02 09:16:09 --> Config Class Initialized
INFO - 2022-06-02 09:16:09 --> Loader Class Initialized
INFO - 2022-06-02 09:16:09 --> Helper loaded: url_helper
INFO - 2022-06-02 09:16:09 --> Helper loaded: file_helper
INFO - 2022-06-02 09:16:09 --> Helper loaded: form_helper
INFO - 2022-06-02 09:16:09 --> Helper loaded: my_helper
INFO - 2022-06-02 09:16:09 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:16:09 --> Controller Class Initialized
DEBUG - 2022-06-02 09:16:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-02 09:16:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 09:16:10 --> Final output sent to browser
DEBUG - 2022-06-02 09:16:10 --> Total execution time: 0.2182
INFO - 2022-06-02 09:31:41 --> Config Class Initialized
INFO - 2022-06-02 09:31:41 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:31:41 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:31:41 --> Utf8 Class Initialized
INFO - 2022-06-02 09:31:41 --> URI Class Initialized
INFO - 2022-06-02 09:31:41 --> Router Class Initialized
INFO - 2022-06-02 09:31:41 --> Output Class Initialized
INFO - 2022-06-02 09:31:41 --> Security Class Initialized
DEBUG - 2022-06-02 09:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:31:41 --> Input Class Initialized
INFO - 2022-06-02 09:31:41 --> Language Class Initialized
INFO - 2022-06-02 09:31:41 --> Language Class Initialized
INFO - 2022-06-02 09:31:41 --> Config Class Initialized
INFO - 2022-06-02 09:31:41 --> Loader Class Initialized
INFO - 2022-06-02 09:31:41 --> Helper loaded: url_helper
INFO - 2022-06-02 09:31:41 --> Helper loaded: file_helper
INFO - 2022-06-02 09:31:41 --> Helper loaded: form_helper
INFO - 2022-06-02 09:31:41 --> Helper loaded: my_helper
INFO - 2022-06-02 09:31:41 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:31:41 --> Controller Class Initialized
INFO - 2022-06-02 09:31:41 --> Helper loaded: cookie_helper
INFO - 2022-06-02 09:31:41 --> Final output sent to browser
DEBUG - 2022-06-02 09:31:41 --> Total execution time: 0.1076
INFO - 2022-06-02 09:31:41 --> Config Class Initialized
INFO - 2022-06-02 09:31:41 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:31:41 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:31:41 --> Utf8 Class Initialized
INFO - 2022-06-02 09:31:41 --> URI Class Initialized
INFO - 2022-06-02 09:31:41 --> Router Class Initialized
INFO - 2022-06-02 09:31:41 --> Output Class Initialized
INFO - 2022-06-02 09:31:41 --> Security Class Initialized
DEBUG - 2022-06-02 09:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:31:41 --> Input Class Initialized
INFO - 2022-06-02 09:31:41 --> Language Class Initialized
INFO - 2022-06-02 09:31:41 --> Language Class Initialized
INFO - 2022-06-02 09:31:41 --> Config Class Initialized
INFO - 2022-06-02 09:31:41 --> Loader Class Initialized
INFO - 2022-06-02 09:31:41 --> Helper loaded: url_helper
INFO - 2022-06-02 09:31:41 --> Helper loaded: file_helper
INFO - 2022-06-02 09:31:41 --> Helper loaded: form_helper
INFO - 2022-06-02 09:31:41 --> Helper loaded: my_helper
INFO - 2022-06-02 09:31:41 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:31:41 --> Controller Class Initialized
DEBUG - 2022-06-02 09:31:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-02 09:31:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 09:31:41 --> Final output sent to browser
DEBUG - 2022-06-02 09:31:41 --> Total execution time: 0.1084
INFO - 2022-06-02 09:31:42 --> Config Class Initialized
INFO - 2022-06-02 09:31:42 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:31:42 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:31:42 --> Utf8 Class Initialized
INFO - 2022-06-02 09:31:42 --> URI Class Initialized
INFO - 2022-06-02 09:31:42 --> Router Class Initialized
INFO - 2022-06-02 09:31:42 --> Output Class Initialized
INFO - 2022-06-02 09:31:42 --> Security Class Initialized
DEBUG - 2022-06-02 09:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:31:42 --> Input Class Initialized
INFO - 2022-06-02 09:31:42 --> Language Class Initialized
INFO - 2022-06-02 09:31:42 --> Language Class Initialized
INFO - 2022-06-02 09:31:42 --> Config Class Initialized
INFO - 2022-06-02 09:31:42 --> Loader Class Initialized
INFO - 2022-06-02 09:31:42 --> Helper loaded: url_helper
INFO - 2022-06-02 09:31:42 --> Helper loaded: file_helper
INFO - 2022-06-02 09:31:42 --> Helper loaded: form_helper
INFO - 2022-06-02 09:31:42 --> Helper loaded: my_helper
INFO - 2022-06-02 09:31:42 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:31:42 --> Controller Class Initialized
ERROR - 2022-06-02 09:31:42 --> Severity: Notice --> Undefined index: ekstra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 40
ERROR - 2022-06-02 09:31:42 --> Severity: Notice --> Undefined index: nilai C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-06-02 09:31:42 --> Severity: Notice --> Undefined index: ekstra2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-06-02 09:31:42 --> Severity: Notice --> Undefined index: nilai2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 55
DEBUG - 2022-06-02 09:31:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 09:31:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 09:31:42 --> Final output sent to browser
DEBUG - 2022-06-02 09:31:42 --> Total execution time: 0.1054
INFO - 2022-06-02 09:32:36 --> Config Class Initialized
INFO - 2022-06-02 09:32:36 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:32:36 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:32:36 --> Utf8 Class Initialized
INFO - 2022-06-02 09:32:36 --> URI Class Initialized
INFO - 2022-06-02 09:32:36 --> Router Class Initialized
INFO - 2022-06-02 09:32:36 --> Output Class Initialized
INFO - 2022-06-02 09:32:36 --> Security Class Initialized
DEBUG - 2022-06-02 09:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:32:36 --> Input Class Initialized
INFO - 2022-06-02 09:32:36 --> Language Class Initialized
INFO - 2022-06-02 09:32:36 --> Language Class Initialized
INFO - 2022-06-02 09:32:36 --> Config Class Initialized
INFO - 2022-06-02 09:32:36 --> Loader Class Initialized
INFO - 2022-06-02 09:32:36 --> Helper loaded: url_helper
INFO - 2022-06-02 09:32:36 --> Helper loaded: file_helper
INFO - 2022-06-02 09:32:36 --> Helper loaded: form_helper
INFO - 2022-06-02 09:32:36 --> Helper loaded: my_helper
INFO - 2022-06-02 09:32:36 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:32:36 --> Controller Class Initialized
DEBUG - 2022-06-02 09:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 09:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 09:32:36 --> Final output sent to browser
DEBUG - 2022-06-02 09:32:36 --> Total execution time: 0.0690
INFO - 2022-06-02 09:33:13 --> Config Class Initialized
INFO - 2022-06-02 09:33:13 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:33:13 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:33:13 --> Utf8 Class Initialized
INFO - 2022-06-02 09:33:13 --> URI Class Initialized
INFO - 2022-06-02 09:33:13 --> Router Class Initialized
INFO - 2022-06-02 09:33:13 --> Output Class Initialized
INFO - 2022-06-02 09:33:13 --> Security Class Initialized
DEBUG - 2022-06-02 09:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:33:13 --> Input Class Initialized
INFO - 2022-06-02 09:33:13 --> Language Class Initialized
INFO - 2022-06-02 09:33:13 --> Language Class Initialized
INFO - 2022-06-02 09:33:13 --> Config Class Initialized
INFO - 2022-06-02 09:33:13 --> Loader Class Initialized
INFO - 2022-06-02 09:33:13 --> Helper loaded: url_helper
INFO - 2022-06-02 09:33:13 --> Helper loaded: file_helper
INFO - 2022-06-02 09:33:13 --> Helper loaded: form_helper
INFO - 2022-06-02 09:33:13 --> Helper loaded: my_helper
INFO - 2022-06-02 09:33:13 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:33:13 --> Controller Class Initialized
INFO - 2022-06-02 09:33:13 --> Final output sent to browser
DEBUG - 2022-06-02 09:33:13 --> Total execution time: 0.0597
INFO - 2022-06-02 09:33:26 --> Config Class Initialized
INFO - 2022-06-02 09:33:26 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:33:26 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:33:26 --> Utf8 Class Initialized
INFO - 2022-06-02 09:33:26 --> URI Class Initialized
INFO - 2022-06-02 09:33:26 --> Router Class Initialized
INFO - 2022-06-02 09:33:26 --> Output Class Initialized
INFO - 2022-06-02 09:33:26 --> Security Class Initialized
DEBUG - 2022-06-02 09:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:33:26 --> Input Class Initialized
INFO - 2022-06-02 09:33:26 --> Language Class Initialized
INFO - 2022-06-02 09:33:26 --> Language Class Initialized
INFO - 2022-06-02 09:33:26 --> Config Class Initialized
INFO - 2022-06-02 09:33:26 --> Loader Class Initialized
INFO - 2022-06-02 09:33:26 --> Helper loaded: url_helper
INFO - 2022-06-02 09:33:26 --> Helper loaded: file_helper
INFO - 2022-06-02 09:33:26 --> Helper loaded: form_helper
INFO - 2022-06-02 09:33:26 --> Helper loaded: my_helper
INFO - 2022-06-02 09:33:26 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:33:26 --> Controller Class Initialized
DEBUG - 2022-06-02 09:33:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 09:33:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 09:33:26 --> Final output sent to browser
DEBUG - 2022-06-02 09:33:26 --> Total execution time: 0.0639
INFO - 2022-06-02 09:33:35 --> Config Class Initialized
INFO - 2022-06-02 09:33:35 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:33:35 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:33:35 --> Utf8 Class Initialized
INFO - 2022-06-02 09:33:35 --> URI Class Initialized
INFO - 2022-06-02 09:33:35 --> Router Class Initialized
INFO - 2022-06-02 09:33:35 --> Output Class Initialized
INFO - 2022-06-02 09:33:35 --> Security Class Initialized
DEBUG - 2022-06-02 09:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:33:35 --> Input Class Initialized
INFO - 2022-06-02 09:33:35 --> Language Class Initialized
INFO - 2022-06-02 09:33:35 --> Language Class Initialized
INFO - 2022-06-02 09:33:35 --> Config Class Initialized
INFO - 2022-06-02 09:33:35 --> Loader Class Initialized
INFO - 2022-06-02 09:33:35 --> Helper loaded: url_helper
INFO - 2022-06-02 09:33:35 --> Helper loaded: file_helper
INFO - 2022-06-02 09:33:35 --> Helper loaded: form_helper
INFO - 2022-06-02 09:33:35 --> Helper loaded: my_helper
INFO - 2022-06-02 09:33:35 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:33:35 --> Controller Class Initialized
INFO - 2022-06-02 09:33:35 --> Final output sent to browser
DEBUG - 2022-06-02 09:33:35 --> Total execution time: 0.0777
INFO - 2022-06-02 09:33:57 --> Config Class Initialized
INFO - 2022-06-02 09:33:57 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:33:57 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:33:57 --> Utf8 Class Initialized
INFO - 2022-06-02 09:33:57 --> URI Class Initialized
INFO - 2022-06-02 09:33:57 --> Router Class Initialized
INFO - 2022-06-02 09:33:57 --> Output Class Initialized
INFO - 2022-06-02 09:33:57 --> Security Class Initialized
DEBUG - 2022-06-02 09:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:33:57 --> Input Class Initialized
INFO - 2022-06-02 09:33:57 --> Language Class Initialized
INFO - 2022-06-02 09:33:57 --> Language Class Initialized
INFO - 2022-06-02 09:33:57 --> Config Class Initialized
INFO - 2022-06-02 09:33:57 --> Loader Class Initialized
INFO - 2022-06-02 09:33:57 --> Helper loaded: url_helper
INFO - 2022-06-02 09:33:57 --> Helper loaded: file_helper
INFO - 2022-06-02 09:33:57 --> Helper loaded: form_helper
INFO - 2022-06-02 09:33:57 --> Helper loaded: my_helper
INFO - 2022-06-02 09:33:57 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:33:57 --> Controller Class Initialized
DEBUG - 2022-06-02 09:33:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 09:33:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 09:33:57 --> Final output sent to browser
DEBUG - 2022-06-02 09:33:57 --> Total execution time: 0.0701
INFO - 2022-06-02 09:34:11 --> Config Class Initialized
INFO - 2022-06-02 09:34:11 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:34:11 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:34:11 --> Utf8 Class Initialized
INFO - 2022-06-02 09:34:11 --> URI Class Initialized
INFO - 2022-06-02 09:34:11 --> Router Class Initialized
INFO - 2022-06-02 09:34:11 --> Output Class Initialized
INFO - 2022-06-02 09:34:11 --> Security Class Initialized
DEBUG - 2022-06-02 09:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:34:11 --> Input Class Initialized
INFO - 2022-06-02 09:34:11 --> Language Class Initialized
INFO - 2022-06-02 09:34:11 --> Language Class Initialized
INFO - 2022-06-02 09:34:11 --> Config Class Initialized
INFO - 2022-06-02 09:34:11 --> Loader Class Initialized
INFO - 2022-06-02 09:34:11 --> Helper loaded: url_helper
INFO - 2022-06-02 09:34:11 --> Helper loaded: file_helper
INFO - 2022-06-02 09:34:11 --> Helper loaded: form_helper
INFO - 2022-06-02 09:34:11 --> Helper loaded: my_helper
INFO - 2022-06-02 09:34:11 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:34:11 --> Controller Class Initialized
INFO - 2022-06-02 09:34:11 --> Final output sent to browser
DEBUG - 2022-06-02 09:34:11 --> Total execution time: 0.0786
INFO - 2022-06-02 09:34:15 --> Config Class Initialized
INFO - 2022-06-02 09:34:15 --> Hooks Class Initialized
DEBUG - 2022-06-02 09:34:16 --> UTF-8 Support Enabled
INFO - 2022-06-02 09:34:16 --> Utf8 Class Initialized
INFO - 2022-06-02 09:34:16 --> URI Class Initialized
INFO - 2022-06-02 09:34:16 --> Router Class Initialized
INFO - 2022-06-02 09:34:16 --> Output Class Initialized
INFO - 2022-06-02 09:34:16 --> Security Class Initialized
DEBUG - 2022-06-02 09:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 09:34:16 --> Input Class Initialized
INFO - 2022-06-02 09:34:16 --> Language Class Initialized
INFO - 2022-06-02 09:34:16 --> Language Class Initialized
INFO - 2022-06-02 09:34:16 --> Config Class Initialized
INFO - 2022-06-02 09:34:16 --> Loader Class Initialized
INFO - 2022-06-02 09:34:16 --> Helper loaded: url_helper
INFO - 2022-06-02 09:34:16 --> Helper loaded: file_helper
INFO - 2022-06-02 09:34:16 --> Helper loaded: form_helper
INFO - 2022-06-02 09:34:16 --> Helper loaded: my_helper
INFO - 2022-06-02 09:34:16 --> Database Driver Class Initialized
DEBUG - 2022-06-02 09:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 09:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 09:34:16 --> Controller Class Initialized
DEBUG - 2022-06-02 09:34:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 09:34:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 09:34:16 --> Final output sent to browser
DEBUG - 2022-06-02 09:34:16 --> Total execution time: 0.0559
INFO - 2022-06-02 10:15:11 --> Config Class Initialized
INFO - 2022-06-02 10:15:11 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:15:11 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:15:11 --> Utf8 Class Initialized
INFO - 2022-06-02 10:15:11 --> URI Class Initialized
INFO - 2022-06-02 10:15:11 --> Router Class Initialized
INFO - 2022-06-02 10:15:11 --> Output Class Initialized
INFO - 2022-06-02 10:15:11 --> Security Class Initialized
DEBUG - 2022-06-02 10:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:15:11 --> Input Class Initialized
INFO - 2022-06-02 10:15:11 --> Language Class Initialized
INFO - 2022-06-02 10:15:11 --> Language Class Initialized
INFO - 2022-06-02 10:15:11 --> Config Class Initialized
INFO - 2022-06-02 10:15:11 --> Loader Class Initialized
INFO - 2022-06-02 10:15:11 --> Helper loaded: url_helper
INFO - 2022-06-02 10:15:11 --> Helper loaded: file_helper
INFO - 2022-06-02 10:15:11 --> Helper loaded: form_helper
INFO - 2022-06-02 10:15:11 --> Helper loaded: my_helper
INFO - 2022-06-02 10:15:11 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:15:11 --> Controller Class Initialized
ERROR - 2022-06-02 10:15:11 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                    a.*, b.nama, a.ekstra, a.nilai, a.ekstra2, a.nilai2
                                                    FROM t_nilai_ekstra a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2021','1',b.id)
                                                    WHERE c.id_kelas = '1' AND a.ta = '20212'
INFO - 2022-06-02 10:15:11 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-02 10:19:37 --> Config Class Initialized
INFO - 2022-06-02 10:19:37 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:19:37 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:19:37 --> Utf8 Class Initialized
INFO - 2022-06-02 10:19:37 --> URI Class Initialized
INFO - 2022-06-02 10:19:37 --> Router Class Initialized
INFO - 2022-06-02 10:19:37 --> Output Class Initialized
INFO - 2022-06-02 10:19:37 --> Security Class Initialized
DEBUG - 2022-06-02 10:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:19:37 --> Input Class Initialized
INFO - 2022-06-02 10:19:37 --> Language Class Initialized
INFO - 2022-06-02 10:19:37 --> Language Class Initialized
INFO - 2022-06-02 10:19:37 --> Config Class Initialized
INFO - 2022-06-02 10:19:37 --> Loader Class Initialized
INFO - 2022-06-02 10:19:37 --> Helper loaded: url_helper
INFO - 2022-06-02 10:19:37 --> Helper loaded: file_helper
INFO - 2022-06-02 10:19:37 --> Helper loaded: form_helper
INFO - 2022-06-02 10:19:37 --> Helper loaded: my_helper
INFO - 2022-06-02 10:19:37 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:19:37 --> Controller Class Initialized
DEBUG - 2022-06-02 10:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:19:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:19:37 --> Final output sent to browser
DEBUG - 2022-06-02 10:19:37 --> Total execution time: 0.0647
INFO - 2022-06-02 10:19:44 --> Config Class Initialized
INFO - 2022-06-02 10:19:44 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:19:44 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:19:44 --> Utf8 Class Initialized
INFO - 2022-06-02 10:19:44 --> URI Class Initialized
INFO - 2022-06-02 10:19:44 --> Router Class Initialized
INFO - 2022-06-02 10:19:44 --> Output Class Initialized
INFO - 2022-06-02 10:19:44 --> Security Class Initialized
DEBUG - 2022-06-02 10:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:19:44 --> Input Class Initialized
INFO - 2022-06-02 10:19:44 --> Language Class Initialized
INFO - 2022-06-02 10:19:44 --> Language Class Initialized
INFO - 2022-06-02 10:19:44 --> Config Class Initialized
INFO - 2022-06-02 10:19:44 --> Loader Class Initialized
INFO - 2022-06-02 10:19:44 --> Helper loaded: url_helper
INFO - 2022-06-02 10:19:44 --> Helper loaded: file_helper
INFO - 2022-06-02 10:19:44 --> Helper loaded: form_helper
INFO - 2022-06-02 10:19:44 --> Helper loaded: my_helper
INFO - 2022-06-02 10:19:44 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:19:44 --> Controller Class Initialized
ERROR - 2022-06-02 10:19:44 --> Severity: Notice --> Undefined variable: ta C:\xampp\htdocs\nilai\application\modules\n_ekstra\controllers\N_ekstra.php 48
INFO - 2022-06-02 10:19:44 --> Final output sent to browser
DEBUG - 2022-06-02 10:19:44 --> Total execution time: 0.0764
INFO - 2022-06-02 10:22:00 --> Config Class Initialized
INFO - 2022-06-02 10:22:00 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:22:00 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:22:00 --> Utf8 Class Initialized
INFO - 2022-06-02 10:22:00 --> URI Class Initialized
INFO - 2022-06-02 10:22:00 --> Router Class Initialized
INFO - 2022-06-02 10:22:00 --> Output Class Initialized
INFO - 2022-06-02 10:22:00 --> Security Class Initialized
DEBUG - 2022-06-02 10:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:22:00 --> Input Class Initialized
INFO - 2022-06-02 10:22:00 --> Language Class Initialized
INFO - 2022-06-02 10:22:00 --> Language Class Initialized
INFO - 2022-06-02 10:22:00 --> Config Class Initialized
INFO - 2022-06-02 10:22:00 --> Loader Class Initialized
INFO - 2022-06-02 10:22:00 --> Helper loaded: url_helper
INFO - 2022-06-02 10:22:00 --> Helper loaded: file_helper
INFO - 2022-06-02 10:22:00 --> Helper loaded: form_helper
INFO - 2022-06-02 10:22:00 --> Helper loaded: my_helper
INFO - 2022-06-02 10:22:00 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:22:00 --> Controller Class Initialized
DEBUG - 2022-06-02 10:22:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:22:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:22:00 --> Final output sent to browser
DEBUG - 2022-06-02 10:22:00 --> Total execution time: 0.0497
INFO - 2022-06-02 10:22:01 --> Config Class Initialized
INFO - 2022-06-02 10:22:01 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:22:01 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:22:01 --> Utf8 Class Initialized
INFO - 2022-06-02 10:22:01 --> URI Class Initialized
INFO - 2022-06-02 10:22:01 --> Router Class Initialized
INFO - 2022-06-02 10:22:01 --> Output Class Initialized
INFO - 2022-06-02 10:22:01 --> Security Class Initialized
DEBUG - 2022-06-02 10:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:22:01 --> Input Class Initialized
INFO - 2022-06-02 10:22:01 --> Language Class Initialized
INFO - 2022-06-02 10:22:01 --> Language Class Initialized
INFO - 2022-06-02 10:22:01 --> Config Class Initialized
INFO - 2022-06-02 10:22:01 --> Loader Class Initialized
INFO - 2022-06-02 10:22:01 --> Helper loaded: url_helper
INFO - 2022-06-02 10:22:01 --> Helper loaded: file_helper
INFO - 2022-06-02 10:22:01 --> Helper loaded: form_helper
INFO - 2022-06-02 10:22:01 --> Helper loaded: my_helper
INFO - 2022-06-02 10:22:01 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:22:01 --> Controller Class Initialized
DEBUG - 2022-06-02 10:22:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:22:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:22:01 --> Final output sent to browser
DEBUG - 2022-06-02 10:22:01 --> Total execution time: 0.0672
INFO - 2022-06-02 10:22:15 --> Config Class Initialized
INFO - 2022-06-02 10:22:15 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:22:15 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:22:15 --> Utf8 Class Initialized
INFO - 2022-06-02 10:22:15 --> URI Class Initialized
INFO - 2022-06-02 10:22:15 --> Router Class Initialized
INFO - 2022-06-02 10:22:15 --> Output Class Initialized
INFO - 2022-06-02 10:22:15 --> Security Class Initialized
DEBUG - 2022-06-02 10:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:22:15 --> Input Class Initialized
INFO - 2022-06-02 10:22:15 --> Language Class Initialized
INFO - 2022-06-02 10:22:15 --> Language Class Initialized
INFO - 2022-06-02 10:22:15 --> Config Class Initialized
INFO - 2022-06-02 10:22:15 --> Loader Class Initialized
INFO - 2022-06-02 10:22:15 --> Helper loaded: url_helper
INFO - 2022-06-02 10:22:15 --> Helper loaded: file_helper
INFO - 2022-06-02 10:22:15 --> Helper loaded: form_helper
INFO - 2022-06-02 10:22:15 --> Helper loaded: my_helper
INFO - 2022-06-02 10:22:15 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:22:15 --> Controller Class Initialized
DEBUG - 2022-06-02 10:22:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:22:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:22:15 --> Final output sent to browser
DEBUG - 2022-06-02 10:22:15 --> Total execution time: 0.0468
INFO - 2022-06-02 10:22:16 --> Config Class Initialized
INFO - 2022-06-02 10:22:16 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:22:16 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:22:16 --> Utf8 Class Initialized
INFO - 2022-06-02 10:22:16 --> URI Class Initialized
INFO - 2022-06-02 10:22:16 --> Router Class Initialized
INFO - 2022-06-02 10:22:16 --> Output Class Initialized
INFO - 2022-06-02 10:22:16 --> Security Class Initialized
DEBUG - 2022-06-02 10:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:22:16 --> Input Class Initialized
INFO - 2022-06-02 10:22:16 --> Language Class Initialized
INFO - 2022-06-02 10:22:16 --> Language Class Initialized
INFO - 2022-06-02 10:22:16 --> Config Class Initialized
INFO - 2022-06-02 10:22:16 --> Loader Class Initialized
INFO - 2022-06-02 10:22:16 --> Helper loaded: url_helper
INFO - 2022-06-02 10:22:16 --> Helper loaded: file_helper
INFO - 2022-06-02 10:22:16 --> Helper loaded: form_helper
INFO - 2022-06-02 10:22:16 --> Helper loaded: my_helper
INFO - 2022-06-02 10:22:16 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:22:16 --> Controller Class Initialized
DEBUG - 2022-06-02 10:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:22:16 --> Final output sent to browser
DEBUG - 2022-06-02 10:22:16 --> Total execution time: 0.0638
INFO - 2022-06-02 10:22:16 --> Config Class Initialized
INFO - 2022-06-02 10:22:16 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:22:16 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:22:16 --> Utf8 Class Initialized
INFO - 2022-06-02 10:22:16 --> URI Class Initialized
INFO - 2022-06-02 10:22:16 --> Router Class Initialized
INFO - 2022-06-02 10:22:16 --> Output Class Initialized
INFO - 2022-06-02 10:22:16 --> Security Class Initialized
DEBUG - 2022-06-02 10:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:22:16 --> Input Class Initialized
INFO - 2022-06-02 10:22:16 --> Language Class Initialized
INFO - 2022-06-02 10:22:16 --> Language Class Initialized
INFO - 2022-06-02 10:22:16 --> Config Class Initialized
INFO - 2022-06-02 10:22:16 --> Loader Class Initialized
INFO - 2022-06-02 10:22:16 --> Helper loaded: url_helper
INFO - 2022-06-02 10:22:16 --> Helper loaded: file_helper
INFO - 2022-06-02 10:22:16 --> Helper loaded: form_helper
INFO - 2022-06-02 10:22:16 --> Helper loaded: my_helper
INFO - 2022-06-02 10:22:16 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:22:16 --> Controller Class Initialized
DEBUG - 2022-06-02 10:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:22:16 --> Final output sent to browser
DEBUG - 2022-06-02 10:22:16 --> Total execution time: 0.0664
INFO - 2022-06-02 10:22:23 --> Config Class Initialized
INFO - 2022-06-02 10:22:23 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:22:23 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:22:23 --> Utf8 Class Initialized
INFO - 2022-06-02 10:22:23 --> URI Class Initialized
INFO - 2022-06-02 10:22:23 --> Router Class Initialized
INFO - 2022-06-02 10:22:23 --> Output Class Initialized
INFO - 2022-06-02 10:22:23 --> Security Class Initialized
DEBUG - 2022-06-02 10:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:22:23 --> Input Class Initialized
INFO - 2022-06-02 10:22:23 --> Language Class Initialized
INFO - 2022-06-02 10:22:23 --> Language Class Initialized
INFO - 2022-06-02 10:22:23 --> Config Class Initialized
INFO - 2022-06-02 10:22:23 --> Loader Class Initialized
INFO - 2022-06-02 10:22:23 --> Helper loaded: url_helper
INFO - 2022-06-02 10:22:23 --> Helper loaded: file_helper
INFO - 2022-06-02 10:22:23 --> Helper loaded: form_helper
INFO - 2022-06-02 10:22:23 --> Helper loaded: my_helper
INFO - 2022-06-02 10:22:23 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:22:23 --> Controller Class Initialized
INFO - 2022-06-02 10:22:23 --> Final output sent to browser
DEBUG - 2022-06-02 10:22:23 --> Total execution time: 0.0706
INFO - 2022-06-02 10:22:24 --> Config Class Initialized
INFO - 2022-06-02 10:22:24 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:22:24 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:22:24 --> Utf8 Class Initialized
INFO - 2022-06-02 10:22:24 --> URI Class Initialized
INFO - 2022-06-02 10:22:24 --> Router Class Initialized
INFO - 2022-06-02 10:22:24 --> Output Class Initialized
INFO - 2022-06-02 10:22:24 --> Security Class Initialized
DEBUG - 2022-06-02 10:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:22:24 --> Input Class Initialized
INFO - 2022-06-02 10:22:24 --> Language Class Initialized
INFO - 2022-06-02 10:22:24 --> Language Class Initialized
INFO - 2022-06-02 10:22:24 --> Config Class Initialized
INFO - 2022-06-02 10:22:24 --> Loader Class Initialized
INFO - 2022-06-02 10:22:24 --> Helper loaded: url_helper
INFO - 2022-06-02 10:22:24 --> Helper loaded: file_helper
INFO - 2022-06-02 10:22:24 --> Helper loaded: form_helper
INFO - 2022-06-02 10:22:24 --> Helper loaded: my_helper
INFO - 2022-06-02 10:22:24 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:22:24 --> Controller Class Initialized
DEBUG - 2022-06-02 10:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:22:24 --> Final output sent to browser
DEBUG - 2022-06-02 10:22:24 --> Total execution time: 0.0770
INFO - 2022-06-02 10:22:25 --> Config Class Initialized
INFO - 2022-06-02 10:22:25 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:22:25 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:22:25 --> Utf8 Class Initialized
INFO - 2022-06-02 10:22:25 --> URI Class Initialized
INFO - 2022-06-02 10:22:25 --> Router Class Initialized
INFO - 2022-06-02 10:22:25 --> Output Class Initialized
INFO - 2022-06-02 10:22:25 --> Security Class Initialized
DEBUG - 2022-06-02 10:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:22:25 --> Input Class Initialized
INFO - 2022-06-02 10:22:25 --> Language Class Initialized
INFO - 2022-06-02 10:22:25 --> Language Class Initialized
INFO - 2022-06-02 10:22:25 --> Config Class Initialized
INFO - 2022-06-02 10:22:25 --> Loader Class Initialized
INFO - 2022-06-02 10:22:25 --> Helper loaded: url_helper
INFO - 2022-06-02 10:22:25 --> Helper loaded: file_helper
INFO - 2022-06-02 10:22:25 --> Helper loaded: form_helper
INFO - 2022-06-02 10:22:25 --> Helper loaded: my_helper
INFO - 2022-06-02 10:22:25 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:22:25 --> Controller Class Initialized
DEBUG - 2022-06-02 10:22:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:22:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:22:25 --> Final output sent to browser
DEBUG - 2022-06-02 10:22:25 --> Total execution time: 0.0566
INFO - 2022-06-02 10:22:46 --> Config Class Initialized
INFO - 2022-06-02 10:22:46 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:22:46 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:22:46 --> Utf8 Class Initialized
INFO - 2022-06-02 10:22:46 --> URI Class Initialized
INFO - 2022-06-02 10:22:46 --> Router Class Initialized
INFO - 2022-06-02 10:22:46 --> Output Class Initialized
INFO - 2022-06-02 10:22:46 --> Security Class Initialized
DEBUG - 2022-06-02 10:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:22:46 --> Input Class Initialized
INFO - 2022-06-02 10:22:46 --> Language Class Initialized
INFO - 2022-06-02 10:22:46 --> Language Class Initialized
INFO - 2022-06-02 10:22:46 --> Config Class Initialized
INFO - 2022-06-02 10:22:46 --> Loader Class Initialized
INFO - 2022-06-02 10:22:46 --> Helper loaded: url_helper
INFO - 2022-06-02 10:22:46 --> Helper loaded: file_helper
INFO - 2022-06-02 10:22:46 --> Helper loaded: form_helper
INFO - 2022-06-02 10:22:46 --> Helper loaded: my_helper
INFO - 2022-06-02 10:22:46 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:22:46 --> Controller Class Initialized
DEBUG - 2022-06-02 10:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:22:46 --> Final output sent to browser
DEBUG - 2022-06-02 10:22:46 --> Total execution time: 0.0773
INFO - 2022-06-02 10:23:23 --> Config Class Initialized
INFO - 2022-06-02 10:23:23 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:23:23 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:23:23 --> Utf8 Class Initialized
INFO - 2022-06-02 10:23:23 --> URI Class Initialized
INFO - 2022-06-02 10:23:23 --> Router Class Initialized
INFO - 2022-06-02 10:23:23 --> Output Class Initialized
INFO - 2022-06-02 10:23:23 --> Security Class Initialized
DEBUG - 2022-06-02 10:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:23:23 --> Input Class Initialized
INFO - 2022-06-02 10:23:23 --> Language Class Initialized
INFO - 2022-06-02 10:23:23 --> Language Class Initialized
INFO - 2022-06-02 10:23:23 --> Config Class Initialized
INFO - 2022-06-02 10:23:23 --> Loader Class Initialized
INFO - 2022-06-02 10:23:23 --> Helper loaded: url_helper
INFO - 2022-06-02 10:23:23 --> Helper loaded: file_helper
INFO - 2022-06-02 10:23:23 --> Helper loaded: form_helper
INFO - 2022-06-02 10:23:23 --> Helper loaded: my_helper
INFO - 2022-06-02 10:23:23 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:23:23 --> Controller Class Initialized
INFO - 2022-06-02 10:23:23 --> Final output sent to browser
DEBUG - 2022-06-02 10:23:23 --> Total execution time: 0.0560
INFO - 2022-06-02 10:23:24 --> Config Class Initialized
INFO - 2022-06-02 10:23:24 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:23:24 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:23:24 --> Utf8 Class Initialized
INFO - 2022-06-02 10:23:24 --> URI Class Initialized
INFO - 2022-06-02 10:23:24 --> Router Class Initialized
INFO - 2022-06-02 10:23:24 --> Output Class Initialized
INFO - 2022-06-02 10:23:24 --> Security Class Initialized
DEBUG - 2022-06-02 10:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:23:24 --> Input Class Initialized
INFO - 2022-06-02 10:23:24 --> Language Class Initialized
INFO - 2022-06-02 10:23:24 --> Language Class Initialized
INFO - 2022-06-02 10:23:24 --> Config Class Initialized
INFO - 2022-06-02 10:23:24 --> Loader Class Initialized
INFO - 2022-06-02 10:23:24 --> Helper loaded: url_helper
INFO - 2022-06-02 10:23:24 --> Helper loaded: file_helper
INFO - 2022-06-02 10:23:24 --> Helper loaded: form_helper
INFO - 2022-06-02 10:23:24 --> Helper loaded: my_helper
INFO - 2022-06-02 10:23:24 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:23:24 --> Controller Class Initialized
DEBUG - 2022-06-02 10:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:23:24 --> Final output sent to browser
DEBUG - 2022-06-02 10:23:24 --> Total execution time: 0.0603
INFO - 2022-06-02 10:23:25 --> Config Class Initialized
INFO - 2022-06-02 10:23:25 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:23:25 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:23:25 --> Utf8 Class Initialized
INFO - 2022-06-02 10:23:25 --> URI Class Initialized
INFO - 2022-06-02 10:23:25 --> Router Class Initialized
INFO - 2022-06-02 10:23:25 --> Output Class Initialized
INFO - 2022-06-02 10:23:25 --> Security Class Initialized
DEBUG - 2022-06-02 10:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:23:25 --> Input Class Initialized
INFO - 2022-06-02 10:23:26 --> Language Class Initialized
INFO - 2022-06-02 10:23:26 --> Language Class Initialized
INFO - 2022-06-02 10:23:26 --> Config Class Initialized
INFO - 2022-06-02 10:23:26 --> Loader Class Initialized
INFO - 2022-06-02 10:23:26 --> Helper loaded: url_helper
INFO - 2022-06-02 10:23:26 --> Helper loaded: file_helper
INFO - 2022-06-02 10:23:26 --> Helper loaded: form_helper
INFO - 2022-06-02 10:23:26 --> Helper loaded: my_helper
INFO - 2022-06-02 10:23:26 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:23:26 --> Controller Class Initialized
DEBUG - 2022-06-02 10:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-06-02 10:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:23:26 --> Final output sent to browser
DEBUG - 2022-06-02 10:23:26 --> Total execution time: 0.0689
INFO - 2022-06-02 10:23:42 --> Config Class Initialized
INFO - 2022-06-02 10:23:42 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:23:42 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:23:42 --> Utf8 Class Initialized
INFO - 2022-06-02 10:23:42 --> URI Class Initialized
INFO - 2022-06-02 10:23:42 --> Router Class Initialized
INFO - 2022-06-02 10:23:42 --> Output Class Initialized
INFO - 2022-06-02 10:23:42 --> Security Class Initialized
DEBUG - 2022-06-02 10:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:23:42 --> Input Class Initialized
INFO - 2022-06-02 10:23:42 --> Language Class Initialized
INFO - 2022-06-02 10:23:42 --> Language Class Initialized
INFO - 2022-06-02 10:23:42 --> Config Class Initialized
INFO - 2022-06-02 10:23:42 --> Loader Class Initialized
INFO - 2022-06-02 10:23:42 --> Helper loaded: url_helper
INFO - 2022-06-02 10:23:42 --> Helper loaded: file_helper
INFO - 2022-06-02 10:23:42 --> Helper loaded: form_helper
INFO - 2022-06-02 10:23:42 --> Helper loaded: my_helper
INFO - 2022-06-02 10:23:42 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:23:42 --> Controller Class Initialized
DEBUG - 2022-06-02 10:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-06-02 10:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:23:42 --> Final output sent to browser
DEBUG - 2022-06-02 10:23:42 --> Total execution time: 0.1424
INFO - 2022-06-02 10:23:44 --> Config Class Initialized
INFO - 2022-06-02 10:23:44 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:23:44 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:23:44 --> Utf8 Class Initialized
INFO - 2022-06-02 10:23:44 --> URI Class Initialized
INFO - 2022-06-02 10:23:44 --> Router Class Initialized
INFO - 2022-06-02 10:23:44 --> Output Class Initialized
INFO - 2022-06-02 10:23:44 --> Security Class Initialized
DEBUG - 2022-06-02 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:23:44 --> Input Class Initialized
INFO - 2022-06-02 10:23:44 --> Language Class Initialized
INFO - 2022-06-02 10:23:44 --> Language Class Initialized
INFO - 2022-06-02 10:23:44 --> Config Class Initialized
INFO - 2022-06-02 10:23:44 --> Loader Class Initialized
INFO - 2022-06-02 10:23:44 --> Helper loaded: url_helper
INFO - 2022-06-02 10:23:44 --> Helper loaded: file_helper
INFO - 2022-06-02 10:23:44 --> Helper loaded: form_helper
INFO - 2022-06-02 10:23:44 --> Helper loaded: my_helper
INFO - 2022-06-02 10:23:44 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:23:44 --> Controller Class Initialized
ERROR - 2022-06-02 10:23:44 --> Query error: Unknown column 'a.desk' in 'field list' - Invalid query: SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = 1 AND a.nilai != '0' AND a.tasm = '20212'
INFO - 2022-06-02 10:23:44 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-02 10:23:47 --> Config Class Initialized
INFO - 2022-06-02 10:23:47 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:23:47 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:23:47 --> Utf8 Class Initialized
INFO - 2022-06-02 10:23:47 --> URI Class Initialized
INFO - 2022-06-02 10:23:47 --> Router Class Initialized
INFO - 2022-06-02 10:23:47 --> Output Class Initialized
INFO - 2022-06-02 10:23:47 --> Security Class Initialized
DEBUG - 2022-06-02 10:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:23:47 --> Input Class Initialized
INFO - 2022-06-02 10:23:47 --> Language Class Initialized
INFO - 2022-06-02 10:23:47 --> Language Class Initialized
INFO - 2022-06-02 10:23:47 --> Config Class Initialized
INFO - 2022-06-02 10:23:47 --> Loader Class Initialized
INFO - 2022-06-02 10:23:47 --> Helper loaded: url_helper
INFO - 2022-06-02 10:23:47 --> Helper loaded: file_helper
INFO - 2022-06-02 10:23:47 --> Helper loaded: form_helper
INFO - 2022-06-02 10:23:47 --> Helper loaded: my_helper
INFO - 2022-06-02 10:23:47 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:23:47 --> Controller Class Initialized
ERROR - 2022-06-02 10:23:47 --> Query error: Unknown column 'tasm' in 'where clause' - Invalid query: SELECT 
                                    		ekstra, nilai, ekstra2, nilai2
                                    		FROM t_nilai_ekstra
                                    		WHERE id_siswa = 1 AND tasm = '20212'
INFO - 2022-06-02 10:23:47 --> Language file loaded: language/english/db_lang.php
INFO - 2022-06-02 10:23:52 --> Config Class Initialized
INFO - 2022-06-02 10:23:52 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:23:52 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:23:52 --> Utf8 Class Initialized
INFO - 2022-06-02 10:23:52 --> URI Class Initialized
INFO - 2022-06-02 10:23:52 --> Router Class Initialized
INFO - 2022-06-02 10:23:52 --> Output Class Initialized
INFO - 2022-06-02 10:23:52 --> Security Class Initialized
DEBUG - 2022-06-02 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:23:52 --> Input Class Initialized
INFO - 2022-06-02 10:23:52 --> Language Class Initialized
INFO - 2022-06-02 10:23:52 --> Language Class Initialized
INFO - 2022-06-02 10:23:52 --> Config Class Initialized
INFO - 2022-06-02 10:23:52 --> Loader Class Initialized
INFO - 2022-06-02 10:23:52 --> Helper loaded: url_helper
INFO - 2022-06-02 10:23:52 --> Helper loaded: file_helper
INFO - 2022-06-02 10:23:52 --> Helper loaded: form_helper
INFO - 2022-06-02 10:23:52 --> Helper loaded: my_helper
INFO - 2022-06-02 10:23:52 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:23:52 --> Controller Class Initialized
INFO - 2022-06-02 10:23:52 --> Helper loaded: cookie_helper
INFO - 2022-06-02 10:23:52 --> Config Class Initialized
INFO - 2022-06-02 10:23:52 --> Hooks Class Initialized
DEBUG - 2022-06-02 10:23:52 --> UTF-8 Support Enabled
INFO - 2022-06-02 10:23:52 --> Utf8 Class Initialized
INFO - 2022-06-02 10:23:52 --> URI Class Initialized
INFO - 2022-06-02 10:23:52 --> Router Class Initialized
INFO - 2022-06-02 10:23:52 --> Output Class Initialized
INFO - 2022-06-02 10:23:52 --> Security Class Initialized
DEBUG - 2022-06-02 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-02 10:23:52 --> Input Class Initialized
INFO - 2022-06-02 10:23:52 --> Language Class Initialized
INFO - 2022-06-02 10:23:52 --> Language Class Initialized
INFO - 2022-06-02 10:23:52 --> Config Class Initialized
INFO - 2022-06-02 10:23:52 --> Loader Class Initialized
INFO - 2022-06-02 10:23:52 --> Helper loaded: url_helper
INFO - 2022-06-02 10:23:52 --> Helper loaded: file_helper
INFO - 2022-06-02 10:23:52 --> Helper loaded: form_helper
INFO - 2022-06-02 10:23:52 --> Helper loaded: my_helper
INFO - 2022-06-02 10:23:52 --> Database Driver Class Initialized
DEBUG - 2022-06-02 10:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-02 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-02 10:23:52 --> Controller Class Initialized
DEBUG - 2022-06-02 10:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-02 10:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-02 10:23:52 --> Final output sent to browser
DEBUG - 2022-06-02 10:23:52 --> Total execution time: 0.0472
