<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-04-25 05:30:10 --> Config Class Initialized
INFO - 2022-04-25 05:30:10 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:30:10 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:30:10 --> Utf8 Class Initialized
INFO - 2022-04-25 05:30:10 --> URI Class Initialized
DEBUG - 2022-04-25 05:30:10 --> No URI present. Default controller set.
INFO - 2022-04-25 05:30:10 --> Router Class Initialized
INFO - 2022-04-25 05:30:10 --> Output Class Initialized
INFO - 2022-04-25 05:30:10 --> Security Class Initialized
DEBUG - 2022-04-25 05:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:30:10 --> Input Class Initialized
INFO - 2022-04-25 05:30:10 --> Language Class Initialized
INFO - 2022-04-25 05:30:10 --> Language Class Initialized
INFO - 2022-04-25 05:30:10 --> Config Class Initialized
INFO - 2022-04-25 05:30:10 --> Loader Class Initialized
INFO - 2022-04-25 05:30:10 --> Helper loaded: url_helper
INFO - 2022-04-25 05:30:10 --> Helper loaded: file_helper
INFO - 2022-04-25 05:30:10 --> Helper loaded: form_helper
INFO - 2022-04-25 05:30:10 --> Helper loaded: my_helper
INFO - 2022-04-25 05:30:10 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:30:10 --> Controller Class Initialized
INFO - 2022-04-25 05:30:11 --> Config Class Initialized
INFO - 2022-04-25 05:30:11 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:30:11 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:30:11 --> Utf8 Class Initialized
INFO - 2022-04-25 05:30:11 --> URI Class Initialized
INFO - 2022-04-25 05:30:11 --> Router Class Initialized
INFO - 2022-04-25 05:30:11 --> Output Class Initialized
INFO - 2022-04-25 05:30:11 --> Security Class Initialized
DEBUG - 2022-04-25 05:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:30:11 --> Input Class Initialized
INFO - 2022-04-25 05:30:11 --> Language Class Initialized
INFO - 2022-04-25 05:30:11 --> Language Class Initialized
INFO - 2022-04-25 05:30:11 --> Config Class Initialized
INFO - 2022-04-25 05:30:11 --> Loader Class Initialized
INFO - 2022-04-25 05:30:11 --> Helper loaded: url_helper
INFO - 2022-04-25 05:30:11 --> Helper loaded: file_helper
INFO - 2022-04-25 05:30:11 --> Helper loaded: form_helper
INFO - 2022-04-25 05:30:11 --> Helper loaded: my_helper
INFO - 2022-04-25 05:30:11 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:30:11 --> Controller Class Initialized
DEBUG - 2022-04-25 05:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-04-25 05:30:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:30:11 --> Final output sent to browser
DEBUG - 2022-04-25 05:30:11 --> Total execution time: 0.1584
INFO - 2022-04-25 05:33:38 --> Config Class Initialized
INFO - 2022-04-25 05:33:38 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:33:38 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:33:38 --> Utf8 Class Initialized
INFO - 2022-04-25 05:33:38 --> URI Class Initialized
INFO - 2022-04-25 05:33:38 --> Router Class Initialized
INFO - 2022-04-25 05:33:38 --> Output Class Initialized
INFO - 2022-04-25 05:33:38 --> Security Class Initialized
DEBUG - 2022-04-25 05:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:33:38 --> Input Class Initialized
INFO - 2022-04-25 05:33:38 --> Language Class Initialized
INFO - 2022-04-25 05:33:38 --> Language Class Initialized
INFO - 2022-04-25 05:33:38 --> Config Class Initialized
INFO - 2022-04-25 05:33:38 --> Loader Class Initialized
INFO - 2022-04-25 05:33:38 --> Helper loaded: url_helper
INFO - 2022-04-25 05:33:38 --> Helper loaded: file_helper
INFO - 2022-04-25 05:33:38 --> Helper loaded: form_helper
INFO - 2022-04-25 05:33:38 --> Helper loaded: my_helper
INFO - 2022-04-25 05:33:38 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:33:38 --> Controller Class Initialized
INFO - 2022-04-25 05:33:38 --> Helper loaded: cookie_helper
INFO - 2022-04-25 05:33:38 --> Final output sent to browser
DEBUG - 2022-04-25 05:33:38 --> Total execution time: 0.1087
INFO - 2022-04-25 05:33:38 --> Config Class Initialized
INFO - 2022-04-25 05:33:38 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:33:38 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:33:38 --> Utf8 Class Initialized
INFO - 2022-04-25 05:33:38 --> URI Class Initialized
INFO - 2022-04-25 05:33:38 --> Router Class Initialized
INFO - 2022-04-25 05:33:38 --> Output Class Initialized
INFO - 2022-04-25 05:33:38 --> Security Class Initialized
DEBUG - 2022-04-25 05:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:33:38 --> Input Class Initialized
INFO - 2022-04-25 05:33:38 --> Language Class Initialized
INFO - 2022-04-25 05:33:38 --> Language Class Initialized
INFO - 2022-04-25 05:33:38 --> Config Class Initialized
INFO - 2022-04-25 05:33:38 --> Loader Class Initialized
INFO - 2022-04-25 05:33:38 --> Helper loaded: url_helper
INFO - 2022-04-25 05:33:38 --> Helper loaded: file_helper
INFO - 2022-04-25 05:33:38 --> Helper loaded: form_helper
INFO - 2022-04-25 05:33:38 --> Helper loaded: my_helper
INFO - 2022-04-25 05:33:38 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:33:38 --> Controller Class Initialized
DEBUG - 2022-04-25 05:33:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-04-25 05:33:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:33:39 --> Final output sent to browser
DEBUG - 2022-04-25 05:33:39 --> Total execution time: 0.9955
INFO - 2022-04-25 05:34:24 --> Config Class Initialized
INFO - 2022-04-25 05:34:24 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:24 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:24 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:24 --> URI Class Initialized
INFO - 2022-04-25 05:34:24 --> Router Class Initialized
INFO - 2022-04-25 05:34:24 --> Output Class Initialized
INFO - 2022-04-25 05:34:24 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:24 --> Input Class Initialized
INFO - 2022-04-25 05:34:24 --> Language Class Initialized
INFO - 2022-04-25 05:34:24 --> Language Class Initialized
INFO - 2022-04-25 05:34:24 --> Config Class Initialized
INFO - 2022-04-25 05:34:24 --> Loader Class Initialized
INFO - 2022-04-25 05:34:24 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:24 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:24 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:24 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:24 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:24 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2022-04-25 05:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:24 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:24 --> Total execution time: 0.1017
INFO - 2022-04-25 05:34:24 --> Config Class Initialized
INFO - 2022-04-25 05:34:24 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:24 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:24 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:24 --> URI Class Initialized
INFO - 2022-04-25 05:34:24 --> Router Class Initialized
INFO - 2022-04-25 05:34:24 --> Output Class Initialized
INFO - 2022-04-25 05:34:24 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:24 --> Input Class Initialized
INFO - 2022-04-25 05:34:24 --> Language Class Initialized
INFO - 2022-04-25 05:34:24 --> Language Class Initialized
INFO - 2022-04-25 05:34:24 --> Config Class Initialized
INFO - 2022-04-25 05:34:24 --> Loader Class Initialized
INFO - 2022-04-25 05:34:24 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:24 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:24 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:24 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:24 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:24 --> Controller Class Initialized
INFO - 2022-04-25 05:34:33 --> Config Class Initialized
INFO - 2022-04-25 05:34:33 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:33 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:33 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:33 --> URI Class Initialized
INFO - 2022-04-25 05:34:33 --> Router Class Initialized
INFO - 2022-04-25 05:34:33 --> Output Class Initialized
INFO - 2022-04-25 05:34:33 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:33 --> Input Class Initialized
INFO - 2022-04-25 05:34:33 --> Language Class Initialized
INFO - 2022-04-25 05:34:33 --> Language Class Initialized
INFO - 2022-04-25 05:34:33 --> Config Class Initialized
INFO - 2022-04-25 05:34:33 --> Loader Class Initialized
INFO - 2022-04-25 05:34:33 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:33 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:33 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:33 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:33 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:33 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-04-25 05:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:33 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:33 --> Total execution time: 0.0814
INFO - 2022-04-25 05:34:33 --> Config Class Initialized
INFO - 2022-04-25 05:34:33 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:33 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:33 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:33 --> URI Class Initialized
INFO - 2022-04-25 05:34:33 --> Router Class Initialized
INFO - 2022-04-25 05:34:33 --> Output Class Initialized
INFO - 2022-04-25 05:34:33 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:33 --> Input Class Initialized
INFO - 2022-04-25 05:34:33 --> Language Class Initialized
INFO - 2022-04-25 05:34:33 --> Language Class Initialized
INFO - 2022-04-25 05:34:33 --> Config Class Initialized
INFO - 2022-04-25 05:34:33 --> Loader Class Initialized
INFO - 2022-04-25 05:34:33 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:33 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:33 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:33 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:33 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:33 --> Controller Class Initialized
INFO - 2022-04-25 05:34:34 --> Config Class Initialized
INFO - 2022-04-25 05:34:34 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:34 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:34 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:34 --> URI Class Initialized
INFO - 2022-04-25 05:34:34 --> Router Class Initialized
INFO - 2022-04-25 05:34:34 --> Output Class Initialized
INFO - 2022-04-25 05:34:34 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:34 --> Input Class Initialized
INFO - 2022-04-25 05:34:34 --> Language Class Initialized
INFO - 2022-04-25 05:34:34 --> Language Class Initialized
INFO - 2022-04-25 05:34:34 --> Config Class Initialized
INFO - 2022-04-25 05:34:34 --> Loader Class Initialized
INFO - 2022-04-25 05:34:34 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:34 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:34 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:34 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:34 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:34 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2022-04-25 05:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:34 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:34 --> Total execution time: 0.0815
INFO - 2022-04-25 05:34:34 --> Config Class Initialized
INFO - 2022-04-25 05:34:34 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:34 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:34 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:34 --> URI Class Initialized
INFO - 2022-04-25 05:34:34 --> Router Class Initialized
INFO - 2022-04-25 05:34:34 --> Output Class Initialized
INFO - 2022-04-25 05:34:34 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:34 --> Input Class Initialized
INFO - 2022-04-25 05:34:34 --> Language Class Initialized
INFO - 2022-04-25 05:34:34 --> Language Class Initialized
INFO - 2022-04-25 05:34:34 --> Config Class Initialized
INFO - 2022-04-25 05:34:34 --> Loader Class Initialized
INFO - 2022-04-25 05:34:34 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:34 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:34 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:34 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:34 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:34 --> Controller Class Initialized
INFO - 2022-04-25 05:34:36 --> Config Class Initialized
INFO - 2022-04-25 05:34:36 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:36 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:36 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:36 --> URI Class Initialized
INFO - 2022-04-25 05:34:36 --> Router Class Initialized
INFO - 2022-04-25 05:34:36 --> Output Class Initialized
INFO - 2022-04-25 05:34:36 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:36 --> Input Class Initialized
INFO - 2022-04-25 05:34:36 --> Language Class Initialized
INFO - 2022-04-25 05:34:36 --> Language Class Initialized
INFO - 2022-04-25 05:34:36 --> Config Class Initialized
INFO - 2022-04-25 05:34:36 --> Loader Class Initialized
INFO - 2022-04-25 05:34:36 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:36 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:36 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:36 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:36 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:36 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-04-25 05:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:36 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:36 --> Total execution time: 0.1232
INFO - 2022-04-25 05:34:43 --> Config Class Initialized
INFO - 2022-04-25 05:34:43 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:43 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:43 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:43 --> URI Class Initialized
INFO - 2022-04-25 05:34:43 --> Router Class Initialized
INFO - 2022-04-25 05:34:43 --> Output Class Initialized
INFO - 2022-04-25 05:34:43 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:43 --> Input Class Initialized
INFO - 2022-04-25 05:34:43 --> Language Class Initialized
INFO - 2022-04-25 05:34:43 --> Language Class Initialized
INFO - 2022-04-25 05:34:43 --> Config Class Initialized
INFO - 2022-04-25 05:34:43 --> Loader Class Initialized
INFO - 2022-04-25 05:34:43 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:43 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:43 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:43 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:43 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:43 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-04-25 05:34:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:43 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:43 --> Total execution time: 0.0961
INFO - 2022-04-25 05:34:43 --> Config Class Initialized
INFO - 2022-04-25 05:34:43 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:43 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:43 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:43 --> URI Class Initialized
INFO - 2022-04-25 05:34:43 --> Router Class Initialized
INFO - 2022-04-25 05:34:43 --> Output Class Initialized
INFO - 2022-04-25 05:34:43 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:43 --> Input Class Initialized
INFO - 2022-04-25 05:34:43 --> Language Class Initialized
INFO - 2022-04-25 05:34:43 --> Language Class Initialized
INFO - 2022-04-25 05:34:43 --> Config Class Initialized
INFO - 2022-04-25 05:34:43 --> Loader Class Initialized
INFO - 2022-04-25 05:34:43 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:43 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:43 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:43 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:43 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:43 --> Controller Class Initialized
INFO - 2022-04-25 05:34:45 --> Config Class Initialized
INFO - 2022-04-25 05:34:45 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:45 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:45 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:45 --> URI Class Initialized
INFO - 2022-04-25 05:34:45 --> Router Class Initialized
INFO - 2022-04-25 05:34:45 --> Output Class Initialized
INFO - 2022-04-25 05:34:45 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:45 --> Input Class Initialized
INFO - 2022-04-25 05:34:45 --> Language Class Initialized
INFO - 2022-04-25 05:34:45 --> Language Class Initialized
INFO - 2022-04-25 05:34:45 --> Config Class Initialized
INFO - 2022-04-25 05:34:45 --> Loader Class Initialized
INFO - 2022-04-25 05:34:45 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:45 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:45 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:45 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:45 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:45 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2022-04-25 05:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:45 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:45 --> Total execution time: 0.0991
INFO - 2022-04-25 05:34:45 --> Config Class Initialized
INFO - 2022-04-25 05:34:45 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:45 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:45 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:45 --> URI Class Initialized
INFO - 2022-04-25 05:34:45 --> Router Class Initialized
INFO - 2022-04-25 05:34:45 --> Output Class Initialized
INFO - 2022-04-25 05:34:45 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:45 --> Input Class Initialized
INFO - 2022-04-25 05:34:45 --> Language Class Initialized
INFO - 2022-04-25 05:34:45 --> Language Class Initialized
INFO - 2022-04-25 05:34:45 --> Config Class Initialized
INFO - 2022-04-25 05:34:45 --> Loader Class Initialized
INFO - 2022-04-25 05:34:45 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:45 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:45 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:45 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:45 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:46 --> Controller Class Initialized
INFO - 2022-04-25 05:34:48 --> Config Class Initialized
INFO - 2022-04-25 05:34:48 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:48 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:48 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:48 --> URI Class Initialized
INFO - 2022-04-25 05:34:48 --> Router Class Initialized
INFO - 2022-04-25 05:34:48 --> Output Class Initialized
INFO - 2022-04-25 05:34:48 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:48 --> Input Class Initialized
INFO - 2022-04-25 05:34:48 --> Language Class Initialized
INFO - 2022-04-25 05:34:48 --> Language Class Initialized
INFO - 2022-04-25 05:34:48 --> Config Class Initialized
INFO - 2022-04-25 05:34:48 --> Loader Class Initialized
INFO - 2022-04-25 05:34:48 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:48 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:48 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-04-25 05:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:48 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:48 --> Total execution time: 0.0943
INFO - 2022-04-25 05:34:48 --> Config Class Initialized
INFO - 2022-04-25 05:34:48 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:48 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:48 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:48 --> URI Class Initialized
INFO - 2022-04-25 05:34:48 --> Router Class Initialized
INFO - 2022-04-25 05:34:48 --> Output Class Initialized
INFO - 2022-04-25 05:34:48 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:48 --> Input Class Initialized
INFO - 2022-04-25 05:34:48 --> Language Class Initialized
INFO - 2022-04-25 05:34:48 --> Language Class Initialized
INFO - 2022-04-25 05:34:48 --> Config Class Initialized
INFO - 2022-04-25 05:34:48 --> Loader Class Initialized
INFO - 2022-04-25 05:34:48 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:48 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:48 --> Controller Class Initialized
INFO - 2022-04-25 05:34:48 --> Config Class Initialized
INFO - 2022-04-25 05:34:48 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:48 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:48 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:48 --> URI Class Initialized
INFO - 2022-04-25 05:34:48 --> Router Class Initialized
INFO - 2022-04-25 05:34:48 --> Output Class Initialized
INFO - 2022-04-25 05:34:48 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:48 --> Input Class Initialized
INFO - 2022-04-25 05:34:48 --> Language Class Initialized
INFO - 2022-04-25 05:34:48 --> Language Class Initialized
INFO - 2022-04-25 05:34:48 --> Config Class Initialized
INFO - 2022-04-25 05:34:48 --> Loader Class Initialized
INFO - 2022-04-25 05:34:48 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:48 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:48 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2022-04-25 05:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:48 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:48 --> Total execution time: 0.0892
INFO - 2022-04-25 05:34:48 --> Config Class Initialized
INFO - 2022-04-25 05:34:48 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:48 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:48 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:48 --> URI Class Initialized
INFO - 2022-04-25 05:34:48 --> Router Class Initialized
INFO - 2022-04-25 05:34:48 --> Output Class Initialized
INFO - 2022-04-25 05:34:48 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:48 --> Input Class Initialized
INFO - 2022-04-25 05:34:48 --> Language Class Initialized
INFO - 2022-04-25 05:34:48 --> Language Class Initialized
INFO - 2022-04-25 05:34:48 --> Config Class Initialized
INFO - 2022-04-25 05:34:48 --> Loader Class Initialized
INFO - 2022-04-25 05:34:48 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:48 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:48 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:48 --> Controller Class Initialized
INFO - 2022-04-25 05:34:49 --> Config Class Initialized
INFO - 2022-04-25 05:34:49 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:49 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:49 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:49 --> URI Class Initialized
INFO - 2022-04-25 05:34:49 --> Router Class Initialized
INFO - 2022-04-25 05:34:49 --> Output Class Initialized
INFO - 2022-04-25 05:34:49 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:49 --> Input Class Initialized
INFO - 2022-04-25 05:34:49 --> Language Class Initialized
INFO - 2022-04-25 05:34:49 --> Language Class Initialized
INFO - 2022-04-25 05:34:49 --> Config Class Initialized
INFO - 2022-04-25 05:34:49 --> Loader Class Initialized
INFO - 2022-04-25 05:34:49 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:49 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:49 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:49 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:49 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:49 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2022-04-25 05:34:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:49 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:49 --> Total execution time: 0.0866
INFO - 2022-04-25 05:34:49 --> Config Class Initialized
INFO - 2022-04-25 05:34:49 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:49 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:49 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:49 --> URI Class Initialized
INFO - 2022-04-25 05:34:49 --> Router Class Initialized
INFO - 2022-04-25 05:34:49 --> Output Class Initialized
INFO - 2022-04-25 05:34:49 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:49 --> Input Class Initialized
INFO - 2022-04-25 05:34:49 --> Language Class Initialized
INFO - 2022-04-25 05:34:49 --> Language Class Initialized
INFO - 2022-04-25 05:34:49 --> Config Class Initialized
INFO - 2022-04-25 05:34:49 --> Loader Class Initialized
INFO - 2022-04-25 05:34:49 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:49 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:49 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:49 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:49 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:49 --> Controller Class Initialized
INFO - 2022-04-25 05:34:51 --> Config Class Initialized
INFO - 2022-04-25 05:34:51 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:51 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:51 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:51 --> URI Class Initialized
INFO - 2022-04-25 05:34:51 --> Router Class Initialized
INFO - 2022-04-25 05:34:51 --> Output Class Initialized
INFO - 2022-04-25 05:34:51 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:51 --> Input Class Initialized
INFO - 2022-04-25 05:34:51 --> Language Class Initialized
INFO - 2022-04-25 05:34:51 --> Language Class Initialized
INFO - 2022-04-25 05:34:51 --> Config Class Initialized
INFO - 2022-04-25 05:34:51 --> Loader Class Initialized
INFO - 2022-04-25 05:34:51 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:51 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:51 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:51 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:51 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:51 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2022-04-25 05:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:51 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:51 --> Total execution time: 0.0719
INFO - 2022-04-25 05:34:51 --> Config Class Initialized
INFO - 2022-04-25 05:34:51 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:51 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:51 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:51 --> URI Class Initialized
INFO - 2022-04-25 05:34:51 --> Router Class Initialized
INFO - 2022-04-25 05:34:51 --> Output Class Initialized
INFO - 2022-04-25 05:34:51 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:51 --> Input Class Initialized
INFO - 2022-04-25 05:34:51 --> Language Class Initialized
INFO - 2022-04-25 05:34:51 --> Language Class Initialized
INFO - 2022-04-25 05:34:51 --> Config Class Initialized
INFO - 2022-04-25 05:34:51 --> Loader Class Initialized
INFO - 2022-04-25 05:34:51 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:51 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:51 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:51 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:51 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:51 --> Controller Class Initialized
INFO - 2022-04-25 05:34:52 --> Config Class Initialized
INFO - 2022-04-25 05:34:52 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:52 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:52 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:52 --> URI Class Initialized
INFO - 2022-04-25 05:34:52 --> Router Class Initialized
INFO - 2022-04-25 05:34:52 --> Output Class Initialized
INFO - 2022-04-25 05:34:52 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:52 --> Input Class Initialized
INFO - 2022-04-25 05:34:52 --> Language Class Initialized
INFO - 2022-04-25 05:34:52 --> Language Class Initialized
INFO - 2022-04-25 05:34:52 --> Config Class Initialized
INFO - 2022-04-25 05:34:52 --> Loader Class Initialized
INFO - 2022-04-25 05:34:52 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:52 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:52 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:52 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:52 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:52 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-04-25 05:34:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:52 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:52 --> Total execution time: 0.0849
INFO - 2022-04-25 05:34:52 --> Config Class Initialized
INFO - 2022-04-25 05:34:52 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:52 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:52 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:52 --> URI Class Initialized
INFO - 2022-04-25 05:34:52 --> Router Class Initialized
INFO - 2022-04-25 05:34:52 --> Output Class Initialized
INFO - 2022-04-25 05:34:52 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:52 --> Input Class Initialized
INFO - 2022-04-25 05:34:52 --> Language Class Initialized
INFO - 2022-04-25 05:34:52 --> Language Class Initialized
INFO - 2022-04-25 05:34:52 --> Config Class Initialized
INFO - 2022-04-25 05:34:52 --> Loader Class Initialized
INFO - 2022-04-25 05:34:52 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:52 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:52 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:52 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:52 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:52 --> Controller Class Initialized
INFO - 2022-04-25 05:34:53 --> Config Class Initialized
INFO - 2022-04-25 05:34:53 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:53 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:53 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:53 --> URI Class Initialized
INFO - 2022-04-25 05:34:53 --> Router Class Initialized
INFO - 2022-04-25 05:34:53 --> Output Class Initialized
INFO - 2022-04-25 05:34:53 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:53 --> Input Class Initialized
INFO - 2022-04-25 05:34:53 --> Language Class Initialized
INFO - 2022-04-25 05:34:53 --> Language Class Initialized
INFO - 2022-04-25 05:34:53 --> Config Class Initialized
INFO - 2022-04-25 05:34:53 --> Loader Class Initialized
INFO - 2022-04-25 05:34:53 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:53 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:53 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:53 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:53 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:53 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2022-04-25 05:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:53 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:53 --> Total execution time: 0.0638
INFO - 2022-04-25 05:34:53 --> Config Class Initialized
INFO - 2022-04-25 05:34:53 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:53 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:53 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:53 --> URI Class Initialized
INFO - 2022-04-25 05:34:53 --> Router Class Initialized
INFO - 2022-04-25 05:34:53 --> Output Class Initialized
INFO - 2022-04-25 05:34:53 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:53 --> Input Class Initialized
INFO - 2022-04-25 05:34:53 --> Language Class Initialized
INFO - 2022-04-25 05:34:53 --> Language Class Initialized
INFO - 2022-04-25 05:34:53 --> Config Class Initialized
INFO - 2022-04-25 05:34:53 --> Loader Class Initialized
INFO - 2022-04-25 05:34:53 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:53 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:53 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:53 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:53 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:53 --> Controller Class Initialized
INFO - 2022-04-25 05:34:54 --> Config Class Initialized
INFO - 2022-04-25 05:34:54 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:34:54 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:34:54 --> Utf8 Class Initialized
INFO - 2022-04-25 05:34:54 --> URI Class Initialized
DEBUG - 2022-04-25 05:34:54 --> No URI present. Default controller set.
INFO - 2022-04-25 05:34:54 --> Router Class Initialized
INFO - 2022-04-25 05:34:54 --> Output Class Initialized
INFO - 2022-04-25 05:34:54 --> Security Class Initialized
DEBUG - 2022-04-25 05:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:34:54 --> Input Class Initialized
INFO - 2022-04-25 05:34:54 --> Language Class Initialized
INFO - 2022-04-25 05:34:54 --> Language Class Initialized
INFO - 2022-04-25 05:34:54 --> Config Class Initialized
INFO - 2022-04-25 05:34:54 --> Loader Class Initialized
INFO - 2022-04-25 05:34:54 --> Helper loaded: url_helper
INFO - 2022-04-25 05:34:54 --> Helper loaded: file_helper
INFO - 2022-04-25 05:34:54 --> Helper loaded: form_helper
INFO - 2022-04-25 05:34:54 --> Helper loaded: my_helper
INFO - 2022-04-25 05:34:54 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:34:54 --> Controller Class Initialized
DEBUG - 2022-04-25 05:34:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-04-25 05:34:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:34:54 --> Final output sent to browser
DEBUG - 2022-04-25 05:34:54 --> Total execution time: 0.8145
INFO - 2022-04-25 05:44:27 --> Config Class Initialized
INFO - 2022-04-25 05:44:27 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:44:27 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:44:27 --> Utf8 Class Initialized
INFO - 2022-04-25 05:44:27 --> URI Class Initialized
INFO - 2022-04-25 05:44:27 --> Router Class Initialized
INFO - 2022-04-25 05:44:27 --> Output Class Initialized
INFO - 2022-04-25 05:44:27 --> Security Class Initialized
DEBUG - 2022-04-25 05:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:44:27 --> Input Class Initialized
INFO - 2022-04-25 05:44:27 --> Language Class Initialized
INFO - 2022-04-25 05:44:27 --> Language Class Initialized
INFO - 2022-04-25 05:44:27 --> Config Class Initialized
INFO - 2022-04-25 05:44:27 --> Loader Class Initialized
INFO - 2022-04-25 05:44:27 --> Helper loaded: url_helper
INFO - 2022-04-25 05:44:27 --> Helper loaded: file_helper
INFO - 2022-04-25 05:44:27 --> Helper loaded: form_helper
INFO - 2022-04-25 05:44:27 --> Helper loaded: my_helper
INFO - 2022-04-25 05:44:27 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:44:27 --> Controller Class Initialized
INFO - 2022-04-25 05:44:27 --> Helper loaded: cookie_helper
INFO - 2022-04-25 05:44:27 --> Config Class Initialized
INFO - 2022-04-25 05:44:27 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:44:27 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:44:27 --> Utf8 Class Initialized
INFO - 2022-04-25 05:44:27 --> URI Class Initialized
INFO - 2022-04-25 05:44:27 --> Router Class Initialized
INFO - 2022-04-25 05:44:27 --> Output Class Initialized
INFO - 2022-04-25 05:44:27 --> Security Class Initialized
DEBUG - 2022-04-25 05:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:44:27 --> Input Class Initialized
INFO - 2022-04-25 05:44:27 --> Language Class Initialized
INFO - 2022-04-25 05:44:27 --> Language Class Initialized
INFO - 2022-04-25 05:44:27 --> Config Class Initialized
INFO - 2022-04-25 05:44:27 --> Loader Class Initialized
INFO - 2022-04-25 05:44:27 --> Helper loaded: url_helper
INFO - 2022-04-25 05:44:27 --> Helper loaded: file_helper
INFO - 2022-04-25 05:44:27 --> Helper loaded: form_helper
INFO - 2022-04-25 05:44:27 --> Helper loaded: my_helper
INFO - 2022-04-25 05:44:27 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:44:27 --> Controller Class Initialized
DEBUG - 2022-04-25 05:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-04-25 05:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:44:27 --> Final output sent to browser
DEBUG - 2022-04-25 05:44:27 --> Total execution time: 0.0680
INFO - 2022-04-25 05:44:31 --> Config Class Initialized
INFO - 2022-04-25 05:44:31 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:44:31 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:44:31 --> Utf8 Class Initialized
INFO - 2022-04-25 05:44:31 --> URI Class Initialized
INFO - 2022-04-25 05:44:31 --> Router Class Initialized
INFO - 2022-04-25 05:44:31 --> Output Class Initialized
INFO - 2022-04-25 05:44:31 --> Security Class Initialized
DEBUG - 2022-04-25 05:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:44:31 --> Input Class Initialized
INFO - 2022-04-25 05:44:31 --> Language Class Initialized
INFO - 2022-04-25 05:44:31 --> Language Class Initialized
INFO - 2022-04-25 05:44:31 --> Config Class Initialized
INFO - 2022-04-25 05:44:31 --> Loader Class Initialized
INFO - 2022-04-25 05:44:31 --> Helper loaded: url_helper
INFO - 2022-04-25 05:44:31 --> Helper loaded: file_helper
INFO - 2022-04-25 05:44:31 --> Helper loaded: form_helper
INFO - 2022-04-25 05:44:31 --> Helper loaded: my_helper
INFO - 2022-04-25 05:44:31 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:44:31 --> Controller Class Initialized
INFO - 2022-04-25 05:44:31 --> Helper loaded: cookie_helper
INFO - 2022-04-25 05:44:31 --> Final output sent to browser
DEBUG - 2022-04-25 05:44:31 --> Total execution time: 0.0874
INFO - 2022-04-25 05:44:31 --> Config Class Initialized
INFO - 2022-04-25 05:44:31 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:44:31 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:44:31 --> Utf8 Class Initialized
INFO - 2022-04-25 05:44:31 --> URI Class Initialized
INFO - 2022-04-25 05:44:31 --> Router Class Initialized
INFO - 2022-04-25 05:44:31 --> Output Class Initialized
INFO - 2022-04-25 05:44:31 --> Security Class Initialized
DEBUG - 2022-04-25 05:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:44:31 --> Input Class Initialized
INFO - 2022-04-25 05:44:31 --> Language Class Initialized
INFO - 2022-04-25 05:44:31 --> Language Class Initialized
INFO - 2022-04-25 05:44:31 --> Config Class Initialized
INFO - 2022-04-25 05:44:31 --> Loader Class Initialized
INFO - 2022-04-25 05:44:31 --> Helper loaded: url_helper
INFO - 2022-04-25 05:44:31 --> Helper loaded: file_helper
INFO - 2022-04-25 05:44:31 --> Helper loaded: form_helper
INFO - 2022-04-25 05:44:31 --> Helper loaded: my_helper
INFO - 2022-04-25 05:44:31 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:44:31 --> Controller Class Initialized
DEBUG - 2022-04-25 05:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-04-25 05:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:44:32 --> Final output sent to browser
DEBUG - 2022-04-25 05:44:32 --> Total execution time: 0.9200
INFO - 2022-04-25 05:44:33 --> Config Class Initialized
INFO - 2022-04-25 05:44:33 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:44:33 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:44:33 --> Utf8 Class Initialized
INFO - 2022-04-25 05:44:33 --> URI Class Initialized
INFO - 2022-04-25 05:44:33 --> Router Class Initialized
INFO - 2022-04-25 05:44:33 --> Output Class Initialized
INFO - 2022-04-25 05:44:33 --> Security Class Initialized
DEBUG - 2022-04-25 05:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:44:33 --> Input Class Initialized
INFO - 2022-04-25 05:44:33 --> Language Class Initialized
INFO - 2022-04-25 05:44:33 --> Language Class Initialized
INFO - 2022-04-25 05:44:33 --> Config Class Initialized
INFO - 2022-04-25 05:44:33 --> Loader Class Initialized
INFO - 2022-04-25 05:44:33 --> Helper loaded: url_helper
INFO - 2022-04-25 05:44:33 --> Helper loaded: file_helper
INFO - 2022-04-25 05:44:33 --> Helper loaded: form_helper
INFO - 2022-04-25 05:44:33 --> Helper loaded: my_helper
INFO - 2022-04-25 05:44:33 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:44:33 --> Controller Class Initialized
DEBUG - 2022-04-25 05:44:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-04-25 05:44:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:44:33 --> Final output sent to browser
DEBUG - 2022-04-25 05:44:33 --> Total execution time: 0.0841
INFO - 2022-04-25 05:44:55 --> Config Class Initialized
INFO - 2022-04-25 05:44:55 --> Hooks Class Initialized
DEBUG - 2022-04-25 05:44:55 --> UTF-8 Support Enabled
INFO - 2022-04-25 05:44:55 --> Utf8 Class Initialized
INFO - 2022-04-25 05:44:55 --> URI Class Initialized
INFO - 2022-04-25 05:44:55 --> Router Class Initialized
INFO - 2022-04-25 05:44:55 --> Output Class Initialized
INFO - 2022-04-25 05:44:55 --> Security Class Initialized
DEBUG - 2022-04-25 05:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 05:44:55 --> Input Class Initialized
INFO - 2022-04-25 05:44:55 --> Language Class Initialized
INFO - 2022-04-25 05:44:55 --> Language Class Initialized
INFO - 2022-04-25 05:44:55 --> Config Class Initialized
INFO - 2022-04-25 05:44:55 --> Loader Class Initialized
INFO - 2022-04-25 05:44:55 --> Helper loaded: url_helper
INFO - 2022-04-25 05:44:55 --> Helper loaded: file_helper
INFO - 2022-04-25 05:44:55 --> Helper loaded: form_helper
INFO - 2022-04-25 05:44:55 --> Helper loaded: my_helper
INFO - 2022-04-25 05:44:55 --> Database Driver Class Initialized
DEBUG - 2022-04-25 05:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 05:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 05:44:55 --> Controller Class Initialized
DEBUG - 2022-04-25 05:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-04-25 05:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 05:44:55 --> Final output sent to browser
DEBUG - 2022-04-25 05:44:55 --> Total execution time: 0.0664
INFO - 2022-04-25 06:00:33 --> Config Class Initialized
INFO - 2022-04-25 06:00:33 --> Hooks Class Initialized
DEBUG - 2022-04-25 06:00:33 --> UTF-8 Support Enabled
INFO - 2022-04-25 06:00:33 --> Utf8 Class Initialized
INFO - 2022-04-25 06:00:33 --> URI Class Initialized
INFO - 2022-04-25 06:00:33 --> Router Class Initialized
INFO - 2022-04-25 06:00:33 --> Output Class Initialized
INFO - 2022-04-25 06:00:33 --> Security Class Initialized
DEBUG - 2022-04-25 06:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 06:00:33 --> Input Class Initialized
INFO - 2022-04-25 06:00:33 --> Language Class Initialized
INFO - 2022-04-25 06:00:33 --> Language Class Initialized
INFO - 2022-04-25 06:00:33 --> Config Class Initialized
INFO - 2022-04-25 06:00:33 --> Loader Class Initialized
INFO - 2022-04-25 06:00:33 --> Helper loaded: url_helper
INFO - 2022-04-25 06:00:33 --> Helper loaded: file_helper
INFO - 2022-04-25 06:00:33 --> Helper loaded: form_helper
INFO - 2022-04-25 06:00:33 --> Helper loaded: my_helper
INFO - 2022-04-25 06:00:33 --> Database Driver Class Initialized
DEBUG - 2022-04-25 06:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 06:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 06:00:33 --> Controller Class Initialized
DEBUG - 2022-04-25 06:00:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-04-25 06:00:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 06:00:33 --> Final output sent to browser
DEBUG - 2022-04-25 06:00:33 --> Total execution time: 0.0591
INFO - 2022-04-25 06:00:41 --> Config Class Initialized
INFO - 2022-04-25 06:00:41 --> Hooks Class Initialized
DEBUG - 2022-04-25 06:00:41 --> UTF-8 Support Enabled
INFO - 2022-04-25 06:00:41 --> Utf8 Class Initialized
INFO - 2022-04-25 06:00:41 --> URI Class Initialized
INFO - 2022-04-25 06:00:41 --> Router Class Initialized
INFO - 2022-04-25 06:00:41 --> Output Class Initialized
INFO - 2022-04-25 06:00:41 --> Security Class Initialized
DEBUG - 2022-04-25 06:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 06:00:41 --> Input Class Initialized
INFO - 2022-04-25 06:00:41 --> Language Class Initialized
INFO - 2022-04-25 06:00:41 --> Language Class Initialized
INFO - 2022-04-25 06:00:41 --> Config Class Initialized
INFO - 2022-04-25 06:00:42 --> Loader Class Initialized
INFO - 2022-04-25 06:00:42 --> Helper loaded: url_helper
INFO - 2022-04-25 06:00:42 --> Helper loaded: file_helper
INFO - 2022-04-25 06:00:42 --> Helper loaded: form_helper
INFO - 2022-04-25 06:00:42 --> Helper loaded: my_helper
INFO - 2022-04-25 06:00:42 --> Database Driver Class Initialized
DEBUG - 2022-04-25 06:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 06:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 06:00:42 --> Controller Class Initialized
INFO - 2022-04-25 06:00:42 --> Final output sent to browser
DEBUG - 2022-04-25 06:00:42 --> Total execution time: 0.1497
INFO - 2022-04-25 06:00:44 --> Config Class Initialized
INFO - 2022-04-25 06:00:44 --> Hooks Class Initialized
DEBUG - 2022-04-25 06:00:44 --> UTF-8 Support Enabled
INFO - 2022-04-25 06:00:44 --> Utf8 Class Initialized
INFO - 2022-04-25 06:00:44 --> URI Class Initialized
INFO - 2022-04-25 06:00:44 --> Router Class Initialized
INFO - 2022-04-25 06:00:44 --> Output Class Initialized
INFO - 2022-04-25 06:00:44 --> Security Class Initialized
DEBUG - 2022-04-25 06:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 06:00:44 --> Input Class Initialized
INFO - 2022-04-25 06:00:44 --> Language Class Initialized
INFO - 2022-04-25 06:00:44 --> Language Class Initialized
INFO - 2022-04-25 06:00:44 --> Config Class Initialized
INFO - 2022-04-25 06:00:44 --> Loader Class Initialized
INFO - 2022-04-25 06:00:44 --> Helper loaded: url_helper
INFO - 2022-04-25 06:00:44 --> Helper loaded: file_helper
INFO - 2022-04-25 06:00:44 --> Helper loaded: form_helper
INFO - 2022-04-25 06:00:44 --> Helper loaded: my_helper
INFO - 2022-04-25 06:00:44 --> Database Driver Class Initialized
DEBUG - 2022-04-25 06:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 06:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 06:00:44 --> Controller Class Initialized
DEBUG - 2022-04-25 06:00:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-04-25 06:00:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 06:00:44 --> Final output sent to browser
DEBUG - 2022-04-25 06:00:44 --> Total execution time: 0.0708
INFO - 2022-04-25 06:00:47 --> Config Class Initialized
INFO - 2022-04-25 06:00:47 --> Hooks Class Initialized
DEBUG - 2022-04-25 06:00:47 --> UTF-8 Support Enabled
INFO - 2022-04-25 06:00:47 --> Utf8 Class Initialized
INFO - 2022-04-25 06:00:47 --> URI Class Initialized
INFO - 2022-04-25 06:00:47 --> Router Class Initialized
INFO - 2022-04-25 06:00:47 --> Output Class Initialized
INFO - 2022-04-25 06:00:47 --> Security Class Initialized
DEBUG - 2022-04-25 06:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 06:00:47 --> Input Class Initialized
INFO - 2022-04-25 06:00:47 --> Language Class Initialized
INFO - 2022-04-25 06:00:47 --> Language Class Initialized
INFO - 2022-04-25 06:00:47 --> Config Class Initialized
INFO - 2022-04-25 06:00:47 --> Loader Class Initialized
INFO - 2022-04-25 06:00:47 --> Helper loaded: url_helper
INFO - 2022-04-25 06:00:47 --> Helper loaded: file_helper
INFO - 2022-04-25 06:00:47 --> Helper loaded: form_helper
INFO - 2022-04-25 06:00:47 --> Helper loaded: my_helper
INFO - 2022-04-25 06:00:47 --> Database Driver Class Initialized
DEBUG - 2022-04-25 06:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 06:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 06:00:47 --> Controller Class Initialized
DEBUG - 2022-04-25 06:00:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-04-25 06:00:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 06:00:47 --> Final output sent to browser
DEBUG - 2022-04-25 06:00:47 --> Total execution time: 0.0743
INFO - 2022-04-25 06:03:21 --> Config Class Initialized
INFO - 2022-04-25 06:03:21 --> Hooks Class Initialized
DEBUG - 2022-04-25 06:03:21 --> UTF-8 Support Enabled
INFO - 2022-04-25 06:03:21 --> Utf8 Class Initialized
INFO - 2022-04-25 06:03:21 --> URI Class Initialized
INFO - 2022-04-25 06:03:21 --> Router Class Initialized
INFO - 2022-04-25 06:03:21 --> Output Class Initialized
INFO - 2022-04-25 06:03:21 --> Security Class Initialized
DEBUG - 2022-04-25 06:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-04-25 06:03:21 --> Input Class Initialized
INFO - 2022-04-25 06:03:21 --> Language Class Initialized
INFO - 2022-04-25 06:03:21 --> Language Class Initialized
INFO - 2022-04-25 06:03:21 --> Config Class Initialized
INFO - 2022-04-25 06:03:21 --> Loader Class Initialized
INFO - 2022-04-25 06:03:21 --> Helper loaded: url_helper
INFO - 2022-04-25 06:03:21 --> Helper loaded: file_helper
INFO - 2022-04-25 06:03:21 --> Helper loaded: form_helper
INFO - 2022-04-25 06:03:21 --> Helper loaded: my_helper
INFO - 2022-04-25 06:03:21 --> Database Driver Class Initialized
DEBUG - 2022-04-25 06:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-04-25 06:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-04-25 06:03:21 --> Controller Class Initialized
DEBUG - 2022-04-25 06:03:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-04-25 06:03:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-04-25 06:03:21 --> Final output sent to browser
DEBUG - 2022-04-25 06:03:21 --> Total execution time: 0.1701
