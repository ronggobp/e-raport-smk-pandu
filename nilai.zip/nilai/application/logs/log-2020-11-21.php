<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-21 01:07:27 --> Config Class Initialized
INFO - 2020-11-21 01:07:27 --> Hooks Class Initialized
DEBUG - 2020-11-21 01:07:27 --> UTF-8 Support Enabled
INFO - 2020-11-21 01:07:27 --> Utf8 Class Initialized
INFO - 2020-11-21 01:07:27 --> URI Class Initialized
DEBUG - 2020-11-21 01:07:27 --> No URI present. Default controller set.
INFO - 2020-11-21 01:07:27 --> Router Class Initialized
INFO - 2020-11-21 01:07:27 --> Output Class Initialized
INFO - 2020-11-21 01:07:27 --> Security Class Initialized
DEBUG - 2020-11-21 01:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 01:07:27 --> Input Class Initialized
INFO - 2020-11-21 01:07:27 --> Language Class Initialized
INFO - 2020-11-21 01:07:28 --> Language Class Initialized
INFO - 2020-11-21 01:07:28 --> Config Class Initialized
INFO - 2020-11-21 01:07:28 --> Loader Class Initialized
INFO - 2020-11-21 01:07:28 --> Helper loaded: url_helper
INFO - 2020-11-21 01:07:28 --> Helper loaded: file_helper
INFO - 2020-11-21 01:07:28 --> Helper loaded: form_helper
INFO - 2020-11-21 01:07:28 --> Helper loaded: my_helper
INFO - 2020-11-21 01:07:28 --> Database Driver Class Initialized
DEBUG - 2020-11-21 01:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 01:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 01:07:28 --> Controller Class Initialized
INFO - 2020-11-21 01:07:29 --> Config Class Initialized
INFO - 2020-11-21 01:07:29 --> Hooks Class Initialized
DEBUG - 2020-11-21 01:07:29 --> UTF-8 Support Enabled
INFO - 2020-11-21 01:07:29 --> Utf8 Class Initialized
INFO - 2020-11-21 01:07:29 --> URI Class Initialized
INFO - 2020-11-21 01:07:29 --> Router Class Initialized
INFO - 2020-11-21 01:07:29 --> Output Class Initialized
INFO - 2020-11-21 01:07:29 --> Security Class Initialized
DEBUG - 2020-11-21 01:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 01:07:29 --> Input Class Initialized
INFO - 2020-11-21 01:07:29 --> Language Class Initialized
INFO - 2020-11-21 01:07:29 --> Language Class Initialized
INFO - 2020-11-21 01:07:29 --> Config Class Initialized
INFO - 2020-11-21 01:07:29 --> Loader Class Initialized
INFO - 2020-11-21 01:07:29 --> Helper loaded: url_helper
INFO - 2020-11-21 01:07:29 --> Helper loaded: file_helper
INFO - 2020-11-21 01:07:29 --> Helper loaded: form_helper
INFO - 2020-11-21 01:07:29 --> Helper loaded: my_helper
INFO - 2020-11-21 01:07:29 --> Database Driver Class Initialized
DEBUG - 2020-11-21 01:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 01:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 01:07:29 --> Controller Class Initialized
DEBUG - 2020-11-21 01:07:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-21 01:07:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 01:07:29 --> Final output sent to browser
DEBUG - 2020-11-21 01:07:29 --> Total execution time: 0.6497
INFO - 2020-11-21 02:47:00 --> Config Class Initialized
INFO - 2020-11-21 02:47:00 --> Hooks Class Initialized
DEBUG - 2020-11-21 02:47:00 --> UTF-8 Support Enabled
INFO - 2020-11-21 02:47:00 --> Utf8 Class Initialized
INFO - 2020-11-21 02:47:00 --> URI Class Initialized
INFO - 2020-11-21 02:47:00 --> Router Class Initialized
INFO - 2020-11-21 02:47:00 --> Output Class Initialized
INFO - 2020-11-21 02:47:00 --> Security Class Initialized
DEBUG - 2020-11-21 02:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 02:47:00 --> Input Class Initialized
INFO - 2020-11-21 02:47:00 --> Language Class Initialized
INFO - 2020-11-21 02:47:00 --> Language Class Initialized
INFO - 2020-11-21 02:47:00 --> Config Class Initialized
INFO - 2020-11-21 02:47:00 --> Loader Class Initialized
INFO - 2020-11-21 02:47:00 --> Helper loaded: url_helper
INFO - 2020-11-21 02:47:00 --> Helper loaded: file_helper
INFO - 2020-11-21 02:47:00 --> Helper loaded: form_helper
INFO - 2020-11-21 02:47:00 --> Helper loaded: my_helper
INFO - 2020-11-21 02:47:00 --> Database Driver Class Initialized
DEBUG - 2020-11-21 02:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 02:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 02:47:00 --> Controller Class Initialized
INFO - 2020-11-21 02:47:00 --> Helper loaded: cookie_helper
INFO - 2020-11-21 02:47:00 --> Final output sent to browser
DEBUG - 2020-11-21 02:47:00 --> Total execution time: 0.3213
INFO - 2020-11-21 02:47:01 --> Config Class Initialized
INFO - 2020-11-21 02:47:01 --> Hooks Class Initialized
DEBUG - 2020-11-21 02:47:01 --> UTF-8 Support Enabled
INFO - 2020-11-21 02:47:01 --> Utf8 Class Initialized
INFO - 2020-11-21 02:47:01 --> URI Class Initialized
INFO - 2020-11-21 02:47:01 --> Router Class Initialized
INFO - 2020-11-21 02:47:01 --> Output Class Initialized
INFO - 2020-11-21 02:47:01 --> Security Class Initialized
DEBUG - 2020-11-21 02:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 02:47:01 --> Input Class Initialized
INFO - 2020-11-21 02:47:01 --> Language Class Initialized
INFO - 2020-11-21 02:47:01 --> Language Class Initialized
INFO - 2020-11-21 02:47:01 --> Config Class Initialized
INFO - 2020-11-21 02:47:01 --> Loader Class Initialized
INFO - 2020-11-21 02:47:01 --> Helper loaded: url_helper
INFO - 2020-11-21 02:47:01 --> Helper loaded: file_helper
INFO - 2020-11-21 02:47:01 --> Helper loaded: form_helper
INFO - 2020-11-21 02:47:01 --> Helper loaded: my_helper
INFO - 2020-11-21 02:47:01 --> Database Driver Class Initialized
DEBUG - 2020-11-21 02:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 02:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 02:47:01 --> Controller Class Initialized
DEBUG - 2020-11-21 02:47:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-21 02:47:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 02:47:01 --> Final output sent to browser
DEBUG - 2020-11-21 02:47:01 --> Total execution time: 0.4107
INFO - 2020-11-21 03:25:32 --> Config Class Initialized
INFO - 2020-11-21 03:25:32 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:25:32 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:25:32 --> Utf8 Class Initialized
INFO - 2020-11-21 03:25:32 --> URI Class Initialized
INFO - 2020-11-21 03:25:32 --> Router Class Initialized
INFO - 2020-11-21 03:25:32 --> Output Class Initialized
INFO - 2020-11-21 03:25:32 --> Security Class Initialized
DEBUG - 2020-11-21 03:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:25:32 --> Input Class Initialized
INFO - 2020-11-21 03:25:32 --> Language Class Initialized
INFO - 2020-11-21 03:25:32 --> Language Class Initialized
INFO - 2020-11-21 03:25:32 --> Config Class Initialized
INFO - 2020-11-21 03:25:32 --> Loader Class Initialized
INFO - 2020-11-21 03:25:33 --> Helper loaded: url_helper
INFO - 2020-11-21 03:25:33 --> Helper loaded: file_helper
INFO - 2020-11-21 03:25:33 --> Helper loaded: form_helper
INFO - 2020-11-21 03:25:33 --> Helper loaded: my_helper
INFO - 2020-11-21 03:25:33 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:25:33 --> Controller Class Initialized
DEBUG - 2020-11-21 03:25:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 03:25:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:25:33 --> Final output sent to browser
DEBUG - 2020-11-21 03:25:33 --> Total execution time: 0.9638
INFO - 2020-11-21 03:47:29 --> Config Class Initialized
INFO - 2020-11-21 03:47:29 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:47:29 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:47:29 --> Utf8 Class Initialized
INFO - 2020-11-21 03:47:29 --> URI Class Initialized
INFO - 2020-11-21 03:47:29 --> Router Class Initialized
INFO - 2020-11-21 03:47:29 --> Output Class Initialized
INFO - 2020-11-21 03:47:29 --> Security Class Initialized
DEBUG - 2020-11-21 03:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:47:29 --> Input Class Initialized
INFO - 2020-11-21 03:47:29 --> Language Class Initialized
INFO - 2020-11-21 03:47:29 --> Language Class Initialized
INFO - 2020-11-21 03:47:29 --> Config Class Initialized
INFO - 2020-11-21 03:47:29 --> Loader Class Initialized
INFO - 2020-11-21 03:47:29 --> Helper loaded: url_helper
INFO - 2020-11-21 03:47:29 --> Helper loaded: file_helper
INFO - 2020-11-21 03:47:29 --> Helper loaded: form_helper
INFO - 2020-11-21 03:47:29 --> Helper loaded: my_helper
INFO - 2020-11-21 03:47:29 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:47:29 --> Controller Class Initialized
DEBUG - 2020-11-21 03:47:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 03:47:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:47:29 --> Final output sent to browser
DEBUG - 2020-11-21 03:47:29 --> Total execution time: 0.4012
INFO - 2020-11-21 03:47:51 --> Config Class Initialized
INFO - 2020-11-21 03:47:51 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:47:52 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:47:52 --> Utf8 Class Initialized
INFO - 2020-11-21 03:47:52 --> URI Class Initialized
INFO - 2020-11-21 03:47:52 --> Router Class Initialized
INFO - 2020-11-21 03:47:52 --> Output Class Initialized
INFO - 2020-11-21 03:47:52 --> Security Class Initialized
DEBUG - 2020-11-21 03:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:47:52 --> Input Class Initialized
INFO - 2020-11-21 03:47:52 --> Language Class Initialized
INFO - 2020-11-21 03:47:52 --> Language Class Initialized
INFO - 2020-11-21 03:47:52 --> Config Class Initialized
INFO - 2020-11-21 03:47:52 --> Loader Class Initialized
INFO - 2020-11-21 03:47:52 --> Helper loaded: url_helper
INFO - 2020-11-21 03:47:52 --> Helper loaded: file_helper
INFO - 2020-11-21 03:47:52 --> Helper loaded: form_helper
INFO - 2020-11-21 03:47:52 --> Helper loaded: my_helper
INFO - 2020-11-21 03:47:52 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:47:52 --> Controller Class Initialized
DEBUG - 2020-11-21 03:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-21 03:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:47:52 --> Final output sent to browser
DEBUG - 2020-11-21 03:47:52 --> Total execution time: 0.8673
INFO - 2020-11-21 03:47:53 --> Config Class Initialized
INFO - 2020-11-21 03:47:53 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:47:53 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:47:53 --> Utf8 Class Initialized
INFO - 2020-11-21 03:47:53 --> URI Class Initialized
INFO - 2020-11-21 03:47:53 --> Router Class Initialized
INFO - 2020-11-21 03:47:53 --> Output Class Initialized
INFO - 2020-11-21 03:47:53 --> Security Class Initialized
DEBUG - 2020-11-21 03:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:47:53 --> Input Class Initialized
INFO - 2020-11-21 03:47:53 --> Language Class Initialized
INFO - 2020-11-21 03:47:53 --> Language Class Initialized
INFO - 2020-11-21 03:47:54 --> Config Class Initialized
INFO - 2020-11-21 03:47:54 --> Loader Class Initialized
INFO - 2020-11-21 03:47:54 --> Helper loaded: url_helper
INFO - 2020-11-21 03:47:54 --> Helper loaded: file_helper
INFO - 2020-11-21 03:47:54 --> Helper loaded: form_helper
INFO - 2020-11-21 03:47:54 --> Helper loaded: my_helper
INFO - 2020-11-21 03:47:54 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:47:54 --> Controller Class Initialized
DEBUG - 2020-11-21 03:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-11-21 03:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:47:54 --> Final output sent to browser
DEBUG - 2020-11-21 03:47:54 --> Total execution time: 0.7903
INFO - 2020-11-21 03:47:58 --> Config Class Initialized
INFO - 2020-11-21 03:47:58 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:47:58 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:47:58 --> Utf8 Class Initialized
INFO - 2020-11-21 03:47:58 --> URI Class Initialized
INFO - 2020-11-21 03:47:58 --> Router Class Initialized
INFO - 2020-11-21 03:47:58 --> Output Class Initialized
INFO - 2020-11-21 03:47:58 --> Security Class Initialized
DEBUG - 2020-11-21 03:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:47:58 --> Input Class Initialized
INFO - 2020-11-21 03:47:58 --> Language Class Initialized
INFO - 2020-11-21 03:47:58 --> Language Class Initialized
INFO - 2020-11-21 03:47:58 --> Config Class Initialized
INFO - 2020-11-21 03:47:58 --> Loader Class Initialized
INFO - 2020-11-21 03:47:58 --> Helper loaded: url_helper
INFO - 2020-11-21 03:47:58 --> Helper loaded: file_helper
INFO - 2020-11-21 03:47:58 --> Helper loaded: form_helper
INFO - 2020-11-21 03:47:58 --> Helper loaded: my_helper
INFO - 2020-11-21 03:47:58 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:47:58 --> Controller Class Initialized
DEBUG - 2020-11-21 03:47:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-21 03:47:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:47:59 --> Final output sent to browser
DEBUG - 2020-11-21 03:47:59 --> Total execution time: 0.8695
INFO - 2020-11-21 03:48:02 --> Config Class Initialized
INFO - 2020-11-21 03:48:02 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:48:02 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:48:02 --> Utf8 Class Initialized
INFO - 2020-11-21 03:48:02 --> URI Class Initialized
INFO - 2020-11-21 03:48:02 --> Router Class Initialized
INFO - 2020-11-21 03:48:02 --> Output Class Initialized
INFO - 2020-11-21 03:48:02 --> Security Class Initialized
DEBUG - 2020-11-21 03:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:48:02 --> Input Class Initialized
INFO - 2020-11-21 03:48:02 --> Language Class Initialized
INFO - 2020-11-21 03:48:02 --> Language Class Initialized
INFO - 2020-11-21 03:48:02 --> Config Class Initialized
INFO - 2020-11-21 03:48:02 --> Loader Class Initialized
INFO - 2020-11-21 03:48:02 --> Helper loaded: url_helper
INFO - 2020-11-21 03:48:02 --> Helper loaded: file_helper
INFO - 2020-11-21 03:48:02 --> Helper loaded: form_helper
INFO - 2020-11-21 03:48:02 --> Helper loaded: my_helper
INFO - 2020-11-21 03:48:02 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:48:03 --> Controller Class Initialized
DEBUG - 2020-11-21 03:48:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-21 03:48:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:48:03 --> Final output sent to browser
DEBUG - 2020-11-21 03:48:03 --> Total execution time: 0.8447
INFO - 2020-11-21 03:48:07 --> Config Class Initialized
INFO - 2020-11-21 03:48:07 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:48:07 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:48:07 --> Utf8 Class Initialized
INFO - 2020-11-21 03:48:07 --> URI Class Initialized
INFO - 2020-11-21 03:48:07 --> Router Class Initialized
INFO - 2020-11-21 03:48:07 --> Output Class Initialized
INFO - 2020-11-21 03:48:07 --> Security Class Initialized
DEBUG - 2020-11-21 03:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:48:07 --> Input Class Initialized
INFO - 2020-11-21 03:48:07 --> Language Class Initialized
INFO - 2020-11-21 03:48:07 --> Language Class Initialized
INFO - 2020-11-21 03:48:07 --> Config Class Initialized
INFO - 2020-11-21 03:48:08 --> Loader Class Initialized
INFO - 2020-11-21 03:48:08 --> Helper loaded: url_helper
INFO - 2020-11-21 03:48:08 --> Helper loaded: file_helper
INFO - 2020-11-21 03:48:08 --> Helper loaded: form_helper
INFO - 2020-11-21 03:48:08 --> Helper loaded: my_helper
INFO - 2020-11-21 03:48:08 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:48:08 --> Controller Class Initialized
DEBUG - 2020-11-21 03:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-11-21 03:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:48:08 --> Final output sent to browser
DEBUG - 2020-11-21 03:48:08 --> Total execution time: 0.7228
INFO - 2020-11-21 03:48:11 --> Config Class Initialized
INFO - 2020-11-21 03:48:11 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:48:11 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:48:11 --> Utf8 Class Initialized
INFO - 2020-11-21 03:48:11 --> URI Class Initialized
INFO - 2020-11-21 03:48:11 --> Router Class Initialized
INFO - 2020-11-21 03:48:11 --> Output Class Initialized
INFO - 2020-11-21 03:48:11 --> Security Class Initialized
DEBUG - 2020-11-21 03:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:48:11 --> Input Class Initialized
INFO - 2020-11-21 03:48:11 --> Language Class Initialized
INFO - 2020-11-21 03:48:11 --> Language Class Initialized
INFO - 2020-11-21 03:48:11 --> Config Class Initialized
INFO - 2020-11-21 03:48:11 --> Loader Class Initialized
INFO - 2020-11-21 03:48:11 --> Helper loaded: url_helper
INFO - 2020-11-21 03:48:11 --> Helper loaded: file_helper
INFO - 2020-11-21 03:48:11 --> Helper loaded: form_helper
INFO - 2020-11-21 03:48:11 --> Helper loaded: my_helper
INFO - 2020-11-21 03:48:11 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:48:11 --> Controller Class Initialized
DEBUG - 2020-11-21 03:48:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-21 03:48:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:48:11 --> Final output sent to browser
DEBUG - 2020-11-21 03:48:11 --> Total execution time: 0.7199
INFO - 2020-11-21 03:48:18 --> Config Class Initialized
INFO - 2020-11-21 03:48:18 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:48:18 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:48:18 --> Utf8 Class Initialized
INFO - 2020-11-21 03:48:18 --> URI Class Initialized
INFO - 2020-11-21 03:48:18 --> Router Class Initialized
INFO - 2020-11-21 03:48:18 --> Output Class Initialized
INFO - 2020-11-21 03:48:18 --> Security Class Initialized
DEBUG - 2020-11-21 03:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:48:18 --> Input Class Initialized
INFO - 2020-11-21 03:48:18 --> Language Class Initialized
INFO - 2020-11-21 03:48:18 --> Language Class Initialized
INFO - 2020-11-21 03:48:18 --> Config Class Initialized
INFO - 2020-11-21 03:48:18 --> Loader Class Initialized
INFO - 2020-11-21 03:48:18 --> Helper loaded: url_helper
INFO - 2020-11-21 03:48:18 --> Helper loaded: file_helper
INFO - 2020-11-21 03:48:18 --> Helper loaded: form_helper
INFO - 2020-11-21 03:48:18 --> Helper loaded: my_helper
INFO - 2020-11-21 03:48:18 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:48:18 --> Controller Class Initialized
DEBUG - 2020-11-21 03:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 03:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:48:19 --> Final output sent to browser
DEBUG - 2020-11-21 03:48:19 --> Total execution time: 0.5338
INFO - 2020-11-21 03:48:20 --> Config Class Initialized
INFO - 2020-11-21 03:48:20 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:48:20 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:48:20 --> Utf8 Class Initialized
INFO - 2020-11-21 03:48:20 --> URI Class Initialized
INFO - 2020-11-21 03:48:20 --> Router Class Initialized
INFO - 2020-11-21 03:48:20 --> Output Class Initialized
INFO - 2020-11-21 03:48:20 --> Security Class Initialized
DEBUG - 2020-11-21 03:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:48:20 --> Input Class Initialized
INFO - 2020-11-21 03:48:20 --> Language Class Initialized
INFO - 2020-11-21 03:48:20 --> Language Class Initialized
INFO - 2020-11-21 03:48:20 --> Config Class Initialized
INFO - 2020-11-21 03:48:20 --> Loader Class Initialized
INFO - 2020-11-21 03:48:20 --> Helper loaded: url_helper
INFO - 2020-11-21 03:48:20 --> Helper loaded: file_helper
INFO - 2020-11-21 03:48:20 --> Helper loaded: form_helper
INFO - 2020-11-21 03:48:20 --> Helper loaded: my_helper
INFO - 2020-11-21 03:48:20 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:48:20 --> Controller Class Initialized
INFO - 2020-11-21 03:48:20 --> Final output sent to browser
DEBUG - 2020-11-21 03:48:20 --> Total execution time: 0.6404
INFO - 2020-11-21 03:51:33 --> Config Class Initialized
INFO - 2020-11-21 03:51:33 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:51:33 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:51:33 --> Utf8 Class Initialized
INFO - 2020-11-21 03:51:33 --> URI Class Initialized
INFO - 2020-11-21 03:51:33 --> Router Class Initialized
INFO - 2020-11-21 03:51:33 --> Output Class Initialized
INFO - 2020-11-21 03:51:33 --> Security Class Initialized
DEBUG - 2020-11-21 03:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:51:33 --> Input Class Initialized
INFO - 2020-11-21 03:51:33 --> Language Class Initialized
INFO - 2020-11-21 03:51:33 --> Language Class Initialized
INFO - 2020-11-21 03:51:33 --> Config Class Initialized
INFO - 2020-11-21 03:51:33 --> Loader Class Initialized
INFO - 2020-11-21 03:51:33 --> Helper loaded: url_helper
INFO - 2020-11-21 03:51:33 --> Helper loaded: file_helper
INFO - 2020-11-21 03:51:33 --> Helper loaded: form_helper
INFO - 2020-11-21 03:51:33 --> Helper loaded: my_helper
INFO - 2020-11-21 03:51:33 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:51:33 --> Controller Class Initialized
DEBUG - 2020-11-21 03:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 03:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:51:33 --> Final output sent to browser
DEBUG - 2020-11-21 03:51:33 --> Total execution time: 0.6286
INFO - 2020-11-21 03:51:47 --> Config Class Initialized
INFO - 2020-11-21 03:51:47 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:51:47 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:51:47 --> Utf8 Class Initialized
INFO - 2020-11-21 03:51:47 --> URI Class Initialized
INFO - 2020-11-21 03:51:47 --> Router Class Initialized
INFO - 2020-11-21 03:51:47 --> Output Class Initialized
INFO - 2020-11-21 03:51:48 --> Security Class Initialized
DEBUG - 2020-11-21 03:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:51:48 --> Input Class Initialized
INFO - 2020-11-21 03:51:48 --> Language Class Initialized
INFO - 2020-11-21 03:51:48 --> Language Class Initialized
INFO - 2020-11-21 03:51:48 --> Config Class Initialized
INFO - 2020-11-21 03:51:48 --> Loader Class Initialized
INFO - 2020-11-21 03:51:48 --> Helper loaded: url_helper
INFO - 2020-11-21 03:51:48 --> Helper loaded: file_helper
INFO - 2020-11-21 03:51:48 --> Helper loaded: form_helper
INFO - 2020-11-21 03:51:48 --> Helper loaded: my_helper
INFO - 2020-11-21 03:51:48 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:51:48 --> Controller Class Initialized
DEBUG - 2020-11-21 03:51:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 03:51:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:51:48 --> Final output sent to browser
DEBUG - 2020-11-21 03:51:48 --> Total execution time: 0.5896
INFO - 2020-11-21 03:53:48 --> Config Class Initialized
INFO - 2020-11-21 03:53:48 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:53:48 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:53:48 --> Utf8 Class Initialized
INFO - 2020-11-21 03:53:48 --> URI Class Initialized
INFO - 2020-11-21 03:53:48 --> Router Class Initialized
INFO - 2020-11-21 03:53:48 --> Output Class Initialized
INFO - 2020-11-21 03:53:48 --> Security Class Initialized
DEBUG - 2020-11-21 03:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:53:48 --> Input Class Initialized
INFO - 2020-11-21 03:53:48 --> Language Class Initialized
INFO - 2020-11-21 03:53:48 --> Language Class Initialized
INFO - 2020-11-21 03:53:48 --> Config Class Initialized
INFO - 2020-11-21 03:53:48 --> Loader Class Initialized
INFO - 2020-11-21 03:53:48 --> Helper loaded: url_helper
INFO - 2020-11-21 03:53:48 --> Helper loaded: file_helper
INFO - 2020-11-21 03:53:48 --> Helper loaded: form_helper
INFO - 2020-11-21 03:53:48 --> Helper loaded: my_helper
INFO - 2020-11-21 03:53:48 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:53:48 --> Controller Class Initialized
INFO - 2020-11-21 03:53:48 --> Final output sent to browser
DEBUG - 2020-11-21 03:53:48 --> Total execution time: 0.7124
INFO - 2020-11-21 03:54:20 --> Config Class Initialized
INFO - 2020-11-21 03:54:20 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:54:20 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:54:20 --> Utf8 Class Initialized
INFO - 2020-11-21 03:54:20 --> URI Class Initialized
INFO - 2020-11-21 03:54:21 --> Router Class Initialized
INFO - 2020-11-21 03:54:21 --> Output Class Initialized
INFO - 2020-11-21 03:54:21 --> Security Class Initialized
DEBUG - 2020-11-21 03:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:54:21 --> Input Class Initialized
INFO - 2020-11-21 03:54:21 --> Language Class Initialized
INFO - 2020-11-21 03:54:21 --> Language Class Initialized
INFO - 2020-11-21 03:54:21 --> Config Class Initialized
INFO - 2020-11-21 03:54:21 --> Loader Class Initialized
INFO - 2020-11-21 03:54:21 --> Helper loaded: url_helper
INFO - 2020-11-21 03:54:21 --> Helper loaded: file_helper
INFO - 2020-11-21 03:54:21 --> Helper loaded: form_helper
INFO - 2020-11-21 03:54:21 --> Helper loaded: my_helper
INFO - 2020-11-21 03:54:21 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:54:21 --> Controller Class Initialized
DEBUG - 2020-11-21 03:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 03:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:54:21 --> Final output sent to browser
DEBUG - 2020-11-21 03:54:21 --> Total execution time: 0.5644
INFO - 2020-11-21 03:54:49 --> Config Class Initialized
INFO - 2020-11-21 03:54:49 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:54:49 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:54:49 --> Utf8 Class Initialized
INFO - 2020-11-21 03:54:49 --> URI Class Initialized
INFO - 2020-11-21 03:54:49 --> Router Class Initialized
INFO - 2020-11-21 03:54:49 --> Output Class Initialized
INFO - 2020-11-21 03:54:49 --> Security Class Initialized
DEBUG - 2020-11-21 03:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:54:49 --> Input Class Initialized
INFO - 2020-11-21 03:54:49 --> Language Class Initialized
INFO - 2020-11-21 03:54:49 --> Language Class Initialized
INFO - 2020-11-21 03:54:49 --> Config Class Initialized
INFO - 2020-11-21 03:54:49 --> Loader Class Initialized
INFO - 2020-11-21 03:54:49 --> Helper loaded: url_helper
INFO - 2020-11-21 03:54:49 --> Helper loaded: file_helper
INFO - 2020-11-21 03:54:49 --> Helper loaded: form_helper
INFO - 2020-11-21 03:54:49 --> Helper loaded: my_helper
INFO - 2020-11-21 03:54:49 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:54:50 --> Controller Class Initialized
DEBUG - 2020-11-21 03:54:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 03:54:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:54:50 --> Final output sent to browser
DEBUG - 2020-11-21 03:54:50 --> Total execution time: 0.7619
INFO - 2020-11-21 03:54:51 --> Config Class Initialized
INFO - 2020-11-21 03:54:51 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:54:51 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:54:51 --> Utf8 Class Initialized
INFO - 2020-11-21 03:54:51 --> URI Class Initialized
INFO - 2020-11-21 03:54:51 --> Router Class Initialized
INFO - 2020-11-21 03:54:51 --> Output Class Initialized
INFO - 2020-11-21 03:54:51 --> Security Class Initialized
DEBUG - 2020-11-21 03:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:54:51 --> Input Class Initialized
INFO - 2020-11-21 03:54:51 --> Language Class Initialized
INFO - 2020-11-21 03:54:51 --> Language Class Initialized
INFO - 2020-11-21 03:54:51 --> Config Class Initialized
INFO - 2020-11-21 03:54:51 --> Loader Class Initialized
INFO - 2020-11-21 03:54:51 --> Helper loaded: url_helper
INFO - 2020-11-21 03:54:51 --> Helper loaded: file_helper
INFO - 2020-11-21 03:54:51 --> Helper loaded: form_helper
INFO - 2020-11-21 03:54:51 --> Helper loaded: my_helper
INFO - 2020-11-21 03:54:51 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:54:51 --> Controller Class Initialized
INFO - 2020-11-21 03:54:51 --> Final output sent to browser
DEBUG - 2020-11-21 03:54:51 --> Total execution time: 0.5378
INFO - 2020-11-21 03:54:58 --> Config Class Initialized
INFO - 2020-11-21 03:54:58 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:54:58 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:54:58 --> Utf8 Class Initialized
INFO - 2020-11-21 03:54:58 --> URI Class Initialized
INFO - 2020-11-21 03:54:58 --> Router Class Initialized
INFO - 2020-11-21 03:54:58 --> Output Class Initialized
INFO - 2020-11-21 03:54:58 --> Security Class Initialized
DEBUG - 2020-11-21 03:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:54:58 --> Input Class Initialized
INFO - 2020-11-21 03:54:58 --> Language Class Initialized
INFO - 2020-11-21 03:54:58 --> Language Class Initialized
INFO - 2020-11-21 03:54:58 --> Config Class Initialized
INFO - 2020-11-21 03:54:58 --> Loader Class Initialized
INFO - 2020-11-21 03:54:58 --> Helper loaded: url_helper
INFO - 2020-11-21 03:54:58 --> Helper loaded: file_helper
INFO - 2020-11-21 03:54:58 --> Helper loaded: form_helper
INFO - 2020-11-21 03:54:58 --> Helper loaded: my_helper
INFO - 2020-11-21 03:54:58 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:54:58 --> Controller Class Initialized
DEBUG - 2020-11-21 03:54:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 03:54:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:54:59 --> Final output sent to browser
DEBUG - 2020-11-21 03:54:59 --> Total execution time: 0.8098
INFO - 2020-11-21 03:55:12 --> Config Class Initialized
INFO - 2020-11-21 03:55:12 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:55:12 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:55:12 --> Utf8 Class Initialized
INFO - 2020-11-21 03:55:12 --> URI Class Initialized
INFO - 2020-11-21 03:55:12 --> Router Class Initialized
INFO - 2020-11-21 03:55:12 --> Output Class Initialized
INFO - 2020-11-21 03:55:12 --> Security Class Initialized
DEBUG - 2020-11-21 03:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:55:12 --> Input Class Initialized
INFO - 2020-11-21 03:55:12 --> Language Class Initialized
INFO - 2020-11-21 03:55:12 --> Language Class Initialized
INFO - 2020-11-21 03:55:12 --> Config Class Initialized
INFO - 2020-11-21 03:55:12 --> Loader Class Initialized
INFO - 2020-11-21 03:55:12 --> Helper loaded: url_helper
INFO - 2020-11-21 03:55:12 --> Helper loaded: file_helper
INFO - 2020-11-21 03:55:12 --> Helper loaded: form_helper
INFO - 2020-11-21 03:55:12 --> Helper loaded: my_helper
INFO - 2020-11-21 03:55:12 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:55:12 --> Controller Class Initialized
DEBUG - 2020-11-21 03:55:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 03:55:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:55:13 --> Final output sent to browser
DEBUG - 2020-11-21 03:55:13 --> Total execution time: 0.4880
INFO - 2020-11-21 03:55:14 --> Config Class Initialized
INFO - 2020-11-21 03:55:14 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:55:14 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:55:14 --> Utf8 Class Initialized
INFO - 2020-11-21 03:55:14 --> URI Class Initialized
INFO - 2020-11-21 03:55:14 --> Router Class Initialized
INFO - 2020-11-21 03:55:14 --> Output Class Initialized
INFO - 2020-11-21 03:55:14 --> Security Class Initialized
DEBUG - 2020-11-21 03:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:55:14 --> Input Class Initialized
INFO - 2020-11-21 03:55:15 --> Language Class Initialized
INFO - 2020-11-21 03:55:15 --> Language Class Initialized
INFO - 2020-11-21 03:55:15 --> Config Class Initialized
INFO - 2020-11-21 03:55:15 --> Loader Class Initialized
INFO - 2020-11-21 03:55:15 --> Helper loaded: url_helper
INFO - 2020-11-21 03:55:15 --> Helper loaded: file_helper
INFO - 2020-11-21 03:55:15 --> Helper loaded: form_helper
INFO - 2020-11-21 03:55:15 --> Helper loaded: my_helper
INFO - 2020-11-21 03:55:15 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:55:15 --> Controller Class Initialized
INFO - 2020-11-21 03:55:15 --> Final output sent to browser
DEBUG - 2020-11-21 03:55:15 --> Total execution time: 0.6899
INFO - 2020-11-21 03:55:35 --> Config Class Initialized
INFO - 2020-11-21 03:55:35 --> Hooks Class Initialized
DEBUG - 2020-11-21 03:55:35 --> UTF-8 Support Enabled
INFO - 2020-11-21 03:55:35 --> Utf8 Class Initialized
INFO - 2020-11-21 03:55:35 --> URI Class Initialized
INFO - 2020-11-21 03:55:35 --> Router Class Initialized
INFO - 2020-11-21 03:55:35 --> Output Class Initialized
INFO - 2020-11-21 03:55:35 --> Security Class Initialized
DEBUG - 2020-11-21 03:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 03:55:35 --> Input Class Initialized
INFO - 2020-11-21 03:55:35 --> Language Class Initialized
INFO - 2020-11-21 03:55:35 --> Language Class Initialized
INFO - 2020-11-21 03:55:35 --> Config Class Initialized
INFO - 2020-11-21 03:55:35 --> Loader Class Initialized
INFO - 2020-11-21 03:55:35 --> Helper loaded: url_helper
INFO - 2020-11-21 03:55:35 --> Helper loaded: file_helper
INFO - 2020-11-21 03:55:35 --> Helper loaded: form_helper
INFO - 2020-11-21 03:55:35 --> Helper loaded: my_helper
INFO - 2020-11-21 03:55:35 --> Database Driver Class Initialized
DEBUG - 2020-11-21 03:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 03:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 03:55:35 --> Controller Class Initialized
DEBUG - 2020-11-21 03:55:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 03:55:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 03:55:36 --> Final output sent to browser
DEBUG - 2020-11-21 03:55:36 --> Total execution time: 0.6982
INFO - 2020-11-21 04:27:12 --> Config Class Initialized
INFO - 2020-11-21 04:27:12 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:27:12 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:27:12 --> Utf8 Class Initialized
INFO - 2020-11-21 04:27:12 --> URI Class Initialized
INFO - 2020-11-21 04:27:12 --> Router Class Initialized
INFO - 2020-11-21 04:27:12 --> Output Class Initialized
INFO - 2020-11-21 04:27:12 --> Security Class Initialized
DEBUG - 2020-11-21 04:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:27:12 --> Input Class Initialized
INFO - 2020-11-21 04:27:12 --> Language Class Initialized
INFO - 2020-11-21 04:27:12 --> Language Class Initialized
INFO - 2020-11-21 04:27:12 --> Config Class Initialized
INFO - 2020-11-21 04:27:13 --> Loader Class Initialized
INFO - 2020-11-21 04:27:13 --> Helper loaded: url_helper
INFO - 2020-11-21 04:27:13 --> Helper loaded: file_helper
INFO - 2020-11-21 04:27:13 --> Helper loaded: form_helper
INFO - 2020-11-21 04:27:13 --> Helper loaded: my_helper
INFO - 2020-11-21 04:27:13 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:27:13 --> Controller Class Initialized
INFO - 2020-11-21 04:27:13 --> Final output sent to browser
DEBUG - 2020-11-21 04:27:13 --> Total execution time: 0.7908
INFO - 2020-11-21 04:27:25 --> Config Class Initialized
INFO - 2020-11-21 04:27:25 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:27:25 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:27:25 --> Utf8 Class Initialized
INFO - 2020-11-21 04:27:25 --> URI Class Initialized
INFO - 2020-11-21 04:27:25 --> Router Class Initialized
INFO - 2020-11-21 04:27:25 --> Output Class Initialized
INFO - 2020-11-21 04:27:25 --> Security Class Initialized
DEBUG - 2020-11-21 04:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:27:25 --> Input Class Initialized
INFO - 2020-11-21 04:27:25 --> Language Class Initialized
INFO - 2020-11-21 04:27:25 --> Language Class Initialized
INFO - 2020-11-21 04:27:25 --> Config Class Initialized
INFO - 2020-11-21 04:27:25 --> Loader Class Initialized
INFO - 2020-11-21 04:27:25 --> Helper loaded: url_helper
INFO - 2020-11-21 04:27:25 --> Helper loaded: file_helper
INFO - 2020-11-21 04:27:25 --> Helper loaded: form_helper
INFO - 2020-11-21 04:27:26 --> Helper loaded: my_helper
INFO - 2020-11-21 04:27:26 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:27:26 --> Controller Class Initialized
INFO - 2020-11-21 04:27:26 --> Final output sent to browser
DEBUG - 2020-11-21 04:27:26 --> Total execution time: 0.6255
INFO - 2020-11-21 04:28:43 --> Config Class Initialized
INFO - 2020-11-21 04:28:43 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:28:43 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:28:43 --> Utf8 Class Initialized
INFO - 2020-11-21 04:28:43 --> URI Class Initialized
INFO - 2020-11-21 04:28:43 --> Router Class Initialized
INFO - 2020-11-21 04:28:43 --> Output Class Initialized
INFO - 2020-11-21 04:28:43 --> Security Class Initialized
DEBUG - 2020-11-21 04:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:28:43 --> Input Class Initialized
INFO - 2020-11-21 04:28:43 --> Language Class Initialized
INFO - 2020-11-21 04:28:43 --> Language Class Initialized
INFO - 2020-11-21 04:28:43 --> Config Class Initialized
INFO - 2020-11-21 04:28:43 --> Loader Class Initialized
INFO - 2020-11-21 04:28:43 --> Helper loaded: url_helper
INFO - 2020-11-21 04:28:43 --> Helper loaded: file_helper
INFO - 2020-11-21 04:28:43 --> Helper loaded: form_helper
INFO - 2020-11-21 04:28:43 --> Helper loaded: my_helper
INFO - 2020-11-21 04:28:43 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:28:43 --> Controller Class Initialized
INFO - 2020-11-21 04:28:43 --> Final output sent to browser
DEBUG - 2020-11-21 04:28:43 --> Total execution time: 0.2277
INFO - 2020-11-21 04:29:03 --> Config Class Initialized
INFO - 2020-11-21 04:29:03 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:29:03 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:29:03 --> Utf8 Class Initialized
INFO - 2020-11-21 04:29:03 --> URI Class Initialized
INFO - 2020-11-21 04:29:03 --> Router Class Initialized
INFO - 2020-11-21 04:29:03 --> Output Class Initialized
INFO - 2020-11-21 04:29:03 --> Security Class Initialized
DEBUG - 2020-11-21 04:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:29:03 --> Input Class Initialized
INFO - 2020-11-21 04:29:03 --> Language Class Initialized
INFO - 2020-11-21 04:29:03 --> Language Class Initialized
INFO - 2020-11-21 04:29:03 --> Config Class Initialized
INFO - 2020-11-21 04:29:03 --> Loader Class Initialized
INFO - 2020-11-21 04:29:03 --> Helper loaded: url_helper
INFO - 2020-11-21 04:29:03 --> Helper loaded: file_helper
INFO - 2020-11-21 04:29:03 --> Helper loaded: form_helper
INFO - 2020-11-21 04:29:03 --> Helper loaded: my_helper
INFO - 2020-11-21 04:29:03 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:29:03 --> Controller Class Initialized
INFO - 2020-11-21 04:29:03 --> Final output sent to browser
DEBUG - 2020-11-21 04:29:03 --> Total execution time: 0.2192
INFO - 2020-11-21 04:29:11 --> Config Class Initialized
INFO - 2020-11-21 04:29:11 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:29:11 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:29:11 --> Utf8 Class Initialized
INFO - 2020-11-21 04:29:11 --> URI Class Initialized
INFO - 2020-11-21 04:29:11 --> Router Class Initialized
INFO - 2020-11-21 04:29:11 --> Output Class Initialized
INFO - 2020-11-21 04:29:11 --> Security Class Initialized
DEBUG - 2020-11-21 04:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:29:11 --> Input Class Initialized
INFO - 2020-11-21 04:29:11 --> Language Class Initialized
INFO - 2020-11-21 04:29:11 --> Language Class Initialized
INFO - 2020-11-21 04:29:11 --> Config Class Initialized
INFO - 2020-11-21 04:29:11 --> Loader Class Initialized
INFO - 2020-11-21 04:29:11 --> Helper loaded: url_helper
INFO - 2020-11-21 04:29:11 --> Helper loaded: file_helper
INFO - 2020-11-21 04:29:11 --> Helper loaded: form_helper
INFO - 2020-11-21 04:29:11 --> Helper loaded: my_helper
INFO - 2020-11-21 04:29:11 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:29:11 --> Controller Class Initialized
INFO - 2020-11-21 04:29:11 --> Final output sent to browser
DEBUG - 2020-11-21 04:29:11 --> Total execution time: 0.2305
INFO - 2020-11-21 04:29:26 --> Config Class Initialized
INFO - 2020-11-21 04:29:26 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:29:26 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:29:26 --> Utf8 Class Initialized
INFO - 2020-11-21 04:29:26 --> URI Class Initialized
INFO - 2020-11-21 04:29:27 --> Router Class Initialized
INFO - 2020-11-21 04:29:27 --> Output Class Initialized
INFO - 2020-11-21 04:29:27 --> Security Class Initialized
DEBUG - 2020-11-21 04:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:29:27 --> Input Class Initialized
INFO - 2020-11-21 04:29:27 --> Language Class Initialized
INFO - 2020-11-21 04:29:27 --> Language Class Initialized
INFO - 2020-11-21 04:29:27 --> Config Class Initialized
INFO - 2020-11-21 04:29:27 --> Loader Class Initialized
INFO - 2020-11-21 04:29:27 --> Helper loaded: url_helper
INFO - 2020-11-21 04:29:27 --> Helper loaded: file_helper
INFO - 2020-11-21 04:29:27 --> Helper loaded: form_helper
INFO - 2020-11-21 04:29:27 --> Helper loaded: my_helper
INFO - 2020-11-21 04:29:27 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:29:27 --> Controller Class Initialized
INFO - 2020-11-21 04:29:27 --> Final output sent to browser
DEBUG - 2020-11-21 04:29:27 --> Total execution time: 0.2286
INFO - 2020-11-21 04:29:41 --> Config Class Initialized
INFO - 2020-11-21 04:29:41 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:29:41 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:29:41 --> Utf8 Class Initialized
INFO - 2020-11-21 04:29:41 --> URI Class Initialized
INFO - 2020-11-21 04:29:41 --> Router Class Initialized
INFO - 2020-11-21 04:29:41 --> Output Class Initialized
INFO - 2020-11-21 04:29:41 --> Security Class Initialized
DEBUG - 2020-11-21 04:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:29:41 --> Input Class Initialized
INFO - 2020-11-21 04:29:41 --> Language Class Initialized
INFO - 2020-11-21 04:29:41 --> Language Class Initialized
INFO - 2020-11-21 04:29:41 --> Config Class Initialized
INFO - 2020-11-21 04:29:41 --> Loader Class Initialized
INFO - 2020-11-21 04:29:41 --> Helper loaded: url_helper
INFO - 2020-11-21 04:29:41 --> Helper loaded: file_helper
INFO - 2020-11-21 04:29:41 --> Helper loaded: form_helper
INFO - 2020-11-21 04:29:41 --> Helper loaded: my_helper
INFO - 2020-11-21 04:29:41 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:29:41 --> Controller Class Initialized
INFO - 2020-11-21 04:29:41 --> Final output sent to browser
DEBUG - 2020-11-21 04:29:41 --> Total execution time: 0.2562
INFO - 2020-11-21 04:29:50 --> Config Class Initialized
INFO - 2020-11-21 04:29:50 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:29:50 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:29:50 --> Utf8 Class Initialized
INFO - 2020-11-21 04:29:50 --> URI Class Initialized
INFO - 2020-11-21 04:29:50 --> Router Class Initialized
INFO - 2020-11-21 04:29:50 --> Output Class Initialized
INFO - 2020-11-21 04:29:50 --> Security Class Initialized
DEBUG - 2020-11-21 04:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:29:50 --> Input Class Initialized
INFO - 2020-11-21 04:29:50 --> Language Class Initialized
INFO - 2020-11-21 04:29:50 --> Language Class Initialized
INFO - 2020-11-21 04:29:50 --> Config Class Initialized
INFO - 2020-11-21 04:29:50 --> Loader Class Initialized
INFO - 2020-11-21 04:29:50 --> Helper loaded: url_helper
INFO - 2020-11-21 04:29:50 --> Helper loaded: file_helper
INFO - 2020-11-21 04:29:50 --> Helper loaded: form_helper
INFO - 2020-11-21 04:29:50 --> Helper loaded: my_helper
INFO - 2020-11-21 04:29:50 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:29:50 --> Controller Class Initialized
INFO - 2020-11-21 04:29:50 --> Final output sent to browser
DEBUG - 2020-11-21 04:29:50 --> Total execution time: 0.2286
INFO - 2020-11-21 04:30:32 --> Config Class Initialized
INFO - 2020-11-21 04:30:32 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:30:32 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:30:32 --> Utf8 Class Initialized
INFO - 2020-11-21 04:30:32 --> URI Class Initialized
INFO - 2020-11-21 04:30:32 --> Router Class Initialized
INFO - 2020-11-21 04:30:32 --> Output Class Initialized
INFO - 2020-11-21 04:30:32 --> Security Class Initialized
DEBUG - 2020-11-21 04:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:30:32 --> Input Class Initialized
INFO - 2020-11-21 04:30:32 --> Language Class Initialized
INFO - 2020-11-21 04:30:32 --> Language Class Initialized
INFO - 2020-11-21 04:30:32 --> Config Class Initialized
INFO - 2020-11-21 04:30:32 --> Loader Class Initialized
INFO - 2020-11-21 04:30:32 --> Helper loaded: url_helper
INFO - 2020-11-21 04:30:32 --> Helper loaded: file_helper
INFO - 2020-11-21 04:30:32 --> Helper loaded: form_helper
INFO - 2020-11-21 04:30:32 --> Helper loaded: my_helper
INFO - 2020-11-21 04:30:32 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:30:32 --> Controller Class Initialized
DEBUG - 2020-11-21 04:30:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/cetak.php
INFO - 2020-11-21 04:30:32 --> Final output sent to browser
DEBUG - 2020-11-21 04:30:32 --> Total execution time: 0.2791
INFO - 2020-11-21 04:30:36 --> Config Class Initialized
INFO - 2020-11-21 04:30:36 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:30:36 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:30:36 --> Utf8 Class Initialized
INFO - 2020-11-21 04:30:37 --> URI Class Initialized
INFO - 2020-11-21 04:30:37 --> Router Class Initialized
INFO - 2020-11-21 04:30:37 --> Output Class Initialized
INFO - 2020-11-21 04:30:37 --> Security Class Initialized
DEBUG - 2020-11-21 04:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:30:37 --> Input Class Initialized
INFO - 2020-11-21 04:30:37 --> Language Class Initialized
INFO - 2020-11-21 04:30:37 --> Language Class Initialized
INFO - 2020-11-21 04:30:37 --> Config Class Initialized
INFO - 2020-11-21 04:30:37 --> Loader Class Initialized
INFO - 2020-11-21 04:30:37 --> Helper loaded: url_helper
INFO - 2020-11-21 04:30:37 --> Helper loaded: file_helper
INFO - 2020-11-21 04:30:37 --> Helper loaded: form_helper
INFO - 2020-11-21 04:30:37 --> Helper loaded: my_helper
INFO - 2020-11-21 04:30:37 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:30:37 --> Controller Class Initialized
INFO - 2020-11-21 04:30:37 --> Final output sent to browser
DEBUG - 2020-11-21 04:30:37 --> Total execution time: 0.2340
INFO - 2020-11-21 04:34:09 --> Config Class Initialized
INFO - 2020-11-21 04:34:09 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:34:09 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:34:09 --> Utf8 Class Initialized
INFO - 2020-11-21 04:34:09 --> URI Class Initialized
INFO - 2020-11-21 04:34:09 --> Router Class Initialized
INFO - 2020-11-21 04:34:09 --> Output Class Initialized
INFO - 2020-11-21 04:34:09 --> Security Class Initialized
DEBUG - 2020-11-21 04:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:34:09 --> Input Class Initialized
INFO - 2020-11-21 04:34:09 --> Language Class Initialized
INFO - 2020-11-21 04:34:09 --> Language Class Initialized
INFO - 2020-11-21 04:34:09 --> Config Class Initialized
INFO - 2020-11-21 04:34:09 --> Loader Class Initialized
INFO - 2020-11-21 04:34:09 --> Helper loaded: url_helper
INFO - 2020-11-21 04:34:09 --> Helper loaded: file_helper
INFO - 2020-11-21 04:34:09 --> Helper loaded: form_helper
INFO - 2020-11-21 04:34:09 --> Helper loaded: my_helper
INFO - 2020-11-21 04:34:09 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:34:09 --> Controller Class Initialized
DEBUG - 2020-11-21 04:34:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 04:34:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:34:09 --> Final output sent to browser
DEBUG - 2020-11-21 04:34:09 --> Total execution time: 0.2474
INFO - 2020-11-21 04:34:38 --> Config Class Initialized
INFO - 2020-11-21 04:34:38 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:34:38 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:34:38 --> Utf8 Class Initialized
INFO - 2020-11-21 04:34:38 --> URI Class Initialized
INFO - 2020-11-21 04:34:38 --> Router Class Initialized
INFO - 2020-11-21 04:34:38 --> Output Class Initialized
INFO - 2020-11-21 04:34:38 --> Security Class Initialized
DEBUG - 2020-11-21 04:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:34:38 --> Input Class Initialized
INFO - 2020-11-21 04:34:38 --> Language Class Initialized
INFO - 2020-11-21 04:34:38 --> Language Class Initialized
INFO - 2020-11-21 04:34:38 --> Config Class Initialized
INFO - 2020-11-21 04:34:38 --> Loader Class Initialized
INFO - 2020-11-21 04:34:38 --> Helper loaded: url_helper
INFO - 2020-11-21 04:34:38 --> Helper loaded: file_helper
INFO - 2020-11-21 04:34:38 --> Helper loaded: form_helper
INFO - 2020-11-21 04:34:38 --> Helper loaded: my_helper
INFO - 2020-11-21 04:34:38 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:34:38 --> Controller Class Initialized
INFO - 2020-11-21 04:34:38 --> Helper loaded: cookie_helper
INFO - 2020-11-21 04:34:38 --> Config Class Initialized
INFO - 2020-11-21 04:34:38 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:34:38 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:34:38 --> Utf8 Class Initialized
INFO - 2020-11-21 04:34:38 --> URI Class Initialized
INFO - 2020-11-21 04:34:38 --> Router Class Initialized
INFO - 2020-11-21 04:34:38 --> Output Class Initialized
INFO - 2020-11-21 04:34:38 --> Security Class Initialized
DEBUG - 2020-11-21 04:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:34:38 --> Input Class Initialized
INFO - 2020-11-21 04:34:38 --> Language Class Initialized
INFO - 2020-11-21 04:34:38 --> Language Class Initialized
INFO - 2020-11-21 04:34:38 --> Config Class Initialized
INFO - 2020-11-21 04:34:38 --> Loader Class Initialized
INFO - 2020-11-21 04:34:38 --> Helper loaded: url_helper
INFO - 2020-11-21 04:34:39 --> Helper loaded: file_helper
INFO - 2020-11-21 04:34:39 --> Helper loaded: form_helper
INFO - 2020-11-21 04:34:39 --> Helper loaded: my_helper
INFO - 2020-11-21 04:34:39 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:34:39 --> Controller Class Initialized
DEBUG - 2020-11-21 04:34:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-21 04:34:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:34:39 --> Final output sent to browser
DEBUG - 2020-11-21 04:34:39 --> Total execution time: 0.3146
INFO - 2020-11-21 04:34:45 --> Config Class Initialized
INFO - 2020-11-21 04:34:45 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:34:45 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:34:45 --> Utf8 Class Initialized
INFO - 2020-11-21 04:34:45 --> URI Class Initialized
INFO - 2020-11-21 04:34:45 --> Router Class Initialized
INFO - 2020-11-21 04:34:45 --> Output Class Initialized
INFO - 2020-11-21 04:34:45 --> Security Class Initialized
DEBUG - 2020-11-21 04:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:34:45 --> Input Class Initialized
INFO - 2020-11-21 04:34:45 --> Language Class Initialized
INFO - 2020-11-21 04:34:45 --> Language Class Initialized
INFO - 2020-11-21 04:34:45 --> Config Class Initialized
INFO - 2020-11-21 04:34:45 --> Loader Class Initialized
INFO - 2020-11-21 04:34:45 --> Helper loaded: url_helper
INFO - 2020-11-21 04:34:45 --> Helper loaded: file_helper
INFO - 2020-11-21 04:34:45 --> Helper loaded: form_helper
INFO - 2020-11-21 04:34:45 --> Helper loaded: my_helper
INFO - 2020-11-21 04:34:45 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:34:45 --> Controller Class Initialized
INFO - 2020-11-21 04:34:46 --> Final output sent to browser
DEBUG - 2020-11-21 04:34:46 --> Total execution time: 0.3151
INFO - 2020-11-21 04:38:01 --> Config Class Initialized
INFO - 2020-11-21 04:38:01 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:38:01 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:38:01 --> Utf8 Class Initialized
INFO - 2020-11-21 04:38:01 --> URI Class Initialized
INFO - 2020-11-21 04:38:01 --> Router Class Initialized
INFO - 2020-11-21 04:38:01 --> Output Class Initialized
INFO - 2020-11-21 04:38:01 --> Security Class Initialized
DEBUG - 2020-11-21 04:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:38:01 --> Input Class Initialized
INFO - 2020-11-21 04:38:01 --> Language Class Initialized
INFO - 2020-11-21 04:38:01 --> Language Class Initialized
INFO - 2020-11-21 04:38:01 --> Config Class Initialized
INFO - 2020-11-21 04:38:01 --> Loader Class Initialized
INFO - 2020-11-21 04:38:01 --> Helper loaded: url_helper
INFO - 2020-11-21 04:38:01 --> Helper loaded: file_helper
INFO - 2020-11-21 04:38:01 --> Helper loaded: form_helper
INFO - 2020-11-21 04:38:01 --> Helper loaded: my_helper
INFO - 2020-11-21 04:38:01 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:38:01 --> Controller Class Initialized
DEBUG - 2020-11-21 04:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-21 04:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:38:01 --> Final output sent to browser
DEBUG - 2020-11-21 04:38:01 --> Total execution time: 0.4110
INFO - 2020-11-21 04:38:07 --> Config Class Initialized
INFO - 2020-11-21 04:38:07 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:38:07 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:38:07 --> Utf8 Class Initialized
INFO - 2020-11-21 04:38:07 --> URI Class Initialized
INFO - 2020-11-21 04:38:07 --> Router Class Initialized
INFO - 2020-11-21 04:38:07 --> Output Class Initialized
INFO - 2020-11-21 04:38:07 --> Security Class Initialized
DEBUG - 2020-11-21 04:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:38:07 --> Input Class Initialized
INFO - 2020-11-21 04:38:07 --> Language Class Initialized
INFO - 2020-11-21 04:38:07 --> Language Class Initialized
INFO - 2020-11-21 04:38:07 --> Config Class Initialized
INFO - 2020-11-21 04:38:07 --> Loader Class Initialized
INFO - 2020-11-21 04:38:07 --> Helper loaded: url_helper
INFO - 2020-11-21 04:38:07 --> Helper loaded: file_helper
INFO - 2020-11-21 04:38:07 --> Helper loaded: form_helper
INFO - 2020-11-21 04:38:07 --> Helper loaded: my_helper
INFO - 2020-11-21 04:38:07 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:38:07 --> Controller Class Initialized
INFO - 2020-11-21 04:38:07 --> Final output sent to browser
DEBUG - 2020-11-21 04:38:07 --> Total execution time: 0.3273
INFO - 2020-11-21 04:38:14 --> Config Class Initialized
INFO - 2020-11-21 04:38:14 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:38:14 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:38:14 --> Utf8 Class Initialized
INFO - 2020-11-21 04:38:14 --> URI Class Initialized
INFO - 2020-11-21 04:38:14 --> Router Class Initialized
INFO - 2020-11-21 04:38:14 --> Output Class Initialized
INFO - 2020-11-21 04:38:14 --> Security Class Initialized
DEBUG - 2020-11-21 04:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:38:14 --> Input Class Initialized
INFO - 2020-11-21 04:38:14 --> Language Class Initialized
INFO - 2020-11-21 04:38:14 --> Language Class Initialized
INFO - 2020-11-21 04:38:14 --> Config Class Initialized
INFO - 2020-11-21 04:38:14 --> Loader Class Initialized
INFO - 2020-11-21 04:38:14 --> Helper loaded: url_helper
INFO - 2020-11-21 04:38:14 --> Helper loaded: file_helper
INFO - 2020-11-21 04:38:14 --> Helper loaded: form_helper
INFO - 2020-11-21 04:38:14 --> Helper loaded: my_helper
INFO - 2020-11-21 04:38:14 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:38:14 --> Controller Class Initialized
INFO - 2020-11-21 04:38:14 --> Helper loaded: cookie_helper
INFO - 2020-11-21 04:38:15 --> Final output sent to browser
DEBUG - 2020-11-21 04:38:15 --> Total execution time: 0.3500
INFO - 2020-11-21 04:38:15 --> Config Class Initialized
INFO - 2020-11-21 04:38:15 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:38:15 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:38:15 --> Utf8 Class Initialized
INFO - 2020-11-21 04:38:15 --> URI Class Initialized
INFO - 2020-11-21 04:38:15 --> Router Class Initialized
INFO - 2020-11-21 04:38:15 --> Output Class Initialized
INFO - 2020-11-21 04:38:15 --> Security Class Initialized
DEBUG - 2020-11-21 04:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:38:15 --> Input Class Initialized
INFO - 2020-11-21 04:38:15 --> Language Class Initialized
INFO - 2020-11-21 04:38:15 --> Language Class Initialized
INFO - 2020-11-21 04:38:15 --> Config Class Initialized
INFO - 2020-11-21 04:38:15 --> Loader Class Initialized
INFO - 2020-11-21 04:38:15 --> Helper loaded: url_helper
INFO - 2020-11-21 04:38:15 --> Helper loaded: file_helper
INFO - 2020-11-21 04:38:15 --> Helper loaded: form_helper
INFO - 2020-11-21 04:38:15 --> Helper loaded: my_helper
INFO - 2020-11-21 04:38:15 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:38:15 --> Controller Class Initialized
DEBUG - 2020-11-21 04:38:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-21 04:38:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:38:16 --> Final output sent to browser
DEBUG - 2020-11-21 04:38:16 --> Total execution time: 0.4007
INFO - 2020-11-21 04:38:18 --> Config Class Initialized
INFO - 2020-11-21 04:38:18 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:38:18 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:38:18 --> Utf8 Class Initialized
INFO - 2020-11-21 04:38:18 --> URI Class Initialized
INFO - 2020-11-21 04:38:18 --> Router Class Initialized
INFO - 2020-11-21 04:38:18 --> Output Class Initialized
INFO - 2020-11-21 04:38:18 --> Security Class Initialized
DEBUG - 2020-11-21 04:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:38:18 --> Input Class Initialized
INFO - 2020-11-21 04:38:18 --> Language Class Initialized
INFO - 2020-11-21 04:38:18 --> Language Class Initialized
INFO - 2020-11-21 04:38:18 --> Config Class Initialized
INFO - 2020-11-21 04:38:18 --> Loader Class Initialized
INFO - 2020-11-21 04:38:18 --> Helper loaded: url_helper
INFO - 2020-11-21 04:38:18 --> Helper loaded: file_helper
INFO - 2020-11-21 04:38:18 --> Helper loaded: form_helper
INFO - 2020-11-21 04:38:18 --> Helper loaded: my_helper
INFO - 2020-11-21 04:38:18 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:38:18 --> Controller Class Initialized
DEBUG - 2020-11-21 04:38:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-11-21 04:38:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:38:18 --> Final output sent to browser
DEBUG - 2020-11-21 04:38:18 --> Total execution time: 0.3122
INFO - 2020-11-21 04:38:18 --> Config Class Initialized
INFO - 2020-11-21 04:38:18 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:38:19 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:38:19 --> Utf8 Class Initialized
INFO - 2020-11-21 04:38:19 --> URI Class Initialized
INFO - 2020-11-21 04:38:19 --> Router Class Initialized
INFO - 2020-11-21 04:38:19 --> Output Class Initialized
INFO - 2020-11-21 04:38:19 --> Security Class Initialized
DEBUG - 2020-11-21 04:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:38:19 --> Input Class Initialized
INFO - 2020-11-21 04:38:19 --> Language Class Initialized
INFO - 2020-11-21 04:38:19 --> Language Class Initialized
INFO - 2020-11-21 04:38:19 --> Config Class Initialized
INFO - 2020-11-21 04:38:19 --> Loader Class Initialized
INFO - 2020-11-21 04:38:19 --> Helper loaded: url_helper
INFO - 2020-11-21 04:38:19 --> Helper loaded: file_helper
INFO - 2020-11-21 04:38:19 --> Helper loaded: form_helper
INFO - 2020-11-21 04:38:19 --> Helper loaded: my_helper
INFO - 2020-11-21 04:38:19 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:38:19 --> Controller Class Initialized
INFO - 2020-11-21 04:38:23 --> Config Class Initialized
INFO - 2020-11-21 04:38:23 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:38:23 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:38:23 --> Utf8 Class Initialized
INFO - 2020-11-21 04:38:23 --> URI Class Initialized
INFO - 2020-11-21 04:38:23 --> Router Class Initialized
INFO - 2020-11-21 04:38:23 --> Output Class Initialized
INFO - 2020-11-21 04:38:23 --> Security Class Initialized
DEBUG - 2020-11-21 04:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:38:23 --> Input Class Initialized
INFO - 2020-11-21 04:38:23 --> Language Class Initialized
INFO - 2020-11-21 04:38:23 --> Language Class Initialized
INFO - 2020-11-21 04:38:23 --> Config Class Initialized
INFO - 2020-11-21 04:38:23 --> Loader Class Initialized
INFO - 2020-11-21 04:38:23 --> Helper loaded: url_helper
INFO - 2020-11-21 04:38:23 --> Helper loaded: file_helper
INFO - 2020-11-21 04:38:23 --> Helper loaded: form_helper
INFO - 2020-11-21 04:38:23 --> Helper loaded: my_helper
INFO - 2020-11-21 04:38:23 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:38:23 --> Controller Class Initialized
INFO - 2020-11-21 04:38:23 --> Helper loaded: cookie_helper
INFO - 2020-11-21 04:38:23 --> Config Class Initialized
INFO - 2020-11-21 04:38:23 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:38:23 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:38:23 --> Utf8 Class Initialized
INFO - 2020-11-21 04:38:23 --> URI Class Initialized
INFO - 2020-11-21 04:38:23 --> Router Class Initialized
INFO - 2020-11-21 04:38:23 --> Output Class Initialized
INFO - 2020-11-21 04:38:23 --> Security Class Initialized
DEBUG - 2020-11-21 04:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:38:23 --> Input Class Initialized
INFO - 2020-11-21 04:38:23 --> Language Class Initialized
INFO - 2020-11-21 04:38:23 --> Language Class Initialized
INFO - 2020-11-21 04:38:23 --> Config Class Initialized
INFO - 2020-11-21 04:38:23 --> Loader Class Initialized
INFO - 2020-11-21 04:38:23 --> Helper loaded: url_helper
INFO - 2020-11-21 04:38:23 --> Helper loaded: file_helper
INFO - 2020-11-21 04:38:23 --> Helper loaded: form_helper
INFO - 2020-11-21 04:38:23 --> Helper loaded: my_helper
INFO - 2020-11-21 04:38:23 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:38:23 --> Controller Class Initialized
DEBUG - 2020-11-21 04:38:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-21 04:38:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:38:23 --> Final output sent to browser
DEBUG - 2020-11-21 04:38:23 --> Total execution time: 0.2988
INFO - 2020-11-21 04:50:30 --> Config Class Initialized
INFO - 2020-11-21 04:50:30 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:30 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:30 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:30 --> URI Class Initialized
INFO - 2020-11-21 04:50:30 --> Router Class Initialized
INFO - 2020-11-21 04:50:30 --> Output Class Initialized
INFO - 2020-11-21 04:50:30 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:30 --> Input Class Initialized
INFO - 2020-11-21 04:50:30 --> Language Class Initialized
INFO - 2020-11-21 04:50:30 --> Language Class Initialized
INFO - 2020-11-21 04:50:30 --> Config Class Initialized
INFO - 2020-11-21 04:50:30 --> Loader Class Initialized
INFO - 2020-11-21 04:50:30 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:30 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:30 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:30 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:30 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:30 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-21 04:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:30 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:30 --> Total execution time: 0.2896
INFO - 2020-11-21 04:50:34 --> Config Class Initialized
INFO - 2020-11-21 04:50:34 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:34 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:34 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:34 --> URI Class Initialized
INFO - 2020-11-21 04:50:34 --> Router Class Initialized
INFO - 2020-11-21 04:50:34 --> Output Class Initialized
INFO - 2020-11-21 04:50:34 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:34 --> Input Class Initialized
INFO - 2020-11-21 04:50:34 --> Language Class Initialized
INFO - 2020-11-21 04:50:34 --> Language Class Initialized
INFO - 2020-11-21 04:50:34 --> Config Class Initialized
INFO - 2020-11-21 04:50:34 --> Loader Class Initialized
INFO - 2020-11-21 04:50:34 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:34 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:34 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:34 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:34 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:34 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-21 04:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:34 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:34 --> Total execution time: 0.2524
INFO - 2020-11-21 04:50:37 --> Config Class Initialized
INFO - 2020-11-21 04:50:37 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:37 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:37 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:37 --> URI Class Initialized
DEBUG - 2020-11-21 04:50:37 --> No URI present. Default controller set.
INFO - 2020-11-21 04:50:37 --> Router Class Initialized
INFO - 2020-11-21 04:50:37 --> Output Class Initialized
INFO - 2020-11-21 04:50:37 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:37 --> Input Class Initialized
INFO - 2020-11-21 04:50:37 --> Language Class Initialized
INFO - 2020-11-21 04:50:37 --> Language Class Initialized
INFO - 2020-11-21 04:50:37 --> Config Class Initialized
INFO - 2020-11-21 04:50:37 --> Loader Class Initialized
INFO - 2020-11-21 04:50:37 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:37 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:37 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:37 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:37 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:38 --> Controller Class Initialized
INFO - 2020-11-21 04:50:38 --> Config Class Initialized
INFO - 2020-11-21 04:50:38 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:38 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:38 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:38 --> URI Class Initialized
INFO - 2020-11-21 04:50:38 --> Router Class Initialized
INFO - 2020-11-21 04:50:38 --> Output Class Initialized
INFO - 2020-11-21 04:50:38 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:38 --> Input Class Initialized
INFO - 2020-11-21 04:50:38 --> Language Class Initialized
INFO - 2020-11-21 04:50:38 --> Language Class Initialized
INFO - 2020-11-21 04:50:38 --> Config Class Initialized
INFO - 2020-11-21 04:50:38 --> Loader Class Initialized
INFO - 2020-11-21 04:50:38 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:38 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:38 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:38 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:38 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:38 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-21 04:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:38 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:38 --> Total execution time: 0.2329
INFO - 2020-11-21 04:50:42 --> Config Class Initialized
INFO - 2020-11-21 04:50:42 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:42 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:42 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:42 --> URI Class Initialized
INFO - 2020-11-21 04:50:42 --> Router Class Initialized
INFO - 2020-11-21 04:50:43 --> Output Class Initialized
INFO - 2020-11-21 04:50:43 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:43 --> Input Class Initialized
INFO - 2020-11-21 04:50:43 --> Language Class Initialized
INFO - 2020-11-21 04:50:43 --> Language Class Initialized
INFO - 2020-11-21 04:50:43 --> Config Class Initialized
INFO - 2020-11-21 04:50:43 --> Loader Class Initialized
INFO - 2020-11-21 04:50:43 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:43 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:43 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:43 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:43 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:43 --> Controller Class Initialized
INFO - 2020-11-21 04:50:43 --> Helper loaded: cookie_helper
INFO - 2020-11-21 04:50:43 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:43 --> Total execution time: 0.3203
INFO - 2020-11-21 04:50:43 --> Config Class Initialized
INFO - 2020-11-21 04:50:43 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:43 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:43 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:43 --> URI Class Initialized
INFO - 2020-11-21 04:50:43 --> Router Class Initialized
INFO - 2020-11-21 04:50:43 --> Output Class Initialized
INFO - 2020-11-21 04:50:43 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:43 --> Input Class Initialized
INFO - 2020-11-21 04:50:43 --> Language Class Initialized
INFO - 2020-11-21 04:50:43 --> Language Class Initialized
INFO - 2020-11-21 04:50:43 --> Config Class Initialized
INFO - 2020-11-21 04:50:43 --> Loader Class Initialized
INFO - 2020-11-21 04:50:43 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:43 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:43 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:43 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:43 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:44 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-21 04:50:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:44 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:44 --> Total execution time: 0.3990
INFO - 2020-11-21 04:50:45 --> Config Class Initialized
INFO - 2020-11-21 04:50:45 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:45 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:45 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:45 --> URI Class Initialized
INFO - 2020-11-21 04:50:45 --> Router Class Initialized
INFO - 2020-11-21 04:50:45 --> Output Class Initialized
INFO - 2020-11-21 04:50:45 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:45 --> Input Class Initialized
INFO - 2020-11-21 04:50:45 --> Language Class Initialized
INFO - 2020-11-21 04:50:45 --> Language Class Initialized
INFO - 2020-11-21 04:50:45 --> Config Class Initialized
INFO - 2020-11-21 04:50:45 --> Loader Class Initialized
INFO - 2020-11-21 04:50:45 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:45 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:45 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:45 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:45 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:45 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-21 04:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:45 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:45 --> Total execution time: 0.2609
INFO - 2020-11-21 04:50:47 --> Config Class Initialized
INFO - 2020-11-21 04:50:47 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:47 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:47 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:47 --> URI Class Initialized
INFO - 2020-11-21 04:50:47 --> Router Class Initialized
INFO - 2020-11-21 04:50:47 --> Output Class Initialized
INFO - 2020-11-21 04:50:47 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:47 --> Input Class Initialized
INFO - 2020-11-21 04:50:47 --> Language Class Initialized
INFO - 2020-11-21 04:50:47 --> Language Class Initialized
INFO - 2020-11-21 04:50:47 --> Config Class Initialized
INFO - 2020-11-21 04:50:47 --> Loader Class Initialized
INFO - 2020-11-21 04:50:47 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:47 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:47 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:47 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:47 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:47 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-21 04:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:48 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:48 --> Total execution time: 0.2899
INFO - 2020-11-21 04:50:54 --> Config Class Initialized
INFO - 2020-11-21 04:50:54 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:54 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:54 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:54 --> URI Class Initialized
INFO - 2020-11-21 04:50:54 --> Router Class Initialized
INFO - 2020-11-21 04:50:54 --> Output Class Initialized
INFO - 2020-11-21 04:50:54 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:54 --> Input Class Initialized
INFO - 2020-11-21 04:50:54 --> Language Class Initialized
INFO - 2020-11-21 04:50:54 --> Language Class Initialized
INFO - 2020-11-21 04:50:54 --> Config Class Initialized
INFO - 2020-11-21 04:50:54 --> Loader Class Initialized
INFO - 2020-11-21 04:50:54 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:54 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:54 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:54 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:54 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:54 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-11-21 04:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:54 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:54 --> Total execution time: 0.2602
INFO - 2020-11-21 04:50:55 --> Config Class Initialized
INFO - 2020-11-21 04:50:55 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:55 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:55 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:55 --> URI Class Initialized
INFO - 2020-11-21 04:50:55 --> Router Class Initialized
INFO - 2020-11-21 04:50:55 --> Output Class Initialized
INFO - 2020-11-21 04:50:55 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:55 --> Input Class Initialized
INFO - 2020-11-21 04:50:55 --> Language Class Initialized
INFO - 2020-11-21 04:50:55 --> Language Class Initialized
INFO - 2020-11-21 04:50:56 --> Config Class Initialized
INFO - 2020-11-21 04:50:56 --> Loader Class Initialized
INFO - 2020-11-21 04:50:56 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:56 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:56 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:56 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:56 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:56 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 04:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:56 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:56 --> Total execution time: 0.2454
INFO - 2020-11-21 04:50:56 --> Config Class Initialized
INFO - 2020-11-21 04:50:56 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:56 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:56 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:56 --> URI Class Initialized
INFO - 2020-11-21 04:50:57 --> Router Class Initialized
INFO - 2020-11-21 04:50:57 --> Output Class Initialized
INFO - 2020-11-21 04:50:57 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:57 --> Input Class Initialized
INFO - 2020-11-21 04:50:57 --> Language Class Initialized
INFO - 2020-11-21 04:50:57 --> Language Class Initialized
INFO - 2020-11-21 04:50:57 --> Config Class Initialized
INFO - 2020-11-21 04:50:57 --> Loader Class Initialized
INFO - 2020-11-21 04:50:57 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:57 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:57 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:57 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:57 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:57 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-21 04:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:57 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:57 --> Total execution time: 0.2798
INFO - 2020-11-21 04:50:57 --> Config Class Initialized
INFO - 2020-11-21 04:50:57 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:57 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:57 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:57 --> URI Class Initialized
INFO - 2020-11-21 04:50:57 --> Router Class Initialized
INFO - 2020-11-21 04:50:57 --> Output Class Initialized
INFO - 2020-11-21 04:50:57 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:57 --> Input Class Initialized
INFO - 2020-11-21 04:50:57 --> Language Class Initialized
INFO - 2020-11-21 04:50:57 --> Language Class Initialized
INFO - 2020-11-21 04:50:57 --> Config Class Initialized
INFO - 2020-11-21 04:50:57 --> Loader Class Initialized
INFO - 2020-11-21 04:50:57 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:57 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:57 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:57 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:57 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:57 --> Controller Class Initialized
INFO - 2020-11-21 04:50:59 --> Config Class Initialized
INFO - 2020-11-21 04:50:59 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:59 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:59 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:59 --> URI Class Initialized
INFO - 2020-11-21 04:50:59 --> Router Class Initialized
INFO - 2020-11-21 04:50:59 --> Output Class Initialized
INFO - 2020-11-21 04:50:59 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:59 --> Input Class Initialized
INFO - 2020-11-21 04:50:59 --> Language Class Initialized
INFO - 2020-11-21 04:50:59 --> Language Class Initialized
INFO - 2020-11-21 04:50:59 --> Config Class Initialized
INFO - 2020-11-21 04:50:59 --> Loader Class Initialized
INFO - 2020-11-21 04:50:59 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:59 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:59 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:59 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:59 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:59 --> Controller Class Initialized
DEBUG - 2020-11-21 04:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-21 04:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:50:59 --> Final output sent to browser
DEBUG - 2020-11-21 04:50:59 --> Total execution time: 0.2400
INFO - 2020-11-21 04:50:59 --> Config Class Initialized
INFO - 2020-11-21 04:50:59 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:50:59 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:50:59 --> Utf8 Class Initialized
INFO - 2020-11-21 04:50:59 --> URI Class Initialized
INFO - 2020-11-21 04:50:59 --> Router Class Initialized
INFO - 2020-11-21 04:50:59 --> Output Class Initialized
INFO - 2020-11-21 04:50:59 --> Security Class Initialized
DEBUG - 2020-11-21 04:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:50:59 --> Input Class Initialized
INFO - 2020-11-21 04:50:59 --> Language Class Initialized
INFO - 2020-11-21 04:50:59 --> Language Class Initialized
INFO - 2020-11-21 04:50:59 --> Config Class Initialized
INFO - 2020-11-21 04:50:59 --> Loader Class Initialized
INFO - 2020-11-21 04:50:59 --> Helper loaded: url_helper
INFO - 2020-11-21 04:50:59 --> Helper loaded: file_helper
INFO - 2020-11-21 04:50:59 --> Helper loaded: form_helper
INFO - 2020-11-21 04:50:59 --> Helper loaded: my_helper
INFO - 2020-11-21 04:50:59 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:50:59 --> Controller Class Initialized
INFO - 2020-11-21 04:51:00 --> Config Class Initialized
INFO - 2020-11-21 04:51:00 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:51:00 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:51:00 --> Utf8 Class Initialized
INFO - 2020-11-21 04:51:00 --> URI Class Initialized
INFO - 2020-11-21 04:51:00 --> Router Class Initialized
INFO - 2020-11-21 04:51:00 --> Output Class Initialized
INFO - 2020-11-21 04:51:00 --> Security Class Initialized
DEBUG - 2020-11-21 04:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:51:00 --> Input Class Initialized
INFO - 2020-11-21 04:51:00 --> Language Class Initialized
INFO - 2020-11-21 04:51:00 --> Language Class Initialized
INFO - 2020-11-21 04:51:00 --> Config Class Initialized
INFO - 2020-11-21 04:51:00 --> Loader Class Initialized
INFO - 2020-11-21 04:51:00 --> Helper loaded: url_helper
INFO - 2020-11-21 04:51:00 --> Helper loaded: file_helper
INFO - 2020-11-21 04:51:00 --> Helper loaded: form_helper
INFO - 2020-11-21 04:51:00 --> Helper loaded: my_helper
INFO - 2020-11-21 04:51:00 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:51:00 --> Controller Class Initialized
DEBUG - 2020-11-21 04:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-21 04:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:51:00 --> Final output sent to browser
DEBUG - 2020-11-21 04:51:00 --> Total execution time: 0.2455
INFO - 2020-11-21 04:51:02 --> Config Class Initialized
INFO - 2020-11-21 04:51:02 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:51:02 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:51:02 --> Utf8 Class Initialized
INFO - 2020-11-21 04:51:02 --> URI Class Initialized
INFO - 2020-11-21 04:51:02 --> Router Class Initialized
INFO - 2020-11-21 04:51:02 --> Output Class Initialized
INFO - 2020-11-21 04:51:02 --> Security Class Initialized
DEBUG - 2020-11-21 04:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:51:02 --> Input Class Initialized
INFO - 2020-11-21 04:51:02 --> Language Class Initialized
INFO - 2020-11-21 04:51:02 --> Language Class Initialized
INFO - 2020-11-21 04:51:02 --> Config Class Initialized
INFO - 2020-11-21 04:51:02 --> Loader Class Initialized
INFO - 2020-11-21 04:51:02 --> Helper loaded: url_helper
INFO - 2020-11-21 04:51:02 --> Helper loaded: file_helper
INFO - 2020-11-21 04:51:02 --> Helper loaded: form_helper
INFO - 2020-11-21 04:51:02 --> Helper loaded: my_helper
INFO - 2020-11-21 04:51:02 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:51:02 --> Controller Class Initialized
DEBUG - 2020-11-21 04:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-21 04:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:51:02 --> Final output sent to browser
DEBUG - 2020-11-21 04:51:02 --> Total execution time: 0.3010
INFO - 2020-11-21 04:51:03 --> Config Class Initialized
INFO - 2020-11-21 04:51:03 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:51:03 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:51:03 --> Utf8 Class Initialized
INFO - 2020-11-21 04:51:03 --> URI Class Initialized
INFO - 2020-11-21 04:51:03 --> Router Class Initialized
INFO - 2020-11-21 04:51:03 --> Output Class Initialized
INFO - 2020-11-21 04:51:03 --> Security Class Initialized
DEBUG - 2020-11-21 04:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:51:03 --> Input Class Initialized
INFO - 2020-11-21 04:51:03 --> Language Class Initialized
INFO - 2020-11-21 04:51:03 --> Language Class Initialized
INFO - 2020-11-21 04:51:03 --> Config Class Initialized
INFO - 2020-11-21 04:51:03 --> Loader Class Initialized
INFO - 2020-11-21 04:51:03 --> Helper loaded: url_helper
INFO - 2020-11-21 04:51:03 --> Helper loaded: file_helper
INFO - 2020-11-21 04:51:03 --> Helper loaded: form_helper
INFO - 2020-11-21 04:51:03 --> Helper loaded: my_helper
INFO - 2020-11-21 04:51:03 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:51:03 --> Controller Class Initialized
DEBUG - 2020-11-21 04:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-11-21 04:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:51:03 --> Final output sent to browser
DEBUG - 2020-11-21 04:51:03 --> Total execution time: 0.2809
INFO - 2020-11-21 04:51:24 --> Config Class Initialized
INFO - 2020-11-21 04:51:24 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:51:24 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:51:24 --> Utf8 Class Initialized
INFO - 2020-11-21 04:51:24 --> URI Class Initialized
INFO - 2020-11-21 04:51:24 --> Router Class Initialized
INFO - 2020-11-21 04:51:24 --> Output Class Initialized
INFO - 2020-11-21 04:51:24 --> Security Class Initialized
DEBUG - 2020-11-21 04:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:51:24 --> Input Class Initialized
INFO - 2020-11-21 04:51:24 --> Language Class Initialized
INFO - 2020-11-21 04:51:24 --> Language Class Initialized
INFO - 2020-11-21 04:51:24 --> Config Class Initialized
INFO - 2020-11-21 04:51:24 --> Loader Class Initialized
INFO - 2020-11-21 04:51:24 --> Helper loaded: url_helper
INFO - 2020-11-21 04:51:24 --> Helper loaded: file_helper
INFO - 2020-11-21 04:51:24 --> Helper loaded: form_helper
INFO - 2020-11-21 04:51:24 --> Helper loaded: my_helper
INFO - 2020-11-21 04:51:24 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:51:24 --> Controller Class Initialized
DEBUG - 2020-11-21 04:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 04:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:51:24 --> Final output sent to browser
DEBUG - 2020-11-21 04:51:24 --> Total execution time: 0.2659
INFO - 2020-11-21 04:51:56 --> Config Class Initialized
INFO - 2020-11-21 04:51:56 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:51:56 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:51:56 --> Utf8 Class Initialized
INFO - 2020-11-21 04:51:56 --> URI Class Initialized
INFO - 2020-11-21 04:51:56 --> Router Class Initialized
INFO - 2020-11-21 04:51:56 --> Output Class Initialized
INFO - 2020-11-21 04:51:56 --> Security Class Initialized
DEBUG - 2020-11-21 04:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:51:56 --> Input Class Initialized
INFO - 2020-11-21 04:51:56 --> Language Class Initialized
INFO - 2020-11-21 04:51:56 --> Language Class Initialized
INFO - 2020-11-21 04:51:56 --> Config Class Initialized
INFO - 2020-11-21 04:51:56 --> Loader Class Initialized
INFO - 2020-11-21 04:51:56 --> Helper loaded: url_helper
INFO - 2020-11-21 04:51:56 --> Helper loaded: file_helper
INFO - 2020-11-21 04:51:56 --> Helper loaded: form_helper
INFO - 2020-11-21 04:51:56 --> Helper loaded: my_helper
INFO - 2020-11-21 04:51:56 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:51:56 --> Controller Class Initialized
INFO - 2020-11-21 04:51:56 --> Final output sent to browser
DEBUG - 2020-11-21 04:51:56 --> Total execution time: 0.3443
INFO - 2020-11-21 04:52:32 --> Config Class Initialized
INFO - 2020-11-21 04:52:32 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:52:32 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:52:32 --> Utf8 Class Initialized
INFO - 2020-11-21 04:52:32 --> URI Class Initialized
INFO - 2020-11-21 04:52:32 --> Router Class Initialized
INFO - 2020-11-21 04:52:32 --> Output Class Initialized
INFO - 2020-11-21 04:52:32 --> Security Class Initialized
DEBUG - 2020-11-21 04:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:52:32 --> Input Class Initialized
INFO - 2020-11-21 04:52:32 --> Language Class Initialized
INFO - 2020-11-21 04:52:32 --> Language Class Initialized
INFO - 2020-11-21 04:52:32 --> Config Class Initialized
INFO - 2020-11-21 04:52:32 --> Loader Class Initialized
INFO - 2020-11-21 04:52:32 --> Helper loaded: url_helper
INFO - 2020-11-21 04:52:32 --> Helper loaded: file_helper
INFO - 2020-11-21 04:52:32 --> Helper loaded: form_helper
INFO - 2020-11-21 04:52:32 --> Helper loaded: my_helper
INFO - 2020-11-21 04:52:32 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:52:32 --> Controller Class Initialized
DEBUG - 2020-11-21 04:52:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 04:52:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 04:52:33 --> Final output sent to browser
DEBUG - 2020-11-21 04:52:33 --> Total execution time: 0.2670
INFO - 2020-11-21 04:59:20 --> Config Class Initialized
INFO - 2020-11-21 04:59:20 --> Hooks Class Initialized
DEBUG - 2020-11-21 04:59:20 --> UTF-8 Support Enabled
INFO - 2020-11-21 04:59:20 --> Utf8 Class Initialized
INFO - 2020-11-21 04:59:20 --> URI Class Initialized
INFO - 2020-11-21 04:59:20 --> Router Class Initialized
INFO - 2020-11-21 04:59:20 --> Output Class Initialized
INFO - 2020-11-21 04:59:20 --> Security Class Initialized
DEBUG - 2020-11-21 04:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 04:59:20 --> Input Class Initialized
INFO - 2020-11-21 04:59:20 --> Language Class Initialized
INFO - 2020-11-21 04:59:20 --> Language Class Initialized
INFO - 2020-11-21 04:59:20 --> Config Class Initialized
INFO - 2020-11-21 04:59:20 --> Loader Class Initialized
INFO - 2020-11-21 04:59:20 --> Helper loaded: url_helper
INFO - 2020-11-21 04:59:20 --> Helper loaded: file_helper
INFO - 2020-11-21 04:59:20 --> Helper loaded: form_helper
INFO - 2020-11-21 04:59:20 --> Helper loaded: my_helper
INFO - 2020-11-21 04:59:20 --> Database Driver Class Initialized
DEBUG - 2020-11-21 04:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 04:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 04:59:20 --> Controller Class Initialized
ERROR - 2020-11-21 04:59:20 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 118
INFO - 2020-11-21 05:00:17 --> Config Class Initialized
INFO - 2020-11-21 05:00:17 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:00:17 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:00:17 --> Utf8 Class Initialized
INFO - 2020-11-21 05:00:17 --> URI Class Initialized
INFO - 2020-11-21 05:00:17 --> Router Class Initialized
INFO - 2020-11-21 05:00:17 --> Output Class Initialized
INFO - 2020-11-21 05:00:17 --> Security Class Initialized
DEBUG - 2020-11-21 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:00:17 --> Input Class Initialized
INFO - 2020-11-21 05:00:17 --> Language Class Initialized
INFO - 2020-11-21 05:00:17 --> Language Class Initialized
INFO - 2020-11-21 05:00:17 --> Config Class Initialized
INFO - 2020-11-21 05:00:17 --> Loader Class Initialized
INFO - 2020-11-21 05:00:17 --> Helper loaded: url_helper
INFO - 2020-11-21 05:00:17 --> Helper loaded: file_helper
INFO - 2020-11-21 05:00:17 --> Helper loaded: form_helper
INFO - 2020-11-21 05:00:17 --> Helper loaded: my_helper
INFO - 2020-11-21 05:00:17 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:00:17 --> Controller Class Initialized
DEBUG - 2020-11-21 05:00:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 05:00:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:00:17 --> Final output sent to browser
DEBUG - 2020-11-21 05:00:17 --> Total execution time: 0.2600
INFO - 2020-11-21 05:00:18 --> Config Class Initialized
INFO - 2020-11-21 05:00:18 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:00:18 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:00:18 --> Utf8 Class Initialized
INFO - 2020-11-21 05:00:18 --> URI Class Initialized
INFO - 2020-11-21 05:00:18 --> Router Class Initialized
INFO - 2020-11-21 05:00:18 --> Output Class Initialized
INFO - 2020-11-21 05:00:18 --> Security Class Initialized
DEBUG - 2020-11-21 05:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:00:18 --> Input Class Initialized
INFO - 2020-11-21 05:00:18 --> Language Class Initialized
INFO - 2020-11-21 05:00:18 --> Language Class Initialized
INFO - 2020-11-21 05:00:18 --> Config Class Initialized
INFO - 2020-11-21 05:00:18 --> Loader Class Initialized
INFO - 2020-11-21 05:00:18 --> Helper loaded: url_helper
INFO - 2020-11-21 05:00:18 --> Helper loaded: file_helper
INFO - 2020-11-21 05:00:18 --> Helper loaded: form_helper
INFO - 2020-11-21 05:00:18 --> Helper loaded: my_helper
INFO - 2020-11-21 05:00:19 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:00:19 --> Controller Class Initialized
INFO - 2020-11-21 05:00:19 --> Helper loaded: cookie_helper
INFO - 2020-11-21 05:00:19 --> Config Class Initialized
INFO - 2020-11-21 05:00:19 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:00:19 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:00:19 --> Utf8 Class Initialized
INFO - 2020-11-21 05:00:19 --> URI Class Initialized
INFO - 2020-11-21 05:00:19 --> Router Class Initialized
INFO - 2020-11-21 05:00:19 --> Output Class Initialized
INFO - 2020-11-21 05:00:19 --> Security Class Initialized
DEBUG - 2020-11-21 05:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:00:19 --> Input Class Initialized
INFO - 2020-11-21 05:00:19 --> Language Class Initialized
INFO - 2020-11-21 05:00:19 --> Language Class Initialized
INFO - 2020-11-21 05:00:19 --> Config Class Initialized
INFO - 2020-11-21 05:00:19 --> Loader Class Initialized
INFO - 2020-11-21 05:00:19 --> Helper loaded: url_helper
INFO - 2020-11-21 05:00:19 --> Helper loaded: file_helper
INFO - 2020-11-21 05:00:19 --> Helper loaded: form_helper
INFO - 2020-11-21 05:00:19 --> Helper loaded: my_helper
INFO - 2020-11-21 05:00:19 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:00:19 --> Controller Class Initialized
DEBUG - 2020-11-21 05:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-21 05:00:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:00:19 --> Final output sent to browser
DEBUG - 2020-11-21 05:00:19 --> Total execution time: 0.2620
INFO - 2020-11-21 05:00:23 --> Config Class Initialized
INFO - 2020-11-21 05:00:23 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:00:23 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:00:23 --> Utf8 Class Initialized
INFO - 2020-11-21 05:00:23 --> URI Class Initialized
INFO - 2020-11-21 05:00:23 --> Router Class Initialized
INFO - 2020-11-21 05:00:23 --> Output Class Initialized
INFO - 2020-11-21 05:00:23 --> Security Class Initialized
DEBUG - 2020-11-21 05:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:00:23 --> Input Class Initialized
INFO - 2020-11-21 05:00:23 --> Language Class Initialized
INFO - 2020-11-21 05:00:23 --> Language Class Initialized
INFO - 2020-11-21 05:00:23 --> Config Class Initialized
INFO - 2020-11-21 05:00:23 --> Loader Class Initialized
INFO - 2020-11-21 05:00:23 --> Helper loaded: url_helper
INFO - 2020-11-21 05:00:23 --> Helper loaded: file_helper
INFO - 2020-11-21 05:00:23 --> Helper loaded: form_helper
INFO - 2020-11-21 05:00:23 --> Helper loaded: my_helper
INFO - 2020-11-21 05:00:23 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:00:23 --> Controller Class Initialized
INFO - 2020-11-21 05:00:23 --> Helper loaded: cookie_helper
INFO - 2020-11-21 05:00:23 --> Final output sent to browser
DEBUG - 2020-11-21 05:00:23 --> Total execution time: 0.3451
INFO - 2020-11-21 05:00:24 --> Config Class Initialized
INFO - 2020-11-21 05:00:24 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:00:24 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:00:24 --> Utf8 Class Initialized
INFO - 2020-11-21 05:00:24 --> URI Class Initialized
INFO - 2020-11-21 05:00:24 --> Router Class Initialized
INFO - 2020-11-21 05:00:24 --> Output Class Initialized
INFO - 2020-11-21 05:00:24 --> Security Class Initialized
DEBUG - 2020-11-21 05:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:00:24 --> Input Class Initialized
INFO - 2020-11-21 05:00:24 --> Language Class Initialized
INFO - 2020-11-21 05:00:24 --> Language Class Initialized
INFO - 2020-11-21 05:00:24 --> Config Class Initialized
INFO - 2020-11-21 05:00:24 --> Loader Class Initialized
INFO - 2020-11-21 05:00:24 --> Helper loaded: url_helper
INFO - 2020-11-21 05:00:24 --> Helper loaded: file_helper
INFO - 2020-11-21 05:00:24 --> Helper loaded: form_helper
INFO - 2020-11-21 05:00:24 --> Helper loaded: my_helper
INFO - 2020-11-21 05:00:24 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:00:24 --> Controller Class Initialized
DEBUG - 2020-11-21 05:00:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-21 05:00:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:00:24 --> Final output sent to browser
DEBUG - 2020-11-21 05:00:24 --> Total execution time: 0.3900
INFO - 2020-11-21 05:00:25 --> Config Class Initialized
INFO - 2020-11-21 05:00:25 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:00:25 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:00:25 --> Utf8 Class Initialized
INFO - 2020-11-21 05:00:25 --> URI Class Initialized
INFO - 2020-11-21 05:00:26 --> Router Class Initialized
INFO - 2020-11-21 05:00:26 --> Output Class Initialized
INFO - 2020-11-21 05:00:26 --> Security Class Initialized
DEBUG - 2020-11-21 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:00:26 --> Input Class Initialized
INFO - 2020-11-21 05:00:26 --> Language Class Initialized
INFO - 2020-11-21 05:00:26 --> Language Class Initialized
INFO - 2020-11-21 05:00:26 --> Config Class Initialized
INFO - 2020-11-21 05:00:26 --> Loader Class Initialized
INFO - 2020-11-21 05:00:26 --> Helper loaded: url_helper
INFO - 2020-11-21 05:00:26 --> Helper loaded: file_helper
INFO - 2020-11-21 05:00:26 --> Helper loaded: form_helper
INFO - 2020-11-21 05:00:26 --> Helper loaded: my_helper
INFO - 2020-11-21 05:00:26 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:00:26 --> Controller Class Initialized
DEBUG - 2020-11-21 05:00:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-21 05:00:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:00:26 --> Final output sent to browser
DEBUG - 2020-11-21 05:00:26 --> Total execution time: 0.3316
INFO - 2020-11-21 05:00:42 --> Config Class Initialized
INFO - 2020-11-21 05:00:42 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:00:42 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:00:42 --> Utf8 Class Initialized
INFO - 2020-11-21 05:00:42 --> URI Class Initialized
INFO - 2020-11-21 05:00:42 --> Router Class Initialized
INFO - 2020-11-21 05:00:42 --> Output Class Initialized
INFO - 2020-11-21 05:00:42 --> Security Class Initialized
DEBUG - 2020-11-21 05:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:00:42 --> Input Class Initialized
INFO - 2020-11-21 05:00:42 --> Language Class Initialized
INFO - 2020-11-21 05:00:42 --> Language Class Initialized
INFO - 2020-11-21 05:00:42 --> Config Class Initialized
INFO - 2020-11-21 05:00:42 --> Loader Class Initialized
INFO - 2020-11-21 05:00:42 --> Helper loaded: url_helper
INFO - 2020-11-21 05:00:42 --> Helper loaded: file_helper
INFO - 2020-11-21 05:00:42 --> Helper loaded: form_helper
INFO - 2020-11-21 05:00:42 --> Helper loaded: my_helper
INFO - 2020-11-21 05:00:42 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:00:42 --> Controller Class Initialized
DEBUG - 2020-11-21 05:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-21 05:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:00:42 --> Final output sent to browser
DEBUG - 2020-11-21 05:00:42 --> Total execution time: 0.3044
INFO - 2020-11-21 05:00:43 --> Config Class Initialized
INFO - 2020-11-21 05:00:43 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:00:43 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:00:43 --> Utf8 Class Initialized
INFO - 2020-11-21 05:00:43 --> URI Class Initialized
INFO - 2020-11-21 05:00:43 --> Router Class Initialized
INFO - 2020-11-21 05:00:43 --> Output Class Initialized
INFO - 2020-11-21 05:00:43 --> Security Class Initialized
DEBUG - 2020-11-21 05:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:00:43 --> Input Class Initialized
INFO - 2020-11-21 05:00:43 --> Language Class Initialized
INFO - 2020-11-21 05:00:43 --> Language Class Initialized
INFO - 2020-11-21 05:00:43 --> Config Class Initialized
INFO - 2020-11-21 05:00:43 --> Loader Class Initialized
INFO - 2020-11-21 05:00:43 --> Helper loaded: url_helper
INFO - 2020-11-21 05:00:43 --> Helper loaded: file_helper
INFO - 2020-11-21 05:00:43 --> Helper loaded: form_helper
INFO - 2020-11-21 05:00:43 --> Helper loaded: my_helper
INFO - 2020-11-21 05:00:43 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:00:43 --> Controller Class Initialized
INFO - 2020-11-21 05:00:48 --> Config Class Initialized
INFO - 2020-11-21 05:00:48 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:00:48 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:00:48 --> Utf8 Class Initialized
INFO - 2020-11-21 05:00:48 --> URI Class Initialized
INFO - 2020-11-21 05:00:48 --> Router Class Initialized
INFO - 2020-11-21 05:00:48 --> Output Class Initialized
INFO - 2020-11-21 05:00:48 --> Security Class Initialized
DEBUG - 2020-11-21 05:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:00:48 --> Input Class Initialized
INFO - 2020-11-21 05:00:48 --> Language Class Initialized
INFO - 2020-11-21 05:00:48 --> Language Class Initialized
INFO - 2020-11-21 05:00:48 --> Config Class Initialized
INFO - 2020-11-21 05:00:48 --> Loader Class Initialized
INFO - 2020-11-21 05:00:48 --> Helper loaded: url_helper
INFO - 2020-11-21 05:00:48 --> Helper loaded: file_helper
INFO - 2020-11-21 05:00:48 --> Helper loaded: form_helper
INFO - 2020-11-21 05:00:48 --> Helper loaded: my_helper
INFO - 2020-11-21 05:00:48 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:00:48 --> Controller Class Initialized
INFO - 2020-11-21 05:00:48 --> Final output sent to browser
DEBUG - 2020-11-21 05:00:48 --> Total execution time: 0.2255
INFO - 2020-11-21 05:01:04 --> Config Class Initialized
INFO - 2020-11-21 05:01:04 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:01:04 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:01:04 --> Utf8 Class Initialized
INFO - 2020-11-21 05:01:04 --> URI Class Initialized
INFO - 2020-11-21 05:01:04 --> Router Class Initialized
INFO - 2020-11-21 05:01:04 --> Output Class Initialized
INFO - 2020-11-21 05:01:04 --> Security Class Initialized
DEBUG - 2020-11-21 05:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:01:04 --> Input Class Initialized
INFO - 2020-11-21 05:01:04 --> Language Class Initialized
INFO - 2020-11-21 05:01:04 --> Language Class Initialized
INFO - 2020-11-21 05:01:04 --> Config Class Initialized
INFO - 2020-11-21 05:01:04 --> Loader Class Initialized
INFO - 2020-11-21 05:01:04 --> Helper loaded: url_helper
INFO - 2020-11-21 05:01:04 --> Helper loaded: file_helper
INFO - 2020-11-21 05:01:04 --> Helper loaded: form_helper
INFO - 2020-11-21 05:01:04 --> Helper loaded: my_helper
INFO - 2020-11-21 05:01:04 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:01:04 --> Controller Class Initialized
DEBUG - 2020-11-21 05:01:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-21 05:01:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:01:05 --> Final output sent to browser
DEBUG - 2020-11-21 05:01:05 --> Total execution time: 0.2844
INFO - 2020-11-21 05:01:25 --> Config Class Initialized
INFO - 2020-11-21 05:01:25 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:01:25 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:01:25 --> Utf8 Class Initialized
INFO - 2020-11-21 05:01:25 --> URI Class Initialized
INFO - 2020-11-21 05:01:25 --> Router Class Initialized
INFO - 2020-11-21 05:01:25 --> Output Class Initialized
INFO - 2020-11-21 05:01:25 --> Security Class Initialized
DEBUG - 2020-11-21 05:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:01:25 --> Input Class Initialized
INFO - 2020-11-21 05:01:25 --> Language Class Initialized
INFO - 2020-11-21 05:01:25 --> Language Class Initialized
INFO - 2020-11-21 05:01:25 --> Config Class Initialized
INFO - 2020-11-21 05:01:25 --> Loader Class Initialized
INFO - 2020-11-21 05:01:25 --> Helper loaded: url_helper
INFO - 2020-11-21 05:01:25 --> Helper loaded: file_helper
INFO - 2020-11-21 05:01:25 --> Helper loaded: form_helper
INFO - 2020-11-21 05:01:25 --> Helper loaded: my_helper
INFO - 2020-11-21 05:01:25 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:01:25 --> Controller Class Initialized
DEBUG - 2020-11-21 05:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-21 05:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:01:25 --> Final output sent to browser
DEBUG - 2020-11-21 05:01:25 --> Total execution time: 0.2759
INFO - 2020-11-21 05:01:25 --> Config Class Initialized
INFO - 2020-11-21 05:01:25 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:01:25 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:01:25 --> Utf8 Class Initialized
INFO - 2020-11-21 05:01:25 --> URI Class Initialized
INFO - 2020-11-21 05:01:25 --> Router Class Initialized
INFO - 2020-11-21 05:01:25 --> Output Class Initialized
INFO - 2020-11-21 05:01:25 --> Security Class Initialized
DEBUG - 2020-11-21 05:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:01:25 --> Input Class Initialized
INFO - 2020-11-21 05:01:25 --> Language Class Initialized
INFO - 2020-11-21 05:01:25 --> Language Class Initialized
INFO - 2020-11-21 05:01:25 --> Config Class Initialized
INFO - 2020-11-21 05:01:25 --> Loader Class Initialized
INFO - 2020-11-21 05:01:25 --> Helper loaded: url_helper
INFO - 2020-11-21 05:01:25 --> Helper loaded: file_helper
INFO - 2020-11-21 05:01:25 --> Helper loaded: form_helper
INFO - 2020-11-21 05:01:25 --> Helper loaded: my_helper
INFO - 2020-11-21 05:01:25 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:01:25 --> Controller Class Initialized
INFO - 2020-11-21 05:15:08 --> Config Class Initialized
INFO - 2020-11-21 05:15:08 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:15:08 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:15:08 --> Utf8 Class Initialized
INFO - 2020-11-21 05:15:08 --> URI Class Initialized
INFO - 2020-11-21 05:15:08 --> Router Class Initialized
INFO - 2020-11-21 05:15:08 --> Output Class Initialized
INFO - 2020-11-21 05:15:08 --> Security Class Initialized
DEBUG - 2020-11-21 05:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:15:08 --> Input Class Initialized
INFO - 2020-11-21 05:15:08 --> Language Class Initialized
INFO - 2020-11-21 05:15:08 --> Language Class Initialized
INFO - 2020-11-21 05:15:08 --> Config Class Initialized
INFO - 2020-11-21 05:15:09 --> Loader Class Initialized
INFO - 2020-11-21 05:15:09 --> Helper loaded: url_helper
INFO - 2020-11-21 05:15:09 --> Helper loaded: file_helper
INFO - 2020-11-21 05:15:09 --> Helper loaded: form_helper
INFO - 2020-11-21 05:15:09 --> Helper loaded: my_helper
INFO - 2020-11-21 05:15:09 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:15:09 --> Controller Class Initialized
INFO - 2020-11-21 05:15:09 --> Helper loaded: cookie_helper
INFO - 2020-11-21 05:15:09 --> Config Class Initialized
INFO - 2020-11-21 05:15:09 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:15:09 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:15:09 --> Utf8 Class Initialized
INFO - 2020-11-21 05:15:09 --> URI Class Initialized
INFO - 2020-11-21 05:15:09 --> Router Class Initialized
INFO - 2020-11-21 05:15:09 --> Output Class Initialized
INFO - 2020-11-21 05:15:09 --> Security Class Initialized
DEBUG - 2020-11-21 05:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:15:09 --> Input Class Initialized
INFO - 2020-11-21 05:15:09 --> Language Class Initialized
INFO - 2020-11-21 05:15:09 --> Language Class Initialized
INFO - 2020-11-21 05:15:09 --> Config Class Initialized
INFO - 2020-11-21 05:15:09 --> Loader Class Initialized
INFO - 2020-11-21 05:15:09 --> Helper loaded: url_helper
INFO - 2020-11-21 05:15:09 --> Helper loaded: file_helper
INFO - 2020-11-21 05:15:09 --> Helper loaded: form_helper
INFO - 2020-11-21 05:15:09 --> Helper loaded: my_helper
INFO - 2020-11-21 05:15:09 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:15:09 --> Controller Class Initialized
DEBUG - 2020-11-21 05:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-21 05:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:15:09 --> Final output sent to browser
DEBUG - 2020-11-21 05:15:09 --> Total execution time: 0.2721
INFO - 2020-11-21 05:15:18 --> Config Class Initialized
INFO - 2020-11-21 05:15:18 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:15:18 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:15:18 --> Utf8 Class Initialized
INFO - 2020-11-21 05:15:18 --> URI Class Initialized
INFO - 2020-11-21 05:15:18 --> Router Class Initialized
INFO - 2020-11-21 05:15:18 --> Output Class Initialized
INFO - 2020-11-21 05:15:18 --> Security Class Initialized
DEBUG - 2020-11-21 05:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:15:18 --> Input Class Initialized
INFO - 2020-11-21 05:15:18 --> Language Class Initialized
INFO - 2020-11-21 05:15:18 --> Language Class Initialized
INFO - 2020-11-21 05:15:18 --> Config Class Initialized
INFO - 2020-11-21 05:15:18 --> Loader Class Initialized
INFO - 2020-11-21 05:15:18 --> Helper loaded: url_helper
INFO - 2020-11-21 05:15:18 --> Helper loaded: file_helper
INFO - 2020-11-21 05:15:18 --> Helper loaded: form_helper
INFO - 2020-11-21 05:15:18 --> Helper loaded: my_helper
INFO - 2020-11-21 05:15:18 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:15:18 --> Controller Class Initialized
INFO - 2020-11-21 05:15:18 --> Helper loaded: cookie_helper
INFO - 2020-11-21 05:15:18 --> Final output sent to browser
DEBUG - 2020-11-21 05:15:18 --> Total execution time: 0.3332
INFO - 2020-11-21 05:15:19 --> Config Class Initialized
INFO - 2020-11-21 05:15:19 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:15:19 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:15:19 --> Utf8 Class Initialized
INFO - 2020-11-21 05:15:19 --> URI Class Initialized
INFO - 2020-11-21 05:15:19 --> Router Class Initialized
INFO - 2020-11-21 05:15:19 --> Output Class Initialized
INFO - 2020-11-21 05:15:19 --> Security Class Initialized
DEBUG - 2020-11-21 05:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:15:19 --> Input Class Initialized
INFO - 2020-11-21 05:15:19 --> Language Class Initialized
INFO - 2020-11-21 05:15:19 --> Language Class Initialized
INFO - 2020-11-21 05:15:19 --> Config Class Initialized
INFO - 2020-11-21 05:15:19 --> Loader Class Initialized
INFO - 2020-11-21 05:15:19 --> Helper loaded: url_helper
INFO - 2020-11-21 05:15:19 --> Helper loaded: file_helper
INFO - 2020-11-21 05:15:19 --> Helper loaded: form_helper
INFO - 2020-11-21 05:15:19 --> Helper loaded: my_helper
INFO - 2020-11-21 05:15:19 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:15:19 --> Controller Class Initialized
DEBUG - 2020-11-21 05:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-21 05:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:15:19 --> Final output sent to browser
DEBUG - 2020-11-21 05:15:19 --> Total execution time: 0.3472
INFO - 2020-11-21 05:15:22 --> Config Class Initialized
INFO - 2020-11-21 05:15:22 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:15:22 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:15:22 --> Utf8 Class Initialized
INFO - 2020-11-21 05:15:22 --> URI Class Initialized
INFO - 2020-11-21 05:15:22 --> Router Class Initialized
INFO - 2020-11-21 05:15:22 --> Output Class Initialized
INFO - 2020-11-21 05:15:22 --> Security Class Initialized
DEBUG - 2020-11-21 05:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:15:22 --> Input Class Initialized
INFO - 2020-11-21 05:15:22 --> Language Class Initialized
INFO - 2020-11-21 05:15:22 --> Language Class Initialized
INFO - 2020-11-21 05:15:22 --> Config Class Initialized
INFO - 2020-11-21 05:15:22 --> Loader Class Initialized
INFO - 2020-11-21 05:15:22 --> Helper loaded: url_helper
INFO - 2020-11-21 05:15:22 --> Helper loaded: file_helper
INFO - 2020-11-21 05:15:22 --> Helper loaded: form_helper
INFO - 2020-11-21 05:15:22 --> Helper loaded: my_helper
INFO - 2020-11-21 05:15:22 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:15:22 --> Controller Class Initialized
DEBUG - 2020-11-21 05:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 05:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:15:22 --> Final output sent to browser
DEBUG - 2020-11-21 05:15:22 --> Total execution time: 0.2898
INFO - 2020-11-21 05:15:26 --> Config Class Initialized
INFO - 2020-11-21 05:15:26 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:15:26 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:15:26 --> Utf8 Class Initialized
INFO - 2020-11-21 05:15:26 --> URI Class Initialized
INFO - 2020-11-21 05:15:26 --> Router Class Initialized
INFO - 2020-11-21 05:15:26 --> Output Class Initialized
INFO - 2020-11-21 05:15:26 --> Security Class Initialized
DEBUG - 2020-11-21 05:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:15:26 --> Input Class Initialized
INFO - 2020-11-21 05:15:26 --> Language Class Initialized
INFO - 2020-11-21 05:15:26 --> Language Class Initialized
INFO - 2020-11-21 05:15:26 --> Config Class Initialized
INFO - 2020-11-21 05:15:26 --> Loader Class Initialized
INFO - 2020-11-21 05:15:26 --> Helper loaded: url_helper
INFO - 2020-11-21 05:15:26 --> Helper loaded: file_helper
INFO - 2020-11-21 05:15:26 --> Helper loaded: form_helper
INFO - 2020-11-21 05:15:26 --> Helper loaded: my_helper
INFO - 2020-11-21 05:15:26 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:15:26 --> Controller Class Initialized
INFO - 2020-11-21 05:15:26 --> Final output sent to browser
DEBUG - 2020-11-21 05:15:26 --> Total execution time: 0.2104
INFO - 2020-11-21 05:17:20 --> Config Class Initialized
INFO - 2020-11-21 05:17:20 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:17:20 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:17:20 --> Utf8 Class Initialized
INFO - 2020-11-21 05:17:20 --> URI Class Initialized
INFO - 2020-11-21 05:17:20 --> Router Class Initialized
INFO - 2020-11-21 05:17:20 --> Output Class Initialized
INFO - 2020-11-21 05:17:20 --> Security Class Initialized
DEBUG - 2020-11-21 05:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:17:20 --> Input Class Initialized
INFO - 2020-11-21 05:17:20 --> Language Class Initialized
INFO - 2020-11-21 05:17:20 --> Language Class Initialized
INFO - 2020-11-21 05:17:20 --> Config Class Initialized
INFO - 2020-11-21 05:17:20 --> Loader Class Initialized
INFO - 2020-11-21 05:17:20 --> Helper loaded: url_helper
INFO - 2020-11-21 05:17:20 --> Helper loaded: file_helper
INFO - 2020-11-21 05:17:20 --> Helper loaded: form_helper
INFO - 2020-11-21 05:17:20 --> Helper loaded: my_helper
INFO - 2020-11-21 05:17:20 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:17:20 --> Controller Class Initialized
DEBUG - 2020-11-21 05:17:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 05:17:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:17:20 --> Final output sent to browser
DEBUG - 2020-11-21 05:17:20 --> Total execution time: 0.3062
INFO - 2020-11-21 05:17:27 --> Config Class Initialized
INFO - 2020-11-21 05:17:27 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:17:27 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:17:28 --> Utf8 Class Initialized
INFO - 2020-11-21 05:17:28 --> URI Class Initialized
INFO - 2020-11-21 05:17:28 --> Router Class Initialized
INFO - 2020-11-21 05:17:28 --> Output Class Initialized
INFO - 2020-11-21 05:17:28 --> Security Class Initialized
DEBUG - 2020-11-21 05:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:17:28 --> Input Class Initialized
INFO - 2020-11-21 05:17:28 --> Language Class Initialized
INFO - 2020-11-21 05:17:28 --> Language Class Initialized
INFO - 2020-11-21 05:17:28 --> Config Class Initialized
INFO - 2020-11-21 05:17:28 --> Loader Class Initialized
INFO - 2020-11-21 05:17:28 --> Helper loaded: url_helper
INFO - 2020-11-21 05:17:28 --> Helper loaded: file_helper
INFO - 2020-11-21 05:17:28 --> Helper loaded: form_helper
INFO - 2020-11-21 05:17:28 --> Helper loaded: my_helper
INFO - 2020-11-21 05:17:28 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:17:28 --> Controller Class Initialized
DEBUG - 2020-11-21 05:17:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 05:17:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:17:28 --> Final output sent to browser
DEBUG - 2020-11-21 05:17:28 --> Total execution time: 0.3084
INFO - 2020-11-21 05:17:29 --> Config Class Initialized
INFO - 2020-11-21 05:17:29 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:17:29 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:17:29 --> Utf8 Class Initialized
INFO - 2020-11-21 05:17:29 --> URI Class Initialized
INFO - 2020-11-21 05:17:29 --> Router Class Initialized
INFO - 2020-11-21 05:17:29 --> Output Class Initialized
INFO - 2020-11-21 05:17:29 --> Security Class Initialized
DEBUG - 2020-11-21 05:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:17:29 --> Input Class Initialized
INFO - 2020-11-21 05:17:29 --> Language Class Initialized
INFO - 2020-11-21 05:17:29 --> Language Class Initialized
INFO - 2020-11-21 05:17:29 --> Config Class Initialized
INFO - 2020-11-21 05:17:29 --> Loader Class Initialized
INFO - 2020-11-21 05:17:29 --> Helper loaded: url_helper
INFO - 2020-11-21 05:17:29 --> Helper loaded: file_helper
INFO - 2020-11-21 05:17:29 --> Helper loaded: form_helper
INFO - 2020-11-21 05:17:29 --> Helper loaded: my_helper
INFO - 2020-11-21 05:17:29 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:17:29 --> Controller Class Initialized
INFO - 2020-11-21 05:17:29 --> Final output sent to browser
DEBUG - 2020-11-21 05:17:29 --> Total execution time: 0.2248
INFO - 2020-11-21 05:21:06 --> Config Class Initialized
INFO - 2020-11-21 05:21:06 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:21:06 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:21:06 --> Utf8 Class Initialized
INFO - 2020-11-21 05:21:06 --> URI Class Initialized
INFO - 2020-11-21 05:21:06 --> Router Class Initialized
INFO - 2020-11-21 05:21:06 --> Output Class Initialized
INFO - 2020-11-21 05:21:06 --> Security Class Initialized
DEBUG - 2020-11-21 05:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:21:06 --> Input Class Initialized
INFO - 2020-11-21 05:21:06 --> Language Class Initialized
INFO - 2020-11-21 05:21:06 --> Language Class Initialized
INFO - 2020-11-21 05:21:06 --> Config Class Initialized
INFO - 2020-11-21 05:21:06 --> Loader Class Initialized
INFO - 2020-11-21 05:21:07 --> Helper loaded: url_helper
INFO - 2020-11-21 05:21:07 --> Helper loaded: file_helper
INFO - 2020-11-21 05:21:07 --> Helper loaded: form_helper
INFO - 2020-11-21 05:21:07 --> Helper loaded: my_helper
INFO - 2020-11-21 05:21:07 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:21:07 --> Controller Class Initialized
DEBUG - 2020-11-21 05:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-21 05:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:21:07 --> Final output sent to browser
DEBUG - 2020-11-21 05:21:07 --> Total execution time: 0.3222
INFO - 2020-11-21 05:21:07 --> Config Class Initialized
INFO - 2020-11-21 05:21:07 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:21:07 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:21:07 --> Utf8 Class Initialized
INFO - 2020-11-21 05:21:07 --> URI Class Initialized
INFO - 2020-11-21 05:21:07 --> Router Class Initialized
INFO - 2020-11-21 05:21:07 --> Output Class Initialized
INFO - 2020-11-21 05:21:07 --> Security Class Initialized
DEBUG - 2020-11-21 05:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:21:07 --> Input Class Initialized
INFO - 2020-11-21 05:21:07 --> Language Class Initialized
INFO - 2020-11-21 05:21:07 --> Language Class Initialized
INFO - 2020-11-21 05:21:07 --> Config Class Initialized
INFO - 2020-11-21 05:21:07 --> Loader Class Initialized
INFO - 2020-11-21 05:21:07 --> Helper loaded: url_helper
INFO - 2020-11-21 05:21:07 --> Helper loaded: file_helper
INFO - 2020-11-21 05:21:07 --> Helper loaded: form_helper
INFO - 2020-11-21 05:21:07 --> Helper loaded: my_helper
INFO - 2020-11-21 05:21:07 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:21:07 --> Controller Class Initialized
INFO - 2020-11-21 05:21:08 --> Config Class Initialized
INFO - 2020-11-21 05:21:08 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:21:08 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:21:08 --> Utf8 Class Initialized
INFO - 2020-11-21 05:21:08 --> URI Class Initialized
INFO - 2020-11-21 05:21:08 --> Router Class Initialized
INFO - 2020-11-21 05:21:08 --> Output Class Initialized
INFO - 2020-11-21 05:21:08 --> Security Class Initialized
DEBUG - 2020-11-21 05:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:21:08 --> Input Class Initialized
INFO - 2020-11-21 05:21:08 --> Language Class Initialized
INFO - 2020-11-21 05:21:08 --> Language Class Initialized
INFO - 2020-11-21 05:21:08 --> Config Class Initialized
INFO - 2020-11-21 05:21:08 --> Loader Class Initialized
INFO - 2020-11-21 05:21:08 --> Helper loaded: url_helper
INFO - 2020-11-21 05:21:08 --> Helper loaded: file_helper
INFO - 2020-11-21 05:21:08 --> Helper loaded: form_helper
INFO - 2020-11-21 05:21:08 --> Helper loaded: my_helper
INFO - 2020-11-21 05:21:08 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:21:08 --> Controller Class Initialized
DEBUG - 2020-11-21 05:21:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-21 05:21:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:21:08 --> Final output sent to browser
DEBUG - 2020-11-21 05:21:08 --> Total execution time: 0.2984
INFO - 2020-11-21 05:23:38 --> Config Class Initialized
INFO - 2020-11-21 05:23:38 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:23:38 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:23:38 --> Utf8 Class Initialized
INFO - 2020-11-21 05:23:38 --> URI Class Initialized
INFO - 2020-11-21 05:23:38 --> Router Class Initialized
INFO - 2020-11-21 05:23:38 --> Output Class Initialized
INFO - 2020-11-21 05:23:38 --> Security Class Initialized
DEBUG - 2020-11-21 05:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:23:38 --> Input Class Initialized
INFO - 2020-11-21 05:23:38 --> Language Class Initialized
INFO - 2020-11-21 05:23:38 --> Language Class Initialized
INFO - 2020-11-21 05:23:38 --> Config Class Initialized
INFO - 2020-11-21 05:23:38 --> Loader Class Initialized
INFO - 2020-11-21 05:23:38 --> Helper loaded: url_helper
INFO - 2020-11-21 05:23:38 --> Helper loaded: file_helper
INFO - 2020-11-21 05:23:38 --> Helper loaded: form_helper
INFO - 2020-11-21 05:23:38 --> Helper loaded: my_helper
INFO - 2020-11-21 05:23:38 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:23:38 --> Controller Class Initialized
DEBUG - 2020-11-21 05:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 05:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:23:38 --> Final output sent to browser
DEBUG - 2020-11-21 05:23:38 --> Total execution time: 0.2596
INFO - 2020-11-21 05:23:39 --> Config Class Initialized
INFO - 2020-11-21 05:23:39 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:23:39 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:23:39 --> Utf8 Class Initialized
INFO - 2020-11-21 05:23:39 --> URI Class Initialized
INFO - 2020-11-21 05:23:39 --> Router Class Initialized
INFO - 2020-11-21 05:23:39 --> Output Class Initialized
INFO - 2020-11-21 05:23:39 --> Security Class Initialized
DEBUG - 2020-11-21 05:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:23:39 --> Input Class Initialized
INFO - 2020-11-21 05:23:39 --> Language Class Initialized
INFO - 2020-11-21 05:23:39 --> Language Class Initialized
INFO - 2020-11-21 05:23:39 --> Config Class Initialized
INFO - 2020-11-21 05:23:39 --> Loader Class Initialized
INFO - 2020-11-21 05:23:39 --> Helper loaded: url_helper
INFO - 2020-11-21 05:23:39 --> Helper loaded: file_helper
INFO - 2020-11-21 05:23:39 --> Helper loaded: form_helper
INFO - 2020-11-21 05:23:39 --> Helper loaded: my_helper
INFO - 2020-11-21 05:23:39 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:23:39 --> Controller Class Initialized
DEBUG - 2020-11-21 05:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 05:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:23:39 --> Final output sent to browser
DEBUG - 2020-11-21 05:23:39 --> Total execution time: 0.2548
INFO - 2020-11-21 05:23:41 --> Config Class Initialized
INFO - 2020-11-21 05:23:41 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:23:41 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:23:41 --> Utf8 Class Initialized
INFO - 2020-11-21 05:23:41 --> URI Class Initialized
INFO - 2020-11-21 05:23:41 --> Router Class Initialized
INFO - 2020-11-21 05:23:41 --> Output Class Initialized
INFO - 2020-11-21 05:23:41 --> Security Class Initialized
DEBUG - 2020-11-21 05:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:23:41 --> Input Class Initialized
INFO - 2020-11-21 05:23:41 --> Language Class Initialized
INFO - 2020-11-21 05:23:41 --> Language Class Initialized
INFO - 2020-11-21 05:23:41 --> Config Class Initialized
INFO - 2020-11-21 05:23:41 --> Loader Class Initialized
INFO - 2020-11-21 05:23:41 --> Helper loaded: url_helper
INFO - 2020-11-21 05:23:41 --> Helper loaded: file_helper
INFO - 2020-11-21 05:23:41 --> Helper loaded: form_helper
INFO - 2020-11-21 05:23:41 --> Helper loaded: my_helper
INFO - 2020-11-21 05:23:41 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:23:41 --> Controller Class Initialized
INFO - 2020-11-21 05:23:41 --> Final output sent to browser
DEBUG - 2020-11-21 05:23:41 --> Total execution time: 0.2220
INFO - 2020-11-21 05:23:48 --> Config Class Initialized
INFO - 2020-11-21 05:23:48 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:23:48 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:23:48 --> Utf8 Class Initialized
INFO - 2020-11-21 05:23:48 --> URI Class Initialized
INFO - 2020-11-21 05:23:48 --> Router Class Initialized
INFO - 2020-11-21 05:23:48 --> Output Class Initialized
INFO - 2020-11-21 05:23:48 --> Security Class Initialized
DEBUG - 2020-11-21 05:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:23:48 --> Input Class Initialized
INFO - 2020-11-21 05:23:48 --> Language Class Initialized
INFO - 2020-11-21 05:23:48 --> Language Class Initialized
INFO - 2020-11-21 05:23:48 --> Config Class Initialized
INFO - 2020-11-21 05:23:48 --> Loader Class Initialized
INFO - 2020-11-21 05:23:48 --> Helper loaded: url_helper
INFO - 2020-11-21 05:23:48 --> Helper loaded: file_helper
INFO - 2020-11-21 05:23:48 --> Helper loaded: form_helper
INFO - 2020-11-21 05:23:48 --> Helper loaded: my_helper
INFO - 2020-11-21 05:23:48 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:23:48 --> Controller Class Initialized
DEBUG - 2020-11-21 05:23:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-21 05:23:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:23:48 --> Final output sent to browser
DEBUG - 2020-11-21 05:23:48 --> Total execution time: 0.3021
INFO - 2020-11-21 05:24:26 --> Config Class Initialized
INFO - 2020-11-21 05:24:26 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:24:26 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:24:26 --> Utf8 Class Initialized
INFO - 2020-11-21 05:24:26 --> URI Class Initialized
INFO - 2020-11-21 05:24:26 --> Router Class Initialized
INFO - 2020-11-21 05:24:26 --> Output Class Initialized
INFO - 2020-11-21 05:24:26 --> Security Class Initialized
DEBUG - 2020-11-21 05:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:24:26 --> Input Class Initialized
INFO - 2020-11-21 05:24:26 --> Language Class Initialized
INFO - 2020-11-21 05:24:26 --> Language Class Initialized
INFO - 2020-11-21 05:24:26 --> Config Class Initialized
INFO - 2020-11-21 05:24:26 --> Loader Class Initialized
INFO - 2020-11-21 05:24:26 --> Helper loaded: url_helper
INFO - 2020-11-21 05:24:26 --> Helper loaded: file_helper
INFO - 2020-11-21 05:24:26 --> Helper loaded: form_helper
INFO - 2020-11-21 05:24:26 --> Helper loaded: my_helper
INFO - 2020-11-21 05:24:26 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:24:26 --> Controller Class Initialized
DEBUG - 2020-11-21 05:24:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-21 05:24:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:24:26 --> Final output sent to browser
DEBUG - 2020-11-21 05:24:26 --> Total execution time: 0.2934
INFO - 2020-11-21 05:24:27 --> Config Class Initialized
INFO - 2020-11-21 05:24:27 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:24:27 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:24:27 --> Utf8 Class Initialized
INFO - 2020-11-21 05:24:27 --> URI Class Initialized
INFO - 2020-11-21 05:24:27 --> Router Class Initialized
INFO - 2020-11-21 05:24:27 --> Output Class Initialized
INFO - 2020-11-21 05:24:27 --> Security Class Initialized
DEBUG - 2020-11-21 05:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:24:27 --> Input Class Initialized
INFO - 2020-11-21 05:24:27 --> Language Class Initialized
INFO - 2020-11-21 05:24:27 --> Language Class Initialized
INFO - 2020-11-21 05:24:27 --> Config Class Initialized
INFO - 2020-11-21 05:24:27 --> Loader Class Initialized
INFO - 2020-11-21 05:24:27 --> Helper loaded: url_helper
INFO - 2020-11-21 05:24:27 --> Helper loaded: file_helper
INFO - 2020-11-21 05:24:27 --> Helper loaded: form_helper
INFO - 2020-11-21 05:24:27 --> Helper loaded: my_helper
INFO - 2020-11-21 05:24:27 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:24:27 --> Controller Class Initialized
INFO - 2020-11-21 05:24:27 --> Final output sent to browser
DEBUG - 2020-11-21 05:24:28 --> Total execution time: 0.2244
INFO - 2020-11-21 05:25:05 --> Config Class Initialized
INFO - 2020-11-21 05:25:05 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:25:05 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:25:05 --> Utf8 Class Initialized
INFO - 2020-11-21 05:25:05 --> URI Class Initialized
INFO - 2020-11-21 05:25:05 --> Router Class Initialized
INFO - 2020-11-21 05:25:06 --> Output Class Initialized
INFO - 2020-11-21 05:25:06 --> Security Class Initialized
DEBUG - 2020-11-21 05:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:25:06 --> Input Class Initialized
INFO - 2020-11-21 05:25:06 --> Language Class Initialized
INFO - 2020-11-21 05:25:06 --> Language Class Initialized
INFO - 2020-11-21 05:25:06 --> Config Class Initialized
INFO - 2020-11-21 05:25:06 --> Loader Class Initialized
INFO - 2020-11-21 05:25:06 --> Helper loaded: url_helper
INFO - 2020-11-21 05:25:06 --> Helper loaded: file_helper
INFO - 2020-11-21 05:25:06 --> Helper loaded: form_helper
INFO - 2020-11-21 05:25:06 --> Helper loaded: my_helper
INFO - 2020-11-21 05:25:06 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:25:06 --> Controller Class Initialized
DEBUG - 2020-11-21 05:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 05:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:25:06 --> Final output sent to browser
DEBUG - 2020-11-21 05:25:06 --> Total execution time: 0.2877
INFO - 2020-11-21 05:25:47 --> Config Class Initialized
INFO - 2020-11-21 05:25:47 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:25:47 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:25:47 --> Utf8 Class Initialized
INFO - 2020-11-21 05:25:47 --> URI Class Initialized
INFO - 2020-11-21 05:25:47 --> Router Class Initialized
INFO - 2020-11-21 05:25:47 --> Output Class Initialized
INFO - 2020-11-21 05:25:47 --> Security Class Initialized
DEBUG - 2020-11-21 05:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:25:47 --> Input Class Initialized
INFO - 2020-11-21 05:25:47 --> Language Class Initialized
INFO - 2020-11-21 05:25:48 --> Language Class Initialized
INFO - 2020-11-21 05:25:48 --> Config Class Initialized
INFO - 2020-11-21 05:25:48 --> Loader Class Initialized
INFO - 2020-11-21 05:25:48 --> Helper loaded: url_helper
INFO - 2020-11-21 05:25:48 --> Helper loaded: file_helper
INFO - 2020-11-21 05:25:48 --> Helper loaded: form_helper
INFO - 2020-11-21 05:25:48 --> Helper loaded: my_helper
INFO - 2020-11-21 05:25:48 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:25:48 --> Controller Class Initialized
DEBUG - 2020-11-21 05:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 05:25:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:25:48 --> Final output sent to browser
DEBUG - 2020-11-21 05:25:48 --> Total execution time: 0.2651
INFO - 2020-11-21 05:26:25 --> Config Class Initialized
INFO - 2020-11-21 05:26:25 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:26:25 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:26:25 --> Utf8 Class Initialized
INFO - 2020-11-21 05:26:25 --> URI Class Initialized
INFO - 2020-11-21 05:26:25 --> Router Class Initialized
INFO - 2020-11-21 05:26:25 --> Output Class Initialized
INFO - 2020-11-21 05:26:25 --> Security Class Initialized
DEBUG - 2020-11-21 05:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:26:25 --> Input Class Initialized
INFO - 2020-11-21 05:26:25 --> Language Class Initialized
INFO - 2020-11-21 05:26:25 --> Language Class Initialized
INFO - 2020-11-21 05:26:25 --> Config Class Initialized
INFO - 2020-11-21 05:26:25 --> Loader Class Initialized
INFO - 2020-11-21 05:26:25 --> Helper loaded: url_helper
INFO - 2020-11-21 05:26:25 --> Helper loaded: file_helper
INFO - 2020-11-21 05:26:25 --> Helper loaded: form_helper
INFO - 2020-11-21 05:26:25 --> Helper loaded: my_helper
INFO - 2020-11-21 05:26:25 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:26:25 --> Controller Class Initialized
DEBUG - 2020-11-21 05:26:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 05:26:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:26:25 --> Final output sent to browser
DEBUG - 2020-11-21 05:26:25 --> Total execution time: 0.2796
INFO - 2020-11-21 05:29:00 --> Config Class Initialized
INFO - 2020-11-21 05:29:00 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:29:00 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:29:00 --> Utf8 Class Initialized
INFO - 2020-11-21 05:29:00 --> URI Class Initialized
INFO - 2020-11-21 05:29:00 --> Router Class Initialized
INFO - 2020-11-21 05:29:00 --> Output Class Initialized
INFO - 2020-11-21 05:29:00 --> Security Class Initialized
DEBUG - 2020-11-21 05:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:29:00 --> Input Class Initialized
INFO - 2020-11-21 05:29:00 --> Language Class Initialized
INFO - 2020-11-21 05:29:00 --> Language Class Initialized
INFO - 2020-11-21 05:29:00 --> Config Class Initialized
INFO - 2020-11-21 05:29:00 --> Loader Class Initialized
INFO - 2020-11-21 05:29:00 --> Helper loaded: url_helper
INFO - 2020-11-21 05:29:00 --> Helper loaded: file_helper
INFO - 2020-11-21 05:29:00 --> Helper loaded: form_helper
INFO - 2020-11-21 05:29:00 --> Helper loaded: my_helper
INFO - 2020-11-21 05:29:00 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:29:00 --> Controller Class Initialized
DEBUG - 2020-11-21 05:29:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 05:29:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:29:00 --> Final output sent to browser
DEBUG - 2020-11-21 05:29:00 --> Total execution time: 0.2631
INFO - 2020-11-21 05:29:40 --> Config Class Initialized
INFO - 2020-11-21 05:29:40 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:29:40 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:29:40 --> Utf8 Class Initialized
INFO - 2020-11-21 05:29:40 --> URI Class Initialized
INFO - 2020-11-21 05:29:40 --> Router Class Initialized
INFO - 2020-11-21 05:29:40 --> Output Class Initialized
INFO - 2020-11-21 05:29:40 --> Security Class Initialized
DEBUG - 2020-11-21 05:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:29:40 --> Input Class Initialized
INFO - 2020-11-21 05:29:40 --> Language Class Initialized
INFO - 2020-11-21 05:29:40 --> Language Class Initialized
INFO - 2020-11-21 05:29:40 --> Config Class Initialized
INFO - 2020-11-21 05:29:40 --> Loader Class Initialized
INFO - 2020-11-21 05:29:40 --> Helper loaded: url_helper
INFO - 2020-11-21 05:29:40 --> Helper loaded: file_helper
INFO - 2020-11-21 05:29:40 --> Helper loaded: form_helper
INFO - 2020-11-21 05:29:40 --> Helper loaded: my_helper
INFO - 2020-11-21 05:29:40 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:29:40 --> Controller Class Initialized
DEBUG - 2020-11-21 05:29:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 05:29:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:29:40 --> Final output sent to browser
DEBUG - 2020-11-21 05:29:40 --> Total execution time: 0.2683
INFO - 2020-11-21 05:30:41 --> Config Class Initialized
INFO - 2020-11-21 05:30:41 --> Hooks Class Initialized
DEBUG - 2020-11-21 05:30:41 --> UTF-8 Support Enabled
INFO - 2020-11-21 05:30:41 --> Utf8 Class Initialized
INFO - 2020-11-21 05:30:41 --> URI Class Initialized
INFO - 2020-11-21 05:30:41 --> Router Class Initialized
INFO - 2020-11-21 05:30:41 --> Output Class Initialized
INFO - 2020-11-21 05:30:41 --> Security Class Initialized
DEBUG - 2020-11-21 05:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-21 05:30:41 --> Input Class Initialized
INFO - 2020-11-21 05:30:41 --> Language Class Initialized
INFO - 2020-11-21 05:30:41 --> Language Class Initialized
INFO - 2020-11-21 05:30:41 --> Config Class Initialized
INFO - 2020-11-21 05:30:41 --> Loader Class Initialized
INFO - 2020-11-21 05:30:41 --> Helper loaded: url_helper
INFO - 2020-11-21 05:30:41 --> Helper loaded: file_helper
INFO - 2020-11-21 05:30:41 --> Helper loaded: form_helper
INFO - 2020-11-21 05:30:41 --> Helper loaded: my_helper
INFO - 2020-11-21 05:30:41 --> Database Driver Class Initialized
DEBUG - 2020-11-21 05:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-21 05:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-21 05:30:41 --> Controller Class Initialized
DEBUG - 2020-11-21 05:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-21 05:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-21 05:30:41 --> Final output sent to browser
DEBUG - 2020-11-21 05:30:41 --> Total execution time: 0.2627
