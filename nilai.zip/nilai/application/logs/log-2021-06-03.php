<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-03 02:34:11 --> Config Class Initialized
INFO - 2021-06-03 02:34:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:34:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:34:11 --> Utf8 Class Initialized
INFO - 2021-06-03 02:34:11 --> URI Class Initialized
DEBUG - 2021-06-03 02:34:11 --> No URI present. Default controller set.
INFO - 2021-06-03 02:34:11 --> Router Class Initialized
INFO - 2021-06-03 02:34:11 --> Output Class Initialized
INFO - 2021-06-03 02:34:11 --> Security Class Initialized
DEBUG - 2021-06-03 02:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:34:11 --> Input Class Initialized
INFO - 2021-06-03 02:34:11 --> Language Class Initialized
INFO - 2021-06-03 02:34:11 --> Language Class Initialized
INFO - 2021-06-03 02:34:11 --> Config Class Initialized
INFO - 2021-06-03 02:34:11 --> Loader Class Initialized
INFO - 2021-06-03 02:34:11 --> Helper loaded: url_helper
INFO - 2021-06-03 02:34:11 --> Helper loaded: file_helper
INFO - 2021-06-03 02:34:11 --> Helper loaded: form_helper
INFO - 2021-06-03 02:34:11 --> Helper loaded: my_helper
INFO - 2021-06-03 02:34:11 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:34:11 --> Controller Class Initialized
INFO - 2021-06-03 02:34:11 --> Config Class Initialized
INFO - 2021-06-03 02:34:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:34:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:34:11 --> Utf8 Class Initialized
INFO - 2021-06-03 02:34:11 --> URI Class Initialized
INFO - 2021-06-03 02:34:11 --> Router Class Initialized
INFO - 2021-06-03 02:34:11 --> Output Class Initialized
INFO - 2021-06-03 02:34:11 --> Security Class Initialized
DEBUG - 2021-06-03 02:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:34:11 --> Input Class Initialized
INFO - 2021-06-03 02:34:11 --> Language Class Initialized
INFO - 2021-06-03 02:34:11 --> Language Class Initialized
INFO - 2021-06-03 02:34:11 --> Config Class Initialized
INFO - 2021-06-03 02:34:11 --> Loader Class Initialized
INFO - 2021-06-03 02:34:11 --> Helper loaded: url_helper
INFO - 2021-06-03 02:34:11 --> Helper loaded: file_helper
INFO - 2021-06-03 02:34:11 --> Helper loaded: form_helper
INFO - 2021-06-03 02:34:11 --> Helper loaded: my_helper
INFO - 2021-06-03 02:34:11 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:34:11 --> Controller Class Initialized
DEBUG - 2021-06-03 02:34:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 02:34:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:34:11 --> Final output sent to browser
DEBUG - 2021-06-03 02:34:11 --> Total execution time: 0.0568
INFO - 2021-06-03 02:34:23 --> Config Class Initialized
INFO - 2021-06-03 02:34:23 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:34:23 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:34:23 --> Utf8 Class Initialized
INFO - 2021-06-03 02:34:23 --> URI Class Initialized
INFO - 2021-06-03 02:34:23 --> Router Class Initialized
INFO - 2021-06-03 02:34:23 --> Output Class Initialized
INFO - 2021-06-03 02:34:23 --> Security Class Initialized
DEBUG - 2021-06-03 02:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:34:23 --> Input Class Initialized
INFO - 2021-06-03 02:34:23 --> Language Class Initialized
INFO - 2021-06-03 02:34:23 --> Language Class Initialized
INFO - 2021-06-03 02:34:23 --> Config Class Initialized
INFO - 2021-06-03 02:34:23 --> Loader Class Initialized
INFO - 2021-06-03 02:34:23 --> Helper loaded: url_helper
INFO - 2021-06-03 02:34:23 --> Helper loaded: file_helper
INFO - 2021-06-03 02:34:23 --> Helper loaded: form_helper
INFO - 2021-06-03 02:34:23 --> Helper loaded: my_helper
INFO - 2021-06-03 02:34:23 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:34:23 --> Controller Class Initialized
INFO - 2021-06-03 02:34:23 --> Helper loaded: cookie_helper
INFO - 2021-06-03 02:34:23 --> Final output sent to browser
DEBUG - 2021-06-03 02:34:23 --> Total execution time: 0.0791
INFO - 2021-06-03 02:34:23 --> Config Class Initialized
INFO - 2021-06-03 02:34:23 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:34:23 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:34:23 --> Utf8 Class Initialized
INFO - 2021-06-03 02:34:23 --> URI Class Initialized
INFO - 2021-06-03 02:34:23 --> Router Class Initialized
INFO - 2021-06-03 02:34:23 --> Output Class Initialized
INFO - 2021-06-03 02:34:23 --> Security Class Initialized
DEBUG - 2021-06-03 02:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:34:23 --> Input Class Initialized
INFO - 2021-06-03 02:34:23 --> Language Class Initialized
INFO - 2021-06-03 02:34:23 --> Language Class Initialized
INFO - 2021-06-03 02:34:23 --> Config Class Initialized
INFO - 2021-06-03 02:34:23 --> Loader Class Initialized
INFO - 2021-06-03 02:34:23 --> Helper loaded: url_helper
INFO - 2021-06-03 02:34:24 --> Helper loaded: file_helper
INFO - 2021-06-03 02:34:24 --> Helper loaded: form_helper
INFO - 2021-06-03 02:34:24 --> Helper loaded: my_helper
INFO - 2021-06-03 02:34:24 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:34:24 --> Controller Class Initialized
DEBUG - 2021-06-03 02:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 02:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:34:24 --> Final output sent to browser
DEBUG - 2021-06-03 02:34:24 --> Total execution time: 0.1743
INFO - 2021-06-03 02:34:30 --> Config Class Initialized
INFO - 2021-06-03 02:34:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:34:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:34:30 --> Utf8 Class Initialized
INFO - 2021-06-03 02:34:30 --> URI Class Initialized
INFO - 2021-06-03 02:34:30 --> Router Class Initialized
INFO - 2021-06-03 02:34:30 --> Output Class Initialized
INFO - 2021-06-03 02:34:30 --> Security Class Initialized
DEBUG - 2021-06-03 02:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:34:30 --> Input Class Initialized
INFO - 2021-06-03 02:34:30 --> Language Class Initialized
INFO - 2021-06-03 02:34:30 --> Language Class Initialized
INFO - 2021-06-03 02:34:30 --> Config Class Initialized
INFO - 2021-06-03 02:34:30 --> Loader Class Initialized
INFO - 2021-06-03 02:34:30 --> Helper loaded: url_helper
INFO - 2021-06-03 02:34:30 --> Helper loaded: file_helper
INFO - 2021-06-03 02:34:30 --> Helper loaded: form_helper
INFO - 2021-06-03 02:34:30 --> Helper loaded: my_helper
INFO - 2021-06-03 02:34:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:34:30 --> Controller Class Initialized
DEBUG - 2021-06-03 02:34:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-06-03 02:34:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:34:30 --> Final output sent to browser
DEBUG - 2021-06-03 02:34:30 --> Total execution time: 0.0659
INFO - 2021-06-03 02:34:30 --> Config Class Initialized
INFO - 2021-06-03 02:34:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:34:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:34:30 --> Utf8 Class Initialized
INFO - 2021-06-03 02:34:30 --> URI Class Initialized
INFO - 2021-06-03 02:34:30 --> Router Class Initialized
INFO - 2021-06-03 02:34:30 --> Output Class Initialized
INFO - 2021-06-03 02:34:30 --> Security Class Initialized
DEBUG - 2021-06-03 02:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:34:30 --> Input Class Initialized
INFO - 2021-06-03 02:34:30 --> Language Class Initialized
INFO - 2021-06-03 02:34:30 --> Language Class Initialized
INFO - 2021-06-03 02:34:30 --> Config Class Initialized
INFO - 2021-06-03 02:34:30 --> Loader Class Initialized
INFO - 2021-06-03 02:34:30 --> Helper loaded: url_helper
INFO - 2021-06-03 02:34:30 --> Helper loaded: file_helper
INFO - 2021-06-03 02:34:30 --> Helper loaded: form_helper
INFO - 2021-06-03 02:34:30 --> Helper loaded: my_helper
INFO - 2021-06-03 02:34:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:34:30 --> Controller Class Initialized
INFO - 2021-06-03 02:34:48 --> Config Class Initialized
INFO - 2021-06-03 02:34:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:34:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:34:48 --> Utf8 Class Initialized
INFO - 2021-06-03 02:34:48 --> URI Class Initialized
INFO - 2021-06-03 02:34:48 --> Router Class Initialized
INFO - 2021-06-03 02:34:48 --> Output Class Initialized
INFO - 2021-06-03 02:34:48 --> Security Class Initialized
DEBUG - 2021-06-03 02:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:34:48 --> Input Class Initialized
INFO - 2021-06-03 02:34:48 --> Language Class Initialized
INFO - 2021-06-03 02:34:48 --> Language Class Initialized
INFO - 2021-06-03 02:34:48 --> Config Class Initialized
INFO - 2021-06-03 02:34:48 --> Loader Class Initialized
INFO - 2021-06-03 02:34:48 --> Helper loaded: url_helper
INFO - 2021-06-03 02:34:48 --> Helper loaded: file_helper
INFO - 2021-06-03 02:34:48 --> Helper loaded: form_helper
INFO - 2021-06-03 02:34:48 --> Helper loaded: my_helper
INFO - 2021-06-03 02:34:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:34:48 --> Controller Class Initialized
INFO - 2021-06-03 02:34:58 --> Config Class Initialized
INFO - 2021-06-03 02:34:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:34:58 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:34:58 --> Utf8 Class Initialized
INFO - 2021-06-03 02:34:58 --> URI Class Initialized
INFO - 2021-06-03 02:34:58 --> Router Class Initialized
INFO - 2021-06-03 02:34:58 --> Output Class Initialized
INFO - 2021-06-03 02:34:58 --> Security Class Initialized
DEBUG - 2021-06-03 02:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:34:58 --> Input Class Initialized
INFO - 2021-06-03 02:34:58 --> Language Class Initialized
INFO - 2021-06-03 02:34:58 --> Language Class Initialized
INFO - 2021-06-03 02:34:58 --> Config Class Initialized
INFO - 2021-06-03 02:34:58 --> Loader Class Initialized
INFO - 2021-06-03 02:34:58 --> Helper loaded: url_helper
INFO - 2021-06-03 02:34:58 --> Helper loaded: file_helper
INFO - 2021-06-03 02:34:58 --> Helper loaded: form_helper
INFO - 2021-06-03 02:34:58 --> Helper loaded: my_helper
INFO - 2021-06-03 02:34:58 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:34:58 --> Controller Class Initialized
INFO - 2021-06-03 02:34:58 --> Helper loaded: cookie_helper
INFO - 2021-06-03 02:34:58 --> Config Class Initialized
INFO - 2021-06-03 02:34:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:34:58 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:34:58 --> Utf8 Class Initialized
INFO - 2021-06-03 02:34:58 --> URI Class Initialized
INFO - 2021-06-03 02:34:58 --> Router Class Initialized
INFO - 2021-06-03 02:34:58 --> Output Class Initialized
INFO - 2021-06-03 02:34:58 --> Security Class Initialized
DEBUG - 2021-06-03 02:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:34:58 --> Input Class Initialized
INFO - 2021-06-03 02:34:58 --> Language Class Initialized
INFO - 2021-06-03 02:34:58 --> Language Class Initialized
INFO - 2021-06-03 02:34:58 --> Config Class Initialized
INFO - 2021-06-03 02:34:58 --> Loader Class Initialized
INFO - 2021-06-03 02:34:58 --> Helper loaded: url_helper
INFO - 2021-06-03 02:34:58 --> Helper loaded: file_helper
INFO - 2021-06-03 02:34:58 --> Helper loaded: form_helper
INFO - 2021-06-03 02:34:58 --> Helper loaded: my_helper
INFO - 2021-06-03 02:34:58 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:34:58 --> Controller Class Initialized
DEBUG - 2021-06-03 02:34:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 02:34:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:34:58 --> Final output sent to browser
DEBUG - 2021-06-03 02:34:58 --> Total execution time: 0.0693
INFO - 2021-06-03 02:35:06 --> Config Class Initialized
INFO - 2021-06-03 02:35:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:35:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:35:06 --> Utf8 Class Initialized
INFO - 2021-06-03 02:35:06 --> URI Class Initialized
INFO - 2021-06-03 02:35:06 --> Router Class Initialized
INFO - 2021-06-03 02:35:06 --> Output Class Initialized
INFO - 2021-06-03 02:35:06 --> Security Class Initialized
DEBUG - 2021-06-03 02:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:35:06 --> Input Class Initialized
INFO - 2021-06-03 02:35:06 --> Language Class Initialized
INFO - 2021-06-03 02:35:06 --> Language Class Initialized
INFO - 2021-06-03 02:35:06 --> Config Class Initialized
INFO - 2021-06-03 02:35:06 --> Loader Class Initialized
INFO - 2021-06-03 02:35:06 --> Helper loaded: url_helper
INFO - 2021-06-03 02:35:06 --> Helper loaded: file_helper
INFO - 2021-06-03 02:35:06 --> Helper loaded: form_helper
INFO - 2021-06-03 02:35:06 --> Helper loaded: my_helper
INFO - 2021-06-03 02:35:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:35:06 --> Controller Class Initialized
INFO - 2021-06-03 02:35:06 --> Helper loaded: cookie_helper
INFO - 2021-06-03 02:35:06 --> Final output sent to browser
DEBUG - 2021-06-03 02:35:06 --> Total execution time: 0.0799
INFO - 2021-06-03 02:35:06 --> Config Class Initialized
INFO - 2021-06-03 02:35:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:35:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:35:06 --> Utf8 Class Initialized
INFO - 2021-06-03 02:35:06 --> URI Class Initialized
INFO - 2021-06-03 02:35:07 --> Router Class Initialized
INFO - 2021-06-03 02:35:07 --> Output Class Initialized
INFO - 2021-06-03 02:35:07 --> Security Class Initialized
DEBUG - 2021-06-03 02:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:35:07 --> Input Class Initialized
INFO - 2021-06-03 02:35:07 --> Language Class Initialized
INFO - 2021-06-03 02:35:07 --> Language Class Initialized
INFO - 2021-06-03 02:35:07 --> Config Class Initialized
INFO - 2021-06-03 02:35:07 --> Loader Class Initialized
INFO - 2021-06-03 02:35:07 --> Helper loaded: url_helper
INFO - 2021-06-03 02:35:07 --> Helper loaded: file_helper
INFO - 2021-06-03 02:35:07 --> Helper loaded: form_helper
INFO - 2021-06-03 02:35:07 --> Helper loaded: my_helper
INFO - 2021-06-03 02:35:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:35:07 --> Controller Class Initialized
DEBUG - 2021-06-03 02:35:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 02:35:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:35:07 --> Final output sent to browser
DEBUG - 2021-06-03 02:35:07 --> Total execution time: 0.0959
INFO - 2021-06-03 02:36:01 --> Config Class Initialized
INFO - 2021-06-03 02:36:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:36:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:36:01 --> Utf8 Class Initialized
INFO - 2021-06-03 02:36:01 --> URI Class Initialized
INFO - 2021-06-03 02:36:01 --> Router Class Initialized
INFO - 2021-06-03 02:36:01 --> Output Class Initialized
INFO - 2021-06-03 02:36:01 --> Security Class Initialized
DEBUG - 2021-06-03 02:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:36:01 --> Input Class Initialized
INFO - 2021-06-03 02:36:01 --> Language Class Initialized
INFO - 2021-06-03 02:36:01 --> Language Class Initialized
INFO - 2021-06-03 02:36:01 --> Config Class Initialized
INFO - 2021-06-03 02:36:01 --> Loader Class Initialized
INFO - 2021-06-03 02:36:01 --> Helper loaded: url_helper
INFO - 2021-06-03 02:36:01 --> Helper loaded: file_helper
INFO - 2021-06-03 02:36:01 --> Helper loaded: form_helper
INFO - 2021-06-03 02:36:01 --> Helper loaded: my_helper
INFO - 2021-06-03 02:36:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:36:01 --> Controller Class Initialized
DEBUG - 2021-06-03 02:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-03 02:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:36:01 --> Final output sent to browser
DEBUG - 2021-06-03 02:36:01 --> Total execution time: 0.0846
INFO - 2021-06-03 02:40:47 --> Config Class Initialized
INFO - 2021-06-03 02:40:47 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:40:47 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:40:47 --> Utf8 Class Initialized
INFO - 2021-06-03 02:40:47 --> URI Class Initialized
INFO - 2021-06-03 02:40:47 --> Router Class Initialized
INFO - 2021-06-03 02:40:47 --> Output Class Initialized
INFO - 2021-06-03 02:40:47 --> Security Class Initialized
DEBUG - 2021-06-03 02:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:40:47 --> Input Class Initialized
INFO - 2021-06-03 02:40:47 --> Language Class Initialized
INFO - 2021-06-03 02:40:47 --> Language Class Initialized
INFO - 2021-06-03 02:40:47 --> Config Class Initialized
INFO - 2021-06-03 02:40:47 --> Loader Class Initialized
INFO - 2021-06-03 02:40:47 --> Helper loaded: url_helper
INFO - 2021-06-03 02:40:47 --> Helper loaded: file_helper
INFO - 2021-06-03 02:40:47 --> Helper loaded: form_helper
INFO - 2021-06-03 02:40:47 --> Helper loaded: my_helper
INFO - 2021-06-03 02:40:47 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:40:47 --> Controller Class Initialized
DEBUG - 2021-06-03 02:40:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-03 02:40:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:40:47 --> Final output sent to browser
DEBUG - 2021-06-03 02:40:47 --> Total execution time: 0.0733
INFO - 2021-06-03 02:40:49 --> Config Class Initialized
INFO - 2021-06-03 02:40:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:40:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:40:49 --> Utf8 Class Initialized
INFO - 2021-06-03 02:40:49 --> URI Class Initialized
INFO - 2021-06-03 02:40:49 --> Router Class Initialized
INFO - 2021-06-03 02:40:49 --> Output Class Initialized
INFO - 2021-06-03 02:40:49 --> Security Class Initialized
DEBUG - 2021-06-03 02:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:40:49 --> Input Class Initialized
INFO - 2021-06-03 02:40:49 --> Language Class Initialized
INFO - 2021-06-03 02:40:49 --> Language Class Initialized
INFO - 2021-06-03 02:40:49 --> Config Class Initialized
INFO - 2021-06-03 02:40:49 --> Loader Class Initialized
INFO - 2021-06-03 02:40:49 --> Helper loaded: url_helper
INFO - 2021-06-03 02:40:49 --> Helper loaded: file_helper
INFO - 2021-06-03 02:40:49 --> Helper loaded: form_helper
INFO - 2021-06-03 02:40:49 --> Helper loaded: my_helper
INFO - 2021-06-03 02:40:49 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:40:49 --> Controller Class Initialized
INFO - 2021-06-03 02:40:49 --> Final output sent to browser
DEBUG - 2021-06-03 02:40:49 --> Total execution time: 0.0822
INFO - 2021-06-03 02:40:51 --> Config Class Initialized
INFO - 2021-06-03 02:40:51 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:40:51 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:40:51 --> Utf8 Class Initialized
INFO - 2021-06-03 02:40:51 --> URI Class Initialized
INFO - 2021-06-03 02:40:51 --> Router Class Initialized
INFO - 2021-06-03 02:40:51 --> Output Class Initialized
INFO - 2021-06-03 02:40:51 --> Security Class Initialized
DEBUG - 2021-06-03 02:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:40:51 --> Input Class Initialized
INFO - 2021-06-03 02:40:51 --> Language Class Initialized
INFO - 2021-06-03 02:40:51 --> Language Class Initialized
INFO - 2021-06-03 02:40:51 --> Config Class Initialized
INFO - 2021-06-03 02:40:51 --> Loader Class Initialized
INFO - 2021-06-03 02:40:51 --> Helper loaded: url_helper
INFO - 2021-06-03 02:40:51 --> Helper loaded: file_helper
INFO - 2021-06-03 02:40:51 --> Helper loaded: form_helper
INFO - 2021-06-03 02:40:51 --> Helper loaded: my_helper
INFO - 2021-06-03 02:40:51 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:40:51 --> Controller Class Initialized
DEBUG - 2021-06-03 02:40:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-03 02:40:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:40:51 --> Final output sent to browser
DEBUG - 2021-06-03 02:40:51 --> Total execution time: 0.0799
INFO - 2021-06-03 02:40:52 --> Config Class Initialized
INFO - 2021-06-03 02:40:52 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:40:52 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:40:52 --> Utf8 Class Initialized
INFO - 2021-06-03 02:40:52 --> URI Class Initialized
INFO - 2021-06-03 02:40:52 --> Router Class Initialized
INFO - 2021-06-03 02:40:52 --> Output Class Initialized
INFO - 2021-06-03 02:40:52 --> Security Class Initialized
DEBUG - 2021-06-03 02:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:40:52 --> Input Class Initialized
INFO - 2021-06-03 02:40:52 --> Language Class Initialized
INFO - 2021-06-03 02:40:52 --> Language Class Initialized
INFO - 2021-06-03 02:40:52 --> Config Class Initialized
INFO - 2021-06-03 02:40:52 --> Loader Class Initialized
INFO - 2021-06-03 02:40:52 --> Helper loaded: url_helper
INFO - 2021-06-03 02:40:52 --> Helper loaded: file_helper
INFO - 2021-06-03 02:40:52 --> Helper loaded: form_helper
INFO - 2021-06-03 02:40:52 --> Helper loaded: my_helper
INFO - 2021-06-03 02:40:52 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:40:52 --> Controller Class Initialized
DEBUG - 2021-06-03 02:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-03 02:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:40:52 --> Final output sent to browser
DEBUG - 2021-06-03 02:40:52 --> Total execution time: 0.0630
INFO - 2021-06-03 02:40:52 --> Config Class Initialized
INFO - 2021-06-03 02:40:52 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:40:52 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:40:52 --> Utf8 Class Initialized
INFO - 2021-06-03 02:40:52 --> URI Class Initialized
INFO - 2021-06-03 02:40:52 --> Router Class Initialized
INFO - 2021-06-03 02:40:52 --> Output Class Initialized
INFO - 2021-06-03 02:40:52 --> Security Class Initialized
DEBUG - 2021-06-03 02:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:40:52 --> Input Class Initialized
INFO - 2021-06-03 02:40:52 --> Language Class Initialized
INFO - 2021-06-03 02:40:52 --> Language Class Initialized
INFO - 2021-06-03 02:40:52 --> Config Class Initialized
INFO - 2021-06-03 02:40:52 --> Loader Class Initialized
INFO - 2021-06-03 02:40:52 --> Helper loaded: url_helper
INFO - 2021-06-03 02:40:52 --> Helper loaded: file_helper
INFO - 2021-06-03 02:40:52 --> Helper loaded: form_helper
INFO - 2021-06-03 02:40:52 --> Helper loaded: my_helper
INFO - 2021-06-03 02:40:52 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:40:52 --> Controller Class Initialized
INFO - 2021-06-03 02:40:54 --> Config Class Initialized
INFO - 2021-06-03 02:40:54 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:40:54 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:40:54 --> Utf8 Class Initialized
INFO - 2021-06-03 02:40:54 --> URI Class Initialized
INFO - 2021-06-03 02:40:54 --> Router Class Initialized
INFO - 2021-06-03 02:40:54 --> Output Class Initialized
INFO - 2021-06-03 02:40:54 --> Security Class Initialized
DEBUG - 2021-06-03 02:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:40:54 --> Input Class Initialized
INFO - 2021-06-03 02:40:54 --> Language Class Initialized
INFO - 2021-06-03 02:40:54 --> Language Class Initialized
INFO - 2021-06-03 02:40:54 --> Config Class Initialized
INFO - 2021-06-03 02:40:54 --> Loader Class Initialized
INFO - 2021-06-03 02:40:54 --> Helper loaded: url_helper
INFO - 2021-06-03 02:40:54 --> Helper loaded: file_helper
INFO - 2021-06-03 02:40:54 --> Helper loaded: form_helper
INFO - 2021-06-03 02:40:54 --> Helper loaded: my_helper
INFO - 2021-06-03 02:40:54 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:40:54 --> Controller Class Initialized
INFO - 2021-06-03 02:40:54 --> Final output sent to browser
DEBUG - 2021-06-03 02:40:54 --> Total execution time: 0.0505
INFO - 2021-06-03 02:40:57 --> Config Class Initialized
INFO - 2021-06-03 02:40:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:40:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:40:57 --> Utf8 Class Initialized
INFO - 2021-06-03 02:40:57 --> URI Class Initialized
INFO - 2021-06-03 02:40:57 --> Router Class Initialized
INFO - 2021-06-03 02:40:57 --> Output Class Initialized
INFO - 2021-06-03 02:40:57 --> Security Class Initialized
DEBUG - 2021-06-03 02:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:40:57 --> Input Class Initialized
INFO - 2021-06-03 02:40:57 --> Language Class Initialized
INFO - 2021-06-03 02:40:57 --> Language Class Initialized
INFO - 2021-06-03 02:40:57 --> Config Class Initialized
INFO - 2021-06-03 02:40:57 --> Loader Class Initialized
INFO - 2021-06-03 02:40:57 --> Helper loaded: url_helper
INFO - 2021-06-03 02:40:57 --> Helper loaded: file_helper
INFO - 2021-06-03 02:40:57 --> Helper loaded: form_helper
INFO - 2021-06-03 02:40:57 --> Helper loaded: my_helper
INFO - 2021-06-03 02:40:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:40:57 --> Controller Class Initialized
INFO - 2021-06-03 02:40:57 --> Final output sent to browser
DEBUG - 2021-06-03 02:40:57 --> Total execution time: 0.0701
INFO - 2021-06-03 02:40:58 --> Config Class Initialized
INFO - 2021-06-03 02:40:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:40:58 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:40:58 --> Utf8 Class Initialized
INFO - 2021-06-03 02:40:58 --> URI Class Initialized
INFO - 2021-06-03 02:40:58 --> Router Class Initialized
INFO - 2021-06-03 02:40:58 --> Output Class Initialized
INFO - 2021-06-03 02:40:58 --> Security Class Initialized
DEBUG - 2021-06-03 02:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:40:58 --> Input Class Initialized
INFO - 2021-06-03 02:40:58 --> Language Class Initialized
INFO - 2021-06-03 02:40:58 --> Language Class Initialized
INFO - 2021-06-03 02:40:58 --> Config Class Initialized
INFO - 2021-06-03 02:40:58 --> Loader Class Initialized
INFO - 2021-06-03 02:40:58 --> Helper loaded: url_helper
INFO - 2021-06-03 02:40:58 --> Helper loaded: file_helper
INFO - 2021-06-03 02:40:58 --> Helper loaded: form_helper
INFO - 2021-06-03 02:40:58 --> Helper loaded: my_helper
INFO - 2021-06-03 02:40:58 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:40:58 --> Controller Class Initialized
INFO - 2021-06-03 02:40:58 --> Final output sent to browser
DEBUG - 2021-06-03 02:40:58 --> Total execution time: 0.0555
INFO - 2021-06-03 02:41:01 --> Config Class Initialized
INFO - 2021-06-03 02:41:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:41:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:41:01 --> Utf8 Class Initialized
INFO - 2021-06-03 02:41:01 --> URI Class Initialized
INFO - 2021-06-03 02:41:01 --> Router Class Initialized
INFO - 2021-06-03 02:41:01 --> Output Class Initialized
INFO - 2021-06-03 02:41:01 --> Security Class Initialized
DEBUG - 2021-06-03 02:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:41:01 --> Input Class Initialized
INFO - 2021-06-03 02:41:01 --> Language Class Initialized
INFO - 2021-06-03 02:41:01 --> Language Class Initialized
INFO - 2021-06-03 02:41:01 --> Config Class Initialized
INFO - 2021-06-03 02:41:01 --> Loader Class Initialized
INFO - 2021-06-03 02:41:01 --> Helper loaded: url_helper
INFO - 2021-06-03 02:41:01 --> Helper loaded: file_helper
INFO - 2021-06-03 02:41:01 --> Helper loaded: form_helper
INFO - 2021-06-03 02:41:01 --> Helper loaded: my_helper
INFO - 2021-06-03 02:41:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:41:01 --> Controller Class Initialized
DEBUG - 2021-06-03 02:41:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-03 02:41:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:41:01 --> Final output sent to browser
DEBUG - 2021-06-03 02:41:01 --> Total execution time: 0.0624
INFO - 2021-06-03 02:41:02 --> Config Class Initialized
INFO - 2021-06-03 02:41:02 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:41:02 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:41:02 --> Utf8 Class Initialized
INFO - 2021-06-03 02:41:02 --> URI Class Initialized
INFO - 2021-06-03 02:41:02 --> Router Class Initialized
INFO - 2021-06-03 02:41:02 --> Output Class Initialized
INFO - 2021-06-03 02:41:02 --> Security Class Initialized
DEBUG - 2021-06-03 02:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:41:02 --> Input Class Initialized
INFO - 2021-06-03 02:41:02 --> Language Class Initialized
INFO - 2021-06-03 02:41:02 --> Language Class Initialized
INFO - 2021-06-03 02:41:02 --> Config Class Initialized
INFO - 2021-06-03 02:41:02 --> Loader Class Initialized
INFO - 2021-06-03 02:41:02 --> Helper loaded: url_helper
INFO - 2021-06-03 02:41:02 --> Helper loaded: file_helper
INFO - 2021-06-03 02:41:02 --> Helper loaded: form_helper
INFO - 2021-06-03 02:41:02 --> Helper loaded: my_helper
INFO - 2021-06-03 02:41:02 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:41:02 --> Controller Class Initialized
DEBUG - 2021-06-03 02:41:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-03 02:41:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:41:02 --> Final output sent to browser
DEBUG - 2021-06-03 02:41:02 --> Total execution time: 0.0692
INFO - 2021-06-03 02:41:05 --> Config Class Initialized
INFO - 2021-06-03 02:41:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:41:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:41:05 --> Utf8 Class Initialized
INFO - 2021-06-03 02:41:05 --> URI Class Initialized
INFO - 2021-06-03 02:41:05 --> Router Class Initialized
INFO - 2021-06-03 02:41:05 --> Output Class Initialized
INFO - 2021-06-03 02:41:05 --> Security Class Initialized
DEBUG - 2021-06-03 02:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:41:05 --> Input Class Initialized
INFO - 2021-06-03 02:41:05 --> Language Class Initialized
INFO - 2021-06-03 02:41:05 --> Language Class Initialized
INFO - 2021-06-03 02:41:05 --> Config Class Initialized
INFO - 2021-06-03 02:41:05 --> Loader Class Initialized
INFO - 2021-06-03 02:41:05 --> Helper loaded: url_helper
INFO - 2021-06-03 02:41:05 --> Helper loaded: file_helper
INFO - 2021-06-03 02:41:05 --> Helper loaded: form_helper
INFO - 2021-06-03 02:41:05 --> Helper loaded: my_helper
INFO - 2021-06-03 02:41:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:41:05 --> Controller Class Initialized
INFO - 2021-06-03 02:41:05 --> Final output sent to browser
DEBUG - 2021-06-03 02:41:05 --> Total execution time: 0.0461
INFO - 2021-06-03 02:41:42 --> Config Class Initialized
INFO - 2021-06-03 02:41:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:41:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:41:42 --> Utf8 Class Initialized
INFO - 2021-06-03 02:41:42 --> URI Class Initialized
INFO - 2021-06-03 02:41:42 --> Router Class Initialized
INFO - 2021-06-03 02:41:42 --> Output Class Initialized
INFO - 2021-06-03 02:41:42 --> Security Class Initialized
DEBUG - 2021-06-03 02:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:41:42 --> Input Class Initialized
INFO - 2021-06-03 02:41:42 --> Language Class Initialized
INFO - 2021-06-03 02:41:42 --> Language Class Initialized
INFO - 2021-06-03 02:41:42 --> Config Class Initialized
INFO - 2021-06-03 02:41:42 --> Loader Class Initialized
INFO - 2021-06-03 02:41:42 --> Helper loaded: url_helper
INFO - 2021-06-03 02:41:42 --> Helper loaded: file_helper
INFO - 2021-06-03 02:41:42 --> Helper loaded: form_helper
INFO - 2021-06-03 02:41:42 --> Helper loaded: my_helper
INFO - 2021-06-03 02:41:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:41:42 --> Controller Class Initialized
INFO - 2021-06-03 02:41:42 --> Helper loaded: cookie_helper
INFO - 2021-06-03 02:41:42 --> Config Class Initialized
INFO - 2021-06-03 02:41:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:41:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:41:42 --> Utf8 Class Initialized
INFO - 2021-06-03 02:41:42 --> URI Class Initialized
INFO - 2021-06-03 02:41:42 --> Router Class Initialized
INFO - 2021-06-03 02:41:42 --> Output Class Initialized
INFO - 2021-06-03 02:41:42 --> Security Class Initialized
DEBUG - 2021-06-03 02:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:41:42 --> Input Class Initialized
INFO - 2021-06-03 02:41:42 --> Language Class Initialized
INFO - 2021-06-03 02:41:42 --> Language Class Initialized
INFO - 2021-06-03 02:41:42 --> Config Class Initialized
INFO - 2021-06-03 02:41:42 --> Loader Class Initialized
INFO - 2021-06-03 02:41:42 --> Helper loaded: url_helper
INFO - 2021-06-03 02:41:42 --> Helper loaded: file_helper
INFO - 2021-06-03 02:41:42 --> Helper loaded: form_helper
INFO - 2021-06-03 02:41:42 --> Helper loaded: my_helper
INFO - 2021-06-03 02:41:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:41:42 --> Controller Class Initialized
DEBUG - 2021-06-03 02:41:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 02:41:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:41:42 --> Final output sent to browser
DEBUG - 2021-06-03 02:41:42 --> Total execution time: 0.0655
INFO - 2021-06-03 02:41:50 --> Config Class Initialized
INFO - 2021-06-03 02:41:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:41:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:41:50 --> Utf8 Class Initialized
INFO - 2021-06-03 02:41:50 --> URI Class Initialized
INFO - 2021-06-03 02:41:50 --> Router Class Initialized
INFO - 2021-06-03 02:41:50 --> Output Class Initialized
INFO - 2021-06-03 02:41:50 --> Security Class Initialized
DEBUG - 2021-06-03 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:41:50 --> Input Class Initialized
INFO - 2021-06-03 02:41:50 --> Language Class Initialized
INFO - 2021-06-03 02:41:50 --> Language Class Initialized
INFO - 2021-06-03 02:41:50 --> Config Class Initialized
INFO - 2021-06-03 02:41:50 --> Loader Class Initialized
INFO - 2021-06-03 02:41:50 --> Helper loaded: url_helper
INFO - 2021-06-03 02:41:50 --> Helper loaded: file_helper
INFO - 2021-06-03 02:41:50 --> Helper loaded: form_helper
INFO - 2021-06-03 02:41:50 --> Helper loaded: my_helper
INFO - 2021-06-03 02:41:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:41:50 --> Controller Class Initialized
INFO - 2021-06-03 02:41:50 --> Helper loaded: cookie_helper
INFO - 2021-06-03 02:41:50 --> Final output sent to browser
DEBUG - 2021-06-03 02:41:50 --> Total execution time: 0.0593
INFO - 2021-06-03 02:41:50 --> Config Class Initialized
INFO - 2021-06-03 02:41:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:41:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:41:50 --> Utf8 Class Initialized
INFO - 2021-06-03 02:41:50 --> URI Class Initialized
INFO - 2021-06-03 02:41:50 --> Router Class Initialized
INFO - 2021-06-03 02:41:50 --> Output Class Initialized
INFO - 2021-06-03 02:41:50 --> Security Class Initialized
DEBUG - 2021-06-03 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:41:50 --> Input Class Initialized
INFO - 2021-06-03 02:41:50 --> Language Class Initialized
INFO - 2021-06-03 02:41:51 --> Language Class Initialized
INFO - 2021-06-03 02:41:51 --> Config Class Initialized
INFO - 2021-06-03 02:41:51 --> Loader Class Initialized
INFO - 2021-06-03 02:41:51 --> Helper loaded: url_helper
INFO - 2021-06-03 02:41:51 --> Helper loaded: file_helper
INFO - 2021-06-03 02:41:51 --> Helper loaded: form_helper
INFO - 2021-06-03 02:41:51 --> Helper loaded: my_helper
INFO - 2021-06-03 02:41:51 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:41:51 --> Controller Class Initialized
DEBUG - 2021-06-03 02:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 02:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:41:51 --> Final output sent to browser
DEBUG - 2021-06-03 02:41:51 --> Total execution time: 0.0744
INFO - 2021-06-03 02:42:06 --> Config Class Initialized
INFO - 2021-06-03 02:42:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:06 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:06 --> URI Class Initialized
INFO - 2021-06-03 02:42:06 --> Router Class Initialized
INFO - 2021-06-03 02:42:06 --> Output Class Initialized
INFO - 2021-06-03 02:42:06 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:06 --> Input Class Initialized
INFO - 2021-06-03 02:42:06 --> Language Class Initialized
INFO - 2021-06-03 02:42:06 --> Language Class Initialized
INFO - 2021-06-03 02:42:06 --> Config Class Initialized
INFO - 2021-06-03 02:42:06 --> Loader Class Initialized
INFO - 2021-06-03 02:42:06 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:06 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:06 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:06 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:06 --> Controller Class Initialized
DEBUG - 2021-06-03 02:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 02:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:42:06 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:06 --> Total execution time: 0.0869
INFO - 2021-06-03 02:42:08 --> Config Class Initialized
INFO - 2021-06-03 02:42:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:08 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:08 --> URI Class Initialized
INFO - 2021-06-03 02:42:08 --> Router Class Initialized
INFO - 2021-06-03 02:42:08 --> Output Class Initialized
INFO - 2021-06-03 02:42:08 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:08 --> Input Class Initialized
INFO - 2021-06-03 02:42:08 --> Language Class Initialized
INFO - 2021-06-03 02:42:08 --> Language Class Initialized
INFO - 2021-06-03 02:42:08 --> Config Class Initialized
INFO - 2021-06-03 02:42:08 --> Loader Class Initialized
INFO - 2021-06-03 02:42:08 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:08 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:08 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:08 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:08 --> Controller Class Initialized
DEBUG - 2021-06-03 02:42:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-03 02:42:08 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:08 --> Total execution time: 0.1824
INFO - 2021-06-03 02:42:14 --> Config Class Initialized
INFO - 2021-06-03 02:42:14 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:14 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:14 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:14 --> URI Class Initialized
INFO - 2021-06-03 02:42:14 --> Router Class Initialized
INFO - 2021-06-03 02:42:14 --> Output Class Initialized
INFO - 2021-06-03 02:42:14 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:14 --> Input Class Initialized
INFO - 2021-06-03 02:42:14 --> Language Class Initialized
INFO - 2021-06-03 02:42:14 --> Language Class Initialized
INFO - 2021-06-03 02:42:14 --> Config Class Initialized
INFO - 2021-06-03 02:42:14 --> Loader Class Initialized
INFO - 2021-06-03 02:42:15 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:15 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:15 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:15 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:15 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:15 --> Controller Class Initialized
INFO - 2021-06-03 02:42:15 --> Helper loaded: cookie_helper
INFO - 2021-06-03 02:42:15 --> Config Class Initialized
INFO - 2021-06-03 02:42:15 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:15 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:15 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:15 --> URI Class Initialized
INFO - 2021-06-03 02:42:15 --> Router Class Initialized
INFO - 2021-06-03 02:42:15 --> Output Class Initialized
INFO - 2021-06-03 02:42:15 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:15 --> Input Class Initialized
INFO - 2021-06-03 02:42:15 --> Language Class Initialized
INFO - 2021-06-03 02:42:15 --> Language Class Initialized
INFO - 2021-06-03 02:42:15 --> Config Class Initialized
INFO - 2021-06-03 02:42:15 --> Loader Class Initialized
INFO - 2021-06-03 02:42:15 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:15 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:15 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:15 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:15 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:15 --> Controller Class Initialized
DEBUG - 2021-06-03 02:42:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 02:42:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:42:15 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:15 --> Total execution time: 0.0662
INFO - 2021-06-03 02:42:30 --> Config Class Initialized
INFO - 2021-06-03 02:42:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:30 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:30 --> URI Class Initialized
INFO - 2021-06-03 02:42:30 --> Router Class Initialized
INFO - 2021-06-03 02:42:30 --> Output Class Initialized
INFO - 2021-06-03 02:42:30 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:30 --> Input Class Initialized
INFO - 2021-06-03 02:42:30 --> Language Class Initialized
INFO - 2021-06-03 02:42:30 --> Language Class Initialized
INFO - 2021-06-03 02:42:30 --> Config Class Initialized
INFO - 2021-06-03 02:42:30 --> Loader Class Initialized
INFO - 2021-06-03 02:42:30 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:30 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:30 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:30 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:30 --> Controller Class Initialized
INFO - 2021-06-03 02:42:30 --> Helper loaded: cookie_helper
INFO - 2021-06-03 02:42:30 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:30 --> Total execution time: 0.0662
INFO - 2021-06-03 02:42:31 --> Config Class Initialized
INFO - 2021-06-03 02:42:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:31 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:31 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:31 --> URI Class Initialized
INFO - 2021-06-03 02:42:31 --> Router Class Initialized
INFO - 2021-06-03 02:42:31 --> Output Class Initialized
INFO - 2021-06-03 02:42:31 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:31 --> Input Class Initialized
INFO - 2021-06-03 02:42:31 --> Language Class Initialized
INFO - 2021-06-03 02:42:31 --> Language Class Initialized
INFO - 2021-06-03 02:42:31 --> Config Class Initialized
INFO - 2021-06-03 02:42:31 --> Loader Class Initialized
INFO - 2021-06-03 02:42:31 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:31 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:31 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:31 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:31 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:31 --> Controller Class Initialized
DEBUG - 2021-06-03 02:42:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 02:42:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:42:31 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:31 --> Total execution time: 0.0721
INFO - 2021-06-03 02:42:35 --> Config Class Initialized
INFO - 2021-06-03 02:42:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:35 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:35 --> URI Class Initialized
INFO - 2021-06-03 02:42:35 --> Router Class Initialized
INFO - 2021-06-03 02:42:35 --> Output Class Initialized
INFO - 2021-06-03 02:42:35 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:35 --> Input Class Initialized
INFO - 2021-06-03 02:42:35 --> Language Class Initialized
INFO - 2021-06-03 02:42:35 --> Language Class Initialized
INFO - 2021-06-03 02:42:35 --> Config Class Initialized
INFO - 2021-06-03 02:42:35 --> Loader Class Initialized
INFO - 2021-06-03 02:42:35 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:35 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:35 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:35 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:35 --> Controller Class Initialized
DEBUG - 2021-06-03 02:42:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 02:42:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:42:35 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:35 --> Total execution time: 0.0943
INFO - 2021-06-03 02:42:38 --> Config Class Initialized
INFO - 2021-06-03 02:42:38 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:38 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:38 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:38 --> URI Class Initialized
INFO - 2021-06-03 02:42:38 --> Router Class Initialized
INFO - 2021-06-03 02:42:38 --> Output Class Initialized
INFO - 2021-06-03 02:42:38 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:38 --> Input Class Initialized
INFO - 2021-06-03 02:42:38 --> Language Class Initialized
INFO - 2021-06-03 02:42:38 --> Language Class Initialized
INFO - 2021-06-03 02:42:38 --> Config Class Initialized
INFO - 2021-06-03 02:42:38 --> Loader Class Initialized
INFO - 2021-06-03 02:42:38 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:38 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:38 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:38 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:38 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:38 --> Controller Class Initialized
DEBUG - 2021-06-03 02:42:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 02:42:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:42:38 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:38 --> Total execution time: 0.1474
INFO - 2021-06-03 02:42:40 --> Config Class Initialized
INFO - 2021-06-03 02:42:40 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:40 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:40 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:40 --> URI Class Initialized
INFO - 2021-06-03 02:42:40 --> Router Class Initialized
INFO - 2021-06-03 02:42:40 --> Output Class Initialized
INFO - 2021-06-03 02:42:40 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:40 --> Input Class Initialized
INFO - 2021-06-03 02:42:40 --> Language Class Initialized
INFO - 2021-06-03 02:42:40 --> Language Class Initialized
INFO - 2021-06-03 02:42:40 --> Config Class Initialized
INFO - 2021-06-03 02:42:40 --> Loader Class Initialized
INFO - 2021-06-03 02:42:40 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:40 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:40 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:40 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:40 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:40 --> Controller Class Initialized
DEBUG - 2021-06-03 02:42:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-03 02:42:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:42:40 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:40 --> Total execution time: 0.0464
INFO - 2021-06-03 02:42:41 --> Config Class Initialized
INFO - 2021-06-03 02:42:41 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:41 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:41 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:41 --> URI Class Initialized
INFO - 2021-06-03 02:42:41 --> Router Class Initialized
INFO - 2021-06-03 02:42:41 --> Output Class Initialized
INFO - 2021-06-03 02:42:41 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:41 --> Input Class Initialized
INFO - 2021-06-03 02:42:41 --> Language Class Initialized
INFO - 2021-06-03 02:42:41 --> Language Class Initialized
INFO - 2021-06-03 02:42:41 --> Config Class Initialized
INFO - 2021-06-03 02:42:41 --> Loader Class Initialized
INFO - 2021-06-03 02:42:41 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:41 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:41 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:41 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:41 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:41 --> Controller Class Initialized
DEBUG - 2021-06-03 02:42:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-03 02:42:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:42:41 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:41 --> Total execution time: 0.0697
INFO - 2021-06-03 02:42:42 --> Config Class Initialized
INFO - 2021-06-03 02:42:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:42 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:42 --> URI Class Initialized
INFO - 2021-06-03 02:42:42 --> Router Class Initialized
INFO - 2021-06-03 02:42:42 --> Output Class Initialized
INFO - 2021-06-03 02:42:42 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:42 --> Input Class Initialized
INFO - 2021-06-03 02:42:42 --> Language Class Initialized
INFO - 2021-06-03 02:42:42 --> Language Class Initialized
INFO - 2021-06-03 02:42:42 --> Config Class Initialized
INFO - 2021-06-03 02:42:42 --> Loader Class Initialized
INFO - 2021-06-03 02:42:42 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:42 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:42 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:42 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:42 --> Controller Class Initialized
DEBUG - 2021-06-03 02:42:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 02:42:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:42:42 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:42 --> Total execution time: 0.0973
INFO - 2021-06-03 02:42:58 --> Config Class Initialized
INFO - 2021-06-03 02:42:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:42:58 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:42:58 --> Utf8 Class Initialized
INFO - 2021-06-03 02:42:58 --> URI Class Initialized
INFO - 2021-06-03 02:42:58 --> Router Class Initialized
INFO - 2021-06-03 02:42:58 --> Output Class Initialized
INFO - 2021-06-03 02:42:58 --> Security Class Initialized
DEBUG - 2021-06-03 02:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:42:58 --> Input Class Initialized
INFO - 2021-06-03 02:42:58 --> Language Class Initialized
INFO - 2021-06-03 02:42:58 --> Language Class Initialized
INFO - 2021-06-03 02:42:58 --> Config Class Initialized
INFO - 2021-06-03 02:42:58 --> Loader Class Initialized
INFO - 2021-06-03 02:42:58 --> Helper loaded: url_helper
INFO - 2021-06-03 02:42:58 --> Helper loaded: file_helper
INFO - 2021-06-03 02:42:58 --> Helper loaded: form_helper
INFO - 2021-06-03 02:42:58 --> Helper loaded: my_helper
INFO - 2021-06-03 02:42:58 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:42:58 --> Controller Class Initialized
INFO - 2021-06-03 02:42:58 --> Final output sent to browser
DEBUG - 2021-06-03 02:42:58 --> Total execution time: 0.1123
INFO - 2021-06-03 02:43:03 --> Config Class Initialized
INFO - 2021-06-03 02:43:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:43:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:43:03 --> Utf8 Class Initialized
INFO - 2021-06-03 02:43:03 --> URI Class Initialized
INFO - 2021-06-03 02:43:03 --> Router Class Initialized
INFO - 2021-06-03 02:43:03 --> Output Class Initialized
INFO - 2021-06-03 02:43:03 --> Security Class Initialized
DEBUG - 2021-06-03 02:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:43:03 --> Input Class Initialized
INFO - 2021-06-03 02:43:03 --> Language Class Initialized
INFO - 2021-06-03 02:43:03 --> Language Class Initialized
INFO - 2021-06-03 02:43:03 --> Config Class Initialized
INFO - 2021-06-03 02:43:03 --> Loader Class Initialized
INFO - 2021-06-03 02:43:03 --> Helper loaded: url_helper
INFO - 2021-06-03 02:43:03 --> Helper loaded: file_helper
INFO - 2021-06-03 02:43:03 --> Helper loaded: form_helper
INFO - 2021-06-03 02:43:03 --> Helper loaded: my_helper
INFO - 2021-06-03 02:43:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:43:03 --> Controller Class Initialized
DEBUG - 2021-06-03 02:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 02:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:43:03 --> Final output sent to browser
DEBUG - 2021-06-03 02:43:03 --> Total execution time: 0.0925
INFO - 2021-06-03 02:44:44 --> Config Class Initialized
INFO - 2021-06-03 02:44:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:44:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:44:44 --> Utf8 Class Initialized
INFO - 2021-06-03 02:44:44 --> URI Class Initialized
INFO - 2021-06-03 02:44:44 --> Router Class Initialized
INFO - 2021-06-03 02:44:44 --> Output Class Initialized
INFO - 2021-06-03 02:44:44 --> Security Class Initialized
DEBUG - 2021-06-03 02:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:44:44 --> Input Class Initialized
INFO - 2021-06-03 02:44:44 --> Language Class Initialized
INFO - 2021-06-03 02:44:44 --> Language Class Initialized
INFO - 2021-06-03 02:44:44 --> Config Class Initialized
INFO - 2021-06-03 02:44:44 --> Loader Class Initialized
INFO - 2021-06-03 02:44:44 --> Helper loaded: url_helper
INFO - 2021-06-03 02:44:44 --> Helper loaded: file_helper
INFO - 2021-06-03 02:44:44 --> Helper loaded: form_helper
INFO - 2021-06-03 02:44:44 --> Helper loaded: my_helper
INFO - 2021-06-03 02:44:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:44:44 --> Controller Class Initialized
INFO - 2021-06-03 02:44:44 --> Final output sent to browser
DEBUG - 2021-06-03 02:44:44 --> Total execution time: 0.1321
INFO - 2021-06-03 02:44:48 --> Config Class Initialized
INFO - 2021-06-03 02:44:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:44:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:44:48 --> Utf8 Class Initialized
INFO - 2021-06-03 02:44:48 --> URI Class Initialized
INFO - 2021-06-03 02:44:48 --> Router Class Initialized
INFO - 2021-06-03 02:44:48 --> Output Class Initialized
INFO - 2021-06-03 02:44:48 --> Security Class Initialized
DEBUG - 2021-06-03 02:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:44:48 --> Input Class Initialized
INFO - 2021-06-03 02:44:48 --> Language Class Initialized
INFO - 2021-06-03 02:44:48 --> Language Class Initialized
INFO - 2021-06-03 02:44:48 --> Config Class Initialized
INFO - 2021-06-03 02:44:48 --> Loader Class Initialized
INFO - 2021-06-03 02:44:48 --> Helper loaded: url_helper
INFO - 2021-06-03 02:44:48 --> Helper loaded: file_helper
INFO - 2021-06-03 02:44:48 --> Helper loaded: form_helper
INFO - 2021-06-03 02:44:48 --> Helper loaded: my_helper
INFO - 2021-06-03 02:44:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:44:48 --> Controller Class Initialized
DEBUG - 2021-06-03 02:44:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 02:44:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:44:48 --> Final output sent to browser
DEBUG - 2021-06-03 02:44:48 --> Total execution time: 0.1320
INFO - 2021-06-03 02:44:50 --> Config Class Initialized
INFO - 2021-06-03 02:44:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:44:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:44:50 --> Utf8 Class Initialized
INFO - 2021-06-03 02:44:50 --> URI Class Initialized
INFO - 2021-06-03 02:44:50 --> Router Class Initialized
INFO - 2021-06-03 02:44:50 --> Output Class Initialized
INFO - 2021-06-03 02:44:50 --> Security Class Initialized
DEBUG - 2021-06-03 02:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:44:50 --> Input Class Initialized
INFO - 2021-06-03 02:44:50 --> Language Class Initialized
INFO - 2021-06-03 02:44:50 --> Language Class Initialized
INFO - 2021-06-03 02:44:50 --> Config Class Initialized
INFO - 2021-06-03 02:44:50 --> Loader Class Initialized
INFO - 2021-06-03 02:44:50 --> Helper loaded: url_helper
INFO - 2021-06-03 02:44:50 --> Helper loaded: file_helper
INFO - 2021-06-03 02:44:50 --> Helper loaded: form_helper
INFO - 2021-06-03 02:44:50 --> Helper loaded: my_helper
INFO - 2021-06-03 02:44:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:44:50 --> Controller Class Initialized
INFO - 2021-06-03 02:44:50 --> Final output sent to browser
DEBUG - 2021-06-03 02:44:50 --> Total execution time: 0.0792
INFO - 2021-06-03 02:44:54 --> Config Class Initialized
INFO - 2021-06-03 02:44:54 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:44:54 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:44:54 --> Utf8 Class Initialized
INFO - 2021-06-03 02:44:54 --> URI Class Initialized
INFO - 2021-06-03 02:44:54 --> Router Class Initialized
INFO - 2021-06-03 02:44:54 --> Output Class Initialized
INFO - 2021-06-03 02:44:54 --> Security Class Initialized
DEBUG - 2021-06-03 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:44:54 --> Input Class Initialized
INFO - 2021-06-03 02:44:54 --> Language Class Initialized
INFO - 2021-06-03 02:44:54 --> Language Class Initialized
INFO - 2021-06-03 02:44:54 --> Config Class Initialized
INFO - 2021-06-03 02:44:54 --> Loader Class Initialized
INFO - 2021-06-03 02:44:54 --> Helper loaded: url_helper
INFO - 2021-06-03 02:44:54 --> Helper loaded: file_helper
INFO - 2021-06-03 02:44:54 --> Helper loaded: form_helper
INFO - 2021-06-03 02:44:54 --> Helper loaded: my_helper
INFO - 2021-06-03 02:44:54 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:44:54 --> Controller Class Initialized
INFO - 2021-06-03 02:44:54 --> Final output sent to browser
DEBUG - 2021-06-03 02:44:54 --> Total execution time: 0.1238
INFO - 2021-06-03 02:44:57 --> Config Class Initialized
INFO - 2021-06-03 02:44:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:44:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:44:57 --> Utf8 Class Initialized
INFO - 2021-06-03 02:44:57 --> URI Class Initialized
INFO - 2021-06-03 02:44:57 --> Router Class Initialized
INFO - 2021-06-03 02:44:57 --> Output Class Initialized
INFO - 2021-06-03 02:44:57 --> Security Class Initialized
DEBUG - 2021-06-03 02:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:44:57 --> Input Class Initialized
INFO - 2021-06-03 02:44:57 --> Language Class Initialized
INFO - 2021-06-03 02:44:57 --> Language Class Initialized
INFO - 2021-06-03 02:44:57 --> Config Class Initialized
INFO - 2021-06-03 02:44:57 --> Loader Class Initialized
INFO - 2021-06-03 02:44:57 --> Helper loaded: url_helper
INFO - 2021-06-03 02:44:57 --> Helper loaded: file_helper
INFO - 2021-06-03 02:44:57 --> Helper loaded: form_helper
INFO - 2021-06-03 02:44:57 --> Helper loaded: my_helper
INFO - 2021-06-03 02:44:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:44:57 --> Controller Class Initialized
DEBUG - 2021-06-03 02:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 02:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:44:57 --> Final output sent to browser
DEBUG - 2021-06-03 02:44:57 --> Total execution time: 0.1131
INFO - 2021-06-03 02:45:00 --> Config Class Initialized
INFO - 2021-06-03 02:45:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:45:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:45:00 --> Utf8 Class Initialized
INFO - 2021-06-03 02:45:00 --> URI Class Initialized
INFO - 2021-06-03 02:45:00 --> Router Class Initialized
INFO - 2021-06-03 02:45:00 --> Output Class Initialized
INFO - 2021-06-03 02:45:00 --> Security Class Initialized
DEBUG - 2021-06-03 02:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:45:00 --> Input Class Initialized
INFO - 2021-06-03 02:45:00 --> Language Class Initialized
INFO - 2021-06-03 02:45:00 --> Language Class Initialized
INFO - 2021-06-03 02:45:00 --> Config Class Initialized
INFO - 2021-06-03 02:45:00 --> Loader Class Initialized
INFO - 2021-06-03 02:45:00 --> Helper loaded: url_helper
INFO - 2021-06-03 02:45:00 --> Helper loaded: file_helper
INFO - 2021-06-03 02:45:00 --> Helper loaded: form_helper
INFO - 2021-06-03 02:45:00 --> Helper loaded: my_helper
INFO - 2021-06-03 02:45:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:45:00 --> Controller Class Initialized
DEBUG - 2021-06-03 02:45:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 02:45:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:45:00 --> Final output sent to browser
DEBUG - 2021-06-03 02:45:00 --> Total execution time: 0.0967
INFO - 2021-06-03 02:45:06 --> Config Class Initialized
INFO - 2021-06-03 02:45:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:45:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:45:06 --> Utf8 Class Initialized
INFO - 2021-06-03 02:45:06 --> URI Class Initialized
INFO - 2021-06-03 02:45:06 --> Router Class Initialized
INFO - 2021-06-03 02:45:06 --> Output Class Initialized
INFO - 2021-06-03 02:45:06 --> Security Class Initialized
DEBUG - 2021-06-03 02:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:45:06 --> Input Class Initialized
INFO - 2021-06-03 02:45:06 --> Language Class Initialized
INFO - 2021-06-03 02:45:06 --> Language Class Initialized
INFO - 2021-06-03 02:45:06 --> Config Class Initialized
INFO - 2021-06-03 02:45:06 --> Loader Class Initialized
INFO - 2021-06-03 02:45:06 --> Helper loaded: url_helper
INFO - 2021-06-03 02:45:06 --> Helper loaded: file_helper
INFO - 2021-06-03 02:45:06 --> Helper loaded: form_helper
INFO - 2021-06-03 02:45:06 --> Helper loaded: my_helper
INFO - 2021-06-03 02:45:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:45:06 --> Controller Class Initialized
INFO - 2021-06-03 02:45:06 --> Final output sent to browser
DEBUG - 2021-06-03 02:45:06 --> Total execution time: 0.1247
INFO - 2021-06-03 02:45:10 --> Config Class Initialized
INFO - 2021-06-03 02:45:10 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:45:10 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:45:10 --> Utf8 Class Initialized
INFO - 2021-06-03 02:45:10 --> URI Class Initialized
INFO - 2021-06-03 02:45:10 --> Router Class Initialized
INFO - 2021-06-03 02:45:10 --> Output Class Initialized
INFO - 2021-06-03 02:45:10 --> Security Class Initialized
DEBUG - 2021-06-03 02:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:45:10 --> Input Class Initialized
INFO - 2021-06-03 02:45:10 --> Language Class Initialized
INFO - 2021-06-03 02:45:10 --> Language Class Initialized
INFO - 2021-06-03 02:45:10 --> Config Class Initialized
INFO - 2021-06-03 02:45:10 --> Loader Class Initialized
INFO - 2021-06-03 02:45:10 --> Helper loaded: url_helper
INFO - 2021-06-03 02:45:10 --> Helper loaded: file_helper
INFO - 2021-06-03 02:45:10 --> Helper loaded: form_helper
INFO - 2021-06-03 02:45:10 --> Helper loaded: my_helper
INFO - 2021-06-03 02:45:10 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:45:10 --> Controller Class Initialized
DEBUG - 2021-06-03 02:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-06-03 02:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:45:10 --> Final output sent to browser
DEBUG - 2021-06-03 02:45:10 --> Total execution time: 0.1168
INFO - 2021-06-03 02:45:42 --> Config Class Initialized
INFO - 2021-06-03 02:45:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:45:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:45:42 --> Utf8 Class Initialized
INFO - 2021-06-03 02:45:42 --> URI Class Initialized
INFO - 2021-06-03 02:45:42 --> Router Class Initialized
INFO - 2021-06-03 02:45:42 --> Output Class Initialized
INFO - 2021-06-03 02:45:42 --> Security Class Initialized
DEBUG - 2021-06-03 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:45:42 --> Input Class Initialized
INFO - 2021-06-03 02:45:42 --> Language Class Initialized
INFO - 2021-06-03 02:45:42 --> Language Class Initialized
INFO - 2021-06-03 02:45:42 --> Config Class Initialized
INFO - 2021-06-03 02:45:42 --> Loader Class Initialized
INFO - 2021-06-03 02:45:42 --> Helper loaded: url_helper
INFO - 2021-06-03 02:45:42 --> Helper loaded: file_helper
INFO - 2021-06-03 02:45:42 --> Helper loaded: form_helper
INFO - 2021-06-03 02:45:42 --> Helper loaded: my_helper
INFO - 2021-06-03 02:45:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:45:42 --> Controller Class Initialized
DEBUG - 2021-06-03 02:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 02:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 02:45:42 --> Final output sent to browser
DEBUG - 2021-06-03 02:45:42 --> Total execution time: 0.0669
INFO - 2021-06-03 02:45:44 --> Config Class Initialized
INFO - 2021-06-03 02:45:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:45:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:45:44 --> Utf8 Class Initialized
INFO - 2021-06-03 02:45:44 --> URI Class Initialized
INFO - 2021-06-03 02:45:44 --> Router Class Initialized
INFO - 2021-06-03 02:45:44 --> Output Class Initialized
INFO - 2021-06-03 02:45:44 --> Security Class Initialized
DEBUG - 2021-06-03 02:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:45:44 --> Input Class Initialized
INFO - 2021-06-03 02:45:44 --> Language Class Initialized
INFO - 2021-06-03 02:45:44 --> Language Class Initialized
INFO - 2021-06-03 02:45:44 --> Config Class Initialized
INFO - 2021-06-03 02:45:44 --> Loader Class Initialized
INFO - 2021-06-03 02:45:44 --> Helper loaded: url_helper
INFO - 2021-06-03 02:45:44 --> Helper loaded: file_helper
INFO - 2021-06-03 02:45:44 --> Helper loaded: form_helper
INFO - 2021-06-03 02:45:44 --> Helper loaded: my_helper
INFO - 2021-06-03 02:45:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:45:44 --> Controller Class Initialized
DEBUG - 2021-06-03 02:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:45:44 --> Final output sent to browser
DEBUG - 2021-06-03 02:45:44 --> Total execution time: 0.1028
INFO - 2021-06-03 02:46:33 --> Config Class Initialized
INFO - 2021-06-03 02:46:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:46:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:46:33 --> Utf8 Class Initialized
INFO - 2021-06-03 02:46:33 --> URI Class Initialized
INFO - 2021-06-03 02:46:33 --> Router Class Initialized
INFO - 2021-06-03 02:46:33 --> Output Class Initialized
INFO - 2021-06-03 02:46:33 --> Security Class Initialized
DEBUG - 2021-06-03 02:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:46:33 --> Input Class Initialized
INFO - 2021-06-03 02:46:33 --> Language Class Initialized
INFO - 2021-06-03 02:46:33 --> Language Class Initialized
INFO - 2021-06-03 02:46:33 --> Config Class Initialized
INFO - 2021-06-03 02:46:33 --> Loader Class Initialized
INFO - 2021-06-03 02:46:33 --> Helper loaded: url_helper
INFO - 2021-06-03 02:46:33 --> Helper loaded: file_helper
INFO - 2021-06-03 02:46:33 --> Helper loaded: form_helper
INFO - 2021-06-03 02:46:33 --> Helper loaded: my_helper
INFO - 2021-06-03 02:46:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:46:33 --> Controller Class Initialized
DEBUG - 2021-06-03 02:46:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:46:33 --> Final output sent to browser
DEBUG - 2021-06-03 02:46:33 --> Total execution time: 0.0861
INFO - 2021-06-03 02:48:16 --> Config Class Initialized
INFO - 2021-06-03 02:48:16 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:48:16 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:48:16 --> Utf8 Class Initialized
INFO - 2021-06-03 02:48:16 --> URI Class Initialized
INFO - 2021-06-03 02:48:16 --> Router Class Initialized
INFO - 2021-06-03 02:48:16 --> Output Class Initialized
INFO - 2021-06-03 02:48:16 --> Security Class Initialized
DEBUG - 2021-06-03 02:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:48:16 --> Input Class Initialized
INFO - 2021-06-03 02:48:16 --> Language Class Initialized
INFO - 2021-06-03 02:48:16 --> Language Class Initialized
INFO - 2021-06-03 02:48:16 --> Config Class Initialized
INFO - 2021-06-03 02:48:16 --> Loader Class Initialized
INFO - 2021-06-03 02:48:16 --> Helper loaded: url_helper
INFO - 2021-06-03 02:48:16 --> Helper loaded: file_helper
INFO - 2021-06-03 02:48:16 --> Helper loaded: form_helper
INFO - 2021-06-03 02:48:16 --> Helper loaded: my_helper
INFO - 2021-06-03 02:48:16 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:48:16 --> Controller Class Initialized
DEBUG - 2021-06-03 02:48:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:48:17 --> Final output sent to browser
DEBUG - 2021-06-03 02:48:17 --> Total execution time: 0.0713
INFO - 2021-06-03 02:51:33 --> Config Class Initialized
INFO - 2021-06-03 02:51:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:51:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:51:33 --> Utf8 Class Initialized
INFO - 2021-06-03 02:51:33 --> URI Class Initialized
INFO - 2021-06-03 02:51:33 --> Router Class Initialized
INFO - 2021-06-03 02:51:33 --> Output Class Initialized
INFO - 2021-06-03 02:51:33 --> Security Class Initialized
DEBUG - 2021-06-03 02:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:51:33 --> Input Class Initialized
INFO - 2021-06-03 02:51:33 --> Language Class Initialized
INFO - 2021-06-03 02:51:33 --> Language Class Initialized
INFO - 2021-06-03 02:51:33 --> Config Class Initialized
INFO - 2021-06-03 02:51:33 --> Loader Class Initialized
INFO - 2021-06-03 02:51:33 --> Helper loaded: url_helper
INFO - 2021-06-03 02:51:33 --> Helper loaded: file_helper
INFO - 2021-06-03 02:51:33 --> Helper loaded: form_helper
INFO - 2021-06-03 02:51:33 --> Helper loaded: my_helper
INFO - 2021-06-03 02:51:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:51:33 --> Controller Class Initialized
DEBUG - 2021-06-03 02:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:51:33 --> Final output sent to browser
DEBUG - 2021-06-03 02:51:33 --> Total execution time: 0.0764
INFO - 2021-06-03 02:51:56 --> Config Class Initialized
INFO - 2021-06-03 02:51:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:51:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:51:56 --> Utf8 Class Initialized
INFO - 2021-06-03 02:51:56 --> URI Class Initialized
INFO - 2021-06-03 02:51:56 --> Router Class Initialized
INFO - 2021-06-03 02:51:56 --> Output Class Initialized
INFO - 2021-06-03 02:51:56 --> Security Class Initialized
DEBUG - 2021-06-03 02:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:51:56 --> Input Class Initialized
INFO - 2021-06-03 02:51:56 --> Language Class Initialized
INFO - 2021-06-03 02:51:56 --> Language Class Initialized
INFO - 2021-06-03 02:51:56 --> Config Class Initialized
INFO - 2021-06-03 02:51:56 --> Loader Class Initialized
INFO - 2021-06-03 02:51:56 --> Helper loaded: url_helper
INFO - 2021-06-03 02:51:56 --> Helper loaded: file_helper
INFO - 2021-06-03 02:51:56 --> Helper loaded: form_helper
INFO - 2021-06-03 02:51:56 --> Helper loaded: my_helper
INFO - 2021-06-03 02:51:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:51:56 --> Controller Class Initialized
DEBUG - 2021-06-03 02:51:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:51:56 --> Final output sent to browser
DEBUG - 2021-06-03 02:51:56 --> Total execution time: 0.0782
INFO - 2021-06-03 02:52:15 --> Config Class Initialized
INFO - 2021-06-03 02:52:15 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:52:15 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:52:15 --> Utf8 Class Initialized
INFO - 2021-06-03 02:52:15 --> URI Class Initialized
INFO - 2021-06-03 02:52:15 --> Router Class Initialized
INFO - 2021-06-03 02:52:15 --> Output Class Initialized
INFO - 2021-06-03 02:52:15 --> Security Class Initialized
DEBUG - 2021-06-03 02:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:52:15 --> Input Class Initialized
INFO - 2021-06-03 02:52:15 --> Language Class Initialized
INFO - 2021-06-03 02:52:15 --> Language Class Initialized
INFO - 2021-06-03 02:52:15 --> Config Class Initialized
INFO - 2021-06-03 02:52:15 --> Loader Class Initialized
INFO - 2021-06-03 02:52:15 --> Helper loaded: url_helper
INFO - 2021-06-03 02:52:15 --> Helper loaded: file_helper
INFO - 2021-06-03 02:52:15 --> Helper loaded: form_helper
INFO - 2021-06-03 02:52:15 --> Helper loaded: my_helper
INFO - 2021-06-03 02:52:15 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:52:15 --> Controller Class Initialized
DEBUG - 2021-06-03 02:52:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:52:15 --> Final output sent to browser
DEBUG - 2021-06-03 02:52:15 --> Total execution time: 0.0739
INFO - 2021-06-03 02:52:17 --> Config Class Initialized
INFO - 2021-06-03 02:52:17 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:52:17 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:52:17 --> Utf8 Class Initialized
INFO - 2021-06-03 02:52:17 --> URI Class Initialized
INFO - 2021-06-03 02:52:17 --> Router Class Initialized
INFO - 2021-06-03 02:52:17 --> Output Class Initialized
INFO - 2021-06-03 02:52:17 --> Security Class Initialized
DEBUG - 2021-06-03 02:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:52:17 --> Input Class Initialized
INFO - 2021-06-03 02:52:17 --> Language Class Initialized
INFO - 2021-06-03 02:52:17 --> Language Class Initialized
INFO - 2021-06-03 02:52:17 --> Config Class Initialized
INFO - 2021-06-03 02:52:17 --> Loader Class Initialized
INFO - 2021-06-03 02:52:17 --> Helper loaded: url_helper
INFO - 2021-06-03 02:52:17 --> Helper loaded: file_helper
INFO - 2021-06-03 02:52:17 --> Helper loaded: form_helper
INFO - 2021-06-03 02:52:17 --> Helper loaded: my_helper
INFO - 2021-06-03 02:52:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:52:17 --> Controller Class Initialized
DEBUG - 2021-06-03 02:52:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:52:17 --> Final output sent to browser
DEBUG - 2021-06-03 02:52:17 --> Total execution time: 0.0843
INFO - 2021-06-03 02:52:19 --> Config Class Initialized
INFO - 2021-06-03 02:52:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:52:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:52:19 --> Utf8 Class Initialized
INFO - 2021-06-03 02:52:19 --> URI Class Initialized
INFO - 2021-06-03 02:52:19 --> Router Class Initialized
INFO - 2021-06-03 02:52:19 --> Output Class Initialized
INFO - 2021-06-03 02:52:19 --> Security Class Initialized
DEBUG - 2021-06-03 02:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:52:19 --> Input Class Initialized
INFO - 2021-06-03 02:52:19 --> Language Class Initialized
INFO - 2021-06-03 02:52:19 --> Language Class Initialized
INFO - 2021-06-03 02:52:19 --> Config Class Initialized
INFO - 2021-06-03 02:52:19 --> Loader Class Initialized
INFO - 2021-06-03 02:52:19 --> Helper loaded: url_helper
INFO - 2021-06-03 02:52:19 --> Helper loaded: file_helper
INFO - 2021-06-03 02:52:19 --> Helper loaded: form_helper
INFO - 2021-06-03 02:52:19 --> Helper loaded: my_helper
INFO - 2021-06-03 02:52:20 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:52:20 --> Controller Class Initialized
DEBUG - 2021-06-03 02:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:52:20 --> Final output sent to browser
DEBUG - 2021-06-03 02:52:20 --> Total execution time: 0.0830
INFO - 2021-06-03 02:53:17 --> Config Class Initialized
INFO - 2021-06-03 02:53:17 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:53:17 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:53:17 --> Utf8 Class Initialized
INFO - 2021-06-03 02:53:17 --> URI Class Initialized
INFO - 2021-06-03 02:53:17 --> Router Class Initialized
INFO - 2021-06-03 02:53:17 --> Output Class Initialized
INFO - 2021-06-03 02:53:17 --> Security Class Initialized
DEBUG - 2021-06-03 02:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:53:17 --> Input Class Initialized
INFO - 2021-06-03 02:53:17 --> Language Class Initialized
INFO - 2021-06-03 02:53:17 --> Language Class Initialized
INFO - 2021-06-03 02:53:17 --> Config Class Initialized
INFO - 2021-06-03 02:53:17 --> Loader Class Initialized
INFO - 2021-06-03 02:53:17 --> Helper loaded: url_helper
INFO - 2021-06-03 02:53:17 --> Helper loaded: file_helper
INFO - 2021-06-03 02:53:17 --> Helper loaded: form_helper
INFO - 2021-06-03 02:53:17 --> Helper loaded: my_helper
INFO - 2021-06-03 02:53:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:53:17 --> Controller Class Initialized
DEBUG - 2021-06-03 02:53:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:53:17 --> Final output sent to browser
DEBUG - 2021-06-03 02:53:17 --> Total execution time: 0.0868
INFO - 2021-06-03 02:54:17 --> Config Class Initialized
INFO - 2021-06-03 02:54:17 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:54:17 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:54:17 --> Utf8 Class Initialized
INFO - 2021-06-03 02:54:17 --> URI Class Initialized
INFO - 2021-06-03 02:54:17 --> Router Class Initialized
INFO - 2021-06-03 02:54:17 --> Output Class Initialized
INFO - 2021-06-03 02:54:17 --> Security Class Initialized
DEBUG - 2021-06-03 02:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:54:17 --> Input Class Initialized
INFO - 2021-06-03 02:54:17 --> Language Class Initialized
INFO - 2021-06-03 02:54:17 --> Language Class Initialized
INFO - 2021-06-03 02:54:17 --> Config Class Initialized
INFO - 2021-06-03 02:54:17 --> Loader Class Initialized
INFO - 2021-06-03 02:54:17 --> Helper loaded: url_helper
INFO - 2021-06-03 02:54:17 --> Helper loaded: file_helper
INFO - 2021-06-03 02:54:17 --> Helper loaded: form_helper
INFO - 2021-06-03 02:54:17 --> Helper loaded: my_helper
INFO - 2021-06-03 02:54:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:54:17 --> Controller Class Initialized
ERROR - 2021-06-03 02:54:17 --> Severity: Notice --> Undefined variable: no C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 233
DEBUG - 2021-06-03 02:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:54:17 --> Final output sent to browser
DEBUG - 2021-06-03 02:54:17 --> Total execution time: 0.1200
INFO - 2021-06-03 02:55:30 --> Config Class Initialized
INFO - 2021-06-03 02:55:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:55:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:55:30 --> Utf8 Class Initialized
INFO - 2021-06-03 02:55:30 --> URI Class Initialized
INFO - 2021-06-03 02:55:30 --> Router Class Initialized
INFO - 2021-06-03 02:55:30 --> Output Class Initialized
INFO - 2021-06-03 02:55:30 --> Security Class Initialized
DEBUG - 2021-06-03 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:55:30 --> Input Class Initialized
INFO - 2021-06-03 02:55:30 --> Language Class Initialized
INFO - 2021-06-03 02:55:30 --> Language Class Initialized
INFO - 2021-06-03 02:55:30 --> Config Class Initialized
INFO - 2021-06-03 02:55:30 --> Loader Class Initialized
INFO - 2021-06-03 02:55:30 --> Helper loaded: url_helper
INFO - 2021-06-03 02:55:30 --> Helper loaded: file_helper
INFO - 2021-06-03 02:55:30 --> Helper loaded: form_helper
INFO - 2021-06-03 02:55:30 --> Helper loaded: my_helper
INFO - 2021-06-03 02:55:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:55:30 --> Controller Class Initialized
ERROR - 2021-06-03 02:55:30 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 484
INFO - 2021-06-03 02:56:07 --> Config Class Initialized
INFO - 2021-06-03 02:56:07 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:56:07 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:56:07 --> Utf8 Class Initialized
INFO - 2021-06-03 02:56:07 --> URI Class Initialized
INFO - 2021-06-03 02:56:07 --> Router Class Initialized
INFO - 2021-06-03 02:56:07 --> Output Class Initialized
INFO - 2021-06-03 02:56:07 --> Security Class Initialized
DEBUG - 2021-06-03 02:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:56:07 --> Input Class Initialized
INFO - 2021-06-03 02:56:07 --> Language Class Initialized
INFO - 2021-06-03 02:56:07 --> Language Class Initialized
INFO - 2021-06-03 02:56:07 --> Config Class Initialized
INFO - 2021-06-03 02:56:07 --> Loader Class Initialized
INFO - 2021-06-03 02:56:07 --> Helper loaded: url_helper
INFO - 2021-06-03 02:56:07 --> Helper loaded: file_helper
INFO - 2021-06-03 02:56:07 --> Helper loaded: form_helper
INFO - 2021-06-03 02:56:07 --> Helper loaded: my_helper
INFO - 2021-06-03 02:56:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:56:07 --> Controller Class Initialized
ERROR - 2021-06-03 02:56:07 --> Severity: Notice --> Undefined variable: no C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 223
ERROR - 2021-06-03 02:56:07 --> Severity: Notice --> Undefined variable: no C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_to.php 228
DEBUG - 2021-06-03 02:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:56:07 --> Final output sent to browser
DEBUG - 2021-06-03 02:56:07 --> Total execution time: 0.0637
INFO - 2021-06-03 02:56:31 --> Config Class Initialized
INFO - 2021-06-03 02:56:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:56:31 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:56:31 --> Utf8 Class Initialized
INFO - 2021-06-03 02:56:31 --> URI Class Initialized
INFO - 2021-06-03 02:56:31 --> Router Class Initialized
INFO - 2021-06-03 02:56:31 --> Output Class Initialized
INFO - 2021-06-03 02:56:31 --> Security Class Initialized
DEBUG - 2021-06-03 02:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:56:31 --> Input Class Initialized
INFO - 2021-06-03 02:56:31 --> Language Class Initialized
INFO - 2021-06-03 02:56:31 --> Language Class Initialized
INFO - 2021-06-03 02:56:31 --> Config Class Initialized
INFO - 2021-06-03 02:56:31 --> Loader Class Initialized
INFO - 2021-06-03 02:56:31 --> Helper loaded: url_helper
INFO - 2021-06-03 02:56:31 --> Helper loaded: file_helper
INFO - 2021-06-03 02:56:31 --> Helper loaded: form_helper
INFO - 2021-06-03 02:56:31 --> Helper loaded: my_helper
INFO - 2021-06-03 02:56:31 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:56:31 --> Controller Class Initialized
DEBUG - 2021-06-03 02:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:56:31 --> Final output sent to browser
DEBUG - 2021-06-03 02:56:31 --> Total execution time: 0.0616
INFO - 2021-06-03 02:56:57 --> Config Class Initialized
INFO - 2021-06-03 02:56:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:56:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:56:57 --> Utf8 Class Initialized
INFO - 2021-06-03 02:56:57 --> URI Class Initialized
INFO - 2021-06-03 02:56:57 --> Router Class Initialized
INFO - 2021-06-03 02:56:57 --> Output Class Initialized
INFO - 2021-06-03 02:56:57 --> Security Class Initialized
DEBUG - 2021-06-03 02:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:56:57 --> Input Class Initialized
INFO - 2021-06-03 02:56:57 --> Language Class Initialized
INFO - 2021-06-03 02:56:57 --> Language Class Initialized
INFO - 2021-06-03 02:56:57 --> Config Class Initialized
INFO - 2021-06-03 02:56:57 --> Loader Class Initialized
INFO - 2021-06-03 02:56:57 --> Helper loaded: url_helper
INFO - 2021-06-03 02:56:57 --> Helper loaded: file_helper
INFO - 2021-06-03 02:56:57 --> Helper loaded: form_helper
INFO - 2021-06-03 02:56:57 --> Helper loaded: my_helper
INFO - 2021-06-03 02:56:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:56:57 --> Controller Class Initialized
DEBUG - 2021-06-03 02:56:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:56:57 --> Final output sent to browser
DEBUG - 2021-06-03 02:56:57 --> Total execution time: 0.0868
INFO - 2021-06-03 02:58:16 --> Config Class Initialized
INFO - 2021-06-03 02:58:16 --> Hooks Class Initialized
DEBUG - 2021-06-03 02:58:16 --> UTF-8 Support Enabled
INFO - 2021-06-03 02:58:16 --> Utf8 Class Initialized
INFO - 2021-06-03 02:58:16 --> URI Class Initialized
INFO - 2021-06-03 02:58:16 --> Router Class Initialized
INFO - 2021-06-03 02:58:16 --> Output Class Initialized
INFO - 2021-06-03 02:58:16 --> Security Class Initialized
DEBUG - 2021-06-03 02:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 02:58:16 --> Input Class Initialized
INFO - 2021-06-03 02:58:16 --> Language Class Initialized
INFO - 2021-06-03 02:58:16 --> Language Class Initialized
INFO - 2021-06-03 02:58:16 --> Config Class Initialized
INFO - 2021-06-03 02:58:16 --> Loader Class Initialized
INFO - 2021-06-03 02:58:16 --> Helper loaded: url_helper
INFO - 2021-06-03 02:58:16 --> Helper loaded: file_helper
INFO - 2021-06-03 02:58:16 --> Helper loaded: form_helper
INFO - 2021-06-03 02:58:16 --> Helper loaded: my_helper
INFO - 2021-06-03 02:58:16 --> Database Driver Class Initialized
DEBUG - 2021-06-03 02:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 02:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 02:58:16 --> Controller Class Initialized
DEBUG - 2021-06-03 02:58:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 02:58:16 --> Final output sent to browser
DEBUG - 2021-06-03 02:58:16 --> Total execution time: 0.0723
INFO - 2021-06-03 03:00:37 --> Config Class Initialized
INFO - 2021-06-03 03:00:37 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:00:37 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:00:37 --> Utf8 Class Initialized
INFO - 2021-06-03 03:00:37 --> URI Class Initialized
INFO - 2021-06-03 03:00:37 --> Router Class Initialized
INFO - 2021-06-03 03:00:37 --> Output Class Initialized
INFO - 2021-06-03 03:00:37 --> Security Class Initialized
DEBUG - 2021-06-03 03:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:00:37 --> Input Class Initialized
INFO - 2021-06-03 03:00:37 --> Language Class Initialized
INFO - 2021-06-03 03:00:37 --> Language Class Initialized
INFO - 2021-06-03 03:00:37 --> Config Class Initialized
INFO - 2021-06-03 03:00:37 --> Loader Class Initialized
INFO - 2021-06-03 03:00:37 --> Helper loaded: url_helper
INFO - 2021-06-03 03:00:37 --> Helper loaded: file_helper
INFO - 2021-06-03 03:00:37 --> Helper loaded: form_helper
INFO - 2021-06-03 03:00:37 --> Helper loaded: my_helper
INFO - 2021-06-03 03:00:37 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:00:37 --> Controller Class Initialized
DEBUG - 2021-06-03 03:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:00:37 --> Final output sent to browser
DEBUG - 2021-06-03 03:00:37 --> Total execution time: 0.0577
INFO - 2021-06-03 03:02:00 --> Config Class Initialized
INFO - 2021-06-03 03:02:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:02:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:02:00 --> Utf8 Class Initialized
INFO - 2021-06-03 03:02:00 --> URI Class Initialized
INFO - 2021-06-03 03:02:00 --> Router Class Initialized
INFO - 2021-06-03 03:02:00 --> Output Class Initialized
INFO - 2021-06-03 03:02:00 --> Security Class Initialized
DEBUG - 2021-06-03 03:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:02:00 --> Input Class Initialized
INFO - 2021-06-03 03:02:00 --> Language Class Initialized
INFO - 2021-06-03 03:02:00 --> Language Class Initialized
INFO - 2021-06-03 03:02:00 --> Config Class Initialized
INFO - 2021-06-03 03:02:00 --> Loader Class Initialized
INFO - 2021-06-03 03:02:00 --> Helper loaded: url_helper
INFO - 2021-06-03 03:02:00 --> Helper loaded: file_helper
INFO - 2021-06-03 03:02:00 --> Helper loaded: form_helper
INFO - 2021-06-03 03:02:00 --> Helper loaded: my_helper
INFO - 2021-06-03 03:02:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:02:00 --> Controller Class Initialized
DEBUG - 2021-06-03 03:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:02:00 --> Final output sent to browser
DEBUG - 2021-06-03 03:02:00 --> Total execution time: 0.0915
INFO - 2021-06-03 03:03:07 --> Config Class Initialized
INFO - 2021-06-03 03:03:07 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:03:07 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:03:07 --> Utf8 Class Initialized
INFO - 2021-06-03 03:03:07 --> URI Class Initialized
INFO - 2021-06-03 03:03:07 --> Router Class Initialized
INFO - 2021-06-03 03:03:07 --> Output Class Initialized
INFO - 2021-06-03 03:03:07 --> Security Class Initialized
DEBUG - 2021-06-03 03:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:03:07 --> Input Class Initialized
INFO - 2021-06-03 03:03:07 --> Language Class Initialized
INFO - 2021-06-03 03:03:07 --> Language Class Initialized
INFO - 2021-06-03 03:03:07 --> Config Class Initialized
INFO - 2021-06-03 03:03:07 --> Loader Class Initialized
INFO - 2021-06-03 03:03:07 --> Helper loaded: url_helper
INFO - 2021-06-03 03:03:07 --> Helper loaded: file_helper
INFO - 2021-06-03 03:03:07 --> Helper loaded: form_helper
INFO - 2021-06-03 03:03:07 --> Helper loaded: my_helper
INFO - 2021-06-03 03:03:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:03:07 --> Controller Class Initialized
DEBUG - 2021-06-03 03:03:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:03:07 --> Final output sent to browser
DEBUG - 2021-06-03 03:03:07 --> Total execution time: 0.0816
INFO - 2021-06-03 03:03:33 --> Config Class Initialized
INFO - 2021-06-03 03:03:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:03:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:03:33 --> Utf8 Class Initialized
INFO - 2021-06-03 03:03:33 --> URI Class Initialized
INFO - 2021-06-03 03:03:33 --> Router Class Initialized
INFO - 2021-06-03 03:03:33 --> Output Class Initialized
INFO - 2021-06-03 03:03:33 --> Security Class Initialized
DEBUG - 2021-06-03 03:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:03:33 --> Input Class Initialized
INFO - 2021-06-03 03:03:33 --> Language Class Initialized
INFO - 2021-06-03 03:03:33 --> Language Class Initialized
INFO - 2021-06-03 03:03:33 --> Config Class Initialized
INFO - 2021-06-03 03:03:33 --> Loader Class Initialized
INFO - 2021-06-03 03:03:33 --> Helper loaded: url_helper
INFO - 2021-06-03 03:03:33 --> Helper loaded: file_helper
INFO - 2021-06-03 03:03:33 --> Helper loaded: form_helper
INFO - 2021-06-03 03:03:33 --> Helper loaded: my_helper
INFO - 2021-06-03 03:03:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:03:33 --> Controller Class Initialized
DEBUG - 2021-06-03 03:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:03:33 --> Final output sent to browser
DEBUG - 2021-06-03 03:03:33 --> Total execution time: 0.0707
INFO - 2021-06-03 03:05:43 --> Config Class Initialized
INFO - 2021-06-03 03:05:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:05:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:05:43 --> Utf8 Class Initialized
INFO - 2021-06-03 03:05:43 --> URI Class Initialized
INFO - 2021-06-03 03:05:43 --> Router Class Initialized
INFO - 2021-06-03 03:05:43 --> Output Class Initialized
INFO - 2021-06-03 03:05:43 --> Security Class Initialized
DEBUG - 2021-06-03 03:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:05:43 --> Input Class Initialized
INFO - 2021-06-03 03:05:43 --> Language Class Initialized
INFO - 2021-06-03 03:05:43 --> Language Class Initialized
INFO - 2021-06-03 03:05:43 --> Config Class Initialized
INFO - 2021-06-03 03:05:43 --> Loader Class Initialized
INFO - 2021-06-03 03:05:43 --> Helper loaded: url_helper
INFO - 2021-06-03 03:05:43 --> Helper loaded: file_helper
INFO - 2021-06-03 03:05:43 --> Helper loaded: form_helper
INFO - 2021-06-03 03:05:43 --> Helper loaded: my_helper
INFO - 2021-06-03 03:05:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:05:43 --> Controller Class Initialized
DEBUG - 2021-06-03 03:05:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:05:43 --> Final output sent to browser
DEBUG - 2021-06-03 03:05:43 --> Total execution time: 0.0783
INFO - 2021-06-03 03:06:01 --> Config Class Initialized
INFO - 2021-06-03 03:06:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:06:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:06:01 --> Utf8 Class Initialized
INFO - 2021-06-03 03:06:01 --> URI Class Initialized
INFO - 2021-06-03 03:06:01 --> Router Class Initialized
INFO - 2021-06-03 03:06:01 --> Output Class Initialized
INFO - 2021-06-03 03:06:01 --> Security Class Initialized
DEBUG - 2021-06-03 03:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:06:01 --> Input Class Initialized
INFO - 2021-06-03 03:06:01 --> Language Class Initialized
INFO - 2021-06-03 03:06:01 --> Language Class Initialized
INFO - 2021-06-03 03:06:01 --> Config Class Initialized
INFO - 2021-06-03 03:06:01 --> Loader Class Initialized
INFO - 2021-06-03 03:06:01 --> Helper loaded: url_helper
INFO - 2021-06-03 03:06:01 --> Helper loaded: file_helper
INFO - 2021-06-03 03:06:01 --> Helper loaded: form_helper
INFO - 2021-06-03 03:06:01 --> Helper loaded: my_helper
INFO - 2021-06-03 03:06:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:06:01 --> Controller Class Initialized
DEBUG - 2021-06-03 03:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:06:01 --> Final output sent to browser
DEBUG - 2021-06-03 03:06:01 --> Total execution time: 0.0591
INFO - 2021-06-03 03:07:22 --> Config Class Initialized
INFO - 2021-06-03 03:07:22 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:07:22 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:07:22 --> Utf8 Class Initialized
INFO - 2021-06-03 03:07:22 --> URI Class Initialized
INFO - 2021-06-03 03:07:22 --> Router Class Initialized
INFO - 2021-06-03 03:07:22 --> Output Class Initialized
INFO - 2021-06-03 03:07:22 --> Security Class Initialized
DEBUG - 2021-06-03 03:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:07:22 --> Input Class Initialized
INFO - 2021-06-03 03:07:22 --> Language Class Initialized
INFO - 2021-06-03 03:07:22 --> Language Class Initialized
INFO - 2021-06-03 03:07:22 --> Config Class Initialized
INFO - 2021-06-03 03:07:22 --> Loader Class Initialized
INFO - 2021-06-03 03:07:22 --> Helper loaded: url_helper
INFO - 2021-06-03 03:07:22 --> Helper loaded: file_helper
INFO - 2021-06-03 03:07:22 --> Helper loaded: form_helper
INFO - 2021-06-03 03:07:22 --> Helper loaded: my_helper
INFO - 2021-06-03 03:07:22 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:07:22 --> Controller Class Initialized
DEBUG - 2021-06-03 03:07:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:07:23 --> Final output sent to browser
DEBUG - 2021-06-03 03:07:23 --> Total execution time: 0.2114
INFO - 2021-06-03 03:07:54 --> Config Class Initialized
INFO - 2021-06-03 03:07:54 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:07:54 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:07:54 --> Utf8 Class Initialized
INFO - 2021-06-03 03:07:54 --> URI Class Initialized
INFO - 2021-06-03 03:07:54 --> Router Class Initialized
INFO - 2021-06-03 03:07:54 --> Output Class Initialized
INFO - 2021-06-03 03:07:54 --> Security Class Initialized
DEBUG - 2021-06-03 03:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:07:54 --> Input Class Initialized
INFO - 2021-06-03 03:07:54 --> Language Class Initialized
INFO - 2021-06-03 03:07:54 --> Language Class Initialized
INFO - 2021-06-03 03:07:54 --> Config Class Initialized
INFO - 2021-06-03 03:07:54 --> Loader Class Initialized
INFO - 2021-06-03 03:07:54 --> Helper loaded: url_helper
INFO - 2021-06-03 03:07:54 --> Helper loaded: file_helper
INFO - 2021-06-03 03:07:54 --> Helper loaded: form_helper
INFO - 2021-06-03 03:07:54 --> Helper loaded: my_helper
INFO - 2021-06-03 03:07:54 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:07:54 --> Controller Class Initialized
DEBUG - 2021-06-03 03:07:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:07:54 --> Final output sent to browser
DEBUG - 2021-06-03 03:07:54 --> Total execution time: 0.1609
INFO - 2021-06-03 03:08:39 --> Config Class Initialized
INFO - 2021-06-03 03:08:39 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:08:39 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:08:39 --> Utf8 Class Initialized
INFO - 2021-06-03 03:08:39 --> URI Class Initialized
INFO - 2021-06-03 03:08:39 --> Router Class Initialized
INFO - 2021-06-03 03:08:39 --> Output Class Initialized
INFO - 2021-06-03 03:08:39 --> Security Class Initialized
DEBUG - 2021-06-03 03:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:08:39 --> Input Class Initialized
INFO - 2021-06-03 03:08:39 --> Language Class Initialized
INFO - 2021-06-03 03:08:39 --> Language Class Initialized
INFO - 2021-06-03 03:08:39 --> Config Class Initialized
INFO - 2021-06-03 03:08:39 --> Loader Class Initialized
INFO - 2021-06-03 03:08:39 --> Helper loaded: url_helper
INFO - 2021-06-03 03:08:39 --> Helper loaded: file_helper
INFO - 2021-06-03 03:08:39 --> Helper loaded: form_helper
INFO - 2021-06-03 03:08:39 --> Helper loaded: my_helper
INFO - 2021-06-03 03:08:39 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:08:39 --> Controller Class Initialized
DEBUG - 2021-06-03 03:08:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:08:39 --> Final output sent to browser
DEBUG - 2021-06-03 03:08:39 --> Total execution time: 0.1662
INFO - 2021-06-03 03:08:57 --> Config Class Initialized
INFO - 2021-06-03 03:08:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:08:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:08:57 --> Utf8 Class Initialized
INFO - 2021-06-03 03:08:57 --> URI Class Initialized
INFO - 2021-06-03 03:08:57 --> Router Class Initialized
INFO - 2021-06-03 03:08:57 --> Output Class Initialized
INFO - 2021-06-03 03:08:57 --> Security Class Initialized
DEBUG - 2021-06-03 03:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:08:57 --> Input Class Initialized
INFO - 2021-06-03 03:08:57 --> Language Class Initialized
INFO - 2021-06-03 03:08:57 --> Language Class Initialized
INFO - 2021-06-03 03:08:57 --> Config Class Initialized
INFO - 2021-06-03 03:08:57 --> Loader Class Initialized
INFO - 2021-06-03 03:08:57 --> Helper loaded: url_helper
INFO - 2021-06-03 03:08:57 --> Helper loaded: file_helper
INFO - 2021-06-03 03:08:57 --> Helper loaded: form_helper
INFO - 2021-06-03 03:08:57 --> Helper loaded: my_helper
INFO - 2021-06-03 03:08:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:08:57 --> Controller Class Initialized
DEBUG - 2021-06-03 03:08:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-03 03:08:57 --> Final output sent to browser
DEBUG - 2021-06-03 03:08:57 --> Total execution time: 0.1697
INFO - 2021-06-03 03:09:53 --> Config Class Initialized
INFO - 2021-06-03 03:09:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:09:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:09:53 --> Utf8 Class Initialized
INFO - 2021-06-03 03:09:53 --> URI Class Initialized
INFO - 2021-06-03 03:09:53 --> Router Class Initialized
INFO - 2021-06-03 03:09:53 --> Output Class Initialized
INFO - 2021-06-03 03:09:53 --> Security Class Initialized
DEBUG - 2021-06-03 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:09:53 --> Input Class Initialized
INFO - 2021-06-03 03:09:53 --> Language Class Initialized
INFO - 2021-06-03 03:09:53 --> Language Class Initialized
INFO - 2021-06-03 03:09:53 --> Config Class Initialized
INFO - 2021-06-03 03:09:53 --> Loader Class Initialized
INFO - 2021-06-03 03:09:53 --> Helper loaded: url_helper
INFO - 2021-06-03 03:09:53 --> Helper loaded: file_helper
INFO - 2021-06-03 03:09:53 --> Helper loaded: form_helper
INFO - 2021-06-03 03:09:53 --> Helper loaded: my_helper
INFO - 2021-06-03 03:09:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:09:53 --> Controller Class Initialized
DEBUG - 2021-06-03 03:09:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:09:53 --> Final output sent to browser
DEBUG - 2021-06-03 03:09:53 --> Total execution time: 0.1812
INFO - 2021-06-03 03:11:12 --> Config Class Initialized
INFO - 2021-06-03 03:11:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:11:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:11:12 --> Utf8 Class Initialized
INFO - 2021-06-03 03:11:12 --> URI Class Initialized
INFO - 2021-06-03 03:11:12 --> Router Class Initialized
INFO - 2021-06-03 03:11:12 --> Output Class Initialized
INFO - 2021-06-03 03:11:12 --> Security Class Initialized
DEBUG - 2021-06-03 03:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:11:12 --> Input Class Initialized
INFO - 2021-06-03 03:11:12 --> Language Class Initialized
INFO - 2021-06-03 03:11:12 --> Language Class Initialized
INFO - 2021-06-03 03:11:12 --> Config Class Initialized
INFO - 2021-06-03 03:11:12 --> Loader Class Initialized
INFO - 2021-06-03 03:11:12 --> Helper loaded: url_helper
INFO - 2021-06-03 03:11:12 --> Helper loaded: file_helper
INFO - 2021-06-03 03:11:12 --> Helper loaded: form_helper
INFO - 2021-06-03 03:11:12 --> Helper loaded: my_helper
INFO - 2021-06-03 03:11:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:11:12 --> Controller Class Initialized
DEBUG - 2021-06-03 03:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:11:12 --> Final output sent to browser
DEBUG - 2021-06-03 03:11:12 --> Total execution time: 0.1530
INFO - 2021-06-03 03:11:28 --> Config Class Initialized
INFO - 2021-06-03 03:11:28 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:11:28 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:11:28 --> Utf8 Class Initialized
INFO - 2021-06-03 03:11:28 --> URI Class Initialized
INFO - 2021-06-03 03:11:28 --> Router Class Initialized
INFO - 2021-06-03 03:11:28 --> Output Class Initialized
INFO - 2021-06-03 03:11:28 --> Security Class Initialized
DEBUG - 2021-06-03 03:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:11:28 --> Input Class Initialized
INFO - 2021-06-03 03:11:28 --> Language Class Initialized
INFO - 2021-06-03 03:11:28 --> Language Class Initialized
INFO - 2021-06-03 03:11:28 --> Config Class Initialized
INFO - 2021-06-03 03:11:28 --> Loader Class Initialized
INFO - 2021-06-03 03:11:28 --> Helper loaded: url_helper
INFO - 2021-06-03 03:11:28 --> Helper loaded: file_helper
INFO - 2021-06-03 03:11:28 --> Helper loaded: form_helper
INFO - 2021-06-03 03:11:28 --> Helper loaded: my_helper
INFO - 2021-06-03 03:11:28 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:11:28 --> Controller Class Initialized
DEBUG - 2021-06-03 03:11:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:11:28 --> Final output sent to browser
DEBUG - 2021-06-03 03:11:28 --> Total execution time: 0.1637
INFO - 2021-06-03 03:12:30 --> Config Class Initialized
INFO - 2021-06-03 03:12:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:12:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:12:30 --> Utf8 Class Initialized
INFO - 2021-06-03 03:12:30 --> URI Class Initialized
INFO - 2021-06-03 03:12:30 --> Router Class Initialized
INFO - 2021-06-03 03:12:30 --> Output Class Initialized
INFO - 2021-06-03 03:12:30 --> Security Class Initialized
DEBUG - 2021-06-03 03:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:12:30 --> Input Class Initialized
INFO - 2021-06-03 03:12:30 --> Language Class Initialized
INFO - 2021-06-03 03:12:30 --> Language Class Initialized
INFO - 2021-06-03 03:12:30 --> Config Class Initialized
INFO - 2021-06-03 03:12:30 --> Loader Class Initialized
INFO - 2021-06-03 03:12:30 --> Helper loaded: url_helper
INFO - 2021-06-03 03:12:30 --> Helper loaded: file_helper
INFO - 2021-06-03 03:12:30 --> Helper loaded: form_helper
INFO - 2021-06-03 03:12:30 --> Helper loaded: my_helper
INFO - 2021-06-03 03:12:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:12:30 --> Controller Class Initialized
DEBUG - 2021-06-03 03:12:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:12:30 --> Final output sent to browser
DEBUG - 2021-06-03 03:12:30 --> Total execution time: 0.1716
INFO - 2021-06-03 03:12:39 --> Config Class Initialized
INFO - 2021-06-03 03:12:39 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:12:39 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:12:39 --> Utf8 Class Initialized
INFO - 2021-06-03 03:12:39 --> URI Class Initialized
INFO - 2021-06-03 03:12:39 --> Router Class Initialized
INFO - 2021-06-03 03:12:39 --> Output Class Initialized
INFO - 2021-06-03 03:12:39 --> Security Class Initialized
DEBUG - 2021-06-03 03:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:12:39 --> Input Class Initialized
INFO - 2021-06-03 03:12:39 --> Language Class Initialized
INFO - 2021-06-03 03:12:40 --> Language Class Initialized
INFO - 2021-06-03 03:12:40 --> Config Class Initialized
INFO - 2021-06-03 03:12:40 --> Loader Class Initialized
INFO - 2021-06-03 03:12:40 --> Helper loaded: url_helper
INFO - 2021-06-03 03:12:40 --> Helper loaded: file_helper
INFO - 2021-06-03 03:12:40 --> Helper loaded: form_helper
INFO - 2021-06-03 03:12:40 --> Helper loaded: my_helper
INFO - 2021-06-03 03:12:40 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:12:40 --> Controller Class Initialized
DEBUG - 2021-06-03 03:12:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:12:40 --> Final output sent to browser
DEBUG - 2021-06-03 03:12:40 --> Total execution time: 0.1000
INFO - 2021-06-03 03:14:34 --> Config Class Initialized
INFO - 2021-06-03 03:14:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:14:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:14:34 --> Utf8 Class Initialized
INFO - 2021-06-03 03:14:34 --> URI Class Initialized
INFO - 2021-06-03 03:14:34 --> Router Class Initialized
INFO - 2021-06-03 03:14:34 --> Output Class Initialized
INFO - 2021-06-03 03:14:34 --> Security Class Initialized
DEBUG - 2021-06-03 03:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:14:34 --> Input Class Initialized
INFO - 2021-06-03 03:14:34 --> Language Class Initialized
INFO - 2021-06-03 03:14:34 --> Language Class Initialized
INFO - 2021-06-03 03:14:34 --> Config Class Initialized
INFO - 2021-06-03 03:14:34 --> Loader Class Initialized
INFO - 2021-06-03 03:14:34 --> Helper loaded: url_helper
INFO - 2021-06-03 03:14:34 --> Helper loaded: file_helper
INFO - 2021-06-03 03:14:34 --> Helper loaded: form_helper
INFO - 2021-06-03 03:14:34 --> Helper loaded: my_helper
INFO - 2021-06-03 03:14:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:14:35 --> Controller Class Initialized
DEBUG - 2021-06-03 03:14:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:14:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:14:35 --> Final output sent to browser
DEBUG - 2021-06-03 03:14:35 --> Total execution time: 0.1459
INFO - 2021-06-03 03:14:36 --> Config Class Initialized
INFO - 2021-06-03 03:14:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:14:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:14:36 --> Utf8 Class Initialized
INFO - 2021-06-03 03:14:36 --> URI Class Initialized
INFO - 2021-06-03 03:14:36 --> Router Class Initialized
INFO - 2021-06-03 03:14:36 --> Output Class Initialized
INFO - 2021-06-03 03:14:36 --> Security Class Initialized
DEBUG - 2021-06-03 03:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:14:36 --> Input Class Initialized
INFO - 2021-06-03 03:14:36 --> Language Class Initialized
INFO - 2021-06-03 03:14:36 --> Language Class Initialized
INFO - 2021-06-03 03:14:36 --> Config Class Initialized
INFO - 2021-06-03 03:14:36 --> Loader Class Initialized
INFO - 2021-06-03 03:14:36 --> Helper loaded: url_helper
INFO - 2021-06-03 03:14:36 --> Helper loaded: file_helper
INFO - 2021-06-03 03:14:36 --> Helper loaded: form_helper
INFO - 2021-06-03 03:14:36 --> Helper loaded: my_helper
INFO - 2021-06-03 03:14:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:14:36 --> Controller Class Initialized
INFO - 2021-06-03 03:14:36 --> Final output sent to browser
DEBUG - 2021-06-03 03:14:36 --> Total execution time: 0.1196
INFO - 2021-06-03 03:14:39 --> Config Class Initialized
INFO - 2021-06-03 03:14:39 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:14:39 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:14:39 --> Utf8 Class Initialized
INFO - 2021-06-03 03:14:39 --> URI Class Initialized
INFO - 2021-06-03 03:14:39 --> Router Class Initialized
INFO - 2021-06-03 03:14:39 --> Output Class Initialized
INFO - 2021-06-03 03:14:39 --> Security Class Initialized
DEBUG - 2021-06-03 03:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:14:39 --> Input Class Initialized
INFO - 2021-06-03 03:14:39 --> Language Class Initialized
INFO - 2021-06-03 03:14:39 --> Language Class Initialized
INFO - 2021-06-03 03:14:39 --> Config Class Initialized
INFO - 2021-06-03 03:14:39 --> Loader Class Initialized
INFO - 2021-06-03 03:14:39 --> Helper loaded: url_helper
INFO - 2021-06-03 03:14:39 --> Helper loaded: file_helper
INFO - 2021-06-03 03:14:39 --> Helper loaded: form_helper
INFO - 2021-06-03 03:14:39 --> Helper loaded: my_helper
INFO - 2021-06-03 03:14:39 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:14:39 --> Controller Class Initialized
INFO - 2021-06-03 03:14:39 --> Final output sent to browser
DEBUG - 2021-06-03 03:14:39 --> Total execution time: 0.2190
INFO - 2021-06-03 03:14:43 --> Config Class Initialized
INFO - 2021-06-03 03:14:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:14:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:14:43 --> Utf8 Class Initialized
INFO - 2021-06-03 03:14:43 --> URI Class Initialized
INFO - 2021-06-03 03:14:43 --> Router Class Initialized
INFO - 2021-06-03 03:14:43 --> Output Class Initialized
INFO - 2021-06-03 03:14:43 --> Security Class Initialized
DEBUG - 2021-06-03 03:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:14:43 --> Input Class Initialized
INFO - 2021-06-03 03:14:43 --> Language Class Initialized
INFO - 2021-06-03 03:14:43 --> Language Class Initialized
INFO - 2021-06-03 03:14:43 --> Config Class Initialized
INFO - 2021-06-03 03:14:43 --> Loader Class Initialized
INFO - 2021-06-03 03:14:43 --> Helper loaded: url_helper
INFO - 2021-06-03 03:14:43 --> Helper loaded: file_helper
INFO - 2021-06-03 03:14:43 --> Helper loaded: form_helper
INFO - 2021-06-03 03:14:43 --> Helper loaded: my_helper
INFO - 2021-06-03 03:14:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:14:43 --> Controller Class Initialized
INFO - 2021-06-03 03:14:43 --> Final output sent to browser
DEBUG - 2021-06-03 03:14:43 --> Total execution time: 0.1004
INFO - 2021-06-03 03:14:47 --> Config Class Initialized
INFO - 2021-06-03 03:14:47 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:14:47 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:14:47 --> Utf8 Class Initialized
INFO - 2021-06-03 03:14:47 --> URI Class Initialized
INFO - 2021-06-03 03:14:47 --> Router Class Initialized
INFO - 2021-06-03 03:14:47 --> Output Class Initialized
INFO - 2021-06-03 03:14:47 --> Security Class Initialized
DEBUG - 2021-06-03 03:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:14:47 --> Input Class Initialized
INFO - 2021-06-03 03:14:47 --> Language Class Initialized
INFO - 2021-06-03 03:14:47 --> Language Class Initialized
INFO - 2021-06-03 03:14:47 --> Config Class Initialized
INFO - 2021-06-03 03:14:47 --> Loader Class Initialized
INFO - 2021-06-03 03:14:47 --> Helper loaded: url_helper
INFO - 2021-06-03 03:14:47 --> Helper loaded: file_helper
INFO - 2021-06-03 03:14:47 --> Helper loaded: form_helper
INFO - 2021-06-03 03:14:47 --> Helper loaded: my_helper
INFO - 2021-06-03 03:14:47 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:14:47 --> Controller Class Initialized
INFO - 2021-06-03 03:14:47 --> Final output sent to browser
DEBUG - 2021-06-03 03:14:47 --> Total execution time: 0.2500
INFO - 2021-06-03 03:14:53 --> Config Class Initialized
INFO - 2021-06-03 03:14:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:14:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:14:53 --> Utf8 Class Initialized
INFO - 2021-06-03 03:14:53 --> URI Class Initialized
INFO - 2021-06-03 03:14:53 --> Router Class Initialized
INFO - 2021-06-03 03:14:53 --> Output Class Initialized
INFO - 2021-06-03 03:14:53 --> Security Class Initialized
DEBUG - 2021-06-03 03:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:14:53 --> Input Class Initialized
INFO - 2021-06-03 03:14:53 --> Language Class Initialized
INFO - 2021-06-03 03:14:53 --> Language Class Initialized
INFO - 2021-06-03 03:14:53 --> Config Class Initialized
INFO - 2021-06-03 03:14:53 --> Loader Class Initialized
INFO - 2021-06-03 03:14:53 --> Helper loaded: url_helper
INFO - 2021-06-03 03:14:53 --> Helper loaded: file_helper
INFO - 2021-06-03 03:14:53 --> Helper loaded: form_helper
INFO - 2021-06-03 03:14:53 --> Helper loaded: my_helper
INFO - 2021-06-03 03:14:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:14:53 --> Controller Class Initialized
INFO - 2021-06-03 03:14:53 --> Final output sent to browser
DEBUG - 2021-06-03 03:14:53 --> Total execution time: 0.1273
INFO - 2021-06-03 03:14:56 --> Config Class Initialized
INFO - 2021-06-03 03:14:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:14:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:14:56 --> Utf8 Class Initialized
INFO - 2021-06-03 03:14:56 --> URI Class Initialized
INFO - 2021-06-03 03:14:56 --> Router Class Initialized
INFO - 2021-06-03 03:14:56 --> Output Class Initialized
INFO - 2021-06-03 03:14:56 --> Security Class Initialized
DEBUG - 2021-06-03 03:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:14:56 --> Input Class Initialized
INFO - 2021-06-03 03:14:56 --> Language Class Initialized
INFO - 2021-06-03 03:14:56 --> Language Class Initialized
INFO - 2021-06-03 03:14:56 --> Config Class Initialized
INFO - 2021-06-03 03:14:56 --> Loader Class Initialized
INFO - 2021-06-03 03:14:56 --> Helper loaded: url_helper
INFO - 2021-06-03 03:14:56 --> Helper loaded: file_helper
INFO - 2021-06-03 03:14:56 --> Helper loaded: form_helper
INFO - 2021-06-03 03:14:56 --> Helper loaded: my_helper
INFO - 2021-06-03 03:14:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:14:56 --> Controller Class Initialized
INFO - 2021-06-03 03:14:56 --> Final output sent to browser
DEBUG - 2021-06-03 03:14:56 --> Total execution time: 0.2203
INFO - 2021-06-03 03:14:58 --> Config Class Initialized
INFO - 2021-06-03 03:14:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:14:59 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:14:59 --> Utf8 Class Initialized
INFO - 2021-06-03 03:14:59 --> URI Class Initialized
INFO - 2021-06-03 03:14:59 --> Router Class Initialized
INFO - 2021-06-03 03:14:59 --> Output Class Initialized
INFO - 2021-06-03 03:14:59 --> Security Class Initialized
DEBUG - 2021-06-03 03:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:14:59 --> Input Class Initialized
INFO - 2021-06-03 03:14:59 --> Language Class Initialized
INFO - 2021-06-03 03:14:59 --> Language Class Initialized
INFO - 2021-06-03 03:14:59 --> Config Class Initialized
INFO - 2021-06-03 03:14:59 --> Loader Class Initialized
INFO - 2021-06-03 03:14:59 --> Helper loaded: url_helper
INFO - 2021-06-03 03:14:59 --> Helper loaded: file_helper
INFO - 2021-06-03 03:14:59 --> Helper loaded: form_helper
INFO - 2021-06-03 03:14:59 --> Helper loaded: my_helper
INFO - 2021-06-03 03:14:59 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:14:59 --> Controller Class Initialized
DEBUG - 2021-06-03 03:14:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 03:14:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:14:59 --> Final output sent to browser
DEBUG - 2021-06-03 03:14:59 --> Total execution time: 0.1395
INFO - 2021-06-03 03:15:00 --> Config Class Initialized
INFO - 2021-06-03 03:15:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:15:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:15:00 --> Utf8 Class Initialized
INFO - 2021-06-03 03:15:00 --> URI Class Initialized
INFO - 2021-06-03 03:15:00 --> Router Class Initialized
INFO - 2021-06-03 03:15:00 --> Output Class Initialized
INFO - 2021-06-03 03:15:00 --> Security Class Initialized
DEBUG - 2021-06-03 03:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:15:00 --> Input Class Initialized
INFO - 2021-06-03 03:15:00 --> Language Class Initialized
INFO - 2021-06-03 03:15:00 --> Language Class Initialized
INFO - 2021-06-03 03:15:00 --> Config Class Initialized
INFO - 2021-06-03 03:15:00 --> Loader Class Initialized
INFO - 2021-06-03 03:15:00 --> Helper loaded: url_helper
INFO - 2021-06-03 03:15:00 --> Helper loaded: file_helper
INFO - 2021-06-03 03:15:00 --> Helper loaded: form_helper
INFO - 2021-06-03 03:15:00 --> Helper loaded: my_helper
INFO - 2021-06-03 03:15:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:15:00 --> Controller Class Initialized
DEBUG - 2021-06-03 03:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:15:00 --> Final output sent to browser
DEBUG - 2021-06-03 03:15:00 --> Total execution time: 0.1442
INFO - 2021-06-03 03:15:02 --> Config Class Initialized
INFO - 2021-06-03 03:15:02 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:15:02 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:15:02 --> Utf8 Class Initialized
INFO - 2021-06-03 03:15:02 --> URI Class Initialized
INFO - 2021-06-03 03:15:02 --> Router Class Initialized
INFO - 2021-06-03 03:15:02 --> Output Class Initialized
INFO - 2021-06-03 03:15:02 --> Security Class Initialized
DEBUG - 2021-06-03 03:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:15:02 --> Input Class Initialized
INFO - 2021-06-03 03:15:02 --> Language Class Initialized
INFO - 2021-06-03 03:15:02 --> Language Class Initialized
INFO - 2021-06-03 03:15:02 --> Config Class Initialized
INFO - 2021-06-03 03:15:02 --> Loader Class Initialized
INFO - 2021-06-03 03:15:02 --> Helper loaded: url_helper
INFO - 2021-06-03 03:15:02 --> Helper loaded: file_helper
INFO - 2021-06-03 03:15:02 --> Helper loaded: form_helper
INFO - 2021-06-03 03:15:02 --> Helper loaded: my_helper
INFO - 2021-06-03 03:15:02 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:15:02 --> Controller Class Initialized
DEBUG - 2021-06-03 03:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 03:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:15:02 --> Final output sent to browser
DEBUG - 2021-06-03 03:15:02 --> Total execution time: 0.2645
INFO - 2021-06-03 03:15:12 --> Config Class Initialized
INFO - 2021-06-03 03:15:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:15:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:15:12 --> Utf8 Class Initialized
INFO - 2021-06-03 03:15:12 --> URI Class Initialized
INFO - 2021-06-03 03:15:12 --> Router Class Initialized
INFO - 2021-06-03 03:15:12 --> Output Class Initialized
INFO - 2021-06-03 03:15:12 --> Security Class Initialized
DEBUG - 2021-06-03 03:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:15:12 --> Input Class Initialized
INFO - 2021-06-03 03:15:12 --> Language Class Initialized
INFO - 2021-06-03 03:15:12 --> Language Class Initialized
INFO - 2021-06-03 03:15:12 --> Config Class Initialized
INFO - 2021-06-03 03:15:12 --> Loader Class Initialized
INFO - 2021-06-03 03:15:12 --> Helper loaded: url_helper
INFO - 2021-06-03 03:15:12 --> Helper loaded: file_helper
INFO - 2021-06-03 03:15:12 --> Helper loaded: form_helper
INFO - 2021-06-03 03:15:12 --> Helper loaded: my_helper
INFO - 2021-06-03 03:15:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:15:12 --> Controller Class Initialized
INFO - 2021-06-03 03:15:12 --> Final output sent to browser
DEBUG - 2021-06-03 03:15:12 --> Total execution time: 0.2269
INFO - 2021-06-03 03:15:21 --> Config Class Initialized
INFO - 2021-06-03 03:15:21 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:15:21 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:15:21 --> Utf8 Class Initialized
INFO - 2021-06-03 03:15:21 --> URI Class Initialized
INFO - 2021-06-03 03:15:21 --> Router Class Initialized
INFO - 2021-06-03 03:15:21 --> Output Class Initialized
INFO - 2021-06-03 03:15:21 --> Security Class Initialized
DEBUG - 2021-06-03 03:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:15:21 --> Input Class Initialized
INFO - 2021-06-03 03:15:21 --> Language Class Initialized
INFO - 2021-06-03 03:15:21 --> Language Class Initialized
INFO - 2021-06-03 03:15:21 --> Config Class Initialized
INFO - 2021-06-03 03:15:21 --> Loader Class Initialized
INFO - 2021-06-03 03:15:21 --> Helper loaded: url_helper
INFO - 2021-06-03 03:15:21 --> Helper loaded: file_helper
INFO - 2021-06-03 03:15:21 --> Helper loaded: form_helper
INFO - 2021-06-03 03:15:21 --> Helper loaded: my_helper
INFO - 2021-06-03 03:15:21 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:15:21 --> Controller Class Initialized
DEBUG - 2021-06-03 03:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:15:21 --> Final output sent to browser
DEBUG - 2021-06-03 03:15:21 --> Total execution time: 0.1486
INFO - 2021-06-03 03:15:23 --> Config Class Initialized
INFO - 2021-06-03 03:15:23 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:15:23 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:15:23 --> Utf8 Class Initialized
INFO - 2021-06-03 03:15:23 --> URI Class Initialized
INFO - 2021-06-03 03:15:23 --> Router Class Initialized
INFO - 2021-06-03 03:15:23 --> Output Class Initialized
INFO - 2021-06-03 03:15:23 --> Security Class Initialized
DEBUG - 2021-06-03 03:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:15:23 --> Input Class Initialized
INFO - 2021-06-03 03:15:23 --> Language Class Initialized
INFO - 2021-06-03 03:15:23 --> Language Class Initialized
INFO - 2021-06-03 03:15:23 --> Config Class Initialized
INFO - 2021-06-03 03:15:23 --> Loader Class Initialized
INFO - 2021-06-03 03:15:23 --> Helper loaded: url_helper
INFO - 2021-06-03 03:15:23 --> Helper loaded: file_helper
INFO - 2021-06-03 03:15:23 --> Helper loaded: form_helper
INFO - 2021-06-03 03:15:23 --> Helper loaded: my_helper
INFO - 2021-06-03 03:15:23 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:15:23 --> Controller Class Initialized
DEBUG - 2021-06-03 03:15:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 03:15:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:15:23 --> Final output sent to browser
DEBUG - 2021-06-03 03:15:23 --> Total execution time: 0.1581
INFO - 2021-06-03 03:15:26 --> Config Class Initialized
INFO - 2021-06-03 03:15:26 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:15:26 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:15:26 --> Utf8 Class Initialized
INFO - 2021-06-03 03:15:26 --> URI Class Initialized
INFO - 2021-06-03 03:15:26 --> Router Class Initialized
INFO - 2021-06-03 03:15:26 --> Output Class Initialized
INFO - 2021-06-03 03:15:26 --> Security Class Initialized
DEBUG - 2021-06-03 03:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:15:26 --> Input Class Initialized
INFO - 2021-06-03 03:15:26 --> Language Class Initialized
INFO - 2021-06-03 03:15:26 --> Language Class Initialized
INFO - 2021-06-03 03:15:26 --> Config Class Initialized
INFO - 2021-06-03 03:15:26 --> Loader Class Initialized
INFO - 2021-06-03 03:15:26 --> Helper loaded: url_helper
INFO - 2021-06-03 03:15:26 --> Helper loaded: file_helper
INFO - 2021-06-03 03:15:26 --> Helper loaded: form_helper
INFO - 2021-06-03 03:15:26 --> Helper loaded: my_helper
INFO - 2021-06-03 03:15:26 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:15:26 --> Controller Class Initialized
DEBUG - 2021-06-03 03:15:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-06-03 03:15:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:15:26 --> Final output sent to browser
DEBUG - 2021-06-03 03:15:26 --> Total execution time: 0.1223
INFO - 2021-06-03 03:15:27 --> Config Class Initialized
INFO - 2021-06-03 03:15:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:15:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:15:27 --> Utf8 Class Initialized
INFO - 2021-06-03 03:15:27 --> URI Class Initialized
INFO - 2021-06-03 03:15:27 --> Router Class Initialized
INFO - 2021-06-03 03:15:27 --> Output Class Initialized
INFO - 2021-06-03 03:15:27 --> Security Class Initialized
DEBUG - 2021-06-03 03:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:15:27 --> Input Class Initialized
INFO - 2021-06-03 03:15:27 --> Language Class Initialized
INFO - 2021-06-03 03:15:27 --> Language Class Initialized
INFO - 2021-06-03 03:15:27 --> Config Class Initialized
INFO - 2021-06-03 03:15:27 --> Loader Class Initialized
INFO - 2021-06-03 03:15:27 --> Helper loaded: url_helper
INFO - 2021-06-03 03:15:27 --> Helper loaded: file_helper
INFO - 2021-06-03 03:15:27 --> Helper loaded: form_helper
INFO - 2021-06-03 03:15:27 --> Helper loaded: my_helper
INFO - 2021-06-03 03:15:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:15:27 --> Controller Class Initialized
DEBUG - 2021-06-03 03:15:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 03:15:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:15:27 --> Final output sent to browser
DEBUG - 2021-06-03 03:15:27 --> Total execution time: 0.1631
INFO - 2021-06-03 03:15:30 --> Config Class Initialized
INFO - 2021-06-03 03:15:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:15:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:15:30 --> Utf8 Class Initialized
INFO - 2021-06-03 03:15:30 --> URI Class Initialized
INFO - 2021-06-03 03:15:30 --> Router Class Initialized
INFO - 2021-06-03 03:15:30 --> Output Class Initialized
INFO - 2021-06-03 03:15:30 --> Security Class Initialized
DEBUG - 2021-06-03 03:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:15:30 --> Input Class Initialized
INFO - 2021-06-03 03:15:30 --> Language Class Initialized
INFO - 2021-06-03 03:15:30 --> Language Class Initialized
INFO - 2021-06-03 03:15:30 --> Config Class Initialized
INFO - 2021-06-03 03:15:30 --> Loader Class Initialized
INFO - 2021-06-03 03:15:30 --> Helper loaded: url_helper
INFO - 2021-06-03 03:15:30 --> Helper loaded: file_helper
INFO - 2021-06-03 03:15:30 --> Helper loaded: form_helper
INFO - 2021-06-03 03:15:30 --> Helper loaded: my_helper
INFO - 2021-06-03 03:15:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:15:30 --> Controller Class Initialized
DEBUG - 2021-06-03 03:15:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:15:30 --> Final output sent to browser
DEBUG - 2021-06-03 03:15:30 --> Total execution time: 0.2051
INFO - 2021-06-03 03:15:32 --> Config Class Initialized
INFO - 2021-06-03 03:15:32 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:15:32 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:15:32 --> Utf8 Class Initialized
INFO - 2021-06-03 03:15:32 --> URI Class Initialized
INFO - 2021-06-03 03:15:32 --> Router Class Initialized
INFO - 2021-06-03 03:15:32 --> Output Class Initialized
INFO - 2021-06-03 03:15:32 --> Security Class Initialized
DEBUG - 2021-06-03 03:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:15:32 --> Input Class Initialized
INFO - 2021-06-03 03:15:32 --> Language Class Initialized
INFO - 2021-06-03 03:15:32 --> Language Class Initialized
INFO - 2021-06-03 03:15:32 --> Config Class Initialized
INFO - 2021-06-03 03:15:32 --> Loader Class Initialized
INFO - 2021-06-03 03:15:32 --> Helper loaded: url_helper
INFO - 2021-06-03 03:15:32 --> Helper loaded: file_helper
INFO - 2021-06-03 03:15:32 --> Helper loaded: form_helper
INFO - 2021-06-03 03:15:32 --> Helper loaded: my_helper
INFO - 2021-06-03 03:15:32 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:15:32 --> Controller Class Initialized
DEBUG - 2021-06-03 03:15:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:15:32 --> Final output sent to browser
DEBUG - 2021-06-03 03:15:32 --> Total execution time: 0.1774
INFO - 2021-06-03 03:16:42 --> Config Class Initialized
INFO - 2021-06-03 03:16:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:16:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:16:42 --> Utf8 Class Initialized
INFO - 2021-06-03 03:16:42 --> URI Class Initialized
INFO - 2021-06-03 03:16:42 --> Router Class Initialized
INFO - 2021-06-03 03:16:42 --> Output Class Initialized
INFO - 2021-06-03 03:16:42 --> Security Class Initialized
DEBUG - 2021-06-03 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:16:42 --> Input Class Initialized
INFO - 2021-06-03 03:16:42 --> Language Class Initialized
INFO - 2021-06-03 03:16:42 --> Language Class Initialized
INFO - 2021-06-03 03:16:42 --> Config Class Initialized
INFO - 2021-06-03 03:16:42 --> Loader Class Initialized
INFO - 2021-06-03 03:16:42 --> Helper loaded: url_helper
INFO - 2021-06-03 03:16:42 --> Helper loaded: file_helper
INFO - 2021-06-03 03:16:42 --> Helper loaded: form_helper
INFO - 2021-06-03 03:16:42 --> Helper loaded: my_helper
INFO - 2021-06-03 03:16:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:16:42 --> Controller Class Initialized
DEBUG - 2021-06-03 03:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:16:42 --> Final output sent to browser
DEBUG - 2021-06-03 03:16:42 --> Total execution time: 0.1466
INFO - 2021-06-03 03:16:43 --> Config Class Initialized
INFO - 2021-06-03 03:16:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:16:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:16:43 --> Utf8 Class Initialized
INFO - 2021-06-03 03:16:43 --> URI Class Initialized
INFO - 2021-06-03 03:16:43 --> Router Class Initialized
INFO - 2021-06-03 03:16:43 --> Output Class Initialized
INFO - 2021-06-03 03:16:43 --> Security Class Initialized
DEBUG - 2021-06-03 03:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:16:43 --> Input Class Initialized
INFO - 2021-06-03 03:16:43 --> Language Class Initialized
INFO - 2021-06-03 03:16:43 --> Language Class Initialized
INFO - 2021-06-03 03:16:43 --> Config Class Initialized
INFO - 2021-06-03 03:16:43 --> Loader Class Initialized
INFO - 2021-06-03 03:16:43 --> Helper loaded: url_helper
INFO - 2021-06-03 03:16:43 --> Helper loaded: file_helper
INFO - 2021-06-03 03:16:43 --> Helper loaded: form_helper
INFO - 2021-06-03 03:16:43 --> Helper loaded: my_helper
INFO - 2021-06-03 03:16:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:16:43 --> Controller Class Initialized
INFO - 2021-06-03 03:16:43 --> Final output sent to browser
DEBUG - 2021-06-03 03:16:43 --> Total execution time: 0.0835
INFO - 2021-06-03 03:16:50 --> Config Class Initialized
INFO - 2021-06-03 03:16:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:16:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:16:50 --> Utf8 Class Initialized
INFO - 2021-06-03 03:16:50 --> URI Class Initialized
INFO - 2021-06-03 03:16:50 --> Router Class Initialized
INFO - 2021-06-03 03:16:50 --> Output Class Initialized
INFO - 2021-06-03 03:16:50 --> Security Class Initialized
DEBUG - 2021-06-03 03:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:16:50 --> Input Class Initialized
INFO - 2021-06-03 03:16:50 --> Language Class Initialized
INFO - 2021-06-03 03:16:50 --> Language Class Initialized
INFO - 2021-06-03 03:16:50 --> Config Class Initialized
INFO - 2021-06-03 03:16:50 --> Loader Class Initialized
INFO - 2021-06-03 03:16:50 --> Helper loaded: url_helper
INFO - 2021-06-03 03:16:50 --> Helper loaded: file_helper
INFO - 2021-06-03 03:16:50 --> Helper loaded: form_helper
INFO - 2021-06-03 03:16:50 --> Helper loaded: my_helper
INFO - 2021-06-03 03:16:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:16:50 --> Controller Class Initialized
INFO - 2021-06-03 03:16:50 --> Final output sent to browser
DEBUG - 2021-06-03 03:16:50 --> Total execution time: 0.1255
INFO - 2021-06-03 03:16:56 --> Config Class Initialized
INFO - 2021-06-03 03:16:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:16:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:16:56 --> Utf8 Class Initialized
INFO - 2021-06-03 03:16:56 --> URI Class Initialized
INFO - 2021-06-03 03:16:56 --> Router Class Initialized
INFO - 2021-06-03 03:16:56 --> Output Class Initialized
INFO - 2021-06-03 03:16:56 --> Security Class Initialized
DEBUG - 2021-06-03 03:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:16:56 --> Input Class Initialized
INFO - 2021-06-03 03:16:56 --> Language Class Initialized
INFO - 2021-06-03 03:16:56 --> Language Class Initialized
INFO - 2021-06-03 03:16:56 --> Config Class Initialized
INFO - 2021-06-03 03:16:56 --> Loader Class Initialized
INFO - 2021-06-03 03:16:56 --> Helper loaded: url_helper
INFO - 2021-06-03 03:16:56 --> Helper loaded: file_helper
INFO - 2021-06-03 03:16:56 --> Helper loaded: form_helper
INFO - 2021-06-03 03:16:56 --> Helper loaded: my_helper
INFO - 2021-06-03 03:16:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:16:56 --> Controller Class Initialized
INFO - 2021-06-03 03:16:56 --> Final output sent to browser
DEBUG - 2021-06-03 03:16:56 --> Total execution time: 0.2359
INFO - 2021-06-03 03:16:58 --> Config Class Initialized
INFO - 2021-06-03 03:16:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:16:58 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:16:58 --> Utf8 Class Initialized
INFO - 2021-06-03 03:16:58 --> URI Class Initialized
INFO - 2021-06-03 03:16:58 --> Router Class Initialized
INFO - 2021-06-03 03:16:58 --> Output Class Initialized
INFO - 2021-06-03 03:16:58 --> Security Class Initialized
DEBUG - 2021-06-03 03:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:16:58 --> Input Class Initialized
INFO - 2021-06-03 03:16:58 --> Language Class Initialized
INFO - 2021-06-03 03:16:58 --> Language Class Initialized
INFO - 2021-06-03 03:16:58 --> Config Class Initialized
INFO - 2021-06-03 03:16:58 --> Loader Class Initialized
INFO - 2021-06-03 03:16:58 --> Helper loaded: url_helper
INFO - 2021-06-03 03:16:58 --> Helper loaded: file_helper
INFO - 2021-06-03 03:16:58 --> Helper loaded: form_helper
INFO - 2021-06-03 03:16:58 --> Helper loaded: my_helper
INFO - 2021-06-03 03:16:58 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:16:58 --> Controller Class Initialized
INFO - 2021-06-03 03:16:58 --> Final output sent to browser
DEBUG - 2021-06-03 03:16:58 --> Total execution time: 0.1287
INFO - 2021-06-03 03:17:04 --> Config Class Initialized
INFO - 2021-06-03 03:17:04 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:17:04 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:17:04 --> Utf8 Class Initialized
INFO - 2021-06-03 03:17:04 --> URI Class Initialized
INFO - 2021-06-03 03:17:04 --> Router Class Initialized
INFO - 2021-06-03 03:17:04 --> Output Class Initialized
INFO - 2021-06-03 03:17:04 --> Security Class Initialized
DEBUG - 2021-06-03 03:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:17:04 --> Input Class Initialized
INFO - 2021-06-03 03:17:04 --> Language Class Initialized
INFO - 2021-06-03 03:17:04 --> Language Class Initialized
INFO - 2021-06-03 03:17:04 --> Config Class Initialized
INFO - 2021-06-03 03:17:04 --> Loader Class Initialized
INFO - 2021-06-03 03:17:04 --> Helper loaded: url_helper
INFO - 2021-06-03 03:17:04 --> Helper loaded: file_helper
INFO - 2021-06-03 03:17:04 --> Helper loaded: form_helper
INFO - 2021-06-03 03:17:04 --> Helper loaded: my_helper
INFO - 2021-06-03 03:17:04 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:17:04 --> Controller Class Initialized
INFO - 2021-06-03 03:17:04 --> Final output sent to browser
DEBUG - 2021-06-03 03:17:04 --> Total execution time: 0.2523
INFO - 2021-06-03 03:17:06 --> Config Class Initialized
INFO - 2021-06-03 03:17:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:17:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:17:06 --> Utf8 Class Initialized
INFO - 2021-06-03 03:17:06 --> URI Class Initialized
INFO - 2021-06-03 03:17:06 --> Router Class Initialized
INFO - 2021-06-03 03:17:06 --> Output Class Initialized
INFO - 2021-06-03 03:17:06 --> Security Class Initialized
DEBUG - 2021-06-03 03:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:17:06 --> Input Class Initialized
INFO - 2021-06-03 03:17:06 --> Language Class Initialized
INFO - 2021-06-03 03:17:06 --> Language Class Initialized
INFO - 2021-06-03 03:17:06 --> Config Class Initialized
INFO - 2021-06-03 03:17:06 --> Loader Class Initialized
INFO - 2021-06-03 03:17:06 --> Helper loaded: url_helper
INFO - 2021-06-03 03:17:06 --> Helper loaded: file_helper
INFO - 2021-06-03 03:17:06 --> Helper loaded: form_helper
INFO - 2021-06-03 03:17:06 --> Helper loaded: my_helper
INFO - 2021-06-03 03:17:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:17:06 --> Controller Class Initialized
DEBUG - 2021-06-03 03:17:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:17:06 --> Final output sent to browser
DEBUG - 2021-06-03 03:17:06 --> Total execution time: 0.1852
INFO - 2021-06-03 03:17:07 --> Config Class Initialized
INFO - 2021-06-03 03:17:07 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:17:07 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:17:07 --> Utf8 Class Initialized
INFO - 2021-06-03 03:17:07 --> URI Class Initialized
INFO - 2021-06-03 03:17:07 --> Router Class Initialized
INFO - 2021-06-03 03:17:07 --> Output Class Initialized
INFO - 2021-06-03 03:17:07 --> Security Class Initialized
DEBUG - 2021-06-03 03:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:17:07 --> Input Class Initialized
INFO - 2021-06-03 03:17:07 --> Language Class Initialized
INFO - 2021-06-03 03:17:07 --> Language Class Initialized
INFO - 2021-06-03 03:17:07 --> Config Class Initialized
INFO - 2021-06-03 03:17:07 --> Loader Class Initialized
INFO - 2021-06-03 03:17:07 --> Helper loaded: url_helper
INFO - 2021-06-03 03:17:07 --> Helper loaded: file_helper
INFO - 2021-06-03 03:17:07 --> Helper loaded: form_helper
INFO - 2021-06-03 03:17:07 --> Helper loaded: my_helper
INFO - 2021-06-03 03:17:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:17:07 --> Controller Class Initialized
DEBUG - 2021-06-03 03:17:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:17:07 --> Final output sent to browser
DEBUG - 2021-06-03 03:17:07 --> Total execution time: 0.1664
INFO - 2021-06-03 03:21:07 --> Config Class Initialized
INFO - 2021-06-03 03:21:07 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:21:07 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:21:07 --> Utf8 Class Initialized
INFO - 2021-06-03 03:21:07 --> URI Class Initialized
INFO - 2021-06-03 03:21:07 --> Router Class Initialized
INFO - 2021-06-03 03:21:07 --> Output Class Initialized
INFO - 2021-06-03 03:21:07 --> Security Class Initialized
DEBUG - 2021-06-03 03:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:21:07 --> Input Class Initialized
INFO - 2021-06-03 03:21:07 --> Language Class Initialized
INFO - 2021-06-03 03:21:07 --> Language Class Initialized
INFO - 2021-06-03 03:21:07 --> Config Class Initialized
INFO - 2021-06-03 03:21:07 --> Loader Class Initialized
INFO - 2021-06-03 03:21:07 --> Helper loaded: url_helper
INFO - 2021-06-03 03:21:07 --> Helper loaded: file_helper
INFO - 2021-06-03 03:21:07 --> Helper loaded: form_helper
INFO - 2021-06-03 03:21:07 --> Helper loaded: my_helper
INFO - 2021-06-03 03:21:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:21:07 --> Controller Class Initialized
DEBUG - 2021-06-03 03:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 03:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:21:07 --> Final output sent to browser
DEBUG - 2021-06-03 03:21:07 --> Total execution time: 0.1065
INFO - 2021-06-03 03:21:09 --> Config Class Initialized
INFO - 2021-06-03 03:21:09 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:21:09 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:21:09 --> Utf8 Class Initialized
INFO - 2021-06-03 03:21:09 --> URI Class Initialized
INFO - 2021-06-03 03:21:09 --> Router Class Initialized
INFO - 2021-06-03 03:21:09 --> Output Class Initialized
INFO - 2021-06-03 03:21:09 --> Security Class Initialized
DEBUG - 2021-06-03 03:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:21:09 --> Input Class Initialized
INFO - 2021-06-03 03:21:09 --> Language Class Initialized
INFO - 2021-06-03 03:21:09 --> Language Class Initialized
INFO - 2021-06-03 03:21:09 --> Config Class Initialized
INFO - 2021-06-03 03:21:09 --> Loader Class Initialized
INFO - 2021-06-03 03:21:09 --> Helper loaded: url_helper
INFO - 2021-06-03 03:21:09 --> Helper loaded: file_helper
INFO - 2021-06-03 03:21:09 --> Helper loaded: form_helper
INFO - 2021-06-03 03:21:09 --> Helper loaded: my_helper
INFO - 2021-06-03 03:21:09 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:21:09 --> Controller Class Initialized
DEBUG - 2021-06-03 03:21:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:21:09 --> Final output sent to browser
DEBUG - 2021-06-03 03:21:09 --> Total execution time: 0.1705
INFO - 2021-06-03 03:23:19 --> Config Class Initialized
INFO - 2021-06-03 03:23:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:19 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:19 --> URI Class Initialized
INFO - 2021-06-03 03:23:20 --> Router Class Initialized
INFO - 2021-06-03 03:23:20 --> Output Class Initialized
INFO - 2021-06-03 03:23:20 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:20 --> Input Class Initialized
INFO - 2021-06-03 03:23:20 --> Language Class Initialized
INFO - 2021-06-03 03:23:20 --> Language Class Initialized
INFO - 2021-06-03 03:23:20 --> Config Class Initialized
INFO - 2021-06-03 03:23:20 --> Loader Class Initialized
INFO - 2021-06-03 03:23:20 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:20 --> Helper loaded: file_helper
INFO - 2021-06-03 03:23:20 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:20 --> Helper loaded: my_helper
INFO - 2021-06-03 03:23:21 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:21 --> Controller Class Initialized
DEBUG - 2021-06-03 03:23:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 03:23:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:23:21 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:21 --> Total execution time: 2.3451
INFO - 2021-06-03 03:23:24 --> Config Class Initialized
INFO - 2021-06-03 03:23:24 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:24 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:24 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:24 --> URI Class Initialized
INFO - 2021-06-03 03:23:24 --> Router Class Initialized
INFO - 2021-06-03 03:23:24 --> Output Class Initialized
INFO - 2021-06-03 03:23:24 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:24 --> Input Class Initialized
INFO - 2021-06-03 03:23:24 --> Language Class Initialized
INFO - 2021-06-03 03:23:24 --> Language Class Initialized
INFO - 2021-06-03 03:23:24 --> Config Class Initialized
INFO - 2021-06-03 03:23:24 --> Loader Class Initialized
INFO - 2021-06-03 03:23:24 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:24 --> Helper loaded: file_helper
INFO - 2021-06-03 03:23:24 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:24 --> Helper loaded: my_helper
INFO - 2021-06-03 03:23:24 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:24 --> Controller Class Initialized
DEBUG - 2021-06-03 03:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:23:24 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:24 --> Total execution time: 0.1998
INFO - 2021-06-03 03:23:28 --> Config Class Initialized
INFO - 2021-06-03 03:23:28 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:23:28 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:23:28 --> Utf8 Class Initialized
INFO - 2021-06-03 03:23:28 --> URI Class Initialized
INFO - 2021-06-03 03:23:28 --> Router Class Initialized
INFO - 2021-06-03 03:23:28 --> Output Class Initialized
INFO - 2021-06-03 03:23:28 --> Security Class Initialized
DEBUG - 2021-06-03 03:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:23:28 --> Input Class Initialized
INFO - 2021-06-03 03:23:28 --> Language Class Initialized
INFO - 2021-06-03 03:23:28 --> Language Class Initialized
INFO - 2021-06-03 03:23:28 --> Config Class Initialized
INFO - 2021-06-03 03:23:28 --> Loader Class Initialized
INFO - 2021-06-03 03:23:28 --> Helper loaded: url_helper
INFO - 2021-06-03 03:23:28 --> Helper loaded: file_helper
INFO - 2021-06-03 03:23:28 --> Helper loaded: form_helper
INFO - 2021-06-03 03:23:28 --> Helper loaded: my_helper
INFO - 2021-06-03 03:23:28 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:23:28 --> Controller Class Initialized
DEBUG - 2021-06-03 03:23:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:23:28 --> Final output sent to browser
DEBUG - 2021-06-03 03:23:28 --> Total execution time: 0.1826
INFO - 2021-06-03 03:24:17 --> Config Class Initialized
INFO - 2021-06-03 03:24:17 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:24:17 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:24:17 --> Utf8 Class Initialized
INFO - 2021-06-03 03:24:17 --> URI Class Initialized
INFO - 2021-06-03 03:24:17 --> Router Class Initialized
INFO - 2021-06-03 03:24:17 --> Output Class Initialized
INFO - 2021-06-03 03:24:17 --> Security Class Initialized
DEBUG - 2021-06-03 03:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:24:17 --> Input Class Initialized
INFO - 2021-06-03 03:24:17 --> Language Class Initialized
INFO - 2021-06-03 03:24:17 --> Language Class Initialized
INFO - 2021-06-03 03:24:17 --> Config Class Initialized
INFO - 2021-06-03 03:24:17 --> Loader Class Initialized
INFO - 2021-06-03 03:24:17 --> Helper loaded: url_helper
INFO - 2021-06-03 03:24:17 --> Helper loaded: file_helper
INFO - 2021-06-03 03:24:17 --> Helper loaded: form_helper
INFO - 2021-06-03 03:24:17 --> Helper loaded: my_helper
INFO - 2021-06-03 03:24:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:24:17 --> Controller Class Initialized
DEBUG - 2021-06-03 03:24:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 03:24:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:24:17 --> Final output sent to browser
DEBUG - 2021-06-03 03:24:17 --> Total execution time: 0.3021
INFO - 2021-06-03 03:24:59 --> Config Class Initialized
INFO - 2021-06-03 03:24:59 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:24:59 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:24:59 --> Utf8 Class Initialized
INFO - 2021-06-03 03:24:59 --> URI Class Initialized
INFO - 2021-06-03 03:24:59 --> Router Class Initialized
INFO - 2021-06-03 03:24:59 --> Output Class Initialized
INFO - 2021-06-03 03:24:59 --> Security Class Initialized
DEBUG - 2021-06-03 03:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:24:59 --> Input Class Initialized
INFO - 2021-06-03 03:24:59 --> Language Class Initialized
INFO - 2021-06-03 03:24:59 --> Language Class Initialized
INFO - 2021-06-03 03:24:59 --> Config Class Initialized
INFO - 2021-06-03 03:24:59 --> Loader Class Initialized
INFO - 2021-06-03 03:24:59 --> Helper loaded: url_helper
INFO - 2021-06-03 03:24:59 --> Helper loaded: file_helper
INFO - 2021-06-03 03:24:59 --> Helper loaded: form_helper
INFO - 2021-06-03 03:24:59 --> Helper loaded: my_helper
INFO - 2021-06-03 03:24:59 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:24:59 --> Controller Class Initialized
DEBUG - 2021-06-03 03:24:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:24:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:24:59 --> Final output sent to browser
DEBUG - 2021-06-03 03:24:59 --> Total execution time: 0.3588
INFO - 2021-06-03 03:25:00 --> Config Class Initialized
INFO - 2021-06-03 03:25:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:00 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:00 --> URI Class Initialized
INFO - 2021-06-03 03:25:00 --> Router Class Initialized
INFO - 2021-06-03 03:25:00 --> Output Class Initialized
INFO - 2021-06-03 03:25:00 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:00 --> Input Class Initialized
INFO - 2021-06-03 03:25:00 --> Language Class Initialized
INFO - 2021-06-03 03:25:00 --> Language Class Initialized
INFO - 2021-06-03 03:25:00 --> Config Class Initialized
INFO - 2021-06-03 03:25:00 --> Loader Class Initialized
INFO - 2021-06-03 03:25:00 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:00 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:00 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:00 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:01 --> Controller Class Initialized
INFO - 2021-06-03 03:25:01 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:01 --> Total execution time: 0.1381
INFO - 2021-06-03 03:25:02 --> Config Class Initialized
INFO - 2021-06-03 03:25:02 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:02 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:02 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:02 --> URI Class Initialized
INFO - 2021-06-03 03:25:02 --> Router Class Initialized
INFO - 2021-06-03 03:25:02 --> Output Class Initialized
INFO - 2021-06-03 03:25:02 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:02 --> Input Class Initialized
INFO - 2021-06-03 03:25:02 --> Language Class Initialized
INFO - 2021-06-03 03:25:02 --> Language Class Initialized
INFO - 2021-06-03 03:25:02 --> Config Class Initialized
INFO - 2021-06-03 03:25:02 --> Loader Class Initialized
INFO - 2021-06-03 03:25:02 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:02 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:02 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:02 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:02 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:02 --> Controller Class Initialized
INFO - 2021-06-03 03:25:02 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:02 --> Total execution time: 0.1644
INFO - 2021-06-03 03:25:04 --> Config Class Initialized
INFO - 2021-06-03 03:25:04 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:04 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:04 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:04 --> URI Class Initialized
INFO - 2021-06-03 03:25:04 --> Router Class Initialized
INFO - 2021-06-03 03:25:04 --> Output Class Initialized
INFO - 2021-06-03 03:25:04 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:04 --> Input Class Initialized
INFO - 2021-06-03 03:25:04 --> Language Class Initialized
INFO - 2021-06-03 03:25:04 --> Language Class Initialized
INFO - 2021-06-03 03:25:04 --> Config Class Initialized
INFO - 2021-06-03 03:25:04 --> Loader Class Initialized
INFO - 2021-06-03 03:25:04 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:04 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:04 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:04 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:04 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:04 --> Controller Class Initialized
INFO - 2021-06-03 03:25:04 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:04 --> Total execution time: 0.1587
INFO - 2021-06-03 03:25:05 --> Config Class Initialized
INFO - 2021-06-03 03:25:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:05 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:05 --> URI Class Initialized
INFO - 2021-06-03 03:25:05 --> Router Class Initialized
INFO - 2021-06-03 03:25:05 --> Output Class Initialized
INFO - 2021-06-03 03:25:05 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:05 --> Input Class Initialized
INFO - 2021-06-03 03:25:05 --> Language Class Initialized
INFO - 2021-06-03 03:25:05 --> Language Class Initialized
INFO - 2021-06-03 03:25:05 --> Config Class Initialized
INFO - 2021-06-03 03:25:05 --> Loader Class Initialized
INFO - 2021-06-03 03:25:05 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:05 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:05 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:05 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:05 --> Controller Class Initialized
INFO - 2021-06-03 03:25:05 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:05 --> Total execution time: 0.1619
INFO - 2021-06-03 03:25:18 --> Config Class Initialized
INFO - 2021-06-03 03:25:18 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:18 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:18 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:18 --> URI Class Initialized
INFO - 2021-06-03 03:25:18 --> Router Class Initialized
INFO - 2021-06-03 03:25:18 --> Output Class Initialized
INFO - 2021-06-03 03:25:18 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:18 --> Input Class Initialized
INFO - 2021-06-03 03:25:18 --> Language Class Initialized
INFO - 2021-06-03 03:25:18 --> Language Class Initialized
INFO - 2021-06-03 03:25:18 --> Config Class Initialized
INFO - 2021-06-03 03:25:18 --> Loader Class Initialized
INFO - 2021-06-03 03:25:18 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:18 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:18 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:18 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:18 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:18 --> Controller Class Initialized
INFO - 2021-06-03 03:25:18 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:18 --> Total execution time: 0.2170
INFO - 2021-06-03 03:25:20 --> Config Class Initialized
INFO - 2021-06-03 03:25:20 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:20 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:20 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:20 --> URI Class Initialized
INFO - 2021-06-03 03:25:20 --> Router Class Initialized
INFO - 2021-06-03 03:25:20 --> Output Class Initialized
INFO - 2021-06-03 03:25:20 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:20 --> Input Class Initialized
INFO - 2021-06-03 03:25:20 --> Language Class Initialized
INFO - 2021-06-03 03:25:20 --> Language Class Initialized
INFO - 2021-06-03 03:25:20 --> Config Class Initialized
INFO - 2021-06-03 03:25:20 --> Loader Class Initialized
INFO - 2021-06-03 03:25:20 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:20 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:20 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:20 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:20 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:20 --> Controller Class Initialized
DEBUG - 2021-06-03 03:25:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 03:25:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:25:20 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:20 --> Total execution time: 0.1499
INFO - 2021-06-03 03:25:22 --> Config Class Initialized
INFO - 2021-06-03 03:25:22 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:22 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:22 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:22 --> URI Class Initialized
INFO - 2021-06-03 03:25:22 --> Router Class Initialized
INFO - 2021-06-03 03:25:22 --> Output Class Initialized
INFO - 2021-06-03 03:25:22 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:22 --> Input Class Initialized
INFO - 2021-06-03 03:25:22 --> Language Class Initialized
INFO - 2021-06-03 03:25:22 --> Language Class Initialized
INFO - 2021-06-03 03:25:22 --> Config Class Initialized
INFO - 2021-06-03 03:25:22 --> Loader Class Initialized
INFO - 2021-06-03 03:25:22 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:22 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:22 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:22 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:22 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:22 --> Controller Class Initialized
DEBUG - 2021-06-03 03:25:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:25:22 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:22 --> Total execution time: 0.1608
INFO - 2021-06-03 03:25:31 --> Config Class Initialized
INFO - 2021-06-03 03:25:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:31 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:31 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:31 --> URI Class Initialized
INFO - 2021-06-03 03:25:31 --> Router Class Initialized
INFO - 2021-06-03 03:25:31 --> Output Class Initialized
INFO - 2021-06-03 03:25:31 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:31 --> Input Class Initialized
INFO - 2021-06-03 03:25:31 --> Language Class Initialized
INFO - 2021-06-03 03:25:31 --> Language Class Initialized
INFO - 2021-06-03 03:25:31 --> Config Class Initialized
INFO - 2021-06-03 03:25:31 --> Loader Class Initialized
INFO - 2021-06-03 03:25:31 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:31 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:31 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:31 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:31 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:31 --> Controller Class Initialized
DEBUG - 2021-06-03 03:25:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:25:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:25:31 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:31 --> Total execution time: 0.1437
INFO - 2021-06-03 03:25:33 --> Config Class Initialized
INFO - 2021-06-03 03:25:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:33 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:33 --> URI Class Initialized
INFO - 2021-06-03 03:25:33 --> Router Class Initialized
INFO - 2021-06-03 03:25:33 --> Output Class Initialized
INFO - 2021-06-03 03:25:33 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:33 --> Input Class Initialized
INFO - 2021-06-03 03:25:33 --> Language Class Initialized
INFO - 2021-06-03 03:25:33 --> Language Class Initialized
INFO - 2021-06-03 03:25:33 --> Config Class Initialized
INFO - 2021-06-03 03:25:33 --> Loader Class Initialized
INFO - 2021-06-03 03:25:33 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:33 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:33 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:33 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:33 --> Controller Class Initialized
INFO - 2021-06-03 03:25:33 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:33 --> Total execution time: 0.1274
INFO - 2021-06-03 03:25:36 --> Config Class Initialized
INFO - 2021-06-03 03:25:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:36 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:36 --> URI Class Initialized
INFO - 2021-06-03 03:25:36 --> Router Class Initialized
INFO - 2021-06-03 03:25:36 --> Output Class Initialized
INFO - 2021-06-03 03:25:36 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:36 --> Input Class Initialized
INFO - 2021-06-03 03:25:36 --> Language Class Initialized
INFO - 2021-06-03 03:25:36 --> Language Class Initialized
INFO - 2021-06-03 03:25:36 --> Config Class Initialized
INFO - 2021-06-03 03:25:36 --> Loader Class Initialized
INFO - 2021-06-03 03:25:36 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:36 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:36 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:36 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:36 --> Controller Class Initialized
INFO - 2021-06-03 03:25:36 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:36 --> Total execution time: 0.2685
INFO - 2021-06-03 03:25:38 --> Config Class Initialized
INFO - 2021-06-03 03:25:38 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:38 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:38 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:38 --> URI Class Initialized
INFO - 2021-06-03 03:25:38 --> Router Class Initialized
INFO - 2021-06-03 03:25:38 --> Output Class Initialized
INFO - 2021-06-03 03:25:38 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:38 --> Input Class Initialized
INFO - 2021-06-03 03:25:38 --> Language Class Initialized
INFO - 2021-06-03 03:25:38 --> Language Class Initialized
INFO - 2021-06-03 03:25:38 --> Config Class Initialized
INFO - 2021-06-03 03:25:38 --> Loader Class Initialized
INFO - 2021-06-03 03:25:38 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:38 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:38 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:38 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:38 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:38 --> Controller Class Initialized
DEBUG - 2021-06-03 03:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 03:25:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:25:38 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:38 --> Total execution time: 0.1504
INFO - 2021-06-03 03:25:39 --> Config Class Initialized
INFO - 2021-06-03 03:25:39 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:25:39 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:25:39 --> Utf8 Class Initialized
INFO - 2021-06-03 03:25:39 --> URI Class Initialized
INFO - 2021-06-03 03:25:39 --> Router Class Initialized
INFO - 2021-06-03 03:25:39 --> Output Class Initialized
INFO - 2021-06-03 03:25:39 --> Security Class Initialized
DEBUG - 2021-06-03 03:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:25:39 --> Input Class Initialized
INFO - 2021-06-03 03:25:39 --> Language Class Initialized
INFO - 2021-06-03 03:25:39 --> Language Class Initialized
INFO - 2021-06-03 03:25:39 --> Config Class Initialized
INFO - 2021-06-03 03:25:39 --> Loader Class Initialized
INFO - 2021-06-03 03:25:39 --> Helper loaded: url_helper
INFO - 2021-06-03 03:25:39 --> Helper loaded: file_helper
INFO - 2021-06-03 03:25:39 --> Helper loaded: form_helper
INFO - 2021-06-03 03:25:39 --> Helper loaded: my_helper
INFO - 2021-06-03 03:25:39 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:25:39 --> Controller Class Initialized
DEBUG - 2021-06-03 03:25:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:25:39 --> Final output sent to browser
DEBUG - 2021-06-03 03:25:39 --> Total execution time: 0.2642
INFO - 2021-06-03 03:26:11 --> Config Class Initialized
INFO - 2021-06-03 03:26:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:26:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:26:11 --> Utf8 Class Initialized
INFO - 2021-06-03 03:26:11 --> URI Class Initialized
INFO - 2021-06-03 03:26:12 --> Router Class Initialized
INFO - 2021-06-03 03:26:12 --> Output Class Initialized
INFO - 2021-06-03 03:26:12 --> Security Class Initialized
DEBUG - 2021-06-03 03:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:26:12 --> Input Class Initialized
INFO - 2021-06-03 03:26:12 --> Language Class Initialized
INFO - 2021-06-03 03:26:12 --> Language Class Initialized
INFO - 2021-06-03 03:26:12 --> Config Class Initialized
INFO - 2021-06-03 03:26:12 --> Loader Class Initialized
INFO - 2021-06-03 03:26:12 --> Helper loaded: url_helper
INFO - 2021-06-03 03:26:12 --> Helper loaded: file_helper
INFO - 2021-06-03 03:26:12 --> Helper loaded: form_helper
INFO - 2021-06-03 03:26:12 --> Helper loaded: my_helper
INFO - 2021-06-03 03:26:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:26:12 --> Controller Class Initialized
DEBUG - 2021-06-03 03:26:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:26:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:26:12 --> Final output sent to browser
DEBUG - 2021-06-03 03:26:12 --> Total execution time: 0.2185
INFO - 2021-06-03 03:26:14 --> Config Class Initialized
INFO - 2021-06-03 03:26:14 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:26:14 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:26:14 --> Utf8 Class Initialized
INFO - 2021-06-03 03:26:14 --> URI Class Initialized
INFO - 2021-06-03 03:26:14 --> Router Class Initialized
INFO - 2021-06-03 03:26:14 --> Output Class Initialized
INFO - 2021-06-03 03:26:14 --> Security Class Initialized
DEBUG - 2021-06-03 03:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:26:14 --> Input Class Initialized
INFO - 2021-06-03 03:26:14 --> Language Class Initialized
INFO - 2021-06-03 03:26:14 --> Language Class Initialized
INFO - 2021-06-03 03:26:14 --> Config Class Initialized
INFO - 2021-06-03 03:26:14 --> Loader Class Initialized
INFO - 2021-06-03 03:26:14 --> Helper loaded: url_helper
INFO - 2021-06-03 03:26:14 --> Helper loaded: file_helper
INFO - 2021-06-03 03:26:14 --> Helper loaded: form_helper
INFO - 2021-06-03 03:26:14 --> Helper loaded: my_helper
INFO - 2021-06-03 03:26:14 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:26:14 --> Controller Class Initialized
INFO - 2021-06-03 03:26:14 --> Final output sent to browser
DEBUG - 2021-06-03 03:26:14 --> Total execution time: 0.1307
INFO - 2021-06-03 03:28:46 --> Config Class Initialized
INFO - 2021-06-03 03:28:46 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:28:46 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:28:46 --> Utf8 Class Initialized
INFO - 2021-06-03 03:28:46 --> URI Class Initialized
INFO - 2021-06-03 03:28:46 --> Router Class Initialized
INFO - 2021-06-03 03:28:46 --> Output Class Initialized
INFO - 2021-06-03 03:28:46 --> Security Class Initialized
DEBUG - 2021-06-03 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:28:46 --> Input Class Initialized
INFO - 2021-06-03 03:28:46 --> Language Class Initialized
INFO - 2021-06-03 03:28:46 --> Language Class Initialized
INFO - 2021-06-03 03:28:46 --> Config Class Initialized
INFO - 2021-06-03 03:28:46 --> Loader Class Initialized
INFO - 2021-06-03 03:28:46 --> Helper loaded: url_helper
INFO - 2021-06-03 03:28:46 --> Helper loaded: file_helper
INFO - 2021-06-03 03:28:46 --> Helper loaded: form_helper
INFO - 2021-06-03 03:28:46 --> Helper loaded: my_helper
INFO - 2021-06-03 03:28:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:28:46 --> Controller Class Initialized
DEBUG - 2021-06-03 03:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:28:46 --> Final output sent to browser
DEBUG - 2021-06-03 03:28:46 --> Total execution time: 0.1517
INFO - 2021-06-03 03:28:48 --> Config Class Initialized
INFO - 2021-06-03 03:28:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:28:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:28:48 --> Utf8 Class Initialized
INFO - 2021-06-03 03:28:48 --> URI Class Initialized
INFO - 2021-06-03 03:28:48 --> Router Class Initialized
INFO - 2021-06-03 03:28:48 --> Output Class Initialized
INFO - 2021-06-03 03:28:48 --> Security Class Initialized
DEBUG - 2021-06-03 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:28:48 --> Input Class Initialized
INFO - 2021-06-03 03:28:48 --> Language Class Initialized
INFO - 2021-06-03 03:28:48 --> Language Class Initialized
INFO - 2021-06-03 03:28:48 --> Config Class Initialized
INFO - 2021-06-03 03:28:48 --> Loader Class Initialized
INFO - 2021-06-03 03:28:48 --> Helper loaded: url_helper
INFO - 2021-06-03 03:28:48 --> Helper loaded: file_helper
INFO - 2021-06-03 03:28:48 --> Helper loaded: form_helper
INFO - 2021-06-03 03:28:48 --> Helper loaded: my_helper
INFO - 2021-06-03 03:28:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:28:48 --> Controller Class Initialized
INFO - 2021-06-03 03:28:48 --> Final output sent to browser
DEBUG - 2021-06-03 03:28:48 --> Total execution time: 0.0956
INFO - 2021-06-03 03:29:30 --> Config Class Initialized
INFO - 2021-06-03 03:29:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:29:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:29:30 --> Utf8 Class Initialized
INFO - 2021-06-03 03:29:30 --> URI Class Initialized
INFO - 2021-06-03 03:29:30 --> Router Class Initialized
INFO - 2021-06-03 03:29:30 --> Output Class Initialized
INFO - 2021-06-03 03:29:30 --> Security Class Initialized
DEBUG - 2021-06-03 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:29:30 --> Input Class Initialized
INFO - 2021-06-03 03:29:30 --> Language Class Initialized
INFO - 2021-06-03 03:29:30 --> Language Class Initialized
INFO - 2021-06-03 03:29:30 --> Config Class Initialized
INFO - 2021-06-03 03:29:30 --> Loader Class Initialized
INFO - 2021-06-03 03:29:30 --> Helper loaded: url_helper
INFO - 2021-06-03 03:29:30 --> Helper loaded: file_helper
INFO - 2021-06-03 03:29:30 --> Helper loaded: form_helper
INFO - 2021-06-03 03:29:30 --> Helper loaded: my_helper
INFO - 2021-06-03 03:29:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:29:30 --> Controller Class Initialized
DEBUG - 2021-06-03 03:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:29:30 --> Final output sent to browser
DEBUG - 2021-06-03 03:29:30 --> Total execution time: 0.1734
INFO - 2021-06-03 03:29:32 --> Config Class Initialized
INFO - 2021-06-03 03:29:32 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:29:32 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:29:32 --> Utf8 Class Initialized
INFO - 2021-06-03 03:29:32 --> URI Class Initialized
INFO - 2021-06-03 03:29:32 --> Router Class Initialized
INFO - 2021-06-03 03:29:32 --> Output Class Initialized
INFO - 2021-06-03 03:29:32 --> Security Class Initialized
DEBUG - 2021-06-03 03:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:29:32 --> Input Class Initialized
INFO - 2021-06-03 03:29:32 --> Language Class Initialized
INFO - 2021-06-03 03:29:32 --> Language Class Initialized
INFO - 2021-06-03 03:29:32 --> Config Class Initialized
INFO - 2021-06-03 03:29:32 --> Loader Class Initialized
INFO - 2021-06-03 03:29:32 --> Helper loaded: url_helper
INFO - 2021-06-03 03:29:32 --> Helper loaded: file_helper
INFO - 2021-06-03 03:29:32 --> Helper loaded: form_helper
INFO - 2021-06-03 03:29:32 --> Helper loaded: my_helper
INFO - 2021-06-03 03:29:32 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:29:32 --> Controller Class Initialized
INFO - 2021-06-03 03:29:32 --> Final output sent to browser
DEBUG - 2021-06-03 03:29:32 --> Total execution time: 0.1240
INFO - 2021-06-03 03:30:39 --> Config Class Initialized
INFO - 2021-06-03 03:30:39 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:30:39 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:30:39 --> Utf8 Class Initialized
INFO - 2021-06-03 03:30:39 --> URI Class Initialized
INFO - 2021-06-03 03:30:39 --> Router Class Initialized
INFO - 2021-06-03 03:30:39 --> Output Class Initialized
INFO - 2021-06-03 03:30:39 --> Security Class Initialized
DEBUG - 2021-06-03 03:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:30:39 --> Input Class Initialized
INFO - 2021-06-03 03:30:39 --> Language Class Initialized
INFO - 2021-06-03 03:30:39 --> Language Class Initialized
INFO - 2021-06-03 03:30:39 --> Config Class Initialized
INFO - 2021-06-03 03:30:39 --> Loader Class Initialized
INFO - 2021-06-03 03:30:39 --> Helper loaded: url_helper
INFO - 2021-06-03 03:30:39 --> Helper loaded: file_helper
INFO - 2021-06-03 03:30:39 --> Helper loaded: form_helper
INFO - 2021-06-03 03:30:39 --> Helper loaded: my_helper
INFO - 2021-06-03 03:30:39 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:30:39 --> Controller Class Initialized
DEBUG - 2021-06-03 03:30:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:30:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:30:39 --> Final output sent to browser
DEBUG - 2021-06-03 03:30:39 --> Total execution time: 0.1817
INFO - 2021-06-03 03:30:41 --> Config Class Initialized
INFO - 2021-06-03 03:30:41 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:30:41 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:30:41 --> Utf8 Class Initialized
INFO - 2021-06-03 03:30:41 --> URI Class Initialized
INFO - 2021-06-03 03:30:41 --> Router Class Initialized
INFO - 2021-06-03 03:30:41 --> Output Class Initialized
INFO - 2021-06-03 03:30:41 --> Security Class Initialized
DEBUG - 2021-06-03 03:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:30:41 --> Input Class Initialized
INFO - 2021-06-03 03:30:41 --> Language Class Initialized
INFO - 2021-06-03 03:30:41 --> Language Class Initialized
INFO - 2021-06-03 03:30:41 --> Config Class Initialized
INFO - 2021-06-03 03:30:41 --> Loader Class Initialized
INFO - 2021-06-03 03:30:41 --> Helper loaded: url_helper
INFO - 2021-06-03 03:30:41 --> Helper loaded: file_helper
INFO - 2021-06-03 03:30:41 --> Helper loaded: form_helper
INFO - 2021-06-03 03:30:41 --> Helper loaded: my_helper
INFO - 2021-06-03 03:30:41 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:30:41 --> Controller Class Initialized
INFO - 2021-06-03 03:30:41 --> Final output sent to browser
DEBUG - 2021-06-03 03:30:41 --> Total execution time: 0.1181
INFO - 2021-06-03 03:44:32 --> Config Class Initialized
INFO - 2021-06-03 03:44:32 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:44:32 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:44:32 --> Utf8 Class Initialized
INFO - 2021-06-03 03:44:32 --> URI Class Initialized
INFO - 2021-06-03 03:44:32 --> Router Class Initialized
INFO - 2021-06-03 03:44:32 --> Output Class Initialized
INFO - 2021-06-03 03:44:32 --> Security Class Initialized
DEBUG - 2021-06-03 03:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:44:32 --> Input Class Initialized
INFO - 2021-06-03 03:44:32 --> Language Class Initialized
INFO - 2021-06-03 03:44:32 --> Language Class Initialized
INFO - 2021-06-03 03:44:32 --> Config Class Initialized
INFO - 2021-06-03 03:44:32 --> Loader Class Initialized
INFO - 2021-06-03 03:44:32 --> Helper loaded: url_helper
INFO - 2021-06-03 03:44:32 --> Helper loaded: file_helper
INFO - 2021-06-03 03:44:32 --> Helper loaded: form_helper
INFO - 2021-06-03 03:44:32 --> Helper loaded: my_helper
INFO - 2021-06-03 03:44:32 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:44:32 --> Controller Class Initialized
DEBUG - 2021-06-03 03:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:44:32 --> Final output sent to browser
DEBUG - 2021-06-03 03:44:32 --> Total execution time: 0.2497
INFO - 2021-06-03 03:44:34 --> Config Class Initialized
INFO - 2021-06-03 03:44:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:44:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:44:34 --> Utf8 Class Initialized
INFO - 2021-06-03 03:44:34 --> URI Class Initialized
INFO - 2021-06-03 03:44:34 --> Router Class Initialized
INFO - 2021-06-03 03:44:34 --> Output Class Initialized
INFO - 2021-06-03 03:44:34 --> Security Class Initialized
DEBUG - 2021-06-03 03:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:44:34 --> Input Class Initialized
INFO - 2021-06-03 03:44:34 --> Language Class Initialized
INFO - 2021-06-03 03:44:34 --> Language Class Initialized
INFO - 2021-06-03 03:44:34 --> Config Class Initialized
INFO - 2021-06-03 03:44:34 --> Loader Class Initialized
INFO - 2021-06-03 03:44:34 --> Helper loaded: url_helper
INFO - 2021-06-03 03:44:34 --> Helper loaded: file_helper
INFO - 2021-06-03 03:44:34 --> Helper loaded: form_helper
INFO - 2021-06-03 03:44:34 --> Helper loaded: my_helper
INFO - 2021-06-03 03:44:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:44:34 --> Controller Class Initialized
INFO - 2021-06-03 03:44:34 --> Final output sent to browser
DEBUG - 2021-06-03 03:44:34 --> Total execution time: 0.1111
INFO - 2021-06-03 03:44:53 --> Config Class Initialized
INFO - 2021-06-03 03:44:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:44:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:44:53 --> Utf8 Class Initialized
INFO - 2021-06-03 03:44:53 --> URI Class Initialized
INFO - 2021-06-03 03:44:53 --> Router Class Initialized
INFO - 2021-06-03 03:44:53 --> Output Class Initialized
INFO - 2021-06-03 03:44:53 --> Security Class Initialized
DEBUG - 2021-06-03 03:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:44:53 --> Input Class Initialized
INFO - 2021-06-03 03:44:53 --> Language Class Initialized
INFO - 2021-06-03 03:44:53 --> Language Class Initialized
INFO - 2021-06-03 03:44:53 --> Config Class Initialized
INFO - 2021-06-03 03:44:53 --> Loader Class Initialized
INFO - 2021-06-03 03:44:53 --> Helper loaded: url_helper
INFO - 2021-06-03 03:44:53 --> Helper loaded: file_helper
INFO - 2021-06-03 03:44:53 --> Helper loaded: form_helper
INFO - 2021-06-03 03:44:53 --> Helper loaded: my_helper
INFO - 2021-06-03 03:44:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:44:53 --> Controller Class Initialized
INFO - 2021-06-03 03:44:53 --> Final output sent to browser
DEBUG - 2021-06-03 03:44:53 --> Total execution time: 0.2307
INFO - 2021-06-03 03:45:04 --> Config Class Initialized
INFO - 2021-06-03 03:45:04 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:45:04 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:45:04 --> Utf8 Class Initialized
INFO - 2021-06-03 03:45:04 --> URI Class Initialized
INFO - 2021-06-03 03:45:05 --> Router Class Initialized
INFO - 2021-06-03 03:45:05 --> Output Class Initialized
INFO - 2021-06-03 03:45:05 --> Security Class Initialized
DEBUG - 2021-06-03 03:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:45:05 --> Input Class Initialized
INFO - 2021-06-03 03:45:05 --> Language Class Initialized
INFO - 2021-06-03 03:45:05 --> Language Class Initialized
INFO - 2021-06-03 03:45:05 --> Config Class Initialized
INFO - 2021-06-03 03:45:05 --> Loader Class Initialized
INFO - 2021-06-03 03:45:05 --> Helper loaded: url_helper
INFO - 2021-06-03 03:45:05 --> Helper loaded: file_helper
INFO - 2021-06-03 03:45:05 --> Helper loaded: form_helper
INFO - 2021-06-03 03:45:05 --> Helper loaded: my_helper
INFO - 2021-06-03 03:45:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:45:05 --> Controller Class Initialized
INFO - 2021-06-03 03:45:05 --> Final output sent to browser
DEBUG - 2021-06-03 03:45:05 --> Total execution time: 0.2642
INFO - 2021-06-03 03:45:08 --> Config Class Initialized
INFO - 2021-06-03 03:45:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:45:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:45:08 --> Utf8 Class Initialized
INFO - 2021-06-03 03:45:08 --> URI Class Initialized
INFO - 2021-06-03 03:45:08 --> Router Class Initialized
INFO - 2021-06-03 03:45:08 --> Output Class Initialized
INFO - 2021-06-03 03:45:08 --> Security Class Initialized
DEBUG - 2021-06-03 03:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:45:08 --> Input Class Initialized
INFO - 2021-06-03 03:45:08 --> Language Class Initialized
INFO - 2021-06-03 03:45:08 --> Language Class Initialized
INFO - 2021-06-03 03:45:08 --> Config Class Initialized
INFO - 2021-06-03 03:45:08 --> Loader Class Initialized
INFO - 2021-06-03 03:45:08 --> Helper loaded: url_helper
INFO - 2021-06-03 03:45:08 --> Helper loaded: file_helper
INFO - 2021-06-03 03:45:08 --> Helper loaded: form_helper
INFO - 2021-06-03 03:45:08 --> Helper loaded: my_helper
INFO - 2021-06-03 03:45:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:45:08 --> Controller Class Initialized
INFO - 2021-06-03 03:45:08 --> Final output sent to browser
DEBUG - 2021-06-03 03:45:08 --> Total execution time: 0.1371
INFO - 2021-06-03 03:45:31 --> Config Class Initialized
INFO - 2021-06-03 03:45:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:45:31 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:45:31 --> Utf8 Class Initialized
INFO - 2021-06-03 03:45:31 --> URI Class Initialized
INFO - 2021-06-03 03:45:31 --> Router Class Initialized
INFO - 2021-06-03 03:45:31 --> Output Class Initialized
INFO - 2021-06-03 03:45:31 --> Security Class Initialized
DEBUG - 2021-06-03 03:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:45:31 --> Input Class Initialized
INFO - 2021-06-03 03:45:31 --> Language Class Initialized
INFO - 2021-06-03 03:45:31 --> Language Class Initialized
INFO - 2021-06-03 03:45:31 --> Config Class Initialized
INFO - 2021-06-03 03:45:31 --> Loader Class Initialized
INFO - 2021-06-03 03:45:31 --> Helper loaded: url_helper
INFO - 2021-06-03 03:45:31 --> Helper loaded: file_helper
INFO - 2021-06-03 03:45:31 --> Helper loaded: form_helper
INFO - 2021-06-03 03:45:31 --> Helper loaded: my_helper
INFO - 2021-06-03 03:45:31 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:45:31 --> Controller Class Initialized
INFO - 2021-06-03 03:45:31 --> Final output sent to browser
DEBUG - 2021-06-03 03:45:31 --> Total execution time: 0.2864
INFO - 2021-06-03 03:45:33 --> Config Class Initialized
INFO - 2021-06-03 03:45:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:45:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:45:33 --> Utf8 Class Initialized
INFO - 2021-06-03 03:45:33 --> URI Class Initialized
INFO - 2021-06-03 03:45:33 --> Router Class Initialized
INFO - 2021-06-03 03:45:33 --> Output Class Initialized
INFO - 2021-06-03 03:45:33 --> Security Class Initialized
DEBUG - 2021-06-03 03:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:45:34 --> Input Class Initialized
INFO - 2021-06-03 03:45:34 --> Language Class Initialized
INFO - 2021-06-03 03:45:34 --> Language Class Initialized
INFO - 2021-06-03 03:45:34 --> Config Class Initialized
INFO - 2021-06-03 03:45:34 --> Loader Class Initialized
INFO - 2021-06-03 03:45:34 --> Helper loaded: url_helper
INFO - 2021-06-03 03:45:34 --> Helper loaded: file_helper
INFO - 2021-06-03 03:45:34 --> Helper loaded: form_helper
INFO - 2021-06-03 03:45:34 --> Helper loaded: my_helper
INFO - 2021-06-03 03:45:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:45:34 --> Controller Class Initialized
INFO - 2021-06-03 03:45:34 --> Final output sent to browser
DEBUG - 2021-06-03 03:45:34 --> Total execution time: 0.1305
INFO - 2021-06-03 03:45:34 --> Config Class Initialized
INFO - 2021-06-03 03:45:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:45:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:45:34 --> Utf8 Class Initialized
INFO - 2021-06-03 03:45:34 --> URI Class Initialized
INFO - 2021-06-03 03:45:34 --> Router Class Initialized
INFO - 2021-06-03 03:45:34 --> Output Class Initialized
INFO - 2021-06-03 03:45:34 --> Security Class Initialized
DEBUG - 2021-06-03 03:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:45:34 --> Input Class Initialized
INFO - 2021-06-03 03:45:34 --> Language Class Initialized
INFO - 2021-06-03 03:45:34 --> Language Class Initialized
INFO - 2021-06-03 03:45:34 --> Config Class Initialized
INFO - 2021-06-03 03:45:34 --> Loader Class Initialized
INFO - 2021-06-03 03:45:34 --> Helper loaded: url_helper
INFO - 2021-06-03 03:45:34 --> Helper loaded: file_helper
INFO - 2021-06-03 03:45:34 --> Helper loaded: form_helper
INFO - 2021-06-03 03:45:34 --> Helper loaded: my_helper
INFO - 2021-06-03 03:45:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:45:34 --> Controller Class Initialized
INFO - 2021-06-03 03:45:34 --> Final output sent to browser
DEBUG - 2021-06-03 03:45:34 --> Total execution time: 0.1195
INFO - 2021-06-03 03:46:06 --> Config Class Initialized
INFO - 2021-06-03 03:46:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:06 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:06 --> URI Class Initialized
INFO - 2021-06-03 03:46:06 --> Router Class Initialized
INFO - 2021-06-03 03:46:06 --> Output Class Initialized
INFO - 2021-06-03 03:46:06 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:06 --> Input Class Initialized
INFO - 2021-06-03 03:46:06 --> Language Class Initialized
INFO - 2021-06-03 03:46:06 --> Language Class Initialized
INFO - 2021-06-03 03:46:06 --> Config Class Initialized
INFO - 2021-06-03 03:46:06 --> Loader Class Initialized
INFO - 2021-06-03 03:46:06 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:06 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:06 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:06 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:06 --> Controller Class Initialized
INFO - 2021-06-03 03:46:06 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:06 --> Total execution time: 0.2403
INFO - 2021-06-03 03:46:08 --> Config Class Initialized
INFO - 2021-06-03 03:46:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:08 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:08 --> URI Class Initialized
INFO - 2021-06-03 03:46:08 --> Router Class Initialized
INFO - 2021-06-03 03:46:08 --> Output Class Initialized
INFO - 2021-06-03 03:46:08 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:08 --> Input Class Initialized
INFO - 2021-06-03 03:46:08 --> Language Class Initialized
INFO - 2021-06-03 03:46:08 --> Language Class Initialized
INFO - 2021-06-03 03:46:08 --> Config Class Initialized
INFO - 2021-06-03 03:46:08 --> Loader Class Initialized
INFO - 2021-06-03 03:46:08 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:08 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:08 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:08 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:08 --> Controller Class Initialized
INFO - 2021-06-03 03:46:08 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:08 --> Total execution time: 0.0969
INFO - 2021-06-03 03:46:27 --> Config Class Initialized
INFO - 2021-06-03 03:46:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:27 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:27 --> URI Class Initialized
INFO - 2021-06-03 03:46:27 --> Router Class Initialized
INFO - 2021-06-03 03:46:27 --> Output Class Initialized
INFO - 2021-06-03 03:46:27 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:27 --> Input Class Initialized
INFO - 2021-06-03 03:46:27 --> Language Class Initialized
INFO - 2021-06-03 03:46:27 --> Language Class Initialized
INFO - 2021-06-03 03:46:27 --> Config Class Initialized
INFO - 2021-06-03 03:46:27 --> Loader Class Initialized
INFO - 2021-06-03 03:46:27 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:27 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:27 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:27 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:28 --> Controller Class Initialized
INFO - 2021-06-03 03:46:28 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:28 --> Total execution time: 0.2479
INFO - 2021-06-03 03:46:30 --> Config Class Initialized
INFO - 2021-06-03 03:46:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:30 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:30 --> URI Class Initialized
INFO - 2021-06-03 03:46:30 --> Router Class Initialized
INFO - 2021-06-03 03:46:30 --> Output Class Initialized
INFO - 2021-06-03 03:46:30 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:30 --> Input Class Initialized
INFO - 2021-06-03 03:46:30 --> Language Class Initialized
INFO - 2021-06-03 03:46:30 --> Language Class Initialized
INFO - 2021-06-03 03:46:30 --> Config Class Initialized
INFO - 2021-06-03 03:46:30 --> Loader Class Initialized
INFO - 2021-06-03 03:46:30 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:30 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:30 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:30 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:30 --> Controller Class Initialized
INFO - 2021-06-03 03:46:30 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:30 --> Total execution time: 0.1510
INFO - 2021-06-03 03:46:31 --> Config Class Initialized
INFO - 2021-06-03 03:46:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:31 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:31 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:31 --> URI Class Initialized
INFO - 2021-06-03 03:46:31 --> Router Class Initialized
INFO - 2021-06-03 03:46:31 --> Output Class Initialized
INFO - 2021-06-03 03:46:31 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:31 --> Input Class Initialized
INFO - 2021-06-03 03:46:31 --> Language Class Initialized
INFO - 2021-06-03 03:46:31 --> Language Class Initialized
INFO - 2021-06-03 03:46:31 --> Config Class Initialized
INFO - 2021-06-03 03:46:31 --> Loader Class Initialized
INFO - 2021-06-03 03:46:31 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:31 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:31 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:31 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:31 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:31 --> Controller Class Initialized
INFO - 2021-06-03 03:46:31 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:31 --> Total execution time: 0.1229
INFO - 2021-06-03 03:46:31 --> Config Class Initialized
INFO - 2021-06-03 03:46:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:31 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:31 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:31 --> URI Class Initialized
INFO - 2021-06-03 03:46:31 --> Router Class Initialized
INFO - 2021-06-03 03:46:31 --> Output Class Initialized
INFO - 2021-06-03 03:46:31 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:31 --> Input Class Initialized
INFO - 2021-06-03 03:46:31 --> Language Class Initialized
INFO - 2021-06-03 03:46:31 --> Language Class Initialized
INFO - 2021-06-03 03:46:31 --> Config Class Initialized
INFO - 2021-06-03 03:46:31 --> Loader Class Initialized
INFO - 2021-06-03 03:46:31 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:31 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:31 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:31 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:31 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:31 --> Controller Class Initialized
INFO - 2021-06-03 03:46:31 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:31 --> Total execution time: 0.1182
INFO - 2021-06-03 03:46:32 --> Config Class Initialized
INFO - 2021-06-03 03:46:32 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:32 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:32 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:32 --> URI Class Initialized
INFO - 2021-06-03 03:46:32 --> Router Class Initialized
INFO - 2021-06-03 03:46:32 --> Output Class Initialized
INFO - 2021-06-03 03:46:32 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:32 --> Input Class Initialized
INFO - 2021-06-03 03:46:32 --> Language Class Initialized
INFO - 2021-06-03 03:46:32 --> Language Class Initialized
INFO - 2021-06-03 03:46:32 --> Config Class Initialized
INFO - 2021-06-03 03:46:32 --> Loader Class Initialized
INFO - 2021-06-03 03:46:32 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:32 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:32 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:32 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:32 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:32 --> Controller Class Initialized
INFO - 2021-06-03 03:46:32 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:32 --> Total execution time: 0.1146
INFO - 2021-06-03 03:46:32 --> Config Class Initialized
INFO - 2021-06-03 03:46:32 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:32 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:32 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:32 --> URI Class Initialized
INFO - 2021-06-03 03:46:32 --> Router Class Initialized
INFO - 2021-06-03 03:46:32 --> Output Class Initialized
INFO - 2021-06-03 03:46:32 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:32 --> Input Class Initialized
INFO - 2021-06-03 03:46:32 --> Language Class Initialized
INFO - 2021-06-03 03:46:32 --> Language Class Initialized
INFO - 2021-06-03 03:46:32 --> Config Class Initialized
INFO - 2021-06-03 03:46:32 --> Loader Class Initialized
INFO - 2021-06-03 03:46:32 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:32 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:32 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:32 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:32 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:32 --> Controller Class Initialized
INFO - 2021-06-03 03:46:32 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:32 --> Total execution time: 0.1052
INFO - 2021-06-03 03:46:33 --> Config Class Initialized
INFO - 2021-06-03 03:46:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:33 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:33 --> URI Class Initialized
INFO - 2021-06-03 03:46:33 --> Router Class Initialized
INFO - 2021-06-03 03:46:33 --> Output Class Initialized
INFO - 2021-06-03 03:46:33 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:33 --> Input Class Initialized
INFO - 2021-06-03 03:46:33 --> Language Class Initialized
INFO - 2021-06-03 03:46:33 --> Language Class Initialized
INFO - 2021-06-03 03:46:33 --> Config Class Initialized
INFO - 2021-06-03 03:46:33 --> Loader Class Initialized
INFO - 2021-06-03 03:46:33 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:33 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:33 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:33 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:34 --> Controller Class Initialized
DEBUG - 2021-06-03 03:46:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 03:46:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:46:34 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:34 --> Total execution time: 0.1144
INFO - 2021-06-03 03:46:35 --> Config Class Initialized
INFO - 2021-06-03 03:46:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:46:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:46:35 --> Utf8 Class Initialized
INFO - 2021-06-03 03:46:35 --> URI Class Initialized
INFO - 2021-06-03 03:46:35 --> Router Class Initialized
INFO - 2021-06-03 03:46:35 --> Output Class Initialized
INFO - 2021-06-03 03:46:35 --> Security Class Initialized
DEBUG - 2021-06-03 03:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:46:35 --> Input Class Initialized
INFO - 2021-06-03 03:46:35 --> Language Class Initialized
INFO - 2021-06-03 03:46:35 --> Language Class Initialized
INFO - 2021-06-03 03:46:35 --> Config Class Initialized
INFO - 2021-06-03 03:46:35 --> Loader Class Initialized
INFO - 2021-06-03 03:46:35 --> Helper loaded: url_helper
INFO - 2021-06-03 03:46:35 --> Helper loaded: file_helper
INFO - 2021-06-03 03:46:35 --> Helper loaded: form_helper
INFO - 2021-06-03 03:46:35 --> Helper loaded: my_helper
INFO - 2021-06-03 03:46:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:46:35 --> Controller Class Initialized
DEBUG - 2021-06-03 03:46:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:46:35 --> Final output sent to browser
DEBUG - 2021-06-03 03:46:35 --> Total execution time: 0.1536
INFO - 2021-06-03 03:48:29 --> Config Class Initialized
INFO - 2021-06-03 03:48:29 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:48:29 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:48:29 --> Utf8 Class Initialized
INFO - 2021-06-03 03:48:29 --> URI Class Initialized
INFO - 2021-06-03 03:48:29 --> Router Class Initialized
INFO - 2021-06-03 03:48:29 --> Output Class Initialized
INFO - 2021-06-03 03:48:29 --> Security Class Initialized
DEBUG - 2021-06-03 03:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:48:29 --> Input Class Initialized
INFO - 2021-06-03 03:48:29 --> Language Class Initialized
INFO - 2021-06-03 03:48:29 --> Language Class Initialized
INFO - 2021-06-03 03:48:29 --> Config Class Initialized
INFO - 2021-06-03 03:48:29 --> Loader Class Initialized
INFO - 2021-06-03 03:48:29 --> Helper loaded: url_helper
INFO - 2021-06-03 03:48:29 --> Helper loaded: file_helper
INFO - 2021-06-03 03:48:29 --> Helper loaded: form_helper
INFO - 2021-06-03 03:48:29 --> Helper loaded: my_helper
INFO - 2021-06-03 03:48:29 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:48:29 --> Controller Class Initialized
DEBUG - 2021-06-03 03:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:48:29 --> Final output sent to browser
DEBUG - 2021-06-03 03:48:29 --> Total execution time: 0.1704
INFO - 2021-06-03 03:48:31 --> Config Class Initialized
INFO - 2021-06-03 03:48:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:48:31 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:48:31 --> Utf8 Class Initialized
INFO - 2021-06-03 03:48:31 --> URI Class Initialized
INFO - 2021-06-03 03:48:31 --> Router Class Initialized
INFO - 2021-06-03 03:48:31 --> Output Class Initialized
INFO - 2021-06-03 03:48:31 --> Security Class Initialized
DEBUG - 2021-06-03 03:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:48:31 --> Input Class Initialized
INFO - 2021-06-03 03:48:31 --> Language Class Initialized
INFO - 2021-06-03 03:48:31 --> Language Class Initialized
INFO - 2021-06-03 03:48:31 --> Config Class Initialized
INFO - 2021-06-03 03:48:31 --> Loader Class Initialized
INFO - 2021-06-03 03:48:31 --> Helper loaded: url_helper
INFO - 2021-06-03 03:48:31 --> Helper loaded: file_helper
INFO - 2021-06-03 03:48:31 --> Helper loaded: form_helper
INFO - 2021-06-03 03:48:31 --> Helper loaded: my_helper
INFO - 2021-06-03 03:48:31 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:48:31 --> Controller Class Initialized
INFO - 2021-06-03 03:48:31 --> Final output sent to browser
DEBUG - 2021-06-03 03:48:31 --> Total execution time: 0.1253
INFO - 2021-06-03 03:48:39 --> Config Class Initialized
INFO - 2021-06-03 03:48:39 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:48:39 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:48:39 --> Utf8 Class Initialized
INFO - 2021-06-03 03:48:39 --> URI Class Initialized
INFO - 2021-06-03 03:48:39 --> Router Class Initialized
INFO - 2021-06-03 03:48:39 --> Output Class Initialized
INFO - 2021-06-03 03:48:39 --> Security Class Initialized
DEBUG - 2021-06-03 03:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:48:39 --> Input Class Initialized
INFO - 2021-06-03 03:48:39 --> Language Class Initialized
INFO - 2021-06-03 03:48:39 --> Language Class Initialized
INFO - 2021-06-03 03:48:39 --> Config Class Initialized
INFO - 2021-06-03 03:48:39 --> Loader Class Initialized
INFO - 2021-06-03 03:48:39 --> Helper loaded: url_helper
INFO - 2021-06-03 03:48:39 --> Helper loaded: file_helper
INFO - 2021-06-03 03:48:39 --> Helper loaded: form_helper
INFO - 2021-06-03 03:48:39 --> Helper loaded: my_helper
INFO - 2021-06-03 03:48:39 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:48:39 --> Controller Class Initialized
INFO - 2021-06-03 03:48:39 --> Final output sent to browser
DEBUG - 2021-06-03 03:48:39 --> Total execution time: 0.2412
INFO - 2021-06-03 03:48:53 --> Config Class Initialized
INFO - 2021-06-03 03:48:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:48:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:48:53 --> Utf8 Class Initialized
INFO - 2021-06-03 03:48:53 --> URI Class Initialized
INFO - 2021-06-03 03:48:53 --> Router Class Initialized
INFO - 2021-06-03 03:48:53 --> Output Class Initialized
INFO - 2021-06-03 03:48:53 --> Security Class Initialized
DEBUG - 2021-06-03 03:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:48:53 --> Input Class Initialized
INFO - 2021-06-03 03:48:53 --> Language Class Initialized
INFO - 2021-06-03 03:48:53 --> Language Class Initialized
INFO - 2021-06-03 03:48:53 --> Config Class Initialized
INFO - 2021-06-03 03:48:53 --> Loader Class Initialized
INFO - 2021-06-03 03:48:53 --> Helper loaded: url_helper
INFO - 2021-06-03 03:48:53 --> Helper loaded: file_helper
INFO - 2021-06-03 03:48:53 --> Helper loaded: form_helper
INFO - 2021-06-03 03:48:53 --> Helper loaded: my_helper
INFO - 2021-06-03 03:48:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:48:53 --> Controller Class Initialized
INFO - 2021-06-03 03:48:53 --> Final output sent to browser
DEBUG - 2021-06-03 03:48:53 --> Total execution time: 0.1037
INFO - 2021-06-03 03:48:56 --> Config Class Initialized
INFO - 2021-06-03 03:48:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:48:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:48:56 --> Utf8 Class Initialized
INFO - 2021-06-03 03:48:56 --> URI Class Initialized
INFO - 2021-06-03 03:48:56 --> Router Class Initialized
INFO - 2021-06-03 03:48:56 --> Output Class Initialized
INFO - 2021-06-03 03:48:56 --> Security Class Initialized
DEBUG - 2021-06-03 03:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:48:56 --> Input Class Initialized
INFO - 2021-06-03 03:48:56 --> Language Class Initialized
INFO - 2021-06-03 03:48:56 --> Language Class Initialized
INFO - 2021-06-03 03:48:56 --> Config Class Initialized
INFO - 2021-06-03 03:48:56 --> Loader Class Initialized
INFO - 2021-06-03 03:48:56 --> Helper loaded: url_helper
INFO - 2021-06-03 03:48:56 --> Helper loaded: file_helper
INFO - 2021-06-03 03:48:56 --> Helper loaded: form_helper
INFO - 2021-06-03 03:48:56 --> Helper loaded: my_helper
INFO - 2021-06-03 03:48:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:48:56 --> Controller Class Initialized
INFO - 2021-06-03 03:48:57 --> Final output sent to browser
DEBUG - 2021-06-03 03:48:57 --> Total execution time: 0.2255
INFO - 2021-06-03 03:48:59 --> Config Class Initialized
INFO - 2021-06-03 03:48:59 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:48:59 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:48:59 --> Utf8 Class Initialized
INFO - 2021-06-03 03:48:59 --> URI Class Initialized
INFO - 2021-06-03 03:48:59 --> Router Class Initialized
INFO - 2021-06-03 03:48:59 --> Output Class Initialized
INFO - 2021-06-03 03:48:59 --> Security Class Initialized
DEBUG - 2021-06-03 03:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:48:59 --> Input Class Initialized
INFO - 2021-06-03 03:48:59 --> Language Class Initialized
INFO - 2021-06-03 03:48:59 --> Language Class Initialized
INFO - 2021-06-03 03:48:59 --> Config Class Initialized
INFO - 2021-06-03 03:48:59 --> Loader Class Initialized
INFO - 2021-06-03 03:48:59 --> Helper loaded: url_helper
INFO - 2021-06-03 03:48:59 --> Helper loaded: file_helper
INFO - 2021-06-03 03:48:59 --> Helper loaded: form_helper
INFO - 2021-06-03 03:48:59 --> Helper loaded: my_helper
INFO - 2021-06-03 03:48:59 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:48:59 --> Controller Class Initialized
DEBUG - 2021-06-03 03:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 03:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:48:59 --> Final output sent to browser
DEBUG - 2021-06-03 03:48:59 --> Total execution time: 0.1562
INFO - 2021-06-03 03:49:00 --> Config Class Initialized
INFO - 2021-06-03 03:49:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:49:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:49:00 --> Utf8 Class Initialized
INFO - 2021-06-03 03:49:00 --> URI Class Initialized
INFO - 2021-06-03 03:49:00 --> Router Class Initialized
INFO - 2021-06-03 03:49:00 --> Output Class Initialized
INFO - 2021-06-03 03:49:00 --> Security Class Initialized
DEBUG - 2021-06-03 03:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:49:00 --> Input Class Initialized
INFO - 2021-06-03 03:49:01 --> Language Class Initialized
INFO - 2021-06-03 03:49:01 --> Language Class Initialized
INFO - 2021-06-03 03:49:01 --> Config Class Initialized
INFO - 2021-06-03 03:49:01 --> Loader Class Initialized
INFO - 2021-06-03 03:49:01 --> Helper loaded: url_helper
INFO - 2021-06-03 03:49:01 --> Helper loaded: file_helper
INFO - 2021-06-03 03:49:01 --> Helper loaded: form_helper
INFO - 2021-06-03 03:49:01 --> Helper loaded: my_helper
INFO - 2021-06-03 03:49:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:49:01 --> Controller Class Initialized
DEBUG - 2021-06-03 03:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:49:01 --> Final output sent to browser
DEBUG - 2021-06-03 03:49:01 --> Total execution time: 0.2287
INFO - 2021-06-03 03:49:31 --> Config Class Initialized
INFO - 2021-06-03 03:49:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:49:32 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:49:32 --> Utf8 Class Initialized
INFO - 2021-06-03 03:49:32 --> URI Class Initialized
INFO - 2021-06-03 03:49:32 --> Router Class Initialized
INFO - 2021-06-03 03:49:32 --> Output Class Initialized
INFO - 2021-06-03 03:49:32 --> Security Class Initialized
DEBUG - 2021-06-03 03:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:49:32 --> Input Class Initialized
INFO - 2021-06-03 03:49:32 --> Language Class Initialized
INFO - 2021-06-03 03:49:32 --> Language Class Initialized
INFO - 2021-06-03 03:49:32 --> Config Class Initialized
INFO - 2021-06-03 03:49:32 --> Loader Class Initialized
INFO - 2021-06-03 03:49:32 --> Helper loaded: url_helper
INFO - 2021-06-03 03:49:32 --> Helper loaded: file_helper
INFO - 2021-06-03 03:49:32 --> Helper loaded: form_helper
INFO - 2021-06-03 03:49:32 --> Helper loaded: my_helper
INFO - 2021-06-03 03:49:32 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:49:32 --> Controller Class Initialized
DEBUG - 2021-06-03 03:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:49:32 --> Final output sent to browser
DEBUG - 2021-06-03 03:49:32 --> Total execution time: 0.1591
INFO - 2021-06-03 03:50:17 --> Config Class Initialized
INFO - 2021-06-03 03:50:17 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:50:17 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:50:17 --> Utf8 Class Initialized
INFO - 2021-06-03 03:50:17 --> URI Class Initialized
INFO - 2021-06-03 03:50:17 --> Router Class Initialized
INFO - 2021-06-03 03:50:17 --> Output Class Initialized
INFO - 2021-06-03 03:50:17 --> Security Class Initialized
DEBUG - 2021-06-03 03:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:50:17 --> Input Class Initialized
INFO - 2021-06-03 03:50:17 --> Language Class Initialized
INFO - 2021-06-03 03:50:17 --> Language Class Initialized
INFO - 2021-06-03 03:50:17 --> Config Class Initialized
INFO - 2021-06-03 03:50:17 --> Loader Class Initialized
INFO - 2021-06-03 03:50:17 --> Helper loaded: url_helper
INFO - 2021-06-03 03:50:17 --> Helper loaded: file_helper
INFO - 2021-06-03 03:50:17 --> Helper loaded: form_helper
INFO - 2021-06-03 03:50:17 --> Helper loaded: my_helper
INFO - 2021-06-03 03:50:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:50:17 --> Controller Class Initialized
DEBUG - 2021-06-03 03:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 03:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 03:50:17 --> Final output sent to browser
DEBUG - 2021-06-03 03:50:17 --> Total execution time: 0.1402
INFO - 2021-06-03 03:50:19 --> Config Class Initialized
INFO - 2021-06-03 03:50:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:50:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:50:19 --> Utf8 Class Initialized
INFO - 2021-06-03 03:50:19 --> URI Class Initialized
INFO - 2021-06-03 03:50:19 --> Router Class Initialized
INFO - 2021-06-03 03:50:19 --> Output Class Initialized
INFO - 2021-06-03 03:50:19 --> Security Class Initialized
DEBUG - 2021-06-03 03:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:50:19 --> Input Class Initialized
INFO - 2021-06-03 03:50:19 --> Language Class Initialized
INFO - 2021-06-03 03:50:19 --> Language Class Initialized
INFO - 2021-06-03 03:50:19 --> Config Class Initialized
INFO - 2021-06-03 03:50:19 --> Loader Class Initialized
INFO - 2021-06-03 03:50:19 --> Helper loaded: url_helper
INFO - 2021-06-03 03:50:19 --> Helper loaded: file_helper
INFO - 2021-06-03 03:50:19 --> Helper loaded: form_helper
INFO - 2021-06-03 03:50:19 --> Helper loaded: my_helper
INFO - 2021-06-03 03:50:19 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:50:19 --> Controller Class Initialized
INFO - 2021-06-03 03:50:19 --> Final output sent to browser
DEBUG - 2021-06-03 03:50:19 --> Total execution time: 0.1115
INFO - 2021-06-03 03:52:32 --> Config Class Initialized
INFO - 2021-06-03 03:52:32 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:52:32 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:52:32 --> Utf8 Class Initialized
INFO - 2021-06-03 03:52:32 --> URI Class Initialized
INFO - 2021-06-03 03:52:32 --> Router Class Initialized
INFO - 2021-06-03 03:52:32 --> Output Class Initialized
INFO - 2021-06-03 03:52:32 --> Security Class Initialized
DEBUG - 2021-06-03 03:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:52:32 --> Input Class Initialized
INFO - 2021-06-03 03:52:32 --> Language Class Initialized
INFO - 2021-06-03 03:52:32 --> Language Class Initialized
INFO - 2021-06-03 03:52:32 --> Config Class Initialized
INFO - 2021-06-03 03:52:32 --> Loader Class Initialized
INFO - 2021-06-03 03:52:32 --> Helper loaded: url_helper
INFO - 2021-06-03 03:52:32 --> Helper loaded: file_helper
INFO - 2021-06-03 03:52:32 --> Helper loaded: form_helper
INFO - 2021-06-03 03:52:32 --> Helper loaded: my_helper
INFO - 2021-06-03 03:52:32 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:52:32 --> Controller Class Initialized
DEBUG - 2021-06-03 03:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:52:32 --> Final output sent to browser
DEBUG - 2021-06-03 03:52:32 --> Total execution time: 0.1536
INFO - 2021-06-03 03:52:33 --> Config Class Initialized
INFO - 2021-06-03 03:52:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:52:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:52:33 --> Utf8 Class Initialized
INFO - 2021-06-03 03:52:33 --> URI Class Initialized
INFO - 2021-06-03 03:52:33 --> Router Class Initialized
INFO - 2021-06-03 03:52:33 --> Output Class Initialized
INFO - 2021-06-03 03:52:33 --> Security Class Initialized
DEBUG - 2021-06-03 03:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:52:33 --> Input Class Initialized
INFO - 2021-06-03 03:52:33 --> Language Class Initialized
INFO - 2021-06-03 03:52:33 --> Language Class Initialized
INFO - 2021-06-03 03:52:33 --> Config Class Initialized
INFO - 2021-06-03 03:52:33 --> Loader Class Initialized
INFO - 2021-06-03 03:52:33 --> Helper loaded: url_helper
INFO - 2021-06-03 03:52:33 --> Helper loaded: file_helper
INFO - 2021-06-03 03:52:33 --> Helper loaded: form_helper
INFO - 2021-06-03 03:52:33 --> Helper loaded: my_helper
INFO - 2021-06-03 03:52:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:52:33 --> Controller Class Initialized
DEBUG - 2021-06-03 03:52:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:52:33 --> Final output sent to browser
DEBUG - 2021-06-03 03:52:33 --> Total execution time: 0.1629
INFO - 2021-06-03 03:52:43 --> Config Class Initialized
INFO - 2021-06-03 03:52:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 03:52:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 03:52:43 --> Utf8 Class Initialized
INFO - 2021-06-03 03:52:43 --> URI Class Initialized
INFO - 2021-06-03 03:52:43 --> Router Class Initialized
INFO - 2021-06-03 03:52:43 --> Output Class Initialized
INFO - 2021-06-03 03:52:43 --> Security Class Initialized
DEBUG - 2021-06-03 03:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 03:52:43 --> Input Class Initialized
INFO - 2021-06-03 03:52:43 --> Language Class Initialized
INFO - 2021-06-03 03:52:43 --> Language Class Initialized
INFO - 2021-06-03 03:52:43 --> Config Class Initialized
INFO - 2021-06-03 03:52:43 --> Loader Class Initialized
INFO - 2021-06-03 03:52:43 --> Helper loaded: url_helper
INFO - 2021-06-03 03:52:43 --> Helper loaded: file_helper
INFO - 2021-06-03 03:52:43 --> Helper loaded: form_helper
INFO - 2021-06-03 03:52:43 --> Helper loaded: my_helper
INFO - 2021-06-03 03:52:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 03:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 03:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 03:52:43 --> Controller Class Initialized
DEBUG - 2021-06-03 03:52:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 03:52:43 --> Final output sent to browser
DEBUG - 2021-06-03 03:52:43 --> Total execution time: 0.1891
INFO - 2021-06-03 04:02:45 --> Config Class Initialized
INFO - 2021-06-03 04:02:45 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:02:45 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:02:45 --> Utf8 Class Initialized
INFO - 2021-06-03 04:02:45 --> URI Class Initialized
INFO - 2021-06-03 04:02:45 --> Router Class Initialized
INFO - 2021-06-03 04:02:45 --> Output Class Initialized
INFO - 2021-06-03 04:02:45 --> Security Class Initialized
DEBUG - 2021-06-03 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:02:45 --> Input Class Initialized
INFO - 2021-06-03 04:02:45 --> Language Class Initialized
INFO - 2021-06-03 04:02:45 --> Language Class Initialized
INFO - 2021-06-03 04:02:45 --> Config Class Initialized
INFO - 2021-06-03 04:02:45 --> Loader Class Initialized
INFO - 2021-06-03 04:02:45 --> Helper loaded: url_helper
INFO - 2021-06-03 04:02:45 --> Helper loaded: file_helper
INFO - 2021-06-03 04:02:45 --> Helper loaded: form_helper
INFO - 2021-06-03 04:02:45 --> Helper loaded: my_helper
INFO - 2021-06-03 04:02:45 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:02:45 --> Controller Class Initialized
DEBUG - 2021-06-03 04:02:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:02:45 --> Final output sent to browser
DEBUG - 2021-06-03 04:02:45 --> Total execution time: 0.1766
INFO - 2021-06-03 04:02:49 --> Config Class Initialized
INFO - 2021-06-03 04:02:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:02:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:02:49 --> Utf8 Class Initialized
INFO - 2021-06-03 04:02:49 --> URI Class Initialized
INFO - 2021-06-03 04:02:49 --> Router Class Initialized
INFO - 2021-06-03 04:02:49 --> Output Class Initialized
INFO - 2021-06-03 04:02:49 --> Security Class Initialized
DEBUG - 2021-06-03 04:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:02:49 --> Input Class Initialized
INFO - 2021-06-03 04:02:49 --> Language Class Initialized
INFO - 2021-06-03 04:02:49 --> Language Class Initialized
INFO - 2021-06-03 04:02:49 --> Config Class Initialized
INFO - 2021-06-03 04:02:49 --> Loader Class Initialized
INFO - 2021-06-03 04:02:49 --> Helper loaded: url_helper
INFO - 2021-06-03 04:02:49 --> Helper loaded: file_helper
INFO - 2021-06-03 04:02:49 --> Helper loaded: form_helper
INFO - 2021-06-03 04:02:49 --> Helper loaded: my_helper
INFO - 2021-06-03 04:02:49 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:02:49 --> Controller Class Initialized
DEBUG - 2021-06-03 04:02:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 04:02:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 04:02:49 --> Final output sent to browser
DEBUG - 2021-06-03 04:02:49 --> Total execution time: 0.1498
INFO - 2021-06-03 04:02:50 --> Config Class Initialized
INFO - 2021-06-03 04:02:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:02:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:02:50 --> Utf8 Class Initialized
INFO - 2021-06-03 04:02:50 --> URI Class Initialized
INFO - 2021-06-03 04:02:50 --> Router Class Initialized
INFO - 2021-06-03 04:02:50 --> Output Class Initialized
INFO - 2021-06-03 04:02:50 --> Security Class Initialized
DEBUG - 2021-06-03 04:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:02:50 --> Input Class Initialized
INFO - 2021-06-03 04:02:50 --> Language Class Initialized
INFO - 2021-06-03 04:02:50 --> Language Class Initialized
INFO - 2021-06-03 04:02:50 --> Config Class Initialized
INFO - 2021-06-03 04:02:50 --> Loader Class Initialized
INFO - 2021-06-03 04:02:50 --> Helper loaded: url_helper
INFO - 2021-06-03 04:02:50 --> Helper loaded: file_helper
INFO - 2021-06-03 04:02:50 --> Helper loaded: form_helper
INFO - 2021-06-03 04:02:50 --> Helper loaded: my_helper
INFO - 2021-06-03 04:02:51 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:02:51 --> Controller Class Initialized
DEBUG - 2021-06-03 04:02:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:02:51 --> Final output sent to browser
DEBUG - 2021-06-03 04:02:51 --> Total execution time: 0.1810
INFO - 2021-06-03 04:08:57 --> Config Class Initialized
INFO - 2021-06-03 04:08:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:08:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:08:57 --> Utf8 Class Initialized
INFO - 2021-06-03 04:08:57 --> URI Class Initialized
INFO - 2021-06-03 04:08:57 --> Router Class Initialized
INFO - 2021-06-03 04:08:57 --> Output Class Initialized
INFO - 2021-06-03 04:08:57 --> Security Class Initialized
DEBUG - 2021-06-03 04:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:08:57 --> Input Class Initialized
INFO - 2021-06-03 04:08:57 --> Language Class Initialized
INFO - 2021-06-03 04:08:57 --> Language Class Initialized
INFO - 2021-06-03 04:08:57 --> Config Class Initialized
INFO - 2021-06-03 04:08:57 --> Loader Class Initialized
INFO - 2021-06-03 04:08:57 --> Helper loaded: url_helper
INFO - 2021-06-03 04:08:57 --> Helper loaded: file_helper
INFO - 2021-06-03 04:08:57 --> Helper loaded: form_helper
INFO - 2021-06-03 04:08:57 --> Helper loaded: my_helper
INFO - 2021-06-03 04:08:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:08:57 --> Controller Class Initialized
DEBUG - 2021-06-03 04:08:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 04:08:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 04:08:57 --> Final output sent to browser
DEBUG - 2021-06-03 04:08:57 --> Total execution time: 0.3282
INFO - 2021-06-03 04:11:44 --> Config Class Initialized
INFO - 2021-06-03 04:11:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:11:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:11:44 --> Utf8 Class Initialized
INFO - 2021-06-03 04:11:44 --> URI Class Initialized
INFO - 2021-06-03 04:11:44 --> Router Class Initialized
INFO - 2021-06-03 04:11:44 --> Output Class Initialized
INFO - 2021-06-03 04:11:44 --> Security Class Initialized
DEBUG - 2021-06-03 04:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:11:44 --> Input Class Initialized
INFO - 2021-06-03 04:11:44 --> Language Class Initialized
INFO - 2021-06-03 04:11:44 --> Language Class Initialized
INFO - 2021-06-03 04:11:44 --> Config Class Initialized
INFO - 2021-06-03 04:11:44 --> Loader Class Initialized
INFO - 2021-06-03 04:11:44 --> Helper loaded: url_helper
INFO - 2021-06-03 04:11:44 --> Helper loaded: file_helper
INFO - 2021-06-03 04:11:44 --> Helper loaded: form_helper
INFO - 2021-06-03 04:11:44 --> Helper loaded: my_helper
INFO - 2021-06-03 04:11:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:11:44 --> Controller Class Initialized
DEBUG - 2021-06-03 04:11:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 04:11:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 04:11:44 --> Final output sent to browser
DEBUG - 2021-06-03 04:11:44 --> Total execution time: 0.1440
INFO - 2021-06-03 04:11:45 --> Config Class Initialized
INFO - 2021-06-03 04:11:45 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:11:45 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:11:45 --> Utf8 Class Initialized
INFO - 2021-06-03 04:11:45 --> URI Class Initialized
INFO - 2021-06-03 04:11:45 --> Router Class Initialized
INFO - 2021-06-03 04:11:45 --> Output Class Initialized
INFO - 2021-06-03 04:11:45 --> Security Class Initialized
DEBUG - 2021-06-03 04:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:11:45 --> Input Class Initialized
INFO - 2021-06-03 04:11:45 --> Language Class Initialized
INFO - 2021-06-03 04:11:45 --> Language Class Initialized
INFO - 2021-06-03 04:11:45 --> Config Class Initialized
INFO - 2021-06-03 04:11:45 --> Loader Class Initialized
INFO - 2021-06-03 04:11:46 --> Helper loaded: url_helper
INFO - 2021-06-03 04:11:46 --> Helper loaded: file_helper
INFO - 2021-06-03 04:11:46 --> Helper loaded: form_helper
INFO - 2021-06-03 04:11:46 --> Helper loaded: my_helper
INFO - 2021-06-03 04:11:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:11:46 --> Controller Class Initialized
INFO - 2021-06-03 04:11:46 --> Final output sent to browser
DEBUG - 2021-06-03 04:11:46 --> Total execution time: 0.1092
INFO - 2021-06-03 04:11:53 --> Config Class Initialized
INFO - 2021-06-03 04:11:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:11:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:11:53 --> Utf8 Class Initialized
INFO - 2021-06-03 04:11:53 --> URI Class Initialized
INFO - 2021-06-03 04:11:53 --> Router Class Initialized
INFO - 2021-06-03 04:11:53 --> Output Class Initialized
INFO - 2021-06-03 04:11:53 --> Security Class Initialized
DEBUG - 2021-06-03 04:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:11:53 --> Input Class Initialized
INFO - 2021-06-03 04:11:53 --> Language Class Initialized
INFO - 2021-06-03 04:11:53 --> Language Class Initialized
INFO - 2021-06-03 04:11:53 --> Config Class Initialized
INFO - 2021-06-03 04:11:53 --> Loader Class Initialized
INFO - 2021-06-03 04:11:53 --> Helper loaded: url_helper
INFO - 2021-06-03 04:11:53 --> Helper loaded: file_helper
INFO - 2021-06-03 04:11:53 --> Helper loaded: form_helper
INFO - 2021-06-03 04:11:53 --> Helper loaded: my_helper
INFO - 2021-06-03 04:11:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:11:53 --> Controller Class Initialized
INFO - 2021-06-03 04:11:53 --> Final output sent to browser
DEBUG - 2021-06-03 04:11:53 --> Total execution time: 0.2244
INFO - 2021-06-03 04:11:55 --> Config Class Initialized
INFO - 2021-06-03 04:11:55 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:11:55 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:11:55 --> Utf8 Class Initialized
INFO - 2021-06-03 04:11:55 --> URI Class Initialized
INFO - 2021-06-03 04:11:55 --> Router Class Initialized
INFO - 2021-06-03 04:11:55 --> Output Class Initialized
INFO - 2021-06-03 04:11:55 --> Security Class Initialized
DEBUG - 2021-06-03 04:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:11:55 --> Input Class Initialized
INFO - 2021-06-03 04:11:55 --> Language Class Initialized
INFO - 2021-06-03 04:11:55 --> Language Class Initialized
INFO - 2021-06-03 04:11:55 --> Config Class Initialized
INFO - 2021-06-03 04:11:55 --> Loader Class Initialized
INFO - 2021-06-03 04:11:55 --> Helper loaded: url_helper
INFO - 2021-06-03 04:11:55 --> Helper loaded: file_helper
INFO - 2021-06-03 04:11:55 --> Helper loaded: form_helper
INFO - 2021-06-03 04:11:55 --> Helper loaded: my_helper
INFO - 2021-06-03 04:11:55 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:11:55 --> Controller Class Initialized
DEBUG - 2021-06-03 04:11:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 04:11:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 04:11:55 --> Final output sent to browser
DEBUG - 2021-06-03 04:11:55 --> Total execution time: 0.1514
INFO - 2021-06-03 04:11:56 --> Config Class Initialized
INFO - 2021-06-03 04:11:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:11:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:11:56 --> Utf8 Class Initialized
INFO - 2021-06-03 04:11:56 --> URI Class Initialized
INFO - 2021-06-03 04:11:56 --> Router Class Initialized
INFO - 2021-06-03 04:11:56 --> Output Class Initialized
INFO - 2021-06-03 04:11:56 --> Security Class Initialized
DEBUG - 2021-06-03 04:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:11:56 --> Input Class Initialized
INFO - 2021-06-03 04:11:56 --> Language Class Initialized
INFO - 2021-06-03 04:11:56 --> Language Class Initialized
INFO - 2021-06-03 04:11:56 --> Config Class Initialized
INFO - 2021-06-03 04:11:56 --> Loader Class Initialized
INFO - 2021-06-03 04:11:56 --> Helper loaded: url_helper
INFO - 2021-06-03 04:11:56 --> Helper loaded: file_helper
INFO - 2021-06-03 04:11:56 --> Helper loaded: form_helper
INFO - 2021-06-03 04:11:56 --> Helper loaded: my_helper
INFO - 2021-06-03 04:11:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:11:56 --> Controller Class Initialized
DEBUG - 2021-06-03 04:11:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:11:56 --> Final output sent to browser
DEBUG - 2021-06-03 04:11:56 --> Total execution time: 0.1234
INFO - 2021-06-03 04:34:48 --> Config Class Initialized
INFO - 2021-06-03 04:34:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:34:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:34:48 --> Utf8 Class Initialized
INFO - 2021-06-03 04:34:48 --> URI Class Initialized
INFO - 2021-06-03 04:34:48 --> Router Class Initialized
INFO - 2021-06-03 04:34:48 --> Output Class Initialized
INFO - 2021-06-03 04:34:48 --> Security Class Initialized
DEBUG - 2021-06-03 04:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:34:48 --> Input Class Initialized
INFO - 2021-06-03 04:34:48 --> Language Class Initialized
INFO - 2021-06-03 04:34:48 --> Language Class Initialized
INFO - 2021-06-03 04:34:48 --> Config Class Initialized
INFO - 2021-06-03 04:34:48 --> Loader Class Initialized
INFO - 2021-06-03 04:34:48 --> Helper loaded: url_helper
INFO - 2021-06-03 04:34:48 --> Helper loaded: file_helper
INFO - 2021-06-03 04:34:48 --> Helper loaded: form_helper
INFO - 2021-06-03 04:34:48 --> Helper loaded: my_helper
INFO - 2021-06-03 04:34:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:34:48 --> Controller Class Initialized
DEBUG - 2021-06-03 04:34:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:34:48 --> Final output sent to browser
DEBUG - 2021-06-03 04:34:48 --> Total execution time: 0.1606
INFO - 2021-06-03 04:36:35 --> Config Class Initialized
INFO - 2021-06-03 04:36:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:36:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:36:35 --> Utf8 Class Initialized
INFO - 2021-06-03 04:36:35 --> URI Class Initialized
INFO - 2021-06-03 04:36:35 --> Router Class Initialized
INFO - 2021-06-03 04:36:35 --> Output Class Initialized
INFO - 2021-06-03 04:36:35 --> Security Class Initialized
DEBUG - 2021-06-03 04:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:36:35 --> Input Class Initialized
INFO - 2021-06-03 04:36:35 --> Language Class Initialized
INFO - 2021-06-03 04:36:35 --> Language Class Initialized
INFO - 2021-06-03 04:36:35 --> Config Class Initialized
INFO - 2021-06-03 04:36:35 --> Loader Class Initialized
INFO - 2021-06-03 04:36:35 --> Helper loaded: url_helper
INFO - 2021-06-03 04:36:35 --> Helper loaded: file_helper
INFO - 2021-06-03 04:36:35 --> Helper loaded: form_helper
INFO - 2021-06-03 04:36:35 --> Helper loaded: my_helper
INFO - 2021-06-03 04:36:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:36:35 --> Controller Class Initialized
DEBUG - 2021-06-03 04:36:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:36:35 --> Final output sent to browser
DEBUG - 2021-06-03 04:36:35 --> Total execution time: 0.1499
INFO - 2021-06-03 04:37:10 --> Config Class Initialized
INFO - 2021-06-03 04:37:10 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:37:10 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:37:10 --> Utf8 Class Initialized
INFO - 2021-06-03 04:37:10 --> URI Class Initialized
INFO - 2021-06-03 04:37:10 --> Router Class Initialized
INFO - 2021-06-03 04:37:10 --> Output Class Initialized
INFO - 2021-06-03 04:37:10 --> Security Class Initialized
DEBUG - 2021-06-03 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:37:10 --> Input Class Initialized
INFO - 2021-06-03 04:37:10 --> Language Class Initialized
INFO - 2021-06-03 04:37:10 --> Language Class Initialized
INFO - 2021-06-03 04:37:10 --> Config Class Initialized
INFO - 2021-06-03 04:37:10 --> Loader Class Initialized
INFO - 2021-06-03 04:37:10 --> Helper loaded: url_helper
INFO - 2021-06-03 04:37:10 --> Helper loaded: file_helper
INFO - 2021-06-03 04:37:10 --> Helper loaded: form_helper
INFO - 2021-06-03 04:37:10 --> Helper loaded: my_helper
INFO - 2021-06-03 04:37:10 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:37:10 --> Controller Class Initialized
DEBUG - 2021-06-03 04:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:37:10 --> Final output sent to browser
DEBUG - 2021-06-03 04:37:10 --> Total execution time: 0.2614
INFO - 2021-06-03 04:38:03 --> Config Class Initialized
INFO - 2021-06-03 04:38:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:38:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:38:03 --> Utf8 Class Initialized
INFO - 2021-06-03 04:38:03 --> URI Class Initialized
INFO - 2021-06-03 04:38:03 --> Router Class Initialized
INFO - 2021-06-03 04:38:03 --> Output Class Initialized
INFO - 2021-06-03 04:38:03 --> Security Class Initialized
DEBUG - 2021-06-03 04:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:38:03 --> Input Class Initialized
INFO - 2021-06-03 04:38:03 --> Language Class Initialized
INFO - 2021-06-03 04:38:03 --> Language Class Initialized
INFO - 2021-06-03 04:38:03 --> Config Class Initialized
INFO - 2021-06-03 04:38:03 --> Loader Class Initialized
INFO - 2021-06-03 04:38:03 --> Helper loaded: url_helper
INFO - 2021-06-03 04:38:03 --> Helper loaded: file_helper
INFO - 2021-06-03 04:38:03 --> Helper loaded: form_helper
INFO - 2021-06-03 04:38:03 --> Helper loaded: my_helper
INFO - 2021-06-03 04:38:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:38:03 --> Controller Class Initialized
DEBUG - 2021-06-03 04:38:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:38:03 --> Final output sent to browser
DEBUG - 2021-06-03 04:38:03 --> Total execution time: 0.1724
INFO - 2021-06-03 04:38:16 --> Config Class Initialized
INFO - 2021-06-03 04:38:16 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:38:16 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:38:16 --> Utf8 Class Initialized
INFO - 2021-06-03 04:38:16 --> URI Class Initialized
INFO - 2021-06-03 04:38:16 --> Router Class Initialized
INFO - 2021-06-03 04:38:16 --> Output Class Initialized
INFO - 2021-06-03 04:38:16 --> Security Class Initialized
DEBUG - 2021-06-03 04:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:38:16 --> Input Class Initialized
INFO - 2021-06-03 04:38:16 --> Language Class Initialized
INFO - 2021-06-03 04:38:16 --> Language Class Initialized
INFO - 2021-06-03 04:38:16 --> Config Class Initialized
INFO - 2021-06-03 04:38:16 --> Loader Class Initialized
INFO - 2021-06-03 04:38:16 --> Helper loaded: url_helper
INFO - 2021-06-03 04:38:16 --> Helper loaded: file_helper
INFO - 2021-06-03 04:38:16 --> Helper loaded: form_helper
INFO - 2021-06-03 04:38:16 --> Helper loaded: my_helper
INFO - 2021-06-03 04:38:16 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:38:16 --> Controller Class Initialized
DEBUG - 2021-06-03 04:38:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:38:16 --> Final output sent to browser
DEBUG - 2021-06-03 04:38:16 --> Total execution time: 0.1380
INFO - 2021-06-03 04:41:16 --> Config Class Initialized
INFO - 2021-06-03 04:41:16 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:41:16 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:41:16 --> Utf8 Class Initialized
INFO - 2021-06-03 04:41:16 --> URI Class Initialized
INFO - 2021-06-03 04:41:16 --> Router Class Initialized
INFO - 2021-06-03 04:41:16 --> Output Class Initialized
INFO - 2021-06-03 04:41:16 --> Security Class Initialized
DEBUG - 2021-06-03 04:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:41:16 --> Input Class Initialized
INFO - 2021-06-03 04:41:16 --> Language Class Initialized
INFO - 2021-06-03 04:41:16 --> Language Class Initialized
INFO - 2021-06-03 04:41:16 --> Config Class Initialized
INFO - 2021-06-03 04:41:16 --> Loader Class Initialized
INFO - 2021-06-03 04:41:16 --> Helper loaded: url_helper
INFO - 2021-06-03 04:41:16 --> Helper loaded: file_helper
INFO - 2021-06-03 04:41:16 --> Helper loaded: form_helper
INFO - 2021-06-03 04:41:16 --> Helper loaded: my_helper
INFO - 2021-06-03 04:41:16 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:41:16 --> Controller Class Initialized
DEBUG - 2021-06-03 04:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:41:16 --> Final output sent to browser
DEBUG - 2021-06-03 04:41:16 --> Total execution time: 0.1577
INFO - 2021-06-03 04:42:09 --> Config Class Initialized
INFO - 2021-06-03 04:42:09 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:42:09 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:42:09 --> Utf8 Class Initialized
INFO - 2021-06-03 04:42:09 --> URI Class Initialized
INFO - 2021-06-03 04:42:09 --> Router Class Initialized
INFO - 2021-06-03 04:42:09 --> Output Class Initialized
INFO - 2021-06-03 04:42:09 --> Security Class Initialized
DEBUG - 2021-06-03 04:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:42:09 --> Input Class Initialized
INFO - 2021-06-03 04:42:09 --> Language Class Initialized
INFO - 2021-06-03 04:42:09 --> Language Class Initialized
INFO - 2021-06-03 04:42:09 --> Config Class Initialized
INFO - 2021-06-03 04:42:09 --> Loader Class Initialized
INFO - 2021-06-03 04:42:09 --> Helper loaded: url_helper
INFO - 2021-06-03 04:42:09 --> Helper loaded: file_helper
INFO - 2021-06-03 04:42:09 --> Helper loaded: form_helper
INFO - 2021-06-03 04:42:09 --> Helper loaded: my_helper
INFO - 2021-06-03 04:42:09 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:42:09 --> Controller Class Initialized
DEBUG - 2021-06-03 04:42:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:42:09 --> Final output sent to browser
DEBUG - 2021-06-03 04:42:09 --> Total execution time: 0.1803
INFO - 2021-06-03 04:42:36 --> Config Class Initialized
INFO - 2021-06-03 04:42:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:42:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:42:36 --> Utf8 Class Initialized
INFO - 2021-06-03 04:42:36 --> URI Class Initialized
INFO - 2021-06-03 04:42:36 --> Router Class Initialized
INFO - 2021-06-03 04:42:36 --> Output Class Initialized
INFO - 2021-06-03 04:42:36 --> Security Class Initialized
DEBUG - 2021-06-03 04:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:42:36 --> Input Class Initialized
INFO - 2021-06-03 04:42:36 --> Language Class Initialized
INFO - 2021-06-03 04:42:36 --> Language Class Initialized
INFO - 2021-06-03 04:42:36 --> Config Class Initialized
INFO - 2021-06-03 04:42:36 --> Loader Class Initialized
INFO - 2021-06-03 04:42:36 --> Helper loaded: url_helper
INFO - 2021-06-03 04:42:36 --> Helper loaded: file_helper
INFO - 2021-06-03 04:42:36 --> Helper loaded: form_helper
INFO - 2021-06-03 04:42:36 --> Helper loaded: my_helper
INFO - 2021-06-03 04:42:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:42:36 --> Controller Class Initialized
DEBUG - 2021-06-03 04:42:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:42:37 --> Final output sent to browser
DEBUG - 2021-06-03 04:42:37 --> Total execution time: 0.1653
INFO - 2021-06-03 04:42:56 --> Config Class Initialized
INFO - 2021-06-03 04:42:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:42:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:42:56 --> Utf8 Class Initialized
INFO - 2021-06-03 04:42:56 --> URI Class Initialized
INFO - 2021-06-03 04:42:56 --> Router Class Initialized
INFO - 2021-06-03 04:42:56 --> Output Class Initialized
INFO - 2021-06-03 04:42:56 --> Security Class Initialized
DEBUG - 2021-06-03 04:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:42:56 --> Input Class Initialized
INFO - 2021-06-03 04:42:56 --> Language Class Initialized
INFO - 2021-06-03 04:42:56 --> Language Class Initialized
INFO - 2021-06-03 04:42:56 --> Config Class Initialized
INFO - 2021-06-03 04:42:56 --> Loader Class Initialized
INFO - 2021-06-03 04:42:56 --> Helper loaded: url_helper
INFO - 2021-06-03 04:42:56 --> Helper loaded: file_helper
INFO - 2021-06-03 04:42:56 --> Helper loaded: form_helper
INFO - 2021-06-03 04:42:56 --> Helper loaded: my_helper
INFO - 2021-06-03 04:42:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:42:56 --> Controller Class Initialized
DEBUG - 2021-06-03 04:42:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:42:56 --> Final output sent to browser
DEBUG - 2021-06-03 04:42:56 --> Total execution time: 0.1548
INFO - 2021-06-03 04:43:59 --> Config Class Initialized
INFO - 2021-06-03 04:43:59 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:43:59 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:43:59 --> Utf8 Class Initialized
INFO - 2021-06-03 04:43:59 --> URI Class Initialized
INFO - 2021-06-03 04:43:59 --> Router Class Initialized
INFO - 2021-06-03 04:43:59 --> Output Class Initialized
INFO - 2021-06-03 04:43:59 --> Security Class Initialized
DEBUG - 2021-06-03 04:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:43:59 --> Input Class Initialized
INFO - 2021-06-03 04:43:59 --> Language Class Initialized
INFO - 2021-06-03 04:43:59 --> Language Class Initialized
INFO - 2021-06-03 04:43:59 --> Config Class Initialized
INFO - 2021-06-03 04:43:59 --> Loader Class Initialized
INFO - 2021-06-03 04:43:59 --> Helper loaded: url_helper
INFO - 2021-06-03 04:43:59 --> Helper loaded: file_helper
INFO - 2021-06-03 04:43:59 --> Helper loaded: form_helper
INFO - 2021-06-03 04:43:59 --> Helper loaded: my_helper
INFO - 2021-06-03 04:43:59 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:43:59 --> Controller Class Initialized
DEBUG - 2021-06-03 04:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:43:59 --> Final output sent to browser
DEBUG - 2021-06-03 04:43:59 --> Total execution time: 0.1729
INFO - 2021-06-03 04:44:36 --> Config Class Initialized
INFO - 2021-06-03 04:44:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:44:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:44:36 --> Utf8 Class Initialized
INFO - 2021-06-03 04:44:36 --> URI Class Initialized
INFO - 2021-06-03 04:44:36 --> Router Class Initialized
INFO - 2021-06-03 04:44:36 --> Output Class Initialized
INFO - 2021-06-03 04:44:36 --> Security Class Initialized
DEBUG - 2021-06-03 04:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:44:36 --> Input Class Initialized
INFO - 2021-06-03 04:44:36 --> Language Class Initialized
INFO - 2021-06-03 04:44:36 --> Language Class Initialized
INFO - 2021-06-03 04:44:36 --> Config Class Initialized
INFO - 2021-06-03 04:44:36 --> Loader Class Initialized
INFO - 2021-06-03 04:44:36 --> Helper loaded: url_helper
INFO - 2021-06-03 04:44:36 --> Helper loaded: file_helper
INFO - 2021-06-03 04:44:36 --> Helper loaded: form_helper
INFO - 2021-06-03 04:44:36 --> Helper loaded: my_helper
INFO - 2021-06-03 04:44:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:44:36 --> Controller Class Initialized
DEBUG - 2021-06-03 04:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:44:36 --> Final output sent to browser
DEBUG - 2021-06-03 04:44:36 --> Total execution time: 0.1632
INFO - 2021-06-03 04:45:00 --> Config Class Initialized
INFO - 2021-06-03 04:45:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:45:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:45:00 --> Utf8 Class Initialized
INFO - 2021-06-03 04:45:00 --> URI Class Initialized
INFO - 2021-06-03 04:45:00 --> Router Class Initialized
INFO - 2021-06-03 04:45:00 --> Output Class Initialized
INFO - 2021-06-03 04:45:00 --> Security Class Initialized
DEBUG - 2021-06-03 04:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:45:00 --> Input Class Initialized
INFO - 2021-06-03 04:45:00 --> Language Class Initialized
INFO - 2021-06-03 04:45:00 --> Language Class Initialized
INFO - 2021-06-03 04:45:00 --> Config Class Initialized
INFO - 2021-06-03 04:45:00 --> Loader Class Initialized
INFO - 2021-06-03 04:45:00 --> Helper loaded: url_helper
INFO - 2021-06-03 04:45:00 --> Helper loaded: file_helper
INFO - 2021-06-03 04:45:00 --> Helper loaded: form_helper
INFO - 2021-06-03 04:45:00 --> Helper loaded: my_helper
INFO - 2021-06-03 04:45:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:45:00 --> Controller Class Initialized
DEBUG - 2021-06-03 04:45:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:45:00 --> Final output sent to browser
DEBUG - 2021-06-03 04:45:00 --> Total execution time: 0.1808
INFO - 2021-06-03 04:45:25 --> Config Class Initialized
INFO - 2021-06-03 04:45:25 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:45:25 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:45:25 --> Utf8 Class Initialized
INFO - 2021-06-03 04:45:25 --> URI Class Initialized
INFO - 2021-06-03 04:45:25 --> Router Class Initialized
INFO - 2021-06-03 04:45:25 --> Output Class Initialized
INFO - 2021-06-03 04:45:25 --> Security Class Initialized
DEBUG - 2021-06-03 04:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:45:25 --> Input Class Initialized
INFO - 2021-06-03 04:45:25 --> Language Class Initialized
INFO - 2021-06-03 04:45:25 --> Language Class Initialized
INFO - 2021-06-03 04:45:25 --> Config Class Initialized
INFO - 2021-06-03 04:45:25 --> Loader Class Initialized
INFO - 2021-06-03 04:45:25 --> Helper loaded: url_helper
INFO - 2021-06-03 04:45:25 --> Helper loaded: file_helper
INFO - 2021-06-03 04:45:25 --> Helper loaded: form_helper
INFO - 2021-06-03 04:45:25 --> Helper loaded: my_helper
INFO - 2021-06-03 04:45:25 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:45:25 --> Controller Class Initialized
DEBUG - 2021-06-03 04:45:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:45:25 --> Final output sent to browser
DEBUG - 2021-06-03 04:45:25 --> Total execution time: 0.1639
INFO - 2021-06-03 04:45:30 --> Config Class Initialized
INFO - 2021-06-03 04:45:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:45:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:45:30 --> Utf8 Class Initialized
INFO - 2021-06-03 04:45:30 --> URI Class Initialized
INFO - 2021-06-03 04:45:30 --> Router Class Initialized
INFO - 2021-06-03 04:45:30 --> Output Class Initialized
INFO - 2021-06-03 04:45:30 --> Security Class Initialized
DEBUG - 2021-06-03 04:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:45:30 --> Input Class Initialized
INFO - 2021-06-03 04:45:30 --> Language Class Initialized
INFO - 2021-06-03 04:45:30 --> Language Class Initialized
INFO - 2021-06-03 04:45:30 --> Config Class Initialized
INFO - 2021-06-03 04:45:30 --> Loader Class Initialized
INFO - 2021-06-03 04:45:30 --> Helper loaded: url_helper
INFO - 2021-06-03 04:45:30 --> Helper loaded: file_helper
INFO - 2021-06-03 04:45:30 --> Helper loaded: form_helper
INFO - 2021-06-03 04:45:30 --> Helper loaded: my_helper
INFO - 2021-06-03 04:45:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:45:30 --> Controller Class Initialized
DEBUG - 2021-06-03 04:45:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:45:30 --> Final output sent to browser
DEBUG - 2021-06-03 04:45:30 --> Total execution time: 0.1549
INFO - 2021-06-03 04:45:42 --> Config Class Initialized
INFO - 2021-06-03 04:45:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:45:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:45:42 --> Utf8 Class Initialized
INFO - 2021-06-03 04:45:42 --> URI Class Initialized
INFO - 2021-06-03 04:45:42 --> Router Class Initialized
INFO - 2021-06-03 04:45:42 --> Output Class Initialized
INFO - 2021-06-03 04:45:42 --> Security Class Initialized
DEBUG - 2021-06-03 04:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:45:42 --> Input Class Initialized
INFO - 2021-06-03 04:45:42 --> Language Class Initialized
INFO - 2021-06-03 04:45:42 --> Language Class Initialized
INFO - 2021-06-03 04:45:42 --> Config Class Initialized
INFO - 2021-06-03 04:45:42 --> Loader Class Initialized
INFO - 2021-06-03 04:45:42 --> Helper loaded: url_helper
INFO - 2021-06-03 04:45:42 --> Helper loaded: file_helper
INFO - 2021-06-03 04:45:42 --> Helper loaded: form_helper
INFO - 2021-06-03 04:45:42 --> Helper loaded: my_helper
INFO - 2021-06-03 04:45:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:45:42 --> Controller Class Initialized
DEBUG - 2021-06-03 04:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:45:42 --> Final output sent to browser
DEBUG - 2021-06-03 04:45:42 --> Total execution time: 0.1430
INFO - 2021-06-03 04:45:51 --> Config Class Initialized
INFO - 2021-06-03 04:45:51 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:45:51 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:45:51 --> Utf8 Class Initialized
INFO - 2021-06-03 04:45:51 --> URI Class Initialized
INFO - 2021-06-03 04:45:51 --> Router Class Initialized
INFO - 2021-06-03 04:45:51 --> Output Class Initialized
INFO - 2021-06-03 04:45:51 --> Security Class Initialized
DEBUG - 2021-06-03 04:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:45:51 --> Input Class Initialized
INFO - 2021-06-03 04:45:51 --> Language Class Initialized
INFO - 2021-06-03 04:45:51 --> Language Class Initialized
INFO - 2021-06-03 04:45:51 --> Config Class Initialized
INFO - 2021-06-03 04:45:51 --> Loader Class Initialized
INFO - 2021-06-03 04:45:51 --> Helper loaded: url_helper
INFO - 2021-06-03 04:45:51 --> Helper loaded: file_helper
INFO - 2021-06-03 04:45:51 --> Helper loaded: form_helper
INFO - 2021-06-03 04:45:51 --> Helper loaded: my_helper
INFO - 2021-06-03 04:45:51 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:45:51 --> Controller Class Initialized
DEBUG - 2021-06-03 04:45:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:45:51 --> Final output sent to browser
DEBUG - 2021-06-03 04:45:51 --> Total execution time: 0.1745
INFO - 2021-06-03 04:48:54 --> Config Class Initialized
INFO - 2021-06-03 04:48:54 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:48:54 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:48:54 --> Utf8 Class Initialized
INFO - 2021-06-03 04:48:54 --> URI Class Initialized
INFO - 2021-06-03 04:48:54 --> Router Class Initialized
INFO - 2021-06-03 04:48:54 --> Output Class Initialized
INFO - 2021-06-03 04:48:54 --> Security Class Initialized
DEBUG - 2021-06-03 04:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:48:54 --> Input Class Initialized
INFO - 2021-06-03 04:48:54 --> Language Class Initialized
INFO - 2021-06-03 04:48:54 --> Language Class Initialized
INFO - 2021-06-03 04:48:54 --> Config Class Initialized
INFO - 2021-06-03 04:48:54 --> Loader Class Initialized
INFO - 2021-06-03 04:48:54 --> Helper loaded: url_helper
INFO - 2021-06-03 04:48:54 --> Helper loaded: file_helper
INFO - 2021-06-03 04:48:54 --> Helper loaded: form_helper
INFO - 2021-06-03 04:48:54 --> Helper loaded: my_helper
INFO - 2021-06-03 04:48:54 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:48:54 --> Controller Class Initialized
DEBUG - 2021-06-03 04:48:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:48:54 --> Final output sent to browser
DEBUG - 2021-06-03 04:48:54 --> Total execution time: 0.1699
INFO - 2021-06-03 04:49:21 --> Config Class Initialized
INFO - 2021-06-03 04:49:21 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:49:21 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:49:21 --> Utf8 Class Initialized
INFO - 2021-06-03 04:49:21 --> URI Class Initialized
INFO - 2021-06-03 04:49:21 --> Router Class Initialized
INFO - 2021-06-03 04:49:21 --> Output Class Initialized
INFO - 2021-06-03 04:49:21 --> Security Class Initialized
DEBUG - 2021-06-03 04:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:49:21 --> Input Class Initialized
INFO - 2021-06-03 04:49:21 --> Language Class Initialized
INFO - 2021-06-03 04:49:21 --> Language Class Initialized
INFO - 2021-06-03 04:49:21 --> Config Class Initialized
INFO - 2021-06-03 04:49:21 --> Loader Class Initialized
INFO - 2021-06-03 04:49:21 --> Helper loaded: url_helper
INFO - 2021-06-03 04:49:21 --> Helper loaded: file_helper
INFO - 2021-06-03 04:49:21 --> Helper loaded: form_helper
INFO - 2021-06-03 04:49:21 --> Helper loaded: my_helper
INFO - 2021-06-03 04:49:21 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:49:21 --> Controller Class Initialized
DEBUG - 2021-06-03 04:49:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:49:21 --> Final output sent to browser
DEBUG - 2021-06-03 04:49:21 --> Total execution time: 0.1975
INFO - 2021-06-03 04:49:42 --> Config Class Initialized
INFO - 2021-06-03 04:49:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:49:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:49:42 --> Utf8 Class Initialized
INFO - 2021-06-03 04:49:42 --> URI Class Initialized
INFO - 2021-06-03 04:49:42 --> Router Class Initialized
INFO - 2021-06-03 04:49:42 --> Output Class Initialized
INFO - 2021-06-03 04:49:42 --> Security Class Initialized
DEBUG - 2021-06-03 04:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:49:42 --> Input Class Initialized
INFO - 2021-06-03 04:49:42 --> Language Class Initialized
INFO - 2021-06-03 04:49:42 --> Language Class Initialized
INFO - 2021-06-03 04:49:42 --> Config Class Initialized
INFO - 2021-06-03 04:49:42 --> Loader Class Initialized
INFO - 2021-06-03 04:49:42 --> Helper loaded: url_helper
INFO - 2021-06-03 04:49:42 --> Helper loaded: file_helper
INFO - 2021-06-03 04:49:42 --> Helper loaded: form_helper
INFO - 2021-06-03 04:49:42 --> Helper loaded: my_helper
INFO - 2021-06-03 04:49:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:49:42 --> Controller Class Initialized
DEBUG - 2021-06-03 04:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:49:42 --> Final output sent to browser
DEBUG - 2021-06-03 04:49:42 --> Total execution time: 0.2116
INFO - 2021-06-03 04:49:56 --> Config Class Initialized
INFO - 2021-06-03 04:49:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:49:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:49:56 --> Utf8 Class Initialized
INFO - 2021-06-03 04:49:56 --> URI Class Initialized
INFO - 2021-06-03 04:49:56 --> Router Class Initialized
INFO - 2021-06-03 04:49:56 --> Output Class Initialized
INFO - 2021-06-03 04:49:56 --> Security Class Initialized
DEBUG - 2021-06-03 04:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:49:56 --> Input Class Initialized
INFO - 2021-06-03 04:49:56 --> Language Class Initialized
INFO - 2021-06-03 04:49:56 --> Language Class Initialized
INFO - 2021-06-03 04:49:56 --> Config Class Initialized
INFO - 2021-06-03 04:49:56 --> Loader Class Initialized
INFO - 2021-06-03 04:49:56 --> Helper loaded: url_helper
INFO - 2021-06-03 04:49:56 --> Helper loaded: file_helper
INFO - 2021-06-03 04:49:56 --> Helper loaded: form_helper
INFO - 2021-06-03 04:49:56 --> Helper loaded: my_helper
INFO - 2021-06-03 04:49:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:49:56 --> Controller Class Initialized
DEBUG - 2021-06-03 04:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:49:56 --> Final output sent to browser
DEBUG - 2021-06-03 04:49:56 --> Total execution time: 0.1716
INFO - 2021-06-03 04:50:23 --> Config Class Initialized
INFO - 2021-06-03 04:50:23 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:50:23 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:50:23 --> Utf8 Class Initialized
INFO - 2021-06-03 04:50:23 --> URI Class Initialized
INFO - 2021-06-03 04:50:23 --> Router Class Initialized
INFO - 2021-06-03 04:50:23 --> Output Class Initialized
INFO - 2021-06-03 04:50:23 --> Security Class Initialized
DEBUG - 2021-06-03 04:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:50:23 --> Input Class Initialized
INFO - 2021-06-03 04:50:23 --> Language Class Initialized
INFO - 2021-06-03 04:50:23 --> Language Class Initialized
INFO - 2021-06-03 04:50:23 --> Config Class Initialized
INFO - 2021-06-03 04:50:23 --> Loader Class Initialized
INFO - 2021-06-03 04:50:23 --> Helper loaded: url_helper
INFO - 2021-06-03 04:50:23 --> Helper loaded: file_helper
INFO - 2021-06-03 04:50:23 --> Helper loaded: form_helper
INFO - 2021-06-03 04:50:23 --> Helper loaded: my_helper
INFO - 2021-06-03 04:50:23 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:50:23 --> Controller Class Initialized
DEBUG - 2021-06-03 04:50:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:50:23 --> Final output sent to browser
DEBUG - 2021-06-03 04:50:23 --> Total execution time: 0.1648
INFO - 2021-06-03 04:50:46 --> Config Class Initialized
INFO - 2021-06-03 04:50:46 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:50:46 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:50:46 --> Utf8 Class Initialized
INFO - 2021-06-03 04:50:46 --> URI Class Initialized
INFO - 2021-06-03 04:50:46 --> Router Class Initialized
INFO - 2021-06-03 04:50:46 --> Output Class Initialized
INFO - 2021-06-03 04:50:46 --> Security Class Initialized
DEBUG - 2021-06-03 04:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:50:46 --> Input Class Initialized
INFO - 2021-06-03 04:50:46 --> Language Class Initialized
INFO - 2021-06-03 04:50:46 --> Language Class Initialized
INFO - 2021-06-03 04:50:46 --> Config Class Initialized
INFO - 2021-06-03 04:50:46 --> Loader Class Initialized
INFO - 2021-06-03 04:50:46 --> Helper loaded: url_helper
INFO - 2021-06-03 04:50:46 --> Helper loaded: file_helper
INFO - 2021-06-03 04:50:46 --> Helper loaded: form_helper
INFO - 2021-06-03 04:50:46 --> Helper loaded: my_helper
INFO - 2021-06-03 04:50:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:50:46 --> Controller Class Initialized
DEBUG - 2021-06-03 04:50:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:50:46 --> Final output sent to browser
DEBUG - 2021-06-03 04:50:46 --> Total execution time: 0.1816
INFO - 2021-06-03 04:51:10 --> Config Class Initialized
INFO - 2021-06-03 04:51:10 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:51:10 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:51:10 --> Utf8 Class Initialized
INFO - 2021-06-03 04:51:10 --> URI Class Initialized
INFO - 2021-06-03 04:51:10 --> Router Class Initialized
INFO - 2021-06-03 04:51:10 --> Output Class Initialized
INFO - 2021-06-03 04:51:10 --> Security Class Initialized
DEBUG - 2021-06-03 04:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:51:10 --> Input Class Initialized
INFO - 2021-06-03 04:51:10 --> Language Class Initialized
INFO - 2021-06-03 04:51:10 --> Language Class Initialized
INFO - 2021-06-03 04:51:10 --> Config Class Initialized
INFO - 2021-06-03 04:51:10 --> Loader Class Initialized
INFO - 2021-06-03 04:51:10 --> Helper loaded: url_helper
INFO - 2021-06-03 04:51:10 --> Helper loaded: file_helper
INFO - 2021-06-03 04:51:10 --> Helper loaded: form_helper
INFO - 2021-06-03 04:51:10 --> Helper loaded: my_helper
INFO - 2021-06-03 04:51:10 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:51:10 --> Controller Class Initialized
DEBUG - 2021-06-03 04:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:51:10 --> Final output sent to browser
DEBUG - 2021-06-03 04:51:10 --> Total execution time: 0.1666
INFO - 2021-06-03 04:51:27 --> Config Class Initialized
INFO - 2021-06-03 04:51:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:51:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:51:27 --> Utf8 Class Initialized
INFO - 2021-06-03 04:51:27 --> URI Class Initialized
INFO - 2021-06-03 04:51:27 --> Router Class Initialized
INFO - 2021-06-03 04:51:27 --> Output Class Initialized
INFO - 2021-06-03 04:51:27 --> Security Class Initialized
DEBUG - 2021-06-03 04:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:51:27 --> Input Class Initialized
INFO - 2021-06-03 04:51:27 --> Language Class Initialized
INFO - 2021-06-03 04:51:27 --> Language Class Initialized
INFO - 2021-06-03 04:51:27 --> Config Class Initialized
INFO - 2021-06-03 04:51:27 --> Loader Class Initialized
INFO - 2021-06-03 04:51:27 --> Helper loaded: url_helper
INFO - 2021-06-03 04:51:27 --> Helper loaded: file_helper
INFO - 2021-06-03 04:51:27 --> Helper loaded: form_helper
INFO - 2021-06-03 04:51:27 --> Helper loaded: my_helper
INFO - 2021-06-03 04:51:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:51:27 --> Controller Class Initialized
DEBUG - 2021-06-03 04:51:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:51:27 --> Final output sent to browser
DEBUG - 2021-06-03 04:51:27 --> Total execution time: 0.1669
INFO - 2021-06-03 04:51:47 --> Config Class Initialized
INFO - 2021-06-03 04:51:47 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:51:47 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:51:47 --> Utf8 Class Initialized
INFO - 2021-06-03 04:51:47 --> URI Class Initialized
INFO - 2021-06-03 04:51:47 --> Router Class Initialized
INFO - 2021-06-03 04:51:47 --> Output Class Initialized
INFO - 2021-06-03 04:51:47 --> Security Class Initialized
DEBUG - 2021-06-03 04:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:51:47 --> Input Class Initialized
INFO - 2021-06-03 04:51:47 --> Language Class Initialized
INFO - 2021-06-03 04:51:47 --> Language Class Initialized
INFO - 2021-06-03 04:51:47 --> Config Class Initialized
INFO - 2021-06-03 04:51:47 --> Loader Class Initialized
INFO - 2021-06-03 04:51:47 --> Helper loaded: url_helper
INFO - 2021-06-03 04:51:47 --> Helper loaded: file_helper
INFO - 2021-06-03 04:51:47 --> Helper loaded: form_helper
INFO - 2021-06-03 04:51:47 --> Helper loaded: my_helper
INFO - 2021-06-03 04:51:47 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:51:47 --> Controller Class Initialized
DEBUG - 2021-06-03 04:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:51:47 --> Final output sent to browser
DEBUG - 2021-06-03 04:51:47 --> Total execution time: 0.1468
INFO - 2021-06-03 04:51:59 --> Config Class Initialized
INFO - 2021-06-03 04:51:59 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:51:59 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:51:59 --> Utf8 Class Initialized
INFO - 2021-06-03 04:51:59 --> URI Class Initialized
INFO - 2021-06-03 04:51:59 --> Router Class Initialized
INFO - 2021-06-03 04:51:59 --> Output Class Initialized
INFO - 2021-06-03 04:51:59 --> Security Class Initialized
DEBUG - 2021-06-03 04:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:51:59 --> Input Class Initialized
INFO - 2021-06-03 04:51:59 --> Language Class Initialized
INFO - 2021-06-03 04:51:59 --> Language Class Initialized
INFO - 2021-06-03 04:51:59 --> Config Class Initialized
INFO - 2021-06-03 04:51:59 --> Loader Class Initialized
INFO - 2021-06-03 04:51:59 --> Helper loaded: url_helper
INFO - 2021-06-03 04:51:59 --> Helper loaded: file_helper
INFO - 2021-06-03 04:51:59 --> Helper loaded: form_helper
INFO - 2021-06-03 04:51:59 --> Helper loaded: my_helper
INFO - 2021-06-03 04:51:59 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:51:59 --> Controller Class Initialized
DEBUG - 2021-06-03 04:51:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:51:59 --> Final output sent to browser
DEBUG - 2021-06-03 04:51:59 --> Total execution time: 0.1558
INFO - 2021-06-03 04:54:35 --> Config Class Initialized
INFO - 2021-06-03 04:54:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:54:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:54:35 --> Utf8 Class Initialized
INFO - 2021-06-03 04:54:35 --> URI Class Initialized
INFO - 2021-06-03 04:54:35 --> Router Class Initialized
INFO - 2021-06-03 04:54:35 --> Output Class Initialized
INFO - 2021-06-03 04:54:35 --> Security Class Initialized
DEBUG - 2021-06-03 04:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:54:35 --> Input Class Initialized
INFO - 2021-06-03 04:54:35 --> Language Class Initialized
INFO - 2021-06-03 04:54:35 --> Language Class Initialized
INFO - 2021-06-03 04:54:35 --> Config Class Initialized
INFO - 2021-06-03 04:54:35 --> Loader Class Initialized
INFO - 2021-06-03 04:54:35 --> Helper loaded: url_helper
INFO - 2021-06-03 04:54:35 --> Helper loaded: file_helper
INFO - 2021-06-03 04:54:35 --> Helper loaded: form_helper
INFO - 2021-06-03 04:54:35 --> Helper loaded: my_helper
INFO - 2021-06-03 04:54:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:54:35 --> Controller Class Initialized
DEBUG - 2021-06-03 04:54:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:54:35 --> Final output sent to browser
DEBUG - 2021-06-03 04:54:35 --> Total execution time: 0.1566
INFO - 2021-06-03 04:54:42 --> Config Class Initialized
INFO - 2021-06-03 04:54:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:54:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:54:42 --> Utf8 Class Initialized
INFO - 2021-06-03 04:54:42 --> URI Class Initialized
INFO - 2021-06-03 04:54:42 --> Router Class Initialized
INFO - 2021-06-03 04:54:42 --> Output Class Initialized
INFO - 2021-06-03 04:54:42 --> Security Class Initialized
DEBUG - 2021-06-03 04:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:54:42 --> Input Class Initialized
INFO - 2021-06-03 04:54:42 --> Language Class Initialized
INFO - 2021-06-03 04:54:42 --> Language Class Initialized
INFO - 2021-06-03 04:54:42 --> Config Class Initialized
INFO - 2021-06-03 04:54:42 --> Loader Class Initialized
INFO - 2021-06-03 04:54:42 --> Helper loaded: url_helper
INFO - 2021-06-03 04:54:42 --> Helper loaded: file_helper
INFO - 2021-06-03 04:54:42 --> Helper loaded: form_helper
INFO - 2021-06-03 04:54:42 --> Helper loaded: my_helper
INFO - 2021-06-03 04:54:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:54:42 --> Controller Class Initialized
DEBUG - 2021-06-03 04:54:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:54:42 --> Final output sent to browser
DEBUG - 2021-06-03 04:54:42 --> Total execution time: 0.1776
INFO - 2021-06-03 04:54:58 --> Config Class Initialized
INFO - 2021-06-03 04:54:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:54:58 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:54:58 --> Utf8 Class Initialized
INFO - 2021-06-03 04:54:58 --> URI Class Initialized
INFO - 2021-06-03 04:54:58 --> Router Class Initialized
INFO - 2021-06-03 04:54:58 --> Output Class Initialized
INFO - 2021-06-03 04:54:58 --> Security Class Initialized
DEBUG - 2021-06-03 04:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:54:58 --> Input Class Initialized
INFO - 2021-06-03 04:54:58 --> Language Class Initialized
INFO - 2021-06-03 04:54:58 --> Language Class Initialized
INFO - 2021-06-03 04:54:58 --> Config Class Initialized
INFO - 2021-06-03 04:54:58 --> Loader Class Initialized
INFO - 2021-06-03 04:54:58 --> Helper loaded: url_helper
INFO - 2021-06-03 04:54:58 --> Helper loaded: file_helper
INFO - 2021-06-03 04:54:58 --> Helper loaded: form_helper
INFO - 2021-06-03 04:54:58 --> Helper loaded: my_helper
INFO - 2021-06-03 04:54:58 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:54:58 --> Controller Class Initialized
DEBUG - 2021-06-03 04:54:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:54:58 --> Final output sent to browser
DEBUG - 2021-06-03 04:54:58 --> Total execution time: 0.1817
INFO - 2021-06-03 04:59:36 --> Config Class Initialized
INFO - 2021-06-03 04:59:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 04:59:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 04:59:36 --> Utf8 Class Initialized
INFO - 2021-06-03 04:59:36 --> URI Class Initialized
INFO - 2021-06-03 04:59:36 --> Router Class Initialized
INFO - 2021-06-03 04:59:36 --> Output Class Initialized
INFO - 2021-06-03 04:59:36 --> Security Class Initialized
DEBUG - 2021-06-03 04:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 04:59:36 --> Input Class Initialized
INFO - 2021-06-03 04:59:36 --> Language Class Initialized
INFO - 2021-06-03 04:59:36 --> Language Class Initialized
INFO - 2021-06-03 04:59:36 --> Config Class Initialized
INFO - 2021-06-03 04:59:36 --> Loader Class Initialized
INFO - 2021-06-03 04:59:36 --> Helper loaded: url_helper
INFO - 2021-06-03 04:59:36 --> Helper loaded: file_helper
INFO - 2021-06-03 04:59:36 --> Helper loaded: form_helper
INFO - 2021-06-03 04:59:36 --> Helper loaded: my_helper
INFO - 2021-06-03 04:59:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 04:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 04:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 04:59:36 --> Controller Class Initialized
DEBUG - 2021-06-03 04:59:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 04:59:36 --> Final output sent to browser
DEBUG - 2021-06-03 04:59:36 --> Total execution time: 0.1838
INFO - 2021-06-03 05:00:03 --> Config Class Initialized
INFO - 2021-06-03 05:00:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:00:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:00:03 --> Utf8 Class Initialized
INFO - 2021-06-03 05:00:03 --> URI Class Initialized
INFO - 2021-06-03 05:00:03 --> Router Class Initialized
INFO - 2021-06-03 05:00:03 --> Output Class Initialized
INFO - 2021-06-03 05:00:03 --> Security Class Initialized
DEBUG - 2021-06-03 05:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:00:03 --> Input Class Initialized
INFO - 2021-06-03 05:00:03 --> Language Class Initialized
INFO - 2021-06-03 05:00:03 --> Language Class Initialized
INFO - 2021-06-03 05:00:03 --> Config Class Initialized
INFO - 2021-06-03 05:00:03 --> Loader Class Initialized
INFO - 2021-06-03 05:00:03 --> Helper loaded: url_helper
INFO - 2021-06-03 05:00:03 --> Helper loaded: file_helper
INFO - 2021-06-03 05:00:03 --> Helper loaded: form_helper
INFO - 2021-06-03 05:00:03 --> Helper loaded: my_helper
INFO - 2021-06-03 05:00:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:00:03 --> Controller Class Initialized
DEBUG - 2021-06-03 05:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:00:03 --> Final output sent to browser
DEBUG - 2021-06-03 05:00:03 --> Total execution time: 0.1725
INFO - 2021-06-03 05:00:26 --> Config Class Initialized
INFO - 2021-06-03 05:00:26 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:00:26 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:00:26 --> Utf8 Class Initialized
INFO - 2021-06-03 05:00:26 --> URI Class Initialized
INFO - 2021-06-03 05:00:26 --> Router Class Initialized
INFO - 2021-06-03 05:00:26 --> Output Class Initialized
INFO - 2021-06-03 05:00:26 --> Security Class Initialized
DEBUG - 2021-06-03 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:00:26 --> Input Class Initialized
INFO - 2021-06-03 05:00:26 --> Language Class Initialized
INFO - 2021-06-03 05:00:26 --> Language Class Initialized
INFO - 2021-06-03 05:00:26 --> Config Class Initialized
INFO - 2021-06-03 05:00:26 --> Loader Class Initialized
INFO - 2021-06-03 05:00:26 --> Helper loaded: url_helper
INFO - 2021-06-03 05:00:26 --> Helper loaded: file_helper
INFO - 2021-06-03 05:00:26 --> Helper loaded: form_helper
INFO - 2021-06-03 05:00:26 --> Helper loaded: my_helper
INFO - 2021-06-03 05:00:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:00:27 --> Controller Class Initialized
DEBUG - 2021-06-03 05:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:00:27 --> Final output sent to browser
DEBUG - 2021-06-03 05:00:27 --> Total execution time: 0.1620
INFO - 2021-06-03 05:00:42 --> Config Class Initialized
INFO - 2021-06-03 05:00:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:00:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:00:42 --> Utf8 Class Initialized
INFO - 2021-06-03 05:00:42 --> URI Class Initialized
INFO - 2021-06-03 05:00:42 --> Router Class Initialized
INFO - 2021-06-03 05:00:42 --> Output Class Initialized
INFO - 2021-06-03 05:00:42 --> Security Class Initialized
DEBUG - 2021-06-03 05:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:00:42 --> Input Class Initialized
INFO - 2021-06-03 05:00:42 --> Language Class Initialized
INFO - 2021-06-03 05:00:42 --> Language Class Initialized
INFO - 2021-06-03 05:00:42 --> Config Class Initialized
INFO - 2021-06-03 05:00:42 --> Loader Class Initialized
INFO - 2021-06-03 05:00:42 --> Helper loaded: url_helper
INFO - 2021-06-03 05:00:42 --> Helper loaded: file_helper
INFO - 2021-06-03 05:00:42 --> Helper loaded: form_helper
INFO - 2021-06-03 05:00:42 --> Helper loaded: my_helper
INFO - 2021-06-03 05:00:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:00:42 --> Controller Class Initialized
DEBUG - 2021-06-03 05:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:00:42 --> Final output sent to browser
DEBUG - 2021-06-03 05:00:42 --> Total execution time: 0.1692
INFO - 2021-06-03 05:08:42 --> Config Class Initialized
INFO - 2021-06-03 05:08:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:08:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:08:43 --> Utf8 Class Initialized
INFO - 2021-06-03 05:08:43 --> URI Class Initialized
INFO - 2021-06-03 05:08:43 --> Router Class Initialized
INFO - 2021-06-03 05:08:43 --> Output Class Initialized
INFO - 2021-06-03 05:08:43 --> Security Class Initialized
DEBUG - 2021-06-03 05:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:08:43 --> Input Class Initialized
INFO - 2021-06-03 05:08:43 --> Language Class Initialized
INFO - 2021-06-03 05:08:43 --> Language Class Initialized
INFO - 2021-06-03 05:08:43 --> Config Class Initialized
INFO - 2021-06-03 05:08:43 --> Loader Class Initialized
INFO - 2021-06-03 05:08:43 --> Helper loaded: url_helper
INFO - 2021-06-03 05:08:43 --> Helper loaded: file_helper
INFO - 2021-06-03 05:08:43 --> Helper loaded: form_helper
INFO - 2021-06-03 05:08:43 --> Helper loaded: my_helper
INFO - 2021-06-03 05:08:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:08:43 --> Controller Class Initialized
DEBUG - 2021-06-03 05:08:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:08:43 --> Final output sent to browser
DEBUG - 2021-06-03 05:08:43 --> Total execution time: 0.1699
INFO - 2021-06-03 05:09:18 --> Config Class Initialized
INFO - 2021-06-03 05:09:18 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:09:18 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:09:18 --> Utf8 Class Initialized
INFO - 2021-06-03 05:09:18 --> URI Class Initialized
INFO - 2021-06-03 05:09:18 --> Router Class Initialized
INFO - 2021-06-03 05:09:18 --> Output Class Initialized
INFO - 2021-06-03 05:09:18 --> Security Class Initialized
DEBUG - 2021-06-03 05:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:09:18 --> Input Class Initialized
INFO - 2021-06-03 05:09:18 --> Language Class Initialized
INFO - 2021-06-03 05:09:18 --> Language Class Initialized
INFO - 2021-06-03 05:09:18 --> Config Class Initialized
INFO - 2021-06-03 05:09:18 --> Loader Class Initialized
INFO - 2021-06-03 05:09:18 --> Helper loaded: url_helper
INFO - 2021-06-03 05:09:18 --> Helper loaded: file_helper
INFO - 2021-06-03 05:09:18 --> Helper loaded: form_helper
INFO - 2021-06-03 05:09:18 --> Helper loaded: my_helper
INFO - 2021-06-03 05:09:18 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:09:18 --> Controller Class Initialized
DEBUG - 2021-06-03 05:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:09:18 --> Final output sent to browser
DEBUG - 2021-06-03 05:09:18 --> Total execution time: 0.1473
INFO - 2021-06-03 05:10:24 --> Config Class Initialized
INFO - 2021-06-03 05:10:24 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:10:24 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:10:24 --> Utf8 Class Initialized
INFO - 2021-06-03 05:10:24 --> URI Class Initialized
INFO - 2021-06-03 05:10:24 --> Router Class Initialized
INFO - 2021-06-03 05:10:24 --> Output Class Initialized
INFO - 2021-06-03 05:10:24 --> Security Class Initialized
DEBUG - 2021-06-03 05:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:10:24 --> Input Class Initialized
INFO - 2021-06-03 05:10:24 --> Language Class Initialized
INFO - 2021-06-03 05:10:24 --> Language Class Initialized
INFO - 2021-06-03 05:10:24 --> Config Class Initialized
INFO - 2021-06-03 05:10:24 --> Loader Class Initialized
INFO - 2021-06-03 05:10:24 --> Helper loaded: url_helper
INFO - 2021-06-03 05:10:24 --> Helper loaded: file_helper
INFO - 2021-06-03 05:10:24 --> Helper loaded: form_helper
INFO - 2021-06-03 05:10:24 --> Helper loaded: my_helper
INFO - 2021-06-03 05:10:24 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:10:24 --> Controller Class Initialized
DEBUG - 2021-06-03 05:10:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:10:24 --> Final output sent to browser
DEBUG - 2021-06-03 05:10:24 --> Total execution time: 0.1709
INFO - 2021-06-03 05:10:34 --> Config Class Initialized
INFO - 2021-06-03 05:10:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:10:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:10:34 --> Utf8 Class Initialized
INFO - 2021-06-03 05:10:34 --> URI Class Initialized
INFO - 2021-06-03 05:10:34 --> Router Class Initialized
INFO - 2021-06-03 05:10:34 --> Output Class Initialized
INFO - 2021-06-03 05:10:34 --> Security Class Initialized
DEBUG - 2021-06-03 05:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:10:34 --> Input Class Initialized
INFO - 2021-06-03 05:10:34 --> Language Class Initialized
INFO - 2021-06-03 05:10:34 --> Language Class Initialized
INFO - 2021-06-03 05:10:34 --> Config Class Initialized
INFO - 2021-06-03 05:10:34 --> Loader Class Initialized
INFO - 2021-06-03 05:10:34 --> Helper loaded: url_helper
INFO - 2021-06-03 05:10:34 --> Helper loaded: file_helper
INFO - 2021-06-03 05:10:34 --> Helper loaded: form_helper
INFO - 2021-06-03 05:10:34 --> Helper loaded: my_helper
INFO - 2021-06-03 05:10:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:10:34 --> Controller Class Initialized
DEBUG - 2021-06-03 05:10:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:10:34 --> Final output sent to browser
DEBUG - 2021-06-03 05:10:34 --> Total execution time: 0.1356
INFO - 2021-06-03 05:11:48 --> Config Class Initialized
INFO - 2021-06-03 05:11:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:11:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:11:48 --> Utf8 Class Initialized
INFO - 2021-06-03 05:11:48 --> URI Class Initialized
INFO - 2021-06-03 05:11:48 --> Router Class Initialized
INFO - 2021-06-03 05:11:48 --> Output Class Initialized
INFO - 2021-06-03 05:11:48 --> Security Class Initialized
DEBUG - 2021-06-03 05:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:11:48 --> Input Class Initialized
INFO - 2021-06-03 05:11:48 --> Language Class Initialized
INFO - 2021-06-03 05:11:48 --> Language Class Initialized
INFO - 2021-06-03 05:11:48 --> Config Class Initialized
INFO - 2021-06-03 05:11:48 --> Loader Class Initialized
INFO - 2021-06-03 05:11:48 --> Helper loaded: url_helper
INFO - 2021-06-03 05:11:48 --> Helper loaded: file_helper
INFO - 2021-06-03 05:11:48 --> Helper loaded: form_helper
INFO - 2021-06-03 05:11:48 --> Helper loaded: my_helper
INFO - 2021-06-03 05:11:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:11:48 --> Controller Class Initialized
DEBUG - 2021-06-03 05:11:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:11:48 --> Final output sent to browser
DEBUG - 2021-06-03 05:11:48 --> Total execution time: 0.1761
INFO - 2021-06-03 05:11:49 --> Config Class Initialized
INFO - 2021-06-03 05:11:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:11:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:11:49 --> Utf8 Class Initialized
INFO - 2021-06-03 05:11:49 --> URI Class Initialized
INFO - 2021-06-03 05:11:49 --> Router Class Initialized
INFO - 2021-06-03 05:11:49 --> Output Class Initialized
INFO - 2021-06-03 05:11:49 --> Security Class Initialized
DEBUG - 2021-06-03 05:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:11:49 --> Input Class Initialized
INFO - 2021-06-03 05:11:49 --> Language Class Initialized
INFO - 2021-06-03 05:11:50 --> Language Class Initialized
INFO - 2021-06-03 05:11:50 --> Config Class Initialized
INFO - 2021-06-03 05:11:50 --> Loader Class Initialized
INFO - 2021-06-03 05:11:50 --> Helper loaded: url_helper
INFO - 2021-06-03 05:11:50 --> Helper loaded: file_helper
INFO - 2021-06-03 05:11:50 --> Helper loaded: form_helper
INFO - 2021-06-03 05:11:50 --> Helper loaded: my_helper
INFO - 2021-06-03 05:11:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:11:50 --> Controller Class Initialized
DEBUG - 2021-06-03 05:11:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:11:50 --> Final output sent to browser
DEBUG - 2021-06-03 05:11:50 --> Total execution time: 0.1692
INFO - 2021-06-03 05:13:33 --> Config Class Initialized
INFO - 2021-06-03 05:13:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:13:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:13:33 --> Utf8 Class Initialized
INFO - 2021-06-03 05:13:33 --> URI Class Initialized
INFO - 2021-06-03 05:13:33 --> Router Class Initialized
INFO - 2021-06-03 05:13:33 --> Output Class Initialized
INFO - 2021-06-03 05:13:33 --> Security Class Initialized
DEBUG - 2021-06-03 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:13:33 --> Input Class Initialized
INFO - 2021-06-03 05:13:33 --> Language Class Initialized
INFO - 2021-06-03 05:13:33 --> Language Class Initialized
INFO - 2021-06-03 05:13:33 --> Config Class Initialized
INFO - 2021-06-03 05:13:33 --> Loader Class Initialized
INFO - 2021-06-03 05:13:33 --> Helper loaded: url_helper
INFO - 2021-06-03 05:13:33 --> Helper loaded: file_helper
INFO - 2021-06-03 05:13:33 --> Helper loaded: form_helper
INFO - 2021-06-03 05:13:33 --> Helper loaded: my_helper
INFO - 2021-06-03 05:13:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:13:33 --> Controller Class Initialized
DEBUG - 2021-06-03 05:13:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:13:33 --> Final output sent to browser
DEBUG - 2021-06-03 05:13:33 --> Total execution time: 0.1676
INFO - 2021-06-03 05:13:35 --> Config Class Initialized
INFO - 2021-06-03 05:13:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:13:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:13:35 --> Utf8 Class Initialized
INFO - 2021-06-03 05:13:35 --> URI Class Initialized
INFO - 2021-06-03 05:13:35 --> Router Class Initialized
INFO - 2021-06-03 05:13:35 --> Output Class Initialized
INFO - 2021-06-03 05:13:35 --> Security Class Initialized
DEBUG - 2021-06-03 05:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:13:35 --> Input Class Initialized
INFO - 2021-06-03 05:13:35 --> Language Class Initialized
INFO - 2021-06-03 05:13:35 --> Language Class Initialized
INFO - 2021-06-03 05:13:35 --> Config Class Initialized
INFO - 2021-06-03 05:13:35 --> Loader Class Initialized
INFO - 2021-06-03 05:13:35 --> Helper loaded: url_helper
INFO - 2021-06-03 05:13:35 --> Helper loaded: file_helper
INFO - 2021-06-03 05:13:35 --> Helper loaded: form_helper
INFO - 2021-06-03 05:13:35 --> Helper loaded: my_helper
INFO - 2021-06-03 05:13:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:13:35 --> Controller Class Initialized
DEBUG - 2021-06-03 05:13:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:13:35 --> Final output sent to browser
DEBUG - 2021-06-03 05:13:35 --> Total execution time: 0.1675
INFO - 2021-06-03 05:14:28 --> Config Class Initialized
INFO - 2021-06-03 05:14:28 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:14:28 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:14:28 --> Utf8 Class Initialized
INFO - 2021-06-03 05:14:28 --> URI Class Initialized
INFO - 2021-06-03 05:14:28 --> Router Class Initialized
INFO - 2021-06-03 05:14:28 --> Output Class Initialized
INFO - 2021-06-03 05:14:28 --> Security Class Initialized
DEBUG - 2021-06-03 05:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:14:28 --> Input Class Initialized
INFO - 2021-06-03 05:14:28 --> Language Class Initialized
INFO - 2021-06-03 05:14:28 --> Language Class Initialized
INFO - 2021-06-03 05:14:28 --> Config Class Initialized
INFO - 2021-06-03 05:14:28 --> Loader Class Initialized
INFO - 2021-06-03 05:14:28 --> Helper loaded: url_helper
INFO - 2021-06-03 05:14:28 --> Helper loaded: file_helper
INFO - 2021-06-03 05:14:28 --> Helper loaded: form_helper
INFO - 2021-06-03 05:14:28 --> Helper loaded: my_helper
INFO - 2021-06-03 05:14:28 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:14:29 --> Controller Class Initialized
DEBUG - 2021-06-03 05:14:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:14:29 --> Final output sent to browser
DEBUG - 2021-06-03 05:14:29 --> Total execution time: 0.1675
INFO - 2021-06-03 05:14:47 --> Config Class Initialized
INFO - 2021-06-03 05:14:47 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:14:47 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:14:47 --> Utf8 Class Initialized
INFO - 2021-06-03 05:14:47 --> URI Class Initialized
INFO - 2021-06-03 05:14:47 --> Router Class Initialized
INFO - 2021-06-03 05:14:47 --> Output Class Initialized
INFO - 2021-06-03 05:14:47 --> Security Class Initialized
DEBUG - 2021-06-03 05:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:14:47 --> Input Class Initialized
INFO - 2021-06-03 05:14:47 --> Language Class Initialized
INFO - 2021-06-03 05:14:47 --> Language Class Initialized
INFO - 2021-06-03 05:14:47 --> Config Class Initialized
INFO - 2021-06-03 05:14:47 --> Loader Class Initialized
INFO - 2021-06-03 05:14:47 --> Helper loaded: url_helper
INFO - 2021-06-03 05:14:47 --> Helper loaded: file_helper
INFO - 2021-06-03 05:14:47 --> Helper loaded: form_helper
INFO - 2021-06-03 05:14:47 --> Helper loaded: my_helper
INFO - 2021-06-03 05:14:47 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:14:47 --> Controller Class Initialized
DEBUG - 2021-06-03 05:14:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:14:47 --> Final output sent to browser
DEBUG - 2021-06-03 05:14:47 --> Total execution time: 0.1746
INFO - 2021-06-03 05:15:50 --> Config Class Initialized
INFO - 2021-06-03 05:15:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:15:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:15:50 --> Utf8 Class Initialized
INFO - 2021-06-03 05:15:50 --> URI Class Initialized
INFO - 2021-06-03 05:15:50 --> Router Class Initialized
INFO - 2021-06-03 05:15:50 --> Output Class Initialized
INFO - 2021-06-03 05:15:50 --> Security Class Initialized
DEBUG - 2021-06-03 05:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:15:50 --> Input Class Initialized
INFO - 2021-06-03 05:15:50 --> Language Class Initialized
INFO - 2021-06-03 05:15:50 --> Language Class Initialized
INFO - 2021-06-03 05:15:50 --> Config Class Initialized
INFO - 2021-06-03 05:15:50 --> Loader Class Initialized
INFO - 2021-06-03 05:15:50 --> Helper loaded: url_helper
INFO - 2021-06-03 05:15:50 --> Helper loaded: file_helper
INFO - 2021-06-03 05:15:50 --> Helper loaded: form_helper
INFO - 2021-06-03 05:15:50 --> Helper loaded: my_helper
INFO - 2021-06-03 05:15:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:15:50 --> Controller Class Initialized
DEBUG - 2021-06-03 05:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:15:50 --> Final output sent to browser
DEBUG - 2021-06-03 05:15:50 --> Total execution time: 0.1791
INFO - 2021-06-03 05:15:51 --> Config Class Initialized
INFO - 2021-06-03 05:15:51 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:15:51 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:15:51 --> Utf8 Class Initialized
INFO - 2021-06-03 05:15:51 --> URI Class Initialized
INFO - 2021-06-03 05:15:51 --> Router Class Initialized
INFO - 2021-06-03 05:15:51 --> Output Class Initialized
INFO - 2021-06-03 05:15:51 --> Security Class Initialized
DEBUG - 2021-06-03 05:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:15:51 --> Input Class Initialized
INFO - 2021-06-03 05:15:51 --> Language Class Initialized
INFO - 2021-06-03 05:15:51 --> Language Class Initialized
INFO - 2021-06-03 05:15:51 --> Config Class Initialized
INFO - 2021-06-03 05:15:51 --> Loader Class Initialized
INFO - 2021-06-03 05:15:51 --> Helper loaded: url_helper
INFO - 2021-06-03 05:15:51 --> Helper loaded: file_helper
INFO - 2021-06-03 05:15:51 --> Helper loaded: form_helper
INFO - 2021-06-03 05:15:51 --> Helper loaded: my_helper
INFO - 2021-06-03 05:15:51 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:15:51 --> Controller Class Initialized
DEBUG - 2021-06-03 05:15:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:15:51 --> Final output sent to browser
DEBUG - 2021-06-03 05:15:51 --> Total execution time: 0.2340
INFO - 2021-06-03 05:17:05 --> Config Class Initialized
INFO - 2021-06-03 05:17:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:17:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:17:05 --> Utf8 Class Initialized
INFO - 2021-06-03 05:17:05 --> URI Class Initialized
INFO - 2021-06-03 05:17:05 --> Router Class Initialized
INFO - 2021-06-03 05:17:05 --> Output Class Initialized
INFO - 2021-06-03 05:17:05 --> Security Class Initialized
DEBUG - 2021-06-03 05:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:17:05 --> Input Class Initialized
INFO - 2021-06-03 05:17:05 --> Language Class Initialized
INFO - 2021-06-03 05:17:05 --> Language Class Initialized
INFO - 2021-06-03 05:17:05 --> Config Class Initialized
INFO - 2021-06-03 05:17:05 --> Loader Class Initialized
INFO - 2021-06-03 05:17:05 --> Helper loaded: url_helper
INFO - 2021-06-03 05:17:05 --> Helper loaded: file_helper
INFO - 2021-06-03 05:17:06 --> Helper loaded: form_helper
INFO - 2021-06-03 05:17:06 --> Helper loaded: my_helper
INFO - 2021-06-03 05:17:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:17:06 --> Controller Class Initialized
DEBUG - 2021-06-03 05:17:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:17:06 --> Final output sent to browser
DEBUG - 2021-06-03 05:17:06 --> Total execution time: 0.1695
INFO - 2021-06-03 05:17:43 --> Config Class Initialized
INFO - 2021-06-03 05:17:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:17:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:17:43 --> Utf8 Class Initialized
INFO - 2021-06-03 05:17:43 --> URI Class Initialized
INFO - 2021-06-03 05:17:43 --> Router Class Initialized
INFO - 2021-06-03 05:17:43 --> Output Class Initialized
INFO - 2021-06-03 05:17:43 --> Security Class Initialized
DEBUG - 2021-06-03 05:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:17:43 --> Input Class Initialized
INFO - 2021-06-03 05:17:43 --> Language Class Initialized
INFO - 2021-06-03 05:17:43 --> Language Class Initialized
INFO - 2021-06-03 05:17:43 --> Config Class Initialized
INFO - 2021-06-03 05:17:43 --> Loader Class Initialized
INFO - 2021-06-03 05:17:43 --> Helper loaded: url_helper
INFO - 2021-06-03 05:17:43 --> Helper loaded: file_helper
INFO - 2021-06-03 05:17:43 --> Helper loaded: form_helper
INFO - 2021-06-03 05:17:43 --> Helper loaded: my_helper
INFO - 2021-06-03 05:17:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:17:43 --> Controller Class Initialized
DEBUG - 2021-06-03 05:17:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:17:43 --> Final output sent to browser
DEBUG - 2021-06-03 05:17:43 --> Total execution time: 0.1712
INFO - 2021-06-03 05:17:44 --> Config Class Initialized
INFO - 2021-06-03 05:17:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:17:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:17:44 --> Utf8 Class Initialized
INFO - 2021-06-03 05:17:44 --> URI Class Initialized
INFO - 2021-06-03 05:17:44 --> Router Class Initialized
INFO - 2021-06-03 05:17:44 --> Output Class Initialized
INFO - 2021-06-03 05:17:44 --> Security Class Initialized
DEBUG - 2021-06-03 05:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:17:44 --> Input Class Initialized
INFO - 2021-06-03 05:17:44 --> Language Class Initialized
INFO - 2021-06-03 05:17:44 --> Language Class Initialized
INFO - 2021-06-03 05:17:44 --> Config Class Initialized
INFO - 2021-06-03 05:17:44 --> Loader Class Initialized
INFO - 2021-06-03 05:17:44 --> Helper loaded: url_helper
INFO - 2021-06-03 05:17:44 --> Helper loaded: file_helper
INFO - 2021-06-03 05:17:44 --> Helper loaded: form_helper
INFO - 2021-06-03 05:17:44 --> Helper loaded: my_helper
INFO - 2021-06-03 05:17:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:17:44 --> Controller Class Initialized
DEBUG - 2021-06-03 05:17:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:17:44 --> Final output sent to browser
DEBUG - 2021-06-03 05:17:44 --> Total execution time: 0.1538
INFO - 2021-06-03 05:17:54 --> Config Class Initialized
INFO - 2021-06-03 05:17:54 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:17:54 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:17:54 --> Utf8 Class Initialized
INFO - 2021-06-03 05:17:54 --> URI Class Initialized
INFO - 2021-06-03 05:17:54 --> Router Class Initialized
INFO - 2021-06-03 05:17:54 --> Output Class Initialized
INFO - 2021-06-03 05:17:54 --> Security Class Initialized
DEBUG - 2021-06-03 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:17:54 --> Input Class Initialized
INFO - 2021-06-03 05:17:54 --> Language Class Initialized
INFO - 2021-06-03 05:17:54 --> Language Class Initialized
INFO - 2021-06-03 05:17:54 --> Config Class Initialized
INFO - 2021-06-03 05:17:54 --> Loader Class Initialized
INFO - 2021-06-03 05:17:54 --> Helper loaded: url_helper
INFO - 2021-06-03 05:17:54 --> Helper loaded: file_helper
INFO - 2021-06-03 05:17:54 --> Helper loaded: form_helper
INFO - 2021-06-03 05:17:54 --> Helper loaded: my_helper
INFO - 2021-06-03 05:17:54 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:17:54 --> Controller Class Initialized
DEBUG - 2021-06-03 05:17:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:17:54 --> Final output sent to browser
DEBUG - 2021-06-03 05:17:54 --> Total execution time: 0.1273
INFO - 2021-06-03 05:18:36 --> Config Class Initialized
INFO - 2021-06-03 05:18:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:18:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:18:36 --> Utf8 Class Initialized
INFO - 2021-06-03 05:18:36 --> URI Class Initialized
INFO - 2021-06-03 05:18:36 --> Router Class Initialized
INFO - 2021-06-03 05:18:36 --> Output Class Initialized
INFO - 2021-06-03 05:18:36 --> Security Class Initialized
DEBUG - 2021-06-03 05:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:18:36 --> Input Class Initialized
INFO - 2021-06-03 05:18:36 --> Language Class Initialized
INFO - 2021-06-03 05:18:36 --> Language Class Initialized
INFO - 2021-06-03 05:18:36 --> Config Class Initialized
INFO - 2021-06-03 05:18:36 --> Loader Class Initialized
INFO - 2021-06-03 05:18:36 --> Helper loaded: url_helper
INFO - 2021-06-03 05:18:36 --> Helper loaded: file_helper
INFO - 2021-06-03 05:18:36 --> Helper loaded: form_helper
INFO - 2021-06-03 05:18:36 --> Helper loaded: my_helper
INFO - 2021-06-03 05:18:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:18:36 --> Controller Class Initialized
DEBUG - 2021-06-03 05:18:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:18:36 --> Final output sent to browser
DEBUG - 2021-06-03 05:18:36 --> Total execution time: 0.1697
INFO - 2021-06-03 05:19:16 --> Config Class Initialized
INFO - 2021-06-03 05:19:16 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:19:16 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:19:16 --> Utf8 Class Initialized
INFO - 2021-06-03 05:19:16 --> URI Class Initialized
INFO - 2021-06-03 05:19:16 --> Router Class Initialized
INFO - 2021-06-03 05:19:16 --> Output Class Initialized
INFO - 2021-06-03 05:19:16 --> Security Class Initialized
DEBUG - 2021-06-03 05:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:19:16 --> Input Class Initialized
INFO - 2021-06-03 05:19:16 --> Language Class Initialized
INFO - 2021-06-03 05:19:16 --> Language Class Initialized
INFO - 2021-06-03 05:19:16 --> Config Class Initialized
INFO - 2021-06-03 05:19:16 --> Loader Class Initialized
INFO - 2021-06-03 05:19:16 --> Helper loaded: url_helper
INFO - 2021-06-03 05:19:16 --> Helper loaded: file_helper
INFO - 2021-06-03 05:19:16 --> Helper loaded: form_helper
INFO - 2021-06-03 05:19:16 --> Helper loaded: my_helper
INFO - 2021-06-03 05:19:16 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:19:16 --> Controller Class Initialized
DEBUG - 2021-06-03 05:19:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:19:16 --> Final output sent to browser
DEBUG - 2021-06-03 05:19:16 --> Total execution time: 0.1547
INFO - 2021-06-03 05:19:43 --> Config Class Initialized
INFO - 2021-06-03 05:19:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:19:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:19:43 --> Utf8 Class Initialized
INFO - 2021-06-03 05:19:43 --> URI Class Initialized
INFO - 2021-06-03 05:19:43 --> Router Class Initialized
INFO - 2021-06-03 05:19:43 --> Output Class Initialized
INFO - 2021-06-03 05:19:43 --> Security Class Initialized
DEBUG - 2021-06-03 05:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:19:43 --> Input Class Initialized
INFO - 2021-06-03 05:19:43 --> Language Class Initialized
INFO - 2021-06-03 05:19:43 --> Language Class Initialized
INFO - 2021-06-03 05:19:43 --> Config Class Initialized
INFO - 2021-06-03 05:19:43 --> Loader Class Initialized
INFO - 2021-06-03 05:19:43 --> Helper loaded: url_helper
INFO - 2021-06-03 05:19:43 --> Helper loaded: file_helper
INFO - 2021-06-03 05:19:43 --> Helper loaded: form_helper
INFO - 2021-06-03 05:19:43 --> Helper loaded: my_helper
INFO - 2021-06-03 05:19:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:19:43 --> Controller Class Initialized
DEBUG - 2021-06-03 05:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:19:43 --> Final output sent to browser
DEBUG - 2021-06-03 05:19:43 --> Total execution time: 0.1505
INFO - 2021-06-03 05:19:59 --> Config Class Initialized
INFO - 2021-06-03 05:19:59 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:19:59 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:19:59 --> Utf8 Class Initialized
INFO - 2021-06-03 05:19:59 --> URI Class Initialized
INFO - 2021-06-03 05:19:59 --> Router Class Initialized
INFO - 2021-06-03 05:19:59 --> Output Class Initialized
INFO - 2021-06-03 05:19:59 --> Security Class Initialized
DEBUG - 2021-06-03 05:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:19:59 --> Input Class Initialized
INFO - 2021-06-03 05:19:59 --> Language Class Initialized
INFO - 2021-06-03 05:19:59 --> Language Class Initialized
INFO - 2021-06-03 05:19:59 --> Config Class Initialized
INFO - 2021-06-03 05:19:59 --> Loader Class Initialized
INFO - 2021-06-03 05:19:59 --> Helper loaded: url_helper
INFO - 2021-06-03 05:19:59 --> Helper loaded: file_helper
INFO - 2021-06-03 05:19:59 --> Helper loaded: form_helper
INFO - 2021-06-03 05:19:59 --> Helper loaded: my_helper
INFO - 2021-06-03 05:19:59 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:19:59 --> Controller Class Initialized
DEBUG - 2021-06-03 05:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:19:59 --> Final output sent to browser
DEBUG - 2021-06-03 05:19:59 --> Total execution time: 0.1508
INFO - 2021-06-03 05:19:59 --> Config Class Initialized
INFO - 2021-06-03 05:19:59 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:19:59 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:19:59 --> Utf8 Class Initialized
INFO - 2021-06-03 05:19:59 --> URI Class Initialized
INFO - 2021-06-03 05:19:59 --> Router Class Initialized
INFO - 2021-06-03 05:19:59 --> Output Class Initialized
INFO - 2021-06-03 05:19:59 --> Security Class Initialized
DEBUG - 2021-06-03 05:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:19:59 --> Input Class Initialized
INFO - 2021-06-03 05:19:59 --> Language Class Initialized
INFO - 2021-06-03 05:20:00 --> Language Class Initialized
INFO - 2021-06-03 05:20:00 --> Config Class Initialized
INFO - 2021-06-03 05:20:00 --> Loader Class Initialized
INFO - 2021-06-03 05:20:00 --> Helper loaded: url_helper
INFO - 2021-06-03 05:20:00 --> Helper loaded: file_helper
INFO - 2021-06-03 05:20:00 --> Helper loaded: form_helper
INFO - 2021-06-03 05:20:00 --> Helper loaded: my_helper
INFO - 2021-06-03 05:20:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:20:00 --> Controller Class Initialized
DEBUG - 2021-06-03 05:20:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:20:00 --> Final output sent to browser
DEBUG - 2021-06-03 05:20:00 --> Total execution time: 0.1788
INFO - 2021-06-03 05:20:14 --> Config Class Initialized
INFO - 2021-06-03 05:20:14 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:20:14 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:20:14 --> Utf8 Class Initialized
INFO - 2021-06-03 05:20:14 --> URI Class Initialized
INFO - 2021-06-03 05:20:14 --> Router Class Initialized
INFO - 2021-06-03 05:20:14 --> Output Class Initialized
INFO - 2021-06-03 05:20:14 --> Security Class Initialized
DEBUG - 2021-06-03 05:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:20:14 --> Input Class Initialized
INFO - 2021-06-03 05:20:14 --> Language Class Initialized
INFO - 2021-06-03 05:20:14 --> Language Class Initialized
INFO - 2021-06-03 05:20:14 --> Config Class Initialized
INFO - 2021-06-03 05:20:14 --> Loader Class Initialized
INFO - 2021-06-03 05:20:14 --> Helper loaded: url_helper
INFO - 2021-06-03 05:20:14 --> Helper loaded: file_helper
INFO - 2021-06-03 05:20:14 --> Helper loaded: form_helper
INFO - 2021-06-03 05:20:14 --> Helper loaded: my_helper
INFO - 2021-06-03 05:20:14 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:20:14 --> Controller Class Initialized
DEBUG - 2021-06-03 05:20:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:20:14 --> Final output sent to browser
DEBUG - 2021-06-03 05:20:14 --> Total execution time: 0.1755
INFO - 2021-06-03 05:20:22 --> Config Class Initialized
INFO - 2021-06-03 05:20:22 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:20:22 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:20:22 --> Utf8 Class Initialized
INFO - 2021-06-03 05:20:22 --> URI Class Initialized
INFO - 2021-06-03 05:20:22 --> Router Class Initialized
INFO - 2021-06-03 05:20:22 --> Output Class Initialized
INFO - 2021-06-03 05:20:22 --> Security Class Initialized
DEBUG - 2021-06-03 05:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:20:22 --> Input Class Initialized
INFO - 2021-06-03 05:20:22 --> Language Class Initialized
INFO - 2021-06-03 05:20:22 --> Language Class Initialized
INFO - 2021-06-03 05:20:22 --> Config Class Initialized
INFO - 2021-06-03 05:20:22 --> Loader Class Initialized
INFO - 2021-06-03 05:20:22 --> Helper loaded: url_helper
INFO - 2021-06-03 05:20:22 --> Helper loaded: file_helper
INFO - 2021-06-03 05:20:22 --> Helper loaded: form_helper
INFO - 2021-06-03 05:20:22 --> Helper loaded: my_helper
INFO - 2021-06-03 05:20:22 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:20:22 --> Controller Class Initialized
DEBUG - 2021-06-03 05:20:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:20:23 --> Final output sent to browser
DEBUG - 2021-06-03 05:20:23 --> Total execution time: 0.1919
INFO - 2021-06-03 05:20:57 --> Config Class Initialized
INFO - 2021-06-03 05:20:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:20:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:20:57 --> Utf8 Class Initialized
INFO - 2021-06-03 05:20:57 --> URI Class Initialized
INFO - 2021-06-03 05:20:57 --> Router Class Initialized
INFO - 2021-06-03 05:20:57 --> Output Class Initialized
INFO - 2021-06-03 05:20:57 --> Security Class Initialized
DEBUG - 2021-06-03 05:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:20:57 --> Input Class Initialized
INFO - 2021-06-03 05:20:57 --> Language Class Initialized
INFO - 2021-06-03 05:20:57 --> Language Class Initialized
INFO - 2021-06-03 05:20:57 --> Config Class Initialized
INFO - 2021-06-03 05:20:57 --> Loader Class Initialized
INFO - 2021-06-03 05:20:57 --> Helper loaded: url_helper
INFO - 2021-06-03 05:20:57 --> Helper loaded: file_helper
INFO - 2021-06-03 05:20:57 --> Helper loaded: form_helper
INFO - 2021-06-03 05:20:57 --> Helper loaded: my_helper
INFO - 2021-06-03 05:20:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:20:57 --> Controller Class Initialized
DEBUG - 2021-06-03 05:20:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:20:57 --> Final output sent to browser
DEBUG - 2021-06-03 05:20:57 --> Total execution time: 0.1557
INFO - 2021-06-03 05:27:45 --> Config Class Initialized
INFO - 2021-06-03 05:27:45 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:27:45 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:27:45 --> Utf8 Class Initialized
INFO - 2021-06-03 05:27:45 --> URI Class Initialized
INFO - 2021-06-03 05:27:45 --> Router Class Initialized
INFO - 2021-06-03 05:27:45 --> Output Class Initialized
INFO - 2021-06-03 05:27:45 --> Security Class Initialized
DEBUG - 2021-06-03 05:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:27:45 --> Input Class Initialized
INFO - 2021-06-03 05:27:45 --> Language Class Initialized
INFO - 2021-06-03 05:27:45 --> Language Class Initialized
INFO - 2021-06-03 05:27:45 --> Config Class Initialized
INFO - 2021-06-03 05:27:45 --> Loader Class Initialized
INFO - 2021-06-03 05:27:45 --> Helper loaded: url_helper
INFO - 2021-06-03 05:27:45 --> Helper loaded: file_helper
INFO - 2021-06-03 05:27:45 --> Helper loaded: form_helper
INFO - 2021-06-03 05:27:45 --> Helper loaded: my_helper
INFO - 2021-06-03 05:27:45 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:27:45 --> Controller Class Initialized
DEBUG - 2021-06-03 05:27:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:27:45 --> Final output sent to browser
DEBUG - 2021-06-03 05:27:45 --> Total execution time: 0.0661
INFO - 2021-06-03 05:28:19 --> Config Class Initialized
INFO - 2021-06-03 05:28:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:28:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:28:19 --> Utf8 Class Initialized
INFO - 2021-06-03 05:28:19 --> URI Class Initialized
INFO - 2021-06-03 05:28:19 --> Router Class Initialized
INFO - 2021-06-03 05:28:19 --> Output Class Initialized
INFO - 2021-06-03 05:28:19 --> Security Class Initialized
DEBUG - 2021-06-03 05:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:28:19 --> Input Class Initialized
INFO - 2021-06-03 05:28:19 --> Language Class Initialized
INFO - 2021-06-03 05:28:19 --> Language Class Initialized
INFO - 2021-06-03 05:28:19 --> Config Class Initialized
INFO - 2021-06-03 05:28:19 --> Loader Class Initialized
INFO - 2021-06-03 05:28:19 --> Helper loaded: url_helper
INFO - 2021-06-03 05:28:19 --> Helper loaded: file_helper
INFO - 2021-06-03 05:28:19 --> Helper loaded: form_helper
INFO - 2021-06-03 05:28:19 --> Helper loaded: my_helper
INFO - 2021-06-03 05:28:19 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:28:19 --> Controller Class Initialized
DEBUG - 2021-06-03 05:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:28:19 --> Final output sent to browser
DEBUG - 2021-06-03 05:28:19 --> Total execution time: 0.0592
INFO - 2021-06-03 05:28:36 --> Config Class Initialized
INFO - 2021-06-03 05:28:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:28:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:28:36 --> Utf8 Class Initialized
INFO - 2021-06-03 05:28:36 --> URI Class Initialized
INFO - 2021-06-03 05:28:36 --> Router Class Initialized
INFO - 2021-06-03 05:28:36 --> Output Class Initialized
INFO - 2021-06-03 05:28:36 --> Security Class Initialized
DEBUG - 2021-06-03 05:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:28:36 --> Input Class Initialized
INFO - 2021-06-03 05:28:36 --> Language Class Initialized
INFO - 2021-06-03 05:28:36 --> Language Class Initialized
INFO - 2021-06-03 05:28:36 --> Config Class Initialized
INFO - 2021-06-03 05:28:36 --> Loader Class Initialized
INFO - 2021-06-03 05:28:36 --> Helper loaded: url_helper
INFO - 2021-06-03 05:28:36 --> Helper loaded: file_helper
INFO - 2021-06-03 05:28:36 --> Helper loaded: form_helper
INFO - 2021-06-03 05:28:36 --> Helper loaded: my_helper
INFO - 2021-06-03 05:28:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:28:37 --> Controller Class Initialized
DEBUG - 2021-06-03 05:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:28:37 --> Final output sent to browser
DEBUG - 2021-06-03 05:28:37 --> Total execution time: 0.0641
INFO - 2021-06-03 05:29:15 --> Config Class Initialized
INFO - 2021-06-03 05:29:15 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:29:15 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:29:15 --> Utf8 Class Initialized
INFO - 2021-06-03 05:29:15 --> URI Class Initialized
INFO - 2021-06-03 05:29:15 --> Router Class Initialized
INFO - 2021-06-03 05:29:15 --> Output Class Initialized
INFO - 2021-06-03 05:29:15 --> Security Class Initialized
DEBUG - 2021-06-03 05:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:29:15 --> Input Class Initialized
INFO - 2021-06-03 05:29:15 --> Language Class Initialized
INFO - 2021-06-03 05:29:15 --> Language Class Initialized
INFO - 2021-06-03 05:29:15 --> Config Class Initialized
INFO - 2021-06-03 05:29:15 --> Loader Class Initialized
INFO - 2021-06-03 05:29:15 --> Helper loaded: url_helper
INFO - 2021-06-03 05:29:15 --> Helper loaded: file_helper
INFO - 2021-06-03 05:29:15 --> Helper loaded: form_helper
INFO - 2021-06-03 05:29:15 --> Helper loaded: my_helper
INFO - 2021-06-03 05:29:15 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:29:15 --> Controller Class Initialized
DEBUG - 2021-06-03 05:29:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:29:15 --> Final output sent to browser
DEBUG - 2021-06-03 05:29:15 --> Total execution time: 0.0802
INFO - 2021-06-03 05:30:13 --> Config Class Initialized
INFO - 2021-06-03 05:30:13 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:30:13 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:30:13 --> Utf8 Class Initialized
INFO - 2021-06-03 05:30:13 --> URI Class Initialized
INFO - 2021-06-03 05:30:13 --> Router Class Initialized
INFO - 2021-06-03 05:30:13 --> Output Class Initialized
INFO - 2021-06-03 05:30:13 --> Security Class Initialized
DEBUG - 2021-06-03 05:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:30:13 --> Input Class Initialized
INFO - 2021-06-03 05:30:13 --> Language Class Initialized
INFO - 2021-06-03 05:30:13 --> Language Class Initialized
INFO - 2021-06-03 05:30:13 --> Config Class Initialized
INFO - 2021-06-03 05:30:13 --> Loader Class Initialized
INFO - 2021-06-03 05:30:13 --> Helper loaded: url_helper
INFO - 2021-06-03 05:30:13 --> Helper loaded: file_helper
INFO - 2021-06-03 05:30:13 --> Helper loaded: form_helper
INFO - 2021-06-03 05:30:13 --> Helper loaded: my_helper
INFO - 2021-06-03 05:30:13 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:30:13 --> Controller Class Initialized
DEBUG - 2021-06-03 05:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:30:13 --> Final output sent to browser
DEBUG - 2021-06-03 05:30:13 --> Total execution time: 0.0760
INFO - 2021-06-03 05:30:14 --> Config Class Initialized
INFO - 2021-06-03 05:30:14 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:30:14 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:30:14 --> Utf8 Class Initialized
INFO - 2021-06-03 05:30:14 --> URI Class Initialized
INFO - 2021-06-03 05:30:14 --> Router Class Initialized
INFO - 2021-06-03 05:30:14 --> Output Class Initialized
INFO - 2021-06-03 05:30:14 --> Security Class Initialized
DEBUG - 2021-06-03 05:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:30:14 --> Input Class Initialized
INFO - 2021-06-03 05:30:14 --> Language Class Initialized
INFO - 2021-06-03 05:30:14 --> Language Class Initialized
INFO - 2021-06-03 05:30:14 --> Config Class Initialized
INFO - 2021-06-03 05:30:14 --> Loader Class Initialized
INFO - 2021-06-03 05:30:14 --> Helper loaded: url_helper
INFO - 2021-06-03 05:30:14 --> Helper loaded: file_helper
INFO - 2021-06-03 05:30:14 --> Helper loaded: form_helper
INFO - 2021-06-03 05:30:14 --> Helper loaded: my_helper
INFO - 2021-06-03 05:30:14 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:30:14 --> Controller Class Initialized
DEBUG - 2021-06-03 05:30:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:30:14 --> Final output sent to browser
DEBUG - 2021-06-03 05:30:14 --> Total execution time: 0.0739
INFO - 2021-06-03 05:31:37 --> Config Class Initialized
INFO - 2021-06-03 05:31:37 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:31:37 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:31:37 --> Utf8 Class Initialized
INFO - 2021-06-03 05:31:37 --> URI Class Initialized
INFO - 2021-06-03 05:31:37 --> Router Class Initialized
INFO - 2021-06-03 05:31:37 --> Output Class Initialized
INFO - 2021-06-03 05:31:37 --> Security Class Initialized
DEBUG - 2021-06-03 05:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:31:37 --> Input Class Initialized
INFO - 2021-06-03 05:31:37 --> Language Class Initialized
INFO - 2021-06-03 05:31:37 --> Language Class Initialized
INFO - 2021-06-03 05:31:37 --> Config Class Initialized
INFO - 2021-06-03 05:31:37 --> Loader Class Initialized
INFO - 2021-06-03 05:31:37 --> Helper loaded: url_helper
INFO - 2021-06-03 05:31:37 --> Helper loaded: file_helper
INFO - 2021-06-03 05:31:37 --> Helper loaded: form_helper
INFO - 2021-06-03 05:31:37 --> Helper loaded: my_helper
INFO - 2021-06-03 05:31:37 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:31:37 --> Controller Class Initialized
DEBUG - 2021-06-03 05:31:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:31:37 --> Final output sent to browser
DEBUG - 2021-06-03 05:31:37 --> Total execution time: 0.0746
INFO - 2021-06-03 05:32:33 --> Config Class Initialized
INFO - 2021-06-03 05:32:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:32:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:32:33 --> Utf8 Class Initialized
INFO - 2021-06-03 05:32:33 --> URI Class Initialized
INFO - 2021-06-03 05:32:33 --> Router Class Initialized
INFO - 2021-06-03 05:32:33 --> Output Class Initialized
INFO - 2021-06-03 05:32:33 --> Security Class Initialized
DEBUG - 2021-06-03 05:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:32:33 --> Input Class Initialized
INFO - 2021-06-03 05:32:33 --> Language Class Initialized
INFO - 2021-06-03 05:32:33 --> Language Class Initialized
INFO - 2021-06-03 05:32:33 --> Config Class Initialized
INFO - 2021-06-03 05:32:33 --> Loader Class Initialized
INFO - 2021-06-03 05:32:33 --> Helper loaded: url_helper
INFO - 2021-06-03 05:32:33 --> Helper loaded: file_helper
INFO - 2021-06-03 05:32:33 --> Helper loaded: form_helper
INFO - 2021-06-03 05:32:33 --> Helper loaded: my_helper
INFO - 2021-06-03 05:32:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:32:33 --> Controller Class Initialized
DEBUG - 2021-06-03 05:32:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:32:33 --> Final output sent to browser
DEBUG - 2021-06-03 05:32:33 --> Total execution time: 0.0744
INFO - 2021-06-03 05:33:05 --> Config Class Initialized
INFO - 2021-06-03 05:33:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:33:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:33:05 --> Utf8 Class Initialized
INFO - 2021-06-03 05:33:05 --> URI Class Initialized
INFO - 2021-06-03 05:33:05 --> Router Class Initialized
INFO - 2021-06-03 05:33:05 --> Output Class Initialized
INFO - 2021-06-03 05:33:05 --> Security Class Initialized
DEBUG - 2021-06-03 05:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:33:05 --> Input Class Initialized
INFO - 2021-06-03 05:33:05 --> Language Class Initialized
INFO - 2021-06-03 05:33:05 --> Language Class Initialized
INFO - 2021-06-03 05:33:05 --> Config Class Initialized
INFO - 2021-06-03 05:33:05 --> Loader Class Initialized
INFO - 2021-06-03 05:33:05 --> Helper loaded: url_helper
INFO - 2021-06-03 05:33:05 --> Helper loaded: file_helper
INFO - 2021-06-03 05:33:05 --> Helper loaded: form_helper
INFO - 2021-06-03 05:33:05 --> Helper loaded: my_helper
INFO - 2021-06-03 05:33:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:33:05 --> Controller Class Initialized
DEBUG - 2021-06-03 05:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:33:05 --> Final output sent to browser
DEBUG - 2021-06-03 05:33:05 --> Total execution time: 0.0812
INFO - 2021-06-03 05:33:41 --> Config Class Initialized
INFO - 2021-06-03 05:33:41 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:33:41 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:33:41 --> Utf8 Class Initialized
INFO - 2021-06-03 05:33:41 --> URI Class Initialized
INFO - 2021-06-03 05:33:41 --> Router Class Initialized
INFO - 2021-06-03 05:33:41 --> Output Class Initialized
INFO - 2021-06-03 05:33:41 --> Security Class Initialized
DEBUG - 2021-06-03 05:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:33:41 --> Input Class Initialized
INFO - 2021-06-03 05:33:41 --> Language Class Initialized
INFO - 2021-06-03 05:33:41 --> Language Class Initialized
INFO - 2021-06-03 05:33:41 --> Config Class Initialized
INFO - 2021-06-03 05:33:41 --> Loader Class Initialized
INFO - 2021-06-03 05:33:41 --> Helper loaded: url_helper
INFO - 2021-06-03 05:33:41 --> Helper loaded: file_helper
INFO - 2021-06-03 05:33:41 --> Helper loaded: form_helper
INFO - 2021-06-03 05:33:41 --> Helper loaded: my_helper
INFO - 2021-06-03 05:33:41 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:33:41 --> Controller Class Initialized
DEBUG - 2021-06-03 05:33:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-03 05:33:41 --> Final output sent to browser
DEBUG - 2021-06-03 05:33:41 --> Total execution time: 0.1590
INFO - 2021-06-03 05:34:46 --> Config Class Initialized
INFO - 2021-06-03 05:34:46 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:34:46 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:34:46 --> Utf8 Class Initialized
INFO - 2021-06-03 05:34:46 --> URI Class Initialized
INFO - 2021-06-03 05:34:46 --> Router Class Initialized
INFO - 2021-06-03 05:34:46 --> Output Class Initialized
INFO - 2021-06-03 05:34:46 --> Security Class Initialized
DEBUG - 2021-06-03 05:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:34:46 --> Input Class Initialized
INFO - 2021-06-03 05:34:46 --> Language Class Initialized
INFO - 2021-06-03 05:34:46 --> Language Class Initialized
INFO - 2021-06-03 05:34:46 --> Config Class Initialized
INFO - 2021-06-03 05:34:46 --> Loader Class Initialized
INFO - 2021-06-03 05:34:46 --> Helper loaded: url_helper
INFO - 2021-06-03 05:34:46 --> Helper loaded: file_helper
INFO - 2021-06-03 05:34:46 --> Helper loaded: form_helper
INFO - 2021-06-03 05:34:46 --> Helper loaded: my_helper
INFO - 2021-06-03 05:34:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:34:46 --> Controller Class Initialized
DEBUG - 2021-06-03 05:34:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:34:46 --> Final output sent to browser
DEBUG - 2021-06-03 05:34:46 --> Total execution time: 0.0864
INFO - 2021-06-03 05:35:00 --> Config Class Initialized
INFO - 2021-06-03 05:35:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:35:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:35:00 --> Utf8 Class Initialized
INFO - 2021-06-03 05:35:00 --> URI Class Initialized
INFO - 2021-06-03 05:35:00 --> Router Class Initialized
INFO - 2021-06-03 05:35:00 --> Output Class Initialized
INFO - 2021-06-03 05:35:00 --> Security Class Initialized
DEBUG - 2021-06-03 05:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:35:00 --> Input Class Initialized
INFO - 2021-06-03 05:35:00 --> Language Class Initialized
INFO - 2021-06-03 05:35:00 --> Language Class Initialized
INFO - 2021-06-03 05:35:00 --> Config Class Initialized
INFO - 2021-06-03 05:35:00 --> Loader Class Initialized
INFO - 2021-06-03 05:35:00 --> Helper loaded: url_helper
INFO - 2021-06-03 05:35:00 --> Helper loaded: file_helper
INFO - 2021-06-03 05:35:00 --> Helper loaded: form_helper
INFO - 2021-06-03 05:35:00 --> Helper loaded: my_helper
INFO - 2021-06-03 05:35:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:35:01 --> Controller Class Initialized
DEBUG - 2021-06-03 05:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:35:01 --> Final output sent to browser
DEBUG - 2021-06-03 05:35:01 --> Total execution time: 0.0846
INFO - 2021-06-03 05:36:16 --> Config Class Initialized
INFO - 2021-06-03 05:36:16 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:36:16 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:36:16 --> Utf8 Class Initialized
INFO - 2021-06-03 05:36:16 --> URI Class Initialized
INFO - 2021-06-03 05:36:16 --> Router Class Initialized
INFO - 2021-06-03 05:36:16 --> Output Class Initialized
INFO - 2021-06-03 05:36:16 --> Security Class Initialized
DEBUG - 2021-06-03 05:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:36:16 --> Input Class Initialized
INFO - 2021-06-03 05:36:16 --> Language Class Initialized
INFO - 2021-06-03 05:36:17 --> Language Class Initialized
INFO - 2021-06-03 05:36:17 --> Config Class Initialized
INFO - 2021-06-03 05:36:17 --> Loader Class Initialized
INFO - 2021-06-03 05:36:17 --> Helper loaded: url_helper
INFO - 2021-06-03 05:36:17 --> Helper loaded: file_helper
INFO - 2021-06-03 05:36:17 --> Helper loaded: form_helper
INFO - 2021-06-03 05:36:17 --> Helper loaded: my_helper
INFO - 2021-06-03 05:36:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:36:17 --> Controller Class Initialized
DEBUG - 2021-06-03 05:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:36:17 --> Final output sent to browser
DEBUG - 2021-06-03 05:36:17 --> Total execution time: 0.0570
INFO - 2021-06-03 05:38:28 --> Config Class Initialized
INFO - 2021-06-03 05:38:28 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:38:28 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:38:28 --> Utf8 Class Initialized
INFO - 2021-06-03 05:38:28 --> URI Class Initialized
INFO - 2021-06-03 05:38:28 --> Router Class Initialized
INFO - 2021-06-03 05:38:28 --> Output Class Initialized
INFO - 2021-06-03 05:38:28 --> Security Class Initialized
DEBUG - 2021-06-03 05:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:38:28 --> Input Class Initialized
INFO - 2021-06-03 05:38:28 --> Language Class Initialized
INFO - 2021-06-03 05:38:28 --> Language Class Initialized
INFO - 2021-06-03 05:38:28 --> Config Class Initialized
INFO - 2021-06-03 05:38:28 --> Loader Class Initialized
INFO - 2021-06-03 05:38:28 --> Helper loaded: url_helper
INFO - 2021-06-03 05:38:28 --> Helper loaded: file_helper
INFO - 2021-06-03 05:38:28 --> Helper loaded: form_helper
INFO - 2021-06-03 05:38:28 --> Helper loaded: my_helper
INFO - 2021-06-03 05:38:28 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:38:28 --> Controller Class Initialized
DEBUG - 2021-06-03 05:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:38:28 --> Final output sent to browser
DEBUG - 2021-06-03 05:38:28 --> Total execution time: 0.0704
INFO - 2021-06-03 05:38:53 --> Config Class Initialized
INFO - 2021-06-03 05:38:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:38:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:38:53 --> Utf8 Class Initialized
INFO - 2021-06-03 05:38:53 --> URI Class Initialized
INFO - 2021-06-03 05:38:53 --> Router Class Initialized
INFO - 2021-06-03 05:38:53 --> Output Class Initialized
INFO - 2021-06-03 05:38:53 --> Security Class Initialized
DEBUG - 2021-06-03 05:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:38:53 --> Input Class Initialized
INFO - 2021-06-03 05:38:53 --> Language Class Initialized
INFO - 2021-06-03 05:38:53 --> Language Class Initialized
INFO - 2021-06-03 05:38:53 --> Config Class Initialized
INFO - 2021-06-03 05:38:53 --> Loader Class Initialized
INFO - 2021-06-03 05:38:53 --> Helper loaded: url_helper
INFO - 2021-06-03 05:38:53 --> Helper loaded: file_helper
INFO - 2021-06-03 05:38:53 --> Helper loaded: form_helper
INFO - 2021-06-03 05:38:53 --> Helper loaded: my_helper
INFO - 2021-06-03 05:38:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:38:53 --> Controller Class Initialized
DEBUG - 2021-06-03 05:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:38:53 --> Final output sent to browser
DEBUG - 2021-06-03 05:38:53 --> Total execution time: 0.0781
INFO - 2021-06-03 05:39:08 --> Config Class Initialized
INFO - 2021-06-03 05:39:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:39:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:39:08 --> Utf8 Class Initialized
INFO - 2021-06-03 05:39:08 --> URI Class Initialized
INFO - 2021-06-03 05:39:08 --> Router Class Initialized
INFO - 2021-06-03 05:39:08 --> Output Class Initialized
INFO - 2021-06-03 05:39:08 --> Security Class Initialized
DEBUG - 2021-06-03 05:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:39:08 --> Input Class Initialized
INFO - 2021-06-03 05:39:08 --> Language Class Initialized
INFO - 2021-06-03 05:39:08 --> Language Class Initialized
INFO - 2021-06-03 05:39:08 --> Config Class Initialized
INFO - 2021-06-03 05:39:08 --> Loader Class Initialized
INFO - 2021-06-03 05:39:08 --> Helper loaded: url_helper
INFO - 2021-06-03 05:39:08 --> Helper loaded: file_helper
INFO - 2021-06-03 05:39:08 --> Helper loaded: form_helper
INFO - 2021-06-03 05:39:08 --> Helper loaded: my_helper
INFO - 2021-06-03 05:39:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:39:08 --> Controller Class Initialized
DEBUG - 2021-06-03 05:39:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:39:08 --> Final output sent to browser
DEBUG - 2021-06-03 05:39:08 --> Total execution time: 0.0592
INFO - 2021-06-03 05:39:39 --> Config Class Initialized
INFO - 2021-06-03 05:39:39 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:39:39 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:39:39 --> Utf8 Class Initialized
INFO - 2021-06-03 05:39:39 --> URI Class Initialized
INFO - 2021-06-03 05:39:39 --> Router Class Initialized
INFO - 2021-06-03 05:39:39 --> Output Class Initialized
INFO - 2021-06-03 05:39:39 --> Security Class Initialized
DEBUG - 2021-06-03 05:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:39:39 --> Input Class Initialized
INFO - 2021-06-03 05:39:39 --> Language Class Initialized
INFO - 2021-06-03 05:39:39 --> Language Class Initialized
INFO - 2021-06-03 05:39:39 --> Config Class Initialized
INFO - 2021-06-03 05:39:39 --> Loader Class Initialized
INFO - 2021-06-03 05:39:39 --> Helper loaded: url_helper
INFO - 2021-06-03 05:39:39 --> Helper loaded: file_helper
INFO - 2021-06-03 05:39:39 --> Helper loaded: form_helper
INFO - 2021-06-03 05:39:39 --> Helper loaded: my_helper
INFO - 2021-06-03 05:39:39 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:39:39 --> Controller Class Initialized
DEBUG - 2021-06-03 05:39:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:39:39 --> Final output sent to browser
DEBUG - 2021-06-03 05:39:39 --> Total execution time: 0.0847
INFO - 2021-06-03 05:39:40 --> Config Class Initialized
INFO - 2021-06-03 05:39:40 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:39:40 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:39:40 --> Utf8 Class Initialized
INFO - 2021-06-03 05:39:40 --> URI Class Initialized
INFO - 2021-06-03 05:39:40 --> Router Class Initialized
INFO - 2021-06-03 05:39:40 --> Output Class Initialized
INFO - 2021-06-03 05:39:40 --> Security Class Initialized
DEBUG - 2021-06-03 05:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:39:40 --> Input Class Initialized
INFO - 2021-06-03 05:39:40 --> Language Class Initialized
INFO - 2021-06-03 05:39:40 --> Language Class Initialized
INFO - 2021-06-03 05:39:40 --> Config Class Initialized
INFO - 2021-06-03 05:39:40 --> Loader Class Initialized
INFO - 2021-06-03 05:39:40 --> Helper loaded: url_helper
INFO - 2021-06-03 05:39:40 --> Helper loaded: file_helper
INFO - 2021-06-03 05:39:40 --> Helper loaded: form_helper
INFO - 2021-06-03 05:39:40 --> Helper loaded: my_helper
INFO - 2021-06-03 05:39:40 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:39:40 --> Controller Class Initialized
DEBUG - 2021-06-03 05:39:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:39:40 --> Final output sent to browser
DEBUG - 2021-06-03 05:39:40 --> Total execution time: 0.0752
INFO - 2021-06-03 05:39:56 --> Config Class Initialized
INFO - 2021-06-03 05:39:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:39:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:39:56 --> Utf8 Class Initialized
INFO - 2021-06-03 05:39:56 --> URI Class Initialized
INFO - 2021-06-03 05:39:56 --> Router Class Initialized
INFO - 2021-06-03 05:39:56 --> Output Class Initialized
INFO - 2021-06-03 05:39:56 --> Security Class Initialized
DEBUG - 2021-06-03 05:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:39:56 --> Input Class Initialized
INFO - 2021-06-03 05:39:56 --> Language Class Initialized
INFO - 2021-06-03 05:39:56 --> Language Class Initialized
INFO - 2021-06-03 05:39:56 --> Config Class Initialized
INFO - 2021-06-03 05:39:56 --> Loader Class Initialized
INFO - 2021-06-03 05:39:56 --> Helper loaded: url_helper
INFO - 2021-06-03 05:39:56 --> Helper loaded: file_helper
INFO - 2021-06-03 05:39:56 --> Helper loaded: form_helper
INFO - 2021-06-03 05:39:56 --> Helper loaded: my_helper
INFO - 2021-06-03 05:39:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:39:56 --> Controller Class Initialized
DEBUG - 2021-06-03 05:39:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:39:56 --> Final output sent to browser
DEBUG - 2021-06-03 05:39:56 --> Total execution time: 0.0734
INFO - 2021-06-03 05:41:05 --> Config Class Initialized
INFO - 2021-06-03 05:41:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:41:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:41:05 --> Utf8 Class Initialized
INFO - 2021-06-03 05:41:05 --> URI Class Initialized
INFO - 2021-06-03 05:41:05 --> Router Class Initialized
INFO - 2021-06-03 05:41:05 --> Output Class Initialized
INFO - 2021-06-03 05:41:05 --> Security Class Initialized
DEBUG - 2021-06-03 05:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:41:05 --> Input Class Initialized
INFO - 2021-06-03 05:41:05 --> Language Class Initialized
INFO - 2021-06-03 05:41:05 --> Language Class Initialized
INFO - 2021-06-03 05:41:05 --> Config Class Initialized
INFO - 2021-06-03 05:41:05 --> Loader Class Initialized
INFO - 2021-06-03 05:41:05 --> Helper loaded: url_helper
INFO - 2021-06-03 05:41:05 --> Helper loaded: file_helper
INFO - 2021-06-03 05:41:05 --> Helper loaded: form_helper
INFO - 2021-06-03 05:41:05 --> Helper loaded: my_helper
INFO - 2021-06-03 05:41:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:41:05 --> Controller Class Initialized
DEBUG - 2021-06-03 05:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:41:05 --> Final output sent to browser
DEBUG - 2021-06-03 05:41:05 --> Total execution time: 0.0810
INFO - 2021-06-03 05:43:01 --> Config Class Initialized
INFO - 2021-06-03 05:43:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:43:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:43:01 --> Utf8 Class Initialized
INFO - 2021-06-03 05:43:01 --> URI Class Initialized
INFO - 2021-06-03 05:43:01 --> Router Class Initialized
INFO - 2021-06-03 05:43:01 --> Output Class Initialized
INFO - 2021-06-03 05:43:01 --> Security Class Initialized
DEBUG - 2021-06-03 05:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:43:01 --> Input Class Initialized
INFO - 2021-06-03 05:43:01 --> Language Class Initialized
INFO - 2021-06-03 05:43:01 --> Language Class Initialized
INFO - 2021-06-03 05:43:01 --> Config Class Initialized
INFO - 2021-06-03 05:43:01 --> Loader Class Initialized
INFO - 2021-06-03 05:43:01 --> Helper loaded: url_helper
INFO - 2021-06-03 05:43:01 --> Helper loaded: file_helper
INFO - 2021-06-03 05:43:01 --> Helper loaded: form_helper
INFO - 2021-06-03 05:43:01 --> Helper loaded: my_helper
INFO - 2021-06-03 05:43:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:43:01 --> Controller Class Initialized
DEBUG - 2021-06-03 05:43:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:43:01 --> Final output sent to browser
DEBUG - 2021-06-03 05:43:01 --> Total execution time: 0.0611
INFO - 2021-06-03 05:43:43 --> Config Class Initialized
INFO - 2021-06-03 05:43:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:43:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:43:43 --> Utf8 Class Initialized
INFO - 2021-06-03 05:43:43 --> URI Class Initialized
INFO - 2021-06-03 05:43:43 --> Router Class Initialized
INFO - 2021-06-03 05:43:43 --> Output Class Initialized
INFO - 2021-06-03 05:43:43 --> Security Class Initialized
DEBUG - 2021-06-03 05:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:43:43 --> Input Class Initialized
INFO - 2021-06-03 05:43:43 --> Language Class Initialized
INFO - 2021-06-03 05:43:43 --> Language Class Initialized
INFO - 2021-06-03 05:43:43 --> Config Class Initialized
INFO - 2021-06-03 05:43:43 --> Loader Class Initialized
INFO - 2021-06-03 05:43:43 --> Helper loaded: url_helper
INFO - 2021-06-03 05:43:43 --> Helper loaded: file_helper
INFO - 2021-06-03 05:43:43 --> Helper loaded: form_helper
INFO - 2021-06-03 05:43:43 --> Helper loaded: my_helper
INFO - 2021-06-03 05:43:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:43:43 --> Controller Class Initialized
DEBUG - 2021-06-03 05:43:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:43:43 --> Final output sent to browser
DEBUG - 2021-06-03 05:43:43 --> Total execution time: 0.0613
INFO - 2021-06-03 05:44:06 --> Config Class Initialized
INFO - 2021-06-03 05:44:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:44:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:44:06 --> Utf8 Class Initialized
INFO - 2021-06-03 05:44:06 --> URI Class Initialized
INFO - 2021-06-03 05:44:06 --> Router Class Initialized
INFO - 2021-06-03 05:44:06 --> Output Class Initialized
INFO - 2021-06-03 05:44:06 --> Security Class Initialized
DEBUG - 2021-06-03 05:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:44:06 --> Input Class Initialized
INFO - 2021-06-03 05:44:06 --> Language Class Initialized
INFO - 2021-06-03 05:44:06 --> Language Class Initialized
INFO - 2021-06-03 05:44:06 --> Config Class Initialized
INFO - 2021-06-03 05:44:06 --> Loader Class Initialized
INFO - 2021-06-03 05:44:06 --> Helper loaded: url_helper
INFO - 2021-06-03 05:44:06 --> Helper loaded: file_helper
INFO - 2021-06-03 05:44:06 --> Helper loaded: form_helper
INFO - 2021-06-03 05:44:06 --> Helper loaded: my_helper
INFO - 2021-06-03 05:44:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:44:06 --> Controller Class Initialized
DEBUG - 2021-06-03 05:44:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:44:06 --> Final output sent to browser
DEBUG - 2021-06-03 05:44:06 --> Total execution time: 0.0694
INFO - 2021-06-03 05:44:07 --> Config Class Initialized
INFO - 2021-06-03 05:44:07 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:44:07 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:44:07 --> Utf8 Class Initialized
INFO - 2021-06-03 05:44:07 --> URI Class Initialized
INFO - 2021-06-03 05:44:07 --> Router Class Initialized
INFO - 2021-06-03 05:44:07 --> Output Class Initialized
INFO - 2021-06-03 05:44:07 --> Security Class Initialized
DEBUG - 2021-06-03 05:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:44:07 --> Input Class Initialized
INFO - 2021-06-03 05:44:07 --> Language Class Initialized
INFO - 2021-06-03 05:44:07 --> Language Class Initialized
INFO - 2021-06-03 05:44:07 --> Config Class Initialized
INFO - 2021-06-03 05:44:07 --> Loader Class Initialized
INFO - 2021-06-03 05:44:07 --> Helper loaded: url_helper
INFO - 2021-06-03 05:44:07 --> Helper loaded: file_helper
INFO - 2021-06-03 05:44:07 --> Helper loaded: form_helper
INFO - 2021-06-03 05:44:07 --> Helper loaded: my_helper
INFO - 2021-06-03 05:44:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:44:07 --> Controller Class Initialized
DEBUG - 2021-06-03 05:44:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:44:07 --> Final output sent to browser
DEBUG - 2021-06-03 05:44:07 --> Total execution time: 0.0588
INFO - 2021-06-03 05:44:19 --> Config Class Initialized
INFO - 2021-06-03 05:44:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:44:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:44:19 --> Utf8 Class Initialized
INFO - 2021-06-03 05:44:19 --> URI Class Initialized
INFO - 2021-06-03 05:44:19 --> Router Class Initialized
INFO - 2021-06-03 05:44:19 --> Output Class Initialized
INFO - 2021-06-03 05:44:19 --> Security Class Initialized
DEBUG - 2021-06-03 05:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:44:19 --> Input Class Initialized
INFO - 2021-06-03 05:44:19 --> Language Class Initialized
INFO - 2021-06-03 05:44:19 --> Language Class Initialized
INFO - 2021-06-03 05:44:19 --> Config Class Initialized
INFO - 2021-06-03 05:44:19 --> Loader Class Initialized
INFO - 2021-06-03 05:44:19 --> Helper loaded: url_helper
INFO - 2021-06-03 05:44:19 --> Helper loaded: file_helper
INFO - 2021-06-03 05:44:19 --> Helper loaded: form_helper
INFO - 2021-06-03 05:44:19 --> Helper loaded: my_helper
INFO - 2021-06-03 05:44:19 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:44:19 --> Controller Class Initialized
DEBUG - 2021-06-03 05:44:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:44:19 --> Final output sent to browser
DEBUG - 2021-06-03 05:44:19 --> Total execution time: 0.0779
INFO - 2021-06-03 05:45:53 --> Config Class Initialized
INFO - 2021-06-03 05:45:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:45:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:45:53 --> Utf8 Class Initialized
INFO - 2021-06-03 05:45:53 --> URI Class Initialized
INFO - 2021-06-03 05:45:53 --> Router Class Initialized
INFO - 2021-06-03 05:45:53 --> Output Class Initialized
INFO - 2021-06-03 05:45:53 --> Security Class Initialized
DEBUG - 2021-06-03 05:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:45:53 --> Input Class Initialized
INFO - 2021-06-03 05:45:53 --> Language Class Initialized
INFO - 2021-06-03 05:45:53 --> Language Class Initialized
INFO - 2021-06-03 05:45:53 --> Config Class Initialized
INFO - 2021-06-03 05:45:53 --> Loader Class Initialized
INFO - 2021-06-03 05:45:53 --> Helper loaded: url_helper
INFO - 2021-06-03 05:45:53 --> Helper loaded: file_helper
INFO - 2021-06-03 05:45:53 --> Helper loaded: form_helper
INFO - 2021-06-03 05:45:53 --> Helper loaded: my_helper
INFO - 2021-06-03 05:45:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:45:53 --> Controller Class Initialized
DEBUG - 2021-06-03 05:45:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:45:53 --> Final output sent to browser
DEBUG - 2021-06-03 05:45:53 --> Total execution time: 0.0775
INFO - 2021-06-03 05:47:31 --> Config Class Initialized
INFO - 2021-06-03 05:47:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:47:31 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:47:31 --> Utf8 Class Initialized
INFO - 2021-06-03 05:47:31 --> URI Class Initialized
INFO - 2021-06-03 05:47:31 --> Router Class Initialized
INFO - 2021-06-03 05:47:31 --> Output Class Initialized
INFO - 2021-06-03 05:47:31 --> Security Class Initialized
DEBUG - 2021-06-03 05:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:47:31 --> Input Class Initialized
INFO - 2021-06-03 05:47:31 --> Language Class Initialized
INFO - 2021-06-03 05:47:31 --> Language Class Initialized
INFO - 2021-06-03 05:47:31 --> Config Class Initialized
INFO - 2021-06-03 05:47:31 --> Loader Class Initialized
INFO - 2021-06-03 05:47:31 --> Helper loaded: url_helper
INFO - 2021-06-03 05:47:31 --> Helper loaded: file_helper
INFO - 2021-06-03 05:47:31 --> Helper loaded: form_helper
INFO - 2021-06-03 05:47:31 --> Helper loaded: my_helper
INFO - 2021-06-03 05:47:31 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:47:31 --> Controller Class Initialized
DEBUG - 2021-06-03 05:47:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:47:31 --> Final output sent to browser
DEBUG - 2021-06-03 05:47:31 --> Total execution time: 0.0765
INFO - 2021-06-03 05:48:41 --> Config Class Initialized
INFO - 2021-06-03 05:48:41 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:48:41 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:48:41 --> Utf8 Class Initialized
INFO - 2021-06-03 05:48:41 --> URI Class Initialized
INFO - 2021-06-03 05:48:41 --> Router Class Initialized
INFO - 2021-06-03 05:48:41 --> Output Class Initialized
INFO - 2021-06-03 05:48:41 --> Security Class Initialized
DEBUG - 2021-06-03 05:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:48:41 --> Input Class Initialized
INFO - 2021-06-03 05:48:41 --> Language Class Initialized
INFO - 2021-06-03 05:48:41 --> Language Class Initialized
INFO - 2021-06-03 05:48:41 --> Config Class Initialized
INFO - 2021-06-03 05:48:41 --> Loader Class Initialized
INFO - 2021-06-03 05:48:41 --> Helper loaded: url_helper
INFO - 2021-06-03 05:48:41 --> Helper loaded: file_helper
INFO - 2021-06-03 05:48:41 --> Helper loaded: form_helper
INFO - 2021-06-03 05:48:41 --> Helper loaded: my_helper
INFO - 2021-06-03 05:48:41 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:48:41 --> Controller Class Initialized
DEBUG - 2021-06-03 05:48:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:48:41 --> Final output sent to browser
DEBUG - 2021-06-03 05:48:41 --> Total execution time: 0.0589
INFO - 2021-06-03 05:49:06 --> Config Class Initialized
INFO - 2021-06-03 05:49:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:49:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:49:06 --> Utf8 Class Initialized
INFO - 2021-06-03 05:49:06 --> URI Class Initialized
INFO - 2021-06-03 05:49:06 --> Router Class Initialized
INFO - 2021-06-03 05:49:06 --> Output Class Initialized
INFO - 2021-06-03 05:49:06 --> Security Class Initialized
DEBUG - 2021-06-03 05:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:49:06 --> Input Class Initialized
INFO - 2021-06-03 05:49:06 --> Language Class Initialized
INFO - 2021-06-03 05:49:06 --> Language Class Initialized
INFO - 2021-06-03 05:49:06 --> Config Class Initialized
INFO - 2021-06-03 05:49:06 --> Loader Class Initialized
INFO - 2021-06-03 05:49:06 --> Helper loaded: url_helper
INFO - 2021-06-03 05:49:06 --> Helper loaded: file_helper
INFO - 2021-06-03 05:49:06 --> Helper loaded: form_helper
INFO - 2021-06-03 05:49:06 --> Helper loaded: my_helper
INFO - 2021-06-03 05:49:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:49:06 --> Controller Class Initialized
DEBUG - 2021-06-03 05:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:49:06 --> Final output sent to browser
DEBUG - 2021-06-03 05:49:06 --> Total execution time: 0.0762
INFO - 2021-06-03 05:49:18 --> Config Class Initialized
INFO - 2021-06-03 05:49:18 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:49:18 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:49:18 --> Utf8 Class Initialized
INFO - 2021-06-03 05:49:18 --> URI Class Initialized
INFO - 2021-06-03 05:49:18 --> Router Class Initialized
INFO - 2021-06-03 05:49:18 --> Output Class Initialized
INFO - 2021-06-03 05:49:18 --> Security Class Initialized
DEBUG - 2021-06-03 05:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:49:18 --> Input Class Initialized
INFO - 2021-06-03 05:49:18 --> Language Class Initialized
INFO - 2021-06-03 05:49:18 --> Language Class Initialized
INFO - 2021-06-03 05:49:18 --> Config Class Initialized
INFO - 2021-06-03 05:49:18 --> Loader Class Initialized
INFO - 2021-06-03 05:49:18 --> Helper loaded: url_helper
INFO - 2021-06-03 05:49:18 --> Helper loaded: file_helper
INFO - 2021-06-03 05:49:18 --> Helper loaded: form_helper
INFO - 2021-06-03 05:49:18 --> Helper loaded: my_helper
INFO - 2021-06-03 05:49:18 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:49:18 --> Controller Class Initialized
DEBUG - 2021-06-03 05:49:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 05:49:18 --> Final output sent to browser
DEBUG - 2021-06-03 05:49:18 --> Total execution time: 0.0711
INFO - 2021-06-03 05:51:34 --> Config Class Initialized
INFO - 2021-06-03 05:51:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:51:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:51:34 --> Utf8 Class Initialized
INFO - 2021-06-03 05:51:34 --> URI Class Initialized
INFO - 2021-06-03 05:51:34 --> Router Class Initialized
INFO - 2021-06-03 05:51:34 --> Output Class Initialized
INFO - 2021-06-03 05:51:34 --> Security Class Initialized
DEBUG - 2021-06-03 05:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:51:34 --> Input Class Initialized
INFO - 2021-06-03 05:51:34 --> Language Class Initialized
INFO - 2021-06-03 05:51:34 --> Language Class Initialized
INFO - 2021-06-03 05:51:34 --> Config Class Initialized
INFO - 2021-06-03 05:51:34 --> Loader Class Initialized
INFO - 2021-06-03 05:51:34 --> Helper loaded: url_helper
INFO - 2021-06-03 05:51:34 --> Helper loaded: file_helper
INFO - 2021-06-03 05:51:34 --> Helper loaded: form_helper
INFO - 2021-06-03 05:51:34 --> Helper loaded: my_helper
INFO - 2021-06-03 05:51:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:51:34 --> Controller Class Initialized
INFO - 2021-06-03 05:51:34 --> Helper loaded: cookie_helper
INFO - 2021-06-03 05:51:34 --> Config Class Initialized
INFO - 2021-06-03 05:51:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 05:51:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 05:51:34 --> Utf8 Class Initialized
INFO - 2021-06-03 05:51:34 --> URI Class Initialized
INFO - 2021-06-03 05:51:34 --> Router Class Initialized
INFO - 2021-06-03 05:51:34 --> Output Class Initialized
INFO - 2021-06-03 05:51:34 --> Security Class Initialized
DEBUG - 2021-06-03 05:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 05:51:34 --> Input Class Initialized
INFO - 2021-06-03 05:51:34 --> Language Class Initialized
INFO - 2021-06-03 05:51:34 --> Language Class Initialized
INFO - 2021-06-03 05:51:34 --> Config Class Initialized
INFO - 2021-06-03 05:51:34 --> Loader Class Initialized
INFO - 2021-06-03 05:51:34 --> Helper loaded: url_helper
INFO - 2021-06-03 05:51:34 --> Helper loaded: file_helper
INFO - 2021-06-03 05:51:34 --> Helper loaded: form_helper
INFO - 2021-06-03 05:51:34 --> Helper loaded: my_helper
INFO - 2021-06-03 05:51:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 05:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 05:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 05:51:34 --> Controller Class Initialized
DEBUG - 2021-06-03 05:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 05:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 05:51:34 --> Final output sent to browser
DEBUG - 2021-06-03 05:51:34 --> Total execution time: 0.0863
INFO - 2021-06-03 06:04:38 --> Config Class Initialized
INFO - 2021-06-03 06:04:38 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:04:38 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:04:38 --> Utf8 Class Initialized
INFO - 2021-06-03 06:04:38 --> URI Class Initialized
INFO - 2021-06-03 06:04:38 --> Router Class Initialized
INFO - 2021-06-03 06:04:38 --> Output Class Initialized
INFO - 2021-06-03 06:04:38 --> Security Class Initialized
DEBUG - 2021-06-03 06:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:04:38 --> Input Class Initialized
INFO - 2021-06-03 06:04:38 --> Language Class Initialized
INFO - 2021-06-03 06:04:38 --> Language Class Initialized
INFO - 2021-06-03 06:04:38 --> Config Class Initialized
INFO - 2021-06-03 06:04:38 --> Loader Class Initialized
INFO - 2021-06-03 06:04:38 --> Helper loaded: url_helper
INFO - 2021-06-03 06:04:38 --> Helper loaded: file_helper
INFO - 2021-06-03 06:04:38 --> Helper loaded: form_helper
INFO - 2021-06-03 06:04:38 --> Helper loaded: my_helper
INFO - 2021-06-03 06:04:38 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:04:38 --> Controller Class Initialized
INFO - 2021-06-03 06:04:38 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:04:38 --> Final output sent to browser
DEBUG - 2021-06-03 06:04:38 --> Total execution time: 0.0918
INFO - 2021-06-03 06:04:38 --> Config Class Initialized
INFO - 2021-06-03 06:04:38 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:04:38 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:04:38 --> Utf8 Class Initialized
INFO - 2021-06-03 06:04:38 --> URI Class Initialized
INFO - 2021-06-03 06:04:38 --> Router Class Initialized
INFO - 2021-06-03 06:04:38 --> Output Class Initialized
INFO - 2021-06-03 06:04:38 --> Security Class Initialized
DEBUG - 2021-06-03 06:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:04:38 --> Input Class Initialized
INFO - 2021-06-03 06:04:38 --> Language Class Initialized
INFO - 2021-06-03 06:04:38 --> Language Class Initialized
INFO - 2021-06-03 06:04:38 --> Config Class Initialized
INFO - 2021-06-03 06:04:38 --> Loader Class Initialized
INFO - 2021-06-03 06:04:38 --> Helper loaded: url_helper
INFO - 2021-06-03 06:04:38 --> Helper loaded: file_helper
INFO - 2021-06-03 06:04:38 --> Helper loaded: form_helper
INFO - 2021-06-03 06:04:38 --> Helper loaded: my_helper
INFO - 2021-06-03 06:04:38 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:04:38 --> Controller Class Initialized
DEBUG - 2021-06-03 06:04:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:04:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:04:38 --> Final output sent to browser
DEBUG - 2021-06-03 06:04:38 --> Total execution time: 0.1845
INFO - 2021-06-03 06:04:47 --> Config Class Initialized
INFO - 2021-06-03 06:04:47 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:04:47 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:04:47 --> Utf8 Class Initialized
INFO - 2021-06-03 06:04:47 --> URI Class Initialized
INFO - 2021-06-03 06:04:47 --> Router Class Initialized
INFO - 2021-06-03 06:04:47 --> Output Class Initialized
INFO - 2021-06-03 06:04:47 --> Security Class Initialized
DEBUG - 2021-06-03 06:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:04:47 --> Input Class Initialized
INFO - 2021-06-03 06:04:47 --> Language Class Initialized
INFO - 2021-06-03 06:04:47 --> Language Class Initialized
INFO - 2021-06-03 06:04:47 --> Config Class Initialized
INFO - 2021-06-03 06:04:47 --> Loader Class Initialized
INFO - 2021-06-03 06:04:47 --> Helper loaded: url_helper
INFO - 2021-06-03 06:04:47 --> Helper loaded: file_helper
INFO - 2021-06-03 06:04:47 --> Helper loaded: form_helper
INFO - 2021-06-03 06:04:47 --> Helper loaded: my_helper
INFO - 2021-06-03 06:04:47 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:04:47 --> Controller Class Initialized
DEBUG - 2021-06-03 06:04:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:04:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:04:47 --> Final output sent to browser
DEBUG - 2021-06-03 06:04:47 --> Total execution time: 0.0821
INFO - 2021-06-03 06:04:49 --> Config Class Initialized
INFO - 2021-06-03 06:04:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:04:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:04:49 --> Utf8 Class Initialized
INFO - 2021-06-03 06:04:49 --> URI Class Initialized
INFO - 2021-06-03 06:04:49 --> Router Class Initialized
INFO - 2021-06-03 06:04:49 --> Output Class Initialized
INFO - 2021-06-03 06:04:49 --> Security Class Initialized
DEBUG - 2021-06-03 06:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:04:49 --> Input Class Initialized
INFO - 2021-06-03 06:04:49 --> Language Class Initialized
INFO - 2021-06-03 06:04:49 --> Language Class Initialized
INFO - 2021-06-03 06:04:49 --> Config Class Initialized
INFO - 2021-06-03 06:04:49 --> Loader Class Initialized
INFO - 2021-06-03 06:04:49 --> Helper loaded: url_helper
INFO - 2021-06-03 06:04:49 --> Helper loaded: file_helper
INFO - 2021-06-03 06:04:49 --> Helper loaded: form_helper
INFO - 2021-06-03 06:04:49 --> Helper loaded: my_helper
INFO - 2021-06-03 06:04:49 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:04:49 --> Controller Class Initialized
DEBUG - 2021-06-03 06:04:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-03 06:04:49 --> Final output sent to browser
DEBUG - 2021-06-03 06:04:49 --> Total execution time: 0.1707
INFO - 2021-06-03 06:05:25 --> Config Class Initialized
INFO - 2021-06-03 06:05:25 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:05:25 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:05:25 --> Utf8 Class Initialized
INFO - 2021-06-03 06:05:25 --> URI Class Initialized
INFO - 2021-06-03 06:05:25 --> Router Class Initialized
INFO - 2021-06-03 06:05:25 --> Output Class Initialized
INFO - 2021-06-03 06:05:25 --> Security Class Initialized
DEBUG - 2021-06-03 06:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:05:25 --> Input Class Initialized
INFO - 2021-06-03 06:05:25 --> Language Class Initialized
INFO - 2021-06-03 06:05:25 --> Language Class Initialized
INFO - 2021-06-03 06:05:25 --> Config Class Initialized
INFO - 2021-06-03 06:05:25 --> Loader Class Initialized
INFO - 2021-06-03 06:05:25 --> Helper loaded: url_helper
INFO - 2021-06-03 06:05:25 --> Helper loaded: file_helper
INFO - 2021-06-03 06:05:25 --> Helper loaded: form_helper
INFO - 2021-06-03 06:05:25 --> Helper loaded: my_helper
INFO - 2021-06-03 06:05:25 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:05:25 --> Controller Class Initialized
DEBUG - 2021-06-03 06:05:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-03 06:05:25 --> Final output sent to browser
DEBUG - 2021-06-03 06:05:25 --> Total execution time: 0.0615
INFO - 2021-06-03 06:06:57 --> Config Class Initialized
INFO - 2021-06-03 06:06:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:06:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:06:57 --> Utf8 Class Initialized
INFO - 2021-06-03 06:06:57 --> URI Class Initialized
INFO - 2021-06-03 06:06:57 --> Router Class Initialized
INFO - 2021-06-03 06:06:57 --> Output Class Initialized
INFO - 2021-06-03 06:06:57 --> Security Class Initialized
DEBUG - 2021-06-03 06:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:06:57 --> Input Class Initialized
INFO - 2021-06-03 06:06:57 --> Language Class Initialized
INFO - 2021-06-03 06:06:57 --> Language Class Initialized
INFO - 2021-06-03 06:06:57 --> Config Class Initialized
INFO - 2021-06-03 06:06:57 --> Loader Class Initialized
INFO - 2021-06-03 06:06:57 --> Helper loaded: url_helper
INFO - 2021-06-03 06:06:57 --> Helper loaded: file_helper
INFO - 2021-06-03 06:06:57 --> Helper loaded: form_helper
INFO - 2021-06-03 06:06:57 --> Helper loaded: my_helper
INFO - 2021-06-03 06:06:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:06:58 --> Controller Class Initialized
DEBUG - 2021-06-03 06:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-03 06:06:58 --> Final output sent to browser
DEBUG - 2021-06-03 06:06:58 --> Total execution time: 0.0743
INFO - 2021-06-03 06:07:49 --> Config Class Initialized
INFO - 2021-06-03 06:07:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:07:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:07:49 --> Utf8 Class Initialized
INFO - 2021-06-03 06:07:49 --> URI Class Initialized
INFO - 2021-06-03 06:07:49 --> Router Class Initialized
INFO - 2021-06-03 06:07:49 --> Output Class Initialized
INFO - 2021-06-03 06:07:49 --> Security Class Initialized
DEBUG - 2021-06-03 06:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:07:49 --> Input Class Initialized
INFO - 2021-06-03 06:07:49 --> Language Class Initialized
INFO - 2021-06-03 06:07:49 --> Language Class Initialized
INFO - 2021-06-03 06:07:49 --> Config Class Initialized
INFO - 2021-06-03 06:07:49 --> Loader Class Initialized
INFO - 2021-06-03 06:07:49 --> Helper loaded: url_helper
INFO - 2021-06-03 06:07:49 --> Helper loaded: file_helper
INFO - 2021-06-03 06:07:49 --> Helper loaded: form_helper
INFO - 2021-06-03 06:07:49 --> Helper loaded: my_helper
INFO - 2021-06-03 06:07:49 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:07:49 --> Controller Class Initialized
DEBUG - 2021-06-03 06:07:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-03 06:07:49 --> Final output sent to browser
DEBUG - 2021-06-03 06:07:49 --> Total execution time: 0.0574
INFO - 2021-06-03 06:09:01 --> Config Class Initialized
INFO - 2021-06-03 06:09:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:01 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:01 --> URI Class Initialized
INFO - 2021-06-03 06:09:01 --> Router Class Initialized
INFO - 2021-06-03 06:09:01 --> Output Class Initialized
INFO - 2021-06-03 06:09:01 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:01 --> Input Class Initialized
INFO - 2021-06-03 06:09:01 --> Language Class Initialized
INFO - 2021-06-03 06:09:01 --> Language Class Initialized
INFO - 2021-06-03 06:09:01 --> Config Class Initialized
INFO - 2021-06-03 06:09:01 --> Loader Class Initialized
INFO - 2021-06-03 06:09:01 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:01 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:01 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:01 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:01 --> Controller Class Initialized
INFO - 2021-06-03 06:09:01 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:09:01 --> Config Class Initialized
INFO - 2021-06-03 06:09:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:01 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:01 --> URI Class Initialized
INFO - 2021-06-03 06:09:01 --> Router Class Initialized
INFO - 2021-06-03 06:09:01 --> Output Class Initialized
INFO - 2021-06-03 06:09:01 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:01 --> Input Class Initialized
INFO - 2021-06-03 06:09:01 --> Language Class Initialized
INFO - 2021-06-03 06:09:01 --> Language Class Initialized
INFO - 2021-06-03 06:09:01 --> Config Class Initialized
INFO - 2021-06-03 06:09:01 --> Loader Class Initialized
INFO - 2021-06-03 06:09:01 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:01 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:01 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:01 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:01 --> Controller Class Initialized
DEBUG - 2021-06-03 06:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:09:01 --> Final output sent to browser
DEBUG - 2021-06-03 06:09:01 --> Total execution time: 0.0827
INFO - 2021-06-03 06:09:13 --> Config Class Initialized
INFO - 2021-06-03 06:09:13 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:13 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:13 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:13 --> URI Class Initialized
INFO - 2021-06-03 06:09:13 --> Router Class Initialized
INFO - 2021-06-03 06:09:13 --> Output Class Initialized
INFO - 2021-06-03 06:09:13 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:13 --> Input Class Initialized
INFO - 2021-06-03 06:09:13 --> Language Class Initialized
INFO - 2021-06-03 06:09:13 --> Language Class Initialized
INFO - 2021-06-03 06:09:13 --> Config Class Initialized
INFO - 2021-06-03 06:09:13 --> Loader Class Initialized
INFO - 2021-06-03 06:09:13 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:13 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:13 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:13 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:13 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:13 --> Controller Class Initialized
INFO - 2021-06-03 06:09:13 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:09:13 --> Final output sent to browser
DEBUG - 2021-06-03 06:09:13 --> Total execution time: 0.0918
INFO - 2021-06-03 06:09:13 --> Config Class Initialized
INFO - 2021-06-03 06:09:13 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:13 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:13 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:13 --> URI Class Initialized
INFO - 2021-06-03 06:09:13 --> Router Class Initialized
INFO - 2021-06-03 06:09:13 --> Output Class Initialized
INFO - 2021-06-03 06:09:13 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:13 --> Input Class Initialized
INFO - 2021-06-03 06:09:13 --> Language Class Initialized
INFO - 2021-06-03 06:09:13 --> Language Class Initialized
INFO - 2021-06-03 06:09:13 --> Config Class Initialized
INFO - 2021-06-03 06:09:13 --> Loader Class Initialized
INFO - 2021-06-03 06:09:13 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:13 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:13 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:13 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:13 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:13 --> Controller Class Initialized
DEBUG - 2021-06-03 06:09:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:09:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:09:13 --> Final output sent to browser
DEBUG - 2021-06-03 06:09:13 --> Total execution time: 0.0897
INFO - 2021-06-03 06:09:36 --> Config Class Initialized
INFO - 2021-06-03 06:09:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:36 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:36 --> URI Class Initialized
INFO - 2021-06-03 06:09:36 --> Router Class Initialized
INFO - 2021-06-03 06:09:36 --> Output Class Initialized
INFO - 2021-06-03 06:09:36 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:36 --> Input Class Initialized
INFO - 2021-06-03 06:09:36 --> Language Class Initialized
INFO - 2021-06-03 06:09:36 --> Language Class Initialized
INFO - 2021-06-03 06:09:36 --> Config Class Initialized
INFO - 2021-06-03 06:09:36 --> Loader Class Initialized
INFO - 2021-06-03 06:09:36 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:36 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:36 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:36 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:36 --> Controller Class Initialized
INFO - 2021-06-03 06:09:36 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:09:36 --> Config Class Initialized
INFO - 2021-06-03 06:09:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:36 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:36 --> URI Class Initialized
INFO - 2021-06-03 06:09:36 --> Router Class Initialized
INFO - 2021-06-03 06:09:36 --> Output Class Initialized
INFO - 2021-06-03 06:09:36 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:36 --> Input Class Initialized
INFO - 2021-06-03 06:09:36 --> Language Class Initialized
INFO - 2021-06-03 06:09:36 --> Language Class Initialized
INFO - 2021-06-03 06:09:36 --> Config Class Initialized
INFO - 2021-06-03 06:09:36 --> Loader Class Initialized
INFO - 2021-06-03 06:09:36 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:36 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:36 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:36 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:36 --> Controller Class Initialized
DEBUG - 2021-06-03 06:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:09:36 --> Final output sent to browser
DEBUG - 2021-06-03 06:09:36 --> Total execution time: 0.0677
INFO - 2021-06-03 06:09:41 --> Config Class Initialized
INFO - 2021-06-03 06:09:41 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:41 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:41 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:41 --> URI Class Initialized
INFO - 2021-06-03 06:09:41 --> Router Class Initialized
INFO - 2021-06-03 06:09:41 --> Output Class Initialized
INFO - 2021-06-03 06:09:41 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:41 --> Input Class Initialized
INFO - 2021-06-03 06:09:41 --> Language Class Initialized
INFO - 2021-06-03 06:09:41 --> Language Class Initialized
INFO - 2021-06-03 06:09:41 --> Config Class Initialized
INFO - 2021-06-03 06:09:41 --> Loader Class Initialized
INFO - 2021-06-03 06:09:41 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:41 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:41 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:41 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:41 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:41 --> Controller Class Initialized
INFO - 2021-06-03 06:09:41 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:09:41 --> Final output sent to browser
DEBUG - 2021-06-03 06:09:41 --> Total execution time: 0.0729
INFO - 2021-06-03 06:09:41 --> Config Class Initialized
INFO - 2021-06-03 06:09:41 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:41 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:41 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:41 --> URI Class Initialized
INFO - 2021-06-03 06:09:41 --> Router Class Initialized
INFO - 2021-06-03 06:09:41 --> Output Class Initialized
INFO - 2021-06-03 06:09:41 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:41 --> Input Class Initialized
INFO - 2021-06-03 06:09:41 --> Language Class Initialized
INFO - 2021-06-03 06:09:41 --> Language Class Initialized
INFO - 2021-06-03 06:09:41 --> Config Class Initialized
INFO - 2021-06-03 06:09:41 --> Loader Class Initialized
INFO - 2021-06-03 06:09:41 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:41 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:41 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:41 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:41 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:41 --> Controller Class Initialized
DEBUG - 2021-06-03 06:09:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:09:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:09:41 --> Final output sent to browser
DEBUG - 2021-06-03 06:09:41 --> Total execution time: 0.0696
INFO - 2021-06-03 06:09:46 --> Config Class Initialized
INFO - 2021-06-03 06:09:46 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:46 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:46 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:46 --> URI Class Initialized
INFO - 2021-06-03 06:09:46 --> Router Class Initialized
INFO - 2021-06-03 06:09:46 --> Output Class Initialized
INFO - 2021-06-03 06:09:46 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:46 --> Input Class Initialized
INFO - 2021-06-03 06:09:46 --> Language Class Initialized
INFO - 2021-06-03 06:09:46 --> Language Class Initialized
INFO - 2021-06-03 06:09:46 --> Config Class Initialized
INFO - 2021-06-03 06:09:46 --> Loader Class Initialized
INFO - 2021-06-03 06:09:46 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:46 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:46 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:46 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:46 --> Controller Class Initialized
DEBUG - 2021-06-03 06:09:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:09:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:09:46 --> Final output sent to browser
DEBUG - 2021-06-03 06:09:46 --> Total execution time: 0.0790
INFO - 2021-06-03 06:09:47 --> Config Class Initialized
INFO - 2021-06-03 06:09:47 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:09:47 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:09:47 --> Utf8 Class Initialized
INFO - 2021-06-03 06:09:47 --> URI Class Initialized
INFO - 2021-06-03 06:09:47 --> Router Class Initialized
INFO - 2021-06-03 06:09:47 --> Output Class Initialized
INFO - 2021-06-03 06:09:47 --> Security Class Initialized
DEBUG - 2021-06-03 06:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:09:47 --> Input Class Initialized
INFO - 2021-06-03 06:09:47 --> Language Class Initialized
INFO - 2021-06-03 06:09:47 --> Language Class Initialized
INFO - 2021-06-03 06:09:47 --> Config Class Initialized
INFO - 2021-06-03 06:09:47 --> Loader Class Initialized
INFO - 2021-06-03 06:09:47 --> Helper loaded: url_helper
INFO - 2021-06-03 06:09:47 --> Helper loaded: file_helper
INFO - 2021-06-03 06:09:47 --> Helper loaded: form_helper
INFO - 2021-06-03 06:09:47 --> Helper loaded: my_helper
INFO - 2021-06-03 06:09:47 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:09:47 --> Controller Class Initialized
DEBUG - 2021-06-03 06:09:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-03 06:09:47 --> Final output sent to browser
DEBUG - 2021-06-03 06:09:47 --> Total execution time: 0.0931
INFO - 2021-06-03 06:10:04 --> Config Class Initialized
INFO - 2021-06-03 06:10:04 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:10:04 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:10:04 --> Utf8 Class Initialized
INFO - 2021-06-03 06:10:04 --> URI Class Initialized
INFO - 2021-06-03 06:10:04 --> Router Class Initialized
INFO - 2021-06-03 06:10:04 --> Output Class Initialized
INFO - 2021-06-03 06:10:04 --> Security Class Initialized
DEBUG - 2021-06-03 06:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:10:04 --> Input Class Initialized
INFO - 2021-06-03 06:10:04 --> Language Class Initialized
INFO - 2021-06-03 06:10:04 --> Language Class Initialized
INFO - 2021-06-03 06:10:04 --> Config Class Initialized
INFO - 2021-06-03 06:10:04 --> Loader Class Initialized
INFO - 2021-06-03 06:10:04 --> Helper loaded: url_helper
INFO - 2021-06-03 06:10:04 --> Helper loaded: file_helper
INFO - 2021-06-03 06:10:04 --> Helper loaded: form_helper
INFO - 2021-06-03 06:10:04 --> Helper loaded: my_helper
INFO - 2021-06-03 06:10:04 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:10:04 --> Controller Class Initialized
DEBUG - 2021-06-03 06:10:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-03 06:10:04 --> Final output sent to browser
DEBUG - 2021-06-03 06:10:04 --> Total execution time: 0.0550
INFO - 2021-06-03 06:11:45 --> Config Class Initialized
INFO - 2021-06-03 06:11:45 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:11:45 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:11:45 --> Utf8 Class Initialized
INFO - 2021-06-03 06:11:45 --> URI Class Initialized
INFO - 2021-06-03 06:11:45 --> Router Class Initialized
INFO - 2021-06-03 06:11:45 --> Output Class Initialized
INFO - 2021-06-03 06:11:45 --> Security Class Initialized
DEBUG - 2021-06-03 06:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:11:45 --> Input Class Initialized
INFO - 2021-06-03 06:11:45 --> Language Class Initialized
INFO - 2021-06-03 06:11:45 --> Language Class Initialized
INFO - 2021-06-03 06:11:45 --> Config Class Initialized
INFO - 2021-06-03 06:11:45 --> Loader Class Initialized
INFO - 2021-06-03 06:11:45 --> Helper loaded: url_helper
INFO - 2021-06-03 06:11:45 --> Helper loaded: file_helper
INFO - 2021-06-03 06:11:45 --> Helper loaded: form_helper
INFO - 2021-06-03 06:11:45 --> Helper loaded: my_helper
INFO - 2021-06-03 06:11:45 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:11:45 --> Controller Class Initialized
INFO - 2021-06-03 06:11:45 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:11:45 --> Config Class Initialized
INFO - 2021-06-03 06:11:45 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:11:45 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:11:45 --> Utf8 Class Initialized
INFO - 2021-06-03 06:11:45 --> URI Class Initialized
INFO - 2021-06-03 06:11:45 --> Router Class Initialized
INFO - 2021-06-03 06:11:45 --> Output Class Initialized
INFO - 2021-06-03 06:11:45 --> Security Class Initialized
DEBUG - 2021-06-03 06:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:11:45 --> Input Class Initialized
INFO - 2021-06-03 06:11:45 --> Language Class Initialized
INFO - 2021-06-03 06:11:45 --> Language Class Initialized
INFO - 2021-06-03 06:11:45 --> Config Class Initialized
INFO - 2021-06-03 06:11:45 --> Loader Class Initialized
INFO - 2021-06-03 06:11:45 --> Helper loaded: url_helper
INFO - 2021-06-03 06:11:45 --> Helper loaded: file_helper
INFO - 2021-06-03 06:11:45 --> Helper loaded: form_helper
INFO - 2021-06-03 06:11:45 --> Helper loaded: my_helper
INFO - 2021-06-03 06:11:45 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:11:45 --> Controller Class Initialized
DEBUG - 2021-06-03 06:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:11:45 --> Final output sent to browser
DEBUG - 2021-06-03 06:11:45 --> Total execution time: 0.0666
INFO - 2021-06-03 06:11:58 --> Config Class Initialized
INFO - 2021-06-03 06:11:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:11:58 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:11:58 --> Utf8 Class Initialized
INFO - 2021-06-03 06:11:58 --> URI Class Initialized
INFO - 2021-06-03 06:11:58 --> Router Class Initialized
INFO - 2021-06-03 06:11:58 --> Output Class Initialized
INFO - 2021-06-03 06:11:58 --> Security Class Initialized
DEBUG - 2021-06-03 06:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:11:58 --> Input Class Initialized
INFO - 2021-06-03 06:11:58 --> Language Class Initialized
INFO - 2021-06-03 06:11:58 --> Language Class Initialized
INFO - 2021-06-03 06:11:58 --> Config Class Initialized
INFO - 2021-06-03 06:11:58 --> Loader Class Initialized
INFO - 2021-06-03 06:11:58 --> Helper loaded: url_helper
INFO - 2021-06-03 06:11:58 --> Helper loaded: file_helper
INFO - 2021-06-03 06:11:58 --> Helper loaded: form_helper
INFO - 2021-06-03 06:11:58 --> Helper loaded: my_helper
INFO - 2021-06-03 06:11:58 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:11:58 --> Controller Class Initialized
INFO - 2021-06-03 06:11:58 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:11:58 --> Final output sent to browser
DEBUG - 2021-06-03 06:11:58 --> Total execution time: 0.0693
INFO - 2021-06-03 06:11:58 --> Config Class Initialized
INFO - 2021-06-03 06:11:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:11:58 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:11:58 --> Utf8 Class Initialized
INFO - 2021-06-03 06:11:58 --> URI Class Initialized
INFO - 2021-06-03 06:11:58 --> Router Class Initialized
INFO - 2021-06-03 06:11:58 --> Output Class Initialized
INFO - 2021-06-03 06:11:58 --> Security Class Initialized
DEBUG - 2021-06-03 06:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:11:58 --> Input Class Initialized
INFO - 2021-06-03 06:11:58 --> Language Class Initialized
INFO - 2021-06-03 06:11:58 --> Language Class Initialized
INFO - 2021-06-03 06:11:58 --> Config Class Initialized
INFO - 2021-06-03 06:11:58 --> Loader Class Initialized
INFO - 2021-06-03 06:11:58 --> Helper loaded: url_helper
INFO - 2021-06-03 06:11:58 --> Helper loaded: file_helper
INFO - 2021-06-03 06:11:58 --> Helper loaded: form_helper
INFO - 2021-06-03 06:11:58 --> Helper loaded: my_helper
INFO - 2021-06-03 06:11:58 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:11:58 --> Controller Class Initialized
DEBUG - 2021-06-03 06:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:11:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:11:58 --> Final output sent to browser
DEBUG - 2021-06-03 06:11:58 --> Total execution time: 0.0889
INFO - 2021-06-03 06:12:01 --> Config Class Initialized
INFO - 2021-06-03 06:12:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:01 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:01 --> URI Class Initialized
INFO - 2021-06-03 06:12:01 --> Router Class Initialized
INFO - 2021-06-03 06:12:01 --> Output Class Initialized
INFO - 2021-06-03 06:12:01 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:01 --> Input Class Initialized
INFO - 2021-06-03 06:12:01 --> Language Class Initialized
INFO - 2021-06-03 06:12:01 --> Language Class Initialized
INFO - 2021-06-03 06:12:01 --> Config Class Initialized
INFO - 2021-06-03 06:12:01 --> Loader Class Initialized
INFO - 2021-06-03 06:12:01 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:01 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:01 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:01 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:02 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:12:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:02 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:02 --> Total execution time: 0.0732
INFO - 2021-06-03 06:12:03 --> Config Class Initialized
INFO - 2021-06-03 06:12:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:03 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:03 --> URI Class Initialized
INFO - 2021-06-03 06:12:03 --> Router Class Initialized
INFO - 2021-06-03 06:12:03 --> Output Class Initialized
INFO - 2021-06-03 06:12:03 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:03 --> Input Class Initialized
INFO - 2021-06-03 06:12:03 --> Language Class Initialized
INFO - 2021-06-03 06:12:03 --> Language Class Initialized
INFO - 2021-06-03 06:12:03 --> Config Class Initialized
INFO - 2021-06-03 06:12:03 --> Loader Class Initialized
INFO - 2021-06-03 06:12:03 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:03 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:03 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:03 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:03 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-03 06:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:03 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:03 --> Total execution time: 0.1110
INFO - 2021-06-03 06:12:04 --> Config Class Initialized
INFO - 2021-06-03 06:12:04 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:04 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:04 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:04 --> URI Class Initialized
INFO - 2021-06-03 06:12:04 --> Router Class Initialized
INFO - 2021-06-03 06:12:04 --> Output Class Initialized
INFO - 2021-06-03 06:12:04 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:04 --> Input Class Initialized
INFO - 2021-06-03 06:12:04 --> Language Class Initialized
INFO - 2021-06-03 06:12:04 --> Language Class Initialized
INFO - 2021-06-03 06:12:04 --> Config Class Initialized
INFO - 2021-06-03 06:12:04 --> Loader Class Initialized
INFO - 2021-06-03 06:12:04 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:04 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:04 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:04 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:04 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:04 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 06:12:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:04 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:04 --> Total execution time: 0.1078
INFO - 2021-06-03 06:12:05 --> Config Class Initialized
INFO - 2021-06-03 06:12:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:05 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:05 --> URI Class Initialized
INFO - 2021-06-03 06:12:05 --> Router Class Initialized
INFO - 2021-06-03 06:12:05 --> Output Class Initialized
INFO - 2021-06-03 06:12:05 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:05 --> Input Class Initialized
INFO - 2021-06-03 06:12:05 --> Language Class Initialized
INFO - 2021-06-03 06:12:05 --> Language Class Initialized
INFO - 2021-06-03 06:12:05 --> Config Class Initialized
INFO - 2021-06-03 06:12:05 --> Loader Class Initialized
INFO - 2021-06-03 06:12:05 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:05 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:05 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:05 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:05 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 06:12:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:05 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:05 --> Total execution time: 0.1109
INFO - 2021-06-03 06:12:07 --> Config Class Initialized
INFO - 2021-06-03 06:12:07 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:07 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:07 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:07 --> URI Class Initialized
INFO - 2021-06-03 06:12:07 --> Router Class Initialized
INFO - 2021-06-03 06:12:07 --> Output Class Initialized
INFO - 2021-06-03 06:12:07 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:07 --> Input Class Initialized
INFO - 2021-06-03 06:12:07 --> Language Class Initialized
INFO - 2021-06-03 06:12:07 --> Language Class Initialized
INFO - 2021-06-03 06:12:07 --> Config Class Initialized
INFO - 2021-06-03 06:12:07 --> Loader Class Initialized
INFO - 2021-06-03 06:12:07 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:07 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:07 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:07 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:07 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 06:12:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:07 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:07 --> Total execution time: 0.0805
INFO - 2021-06-03 06:12:08 --> Config Class Initialized
INFO - 2021-06-03 06:12:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:08 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:08 --> URI Class Initialized
INFO - 2021-06-03 06:12:08 --> Router Class Initialized
INFO - 2021-06-03 06:12:08 --> Output Class Initialized
INFO - 2021-06-03 06:12:08 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:08 --> Input Class Initialized
INFO - 2021-06-03 06:12:08 --> Language Class Initialized
INFO - 2021-06-03 06:12:08 --> Language Class Initialized
INFO - 2021-06-03 06:12:08 --> Config Class Initialized
INFO - 2021-06-03 06:12:08 --> Loader Class Initialized
INFO - 2021-06-03 06:12:08 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:08 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:08 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:08 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:08 --> Controller Class Initialized
INFO - 2021-06-03 06:12:08 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:08 --> Total execution time: 0.0584
INFO - 2021-06-03 06:12:13 --> Config Class Initialized
INFO - 2021-06-03 06:12:13 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:13 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:13 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:13 --> URI Class Initialized
INFO - 2021-06-03 06:12:13 --> Router Class Initialized
INFO - 2021-06-03 06:12:13 --> Output Class Initialized
INFO - 2021-06-03 06:12:13 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:13 --> Input Class Initialized
INFO - 2021-06-03 06:12:13 --> Language Class Initialized
INFO - 2021-06-03 06:12:13 --> Language Class Initialized
INFO - 2021-06-03 06:12:13 --> Config Class Initialized
INFO - 2021-06-03 06:12:13 --> Loader Class Initialized
INFO - 2021-06-03 06:12:13 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:13 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:13 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:13 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:13 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:13 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 06:12:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:13 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:13 --> Total execution time: 0.0699
INFO - 2021-06-03 06:12:14 --> Config Class Initialized
INFO - 2021-06-03 06:12:14 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:14 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:14 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:14 --> URI Class Initialized
INFO - 2021-06-03 06:12:14 --> Router Class Initialized
INFO - 2021-06-03 06:12:14 --> Output Class Initialized
INFO - 2021-06-03 06:12:14 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:14 --> Input Class Initialized
INFO - 2021-06-03 06:12:14 --> Language Class Initialized
INFO - 2021-06-03 06:12:14 --> Language Class Initialized
INFO - 2021-06-03 06:12:14 --> Config Class Initialized
INFO - 2021-06-03 06:12:14 --> Loader Class Initialized
INFO - 2021-06-03 06:12:14 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:14 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:14 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:14 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:14 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:14 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 06:12:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:14 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:14 --> Total execution time: 0.1085
INFO - 2021-06-03 06:12:16 --> Config Class Initialized
INFO - 2021-06-03 06:12:16 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:16 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:16 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:16 --> URI Class Initialized
INFO - 2021-06-03 06:12:16 --> Router Class Initialized
INFO - 2021-06-03 06:12:16 --> Output Class Initialized
INFO - 2021-06-03 06:12:16 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:16 --> Input Class Initialized
INFO - 2021-06-03 06:12:16 --> Language Class Initialized
INFO - 2021-06-03 06:12:16 --> Language Class Initialized
INFO - 2021-06-03 06:12:16 --> Config Class Initialized
INFO - 2021-06-03 06:12:16 --> Loader Class Initialized
INFO - 2021-06-03 06:12:16 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:16 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:16 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:16 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:16 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:17 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-06-03 06:12:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:17 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:17 --> Total execution time: 0.1063
INFO - 2021-06-03 06:12:18 --> Config Class Initialized
INFO - 2021-06-03 06:12:18 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:18 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:18 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:18 --> URI Class Initialized
INFO - 2021-06-03 06:12:18 --> Router Class Initialized
INFO - 2021-06-03 06:12:18 --> Output Class Initialized
INFO - 2021-06-03 06:12:18 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:18 --> Input Class Initialized
INFO - 2021-06-03 06:12:18 --> Language Class Initialized
INFO - 2021-06-03 06:12:18 --> Language Class Initialized
INFO - 2021-06-03 06:12:18 --> Config Class Initialized
INFO - 2021-06-03 06:12:18 --> Loader Class Initialized
INFO - 2021-06-03 06:12:18 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:18 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:18 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:18 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:18 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:18 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 06:12:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:18 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:18 --> Total execution time: 0.1164
INFO - 2021-06-03 06:12:19 --> Config Class Initialized
INFO - 2021-06-03 06:12:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:19 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:19 --> URI Class Initialized
INFO - 2021-06-03 06:12:19 --> Router Class Initialized
INFO - 2021-06-03 06:12:19 --> Output Class Initialized
INFO - 2021-06-03 06:12:19 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:19 --> Input Class Initialized
INFO - 2021-06-03 06:12:19 --> Language Class Initialized
INFO - 2021-06-03 06:12:19 --> Language Class Initialized
INFO - 2021-06-03 06:12:19 --> Config Class Initialized
INFO - 2021-06-03 06:12:19 --> Loader Class Initialized
INFO - 2021-06-03 06:12:19 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:19 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:19 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:19 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:19 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:19 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:12:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:19 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:19 --> Total execution time: 0.0733
INFO - 2021-06-03 06:12:22 --> Config Class Initialized
INFO - 2021-06-03 06:12:22 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:22 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:22 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:22 --> URI Class Initialized
DEBUG - 2021-06-03 06:12:22 --> No URI present. Default controller set.
INFO - 2021-06-03 06:12:22 --> Router Class Initialized
INFO - 2021-06-03 06:12:22 --> Output Class Initialized
INFO - 2021-06-03 06:12:22 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:22 --> Input Class Initialized
INFO - 2021-06-03 06:12:22 --> Language Class Initialized
INFO - 2021-06-03 06:12:22 --> Language Class Initialized
INFO - 2021-06-03 06:12:22 --> Config Class Initialized
INFO - 2021-06-03 06:12:22 --> Loader Class Initialized
INFO - 2021-06-03 06:12:22 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:22 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:22 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:22 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:22 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:22 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:22 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:22 --> Total execution time: 0.0690
INFO - 2021-06-03 06:12:25 --> Config Class Initialized
INFO - 2021-06-03 06:12:25 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:25 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:25 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:25 --> URI Class Initialized
INFO - 2021-06-03 06:12:25 --> Router Class Initialized
INFO - 2021-06-03 06:12:25 --> Output Class Initialized
INFO - 2021-06-03 06:12:25 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:25 --> Input Class Initialized
INFO - 2021-06-03 06:12:25 --> Language Class Initialized
INFO - 2021-06-03 06:12:25 --> Language Class Initialized
INFO - 2021-06-03 06:12:25 --> Config Class Initialized
INFO - 2021-06-03 06:12:25 --> Loader Class Initialized
INFO - 2021-06-03 06:12:25 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:25 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:25 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:25 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:25 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:25 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:12:25 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:25 --> Total execution time: 0.0709
INFO - 2021-06-03 06:12:27 --> Config Class Initialized
INFO - 2021-06-03 06:12:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:12:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:12:27 --> Utf8 Class Initialized
INFO - 2021-06-03 06:12:27 --> URI Class Initialized
INFO - 2021-06-03 06:12:27 --> Router Class Initialized
INFO - 2021-06-03 06:12:27 --> Output Class Initialized
INFO - 2021-06-03 06:12:27 --> Security Class Initialized
DEBUG - 2021-06-03 06:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:12:27 --> Input Class Initialized
INFO - 2021-06-03 06:12:27 --> Language Class Initialized
INFO - 2021-06-03 06:12:27 --> Language Class Initialized
INFO - 2021-06-03 06:12:27 --> Config Class Initialized
INFO - 2021-06-03 06:12:27 --> Loader Class Initialized
INFO - 2021-06-03 06:12:27 --> Helper loaded: url_helper
INFO - 2021-06-03 06:12:27 --> Helper loaded: file_helper
INFO - 2021-06-03 06:12:27 --> Helper loaded: form_helper
INFO - 2021-06-03 06:12:27 --> Helper loaded: my_helper
INFO - 2021-06-03 06:12:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:12:27 --> Controller Class Initialized
DEBUG - 2021-06-03 06:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:12:27 --> Final output sent to browser
DEBUG - 2021-06-03 06:12:27 --> Total execution time: 0.1966
INFO - 2021-06-03 06:13:48 --> Config Class Initialized
INFO - 2021-06-03 06:13:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:13:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:13:48 --> Utf8 Class Initialized
INFO - 2021-06-03 06:13:48 --> URI Class Initialized
INFO - 2021-06-03 06:13:48 --> Router Class Initialized
INFO - 2021-06-03 06:13:48 --> Output Class Initialized
INFO - 2021-06-03 06:13:48 --> Security Class Initialized
DEBUG - 2021-06-03 06:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:13:48 --> Input Class Initialized
INFO - 2021-06-03 06:13:48 --> Language Class Initialized
INFO - 2021-06-03 06:13:48 --> Language Class Initialized
INFO - 2021-06-03 06:13:48 --> Config Class Initialized
INFO - 2021-06-03 06:13:48 --> Loader Class Initialized
INFO - 2021-06-03 06:13:48 --> Helper loaded: url_helper
INFO - 2021-06-03 06:13:48 --> Helper loaded: file_helper
INFO - 2021-06-03 06:13:48 --> Helper loaded: form_helper
INFO - 2021-06-03 06:13:48 --> Helper loaded: my_helper
INFO - 2021-06-03 06:13:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:13:48 --> Controller Class Initialized
DEBUG - 2021-06-03 06:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:13:48 --> Final output sent to browser
DEBUG - 2021-06-03 06:13:48 --> Total execution time: 0.0708
INFO - 2021-06-03 06:15:17 --> Config Class Initialized
INFO - 2021-06-03 06:15:17 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:15:17 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:15:17 --> Utf8 Class Initialized
INFO - 2021-06-03 06:15:17 --> URI Class Initialized
INFO - 2021-06-03 06:15:17 --> Router Class Initialized
INFO - 2021-06-03 06:15:17 --> Output Class Initialized
INFO - 2021-06-03 06:15:17 --> Security Class Initialized
DEBUG - 2021-06-03 06:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:15:17 --> Input Class Initialized
INFO - 2021-06-03 06:15:17 --> Language Class Initialized
INFO - 2021-06-03 06:15:17 --> Language Class Initialized
INFO - 2021-06-03 06:15:17 --> Config Class Initialized
INFO - 2021-06-03 06:15:17 --> Loader Class Initialized
INFO - 2021-06-03 06:15:17 --> Helper loaded: url_helper
INFO - 2021-06-03 06:15:17 --> Helper loaded: file_helper
INFO - 2021-06-03 06:15:17 --> Helper loaded: form_helper
INFO - 2021-06-03 06:15:17 --> Helper loaded: my_helper
INFO - 2021-06-03 06:15:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:15:17 --> Controller Class Initialized
DEBUG - 2021-06-03 06:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:15:17 --> Final output sent to browser
DEBUG - 2021-06-03 06:15:17 --> Total execution time: 0.0787
INFO - 2021-06-03 06:15:50 --> Config Class Initialized
INFO - 2021-06-03 06:15:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:15:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:15:50 --> Utf8 Class Initialized
INFO - 2021-06-03 06:15:50 --> URI Class Initialized
INFO - 2021-06-03 06:15:50 --> Router Class Initialized
INFO - 2021-06-03 06:15:50 --> Output Class Initialized
INFO - 2021-06-03 06:15:50 --> Security Class Initialized
DEBUG - 2021-06-03 06:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:15:50 --> Input Class Initialized
INFO - 2021-06-03 06:15:50 --> Language Class Initialized
INFO - 2021-06-03 06:15:50 --> Language Class Initialized
INFO - 2021-06-03 06:15:50 --> Config Class Initialized
INFO - 2021-06-03 06:15:50 --> Loader Class Initialized
INFO - 2021-06-03 06:15:50 --> Helper loaded: url_helper
INFO - 2021-06-03 06:15:50 --> Helper loaded: file_helper
INFO - 2021-06-03 06:15:50 --> Helper loaded: form_helper
INFO - 2021-06-03 06:15:50 --> Helper loaded: my_helper
INFO - 2021-06-03 06:15:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:15:50 --> Controller Class Initialized
DEBUG - 2021-06-03 06:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:15:50 --> Final output sent to browser
DEBUG - 2021-06-03 06:15:50 --> Total execution time: 0.0789
INFO - 2021-06-03 06:17:00 --> Config Class Initialized
INFO - 2021-06-03 06:17:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:17:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:17:00 --> Utf8 Class Initialized
INFO - 2021-06-03 06:17:00 --> URI Class Initialized
INFO - 2021-06-03 06:17:00 --> Router Class Initialized
INFO - 2021-06-03 06:17:00 --> Output Class Initialized
INFO - 2021-06-03 06:17:00 --> Security Class Initialized
DEBUG - 2021-06-03 06:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:17:00 --> Input Class Initialized
INFO - 2021-06-03 06:17:00 --> Language Class Initialized
INFO - 2021-06-03 06:17:00 --> Language Class Initialized
INFO - 2021-06-03 06:17:00 --> Config Class Initialized
INFO - 2021-06-03 06:17:00 --> Loader Class Initialized
INFO - 2021-06-03 06:17:00 --> Helper loaded: url_helper
INFO - 2021-06-03 06:17:00 --> Helper loaded: file_helper
INFO - 2021-06-03 06:17:00 --> Helper loaded: form_helper
INFO - 2021-06-03 06:17:00 --> Helper loaded: my_helper
INFO - 2021-06-03 06:17:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:17:00 --> Controller Class Initialized
DEBUG - 2021-06-03 06:17:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:17:00 --> Final output sent to browser
DEBUG - 2021-06-03 06:17:00 --> Total execution time: 0.0701
INFO - 2021-06-03 06:18:53 --> Config Class Initialized
INFO - 2021-06-03 06:18:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:18:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:18:53 --> Utf8 Class Initialized
INFO - 2021-06-03 06:18:53 --> URI Class Initialized
INFO - 2021-06-03 06:18:53 --> Router Class Initialized
INFO - 2021-06-03 06:18:53 --> Output Class Initialized
INFO - 2021-06-03 06:18:53 --> Security Class Initialized
DEBUG - 2021-06-03 06:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:18:53 --> Input Class Initialized
INFO - 2021-06-03 06:18:53 --> Language Class Initialized
INFO - 2021-06-03 06:18:53 --> Language Class Initialized
INFO - 2021-06-03 06:18:53 --> Config Class Initialized
INFO - 2021-06-03 06:18:53 --> Loader Class Initialized
INFO - 2021-06-03 06:18:53 --> Helper loaded: url_helper
INFO - 2021-06-03 06:18:53 --> Helper loaded: file_helper
INFO - 2021-06-03 06:18:53 --> Helper loaded: form_helper
INFO - 2021-06-03 06:18:53 --> Helper loaded: my_helper
INFO - 2021-06-03 06:18:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:18:53 --> Controller Class Initialized
DEBUG - 2021-06-03 06:18:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:18:53 --> Final output sent to browser
DEBUG - 2021-06-03 06:18:53 --> Total execution time: 0.0602
INFO - 2021-06-03 06:19:22 --> Config Class Initialized
INFO - 2021-06-03 06:19:22 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:19:22 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:19:22 --> Utf8 Class Initialized
INFO - 2021-06-03 06:19:22 --> URI Class Initialized
INFO - 2021-06-03 06:19:22 --> Router Class Initialized
INFO - 2021-06-03 06:19:22 --> Output Class Initialized
INFO - 2021-06-03 06:19:22 --> Security Class Initialized
DEBUG - 2021-06-03 06:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:19:22 --> Input Class Initialized
INFO - 2021-06-03 06:19:22 --> Language Class Initialized
INFO - 2021-06-03 06:19:22 --> Language Class Initialized
INFO - 2021-06-03 06:19:22 --> Config Class Initialized
INFO - 2021-06-03 06:19:22 --> Loader Class Initialized
INFO - 2021-06-03 06:19:22 --> Helper loaded: url_helper
INFO - 2021-06-03 06:19:22 --> Helper loaded: file_helper
INFO - 2021-06-03 06:19:22 --> Helper loaded: form_helper
INFO - 2021-06-03 06:19:22 --> Helper loaded: my_helper
INFO - 2021-06-03 06:19:22 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:19:22 --> Controller Class Initialized
DEBUG - 2021-06-03 06:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:19:22 --> Final output sent to browser
DEBUG - 2021-06-03 06:19:22 --> Total execution time: 0.0844
INFO - 2021-06-03 06:19:41 --> Config Class Initialized
INFO - 2021-06-03 06:19:41 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:19:41 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:19:41 --> Utf8 Class Initialized
INFO - 2021-06-03 06:19:41 --> URI Class Initialized
INFO - 2021-06-03 06:19:41 --> Router Class Initialized
INFO - 2021-06-03 06:19:41 --> Output Class Initialized
INFO - 2021-06-03 06:19:41 --> Security Class Initialized
DEBUG - 2021-06-03 06:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:19:41 --> Input Class Initialized
INFO - 2021-06-03 06:19:41 --> Language Class Initialized
INFO - 2021-06-03 06:19:41 --> Language Class Initialized
INFO - 2021-06-03 06:19:41 --> Config Class Initialized
INFO - 2021-06-03 06:19:41 --> Loader Class Initialized
INFO - 2021-06-03 06:19:41 --> Helper loaded: url_helper
INFO - 2021-06-03 06:19:41 --> Helper loaded: file_helper
INFO - 2021-06-03 06:19:41 --> Helper loaded: form_helper
INFO - 2021-06-03 06:19:41 --> Helper loaded: my_helper
INFO - 2021-06-03 06:19:41 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:19:41 --> Controller Class Initialized
DEBUG - 2021-06-03 06:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:19:41 --> Final output sent to browser
DEBUG - 2021-06-03 06:19:41 --> Total execution time: 0.0827
INFO - 2021-06-03 06:19:51 --> Config Class Initialized
INFO - 2021-06-03 06:19:51 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:19:51 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:19:51 --> Utf8 Class Initialized
INFO - 2021-06-03 06:19:51 --> URI Class Initialized
INFO - 2021-06-03 06:19:51 --> Router Class Initialized
INFO - 2021-06-03 06:19:51 --> Output Class Initialized
INFO - 2021-06-03 06:19:51 --> Security Class Initialized
DEBUG - 2021-06-03 06:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:19:51 --> Input Class Initialized
INFO - 2021-06-03 06:19:51 --> Language Class Initialized
INFO - 2021-06-03 06:19:51 --> Language Class Initialized
INFO - 2021-06-03 06:19:51 --> Config Class Initialized
INFO - 2021-06-03 06:19:51 --> Loader Class Initialized
INFO - 2021-06-03 06:19:51 --> Helper loaded: url_helper
INFO - 2021-06-03 06:19:51 --> Helper loaded: file_helper
INFO - 2021-06-03 06:19:51 --> Helper loaded: form_helper
INFO - 2021-06-03 06:19:51 --> Helper loaded: my_helper
INFO - 2021-06-03 06:19:51 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:19:51 --> Controller Class Initialized
DEBUG - 2021-06-03 06:19:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:19:51 --> Final output sent to browser
DEBUG - 2021-06-03 06:19:51 --> Total execution time: 0.0926
INFO - 2021-06-03 06:20:44 --> Config Class Initialized
INFO - 2021-06-03 06:20:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:20:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:20:44 --> Utf8 Class Initialized
INFO - 2021-06-03 06:20:44 --> URI Class Initialized
INFO - 2021-06-03 06:20:44 --> Router Class Initialized
INFO - 2021-06-03 06:20:44 --> Output Class Initialized
INFO - 2021-06-03 06:20:44 --> Security Class Initialized
DEBUG - 2021-06-03 06:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:20:44 --> Input Class Initialized
INFO - 2021-06-03 06:20:44 --> Language Class Initialized
INFO - 2021-06-03 06:20:44 --> Language Class Initialized
INFO - 2021-06-03 06:20:44 --> Config Class Initialized
INFO - 2021-06-03 06:20:44 --> Loader Class Initialized
INFO - 2021-06-03 06:20:44 --> Helper loaded: url_helper
INFO - 2021-06-03 06:20:44 --> Helper loaded: file_helper
INFO - 2021-06-03 06:20:44 --> Helper loaded: form_helper
INFO - 2021-06-03 06:20:44 --> Helper loaded: my_helper
INFO - 2021-06-03 06:20:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:20:44 --> Controller Class Initialized
DEBUG - 2021-06-03 06:20:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:20:44 --> Final output sent to browser
DEBUG - 2021-06-03 06:20:44 --> Total execution time: 0.0645
INFO - 2021-06-03 06:22:13 --> Config Class Initialized
INFO - 2021-06-03 06:22:13 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:22:13 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:22:13 --> Utf8 Class Initialized
INFO - 2021-06-03 06:22:13 --> URI Class Initialized
INFO - 2021-06-03 06:22:13 --> Router Class Initialized
INFO - 2021-06-03 06:22:13 --> Output Class Initialized
INFO - 2021-06-03 06:22:13 --> Security Class Initialized
DEBUG - 2021-06-03 06:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:22:13 --> Input Class Initialized
INFO - 2021-06-03 06:22:13 --> Language Class Initialized
INFO - 2021-06-03 06:22:13 --> Language Class Initialized
INFO - 2021-06-03 06:22:13 --> Config Class Initialized
INFO - 2021-06-03 06:22:13 --> Loader Class Initialized
INFO - 2021-06-03 06:22:13 --> Helper loaded: url_helper
INFO - 2021-06-03 06:22:13 --> Helper loaded: file_helper
INFO - 2021-06-03 06:22:13 --> Helper loaded: form_helper
INFO - 2021-06-03 06:22:13 --> Helper loaded: my_helper
INFO - 2021-06-03 06:22:13 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:22:13 --> Controller Class Initialized
DEBUG - 2021-06-03 06:22:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:22:13 --> Final output sent to browser
DEBUG - 2021-06-03 06:22:13 --> Total execution time: 0.0730
INFO - 2021-06-03 06:22:49 --> Config Class Initialized
INFO - 2021-06-03 06:22:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:22:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:22:49 --> Utf8 Class Initialized
INFO - 2021-06-03 06:22:49 --> URI Class Initialized
INFO - 2021-06-03 06:22:49 --> Router Class Initialized
INFO - 2021-06-03 06:22:49 --> Output Class Initialized
INFO - 2021-06-03 06:22:49 --> Security Class Initialized
DEBUG - 2021-06-03 06:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:22:49 --> Input Class Initialized
INFO - 2021-06-03 06:22:49 --> Language Class Initialized
INFO - 2021-06-03 06:22:49 --> Language Class Initialized
INFO - 2021-06-03 06:22:49 --> Config Class Initialized
INFO - 2021-06-03 06:22:49 --> Loader Class Initialized
INFO - 2021-06-03 06:22:49 --> Helper loaded: url_helper
INFO - 2021-06-03 06:22:49 --> Helper loaded: file_helper
INFO - 2021-06-03 06:22:49 --> Helper loaded: form_helper
INFO - 2021-06-03 06:22:49 --> Helper loaded: my_helper
INFO - 2021-06-03 06:22:49 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:22:49 --> Controller Class Initialized
DEBUG - 2021-06-03 06:22:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:22:49 --> Final output sent to browser
DEBUG - 2021-06-03 06:22:49 --> Total execution time: 0.0623
INFO - 2021-06-03 06:23:26 --> Config Class Initialized
INFO - 2021-06-03 06:23:26 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:23:26 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:23:26 --> Utf8 Class Initialized
INFO - 2021-06-03 06:23:26 --> URI Class Initialized
INFO - 2021-06-03 06:23:26 --> Router Class Initialized
INFO - 2021-06-03 06:23:26 --> Output Class Initialized
INFO - 2021-06-03 06:23:26 --> Security Class Initialized
DEBUG - 2021-06-03 06:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:23:26 --> Input Class Initialized
INFO - 2021-06-03 06:23:26 --> Language Class Initialized
INFO - 2021-06-03 06:23:26 --> Language Class Initialized
INFO - 2021-06-03 06:23:26 --> Config Class Initialized
INFO - 2021-06-03 06:23:26 --> Loader Class Initialized
INFO - 2021-06-03 06:23:26 --> Helper loaded: url_helper
INFO - 2021-06-03 06:23:26 --> Helper loaded: file_helper
INFO - 2021-06-03 06:23:26 --> Helper loaded: form_helper
INFO - 2021-06-03 06:23:26 --> Helper loaded: my_helper
INFO - 2021-06-03 06:23:26 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:23:26 --> Controller Class Initialized
DEBUG - 2021-06-03 06:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:23:26 --> Final output sent to browser
DEBUG - 2021-06-03 06:23:26 --> Total execution time: 0.0669
INFO - 2021-06-03 06:23:35 --> Config Class Initialized
INFO - 2021-06-03 06:23:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:23:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:23:35 --> Utf8 Class Initialized
INFO - 2021-06-03 06:23:35 --> URI Class Initialized
INFO - 2021-06-03 06:23:35 --> Router Class Initialized
INFO - 2021-06-03 06:23:35 --> Output Class Initialized
INFO - 2021-06-03 06:23:35 --> Security Class Initialized
DEBUG - 2021-06-03 06:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:23:35 --> Input Class Initialized
INFO - 2021-06-03 06:23:35 --> Language Class Initialized
INFO - 2021-06-03 06:23:35 --> Language Class Initialized
INFO - 2021-06-03 06:23:35 --> Config Class Initialized
INFO - 2021-06-03 06:23:35 --> Loader Class Initialized
INFO - 2021-06-03 06:23:35 --> Helper loaded: url_helper
INFO - 2021-06-03 06:23:35 --> Helper loaded: file_helper
INFO - 2021-06-03 06:23:35 --> Helper loaded: form_helper
INFO - 2021-06-03 06:23:35 --> Helper loaded: my_helper
INFO - 2021-06-03 06:23:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:23:35 --> Controller Class Initialized
DEBUG - 2021-06-03 06:23:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:23:35 --> Final output sent to browser
DEBUG - 2021-06-03 06:23:35 --> Total execution time: 0.0588
INFO - 2021-06-03 06:24:52 --> Config Class Initialized
INFO - 2021-06-03 06:24:52 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:24:52 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:24:52 --> Utf8 Class Initialized
INFO - 2021-06-03 06:24:52 --> URI Class Initialized
INFO - 2021-06-03 06:24:52 --> Router Class Initialized
INFO - 2021-06-03 06:24:52 --> Output Class Initialized
INFO - 2021-06-03 06:24:52 --> Security Class Initialized
DEBUG - 2021-06-03 06:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:24:52 --> Input Class Initialized
INFO - 2021-06-03 06:24:52 --> Language Class Initialized
INFO - 2021-06-03 06:24:52 --> Language Class Initialized
INFO - 2021-06-03 06:24:52 --> Config Class Initialized
INFO - 2021-06-03 06:24:52 --> Loader Class Initialized
INFO - 2021-06-03 06:24:52 --> Helper loaded: url_helper
INFO - 2021-06-03 06:24:52 --> Helper loaded: file_helper
INFO - 2021-06-03 06:24:52 --> Helper loaded: form_helper
INFO - 2021-06-03 06:24:52 --> Helper loaded: my_helper
INFO - 2021-06-03 06:24:52 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:24:52 --> Controller Class Initialized
DEBUG - 2021-06-03 06:24:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:24:52 --> Final output sent to browser
DEBUG - 2021-06-03 06:24:52 --> Total execution time: 0.0742
INFO - 2021-06-03 06:25:25 --> Config Class Initialized
INFO - 2021-06-03 06:25:25 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:25:25 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:25:25 --> Utf8 Class Initialized
INFO - 2021-06-03 06:25:25 --> URI Class Initialized
INFO - 2021-06-03 06:25:25 --> Router Class Initialized
INFO - 2021-06-03 06:25:25 --> Output Class Initialized
INFO - 2021-06-03 06:25:25 --> Security Class Initialized
DEBUG - 2021-06-03 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:25:25 --> Input Class Initialized
INFO - 2021-06-03 06:25:25 --> Language Class Initialized
INFO - 2021-06-03 06:25:25 --> Language Class Initialized
INFO - 2021-06-03 06:25:25 --> Config Class Initialized
INFO - 2021-06-03 06:25:25 --> Loader Class Initialized
INFO - 2021-06-03 06:25:25 --> Helper loaded: url_helper
INFO - 2021-06-03 06:25:25 --> Helper loaded: file_helper
INFO - 2021-06-03 06:25:25 --> Helper loaded: form_helper
INFO - 2021-06-03 06:25:25 --> Helper loaded: my_helper
INFO - 2021-06-03 06:25:25 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:25:25 --> Controller Class Initialized
DEBUG - 2021-06-03 06:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:25:25 --> Final output sent to browser
DEBUG - 2021-06-03 06:25:25 --> Total execution time: 0.0694
INFO - 2021-06-03 06:25:43 --> Config Class Initialized
INFO - 2021-06-03 06:25:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:25:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:25:43 --> Utf8 Class Initialized
INFO - 2021-06-03 06:25:43 --> URI Class Initialized
INFO - 2021-06-03 06:25:43 --> Router Class Initialized
INFO - 2021-06-03 06:25:43 --> Output Class Initialized
INFO - 2021-06-03 06:25:43 --> Security Class Initialized
DEBUG - 2021-06-03 06:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:25:43 --> Input Class Initialized
INFO - 2021-06-03 06:25:43 --> Language Class Initialized
INFO - 2021-06-03 06:25:43 --> Language Class Initialized
INFO - 2021-06-03 06:25:43 --> Config Class Initialized
INFO - 2021-06-03 06:25:43 --> Loader Class Initialized
INFO - 2021-06-03 06:25:43 --> Helper loaded: url_helper
INFO - 2021-06-03 06:25:43 --> Helper loaded: file_helper
INFO - 2021-06-03 06:25:43 --> Helper loaded: form_helper
INFO - 2021-06-03 06:25:43 --> Helper loaded: my_helper
INFO - 2021-06-03 06:25:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:25:43 --> Controller Class Initialized
DEBUG - 2021-06-03 06:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:25:43 --> Final output sent to browser
DEBUG - 2021-06-03 06:25:43 --> Total execution time: 0.0666
INFO - 2021-06-03 06:25:44 --> Config Class Initialized
INFO - 2021-06-03 06:25:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:25:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:25:44 --> Utf8 Class Initialized
INFO - 2021-06-03 06:25:44 --> URI Class Initialized
INFO - 2021-06-03 06:25:44 --> Router Class Initialized
INFO - 2021-06-03 06:25:44 --> Output Class Initialized
INFO - 2021-06-03 06:25:44 --> Security Class Initialized
DEBUG - 2021-06-03 06:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:25:44 --> Input Class Initialized
INFO - 2021-06-03 06:25:44 --> Language Class Initialized
INFO - 2021-06-03 06:25:44 --> Language Class Initialized
INFO - 2021-06-03 06:25:44 --> Config Class Initialized
INFO - 2021-06-03 06:25:44 --> Loader Class Initialized
INFO - 2021-06-03 06:25:44 --> Helper loaded: url_helper
INFO - 2021-06-03 06:25:44 --> Helper loaded: file_helper
INFO - 2021-06-03 06:25:44 --> Helper loaded: form_helper
INFO - 2021-06-03 06:25:44 --> Helper loaded: my_helper
INFO - 2021-06-03 06:25:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:25:44 --> Controller Class Initialized
DEBUG - 2021-06-03 06:25:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:25:44 --> Final output sent to browser
DEBUG - 2021-06-03 06:25:44 --> Total execution time: 0.0692
INFO - 2021-06-03 06:32:14 --> Config Class Initialized
INFO - 2021-06-03 06:32:14 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:32:14 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:32:14 --> Utf8 Class Initialized
INFO - 2021-06-03 06:32:14 --> URI Class Initialized
INFO - 2021-06-03 06:32:14 --> Router Class Initialized
INFO - 2021-06-03 06:32:14 --> Output Class Initialized
INFO - 2021-06-03 06:32:14 --> Security Class Initialized
DEBUG - 2021-06-03 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:32:14 --> Input Class Initialized
INFO - 2021-06-03 06:32:14 --> Language Class Initialized
INFO - 2021-06-03 06:32:14 --> Language Class Initialized
INFO - 2021-06-03 06:32:14 --> Config Class Initialized
INFO - 2021-06-03 06:32:14 --> Loader Class Initialized
INFO - 2021-06-03 06:32:14 --> Helper loaded: url_helper
INFO - 2021-06-03 06:32:14 --> Helper loaded: file_helper
INFO - 2021-06-03 06:32:14 --> Helper loaded: form_helper
INFO - 2021-06-03 06:32:14 --> Helper loaded: my_helper
INFO - 2021-06-03 06:32:14 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:32:14 --> Controller Class Initialized
DEBUG - 2021-06-03 06:32:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:32:14 --> Final output sent to browser
DEBUG - 2021-06-03 06:32:14 --> Total execution time: 0.0815
INFO - 2021-06-03 06:32:22 --> Config Class Initialized
INFO - 2021-06-03 06:32:22 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:32:22 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:32:22 --> Utf8 Class Initialized
INFO - 2021-06-03 06:32:22 --> URI Class Initialized
INFO - 2021-06-03 06:32:22 --> Router Class Initialized
INFO - 2021-06-03 06:32:22 --> Output Class Initialized
INFO - 2021-06-03 06:32:22 --> Security Class Initialized
DEBUG - 2021-06-03 06:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:32:22 --> Input Class Initialized
INFO - 2021-06-03 06:32:22 --> Language Class Initialized
INFO - 2021-06-03 06:32:22 --> Language Class Initialized
INFO - 2021-06-03 06:32:22 --> Config Class Initialized
INFO - 2021-06-03 06:32:22 --> Loader Class Initialized
INFO - 2021-06-03 06:32:22 --> Helper loaded: url_helper
INFO - 2021-06-03 06:32:22 --> Helper loaded: file_helper
INFO - 2021-06-03 06:32:22 --> Helper loaded: form_helper
INFO - 2021-06-03 06:32:22 --> Helper loaded: my_helper
INFO - 2021-06-03 06:32:22 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:32:22 --> Controller Class Initialized
DEBUG - 2021-06-03 06:32:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:32:22 --> Final output sent to browser
DEBUG - 2021-06-03 06:32:22 --> Total execution time: 0.0576
INFO - 2021-06-03 06:32:40 --> Config Class Initialized
INFO - 2021-06-03 06:32:40 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:32:40 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:32:40 --> Utf8 Class Initialized
INFO - 2021-06-03 06:32:40 --> URI Class Initialized
INFO - 2021-06-03 06:32:40 --> Router Class Initialized
INFO - 2021-06-03 06:32:40 --> Output Class Initialized
INFO - 2021-06-03 06:32:40 --> Security Class Initialized
DEBUG - 2021-06-03 06:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:32:40 --> Input Class Initialized
INFO - 2021-06-03 06:32:40 --> Language Class Initialized
INFO - 2021-06-03 06:32:40 --> Language Class Initialized
INFO - 2021-06-03 06:32:40 --> Config Class Initialized
INFO - 2021-06-03 06:32:40 --> Loader Class Initialized
INFO - 2021-06-03 06:32:40 --> Helper loaded: url_helper
INFO - 2021-06-03 06:32:40 --> Helper loaded: file_helper
INFO - 2021-06-03 06:32:40 --> Helper loaded: form_helper
INFO - 2021-06-03 06:32:40 --> Helper loaded: my_helper
INFO - 2021-06-03 06:32:40 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:32:40 --> Controller Class Initialized
INFO - 2021-06-03 06:32:40 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:32:40 --> Config Class Initialized
INFO - 2021-06-03 06:32:40 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:32:40 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:32:40 --> Utf8 Class Initialized
INFO - 2021-06-03 06:32:40 --> URI Class Initialized
INFO - 2021-06-03 06:32:40 --> Router Class Initialized
INFO - 2021-06-03 06:32:40 --> Output Class Initialized
INFO - 2021-06-03 06:32:40 --> Security Class Initialized
DEBUG - 2021-06-03 06:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:32:40 --> Input Class Initialized
INFO - 2021-06-03 06:32:40 --> Language Class Initialized
INFO - 2021-06-03 06:32:40 --> Language Class Initialized
INFO - 2021-06-03 06:32:40 --> Config Class Initialized
INFO - 2021-06-03 06:32:40 --> Loader Class Initialized
INFO - 2021-06-03 06:32:40 --> Helper loaded: url_helper
INFO - 2021-06-03 06:32:40 --> Helper loaded: file_helper
INFO - 2021-06-03 06:32:40 --> Helper loaded: form_helper
INFO - 2021-06-03 06:32:40 --> Helper loaded: my_helper
INFO - 2021-06-03 06:32:40 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:32:40 --> Controller Class Initialized
DEBUG - 2021-06-03 06:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:32:40 --> Final output sent to browser
DEBUG - 2021-06-03 06:32:40 --> Total execution time: 0.0656
INFO - 2021-06-03 06:32:54 --> Config Class Initialized
INFO - 2021-06-03 06:32:54 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:32:54 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:32:54 --> Utf8 Class Initialized
INFO - 2021-06-03 06:32:54 --> URI Class Initialized
INFO - 2021-06-03 06:32:54 --> Router Class Initialized
INFO - 2021-06-03 06:32:54 --> Output Class Initialized
INFO - 2021-06-03 06:32:54 --> Security Class Initialized
DEBUG - 2021-06-03 06:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:32:54 --> Input Class Initialized
INFO - 2021-06-03 06:32:54 --> Language Class Initialized
INFO - 2021-06-03 06:32:54 --> Language Class Initialized
INFO - 2021-06-03 06:32:54 --> Config Class Initialized
INFO - 2021-06-03 06:32:54 --> Loader Class Initialized
INFO - 2021-06-03 06:32:54 --> Helper loaded: url_helper
INFO - 2021-06-03 06:32:54 --> Helper loaded: file_helper
INFO - 2021-06-03 06:32:54 --> Helper loaded: form_helper
INFO - 2021-06-03 06:32:54 --> Helper loaded: my_helper
INFO - 2021-06-03 06:32:54 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:32:54 --> Controller Class Initialized
INFO - 2021-06-03 06:32:54 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:32:54 --> Final output sent to browser
DEBUG - 2021-06-03 06:32:54 --> Total execution time: 0.0776
INFO - 2021-06-03 06:32:56 --> Config Class Initialized
INFO - 2021-06-03 06:32:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:32:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:32:56 --> Utf8 Class Initialized
INFO - 2021-06-03 06:32:56 --> URI Class Initialized
INFO - 2021-06-03 06:32:56 --> Router Class Initialized
INFO - 2021-06-03 06:32:56 --> Output Class Initialized
INFO - 2021-06-03 06:32:56 --> Security Class Initialized
DEBUG - 2021-06-03 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:32:56 --> Input Class Initialized
INFO - 2021-06-03 06:32:56 --> Language Class Initialized
INFO - 2021-06-03 06:32:56 --> Language Class Initialized
INFO - 2021-06-03 06:32:56 --> Config Class Initialized
INFO - 2021-06-03 06:32:56 --> Loader Class Initialized
INFO - 2021-06-03 06:32:56 --> Helper loaded: url_helper
INFO - 2021-06-03 06:32:56 --> Helper loaded: file_helper
INFO - 2021-06-03 06:32:56 --> Helper loaded: form_helper
INFO - 2021-06-03 06:32:56 --> Helper loaded: my_helper
INFO - 2021-06-03 06:32:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:32:56 --> Controller Class Initialized
DEBUG - 2021-06-03 06:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:32:56 --> Final output sent to browser
DEBUG - 2021-06-03 06:32:56 --> Total execution time: 0.0877
INFO - 2021-06-03 06:37:18 --> Config Class Initialized
INFO - 2021-06-03 06:37:18 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:37:18 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:37:18 --> Utf8 Class Initialized
INFO - 2021-06-03 06:37:18 --> URI Class Initialized
INFO - 2021-06-03 06:37:18 --> Router Class Initialized
INFO - 2021-06-03 06:37:18 --> Output Class Initialized
INFO - 2021-06-03 06:37:18 --> Security Class Initialized
DEBUG - 2021-06-03 06:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:37:18 --> Input Class Initialized
INFO - 2021-06-03 06:37:18 --> Language Class Initialized
INFO - 2021-06-03 06:37:18 --> Language Class Initialized
INFO - 2021-06-03 06:37:18 --> Config Class Initialized
INFO - 2021-06-03 06:37:18 --> Loader Class Initialized
INFO - 2021-06-03 06:37:18 --> Helper loaded: url_helper
INFO - 2021-06-03 06:37:18 --> Helper loaded: file_helper
INFO - 2021-06-03 06:37:18 --> Helper loaded: form_helper
INFO - 2021-06-03 06:37:18 --> Helper loaded: my_helper
INFO - 2021-06-03 06:37:18 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:37:18 --> Controller Class Initialized
INFO - 2021-06-03 06:37:18 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:37:18 --> Config Class Initialized
INFO - 2021-06-03 06:37:18 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:37:18 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:37:18 --> Utf8 Class Initialized
INFO - 2021-06-03 06:37:18 --> URI Class Initialized
INFO - 2021-06-03 06:37:18 --> Router Class Initialized
INFO - 2021-06-03 06:37:18 --> Output Class Initialized
INFO - 2021-06-03 06:37:18 --> Security Class Initialized
DEBUG - 2021-06-03 06:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:37:18 --> Input Class Initialized
INFO - 2021-06-03 06:37:18 --> Language Class Initialized
INFO - 2021-06-03 06:37:18 --> Language Class Initialized
INFO - 2021-06-03 06:37:18 --> Config Class Initialized
INFO - 2021-06-03 06:37:18 --> Loader Class Initialized
INFO - 2021-06-03 06:37:18 --> Helper loaded: url_helper
INFO - 2021-06-03 06:37:18 --> Helper loaded: file_helper
INFO - 2021-06-03 06:37:18 --> Helper loaded: form_helper
INFO - 2021-06-03 06:37:18 --> Helper loaded: my_helper
INFO - 2021-06-03 06:37:18 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:37:18 --> Controller Class Initialized
DEBUG - 2021-06-03 06:37:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:37:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:37:18 --> Final output sent to browser
DEBUG - 2021-06-03 06:37:18 --> Total execution time: 0.0731
INFO - 2021-06-03 06:37:42 --> Config Class Initialized
INFO - 2021-06-03 06:37:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:37:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:37:42 --> Utf8 Class Initialized
INFO - 2021-06-03 06:37:42 --> URI Class Initialized
INFO - 2021-06-03 06:37:42 --> Router Class Initialized
INFO - 2021-06-03 06:37:42 --> Output Class Initialized
INFO - 2021-06-03 06:37:42 --> Security Class Initialized
DEBUG - 2021-06-03 06:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:37:42 --> Input Class Initialized
INFO - 2021-06-03 06:37:42 --> Language Class Initialized
INFO - 2021-06-03 06:37:42 --> Language Class Initialized
INFO - 2021-06-03 06:37:42 --> Config Class Initialized
INFO - 2021-06-03 06:37:42 --> Loader Class Initialized
INFO - 2021-06-03 06:37:42 --> Helper loaded: url_helper
INFO - 2021-06-03 06:37:42 --> Helper loaded: file_helper
INFO - 2021-06-03 06:37:42 --> Helper loaded: form_helper
INFO - 2021-06-03 06:37:42 --> Helper loaded: my_helper
INFO - 2021-06-03 06:37:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:37:42 --> Controller Class Initialized
DEBUG - 2021-06-03 06:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:37:42 --> Final output sent to browser
DEBUG - 2021-06-03 06:37:42 --> Total execution time: 0.0467
INFO - 2021-06-03 06:37:49 --> Config Class Initialized
INFO - 2021-06-03 06:37:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:37:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:37:49 --> Utf8 Class Initialized
INFO - 2021-06-03 06:37:49 --> URI Class Initialized
INFO - 2021-06-03 06:37:49 --> Router Class Initialized
INFO - 2021-06-03 06:37:49 --> Output Class Initialized
INFO - 2021-06-03 06:37:49 --> Security Class Initialized
DEBUG - 2021-06-03 06:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:37:49 --> Input Class Initialized
INFO - 2021-06-03 06:37:49 --> Language Class Initialized
INFO - 2021-06-03 06:37:49 --> Language Class Initialized
INFO - 2021-06-03 06:37:49 --> Config Class Initialized
INFO - 2021-06-03 06:37:49 --> Loader Class Initialized
INFO - 2021-06-03 06:37:49 --> Helper loaded: url_helper
INFO - 2021-06-03 06:37:49 --> Helper loaded: file_helper
INFO - 2021-06-03 06:37:49 --> Helper loaded: form_helper
INFO - 2021-06-03 06:37:49 --> Helper loaded: my_helper
INFO - 2021-06-03 06:37:49 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:37:49 --> Controller Class Initialized
INFO - 2021-06-03 06:37:49 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:37:49 --> Final output sent to browser
DEBUG - 2021-06-03 06:37:49 --> Total execution time: 0.0703
INFO - 2021-06-03 06:37:49 --> Config Class Initialized
INFO - 2021-06-03 06:37:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:37:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:37:49 --> Utf8 Class Initialized
INFO - 2021-06-03 06:37:49 --> URI Class Initialized
INFO - 2021-06-03 06:37:49 --> Router Class Initialized
INFO - 2021-06-03 06:37:49 --> Output Class Initialized
INFO - 2021-06-03 06:37:49 --> Security Class Initialized
DEBUG - 2021-06-03 06:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:37:49 --> Input Class Initialized
INFO - 2021-06-03 06:37:49 --> Language Class Initialized
INFO - 2021-06-03 06:37:50 --> Language Class Initialized
INFO - 2021-06-03 06:37:50 --> Config Class Initialized
INFO - 2021-06-03 06:37:50 --> Loader Class Initialized
INFO - 2021-06-03 06:37:50 --> Helper loaded: url_helper
INFO - 2021-06-03 06:37:50 --> Helper loaded: file_helper
INFO - 2021-06-03 06:37:50 --> Helper loaded: form_helper
INFO - 2021-06-03 06:37:50 --> Helper loaded: my_helper
INFO - 2021-06-03 06:37:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:37:50 --> Controller Class Initialized
DEBUG - 2021-06-03 06:37:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:37:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:37:50 --> Final output sent to browser
DEBUG - 2021-06-03 06:37:50 --> Total execution time: 0.0919
INFO - 2021-06-03 06:37:55 --> Config Class Initialized
INFO - 2021-06-03 06:37:55 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:37:55 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:37:55 --> Utf8 Class Initialized
INFO - 2021-06-03 06:37:55 --> URI Class Initialized
INFO - 2021-06-03 06:37:55 --> Router Class Initialized
INFO - 2021-06-03 06:37:55 --> Output Class Initialized
INFO - 2021-06-03 06:37:55 --> Security Class Initialized
DEBUG - 2021-06-03 06:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:37:55 --> Input Class Initialized
INFO - 2021-06-03 06:37:55 --> Language Class Initialized
INFO - 2021-06-03 06:37:55 --> Language Class Initialized
INFO - 2021-06-03 06:37:55 --> Config Class Initialized
INFO - 2021-06-03 06:37:55 --> Loader Class Initialized
INFO - 2021-06-03 06:37:55 --> Helper loaded: url_helper
INFO - 2021-06-03 06:37:55 --> Helper loaded: file_helper
INFO - 2021-06-03 06:37:55 --> Helper loaded: form_helper
INFO - 2021-06-03 06:37:55 --> Helper loaded: my_helper
INFO - 2021-06-03 06:37:55 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:37:55 --> Controller Class Initialized
DEBUG - 2021-06-03 06:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 06:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:37:55 --> Final output sent to browser
DEBUG - 2021-06-03 06:37:55 --> Total execution time: 0.1308
INFO - 2021-06-03 06:37:56 --> Config Class Initialized
INFO - 2021-06-03 06:37:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:37:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:37:56 --> Utf8 Class Initialized
INFO - 2021-06-03 06:37:56 --> URI Class Initialized
INFO - 2021-06-03 06:37:56 --> Router Class Initialized
INFO - 2021-06-03 06:37:56 --> Output Class Initialized
INFO - 2021-06-03 06:37:56 --> Security Class Initialized
DEBUG - 2021-06-03 06:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:37:56 --> Input Class Initialized
INFO - 2021-06-03 06:37:56 --> Language Class Initialized
INFO - 2021-06-03 06:37:56 --> Language Class Initialized
INFO - 2021-06-03 06:37:56 --> Config Class Initialized
INFO - 2021-06-03 06:37:56 --> Loader Class Initialized
INFO - 2021-06-03 06:37:56 --> Helper loaded: url_helper
INFO - 2021-06-03 06:37:56 --> Helper loaded: file_helper
INFO - 2021-06-03 06:37:56 --> Helper loaded: form_helper
INFO - 2021-06-03 06:37:56 --> Helper loaded: my_helper
INFO - 2021-06-03 06:37:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:37:56 --> Controller Class Initialized
DEBUG - 2021-06-03 06:37:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 06:37:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:37:56 --> Final output sent to browser
DEBUG - 2021-06-03 06:37:56 --> Total execution time: 0.0747
INFO - 2021-06-03 06:37:57 --> Config Class Initialized
INFO - 2021-06-03 06:37:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:37:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:37:57 --> Utf8 Class Initialized
INFO - 2021-06-03 06:37:57 --> URI Class Initialized
INFO - 2021-06-03 06:37:57 --> Router Class Initialized
INFO - 2021-06-03 06:37:57 --> Output Class Initialized
INFO - 2021-06-03 06:37:57 --> Security Class Initialized
DEBUG - 2021-06-03 06:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:37:57 --> Input Class Initialized
INFO - 2021-06-03 06:37:57 --> Language Class Initialized
INFO - 2021-06-03 06:37:57 --> Language Class Initialized
INFO - 2021-06-03 06:37:57 --> Config Class Initialized
INFO - 2021-06-03 06:37:57 --> Loader Class Initialized
INFO - 2021-06-03 06:37:57 --> Helper loaded: url_helper
INFO - 2021-06-03 06:37:57 --> Helper loaded: file_helper
INFO - 2021-06-03 06:37:57 --> Helper loaded: form_helper
INFO - 2021-06-03 06:37:57 --> Helper loaded: my_helper
INFO - 2021-06-03 06:37:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:37:57 --> Controller Class Initialized
DEBUG - 2021-06-03 06:37:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 06:37:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:37:57 --> Final output sent to browser
DEBUG - 2021-06-03 06:37:57 --> Total execution time: 0.0548
INFO - 2021-06-03 06:37:59 --> Config Class Initialized
INFO - 2021-06-03 06:37:59 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:37:59 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:37:59 --> Utf8 Class Initialized
INFO - 2021-06-03 06:37:59 --> URI Class Initialized
INFO - 2021-06-03 06:37:59 --> Router Class Initialized
INFO - 2021-06-03 06:37:59 --> Output Class Initialized
INFO - 2021-06-03 06:37:59 --> Security Class Initialized
DEBUG - 2021-06-03 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:37:59 --> Input Class Initialized
INFO - 2021-06-03 06:37:59 --> Language Class Initialized
INFO - 2021-06-03 06:37:59 --> Language Class Initialized
INFO - 2021-06-03 06:37:59 --> Config Class Initialized
INFO - 2021-06-03 06:37:59 --> Loader Class Initialized
INFO - 2021-06-03 06:37:59 --> Helper loaded: url_helper
INFO - 2021-06-03 06:37:59 --> Helper loaded: file_helper
INFO - 2021-06-03 06:37:59 --> Helper loaded: form_helper
INFO - 2021-06-03 06:37:59 --> Helper loaded: my_helper
INFO - 2021-06-03 06:37:59 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:37:59 --> Controller Class Initialized
DEBUG - 2021-06-03 06:37:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 06:37:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:37:59 --> Final output sent to browser
DEBUG - 2021-06-03 06:37:59 --> Total execution time: 0.0856
INFO - 2021-06-03 06:38:00 --> Config Class Initialized
INFO - 2021-06-03 06:38:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:38:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:38:00 --> Utf8 Class Initialized
INFO - 2021-06-03 06:38:00 --> URI Class Initialized
INFO - 2021-06-03 06:38:00 --> Router Class Initialized
INFO - 2021-06-03 06:38:00 --> Output Class Initialized
INFO - 2021-06-03 06:38:00 --> Security Class Initialized
DEBUG - 2021-06-03 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:38:00 --> Input Class Initialized
INFO - 2021-06-03 06:38:00 --> Language Class Initialized
INFO - 2021-06-03 06:38:00 --> Language Class Initialized
INFO - 2021-06-03 06:38:00 --> Config Class Initialized
INFO - 2021-06-03 06:38:00 --> Loader Class Initialized
INFO - 2021-06-03 06:38:00 --> Helper loaded: url_helper
INFO - 2021-06-03 06:38:00 --> Helper loaded: file_helper
INFO - 2021-06-03 06:38:00 --> Helper loaded: form_helper
INFO - 2021-06-03 06:38:00 --> Helper loaded: my_helper
INFO - 2021-06-03 06:38:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:38:00 --> Controller Class Initialized
DEBUG - 2021-06-03 06:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 06:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:38:00 --> Final output sent to browser
DEBUG - 2021-06-03 06:38:00 --> Total execution time: 0.0619
INFO - 2021-06-03 06:38:01 --> Config Class Initialized
INFO - 2021-06-03 06:38:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:38:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:38:01 --> Utf8 Class Initialized
INFO - 2021-06-03 06:38:01 --> URI Class Initialized
INFO - 2021-06-03 06:38:01 --> Router Class Initialized
INFO - 2021-06-03 06:38:01 --> Output Class Initialized
INFO - 2021-06-03 06:38:01 --> Security Class Initialized
DEBUG - 2021-06-03 06:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:38:01 --> Input Class Initialized
INFO - 2021-06-03 06:38:01 --> Language Class Initialized
INFO - 2021-06-03 06:38:01 --> Language Class Initialized
INFO - 2021-06-03 06:38:01 --> Config Class Initialized
INFO - 2021-06-03 06:38:01 --> Loader Class Initialized
INFO - 2021-06-03 06:38:01 --> Helper loaded: url_helper
INFO - 2021-06-03 06:38:01 --> Helper loaded: file_helper
INFO - 2021-06-03 06:38:01 --> Helper loaded: form_helper
INFO - 2021-06-03 06:38:01 --> Helper loaded: my_helper
INFO - 2021-06-03 06:38:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:38:01 --> Controller Class Initialized
DEBUG - 2021-06-03 06:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-06-03 06:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:38:01 --> Final output sent to browser
DEBUG - 2021-06-03 06:38:01 --> Total execution time: 0.1115
INFO - 2021-06-03 06:38:02 --> Config Class Initialized
INFO - 2021-06-03 06:38:02 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:38:02 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:38:02 --> Utf8 Class Initialized
INFO - 2021-06-03 06:38:02 --> URI Class Initialized
INFO - 2021-06-03 06:38:02 --> Router Class Initialized
INFO - 2021-06-03 06:38:02 --> Output Class Initialized
INFO - 2021-06-03 06:38:02 --> Security Class Initialized
DEBUG - 2021-06-03 06:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:38:02 --> Input Class Initialized
INFO - 2021-06-03 06:38:02 --> Language Class Initialized
INFO - 2021-06-03 06:38:02 --> Language Class Initialized
INFO - 2021-06-03 06:38:02 --> Config Class Initialized
INFO - 2021-06-03 06:38:02 --> Loader Class Initialized
INFO - 2021-06-03 06:38:02 --> Helper loaded: url_helper
INFO - 2021-06-03 06:38:02 --> Helper loaded: file_helper
INFO - 2021-06-03 06:38:02 --> Helper loaded: form_helper
INFO - 2021-06-03 06:38:02 --> Helper loaded: my_helper
INFO - 2021-06-03 06:38:02 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:38:02 --> Controller Class Initialized
DEBUG - 2021-06-03 06:38:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:38:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:38:02 --> Final output sent to browser
DEBUG - 2021-06-03 06:38:02 --> Total execution time: 0.0769
INFO - 2021-06-03 06:38:17 --> Config Class Initialized
INFO - 2021-06-03 06:38:17 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:38:17 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:38:17 --> Utf8 Class Initialized
INFO - 2021-06-03 06:38:17 --> URI Class Initialized
INFO - 2021-06-03 06:38:17 --> Router Class Initialized
INFO - 2021-06-03 06:38:17 --> Output Class Initialized
INFO - 2021-06-03 06:38:17 --> Security Class Initialized
DEBUG - 2021-06-03 06:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:38:17 --> Input Class Initialized
INFO - 2021-06-03 06:38:17 --> Language Class Initialized
INFO - 2021-06-03 06:38:17 --> Language Class Initialized
INFO - 2021-06-03 06:38:17 --> Config Class Initialized
INFO - 2021-06-03 06:38:17 --> Loader Class Initialized
INFO - 2021-06-03 06:38:17 --> Helper loaded: url_helper
INFO - 2021-06-03 06:38:17 --> Helper loaded: file_helper
INFO - 2021-06-03 06:38:17 --> Helper loaded: form_helper
INFO - 2021-06-03 06:38:17 --> Helper loaded: my_helper
INFO - 2021-06-03 06:38:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:38:17 --> Controller Class Initialized
DEBUG - 2021-06-03 06:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-06-03 06:38:17 --> Final output sent to browser
DEBUG - 2021-06-03 06:38:17 --> Total execution time: 0.1819
INFO - 2021-06-03 06:39:26 --> Config Class Initialized
INFO - 2021-06-03 06:39:26 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:39:26 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:39:26 --> Utf8 Class Initialized
INFO - 2021-06-03 06:39:26 --> URI Class Initialized
INFO - 2021-06-03 06:39:26 --> Router Class Initialized
INFO - 2021-06-03 06:39:26 --> Output Class Initialized
INFO - 2021-06-03 06:39:26 --> Security Class Initialized
DEBUG - 2021-06-03 06:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:39:26 --> Input Class Initialized
INFO - 2021-06-03 06:39:26 --> Language Class Initialized
INFO - 2021-06-03 06:39:26 --> Language Class Initialized
INFO - 2021-06-03 06:39:26 --> Config Class Initialized
INFO - 2021-06-03 06:39:26 --> Loader Class Initialized
INFO - 2021-06-03 06:39:26 --> Helper loaded: url_helper
INFO - 2021-06-03 06:39:26 --> Helper loaded: file_helper
INFO - 2021-06-03 06:39:26 --> Helper loaded: form_helper
INFO - 2021-06-03 06:39:26 --> Helper loaded: my_helper
INFO - 2021-06-03 06:39:26 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:39:26 --> Controller Class Initialized
DEBUG - 2021-06-03 06:39:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:39:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:39:26 --> Final output sent to browser
DEBUG - 2021-06-03 06:39:26 --> Total execution time: 0.0539
INFO - 2021-06-03 06:40:37 --> Config Class Initialized
INFO - 2021-06-03 06:40:37 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:40:37 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:40:37 --> Utf8 Class Initialized
INFO - 2021-06-03 06:40:37 --> URI Class Initialized
INFO - 2021-06-03 06:40:37 --> Router Class Initialized
INFO - 2021-06-03 06:40:37 --> Output Class Initialized
INFO - 2021-06-03 06:40:37 --> Security Class Initialized
DEBUG - 2021-06-03 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:40:37 --> Input Class Initialized
INFO - 2021-06-03 06:40:37 --> Language Class Initialized
INFO - 2021-06-03 06:40:37 --> Language Class Initialized
INFO - 2021-06-03 06:40:37 --> Config Class Initialized
INFO - 2021-06-03 06:40:37 --> Loader Class Initialized
INFO - 2021-06-03 06:40:37 --> Helper loaded: url_helper
INFO - 2021-06-03 06:40:37 --> Helper loaded: file_helper
INFO - 2021-06-03 06:40:37 --> Helper loaded: form_helper
INFO - 2021-06-03 06:40:37 --> Helper loaded: my_helper
INFO - 2021-06-03 06:40:37 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:40:37 --> Controller Class Initialized
DEBUG - 2021-06-03 06:40:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-06-03 06:40:37 --> Final output sent to browser
DEBUG - 2021-06-03 06:40:37 --> Total execution time: 0.0565
INFO - 2021-06-03 06:41:23 --> Config Class Initialized
INFO - 2021-06-03 06:41:23 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:41:23 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:41:23 --> Utf8 Class Initialized
INFO - 2021-06-03 06:41:23 --> URI Class Initialized
INFO - 2021-06-03 06:41:23 --> Router Class Initialized
INFO - 2021-06-03 06:41:23 --> Output Class Initialized
INFO - 2021-06-03 06:41:23 --> Security Class Initialized
DEBUG - 2021-06-03 06:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:41:23 --> Input Class Initialized
INFO - 2021-06-03 06:41:23 --> Language Class Initialized
INFO - 2021-06-03 06:41:23 --> Language Class Initialized
INFO - 2021-06-03 06:41:23 --> Config Class Initialized
INFO - 2021-06-03 06:41:23 --> Loader Class Initialized
INFO - 2021-06-03 06:41:23 --> Helper loaded: url_helper
INFO - 2021-06-03 06:41:23 --> Helper loaded: file_helper
INFO - 2021-06-03 06:41:23 --> Helper loaded: form_helper
INFO - 2021-06-03 06:41:23 --> Helper loaded: my_helper
INFO - 2021-06-03 06:41:23 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:41:23 --> Controller Class Initialized
DEBUG - 2021-06-03 06:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-06-03 06:41:23 --> Final output sent to browser
DEBUG - 2021-06-03 06:41:23 --> Total execution time: 0.0580
INFO - 2021-06-03 06:42:08 --> Config Class Initialized
INFO - 2021-06-03 06:42:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:42:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:42:08 --> Utf8 Class Initialized
INFO - 2021-06-03 06:42:08 --> URI Class Initialized
INFO - 2021-06-03 06:42:08 --> Router Class Initialized
INFO - 2021-06-03 06:42:08 --> Output Class Initialized
INFO - 2021-06-03 06:42:08 --> Security Class Initialized
DEBUG - 2021-06-03 06:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:42:08 --> Input Class Initialized
INFO - 2021-06-03 06:42:08 --> Language Class Initialized
INFO - 2021-06-03 06:42:08 --> Language Class Initialized
INFO - 2021-06-03 06:42:08 --> Config Class Initialized
INFO - 2021-06-03 06:42:08 --> Loader Class Initialized
INFO - 2021-06-03 06:42:08 --> Helper loaded: url_helper
INFO - 2021-06-03 06:42:08 --> Helper loaded: file_helper
INFO - 2021-06-03 06:42:08 --> Helper loaded: form_helper
INFO - 2021-06-03 06:42:08 --> Helper loaded: my_helper
INFO - 2021-06-03 06:42:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:42:08 --> Controller Class Initialized
DEBUG - 2021-06-03 06:42:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-06-03 06:42:08 --> Final output sent to browser
DEBUG - 2021-06-03 06:42:08 --> Total execution time: 0.0613
INFO - 2021-06-03 06:42:19 --> Config Class Initialized
INFO - 2021-06-03 06:42:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:42:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:42:19 --> Utf8 Class Initialized
INFO - 2021-06-03 06:42:19 --> URI Class Initialized
INFO - 2021-06-03 06:42:19 --> Router Class Initialized
INFO - 2021-06-03 06:42:19 --> Output Class Initialized
INFO - 2021-06-03 06:42:19 --> Security Class Initialized
DEBUG - 2021-06-03 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:42:19 --> Input Class Initialized
INFO - 2021-06-03 06:42:19 --> Language Class Initialized
INFO - 2021-06-03 06:42:19 --> Language Class Initialized
INFO - 2021-06-03 06:42:19 --> Config Class Initialized
INFO - 2021-06-03 06:42:19 --> Loader Class Initialized
INFO - 2021-06-03 06:42:19 --> Helper loaded: url_helper
INFO - 2021-06-03 06:42:19 --> Helper loaded: file_helper
INFO - 2021-06-03 06:42:19 --> Helper loaded: form_helper
INFO - 2021-06-03 06:42:19 --> Helper loaded: my_helper
INFO - 2021-06-03 06:42:19 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:42:19 --> Controller Class Initialized
DEBUG - 2021-06-03 06:42:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-06-03 06:42:19 --> Final output sent to browser
DEBUG - 2021-06-03 06:42:19 --> Total execution time: 0.0766
INFO - 2021-06-03 06:43:44 --> Config Class Initialized
INFO - 2021-06-03 06:43:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:43:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:43:44 --> Utf8 Class Initialized
INFO - 2021-06-03 06:43:44 --> URI Class Initialized
INFO - 2021-06-03 06:43:44 --> Router Class Initialized
INFO - 2021-06-03 06:43:44 --> Output Class Initialized
INFO - 2021-06-03 06:43:44 --> Security Class Initialized
DEBUG - 2021-06-03 06:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:43:44 --> Input Class Initialized
INFO - 2021-06-03 06:43:44 --> Language Class Initialized
INFO - 2021-06-03 06:43:44 --> Language Class Initialized
INFO - 2021-06-03 06:43:44 --> Config Class Initialized
INFO - 2021-06-03 06:43:44 --> Loader Class Initialized
INFO - 2021-06-03 06:43:44 --> Helper loaded: url_helper
INFO - 2021-06-03 06:43:44 --> Helper loaded: file_helper
INFO - 2021-06-03 06:43:44 --> Helper loaded: form_helper
INFO - 2021-06-03 06:43:44 --> Helper loaded: my_helper
INFO - 2021-06-03 06:43:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:43:44 --> Controller Class Initialized
DEBUG - 2021-06-03 06:43:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-06-03 06:43:44 --> Final output sent to browser
DEBUG - 2021-06-03 06:43:44 --> Total execution time: 0.0836
INFO - 2021-06-03 06:44:27 --> Config Class Initialized
INFO - 2021-06-03 06:44:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:44:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:44:27 --> Utf8 Class Initialized
INFO - 2021-06-03 06:44:27 --> URI Class Initialized
INFO - 2021-06-03 06:44:27 --> Router Class Initialized
INFO - 2021-06-03 06:44:27 --> Output Class Initialized
INFO - 2021-06-03 06:44:27 --> Security Class Initialized
DEBUG - 2021-06-03 06:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:44:27 --> Input Class Initialized
INFO - 2021-06-03 06:44:27 --> Language Class Initialized
INFO - 2021-06-03 06:44:27 --> Language Class Initialized
INFO - 2021-06-03 06:44:27 --> Config Class Initialized
INFO - 2021-06-03 06:44:27 --> Loader Class Initialized
INFO - 2021-06-03 06:44:27 --> Helper loaded: url_helper
INFO - 2021-06-03 06:44:27 --> Helper loaded: file_helper
INFO - 2021-06-03 06:44:27 --> Helper loaded: form_helper
INFO - 2021-06-03 06:44:27 --> Helper loaded: my_helper
INFO - 2021-06-03 06:44:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:44:27 --> Controller Class Initialized
INFO - 2021-06-03 06:44:27 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:44:27 --> Config Class Initialized
INFO - 2021-06-03 06:44:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:44:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:44:27 --> Utf8 Class Initialized
INFO - 2021-06-03 06:44:27 --> URI Class Initialized
INFO - 2021-06-03 06:44:27 --> Router Class Initialized
INFO - 2021-06-03 06:44:27 --> Output Class Initialized
INFO - 2021-06-03 06:44:27 --> Security Class Initialized
DEBUG - 2021-06-03 06:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:44:27 --> Input Class Initialized
INFO - 2021-06-03 06:44:27 --> Language Class Initialized
INFO - 2021-06-03 06:44:27 --> Language Class Initialized
INFO - 2021-06-03 06:44:27 --> Config Class Initialized
INFO - 2021-06-03 06:44:27 --> Loader Class Initialized
INFO - 2021-06-03 06:44:27 --> Helper loaded: url_helper
INFO - 2021-06-03 06:44:27 --> Helper loaded: file_helper
INFO - 2021-06-03 06:44:27 --> Helper loaded: form_helper
INFO - 2021-06-03 06:44:27 --> Helper loaded: my_helper
INFO - 2021-06-03 06:44:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:44:27 --> Controller Class Initialized
DEBUG - 2021-06-03 06:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:44:27 --> Final output sent to browser
DEBUG - 2021-06-03 06:44:27 --> Total execution time: 0.0677
INFO - 2021-06-03 06:44:34 --> Config Class Initialized
INFO - 2021-06-03 06:44:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:44:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:44:34 --> Utf8 Class Initialized
INFO - 2021-06-03 06:44:34 --> URI Class Initialized
INFO - 2021-06-03 06:44:34 --> Router Class Initialized
INFO - 2021-06-03 06:44:34 --> Output Class Initialized
INFO - 2021-06-03 06:44:34 --> Security Class Initialized
DEBUG - 2021-06-03 06:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:44:34 --> Input Class Initialized
INFO - 2021-06-03 06:44:34 --> Language Class Initialized
INFO - 2021-06-03 06:44:34 --> Language Class Initialized
INFO - 2021-06-03 06:44:34 --> Config Class Initialized
INFO - 2021-06-03 06:44:34 --> Loader Class Initialized
INFO - 2021-06-03 06:44:34 --> Helper loaded: url_helper
INFO - 2021-06-03 06:44:34 --> Helper loaded: file_helper
INFO - 2021-06-03 06:44:34 --> Helper loaded: form_helper
INFO - 2021-06-03 06:44:34 --> Helper loaded: my_helper
INFO - 2021-06-03 06:44:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:44:34 --> Controller Class Initialized
INFO - 2021-06-03 06:44:34 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:44:34 --> Final output sent to browser
DEBUG - 2021-06-03 06:44:34 --> Total execution time: 0.0984
INFO - 2021-06-03 06:44:34 --> Config Class Initialized
INFO - 2021-06-03 06:44:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:44:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:44:34 --> Utf8 Class Initialized
INFO - 2021-06-03 06:44:34 --> URI Class Initialized
INFO - 2021-06-03 06:44:34 --> Router Class Initialized
INFO - 2021-06-03 06:44:34 --> Output Class Initialized
INFO - 2021-06-03 06:44:34 --> Security Class Initialized
DEBUG - 2021-06-03 06:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:44:34 --> Input Class Initialized
INFO - 2021-06-03 06:44:34 --> Language Class Initialized
INFO - 2021-06-03 06:44:34 --> Language Class Initialized
INFO - 2021-06-03 06:44:34 --> Config Class Initialized
INFO - 2021-06-03 06:44:34 --> Loader Class Initialized
INFO - 2021-06-03 06:44:35 --> Helper loaded: url_helper
INFO - 2021-06-03 06:44:35 --> Helper loaded: file_helper
INFO - 2021-06-03 06:44:35 --> Helper loaded: form_helper
INFO - 2021-06-03 06:44:35 --> Helper loaded: my_helper
INFO - 2021-06-03 06:44:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:44:35 --> Controller Class Initialized
DEBUG - 2021-06-03 06:44:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:44:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:44:35 --> Final output sent to browser
DEBUG - 2021-06-03 06:44:35 --> Total execution time: 0.1206
INFO - 2021-06-03 06:44:36 --> Config Class Initialized
INFO - 2021-06-03 06:44:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:44:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:44:36 --> Utf8 Class Initialized
INFO - 2021-06-03 06:44:36 --> URI Class Initialized
INFO - 2021-06-03 06:44:36 --> Router Class Initialized
INFO - 2021-06-03 06:44:36 --> Output Class Initialized
INFO - 2021-06-03 06:44:36 --> Security Class Initialized
DEBUG - 2021-06-03 06:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:44:36 --> Input Class Initialized
INFO - 2021-06-03 06:44:36 --> Language Class Initialized
INFO - 2021-06-03 06:44:36 --> Language Class Initialized
INFO - 2021-06-03 06:44:36 --> Config Class Initialized
INFO - 2021-06-03 06:44:36 --> Loader Class Initialized
INFO - 2021-06-03 06:44:36 --> Helper loaded: url_helper
INFO - 2021-06-03 06:44:36 --> Helper loaded: file_helper
INFO - 2021-06-03 06:44:36 --> Helper loaded: form_helper
INFO - 2021-06-03 06:44:36 --> Helper loaded: my_helper
INFO - 2021-06-03 06:44:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:44:36 --> Controller Class Initialized
DEBUG - 2021-06-03 06:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:44:36 --> Final output sent to browser
DEBUG - 2021-06-03 06:44:36 --> Total execution time: 0.0888
INFO - 2021-06-03 06:44:38 --> Config Class Initialized
INFO - 2021-06-03 06:44:38 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:44:38 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:44:38 --> Utf8 Class Initialized
INFO - 2021-06-03 06:44:38 --> URI Class Initialized
INFO - 2021-06-03 06:44:38 --> Router Class Initialized
INFO - 2021-06-03 06:44:38 --> Output Class Initialized
INFO - 2021-06-03 06:44:38 --> Security Class Initialized
DEBUG - 2021-06-03 06:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:44:38 --> Input Class Initialized
INFO - 2021-06-03 06:44:38 --> Language Class Initialized
INFO - 2021-06-03 06:44:38 --> Language Class Initialized
INFO - 2021-06-03 06:44:38 --> Config Class Initialized
INFO - 2021-06-03 06:44:38 --> Loader Class Initialized
INFO - 2021-06-03 06:44:38 --> Helper loaded: url_helper
INFO - 2021-06-03 06:44:38 --> Helper loaded: file_helper
INFO - 2021-06-03 06:44:38 --> Helper loaded: form_helper
INFO - 2021-06-03 06:44:38 --> Helper loaded: my_helper
INFO - 2021-06-03 06:44:38 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:44:38 --> Controller Class Initialized
DEBUG - 2021-06-03 06:44:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-06-03 06:44:38 --> Final output sent to browser
DEBUG - 2021-06-03 06:44:38 --> Total execution time: 0.1051
INFO - 2021-06-03 06:45:01 --> Config Class Initialized
INFO - 2021-06-03 06:45:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:01 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:01 --> URI Class Initialized
INFO - 2021-06-03 06:45:01 --> Router Class Initialized
INFO - 2021-06-03 06:45:01 --> Output Class Initialized
INFO - 2021-06-03 06:45:01 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:01 --> Input Class Initialized
INFO - 2021-06-03 06:45:01 --> Language Class Initialized
INFO - 2021-06-03 06:45:01 --> Language Class Initialized
INFO - 2021-06-03 06:45:01 --> Config Class Initialized
INFO - 2021-06-03 06:45:01 --> Loader Class Initialized
INFO - 2021-06-03 06:45:01 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:01 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:01 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:01 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:01 --> Controller Class Initialized
INFO - 2021-06-03 06:45:01 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:45:01 --> Config Class Initialized
INFO - 2021-06-03 06:45:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:01 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:01 --> URI Class Initialized
INFO - 2021-06-03 06:45:01 --> Router Class Initialized
INFO - 2021-06-03 06:45:01 --> Output Class Initialized
INFO - 2021-06-03 06:45:01 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:01 --> Input Class Initialized
INFO - 2021-06-03 06:45:01 --> Language Class Initialized
INFO - 2021-06-03 06:45:01 --> Language Class Initialized
INFO - 2021-06-03 06:45:01 --> Config Class Initialized
INFO - 2021-06-03 06:45:01 --> Loader Class Initialized
INFO - 2021-06-03 06:45:01 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:01 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:01 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:01 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:01 --> Controller Class Initialized
DEBUG - 2021-06-03 06:45:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:45:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:45:01 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:01 --> Total execution time: 0.0655
INFO - 2021-06-03 06:45:08 --> Config Class Initialized
INFO - 2021-06-03 06:45:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:08 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:08 --> URI Class Initialized
INFO - 2021-06-03 06:45:08 --> Router Class Initialized
INFO - 2021-06-03 06:45:08 --> Output Class Initialized
INFO - 2021-06-03 06:45:08 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:08 --> Input Class Initialized
INFO - 2021-06-03 06:45:08 --> Language Class Initialized
INFO - 2021-06-03 06:45:08 --> Language Class Initialized
INFO - 2021-06-03 06:45:08 --> Config Class Initialized
INFO - 2021-06-03 06:45:08 --> Loader Class Initialized
INFO - 2021-06-03 06:45:08 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:08 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:08 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:08 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:08 --> Controller Class Initialized
INFO - 2021-06-03 06:45:08 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:45:08 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:08 --> Total execution time: 0.0797
INFO - 2021-06-03 06:45:09 --> Config Class Initialized
INFO - 2021-06-03 06:45:09 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:09 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:09 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:09 --> URI Class Initialized
INFO - 2021-06-03 06:45:09 --> Router Class Initialized
INFO - 2021-06-03 06:45:09 --> Output Class Initialized
INFO - 2021-06-03 06:45:09 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:09 --> Input Class Initialized
INFO - 2021-06-03 06:45:09 --> Language Class Initialized
INFO - 2021-06-03 06:45:09 --> Language Class Initialized
INFO - 2021-06-03 06:45:09 --> Config Class Initialized
INFO - 2021-06-03 06:45:09 --> Loader Class Initialized
INFO - 2021-06-03 06:45:09 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:09 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:09 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:09 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:09 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:09 --> Controller Class Initialized
DEBUG - 2021-06-03 06:45:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:45:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:45:09 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:09 --> Total execution time: 0.0980
INFO - 2021-06-03 06:45:10 --> Config Class Initialized
INFO - 2021-06-03 06:45:10 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:10 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:10 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:10 --> URI Class Initialized
INFO - 2021-06-03 06:45:10 --> Router Class Initialized
INFO - 2021-06-03 06:45:10 --> Output Class Initialized
INFO - 2021-06-03 06:45:10 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:10 --> Input Class Initialized
INFO - 2021-06-03 06:45:10 --> Language Class Initialized
INFO - 2021-06-03 06:45:10 --> Language Class Initialized
INFO - 2021-06-03 06:45:10 --> Config Class Initialized
INFO - 2021-06-03 06:45:10 --> Loader Class Initialized
INFO - 2021-06-03 06:45:10 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:10 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:10 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:10 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:10 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:10 --> Controller Class Initialized
DEBUG - 2021-06-03 06:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:45:10 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:10 --> Total execution time: 0.0858
INFO - 2021-06-03 06:45:11 --> Config Class Initialized
INFO - 2021-06-03 06:45:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:11 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:11 --> URI Class Initialized
INFO - 2021-06-03 06:45:11 --> Router Class Initialized
INFO - 2021-06-03 06:45:11 --> Output Class Initialized
INFO - 2021-06-03 06:45:11 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:11 --> Input Class Initialized
INFO - 2021-06-03 06:45:11 --> Language Class Initialized
INFO - 2021-06-03 06:45:11 --> Language Class Initialized
INFO - 2021-06-03 06:45:11 --> Config Class Initialized
INFO - 2021-06-03 06:45:11 --> Loader Class Initialized
INFO - 2021-06-03 06:45:11 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:11 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:11 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:11 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:11 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:11 --> Controller Class Initialized
DEBUG - 2021-06-03 06:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-06-03 06:45:11 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:11 --> Total execution time: 0.1059
INFO - 2021-06-03 06:45:29 --> Config Class Initialized
INFO - 2021-06-03 06:45:29 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:29 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:29 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:29 --> URI Class Initialized
INFO - 2021-06-03 06:45:29 --> Router Class Initialized
INFO - 2021-06-03 06:45:29 --> Output Class Initialized
INFO - 2021-06-03 06:45:29 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:29 --> Input Class Initialized
INFO - 2021-06-03 06:45:29 --> Language Class Initialized
INFO - 2021-06-03 06:45:29 --> Language Class Initialized
INFO - 2021-06-03 06:45:29 --> Config Class Initialized
INFO - 2021-06-03 06:45:29 --> Loader Class Initialized
INFO - 2021-06-03 06:45:29 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:29 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:29 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:29 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:29 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:29 --> Controller Class Initialized
INFO - 2021-06-03 06:45:29 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:45:29 --> Config Class Initialized
INFO - 2021-06-03 06:45:29 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:29 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:29 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:29 --> URI Class Initialized
INFO - 2021-06-03 06:45:29 --> Router Class Initialized
INFO - 2021-06-03 06:45:29 --> Output Class Initialized
INFO - 2021-06-03 06:45:29 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:29 --> Input Class Initialized
INFO - 2021-06-03 06:45:29 --> Language Class Initialized
INFO - 2021-06-03 06:45:29 --> Language Class Initialized
INFO - 2021-06-03 06:45:29 --> Config Class Initialized
INFO - 2021-06-03 06:45:29 --> Loader Class Initialized
INFO - 2021-06-03 06:45:29 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:29 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:29 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:29 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:29 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:29 --> Controller Class Initialized
DEBUG - 2021-06-03 06:45:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:45:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:45:29 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:29 --> Total execution time: 0.0728
INFO - 2021-06-03 06:45:46 --> Config Class Initialized
INFO - 2021-06-03 06:45:46 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:46 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:46 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:46 --> URI Class Initialized
INFO - 2021-06-03 06:45:46 --> Router Class Initialized
INFO - 2021-06-03 06:45:46 --> Output Class Initialized
INFO - 2021-06-03 06:45:46 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:46 --> Input Class Initialized
INFO - 2021-06-03 06:45:46 --> Language Class Initialized
INFO - 2021-06-03 06:45:46 --> Language Class Initialized
INFO - 2021-06-03 06:45:46 --> Config Class Initialized
INFO - 2021-06-03 06:45:46 --> Loader Class Initialized
INFO - 2021-06-03 06:45:46 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:46 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:46 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:46 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:46 --> Controller Class Initialized
INFO - 2021-06-03 06:45:46 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:45:46 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:46 --> Total execution time: 0.0805
INFO - 2021-06-03 06:45:47 --> Config Class Initialized
INFO - 2021-06-03 06:45:47 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:47 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:47 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:47 --> URI Class Initialized
INFO - 2021-06-03 06:45:47 --> Router Class Initialized
INFO - 2021-06-03 06:45:47 --> Output Class Initialized
INFO - 2021-06-03 06:45:47 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:47 --> Input Class Initialized
INFO - 2021-06-03 06:45:47 --> Language Class Initialized
INFO - 2021-06-03 06:45:47 --> Language Class Initialized
INFO - 2021-06-03 06:45:47 --> Config Class Initialized
INFO - 2021-06-03 06:45:47 --> Loader Class Initialized
INFO - 2021-06-03 06:45:47 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:47 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:47 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:47 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:47 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:47 --> Controller Class Initialized
DEBUG - 2021-06-03 06:45:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:45:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:45:47 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:47 --> Total execution time: 0.0855
INFO - 2021-06-03 06:45:48 --> Config Class Initialized
INFO - 2021-06-03 06:45:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:48 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:48 --> URI Class Initialized
INFO - 2021-06-03 06:45:48 --> Router Class Initialized
INFO - 2021-06-03 06:45:48 --> Output Class Initialized
INFO - 2021-06-03 06:45:48 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:48 --> Input Class Initialized
INFO - 2021-06-03 06:45:48 --> Language Class Initialized
INFO - 2021-06-03 06:45:49 --> Language Class Initialized
INFO - 2021-06-03 06:45:49 --> Config Class Initialized
INFO - 2021-06-03 06:45:49 --> Loader Class Initialized
INFO - 2021-06-03 06:45:49 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:49 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:49 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:49 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:49 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:49 --> Controller Class Initialized
DEBUG - 2021-06-03 06:45:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:45:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:45:49 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:49 --> Total execution time: 0.0739
INFO - 2021-06-03 06:45:50 --> Config Class Initialized
INFO - 2021-06-03 06:45:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:45:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:45:50 --> Utf8 Class Initialized
INFO - 2021-06-03 06:45:50 --> URI Class Initialized
INFO - 2021-06-03 06:45:50 --> Router Class Initialized
INFO - 2021-06-03 06:45:50 --> Output Class Initialized
INFO - 2021-06-03 06:45:50 --> Security Class Initialized
DEBUG - 2021-06-03 06:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:45:50 --> Input Class Initialized
INFO - 2021-06-03 06:45:50 --> Language Class Initialized
INFO - 2021-06-03 06:45:50 --> Language Class Initialized
INFO - 2021-06-03 06:45:50 --> Config Class Initialized
INFO - 2021-06-03 06:45:50 --> Loader Class Initialized
INFO - 2021-06-03 06:45:50 --> Helper loaded: url_helper
INFO - 2021-06-03 06:45:50 --> Helper loaded: file_helper
INFO - 2021-06-03 06:45:50 --> Helper loaded: form_helper
INFO - 2021-06-03 06:45:50 --> Helper loaded: my_helper
INFO - 2021-06-03 06:45:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:45:50 --> Controller Class Initialized
DEBUG - 2021-06-03 06:45:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-03 06:45:50 --> Final output sent to browser
DEBUG - 2021-06-03 06:45:50 --> Total execution time: 0.1029
INFO - 2021-06-03 06:46:12 --> Config Class Initialized
INFO - 2021-06-03 06:46:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:46:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:46:12 --> Utf8 Class Initialized
INFO - 2021-06-03 06:46:12 --> URI Class Initialized
INFO - 2021-06-03 06:46:12 --> Router Class Initialized
INFO - 2021-06-03 06:46:12 --> Output Class Initialized
INFO - 2021-06-03 06:46:12 --> Security Class Initialized
DEBUG - 2021-06-03 06:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:46:12 --> Input Class Initialized
INFO - 2021-06-03 06:46:12 --> Language Class Initialized
INFO - 2021-06-03 06:46:12 --> Language Class Initialized
INFO - 2021-06-03 06:46:12 --> Config Class Initialized
INFO - 2021-06-03 06:46:12 --> Loader Class Initialized
INFO - 2021-06-03 06:46:12 --> Helper loaded: url_helper
INFO - 2021-06-03 06:46:12 --> Helper loaded: file_helper
INFO - 2021-06-03 06:46:12 --> Helper loaded: form_helper
INFO - 2021-06-03 06:46:12 --> Helper loaded: my_helper
INFO - 2021-06-03 06:46:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:46:12 --> Controller Class Initialized
INFO - 2021-06-03 06:46:12 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:46:12 --> Config Class Initialized
INFO - 2021-06-03 06:46:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:46:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:46:12 --> Utf8 Class Initialized
INFO - 2021-06-03 06:46:12 --> URI Class Initialized
INFO - 2021-06-03 06:46:12 --> Router Class Initialized
INFO - 2021-06-03 06:46:12 --> Output Class Initialized
INFO - 2021-06-03 06:46:12 --> Security Class Initialized
DEBUG - 2021-06-03 06:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:46:12 --> Input Class Initialized
INFO - 2021-06-03 06:46:12 --> Language Class Initialized
INFO - 2021-06-03 06:46:12 --> Language Class Initialized
INFO - 2021-06-03 06:46:12 --> Config Class Initialized
INFO - 2021-06-03 06:46:12 --> Loader Class Initialized
INFO - 2021-06-03 06:46:12 --> Helper loaded: url_helper
INFO - 2021-06-03 06:46:12 --> Helper loaded: file_helper
INFO - 2021-06-03 06:46:12 --> Helper loaded: form_helper
INFO - 2021-06-03 06:46:12 --> Helper loaded: my_helper
INFO - 2021-06-03 06:46:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:46:12 --> Controller Class Initialized
DEBUG - 2021-06-03 06:46:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:46:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:46:12 --> Final output sent to browser
DEBUG - 2021-06-03 06:46:12 --> Total execution time: 0.0693
INFO - 2021-06-03 06:47:05 --> Config Class Initialized
INFO - 2021-06-03 06:47:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:47:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:47:05 --> Utf8 Class Initialized
INFO - 2021-06-03 06:47:05 --> URI Class Initialized
INFO - 2021-06-03 06:47:05 --> Router Class Initialized
INFO - 2021-06-03 06:47:05 --> Output Class Initialized
INFO - 2021-06-03 06:47:05 --> Security Class Initialized
DEBUG - 2021-06-03 06:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:47:05 --> Input Class Initialized
INFO - 2021-06-03 06:47:05 --> Language Class Initialized
INFO - 2021-06-03 06:47:05 --> Language Class Initialized
INFO - 2021-06-03 06:47:05 --> Config Class Initialized
INFO - 2021-06-03 06:47:05 --> Loader Class Initialized
INFO - 2021-06-03 06:47:05 --> Helper loaded: url_helper
INFO - 2021-06-03 06:47:05 --> Helper loaded: file_helper
INFO - 2021-06-03 06:47:05 --> Helper loaded: form_helper
INFO - 2021-06-03 06:47:05 --> Helper loaded: my_helper
INFO - 2021-06-03 06:47:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:47:05 --> Controller Class Initialized
INFO - 2021-06-03 06:47:05 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:47:05 --> Final output sent to browser
DEBUG - 2021-06-03 06:47:05 --> Total execution time: 0.0632
INFO - 2021-06-03 06:47:06 --> Config Class Initialized
INFO - 2021-06-03 06:47:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:47:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:47:06 --> Utf8 Class Initialized
INFO - 2021-06-03 06:47:06 --> URI Class Initialized
INFO - 2021-06-03 06:47:06 --> Router Class Initialized
INFO - 2021-06-03 06:47:06 --> Output Class Initialized
INFO - 2021-06-03 06:47:06 --> Security Class Initialized
DEBUG - 2021-06-03 06:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:47:06 --> Input Class Initialized
INFO - 2021-06-03 06:47:06 --> Language Class Initialized
INFO - 2021-06-03 06:47:06 --> Language Class Initialized
INFO - 2021-06-03 06:47:06 --> Config Class Initialized
INFO - 2021-06-03 06:47:06 --> Loader Class Initialized
INFO - 2021-06-03 06:47:06 --> Helper loaded: url_helper
INFO - 2021-06-03 06:47:06 --> Helper loaded: file_helper
INFO - 2021-06-03 06:47:06 --> Helper loaded: form_helper
INFO - 2021-06-03 06:47:06 --> Helper loaded: my_helper
INFO - 2021-06-03 06:47:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:47:06 --> Controller Class Initialized
DEBUG - 2021-06-03 06:47:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:47:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:47:06 --> Final output sent to browser
DEBUG - 2021-06-03 06:47:06 --> Total execution time: 0.0984
INFO - 2021-06-03 06:47:08 --> Config Class Initialized
INFO - 2021-06-03 06:47:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:47:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:47:08 --> Utf8 Class Initialized
INFO - 2021-06-03 06:47:08 --> URI Class Initialized
INFO - 2021-06-03 06:47:08 --> Router Class Initialized
INFO - 2021-06-03 06:47:08 --> Output Class Initialized
INFO - 2021-06-03 06:47:08 --> Security Class Initialized
DEBUG - 2021-06-03 06:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:47:08 --> Input Class Initialized
INFO - 2021-06-03 06:47:08 --> Language Class Initialized
INFO - 2021-06-03 06:47:08 --> Language Class Initialized
INFO - 2021-06-03 06:47:08 --> Config Class Initialized
INFO - 2021-06-03 06:47:08 --> Loader Class Initialized
INFO - 2021-06-03 06:47:08 --> Helper loaded: url_helper
INFO - 2021-06-03 06:47:08 --> Helper loaded: file_helper
INFO - 2021-06-03 06:47:08 --> Helper loaded: form_helper
INFO - 2021-06-03 06:47:08 --> Helper loaded: my_helper
INFO - 2021-06-03 06:47:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:47:08 --> Controller Class Initialized
DEBUG - 2021-06-03 06:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 06:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:47:08 --> Final output sent to browser
DEBUG - 2021-06-03 06:47:08 --> Total execution time: 0.1377
INFO - 2021-06-03 06:47:09 --> Config Class Initialized
INFO - 2021-06-03 06:47:09 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:47:09 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:47:09 --> Utf8 Class Initialized
INFO - 2021-06-03 06:47:09 --> URI Class Initialized
INFO - 2021-06-03 06:47:09 --> Router Class Initialized
INFO - 2021-06-03 06:47:09 --> Output Class Initialized
INFO - 2021-06-03 06:47:09 --> Security Class Initialized
DEBUG - 2021-06-03 06:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:47:09 --> Input Class Initialized
INFO - 2021-06-03 06:47:09 --> Language Class Initialized
INFO - 2021-06-03 06:47:09 --> Language Class Initialized
INFO - 2021-06-03 06:47:09 --> Config Class Initialized
INFO - 2021-06-03 06:47:09 --> Loader Class Initialized
INFO - 2021-06-03 06:47:09 --> Helper loaded: url_helper
INFO - 2021-06-03 06:47:09 --> Helper loaded: file_helper
INFO - 2021-06-03 06:47:09 --> Helper loaded: form_helper
INFO - 2021-06-03 06:47:09 --> Helper loaded: my_helper
INFO - 2021-06-03 06:47:09 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:47:09 --> Controller Class Initialized
DEBUG - 2021-06-03 06:47:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 06:47:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:47:09 --> Final output sent to browser
DEBUG - 2021-06-03 06:47:09 --> Total execution time: 0.0788
INFO - 2021-06-03 06:47:10 --> Config Class Initialized
INFO - 2021-06-03 06:47:10 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:47:10 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:47:10 --> Utf8 Class Initialized
INFO - 2021-06-03 06:47:10 --> URI Class Initialized
INFO - 2021-06-03 06:47:10 --> Router Class Initialized
INFO - 2021-06-03 06:47:10 --> Output Class Initialized
INFO - 2021-06-03 06:47:10 --> Security Class Initialized
DEBUG - 2021-06-03 06:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:47:10 --> Input Class Initialized
INFO - 2021-06-03 06:47:10 --> Language Class Initialized
INFO - 2021-06-03 06:47:10 --> Language Class Initialized
INFO - 2021-06-03 06:47:10 --> Config Class Initialized
INFO - 2021-06-03 06:47:10 --> Loader Class Initialized
INFO - 2021-06-03 06:47:10 --> Helper loaded: url_helper
INFO - 2021-06-03 06:47:10 --> Helper loaded: file_helper
INFO - 2021-06-03 06:47:10 --> Helper loaded: form_helper
INFO - 2021-06-03 06:47:10 --> Helper loaded: my_helper
INFO - 2021-06-03 06:47:10 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:47:10 --> Controller Class Initialized
DEBUG - 2021-06-03 06:47:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 06:47:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:47:10 --> Final output sent to browser
DEBUG - 2021-06-03 06:47:10 --> Total execution time: 0.0780
INFO - 2021-06-03 06:47:11 --> Config Class Initialized
INFO - 2021-06-03 06:47:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:47:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:47:11 --> Utf8 Class Initialized
INFO - 2021-06-03 06:47:11 --> URI Class Initialized
INFO - 2021-06-03 06:47:11 --> Router Class Initialized
INFO - 2021-06-03 06:47:11 --> Output Class Initialized
INFO - 2021-06-03 06:47:11 --> Security Class Initialized
DEBUG - 2021-06-03 06:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:47:11 --> Input Class Initialized
INFO - 2021-06-03 06:47:11 --> Language Class Initialized
INFO - 2021-06-03 06:47:11 --> Language Class Initialized
INFO - 2021-06-03 06:47:11 --> Config Class Initialized
INFO - 2021-06-03 06:47:11 --> Loader Class Initialized
INFO - 2021-06-03 06:47:11 --> Helper loaded: url_helper
INFO - 2021-06-03 06:47:11 --> Helper loaded: file_helper
INFO - 2021-06-03 06:47:11 --> Helper loaded: form_helper
INFO - 2021-06-03 06:47:11 --> Helper loaded: my_helper
INFO - 2021-06-03 06:47:11 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:47:11 --> Controller Class Initialized
DEBUG - 2021-06-03 06:47:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 06:47:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:47:11 --> Final output sent to browser
DEBUG - 2021-06-03 06:47:11 --> Total execution time: 0.0936
INFO - 2021-06-03 06:47:12 --> Config Class Initialized
INFO - 2021-06-03 06:47:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:47:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:47:12 --> Utf8 Class Initialized
INFO - 2021-06-03 06:47:12 --> URI Class Initialized
INFO - 2021-06-03 06:47:12 --> Router Class Initialized
INFO - 2021-06-03 06:47:12 --> Output Class Initialized
INFO - 2021-06-03 06:47:12 --> Security Class Initialized
DEBUG - 2021-06-03 06:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:47:12 --> Input Class Initialized
INFO - 2021-06-03 06:47:12 --> Language Class Initialized
INFO - 2021-06-03 06:47:12 --> Language Class Initialized
INFO - 2021-06-03 06:47:12 --> Config Class Initialized
INFO - 2021-06-03 06:47:12 --> Loader Class Initialized
INFO - 2021-06-03 06:47:12 --> Helper loaded: url_helper
INFO - 2021-06-03 06:47:12 --> Helper loaded: file_helper
INFO - 2021-06-03 06:47:12 --> Helper loaded: form_helper
INFO - 2021-06-03 06:47:12 --> Helper loaded: my_helper
INFO - 2021-06-03 06:47:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:47:12 --> Controller Class Initialized
DEBUG - 2021-06-03 06:47:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 06:47:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:47:12 --> Final output sent to browser
DEBUG - 2021-06-03 06:47:12 --> Total execution time: 0.0929
INFO - 2021-06-03 06:47:13 --> Config Class Initialized
INFO - 2021-06-03 06:47:13 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:47:13 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:47:13 --> Utf8 Class Initialized
INFO - 2021-06-03 06:47:13 --> URI Class Initialized
INFO - 2021-06-03 06:47:13 --> Router Class Initialized
INFO - 2021-06-03 06:47:13 --> Output Class Initialized
INFO - 2021-06-03 06:47:13 --> Security Class Initialized
DEBUG - 2021-06-03 06:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:47:13 --> Input Class Initialized
INFO - 2021-06-03 06:47:13 --> Language Class Initialized
INFO - 2021-06-03 06:47:13 --> Language Class Initialized
INFO - 2021-06-03 06:47:13 --> Config Class Initialized
INFO - 2021-06-03 06:47:13 --> Loader Class Initialized
INFO - 2021-06-03 06:47:13 --> Helper loaded: url_helper
INFO - 2021-06-03 06:47:13 --> Helper loaded: file_helper
INFO - 2021-06-03 06:47:13 --> Helper loaded: form_helper
INFO - 2021-06-03 06:47:13 --> Helper loaded: my_helper
INFO - 2021-06-03 06:47:13 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:47:13 --> Controller Class Initialized
DEBUG - 2021-06-03 06:47:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:47:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:47:13 --> Final output sent to browser
DEBUG - 2021-06-03 06:47:13 --> Total execution time: 0.0953
INFO - 2021-06-03 06:47:15 --> Config Class Initialized
INFO - 2021-06-03 06:47:15 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:47:15 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:47:15 --> Utf8 Class Initialized
INFO - 2021-06-03 06:47:15 --> URI Class Initialized
INFO - 2021-06-03 06:47:15 --> Router Class Initialized
INFO - 2021-06-03 06:47:15 --> Output Class Initialized
INFO - 2021-06-03 06:47:15 --> Security Class Initialized
DEBUG - 2021-06-03 06:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:47:15 --> Input Class Initialized
INFO - 2021-06-03 06:47:15 --> Language Class Initialized
INFO - 2021-06-03 06:47:15 --> Language Class Initialized
INFO - 2021-06-03 06:47:15 --> Config Class Initialized
INFO - 2021-06-03 06:47:15 --> Loader Class Initialized
INFO - 2021-06-03 06:47:15 --> Helper loaded: url_helper
INFO - 2021-06-03 06:47:15 --> Helper loaded: file_helper
INFO - 2021-06-03 06:47:15 --> Helper loaded: form_helper
INFO - 2021-06-03 06:47:15 --> Helper loaded: my_helper
INFO - 2021-06-03 06:47:15 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:47:15 --> Controller Class Initialized
DEBUG - 2021-06-03 06:47:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-06-03 06:47:15 --> Final output sent to browser
DEBUG - 2021-06-03 06:47:15 --> Total execution time: 0.0852
INFO - 2021-06-03 06:48:11 --> Config Class Initialized
INFO - 2021-06-03 06:48:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:48:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:48:11 --> Utf8 Class Initialized
INFO - 2021-06-03 06:48:11 --> URI Class Initialized
INFO - 2021-06-03 06:48:11 --> Router Class Initialized
INFO - 2021-06-03 06:48:11 --> Output Class Initialized
INFO - 2021-06-03 06:48:11 --> Security Class Initialized
DEBUG - 2021-06-03 06:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:48:11 --> Input Class Initialized
INFO - 2021-06-03 06:48:11 --> Language Class Initialized
INFO - 2021-06-03 06:48:11 --> Language Class Initialized
INFO - 2021-06-03 06:48:11 --> Config Class Initialized
INFO - 2021-06-03 06:48:11 --> Loader Class Initialized
INFO - 2021-06-03 06:48:11 --> Helper loaded: url_helper
INFO - 2021-06-03 06:48:11 --> Helper loaded: file_helper
INFO - 2021-06-03 06:48:11 --> Helper loaded: form_helper
INFO - 2021-06-03 06:48:11 --> Helper loaded: my_helper
INFO - 2021-06-03 06:48:11 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:48:11 --> Controller Class Initialized
DEBUG - 2021-06-03 06:48:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-06-03 06:48:11 --> Final output sent to browser
DEBUG - 2021-06-03 06:48:11 --> Total execution time: 0.0663
INFO - 2021-06-03 06:48:46 --> Config Class Initialized
INFO - 2021-06-03 06:48:46 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:48:46 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:48:46 --> Utf8 Class Initialized
INFO - 2021-06-03 06:48:46 --> URI Class Initialized
INFO - 2021-06-03 06:48:46 --> Router Class Initialized
INFO - 2021-06-03 06:48:46 --> Output Class Initialized
INFO - 2021-06-03 06:48:46 --> Security Class Initialized
DEBUG - 2021-06-03 06:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:48:46 --> Input Class Initialized
INFO - 2021-06-03 06:48:46 --> Language Class Initialized
INFO - 2021-06-03 06:48:46 --> Language Class Initialized
INFO - 2021-06-03 06:48:46 --> Config Class Initialized
INFO - 2021-06-03 06:48:46 --> Loader Class Initialized
INFO - 2021-06-03 06:48:46 --> Helper loaded: url_helper
INFO - 2021-06-03 06:48:46 --> Helper loaded: file_helper
INFO - 2021-06-03 06:48:46 --> Helper loaded: form_helper
INFO - 2021-06-03 06:48:46 --> Helper loaded: my_helper
INFO - 2021-06-03 06:48:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:48:46 --> Controller Class Initialized
DEBUG - 2021-06-03 06:48:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-06-03 06:48:46 --> Final output sent to browser
DEBUG - 2021-06-03 06:48:46 --> Total execution time: 0.0817
INFO - 2021-06-03 06:49:12 --> Config Class Initialized
INFO - 2021-06-03 06:49:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:49:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:49:12 --> Utf8 Class Initialized
INFO - 2021-06-03 06:49:12 --> URI Class Initialized
INFO - 2021-06-03 06:49:12 --> Router Class Initialized
INFO - 2021-06-03 06:49:12 --> Output Class Initialized
INFO - 2021-06-03 06:49:12 --> Security Class Initialized
DEBUG - 2021-06-03 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:49:12 --> Input Class Initialized
INFO - 2021-06-03 06:49:12 --> Language Class Initialized
INFO - 2021-06-03 06:49:12 --> Language Class Initialized
INFO - 2021-06-03 06:49:12 --> Config Class Initialized
INFO - 2021-06-03 06:49:12 --> Loader Class Initialized
INFO - 2021-06-03 06:49:12 --> Helper loaded: url_helper
INFO - 2021-06-03 06:49:12 --> Helper loaded: file_helper
INFO - 2021-06-03 06:49:12 --> Helper loaded: form_helper
INFO - 2021-06-03 06:49:12 --> Helper loaded: my_helper
INFO - 2021-06-03 06:49:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:49:12 --> Controller Class Initialized
DEBUG - 2021-06-03 06:49:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-06-03 06:49:12 --> Final output sent to browser
DEBUG - 2021-06-03 06:49:12 --> Total execution time: 0.0623
INFO - 2021-06-03 06:49:42 --> Config Class Initialized
INFO - 2021-06-03 06:49:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:49:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:49:42 --> Utf8 Class Initialized
INFO - 2021-06-03 06:49:42 --> URI Class Initialized
INFO - 2021-06-03 06:49:42 --> Router Class Initialized
INFO - 2021-06-03 06:49:43 --> Output Class Initialized
INFO - 2021-06-03 06:49:43 --> Security Class Initialized
DEBUG - 2021-06-03 06:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:49:43 --> Input Class Initialized
INFO - 2021-06-03 06:49:43 --> Language Class Initialized
INFO - 2021-06-03 06:49:43 --> Language Class Initialized
INFO - 2021-06-03 06:49:43 --> Config Class Initialized
INFO - 2021-06-03 06:49:43 --> Loader Class Initialized
INFO - 2021-06-03 06:49:43 --> Helper loaded: url_helper
INFO - 2021-06-03 06:49:43 --> Helper loaded: file_helper
INFO - 2021-06-03 06:49:43 --> Helper loaded: form_helper
INFO - 2021-06-03 06:49:43 --> Helper loaded: my_helper
INFO - 2021-06-03 06:49:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:49:43 --> Controller Class Initialized
INFO - 2021-06-03 06:49:43 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:49:43 --> Config Class Initialized
INFO - 2021-06-03 06:49:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:49:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:49:43 --> Utf8 Class Initialized
INFO - 2021-06-03 06:49:43 --> URI Class Initialized
INFO - 2021-06-03 06:49:43 --> Router Class Initialized
INFO - 2021-06-03 06:49:43 --> Output Class Initialized
INFO - 2021-06-03 06:49:43 --> Security Class Initialized
DEBUG - 2021-06-03 06:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:49:43 --> Input Class Initialized
INFO - 2021-06-03 06:49:43 --> Language Class Initialized
INFO - 2021-06-03 06:49:43 --> Language Class Initialized
INFO - 2021-06-03 06:49:43 --> Config Class Initialized
INFO - 2021-06-03 06:49:43 --> Loader Class Initialized
INFO - 2021-06-03 06:49:43 --> Helper loaded: url_helper
INFO - 2021-06-03 06:49:43 --> Helper loaded: file_helper
INFO - 2021-06-03 06:49:43 --> Helper loaded: form_helper
INFO - 2021-06-03 06:49:43 --> Helper loaded: my_helper
INFO - 2021-06-03 06:49:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:49:43 --> Controller Class Initialized
DEBUG - 2021-06-03 06:49:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:49:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:49:43 --> Final output sent to browser
DEBUG - 2021-06-03 06:49:43 --> Total execution time: 0.0701
INFO - 2021-06-03 06:49:55 --> Config Class Initialized
INFO - 2021-06-03 06:49:55 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:49:55 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:49:55 --> Utf8 Class Initialized
INFO - 2021-06-03 06:49:55 --> URI Class Initialized
INFO - 2021-06-03 06:49:55 --> Router Class Initialized
INFO - 2021-06-03 06:49:55 --> Output Class Initialized
INFO - 2021-06-03 06:49:55 --> Security Class Initialized
DEBUG - 2021-06-03 06:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:49:55 --> Input Class Initialized
INFO - 2021-06-03 06:49:55 --> Language Class Initialized
INFO - 2021-06-03 06:49:55 --> Language Class Initialized
INFO - 2021-06-03 06:49:55 --> Config Class Initialized
INFO - 2021-06-03 06:49:55 --> Loader Class Initialized
INFO - 2021-06-03 06:49:55 --> Helper loaded: url_helper
INFO - 2021-06-03 06:49:55 --> Helper loaded: file_helper
INFO - 2021-06-03 06:49:55 --> Helper loaded: form_helper
INFO - 2021-06-03 06:49:55 --> Helper loaded: my_helper
INFO - 2021-06-03 06:49:55 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:49:55 --> Controller Class Initialized
INFO - 2021-06-03 06:49:55 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:49:55 --> Final output sent to browser
DEBUG - 2021-06-03 06:49:55 --> Total execution time: 0.0701
INFO - 2021-06-03 06:49:56 --> Config Class Initialized
INFO - 2021-06-03 06:49:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:49:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:49:56 --> Utf8 Class Initialized
INFO - 2021-06-03 06:49:56 --> URI Class Initialized
INFO - 2021-06-03 06:49:56 --> Router Class Initialized
INFO - 2021-06-03 06:49:56 --> Output Class Initialized
INFO - 2021-06-03 06:49:56 --> Security Class Initialized
DEBUG - 2021-06-03 06:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:49:56 --> Input Class Initialized
INFO - 2021-06-03 06:49:56 --> Language Class Initialized
INFO - 2021-06-03 06:49:56 --> Language Class Initialized
INFO - 2021-06-03 06:49:56 --> Config Class Initialized
INFO - 2021-06-03 06:49:56 --> Loader Class Initialized
INFO - 2021-06-03 06:49:56 --> Helper loaded: url_helper
INFO - 2021-06-03 06:49:56 --> Helper loaded: file_helper
INFO - 2021-06-03 06:49:56 --> Helper loaded: form_helper
INFO - 2021-06-03 06:49:56 --> Helper loaded: my_helper
INFO - 2021-06-03 06:49:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:49:56 --> Controller Class Initialized
DEBUG - 2021-06-03 06:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:49:56 --> Final output sent to browser
DEBUG - 2021-06-03 06:49:56 --> Total execution time: 0.0975
INFO - 2021-06-03 06:49:57 --> Config Class Initialized
INFO - 2021-06-03 06:49:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:49:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:49:57 --> Utf8 Class Initialized
INFO - 2021-06-03 06:49:57 --> URI Class Initialized
INFO - 2021-06-03 06:49:57 --> Router Class Initialized
INFO - 2021-06-03 06:49:57 --> Output Class Initialized
INFO - 2021-06-03 06:49:57 --> Security Class Initialized
DEBUG - 2021-06-03 06:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:49:57 --> Input Class Initialized
INFO - 2021-06-03 06:49:57 --> Language Class Initialized
INFO - 2021-06-03 06:49:57 --> Language Class Initialized
INFO - 2021-06-03 06:49:57 --> Config Class Initialized
INFO - 2021-06-03 06:49:57 --> Loader Class Initialized
INFO - 2021-06-03 06:49:57 --> Helper loaded: url_helper
INFO - 2021-06-03 06:49:57 --> Helper loaded: file_helper
INFO - 2021-06-03 06:49:57 --> Helper loaded: form_helper
INFO - 2021-06-03 06:49:57 --> Helper loaded: my_helper
INFO - 2021-06-03 06:49:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:49:57 --> Controller Class Initialized
DEBUG - 2021-06-03 06:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-03 06:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:49:57 --> Final output sent to browser
DEBUG - 2021-06-03 06:49:57 --> Total execution time: 0.0967
INFO - 2021-06-03 06:49:58 --> Config Class Initialized
INFO - 2021-06-03 06:49:58 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:49:58 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:49:58 --> Utf8 Class Initialized
INFO - 2021-06-03 06:49:58 --> URI Class Initialized
INFO - 2021-06-03 06:49:58 --> Router Class Initialized
INFO - 2021-06-03 06:49:58 --> Output Class Initialized
INFO - 2021-06-03 06:49:58 --> Security Class Initialized
DEBUG - 2021-06-03 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:49:58 --> Input Class Initialized
INFO - 2021-06-03 06:49:58 --> Language Class Initialized
INFO - 2021-06-03 06:49:58 --> Language Class Initialized
INFO - 2021-06-03 06:49:58 --> Config Class Initialized
INFO - 2021-06-03 06:49:58 --> Loader Class Initialized
INFO - 2021-06-03 06:49:58 --> Helper loaded: url_helper
INFO - 2021-06-03 06:49:58 --> Helper loaded: file_helper
INFO - 2021-06-03 06:49:58 --> Helper loaded: form_helper
INFO - 2021-06-03 06:49:58 --> Helper loaded: my_helper
INFO - 2021-06-03 06:49:58 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:49:58 --> Controller Class Initialized
DEBUG - 2021-06-03 06:49:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 06:49:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:49:58 --> Final output sent to browser
DEBUG - 2021-06-03 06:49:58 --> Total execution time: 0.0986
INFO - 2021-06-03 06:49:59 --> Config Class Initialized
INFO - 2021-06-03 06:49:59 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:49:59 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:49:59 --> Utf8 Class Initialized
INFO - 2021-06-03 06:49:59 --> URI Class Initialized
INFO - 2021-06-03 06:49:59 --> Router Class Initialized
INFO - 2021-06-03 06:49:59 --> Output Class Initialized
INFO - 2021-06-03 06:49:59 --> Security Class Initialized
DEBUG - 2021-06-03 06:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:49:59 --> Input Class Initialized
INFO - 2021-06-03 06:49:59 --> Language Class Initialized
INFO - 2021-06-03 06:49:59 --> Language Class Initialized
INFO - 2021-06-03 06:49:59 --> Config Class Initialized
INFO - 2021-06-03 06:49:59 --> Loader Class Initialized
INFO - 2021-06-03 06:49:59 --> Helper loaded: url_helper
INFO - 2021-06-03 06:49:59 --> Helper loaded: file_helper
INFO - 2021-06-03 06:49:59 --> Helper loaded: form_helper
INFO - 2021-06-03 06:49:59 --> Helper loaded: my_helper
INFO - 2021-06-03 06:49:59 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:49:59 --> Controller Class Initialized
DEBUG - 2021-06-03 06:49:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 06:49:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:49:59 --> Final output sent to browser
DEBUG - 2021-06-03 06:49:59 --> Total execution time: 0.1081
INFO - 2021-06-03 06:50:00 --> Config Class Initialized
INFO - 2021-06-03 06:50:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:50:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:50:00 --> Utf8 Class Initialized
INFO - 2021-06-03 06:50:00 --> URI Class Initialized
INFO - 2021-06-03 06:50:00 --> Router Class Initialized
INFO - 2021-06-03 06:50:00 --> Output Class Initialized
INFO - 2021-06-03 06:50:00 --> Security Class Initialized
DEBUG - 2021-06-03 06:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:50:00 --> Input Class Initialized
INFO - 2021-06-03 06:50:00 --> Language Class Initialized
INFO - 2021-06-03 06:50:00 --> Language Class Initialized
INFO - 2021-06-03 06:50:00 --> Config Class Initialized
INFO - 2021-06-03 06:50:00 --> Loader Class Initialized
INFO - 2021-06-03 06:50:00 --> Helper loaded: url_helper
INFO - 2021-06-03 06:50:00 --> Helper loaded: file_helper
INFO - 2021-06-03 06:50:00 --> Helper loaded: form_helper
INFO - 2021-06-03 06:50:00 --> Helper loaded: my_helper
INFO - 2021-06-03 06:50:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:50:00 --> Controller Class Initialized
DEBUG - 2021-06-03 06:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 06:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:50:00 --> Final output sent to browser
DEBUG - 2021-06-03 06:50:00 --> Total execution time: 0.0593
INFO - 2021-06-03 06:50:01 --> Config Class Initialized
INFO - 2021-06-03 06:50:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:50:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:50:01 --> Utf8 Class Initialized
INFO - 2021-06-03 06:50:01 --> URI Class Initialized
INFO - 2021-06-03 06:50:01 --> Router Class Initialized
INFO - 2021-06-03 06:50:01 --> Output Class Initialized
INFO - 2021-06-03 06:50:01 --> Security Class Initialized
DEBUG - 2021-06-03 06:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:50:01 --> Input Class Initialized
INFO - 2021-06-03 06:50:01 --> Language Class Initialized
INFO - 2021-06-03 06:50:01 --> Language Class Initialized
INFO - 2021-06-03 06:50:01 --> Config Class Initialized
INFO - 2021-06-03 06:50:01 --> Loader Class Initialized
INFO - 2021-06-03 06:50:01 --> Helper loaded: url_helper
INFO - 2021-06-03 06:50:01 --> Helper loaded: file_helper
INFO - 2021-06-03 06:50:01 --> Helper loaded: form_helper
INFO - 2021-06-03 06:50:01 --> Helper loaded: my_helper
INFO - 2021-06-03 06:50:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:50:01 --> Controller Class Initialized
DEBUG - 2021-06-03 06:50:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 06:50:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:50:01 --> Final output sent to browser
DEBUG - 2021-06-03 06:50:01 --> Total execution time: 0.0822
INFO - 2021-06-03 06:50:02 --> Config Class Initialized
INFO - 2021-06-03 06:50:02 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:50:02 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:50:02 --> Utf8 Class Initialized
INFO - 2021-06-03 06:50:02 --> URI Class Initialized
INFO - 2021-06-03 06:50:02 --> Router Class Initialized
INFO - 2021-06-03 06:50:02 --> Output Class Initialized
INFO - 2021-06-03 06:50:02 --> Security Class Initialized
DEBUG - 2021-06-03 06:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:50:02 --> Input Class Initialized
INFO - 2021-06-03 06:50:02 --> Language Class Initialized
INFO - 2021-06-03 06:50:02 --> Language Class Initialized
INFO - 2021-06-03 06:50:02 --> Config Class Initialized
INFO - 2021-06-03 06:50:02 --> Loader Class Initialized
INFO - 2021-06-03 06:50:02 --> Helper loaded: url_helper
INFO - 2021-06-03 06:50:02 --> Helper loaded: file_helper
INFO - 2021-06-03 06:50:02 --> Helper loaded: form_helper
INFO - 2021-06-03 06:50:02 --> Helper loaded: my_helper
INFO - 2021-06-03 06:50:02 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:50:02 --> Controller Class Initialized
DEBUG - 2021-06-03 06:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 06:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:50:02 --> Final output sent to browser
DEBUG - 2021-06-03 06:50:02 --> Total execution time: 0.0772
INFO - 2021-06-03 06:50:03 --> Config Class Initialized
INFO - 2021-06-03 06:50:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:50:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:50:03 --> Utf8 Class Initialized
INFO - 2021-06-03 06:50:03 --> URI Class Initialized
INFO - 2021-06-03 06:50:03 --> Router Class Initialized
INFO - 2021-06-03 06:50:03 --> Output Class Initialized
INFO - 2021-06-03 06:50:03 --> Security Class Initialized
DEBUG - 2021-06-03 06:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:50:03 --> Input Class Initialized
INFO - 2021-06-03 06:50:03 --> Language Class Initialized
INFO - 2021-06-03 06:50:03 --> Language Class Initialized
INFO - 2021-06-03 06:50:03 --> Config Class Initialized
INFO - 2021-06-03 06:50:03 --> Loader Class Initialized
INFO - 2021-06-03 06:50:03 --> Helper loaded: url_helper
INFO - 2021-06-03 06:50:03 --> Helper loaded: file_helper
INFO - 2021-06-03 06:50:03 --> Helper loaded: form_helper
INFO - 2021-06-03 06:50:03 --> Helper loaded: my_helper
INFO - 2021-06-03 06:50:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:50:03 --> Controller Class Initialized
DEBUG - 2021-06-03 06:50:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 06:50:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:50:03 --> Final output sent to browser
DEBUG - 2021-06-03 06:50:03 --> Total execution time: 0.0903
INFO - 2021-06-03 06:50:04 --> Config Class Initialized
INFO - 2021-06-03 06:50:04 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:50:04 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:50:04 --> Utf8 Class Initialized
INFO - 2021-06-03 06:50:04 --> URI Class Initialized
INFO - 2021-06-03 06:50:04 --> Router Class Initialized
INFO - 2021-06-03 06:50:04 --> Output Class Initialized
INFO - 2021-06-03 06:50:04 --> Security Class Initialized
DEBUG - 2021-06-03 06:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:50:04 --> Input Class Initialized
INFO - 2021-06-03 06:50:04 --> Language Class Initialized
INFO - 2021-06-03 06:50:04 --> Language Class Initialized
INFO - 2021-06-03 06:50:04 --> Config Class Initialized
INFO - 2021-06-03 06:50:04 --> Loader Class Initialized
INFO - 2021-06-03 06:50:04 --> Helper loaded: url_helper
INFO - 2021-06-03 06:50:04 --> Helper loaded: file_helper
INFO - 2021-06-03 06:50:04 --> Helper loaded: form_helper
INFO - 2021-06-03 06:50:04 --> Helper loaded: my_helper
INFO - 2021-06-03 06:50:04 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:50:04 --> Controller Class Initialized
INFO - 2021-06-03 06:50:04 --> Final output sent to browser
DEBUG - 2021-06-03 06:50:04 --> Total execution time: 0.0636
INFO - 2021-06-03 06:50:06 --> Config Class Initialized
INFO - 2021-06-03 06:50:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:50:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:50:06 --> Utf8 Class Initialized
INFO - 2021-06-03 06:50:06 --> URI Class Initialized
INFO - 2021-06-03 06:50:06 --> Router Class Initialized
INFO - 2021-06-03 06:50:06 --> Output Class Initialized
INFO - 2021-06-03 06:50:06 --> Security Class Initialized
DEBUG - 2021-06-03 06:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:50:06 --> Input Class Initialized
INFO - 2021-06-03 06:50:06 --> Language Class Initialized
INFO - 2021-06-03 06:50:06 --> Language Class Initialized
INFO - 2021-06-03 06:50:06 --> Config Class Initialized
INFO - 2021-06-03 06:50:06 --> Loader Class Initialized
INFO - 2021-06-03 06:50:06 --> Helper loaded: url_helper
INFO - 2021-06-03 06:50:06 --> Helper loaded: file_helper
INFO - 2021-06-03 06:50:06 --> Helper loaded: form_helper
INFO - 2021-06-03 06:50:06 --> Helper loaded: my_helper
INFO - 2021-06-03 06:50:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:50:06 --> Controller Class Initialized
DEBUG - 2021-06-03 06:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 06:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:50:06 --> Final output sent to browser
DEBUG - 2021-06-03 06:50:06 --> Total execution time: 0.0674
INFO - 2021-06-03 06:50:07 --> Config Class Initialized
INFO - 2021-06-03 06:50:07 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:50:07 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:50:07 --> Utf8 Class Initialized
INFO - 2021-06-03 06:50:07 --> URI Class Initialized
INFO - 2021-06-03 06:50:07 --> Router Class Initialized
INFO - 2021-06-03 06:50:07 --> Output Class Initialized
INFO - 2021-06-03 06:50:07 --> Security Class Initialized
DEBUG - 2021-06-03 06:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:50:07 --> Input Class Initialized
INFO - 2021-06-03 06:50:07 --> Language Class Initialized
INFO - 2021-06-03 06:50:07 --> Language Class Initialized
INFO - 2021-06-03 06:50:07 --> Config Class Initialized
INFO - 2021-06-03 06:50:07 --> Loader Class Initialized
INFO - 2021-06-03 06:50:07 --> Helper loaded: url_helper
INFO - 2021-06-03 06:50:07 --> Helper loaded: file_helper
INFO - 2021-06-03 06:50:07 --> Helper loaded: form_helper
INFO - 2021-06-03 06:50:07 --> Helper loaded: my_helper
INFO - 2021-06-03 06:50:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:50:07 --> Controller Class Initialized
DEBUG - 2021-06-03 06:50:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 06:50:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:50:07 --> Final output sent to browser
DEBUG - 2021-06-03 06:50:07 --> Total execution time: 0.0632
INFO - 2021-06-03 06:50:08 --> Config Class Initialized
INFO - 2021-06-03 06:50:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:50:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:50:08 --> Utf8 Class Initialized
INFO - 2021-06-03 06:50:08 --> URI Class Initialized
INFO - 2021-06-03 06:50:08 --> Router Class Initialized
INFO - 2021-06-03 06:50:08 --> Output Class Initialized
INFO - 2021-06-03 06:50:08 --> Security Class Initialized
DEBUG - 2021-06-03 06:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:50:08 --> Input Class Initialized
INFO - 2021-06-03 06:50:08 --> Language Class Initialized
INFO - 2021-06-03 06:50:08 --> Language Class Initialized
INFO - 2021-06-03 06:50:08 --> Config Class Initialized
INFO - 2021-06-03 06:50:08 --> Loader Class Initialized
INFO - 2021-06-03 06:50:08 --> Helper loaded: url_helper
INFO - 2021-06-03 06:50:08 --> Helper loaded: file_helper
INFO - 2021-06-03 06:50:08 --> Helper loaded: form_helper
INFO - 2021-06-03 06:50:08 --> Helper loaded: my_helper
INFO - 2021-06-03 06:50:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:50:08 --> Controller Class Initialized
DEBUG - 2021-06-03 06:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:50:08 --> Final output sent to browser
DEBUG - 2021-06-03 06:50:08 --> Total execution time: 0.0879
INFO - 2021-06-03 06:50:12 --> Config Class Initialized
INFO - 2021-06-03 06:50:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:50:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:50:12 --> Utf8 Class Initialized
INFO - 2021-06-03 06:50:12 --> URI Class Initialized
INFO - 2021-06-03 06:50:12 --> Router Class Initialized
INFO - 2021-06-03 06:50:12 --> Output Class Initialized
INFO - 2021-06-03 06:50:12 --> Security Class Initialized
DEBUG - 2021-06-03 06:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:50:12 --> Input Class Initialized
INFO - 2021-06-03 06:50:12 --> Language Class Initialized
INFO - 2021-06-03 06:50:12 --> Language Class Initialized
INFO - 2021-06-03 06:50:12 --> Config Class Initialized
INFO - 2021-06-03 06:50:12 --> Loader Class Initialized
INFO - 2021-06-03 06:50:12 --> Helper loaded: url_helper
INFO - 2021-06-03 06:50:12 --> Helper loaded: file_helper
INFO - 2021-06-03 06:50:12 --> Helper loaded: form_helper
INFO - 2021-06-03 06:50:12 --> Helper loaded: my_helper
INFO - 2021-06-03 06:50:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:50:12 --> Controller Class Initialized
DEBUG - 2021-06-03 06:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-06-03 06:50:12 --> Final output sent to browser
DEBUG - 2021-06-03 06:50:12 --> Total execution time: 0.1972
INFO - 2021-06-03 06:51:24 --> Config Class Initialized
INFO - 2021-06-03 06:51:24 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:51:24 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:51:24 --> Utf8 Class Initialized
INFO - 2021-06-03 06:51:24 --> URI Class Initialized
INFO - 2021-06-03 06:51:24 --> Router Class Initialized
INFO - 2021-06-03 06:51:24 --> Output Class Initialized
INFO - 2021-06-03 06:51:24 --> Security Class Initialized
DEBUG - 2021-06-03 06:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:51:24 --> Input Class Initialized
INFO - 2021-06-03 06:51:24 --> Language Class Initialized
INFO - 2021-06-03 06:51:24 --> Language Class Initialized
INFO - 2021-06-03 06:51:24 --> Config Class Initialized
INFO - 2021-06-03 06:51:24 --> Loader Class Initialized
INFO - 2021-06-03 06:51:24 --> Helper loaded: url_helper
INFO - 2021-06-03 06:51:24 --> Helper loaded: file_helper
INFO - 2021-06-03 06:51:24 --> Helper loaded: form_helper
INFO - 2021-06-03 06:51:24 --> Helper loaded: my_helper
INFO - 2021-06-03 06:51:24 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:51:24 --> Controller Class Initialized
DEBUG - 2021-06-03 06:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-06-03 06:51:24 --> Final output sent to browser
DEBUG - 2021-06-03 06:51:24 --> Total execution time: 0.0565
INFO - 2021-06-03 06:51:50 --> Config Class Initialized
INFO - 2021-06-03 06:51:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:51:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:51:50 --> Utf8 Class Initialized
INFO - 2021-06-03 06:51:50 --> URI Class Initialized
INFO - 2021-06-03 06:51:50 --> Router Class Initialized
INFO - 2021-06-03 06:51:50 --> Output Class Initialized
INFO - 2021-06-03 06:51:50 --> Security Class Initialized
DEBUG - 2021-06-03 06:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:51:50 --> Input Class Initialized
INFO - 2021-06-03 06:51:50 --> Language Class Initialized
INFO - 2021-06-03 06:51:50 --> Language Class Initialized
INFO - 2021-06-03 06:51:50 --> Config Class Initialized
INFO - 2021-06-03 06:51:50 --> Loader Class Initialized
INFO - 2021-06-03 06:51:50 --> Helper loaded: url_helper
INFO - 2021-06-03 06:51:50 --> Helper loaded: file_helper
INFO - 2021-06-03 06:51:50 --> Helper loaded: form_helper
INFO - 2021-06-03 06:51:50 --> Helper loaded: my_helper
INFO - 2021-06-03 06:51:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:51:50 --> Controller Class Initialized
DEBUG - 2021-06-03 06:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-06-03 06:51:50 --> Final output sent to browser
DEBUG - 2021-06-03 06:51:50 --> Total execution time: 0.0594
INFO - 2021-06-03 06:52:34 --> Config Class Initialized
INFO - 2021-06-03 06:52:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:34 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:34 --> URI Class Initialized
INFO - 2021-06-03 06:52:34 --> Router Class Initialized
INFO - 2021-06-03 06:52:34 --> Output Class Initialized
INFO - 2021-06-03 06:52:34 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:34 --> Input Class Initialized
INFO - 2021-06-03 06:52:34 --> Language Class Initialized
INFO - 2021-06-03 06:52:34 --> Language Class Initialized
INFO - 2021-06-03 06:52:34 --> Config Class Initialized
INFO - 2021-06-03 06:52:34 --> Loader Class Initialized
INFO - 2021-06-03 06:52:34 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:34 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:34 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:34 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:34 --> Controller Class Initialized
INFO - 2021-06-03 06:52:34 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:52:34 --> Config Class Initialized
INFO - 2021-06-03 06:52:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:34 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:34 --> URI Class Initialized
INFO - 2021-06-03 06:52:34 --> Router Class Initialized
INFO - 2021-06-03 06:52:34 --> Output Class Initialized
INFO - 2021-06-03 06:52:34 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:34 --> Input Class Initialized
INFO - 2021-06-03 06:52:34 --> Language Class Initialized
INFO - 2021-06-03 06:52:34 --> Language Class Initialized
INFO - 2021-06-03 06:52:34 --> Config Class Initialized
INFO - 2021-06-03 06:52:34 --> Loader Class Initialized
INFO - 2021-06-03 06:52:34 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:34 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:34 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:34 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:34 --> Controller Class Initialized
DEBUG - 2021-06-03 06:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:52:34 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:34 --> Total execution time: 0.0461
INFO - 2021-06-03 06:52:46 --> Config Class Initialized
INFO - 2021-06-03 06:52:46 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:46 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:46 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:46 --> URI Class Initialized
INFO - 2021-06-03 06:52:46 --> Router Class Initialized
INFO - 2021-06-03 06:52:46 --> Output Class Initialized
INFO - 2021-06-03 06:52:46 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:46 --> Input Class Initialized
INFO - 2021-06-03 06:52:46 --> Language Class Initialized
INFO - 2021-06-03 06:52:46 --> Language Class Initialized
INFO - 2021-06-03 06:52:46 --> Config Class Initialized
INFO - 2021-06-03 06:52:46 --> Loader Class Initialized
INFO - 2021-06-03 06:52:46 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:46 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:46 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:46 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:46 --> Controller Class Initialized
INFO - 2021-06-03 06:52:46 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:52:46 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:46 --> Total execution time: 0.0750
INFO - 2021-06-03 06:52:46 --> Config Class Initialized
INFO - 2021-06-03 06:52:46 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:46 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:46 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:46 --> URI Class Initialized
INFO - 2021-06-03 06:52:46 --> Router Class Initialized
INFO - 2021-06-03 06:52:46 --> Output Class Initialized
INFO - 2021-06-03 06:52:46 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:46 --> Input Class Initialized
INFO - 2021-06-03 06:52:46 --> Language Class Initialized
INFO - 2021-06-03 06:52:46 --> Language Class Initialized
INFO - 2021-06-03 06:52:46 --> Config Class Initialized
INFO - 2021-06-03 06:52:46 --> Loader Class Initialized
INFO - 2021-06-03 06:52:46 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:46 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:46 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:46 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:46 --> Controller Class Initialized
DEBUG - 2021-06-03 06:52:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:52:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:52:46 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:46 --> Total execution time: 0.0748
INFO - 2021-06-03 06:52:48 --> Config Class Initialized
INFO - 2021-06-03 06:52:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:48 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:48 --> URI Class Initialized
INFO - 2021-06-03 06:52:48 --> Router Class Initialized
INFO - 2021-06-03 06:52:48 --> Output Class Initialized
INFO - 2021-06-03 06:52:48 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:48 --> Input Class Initialized
INFO - 2021-06-03 06:52:48 --> Language Class Initialized
INFO - 2021-06-03 06:52:48 --> Language Class Initialized
INFO - 2021-06-03 06:52:48 --> Config Class Initialized
INFO - 2021-06-03 06:52:48 --> Loader Class Initialized
INFO - 2021-06-03 06:52:48 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:48 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:48 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:48 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:48 --> Controller Class Initialized
DEBUG - 2021-06-03 06:52:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 06:52:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:52:49 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:49 --> Total execution time: 0.0961
INFO - 2021-06-03 06:52:50 --> Config Class Initialized
INFO - 2021-06-03 06:52:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:50 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:50 --> URI Class Initialized
INFO - 2021-06-03 06:52:50 --> Router Class Initialized
INFO - 2021-06-03 06:52:50 --> Output Class Initialized
INFO - 2021-06-03 06:52:50 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:50 --> Input Class Initialized
INFO - 2021-06-03 06:52:50 --> Language Class Initialized
INFO - 2021-06-03 06:52:50 --> Language Class Initialized
INFO - 2021-06-03 06:52:50 --> Config Class Initialized
INFO - 2021-06-03 06:52:50 --> Loader Class Initialized
INFO - 2021-06-03 06:52:50 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:50 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:50 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:50 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:50 --> Controller Class Initialized
DEBUG - 2021-06-03 06:52:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 06:52:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:52:50 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:50 --> Total execution time: 0.0736
INFO - 2021-06-03 06:52:51 --> Config Class Initialized
INFO - 2021-06-03 06:52:51 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:51 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:51 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:51 --> URI Class Initialized
INFO - 2021-06-03 06:52:51 --> Router Class Initialized
INFO - 2021-06-03 06:52:51 --> Output Class Initialized
INFO - 2021-06-03 06:52:51 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:51 --> Input Class Initialized
INFO - 2021-06-03 06:52:51 --> Language Class Initialized
INFO - 2021-06-03 06:52:51 --> Language Class Initialized
INFO - 2021-06-03 06:52:51 --> Config Class Initialized
INFO - 2021-06-03 06:52:51 --> Loader Class Initialized
INFO - 2021-06-03 06:52:51 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:51 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:51 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:51 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:51 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:51 --> Controller Class Initialized
DEBUG - 2021-06-03 06:52:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 06:52:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:52:51 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:51 --> Total execution time: 0.0681
INFO - 2021-06-03 06:52:52 --> Config Class Initialized
INFO - 2021-06-03 06:52:52 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:52 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:52 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:52 --> URI Class Initialized
INFO - 2021-06-03 06:52:52 --> Router Class Initialized
INFO - 2021-06-03 06:52:52 --> Output Class Initialized
INFO - 2021-06-03 06:52:52 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:52 --> Input Class Initialized
INFO - 2021-06-03 06:52:52 --> Language Class Initialized
INFO - 2021-06-03 06:52:52 --> Language Class Initialized
INFO - 2021-06-03 06:52:52 --> Config Class Initialized
INFO - 2021-06-03 06:52:52 --> Loader Class Initialized
INFO - 2021-06-03 06:52:52 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:52 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:52 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:52 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:52 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:52 --> Controller Class Initialized
DEBUG - 2021-06-03 06:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 06:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:52:52 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:52 --> Total execution time: 0.0795
INFO - 2021-06-03 06:52:53 --> Config Class Initialized
INFO - 2021-06-03 06:52:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:53 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:53 --> URI Class Initialized
INFO - 2021-06-03 06:52:53 --> Router Class Initialized
INFO - 2021-06-03 06:52:53 --> Output Class Initialized
INFO - 2021-06-03 06:52:53 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:53 --> Input Class Initialized
INFO - 2021-06-03 06:52:53 --> Language Class Initialized
INFO - 2021-06-03 06:52:53 --> Language Class Initialized
INFO - 2021-06-03 06:52:53 --> Config Class Initialized
INFO - 2021-06-03 06:52:53 --> Loader Class Initialized
INFO - 2021-06-03 06:52:53 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:53 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:53 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:53 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:53 --> Controller Class Initialized
DEBUG - 2021-06-03 06:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 06:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:52:53 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:53 --> Total execution time: 0.0808
INFO - 2021-06-03 06:52:54 --> Config Class Initialized
INFO - 2021-06-03 06:52:54 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:54 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:54 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:54 --> URI Class Initialized
INFO - 2021-06-03 06:52:54 --> Router Class Initialized
INFO - 2021-06-03 06:52:54 --> Output Class Initialized
INFO - 2021-06-03 06:52:54 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:54 --> Input Class Initialized
INFO - 2021-06-03 06:52:54 --> Language Class Initialized
INFO - 2021-06-03 06:52:54 --> Language Class Initialized
INFO - 2021-06-03 06:52:54 --> Config Class Initialized
INFO - 2021-06-03 06:52:54 --> Loader Class Initialized
INFO - 2021-06-03 06:52:54 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:54 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:54 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:54 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:54 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:54 --> Controller Class Initialized
DEBUG - 2021-06-03 06:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:52:54 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:54 --> Total execution time: 0.0716
INFO - 2021-06-03 06:52:56 --> Config Class Initialized
INFO - 2021-06-03 06:52:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:52:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:52:56 --> Utf8 Class Initialized
INFO - 2021-06-03 06:52:56 --> URI Class Initialized
INFO - 2021-06-03 06:52:56 --> Router Class Initialized
INFO - 2021-06-03 06:52:56 --> Output Class Initialized
INFO - 2021-06-03 06:52:56 --> Security Class Initialized
DEBUG - 2021-06-03 06:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:52:56 --> Input Class Initialized
INFO - 2021-06-03 06:52:56 --> Language Class Initialized
INFO - 2021-06-03 06:52:56 --> Language Class Initialized
INFO - 2021-06-03 06:52:56 --> Config Class Initialized
INFO - 2021-06-03 06:52:56 --> Loader Class Initialized
INFO - 2021-06-03 06:52:56 --> Helper loaded: url_helper
INFO - 2021-06-03 06:52:56 --> Helper loaded: file_helper
INFO - 2021-06-03 06:52:56 --> Helper loaded: form_helper
INFO - 2021-06-03 06:52:56 --> Helper loaded: my_helper
INFO - 2021-06-03 06:52:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:52:56 --> Controller Class Initialized
DEBUG - 2021-06-03 06:52:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-06-03 06:52:56 --> Final output sent to browser
DEBUG - 2021-06-03 06:52:56 --> Total execution time: 0.1937
INFO - 2021-06-03 06:55:00 --> Config Class Initialized
INFO - 2021-06-03 06:55:00 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:55:00 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:55:00 --> Utf8 Class Initialized
INFO - 2021-06-03 06:55:00 --> URI Class Initialized
INFO - 2021-06-03 06:55:00 --> Router Class Initialized
INFO - 2021-06-03 06:55:00 --> Output Class Initialized
INFO - 2021-06-03 06:55:00 --> Security Class Initialized
DEBUG - 2021-06-03 06:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:55:00 --> Input Class Initialized
INFO - 2021-06-03 06:55:00 --> Language Class Initialized
INFO - 2021-06-03 06:55:00 --> Language Class Initialized
INFO - 2021-06-03 06:55:00 --> Config Class Initialized
INFO - 2021-06-03 06:55:00 --> Loader Class Initialized
INFO - 2021-06-03 06:55:00 --> Helper loaded: url_helper
INFO - 2021-06-03 06:55:00 --> Helper loaded: file_helper
INFO - 2021-06-03 06:55:00 --> Helper loaded: form_helper
INFO - 2021-06-03 06:55:00 --> Helper loaded: my_helper
INFO - 2021-06-03 06:55:00 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:55:00 --> Controller Class Initialized
DEBUG - 2021-06-03 06:55:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-06-03 06:55:00 --> Final output sent to browser
DEBUG - 2021-06-03 06:55:00 --> Total execution time: 0.0621
INFO - 2021-06-03 06:55:35 --> Config Class Initialized
INFO - 2021-06-03 06:55:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:55:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:55:35 --> Utf8 Class Initialized
INFO - 2021-06-03 06:55:35 --> URI Class Initialized
INFO - 2021-06-03 06:55:35 --> Router Class Initialized
INFO - 2021-06-03 06:55:35 --> Output Class Initialized
INFO - 2021-06-03 06:55:35 --> Security Class Initialized
DEBUG - 2021-06-03 06:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:55:35 --> Input Class Initialized
INFO - 2021-06-03 06:55:35 --> Language Class Initialized
INFO - 2021-06-03 06:55:35 --> Language Class Initialized
INFO - 2021-06-03 06:55:35 --> Config Class Initialized
INFO - 2021-06-03 06:55:35 --> Loader Class Initialized
INFO - 2021-06-03 06:55:35 --> Helper loaded: url_helper
INFO - 2021-06-03 06:55:35 --> Helper loaded: file_helper
INFO - 2021-06-03 06:55:35 --> Helper loaded: form_helper
INFO - 2021-06-03 06:55:35 --> Helper loaded: my_helper
INFO - 2021-06-03 06:55:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:55:35 --> Controller Class Initialized
DEBUG - 2021-06-03 06:55:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-06-03 06:55:35 --> Final output sent to browser
DEBUG - 2021-06-03 06:55:35 --> Total execution time: 0.0573
INFO - 2021-06-03 06:56:07 --> Config Class Initialized
INFO - 2021-06-03 06:56:07 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:56:07 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:56:07 --> Utf8 Class Initialized
INFO - 2021-06-03 06:56:07 --> URI Class Initialized
INFO - 2021-06-03 06:56:07 --> Router Class Initialized
INFO - 2021-06-03 06:56:07 --> Output Class Initialized
INFO - 2021-06-03 06:56:07 --> Security Class Initialized
DEBUG - 2021-06-03 06:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:56:07 --> Input Class Initialized
INFO - 2021-06-03 06:56:07 --> Language Class Initialized
INFO - 2021-06-03 06:56:07 --> Language Class Initialized
INFO - 2021-06-03 06:56:07 --> Config Class Initialized
INFO - 2021-06-03 06:56:07 --> Loader Class Initialized
INFO - 2021-06-03 06:56:07 --> Helper loaded: url_helper
INFO - 2021-06-03 06:56:07 --> Helper loaded: file_helper
INFO - 2021-06-03 06:56:07 --> Helper loaded: form_helper
INFO - 2021-06-03 06:56:07 --> Helper loaded: my_helper
INFO - 2021-06-03 06:56:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:56:07 --> Controller Class Initialized
INFO - 2021-06-03 06:56:07 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:56:07 --> Config Class Initialized
INFO - 2021-06-03 06:56:07 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:56:07 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:56:07 --> Utf8 Class Initialized
INFO - 2021-06-03 06:56:07 --> URI Class Initialized
INFO - 2021-06-03 06:56:07 --> Router Class Initialized
INFO - 2021-06-03 06:56:07 --> Output Class Initialized
INFO - 2021-06-03 06:56:07 --> Security Class Initialized
DEBUG - 2021-06-03 06:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:56:07 --> Input Class Initialized
INFO - 2021-06-03 06:56:07 --> Language Class Initialized
INFO - 2021-06-03 06:56:07 --> Language Class Initialized
INFO - 2021-06-03 06:56:07 --> Config Class Initialized
INFO - 2021-06-03 06:56:07 --> Loader Class Initialized
INFO - 2021-06-03 06:56:07 --> Helper loaded: url_helper
INFO - 2021-06-03 06:56:07 --> Helper loaded: file_helper
INFO - 2021-06-03 06:56:07 --> Helper loaded: form_helper
INFO - 2021-06-03 06:56:07 --> Helper loaded: my_helper
INFO - 2021-06-03 06:56:07 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:56:07 --> Controller Class Initialized
DEBUG - 2021-06-03 06:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:56:07 --> Final output sent to browser
DEBUG - 2021-06-03 06:56:07 --> Total execution time: 0.0601
INFO - 2021-06-03 06:57:26 --> Config Class Initialized
INFO - 2021-06-03 06:57:26 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:26 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:26 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:26 --> URI Class Initialized
INFO - 2021-06-03 06:57:26 --> Router Class Initialized
INFO - 2021-06-03 06:57:26 --> Output Class Initialized
INFO - 2021-06-03 06:57:26 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:26 --> Input Class Initialized
INFO - 2021-06-03 06:57:26 --> Language Class Initialized
INFO - 2021-06-03 06:57:26 --> Language Class Initialized
INFO - 2021-06-03 06:57:26 --> Config Class Initialized
INFO - 2021-06-03 06:57:26 --> Loader Class Initialized
INFO - 2021-06-03 06:57:26 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:26 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:26 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:26 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:26 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:26 --> Controller Class Initialized
INFO - 2021-06-03 06:57:26 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:57:26 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:26 --> Total execution time: 0.0811
INFO - 2021-06-03 06:57:27 --> Config Class Initialized
INFO - 2021-06-03 06:57:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:27 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:27 --> URI Class Initialized
INFO - 2021-06-03 06:57:27 --> Router Class Initialized
INFO - 2021-06-03 06:57:27 --> Output Class Initialized
INFO - 2021-06-03 06:57:27 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:27 --> Input Class Initialized
INFO - 2021-06-03 06:57:27 --> Language Class Initialized
INFO - 2021-06-03 06:57:27 --> Language Class Initialized
INFO - 2021-06-03 06:57:27 --> Config Class Initialized
INFO - 2021-06-03 06:57:27 --> Loader Class Initialized
INFO - 2021-06-03 06:57:27 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:27 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:27 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:27 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:27 --> Controller Class Initialized
DEBUG - 2021-06-03 06:57:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:57:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:57:27 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:27 --> Total execution time: 0.0956
INFO - 2021-06-03 06:57:29 --> Config Class Initialized
INFO - 2021-06-03 06:57:29 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:29 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:29 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:29 --> URI Class Initialized
INFO - 2021-06-03 06:57:29 --> Router Class Initialized
INFO - 2021-06-03 06:57:29 --> Output Class Initialized
INFO - 2021-06-03 06:57:29 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:29 --> Input Class Initialized
INFO - 2021-06-03 06:57:29 --> Language Class Initialized
INFO - 2021-06-03 06:57:29 --> Language Class Initialized
INFO - 2021-06-03 06:57:29 --> Config Class Initialized
INFO - 2021-06-03 06:57:29 --> Loader Class Initialized
INFO - 2021-06-03 06:57:29 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:29 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:29 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:29 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:29 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:29 --> Controller Class Initialized
DEBUG - 2021-06-03 06:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 06:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:57:29 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:29 --> Total execution time: 0.0960
INFO - 2021-06-03 06:57:30 --> Config Class Initialized
INFO - 2021-06-03 06:57:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:30 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:30 --> URI Class Initialized
INFO - 2021-06-03 06:57:30 --> Router Class Initialized
INFO - 2021-06-03 06:57:30 --> Output Class Initialized
INFO - 2021-06-03 06:57:30 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:30 --> Input Class Initialized
INFO - 2021-06-03 06:57:30 --> Language Class Initialized
INFO - 2021-06-03 06:57:30 --> Language Class Initialized
INFO - 2021-06-03 06:57:30 --> Config Class Initialized
INFO - 2021-06-03 06:57:30 --> Loader Class Initialized
INFO - 2021-06-03 06:57:30 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:30 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:30 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:30 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:30 --> Controller Class Initialized
DEBUG - 2021-06-03 06:57:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 06:57:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:57:30 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:30 --> Total execution time: 0.0678
INFO - 2021-06-03 06:57:30 --> Config Class Initialized
INFO - 2021-06-03 06:57:30 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:30 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:30 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:30 --> URI Class Initialized
INFO - 2021-06-03 06:57:30 --> Router Class Initialized
INFO - 2021-06-03 06:57:30 --> Output Class Initialized
INFO - 2021-06-03 06:57:30 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:30 --> Input Class Initialized
INFO - 2021-06-03 06:57:30 --> Language Class Initialized
INFO - 2021-06-03 06:57:30 --> Language Class Initialized
INFO - 2021-06-03 06:57:30 --> Config Class Initialized
INFO - 2021-06-03 06:57:30 --> Loader Class Initialized
INFO - 2021-06-03 06:57:30 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:30 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:30 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:30 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:30 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:30 --> Controller Class Initialized
DEBUG - 2021-06-03 06:57:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 06:57:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:57:30 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:30 --> Total execution time: 0.0547
INFO - 2021-06-03 06:57:31 --> Config Class Initialized
INFO - 2021-06-03 06:57:31 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:31 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:31 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:31 --> URI Class Initialized
INFO - 2021-06-03 06:57:31 --> Router Class Initialized
INFO - 2021-06-03 06:57:31 --> Output Class Initialized
INFO - 2021-06-03 06:57:31 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:31 --> Input Class Initialized
INFO - 2021-06-03 06:57:31 --> Language Class Initialized
INFO - 2021-06-03 06:57:31 --> Language Class Initialized
INFO - 2021-06-03 06:57:31 --> Config Class Initialized
INFO - 2021-06-03 06:57:31 --> Loader Class Initialized
INFO - 2021-06-03 06:57:31 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:31 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:31 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:31 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:31 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:31 --> Controller Class Initialized
DEBUG - 2021-06-03 06:57:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 06:57:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:57:31 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:31 --> Total execution time: 0.0728
INFO - 2021-06-03 06:57:32 --> Config Class Initialized
INFO - 2021-06-03 06:57:32 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:32 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:32 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:32 --> URI Class Initialized
INFO - 2021-06-03 06:57:32 --> Router Class Initialized
INFO - 2021-06-03 06:57:32 --> Output Class Initialized
INFO - 2021-06-03 06:57:32 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:32 --> Input Class Initialized
INFO - 2021-06-03 06:57:32 --> Language Class Initialized
INFO - 2021-06-03 06:57:32 --> Language Class Initialized
INFO - 2021-06-03 06:57:32 --> Config Class Initialized
INFO - 2021-06-03 06:57:32 --> Loader Class Initialized
INFO - 2021-06-03 06:57:32 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:32 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:32 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:32 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:32 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:32 --> Controller Class Initialized
DEBUG - 2021-06-03 06:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 06:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:57:32 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:32 --> Total execution time: 0.0584
INFO - 2021-06-03 06:57:33 --> Config Class Initialized
INFO - 2021-06-03 06:57:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:33 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:33 --> URI Class Initialized
INFO - 2021-06-03 06:57:33 --> Router Class Initialized
INFO - 2021-06-03 06:57:33 --> Output Class Initialized
INFO - 2021-06-03 06:57:33 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:33 --> Input Class Initialized
INFO - 2021-06-03 06:57:33 --> Language Class Initialized
INFO - 2021-06-03 06:57:33 --> Language Class Initialized
INFO - 2021-06-03 06:57:33 --> Config Class Initialized
INFO - 2021-06-03 06:57:33 --> Loader Class Initialized
INFO - 2021-06-03 06:57:33 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:33 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:33 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:33 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:33 --> Controller Class Initialized
DEBUG - 2021-06-03 06:57:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 06:57:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:57:33 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:33 --> Total execution time: 0.0676
INFO - 2021-06-03 06:57:35 --> Config Class Initialized
INFO - 2021-06-03 06:57:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:35 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:35 --> URI Class Initialized
INFO - 2021-06-03 06:57:35 --> Router Class Initialized
INFO - 2021-06-03 06:57:35 --> Output Class Initialized
INFO - 2021-06-03 06:57:35 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:35 --> Input Class Initialized
INFO - 2021-06-03 06:57:35 --> Language Class Initialized
INFO - 2021-06-03 06:57:35 --> Language Class Initialized
INFO - 2021-06-03 06:57:35 --> Config Class Initialized
INFO - 2021-06-03 06:57:35 --> Loader Class Initialized
INFO - 2021-06-03 06:57:35 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:35 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:35 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:35 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:35 --> Controller Class Initialized
DEBUG - 2021-06-03 06:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-06-03 06:57:35 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:35 --> Total execution time: 0.0915
INFO - 2021-06-03 06:57:49 --> Config Class Initialized
INFO - 2021-06-03 06:57:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:57:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:57:49 --> Utf8 Class Initialized
INFO - 2021-06-03 06:57:49 --> URI Class Initialized
INFO - 2021-06-03 06:57:49 --> Router Class Initialized
INFO - 2021-06-03 06:57:49 --> Output Class Initialized
INFO - 2021-06-03 06:57:49 --> Security Class Initialized
DEBUG - 2021-06-03 06:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:57:49 --> Input Class Initialized
INFO - 2021-06-03 06:57:49 --> Language Class Initialized
INFO - 2021-06-03 06:57:49 --> Language Class Initialized
INFO - 2021-06-03 06:57:49 --> Config Class Initialized
INFO - 2021-06-03 06:57:49 --> Loader Class Initialized
INFO - 2021-06-03 06:57:49 --> Helper loaded: url_helper
INFO - 2021-06-03 06:57:49 --> Helper loaded: file_helper
INFO - 2021-06-03 06:57:49 --> Helper loaded: form_helper
INFO - 2021-06-03 06:57:49 --> Helper loaded: my_helper
INFO - 2021-06-03 06:57:49 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:57:49 --> Controller Class Initialized
DEBUG - 2021-06-03 06:57:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-06-03 06:57:49 --> Final output sent to browser
DEBUG - 2021-06-03 06:57:49 --> Total execution time: 0.0782
INFO - 2021-06-03 06:58:37 --> Config Class Initialized
INFO - 2021-06-03 06:58:37 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:58:37 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:58:37 --> Utf8 Class Initialized
INFO - 2021-06-03 06:58:37 --> URI Class Initialized
INFO - 2021-06-03 06:58:37 --> Router Class Initialized
INFO - 2021-06-03 06:58:37 --> Output Class Initialized
INFO - 2021-06-03 06:58:37 --> Security Class Initialized
DEBUG - 2021-06-03 06:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:58:37 --> Input Class Initialized
INFO - 2021-06-03 06:58:37 --> Language Class Initialized
INFO - 2021-06-03 06:58:37 --> Language Class Initialized
INFO - 2021-06-03 06:58:37 --> Config Class Initialized
INFO - 2021-06-03 06:58:37 --> Loader Class Initialized
INFO - 2021-06-03 06:58:37 --> Helper loaded: url_helper
INFO - 2021-06-03 06:58:37 --> Helper loaded: file_helper
INFO - 2021-06-03 06:58:37 --> Helper loaded: form_helper
INFO - 2021-06-03 06:58:37 --> Helper loaded: my_helper
INFO - 2021-06-03 06:58:37 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:58:37 --> Controller Class Initialized
DEBUG - 2021-06-03 06:58:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-06-03 06:58:37 --> Final output sent to browser
DEBUG - 2021-06-03 06:58:37 --> Total execution time: 0.0658
INFO - 2021-06-03 06:58:51 --> Config Class Initialized
INFO - 2021-06-03 06:58:51 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:58:51 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:58:51 --> Utf8 Class Initialized
INFO - 2021-06-03 06:58:51 --> URI Class Initialized
INFO - 2021-06-03 06:58:51 --> Router Class Initialized
INFO - 2021-06-03 06:58:51 --> Output Class Initialized
INFO - 2021-06-03 06:58:51 --> Security Class Initialized
DEBUG - 2021-06-03 06:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:58:51 --> Input Class Initialized
INFO - 2021-06-03 06:58:51 --> Language Class Initialized
INFO - 2021-06-03 06:58:51 --> Language Class Initialized
INFO - 2021-06-03 06:58:51 --> Config Class Initialized
INFO - 2021-06-03 06:58:51 --> Loader Class Initialized
INFO - 2021-06-03 06:58:51 --> Helper loaded: url_helper
INFO - 2021-06-03 06:58:51 --> Helper loaded: file_helper
INFO - 2021-06-03 06:58:51 --> Helper loaded: form_helper
INFO - 2021-06-03 06:58:51 --> Helper loaded: my_helper
INFO - 2021-06-03 06:58:51 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:58:51 --> Controller Class Initialized
DEBUG - 2021-06-03 06:58:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-06-03 06:58:51 --> Final output sent to browser
DEBUG - 2021-06-03 06:58:51 --> Total execution time: 0.0780
INFO - 2021-06-03 06:59:24 --> Config Class Initialized
INFO - 2021-06-03 06:59:24 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:59:24 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:59:24 --> Utf8 Class Initialized
INFO - 2021-06-03 06:59:24 --> URI Class Initialized
INFO - 2021-06-03 06:59:24 --> Router Class Initialized
INFO - 2021-06-03 06:59:24 --> Output Class Initialized
INFO - 2021-06-03 06:59:24 --> Security Class Initialized
DEBUG - 2021-06-03 06:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:59:24 --> Input Class Initialized
INFO - 2021-06-03 06:59:24 --> Language Class Initialized
INFO - 2021-06-03 06:59:24 --> Language Class Initialized
INFO - 2021-06-03 06:59:24 --> Config Class Initialized
INFO - 2021-06-03 06:59:24 --> Loader Class Initialized
INFO - 2021-06-03 06:59:24 --> Helper loaded: url_helper
INFO - 2021-06-03 06:59:24 --> Helper loaded: file_helper
INFO - 2021-06-03 06:59:24 --> Helper loaded: form_helper
INFO - 2021-06-03 06:59:24 --> Helper loaded: my_helper
INFO - 2021-06-03 06:59:24 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:59:24 --> Controller Class Initialized
INFO - 2021-06-03 06:59:24 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:59:24 --> Config Class Initialized
INFO - 2021-06-03 06:59:24 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:59:24 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:59:24 --> Utf8 Class Initialized
INFO - 2021-06-03 06:59:24 --> URI Class Initialized
INFO - 2021-06-03 06:59:24 --> Router Class Initialized
INFO - 2021-06-03 06:59:24 --> Output Class Initialized
INFO - 2021-06-03 06:59:24 --> Security Class Initialized
DEBUG - 2021-06-03 06:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:59:25 --> Input Class Initialized
INFO - 2021-06-03 06:59:25 --> Language Class Initialized
INFO - 2021-06-03 06:59:25 --> Language Class Initialized
INFO - 2021-06-03 06:59:25 --> Config Class Initialized
INFO - 2021-06-03 06:59:25 --> Loader Class Initialized
INFO - 2021-06-03 06:59:25 --> Helper loaded: url_helper
INFO - 2021-06-03 06:59:25 --> Helper loaded: file_helper
INFO - 2021-06-03 06:59:25 --> Helper loaded: form_helper
INFO - 2021-06-03 06:59:25 --> Helper loaded: my_helper
INFO - 2021-06-03 06:59:25 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:59:25 --> Controller Class Initialized
DEBUG - 2021-06-03 06:59:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 06:59:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:59:25 --> Final output sent to browser
DEBUG - 2021-06-03 06:59:25 --> Total execution time: 0.0813
INFO - 2021-06-03 06:59:35 --> Config Class Initialized
INFO - 2021-06-03 06:59:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:59:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:59:35 --> Utf8 Class Initialized
INFO - 2021-06-03 06:59:35 --> URI Class Initialized
INFO - 2021-06-03 06:59:35 --> Router Class Initialized
INFO - 2021-06-03 06:59:35 --> Output Class Initialized
INFO - 2021-06-03 06:59:35 --> Security Class Initialized
DEBUG - 2021-06-03 06:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:59:35 --> Input Class Initialized
INFO - 2021-06-03 06:59:35 --> Language Class Initialized
INFO - 2021-06-03 06:59:35 --> Language Class Initialized
INFO - 2021-06-03 06:59:35 --> Config Class Initialized
INFO - 2021-06-03 06:59:35 --> Loader Class Initialized
INFO - 2021-06-03 06:59:35 --> Helper loaded: url_helper
INFO - 2021-06-03 06:59:35 --> Helper loaded: file_helper
INFO - 2021-06-03 06:59:35 --> Helper loaded: form_helper
INFO - 2021-06-03 06:59:35 --> Helper loaded: my_helper
INFO - 2021-06-03 06:59:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:59:35 --> Controller Class Initialized
INFO - 2021-06-03 06:59:35 --> Helper loaded: cookie_helper
INFO - 2021-06-03 06:59:35 --> Final output sent to browser
DEBUG - 2021-06-03 06:59:35 --> Total execution time: 0.0720
INFO - 2021-06-03 06:59:38 --> Config Class Initialized
INFO - 2021-06-03 06:59:38 --> Hooks Class Initialized
DEBUG - 2021-06-03 06:59:38 --> UTF-8 Support Enabled
INFO - 2021-06-03 06:59:38 --> Utf8 Class Initialized
INFO - 2021-06-03 06:59:38 --> URI Class Initialized
INFO - 2021-06-03 06:59:38 --> Router Class Initialized
INFO - 2021-06-03 06:59:38 --> Output Class Initialized
INFO - 2021-06-03 06:59:38 --> Security Class Initialized
DEBUG - 2021-06-03 06:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 06:59:38 --> Input Class Initialized
INFO - 2021-06-03 06:59:38 --> Language Class Initialized
INFO - 2021-06-03 06:59:38 --> Language Class Initialized
INFO - 2021-06-03 06:59:38 --> Config Class Initialized
INFO - 2021-06-03 06:59:38 --> Loader Class Initialized
INFO - 2021-06-03 06:59:38 --> Helper loaded: url_helper
INFO - 2021-06-03 06:59:38 --> Helper loaded: file_helper
INFO - 2021-06-03 06:59:38 --> Helper loaded: form_helper
INFO - 2021-06-03 06:59:38 --> Helper loaded: my_helper
INFO - 2021-06-03 06:59:38 --> Database Driver Class Initialized
DEBUG - 2021-06-03 06:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 06:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 06:59:38 --> Controller Class Initialized
DEBUG - 2021-06-03 06:59:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 06:59:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 06:59:38 --> Final output sent to browser
DEBUG - 2021-06-03 06:59:38 --> Total execution time: 0.0790
INFO - 2021-06-03 07:01:43 --> Config Class Initialized
INFO - 2021-06-03 07:01:43 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:01:43 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:01:43 --> Utf8 Class Initialized
INFO - 2021-06-03 07:01:43 --> URI Class Initialized
INFO - 2021-06-03 07:01:43 --> Router Class Initialized
INFO - 2021-06-03 07:01:43 --> Output Class Initialized
INFO - 2021-06-03 07:01:43 --> Security Class Initialized
DEBUG - 2021-06-03 07:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:01:43 --> Input Class Initialized
INFO - 2021-06-03 07:01:43 --> Language Class Initialized
INFO - 2021-06-03 07:01:43 --> Language Class Initialized
INFO - 2021-06-03 07:01:43 --> Config Class Initialized
INFO - 2021-06-03 07:01:43 --> Loader Class Initialized
INFO - 2021-06-03 07:01:43 --> Helper loaded: url_helper
INFO - 2021-06-03 07:01:43 --> Helper loaded: file_helper
INFO - 2021-06-03 07:01:43 --> Helper loaded: form_helper
INFO - 2021-06-03 07:01:43 --> Helper loaded: my_helper
INFO - 2021-06-03 07:01:43 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:01:43 --> Controller Class Initialized
DEBUG - 2021-06-03 07:01:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 07:01:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:01:43 --> Final output sent to browser
DEBUG - 2021-06-03 07:01:43 --> Total execution time: 0.0659
INFO - 2021-06-03 07:01:44 --> Config Class Initialized
INFO - 2021-06-03 07:01:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:01:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:01:44 --> Utf8 Class Initialized
INFO - 2021-06-03 07:01:44 --> URI Class Initialized
INFO - 2021-06-03 07:01:44 --> Router Class Initialized
INFO - 2021-06-03 07:01:44 --> Output Class Initialized
INFO - 2021-06-03 07:01:44 --> Security Class Initialized
DEBUG - 2021-06-03 07:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:01:44 --> Input Class Initialized
INFO - 2021-06-03 07:01:44 --> Language Class Initialized
INFO - 2021-06-03 07:01:44 --> Language Class Initialized
INFO - 2021-06-03 07:01:44 --> Config Class Initialized
INFO - 2021-06-03 07:01:44 --> Loader Class Initialized
INFO - 2021-06-03 07:01:44 --> Helper loaded: url_helper
INFO - 2021-06-03 07:01:44 --> Helper loaded: file_helper
INFO - 2021-06-03 07:01:44 --> Helper loaded: form_helper
INFO - 2021-06-03 07:01:44 --> Helper loaded: my_helper
INFO - 2021-06-03 07:01:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:01:44 --> Controller Class Initialized
DEBUG - 2021-06-03 07:01:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-03 07:01:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:01:44 --> Final output sent to browser
DEBUG - 2021-06-03 07:01:44 --> Total execution time: 0.0782
INFO - 2021-06-03 07:01:45 --> Config Class Initialized
INFO - 2021-06-03 07:01:45 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:01:45 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:01:45 --> Utf8 Class Initialized
INFO - 2021-06-03 07:01:45 --> URI Class Initialized
INFO - 2021-06-03 07:01:45 --> Router Class Initialized
INFO - 2021-06-03 07:01:45 --> Output Class Initialized
INFO - 2021-06-03 07:01:45 --> Security Class Initialized
DEBUG - 2021-06-03 07:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:01:45 --> Input Class Initialized
INFO - 2021-06-03 07:01:45 --> Language Class Initialized
INFO - 2021-06-03 07:01:45 --> Language Class Initialized
INFO - 2021-06-03 07:01:45 --> Config Class Initialized
INFO - 2021-06-03 07:01:45 --> Loader Class Initialized
INFO - 2021-06-03 07:01:45 --> Helper loaded: url_helper
INFO - 2021-06-03 07:01:45 --> Helper loaded: file_helper
INFO - 2021-06-03 07:01:45 --> Helper loaded: form_helper
INFO - 2021-06-03 07:01:45 --> Helper loaded: my_helper
INFO - 2021-06-03 07:01:45 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:01:45 --> Controller Class Initialized
DEBUG - 2021-06-03 07:01:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 07:01:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:01:45 --> Final output sent to browser
DEBUG - 2021-06-03 07:01:45 --> Total execution time: 0.0980
INFO - 2021-06-03 07:01:46 --> Config Class Initialized
INFO - 2021-06-03 07:01:46 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:01:46 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:01:46 --> Utf8 Class Initialized
INFO - 2021-06-03 07:01:46 --> URI Class Initialized
INFO - 2021-06-03 07:01:46 --> Router Class Initialized
INFO - 2021-06-03 07:01:46 --> Output Class Initialized
INFO - 2021-06-03 07:01:46 --> Security Class Initialized
DEBUG - 2021-06-03 07:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:01:46 --> Input Class Initialized
INFO - 2021-06-03 07:01:46 --> Language Class Initialized
INFO - 2021-06-03 07:01:46 --> Language Class Initialized
INFO - 2021-06-03 07:01:46 --> Config Class Initialized
INFO - 2021-06-03 07:01:46 --> Loader Class Initialized
INFO - 2021-06-03 07:01:46 --> Helper loaded: url_helper
INFO - 2021-06-03 07:01:46 --> Helper loaded: file_helper
INFO - 2021-06-03 07:01:46 --> Helper loaded: form_helper
INFO - 2021-06-03 07:01:46 --> Helper loaded: my_helper
INFO - 2021-06-03 07:01:46 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:01:46 --> Controller Class Initialized
DEBUG - 2021-06-03 07:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 07:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:01:47 --> Final output sent to browser
DEBUG - 2021-06-03 07:01:47 --> Total execution time: 0.1135
INFO - 2021-06-03 07:02:04 --> Config Class Initialized
INFO - 2021-06-03 07:02:04 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:04 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:04 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:04 --> URI Class Initialized
INFO - 2021-06-03 07:02:04 --> Router Class Initialized
INFO - 2021-06-03 07:02:04 --> Output Class Initialized
INFO - 2021-06-03 07:02:04 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:04 --> Input Class Initialized
INFO - 2021-06-03 07:02:04 --> Language Class Initialized
INFO - 2021-06-03 07:02:04 --> Language Class Initialized
INFO - 2021-06-03 07:02:04 --> Config Class Initialized
INFO - 2021-06-03 07:02:04 --> Loader Class Initialized
INFO - 2021-06-03 07:02:04 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:04 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:04 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:04 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:04 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:04 --> Controller Class Initialized
INFO - 2021-06-03 07:02:04 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:04 --> Total execution time: 0.1283
INFO - 2021-06-03 07:02:08 --> Config Class Initialized
INFO - 2021-06-03 07:02:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:08 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:08 --> URI Class Initialized
INFO - 2021-06-03 07:02:08 --> Router Class Initialized
INFO - 2021-06-03 07:02:08 --> Output Class Initialized
INFO - 2021-06-03 07:02:08 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:08 --> Input Class Initialized
INFO - 2021-06-03 07:02:08 --> Language Class Initialized
INFO - 2021-06-03 07:02:08 --> Language Class Initialized
INFO - 2021-06-03 07:02:08 --> Config Class Initialized
INFO - 2021-06-03 07:02:08 --> Loader Class Initialized
INFO - 2021-06-03 07:02:08 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:08 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:08 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:08 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:08 --> Controller Class Initialized
DEBUG - 2021-06-03 07:02:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 07:02:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:02:08 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:08 --> Total execution time: 0.0628
INFO - 2021-06-03 07:02:08 --> Config Class Initialized
INFO - 2021-06-03 07:02:08 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:08 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:08 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:08 --> URI Class Initialized
INFO - 2021-06-03 07:02:08 --> Router Class Initialized
INFO - 2021-06-03 07:02:08 --> Output Class Initialized
INFO - 2021-06-03 07:02:08 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:08 --> Input Class Initialized
INFO - 2021-06-03 07:02:08 --> Language Class Initialized
INFO - 2021-06-03 07:02:08 --> Language Class Initialized
INFO - 2021-06-03 07:02:08 --> Config Class Initialized
INFO - 2021-06-03 07:02:08 --> Loader Class Initialized
INFO - 2021-06-03 07:02:08 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:08 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:08 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:08 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:08 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:08 --> Controller Class Initialized
DEBUG - 2021-06-03 07:02:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 07:02:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:02:08 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:08 --> Total execution time: 0.0643
INFO - 2021-06-03 07:02:10 --> Config Class Initialized
INFO - 2021-06-03 07:02:10 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:10 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:10 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:10 --> URI Class Initialized
INFO - 2021-06-03 07:02:10 --> Router Class Initialized
INFO - 2021-06-03 07:02:10 --> Output Class Initialized
INFO - 2021-06-03 07:02:10 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:10 --> Input Class Initialized
INFO - 2021-06-03 07:02:10 --> Language Class Initialized
INFO - 2021-06-03 07:02:10 --> Language Class Initialized
INFO - 2021-06-03 07:02:10 --> Config Class Initialized
INFO - 2021-06-03 07:02:10 --> Loader Class Initialized
INFO - 2021-06-03 07:02:10 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:10 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:10 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:10 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:10 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:10 --> Controller Class Initialized
INFO - 2021-06-03 07:02:10 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:10 --> Total execution time: 0.0407
INFO - 2021-06-03 07:02:11 --> Config Class Initialized
INFO - 2021-06-03 07:02:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:11 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:11 --> URI Class Initialized
INFO - 2021-06-03 07:02:11 --> Router Class Initialized
INFO - 2021-06-03 07:02:11 --> Output Class Initialized
INFO - 2021-06-03 07:02:11 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:11 --> Input Class Initialized
INFO - 2021-06-03 07:02:11 --> Language Class Initialized
INFO - 2021-06-03 07:02:11 --> Language Class Initialized
INFO - 2021-06-03 07:02:11 --> Config Class Initialized
INFO - 2021-06-03 07:02:11 --> Loader Class Initialized
INFO - 2021-06-03 07:02:11 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:11 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:11 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:11 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:11 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:11 --> Controller Class Initialized
DEBUG - 2021-06-03 07:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 07:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:02:11 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:11 --> Total execution time: 0.0605
INFO - 2021-06-03 07:02:12 --> Config Class Initialized
INFO - 2021-06-03 07:02:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:12 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:12 --> URI Class Initialized
INFO - 2021-06-03 07:02:12 --> Router Class Initialized
INFO - 2021-06-03 07:02:12 --> Output Class Initialized
INFO - 2021-06-03 07:02:12 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:12 --> Input Class Initialized
INFO - 2021-06-03 07:02:12 --> Language Class Initialized
INFO - 2021-06-03 07:02:12 --> Language Class Initialized
INFO - 2021-06-03 07:02:12 --> Config Class Initialized
INFO - 2021-06-03 07:02:12 --> Loader Class Initialized
INFO - 2021-06-03 07:02:12 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:12 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:12 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:12 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:12 --> Controller Class Initialized
DEBUG - 2021-06-03 07:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 07:02:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:02:12 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:12 --> Total execution time: 0.0717
INFO - 2021-06-03 07:02:16 --> Config Class Initialized
INFO - 2021-06-03 07:02:16 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:16 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:16 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:16 --> URI Class Initialized
INFO - 2021-06-03 07:02:16 --> Router Class Initialized
INFO - 2021-06-03 07:02:16 --> Output Class Initialized
INFO - 2021-06-03 07:02:16 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:16 --> Input Class Initialized
INFO - 2021-06-03 07:02:16 --> Language Class Initialized
INFO - 2021-06-03 07:02:17 --> Language Class Initialized
INFO - 2021-06-03 07:02:17 --> Config Class Initialized
INFO - 2021-06-03 07:02:17 --> Loader Class Initialized
INFO - 2021-06-03 07:02:17 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:17 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:17 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:17 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:17 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:17 --> Controller Class Initialized
INFO - 2021-06-03 07:02:17 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:17 --> Total execution time: 0.1186
INFO - 2021-06-03 07:02:19 --> Config Class Initialized
INFO - 2021-06-03 07:02:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:19 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:19 --> URI Class Initialized
INFO - 2021-06-03 07:02:19 --> Router Class Initialized
INFO - 2021-06-03 07:02:19 --> Output Class Initialized
INFO - 2021-06-03 07:02:19 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:19 --> Input Class Initialized
INFO - 2021-06-03 07:02:19 --> Language Class Initialized
INFO - 2021-06-03 07:02:19 --> Language Class Initialized
INFO - 2021-06-03 07:02:19 --> Config Class Initialized
INFO - 2021-06-03 07:02:19 --> Loader Class Initialized
INFO - 2021-06-03 07:02:19 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:19 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:19 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:19 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:19 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:19 --> Controller Class Initialized
DEBUG - 2021-06-03 07:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 07:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:02:19 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:19 --> Total execution time: 0.0954
INFO - 2021-06-03 07:02:22 --> Config Class Initialized
INFO - 2021-06-03 07:02:22 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:22 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:22 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:22 --> URI Class Initialized
INFO - 2021-06-03 07:02:22 --> Router Class Initialized
INFO - 2021-06-03 07:02:22 --> Output Class Initialized
INFO - 2021-06-03 07:02:22 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:22 --> Input Class Initialized
INFO - 2021-06-03 07:02:22 --> Language Class Initialized
INFO - 2021-06-03 07:02:22 --> Language Class Initialized
INFO - 2021-06-03 07:02:22 --> Config Class Initialized
INFO - 2021-06-03 07:02:22 --> Loader Class Initialized
INFO - 2021-06-03 07:02:22 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:22 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:22 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:22 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:22 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:22 --> Controller Class Initialized
DEBUG - 2021-06-03 07:02:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-06-03 07:02:22 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:22 --> Total execution time: 0.0989
INFO - 2021-06-03 07:02:42 --> Config Class Initialized
INFO - 2021-06-03 07:02:42 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:42 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:42 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:42 --> URI Class Initialized
INFO - 2021-06-03 07:02:42 --> Router Class Initialized
INFO - 2021-06-03 07:02:42 --> Output Class Initialized
INFO - 2021-06-03 07:02:42 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:42 --> Input Class Initialized
INFO - 2021-06-03 07:02:42 --> Language Class Initialized
INFO - 2021-06-03 07:02:42 --> Language Class Initialized
INFO - 2021-06-03 07:02:42 --> Config Class Initialized
INFO - 2021-06-03 07:02:42 --> Loader Class Initialized
INFO - 2021-06-03 07:02:42 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:42 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:42 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:42 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:42 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:42 --> Controller Class Initialized
DEBUG - 2021-06-03 07:02:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-06-03 07:02:42 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:42 --> Total execution time: 0.0589
INFO - 2021-06-03 07:02:50 --> Config Class Initialized
INFO - 2021-06-03 07:02:50 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:50 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:50 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:50 --> URI Class Initialized
INFO - 2021-06-03 07:02:50 --> Router Class Initialized
INFO - 2021-06-03 07:02:50 --> Output Class Initialized
INFO - 2021-06-03 07:02:50 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:50 --> Input Class Initialized
INFO - 2021-06-03 07:02:50 --> Language Class Initialized
INFO - 2021-06-03 07:02:50 --> Language Class Initialized
INFO - 2021-06-03 07:02:50 --> Config Class Initialized
INFO - 2021-06-03 07:02:50 --> Loader Class Initialized
INFO - 2021-06-03 07:02:50 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:50 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:50 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:50 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:50 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:50 --> Controller Class Initialized
DEBUG - 2021-06-03 07:02:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-06-03 07:02:50 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:50 --> Total execution time: 0.0789
INFO - 2021-06-03 07:02:56 --> Config Class Initialized
INFO - 2021-06-03 07:02:56 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:02:56 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:02:56 --> Utf8 Class Initialized
INFO - 2021-06-03 07:02:56 --> URI Class Initialized
INFO - 2021-06-03 07:02:56 --> Router Class Initialized
INFO - 2021-06-03 07:02:56 --> Output Class Initialized
INFO - 2021-06-03 07:02:56 --> Security Class Initialized
DEBUG - 2021-06-03 07:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:02:56 --> Input Class Initialized
INFO - 2021-06-03 07:02:56 --> Language Class Initialized
INFO - 2021-06-03 07:02:56 --> Language Class Initialized
INFO - 2021-06-03 07:02:56 --> Config Class Initialized
INFO - 2021-06-03 07:02:56 --> Loader Class Initialized
INFO - 2021-06-03 07:02:56 --> Helper loaded: url_helper
INFO - 2021-06-03 07:02:56 --> Helper loaded: file_helper
INFO - 2021-06-03 07:02:56 --> Helper loaded: form_helper
INFO - 2021-06-03 07:02:56 --> Helper loaded: my_helper
INFO - 2021-06-03 07:02:56 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:02:56 --> Controller Class Initialized
DEBUG - 2021-06-03 07:02:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-06-03 07:02:56 --> Final output sent to browser
DEBUG - 2021-06-03 07:02:56 --> Total execution time: 0.0735
INFO - 2021-06-03 07:04:44 --> Config Class Initialized
INFO - 2021-06-03 07:04:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:04:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:04:44 --> Utf8 Class Initialized
INFO - 2021-06-03 07:04:44 --> URI Class Initialized
INFO - 2021-06-03 07:04:44 --> Router Class Initialized
INFO - 2021-06-03 07:04:44 --> Output Class Initialized
INFO - 2021-06-03 07:04:44 --> Security Class Initialized
DEBUG - 2021-06-03 07:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:04:44 --> Input Class Initialized
INFO - 2021-06-03 07:04:44 --> Language Class Initialized
INFO - 2021-06-03 07:04:44 --> Language Class Initialized
INFO - 2021-06-03 07:04:44 --> Config Class Initialized
INFO - 2021-06-03 07:04:44 --> Loader Class Initialized
INFO - 2021-06-03 07:04:44 --> Helper loaded: url_helper
INFO - 2021-06-03 07:04:44 --> Helper loaded: file_helper
INFO - 2021-06-03 07:04:44 --> Helper loaded: form_helper
INFO - 2021-06-03 07:04:44 --> Helper loaded: my_helper
INFO - 2021-06-03 07:04:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:04:44 --> Controller Class Initialized
INFO - 2021-06-03 07:04:44 --> Helper loaded: cookie_helper
INFO - 2021-06-03 07:04:44 --> Config Class Initialized
INFO - 2021-06-03 07:04:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:04:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:04:44 --> Utf8 Class Initialized
INFO - 2021-06-03 07:04:44 --> URI Class Initialized
INFO - 2021-06-03 07:04:44 --> Router Class Initialized
INFO - 2021-06-03 07:04:44 --> Output Class Initialized
INFO - 2021-06-03 07:04:44 --> Security Class Initialized
DEBUG - 2021-06-03 07:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:04:44 --> Input Class Initialized
INFO - 2021-06-03 07:04:44 --> Language Class Initialized
INFO - 2021-06-03 07:04:44 --> Language Class Initialized
INFO - 2021-06-03 07:04:44 --> Config Class Initialized
INFO - 2021-06-03 07:04:44 --> Loader Class Initialized
INFO - 2021-06-03 07:04:44 --> Helper loaded: url_helper
INFO - 2021-06-03 07:04:44 --> Helper loaded: file_helper
INFO - 2021-06-03 07:04:44 --> Helper loaded: form_helper
INFO - 2021-06-03 07:04:44 --> Helper loaded: my_helper
INFO - 2021-06-03 07:04:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:04:44 --> Controller Class Initialized
DEBUG - 2021-06-03 07:04:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 07:04:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:04:44 --> Final output sent to browser
DEBUG - 2021-06-03 07:04:44 --> Total execution time: 0.0667
INFO - 2021-06-03 07:04:53 --> Config Class Initialized
INFO - 2021-06-03 07:04:53 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:04:53 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:04:53 --> Utf8 Class Initialized
INFO - 2021-06-03 07:04:53 --> URI Class Initialized
INFO - 2021-06-03 07:04:53 --> Router Class Initialized
INFO - 2021-06-03 07:04:53 --> Output Class Initialized
INFO - 2021-06-03 07:04:53 --> Security Class Initialized
DEBUG - 2021-06-03 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:04:53 --> Input Class Initialized
INFO - 2021-06-03 07:04:53 --> Language Class Initialized
INFO - 2021-06-03 07:04:53 --> Language Class Initialized
INFO - 2021-06-03 07:04:53 --> Config Class Initialized
INFO - 2021-06-03 07:04:53 --> Loader Class Initialized
INFO - 2021-06-03 07:04:53 --> Helper loaded: url_helper
INFO - 2021-06-03 07:04:53 --> Helper loaded: file_helper
INFO - 2021-06-03 07:04:53 --> Helper loaded: form_helper
INFO - 2021-06-03 07:04:53 --> Helper loaded: my_helper
INFO - 2021-06-03 07:04:53 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:04:53 --> Controller Class Initialized
DEBUG - 2021-06-03 07:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 07:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:04:53 --> Final output sent to browser
DEBUG - 2021-06-03 07:04:53 --> Total execution time: 0.1012
INFO - 2021-06-03 07:04:55 --> Config Class Initialized
INFO - 2021-06-03 07:04:55 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:04:55 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:04:55 --> Utf8 Class Initialized
INFO - 2021-06-03 07:04:55 --> URI Class Initialized
DEBUG - 2021-06-03 07:04:55 --> No URI present. Default controller set.
INFO - 2021-06-03 07:04:55 --> Router Class Initialized
INFO - 2021-06-03 07:04:55 --> Output Class Initialized
INFO - 2021-06-03 07:04:55 --> Security Class Initialized
DEBUG - 2021-06-03 07:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:04:55 --> Input Class Initialized
INFO - 2021-06-03 07:04:55 --> Language Class Initialized
INFO - 2021-06-03 07:04:55 --> Language Class Initialized
INFO - 2021-06-03 07:04:55 --> Config Class Initialized
INFO - 2021-06-03 07:04:55 --> Loader Class Initialized
INFO - 2021-06-03 07:04:55 --> Helper loaded: url_helper
INFO - 2021-06-03 07:04:55 --> Helper loaded: file_helper
INFO - 2021-06-03 07:04:55 --> Helper loaded: form_helper
INFO - 2021-06-03 07:04:55 --> Helper loaded: my_helper
INFO - 2021-06-03 07:04:55 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:04:55 --> Controller Class Initialized
INFO - 2021-06-03 07:04:55 --> Config Class Initialized
INFO - 2021-06-03 07:04:55 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:04:55 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:04:55 --> Utf8 Class Initialized
INFO - 2021-06-03 07:04:55 --> URI Class Initialized
INFO - 2021-06-03 07:04:55 --> Router Class Initialized
INFO - 2021-06-03 07:04:55 --> Output Class Initialized
INFO - 2021-06-03 07:04:55 --> Security Class Initialized
DEBUG - 2021-06-03 07:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:04:55 --> Input Class Initialized
INFO - 2021-06-03 07:04:55 --> Language Class Initialized
INFO - 2021-06-03 07:04:55 --> Language Class Initialized
INFO - 2021-06-03 07:04:55 --> Config Class Initialized
INFO - 2021-06-03 07:04:55 --> Loader Class Initialized
INFO - 2021-06-03 07:04:55 --> Helper loaded: url_helper
INFO - 2021-06-03 07:04:55 --> Helper loaded: file_helper
INFO - 2021-06-03 07:04:55 --> Helper loaded: form_helper
INFO - 2021-06-03 07:04:55 --> Helper loaded: my_helper
INFO - 2021-06-03 07:04:55 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:04:56 --> Controller Class Initialized
DEBUG - 2021-06-03 07:04:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 07:04:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:04:56 --> Final output sent to browser
DEBUG - 2021-06-03 07:04:56 --> Total execution time: 0.0763
INFO - 2021-06-03 07:05:01 --> Config Class Initialized
INFO - 2021-06-03 07:05:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:05:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:05:01 --> Utf8 Class Initialized
INFO - 2021-06-03 07:05:01 --> URI Class Initialized
INFO - 2021-06-03 07:05:01 --> Router Class Initialized
INFO - 2021-06-03 07:05:01 --> Output Class Initialized
INFO - 2021-06-03 07:05:01 --> Security Class Initialized
DEBUG - 2021-06-03 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:05:01 --> Input Class Initialized
INFO - 2021-06-03 07:05:01 --> Language Class Initialized
INFO - 2021-06-03 07:05:01 --> Language Class Initialized
INFO - 2021-06-03 07:05:01 --> Config Class Initialized
INFO - 2021-06-03 07:05:01 --> Loader Class Initialized
INFO - 2021-06-03 07:05:01 --> Helper loaded: url_helper
INFO - 2021-06-03 07:05:01 --> Helper loaded: file_helper
INFO - 2021-06-03 07:05:01 --> Helper loaded: form_helper
INFO - 2021-06-03 07:05:01 --> Helper loaded: my_helper
INFO - 2021-06-03 07:05:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:05:01 --> Controller Class Initialized
INFO - 2021-06-03 07:05:01 --> Helper loaded: cookie_helper
INFO - 2021-06-03 07:05:01 --> Final output sent to browser
DEBUG - 2021-06-03 07:05:01 --> Total execution time: 0.0765
INFO - 2021-06-03 07:05:01 --> Config Class Initialized
INFO - 2021-06-03 07:05:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:05:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:05:01 --> Utf8 Class Initialized
INFO - 2021-06-03 07:05:01 --> URI Class Initialized
INFO - 2021-06-03 07:05:01 --> Router Class Initialized
INFO - 2021-06-03 07:05:01 --> Output Class Initialized
INFO - 2021-06-03 07:05:01 --> Security Class Initialized
DEBUG - 2021-06-03 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:05:01 --> Input Class Initialized
INFO - 2021-06-03 07:05:01 --> Language Class Initialized
INFO - 2021-06-03 07:05:01 --> Language Class Initialized
INFO - 2021-06-03 07:05:01 --> Config Class Initialized
INFO - 2021-06-03 07:05:01 --> Loader Class Initialized
INFO - 2021-06-03 07:05:01 --> Helper loaded: url_helper
INFO - 2021-06-03 07:05:01 --> Helper loaded: file_helper
INFO - 2021-06-03 07:05:01 --> Helper loaded: form_helper
INFO - 2021-06-03 07:05:01 --> Helper loaded: my_helper
INFO - 2021-06-03 07:05:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:05:01 --> Controller Class Initialized
DEBUG - 2021-06-03 07:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 07:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:05:01 --> Final output sent to browser
DEBUG - 2021-06-03 07:05:01 --> Total execution time: 0.0923
INFO - 2021-06-03 07:05:03 --> Config Class Initialized
INFO - 2021-06-03 07:05:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:05:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:05:03 --> Utf8 Class Initialized
INFO - 2021-06-03 07:05:03 --> URI Class Initialized
INFO - 2021-06-03 07:05:03 --> Router Class Initialized
INFO - 2021-06-03 07:05:03 --> Output Class Initialized
INFO - 2021-06-03 07:05:03 --> Security Class Initialized
DEBUG - 2021-06-03 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:05:03 --> Input Class Initialized
INFO - 2021-06-03 07:05:03 --> Language Class Initialized
INFO - 2021-06-03 07:05:03 --> Language Class Initialized
INFO - 2021-06-03 07:05:03 --> Config Class Initialized
INFO - 2021-06-03 07:05:03 --> Loader Class Initialized
INFO - 2021-06-03 07:05:03 --> Helper loaded: url_helper
INFO - 2021-06-03 07:05:03 --> Helper loaded: file_helper
INFO - 2021-06-03 07:05:03 --> Helper loaded: form_helper
INFO - 2021-06-03 07:05:03 --> Helper loaded: my_helper
INFO - 2021-06-03 07:05:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:05:03 --> Controller Class Initialized
DEBUG - 2021-06-03 07:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 07:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:05:03 --> Final output sent to browser
DEBUG - 2021-06-03 07:05:03 --> Total execution time: 0.0637
INFO - 2021-06-03 07:05:06 --> Config Class Initialized
INFO - 2021-06-03 07:05:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:05:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:05:06 --> Utf8 Class Initialized
INFO - 2021-06-03 07:05:06 --> URI Class Initialized
INFO - 2021-06-03 07:05:06 --> Router Class Initialized
INFO - 2021-06-03 07:05:06 --> Output Class Initialized
INFO - 2021-06-03 07:05:06 --> Security Class Initialized
DEBUG - 2021-06-03 07:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:05:06 --> Input Class Initialized
INFO - 2021-06-03 07:05:06 --> Language Class Initialized
INFO - 2021-06-03 07:05:06 --> Language Class Initialized
INFO - 2021-06-03 07:05:06 --> Config Class Initialized
INFO - 2021-06-03 07:05:06 --> Loader Class Initialized
INFO - 2021-06-03 07:05:06 --> Helper loaded: url_helper
INFO - 2021-06-03 07:05:06 --> Helper loaded: file_helper
INFO - 2021-06-03 07:05:06 --> Helper loaded: form_helper
INFO - 2021-06-03 07:05:06 --> Helper loaded: my_helper
INFO - 2021-06-03 07:05:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:05:06 --> Controller Class Initialized
DEBUG - 2021-06-03 07:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-06-03 07:05:06 --> Final output sent to browser
DEBUG - 2021-06-03 07:05:06 --> Total execution time: 0.0891
INFO - 2021-06-03 07:05:24 --> Config Class Initialized
INFO - 2021-06-03 07:05:24 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:05:24 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:05:24 --> Utf8 Class Initialized
INFO - 2021-06-03 07:05:24 --> URI Class Initialized
INFO - 2021-06-03 07:05:24 --> Router Class Initialized
INFO - 2021-06-03 07:05:24 --> Output Class Initialized
INFO - 2021-06-03 07:05:24 --> Security Class Initialized
DEBUG - 2021-06-03 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:05:24 --> Input Class Initialized
INFO - 2021-06-03 07:05:24 --> Language Class Initialized
INFO - 2021-06-03 07:05:24 --> Language Class Initialized
INFO - 2021-06-03 07:05:24 --> Config Class Initialized
INFO - 2021-06-03 07:05:24 --> Loader Class Initialized
INFO - 2021-06-03 07:05:24 --> Helper loaded: url_helper
INFO - 2021-06-03 07:05:24 --> Helper loaded: file_helper
INFO - 2021-06-03 07:05:24 --> Helper loaded: form_helper
INFO - 2021-06-03 07:05:24 --> Helper loaded: my_helper
INFO - 2021-06-03 07:05:24 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:05:24 --> Controller Class Initialized
INFO - 2021-06-03 07:05:24 --> Helper loaded: cookie_helper
INFO - 2021-06-03 07:05:24 --> Config Class Initialized
INFO - 2021-06-03 07:05:24 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:05:24 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:05:24 --> Utf8 Class Initialized
INFO - 2021-06-03 07:05:24 --> URI Class Initialized
INFO - 2021-06-03 07:05:24 --> Router Class Initialized
INFO - 2021-06-03 07:05:24 --> Output Class Initialized
INFO - 2021-06-03 07:05:24 --> Security Class Initialized
DEBUG - 2021-06-03 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:05:24 --> Input Class Initialized
INFO - 2021-06-03 07:05:24 --> Language Class Initialized
INFO - 2021-06-03 07:05:24 --> Language Class Initialized
INFO - 2021-06-03 07:05:24 --> Config Class Initialized
INFO - 2021-06-03 07:05:24 --> Loader Class Initialized
INFO - 2021-06-03 07:05:24 --> Helper loaded: url_helper
INFO - 2021-06-03 07:05:24 --> Helper loaded: file_helper
INFO - 2021-06-03 07:05:24 --> Helper loaded: form_helper
INFO - 2021-06-03 07:05:24 --> Helper loaded: my_helper
INFO - 2021-06-03 07:05:24 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:05:24 --> Controller Class Initialized
DEBUG - 2021-06-03 07:05:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 07:05:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:05:24 --> Final output sent to browser
DEBUG - 2021-06-03 07:05:24 --> Total execution time: 0.0523
INFO - 2021-06-03 07:05:33 --> Config Class Initialized
INFO - 2021-06-03 07:05:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:05:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:05:33 --> Utf8 Class Initialized
INFO - 2021-06-03 07:05:33 --> URI Class Initialized
INFO - 2021-06-03 07:05:33 --> Router Class Initialized
INFO - 2021-06-03 07:05:33 --> Output Class Initialized
INFO - 2021-06-03 07:05:33 --> Security Class Initialized
DEBUG - 2021-06-03 07:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:05:33 --> Input Class Initialized
INFO - 2021-06-03 07:05:33 --> Language Class Initialized
INFO - 2021-06-03 07:05:33 --> Language Class Initialized
INFO - 2021-06-03 07:05:33 --> Config Class Initialized
INFO - 2021-06-03 07:05:33 --> Loader Class Initialized
INFO - 2021-06-03 07:05:33 --> Helper loaded: url_helper
INFO - 2021-06-03 07:05:33 --> Helper loaded: file_helper
INFO - 2021-06-03 07:05:33 --> Helper loaded: form_helper
INFO - 2021-06-03 07:05:33 --> Helper loaded: my_helper
INFO - 2021-06-03 07:05:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:05:33 --> Controller Class Initialized
INFO - 2021-06-03 07:05:33 --> Helper loaded: cookie_helper
INFO - 2021-06-03 07:05:33 --> Final output sent to browser
DEBUG - 2021-06-03 07:05:33 --> Total execution time: 0.0565
INFO - 2021-06-03 07:05:33 --> Config Class Initialized
INFO - 2021-06-03 07:05:33 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:05:33 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:05:33 --> Utf8 Class Initialized
INFO - 2021-06-03 07:05:33 --> URI Class Initialized
INFO - 2021-06-03 07:05:33 --> Router Class Initialized
INFO - 2021-06-03 07:05:33 --> Output Class Initialized
INFO - 2021-06-03 07:05:33 --> Security Class Initialized
DEBUG - 2021-06-03 07:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:05:33 --> Input Class Initialized
INFO - 2021-06-03 07:05:33 --> Language Class Initialized
INFO - 2021-06-03 07:05:33 --> Language Class Initialized
INFO - 2021-06-03 07:05:33 --> Config Class Initialized
INFO - 2021-06-03 07:05:33 --> Loader Class Initialized
INFO - 2021-06-03 07:05:33 --> Helper loaded: url_helper
INFO - 2021-06-03 07:05:33 --> Helper loaded: file_helper
INFO - 2021-06-03 07:05:33 --> Helper loaded: form_helper
INFO - 2021-06-03 07:05:33 --> Helper loaded: my_helper
INFO - 2021-06-03 07:05:33 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:05:34 --> Controller Class Initialized
DEBUG - 2021-06-03 07:05:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 07:05:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:05:34 --> Final output sent to browser
DEBUG - 2021-06-03 07:05:34 --> Total execution time: 0.0923
INFO - 2021-06-03 07:05:35 --> Config Class Initialized
INFO - 2021-06-03 07:05:35 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:05:35 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:05:35 --> Utf8 Class Initialized
INFO - 2021-06-03 07:05:35 --> URI Class Initialized
INFO - 2021-06-03 07:05:35 --> Router Class Initialized
INFO - 2021-06-03 07:05:35 --> Output Class Initialized
INFO - 2021-06-03 07:05:35 --> Security Class Initialized
DEBUG - 2021-06-03 07:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:05:35 --> Input Class Initialized
INFO - 2021-06-03 07:05:35 --> Language Class Initialized
INFO - 2021-06-03 07:05:35 --> Language Class Initialized
INFO - 2021-06-03 07:05:35 --> Config Class Initialized
INFO - 2021-06-03 07:05:35 --> Loader Class Initialized
INFO - 2021-06-03 07:05:35 --> Helper loaded: url_helper
INFO - 2021-06-03 07:05:35 --> Helper loaded: file_helper
INFO - 2021-06-03 07:05:35 --> Helper loaded: form_helper
INFO - 2021-06-03 07:05:35 --> Helper loaded: my_helper
INFO - 2021-06-03 07:05:35 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:05:35 --> Controller Class Initialized
DEBUG - 2021-06-03 07:05:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 07:05:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:05:35 --> Final output sent to browser
DEBUG - 2021-06-03 07:05:35 --> Total execution time: 0.1316
INFO - 2021-06-03 07:06:03 --> Config Class Initialized
INFO - 2021-06-03 07:06:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:06:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:06:03 --> Utf8 Class Initialized
INFO - 2021-06-03 07:06:03 --> URI Class Initialized
INFO - 2021-06-03 07:06:03 --> Router Class Initialized
INFO - 2021-06-03 07:06:03 --> Output Class Initialized
INFO - 2021-06-03 07:06:03 --> Security Class Initialized
DEBUG - 2021-06-03 07:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:06:03 --> Input Class Initialized
INFO - 2021-06-03 07:06:03 --> Language Class Initialized
INFO - 2021-06-03 07:06:03 --> Language Class Initialized
INFO - 2021-06-03 07:06:03 --> Config Class Initialized
INFO - 2021-06-03 07:06:03 --> Loader Class Initialized
INFO - 2021-06-03 07:06:03 --> Helper loaded: url_helper
INFO - 2021-06-03 07:06:03 --> Helper loaded: file_helper
INFO - 2021-06-03 07:06:03 --> Helper loaded: form_helper
INFO - 2021-06-03 07:06:03 --> Helper loaded: my_helper
INFO - 2021-06-03 07:06:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:06:03 --> Controller Class Initialized
INFO - 2021-06-03 07:06:03 --> Final output sent to browser
DEBUG - 2021-06-03 07:06:03 --> Total execution time: 0.1380
INFO - 2021-06-03 07:06:05 --> Config Class Initialized
INFO - 2021-06-03 07:06:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:06:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:06:05 --> Utf8 Class Initialized
INFO - 2021-06-03 07:06:05 --> URI Class Initialized
INFO - 2021-06-03 07:06:05 --> Router Class Initialized
INFO - 2021-06-03 07:06:05 --> Output Class Initialized
INFO - 2021-06-03 07:06:05 --> Security Class Initialized
DEBUG - 2021-06-03 07:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:06:05 --> Input Class Initialized
INFO - 2021-06-03 07:06:05 --> Language Class Initialized
INFO - 2021-06-03 07:06:05 --> Language Class Initialized
INFO - 2021-06-03 07:06:05 --> Config Class Initialized
INFO - 2021-06-03 07:06:05 --> Loader Class Initialized
INFO - 2021-06-03 07:06:05 --> Helper loaded: url_helper
INFO - 2021-06-03 07:06:05 --> Helper loaded: file_helper
INFO - 2021-06-03 07:06:05 --> Helper loaded: form_helper
INFO - 2021-06-03 07:06:05 --> Helper loaded: my_helper
INFO - 2021-06-03 07:06:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:06:05 --> Controller Class Initialized
DEBUG - 2021-06-03 07:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 07:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:06:05 --> Final output sent to browser
DEBUG - 2021-06-03 07:06:05 --> Total execution time: 0.0593
INFO - 2021-06-03 07:06:06 --> Config Class Initialized
INFO - 2021-06-03 07:06:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:06:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:06:06 --> Utf8 Class Initialized
INFO - 2021-06-03 07:06:06 --> URI Class Initialized
INFO - 2021-06-03 07:06:06 --> Router Class Initialized
INFO - 2021-06-03 07:06:06 --> Output Class Initialized
INFO - 2021-06-03 07:06:06 --> Security Class Initialized
DEBUG - 2021-06-03 07:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:06:06 --> Input Class Initialized
INFO - 2021-06-03 07:06:06 --> Language Class Initialized
INFO - 2021-06-03 07:06:06 --> Language Class Initialized
INFO - 2021-06-03 07:06:06 --> Config Class Initialized
INFO - 2021-06-03 07:06:06 --> Loader Class Initialized
INFO - 2021-06-03 07:06:06 --> Helper loaded: url_helper
INFO - 2021-06-03 07:06:06 --> Helper loaded: file_helper
INFO - 2021-06-03 07:06:06 --> Helper loaded: form_helper
INFO - 2021-06-03 07:06:06 --> Helper loaded: my_helper
INFO - 2021-06-03 07:06:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:06:06 --> Controller Class Initialized
DEBUG - 2021-06-03 07:06:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 07:06:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:06:06 --> Final output sent to browser
DEBUG - 2021-06-03 07:06:06 --> Total execution time: 0.0773
INFO - 2021-06-03 07:06:09 --> Config Class Initialized
INFO - 2021-06-03 07:06:09 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:06:09 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:06:09 --> Utf8 Class Initialized
INFO - 2021-06-03 07:06:09 --> URI Class Initialized
INFO - 2021-06-03 07:06:09 --> Router Class Initialized
INFO - 2021-06-03 07:06:09 --> Output Class Initialized
INFO - 2021-06-03 07:06:09 --> Security Class Initialized
DEBUG - 2021-06-03 07:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:06:09 --> Input Class Initialized
INFO - 2021-06-03 07:06:09 --> Language Class Initialized
INFO - 2021-06-03 07:06:09 --> Language Class Initialized
INFO - 2021-06-03 07:06:09 --> Config Class Initialized
INFO - 2021-06-03 07:06:09 --> Loader Class Initialized
INFO - 2021-06-03 07:06:09 --> Helper loaded: url_helper
INFO - 2021-06-03 07:06:09 --> Helper loaded: file_helper
INFO - 2021-06-03 07:06:09 --> Helper loaded: form_helper
INFO - 2021-06-03 07:06:09 --> Helper loaded: my_helper
INFO - 2021-06-03 07:06:09 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:06:09 --> Controller Class Initialized
DEBUG - 2021-06-03 07:06:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 07:06:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:06:09 --> Final output sent to browser
DEBUG - 2021-06-03 07:06:09 --> Total execution time: 0.0774
INFO - 2021-06-03 07:06:10 --> Config Class Initialized
INFO - 2021-06-03 07:06:10 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:06:10 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:06:10 --> Utf8 Class Initialized
INFO - 2021-06-03 07:06:10 --> URI Class Initialized
INFO - 2021-06-03 07:06:10 --> Router Class Initialized
INFO - 2021-06-03 07:06:10 --> Output Class Initialized
INFO - 2021-06-03 07:06:10 --> Security Class Initialized
DEBUG - 2021-06-03 07:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:06:10 --> Input Class Initialized
INFO - 2021-06-03 07:06:10 --> Language Class Initialized
INFO - 2021-06-03 07:06:10 --> Language Class Initialized
INFO - 2021-06-03 07:06:10 --> Config Class Initialized
INFO - 2021-06-03 07:06:10 --> Loader Class Initialized
INFO - 2021-06-03 07:06:10 --> Helper loaded: url_helper
INFO - 2021-06-03 07:06:10 --> Helper loaded: file_helper
INFO - 2021-06-03 07:06:10 --> Helper loaded: form_helper
INFO - 2021-06-03 07:06:10 --> Helper loaded: my_helper
INFO - 2021-06-03 07:06:10 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:06:10 --> Controller Class Initialized
DEBUG - 2021-06-03 07:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 07:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:06:10 --> Final output sent to browser
DEBUG - 2021-06-03 07:06:10 --> Total execution time: 0.0772
INFO - 2021-06-03 07:06:15 --> Config Class Initialized
INFO - 2021-06-03 07:06:15 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:06:15 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:06:15 --> Utf8 Class Initialized
INFO - 2021-06-03 07:06:15 --> URI Class Initialized
INFO - 2021-06-03 07:06:15 --> Router Class Initialized
INFO - 2021-06-03 07:06:15 --> Output Class Initialized
INFO - 2021-06-03 07:06:15 --> Security Class Initialized
DEBUG - 2021-06-03 07:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:06:15 --> Input Class Initialized
INFO - 2021-06-03 07:06:15 --> Language Class Initialized
INFO - 2021-06-03 07:06:15 --> Language Class Initialized
INFO - 2021-06-03 07:06:15 --> Config Class Initialized
INFO - 2021-06-03 07:06:15 --> Loader Class Initialized
INFO - 2021-06-03 07:06:15 --> Helper loaded: url_helper
INFO - 2021-06-03 07:06:15 --> Helper loaded: file_helper
INFO - 2021-06-03 07:06:15 --> Helper loaded: form_helper
INFO - 2021-06-03 07:06:15 --> Helper loaded: my_helper
INFO - 2021-06-03 07:06:15 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:06:15 --> Controller Class Initialized
INFO - 2021-06-03 07:06:15 --> Final output sent to browser
DEBUG - 2021-06-03 07:06:15 --> Total execution time: 0.1286
INFO - 2021-06-03 07:06:19 --> Config Class Initialized
INFO - 2021-06-03 07:06:19 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:06:19 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:06:19 --> Utf8 Class Initialized
INFO - 2021-06-03 07:06:19 --> URI Class Initialized
INFO - 2021-06-03 07:06:19 --> Router Class Initialized
INFO - 2021-06-03 07:06:19 --> Output Class Initialized
INFO - 2021-06-03 07:06:19 --> Security Class Initialized
DEBUG - 2021-06-03 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:06:19 --> Input Class Initialized
INFO - 2021-06-03 07:06:19 --> Language Class Initialized
INFO - 2021-06-03 07:06:19 --> Language Class Initialized
INFO - 2021-06-03 07:06:19 --> Config Class Initialized
INFO - 2021-06-03 07:06:19 --> Loader Class Initialized
INFO - 2021-06-03 07:06:19 --> Helper loaded: url_helper
INFO - 2021-06-03 07:06:19 --> Helper loaded: file_helper
INFO - 2021-06-03 07:06:19 --> Helper loaded: form_helper
INFO - 2021-06-03 07:06:19 --> Helper loaded: my_helper
INFO - 2021-06-03 07:06:19 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:06:19 --> Controller Class Initialized
DEBUG - 2021-06-03 07:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 07:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:06:19 --> Final output sent to browser
DEBUG - 2021-06-03 07:06:19 --> Total execution time: 0.0815
INFO - 2021-06-03 07:06:21 --> Config Class Initialized
INFO - 2021-06-03 07:06:21 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:06:21 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:06:21 --> Utf8 Class Initialized
INFO - 2021-06-03 07:06:21 --> URI Class Initialized
INFO - 2021-06-03 07:06:21 --> Router Class Initialized
INFO - 2021-06-03 07:06:21 --> Output Class Initialized
INFO - 2021-06-03 07:06:21 --> Security Class Initialized
DEBUG - 2021-06-03 07:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:06:21 --> Input Class Initialized
INFO - 2021-06-03 07:06:21 --> Language Class Initialized
INFO - 2021-06-03 07:06:21 --> Language Class Initialized
INFO - 2021-06-03 07:06:21 --> Config Class Initialized
INFO - 2021-06-03 07:06:21 --> Loader Class Initialized
INFO - 2021-06-03 07:06:21 --> Helper loaded: url_helper
INFO - 2021-06-03 07:06:21 --> Helper loaded: file_helper
INFO - 2021-06-03 07:06:21 --> Helper loaded: form_helper
INFO - 2021-06-03 07:06:21 --> Helper loaded: my_helper
INFO - 2021-06-03 07:06:21 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:06:21 --> Controller Class Initialized
DEBUG - 2021-06-03 07:06:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-06-03 07:06:21 --> Final output sent to browser
DEBUG - 2021-06-03 07:06:21 --> Total execution time: 0.0810
INFO - 2021-06-03 07:06:45 --> Config Class Initialized
INFO - 2021-06-03 07:06:45 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:06:45 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:06:45 --> Utf8 Class Initialized
INFO - 2021-06-03 07:06:45 --> URI Class Initialized
INFO - 2021-06-03 07:06:45 --> Router Class Initialized
INFO - 2021-06-03 07:06:45 --> Output Class Initialized
INFO - 2021-06-03 07:06:45 --> Security Class Initialized
DEBUG - 2021-06-03 07:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:06:45 --> Input Class Initialized
INFO - 2021-06-03 07:06:45 --> Language Class Initialized
INFO - 2021-06-03 07:06:45 --> Language Class Initialized
INFO - 2021-06-03 07:06:45 --> Config Class Initialized
INFO - 2021-06-03 07:06:45 --> Loader Class Initialized
INFO - 2021-06-03 07:06:45 --> Helper loaded: url_helper
INFO - 2021-06-03 07:06:45 --> Helper loaded: file_helper
INFO - 2021-06-03 07:06:45 --> Helper loaded: form_helper
INFO - 2021-06-03 07:06:45 --> Helper loaded: my_helper
INFO - 2021-06-03 07:06:45 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:06:45 --> Controller Class Initialized
DEBUG - 2021-06-03 07:06:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-06-03 07:06:45 --> Final output sent to browser
DEBUG - 2021-06-03 07:06:45 --> Total execution time: 0.0722
INFO - 2021-06-03 07:07:23 --> Config Class Initialized
INFO - 2021-06-03 07:07:23 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:07:23 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:07:23 --> Utf8 Class Initialized
INFO - 2021-06-03 07:07:23 --> URI Class Initialized
INFO - 2021-06-03 07:07:23 --> Router Class Initialized
INFO - 2021-06-03 07:07:23 --> Output Class Initialized
INFO - 2021-06-03 07:07:23 --> Security Class Initialized
DEBUG - 2021-06-03 07:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:07:23 --> Input Class Initialized
INFO - 2021-06-03 07:07:23 --> Language Class Initialized
INFO - 2021-06-03 07:07:23 --> Language Class Initialized
INFO - 2021-06-03 07:07:23 --> Config Class Initialized
INFO - 2021-06-03 07:07:23 --> Loader Class Initialized
INFO - 2021-06-03 07:07:23 --> Helper loaded: url_helper
INFO - 2021-06-03 07:07:23 --> Helper loaded: file_helper
INFO - 2021-06-03 07:07:23 --> Helper loaded: form_helper
INFO - 2021-06-03 07:07:23 --> Helper loaded: my_helper
INFO - 2021-06-03 07:07:23 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:07:23 --> Controller Class Initialized
INFO - 2021-06-03 07:07:23 --> Helper loaded: cookie_helper
INFO - 2021-06-03 07:07:23 --> Config Class Initialized
INFO - 2021-06-03 07:07:23 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:07:23 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:07:23 --> Utf8 Class Initialized
INFO - 2021-06-03 07:07:23 --> URI Class Initialized
INFO - 2021-06-03 07:07:23 --> Router Class Initialized
INFO - 2021-06-03 07:07:23 --> Output Class Initialized
INFO - 2021-06-03 07:07:23 --> Security Class Initialized
DEBUG - 2021-06-03 07:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:07:23 --> Input Class Initialized
INFO - 2021-06-03 07:07:23 --> Language Class Initialized
INFO - 2021-06-03 07:07:23 --> Language Class Initialized
INFO - 2021-06-03 07:07:23 --> Config Class Initialized
INFO - 2021-06-03 07:07:23 --> Loader Class Initialized
INFO - 2021-06-03 07:07:23 --> Helper loaded: url_helper
INFO - 2021-06-03 07:07:23 --> Helper loaded: file_helper
INFO - 2021-06-03 07:07:23 --> Helper loaded: form_helper
INFO - 2021-06-03 07:07:23 --> Helper loaded: my_helper
INFO - 2021-06-03 07:07:23 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:07:23 --> Controller Class Initialized
DEBUG - 2021-06-03 07:07:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 07:07:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:07:23 --> Final output sent to browser
DEBUG - 2021-06-03 07:07:23 --> Total execution time: 0.0696
INFO - 2021-06-03 07:07:28 --> Config Class Initialized
INFO - 2021-06-03 07:07:28 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:07:28 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:07:28 --> Utf8 Class Initialized
INFO - 2021-06-03 07:07:28 --> URI Class Initialized
INFO - 2021-06-03 07:07:28 --> Router Class Initialized
INFO - 2021-06-03 07:07:28 --> Output Class Initialized
INFO - 2021-06-03 07:07:28 --> Security Class Initialized
DEBUG - 2021-06-03 07:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:07:28 --> Input Class Initialized
INFO - 2021-06-03 07:07:28 --> Language Class Initialized
INFO - 2021-06-03 07:07:28 --> Language Class Initialized
INFO - 2021-06-03 07:07:28 --> Config Class Initialized
INFO - 2021-06-03 07:07:28 --> Loader Class Initialized
INFO - 2021-06-03 07:07:28 --> Helper loaded: url_helper
INFO - 2021-06-03 07:07:28 --> Helper loaded: file_helper
INFO - 2021-06-03 07:07:28 --> Helper loaded: form_helper
INFO - 2021-06-03 07:07:28 --> Helper loaded: my_helper
INFO - 2021-06-03 07:07:28 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:07:28 --> Controller Class Initialized
INFO - 2021-06-03 07:07:28 --> Helper loaded: cookie_helper
INFO - 2021-06-03 07:07:28 --> Final output sent to browser
DEBUG - 2021-06-03 07:07:28 --> Total execution time: 0.0783
INFO - 2021-06-03 07:07:29 --> Config Class Initialized
INFO - 2021-06-03 07:07:29 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:07:29 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:07:29 --> Utf8 Class Initialized
INFO - 2021-06-03 07:07:29 --> URI Class Initialized
INFO - 2021-06-03 07:07:29 --> Router Class Initialized
INFO - 2021-06-03 07:07:29 --> Output Class Initialized
INFO - 2021-06-03 07:07:29 --> Security Class Initialized
DEBUG - 2021-06-03 07:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:07:29 --> Input Class Initialized
INFO - 2021-06-03 07:07:29 --> Language Class Initialized
INFO - 2021-06-03 07:07:29 --> Language Class Initialized
INFO - 2021-06-03 07:07:29 --> Config Class Initialized
INFO - 2021-06-03 07:07:29 --> Loader Class Initialized
INFO - 2021-06-03 07:07:29 --> Helper loaded: url_helper
INFO - 2021-06-03 07:07:29 --> Helper loaded: file_helper
INFO - 2021-06-03 07:07:29 --> Helper loaded: form_helper
INFO - 2021-06-03 07:07:29 --> Helper loaded: my_helper
INFO - 2021-06-03 07:07:29 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:07:29 --> Controller Class Initialized
DEBUG - 2021-06-03 07:07:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 07:07:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:07:29 --> Final output sent to browser
DEBUG - 2021-06-03 07:07:29 --> Total execution time: 0.0857
INFO - 2021-06-03 07:08:47 --> Config Class Initialized
INFO - 2021-06-03 07:08:47 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:08:47 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:08:47 --> Utf8 Class Initialized
INFO - 2021-06-03 07:08:47 --> URI Class Initialized
INFO - 2021-06-03 07:08:47 --> Router Class Initialized
INFO - 2021-06-03 07:08:47 --> Output Class Initialized
INFO - 2021-06-03 07:08:47 --> Security Class Initialized
DEBUG - 2021-06-03 07:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:08:47 --> Input Class Initialized
INFO - 2021-06-03 07:08:47 --> Language Class Initialized
INFO - 2021-06-03 07:08:47 --> Language Class Initialized
INFO - 2021-06-03 07:08:47 --> Config Class Initialized
INFO - 2021-06-03 07:08:47 --> Loader Class Initialized
INFO - 2021-06-03 07:08:47 --> Helper loaded: url_helper
INFO - 2021-06-03 07:08:47 --> Helper loaded: file_helper
INFO - 2021-06-03 07:08:47 --> Helper loaded: form_helper
INFO - 2021-06-03 07:08:47 --> Helper loaded: my_helper
INFO - 2021-06-03 07:08:47 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:08:47 --> Controller Class Initialized
DEBUG - 2021-06-03 07:08:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-06-03 07:08:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:08:47 --> Final output sent to browser
DEBUG - 2021-06-03 07:08:47 --> Total execution time: 0.0862
INFO - 2021-06-03 07:08:48 --> Config Class Initialized
INFO - 2021-06-03 07:08:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:08:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:08:48 --> Utf8 Class Initialized
INFO - 2021-06-03 07:08:48 --> URI Class Initialized
INFO - 2021-06-03 07:08:48 --> Router Class Initialized
INFO - 2021-06-03 07:08:48 --> Output Class Initialized
INFO - 2021-06-03 07:08:48 --> Security Class Initialized
DEBUG - 2021-06-03 07:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:08:48 --> Input Class Initialized
INFO - 2021-06-03 07:08:48 --> Language Class Initialized
INFO - 2021-06-03 07:08:48 --> Language Class Initialized
INFO - 2021-06-03 07:08:48 --> Config Class Initialized
INFO - 2021-06-03 07:08:48 --> Loader Class Initialized
INFO - 2021-06-03 07:08:48 --> Helper loaded: url_helper
INFO - 2021-06-03 07:08:48 --> Helper loaded: file_helper
INFO - 2021-06-03 07:08:48 --> Helper loaded: form_helper
INFO - 2021-06-03 07:08:48 --> Helper loaded: my_helper
INFO - 2021-06-03 07:08:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:08:48 --> Controller Class Initialized
DEBUG - 2021-06-03 07:08:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-06-03 07:08:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:08:48 --> Final output sent to browser
DEBUG - 2021-06-03 07:08:48 --> Total execution time: 0.0956
INFO - 2021-06-03 07:09:01 --> Config Class Initialized
INFO - 2021-06-03 07:09:01 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:01 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:01 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:01 --> URI Class Initialized
INFO - 2021-06-03 07:09:01 --> Router Class Initialized
INFO - 2021-06-03 07:09:01 --> Output Class Initialized
INFO - 2021-06-03 07:09:01 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:01 --> Input Class Initialized
INFO - 2021-06-03 07:09:01 --> Language Class Initialized
INFO - 2021-06-03 07:09:01 --> Language Class Initialized
INFO - 2021-06-03 07:09:01 --> Config Class Initialized
INFO - 2021-06-03 07:09:01 --> Loader Class Initialized
INFO - 2021-06-03 07:09:01 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:01 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:01 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:01 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:01 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:01 --> Controller Class Initialized
INFO - 2021-06-03 07:09:01 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:01 --> Total execution time: 0.0977
INFO - 2021-06-03 07:09:03 --> Config Class Initialized
INFO - 2021-06-03 07:09:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:03 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:03 --> URI Class Initialized
INFO - 2021-06-03 07:09:03 --> Router Class Initialized
INFO - 2021-06-03 07:09:03 --> Output Class Initialized
INFO - 2021-06-03 07:09:03 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:03 --> Input Class Initialized
INFO - 2021-06-03 07:09:03 --> Language Class Initialized
INFO - 2021-06-03 07:09:03 --> Language Class Initialized
INFO - 2021-06-03 07:09:03 --> Config Class Initialized
INFO - 2021-06-03 07:09:03 --> Loader Class Initialized
INFO - 2021-06-03 07:09:03 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:03 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:03 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:03 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:03 --> Controller Class Initialized
DEBUG - 2021-06-03 07:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-06-03 07:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:09:03 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:03 --> Total execution time: 0.0865
INFO - 2021-06-03 07:09:04 --> Config Class Initialized
INFO - 2021-06-03 07:09:04 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:04 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:04 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:04 --> URI Class Initialized
INFO - 2021-06-03 07:09:04 --> Router Class Initialized
INFO - 2021-06-03 07:09:04 --> Output Class Initialized
INFO - 2021-06-03 07:09:04 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:04 --> Input Class Initialized
INFO - 2021-06-03 07:09:04 --> Language Class Initialized
INFO - 2021-06-03 07:09:04 --> Language Class Initialized
INFO - 2021-06-03 07:09:04 --> Config Class Initialized
INFO - 2021-06-03 07:09:04 --> Loader Class Initialized
INFO - 2021-06-03 07:09:04 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:04 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:04 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:04 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:04 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:04 --> Controller Class Initialized
DEBUG - 2021-06-03 07:09:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-06-03 07:09:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:09:04 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:04 --> Total execution time: 0.0618
INFO - 2021-06-03 07:09:05 --> Config Class Initialized
INFO - 2021-06-03 07:09:05 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:05 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:05 --> URI Class Initialized
INFO - 2021-06-03 07:09:05 --> Router Class Initialized
INFO - 2021-06-03 07:09:05 --> Output Class Initialized
INFO - 2021-06-03 07:09:05 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:05 --> Input Class Initialized
INFO - 2021-06-03 07:09:05 --> Language Class Initialized
INFO - 2021-06-03 07:09:05 --> Language Class Initialized
INFO - 2021-06-03 07:09:05 --> Config Class Initialized
INFO - 2021-06-03 07:09:05 --> Loader Class Initialized
INFO - 2021-06-03 07:09:05 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:05 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:05 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:05 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:05 --> Controller Class Initialized
DEBUG - 2021-06-03 07:09:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-06-03 07:09:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:09:05 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:05 --> Total execution time: 0.0552
INFO - 2021-06-03 07:09:06 --> Config Class Initialized
INFO - 2021-06-03 07:09:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:06 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:06 --> URI Class Initialized
INFO - 2021-06-03 07:09:06 --> Router Class Initialized
INFO - 2021-06-03 07:09:06 --> Output Class Initialized
INFO - 2021-06-03 07:09:06 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:06 --> Input Class Initialized
INFO - 2021-06-03 07:09:06 --> Language Class Initialized
INFO - 2021-06-03 07:09:06 --> Language Class Initialized
INFO - 2021-06-03 07:09:06 --> Config Class Initialized
INFO - 2021-06-03 07:09:06 --> Loader Class Initialized
INFO - 2021-06-03 07:09:06 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:06 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:06 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:06 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:06 --> Controller Class Initialized
DEBUG - 2021-06-03 07:09:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-06-03 07:09:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:09:06 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:06 --> Total execution time: 0.0830
INFO - 2021-06-03 07:09:09 --> Config Class Initialized
INFO - 2021-06-03 07:09:09 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:09 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:09 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:09 --> URI Class Initialized
INFO - 2021-06-03 07:09:09 --> Router Class Initialized
INFO - 2021-06-03 07:09:09 --> Output Class Initialized
INFO - 2021-06-03 07:09:09 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:09 --> Input Class Initialized
INFO - 2021-06-03 07:09:09 --> Language Class Initialized
INFO - 2021-06-03 07:09:09 --> Language Class Initialized
INFO - 2021-06-03 07:09:09 --> Config Class Initialized
INFO - 2021-06-03 07:09:09 --> Loader Class Initialized
INFO - 2021-06-03 07:09:09 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:09 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:09 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:09 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:09 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:09 --> Controller Class Initialized
INFO - 2021-06-03 07:09:09 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:09 --> Total execution time: 0.0932
INFO - 2021-06-03 07:09:11 --> Config Class Initialized
INFO - 2021-06-03 07:09:11 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:11 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:11 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:11 --> URI Class Initialized
INFO - 2021-06-03 07:09:11 --> Router Class Initialized
INFO - 2021-06-03 07:09:11 --> Output Class Initialized
INFO - 2021-06-03 07:09:11 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:11 --> Input Class Initialized
INFO - 2021-06-03 07:09:11 --> Language Class Initialized
INFO - 2021-06-03 07:09:11 --> Language Class Initialized
INFO - 2021-06-03 07:09:11 --> Config Class Initialized
INFO - 2021-06-03 07:09:11 --> Loader Class Initialized
INFO - 2021-06-03 07:09:11 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:11 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:11 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:11 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:11 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:11 --> Controller Class Initialized
DEBUG - 2021-06-03 07:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 07:09:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:09:11 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:11 --> Total execution time: 0.0875
INFO - 2021-06-03 07:09:13 --> Config Class Initialized
INFO - 2021-06-03 07:09:13 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:13 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:13 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:13 --> URI Class Initialized
INFO - 2021-06-03 07:09:13 --> Router Class Initialized
INFO - 2021-06-03 07:09:13 --> Output Class Initialized
INFO - 2021-06-03 07:09:13 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:13 --> Input Class Initialized
INFO - 2021-06-03 07:09:13 --> Language Class Initialized
INFO - 2021-06-03 07:09:13 --> Language Class Initialized
INFO - 2021-06-03 07:09:13 --> Config Class Initialized
INFO - 2021-06-03 07:09:13 --> Loader Class Initialized
INFO - 2021-06-03 07:09:13 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:13 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:13 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:13 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:13 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:13 --> Controller Class Initialized
DEBUG - 2021-06-03 07:09:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-06-03 07:09:13 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:13 --> Total execution time: 0.0961
INFO - 2021-06-03 07:09:36 --> Config Class Initialized
INFO - 2021-06-03 07:09:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:36 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:36 --> URI Class Initialized
INFO - 2021-06-03 07:09:36 --> Router Class Initialized
INFO - 2021-06-03 07:09:36 --> Output Class Initialized
INFO - 2021-06-03 07:09:36 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:36 --> Input Class Initialized
INFO - 2021-06-03 07:09:36 --> Language Class Initialized
INFO - 2021-06-03 07:09:36 --> Language Class Initialized
INFO - 2021-06-03 07:09:36 --> Config Class Initialized
INFO - 2021-06-03 07:09:36 --> Loader Class Initialized
INFO - 2021-06-03 07:09:36 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:36 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:36 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:36 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:36 --> Controller Class Initialized
DEBUG - 2021-06-03 07:09:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-06-03 07:09:36 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:36 --> Total execution time: 0.0712
INFO - 2021-06-03 07:09:57 --> Config Class Initialized
INFO - 2021-06-03 07:09:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:57 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:57 --> URI Class Initialized
INFO - 2021-06-03 07:09:57 --> Router Class Initialized
INFO - 2021-06-03 07:09:57 --> Output Class Initialized
INFO - 2021-06-03 07:09:57 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:57 --> Input Class Initialized
INFO - 2021-06-03 07:09:57 --> Language Class Initialized
INFO - 2021-06-03 07:09:57 --> Language Class Initialized
INFO - 2021-06-03 07:09:57 --> Config Class Initialized
INFO - 2021-06-03 07:09:57 --> Loader Class Initialized
INFO - 2021-06-03 07:09:57 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:57 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:57 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:57 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:57 --> Controller Class Initialized
INFO - 2021-06-03 07:09:57 --> Helper loaded: cookie_helper
INFO - 2021-06-03 07:09:57 --> Config Class Initialized
INFO - 2021-06-03 07:09:57 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:09:57 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:09:57 --> Utf8 Class Initialized
INFO - 2021-06-03 07:09:57 --> URI Class Initialized
INFO - 2021-06-03 07:09:57 --> Router Class Initialized
INFO - 2021-06-03 07:09:57 --> Output Class Initialized
INFO - 2021-06-03 07:09:57 --> Security Class Initialized
DEBUG - 2021-06-03 07:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:09:57 --> Input Class Initialized
INFO - 2021-06-03 07:09:57 --> Language Class Initialized
INFO - 2021-06-03 07:09:57 --> Language Class Initialized
INFO - 2021-06-03 07:09:57 --> Config Class Initialized
INFO - 2021-06-03 07:09:57 --> Loader Class Initialized
INFO - 2021-06-03 07:09:57 --> Helper loaded: url_helper
INFO - 2021-06-03 07:09:57 --> Helper loaded: file_helper
INFO - 2021-06-03 07:09:57 --> Helper loaded: form_helper
INFO - 2021-06-03 07:09:57 --> Helper loaded: my_helper
INFO - 2021-06-03 07:09:57 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:09:58 --> Controller Class Initialized
DEBUG - 2021-06-03 07:09:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 07:09:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:09:58 --> Final output sent to browser
DEBUG - 2021-06-03 07:09:58 --> Total execution time: 0.0920
INFO - 2021-06-03 07:10:03 --> Config Class Initialized
INFO - 2021-06-03 07:10:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:10:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:10:03 --> Utf8 Class Initialized
INFO - 2021-06-03 07:10:03 --> URI Class Initialized
INFO - 2021-06-03 07:10:03 --> Router Class Initialized
INFO - 2021-06-03 07:10:03 --> Output Class Initialized
INFO - 2021-06-03 07:10:03 --> Security Class Initialized
DEBUG - 2021-06-03 07:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:10:03 --> Input Class Initialized
INFO - 2021-06-03 07:10:03 --> Language Class Initialized
INFO - 2021-06-03 07:10:03 --> Language Class Initialized
INFO - 2021-06-03 07:10:03 --> Config Class Initialized
INFO - 2021-06-03 07:10:03 --> Loader Class Initialized
INFO - 2021-06-03 07:10:03 --> Helper loaded: url_helper
INFO - 2021-06-03 07:10:03 --> Helper loaded: file_helper
INFO - 2021-06-03 07:10:03 --> Helper loaded: form_helper
INFO - 2021-06-03 07:10:03 --> Helper loaded: my_helper
INFO - 2021-06-03 07:10:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:10:03 --> Controller Class Initialized
INFO - 2021-06-03 07:10:03 --> Helper loaded: cookie_helper
INFO - 2021-06-03 07:10:03 --> Final output sent to browser
DEBUG - 2021-06-03 07:10:03 --> Total execution time: 0.0959
INFO - 2021-06-03 07:10:03 --> Config Class Initialized
INFO - 2021-06-03 07:10:03 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:10:03 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:10:03 --> Utf8 Class Initialized
INFO - 2021-06-03 07:10:03 --> URI Class Initialized
INFO - 2021-06-03 07:10:03 --> Router Class Initialized
INFO - 2021-06-03 07:10:03 --> Output Class Initialized
INFO - 2021-06-03 07:10:03 --> Security Class Initialized
DEBUG - 2021-06-03 07:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:10:03 --> Input Class Initialized
INFO - 2021-06-03 07:10:03 --> Language Class Initialized
INFO - 2021-06-03 07:10:03 --> Language Class Initialized
INFO - 2021-06-03 07:10:03 --> Config Class Initialized
INFO - 2021-06-03 07:10:03 --> Loader Class Initialized
INFO - 2021-06-03 07:10:03 --> Helper loaded: url_helper
INFO - 2021-06-03 07:10:03 --> Helper loaded: file_helper
INFO - 2021-06-03 07:10:03 --> Helper loaded: form_helper
INFO - 2021-06-03 07:10:03 --> Helper loaded: my_helper
INFO - 2021-06-03 07:10:03 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:10:03 --> Controller Class Initialized
DEBUG - 2021-06-03 07:10:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 07:10:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:10:03 --> Final output sent to browser
DEBUG - 2021-06-03 07:10:03 --> Total execution time: 0.0832
INFO - 2021-06-03 07:10:04 --> Config Class Initialized
INFO - 2021-06-03 07:10:04 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:10:05 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:10:05 --> Utf8 Class Initialized
INFO - 2021-06-03 07:10:05 --> URI Class Initialized
INFO - 2021-06-03 07:10:05 --> Router Class Initialized
INFO - 2021-06-03 07:10:05 --> Output Class Initialized
INFO - 2021-06-03 07:10:05 --> Security Class Initialized
DEBUG - 2021-06-03 07:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:10:05 --> Input Class Initialized
INFO - 2021-06-03 07:10:05 --> Language Class Initialized
INFO - 2021-06-03 07:10:05 --> Language Class Initialized
INFO - 2021-06-03 07:10:05 --> Config Class Initialized
INFO - 2021-06-03 07:10:05 --> Loader Class Initialized
INFO - 2021-06-03 07:10:05 --> Helper loaded: url_helper
INFO - 2021-06-03 07:10:05 --> Helper loaded: file_helper
INFO - 2021-06-03 07:10:05 --> Helper loaded: form_helper
INFO - 2021-06-03 07:10:05 --> Helper loaded: my_helper
INFO - 2021-06-03 07:10:05 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:10:05 --> Controller Class Initialized
DEBUG - 2021-06-03 07:10:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-03 07:10:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:10:05 --> Final output sent to browser
DEBUG - 2021-06-03 07:10:05 --> Total execution time: 0.1048
INFO - 2021-06-03 07:10:06 --> Config Class Initialized
INFO - 2021-06-03 07:10:06 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:10:06 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:10:06 --> Utf8 Class Initialized
INFO - 2021-06-03 07:10:06 --> URI Class Initialized
INFO - 2021-06-03 07:10:06 --> Router Class Initialized
INFO - 2021-06-03 07:10:06 --> Output Class Initialized
INFO - 2021-06-03 07:10:06 --> Security Class Initialized
DEBUG - 2021-06-03 07:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:10:06 --> Input Class Initialized
INFO - 2021-06-03 07:10:06 --> Language Class Initialized
INFO - 2021-06-03 07:10:06 --> Language Class Initialized
INFO - 2021-06-03 07:10:06 --> Config Class Initialized
INFO - 2021-06-03 07:10:06 --> Loader Class Initialized
INFO - 2021-06-03 07:10:06 --> Helper loaded: url_helper
INFO - 2021-06-03 07:10:06 --> Helper loaded: file_helper
INFO - 2021-06-03 07:10:06 --> Helper loaded: form_helper
INFO - 2021-06-03 07:10:06 --> Helper loaded: my_helper
INFO - 2021-06-03 07:10:06 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:10:06 --> Controller Class Initialized
DEBUG - 2021-06-03 07:10:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-03 07:10:06 --> Final output sent to browser
DEBUG - 2021-06-03 07:10:06 --> Total execution time: 0.1066
INFO - 2021-06-03 07:10:27 --> Config Class Initialized
INFO - 2021-06-03 07:10:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:10:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:10:27 --> Utf8 Class Initialized
INFO - 2021-06-03 07:10:27 --> URI Class Initialized
INFO - 2021-06-03 07:10:27 --> Router Class Initialized
INFO - 2021-06-03 07:10:27 --> Output Class Initialized
INFO - 2021-06-03 07:10:27 --> Security Class Initialized
DEBUG - 2021-06-03 07:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:10:27 --> Input Class Initialized
INFO - 2021-06-03 07:10:27 --> Language Class Initialized
INFO - 2021-06-03 07:10:27 --> Language Class Initialized
INFO - 2021-06-03 07:10:27 --> Config Class Initialized
INFO - 2021-06-03 07:10:27 --> Loader Class Initialized
INFO - 2021-06-03 07:10:27 --> Helper loaded: url_helper
INFO - 2021-06-03 07:10:27 --> Helper loaded: file_helper
INFO - 2021-06-03 07:10:27 --> Helper loaded: form_helper
INFO - 2021-06-03 07:10:27 --> Helper loaded: my_helper
INFO - 2021-06-03 07:10:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:10:27 --> Controller Class Initialized
INFO - 2021-06-03 07:10:27 --> Helper loaded: cookie_helper
INFO - 2021-06-03 07:10:27 --> Config Class Initialized
INFO - 2021-06-03 07:10:27 --> Hooks Class Initialized
DEBUG - 2021-06-03 07:10:27 --> UTF-8 Support Enabled
INFO - 2021-06-03 07:10:27 --> Utf8 Class Initialized
INFO - 2021-06-03 07:10:27 --> URI Class Initialized
INFO - 2021-06-03 07:10:27 --> Router Class Initialized
INFO - 2021-06-03 07:10:27 --> Output Class Initialized
INFO - 2021-06-03 07:10:27 --> Security Class Initialized
DEBUG - 2021-06-03 07:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 07:10:27 --> Input Class Initialized
INFO - 2021-06-03 07:10:27 --> Language Class Initialized
INFO - 2021-06-03 07:10:27 --> Language Class Initialized
INFO - 2021-06-03 07:10:27 --> Config Class Initialized
INFO - 2021-06-03 07:10:27 --> Loader Class Initialized
INFO - 2021-06-03 07:10:27 --> Helper loaded: url_helper
INFO - 2021-06-03 07:10:27 --> Helper loaded: file_helper
INFO - 2021-06-03 07:10:27 --> Helper loaded: form_helper
INFO - 2021-06-03 07:10:27 --> Helper loaded: my_helper
INFO - 2021-06-03 07:10:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 07:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 07:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 07:10:27 --> Controller Class Initialized
DEBUG - 2021-06-03 07:10:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 07:10:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 07:10:27 --> Final output sent to browser
DEBUG - 2021-06-03 07:10:27 --> Total execution time: 0.0660
INFO - 2021-06-03 08:11:36 --> Config Class Initialized
INFO - 2021-06-03 08:11:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:11:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:11:36 --> Utf8 Class Initialized
INFO - 2021-06-03 08:11:36 --> URI Class Initialized
DEBUG - 2021-06-03 08:11:36 --> No URI present. Default controller set.
INFO - 2021-06-03 08:11:36 --> Router Class Initialized
INFO - 2021-06-03 08:11:36 --> Output Class Initialized
INFO - 2021-06-03 08:11:36 --> Security Class Initialized
DEBUG - 2021-06-03 08:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:11:36 --> Input Class Initialized
INFO - 2021-06-03 08:11:36 --> Language Class Initialized
INFO - 2021-06-03 08:11:36 --> Language Class Initialized
INFO - 2021-06-03 08:11:36 --> Config Class Initialized
INFO - 2021-06-03 08:11:36 --> Loader Class Initialized
INFO - 2021-06-03 08:11:36 --> Helper loaded: url_helper
INFO - 2021-06-03 08:11:36 --> Helper loaded: file_helper
INFO - 2021-06-03 08:11:36 --> Helper loaded: form_helper
INFO - 2021-06-03 08:11:36 --> Helper loaded: my_helper
INFO - 2021-06-03 08:11:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:11:36 --> Controller Class Initialized
INFO - 2021-06-03 08:11:36 --> Config Class Initialized
INFO - 2021-06-03 08:11:36 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:11:36 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:11:36 --> Utf8 Class Initialized
INFO - 2021-06-03 08:11:36 --> URI Class Initialized
INFO - 2021-06-03 08:11:36 --> Router Class Initialized
INFO - 2021-06-03 08:11:36 --> Output Class Initialized
INFO - 2021-06-03 08:11:36 --> Security Class Initialized
DEBUG - 2021-06-03 08:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:11:36 --> Input Class Initialized
INFO - 2021-06-03 08:11:36 --> Language Class Initialized
INFO - 2021-06-03 08:11:36 --> Language Class Initialized
INFO - 2021-06-03 08:11:36 --> Config Class Initialized
INFO - 2021-06-03 08:11:36 --> Loader Class Initialized
INFO - 2021-06-03 08:11:36 --> Helper loaded: url_helper
INFO - 2021-06-03 08:11:36 --> Helper loaded: file_helper
INFO - 2021-06-03 08:11:36 --> Helper loaded: form_helper
INFO - 2021-06-03 08:11:36 --> Helper loaded: my_helper
INFO - 2021-06-03 08:11:36 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:11:36 --> Controller Class Initialized
DEBUG - 2021-06-03 08:11:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 08:11:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 08:11:36 --> Final output sent to browser
DEBUG - 2021-06-03 08:11:36 --> Total execution time: 0.0566
INFO - 2021-06-03 08:11:48 --> Config Class Initialized
INFO - 2021-06-03 08:11:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:11:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:11:48 --> Utf8 Class Initialized
INFO - 2021-06-03 08:11:48 --> URI Class Initialized
INFO - 2021-06-03 08:11:48 --> Router Class Initialized
INFO - 2021-06-03 08:11:48 --> Output Class Initialized
INFO - 2021-06-03 08:11:48 --> Security Class Initialized
DEBUG - 2021-06-03 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:11:48 --> Input Class Initialized
INFO - 2021-06-03 08:11:48 --> Language Class Initialized
INFO - 2021-06-03 08:11:48 --> Language Class Initialized
INFO - 2021-06-03 08:11:48 --> Config Class Initialized
INFO - 2021-06-03 08:11:48 --> Loader Class Initialized
INFO - 2021-06-03 08:11:48 --> Helper loaded: url_helper
INFO - 2021-06-03 08:11:48 --> Helper loaded: file_helper
INFO - 2021-06-03 08:11:48 --> Helper loaded: form_helper
INFO - 2021-06-03 08:11:48 --> Helper loaded: my_helper
INFO - 2021-06-03 08:11:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:11:48 --> Controller Class Initialized
INFO - 2021-06-03 08:11:48 --> Helper loaded: cookie_helper
INFO - 2021-06-03 08:11:48 --> Final output sent to browser
DEBUG - 2021-06-03 08:11:48 --> Total execution time: 0.1428
INFO - 2021-06-03 08:11:49 --> Config Class Initialized
INFO - 2021-06-03 08:11:49 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:11:49 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:11:49 --> Utf8 Class Initialized
INFO - 2021-06-03 08:11:49 --> URI Class Initialized
INFO - 2021-06-03 08:11:49 --> Router Class Initialized
INFO - 2021-06-03 08:11:49 --> Output Class Initialized
INFO - 2021-06-03 08:11:49 --> Security Class Initialized
DEBUG - 2021-06-03 08:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:11:49 --> Input Class Initialized
INFO - 2021-06-03 08:11:49 --> Language Class Initialized
INFO - 2021-06-03 08:11:49 --> Language Class Initialized
INFO - 2021-06-03 08:11:49 --> Config Class Initialized
INFO - 2021-06-03 08:11:49 --> Loader Class Initialized
INFO - 2021-06-03 08:11:49 --> Helper loaded: url_helper
INFO - 2021-06-03 08:11:49 --> Helper loaded: file_helper
INFO - 2021-06-03 08:11:49 --> Helper loaded: form_helper
INFO - 2021-06-03 08:11:49 --> Helper loaded: my_helper
INFO - 2021-06-03 08:11:49 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:11:49 --> Controller Class Initialized
DEBUG - 2021-06-03 08:11:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 08:11:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 08:11:49 --> Final output sent to browser
DEBUG - 2021-06-03 08:11:49 --> Total execution time: 0.1628
INFO - 2021-06-03 08:12:34 --> Config Class Initialized
INFO - 2021-06-03 08:12:34 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:12:34 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:12:34 --> Utf8 Class Initialized
INFO - 2021-06-03 08:12:34 --> URI Class Initialized
INFO - 2021-06-03 08:12:34 --> Router Class Initialized
INFO - 2021-06-03 08:12:34 --> Output Class Initialized
INFO - 2021-06-03 08:12:34 --> Security Class Initialized
DEBUG - 2021-06-03 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:12:34 --> Input Class Initialized
INFO - 2021-06-03 08:12:34 --> Language Class Initialized
INFO - 2021-06-03 08:12:34 --> Language Class Initialized
INFO - 2021-06-03 08:12:34 --> Config Class Initialized
INFO - 2021-06-03 08:12:34 --> Loader Class Initialized
INFO - 2021-06-03 08:12:34 --> Helper loaded: url_helper
INFO - 2021-06-03 08:12:34 --> Helper loaded: file_helper
INFO - 2021-06-03 08:12:34 --> Helper loaded: form_helper
INFO - 2021-06-03 08:12:34 --> Helper loaded: my_helper
INFO - 2021-06-03 08:12:34 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:12:34 --> Controller Class Initialized
DEBUG - 2021-06-03 08:12:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-03 08:12:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 08:12:34 --> Final output sent to browser
DEBUG - 2021-06-03 08:12:34 --> Total execution time: 0.3273
INFO - 2021-06-03 08:12:44 --> Config Class Initialized
INFO - 2021-06-03 08:12:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:12:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:12:44 --> Utf8 Class Initialized
INFO - 2021-06-03 08:12:44 --> URI Class Initialized
INFO - 2021-06-03 08:12:44 --> Router Class Initialized
INFO - 2021-06-03 08:12:44 --> Output Class Initialized
INFO - 2021-06-03 08:12:44 --> Security Class Initialized
DEBUG - 2021-06-03 08:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:12:44 --> Input Class Initialized
INFO - 2021-06-03 08:12:44 --> Language Class Initialized
INFO - 2021-06-03 08:12:44 --> Language Class Initialized
INFO - 2021-06-03 08:12:44 --> Config Class Initialized
INFO - 2021-06-03 08:12:44 --> Loader Class Initialized
INFO - 2021-06-03 08:12:44 --> Helper loaded: url_helper
INFO - 2021-06-03 08:12:44 --> Helper loaded: file_helper
INFO - 2021-06-03 08:12:44 --> Helper loaded: form_helper
INFO - 2021-06-03 08:12:44 --> Helper loaded: my_helper
INFO - 2021-06-03 08:12:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:12:44 --> Controller Class Initialized
DEBUG - 2021-06-03 08:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-03 08:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 08:12:44 --> Final output sent to browser
DEBUG - 2021-06-03 08:12:44 --> Total execution time: 0.3288
INFO - 2021-06-03 08:12:44 --> Config Class Initialized
INFO - 2021-06-03 08:12:44 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:12:44 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:12:44 --> Utf8 Class Initialized
INFO - 2021-06-03 08:12:44 --> URI Class Initialized
INFO - 2021-06-03 08:12:44 --> Router Class Initialized
INFO - 2021-06-03 08:12:44 --> Output Class Initialized
INFO - 2021-06-03 08:12:44 --> Security Class Initialized
DEBUG - 2021-06-03 08:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:12:44 --> Input Class Initialized
INFO - 2021-06-03 08:12:44 --> Language Class Initialized
INFO - 2021-06-03 08:12:44 --> Language Class Initialized
INFO - 2021-06-03 08:12:44 --> Config Class Initialized
INFO - 2021-06-03 08:12:44 --> Loader Class Initialized
INFO - 2021-06-03 08:12:44 --> Helper loaded: url_helper
INFO - 2021-06-03 08:12:44 --> Helper loaded: file_helper
INFO - 2021-06-03 08:12:44 --> Helper loaded: form_helper
INFO - 2021-06-03 08:12:44 --> Helper loaded: my_helper
INFO - 2021-06-03 08:12:44 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:12:44 --> Controller Class Initialized
INFO - 2021-06-03 08:12:48 --> Config Class Initialized
INFO - 2021-06-03 08:12:48 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:12:48 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:12:48 --> Utf8 Class Initialized
INFO - 2021-06-03 08:12:48 --> URI Class Initialized
INFO - 2021-06-03 08:12:48 --> Router Class Initialized
INFO - 2021-06-03 08:12:48 --> Output Class Initialized
INFO - 2021-06-03 08:12:48 --> Security Class Initialized
DEBUG - 2021-06-03 08:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:12:48 --> Input Class Initialized
INFO - 2021-06-03 08:12:48 --> Language Class Initialized
INFO - 2021-06-03 08:12:48 --> Language Class Initialized
INFO - 2021-06-03 08:12:48 --> Config Class Initialized
INFO - 2021-06-03 08:12:48 --> Loader Class Initialized
INFO - 2021-06-03 08:12:48 --> Helper loaded: url_helper
INFO - 2021-06-03 08:12:48 --> Helper loaded: file_helper
INFO - 2021-06-03 08:12:48 --> Helper loaded: form_helper
INFO - 2021-06-03 08:12:48 --> Helper loaded: my_helper
INFO - 2021-06-03 08:12:48 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:12:48 --> Controller Class Initialized
INFO - 2021-06-03 08:12:48 --> Final output sent to browser
DEBUG - 2021-06-03 08:12:48 --> Total execution time: 0.1924
INFO - 2021-06-03 08:13:12 --> Config Class Initialized
INFO - 2021-06-03 08:13:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:13:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:13:12 --> Utf8 Class Initialized
INFO - 2021-06-03 08:13:12 --> URI Class Initialized
INFO - 2021-06-03 08:13:12 --> Router Class Initialized
INFO - 2021-06-03 08:13:12 --> Output Class Initialized
INFO - 2021-06-03 08:13:12 --> Security Class Initialized
DEBUG - 2021-06-03 08:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:13:12 --> Input Class Initialized
INFO - 2021-06-03 08:13:12 --> Language Class Initialized
INFO - 2021-06-03 08:13:12 --> Language Class Initialized
INFO - 2021-06-03 08:13:12 --> Config Class Initialized
INFO - 2021-06-03 08:13:12 --> Loader Class Initialized
INFO - 2021-06-03 08:13:12 --> Helper loaded: url_helper
INFO - 2021-06-03 08:13:12 --> Helper loaded: file_helper
INFO - 2021-06-03 08:13:12 --> Helper loaded: form_helper
INFO - 2021-06-03 08:13:12 --> Helper loaded: my_helper
INFO - 2021-06-03 08:13:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:13:12 --> Controller Class Initialized
INFO - 2021-06-03 08:13:12 --> Final output sent to browser
DEBUG - 2021-06-03 08:13:12 --> Total execution time: 0.1745
INFO - 2021-06-03 08:13:12 --> Config Class Initialized
INFO - 2021-06-03 08:13:12 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:13:12 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:13:12 --> Utf8 Class Initialized
INFO - 2021-06-03 08:13:12 --> URI Class Initialized
INFO - 2021-06-03 08:13:12 --> Router Class Initialized
INFO - 2021-06-03 08:13:12 --> Output Class Initialized
INFO - 2021-06-03 08:13:12 --> Security Class Initialized
DEBUG - 2021-06-03 08:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:13:12 --> Input Class Initialized
INFO - 2021-06-03 08:13:12 --> Language Class Initialized
INFO - 2021-06-03 08:13:12 --> Language Class Initialized
INFO - 2021-06-03 08:13:12 --> Config Class Initialized
INFO - 2021-06-03 08:13:12 --> Loader Class Initialized
INFO - 2021-06-03 08:13:12 --> Helper loaded: url_helper
INFO - 2021-06-03 08:13:12 --> Helper loaded: file_helper
INFO - 2021-06-03 08:13:12 --> Helper loaded: form_helper
INFO - 2021-06-03 08:13:12 --> Helper loaded: my_helper
INFO - 2021-06-03 08:13:12 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:13:12 --> Controller Class Initialized
INFO - 2021-06-03 08:13:15 --> Config Class Initialized
INFO - 2021-06-03 08:13:15 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:13:15 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:13:15 --> Utf8 Class Initialized
INFO - 2021-06-03 08:13:15 --> URI Class Initialized
INFO - 2021-06-03 08:13:15 --> Router Class Initialized
INFO - 2021-06-03 08:13:15 --> Output Class Initialized
INFO - 2021-06-03 08:13:15 --> Security Class Initialized
DEBUG - 2021-06-03 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:13:15 --> Input Class Initialized
INFO - 2021-06-03 08:13:15 --> Language Class Initialized
INFO - 2021-06-03 08:13:15 --> Language Class Initialized
INFO - 2021-06-03 08:13:15 --> Config Class Initialized
INFO - 2021-06-03 08:13:15 --> Loader Class Initialized
INFO - 2021-06-03 08:13:15 --> Helper loaded: url_helper
INFO - 2021-06-03 08:13:15 --> Helper loaded: file_helper
INFO - 2021-06-03 08:13:15 --> Helper loaded: form_helper
INFO - 2021-06-03 08:13:15 --> Helper loaded: my_helper
INFO - 2021-06-03 08:13:15 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:13:15 --> Controller Class Initialized
INFO - 2021-06-03 08:13:15 --> Final output sent to browser
DEBUG - 2021-06-03 08:13:15 --> Total execution time: 0.2227
INFO - 2021-06-03 08:13:20 --> Config Class Initialized
INFO - 2021-06-03 08:13:20 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:13:20 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:13:20 --> Utf8 Class Initialized
INFO - 2021-06-03 08:13:20 --> URI Class Initialized
INFO - 2021-06-03 08:13:20 --> Router Class Initialized
INFO - 2021-06-03 08:13:20 --> Output Class Initialized
INFO - 2021-06-03 08:13:20 --> Security Class Initialized
DEBUG - 2021-06-03 08:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:13:20 --> Input Class Initialized
INFO - 2021-06-03 08:13:20 --> Language Class Initialized
INFO - 2021-06-03 08:13:20 --> Language Class Initialized
INFO - 2021-06-03 08:13:20 --> Config Class Initialized
INFO - 2021-06-03 08:13:20 --> Loader Class Initialized
INFO - 2021-06-03 08:13:20 --> Helper loaded: url_helper
INFO - 2021-06-03 08:13:20 --> Helper loaded: file_helper
INFO - 2021-06-03 08:13:20 --> Helper loaded: form_helper
INFO - 2021-06-03 08:13:20 --> Helper loaded: my_helper
INFO - 2021-06-03 08:13:20 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:13:20 --> Controller Class Initialized
INFO - 2021-06-03 08:13:37 --> Config Class Initialized
INFO - 2021-06-03 08:13:37 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:13:37 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:13:37 --> Utf8 Class Initialized
INFO - 2021-06-03 08:13:37 --> URI Class Initialized
INFO - 2021-06-03 08:13:37 --> Router Class Initialized
INFO - 2021-06-03 08:13:37 --> Output Class Initialized
INFO - 2021-06-03 08:13:37 --> Security Class Initialized
DEBUG - 2021-06-03 08:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:13:37 --> Input Class Initialized
INFO - 2021-06-03 08:13:37 --> Language Class Initialized
INFO - 2021-06-03 08:13:37 --> Language Class Initialized
INFO - 2021-06-03 08:13:37 --> Config Class Initialized
INFO - 2021-06-03 08:13:37 --> Loader Class Initialized
INFO - 2021-06-03 08:13:37 --> Helper loaded: url_helper
INFO - 2021-06-03 08:13:37 --> Helper loaded: file_helper
INFO - 2021-06-03 08:13:37 --> Helper loaded: form_helper
INFO - 2021-06-03 08:13:37 --> Helper loaded: my_helper
INFO - 2021-06-03 08:13:37 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:13:37 --> Controller Class Initialized
INFO - 2021-06-03 08:15:20 --> Config Class Initialized
INFO - 2021-06-03 08:15:20 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:15:20 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:15:20 --> Utf8 Class Initialized
INFO - 2021-06-03 08:15:20 --> URI Class Initialized
INFO - 2021-06-03 08:15:20 --> Router Class Initialized
INFO - 2021-06-03 08:15:20 --> Output Class Initialized
INFO - 2021-06-03 08:15:20 --> Security Class Initialized
DEBUG - 2021-06-03 08:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:15:20 --> Input Class Initialized
INFO - 2021-06-03 08:15:20 --> Language Class Initialized
INFO - 2021-06-03 08:15:20 --> Language Class Initialized
INFO - 2021-06-03 08:15:20 --> Config Class Initialized
INFO - 2021-06-03 08:15:20 --> Loader Class Initialized
INFO - 2021-06-03 08:15:20 --> Helper loaded: url_helper
INFO - 2021-06-03 08:15:20 --> Helper loaded: file_helper
INFO - 2021-06-03 08:15:20 --> Helper loaded: form_helper
INFO - 2021-06-03 08:15:20 --> Helper loaded: my_helper
INFO - 2021-06-03 08:15:20 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:15:20 --> Controller Class Initialized
INFO - 2021-06-03 08:15:20 --> Helper loaded: cookie_helper
INFO - 2021-06-03 08:15:20 --> Config Class Initialized
INFO - 2021-06-03 08:15:20 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:15:20 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:15:20 --> Utf8 Class Initialized
INFO - 2021-06-03 08:15:20 --> URI Class Initialized
INFO - 2021-06-03 08:15:20 --> Router Class Initialized
INFO - 2021-06-03 08:15:20 --> Output Class Initialized
INFO - 2021-06-03 08:15:20 --> Security Class Initialized
DEBUG - 2021-06-03 08:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:15:20 --> Input Class Initialized
INFO - 2021-06-03 08:15:20 --> Language Class Initialized
INFO - 2021-06-03 08:15:20 --> Language Class Initialized
INFO - 2021-06-03 08:15:20 --> Config Class Initialized
INFO - 2021-06-03 08:15:20 --> Loader Class Initialized
INFO - 2021-06-03 08:15:20 --> Helper loaded: url_helper
INFO - 2021-06-03 08:15:20 --> Helper loaded: file_helper
INFO - 2021-06-03 08:15:20 --> Helper loaded: form_helper
INFO - 2021-06-03 08:15:20 --> Helper loaded: my_helper
INFO - 2021-06-03 08:15:20 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:15:20 --> Controller Class Initialized
DEBUG - 2021-06-03 08:15:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-03 08:15:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 08:15:20 --> Final output sent to browser
DEBUG - 2021-06-03 08:15:20 --> Total execution time: 0.1532
INFO - 2021-06-03 08:15:26 --> Config Class Initialized
INFO - 2021-06-03 08:15:26 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:15:26 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:15:26 --> Utf8 Class Initialized
INFO - 2021-06-03 08:15:26 --> URI Class Initialized
INFO - 2021-06-03 08:15:26 --> Router Class Initialized
INFO - 2021-06-03 08:15:26 --> Output Class Initialized
INFO - 2021-06-03 08:15:26 --> Security Class Initialized
DEBUG - 2021-06-03 08:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:15:26 --> Input Class Initialized
INFO - 2021-06-03 08:15:26 --> Language Class Initialized
INFO - 2021-06-03 08:15:26 --> Language Class Initialized
INFO - 2021-06-03 08:15:26 --> Config Class Initialized
INFO - 2021-06-03 08:15:26 --> Loader Class Initialized
INFO - 2021-06-03 08:15:26 --> Helper loaded: url_helper
INFO - 2021-06-03 08:15:26 --> Helper loaded: file_helper
INFO - 2021-06-03 08:15:26 --> Helper loaded: form_helper
INFO - 2021-06-03 08:15:27 --> Helper loaded: my_helper
INFO - 2021-06-03 08:15:27 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:15:27 --> Controller Class Initialized
INFO - 2021-06-03 08:15:27 --> Helper loaded: cookie_helper
INFO - 2021-06-03 08:15:27 --> Final output sent to browser
DEBUG - 2021-06-03 08:15:27 --> Total execution time: 0.1560
INFO - 2021-06-03 08:15:28 --> Config Class Initialized
INFO - 2021-06-03 08:15:28 --> Hooks Class Initialized
DEBUG - 2021-06-03 08:15:28 --> UTF-8 Support Enabled
INFO - 2021-06-03 08:15:28 --> Utf8 Class Initialized
INFO - 2021-06-03 08:15:28 --> URI Class Initialized
INFO - 2021-06-03 08:15:28 --> Router Class Initialized
INFO - 2021-06-03 08:15:28 --> Output Class Initialized
INFO - 2021-06-03 08:15:28 --> Security Class Initialized
DEBUG - 2021-06-03 08:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-03 08:15:28 --> Input Class Initialized
INFO - 2021-06-03 08:15:28 --> Language Class Initialized
INFO - 2021-06-03 08:15:28 --> Language Class Initialized
INFO - 2021-06-03 08:15:28 --> Config Class Initialized
INFO - 2021-06-03 08:15:28 --> Loader Class Initialized
INFO - 2021-06-03 08:15:28 --> Helper loaded: url_helper
INFO - 2021-06-03 08:15:28 --> Helper loaded: file_helper
INFO - 2021-06-03 08:15:28 --> Helper loaded: form_helper
INFO - 2021-06-03 08:15:28 --> Helper loaded: my_helper
INFO - 2021-06-03 08:15:28 --> Database Driver Class Initialized
DEBUG - 2021-06-03 08:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-03 08:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-03 08:15:28 --> Controller Class Initialized
DEBUG - 2021-06-03 08:15:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-03 08:15:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-03 08:15:28 --> Final output sent to browser
DEBUG - 2021-06-03 08:15:28 --> Total execution time: 0.1935
