<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-14 05:08:08 --> Config Class Initialized
INFO - 2022-05-14 05:08:08 --> Hooks Class Initialized
DEBUG - 2022-05-14 05:08:08 --> UTF-8 Support Enabled
INFO - 2022-05-14 05:08:08 --> Utf8 Class Initialized
INFO - 2022-05-14 05:08:08 --> URI Class Initialized
DEBUG - 2022-05-14 05:08:08 --> No URI present. Default controller set.
INFO - 2022-05-14 05:08:08 --> Router Class Initialized
INFO - 2022-05-14 05:08:08 --> Output Class Initialized
INFO - 2022-05-14 05:08:08 --> Security Class Initialized
DEBUG - 2022-05-14 05:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-14 05:08:08 --> Input Class Initialized
INFO - 2022-05-14 05:08:08 --> Language Class Initialized
INFO - 2022-05-14 05:08:08 --> Language Class Initialized
INFO - 2022-05-14 05:08:08 --> Config Class Initialized
INFO - 2022-05-14 05:08:08 --> Loader Class Initialized
INFO - 2022-05-14 05:08:08 --> Helper loaded: url_helper
INFO - 2022-05-14 05:08:08 --> Helper loaded: file_helper
INFO - 2022-05-14 05:08:08 --> Helper loaded: form_helper
INFO - 2022-05-14 05:08:08 --> Helper loaded: my_helper
INFO - 2022-05-14 05:08:08 --> Database Driver Class Initialized
DEBUG - 2022-05-14 05:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-14 05:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-14 05:08:08 --> Controller Class Initialized
INFO - 2022-05-14 05:08:08 --> Config Class Initialized
INFO - 2022-05-14 05:08:08 --> Hooks Class Initialized
DEBUG - 2022-05-14 05:08:08 --> UTF-8 Support Enabled
INFO - 2022-05-14 05:08:08 --> Utf8 Class Initialized
INFO - 2022-05-14 05:08:08 --> URI Class Initialized
INFO - 2022-05-14 05:08:08 --> Router Class Initialized
INFO - 2022-05-14 05:08:08 --> Output Class Initialized
INFO - 2022-05-14 05:08:08 --> Security Class Initialized
DEBUG - 2022-05-14 05:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-14 05:08:08 --> Input Class Initialized
INFO - 2022-05-14 05:08:08 --> Language Class Initialized
INFO - 2022-05-14 05:08:08 --> Language Class Initialized
INFO - 2022-05-14 05:08:08 --> Config Class Initialized
INFO - 2022-05-14 05:08:08 --> Loader Class Initialized
INFO - 2022-05-14 05:08:08 --> Helper loaded: url_helper
INFO - 2022-05-14 05:08:08 --> Helper loaded: file_helper
INFO - 2022-05-14 05:08:08 --> Helper loaded: form_helper
INFO - 2022-05-14 05:08:08 --> Helper loaded: my_helper
INFO - 2022-05-14 05:08:08 --> Database Driver Class Initialized
DEBUG - 2022-05-14 05:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-14 05:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-14 05:08:08 --> Controller Class Initialized
DEBUG - 2022-05-14 05:08:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-14 05:08:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-14 05:08:08 --> Final output sent to browser
DEBUG - 2022-05-14 05:08:08 --> Total execution time: 0.0620
INFO - 2022-05-14 05:08:52 --> Config Class Initialized
INFO - 2022-05-14 05:08:52 --> Hooks Class Initialized
DEBUG - 2022-05-14 05:08:52 --> UTF-8 Support Enabled
INFO - 2022-05-14 05:08:52 --> Utf8 Class Initialized
INFO - 2022-05-14 05:08:52 --> URI Class Initialized
INFO - 2022-05-14 05:08:52 --> Router Class Initialized
INFO - 2022-05-14 05:08:52 --> Output Class Initialized
INFO - 2022-05-14 05:08:52 --> Security Class Initialized
DEBUG - 2022-05-14 05:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-14 05:08:52 --> Input Class Initialized
INFO - 2022-05-14 05:08:52 --> Language Class Initialized
INFO - 2022-05-14 05:08:52 --> Language Class Initialized
INFO - 2022-05-14 05:08:52 --> Config Class Initialized
INFO - 2022-05-14 05:08:52 --> Loader Class Initialized
INFO - 2022-05-14 05:08:52 --> Helper loaded: url_helper
INFO - 2022-05-14 05:08:52 --> Helper loaded: file_helper
INFO - 2022-05-14 05:08:52 --> Helper loaded: form_helper
INFO - 2022-05-14 05:08:52 --> Helper loaded: my_helper
INFO - 2022-05-14 05:08:52 --> Database Driver Class Initialized
DEBUG - 2022-05-14 05:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-14 05:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-14 05:08:52 --> Controller Class Initialized
INFO - 2022-05-14 05:08:52 --> Helper loaded: cookie_helper
INFO - 2022-05-14 05:08:52 --> Final output sent to browser
DEBUG - 2022-05-14 05:08:52 --> Total execution time: 0.0873
INFO - 2022-05-14 05:08:55 --> Config Class Initialized
INFO - 2022-05-14 05:08:55 --> Hooks Class Initialized
DEBUG - 2022-05-14 05:08:55 --> UTF-8 Support Enabled
INFO - 2022-05-14 05:08:55 --> Utf8 Class Initialized
INFO - 2022-05-14 05:08:55 --> URI Class Initialized
INFO - 2022-05-14 05:08:55 --> Router Class Initialized
INFO - 2022-05-14 05:08:55 --> Output Class Initialized
INFO - 2022-05-14 05:08:55 --> Security Class Initialized
DEBUG - 2022-05-14 05:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-14 05:08:55 --> Input Class Initialized
INFO - 2022-05-14 05:08:55 --> Language Class Initialized
INFO - 2022-05-14 05:08:55 --> Language Class Initialized
INFO - 2022-05-14 05:08:55 --> Config Class Initialized
INFO - 2022-05-14 05:08:55 --> Loader Class Initialized
INFO - 2022-05-14 05:08:55 --> Helper loaded: url_helper
INFO - 2022-05-14 05:08:55 --> Helper loaded: file_helper
INFO - 2022-05-14 05:08:55 --> Helper loaded: form_helper
INFO - 2022-05-14 05:08:55 --> Helper loaded: my_helper
INFO - 2022-05-14 05:08:55 --> Database Driver Class Initialized
DEBUG - 2022-05-14 05:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-14 05:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-14 05:08:55 --> Controller Class Initialized
DEBUG - 2022-05-14 05:08:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-05-14 05:08:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-14 05:08:55 --> Final output sent to browser
DEBUG - 2022-05-14 05:08:55 --> Total execution time: 0.0835
INFO - 2022-05-14 05:09:02 --> Config Class Initialized
INFO - 2022-05-14 05:09:02 --> Hooks Class Initialized
DEBUG - 2022-05-14 05:09:02 --> UTF-8 Support Enabled
INFO - 2022-05-14 05:09:02 --> Utf8 Class Initialized
INFO - 2022-05-14 05:09:02 --> URI Class Initialized
INFO - 2022-05-14 05:09:02 --> Router Class Initialized
INFO - 2022-05-14 05:09:02 --> Output Class Initialized
INFO - 2022-05-14 05:09:02 --> Security Class Initialized
DEBUG - 2022-05-14 05:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-14 05:09:02 --> Input Class Initialized
INFO - 2022-05-14 05:09:02 --> Language Class Initialized
INFO - 2022-05-14 05:09:02 --> Language Class Initialized
INFO - 2022-05-14 05:09:02 --> Config Class Initialized
INFO - 2022-05-14 05:09:02 --> Loader Class Initialized
INFO - 2022-05-14 05:09:02 --> Helper loaded: url_helper
INFO - 2022-05-14 05:09:02 --> Helper loaded: file_helper
INFO - 2022-05-14 05:09:02 --> Helper loaded: form_helper
INFO - 2022-05-14 05:09:02 --> Helper loaded: my_helper
INFO - 2022-05-14 05:09:02 --> Database Driver Class Initialized
DEBUG - 2022-05-14 05:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-14 05:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-14 05:09:02 --> Controller Class Initialized
DEBUG - 2022-05-14 05:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2022-05-14 05:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-14 05:09:02 --> Final output sent to browser
DEBUG - 2022-05-14 05:09:02 --> Total execution time: 0.0671
INFO - 2022-05-14 05:09:02 --> Config Class Initialized
INFO - 2022-05-14 05:09:02 --> Hooks Class Initialized
DEBUG - 2022-05-14 05:09:02 --> UTF-8 Support Enabled
INFO - 2022-05-14 05:09:02 --> Utf8 Class Initialized
INFO - 2022-05-14 05:09:02 --> URI Class Initialized
INFO - 2022-05-14 05:09:02 --> Router Class Initialized
INFO - 2022-05-14 05:09:02 --> Output Class Initialized
INFO - 2022-05-14 05:09:02 --> Security Class Initialized
DEBUG - 2022-05-14 05:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-14 05:09:02 --> Input Class Initialized
INFO - 2022-05-14 05:09:02 --> Language Class Initialized
INFO - 2022-05-14 05:09:02 --> Language Class Initialized
INFO - 2022-05-14 05:09:02 --> Config Class Initialized
INFO - 2022-05-14 05:09:02 --> Loader Class Initialized
INFO - 2022-05-14 05:09:02 --> Helper loaded: url_helper
INFO - 2022-05-14 05:09:02 --> Helper loaded: file_helper
INFO - 2022-05-14 05:09:02 --> Helper loaded: form_helper
INFO - 2022-05-14 05:09:02 --> Helper loaded: my_helper
INFO - 2022-05-14 05:09:02 --> Database Driver Class Initialized
DEBUG - 2022-05-14 05:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-14 05:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-14 05:09:02 --> Controller Class Initialized
INFO - 2022-05-14 05:09:06 --> Config Class Initialized
INFO - 2022-05-14 05:09:06 --> Hooks Class Initialized
DEBUG - 2022-05-14 05:09:06 --> UTF-8 Support Enabled
INFO - 2022-05-14 05:09:06 --> Utf8 Class Initialized
INFO - 2022-05-14 05:09:06 --> URI Class Initialized
INFO - 2022-05-14 05:09:06 --> Router Class Initialized
INFO - 2022-05-14 05:09:06 --> Output Class Initialized
INFO - 2022-05-14 05:09:06 --> Security Class Initialized
DEBUG - 2022-05-14 05:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-14 05:09:06 --> Input Class Initialized
INFO - 2022-05-14 05:09:06 --> Language Class Initialized
INFO - 2022-05-14 05:09:06 --> Language Class Initialized
INFO - 2022-05-14 05:09:06 --> Config Class Initialized
INFO - 2022-05-14 05:09:06 --> Loader Class Initialized
INFO - 2022-05-14 05:09:06 --> Helper loaded: url_helper
INFO - 2022-05-14 05:09:06 --> Helper loaded: file_helper
INFO - 2022-05-14 05:09:06 --> Helper loaded: form_helper
INFO - 2022-05-14 05:09:06 --> Helper loaded: my_helper
INFO - 2022-05-14 05:09:06 --> Database Driver Class Initialized
DEBUG - 2022-05-14 05:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-14 05:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-14 05:09:06 --> Controller Class Initialized
DEBUG - 2022-05-14 05:09:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2022-05-14 05:09:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-14 05:09:06 --> Final output sent to browser
DEBUG - 2022-05-14 05:09:06 --> Total execution time: 0.0602
INFO - 2022-05-14 05:09:06 --> Config Class Initialized
INFO - 2022-05-14 05:09:06 --> Hooks Class Initialized
DEBUG - 2022-05-14 05:09:06 --> UTF-8 Support Enabled
INFO - 2022-05-14 05:09:06 --> Utf8 Class Initialized
INFO - 2022-05-14 05:09:06 --> URI Class Initialized
INFO - 2022-05-14 05:09:06 --> Router Class Initialized
INFO - 2022-05-14 05:09:06 --> Output Class Initialized
INFO - 2022-05-14 05:09:06 --> Security Class Initialized
DEBUG - 2022-05-14 05:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-14 05:09:06 --> Input Class Initialized
INFO - 2022-05-14 05:09:06 --> Language Class Initialized
INFO - 2022-05-14 05:09:06 --> Language Class Initialized
INFO - 2022-05-14 05:09:06 --> Config Class Initialized
INFO - 2022-05-14 05:09:06 --> Loader Class Initialized
INFO - 2022-05-14 05:09:06 --> Helper loaded: url_helper
INFO - 2022-05-14 05:09:06 --> Helper loaded: file_helper
INFO - 2022-05-14 05:09:06 --> Helper loaded: form_helper
INFO - 2022-05-14 05:09:06 --> Helper loaded: my_helper
INFO - 2022-05-14 05:09:06 --> Database Driver Class Initialized
DEBUG - 2022-05-14 05:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-14 05:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-14 05:09:06 --> Controller Class Initialized
