<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-16 01:23:52 --> Config Class Initialized
INFO - 2021-12-16 01:23:52 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:23:52 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:23:52 --> Utf8 Class Initialized
INFO - 2021-12-16 01:23:52 --> URI Class Initialized
DEBUG - 2021-12-16 01:23:52 --> No URI present. Default controller set.
INFO - 2021-12-16 01:23:52 --> Router Class Initialized
INFO - 2021-12-16 01:23:52 --> Output Class Initialized
INFO - 2021-12-16 01:23:52 --> Security Class Initialized
DEBUG - 2021-12-16 01:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:23:52 --> Input Class Initialized
INFO - 2021-12-16 01:23:52 --> Language Class Initialized
INFO - 2021-12-16 01:23:52 --> Language Class Initialized
INFO - 2021-12-16 01:23:52 --> Config Class Initialized
INFO - 2021-12-16 01:23:52 --> Loader Class Initialized
INFO - 2021-12-16 01:23:52 --> Helper loaded: url_helper
INFO - 2021-12-16 01:23:52 --> Helper loaded: file_helper
INFO - 2021-12-16 01:23:52 --> Helper loaded: form_helper
INFO - 2021-12-16 01:23:52 --> Helper loaded: my_helper
INFO - 2021-12-16 01:23:53 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:23:53 --> Controller Class Initialized
INFO - 2021-12-16 01:23:53 --> Config Class Initialized
INFO - 2021-12-16 01:23:53 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:23:53 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:23:53 --> Utf8 Class Initialized
INFO - 2021-12-16 01:23:53 --> URI Class Initialized
INFO - 2021-12-16 01:23:53 --> Router Class Initialized
INFO - 2021-12-16 01:23:53 --> Output Class Initialized
INFO - 2021-12-16 01:23:53 --> Security Class Initialized
DEBUG - 2021-12-16 01:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:23:53 --> Input Class Initialized
INFO - 2021-12-16 01:23:53 --> Language Class Initialized
INFO - 2021-12-16 01:23:53 --> Language Class Initialized
INFO - 2021-12-16 01:23:53 --> Config Class Initialized
INFO - 2021-12-16 01:23:53 --> Loader Class Initialized
INFO - 2021-12-16 01:23:53 --> Helper loaded: url_helper
INFO - 2021-12-16 01:23:53 --> Helper loaded: file_helper
INFO - 2021-12-16 01:23:53 --> Helper loaded: form_helper
INFO - 2021-12-16 01:23:53 --> Helper loaded: my_helper
INFO - 2021-12-16 01:23:53 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:23:53 --> Controller Class Initialized
DEBUG - 2021-12-16 01:23:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-16 01:23:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:23:53 --> Final output sent to browser
DEBUG - 2021-12-16 01:23:53 --> Total execution time: 0.0380
INFO - 2021-12-16 01:24:16 --> Config Class Initialized
INFO - 2021-12-16 01:24:16 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:24:16 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:24:16 --> Utf8 Class Initialized
INFO - 2021-12-16 01:24:16 --> URI Class Initialized
INFO - 2021-12-16 01:24:16 --> Router Class Initialized
INFO - 2021-12-16 01:24:16 --> Output Class Initialized
INFO - 2021-12-16 01:24:16 --> Security Class Initialized
DEBUG - 2021-12-16 01:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:24:16 --> Input Class Initialized
INFO - 2021-12-16 01:24:16 --> Language Class Initialized
INFO - 2021-12-16 01:24:16 --> Language Class Initialized
INFO - 2021-12-16 01:24:16 --> Config Class Initialized
INFO - 2021-12-16 01:24:16 --> Loader Class Initialized
INFO - 2021-12-16 01:24:16 --> Helper loaded: url_helper
INFO - 2021-12-16 01:24:16 --> Helper loaded: file_helper
INFO - 2021-12-16 01:24:16 --> Helper loaded: form_helper
INFO - 2021-12-16 01:24:16 --> Helper loaded: my_helper
INFO - 2021-12-16 01:24:16 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:24:16 --> Controller Class Initialized
INFO - 2021-12-16 01:24:16 --> Final output sent to browser
DEBUG - 2021-12-16 01:24:16 --> Total execution time: 0.0430
INFO - 2021-12-16 01:24:27 --> Config Class Initialized
INFO - 2021-12-16 01:24:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:24:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:24:27 --> Utf8 Class Initialized
INFO - 2021-12-16 01:24:27 --> URI Class Initialized
INFO - 2021-12-16 01:24:27 --> Router Class Initialized
INFO - 2021-12-16 01:24:27 --> Output Class Initialized
INFO - 2021-12-16 01:24:27 --> Security Class Initialized
DEBUG - 2021-12-16 01:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:24:27 --> Input Class Initialized
INFO - 2021-12-16 01:24:27 --> Language Class Initialized
INFO - 2021-12-16 01:24:27 --> Language Class Initialized
INFO - 2021-12-16 01:24:27 --> Config Class Initialized
INFO - 2021-12-16 01:24:27 --> Loader Class Initialized
INFO - 2021-12-16 01:24:27 --> Helper loaded: url_helper
INFO - 2021-12-16 01:24:27 --> Helper loaded: file_helper
INFO - 2021-12-16 01:24:27 --> Helper loaded: form_helper
INFO - 2021-12-16 01:24:27 --> Helper loaded: my_helper
INFO - 2021-12-16 01:24:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:24:27 --> Controller Class Initialized
INFO - 2021-12-16 01:24:27 --> Helper loaded: cookie_helper
INFO - 2021-12-16 01:24:27 --> Final output sent to browser
DEBUG - 2021-12-16 01:24:27 --> Total execution time: 0.0510
INFO - 2021-12-16 01:24:28 --> Config Class Initialized
INFO - 2021-12-16 01:24:28 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:24:28 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:24:28 --> Utf8 Class Initialized
INFO - 2021-12-16 01:24:28 --> URI Class Initialized
INFO - 2021-12-16 01:24:28 --> Router Class Initialized
INFO - 2021-12-16 01:24:28 --> Output Class Initialized
INFO - 2021-12-16 01:24:28 --> Security Class Initialized
DEBUG - 2021-12-16 01:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:24:28 --> Input Class Initialized
INFO - 2021-12-16 01:24:28 --> Language Class Initialized
INFO - 2021-12-16 01:24:28 --> Language Class Initialized
INFO - 2021-12-16 01:24:28 --> Config Class Initialized
INFO - 2021-12-16 01:24:28 --> Loader Class Initialized
INFO - 2021-12-16 01:24:28 --> Helper loaded: url_helper
INFO - 2021-12-16 01:24:28 --> Helper loaded: file_helper
INFO - 2021-12-16 01:24:28 --> Helper loaded: form_helper
INFO - 2021-12-16 01:24:28 --> Helper loaded: my_helper
INFO - 2021-12-16 01:24:28 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:24:28 --> Controller Class Initialized
DEBUG - 2021-12-16 01:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-16 01:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:24:28 --> Final output sent to browser
DEBUG - 2021-12-16 01:24:28 --> Total execution time: 0.2370
INFO - 2021-12-16 01:24:50 --> Config Class Initialized
INFO - 2021-12-16 01:24:50 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:24:50 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:24:51 --> Utf8 Class Initialized
INFO - 2021-12-16 01:24:51 --> URI Class Initialized
INFO - 2021-12-16 01:24:51 --> Router Class Initialized
INFO - 2021-12-16 01:24:51 --> Output Class Initialized
INFO - 2021-12-16 01:24:51 --> Security Class Initialized
DEBUG - 2021-12-16 01:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:24:51 --> Input Class Initialized
INFO - 2021-12-16 01:24:51 --> Language Class Initialized
INFO - 2021-12-16 01:24:51 --> Language Class Initialized
INFO - 2021-12-16 01:24:51 --> Config Class Initialized
INFO - 2021-12-16 01:24:51 --> Loader Class Initialized
INFO - 2021-12-16 01:24:51 --> Helper loaded: url_helper
INFO - 2021-12-16 01:24:51 --> Helper loaded: file_helper
INFO - 2021-12-16 01:24:51 --> Helper loaded: form_helper
INFO - 2021-12-16 01:24:51 --> Helper loaded: my_helper
INFO - 2021-12-16 01:24:51 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:24:51 --> Controller Class Initialized
DEBUG - 2021-12-16 01:24:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 01:24:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:24:51 --> Final output sent to browser
DEBUG - 2021-12-16 01:24:51 --> Total execution time: 0.0740
INFO - 2021-12-16 01:25:08 --> Config Class Initialized
INFO - 2021-12-16 01:25:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:25:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:25:08 --> Utf8 Class Initialized
INFO - 2021-12-16 01:25:08 --> URI Class Initialized
INFO - 2021-12-16 01:25:08 --> Router Class Initialized
INFO - 2021-12-16 01:25:08 --> Output Class Initialized
INFO - 2021-12-16 01:25:08 --> Security Class Initialized
DEBUG - 2021-12-16 01:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:25:08 --> Input Class Initialized
INFO - 2021-12-16 01:25:08 --> Language Class Initialized
INFO - 2021-12-16 01:25:08 --> Language Class Initialized
INFO - 2021-12-16 01:25:08 --> Config Class Initialized
INFO - 2021-12-16 01:25:08 --> Loader Class Initialized
INFO - 2021-12-16 01:25:08 --> Helper loaded: url_helper
INFO - 2021-12-16 01:25:08 --> Helper loaded: file_helper
INFO - 2021-12-16 01:25:08 --> Helper loaded: form_helper
INFO - 2021-12-16 01:25:08 --> Helper loaded: my_helper
INFO - 2021-12-16 01:25:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:25:08 --> Controller Class Initialized
DEBUG - 2021-12-16 01:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 01:25:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:25:08 --> Final output sent to browser
DEBUG - 2021-12-16 01:25:08 --> Total execution time: 0.0490
INFO - 2021-12-16 01:25:45 --> Config Class Initialized
INFO - 2021-12-16 01:25:45 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:25:45 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:25:45 --> Utf8 Class Initialized
INFO - 2021-12-16 01:25:45 --> URI Class Initialized
INFO - 2021-12-16 01:25:45 --> Router Class Initialized
INFO - 2021-12-16 01:25:45 --> Output Class Initialized
INFO - 2021-12-16 01:25:45 --> Security Class Initialized
DEBUG - 2021-12-16 01:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:25:45 --> Input Class Initialized
INFO - 2021-12-16 01:25:45 --> Language Class Initialized
INFO - 2021-12-16 01:25:45 --> Language Class Initialized
INFO - 2021-12-16 01:25:45 --> Config Class Initialized
INFO - 2021-12-16 01:25:45 --> Loader Class Initialized
INFO - 2021-12-16 01:25:45 --> Helper loaded: url_helper
INFO - 2021-12-16 01:25:45 --> Helper loaded: file_helper
INFO - 2021-12-16 01:25:45 --> Helper loaded: form_helper
INFO - 2021-12-16 01:25:45 --> Helper loaded: my_helper
INFO - 2021-12-16 01:25:45 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:25:45 --> Controller Class Initialized
DEBUG - 2021-12-16 01:25:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 01:25:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:25:45 --> Final output sent to browser
DEBUG - 2021-12-16 01:25:45 --> Total execution time: 0.0590
INFO - 2021-12-16 01:25:49 --> Config Class Initialized
INFO - 2021-12-16 01:25:49 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:25:49 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:25:49 --> Utf8 Class Initialized
INFO - 2021-12-16 01:25:49 --> URI Class Initialized
INFO - 2021-12-16 01:25:49 --> Router Class Initialized
INFO - 2021-12-16 01:25:49 --> Output Class Initialized
INFO - 2021-12-16 01:25:49 --> Security Class Initialized
DEBUG - 2021-12-16 01:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:25:49 --> Input Class Initialized
INFO - 2021-12-16 01:25:49 --> Language Class Initialized
INFO - 2021-12-16 01:25:49 --> Language Class Initialized
INFO - 2021-12-16 01:25:49 --> Config Class Initialized
INFO - 2021-12-16 01:25:49 --> Loader Class Initialized
INFO - 2021-12-16 01:25:49 --> Helper loaded: url_helper
INFO - 2021-12-16 01:25:49 --> Helper loaded: file_helper
INFO - 2021-12-16 01:25:49 --> Helper loaded: form_helper
INFO - 2021-12-16 01:25:49 --> Helper loaded: my_helper
INFO - 2021-12-16 01:25:49 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:25:49 --> Controller Class Initialized
DEBUG - 2021-12-16 01:25:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 01:25:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:25:49 --> Final output sent to browser
DEBUG - 2021-12-16 01:25:49 --> Total execution time: 0.0470
INFO - 2021-12-16 01:25:49 --> Config Class Initialized
INFO - 2021-12-16 01:25:49 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:25:49 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:25:49 --> Utf8 Class Initialized
INFO - 2021-12-16 01:25:49 --> URI Class Initialized
INFO - 2021-12-16 01:25:49 --> Router Class Initialized
INFO - 2021-12-16 01:25:49 --> Output Class Initialized
INFO - 2021-12-16 01:25:49 --> Security Class Initialized
DEBUG - 2021-12-16 01:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:25:49 --> Input Class Initialized
INFO - 2021-12-16 01:25:49 --> Language Class Initialized
INFO - 2021-12-16 01:25:49 --> Language Class Initialized
INFO - 2021-12-16 01:25:49 --> Config Class Initialized
INFO - 2021-12-16 01:25:49 --> Loader Class Initialized
INFO - 2021-12-16 01:25:49 --> Helper loaded: url_helper
INFO - 2021-12-16 01:25:49 --> Helper loaded: file_helper
INFO - 2021-12-16 01:25:49 --> Helper loaded: form_helper
INFO - 2021-12-16 01:25:49 --> Helper loaded: my_helper
INFO - 2021-12-16 01:25:49 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:25:49 --> Controller Class Initialized
INFO - 2021-12-16 01:25:53 --> Config Class Initialized
INFO - 2021-12-16 01:25:53 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:25:53 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:25:53 --> Utf8 Class Initialized
INFO - 2021-12-16 01:25:53 --> URI Class Initialized
INFO - 2021-12-16 01:25:53 --> Router Class Initialized
INFO - 2021-12-16 01:25:53 --> Output Class Initialized
INFO - 2021-12-16 01:25:53 --> Security Class Initialized
DEBUG - 2021-12-16 01:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:25:53 --> Input Class Initialized
INFO - 2021-12-16 01:25:53 --> Language Class Initialized
INFO - 2021-12-16 01:25:53 --> Language Class Initialized
INFO - 2021-12-16 01:25:53 --> Config Class Initialized
INFO - 2021-12-16 01:25:53 --> Loader Class Initialized
INFO - 2021-12-16 01:25:53 --> Helper loaded: url_helper
INFO - 2021-12-16 01:25:53 --> Helper loaded: file_helper
INFO - 2021-12-16 01:25:53 --> Helper loaded: form_helper
INFO - 2021-12-16 01:25:53 --> Helper loaded: my_helper
INFO - 2021-12-16 01:25:53 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:25:53 --> Controller Class Initialized
ERROR - 2021-12-16 01:25:53 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-16 01:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-16 01:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:25:53 --> Final output sent to browser
DEBUG - 2021-12-16 01:25:53 --> Total execution time: 0.0500
INFO - 2021-12-16 01:33:12 --> Config Class Initialized
INFO - 2021-12-16 01:33:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:33:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:33:12 --> Utf8 Class Initialized
INFO - 2021-12-16 01:33:12 --> URI Class Initialized
INFO - 2021-12-16 01:33:12 --> Router Class Initialized
INFO - 2021-12-16 01:33:12 --> Output Class Initialized
INFO - 2021-12-16 01:33:12 --> Security Class Initialized
DEBUG - 2021-12-16 01:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:33:12 --> Input Class Initialized
INFO - 2021-12-16 01:33:12 --> Language Class Initialized
INFO - 2021-12-16 01:33:12 --> Language Class Initialized
INFO - 2021-12-16 01:33:12 --> Config Class Initialized
INFO - 2021-12-16 01:33:12 --> Loader Class Initialized
INFO - 2021-12-16 01:33:12 --> Helper loaded: url_helper
INFO - 2021-12-16 01:33:12 --> Helper loaded: file_helper
INFO - 2021-12-16 01:33:12 --> Helper loaded: form_helper
INFO - 2021-12-16 01:33:12 --> Helper loaded: my_helper
INFO - 2021-12-16 01:33:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:33:12 --> Controller Class Initialized
INFO - 2021-12-16 01:33:12 --> Upload Class Initialized
INFO - 2021-12-16 01:33:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-12-16 01:33:12 --> The upload path does not appear to be valid.
INFO - 2021-12-16 01:33:12 --> Config Class Initialized
INFO - 2021-12-16 01:33:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:33:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:33:12 --> Utf8 Class Initialized
INFO - 2021-12-16 01:33:12 --> URI Class Initialized
INFO - 2021-12-16 01:33:12 --> Router Class Initialized
INFO - 2021-12-16 01:33:12 --> Output Class Initialized
INFO - 2021-12-16 01:33:12 --> Security Class Initialized
DEBUG - 2021-12-16 01:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:33:12 --> Input Class Initialized
INFO - 2021-12-16 01:33:12 --> Language Class Initialized
INFO - 2021-12-16 01:33:12 --> Language Class Initialized
INFO - 2021-12-16 01:33:12 --> Config Class Initialized
INFO - 2021-12-16 01:33:12 --> Loader Class Initialized
INFO - 2021-12-16 01:33:12 --> Helper loaded: url_helper
INFO - 2021-12-16 01:33:12 --> Helper loaded: file_helper
INFO - 2021-12-16 01:33:12 --> Helper loaded: form_helper
INFO - 2021-12-16 01:33:12 --> Helper loaded: my_helper
INFO - 2021-12-16 01:33:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:33:12 --> Controller Class Initialized
DEBUG - 2021-12-16 01:33:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 01:33:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:33:12 --> Final output sent to browser
DEBUG - 2021-12-16 01:33:12 --> Total execution time: 0.0370
INFO - 2021-12-16 01:33:13 --> Config Class Initialized
INFO - 2021-12-16 01:33:13 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:33:13 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:33:13 --> Utf8 Class Initialized
INFO - 2021-12-16 01:33:13 --> URI Class Initialized
INFO - 2021-12-16 01:33:13 --> Router Class Initialized
INFO - 2021-12-16 01:33:13 --> Output Class Initialized
INFO - 2021-12-16 01:33:13 --> Security Class Initialized
DEBUG - 2021-12-16 01:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:33:13 --> Input Class Initialized
INFO - 2021-12-16 01:33:13 --> Language Class Initialized
INFO - 2021-12-16 01:33:13 --> Language Class Initialized
INFO - 2021-12-16 01:33:13 --> Config Class Initialized
INFO - 2021-12-16 01:33:13 --> Loader Class Initialized
INFO - 2021-12-16 01:33:13 --> Helper loaded: url_helper
INFO - 2021-12-16 01:33:13 --> Helper loaded: file_helper
INFO - 2021-12-16 01:33:13 --> Helper loaded: form_helper
INFO - 2021-12-16 01:33:13 --> Helper loaded: my_helper
INFO - 2021-12-16 01:33:13 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:33:13 --> Controller Class Initialized
INFO - 2021-12-16 01:33:19 --> Config Class Initialized
INFO - 2021-12-16 01:33:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:33:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:33:19 --> Utf8 Class Initialized
INFO - 2021-12-16 01:33:19 --> URI Class Initialized
INFO - 2021-12-16 01:33:19 --> Router Class Initialized
INFO - 2021-12-16 01:33:19 --> Output Class Initialized
INFO - 2021-12-16 01:33:19 --> Security Class Initialized
DEBUG - 2021-12-16 01:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:33:19 --> Input Class Initialized
INFO - 2021-12-16 01:33:19 --> Language Class Initialized
INFO - 2021-12-16 01:33:19 --> Language Class Initialized
INFO - 2021-12-16 01:33:19 --> Config Class Initialized
INFO - 2021-12-16 01:33:19 --> Loader Class Initialized
INFO - 2021-12-16 01:33:19 --> Helper loaded: url_helper
INFO - 2021-12-16 01:33:19 --> Helper loaded: file_helper
INFO - 2021-12-16 01:33:19 --> Helper loaded: form_helper
INFO - 2021-12-16 01:33:19 --> Helper loaded: my_helper
INFO - 2021-12-16 01:33:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:33:19 --> Controller Class Initialized
DEBUG - 2021-12-16 01:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 01:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:33:19 --> Final output sent to browser
DEBUG - 2021-12-16 01:33:19 --> Total execution time: 0.0380
INFO - 2021-12-16 01:33:20 --> Config Class Initialized
INFO - 2021-12-16 01:33:20 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:33:20 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:33:20 --> Utf8 Class Initialized
INFO - 2021-12-16 01:33:20 --> URI Class Initialized
INFO - 2021-12-16 01:33:20 --> Router Class Initialized
INFO - 2021-12-16 01:33:20 --> Output Class Initialized
INFO - 2021-12-16 01:33:20 --> Security Class Initialized
DEBUG - 2021-12-16 01:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:33:20 --> Input Class Initialized
INFO - 2021-12-16 01:33:20 --> Language Class Initialized
INFO - 2021-12-16 01:33:20 --> Language Class Initialized
INFO - 2021-12-16 01:33:20 --> Config Class Initialized
INFO - 2021-12-16 01:33:20 --> Loader Class Initialized
INFO - 2021-12-16 01:33:20 --> Helper loaded: url_helper
INFO - 2021-12-16 01:33:20 --> Helper loaded: file_helper
INFO - 2021-12-16 01:33:20 --> Helper loaded: form_helper
INFO - 2021-12-16 01:33:20 --> Helper loaded: my_helper
INFO - 2021-12-16 01:33:20 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:33:20 --> Controller Class Initialized
DEBUG - 2021-12-16 01:33:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 01:33:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:33:20 --> Final output sent to browser
DEBUG - 2021-12-16 01:33:20 --> Total execution time: 0.0290
INFO - 2021-12-16 01:38:00 --> Config Class Initialized
INFO - 2021-12-16 01:38:00 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:38:00 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:38:00 --> Utf8 Class Initialized
INFO - 2021-12-16 01:38:00 --> URI Class Initialized
INFO - 2021-12-16 01:38:00 --> Router Class Initialized
INFO - 2021-12-16 01:38:00 --> Output Class Initialized
INFO - 2021-12-16 01:38:00 --> Security Class Initialized
DEBUG - 2021-12-16 01:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:38:00 --> Input Class Initialized
INFO - 2021-12-16 01:38:00 --> Language Class Initialized
INFO - 2021-12-16 01:38:00 --> Language Class Initialized
INFO - 2021-12-16 01:38:00 --> Config Class Initialized
INFO - 2021-12-16 01:38:00 --> Loader Class Initialized
INFO - 2021-12-16 01:38:00 --> Helper loaded: url_helper
INFO - 2021-12-16 01:38:00 --> Helper loaded: file_helper
INFO - 2021-12-16 01:38:00 --> Helper loaded: form_helper
INFO - 2021-12-16 01:38:00 --> Helper loaded: my_helper
INFO - 2021-12-16 01:38:00 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:38:00 --> Controller Class Initialized
INFO - 2021-12-16 01:38:00 --> Config Class Initialized
INFO - 2021-12-16 01:38:00 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:38:00 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:38:00 --> Utf8 Class Initialized
INFO - 2021-12-16 01:38:00 --> URI Class Initialized
INFO - 2021-12-16 01:38:00 --> Router Class Initialized
INFO - 2021-12-16 01:38:00 --> Output Class Initialized
INFO - 2021-12-16 01:38:00 --> Security Class Initialized
DEBUG - 2021-12-16 01:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:38:00 --> Input Class Initialized
INFO - 2021-12-16 01:38:00 --> Language Class Initialized
INFO - 2021-12-16 01:38:00 --> Language Class Initialized
INFO - 2021-12-16 01:38:00 --> Config Class Initialized
INFO - 2021-12-16 01:38:00 --> Loader Class Initialized
INFO - 2021-12-16 01:38:00 --> Helper loaded: url_helper
INFO - 2021-12-16 01:38:00 --> Helper loaded: file_helper
INFO - 2021-12-16 01:38:00 --> Helper loaded: form_helper
INFO - 2021-12-16 01:38:00 --> Helper loaded: my_helper
INFO - 2021-12-16 01:38:00 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:38:00 --> Controller Class Initialized
DEBUG - 2021-12-16 01:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 01:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:38:00 --> Final output sent to browser
DEBUG - 2021-12-16 01:38:00 --> Total execution time: 0.0420
INFO - 2021-12-16 01:38:25 --> Config Class Initialized
INFO - 2021-12-16 01:38:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:38:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:38:25 --> Utf8 Class Initialized
INFO - 2021-12-16 01:38:25 --> URI Class Initialized
INFO - 2021-12-16 01:38:25 --> Router Class Initialized
INFO - 2021-12-16 01:38:25 --> Output Class Initialized
INFO - 2021-12-16 01:38:25 --> Security Class Initialized
DEBUG - 2021-12-16 01:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:38:25 --> Input Class Initialized
INFO - 2021-12-16 01:38:25 --> Language Class Initialized
INFO - 2021-12-16 01:38:25 --> Language Class Initialized
INFO - 2021-12-16 01:38:25 --> Config Class Initialized
INFO - 2021-12-16 01:38:25 --> Loader Class Initialized
INFO - 2021-12-16 01:38:25 --> Helper loaded: url_helper
INFO - 2021-12-16 01:38:25 --> Helper loaded: file_helper
INFO - 2021-12-16 01:38:25 --> Helper loaded: form_helper
INFO - 2021-12-16 01:38:25 --> Helper loaded: my_helper
INFO - 2021-12-16 01:38:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:38:25 --> Controller Class Initialized
DEBUG - 2021-12-16 01:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 01:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:38:25 --> Final output sent to browser
DEBUG - 2021-12-16 01:38:25 --> Total execution time: 0.0510
INFO - 2021-12-16 01:40:07 --> Config Class Initialized
INFO - 2021-12-16 01:40:07 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:07 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:07 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:07 --> URI Class Initialized
INFO - 2021-12-16 01:40:07 --> Router Class Initialized
INFO - 2021-12-16 01:40:07 --> Output Class Initialized
INFO - 2021-12-16 01:40:07 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:07 --> Input Class Initialized
INFO - 2021-12-16 01:40:07 --> Language Class Initialized
INFO - 2021-12-16 01:40:07 --> Language Class Initialized
INFO - 2021-12-16 01:40:07 --> Config Class Initialized
INFO - 2021-12-16 01:40:07 --> Loader Class Initialized
INFO - 2021-12-16 01:40:07 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:07 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:07 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:07 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:07 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:07 --> Controller Class Initialized
INFO - 2021-12-16 01:40:07 --> Config Class Initialized
INFO - 2021-12-16 01:40:07 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:07 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:07 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:07 --> URI Class Initialized
INFO - 2021-12-16 01:40:07 --> Router Class Initialized
INFO - 2021-12-16 01:40:07 --> Output Class Initialized
INFO - 2021-12-16 01:40:07 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:07 --> Input Class Initialized
INFO - 2021-12-16 01:40:07 --> Language Class Initialized
INFO - 2021-12-16 01:40:07 --> Language Class Initialized
INFO - 2021-12-16 01:40:07 --> Config Class Initialized
INFO - 2021-12-16 01:40:07 --> Loader Class Initialized
INFO - 2021-12-16 01:40:07 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:07 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:07 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:07 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:07 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:07 --> Controller Class Initialized
DEBUG - 2021-12-16 01:40:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 01:40:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:40:07 --> Final output sent to browser
DEBUG - 2021-12-16 01:40:07 --> Total execution time: 0.0430
INFO - 2021-12-16 01:40:19 --> Config Class Initialized
INFO - 2021-12-16 01:40:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:19 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:19 --> URI Class Initialized
INFO - 2021-12-16 01:40:19 --> Router Class Initialized
INFO - 2021-12-16 01:40:19 --> Output Class Initialized
INFO - 2021-12-16 01:40:19 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:19 --> Input Class Initialized
INFO - 2021-12-16 01:40:19 --> Language Class Initialized
INFO - 2021-12-16 01:40:19 --> Language Class Initialized
INFO - 2021-12-16 01:40:19 --> Config Class Initialized
INFO - 2021-12-16 01:40:19 --> Loader Class Initialized
INFO - 2021-12-16 01:40:19 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:19 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:19 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:19 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:19 --> Controller Class Initialized
DEBUG - 2021-12-16 01:40:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 01:40:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:40:19 --> Final output sent to browser
DEBUG - 2021-12-16 01:40:19 --> Total execution time: 0.0410
INFO - 2021-12-16 01:40:20 --> Config Class Initialized
INFO - 2021-12-16 01:40:20 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:20 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:20 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:20 --> URI Class Initialized
INFO - 2021-12-16 01:40:20 --> Router Class Initialized
INFO - 2021-12-16 01:40:20 --> Output Class Initialized
INFO - 2021-12-16 01:40:20 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:20 --> Input Class Initialized
INFO - 2021-12-16 01:40:20 --> Language Class Initialized
INFO - 2021-12-16 01:40:20 --> Language Class Initialized
INFO - 2021-12-16 01:40:20 --> Config Class Initialized
INFO - 2021-12-16 01:40:20 --> Loader Class Initialized
INFO - 2021-12-16 01:40:20 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:20 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:20 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:20 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:20 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:20 --> Controller Class Initialized
INFO - 2021-12-16 01:40:21 --> Config Class Initialized
INFO - 2021-12-16 01:40:21 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:21 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:21 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:21 --> URI Class Initialized
INFO - 2021-12-16 01:40:21 --> Router Class Initialized
INFO - 2021-12-16 01:40:21 --> Output Class Initialized
INFO - 2021-12-16 01:40:21 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:21 --> Input Class Initialized
INFO - 2021-12-16 01:40:21 --> Language Class Initialized
INFO - 2021-12-16 01:40:21 --> Language Class Initialized
INFO - 2021-12-16 01:40:21 --> Config Class Initialized
INFO - 2021-12-16 01:40:21 --> Loader Class Initialized
INFO - 2021-12-16 01:40:21 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:21 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:21 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:21 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:21 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:21 --> Controller Class Initialized
ERROR - 2021-12-16 01:40:21 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-16 01:40:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-16 01:40:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:40:21 --> Final output sent to browser
DEBUG - 2021-12-16 01:40:21 --> Total execution time: 0.0510
INFO - 2021-12-16 01:40:38 --> Config Class Initialized
INFO - 2021-12-16 01:40:38 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:38 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:38 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:38 --> URI Class Initialized
INFO - 2021-12-16 01:40:38 --> Router Class Initialized
INFO - 2021-12-16 01:40:38 --> Output Class Initialized
INFO - 2021-12-16 01:40:38 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:38 --> Input Class Initialized
INFO - 2021-12-16 01:40:38 --> Language Class Initialized
INFO - 2021-12-16 01:40:38 --> Language Class Initialized
INFO - 2021-12-16 01:40:38 --> Config Class Initialized
INFO - 2021-12-16 01:40:38 --> Loader Class Initialized
INFO - 2021-12-16 01:40:38 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:38 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:38 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:38 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:38 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:38 --> Controller Class Initialized
DEBUG - 2021-12-16 01:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 01:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:40:38 --> Final output sent to browser
DEBUG - 2021-12-16 01:40:38 --> Total execution time: 0.0350
INFO - 2021-12-16 01:40:38 --> Config Class Initialized
INFO - 2021-12-16 01:40:38 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:38 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:38 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:38 --> URI Class Initialized
INFO - 2021-12-16 01:40:38 --> Router Class Initialized
INFO - 2021-12-16 01:40:38 --> Output Class Initialized
INFO - 2021-12-16 01:40:38 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:38 --> Input Class Initialized
INFO - 2021-12-16 01:40:38 --> Language Class Initialized
INFO - 2021-12-16 01:40:38 --> Language Class Initialized
INFO - 2021-12-16 01:40:38 --> Config Class Initialized
INFO - 2021-12-16 01:40:38 --> Loader Class Initialized
INFO - 2021-12-16 01:40:38 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:38 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:38 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:38 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:38 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:38 --> Controller Class Initialized
INFO - 2021-12-16 01:40:41 --> Config Class Initialized
INFO - 2021-12-16 01:40:41 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:41 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:41 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:41 --> URI Class Initialized
INFO - 2021-12-16 01:40:41 --> Router Class Initialized
INFO - 2021-12-16 01:40:41 --> Output Class Initialized
INFO - 2021-12-16 01:40:41 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:41 --> Input Class Initialized
INFO - 2021-12-16 01:40:41 --> Language Class Initialized
INFO - 2021-12-16 01:40:41 --> Language Class Initialized
INFO - 2021-12-16 01:40:41 --> Config Class Initialized
INFO - 2021-12-16 01:40:41 --> Loader Class Initialized
INFO - 2021-12-16 01:40:41 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:41 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:41 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:41 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:41 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:41 --> Controller Class Initialized
DEBUG - 2021-12-16 01:40:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 01:40:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:40:41 --> Final output sent to browser
DEBUG - 2021-12-16 01:40:41 --> Total execution time: 0.0330
INFO - 2021-12-16 01:40:54 --> Config Class Initialized
INFO - 2021-12-16 01:40:54 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:54 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:54 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:54 --> URI Class Initialized
INFO - 2021-12-16 01:40:54 --> Router Class Initialized
INFO - 2021-12-16 01:40:54 --> Output Class Initialized
INFO - 2021-12-16 01:40:54 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:54 --> Input Class Initialized
INFO - 2021-12-16 01:40:54 --> Language Class Initialized
INFO - 2021-12-16 01:40:54 --> Language Class Initialized
INFO - 2021-12-16 01:40:54 --> Config Class Initialized
INFO - 2021-12-16 01:40:54 --> Loader Class Initialized
INFO - 2021-12-16 01:40:54 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:54 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:54 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:54 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:54 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:54 --> Controller Class Initialized
DEBUG - 2021-12-16 01:40:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 01:40:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:40:54 --> Final output sent to browser
DEBUG - 2021-12-16 01:40:54 --> Total execution time: 0.0350
INFO - 2021-12-16 01:40:54 --> Config Class Initialized
INFO - 2021-12-16 01:40:54 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:54 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:54 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:54 --> URI Class Initialized
INFO - 2021-12-16 01:40:54 --> Router Class Initialized
INFO - 2021-12-16 01:40:54 --> Output Class Initialized
INFO - 2021-12-16 01:40:54 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:54 --> Input Class Initialized
INFO - 2021-12-16 01:40:54 --> Language Class Initialized
INFO - 2021-12-16 01:40:54 --> Language Class Initialized
INFO - 2021-12-16 01:40:54 --> Config Class Initialized
INFO - 2021-12-16 01:40:54 --> Loader Class Initialized
INFO - 2021-12-16 01:40:54 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:54 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:54 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:54 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:54 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:54 --> Controller Class Initialized
INFO - 2021-12-16 01:40:55 --> Config Class Initialized
INFO - 2021-12-16 01:40:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:40:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:40:55 --> Utf8 Class Initialized
INFO - 2021-12-16 01:40:55 --> URI Class Initialized
INFO - 2021-12-16 01:40:55 --> Router Class Initialized
INFO - 2021-12-16 01:40:55 --> Output Class Initialized
INFO - 2021-12-16 01:40:55 --> Security Class Initialized
DEBUG - 2021-12-16 01:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:40:55 --> Input Class Initialized
INFO - 2021-12-16 01:40:55 --> Language Class Initialized
INFO - 2021-12-16 01:40:55 --> Language Class Initialized
INFO - 2021-12-16 01:40:55 --> Config Class Initialized
INFO - 2021-12-16 01:40:55 --> Loader Class Initialized
INFO - 2021-12-16 01:40:55 --> Helper loaded: url_helper
INFO - 2021-12-16 01:40:55 --> Helper loaded: file_helper
INFO - 2021-12-16 01:40:55 --> Helper loaded: form_helper
INFO - 2021-12-16 01:40:55 --> Helper loaded: my_helper
INFO - 2021-12-16 01:40:55 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:40:55 --> Controller Class Initialized
ERROR - 2021-12-16 01:40:55 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-16 01:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-16 01:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:40:55 --> Final output sent to browser
DEBUG - 2021-12-16 01:40:55 --> Total execution time: 0.0490
INFO - 2021-12-16 01:44:12 --> Config Class Initialized
INFO - 2021-12-16 01:44:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:44:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:44:12 --> Utf8 Class Initialized
INFO - 2021-12-16 01:44:12 --> URI Class Initialized
INFO - 2021-12-16 01:44:12 --> Router Class Initialized
INFO - 2021-12-16 01:44:12 --> Output Class Initialized
INFO - 2021-12-16 01:44:12 --> Security Class Initialized
DEBUG - 2021-12-16 01:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:44:12 --> Input Class Initialized
INFO - 2021-12-16 01:44:12 --> Language Class Initialized
INFO - 2021-12-16 01:44:12 --> Language Class Initialized
INFO - 2021-12-16 01:44:12 --> Config Class Initialized
INFO - 2021-12-16 01:44:12 --> Loader Class Initialized
INFO - 2021-12-16 01:44:12 --> Helper loaded: url_helper
INFO - 2021-12-16 01:44:12 --> Helper loaded: file_helper
INFO - 2021-12-16 01:44:12 --> Helper loaded: form_helper
INFO - 2021-12-16 01:44:12 --> Helper loaded: my_helper
INFO - 2021-12-16 01:44:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:44:12 --> Controller Class Initialized
INFO - 2021-12-16 01:44:12 --> Upload Class Initialized
INFO - 2021-12-16 01:44:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-12-16 01:44:12 --> The upload path does not appear to be valid.
INFO - 2021-12-16 01:44:12 --> Config Class Initialized
INFO - 2021-12-16 01:44:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:44:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:44:12 --> Utf8 Class Initialized
INFO - 2021-12-16 01:44:12 --> URI Class Initialized
INFO - 2021-12-16 01:44:12 --> Router Class Initialized
INFO - 2021-12-16 01:44:12 --> Output Class Initialized
INFO - 2021-12-16 01:44:12 --> Security Class Initialized
DEBUG - 2021-12-16 01:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:44:12 --> Input Class Initialized
INFO - 2021-12-16 01:44:12 --> Language Class Initialized
INFO - 2021-12-16 01:44:12 --> Language Class Initialized
INFO - 2021-12-16 01:44:12 --> Config Class Initialized
INFO - 2021-12-16 01:44:12 --> Loader Class Initialized
INFO - 2021-12-16 01:44:12 --> Helper loaded: url_helper
INFO - 2021-12-16 01:44:12 --> Helper loaded: file_helper
INFO - 2021-12-16 01:44:12 --> Helper loaded: form_helper
INFO - 2021-12-16 01:44:12 --> Helper loaded: my_helper
INFO - 2021-12-16 01:44:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:44:12 --> Controller Class Initialized
DEBUG - 2021-12-16 01:44:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 01:44:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:44:12 --> Final output sent to browser
DEBUG - 2021-12-16 01:44:12 --> Total execution time: 0.0360
INFO - 2021-12-16 01:44:12 --> Config Class Initialized
INFO - 2021-12-16 01:44:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:44:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:44:12 --> Utf8 Class Initialized
INFO - 2021-12-16 01:44:12 --> URI Class Initialized
INFO - 2021-12-16 01:44:12 --> Router Class Initialized
INFO - 2021-12-16 01:44:12 --> Output Class Initialized
INFO - 2021-12-16 01:44:12 --> Security Class Initialized
DEBUG - 2021-12-16 01:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:44:12 --> Input Class Initialized
INFO - 2021-12-16 01:44:12 --> Language Class Initialized
INFO - 2021-12-16 01:44:12 --> Language Class Initialized
INFO - 2021-12-16 01:44:12 --> Config Class Initialized
INFO - 2021-12-16 01:44:12 --> Loader Class Initialized
INFO - 2021-12-16 01:44:12 --> Helper loaded: url_helper
INFO - 2021-12-16 01:44:12 --> Helper loaded: file_helper
INFO - 2021-12-16 01:44:12 --> Helper loaded: form_helper
INFO - 2021-12-16 01:44:12 --> Helper loaded: my_helper
INFO - 2021-12-16 01:44:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:44:12 --> Controller Class Initialized
INFO - 2021-12-16 01:44:14 --> Config Class Initialized
INFO - 2021-12-16 01:44:14 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:44:14 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:44:14 --> Utf8 Class Initialized
INFO - 2021-12-16 01:44:14 --> URI Class Initialized
INFO - 2021-12-16 01:44:14 --> Router Class Initialized
INFO - 2021-12-16 01:44:14 --> Output Class Initialized
INFO - 2021-12-16 01:44:14 --> Security Class Initialized
DEBUG - 2021-12-16 01:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:44:14 --> Input Class Initialized
INFO - 2021-12-16 01:44:14 --> Language Class Initialized
INFO - 2021-12-16 01:44:14 --> Language Class Initialized
INFO - 2021-12-16 01:44:14 --> Config Class Initialized
INFO - 2021-12-16 01:44:14 --> Loader Class Initialized
INFO - 2021-12-16 01:44:14 --> Helper loaded: url_helper
INFO - 2021-12-16 01:44:14 --> Helper loaded: file_helper
INFO - 2021-12-16 01:44:14 --> Helper loaded: form_helper
INFO - 2021-12-16 01:44:14 --> Helper loaded: my_helper
INFO - 2021-12-16 01:44:14 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:44:14 --> Controller Class Initialized
ERROR - 2021-12-16 01:44:14 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-16 01:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-16 01:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:44:14 --> Final output sent to browser
DEBUG - 2021-12-16 01:44:14 --> Total execution time: 0.0280
INFO - 2021-12-16 01:44:16 --> Config Class Initialized
INFO - 2021-12-16 01:44:16 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:44:16 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:44:16 --> Utf8 Class Initialized
INFO - 2021-12-16 01:44:16 --> URI Class Initialized
INFO - 2021-12-16 01:44:16 --> Router Class Initialized
INFO - 2021-12-16 01:44:16 --> Output Class Initialized
INFO - 2021-12-16 01:44:16 --> Security Class Initialized
DEBUG - 2021-12-16 01:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:44:16 --> Input Class Initialized
INFO - 2021-12-16 01:44:16 --> Language Class Initialized
INFO - 2021-12-16 01:44:16 --> Language Class Initialized
INFO - 2021-12-16 01:44:16 --> Config Class Initialized
INFO - 2021-12-16 01:44:16 --> Loader Class Initialized
INFO - 2021-12-16 01:44:16 --> Helper loaded: url_helper
INFO - 2021-12-16 01:44:16 --> Helper loaded: file_helper
INFO - 2021-12-16 01:44:16 --> Helper loaded: form_helper
INFO - 2021-12-16 01:44:16 --> Helper loaded: my_helper
INFO - 2021-12-16 01:44:16 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:44:16 --> Controller Class Initialized
DEBUG - 2021-12-16 01:44:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 01:44:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:44:16 --> Final output sent to browser
DEBUG - 2021-12-16 01:44:16 --> Total execution time: 0.0340
INFO - 2021-12-16 01:44:17 --> Config Class Initialized
INFO - 2021-12-16 01:44:17 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:44:17 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:44:17 --> Utf8 Class Initialized
INFO - 2021-12-16 01:44:17 --> URI Class Initialized
INFO - 2021-12-16 01:44:17 --> Router Class Initialized
INFO - 2021-12-16 01:44:17 --> Output Class Initialized
INFO - 2021-12-16 01:44:17 --> Security Class Initialized
DEBUG - 2021-12-16 01:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:44:17 --> Input Class Initialized
INFO - 2021-12-16 01:44:17 --> Language Class Initialized
INFO - 2021-12-16 01:44:17 --> Language Class Initialized
INFO - 2021-12-16 01:44:17 --> Config Class Initialized
INFO - 2021-12-16 01:44:17 --> Loader Class Initialized
INFO - 2021-12-16 01:44:17 --> Helper loaded: url_helper
INFO - 2021-12-16 01:44:17 --> Helper loaded: file_helper
INFO - 2021-12-16 01:44:17 --> Helper loaded: form_helper
INFO - 2021-12-16 01:44:17 --> Helper loaded: my_helper
INFO - 2021-12-16 01:44:17 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:44:17 --> Controller Class Initialized
DEBUG - 2021-12-16 01:44:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 01:44:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:44:17 --> Final output sent to browser
DEBUG - 2021-12-16 01:44:17 --> Total execution time: 0.0290
INFO - 2021-12-16 01:57:08 --> Config Class Initialized
INFO - 2021-12-16 01:57:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:57:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:57:08 --> Utf8 Class Initialized
INFO - 2021-12-16 01:57:08 --> URI Class Initialized
INFO - 2021-12-16 01:57:08 --> Router Class Initialized
INFO - 2021-12-16 01:57:08 --> Output Class Initialized
INFO - 2021-12-16 01:57:08 --> Security Class Initialized
DEBUG - 2021-12-16 01:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:57:08 --> Input Class Initialized
INFO - 2021-12-16 01:57:08 --> Language Class Initialized
INFO - 2021-12-16 01:57:08 --> Language Class Initialized
INFO - 2021-12-16 01:57:08 --> Config Class Initialized
INFO - 2021-12-16 01:57:08 --> Loader Class Initialized
INFO - 2021-12-16 01:57:08 --> Helper loaded: url_helper
INFO - 2021-12-16 01:57:08 --> Helper loaded: file_helper
INFO - 2021-12-16 01:57:08 --> Helper loaded: form_helper
INFO - 2021-12-16 01:57:08 --> Helper loaded: my_helper
INFO - 2021-12-16 01:57:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:57:08 --> Controller Class Initialized
INFO - 2021-12-16 01:57:08 --> Config Class Initialized
INFO - 2021-12-16 01:57:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:57:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:57:08 --> Utf8 Class Initialized
INFO - 2021-12-16 01:57:08 --> URI Class Initialized
INFO - 2021-12-16 01:57:08 --> Router Class Initialized
INFO - 2021-12-16 01:57:08 --> Output Class Initialized
INFO - 2021-12-16 01:57:08 --> Security Class Initialized
DEBUG - 2021-12-16 01:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:57:08 --> Input Class Initialized
INFO - 2021-12-16 01:57:08 --> Language Class Initialized
INFO - 2021-12-16 01:57:08 --> Language Class Initialized
INFO - 2021-12-16 01:57:08 --> Config Class Initialized
INFO - 2021-12-16 01:57:08 --> Loader Class Initialized
INFO - 2021-12-16 01:57:08 --> Helper loaded: url_helper
INFO - 2021-12-16 01:57:08 --> Helper loaded: file_helper
INFO - 2021-12-16 01:57:08 --> Helper loaded: form_helper
INFO - 2021-12-16 01:57:08 --> Helper loaded: my_helper
INFO - 2021-12-16 01:57:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:57:08 --> Controller Class Initialized
DEBUG - 2021-12-16 01:57:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 01:57:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:57:08 --> Final output sent to browser
DEBUG - 2021-12-16 01:57:08 --> Total execution time: 0.0420
INFO - 2021-12-16 01:57:28 --> Config Class Initialized
INFO - 2021-12-16 01:57:28 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:57:28 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:57:28 --> Utf8 Class Initialized
INFO - 2021-12-16 01:57:28 --> URI Class Initialized
INFO - 2021-12-16 01:57:28 --> Router Class Initialized
INFO - 2021-12-16 01:57:28 --> Output Class Initialized
INFO - 2021-12-16 01:57:28 --> Security Class Initialized
DEBUG - 2021-12-16 01:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:57:28 --> Input Class Initialized
INFO - 2021-12-16 01:57:28 --> Language Class Initialized
INFO - 2021-12-16 01:57:28 --> Language Class Initialized
INFO - 2021-12-16 01:57:28 --> Config Class Initialized
INFO - 2021-12-16 01:57:28 --> Loader Class Initialized
INFO - 2021-12-16 01:57:28 --> Helper loaded: url_helper
INFO - 2021-12-16 01:57:28 --> Helper loaded: file_helper
INFO - 2021-12-16 01:57:28 --> Helper loaded: form_helper
INFO - 2021-12-16 01:57:28 --> Helper loaded: my_helper
INFO - 2021-12-16 01:57:28 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:57:28 --> Controller Class Initialized
DEBUG - 2021-12-16 01:57:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 01:57:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:57:28 --> Final output sent to browser
DEBUG - 2021-12-16 01:57:28 --> Total execution time: 0.0440
INFO - 2021-12-16 01:58:14 --> Config Class Initialized
INFO - 2021-12-16 01:58:14 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:14 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:14 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:14 --> URI Class Initialized
INFO - 2021-12-16 01:58:14 --> Router Class Initialized
INFO - 2021-12-16 01:58:14 --> Output Class Initialized
INFO - 2021-12-16 01:58:14 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:14 --> Input Class Initialized
INFO - 2021-12-16 01:58:14 --> Language Class Initialized
INFO - 2021-12-16 01:58:14 --> Language Class Initialized
INFO - 2021-12-16 01:58:14 --> Config Class Initialized
INFO - 2021-12-16 01:58:14 --> Loader Class Initialized
INFO - 2021-12-16 01:58:14 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:14 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:14 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:14 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:14 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:14 --> Controller Class Initialized
INFO - 2021-12-16 01:58:14 --> Config Class Initialized
INFO - 2021-12-16 01:58:14 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:14 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:14 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:14 --> URI Class Initialized
INFO - 2021-12-16 01:58:14 --> Router Class Initialized
INFO - 2021-12-16 01:58:14 --> Output Class Initialized
INFO - 2021-12-16 01:58:14 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:14 --> Input Class Initialized
INFO - 2021-12-16 01:58:14 --> Language Class Initialized
INFO - 2021-12-16 01:58:14 --> Language Class Initialized
INFO - 2021-12-16 01:58:14 --> Config Class Initialized
INFO - 2021-12-16 01:58:14 --> Loader Class Initialized
INFO - 2021-12-16 01:58:14 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:14 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:14 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:14 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:14 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:14 --> Controller Class Initialized
DEBUG - 2021-12-16 01:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 01:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:58:14 --> Final output sent to browser
DEBUG - 2021-12-16 01:58:14 --> Total execution time: 0.0430
INFO - 2021-12-16 01:58:24 --> Config Class Initialized
INFO - 2021-12-16 01:58:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:24 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:24 --> URI Class Initialized
INFO - 2021-12-16 01:58:24 --> Router Class Initialized
INFO - 2021-12-16 01:58:24 --> Output Class Initialized
INFO - 2021-12-16 01:58:24 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:24 --> Input Class Initialized
INFO - 2021-12-16 01:58:24 --> Language Class Initialized
INFO - 2021-12-16 01:58:24 --> Language Class Initialized
INFO - 2021-12-16 01:58:24 --> Config Class Initialized
INFO - 2021-12-16 01:58:24 --> Loader Class Initialized
INFO - 2021-12-16 01:58:24 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:24 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:24 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:24 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:24 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:24 --> Controller Class Initialized
DEBUG - 2021-12-16 01:58:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 01:58:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:58:25 --> Final output sent to browser
DEBUG - 2021-12-16 01:58:25 --> Total execution time: 0.0350
INFO - 2021-12-16 01:58:25 --> Config Class Initialized
INFO - 2021-12-16 01:58:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:25 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:25 --> URI Class Initialized
INFO - 2021-12-16 01:58:25 --> Router Class Initialized
INFO - 2021-12-16 01:58:25 --> Output Class Initialized
INFO - 2021-12-16 01:58:25 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:25 --> Input Class Initialized
INFO - 2021-12-16 01:58:25 --> Language Class Initialized
INFO - 2021-12-16 01:58:25 --> Language Class Initialized
INFO - 2021-12-16 01:58:25 --> Config Class Initialized
INFO - 2021-12-16 01:58:25 --> Loader Class Initialized
INFO - 2021-12-16 01:58:25 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:25 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:25 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:25 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:25 --> Controller Class Initialized
INFO - 2021-12-16 01:58:26 --> Config Class Initialized
INFO - 2021-12-16 01:58:26 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:26 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:26 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:26 --> URI Class Initialized
INFO - 2021-12-16 01:58:26 --> Router Class Initialized
INFO - 2021-12-16 01:58:26 --> Output Class Initialized
INFO - 2021-12-16 01:58:26 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:26 --> Input Class Initialized
INFO - 2021-12-16 01:58:26 --> Language Class Initialized
INFO - 2021-12-16 01:58:26 --> Language Class Initialized
INFO - 2021-12-16 01:58:26 --> Config Class Initialized
INFO - 2021-12-16 01:58:26 --> Loader Class Initialized
INFO - 2021-12-16 01:58:26 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:26 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:26 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:26 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:26 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:26 --> Controller Class Initialized
INFO - 2021-12-16 01:58:27 --> Config Class Initialized
INFO - 2021-12-16 01:58:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:27 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:27 --> URI Class Initialized
INFO - 2021-12-16 01:58:27 --> Router Class Initialized
INFO - 2021-12-16 01:58:27 --> Output Class Initialized
INFO - 2021-12-16 01:58:27 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:27 --> Input Class Initialized
INFO - 2021-12-16 01:58:27 --> Language Class Initialized
INFO - 2021-12-16 01:58:27 --> Language Class Initialized
INFO - 2021-12-16 01:58:27 --> Config Class Initialized
INFO - 2021-12-16 01:58:27 --> Loader Class Initialized
INFO - 2021-12-16 01:58:27 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:27 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:27 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:27 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:27 --> Controller Class Initialized
INFO - 2021-12-16 01:58:27 --> Config Class Initialized
INFO - 2021-12-16 01:58:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:27 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:27 --> URI Class Initialized
INFO - 2021-12-16 01:58:27 --> Router Class Initialized
INFO - 2021-12-16 01:58:27 --> Output Class Initialized
INFO - 2021-12-16 01:58:27 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:27 --> Input Class Initialized
INFO - 2021-12-16 01:58:27 --> Language Class Initialized
INFO - 2021-12-16 01:58:27 --> Language Class Initialized
INFO - 2021-12-16 01:58:27 --> Config Class Initialized
INFO - 2021-12-16 01:58:27 --> Loader Class Initialized
INFO - 2021-12-16 01:58:27 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:27 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:27 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:27 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:27 --> Controller Class Initialized
INFO - 2021-12-16 01:58:28 --> Config Class Initialized
INFO - 2021-12-16 01:58:28 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:28 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:28 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:28 --> URI Class Initialized
INFO - 2021-12-16 01:58:28 --> Router Class Initialized
INFO - 2021-12-16 01:58:28 --> Output Class Initialized
INFO - 2021-12-16 01:58:28 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:28 --> Input Class Initialized
INFO - 2021-12-16 01:58:28 --> Language Class Initialized
INFO - 2021-12-16 01:58:28 --> Language Class Initialized
INFO - 2021-12-16 01:58:28 --> Config Class Initialized
INFO - 2021-12-16 01:58:28 --> Loader Class Initialized
INFO - 2021-12-16 01:58:28 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:28 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:28 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:28 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:28 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:28 --> Controller Class Initialized
INFO - 2021-12-16 01:58:29 --> Config Class Initialized
INFO - 2021-12-16 01:58:29 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:29 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:29 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:29 --> URI Class Initialized
INFO - 2021-12-16 01:58:29 --> Router Class Initialized
INFO - 2021-12-16 01:58:29 --> Output Class Initialized
INFO - 2021-12-16 01:58:29 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:29 --> Input Class Initialized
INFO - 2021-12-16 01:58:29 --> Language Class Initialized
INFO - 2021-12-16 01:58:29 --> Language Class Initialized
INFO - 2021-12-16 01:58:29 --> Config Class Initialized
INFO - 2021-12-16 01:58:29 --> Loader Class Initialized
INFO - 2021-12-16 01:58:29 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:29 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:29 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:29 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:29 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:29 --> Controller Class Initialized
INFO - 2021-12-16 01:58:29 --> Config Class Initialized
INFO - 2021-12-16 01:58:29 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:29 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:29 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:29 --> URI Class Initialized
INFO - 2021-12-16 01:58:29 --> Router Class Initialized
INFO - 2021-12-16 01:58:29 --> Output Class Initialized
INFO - 2021-12-16 01:58:29 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:29 --> Input Class Initialized
INFO - 2021-12-16 01:58:29 --> Language Class Initialized
INFO - 2021-12-16 01:58:29 --> Language Class Initialized
INFO - 2021-12-16 01:58:29 --> Config Class Initialized
INFO - 2021-12-16 01:58:29 --> Loader Class Initialized
INFO - 2021-12-16 01:58:29 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:29 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:29 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:29 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:29 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:29 --> Controller Class Initialized
INFO - 2021-12-16 01:58:30 --> Config Class Initialized
INFO - 2021-12-16 01:58:30 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:30 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:30 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:30 --> URI Class Initialized
INFO - 2021-12-16 01:58:30 --> Router Class Initialized
INFO - 2021-12-16 01:58:30 --> Output Class Initialized
INFO - 2021-12-16 01:58:30 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:30 --> Input Class Initialized
INFO - 2021-12-16 01:58:30 --> Language Class Initialized
INFO - 2021-12-16 01:58:30 --> Language Class Initialized
INFO - 2021-12-16 01:58:30 --> Config Class Initialized
INFO - 2021-12-16 01:58:30 --> Loader Class Initialized
INFO - 2021-12-16 01:58:30 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:30 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:30 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:30 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:30 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:30 --> Controller Class Initialized
INFO - 2021-12-16 01:58:31 --> Config Class Initialized
INFO - 2021-12-16 01:58:31 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:31 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:31 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:31 --> URI Class Initialized
INFO - 2021-12-16 01:58:31 --> Router Class Initialized
INFO - 2021-12-16 01:58:31 --> Output Class Initialized
INFO - 2021-12-16 01:58:31 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:31 --> Input Class Initialized
INFO - 2021-12-16 01:58:31 --> Language Class Initialized
INFO - 2021-12-16 01:58:31 --> Language Class Initialized
INFO - 2021-12-16 01:58:31 --> Config Class Initialized
INFO - 2021-12-16 01:58:31 --> Loader Class Initialized
INFO - 2021-12-16 01:58:31 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:31 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:31 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:31 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:31 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:31 --> Controller Class Initialized
ERROR - 2021-12-16 01:58:31 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-16 01:58:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-16 01:58:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:58:31 --> Final output sent to browser
DEBUG - 2021-12-16 01:58:31 --> Total execution time: 0.0540
INFO - 2021-12-16 01:58:40 --> Config Class Initialized
INFO - 2021-12-16 01:58:40 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:40 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:40 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:40 --> URI Class Initialized
INFO - 2021-12-16 01:58:40 --> Router Class Initialized
INFO - 2021-12-16 01:58:40 --> Output Class Initialized
INFO - 2021-12-16 01:58:40 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:40 --> Input Class Initialized
INFO - 2021-12-16 01:58:40 --> Language Class Initialized
INFO - 2021-12-16 01:58:40 --> Language Class Initialized
INFO - 2021-12-16 01:58:40 --> Config Class Initialized
INFO - 2021-12-16 01:58:40 --> Loader Class Initialized
INFO - 2021-12-16 01:58:40 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:40 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:40 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:40 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:40 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:40 --> Controller Class Initialized
INFO - 2021-12-16 01:58:40 --> Upload Class Initialized
INFO - 2021-12-16 01:58:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-12-16 01:58:40 --> The upload path does not appear to be valid.
INFO - 2021-12-16 01:58:40 --> Config Class Initialized
INFO - 2021-12-16 01:58:40 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:40 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:40 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:40 --> URI Class Initialized
INFO - 2021-12-16 01:58:40 --> Router Class Initialized
INFO - 2021-12-16 01:58:40 --> Output Class Initialized
INFO - 2021-12-16 01:58:40 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:40 --> Input Class Initialized
INFO - 2021-12-16 01:58:40 --> Language Class Initialized
INFO - 2021-12-16 01:58:40 --> Language Class Initialized
INFO - 2021-12-16 01:58:40 --> Config Class Initialized
INFO - 2021-12-16 01:58:40 --> Loader Class Initialized
INFO - 2021-12-16 01:58:40 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:40 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:40 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:40 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:40 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:40 --> Controller Class Initialized
DEBUG - 2021-12-16 01:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 01:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:58:40 --> Final output sent to browser
DEBUG - 2021-12-16 01:58:40 --> Total execution time: 0.0350
INFO - 2021-12-16 01:58:40 --> Config Class Initialized
INFO - 2021-12-16 01:58:40 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:40 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:40 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:40 --> URI Class Initialized
INFO - 2021-12-16 01:58:40 --> Router Class Initialized
INFO - 2021-12-16 01:58:40 --> Output Class Initialized
INFO - 2021-12-16 01:58:41 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:41 --> Input Class Initialized
INFO - 2021-12-16 01:58:41 --> Language Class Initialized
INFO - 2021-12-16 01:58:41 --> Language Class Initialized
INFO - 2021-12-16 01:58:41 --> Config Class Initialized
INFO - 2021-12-16 01:58:41 --> Loader Class Initialized
INFO - 2021-12-16 01:58:41 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:41 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:41 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:41 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:41 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:41 --> Controller Class Initialized
INFO - 2021-12-16 01:58:55 --> Config Class Initialized
INFO - 2021-12-16 01:58:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:55 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:55 --> URI Class Initialized
INFO - 2021-12-16 01:58:55 --> Router Class Initialized
INFO - 2021-12-16 01:58:55 --> Output Class Initialized
INFO - 2021-12-16 01:58:55 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:55 --> Input Class Initialized
INFO - 2021-12-16 01:58:56 --> Language Class Initialized
INFO - 2021-12-16 01:58:56 --> Language Class Initialized
INFO - 2021-12-16 01:58:56 --> Config Class Initialized
INFO - 2021-12-16 01:58:56 --> Loader Class Initialized
INFO - 2021-12-16 01:58:56 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:56 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:56 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:56 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:56 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:56 --> Controller Class Initialized
INFO - 2021-12-16 01:58:56 --> Config Class Initialized
INFO - 2021-12-16 01:58:56 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:56 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:56 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:56 --> URI Class Initialized
INFO - 2021-12-16 01:58:56 --> Router Class Initialized
INFO - 2021-12-16 01:58:56 --> Output Class Initialized
INFO - 2021-12-16 01:58:56 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:56 --> Input Class Initialized
INFO - 2021-12-16 01:58:56 --> Language Class Initialized
INFO - 2021-12-16 01:58:56 --> Language Class Initialized
INFO - 2021-12-16 01:58:56 --> Config Class Initialized
INFO - 2021-12-16 01:58:56 --> Loader Class Initialized
INFO - 2021-12-16 01:58:56 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:56 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:56 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:56 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:56 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:56 --> Controller Class Initialized
INFO - 2021-12-16 01:58:57 --> Config Class Initialized
INFO - 2021-12-16 01:58:57 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:57 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:57 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:57 --> URI Class Initialized
INFO - 2021-12-16 01:58:58 --> Router Class Initialized
INFO - 2021-12-16 01:58:58 --> Output Class Initialized
INFO - 2021-12-16 01:58:58 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:58 --> Input Class Initialized
INFO - 2021-12-16 01:58:58 --> Language Class Initialized
INFO - 2021-12-16 01:58:58 --> Language Class Initialized
INFO - 2021-12-16 01:58:58 --> Config Class Initialized
INFO - 2021-12-16 01:58:58 --> Loader Class Initialized
INFO - 2021-12-16 01:58:58 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:58 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:58 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:58 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:58 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:58 --> Controller Class Initialized
INFO - 2021-12-16 01:58:59 --> Config Class Initialized
INFO - 2021-12-16 01:58:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:59 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:59 --> URI Class Initialized
INFO - 2021-12-16 01:58:59 --> Router Class Initialized
INFO - 2021-12-16 01:58:59 --> Output Class Initialized
INFO - 2021-12-16 01:58:59 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:59 --> Input Class Initialized
INFO - 2021-12-16 01:58:59 --> Language Class Initialized
INFO - 2021-12-16 01:58:59 --> Language Class Initialized
INFO - 2021-12-16 01:58:59 --> Config Class Initialized
INFO - 2021-12-16 01:58:59 --> Loader Class Initialized
INFO - 2021-12-16 01:58:59 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:59 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:59 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:59 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:59 --> Controller Class Initialized
INFO - 2021-12-16 01:58:59 --> Config Class Initialized
INFO - 2021-12-16 01:58:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:58:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:58:59 --> Utf8 Class Initialized
INFO - 2021-12-16 01:58:59 --> URI Class Initialized
INFO - 2021-12-16 01:58:59 --> Router Class Initialized
INFO - 2021-12-16 01:58:59 --> Output Class Initialized
INFO - 2021-12-16 01:58:59 --> Security Class Initialized
DEBUG - 2021-12-16 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:58:59 --> Input Class Initialized
INFO - 2021-12-16 01:58:59 --> Language Class Initialized
INFO - 2021-12-16 01:58:59 --> Language Class Initialized
INFO - 2021-12-16 01:58:59 --> Config Class Initialized
INFO - 2021-12-16 01:58:59 --> Loader Class Initialized
INFO - 2021-12-16 01:58:59 --> Helper loaded: url_helper
INFO - 2021-12-16 01:58:59 --> Helper loaded: file_helper
INFO - 2021-12-16 01:58:59 --> Helper loaded: form_helper
INFO - 2021-12-16 01:58:59 --> Helper loaded: my_helper
INFO - 2021-12-16 01:58:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:58:59 --> Controller Class Initialized
INFO - 2021-12-16 01:59:02 --> Config Class Initialized
INFO - 2021-12-16 01:59:02 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:59:02 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:59:02 --> Utf8 Class Initialized
INFO - 2021-12-16 01:59:02 --> URI Class Initialized
INFO - 2021-12-16 01:59:02 --> Router Class Initialized
INFO - 2021-12-16 01:59:02 --> Output Class Initialized
INFO - 2021-12-16 01:59:02 --> Security Class Initialized
DEBUG - 2021-12-16 01:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:59:02 --> Input Class Initialized
INFO - 2021-12-16 01:59:02 --> Language Class Initialized
INFO - 2021-12-16 01:59:02 --> Language Class Initialized
INFO - 2021-12-16 01:59:02 --> Config Class Initialized
INFO - 2021-12-16 01:59:02 --> Loader Class Initialized
INFO - 2021-12-16 01:59:02 --> Helper loaded: url_helper
INFO - 2021-12-16 01:59:02 --> Helper loaded: file_helper
INFO - 2021-12-16 01:59:02 --> Helper loaded: form_helper
INFO - 2021-12-16 01:59:02 --> Helper loaded: my_helper
INFO - 2021-12-16 01:59:02 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:59:02 --> Controller Class Initialized
ERROR - 2021-12-16 01:59:02 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-16 01:59:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-16 01:59:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:59:02 --> Final output sent to browser
DEBUG - 2021-12-16 01:59:02 --> Total execution time: 0.0530
INFO - 2021-12-16 01:59:23 --> Config Class Initialized
INFO - 2021-12-16 01:59:23 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:59:23 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:59:23 --> Utf8 Class Initialized
INFO - 2021-12-16 01:59:23 --> URI Class Initialized
INFO - 2021-12-16 01:59:23 --> Router Class Initialized
INFO - 2021-12-16 01:59:23 --> Output Class Initialized
INFO - 2021-12-16 01:59:23 --> Security Class Initialized
DEBUG - 2021-12-16 01:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:59:23 --> Input Class Initialized
INFO - 2021-12-16 01:59:23 --> Language Class Initialized
INFO - 2021-12-16 01:59:23 --> Language Class Initialized
INFO - 2021-12-16 01:59:23 --> Config Class Initialized
INFO - 2021-12-16 01:59:23 --> Loader Class Initialized
INFO - 2021-12-16 01:59:23 --> Helper loaded: url_helper
INFO - 2021-12-16 01:59:23 --> Helper loaded: file_helper
INFO - 2021-12-16 01:59:23 --> Helper loaded: form_helper
INFO - 2021-12-16 01:59:23 --> Helper loaded: my_helper
INFO - 2021-12-16 01:59:23 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:59:23 --> Controller Class Initialized
INFO - 2021-12-16 01:59:23 --> Upload Class Initialized
INFO - 2021-12-16 01:59:23 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-12-16 01:59:23 --> The upload path does not appear to be valid.
INFO - 2021-12-16 01:59:23 --> Config Class Initialized
INFO - 2021-12-16 01:59:23 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:59:23 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:59:23 --> Utf8 Class Initialized
INFO - 2021-12-16 01:59:23 --> URI Class Initialized
INFO - 2021-12-16 01:59:23 --> Router Class Initialized
INFO - 2021-12-16 01:59:23 --> Output Class Initialized
INFO - 2021-12-16 01:59:23 --> Security Class Initialized
DEBUG - 2021-12-16 01:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:59:23 --> Input Class Initialized
INFO - 2021-12-16 01:59:23 --> Language Class Initialized
INFO - 2021-12-16 01:59:23 --> Language Class Initialized
INFO - 2021-12-16 01:59:23 --> Config Class Initialized
INFO - 2021-12-16 01:59:23 --> Loader Class Initialized
INFO - 2021-12-16 01:59:23 --> Helper loaded: url_helper
INFO - 2021-12-16 01:59:23 --> Helper loaded: file_helper
INFO - 2021-12-16 01:59:23 --> Helper loaded: form_helper
INFO - 2021-12-16 01:59:23 --> Helper loaded: my_helper
INFO - 2021-12-16 01:59:23 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:59:23 --> Controller Class Initialized
DEBUG - 2021-12-16 01:59:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 01:59:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 01:59:23 --> Final output sent to browser
DEBUG - 2021-12-16 01:59:23 --> Total execution time: 0.0340
INFO - 2021-12-16 01:59:23 --> Config Class Initialized
INFO - 2021-12-16 01:59:23 --> Hooks Class Initialized
DEBUG - 2021-12-16 01:59:23 --> UTF-8 Support Enabled
INFO - 2021-12-16 01:59:23 --> Utf8 Class Initialized
INFO - 2021-12-16 01:59:23 --> URI Class Initialized
INFO - 2021-12-16 01:59:23 --> Router Class Initialized
INFO - 2021-12-16 01:59:23 --> Output Class Initialized
INFO - 2021-12-16 01:59:23 --> Security Class Initialized
DEBUG - 2021-12-16 01:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 01:59:23 --> Input Class Initialized
INFO - 2021-12-16 01:59:23 --> Language Class Initialized
INFO - 2021-12-16 01:59:23 --> Language Class Initialized
INFO - 2021-12-16 01:59:23 --> Config Class Initialized
INFO - 2021-12-16 01:59:23 --> Loader Class Initialized
INFO - 2021-12-16 01:59:23 --> Helper loaded: url_helper
INFO - 2021-12-16 01:59:23 --> Helper loaded: file_helper
INFO - 2021-12-16 01:59:23 --> Helper loaded: form_helper
INFO - 2021-12-16 01:59:23 --> Helper loaded: my_helper
INFO - 2021-12-16 01:59:23 --> Database Driver Class Initialized
DEBUG - 2021-12-16 01:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 01:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 01:59:23 --> Controller Class Initialized
INFO - 2021-12-16 02:04:17 --> Config Class Initialized
INFO - 2021-12-16 02:04:17 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:04:17 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:04:17 --> Utf8 Class Initialized
INFO - 2021-12-16 02:04:17 --> URI Class Initialized
INFO - 2021-12-16 02:04:17 --> Router Class Initialized
INFO - 2021-12-16 02:04:17 --> Output Class Initialized
INFO - 2021-12-16 02:04:17 --> Security Class Initialized
DEBUG - 2021-12-16 02:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:04:17 --> Input Class Initialized
INFO - 2021-12-16 02:04:17 --> Language Class Initialized
INFO - 2021-12-16 02:04:17 --> Language Class Initialized
INFO - 2021-12-16 02:04:17 --> Config Class Initialized
INFO - 2021-12-16 02:04:17 --> Loader Class Initialized
INFO - 2021-12-16 02:04:17 --> Helper loaded: url_helper
INFO - 2021-12-16 02:04:17 --> Helper loaded: file_helper
INFO - 2021-12-16 02:04:17 --> Helper loaded: form_helper
INFO - 2021-12-16 02:04:17 --> Helper loaded: my_helper
INFO - 2021-12-16 02:04:17 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:04:17 --> Controller Class Initialized
DEBUG - 2021-12-16 02:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 02:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:04:17 --> Final output sent to browser
DEBUG - 2021-12-16 02:04:17 --> Total execution time: 0.0570
INFO - 2021-12-16 02:04:33 --> Config Class Initialized
INFO - 2021-12-16 02:04:33 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:04:33 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:04:33 --> Utf8 Class Initialized
INFO - 2021-12-16 02:04:33 --> URI Class Initialized
INFO - 2021-12-16 02:04:33 --> Router Class Initialized
INFO - 2021-12-16 02:04:33 --> Output Class Initialized
INFO - 2021-12-16 02:04:33 --> Security Class Initialized
DEBUG - 2021-12-16 02:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:04:33 --> Input Class Initialized
INFO - 2021-12-16 02:04:33 --> Language Class Initialized
INFO - 2021-12-16 02:04:33 --> Language Class Initialized
INFO - 2021-12-16 02:04:33 --> Config Class Initialized
INFO - 2021-12-16 02:04:33 --> Loader Class Initialized
INFO - 2021-12-16 02:04:33 --> Helper loaded: url_helper
INFO - 2021-12-16 02:04:33 --> Helper loaded: file_helper
INFO - 2021-12-16 02:04:33 --> Helper loaded: form_helper
INFO - 2021-12-16 02:04:33 --> Helper loaded: my_helper
INFO - 2021-12-16 02:04:33 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:04:33 --> Controller Class Initialized
DEBUG - 2021-12-16 02:04:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 02:04:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:04:33 --> Final output sent to browser
DEBUG - 2021-12-16 02:04:33 --> Total execution time: 0.0490
INFO - 2021-12-16 02:06:07 --> Config Class Initialized
INFO - 2021-12-16 02:06:07 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:06:07 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:06:07 --> Utf8 Class Initialized
INFO - 2021-12-16 02:06:07 --> URI Class Initialized
INFO - 2021-12-16 02:06:07 --> Router Class Initialized
INFO - 2021-12-16 02:06:07 --> Output Class Initialized
INFO - 2021-12-16 02:06:07 --> Security Class Initialized
DEBUG - 2021-12-16 02:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:06:07 --> Input Class Initialized
INFO - 2021-12-16 02:06:07 --> Language Class Initialized
INFO - 2021-12-16 02:06:07 --> Language Class Initialized
INFO - 2021-12-16 02:06:07 --> Config Class Initialized
INFO - 2021-12-16 02:06:07 --> Loader Class Initialized
INFO - 2021-12-16 02:06:07 --> Helper loaded: url_helper
INFO - 2021-12-16 02:06:07 --> Helper loaded: file_helper
INFO - 2021-12-16 02:06:07 --> Helper loaded: form_helper
INFO - 2021-12-16 02:06:07 --> Helper loaded: my_helper
INFO - 2021-12-16 02:06:07 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:06:07 --> Controller Class Initialized
INFO - 2021-12-16 02:06:07 --> Config Class Initialized
INFO - 2021-12-16 02:06:07 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:06:07 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:06:07 --> Utf8 Class Initialized
INFO - 2021-12-16 02:06:07 --> URI Class Initialized
INFO - 2021-12-16 02:06:07 --> Router Class Initialized
INFO - 2021-12-16 02:06:07 --> Output Class Initialized
INFO - 2021-12-16 02:06:07 --> Security Class Initialized
DEBUG - 2021-12-16 02:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:06:07 --> Input Class Initialized
INFO - 2021-12-16 02:06:07 --> Language Class Initialized
INFO - 2021-12-16 02:06:07 --> Language Class Initialized
INFO - 2021-12-16 02:06:07 --> Config Class Initialized
INFO - 2021-12-16 02:06:07 --> Loader Class Initialized
INFO - 2021-12-16 02:06:07 --> Helper loaded: url_helper
INFO - 2021-12-16 02:06:07 --> Helper loaded: file_helper
INFO - 2021-12-16 02:06:07 --> Helper loaded: form_helper
INFO - 2021-12-16 02:06:07 --> Helper loaded: my_helper
INFO - 2021-12-16 02:06:07 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:06:07 --> Controller Class Initialized
DEBUG - 2021-12-16 02:06:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 02:06:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:06:07 --> Final output sent to browser
DEBUG - 2021-12-16 02:06:07 --> Total execution time: 0.0500
INFO - 2021-12-16 02:07:12 --> Config Class Initialized
INFO - 2021-12-16 02:07:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:07:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:07:12 --> Utf8 Class Initialized
INFO - 2021-12-16 02:07:12 --> URI Class Initialized
INFO - 2021-12-16 02:07:12 --> Router Class Initialized
INFO - 2021-12-16 02:07:12 --> Output Class Initialized
INFO - 2021-12-16 02:07:12 --> Security Class Initialized
DEBUG - 2021-12-16 02:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:07:12 --> Input Class Initialized
INFO - 2021-12-16 02:07:12 --> Language Class Initialized
INFO - 2021-12-16 02:07:12 --> Language Class Initialized
INFO - 2021-12-16 02:07:12 --> Config Class Initialized
INFO - 2021-12-16 02:07:12 --> Loader Class Initialized
INFO - 2021-12-16 02:07:12 --> Helper loaded: url_helper
INFO - 2021-12-16 02:07:12 --> Helper loaded: file_helper
INFO - 2021-12-16 02:07:12 --> Helper loaded: form_helper
INFO - 2021-12-16 02:07:12 --> Helper loaded: my_helper
INFO - 2021-12-16 02:07:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:07:12 --> Controller Class Initialized
DEBUG - 2021-12-16 02:07:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 02:07:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:07:12 --> Final output sent to browser
DEBUG - 2021-12-16 02:07:12 --> Total execution time: 0.0440
INFO - 2021-12-16 02:07:30 --> Config Class Initialized
INFO - 2021-12-16 02:07:30 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:07:30 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:07:30 --> Utf8 Class Initialized
INFO - 2021-12-16 02:07:30 --> URI Class Initialized
INFO - 2021-12-16 02:07:30 --> Router Class Initialized
INFO - 2021-12-16 02:07:30 --> Output Class Initialized
INFO - 2021-12-16 02:07:30 --> Security Class Initialized
DEBUG - 2021-12-16 02:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:07:30 --> Input Class Initialized
INFO - 2021-12-16 02:07:30 --> Language Class Initialized
INFO - 2021-12-16 02:07:30 --> Language Class Initialized
INFO - 2021-12-16 02:07:30 --> Config Class Initialized
INFO - 2021-12-16 02:07:30 --> Loader Class Initialized
INFO - 2021-12-16 02:07:30 --> Helper loaded: url_helper
INFO - 2021-12-16 02:07:30 --> Helper loaded: file_helper
INFO - 2021-12-16 02:07:30 --> Helper loaded: form_helper
INFO - 2021-12-16 02:07:30 --> Helper loaded: my_helper
INFO - 2021-12-16 02:07:30 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:07:30 --> Controller Class Initialized
INFO - 2021-12-16 02:07:30 --> Config Class Initialized
INFO - 2021-12-16 02:07:30 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:07:30 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:07:30 --> Utf8 Class Initialized
INFO - 2021-12-16 02:07:30 --> URI Class Initialized
INFO - 2021-12-16 02:07:30 --> Router Class Initialized
INFO - 2021-12-16 02:07:30 --> Output Class Initialized
INFO - 2021-12-16 02:07:30 --> Security Class Initialized
DEBUG - 2021-12-16 02:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:07:30 --> Input Class Initialized
INFO - 2021-12-16 02:07:30 --> Language Class Initialized
INFO - 2021-12-16 02:07:30 --> Language Class Initialized
INFO - 2021-12-16 02:07:30 --> Config Class Initialized
INFO - 2021-12-16 02:07:30 --> Loader Class Initialized
INFO - 2021-12-16 02:07:30 --> Helper loaded: url_helper
INFO - 2021-12-16 02:07:30 --> Helper loaded: file_helper
INFO - 2021-12-16 02:07:30 --> Helper loaded: form_helper
INFO - 2021-12-16 02:07:30 --> Helper loaded: my_helper
INFO - 2021-12-16 02:07:30 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:07:30 --> Controller Class Initialized
DEBUG - 2021-12-16 02:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 02:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:07:31 --> Final output sent to browser
DEBUG - 2021-12-16 02:07:31 --> Total execution time: 0.0430
INFO - 2021-12-16 02:07:50 --> Config Class Initialized
INFO - 2021-12-16 02:07:50 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:07:50 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:07:50 --> Utf8 Class Initialized
INFO - 2021-12-16 02:07:50 --> URI Class Initialized
INFO - 2021-12-16 02:07:50 --> Router Class Initialized
INFO - 2021-12-16 02:07:50 --> Output Class Initialized
INFO - 2021-12-16 02:07:50 --> Security Class Initialized
DEBUG - 2021-12-16 02:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:07:50 --> Input Class Initialized
INFO - 2021-12-16 02:07:50 --> Language Class Initialized
INFO - 2021-12-16 02:07:50 --> Language Class Initialized
INFO - 2021-12-16 02:07:50 --> Config Class Initialized
INFO - 2021-12-16 02:07:50 --> Loader Class Initialized
INFO - 2021-12-16 02:07:50 --> Helper loaded: url_helper
INFO - 2021-12-16 02:07:50 --> Helper loaded: file_helper
INFO - 2021-12-16 02:07:50 --> Helper loaded: form_helper
INFO - 2021-12-16 02:07:50 --> Helper loaded: my_helper
INFO - 2021-12-16 02:07:50 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:07:50 --> Controller Class Initialized
DEBUG - 2021-12-16 02:07:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 02:07:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:07:50 --> Final output sent to browser
DEBUG - 2021-12-16 02:07:50 --> Total execution time: 0.0490
INFO - 2021-12-16 02:08:34 --> Config Class Initialized
INFO - 2021-12-16 02:08:34 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:08:34 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:08:34 --> Utf8 Class Initialized
INFO - 2021-12-16 02:08:34 --> URI Class Initialized
INFO - 2021-12-16 02:08:34 --> Router Class Initialized
INFO - 2021-12-16 02:08:34 --> Output Class Initialized
INFO - 2021-12-16 02:08:34 --> Security Class Initialized
DEBUG - 2021-12-16 02:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:08:34 --> Input Class Initialized
INFO - 2021-12-16 02:08:34 --> Language Class Initialized
INFO - 2021-12-16 02:08:34 --> Language Class Initialized
INFO - 2021-12-16 02:08:34 --> Config Class Initialized
INFO - 2021-12-16 02:08:34 --> Loader Class Initialized
INFO - 2021-12-16 02:08:34 --> Helper loaded: url_helper
INFO - 2021-12-16 02:08:34 --> Helper loaded: file_helper
INFO - 2021-12-16 02:08:34 --> Helper loaded: form_helper
INFO - 2021-12-16 02:08:34 --> Helper loaded: my_helper
INFO - 2021-12-16 02:08:34 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:08:34 --> Controller Class Initialized
INFO - 2021-12-16 02:08:34 --> Config Class Initialized
INFO - 2021-12-16 02:08:34 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:08:34 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:08:34 --> Utf8 Class Initialized
INFO - 2021-12-16 02:08:34 --> URI Class Initialized
INFO - 2021-12-16 02:08:34 --> Router Class Initialized
INFO - 2021-12-16 02:08:34 --> Output Class Initialized
INFO - 2021-12-16 02:08:34 --> Security Class Initialized
DEBUG - 2021-12-16 02:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:08:34 --> Input Class Initialized
INFO - 2021-12-16 02:08:34 --> Language Class Initialized
INFO - 2021-12-16 02:08:34 --> Language Class Initialized
INFO - 2021-12-16 02:08:34 --> Config Class Initialized
INFO - 2021-12-16 02:08:34 --> Loader Class Initialized
INFO - 2021-12-16 02:08:34 --> Helper loaded: url_helper
INFO - 2021-12-16 02:08:34 --> Helper loaded: file_helper
INFO - 2021-12-16 02:08:34 --> Helper loaded: form_helper
INFO - 2021-12-16 02:08:34 --> Helper loaded: my_helper
INFO - 2021-12-16 02:08:34 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:08:34 --> Controller Class Initialized
DEBUG - 2021-12-16 02:08:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 02:08:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:08:34 --> Final output sent to browser
DEBUG - 2021-12-16 02:08:34 --> Total execution time: 0.0440
INFO - 2021-12-16 02:09:01 --> Config Class Initialized
INFO - 2021-12-16 02:09:01 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:09:01 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:09:01 --> Utf8 Class Initialized
INFO - 2021-12-16 02:09:01 --> URI Class Initialized
INFO - 2021-12-16 02:09:01 --> Router Class Initialized
INFO - 2021-12-16 02:09:01 --> Output Class Initialized
INFO - 2021-12-16 02:09:01 --> Security Class Initialized
DEBUG - 2021-12-16 02:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:09:01 --> Input Class Initialized
INFO - 2021-12-16 02:09:01 --> Language Class Initialized
INFO - 2021-12-16 02:09:01 --> Language Class Initialized
INFO - 2021-12-16 02:09:01 --> Config Class Initialized
INFO - 2021-12-16 02:09:01 --> Loader Class Initialized
INFO - 2021-12-16 02:09:01 --> Helper loaded: url_helper
INFO - 2021-12-16 02:09:01 --> Helper loaded: file_helper
INFO - 2021-12-16 02:09:01 --> Helper loaded: form_helper
INFO - 2021-12-16 02:09:01 --> Helper loaded: my_helper
INFO - 2021-12-16 02:09:01 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:09:01 --> Controller Class Initialized
DEBUG - 2021-12-16 02:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 02:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:09:01 --> Final output sent to browser
DEBUG - 2021-12-16 02:09:01 --> Total execution time: 0.0480
INFO - 2021-12-16 02:12:08 --> Config Class Initialized
INFO - 2021-12-16 02:12:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:12:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:12:08 --> Utf8 Class Initialized
INFO - 2021-12-16 02:12:08 --> URI Class Initialized
INFO - 2021-12-16 02:12:08 --> Router Class Initialized
INFO - 2021-12-16 02:12:08 --> Output Class Initialized
INFO - 2021-12-16 02:12:08 --> Security Class Initialized
DEBUG - 2021-12-16 02:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:12:08 --> Input Class Initialized
INFO - 2021-12-16 02:12:08 --> Language Class Initialized
INFO - 2021-12-16 02:12:08 --> Language Class Initialized
INFO - 2021-12-16 02:12:08 --> Config Class Initialized
INFO - 2021-12-16 02:12:08 --> Loader Class Initialized
INFO - 2021-12-16 02:12:08 --> Helper loaded: url_helper
INFO - 2021-12-16 02:12:08 --> Helper loaded: file_helper
INFO - 2021-12-16 02:12:08 --> Helper loaded: form_helper
INFO - 2021-12-16 02:12:08 --> Helper loaded: my_helper
INFO - 2021-12-16 02:12:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:12:08 --> Controller Class Initialized
INFO - 2021-12-16 02:12:08 --> Config Class Initialized
INFO - 2021-12-16 02:12:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:12:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:12:08 --> Utf8 Class Initialized
INFO - 2021-12-16 02:12:08 --> URI Class Initialized
INFO - 2021-12-16 02:12:08 --> Router Class Initialized
INFO - 2021-12-16 02:12:08 --> Output Class Initialized
INFO - 2021-12-16 02:12:08 --> Security Class Initialized
DEBUG - 2021-12-16 02:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:12:08 --> Input Class Initialized
INFO - 2021-12-16 02:12:08 --> Language Class Initialized
INFO - 2021-12-16 02:12:08 --> Language Class Initialized
INFO - 2021-12-16 02:12:08 --> Config Class Initialized
INFO - 2021-12-16 02:12:08 --> Loader Class Initialized
INFO - 2021-12-16 02:12:08 --> Helper loaded: url_helper
INFO - 2021-12-16 02:12:08 --> Helper loaded: file_helper
INFO - 2021-12-16 02:12:08 --> Helper loaded: form_helper
INFO - 2021-12-16 02:12:08 --> Helper loaded: my_helper
INFO - 2021-12-16 02:12:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:12:08 --> Controller Class Initialized
DEBUG - 2021-12-16 02:12:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 02:12:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:12:08 --> Final output sent to browser
DEBUG - 2021-12-16 02:12:08 --> Total execution time: 0.0420
INFO - 2021-12-16 02:12:22 --> Config Class Initialized
INFO - 2021-12-16 02:12:22 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:12:22 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:12:22 --> Utf8 Class Initialized
INFO - 2021-12-16 02:12:22 --> URI Class Initialized
INFO - 2021-12-16 02:12:22 --> Router Class Initialized
INFO - 2021-12-16 02:12:22 --> Output Class Initialized
INFO - 2021-12-16 02:12:22 --> Security Class Initialized
DEBUG - 2021-12-16 02:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:12:22 --> Input Class Initialized
INFO - 2021-12-16 02:12:22 --> Language Class Initialized
INFO - 2021-12-16 02:12:22 --> Language Class Initialized
INFO - 2021-12-16 02:12:22 --> Config Class Initialized
INFO - 2021-12-16 02:12:22 --> Loader Class Initialized
INFO - 2021-12-16 02:12:22 --> Helper loaded: url_helper
INFO - 2021-12-16 02:12:22 --> Helper loaded: file_helper
INFO - 2021-12-16 02:12:22 --> Helper loaded: form_helper
INFO - 2021-12-16 02:12:22 --> Helper loaded: my_helper
INFO - 2021-12-16 02:12:22 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:12:22 --> Controller Class Initialized
DEBUG - 2021-12-16 02:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 02:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:12:22 --> Final output sent to browser
DEBUG - 2021-12-16 02:12:22 --> Total execution time: 0.0520
INFO - 2021-12-16 02:23:41 --> Config Class Initialized
INFO - 2021-12-16 02:23:41 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:23:41 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:23:41 --> Utf8 Class Initialized
INFO - 2021-12-16 02:23:41 --> URI Class Initialized
INFO - 2021-12-16 02:23:41 --> Router Class Initialized
INFO - 2021-12-16 02:23:41 --> Output Class Initialized
INFO - 2021-12-16 02:23:41 --> Security Class Initialized
DEBUG - 2021-12-16 02:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:23:41 --> Input Class Initialized
INFO - 2021-12-16 02:23:41 --> Language Class Initialized
INFO - 2021-12-16 02:23:41 --> Language Class Initialized
INFO - 2021-12-16 02:23:41 --> Config Class Initialized
INFO - 2021-12-16 02:23:41 --> Loader Class Initialized
INFO - 2021-12-16 02:23:41 --> Helper loaded: url_helper
INFO - 2021-12-16 02:23:41 --> Helper loaded: file_helper
INFO - 2021-12-16 02:23:41 --> Helper loaded: form_helper
INFO - 2021-12-16 02:23:41 --> Helper loaded: my_helper
INFO - 2021-12-16 02:23:41 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:23:41 --> Controller Class Initialized
INFO - 2021-12-16 02:23:41 --> Config Class Initialized
INFO - 2021-12-16 02:23:41 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:23:41 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:23:41 --> Utf8 Class Initialized
INFO - 2021-12-16 02:23:41 --> URI Class Initialized
INFO - 2021-12-16 02:23:41 --> Router Class Initialized
INFO - 2021-12-16 02:23:41 --> Output Class Initialized
INFO - 2021-12-16 02:23:41 --> Security Class Initialized
DEBUG - 2021-12-16 02:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:23:41 --> Input Class Initialized
INFO - 2021-12-16 02:23:41 --> Language Class Initialized
INFO - 2021-12-16 02:23:41 --> Language Class Initialized
INFO - 2021-12-16 02:23:41 --> Config Class Initialized
INFO - 2021-12-16 02:23:41 --> Loader Class Initialized
INFO - 2021-12-16 02:23:41 --> Helper loaded: url_helper
INFO - 2021-12-16 02:23:41 --> Helper loaded: file_helper
INFO - 2021-12-16 02:23:41 --> Helper loaded: form_helper
INFO - 2021-12-16 02:23:41 --> Helper loaded: my_helper
INFO - 2021-12-16 02:23:41 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:23:41 --> Controller Class Initialized
DEBUG - 2021-12-16 02:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 02:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:23:41 --> Final output sent to browser
DEBUG - 2021-12-16 02:23:41 --> Total execution time: 0.0430
INFO - 2021-12-16 02:23:48 --> Config Class Initialized
INFO - 2021-12-16 02:23:48 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:23:48 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:23:48 --> Utf8 Class Initialized
INFO - 2021-12-16 02:23:48 --> URI Class Initialized
INFO - 2021-12-16 02:23:48 --> Router Class Initialized
INFO - 2021-12-16 02:23:48 --> Output Class Initialized
INFO - 2021-12-16 02:23:48 --> Security Class Initialized
DEBUG - 2021-12-16 02:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:23:48 --> Input Class Initialized
INFO - 2021-12-16 02:23:48 --> Language Class Initialized
INFO - 2021-12-16 02:23:48 --> Language Class Initialized
INFO - 2021-12-16 02:23:48 --> Config Class Initialized
INFO - 2021-12-16 02:23:48 --> Loader Class Initialized
INFO - 2021-12-16 02:23:48 --> Helper loaded: url_helper
INFO - 2021-12-16 02:23:48 --> Helper loaded: file_helper
INFO - 2021-12-16 02:23:48 --> Helper loaded: form_helper
INFO - 2021-12-16 02:23:48 --> Helper loaded: my_helper
INFO - 2021-12-16 02:23:48 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:23:48 --> Controller Class Initialized
DEBUG - 2021-12-16 02:23:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 02:23:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:23:48 --> Final output sent to browser
DEBUG - 2021-12-16 02:23:48 --> Total execution time: 0.0470
INFO - 2021-12-16 02:41:57 --> Config Class Initialized
INFO - 2021-12-16 02:41:57 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:41:57 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:41:57 --> Utf8 Class Initialized
INFO - 2021-12-16 02:41:57 --> URI Class Initialized
INFO - 2021-12-16 02:41:57 --> Router Class Initialized
INFO - 2021-12-16 02:41:57 --> Output Class Initialized
INFO - 2021-12-16 02:41:57 --> Security Class Initialized
DEBUG - 2021-12-16 02:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:41:57 --> Input Class Initialized
INFO - 2021-12-16 02:41:57 --> Language Class Initialized
INFO - 2021-12-16 02:41:57 --> Language Class Initialized
INFO - 2021-12-16 02:41:57 --> Config Class Initialized
INFO - 2021-12-16 02:41:57 --> Loader Class Initialized
INFO - 2021-12-16 02:41:57 --> Helper loaded: url_helper
INFO - 2021-12-16 02:41:57 --> Helper loaded: file_helper
INFO - 2021-12-16 02:41:57 --> Helper loaded: form_helper
INFO - 2021-12-16 02:41:57 --> Helper loaded: my_helper
INFO - 2021-12-16 02:41:57 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:41:57 --> Controller Class Initialized
INFO - 2021-12-16 02:41:57 --> Config Class Initialized
INFO - 2021-12-16 02:41:57 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:41:57 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:41:57 --> Utf8 Class Initialized
INFO - 2021-12-16 02:41:57 --> URI Class Initialized
INFO - 2021-12-16 02:41:57 --> Router Class Initialized
INFO - 2021-12-16 02:41:57 --> Output Class Initialized
INFO - 2021-12-16 02:41:57 --> Security Class Initialized
DEBUG - 2021-12-16 02:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:41:57 --> Input Class Initialized
INFO - 2021-12-16 02:41:57 --> Language Class Initialized
INFO - 2021-12-16 02:41:57 --> Language Class Initialized
INFO - 2021-12-16 02:41:57 --> Config Class Initialized
INFO - 2021-12-16 02:41:57 --> Loader Class Initialized
INFO - 2021-12-16 02:41:57 --> Helper loaded: url_helper
INFO - 2021-12-16 02:41:57 --> Helper loaded: file_helper
INFO - 2021-12-16 02:41:57 --> Helper loaded: form_helper
INFO - 2021-12-16 02:41:57 --> Helper loaded: my_helper
INFO - 2021-12-16 02:41:57 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:41:57 --> Controller Class Initialized
DEBUG - 2021-12-16 02:41:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 02:41:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:41:57 --> Final output sent to browser
DEBUG - 2021-12-16 02:41:57 --> Total execution time: 0.0440
INFO - 2021-12-16 02:52:55 --> Config Class Initialized
INFO - 2021-12-16 02:52:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:52:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:52:55 --> Utf8 Class Initialized
INFO - 2021-12-16 02:52:55 --> URI Class Initialized
INFO - 2021-12-16 02:52:55 --> Router Class Initialized
INFO - 2021-12-16 02:52:55 --> Output Class Initialized
INFO - 2021-12-16 02:52:55 --> Security Class Initialized
DEBUG - 2021-12-16 02:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:52:55 --> Input Class Initialized
INFO - 2021-12-16 02:52:55 --> Language Class Initialized
INFO - 2021-12-16 02:52:55 --> Language Class Initialized
INFO - 2021-12-16 02:52:55 --> Config Class Initialized
INFO - 2021-12-16 02:52:55 --> Loader Class Initialized
INFO - 2021-12-16 02:52:55 --> Helper loaded: url_helper
INFO - 2021-12-16 02:52:55 --> Helper loaded: file_helper
INFO - 2021-12-16 02:52:55 --> Helper loaded: form_helper
INFO - 2021-12-16 02:52:55 --> Helper loaded: my_helper
INFO - 2021-12-16 02:52:55 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:52:55 --> Controller Class Initialized
DEBUG - 2021-12-16 02:52:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 02:52:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:52:55 --> Final output sent to browser
DEBUG - 2021-12-16 02:52:55 --> Total execution time: 0.0510
INFO - 2021-12-16 02:54:14 --> Config Class Initialized
INFO - 2021-12-16 02:54:14 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:54:14 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:54:14 --> Utf8 Class Initialized
INFO - 2021-12-16 02:54:14 --> URI Class Initialized
INFO - 2021-12-16 02:54:14 --> Router Class Initialized
INFO - 2021-12-16 02:54:14 --> Output Class Initialized
INFO - 2021-12-16 02:54:14 --> Security Class Initialized
DEBUG - 2021-12-16 02:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:54:14 --> Input Class Initialized
INFO - 2021-12-16 02:54:14 --> Language Class Initialized
INFO - 2021-12-16 02:54:14 --> Language Class Initialized
INFO - 2021-12-16 02:54:14 --> Config Class Initialized
INFO - 2021-12-16 02:54:14 --> Loader Class Initialized
INFO - 2021-12-16 02:54:14 --> Helper loaded: url_helper
INFO - 2021-12-16 02:54:14 --> Helper loaded: file_helper
INFO - 2021-12-16 02:54:14 --> Helper loaded: form_helper
INFO - 2021-12-16 02:54:14 --> Helper loaded: my_helper
INFO - 2021-12-16 02:54:14 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:54:14 --> Controller Class Initialized
INFO - 2021-12-16 02:54:14 --> Config Class Initialized
INFO - 2021-12-16 02:54:14 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:54:14 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:54:14 --> Utf8 Class Initialized
INFO - 2021-12-16 02:54:14 --> URI Class Initialized
INFO - 2021-12-16 02:54:14 --> Router Class Initialized
INFO - 2021-12-16 02:54:14 --> Output Class Initialized
INFO - 2021-12-16 02:54:14 --> Security Class Initialized
DEBUG - 2021-12-16 02:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:54:14 --> Input Class Initialized
INFO - 2021-12-16 02:54:14 --> Language Class Initialized
INFO - 2021-12-16 02:54:14 --> Language Class Initialized
INFO - 2021-12-16 02:54:14 --> Config Class Initialized
INFO - 2021-12-16 02:54:14 --> Loader Class Initialized
INFO - 2021-12-16 02:54:14 --> Helper loaded: url_helper
INFO - 2021-12-16 02:54:14 --> Helper loaded: file_helper
INFO - 2021-12-16 02:54:14 --> Helper loaded: form_helper
INFO - 2021-12-16 02:54:14 --> Helper loaded: my_helper
INFO - 2021-12-16 02:54:14 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:54:14 --> Controller Class Initialized
DEBUG - 2021-12-16 02:54:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 02:54:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:54:14 --> Final output sent to browser
DEBUG - 2021-12-16 02:54:14 --> Total execution time: 0.0460
INFO - 2021-12-16 02:57:27 --> Config Class Initialized
INFO - 2021-12-16 02:57:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:57:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:57:27 --> Utf8 Class Initialized
INFO - 2021-12-16 02:57:27 --> URI Class Initialized
INFO - 2021-12-16 02:57:27 --> Router Class Initialized
INFO - 2021-12-16 02:57:27 --> Output Class Initialized
INFO - 2021-12-16 02:57:27 --> Security Class Initialized
DEBUG - 2021-12-16 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:57:27 --> Input Class Initialized
INFO - 2021-12-16 02:57:27 --> Language Class Initialized
INFO - 2021-12-16 02:57:27 --> Language Class Initialized
INFO - 2021-12-16 02:57:27 --> Config Class Initialized
INFO - 2021-12-16 02:57:27 --> Loader Class Initialized
INFO - 2021-12-16 02:57:27 --> Helper loaded: url_helper
INFO - 2021-12-16 02:57:27 --> Helper loaded: file_helper
INFO - 2021-12-16 02:57:27 --> Helper loaded: form_helper
INFO - 2021-12-16 02:57:27 --> Helper loaded: my_helper
INFO - 2021-12-16 02:57:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:57:27 --> Controller Class Initialized
DEBUG - 2021-12-16 02:57:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 02:57:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:57:27 --> Final output sent to browser
DEBUG - 2021-12-16 02:57:27 --> Total execution time: 0.0580
INFO - 2021-12-16 02:59:49 --> Config Class Initialized
INFO - 2021-12-16 02:59:49 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:59:49 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:59:49 --> Utf8 Class Initialized
INFO - 2021-12-16 02:59:49 --> URI Class Initialized
INFO - 2021-12-16 02:59:49 --> Router Class Initialized
INFO - 2021-12-16 02:59:49 --> Output Class Initialized
INFO - 2021-12-16 02:59:49 --> Security Class Initialized
DEBUG - 2021-12-16 02:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:59:49 --> Input Class Initialized
INFO - 2021-12-16 02:59:49 --> Language Class Initialized
INFO - 2021-12-16 02:59:49 --> Language Class Initialized
INFO - 2021-12-16 02:59:49 --> Config Class Initialized
INFO - 2021-12-16 02:59:49 --> Loader Class Initialized
INFO - 2021-12-16 02:59:49 --> Helper loaded: url_helper
INFO - 2021-12-16 02:59:49 --> Helper loaded: file_helper
INFO - 2021-12-16 02:59:49 --> Helper loaded: form_helper
INFO - 2021-12-16 02:59:49 --> Helper loaded: my_helper
INFO - 2021-12-16 02:59:49 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:59:49 --> Controller Class Initialized
INFO - 2021-12-16 02:59:49 --> Config Class Initialized
INFO - 2021-12-16 02:59:49 --> Hooks Class Initialized
DEBUG - 2021-12-16 02:59:49 --> UTF-8 Support Enabled
INFO - 2021-12-16 02:59:49 --> Utf8 Class Initialized
INFO - 2021-12-16 02:59:49 --> URI Class Initialized
INFO - 2021-12-16 02:59:49 --> Router Class Initialized
INFO - 2021-12-16 02:59:49 --> Output Class Initialized
INFO - 2021-12-16 02:59:49 --> Security Class Initialized
DEBUG - 2021-12-16 02:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 02:59:49 --> Input Class Initialized
INFO - 2021-12-16 02:59:49 --> Language Class Initialized
INFO - 2021-12-16 02:59:49 --> Language Class Initialized
INFO - 2021-12-16 02:59:49 --> Config Class Initialized
INFO - 2021-12-16 02:59:49 --> Loader Class Initialized
INFO - 2021-12-16 02:59:49 --> Helper loaded: url_helper
INFO - 2021-12-16 02:59:49 --> Helper loaded: file_helper
INFO - 2021-12-16 02:59:49 --> Helper loaded: form_helper
INFO - 2021-12-16 02:59:49 --> Helper loaded: my_helper
INFO - 2021-12-16 02:59:49 --> Database Driver Class Initialized
DEBUG - 2021-12-16 02:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 02:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 02:59:49 --> Controller Class Initialized
DEBUG - 2021-12-16 02:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 02:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 02:59:49 --> Final output sent to browser
DEBUG - 2021-12-16 02:59:49 --> Total execution time: 0.0430
INFO - 2021-12-16 03:00:20 --> Config Class Initialized
INFO - 2021-12-16 03:00:20 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:00:20 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:00:20 --> Utf8 Class Initialized
INFO - 2021-12-16 03:00:20 --> URI Class Initialized
INFO - 2021-12-16 03:00:20 --> Router Class Initialized
INFO - 2021-12-16 03:00:20 --> Output Class Initialized
INFO - 2021-12-16 03:00:20 --> Security Class Initialized
DEBUG - 2021-12-16 03:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:00:20 --> Input Class Initialized
INFO - 2021-12-16 03:00:20 --> Language Class Initialized
INFO - 2021-12-16 03:00:20 --> Language Class Initialized
INFO - 2021-12-16 03:00:20 --> Config Class Initialized
INFO - 2021-12-16 03:00:20 --> Loader Class Initialized
INFO - 2021-12-16 03:00:20 --> Helper loaded: url_helper
INFO - 2021-12-16 03:00:20 --> Helper loaded: file_helper
INFO - 2021-12-16 03:00:20 --> Helper loaded: form_helper
INFO - 2021-12-16 03:00:20 --> Helper loaded: my_helper
INFO - 2021-12-16 03:00:20 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:00:20 --> Controller Class Initialized
DEBUG - 2021-12-16 03:00:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 03:00:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:00:20 --> Final output sent to browser
DEBUG - 2021-12-16 03:00:20 --> Total execution time: 0.0300
INFO - 2021-12-16 03:02:19 --> Config Class Initialized
INFO - 2021-12-16 03:02:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:02:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:02:19 --> Utf8 Class Initialized
INFO - 2021-12-16 03:02:19 --> URI Class Initialized
INFO - 2021-12-16 03:02:19 --> Router Class Initialized
INFO - 2021-12-16 03:02:19 --> Output Class Initialized
INFO - 2021-12-16 03:02:19 --> Security Class Initialized
DEBUG - 2021-12-16 03:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:02:19 --> Input Class Initialized
INFO - 2021-12-16 03:02:19 --> Language Class Initialized
INFO - 2021-12-16 03:02:19 --> Language Class Initialized
INFO - 2021-12-16 03:02:19 --> Config Class Initialized
INFO - 2021-12-16 03:02:19 --> Loader Class Initialized
INFO - 2021-12-16 03:02:19 --> Helper loaded: url_helper
INFO - 2021-12-16 03:02:19 --> Helper loaded: file_helper
INFO - 2021-12-16 03:02:19 --> Helper loaded: form_helper
INFO - 2021-12-16 03:02:19 --> Helper loaded: my_helper
INFO - 2021-12-16 03:02:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:02:19 --> Controller Class Initialized
INFO - 2021-12-16 03:02:19 --> Config Class Initialized
INFO - 2021-12-16 03:02:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:02:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:02:19 --> Utf8 Class Initialized
INFO - 2021-12-16 03:02:19 --> URI Class Initialized
INFO - 2021-12-16 03:02:19 --> Router Class Initialized
INFO - 2021-12-16 03:02:19 --> Output Class Initialized
INFO - 2021-12-16 03:02:19 --> Security Class Initialized
DEBUG - 2021-12-16 03:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:02:19 --> Input Class Initialized
INFO - 2021-12-16 03:02:19 --> Language Class Initialized
INFO - 2021-12-16 03:02:19 --> Language Class Initialized
INFO - 2021-12-16 03:02:19 --> Config Class Initialized
INFO - 2021-12-16 03:02:19 --> Loader Class Initialized
INFO - 2021-12-16 03:02:19 --> Helper loaded: url_helper
INFO - 2021-12-16 03:02:19 --> Helper loaded: file_helper
INFO - 2021-12-16 03:02:19 --> Helper loaded: form_helper
INFO - 2021-12-16 03:02:19 --> Helper loaded: my_helper
INFO - 2021-12-16 03:02:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:02:19 --> Controller Class Initialized
DEBUG - 2021-12-16 03:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 03:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:02:19 --> Final output sent to browser
DEBUG - 2021-12-16 03:02:19 --> Total execution time: 0.0450
INFO - 2021-12-16 03:02:36 --> Config Class Initialized
INFO - 2021-12-16 03:02:36 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:02:36 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:02:36 --> Utf8 Class Initialized
INFO - 2021-12-16 03:02:36 --> URI Class Initialized
INFO - 2021-12-16 03:02:36 --> Router Class Initialized
INFO - 2021-12-16 03:02:36 --> Output Class Initialized
INFO - 2021-12-16 03:02:36 --> Security Class Initialized
DEBUG - 2021-12-16 03:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:02:36 --> Input Class Initialized
INFO - 2021-12-16 03:02:36 --> Language Class Initialized
INFO - 2021-12-16 03:02:36 --> Language Class Initialized
INFO - 2021-12-16 03:02:36 --> Config Class Initialized
INFO - 2021-12-16 03:02:36 --> Loader Class Initialized
INFO - 2021-12-16 03:02:36 --> Helper loaded: url_helper
INFO - 2021-12-16 03:02:36 --> Helper loaded: file_helper
INFO - 2021-12-16 03:02:36 --> Helper loaded: form_helper
INFO - 2021-12-16 03:02:36 --> Helper loaded: my_helper
INFO - 2021-12-16 03:02:36 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:02:36 --> Controller Class Initialized
DEBUG - 2021-12-16 03:02:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 03:02:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:02:36 --> Final output sent to browser
DEBUG - 2021-12-16 03:02:36 --> Total execution time: 0.0440
INFO - 2021-12-16 03:03:04 --> Config Class Initialized
INFO - 2021-12-16 03:03:04 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:03:04 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:03:04 --> Utf8 Class Initialized
INFO - 2021-12-16 03:03:04 --> URI Class Initialized
INFO - 2021-12-16 03:03:04 --> Router Class Initialized
INFO - 2021-12-16 03:03:04 --> Output Class Initialized
INFO - 2021-12-16 03:03:04 --> Security Class Initialized
DEBUG - 2021-12-16 03:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:03:04 --> Input Class Initialized
INFO - 2021-12-16 03:03:04 --> Language Class Initialized
INFO - 2021-12-16 03:03:04 --> Language Class Initialized
INFO - 2021-12-16 03:03:04 --> Config Class Initialized
INFO - 2021-12-16 03:03:04 --> Loader Class Initialized
INFO - 2021-12-16 03:03:04 --> Helper loaded: url_helper
INFO - 2021-12-16 03:03:05 --> Helper loaded: file_helper
INFO - 2021-12-16 03:03:05 --> Helper loaded: form_helper
INFO - 2021-12-16 03:03:05 --> Helper loaded: my_helper
INFO - 2021-12-16 03:03:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:03:05 --> Controller Class Initialized
INFO - 2021-12-16 03:03:05 --> Config Class Initialized
INFO - 2021-12-16 03:03:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:03:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:03:05 --> Utf8 Class Initialized
INFO - 2021-12-16 03:03:05 --> URI Class Initialized
INFO - 2021-12-16 03:03:05 --> Router Class Initialized
INFO - 2021-12-16 03:03:05 --> Output Class Initialized
INFO - 2021-12-16 03:03:05 --> Security Class Initialized
DEBUG - 2021-12-16 03:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:03:05 --> Input Class Initialized
INFO - 2021-12-16 03:03:05 --> Language Class Initialized
INFO - 2021-12-16 03:03:05 --> Language Class Initialized
INFO - 2021-12-16 03:03:05 --> Config Class Initialized
INFO - 2021-12-16 03:03:05 --> Loader Class Initialized
INFO - 2021-12-16 03:03:05 --> Helper loaded: url_helper
INFO - 2021-12-16 03:03:05 --> Helper loaded: file_helper
INFO - 2021-12-16 03:03:05 --> Helper loaded: form_helper
INFO - 2021-12-16 03:03:05 --> Helper loaded: my_helper
INFO - 2021-12-16 03:03:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:03:05 --> Controller Class Initialized
DEBUG - 2021-12-16 03:03:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 03:03:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:03:05 --> Final output sent to browser
DEBUG - 2021-12-16 03:03:05 --> Total execution time: 0.0440
INFO - 2021-12-16 03:11:13 --> Config Class Initialized
INFO - 2021-12-16 03:11:13 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:11:13 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:11:13 --> Utf8 Class Initialized
INFO - 2021-12-16 03:11:13 --> URI Class Initialized
INFO - 2021-12-16 03:11:13 --> Router Class Initialized
INFO - 2021-12-16 03:11:13 --> Output Class Initialized
INFO - 2021-12-16 03:11:13 --> Security Class Initialized
DEBUG - 2021-12-16 03:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:11:13 --> Input Class Initialized
INFO - 2021-12-16 03:11:13 --> Language Class Initialized
INFO - 2021-12-16 03:11:13 --> Language Class Initialized
INFO - 2021-12-16 03:11:13 --> Config Class Initialized
INFO - 2021-12-16 03:11:13 --> Loader Class Initialized
INFO - 2021-12-16 03:11:13 --> Helper loaded: url_helper
INFO - 2021-12-16 03:11:13 --> Helper loaded: file_helper
INFO - 2021-12-16 03:11:13 --> Helper loaded: form_helper
INFO - 2021-12-16 03:11:13 --> Helper loaded: my_helper
INFO - 2021-12-16 03:11:13 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:11:13 --> Controller Class Initialized
DEBUG - 2021-12-16 03:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-16 03:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:11:13 --> Final output sent to browser
DEBUG - 2021-12-16 03:11:13 --> Total execution time: 0.0270
INFO - 2021-12-16 03:11:14 --> Config Class Initialized
INFO - 2021-12-16 03:11:14 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:11:14 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:11:14 --> Utf8 Class Initialized
INFO - 2021-12-16 03:11:14 --> URI Class Initialized
INFO - 2021-12-16 03:11:14 --> Router Class Initialized
INFO - 2021-12-16 03:11:14 --> Output Class Initialized
INFO - 2021-12-16 03:11:14 --> Security Class Initialized
DEBUG - 2021-12-16 03:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:11:14 --> Input Class Initialized
INFO - 2021-12-16 03:11:14 --> Language Class Initialized
INFO - 2021-12-16 03:11:14 --> Language Class Initialized
INFO - 2021-12-16 03:11:14 --> Config Class Initialized
INFO - 2021-12-16 03:11:14 --> Loader Class Initialized
INFO - 2021-12-16 03:11:14 --> Helper loaded: url_helper
INFO - 2021-12-16 03:11:14 --> Helper loaded: file_helper
INFO - 2021-12-16 03:11:14 --> Helper loaded: form_helper
INFO - 2021-12-16 03:11:14 --> Helper loaded: my_helper
INFO - 2021-12-16 03:11:14 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:11:14 --> Controller Class Initialized
INFO - 2021-12-16 03:11:15 --> Config Class Initialized
INFO - 2021-12-16 03:11:15 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:11:15 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:11:15 --> Utf8 Class Initialized
INFO - 2021-12-16 03:11:15 --> URI Class Initialized
INFO - 2021-12-16 03:11:15 --> Router Class Initialized
INFO - 2021-12-16 03:11:15 --> Output Class Initialized
INFO - 2021-12-16 03:11:15 --> Security Class Initialized
DEBUG - 2021-12-16 03:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:11:15 --> Input Class Initialized
INFO - 2021-12-16 03:11:15 --> Language Class Initialized
INFO - 2021-12-16 03:11:15 --> Language Class Initialized
INFO - 2021-12-16 03:11:15 --> Config Class Initialized
INFO - 2021-12-16 03:11:15 --> Loader Class Initialized
INFO - 2021-12-16 03:11:15 --> Helper loaded: url_helper
INFO - 2021-12-16 03:11:15 --> Helper loaded: file_helper
INFO - 2021-12-16 03:11:15 --> Helper loaded: form_helper
INFO - 2021-12-16 03:11:15 --> Helper loaded: my_helper
INFO - 2021-12-16 03:11:15 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:11:15 --> Controller Class Initialized
DEBUG - 2021-12-16 03:11:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 03:11:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:11:15 --> Final output sent to browser
DEBUG - 2021-12-16 03:11:15 --> Total execution time: 0.0500
INFO - 2021-12-16 03:11:15 --> Config Class Initialized
INFO - 2021-12-16 03:11:15 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:11:15 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:11:15 --> Utf8 Class Initialized
INFO - 2021-12-16 03:11:15 --> URI Class Initialized
INFO - 2021-12-16 03:11:15 --> Router Class Initialized
INFO - 2021-12-16 03:11:15 --> Output Class Initialized
INFO - 2021-12-16 03:11:15 --> Security Class Initialized
DEBUG - 2021-12-16 03:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:11:15 --> Input Class Initialized
INFO - 2021-12-16 03:11:15 --> Language Class Initialized
INFO - 2021-12-16 03:11:15 --> Language Class Initialized
INFO - 2021-12-16 03:11:15 --> Config Class Initialized
INFO - 2021-12-16 03:11:15 --> Loader Class Initialized
INFO - 2021-12-16 03:11:15 --> Helper loaded: url_helper
INFO - 2021-12-16 03:11:15 --> Helper loaded: file_helper
INFO - 2021-12-16 03:11:15 --> Helper loaded: form_helper
INFO - 2021-12-16 03:11:15 --> Helper loaded: my_helper
INFO - 2021-12-16 03:11:15 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:11:15 --> Controller Class Initialized
INFO - 2021-12-16 03:11:20 --> Config Class Initialized
INFO - 2021-12-16 03:11:20 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:11:20 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:11:20 --> Utf8 Class Initialized
INFO - 2021-12-16 03:11:20 --> URI Class Initialized
INFO - 2021-12-16 03:11:20 --> Router Class Initialized
INFO - 2021-12-16 03:11:20 --> Output Class Initialized
INFO - 2021-12-16 03:11:20 --> Security Class Initialized
DEBUG - 2021-12-16 03:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:11:20 --> Input Class Initialized
INFO - 2021-12-16 03:11:20 --> Language Class Initialized
INFO - 2021-12-16 03:11:20 --> Language Class Initialized
INFO - 2021-12-16 03:11:20 --> Config Class Initialized
INFO - 2021-12-16 03:11:20 --> Loader Class Initialized
INFO - 2021-12-16 03:11:20 --> Helper loaded: url_helper
INFO - 2021-12-16 03:11:20 --> Helper loaded: file_helper
INFO - 2021-12-16 03:11:20 --> Helper loaded: form_helper
INFO - 2021-12-16 03:11:20 --> Helper loaded: my_helper
INFO - 2021-12-16 03:11:20 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:11:20 --> Controller Class Initialized
INFO - 2021-12-16 03:11:21 --> Config Class Initialized
INFO - 2021-12-16 03:11:21 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:11:21 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:11:21 --> Utf8 Class Initialized
INFO - 2021-12-16 03:11:21 --> URI Class Initialized
INFO - 2021-12-16 03:11:21 --> Router Class Initialized
INFO - 2021-12-16 03:11:21 --> Output Class Initialized
INFO - 2021-12-16 03:11:21 --> Security Class Initialized
DEBUG - 2021-12-16 03:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:11:21 --> Input Class Initialized
INFO - 2021-12-16 03:11:21 --> Language Class Initialized
INFO - 2021-12-16 03:11:21 --> Language Class Initialized
INFO - 2021-12-16 03:11:21 --> Config Class Initialized
INFO - 2021-12-16 03:11:21 --> Loader Class Initialized
INFO - 2021-12-16 03:11:21 --> Helper loaded: url_helper
INFO - 2021-12-16 03:11:21 --> Helper loaded: file_helper
INFO - 2021-12-16 03:11:21 --> Helper loaded: form_helper
INFO - 2021-12-16 03:11:21 --> Helper loaded: my_helper
INFO - 2021-12-16 03:11:21 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:11:21 --> Controller Class Initialized
INFO - 2021-12-16 03:15:23 --> Config Class Initialized
INFO - 2021-12-16 03:15:23 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:15:23 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:15:23 --> Utf8 Class Initialized
INFO - 2021-12-16 03:15:23 --> URI Class Initialized
INFO - 2021-12-16 03:15:23 --> Router Class Initialized
INFO - 2021-12-16 03:15:23 --> Output Class Initialized
INFO - 2021-12-16 03:15:23 --> Security Class Initialized
DEBUG - 2021-12-16 03:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:15:23 --> Input Class Initialized
INFO - 2021-12-16 03:15:23 --> Language Class Initialized
INFO - 2021-12-16 03:15:23 --> Language Class Initialized
INFO - 2021-12-16 03:15:23 --> Config Class Initialized
INFO - 2021-12-16 03:15:23 --> Loader Class Initialized
INFO - 2021-12-16 03:15:23 --> Helper loaded: url_helper
INFO - 2021-12-16 03:15:23 --> Helper loaded: file_helper
INFO - 2021-12-16 03:15:23 --> Helper loaded: form_helper
INFO - 2021-12-16 03:15:23 --> Helper loaded: my_helper
INFO - 2021-12-16 03:15:23 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:15:23 --> Controller Class Initialized
INFO - 2021-12-16 03:16:33 --> Config Class Initialized
INFO - 2021-12-16 03:16:33 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:16:33 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:16:33 --> Utf8 Class Initialized
INFO - 2021-12-16 03:16:33 --> URI Class Initialized
INFO - 2021-12-16 03:16:33 --> Router Class Initialized
INFO - 2021-12-16 03:16:33 --> Output Class Initialized
INFO - 2021-12-16 03:16:33 --> Security Class Initialized
DEBUG - 2021-12-16 03:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:16:33 --> Input Class Initialized
INFO - 2021-12-16 03:16:33 --> Language Class Initialized
INFO - 2021-12-16 03:16:33 --> Language Class Initialized
INFO - 2021-12-16 03:16:33 --> Config Class Initialized
INFO - 2021-12-16 03:16:33 --> Loader Class Initialized
INFO - 2021-12-16 03:16:33 --> Helper loaded: url_helper
INFO - 2021-12-16 03:16:33 --> Helper loaded: file_helper
INFO - 2021-12-16 03:16:33 --> Helper loaded: form_helper
INFO - 2021-12-16 03:16:33 --> Helper loaded: my_helper
INFO - 2021-12-16 03:16:33 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:16:33 --> Controller Class Initialized
ERROR - 2021-12-16 03:16:33 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-16 03:16:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-16 03:16:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:16:33 --> Final output sent to browser
DEBUG - 2021-12-16 03:16:33 --> Total execution time: 0.0470
INFO - 2021-12-16 03:17:06 --> Config Class Initialized
INFO - 2021-12-16 03:17:06 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:17:06 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:17:06 --> Utf8 Class Initialized
INFO - 2021-12-16 03:17:06 --> URI Class Initialized
INFO - 2021-12-16 03:17:06 --> Router Class Initialized
INFO - 2021-12-16 03:17:06 --> Output Class Initialized
INFO - 2021-12-16 03:17:06 --> Security Class Initialized
DEBUG - 2021-12-16 03:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:17:06 --> Input Class Initialized
INFO - 2021-12-16 03:17:06 --> Language Class Initialized
INFO - 2021-12-16 03:17:06 --> Language Class Initialized
INFO - 2021-12-16 03:17:06 --> Config Class Initialized
INFO - 2021-12-16 03:17:06 --> Loader Class Initialized
INFO - 2021-12-16 03:17:06 --> Helper loaded: url_helper
INFO - 2021-12-16 03:17:06 --> Helper loaded: file_helper
INFO - 2021-12-16 03:17:06 --> Helper loaded: form_helper
INFO - 2021-12-16 03:17:06 --> Helper loaded: my_helper
INFO - 2021-12-16 03:17:06 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:17:06 --> Controller Class Initialized
INFO - 2021-12-16 03:17:06 --> Upload Class Initialized
INFO - 2021-12-16 03:17:06 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-12-16 03:17:06 --> The upload path does not appear to be valid.
INFO - 2021-12-16 03:17:06 --> Config Class Initialized
INFO - 2021-12-16 03:17:06 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:17:06 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:17:06 --> Utf8 Class Initialized
INFO - 2021-12-16 03:17:06 --> URI Class Initialized
INFO - 2021-12-16 03:17:06 --> Router Class Initialized
INFO - 2021-12-16 03:17:06 --> Output Class Initialized
INFO - 2021-12-16 03:17:06 --> Security Class Initialized
DEBUG - 2021-12-16 03:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:17:06 --> Input Class Initialized
INFO - 2021-12-16 03:17:06 --> Language Class Initialized
INFO - 2021-12-16 03:17:06 --> Language Class Initialized
INFO - 2021-12-16 03:17:06 --> Config Class Initialized
INFO - 2021-12-16 03:17:06 --> Loader Class Initialized
INFO - 2021-12-16 03:17:06 --> Helper loaded: url_helper
INFO - 2021-12-16 03:17:06 --> Helper loaded: file_helper
INFO - 2021-12-16 03:17:06 --> Helper loaded: form_helper
INFO - 2021-12-16 03:17:06 --> Helper loaded: my_helper
INFO - 2021-12-16 03:17:06 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:17:06 --> Controller Class Initialized
DEBUG - 2021-12-16 03:17:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 03:17:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:17:06 --> Final output sent to browser
DEBUG - 2021-12-16 03:17:06 --> Total execution time: 0.0350
INFO - 2021-12-16 03:17:06 --> Config Class Initialized
INFO - 2021-12-16 03:17:06 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:17:06 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:17:06 --> Utf8 Class Initialized
INFO - 2021-12-16 03:17:06 --> URI Class Initialized
INFO - 2021-12-16 03:17:06 --> Router Class Initialized
INFO - 2021-12-16 03:17:06 --> Output Class Initialized
INFO - 2021-12-16 03:17:06 --> Security Class Initialized
DEBUG - 2021-12-16 03:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:17:06 --> Input Class Initialized
INFO - 2021-12-16 03:17:06 --> Language Class Initialized
INFO - 2021-12-16 03:17:06 --> Language Class Initialized
INFO - 2021-12-16 03:17:06 --> Config Class Initialized
INFO - 2021-12-16 03:17:06 --> Loader Class Initialized
INFO - 2021-12-16 03:17:06 --> Helper loaded: url_helper
INFO - 2021-12-16 03:17:06 --> Helper loaded: file_helper
INFO - 2021-12-16 03:17:06 --> Helper loaded: form_helper
INFO - 2021-12-16 03:17:06 --> Helper loaded: my_helper
INFO - 2021-12-16 03:17:06 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:17:06 --> Controller Class Initialized
INFO - 2021-12-16 03:17:09 --> Config Class Initialized
INFO - 2021-12-16 03:17:09 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:17:09 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:17:09 --> Utf8 Class Initialized
INFO - 2021-12-16 03:17:09 --> URI Class Initialized
INFO - 2021-12-16 03:17:09 --> Router Class Initialized
INFO - 2021-12-16 03:17:09 --> Output Class Initialized
INFO - 2021-12-16 03:17:09 --> Security Class Initialized
DEBUG - 2021-12-16 03:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:17:09 --> Input Class Initialized
INFO - 2021-12-16 03:17:09 --> Language Class Initialized
INFO - 2021-12-16 03:17:09 --> Language Class Initialized
INFO - 2021-12-16 03:17:09 --> Config Class Initialized
INFO - 2021-12-16 03:17:09 --> Loader Class Initialized
INFO - 2021-12-16 03:17:09 --> Helper loaded: url_helper
INFO - 2021-12-16 03:17:09 --> Helper loaded: file_helper
INFO - 2021-12-16 03:17:09 --> Helper loaded: form_helper
INFO - 2021-12-16 03:17:09 --> Helper loaded: my_helper
INFO - 2021-12-16 03:17:09 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:17:09 --> Controller Class Initialized
DEBUG - 2021-12-16 03:17:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 03:17:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:17:09 --> Final output sent to browser
DEBUG - 2021-12-16 03:17:09 --> Total execution time: 0.0440
INFO - 2021-12-16 03:18:59 --> Config Class Initialized
INFO - 2021-12-16 03:18:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:18:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:18:59 --> Utf8 Class Initialized
INFO - 2021-12-16 03:18:59 --> URI Class Initialized
INFO - 2021-12-16 03:18:59 --> Router Class Initialized
INFO - 2021-12-16 03:18:59 --> Output Class Initialized
INFO - 2021-12-16 03:18:59 --> Security Class Initialized
DEBUG - 2021-12-16 03:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:18:59 --> Input Class Initialized
INFO - 2021-12-16 03:18:59 --> Language Class Initialized
INFO - 2021-12-16 03:18:59 --> Language Class Initialized
INFO - 2021-12-16 03:18:59 --> Config Class Initialized
INFO - 2021-12-16 03:18:59 --> Loader Class Initialized
INFO - 2021-12-16 03:18:59 --> Helper loaded: url_helper
INFO - 2021-12-16 03:18:59 --> Helper loaded: file_helper
INFO - 2021-12-16 03:18:59 --> Helper loaded: form_helper
INFO - 2021-12-16 03:18:59 --> Helper loaded: my_helper
INFO - 2021-12-16 03:18:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:18:59 --> Controller Class Initialized
DEBUG - 2021-12-16 03:18:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 03:18:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 03:18:59 --> Final output sent to browser
DEBUG - 2021-12-16 03:18:59 --> Total execution time: 0.0350
INFO - 2021-12-16 03:18:59 --> Config Class Initialized
INFO - 2021-12-16 03:18:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 03:18:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 03:18:59 --> Utf8 Class Initialized
INFO - 2021-12-16 03:18:59 --> URI Class Initialized
INFO - 2021-12-16 03:18:59 --> Router Class Initialized
INFO - 2021-12-16 03:18:59 --> Output Class Initialized
INFO - 2021-12-16 03:18:59 --> Security Class Initialized
DEBUG - 2021-12-16 03:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 03:18:59 --> Input Class Initialized
INFO - 2021-12-16 03:18:59 --> Language Class Initialized
INFO - 2021-12-16 03:18:59 --> Language Class Initialized
INFO - 2021-12-16 03:18:59 --> Config Class Initialized
INFO - 2021-12-16 03:18:59 --> Loader Class Initialized
INFO - 2021-12-16 03:18:59 --> Helper loaded: url_helper
INFO - 2021-12-16 03:18:59 --> Helper loaded: file_helper
INFO - 2021-12-16 03:18:59 --> Helper loaded: form_helper
INFO - 2021-12-16 03:18:59 --> Helper loaded: my_helper
INFO - 2021-12-16 03:18:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 03:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 03:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 03:18:59 --> Controller Class Initialized
INFO - 2021-12-16 04:10:32 --> Config Class Initialized
INFO - 2021-12-16 04:10:32 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:10:32 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:10:32 --> Utf8 Class Initialized
INFO - 2021-12-16 04:10:32 --> URI Class Initialized
INFO - 2021-12-16 04:10:32 --> Router Class Initialized
INFO - 2021-12-16 04:10:32 --> Output Class Initialized
INFO - 2021-12-16 04:10:32 --> Security Class Initialized
DEBUG - 2021-12-16 04:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:10:32 --> Input Class Initialized
INFO - 2021-12-16 04:10:32 --> Language Class Initialized
INFO - 2021-12-16 04:10:32 --> Language Class Initialized
INFO - 2021-12-16 04:10:32 --> Config Class Initialized
INFO - 2021-12-16 04:10:32 --> Loader Class Initialized
INFO - 2021-12-16 04:10:32 --> Helper loaded: url_helper
INFO - 2021-12-16 04:10:32 --> Helper loaded: file_helper
INFO - 2021-12-16 04:10:32 --> Helper loaded: form_helper
INFO - 2021-12-16 04:10:32 --> Helper loaded: my_helper
INFO - 2021-12-16 04:10:32 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:10:32 --> Controller Class Initialized
DEBUG - 2021-12-16 04:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-16 04:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:10:32 --> Final output sent to browser
DEBUG - 2021-12-16 04:10:32 --> Total execution time: 0.0320
INFO - 2021-12-16 04:10:32 --> Config Class Initialized
INFO - 2021-12-16 04:10:32 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:10:32 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:10:32 --> Utf8 Class Initialized
INFO - 2021-12-16 04:10:32 --> URI Class Initialized
INFO - 2021-12-16 04:10:32 --> Router Class Initialized
INFO - 2021-12-16 04:10:32 --> Output Class Initialized
INFO - 2021-12-16 04:10:32 --> Security Class Initialized
DEBUG - 2021-12-16 04:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:10:32 --> Input Class Initialized
INFO - 2021-12-16 04:10:32 --> Language Class Initialized
INFO - 2021-12-16 04:10:32 --> Language Class Initialized
INFO - 2021-12-16 04:10:32 --> Config Class Initialized
INFO - 2021-12-16 04:10:32 --> Loader Class Initialized
INFO - 2021-12-16 04:10:32 --> Helper loaded: url_helper
INFO - 2021-12-16 04:10:32 --> Helper loaded: file_helper
INFO - 2021-12-16 04:10:32 --> Helper loaded: form_helper
INFO - 2021-12-16 04:10:32 --> Helper loaded: my_helper
INFO - 2021-12-16 04:10:32 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:10:32 --> Controller Class Initialized
INFO - 2021-12-16 04:10:43 --> Config Class Initialized
INFO - 2021-12-16 04:10:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:10:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:10:43 --> Utf8 Class Initialized
INFO - 2021-12-16 04:10:43 --> URI Class Initialized
INFO - 2021-12-16 04:10:43 --> Router Class Initialized
INFO - 2021-12-16 04:10:43 --> Output Class Initialized
INFO - 2021-12-16 04:10:43 --> Security Class Initialized
DEBUG - 2021-12-16 04:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:10:43 --> Input Class Initialized
INFO - 2021-12-16 04:10:43 --> Language Class Initialized
INFO - 2021-12-16 04:10:43 --> Language Class Initialized
INFO - 2021-12-16 04:10:43 --> Config Class Initialized
INFO - 2021-12-16 04:10:43 --> Loader Class Initialized
INFO - 2021-12-16 04:10:43 --> Helper loaded: url_helper
INFO - 2021-12-16 04:10:43 --> Helper loaded: file_helper
INFO - 2021-12-16 04:10:43 --> Helper loaded: form_helper
INFO - 2021-12-16 04:10:43 --> Helper loaded: my_helper
INFO - 2021-12-16 04:10:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:10:43 --> Controller Class Initialized
INFO - 2021-12-16 04:10:43 --> Final output sent to browser
DEBUG - 2021-12-16 04:10:43 --> Total execution time: 0.0570
INFO - 2021-12-16 04:10:43 --> Config Class Initialized
INFO - 2021-12-16 04:10:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:10:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:10:43 --> Utf8 Class Initialized
INFO - 2021-12-16 04:10:43 --> URI Class Initialized
INFO - 2021-12-16 04:10:43 --> Router Class Initialized
INFO - 2021-12-16 04:10:43 --> Output Class Initialized
INFO - 2021-12-16 04:10:43 --> Security Class Initialized
DEBUG - 2021-12-16 04:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:10:43 --> Input Class Initialized
INFO - 2021-12-16 04:10:43 --> Language Class Initialized
INFO - 2021-12-16 04:10:44 --> Language Class Initialized
INFO - 2021-12-16 04:10:44 --> Config Class Initialized
INFO - 2021-12-16 04:10:44 --> Loader Class Initialized
INFO - 2021-12-16 04:10:44 --> Helper loaded: url_helper
INFO - 2021-12-16 04:10:44 --> Helper loaded: file_helper
INFO - 2021-12-16 04:10:44 --> Helper loaded: form_helper
INFO - 2021-12-16 04:10:44 --> Helper loaded: my_helper
INFO - 2021-12-16 04:10:44 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:10:44 --> Controller Class Initialized
INFO - 2021-12-16 04:10:52 --> Config Class Initialized
INFO - 2021-12-16 04:10:52 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:10:52 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:10:52 --> Utf8 Class Initialized
INFO - 2021-12-16 04:10:52 --> URI Class Initialized
INFO - 2021-12-16 04:10:52 --> Router Class Initialized
INFO - 2021-12-16 04:10:52 --> Output Class Initialized
INFO - 2021-12-16 04:10:52 --> Security Class Initialized
DEBUG - 2021-12-16 04:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:10:52 --> Input Class Initialized
INFO - 2021-12-16 04:10:52 --> Language Class Initialized
INFO - 2021-12-16 04:10:52 --> Language Class Initialized
INFO - 2021-12-16 04:10:52 --> Config Class Initialized
INFO - 2021-12-16 04:10:52 --> Loader Class Initialized
INFO - 2021-12-16 04:10:52 --> Helper loaded: url_helper
INFO - 2021-12-16 04:10:52 --> Helper loaded: file_helper
INFO - 2021-12-16 04:10:52 --> Helper loaded: form_helper
INFO - 2021-12-16 04:10:52 --> Helper loaded: my_helper
INFO - 2021-12-16 04:10:52 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:10:52 --> Controller Class Initialized
INFO - 2021-12-16 04:10:52 --> Helper loaded: cookie_helper
INFO - 2021-12-16 04:10:52 --> Config Class Initialized
INFO - 2021-12-16 04:10:52 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:10:52 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:10:52 --> Utf8 Class Initialized
INFO - 2021-12-16 04:10:52 --> URI Class Initialized
INFO - 2021-12-16 04:10:52 --> Router Class Initialized
INFO - 2021-12-16 04:10:52 --> Output Class Initialized
INFO - 2021-12-16 04:10:52 --> Security Class Initialized
DEBUG - 2021-12-16 04:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:10:52 --> Input Class Initialized
INFO - 2021-12-16 04:10:52 --> Language Class Initialized
INFO - 2021-12-16 04:10:52 --> Language Class Initialized
INFO - 2021-12-16 04:10:52 --> Config Class Initialized
INFO - 2021-12-16 04:10:52 --> Loader Class Initialized
INFO - 2021-12-16 04:10:52 --> Helper loaded: url_helper
INFO - 2021-12-16 04:10:52 --> Helper loaded: file_helper
INFO - 2021-12-16 04:10:52 --> Helper loaded: form_helper
INFO - 2021-12-16 04:10:52 --> Helper loaded: my_helper
INFO - 2021-12-16 04:10:52 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:10:52 --> Controller Class Initialized
DEBUG - 2021-12-16 04:10:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-16 04:10:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:10:52 --> Final output sent to browser
DEBUG - 2021-12-16 04:10:52 --> Total execution time: 0.0360
INFO - 2021-12-16 04:11:10 --> Config Class Initialized
INFO - 2021-12-16 04:11:10 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:11:10 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:11:10 --> Utf8 Class Initialized
INFO - 2021-12-16 04:11:10 --> URI Class Initialized
INFO - 2021-12-16 04:11:10 --> Router Class Initialized
INFO - 2021-12-16 04:11:10 --> Output Class Initialized
INFO - 2021-12-16 04:11:10 --> Security Class Initialized
DEBUG - 2021-12-16 04:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:11:10 --> Input Class Initialized
INFO - 2021-12-16 04:11:10 --> Language Class Initialized
INFO - 2021-12-16 04:11:11 --> Language Class Initialized
INFO - 2021-12-16 04:11:11 --> Config Class Initialized
INFO - 2021-12-16 04:11:11 --> Loader Class Initialized
INFO - 2021-12-16 04:11:11 --> Helper loaded: url_helper
INFO - 2021-12-16 04:11:11 --> Helper loaded: file_helper
INFO - 2021-12-16 04:11:11 --> Helper loaded: form_helper
INFO - 2021-12-16 04:11:11 --> Helper loaded: my_helper
INFO - 2021-12-16 04:11:11 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:11:11 --> Controller Class Initialized
INFO - 2021-12-16 04:11:11 --> Helper loaded: cookie_helper
INFO - 2021-12-16 04:11:11 --> Final output sent to browser
DEBUG - 2021-12-16 04:11:11 --> Total execution time: 0.0450
INFO - 2021-12-16 04:11:15 --> Config Class Initialized
INFO - 2021-12-16 04:11:15 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:11:15 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:11:15 --> Utf8 Class Initialized
INFO - 2021-12-16 04:11:15 --> URI Class Initialized
INFO - 2021-12-16 04:11:15 --> Router Class Initialized
INFO - 2021-12-16 04:11:15 --> Output Class Initialized
INFO - 2021-12-16 04:11:15 --> Security Class Initialized
DEBUG - 2021-12-16 04:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:11:15 --> Input Class Initialized
INFO - 2021-12-16 04:11:15 --> Language Class Initialized
INFO - 2021-12-16 04:11:15 --> Language Class Initialized
INFO - 2021-12-16 04:11:15 --> Config Class Initialized
INFO - 2021-12-16 04:11:15 --> Loader Class Initialized
INFO - 2021-12-16 04:11:15 --> Helper loaded: url_helper
INFO - 2021-12-16 04:11:15 --> Helper loaded: file_helper
INFO - 2021-12-16 04:11:15 --> Helper loaded: form_helper
INFO - 2021-12-16 04:11:15 --> Helper loaded: my_helper
INFO - 2021-12-16 04:11:15 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:11:15 --> Controller Class Initialized
DEBUG - 2021-12-16 04:11:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-16 04:11:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:11:15 --> Final output sent to browser
DEBUG - 2021-12-16 04:11:15 --> Total execution time: 0.2020
INFO - 2021-12-16 04:11:36 --> Config Class Initialized
INFO - 2021-12-16 04:11:36 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:11:36 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:11:36 --> Utf8 Class Initialized
INFO - 2021-12-16 04:11:36 --> URI Class Initialized
INFO - 2021-12-16 04:11:36 --> Router Class Initialized
INFO - 2021-12-16 04:11:36 --> Output Class Initialized
INFO - 2021-12-16 04:11:36 --> Security Class Initialized
DEBUG - 2021-12-16 04:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:11:36 --> Input Class Initialized
INFO - 2021-12-16 04:11:36 --> Language Class Initialized
INFO - 2021-12-16 04:11:36 --> Language Class Initialized
INFO - 2021-12-16 04:11:36 --> Config Class Initialized
INFO - 2021-12-16 04:11:36 --> Loader Class Initialized
INFO - 2021-12-16 04:11:36 --> Helper loaded: url_helper
INFO - 2021-12-16 04:11:36 --> Helper loaded: file_helper
INFO - 2021-12-16 04:11:36 --> Helper loaded: form_helper
INFO - 2021-12-16 04:11:36 --> Helper loaded: my_helper
INFO - 2021-12-16 04:11:36 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:11:36 --> Controller Class Initialized
DEBUG - 2021-12-16 04:11:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-16 04:11:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:11:36 --> Final output sent to browser
DEBUG - 2021-12-16 04:11:36 --> Total execution time: 0.1140
INFO - 2021-12-16 04:13:27 --> Config Class Initialized
INFO - 2021-12-16 04:13:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:13:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:13:27 --> Utf8 Class Initialized
INFO - 2021-12-16 04:13:27 --> URI Class Initialized
INFO - 2021-12-16 04:13:27 --> Router Class Initialized
INFO - 2021-12-16 04:13:27 --> Output Class Initialized
INFO - 2021-12-16 04:13:27 --> Security Class Initialized
DEBUG - 2021-12-16 04:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:13:27 --> Input Class Initialized
INFO - 2021-12-16 04:13:27 --> Language Class Initialized
INFO - 2021-12-16 04:13:27 --> Language Class Initialized
INFO - 2021-12-16 04:13:27 --> Config Class Initialized
INFO - 2021-12-16 04:13:27 --> Loader Class Initialized
INFO - 2021-12-16 04:13:27 --> Helper loaded: url_helper
INFO - 2021-12-16 04:13:27 --> Helper loaded: file_helper
INFO - 2021-12-16 04:13:27 --> Helper loaded: form_helper
INFO - 2021-12-16 04:13:27 --> Helper loaded: my_helper
INFO - 2021-12-16 04:13:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:13:27 --> Controller Class Initialized
INFO - 2021-12-16 04:13:27 --> Final output sent to browser
DEBUG - 2021-12-16 04:13:27 --> Total execution time: 0.0720
INFO - 2021-12-16 04:18:47 --> Config Class Initialized
INFO - 2021-12-16 04:18:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:18:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:18:47 --> Utf8 Class Initialized
INFO - 2021-12-16 04:18:47 --> URI Class Initialized
INFO - 2021-12-16 04:18:47 --> Router Class Initialized
INFO - 2021-12-16 04:18:47 --> Output Class Initialized
INFO - 2021-12-16 04:18:47 --> Security Class Initialized
DEBUG - 2021-12-16 04:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:18:47 --> Input Class Initialized
INFO - 2021-12-16 04:18:47 --> Language Class Initialized
INFO - 2021-12-16 04:18:47 --> Language Class Initialized
INFO - 2021-12-16 04:18:47 --> Config Class Initialized
INFO - 2021-12-16 04:18:47 --> Loader Class Initialized
INFO - 2021-12-16 04:18:47 --> Helper loaded: url_helper
INFO - 2021-12-16 04:18:47 --> Helper loaded: file_helper
INFO - 2021-12-16 04:18:47 --> Helper loaded: form_helper
INFO - 2021-12-16 04:18:47 --> Helper loaded: my_helper
INFO - 2021-12-16 04:18:47 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:18:47 --> Controller Class Initialized
INFO - 2021-12-16 04:18:48 --> Final output sent to browser
DEBUG - 2021-12-16 04:18:48 --> Total execution time: 0.0640
INFO - 2021-12-16 04:28:56 --> Config Class Initialized
INFO - 2021-12-16 04:28:56 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:28:56 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:28:56 --> Utf8 Class Initialized
INFO - 2021-12-16 04:28:56 --> URI Class Initialized
INFO - 2021-12-16 04:28:56 --> Router Class Initialized
INFO - 2021-12-16 04:28:56 --> Output Class Initialized
INFO - 2021-12-16 04:28:56 --> Security Class Initialized
DEBUG - 2021-12-16 04:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:28:56 --> Input Class Initialized
INFO - 2021-12-16 04:28:56 --> Language Class Initialized
INFO - 2021-12-16 04:28:56 --> Language Class Initialized
INFO - 2021-12-16 04:28:56 --> Config Class Initialized
INFO - 2021-12-16 04:28:56 --> Loader Class Initialized
INFO - 2021-12-16 04:28:56 --> Helper loaded: url_helper
INFO - 2021-12-16 04:28:56 --> Helper loaded: file_helper
INFO - 2021-12-16 04:28:56 --> Helper loaded: form_helper
INFO - 2021-12-16 04:28:56 --> Helper loaded: my_helper
INFO - 2021-12-16 04:28:56 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:28:56 --> Controller Class Initialized
INFO - 2021-12-16 04:28:56 --> Final output sent to browser
DEBUG - 2021-12-16 04:28:56 --> Total execution time: 0.0670
INFO - 2021-12-16 04:29:21 --> Config Class Initialized
INFO - 2021-12-16 04:29:21 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:29:21 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:29:21 --> Utf8 Class Initialized
INFO - 2021-12-16 04:29:21 --> URI Class Initialized
INFO - 2021-12-16 04:29:21 --> Router Class Initialized
INFO - 2021-12-16 04:29:21 --> Output Class Initialized
INFO - 2021-12-16 04:29:21 --> Security Class Initialized
DEBUG - 2021-12-16 04:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:29:21 --> Input Class Initialized
INFO - 2021-12-16 04:29:21 --> Language Class Initialized
INFO - 2021-12-16 04:29:21 --> Language Class Initialized
INFO - 2021-12-16 04:29:21 --> Config Class Initialized
INFO - 2021-12-16 04:29:21 --> Loader Class Initialized
INFO - 2021-12-16 04:29:21 --> Helper loaded: url_helper
INFO - 2021-12-16 04:29:21 --> Helper loaded: file_helper
INFO - 2021-12-16 04:29:21 --> Helper loaded: form_helper
INFO - 2021-12-16 04:29:21 --> Helper loaded: my_helper
INFO - 2021-12-16 04:29:21 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:29:21 --> Controller Class Initialized
DEBUG - 2021-12-16 04:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-16 04:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:29:21 --> Final output sent to browser
DEBUG - 2021-12-16 04:29:21 --> Total execution time: 0.0550
INFO - 2021-12-16 04:34:11 --> Config Class Initialized
INFO - 2021-12-16 04:34:11 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:34:11 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:34:11 --> Utf8 Class Initialized
INFO - 2021-12-16 04:34:11 --> URI Class Initialized
INFO - 2021-12-16 04:34:11 --> Router Class Initialized
INFO - 2021-12-16 04:34:11 --> Output Class Initialized
INFO - 2021-12-16 04:34:11 --> Security Class Initialized
DEBUG - 2021-12-16 04:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:34:11 --> Input Class Initialized
INFO - 2021-12-16 04:34:11 --> Language Class Initialized
INFO - 2021-12-16 04:34:11 --> Language Class Initialized
INFO - 2021-12-16 04:34:11 --> Config Class Initialized
INFO - 2021-12-16 04:34:11 --> Loader Class Initialized
INFO - 2021-12-16 04:34:11 --> Helper loaded: url_helper
INFO - 2021-12-16 04:34:11 --> Helper loaded: file_helper
INFO - 2021-12-16 04:34:11 --> Helper loaded: form_helper
INFO - 2021-12-16 04:34:11 --> Helper loaded: my_helper
INFO - 2021-12-16 04:34:11 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:34:11 --> Controller Class Initialized
INFO - 2021-12-16 04:34:11 --> Final output sent to browser
DEBUG - 2021-12-16 04:34:11 --> Total execution time: 0.0780
INFO - 2021-12-16 04:34:21 --> Config Class Initialized
INFO - 2021-12-16 04:34:21 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:34:21 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:34:21 --> Utf8 Class Initialized
INFO - 2021-12-16 04:34:21 --> URI Class Initialized
INFO - 2021-12-16 04:34:21 --> Router Class Initialized
INFO - 2021-12-16 04:34:21 --> Output Class Initialized
INFO - 2021-12-16 04:34:21 --> Security Class Initialized
DEBUG - 2021-12-16 04:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:34:21 --> Input Class Initialized
INFO - 2021-12-16 04:34:21 --> Language Class Initialized
INFO - 2021-12-16 04:34:21 --> Language Class Initialized
INFO - 2021-12-16 04:34:21 --> Config Class Initialized
INFO - 2021-12-16 04:34:21 --> Loader Class Initialized
INFO - 2021-12-16 04:34:21 --> Helper loaded: url_helper
INFO - 2021-12-16 04:34:21 --> Helper loaded: file_helper
INFO - 2021-12-16 04:34:21 --> Helper loaded: form_helper
INFO - 2021-12-16 04:34:21 --> Helper loaded: my_helper
INFO - 2021-12-16 04:34:21 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:34:21 --> Controller Class Initialized
DEBUG - 2021-12-16 04:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-16 04:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:34:21 --> Final output sent to browser
DEBUG - 2021-12-16 04:34:21 --> Total execution time: 0.0460
INFO - 2021-12-16 04:34:35 --> Config Class Initialized
INFO - 2021-12-16 04:34:35 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:34:35 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:34:35 --> Utf8 Class Initialized
INFO - 2021-12-16 04:34:35 --> URI Class Initialized
INFO - 2021-12-16 04:34:35 --> Router Class Initialized
INFO - 2021-12-16 04:34:35 --> Output Class Initialized
INFO - 2021-12-16 04:34:35 --> Security Class Initialized
DEBUG - 2021-12-16 04:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:34:35 --> Input Class Initialized
INFO - 2021-12-16 04:34:35 --> Language Class Initialized
INFO - 2021-12-16 04:34:35 --> Language Class Initialized
INFO - 2021-12-16 04:34:35 --> Config Class Initialized
INFO - 2021-12-16 04:34:35 --> Loader Class Initialized
INFO - 2021-12-16 04:34:35 --> Helper loaded: url_helper
INFO - 2021-12-16 04:34:35 --> Helper loaded: file_helper
INFO - 2021-12-16 04:34:35 --> Helper loaded: form_helper
INFO - 2021-12-16 04:34:35 --> Helper loaded: my_helper
INFO - 2021-12-16 04:34:35 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:34:35 --> Controller Class Initialized
INFO - 2021-12-16 04:34:35 --> Final output sent to browser
DEBUG - 2021-12-16 04:34:35 --> Total execution time: 0.0500
INFO - 2021-12-16 04:35:53 --> Config Class Initialized
INFO - 2021-12-16 04:35:53 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:35:53 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:35:53 --> Utf8 Class Initialized
INFO - 2021-12-16 04:35:53 --> URI Class Initialized
INFO - 2021-12-16 04:35:53 --> Router Class Initialized
INFO - 2021-12-16 04:35:53 --> Output Class Initialized
INFO - 2021-12-16 04:35:53 --> Security Class Initialized
DEBUG - 2021-12-16 04:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:35:53 --> Input Class Initialized
INFO - 2021-12-16 04:35:53 --> Language Class Initialized
INFO - 2021-12-16 04:35:53 --> Language Class Initialized
INFO - 2021-12-16 04:35:53 --> Config Class Initialized
INFO - 2021-12-16 04:35:53 --> Loader Class Initialized
INFO - 2021-12-16 04:35:53 --> Helper loaded: url_helper
INFO - 2021-12-16 04:35:53 --> Helper loaded: file_helper
INFO - 2021-12-16 04:35:53 --> Helper loaded: form_helper
INFO - 2021-12-16 04:35:53 --> Helper loaded: my_helper
INFO - 2021-12-16 04:35:53 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:35:53 --> Controller Class Initialized
INFO - 2021-12-16 04:35:53 --> Final output sent to browser
DEBUG - 2021-12-16 04:35:53 --> Total execution time: 0.0980
INFO - 2021-12-16 04:35:56 --> Config Class Initialized
INFO - 2021-12-16 04:35:56 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:35:56 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:35:56 --> Utf8 Class Initialized
INFO - 2021-12-16 04:35:56 --> URI Class Initialized
INFO - 2021-12-16 04:35:56 --> Router Class Initialized
INFO - 2021-12-16 04:35:56 --> Output Class Initialized
INFO - 2021-12-16 04:35:56 --> Security Class Initialized
DEBUG - 2021-12-16 04:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:35:56 --> Input Class Initialized
INFO - 2021-12-16 04:35:56 --> Language Class Initialized
INFO - 2021-12-16 04:35:56 --> Language Class Initialized
INFO - 2021-12-16 04:35:56 --> Config Class Initialized
INFO - 2021-12-16 04:35:56 --> Loader Class Initialized
INFO - 2021-12-16 04:35:56 --> Helper loaded: url_helper
INFO - 2021-12-16 04:35:56 --> Helper loaded: file_helper
INFO - 2021-12-16 04:35:56 --> Helper loaded: form_helper
INFO - 2021-12-16 04:35:56 --> Helper loaded: my_helper
INFO - 2021-12-16 04:35:56 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:35:56 --> Controller Class Initialized
DEBUG - 2021-12-16 04:35:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-16 04:35:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:35:56 --> Final output sent to browser
DEBUG - 2021-12-16 04:35:56 --> Total execution time: 0.0510
INFO - 2021-12-16 04:36:02 --> Config Class Initialized
INFO - 2021-12-16 04:36:02 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:36:02 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:36:02 --> Utf8 Class Initialized
INFO - 2021-12-16 04:36:02 --> URI Class Initialized
INFO - 2021-12-16 04:36:02 --> Router Class Initialized
INFO - 2021-12-16 04:36:02 --> Output Class Initialized
INFO - 2021-12-16 04:36:02 --> Security Class Initialized
DEBUG - 2021-12-16 04:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:36:02 --> Input Class Initialized
INFO - 2021-12-16 04:36:02 --> Language Class Initialized
INFO - 2021-12-16 04:36:02 --> Language Class Initialized
INFO - 2021-12-16 04:36:02 --> Config Class Initialized
INFO - 2021-12-16 04:36:02 --> Loader Class Initialized
INFO - 2021-12-16 04:36:02 --> Helper loaded: url_helper
INFO - 2021-12-16 04:36:02 --> Helper loaded: file_helper
INFO - 2021-12-16 04:36:02 --> Helper loaded: form_helper
INFO - 2021-12-16 04:36:02 --> Helper loaded: my_helper
INFO - 2021-12-16 04:36:02 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:36:02 --> Controller Class Initialized
DEBUG - 2021-12-16 04:36:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-16 04:36:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:36:02 --> Final output sent to browser
DEBUG - 2021-12-16 04:36:02 --> Total execution time: 0.0480
INFO - 2021-12-16 04:36:04 --> Config Class Initialized
INFO - 2021-12-16 04:36:04 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:36:04 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:36:04 --> Utf8 Class Initialized
INFO - 2021-12-16 04:36:04 --> URI Class Initialized
INFO - 2021-12-16 04:36:04 --> Router Class Initialized
INFO - 2021-12-16 04:36:04 --> Output Class Initialized
INFO - 2021-12-16 04:36:04 --> Security Class Initialized
DEBUG - 2021-12-16 04:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:36:04 --> Input Class Initialized
INFO - 2021-12-16 04:36:04 --> Language Class Initialized
INFO - 2021-12-16 04:36:04 --> Language Class Initialized
INFO - 2021-12-16 04:36:04 --> Config Class Initialized
INFO - 2021-12-16 04:36:04 --> Loader Class Initialized
INFO - 2021-12-16 04:36:04 --> Helper loaded: url_helper
INFO - 2021-12-16 04:36:04 --> Helper loaded: file_helper
INFO - 2021-12-16 04:36:04 --> Helper loaded: form_helper
INFO - 2021-12-16 04:36:04 --> Helper loaded: my_helper
INFO - 2021-12-16 04:36:04 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:36:04 --> Controller Class Initialized
INFO - 2021-12-16 04:36:04 --> Final output sent to browser
DEBUG - 2021-12-16 04:36:04 --> Total execution time: 0.0450
INFO - 2021-12-16 04:36:10 --> Config Class Initialized
INFO - 2021-12-16 04:36:10 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:36:10 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:36:10 --> Utf8 Class Initialized
INFO - 2021-12-16 04:36:10 --> URI Class Initialized
INFO - 2021-12-16 04:36:10 --> Router Class Initialized
INFO - 2021-12-16 04:36:10 --> Output Class Initialized
INFO - 2021-12-16 04:36:10 --> Security Class Initialized
DEBUG - 2021-12-16 04:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:36:10 --> Input Class Initialized
INFO - 2021-12-16 04:36:10 --> Language Class Initialized
INFO - 2021-12-16 04:36:10 --> Language Class Initialized
INFO - 2021-12-16 04:36:10 --> Config Class Initialized
INFO - 2021-12-16 04:36:10 --> Loader Class Initialized
INFO - 2021-12-16 04:36:10 --> Helper loaded: url_helper
INFO - 2021-12-16 04:36:10 --> Helper loaded: file_helper
INFO - 2021-12-16 04:36:10 --> Helper loaded: form_helper
INFO - 2021-12-16 04:36:10 --> Helper loaded: my_helper
INFO - 2021-12-16 04:36:10 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:36:10 --> Controller Class Initialized
INFO - 2021-12-16 04:36:10 --> Final output sent to browser
DEBUG - 2021-12-16 04:36:10 --> Total execution time: 0.1080
INFO - 2021-12-16 04:36:12 --> Config Class Initialized
INFO - 2021-12-16 04:36:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:36:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:36:12 --> Utf8 Class Initialized
INFO - 2021-12-16 04:36:12 --> URI Class Initialized
INFO - 2021-12-16 04:36:12 --> Router Class Initialized
INFO - 2021-12-16 04:36:12 --> Output Class Initialized
INFO - 2021-12-16 04:36:12 --> Security Class Initialized
DEBUG - 2021-12-16 04:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:36:12 --> Input Class Initialized
INFO - 2021-12-16 04:36:12 --> Language Class Initialized
INFO - 2021-12-16 04:36:12 --> Language Class Initialized
INFO - 2021-12-16 04:36:12 --> Config Class Initialized
INFO - 2021-12-16 04:36:12 --> Loader Class Initialized
INFO - 2021-12-16 04:36:12 --> Helper loaded: url_helper
INFO - 2021-12-16 04:36:12 --> Helper loaded: file_helper
INFO - 2021-12-16 04:36:12 --> Helper loaded: form_helper
INFO - 2021-12-16 04:36:12 --> Helper loaded: my_helper
INFO - 2021-12-16 04:36:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:36:12 --> Controller Class Initialized
DEBUG - 2021-12-16 04:36:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-16 04:36:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:36:12 --> Final output sent to browser
DEBUG - 2021-12-16 04:36:12 --> Total execution time: 0.0760
INFO - 2021-12-16 04:39:41 --> Config Class Initialized
INFO - 2021-12-16 04:39:41 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:39:41 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:39:41 --> Utf8 Class Initialized
INFO - 2021-12-16 04:39:41 --> URI Class Initialized
INFO - 2021-12-16 04:39:41 --> Router Class Initialized
INFO - 2021-12-16 04:39:41 --> Output Class Initialized
INFO - 2021-12-16 04:39:41 --> Security Class Initialized
DEBUG - 2021-12-16 04:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:39:41 --> Input Class Initialized
INFO - 2021-12-16 04:39:41 --> Language Class Initialized
INFO - 2021-12-16 04:39:41 --> Language Class Initialized
INFO - 2021-12-16 04:39:41 --> Config Class Initialized
INFO - 2021-12-16 04:39:41 --> Loader Class Initialized
INFO - 2021-12-16 04:39:41 --> Helper loaded: url_helper
INFO - 2021-12-16 04:39:41 --> Helper loaded: file_helper
INFO - 2021-12-16 04:39:41 --> Helper loaded: form_helper
INFO - 2021-12-16 04:39:41 --> Helper loaded: my_helper
INFO - 2021-12-16 04:39:41 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:39:41 --> Controller Class Initialized
INFO - 2021-12-16 04:39:41 --> Final output sent to browser
DEBUG - 2021-12-16 04:39:41 --> Total execution time: 0.0880
INFO - 2021-12-16 04:39:52 --> Config Class Initialized
INFO - 2021-12-16 04:39:52 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:39:52 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:39:52 --> Utf8 Class Initialized
INFO - 2021-12-16 04:39:52 --> URI Class Initialized
INFO - 2021-12-16 04:39:52 --> Router Class Initialized
INFO - 2021-12-16 04:39:52 --> Output Class Initialized
INFO - 2021-12-16 04:39:52 --> Security Class Initialized
DEBUG - 2021-12-16 04:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:39:52 --> Input Class Initialized
INFO - 2021-12-16 04:39:52 --> Language Class Initialized
INFO - 2021-12-16 04:39:52 --> Language Class Initialized
INFO - 2021-12-16 04:39:52 --> Config Class Initialized
INFO - 2021-12-16 04:39:52 --> Loader Class Initialized
INFO - 2021-12-16 04:39:52 --> Helper loaded: url_helper
INFO - 2021-12-16 04:39:52 --> Helper loaded: file_helper
INFO - 2021-12-16 04:39:52 --> Helper loaded: form_helper
INFO - 2021-12-16 04:39:52 --> Helper loaded: my_helper
INFO - 2021-12-16 04:39:52 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:39:52 --> Controller Class Initialized
INFO - 2021-12-16 04:39:52 --> Final output sent to browser
DEBUG - 2021-12-16 04:39:52 --> Total execution time: 0.0920
INFO - 2021-12-16 04:40:02 --> Config Class Initialized
INFO - 2021-12-16 04:40:02 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:40:02 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:40:02 --> Utf8 Class Initialized
INFO - 2021-12-16 04:40:02 --> URI Class Initialized
INFO - 2021-12-16 04:40:02 --> Router Class Initialized
INFO - 2021-12-16 04:40:02 --> Output Class Initialized
INFO - 2021-12-16 04:40:02 --> Security Class Initialized
DEBUG - 2021-12-16 04:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:40:02 --> Input Class Initialized
INFO - 2021-12-16 04:40:02 --> Language Class Initialized
INFO - 2021-12-16 04:40:02 --> Language Class Initialized
INFO - 2021-12-16 04:40:02 --> Config Class Initialized
INFO - 2021-12-16 04:40:02 --> Loader Class Initialized
INFO - 2021-12-16 04:40:02 --> Helper loaded: url_helper
INFO - 2021-12-16 04:40:02 --> Helper loaded: file_helper
INFO - 2021-12-16 04:40:02 --> Helper loaded: form_helper
INFO - 2021-12-16 04:40:02 --> Helper loaded: my_helper
INFO - 2021-12-16 04:40:02 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:40:02 --> Controller Class Initialized
INFO - 2021-12-16 04:40:02 --> Helper loaded: cookie_helper
INFO - 2021-12-16 04:40:02 --> Config Class Initialized
INFO - 2021-12-16 04:40:02 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:40:02 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:40:02 --> Utf8 Class Initialized
INFO - 2021-12-16 04:40:02 --> URI Class Initialized
INFO - 2021-12-16 04:40:02 --> Router Class Initialized
INFO - 2021-12-16 04:40:02 --> Output Class Initialized
INFO - 2021-12-16 04:40:02 --> Security Class Initialized
DEBUG - 2021-12-16 04:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:40:02 --> Input Class Initialized
INFO - 2021-12-16 04:40:02 --> Language Class Initialized
INFO - 2021-12-16 04:40:02 --> Language Class Initialized
INFO - 2021-12-16 04:40:02 --> Config Class Initialized
INFO - 2021-12-16 04:40:02 --> Loader Class Initialized
INFO - 2021-12-16 04:40:02 --> Helper loaded: url_helper
INFO - 2021-12-16 04:40:02 --> Helper loaded: file_helper
INFO - 2021-12-16 04:40:02 --> Helper loaded: form_helper
INFO - 2021-12-16 04:40:02 --> Helper loaded: my_helper
INFO - 2021-12-16 04:40:02 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:40:02 --> Controller Class Initialized
DEBUG - 2021-12-16 04:40:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-16 04:40:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:40:02 --> Final output sent to browser
DEBUG - 2021-12-16 04:40:02 --> Total execution time: 0.0350
INFO - 2021-12-16 04:40:24 --> Config Class Initialized
INFO - 2021-12-16 04:40:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:40:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:40:24 --> Utf8 Class Initialized
INFO - 2021-12-16 04:40:24 --> URI Class Initialized
INFO - 2021-12-16 04:40:24 --> Router Class Initialized
INFO - 2021-12-16 04:40:24 --> Output Class Initialized
INFO - 2021-12-16 04:40:24 --> Security Class Initialized
DEBUG - 2021-12-16 04:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:40:24 --> Input Class Initialized
INFO - 2021-12-16 04:40:24 --> Language Class Initialized
INFO - 2021-12-16 04:40:24 --> Language Class Initialized
INFO - 2021-12-16 04:40:24 --> Config Class Initialized
INFO - 2021-12-16 04:40:24 --> Loader Class Initialized
INFO - 2021-12-16 04:40:24 --> Helper loaded: url_helper
INFO - 2021-12-16 04:40:24 --> Helper loaded: file_helper
INFO - 2021-12-16 04:40:24 --> Helper loaded: form_helper
INFO - 2021-12-16 04:40:24 --> Helper loaded: my_helper
INFO - 2021-12-16 04:40:24 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:40:24 --> Controller Class Initialized
INFO - 2021-12-16 04:40:24 --> Final output sent to browser
DEBUG - 2021-12-16 04:40:24 --> Total execution time: 0.0580
INFO - 2021-12-16 04:40:33 --> Config Class Initialized
INFO - 2021-12-16 04:40:33 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:40:33 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:40:33 --> Utf8 Class Initialized
INFO - 2021-12-16 04:40:33 --> URI Class Initialized
INFO - 2021-12-16 04:40:33 --> Router Class Initialized
INFO - 2021-12-16 04:40:33 --> Output Class Initialized
INFO - 2021-12-16 04:40:33 --> Security Class Initialized
DEBUG - 2021-12-16 04:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:40:33 --> Input Class Initialized
INFO - 2021-12-16 04:40:33 --> Language Class Initialized
INFO - 2021-12-16 04:40:33 --> Language Class Initialized
INFO - 2021-12-16 04:40:33 --> Config Class Initialized
INFO - 2021-12-16 04:40:33 --> Loader Class Initialized
INFO - 2021-12-16 04:40:33 --> Helper loaded: url_helper
INFO - 2021-12-16 04:40:33 --> Helper loaded: file_helper
INFO - 2021-12-16 04:40:33 --> Helper loaded: form_helper
INFO - 2021-12-16 04:40:33 --> Helper loaded: my_helper
INFO - 2021-12-16 04:40:33 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:40:33 --> Controller Class Initialized
INFO - 2021-12-16 04:40:33 --> Final output sent to browser
DEBUG - 2021-12-16 04:40:33 --> Total execution time: 0.0450
INFO - 2021-12-16 04:40:47 --> Config Class Initialized
INFO - 2021-12-16 04:40:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:40:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:40:47 --> Utf8 Class Initialized
INFO - 2021-12-16 04:40:47 --> URI Class Initialized
INFO - 2021-12-16 04:40:47 --> Router Class Initialized
INFO - 2021-12-16 04:40:47 --> Output Class Initialized
INFO - 2021-12-16 04:40:47 --> Security Class Initialized
DEBUG - 2021-12-16 04:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:40:47 --> Input Class Initialized
INFO - 2021-12-16 04:40:47 --> Language Class Initialized
INFO - 2021-12-16 04:40:47 --> Language Class Initialized
INFO - 2021-12-16 04:40:47 --> Config Class Initialized
INFO - 2021-12-16 04:40:47 --> Loader Class Initialized
INFO - 2021-12-16 04:40:47 --> Helper loaded: url_helper
INFO - 2021-12-16 04:40:47 --> Helper loaded: file_helper
INFO - 2021-12-16 04:40:47 --> Helper loaded: form_helper
INFO - 2021-12-16 04:40:47 --> Helper loaded: my_helper
INFO - 2021-12-16 04:40:47 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:40:47 --> Controller Class Initialized
INFO - 2021-12-16 04:40:47 --> Final output sent to browser
DEBUG - 2021-12-16 04:40:47 --> Total execution time: 0.0620
INFO - 2021-12-16 04:40:54 --> Config Class Initialized
INFO - 2021-12-16 04:40:54 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:40:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:40:55 --> Utf8 Class Initialized
INFO - 2021-12-16 04:40:55 --> URI Class Initialized
INFO - 2021-12-16 04:40:55 --> Router Class Initialized
INFO - 2021-12-16 04:40:55 --> Output Class Initialized
INFO - 2021-12-16 04:40:55 --> Security Class Initialized
DEBUG - 2021-12-16 04:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:40:55 --> Input Class Initialized
INFO - 2021-12-16 04:40:55 --> Language Class Initialized
INFO - 2021-12-16 04:40:55 --> Language Class Initialized
INFO - 2021-12-16 04:40:55 --> Config Class Initialized
INFO - 2021-12-16 04:40:55 --> Loader Class Initialized
INFO - 2021-12-16 04:40:55 --> Helper loaded: url_helper
INFO - 2021-12-16 04:40:55 --> Helper loaded: file_helper
INFO - 2021-12-16 04:40:55 --> Helper loaded: form_helper
INFO - 2021-12-16 04:40:55 --> Helper loaded: my_helper
INFO - 2021-12-16 04:40:55 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:40:55 --> Controller Class Initialized
INFO - 2021-12-16 04:40:55 --> Final output sent to browser
DEBUG - 2021-12-16 04:40:55 --> Total execution time: 0.0630
INFO - 2021-12-16 04:41:08 --> Config Class Initialized
INFO - 2021-12-16 04:41:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:08 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:08 --> URI Class Initialized
INFO - 2021-12-16 04:41:08 --> Router Class Initialized
INFO - 2021-12-16 04:41:08 --> Output Class Initialized
INFO - 2021-12-16 04:41:08 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:08 --> Input Class Initialized
INFO - 2021-12-16 04:41:08 --> Language Class Initialized
INFO - 2021-12-16 04:41:08 --> Language Class Initialized
INFO - 2021-12-16 04:41:08 --> Config Class Initialized
INFO - 2021-12-16 04:41:08 --> Loader Class Initialized
INFO - 2021-12-16 04:41:08 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:08 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:08 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:08 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:08 --> Controller Class Initialized
INFO - 2021-12-16 04:41:08 --> Helper loaded: cookie_helper
INFO - 2021-12-16 04:41:08 --> Final output sent to browser
DEBUG - 2021-12-16 04:41:08 --> Total execution time: 0.0580
INFO - 2021-12-16 04:41:09 --> Config Class Initialized
INFO - 2021-12-16 04:41:09 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:09 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:09 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:09 --> URI Class Initialized
INFO - 2021-12-16 04:41:09 --> Router Class Initialized
INFO - 2021-12-16 04:41:09 --> Output Class Initialized
INFO - 2021-12-16 04:41:09 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:09 --> Input Class Initialized
INFO - 2021-12-16 04:41:09 --> Language Class Initialized
INFO - 2021-12-16 04:41:09 --> Language Class Initialized
INFO - 2021-12-16 04:41:09 --> Config Class Initialized
INFO - 2021-12-16 04:41:09 --> Loader Class Initialized
INFO - 2021-12-16 04:41:09 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:09 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:09 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:09 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:09 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:09 --> Controller Class Initialized
DEBUG - 2021-12-16 04:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-16 04:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:41:09 --> Final output sent to browser
DEBUG - 2021-12-16 04:41:09 --> Total execution time: 0.2610
INFO - 2021-12-16 04:41:15 --> Config Class Initialized
INFO - 2021-12-16 04:41:15 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:15 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:15 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:15 --> URI Class Initialized
INFO - 2021-12-16 04:41:15 --> Router Class Initialized
INFO - 2021-12-16 04:41:15 --> Output Class Initialized
INFO - 2021-12-16 04:41:15 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:15 --> Input Class Initialized
INFO - 2021-12-16 04:41:15 --> Language Class Initialized
INFO - 2021-12-16 04:41:15 --> Language Class Initialized
INFO - 2021-12-16 04:41:15 --> Config Class Initialized
INFO - 2021-12-16 04:41:15 --> Loader Class Initialized
INFO - 2021-12-16 04:41:15 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:15 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:15 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:15 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:15 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:15 --> Controller Class Initialized
DEBUG - 2021-12-16 04:41:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-16 04:41:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:41:15 --> Final output sent to browser
DEBUG - 2021-12-16 04:41:15 --> Total execution time: 0.0580
INFO - 2021-12-16 04:41:15 --> Config Class Initialized
INFO - 2021-12-16 04:41:15 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:15 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:15 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:15 --> URI Class Initialized
INFO - 2021-12-16 04:41:15 --> Router Class Initialized
INFO - 2021-12-16 04:41:15 --> Output Class Initialized
INFO - 2021-12-16 04:41:15 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:15 --> Input Class Initialized
INFO - 2021-12-16 04:41:15 --> Language Class Initialized
INFO - 2021-12-16 04:41:15 --> Language Class Initialized
INFO - 2021-12-16 04:41:15 --> Config Class Initialized
INFO - 2021-12-16 04:41:15 --> Loader Class Initialized
INFO - 2021-12-16 04:41:15 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:15 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:15 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:15 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:15 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:15 --> Controller Class Initialized
INFO - 2021-12-16 04:41:18 --> Config Class Initialized
INFO - 2021-12-16 04:41:18 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:18 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:18 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:18 --> URI Class Initialized
INFO - 2021-12-16 04:41:18 --> Router Class Initialized
INFO - 2021-12-16 04:41:18 --> Output Class Initialized
INFO - 2021-12-16 04:41:18 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:18 --> Input Class Initialized
INFO - 2021-12-16 04:41:18 --> Language Class Initialized
INFO - 2021-12-16 04:41:18 --> Language Class Initialized
INFO - 2021-12-16 04:41:18 --> Config Class Initialized
INFO - 2021-12-16 04:41:18 --> Loader Class Initialized
INFO - 2021-12-16 04:41:18 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:18 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:18 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:18 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:18 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:18 --> Controller Class Initialized
INFO - 2021-12-16 04:41:18 --> Final output sent to browser
DEBUG - 2021-12-16 04:41:18 --> Total execution time: 0.0590
INFO - 2021-12-16 04:41:18 --> Config Class Initialized
INFO - 2021-12-16 04:41:18 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:18 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:18 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:18 --> URI Class Initialized
INFO - 2021-12-16 04:41:18 --> Router Class Initialized
INFO - 2021-12-16 04:41:18 --> Output Class Initialized
INFO - 2021-12-16 04:41:18 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:18 --> Input Class Initialized
INFO - 2021-12-16 04:41:18 --> Language Class Initialized
INFO - 2021-12-16 04:41:18 --> Language Class Initialized
INFO - 2021-12-16 04:41:18 --> Config Class Initialized
INFO - 2021-12-16 04:41:18 --> Loader Class Initialized
INFO - 2021-12-16 04:41:18 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:18 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:18 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:18 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:18 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:18 --> Controller Class Initialized
INFO - 2021-12-16 04:41:26 --> Config Class Initialized
INFO - 2021-12-16 04:41:26 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:26 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:26 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:26 --> URI Class Initialized
INFO - 2021-12-16 04:41:26 --> Router Class Initialized
INFO - 2021-12-16 04:41:26 --> Output Class Initialized
INFO - 2021-12-16 04:41:26 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:26 --> Input Class Initialized
INFO - 2021-12-16 04:41:26 --> Language Class Initialized
INFO - 2021-12-16 04:41:26 --> Language Class Initialized
INFO - 2021-12-16 04:41:26 --> Config Class Initialized
INFO - 2021-12-16 04:41:26 --> Loader Class Initialized
INFO - 2021-12-16 04:41:26 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:26 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:26 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:26 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:26 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:26 --> Controller Class Initialized
INFO - 2021-12-16 04:41:26 --> Helper loaded: cookie_helper
INFO - 2021-12-16 04:41:26 --> Config Class Initialized
INFO - 2021-12-16 04:41:26 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:26 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:26 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:26 --> URI Class Initialized
INFO - 2021-12-16 04:41:26 --> Router Class Initialized
INFO - 2021-12-16 04:41:26 --> Output Class Initialized
INFO - 2021-12-16 04:41:26 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:26 --> Input Class Initialized
INFO - 2021-12-16 04:41:26 --> Language Class Initialized
INFO - 2021-12-16 04:41:26 --> Language Class Initialized
INFO - 2021-12-16 04:41:26 --> Config Class Initialized
INFO - 2021-12-16 04:41:26 --> Loader Class Initialized
INFO - 2021-12-16 04:41:26 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:26 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:26 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:26 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:26 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:26 --> Controller Class Initialized
DEBUG - 2021-12-16 04:41:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-16 04:41:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:41:26 --> Final output sent to browser
DEBUG - 2021-12-16 04:41:26 --> Total execution time: 0.0350
INFO - 2021-12-16 04:41:41 --> Config Class Initialized
INFO - 2021-12-16 04:41:41 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:41 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:41 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:41 --> URI Class Initialized
INFO - 2021-12-16 04:41:41 --> Router Class Initialized
INFO - 2021-12-16 04:41:41 --> Output Class Initialized
INFO - 2021-12-16 04:41:41 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:41 --> Input Class Initialized
INFO - 2021-12-16 04:41:41 --> Language Class Initialized
INFO - 2021-12-16 04:41:41 --> Language Class Initialized
INFO - 2021-12-16 04:41:41 --> Config Class Initialized
INFO - 2021-12-16 04:41:41 --> Loader Class Initialized
INFO - 2021-12-16 04:41:41 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:41 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:41 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:41 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:41 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:41 --> Controller Class Initialized
INFO - 2021-12-16 04:41:41 --> Helper loaded: cookie_helper
INFO - 2021-12-16 04:41:41 --> Final output sent to browser
DEBUG - 2021-12-16 04:41:41 --> Total execution time: 0.0510
INFO - 2021-12-16 04:41:43 --> Config Class Initialized
INFO - 2021-12-16 04:41:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:43 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:43 --> URI Class Initialized
INFO - 2021-12-16 04:41:43 --> Router Class Initialized
INFO - 2021-12-16 04:41:43 --> Output Class Initialized
INFO - 2021-12-16 04:41:43 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:43 --> Input Class Initialized
INFO - 2021-12-16 04:41:43 --> Language Class Initialized
INFO - 2021-12-16 04:41:43 --> Language Class Initialized
INFO - 2021-12-16 04:41:43 --> Config Class Initialized
INFO - 2021-12-16 04:41:43 --> Loader Class Initialized
INFO - 2021-12-16 04:41:43 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:43 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:43 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:43 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:43 --> Controller Class Initialized
DEBUG - 2021-12-16 04:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-16 04:41:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:41:43 --> Final output sent to browser
DEBUG - 2021-12-16 04:41:43 --> Total execution time: 0.1610
INFO - 2021-12-16 04:41:47 --> Config Class Initialized
INFO - 2021-12-16 04:41:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:41:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:41:47 --> Utf8 Class Initialized
INFO - 2021-12-16 04:41:47 --> URI Class Initialized
INFO - 2021-12-16 04:41:47 --> Router Class Initialized
INFO - 2021-12-16 04:41:48 --> Output Class Initialized
INFO - 2021-12-16 04:41:48 --> Security Class Initialized
DEBUG - 2021-12-16 04:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:41:48 --> Input Class Initialized
INFO - 2021-12-16 04:41:48 --> Language Class Initialized
INFO - 2021-12-16 04:41:48 --> Language Class Initialized
INFO - 2021-12-16 04:41:48 --> Config Class Initialized
INFO - 2021-12-16 04:41:48 --> Loader Class Initialized
INFO - 2021-12-16 04:41:48 --> Helper loaded: url_helper
INFO - 2021-12-16 04:41:48 --> Helper loaded: file_helper
INFO - 2021-12-16 04:41:48 --> Helper loaded: form_helper
INFO - 2021-12-16 04:41:48 --> Helper loaded: my_helper
INFO - 2021-12-16 04:41:48 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:41:48 --> Controller Class Initialized
DEBUG - 2021-12-16 04:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-16 04:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:41:48 --> Final output sent to browser
DEBUG - 2021-12-16 04:41:48 --> Total execution time: 0.1100
INFO - 2021-12-16 04:48:38 --> Config Class Initialized
INFO - 2021-12-16 04:48:38 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:48:38 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:48:38 --> Utf8 Class Initialized
INFO - 2021-12-16 04:48:38 --> URI Class Initialized
INFO - 2021-12-16 04:48:38 --> Router Class Initialized
INFO - 2021-12-16 04:48:38 --> Output Class Initialized
INFO - 2021-12-16 04:48:38 --> Security Class Initialized
DEBUG - 2021-12-16 04:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:48:38 --> Input Class Initialized
INFO - 2021-12-16 04:48:38 --> Language Class Initialized
INFO - 2021-12-16 04:48:38 --> Language Class Initialized
INFO - 2021-12-16 04:48:38 --> Config Class Initialized
INFO - 2021-12-16 04:48:38 --> Loader Class Initialized
INFO - 2021-12-16 04:48:38 --> Helper loaded: url_helper
INFO - 2021-12-16 04:48:38 --> Helper loaded: file_helper
INFO - 2021-12-16 04:48:38 --> Helper loaded: form_helper
INFO - 2021-12-16 04:48:38 --> Helper loaded: my_helper
INFO - 2021-12-16 04:48:38 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:48:38 --> Controller Class Initialized
INFO - 2021-12-16 04:48:38 --> Final output sent to browser
DEBUG - 2021-12-16 04:48:38 --> Total execution time: 0.0660
INFO - 2021-12-16 04:52:40 --> Config Class Initialized
INFO - 2021-12-16 04:52:40 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:52:40 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:52:40 --> Utf8 Class Initialized
INFO - 2021-12-16 04:52:40 --> URI Class Initialized
INFO - 2021-12-16 04:52:40 --> Router Class Initialized
INFO - 2021-12-16 04:52:40 --> Output Class Initialized
INFO - 2021-12-16 04:52:40 --> Security Class Initialized
DEBUG - 2021-12-16 04:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:52:40 --> Input Class Initialized
INFO - 2021-12-16 04:52:40 --> Language Class Initialized
INFO - 2021-12-16 04:52:40 --> Language Class Initialized
INFO - 2021-12-16 04:52:40 --> Config Class Initialized
INFO - 2021-12-16 04:52:40 --> Loader Class Initialized
INFO - 2021-12-16 04:52:40 --> Helper loaded: url_helper
INFO - 2021-12-16 04:52:40 --> Helper loaded: file_helper
INFO - 2021-12-16 04:52:40 --> Helper loaded: form_helper
INFO - 2021-12-16 04:52:40 --> Helper loaded: my_helper
INFO - 2021-12-16 04:52:40 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:52:40 --> Controller Class Initialized
INFO - 2021-12-16 04:52:40 --> Final output sent to browser
DEBUG - 2021-12-16 04:52:40 --> Total execution time: 0.0830
INFO - 2021-12-16 04:52:45 --> Config Class Initialized
INFO - 2021-12-16 04:52:45 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:52:45 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:52:45 --> Utf8 Class Initialized
INFO - 2021-12-16 04:52:45 --> URI Class Initialized
INFO - 2021-12-16 04:52:45 --> Router Class Initialized
INFO - 2021-12-16 04:52:45 --> Output Class Initialized
INFO - 2021-12-16 04:52:45 --> Security Class Initialized
DEBUG - 2021-12-16 04:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:52:45 --> Input Class Initialized
INFO - 2021-12-16 04:52:45 --> Language Class Initialized
INFO - 2021-12-16 04:52:45 --> Language Class Initialized
INFO - 2021-12-16 04:52:45 --> Config Class Initialized
INFO - 2021-12-16 04:52:45 --> Loader Class Initialized
INFO - 2021-12-16 04:52:45 --> Helper loaded: url_helper
INFO - 2021-12-16 04:52:45 --> Helper loaded: file_helper
INFO - 2021-12-16 04:52:45 --> Helper loaded: form_helper
INFO - 2021-12-16 04:52:45 --> Helper loaded: my_helper
INFO - 2021-12-16 04:52:45 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:52:45 --> Controller Class Initialized
DEBUG - 2021-12-16 04:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-16 04:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:52:45 --> Final output sent to browser
DEBUG - 2021-12-16 04:52:45 --> Total execution time: 0.0620
INFO - 2021-12-16 04:55:56 --> Config Class Initialized
INFO - 2021-12-16 04:55:56 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:55:56 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:55:56 --> Utf8 Class Initialized
INFO - 2021-12-16 04:55:56 --> URI Class Initialized
INFO - 2021-12-16 04:55:56 --> Router Class Initialized
INFO - 2021-12-16 04:55:56 --> Output Class Initialized
INFO - 2021-12-16 04:55:56 --> Security Class Initialized
DEBUG - 2021-12-16 04:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:55:56 --> Input Class Initialized
INFO - 2021-12-16 04:55:56 --> Language Class Initialized
INFO - 2021-12-16 04:55:56 --> Language Class Initialized
INFO - 2021-12-16 04:55:56 --> Config Class Initialized
INFO - 2021-12-16 04:55:56 --> Loader Class Initialized
INFO - 2021-12-16 04:55:56 --> Helper loaded: url_helper
INFO - 2021-12-16 04:55:56 --> Helper loaded: file_helper
INFO - 2021-12-16 04:55:56 --> Helper loaded: form_helper
INFO - 2021-12-16 04:55:56 --> Helper loaded: my_helper
INFO - 2021-12-16 04:55:56 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:55:56 --> Controller Class Initialized
INFO - 2021-12-16 04:55:56 --> Final output sent to browser
DEBUG - 2021-12-16 04:55:56 --> Total execution time: 0.0710
INFO - 2021-12-16 04:56:03 --> Config Class Initialized
INFO - 2021-12-16 04:56:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:56:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:56:03 --> Utf8 Class Initialized
INFO - 2021-12-16 04:56:03 --> URI Class Initialized
INFO - 2021-12-16 04:56:03 --> Router Class Initialized
INFO - 2021-12-16 04:56:03 --> Output Class Initialized
INFO - 2021-12-16 04:56:03 --> Security Class Initialized
DEBUG - 2021-12-16 04:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:56:03 --> Input Class Initialized
INFO - 2021-12-16 04:56:03 --> Language Class Initialized
INFO - 2021-12-16 04:56:03 --> Language Class Initialized
INFO - 2021-12-16 04:56:03 --> Config Class Initialized
INFO - 2021-12-16 04:56:03 --> Loader Class Initialized
INFO - 2021-12-16 04:56:03 --> Helper loaded: url_helper
INFO - 2021-12-16 04:56:03 --> Helper loaded: file_helper
INFO - 2021-12-16 04:56:03 --> Helper loaded: form_helper
INFO - 2021-12-16 04:56:03 --> Helper loaded: my_helper
INFO - 2021-12-16 04:56:03 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:56:03 --> Controller Class Initialized
DEBUG - 2021-12-16 04:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-16 04:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:56:03 --> Final output sent to browser
DEBUG - 2021-12-16 04:56:03 --> Total execution time: 0.0510
INFO - 2021-12-16 04:56:06 --> Config Class Initialized
INFO - 2021-12-16 04:56:06 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:56:06 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:56:06 --> Utf8 Class Initialized
INFO - 2021-12-16 04:56:06 --> URI Class Initialized
INFO - 2021-12-16 04:56:06 --> Router Class Initialized
INFO - 2021-12-16 04:56:06 --> Output Class Initialized
INFO - 2021-12-16 04:56:06 --> Security Class Initialized
DEBUG - 2021-12-16 04:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:56:06 --> Input Class Initialized
INFO - 2021-12-16 04:56:06 --> Language Class Initialized
INFO - 2021-12-16 04:56:06 --> Language Class Initialized
INFO - 2021-12-16 04:56:06 --> Config Class Initialized
INFO - 2021-12-16 04:56:06 --> Loader Class Initialized
INFO - 2021-12-16 04:56:06 --> Helper loaded: url_helper
INFO - 2021-12-16 04:56:06 --> Helper loaded: file_helper
INFO - 2021-12-16 04:56:06 --> Helper loaded: form_helper
INFO - 2021-12-16 04:56:06 --> Helper loaded: my_helper
INFO - 2021-12-16 04:56:06 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:56:06 --> Controller Class Initialized
INFO - 2021-12-16 04:56:06 --> Final output sent to browser
DEBUG - 2021-12-16 04:56:06 --> Total execution time: 0.0530
INFO - 2021-12-16 04:57:32 --> Config Class Initialized
INFO - 2021-12-16 04:57:32 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:57:32 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:57:32 --> Utf8 Class Initialized
INFO - 2021-12-16 04:57:32 --> URI Class Initialized
INFO - 2021-12-16 04:57:32 --> Router Class Initialized
INFO - 2021-12-16 04:57:32 --> Output Class Initialized
INFO - 2021-12-16 04:57:32 --> Security Class Initialized
DEBUG - 2021-12-16 04:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:57:32 --> Input Class Initialized
INFO - 2021-12-16 04:57:32 --> Language Class Initialized
INFO - 2021-12-16 04:57:32 --> Language Class Initialized
INFO - 2021-12-16 04:57:32 --> Config Class Initialized
INFO - 2021-12-16 04:57:32 --> Loader Class Initialized
INFO - 2021-12-16 04:57:32 --> Helper loaded: url_helper
INFO - 2021-12-16 04:57:32 --> Helper loaded: file_helper
INFO - 2021-12-16 04:57:32 --> Helper loaded: form_helper
INFO - 2021-12-16 04:57:32 --> Helper loaded: my_helper
INFO - 2021-12-16 04:57:32 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:57:32 --> Controller Class Initialized
INFO - 2021-12-16 04:57:32 --> Final output sent to browser
DEBUG - 2021-12-16 04:57:32 --> Total execution time: 0.0790
INFO - 2021-12-16 04:57:39 --> Config Class Initialized
INFO - 2021-12-16 04:57:39 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:57:39 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:57:39 --> Utf8 Class Initialized
INFO - 2021-12-16 04:57:39 --> URI Class Initialized
INFO - 2021-12-16 04:57:39 --> Router Class Initialized
INFO - 2021-12-16 04:57:39 --> Output Class Initialized
INFO - 2021-12-16 04:57:39 --> Security Class Initialized
DEBUG - 2021-12-16 04:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:57:39 --> Input Class Initialized
INFO - 2021-12-16 04:57:39 --> Language Class Initialized
INFO - 2021-12-16 04:57:39 --> Language Class Initialized
INFO - 2021-12-16 04:57:39 --> Config Class Initialized
INFO - 2021-12-16 04:57:39 --> Loader Class Initialized
INFO - 2021-12-16 04:57:39 --> Helper loaded: url_helper
INFO - 2021-12-16 04:57:39 --> Helper loaded: file_helper
INFO - 2021-12-16 04:57:39 --> Helper loaded: form_helper
INFO - 2021-12-16 04:57:39 --> Helper loaded: my_helper
INFO - 2021-12-16 04:57:39 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:57:39 --> Controller Class Initialized
DEBUG - 2021-12-16 04:57:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-16 04:57:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:57:39 --> Final output sent to browser
DEBUG - 2021-12-16 04:57:39 --> Total execution time: 0.0680
INFO - 2021-12-16 04:59:21 --> Config Class Initialized
INFO - 2021-12-16 04:59:21 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:59:21 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:59:21 --> Utf8 Class Initialized
INFO - 2021-12-16 04:59:21 --> URI Class Initialized
INFO - 2021-12-16 04:59:21 --> Router Class Initialized
INFO - 2021-12-16 04:59:21 --> Output Class Initialized
INFO - 2021-12-16 04:59:21 --> Security Class Initialized
DEBUG - 2021-12-16 04:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:59:21 --> Input Class Initialized
INFO - 2021-12-16 04:59:21 --> Language Class Initialized
INFO - 2021-12-16 04:59:21 --> Language Class Initialized
INFO - 2021-12-16 04:59:21 --> Config Class Initialized
INFO - 2021-12-16 04:59:21 --> Loader Class Initialized
INFO - 2021-12-16 04:59:21 --> Helper loaded: url_helper
INFO - 2021-12-16 04:59:21 --> Helper loaded: file_helper
INFO - 2021-12-16 04:59:21 --> Helper loaded: form_helper
INFO - 2021-12-16 04:59:21 --> Helper loaded: my_helper
INFO - 2021-12-16 04:59:21 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:59:21 --> Controller Class Initialized
INFO - 2021-12-16 04:59:21 --> Final output sent to browser
DEBUG - 2021-12-16 04:59:21 --> Total execution time: 0.0740
INFO - 2021-12-16 04:59:35 --> Config Class Initialized
INFO - 2021-12-16 04:59:35 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:59:35 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:59:35 --> Utf8 Class Initialized
INFO - 2021-12-16 04:59:35 --> URI Class Initialized
INFO - 2021-12-16 04:59:35 --> Router Class Initialized
INFO - 2021-12-16 04:59:35 --> Output Class Initialized
INFO - 2021-12-16 04:59:35 --> Security Class Initialized
DEBUG - 2021-12-16 04:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:59:35 --> Input Class Initialized
INFO - 2021-12-16 04:59:35 --> Language Class Initialized
INFO - 2021-12-16 04:59:35 --> Language Class Initialized
INFO - 2021-12-16 04:59:35 --> Config Class Initialized
INFO - 2021-12-16 04:59:35 --> Loader Class Initialized
INFO - 2021-12-16 04:59:35 --> Helper loaded: url_helper
INFO - 2021-12-16 04:59:35 --> Helper loaded: file_helper
INFO - 2021-12-16 04:59:35 --> Helper loaded: form_helper
INFO - 2021-12-16 04:59:35 --> Helper loaded: my_helper
INFO - 2021-12-16 04:59:35 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:59:35 --> Controller Class Initialized
INFO - 2021-12-16 04:59:35 --> Final output sent to browser
DEBUG - 2021-12-16 04:59:35 --> Total execution time: 0.0720
INFO - 2021-12-16 04:59:45 --> Config Class Initialized
INFO - 2021-12-16 04:59:45 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:59:45 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:59:45 --> Utf8 Class Initialized
INFO - 2021-12-16 04:59:45 --> URI Class Initialized
INFO - 2021-12-16 04:59:45 --> Router Class Initialized
INFO - 2021-12-16 04:59:45 --> Output Class Initialized
INFO - 2021-12-16 04:59:45 --> Security Class Initialized
DEBUG - 2021-12-16 04:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:59:45 --> Input Class Initialized
INFO - 2021-12-16 04:59:45 --> Language Class Initialized
INFO - 2021-12-16 04:59:45 --> Language Class Initialized
INFO - 2021-12-16 04:59:45 --> Config Class Initialized
INFO - 2021-12-16 04:59:45 --> Loader Class Initialized
INFO - 2021-12-16 04:59:45 --> Helper loaded: url_helper
INFO - 2021-12-16 04:59:45 --> Helper loaded: file_helper
INFO - 2021-12-16 04:59:45 --> Helper loaded: form_helper
INFO - 2021-12-16 04:59:45 --> Helper loaded: my_helper
INFO - 2021-12-16 04:59:45 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:59:45 --> Controller Class Initialized
INFO - 2021-12-16 04:59:45 --> Helper loaded: cookie_helper
INFO - 2021-12-16 04:59:45 --> Config Class Initialized
INFO - 2021-12-16 04:59:45 --> Hooks Class Initialized
DEBUG - 2021-12-16 04:59:45 --> UTF-8 Support Enabled
INFO - 2021-12-16 04:59:45 --> Utf8 Class Initialized
INFO - 2021-12-16 04:59:45 --> URI Class Initialized
INFO - 2021-12-16 04:59:45 --> Router Class Initialized
INFO - 2021-12-16 04:59:45 --> Output Class Initialized
INFO - 2021-12-16 04:59:45 --> Security Class Initialized
DEBUG - 2021-12-16 04:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 04:59:45 --> Input Class Initialized
INFO - 2021-12-16 04:59:45 --> Language Class Initialized
INFO - 2021-12-16 04:59:45 --> Language Class Initialized
INFO - 2021-12-16 04:59:45 --> Config Class Initialized
INFO - 2021-12-16 04:59:45 --> Loader Class Initialized
INFO - 2021-12-16 04:59:45 --> Helper loaded: url_helper
INFO - 2021-12-16 04:59:45 --> Helper loaded: file_helper
INFO - 2021-12-16 04:59:45 --> Helper loaded: form_helper
INFO - 2021-12-16 04:59:45 --> Helper loaded: my_helper
INFO - 2021-12-16 04:59:45 --> Database Driver Class Initialized
DEBUG - 2021-12-16 04:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 04:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 04:59:45 --> Controller Class Initialized
DEBUG - 2021-12-16 04:59:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-16 04:59:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 04:59:45 --> Final output sent to browser
DEBUG - 2021-12-16 04:59:45 --> Total execution time: 0.0390
INFO - 2021-12-16 05:00:07 --> Config Class Initialized
INFO - 2021-12-16 05:00:07 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:07 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:07 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:07 --> URI Class Initialized
INFO - 2021-12-16 05:00:07 --> Router Class Initialized
INFO - 2021-12-16 05:00:07 --> Output Class Initialized
INFO - 2021-12-16 05:00:07 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:07 --> Input Class Initialized
INFO - 2021-12-16 05:00:07 --> Language Class Initialized
INFO - 2021-12-16 05:00:07 --> Language Class Initialized
INFO - 2021-12-16 05:00:07 --> Config Class Initialized
INFO - 2021-12-16 05:00:07 --> Loader Class Initialized
INFO - 2021-12-16 05:00:07 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:07 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:07 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:07 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:07 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:07 --> Controller Class Initialized
INFO - 2021-12-16 05:00:07 --> Helper loaded: cookie_helper
INFO - 2021-12-16 05:00:07 --> Final output sent to browser
DEBUG - 2021-12-16 05:00:07 --> Total execution time: 0.0480
INFO - 2021-12-16 05:00:10 --> Config Class Initialized
INFO - 2021-12-16 05:00:10 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:10 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:10 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:10 --> URI Class Initialized
INFO - 2021-12-16 05:00:10 --> Router Class Initialized
INFO - 2021-12-16 05:00:10 --> Output Class Initialized
INFO - 2021-12-16 05:00:10 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:10 --> Input Class Initialized
INFO - 2021-12-16 05:00:10 --> Language Class Initialized
INFO - 2021-12-16 05:00:10 --> Language Class Initialized
INFO - 2021-12-16 05:00:10 --> Config Class Initialized
INFO - 2021-12-16 05:00:10 --> Loader Class Initialized
INFO - 2021-12-16 05:00:10 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:10 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:10 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:10 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:10 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:10 --> Controller Class Initialized
DEBUG - 2021-12-16 05:00:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-16 05:00:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 05:00:10 --> Final output sent to browser
DEBUG - 2021-12-16 05:00:10 --> Total execution time: 0.2780
INFO - 2021-12-16 05:00:13 --> Config Class Initialized
INFO - 2021-12-16 05:00:13 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:13 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:13 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:13 --> URI Class Initialized
INFO - 2021-12-16 05:00:13 --> Router Class Initialized
INFO - 2021-12-16 05:00:13 --> Output Class Initialized
INFO - 2021-12-16 05:00:13 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:13 --> Input Class Initialized
INFO - 2021-12-16 05:00:13 --> Language Class Initialized
INFO - 2021-12-16 05:00:13 --> Language Class Initialized
INFO - 2021-12-16 05:00:13 --> Config Class Initialized
INFO - 2021-12-16 05:00:13 --> Loader Class Initialized
INFO - 2021-12-16 05:00:13 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:13 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:13 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:13 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:13 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:13 --> Controller Class Initialized
DEBUG - 2021-12-16 05:00:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-16 05:00:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 05:00:13 --> Final output sent to browser
DEBUG - 2021-12-16 05:00:13 --> Total execution time: 0.0600
INFO - 2021-12-16 05:00:13 --> Config Class Initialized
INFO - 2021-12-16 05:00:13 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:13 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:13 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:13 --> URI Class Initialized
INFO - 2021-12-16 05:00:13 --> Router Class Initialized
INFO - 2021-12-16 05:00:13 --> Output Class Initialized
INFO - 2021-12-16 05:00:13 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:13 --> Input Class Initialized
INFO - 2021-12-16 05:00:13 --> Language Class Initialized
INFO - 2021-12-16 05:00:13 --> Language Class Initialized
INFO - 2021-12-16 05:00:13 --> Config Class Initialized
INFO - 2021-12-16 05:00:13 --> Loader Class Initialized
INFO - 2021-12-16 05:00:13 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:13 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:13 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:13 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:13 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:13 --> Controller Class Initialized
INFO - 2021-12-16 05:00:18 --> Config Class Initialized
INFO - 2021-12-16 05:00:18 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:18 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:18 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:18 --> URI Class Initialized
INFO - 2021-12-16 05:00:18 --> Router Class Initialized
INFO - 2021-12-16 05:00:18 --> Output Class Initialized
INFO - 2021-12-16 05:00:18 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:18 --> Input Class Initialized
INFO - 2021-12-16 05:00:18 --> Language Class Initialized
INFO - 2021-12-16 05:00:18 --> Language Class Initialized
INFO - 2021-12-16 05:00:18 --> Config Class Initialized
INFO - 2021-12-16 05:00:18 --> Loader Class Initialized
INFO - 2021-12-16 05:00:18 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:18 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:19 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:19 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:19 --> Controller Class Initialized
INFO - 2021-12-16 05:00:19 --> Final output sent to browser
DEBUG - 2021-12-16 05:00:19 --> Total execution time: 0.0690
INFO - 2021-12-16 05:00:19 --> Config Class Initialized
INFO - 2021-12-16 05:00:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:19 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:19 --> URI Class Initialized
INFO - 2021-12-16 05:00:19 --> Router Class Initialized
INFO - 2021-12-16 05:00:19 --> Output Class Initialized
INFO - 2021-12-16 05:00:19 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:19 --> Input Class Initialized
INFO - 2021-12-16 05:00:19 --> Language Class Initialized
INFO - 2021-12-16 05:00:19 --> Language Class Initialized
INFO - 2021-12-16 05:00:19 --> Config Class Initialized
INFO - 2021-12-16 05:00:19 --> Loader Class Initialized
INFO - 2021-12-16 05:00:19 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:19 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:19 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:19 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:19 --> Controller Class Initialized
INFO - 2021-12-16 05:00:27 --> Config Class Initialized
INFO - 2021-12-16 05:00:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:27 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:27 --> URI Class Initialized
INFO - 2021-12-16 05:00:27 --> Router Class Initialized
INFO - 2021-12-16 05:00:27 --> Output Class Initialized
INFO - 2021-12-16 05:00:27 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:27 --> Input Class Initialized
INFO - 2021-12-16 05:00:27 --> Language Class Initialized
INFO - 2021-12-16 05:00:27 --> Language Class Initialized
INFO - 2021-12-16 05:00:27 --> Config Class Initialized
INFO - 2021-12-16 05:00:27 --> Loader Class Initialized
INFO - 2021-12-16 05:00:27 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:27 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:27 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:27 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:27 --> Controller Class Initialized
INFO - 2021-12-16 05:00:27 --> Helper loaded: cookie_helper
INFO - 2021-12-16 05:00:27 --> Config Class Initialized
INFO - 2021-12-16 05:00:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:27 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:27 --> URI Class Initialized
INFO - 2021-12-16 05:00:27 --> Router Class Initialized
INFO - 2021-12-16 05:00:27 --> Output Class Initialized
INFO - 2021-12-16 05:00:27 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:27 --> Input Class Initialized
INFO - 2021-12-16 05:00:27 --> Language Class Initialized
INFO - 2021-12-16 05:00:27 --> Language Class Initialized
INFO - 2021-12-16 05:00:27 --> Config Class Initialized
INFO - 2021-12-16 05:00:27 --> Loader Class Initialized
INFO - 2021-12-16 05:00:27 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:27 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:27 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:27 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:27 --> Controller Class Initialized
DEBUG - 2021-12-16 05:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-16 05:00:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 05:00:27 --> Final output sent to browser
DEBUG - 2021-12-16 05:00:27 --> Total execution time: 0.0410
INFO - 2021-12-16 05:00:39 --> Config Class Initialized
INFO - 2021-12-16 05:00:39 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:39 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:39 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:39 --> URI Class Initialized
INFO - 2021-12-16 05:00:39 --> Router Class Initialized
INFO - 2021-12-16 05:00:39 --> Output Class Initialized
INFO - 2021-12-16 05:00:39 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:39 --> Input Class Initialized
INFO - 2021-12-16 05:00:39 --> Language Class Initialized
INFO - 2021-12-16 05:00:39 --> Language Class Initialized
INFO - 2021-12-16 05:00:39 --> Config Class Initialized
INFO - 2021-12-16 05:00:39 --> Loader Class Initialized
INFO - 2021-12-16 05:00:39 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:39 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:39 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:39 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:39 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:39 --> Controller Class Initialized
INFO - 2021-12-16 05:00:39 --> Helper loaded: cookie_helper
INFO - 2021-12-16 05:00:39 --> Final output sent to browser
DEBUG - 2021-12-16 05:00:39 --> Total execution time: 0.0480
INFO - 2021-12-16 05:00:42 --> Config Class Initialized
INFO - 2021-12-16 05:00:42 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:42 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:42 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:42 --> URI Class Initialized
INFO - 2021-12-16 05:00:42 --> Router Class Initialized
INFO - 2021-12-16 05:00:42 --> Output Class Initialized
INFO - 2021-12-16 05:00:42 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:42 --> Input Class Initialized
INFO - 2021-12-16 05:00:42 --> Language Class Initialized
INFO - 2021-12-16 05:00:42 --> Language Class Initialized
INFO - 2021-12-16 05:00:42 --> Config Class Initialized
INFO - 2021-12-16 05:00:42 --> Loader Class Initialized
INFO - 2021-12-16 05:00:42 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:42 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:42 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:42 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:42 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:42 --> Controller Class Initialized
DEBUG - 2021-12-16 05:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-16 05:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 05:00:42 --> Final output sent to browser
DEBUG - 2021-12-16 05:00:42 --> Total execution time: 0.1410
INFO - 2021-12-16 05:00:50 --> Config Class Initialized
INFO - 2021-12-16 05:00:50 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:00:50 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:00:50 --> Utf8 Class Initialized
INFO - 2021-12-16 05:00:50 --> URI Class Initialized
INFO - 2021-12-16 05:00:50 --> Router Class Initialized
INFO - 2021-12-16 05:00:50 --> Output Class Initialized
INFO - 2021-12-16 05:00:50 --> Security Class Initialized
DEBUG - 2021-12-16 05:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:00:50 --> Input Class Initialized
INFO - 2021-12-16 05:00:50 --> Language Class Initialized
INFO - 2021-12-16 05:00:50 --> Language Class Initialized
INFO - 2021-12-16 05:00:50 --> Config Class Initialized
INFO - 2021-12-16 05:00:50 --> Loader Class Initialized
INFO - 2021-12-16 05:00:50 --> Helper loaded: url_helper
INFO - 2021-12-16 05:00:50 --> Helper loaded: file_helper
INFO - 2021-12-16 05:00:50 --> Helper loaded: form_helper
INFO - 2021-12-16 05:00:50 --> Helper loaded: my_helper
INFO - 2021-12-16 05:00:50 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:00:50 --> Controller Class Initialized
DEBUG - 2021-12-16 05:00:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-16 05:00:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 05:00:50 --> Final output sent to browser
DEBUG - 2021-12-16 05:00:50 --> Total execution time: 0.1240
INFO - 2021-12-16 05:07:39 --> Config Class Initialized
INFO - 2021-12-16 05:07:39 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:07:39 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:07:39 --> Utf8 Class Initialized
INFO - 2021-12-16 05:07:39 --> URI Class Initialized
INFO - 2021-12-16 05:07:39 --> Router Class Initialized
INFO - 2021-12-16 05:07:39 --> Output Class Initialized
INFO - 2021-12-16 05:07:39 --> Security Class Initialized
DEBUG - 2021-12-16 05:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:07:39 --> Input Class Initialized
INFO - 2021-12-16 05:07:39 --> Language Class Initialized
INFO - 2021-12-16 05:07:39 --> Language Class Initialized
INFO - 2021-12-16 05:07:39 --> Config Class Initialized
INFO - 2021-12-16 05:07:39 --> Loader Class Initialized
INFO - 2021-12-16 05:07:39 --> Helper loaded: url_helper
INFO - 2021-12-16 05:07:39 --> Helper loaded: file_helper
INFO - 2021-12-16 05:07:39 --> Helper loaded: form_helper
INFO - 2021-12-16 05:07:39 --> Helper loaded: my_helper
INFO - 2021-12-16 05:07:39 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:07:39 --> Controller Class Initialized
INFO - 2021-12-16 05:07:40 --> Final output sent to browser
DEBUG - 2021-12-16 05:07:40 --> Total execution time: 0.1380
INFO - 2021-12-16 05:12:20 --> Config Class Initialized
INFO - 2021-12-16 05:12:20 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:12:20 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:12:20 --> Utf8 Class Initialized
INFO - 2021-12-16 05:12:20 --> URI Class Initialized
INFO - 2021-12-16 05:12:20 --> Router Class Initialized
INFO - 2021-12-16 05:12:20 --> Output Class Initialized
INFO - 2021-12-16 05:12:20 --> Security Class Initialized
DEBUG - 2021-12-16 05:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:12:20 --> Input Class Initialized
INFO - 2021-12-16 05:12:20 --> Language Class Initialized
INFO - 2021-12-16 05:12:20 --> Language Class Initialized
INFO - 2021-12-16 05:12:20 --> Config Class Initialized
INFO - 2021-12-16 05:12:20 --> Loader Class Initialized
INFO - 2021-12-16 05:12:20 --> Helper loaded: url_helper
INFO - 2021-12-16 05:12:20 --> Helper loaded: file_helper
INFO - 2021-12-16 05:12:20 --> Helper loaded: form_helper
INFO - 2021-12-16 05:12:20 --> Helper loaded: my_helper
INFO - 2021-12-16 05:12:20 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:12:20 --> Controller Class Initialized
INFO - 2021-12-16 05:12:20 --> Final output sent to browser
DEBUG - 2021-12-16 05:12:20 --> Total execution time: 0.1430
INFO - 2021-12-16 05:12:27 --> Config Class Initialized
INFO - 2021-12-16 05:12:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:12:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:12:27 --> Utf8 Class Initialized
INFO - 2021-12-16 05:12:27 --> URI Class Initialized
INFO - 2021-12-16 05:12:27 --> Router Class Initialized
INFO - 2021-12-16 05:12:27 --> Output Class Initialized
INFO - 2021-12-16 05:12:27 --> Security Class Initialized
DEBUG - 2021-12-16 05:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:12:27 --> Input Class Initialized
INFO - 2021-12-16 05:12:27 --> Language Class Initialized
INFO - 2021-12-16 05:12:27 --> Language Class Initialized
INFO - 2021-12-16 05:12:27 --> Config Class Initialized
INFO - 2021-12-16 05:12:27 --> Loader Class Initialized
INFO - 2021-12-16 05:12:27 --> Helper loaded: url_helper
INFO - 2021-12-16 05:12:27 --> Helper loaded: file_helper
INFO - 2021-12-16 05:12:27 --> Helper loaded: form_helper
INFO - 2021-12-16 05:12:27 --> Helper loaded: my_helper
INFO - 2021-12-16 05:12:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:12:27 --> Controller Class Initialized
DEBUG - 2021-12-16 05:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-16 05:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 05:12:27 --> Final output sent to browser
DEBUG - 2021-12-16 05:12:27 --> Total execution time: 0.0550
INFO - 2021-12-16 05:16:48 --> Config Class Initialized
INFO - 2021-12-16 05:16:48 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:16:48 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:16:48 --> Utf8 Class Initialized
INFO - 2021-12-16 05:16:48 --> URI Class Initialized
INFO - 2021-12-16 05:16:48 --> Router Class Initialized
INFO - 2021-12-16 05:16:48 --> Output Class Initialized
INFO - 2021-12-16 05:16:48 --> Security Class Initialized
DEBUG - 2021-12-16 05:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:16:48 --> Input Class Initialized
INFO - 2021-12-16 05:16:48 --> Language Class Initialized
INFO - 2021-12-16 05:16:48 --> Language Class Initialized
INFO - 2021-12-16 05:16:48 --> Config Class Initialized
INFO - 2021-12-16 05:16:48 --> Loader Class Initialized
INFO - 2021-12-16 05:16:48 --> Helper loaded: url_helper
INFO - 2021-12-16 05:16:48 --> Helper loaded: file_helper
INFO - 2021-12-16 05:16:48 --> Helper loaded: form_helper
INFO - 2021-12-16 05:16:48 --> Helper loaded: my_helper
INFO - 2021-12-16 05:16:48 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:16:48 --> Controller Class Initialized
INFO - 2021-12-16 05:16:48 --> Final output sent to browser
DEBUG - 2021-12-16 05:16:48 --> Total execution time: 0.0830
INFO - 2021-12-16 05:16:54 --> Config Class Initialized
INFO - 2021-12-16 05:16:54 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:16:54 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:16:54 --> Utf8 Class Initialized
INFO - 2021-12-16 05:16:54 --> URI Class Initialized
INFO - 2021-12-16 05:16:54 --> Router Class Initialized
INFO - 2021-12-16 05:16:54 --> Output Class Initialized
INFO - 2021-12-16 05:16:54 --> Security Class Initialized
DEBUG - 2021-12-16 05:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:16:54 --> Input Class Initialized
INFO - 2021-12-16 05:16:54 --> Language Class Initialized
INFO - 2021-12-16 05:16:54 --> Language Class Initialized
INFO - 2021-12-16 05:16:54 --> Config Class Initialized
INFO - 2021-12-16 05:16:54 --> Loader Class Initialized
INFO - 2021-12-16 05:16:54 --> Helper loaded: url_helper
INFO - 2021-12-16 05:16:54 --> Helper loaded: file_helper
INFO - 2021-12-16 05:16:54 --> Helper loaded: form_helper
INFO - 2021-12-16 05:16:54 --> Helper loaded: my_helper
INFO - 2021-12-16 05:16:54 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:16:54 --> Controller Class Initialized
DEBUG - 2021-12-16 05:16:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-16 05:16:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 05:16:54 --> Final output sent to browser
DEBUG - 2021-12-16 05:16:54 --> Total execution time: 0.0460
INFO - 2021-12-16 05:16:55 --> Config Class Initialized
INFO - 2021-12-16 05:16:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:16:56 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:16:56 --> Utf8 Class Initialized
INFO - 2021-12-16 05:16:56 --> URI Class Initialized
INFO - 2021-12-16 05:16:56 --> Router Class Initialized
INFO - 2021-12-16 05:16:56 --> Output Class Initialized
INFO - 2021-12-16 05:16:56 --> Security Class Initialized
DEBUG - 2021-12-16 05:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:16:56 --> Input Class Initialized
INFO - 2021-12-16 05:16:56 --> Language Class Initialized
INFO - 2021-12-16 05:16:56 --> Language Class Initialized
INFO - 2021-12-16 05:16:56 --> Config Class Initialized
INFO - 2021-12-16 05:16:56 --> Loader Class Initialized
INFO - 2021-12-16 05:16:56 --> Helper loaded: url_helper
INFO - 2021-12-16 05:16:56 --> Helper loaded: file_helper
INFO - 2021-12-16 05:16:56 --> Helper loaded: form_helper
INFO - 2021-12-16 05:16:56 --> Helper loaded: my_helper
INFO - 2021-12-16 05:16:56 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:16:56 --> Controller Class Initialized
INFO - 2021-12-16 05:16:56 --> Final output sent to browser
DEBUG - 2021-12-16 05:16:56 --> Total execution time: 0.0530
INFO - 2021-12-16 05:18:02 --> Config Class Initialized
INFO - 2021-12-16 05:18:02 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:18:02 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:18:02 --> Utf8 Class Initialized
INFO - 2021-12-16 05:18:02 --> URI Class Initialized
INFO - 2021-12-16 05:18:02 --> Router Class Initialized
INFO - 2021-12-16 05:18:02 --> Output Class Initialized
INFO - 2021-12-16 05:18:02 --> Security Class Initialized
DEBUG - 2021-12-16 05:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:18:02 --> Input Class Initialized
INFO - 2021-12-16 05:18:02 --> Language Class Initialized
INFO - 2021-12-16 05:18:02 --> Language Class Initialized
INFO - 2021-12-16 05:18:02 --> Config Class Initialized
INFO - 2021-12-16 05:18:02 --> Loader Class Initialized
INFO - 2021-12-16 05:18:02 --> Helper loaded: url_helper
INFO - 2021-12-16 05:18:02 --> Helper loaded: file_helper
INFO - 2021-12-16 05:18:02 --> Helper loaded: form_helper
INFO - 2021-12-16 05:18:02 --> Helper loaded: my_helper
INFO - 2021-12-16 05:18:02 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:18:02 --> Controller Class Initialized
INFO - 2021-12-16 05:18:02 --> Final output sent to browser
DEBUG - 2021-12-16 05:18:02 --> Total execution time: 0.0990
INFO - 2021-12-16 05:18:06 --> Config Class Initialized
INFO - 2021-12-16 05:18:06 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:18:06 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:18:06 --> Utf8 Class Initialized
INFO - 2021-12-16 05:18:06 --> URI Class Initialized
INFO - 2021-12-16 05:18:06 --> Router Class Initialized
INFO - 2021-12-16 05:18:06 --> Output Class Initialized
INFO - 2021-12-16 05:18:06 --> Security Class Initialized
DEBUG - 2021-12-16 05:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:18:06 --> Input Class Initialized
INFO - 2021-12-16 05:18:06 --> Language Class Initialized
INFO - 2021-12-16 05:18:06 --> Language Class Initialized
INFO - 2021-12-16 05:18:06 --> Config Class Initialized
INFO - 2021-12-16 05:18:06 --> Loader Class Initialized
INFO - 2021-12-16 05:18:06 --> Helper loaded: url_helper
INFO - 2021-12-16 05:18:06 --> Helper loaded: file_helper
INFO - 2021-12-16 05:18:06 --> Helper loaded: form_helper
INFO - 2021-12-16 05:18:06 --> Helper loaded: my_helper
INFO - 2021-12-16 05:18:06 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:18:06 --> Controller Class Initialized
DEBUG - 2021-12-16 05:18:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-16 05:18:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 05:18:06 --> Final output sent to browser
DEBUG - 2021-12-16 05:18:06 --> Total execution time: 0.0760
INFO - 2021-12-16 05:19:36 --> Config Class Initialized
INFO - 2021-12-16 05:19:36 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:19:36 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:19:36 --> Utf8 Class Initialized
INFO - 2021-12-16 05:19:36 --> URI Class Initialized
INFO - 2021-12-16 05:19:36 --> Router Class Initialized
INFO - 2021-12-16 05:19:36 --> Output Class Initialized
INFO - 2021-12-16 05:19:36 --> Security Class Initialized
DEBUG - 2021-12-16 05:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:19:36 --> Input Class Initialized
INFO - 2021-12-16 05:19:36 --> Language Class Initialized
INFO - 2021-12-16 05:19:36 --> Language Class Initialized
INFO - 2021-12-16 05:19:36 --> Config Class Initialized
INFO - 2021-12-16 05:19:36 --> Loader Class Initialized
INFO - 2021-12-16 05:19:36 --> Helper loaded: url_helper
INFO - 2021-12-16 05:19:36 --> Helper loaded: file_helper
INFO - 2021-12-16 05:19:36 --> Helper loaded: form_helper
INFO - 2021-12-16 05:19:36 --> Helper loaded: my_helper
INFO - 2021-12-16 05:19:36 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:19:36 --> Controller Class Initialized
INFO - 2021-12-16 05:19:36 --> Final output sent to browser
DEBUG - 2021-12-16 05:19:36 --> Total execution time: 0.0880
INFO - 2021-12-16 05:19:46 --> Config Class Initialized
INFO - 2021-12-16 05:19:46 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:19:46 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:19:46 --> Utf8 Class Initialized
INFO - 2021-12-16 05:19:46 --> URI Class Initialized
INFO - 2021-12-16 05:19:46 --> Router Class Initialized
INFO - 2021-12-16 05:19:46 --> Output Class Initialized
INFO - 2021-12-16 05:19:46 --> Security Class Initialized
DEBUG - 2021-12-16 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:19:46 --> Input Class Initialized
INFO - 2021-12-16 05:19:46 --> Language Class Initialized
INFO - 2021-12-16 05:19:46 --> Language Class Initialized
INFO - 2021-12-16 05:19:46 --> Config Class Initialized
INFO - 2021-12-16 05:19:46 --> Loader Class Initialized
INFO - 2021-12-16 05:19:46 --> Helper loaded: url_helper
INFO - 2021-12-16 05:19:46 --> Helper loaded: file_helper
INFO - 2021-12-16 05:19:46 --> Helper loaded: form_helper
INFO - 2021-12-16 05:19:46 --> Helper loaded: my_helper
INFO - 2021-12-16 05:19:46 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:19:46 --> Controller Class Initialized
INFO - 2021-12-16 05:19:46 --> Helper loaded: cookie_helper
INFO - 2021-12-16 05:19:46 --> Config Class Initialized
INFO - 2021-12-16 05:19:46 --> Hooks Class Initialized
DEBUG - 2021-12-16 05:19:46 --> UTF-8 Support Enabled
INFO - 2021-12-16 05:19:46 --> Utf8 Class Initialized
INFO - 2021-12-16 05:19:46 --> URI Class Initialized
INFO - 2021-12-16 05:19:46 --> Router Class Initialized
INFO - 2021-12-16 05:19:46 --> Output Class Initialized
INFO - 2021-12-16 05:19:46 --> Security Class Initialized
DEBUG - 2021-12-16 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 05:19:46 --> Input Class Initialized
INFO - 2021-12-16 05:19:46 --> Language Class Initialized
INFO - 2021-12-16 05:19:46 --> Language Class Initialized
INFO - 2021-12-16 05:19:46 --> Config Class Initialized
INFO - 2021-12-16 05:19:46 --> Loader Class Initialized
INFO - 2021-12-16 05:19:46 --> Helper loaded: url_helper
INFO - 2021-12-16 05:19:46 --> Helper loaded: file_helper
INFO - 2021-12-16 05:19:46 --> Helper loaded: form_helper
INFO - 2021-12-16 05:19:46 --> Helper loaded: my_helper
INFO - 2021-12-16 05:19:46 --> Database Driver Class Initialized
DEBUG - 2021-12-16 05:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 05:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 05:19:46 --> Controller Class Initialized
DEBUG - 2021-12-16 05:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-16 05:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 05:19:46 --> Final output sent to browser
DEBUG - 2021-12-16 05:19:46 --> Total execution time: 0.0350
INFO - 2021-12-16 07:34:52 --> Config Class Initialized
INFO - 2021-12-16 07:34:52 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:34:52 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:34:52 --> Utf8 Class Initialized
INFO - 2021-12-16 07:34:52 --> URI Class Initialized
INFO - 2021-12-16 07:34:52 --> Router Class Initialized
INFO - 2021-12-16 07:34:52 --> Output Class Initialized
INFO - 2021-12-16 07:34:52 --> Security Class Initialized
DEBUG - 2021-12-16 07:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:34:52 --> Input Class Initialized
INFO - 2021-12-16 07:34:52 --> Language Class Initialized
INFO - 2021-12-16 07:34:52 --> Language Class Initialized
INFO - 2021-12-16 07:34:52 --> Config Class Initialized
INFO - 2021-12-16 07:34:52 --> Loader Class Initialized
INFO - 2021-12-16 07:34:52 --> Helper loaded: url_helper
INFO - 2021-12-16 07:34:52 --> Helper loaded: file_helper
INFO - 2021-12-16 07:34:52 --> Helper loaded: form_helper
INFO - 2021-12-16 07:34:52 --> Helper loaded: my_helper
INFO - 2021-12-16 07:34:52 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:34:52 --> Controller Class Initialized
INFO - 2021-12-16 07:34:52 --> Final output sent to browser
DEBUG - 2021-12-16 07:34:52 --> Total execution time: 0.0360
INFO - 2021-12-16 07:34:55 --> Config Class Initialized
INFO - 2021-12-16 07:34:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:34:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:34:55 --> Utf8 Class Initialized
INFO - 2021-12-16 07:34:55 --> URI Class Initialized
INFO - 2021-12-16 07:34:55 --> Router Class Initialized
INFO - 2021-12-16 07:34:55 --> Output Class Initialized
INFO - 2021-12-16 07:34:55 --> Security Class Initialized
DEBUG - 2021-12-16 07:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:34:55 --> Input Class Initialized
INFO - 2021-12-16 07:34:55 --> Language Class Initialized
INFO - 2021-12-16 07:34:55 --> Language Class Initialized
INFO - 2021-12-16 07:34:55 --> Config Class Initialized
INFO - 2021-12-16 07:34:55 --> Loader Class Initialized
INFO - 2021-12-16 07:34:55 --> Helper loaded: url_helper
INFO - 2021-12-16 07:34:55 --> Helper loaded: file_helper
INFO - 2021-12-16 07:34:55 --> Helper loaded: form_helper
INFO - 2021-12-16 07:34:55 --> Helper loaded: my_helper
INFO - 2021-12-16 07:34:55 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:34:55 --> Controller Class Initialized
INFO - 2021-12-16 07:34:55 --> Helper loaded: cookie_helper
INFO - 2021-12-16 07:34:55 --> Final output sent to browser
DEBUG - 2021-12-16 07:34:55 --> Total execution time: 0.0420
INFO - 2021-12-16 07:34:56 --> Config Class Initialized
INFO - 2021-12-16 07:34:56 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:34:56 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:34:56 --> Utf8 Class Initialized
INFO - 2021-12-16 07:34:56 --> URI Class Initialized
INFO - 2021-12-16 07:34:56 --> Router Class Initialized
INFO - 2021-12-16 07:34:56 --> Output Class Initialized
INFO - 2021-12-16 07:34:56 --> Security Class Initialized
DEBUG - 2021-12-16 07:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:34:56 --> Input Class Initialized
INFO - 2021-12-16 07:34:56 --> Language Class Initialized
INFO - 2021-12-16 07:34:56 --> Language Class Initialized
INFO - 2021-12-16 07:34:56 --> Config Class Initialized
INFO - 2021-12-16 07:34:56 --> Loader Class Initialized
INFO - 2021-12-16 07:34:56 --> Helper loaded: url_helper
INFO - 2021-12-16 07:34:56 --> Helper loaded: file_helper
INFO - 2021-12-16 07:34:56 --> Helper loaded: form_helper
INFO - 2021-12-16 07:34:56 --> Helper loaded: my_helper
INFO - 2021-12-16 07:34:56 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:34:56 --> Controller Class Initialized
DEBUG - 2021-12-16 07:34:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-16 07:34:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 07:34:56 --> Final output sent to browser
DEBUG - 2021-12-16 07:34:56 --> Total execution time: 0.2430
INFO - 2021-12-16 07:35:00 --> Config Class Initialized
INFO - 2021-12-16 07:35:00 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:35:00 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:35:00 --> Utf8 Class Initialized
INFO - 2021-12-16 07:35:00 --> URI Class Initialized
INFO - 2021-12-16 07:35:00 --> Router Class Initialized
INFO - 2021-12-16 07:35:00 --> Output Class Initialized
INFO - 2021-12-16 07:35:00 --> Security Class Initialized
DEBUG - 2021-12-16 07:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:35:00 --> Input Class Initialized
INFO - 2021-12-16 07:35:00 --> Language Class Initialized
INFO - 2021-12-16 07:35:00 --> Language Class Initialized
INFO - 2021-12-16 07:35:00 --> Config Class Initialized
INFO - 2021-12-16 07:35:00 --> Loader Class Initialized
INFO - 2021-12-16 07:35:00 --> Helper loaded: url_helper
INFO - 2021-12-16 07:35:00 --> Helper loaded: file_helper
INFO - 2021-12-16 07:35:00 --> Helper loaded: form_helper
INFO - 2021-12-16 07:35:00 --> Helper loaded: my_helper
INFO - 2021-12-16 07:35:00 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:35:00 --> Controller Class Initialized
DEBUG - 2021-12-16 07:35:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 07:35:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 07:35:00 --> Final output sent to browser
DEBUG - 2021-12-16 07:35:00 --> Total execution time: 0.0480
INFO - 2021-12-16 07:35:00 --> Config Class Initialized
INFO - 2021-12-16 07:35:00 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:35:00 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:35:00 --> Utf8 Class Initialized
INFO - 2021-12-16 07:35:00 --> URI Class Initialized
INFO - 2021-12-16 07:35:00 --> Router Class Initialized
INFO - 2021-12-16 07:35:00 --> Output Class Initialized
INFO - 2021-12-16 07:35:00 --> Security Class Initialized
DEBUG - 2021-12-16 07:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:35:00 --> Input Class Initialized
INFO - 2021-12-16 07:35:00 --> Language Class Initialized
INFO - 2021-12-16 07:35:00 --> Language Class Initialized
INFO - 2021-12-16 07:35:00 --> Config Class Initialized
INFO - 2021-12-16 07:35:00 --> Loader Class Initialized
INFO - 2021-12-16 07:35:00 --> Helper loaded: url_helper
INFO - 2021-12-16 07:35:00 --> Helper loaded: file_helper
INFO - 2021-12-16 07:35:00 --> Helper loaded: form_helper
INFO - 2021-12-16 07:35:00 --> Helper loaded: my_helper
INFO - 2021-12-16 07:35:00 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:35:00 --> Controller Class Initialized
INFO - 2021-12-16 07:35:01 --> Config Class Initialized
INFO - 2021-12-16 07:35:01 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:35:01 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:35:01 --> Utf8 Class Initialized
INFO - 2021-12-16 07:35:01 --> URI Class Initialized
INFO - 2021-12-16 07:35:01 --> Router Class Initialized
INFO - 2021-12-16 07:35:01 --> Output Class Initialized
INFO - 2021-12-16 07:35:01 --> Security Class Initialized
DEBUG - 2021-12-16 07:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:35:01 --> Input Class Initialized
INFO - 2021-12-16 07:35:01 --> Language Class Initialized
INFO - 2021-12-16 07:35:01 --> Language Class Initialized
INFO - 2021-12-16 07:35:01 --> Config Class Initialized
INFO - 2021-12-16 07:35:01 --> Loader Class Initialized
INFO - 2021-12-16 07:35:01 --> Helper loaded: url_helper
INFO - 2021-12-16 07:35:01 --> Helper loaded: file_helper
INFO - 2021-12-16 07:35:01 --> Helper loaded: form_helper
INFO - 2021-12-16 07:35:01 --> Helper loaded: my_helper
INFO - 2021-12-16 07:35:01 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:35:01 --> Controller Class Initialized
ERROR - 2021-12-16 07:35:01 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-16 07:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-16 07:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 07:35:01 --> Final output sent to browser
DEBUG - 2021-12-16 07:35:01 --> Total execution time: 0.0390
INFO - 2021-12-16 07:51:43 --> Config Class Initialized
INFO - 2021-12-16 07:51:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:51:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:51:43 --> Utf8 Class Initialized
INFO - 2021-12-16 07:51:43 --> URI Class Initialized
INFO - 2021-12-16 07:51:43 --> Router Class Initialized
INFO - 2021-12-16 07:51:43 --> Output Class Initialized
INFO - 2021-12-16 07:51:43 --> Security Class Initialized
DEBUG - 2021-12-16 07:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:51:43 --> Input Class Initialized
INFO - 2021-12-16 07:51:43 --> Language Class Initialized
INFO - 2021-12-16 07:51:43 --> Language Class Initialized
INFO - 2021-12-16 07:51:43 --> Config Class Initialized
INFO - 2021-12-16 07:51:43 --> Loader Class Initialized
INFO - 2021-12-16 07:51:43 --> Helper loaded: url_helper
INFO - 2021-12-16 07:51:43 --> Helper loaded: file_helper
INFO - 2021-12-16 07:51:43 --> Helper loaded: form_helper
INFO - 2021-12-16 07:51:43 --> Helper loaded: my_helper
INFO - 2021-12-16 07:51:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:51:43 --> Controller Class Initialized
DEBUG - 2021-12-16 07:51:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 07:51:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 07:51:43 --> Final output sent to browser
DEBUG - 2021-12-16 07:51:43 --> Total execution time: 0.0450
INFO - 2021-12-16 07:51:43 --> Config Class Initialized
INFO - 2021-12-16 07:51:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:51:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:51:43 --> Utf8 Class Initialized
INFO - 2021-12-16 07:51:43 --> URI Class Initialized
INFO - 2021-12-16 07:51:43 --> Router Class Initialized
INFO - 2021-12-16 07:51:43 --> Output Class Initialized
INFO - 2021-12-16 07:51:43 --> Security Class Initialized
DEBUG - 2021-12-16 07:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:51:43 --> Input Class Initialized
INFO - 2021-12-16 07:51:43 --> Language Class Initialized
INFO - 2021-12-16 07:51:43 --> Language Class Initialized
INFO - 2021-12-16 07:51:43 --> Config Class Initialized
INFO - 2021-12-16 07:51:43 --> Loader Class Initialized
INFO - 2021-12-16 07:51:43 --> Helper loaded: url_helper
INFO - 2021-12-16 07:51:43 --> Helper loaded: file_helper
INFO - 2021-12-16 07:51:43 --> Helper loaded: form_helper
INFO - 2021-12-16 07:51:43 --> Helper loaded: my_helper
INFO - 2021-12-16 07:51:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:51:43 --> Controller Class Initialized
INFO - 2021-12-16 07:55:29 --> Config Class Initialized
INFO - 2021-12-16 07:55:29 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:55:29 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:55:29 --> Utf8 Class Initialized
INFO - 2021-12-16 07:55:29 --> URI Class Initialized
INFO - 2021-12-16 07:55:29 --> Router Class Initialized
INFO - 2021-12-16 07:55:29 --> Output Class Initialized
INFO - 2021-12-16 07:55:29 --> Security Class Initialized
DEBUG - 2021-12-16 07:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:55:29 --> Input Class Initialized
INFO - 2021-12-16 07:55:29 --> Language Class Initialized
INFO - 2021-12-16 07:55:29 --> Language Class Initialized
INFO - 2021-12-16 07:55:29 --> Config Class Initialized
INFO - 2021-12-16 07:55:29 --> Loader Class Initialized
INFO - 2021-12-16 07:55:29 --> Helper loaded: url_helper
INFO - 2021-12-16 07:55:29 --> Helper loaded: file_helper
INFO - 2021-12-16 07:55:29 --> Helper loaded: form_helper
INFO - 2021-12-16 07:55:29 --> Helper loaded: my_helper
INFO - 2021-12-16 07:55:29 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:55:29 --> Controller Class Initialized
DEBUG - 2021-12-16 07:55:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-12-16 07:55:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 07:55:29 --> Final output sent to browser
DEBUG - 2021-12-16 07:55:29 --> Total execution time: 0.0520
INFO - 2021-12-16 07:56:19 --> Config Class Initialized
INFO - 2021-12-16 07:56:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:56:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:56:19 --> Utf8 Class Initialized
INFO - 2021-12-16 07:56:19 --> URI Class Initialized
INFO - 2021-12-16 07:56:19 --> Router Class Initialized
INFO - 2021-12-16 07:56:19 --> Output Class Initialized
INFO - 2021-12-16 07:56:19 --> Security Class Initialized
DEBUG - 2021-12-16 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:56:19 --> Input Class Initialized
INFO - 2021-12-16 07:56:19 --> Language Class Initialized
INFO - 2021-12-16 07:56:19 --> Language Class Initialized
INFO - 2021-12-16 07:56:19 --> Config Class Initialized
INFO - 2021-12-16 07:56:19 --> Loader Class Initialized
INFO - 2021-12-16 07:56:19 --> Helper loaded: url_helper
INFO - 2021-12-16 07:56:19 --> Helper loaded: file_helper
INFO - 2021-12-16 07:56:19 --> Helper loaded: form_helper
INFO - 2021-12-16 07:56:19 --> Helper loaded: my_helper
INFO - 2021-12-16 07:56:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:56:19 --> Controller Class Initialized
ERROR - 2021-12-16 07:56:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: INSERT INTO m_siswa (nis, nisn, nama, jk, tmp_lahir, tgl_lahir, agama, status, anakke, alamat, notelp, email, sek_asal, sek_asal_alamat, diterima_kelas, diterima_tgl, diterima_smt, prog_keahlian, komp_keahlian, ijazah_no, ijazah_thn, skhun_no, skhun_thn, ortu_ayah, ortu_ibu, ortu_alamat, ortu_notelp, ortu_email, ortu_ayah_pkj, ortu_ibu_pkj, wali, wali_alamat, notelp_rumah, wali_email, wali_pkj) VALUES ;
INFO - 2021-12-16 07:56:22 --> Language file loaded: language/english/db_lang.php
INFO - 2021-12-16 07:59:44 --> Config Class Initialized
INFO - 2021-12-16 07:59:44 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:59:44 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:59:44 --> Utf8 Class Initialized
INFO - 2021-12-16 07:59:44 --> URI Class Initialized
INFO - 2021-12-16 07:59:44 --> Router Class Initialized
INFO - 2021-12-16 07:59:44 --> Output Class Initialized
INFO - 2021-12-16 07:59:44 --> Security Class Initialized
DEBUG - 2021-12-16 07:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:59:44 --> Input Class Initialized
INFO - 2021-12-16 07:59:44 --> Language Class Initialized
INFO - 2021-12-16 07:59:44 --> Language Class Initialized
INFO - 2021-12-16 07:59:44 --> Config Class Initialized
INFO - 2021-12-16 07:59:44 --> Loader Class Initialized
INFO - 2021-12-16 07:59:44 --> Helper loaded: url_helper
INFO - 2021-12-16 07:59:44 --> Helper loaded: file_helper
INFO - 2021-12-16 07:59:44 --> Helper loaded: form_helper
INFO - 2021-12-16 07:59:44 --> Helper loaded: my_helper
INFO - 2021-12-16 07:59:44 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:59:44 --> Controller Class Initialized
DEBUG - 2021-12-16 07:59:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-12-16 07:59:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 07:59:44 --> Final output sent to browser
DEBUG - 2021-12-16 07:59:44 --> Total execution time: 0.0460
INFO - 2021-12-16 07:59:47 --> Config Class Initialized
INFO - 2021-12-16 07:59:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:59:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:59:47 --> Utf8 Class Initialized
INFO - 2021-12-16 07:59:47 --> URI Class Initialized
INFO - 2021-12-16 07:59:47 --> Router Class Initialized
INFO - 2021-12-16 07:59:47 --> Output Class Initialized
INFO - 2021-12-16 07:59:47 --> Security Class Initialized
DEBUG - 2021-12-16 07:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:59:47 --> Input Class Initialized
INFO - 2021-12-16 07:59:47 --> Language Class Initialized
INFO - 2021-12-16 07:59:47 --> Language Class Initialized
INFO - 2021-12-16 07:59:47 --> Config Class Initialized
INFO - 2021-12-16 07:59:47 --> Loader Class Initialized
INFO - 2021-12-16 07:59:47 --> Helper loaded: url_helper
INFO - 2021-12-16 07:59:47 --> Helper loaded: file_helper
INFO - 2021-12-16 07:59:47 --> Helper loaded: form_helper
INFO - 2021-12-16 07:59:47 --> Helper loaded: my_helper
INFO - 2021-12-16 07:59:47 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:59:47 --> Controller Class Initialized
DEBUG - 2021-12-16 07:59:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 07:59:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 07:59:47 --> Final output sent to browser
DEBUG - 2021-12-16 07:59:47 --> Total execution time: 0.0410
INFO - 2021-12-16 07:59:47 --> Config Class Initialized
INFO - 2021-12-16 07:59:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 07:59:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 07:59:47 --> Utf8 Class Initialized
INFO - 2021-12-16 07:59:47 --> URI Class Initialized
INFO - 2021-12-16 07:59:47 --> Router Class Initialized
INFO - 2021-12-16 07:59:47 --> Output Class Initialized
INFO - 2021-12-16 07:59:47 --> Security Class Initialized
DEBUG - 2021-12-16 07:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 07:59:47 --> Input Class Initialized
INFO - 2021-12-16 07:59:47 --> Language Class Initialized
INFO - 2021-12-16 07:59:47 --> Language Class Initialized
INFO - 2021-12-16 07:59:47 --> Config Class Initialized
INFO - 2021-12-16 07:59:47 --> Loader Class Initialized
INFO - 2021-12-16 07:59:47 --> Helper loaded: url_helper
INFO - 2021-12-16 07:59:47 --> Helper loaded: file_helper
INFO - 2021-12-16 07:59:47 --> Helper loaded: form_helper
INFO - 2021-12-16 07:59:47 --> Helper loaded: my_helper
INFO - 2021-12-16 07:59:47 --> Database Driver Class Initialized
DEBUG - 2021-12-16 07:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 07:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 07:59:47 --> Controller Class Initialized
INFO - 2021-12-16 08:00:05 --> Config Class Initialized
INFO - 2021-12-16 08:00:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:00:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:00:05 --> Utf8 Class Initialized
INFO - 2021-12-16 08:00:05 --> URI Class Initialized
INFO - 2021-12-16 08:00:05 --> Router Class Initialized
INFO - 2021-12-16 08:00:05 --> Output Class Initialized
INFO - 2021-12-16 08:00:05 --> Security Class Initialized
DEBUG - 2021-12-16 08:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:00:05 --> Input Class Initialized
INFO - 2021-12-16 08:00:05 --> Language Class Initialized
INFO - 2021-12-16 08:00:05 --> Language Class Initialized
INFO - 2021-12-16 08:00:05 --> Config Class Initialized
INFO - 2021-12-16 08:00:05 --> Loader Class Initialized
INFO - 2021-12-16 08:00:05 --> Helper loaded: url_helper
INFO - 2021-12-16 08:00:05 --> Helper loaded: file_helper
INFO - 2021-12-16 08:00:05 --> Helper loaded: form_helper
INFO - 2021-12-16 08:00:05 --> Helper loaded: my_helper
INFO - 2021-12-16 08:00:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:00:05 --> Controller Class Initialized
INFO - 2021-12-16 08:00:12 --> Config Class Initialized
INFO - 2021-12-16 08:00:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:00:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:00:12 --> Utf8 Class Initialized
INFO - 2021-12-16 08:00:12 --> URI Class Initialized
INFO - 2021-12-16 08:00:12 --> Router Class Initialized
INFO - 2021-12-16 08:00:12 --> Output Class Initialized
INFO - 2021-12-16 08:00:12 --> Security Class Initialized
DEBUG - 2021-12-16 08:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:00:12 --> Input Class Initialized
INFO - 2021-12-16 08:00:12 --> Language Class Initialized
INFO - 2021-12-16 08:00:12 --> Language Class Initialized
INFO - 2021-12-16 08:00:12 --> Config Class Initialized
INFO - 2021-12-16 08:00:12 --> Loader Class Initialized
INFO - 2021-12-16 08:00:12 --> Helper loaded: url_helper
INFO - 2021-12-16 08:00:12 --> Helper loaded: file_helper
INFO - 2021-12-16 08:00:12 --> Helper loaded: form_helper
INFO - 2021-12-16 08:00:12 --> Helper loaded: my_helper
INFO - 2021-12-16 08:00:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:00:12 --> Controller Class Initialized
INFO - 2021-12-16 08:03:03 --> Config Class Initialized
INFO - 2021-12-16 08:03:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:03:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:03:03 --> Utf8 Class Initialized
INFO - 2021-12-16 08:03:03 --> URI Class Initialized
INFO - 2021-12-16 08:03:03 --> Router Class Initialized
INFO - 2021-12-16 08:03:03 --> Output Class Initialized
INFO - 2021-12-16 08:03:03 --> Security Class Initialized
DEBUG - 2021-12-16 08:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:03:03 --> Input Class Initialized
INFO - 2021-12-16 08:03:03 --> Language Class Initialized
INFO - 2021-12-16 08:03:03 --> Language Class Initialized
INFO - 2021-12-16 08:03:03 --> Config Class Initialized
INFO - 2021-12-16 08:03:03 --> Loader Class Initialized
INFO - 2021-12-16 08:03:03 --> Helper loaded: url_helper
INFO - 2021-12-16 08:03:03 --> Helper loaded: file_helper
INFO - 2021-12-16 08:03:03 --> Helper loaded: form_helper
INFO - 2021-12-16 08:03:03 --> Helper loaded: my_helper
INFO - 2021-12-16 08:03:03 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:03:03 --> Controller Class Initialized
DEBUG - 2021-12-16 08:03:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-12-16 08:03:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:03:03 --> Final output sent to browser
DEBUG - 2021-12-16 08:03:03 --> Total execution time: 0.0450
INFO - 2021-12-16 08:03:13 --> Config Class Initialized
INFO - 2021-12-16 08:03:13 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:03:13 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:03:13 --> Utf8 Class Initialized
INFO - 2021-12-16 08:03:13 --> URI Class Initialized
INFO - 2021-12-16 08:03:13 --> Router Class Initialized
INFO - 2021-12-16 08:03:13 --> Output Class Initialized
INFO - 2021-12-16 08:03:13 --> Security Class Initialized
DEBUG - 2021-12-16 08:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:03:13 --> Input Class Initialized
INFO - 2021-12-16 08:03:13 --> Language Class Initialized
INFO - 2021-12-16 08:03:13 --> Language Class Initialized
INFO - 2021-12-16 08:03:13 --> Config Class Initialized
INFO - 2021-12-16 08:03:13 --> Loader Class Initialized
INFO - 2021-12-16 08:03:13 --> Helper loaded: url_helper
INFO - 2021-12-16 08:03:13 --> Helper loaded: file_helper
INFO - 2021-12-16 08:03:13 --> Helper loaded: form_helper
INFO - 2021-12-16 08:03:13 --> Helper loaded: my_helper
INFO - 2021-12-16 08:03:13 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:03:13 --> Controller Class Initialized
INFO - 2021-12-16 08:03:17 --> Config Class Initialized
INFO - 2021-12-16 08:03:17 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:03:17 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:03:17 --> Utf8 Class Initialized
INFO - 2021-12-16 08:03:17 --> URI Class Initialized
INFO - 2021-12-16 08:03:17 --> Router Class Initialized
INFO - 2021-12-16 08:03:17 --> Output Class Initialized
INFO - 2021-12-16 08:03:17 --> Security Class Initialized
DEBUG - 2021-12-16 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:03:17 --> Input Class Initialized
INFO - 2021-12-16 08:03:17 --> Language Class Initialized
INFO - 2021-12-16 08:03:17 --> Language Class Initialized
INFO - 2021-12-16 08:03:17 --> Config Class Initialized
INFO - 2021-12-16 08:03:17 --> Loader Class Initialized
INFO - 2021-12-16 08:03:17 --> Helper loaded: url_helper
INFO - 2021-12-16 08:03:17 --> Helper loaded: file_helper
INFO - 2021-12-16 08:03:17 --> Helper loaded: form_helper
INFO - 2021-12-16 08:03:17 --> Helper loaded: my_helper
INFO - 2021-12-16 08:03:17 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:03:17 --> Controller Class Initialized
DEBUG - 2021-12-16 08:03:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-12-16 08:03:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:03:17 --> Final output sent to browser
DEBUG - 2021-12-16 08:03:17 --> Total execution time: 0.0350
INFO - 2021-12-16 08:03:33 --> Config Class Initialized
INFO - 2021-12-16 08:03:33 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:03:33 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:03:33 --> Utf8 Class Initialized
INFO - 2021-12-16 08:03:33 --> URI Class Initialized
INFO - 2021-12-16 08:03:33 --> Router Class Initialized
INFO - 2021-12-16 08:03:33 --> Output Class Initialized
INFO - 2021-12-16 08:03:33 --> Security Class Initialized
DEBUG - 2021-12-16 08:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:03:33 --> Input Class Initialized
INFO - 2021-12-16 08:03:33 --> Language Class Initialized
INFO - 2021-12-16 08:03:33 --> Language Class Initialized
INFO - 2021-12-16 08:03:33 --> Config Class Initialized
INFO - 2021-12-16 08:03:33 --> Loader Class Initialized
INFO - 2021-12-16 08:03:33 --> Helper loaded: url_helper
INFO - 2021-12-16 08:03:33 --> Helper loaded: file_helper
INFO - 2021-12-16 08:03:33 --> Helper loaded: form_helper
INFO - 2021-12-16 08:03:33 --> Helper loaded: my_helper
INFO - 2021-12-16 08:03:33 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:03:33 --> Controller Class Initialized
DEBUG - 2021-12-16 08:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 08:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:03:33 --> Final output sent to browser
DEBUG - 2021-12-16 08:03:33 --> Total execution time: 0.0440
INFO - 2021-12-16 08:03:33 --> Config Class Initialized
INFO - 2021-12-16 08:03:33 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:03:33 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:03:33 --> Utf8 Class Initialized
INFO - 2021-12-16 08:03:33 --> URI Class Initialized
INFO - 2021-12-16 08:03:33 --> Router Class Initialized
INFO - 2021-12-16 08:03:33 --> Output Class Initialized
INFO - 2021-12-16 08:03:33 --> Security Class Initialized
DEBUG - 2021-12-16 08:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:03:33 --> Input Class Initialized
INFO - 2021-12-16 08:03:33 --> Language Class Initialized
INFO - 2021-12-16 08:03:33 --> Language Class Initialized
INFO - 2021-12-16 08:03:33 --> Config Class Initialized
INFO - 2021-12-16 08:03:33 --> Loader Class Initialized
INFO - 2021-12-16 08:03:33 --> Helper loaded: url_helper
INFO - 2021-12-16 08:03:33 --> Helper loaded: file_helper
INFO - 2021-12-16 08:03:33 --> Helper loaded: form_helper
INFO - 2021-12-16 08:03:33 --> Helper loaded: my_helper
INFO - 2021-12-16 08:03:33 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:03:33 --> Controller Class Initialized
INFO - 2021-12-16 08:03:48 --> Config Class Initialized
INFO - 2021-12-16 08:03:48 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:03:48 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:03:48 --> Utf8 Class Initialized
INFO - 2021-12-16 08:03:48 --> URI Class Initialized
INFO - 2021-12-16 08:03:48 --> Router Class Initialized
INFO - 2021-12-16 08:03:48 --> Output Class Initialized
INFO - 2021-12-16 08:03:48 --> Security Class Initialized
DEBUG - 2021-12-16 08:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:03:48 --> Input Class Initialized
INFO - 2021-12-16 08:03:48 --> Language Class Initialized
INFO - 2021-12-16 08:03:48 --> Language Class Initialized
INFO - 2021-12-16 08:03:48 --> Config Class Initialized
INFO - 2021-12-16 08:03:48 --> Loader Class Initialized
INFO - 2021-12-16 08:03:48 --> Helper loaded: url_helper
INFO - 2021-12-16 08:03:48 --> Helper loaded: file_helper
INFO - 2021-12-16 08:03:48 --> Helper loaded: form_helper
INFO - 2021-12-16 08:03:48 --> Helper loaded: my_helper
INFO - 2021-12-16 08:03:48 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:03:48 --> Controller Class Initialized
INFO - 2021-12-16 08:03:50 --> Config Class Initialized
INFO - 2021-12-16 08:03:50 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:03:50 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:03:50 --> Utf8 Class Initialized
INFO - 2021-12-16 08:03:50 --> URI Class Initialized
INFO - 2021-12-16 08:03:50 --> Router Class Initialized
INFO - 2021-12-16 08:03:50 --> Output Class Initialized
INFO - 2021-12-16 08:03:50 --> Security Class Initialized
DEBUG - 2021-12-16 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:03:50 --> Input Class Initialized
INFO - 2021-12-16 08:03:50 --> Language Class Initialized
INFO - 2021-12-16 08:03:50 --> Language Class Initialized
INFO - 2021-12-16 08:03:50 --> Config Class Initialized
INFO - 2021-12-16 08:03:50 --> Loader Class Initialized
INFO - 2021-12-16 08:03:50 --> Helper loaded: url_helper
INFO - 2021-12-16 08:03:50 --> Helper loaded: file_helper
INFO - 2021-12-16 08:03:50 --> Helper loaded: form_helper
INFO - 2021-12-16 08:03:50 --> Helper loaded: my_helper
INFO - 2021-12-16 08:03:50 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:03:50 --> Controller Class Initialized
ERROR - 2021-12-16 08:03:50 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-16 08:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-16 08:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:03:50 --> Final output sent to browser
DEBUG - 2021-12-16 08:03:50 --> Total execution time: 0.0470
INFO - 2021-12-16 08:04:09 --> Config Class Initialized
INFO - 2021-12-16 08:04:09 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:04:09 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:04:09 --> Utf8 Class Initialized
INFO - 2021-12-16 08:04:09 --> URI Class Initialized
INFO - 2021-12-16 08:04:09 --> Router Class Initialized
INFO - 2021-12-16 08:04:09 --> Output Class Initialized
INFO - 2021-12-16 08:04:09 --> Security Class Initialized
DEBUG - 2021-12-16 08:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:04:09 --> Input Class Initialized
INFO - 2021-12-16 08:04:09 --> Language Class Initialized
INFO - 2021-12-16 08:04:09 --> Language Class Initialized
INFO - 2021-12-16 08:04:09 --> Config Class Initialized
INFO - 2021-12-16 08:04:09 --> Loader Class Initialized
INFO - 2021-12-16 08:04:09 --> Helper loaded: url_helper
INFO - 2021-12-16 08:04:09 --> Helper loaded: file_helper
INFO - 2021-12-16 08:04:09 --> Helper loaded: form_helper
INFO - 2021-12-16 08:04:09 --> Helper loaded: my_helper
INFO - 2021-12-16 08:04:09 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:04:09 --> Controller Class Initialized
DEBUG - 2021-12-16 08:04:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-16 08:04:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:04:09 --> Final output sent to browser
DEBUG - 2021-12-16 08:04:09 --> Total execution time: 0.0350
INFO - 2021-12-16 08:04:09 --> Config Class Initialized
INFO - 2021-12-16 08:04:09 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:04:09 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:04:09 --> Utf8 Class Initialized
INFO - 2021-12-16 08:04:09 --> URI Class Initialized
INFO - 2021-12-16 08:04:09 --> Router Class Initialized
INFO - 2021-12-16 08:04:09 --> Output Class Initialized
INFO - 2021-12-16 08:04:09 --> Security Class Initialized
DEBUG - 2021-12-16 08:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:04:09 --> Input Class Initialized
INFO - 2021-12-16 08:04:09 --> Language Class Initialized
INFO - 2021-12-16 08:04:09 --> Language Class Initialized
INFO - 2021-12-16 08:04:09 --> Config Class Initialized
INFO - 2021-12-16 08:04:09 --> Loader Class Initialized
INFO - 2021-12-16 08:04:09 --> Helper loaded: url_helper
INFO - 2021-12-16 08:04:09 --> Helper loaded: file_helper
INFO - 2021-12-16 08:04:09 --> Helper loaded: form_helper
INFO - 2021-12-16 08:04:09 --> Helper loaded: my_helper
INFO - 2021-12-16 08:04:09 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:04:09 --> Controller Class Initialized
INFO - 2021-12-16 08:08:53 --> Config Class Initialized
INFO - 2021-12-16 08:08:53 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:08:53 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:08:53 --> Utf8 Class Initialized
INFO - 2021-12-16 08:08:53 --> URI Class Initialized
INFO - 2021-12-16 08:08:53 --> Router Class Initialized
INFO - 2021-12-16 08:08:53 --> Output Class Initialized
INFO - 2021-12-16 08:08:53 --> Security Class Initialized
DEBUG - 2021-12-16 08:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:08:53 --> Input Class Initialized
INFO - 2021-12-16 08:08:53 --> Language Class Initialized
INFO - 2021-12-16 08:08:53 --> Language Class Initialized
INFO - 2021-12-16 08:08:53 --> Config Class Initialized
INFO - 2021-12-16 08:08:53 --> Loader Class Initialized
INFO - 2021-12-16 08:08:53 --> Helper loaded: url_helper
INFO - 2021-12-16 08:08:53 --> Helper loaded: file_helper
INFO - 2021-12-16 08:08:53 --> Helper loaded: form_helper
INFO - 2021-12-16 08:08:53 --> Helper loaded: my_helper
INFO - 2021-12-16 08:08:53 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:08:53 --> Controller Class Initialized
DEBUG - 2021-12-16 08:08:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:08:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:08:53 --> Final output sent to browser
DEBUG - 2021-12-16 08:08:53 --> Total execution time: 0.0650
INFO - 2021-12-16 08:08:57 --> Config Class Initialized
INFO - 2021-12-16 08:08:57 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:08:57 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:08:57 --> Utf8 Class Initialized
INFO - 2021-12-16 08:08:57 --> URI Class Initialized
INFO - 2021-12-16 08:08:57 --> Router Class Initialized
INFO - 2021-12-16 08:08:57 --> Output Class Initialized
INFO - 2021-12-16 08:08:57 --> Security Class Initialized
DEBUG - 2021-12-16 08:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:08:57 --> Input Class Initialized
INFO - 2021-12-16 08:08:57 --> Language Class Initialized
INFO - 2021-12-16 08:08:57 --> Language Class Initialized
INFO - 2021-12-16 08:08:57 --> Config Class Initialized
INFO - 2021-12-16 08:08:57 --> Loader Class Initialized
INFO - 2021-12-16 08:08:57 --> Helper loaded: url_helper
INFO - 2021-12-16 08:08:57 --> Helper loaded: file_helper
INFO - 2021-12-16 08:08:57 --> Helper loaded: form_helper
INFO - 2021-12-16 08:08:57 --> Helper loaded: my_helper
INFO - 2021-12-16 08:08:57 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:08:57 --> Controller Class Initialized
DEBUG - 2021-12-16 08:08:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-16 08:08:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:08:57 --> Final output sent to browser
DEBUG - 2021-12-16 08:08:57 --> Total execution time: 0.0500
INFO - 2021-12-16 08:08:57 --> Config Class Initialized
INFO - 2021-12-16 08:08:57 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:08:57 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:08:57 --> Utf8 Class Initialized
INFO - 2021-12-16 08:08:57 --> URI Class Initialized
INFO - 2021-12-16 08:08:57 --> Router Class Initialized
INFO - 2021-12-16 08:08:57 --> Output Class Initialized
INFO - 2021-12-16 08:08:57 --> Security Class Initialized
DEBUG - 2021-12-16 08:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:08:57 --> Input Class Initialized
INFO - 2021-12-16 08:08:57 --> Language Class Initialized
INFO - 2021-12-16 08:08:57 --> Language Class Initialized
INFO - 2021-12-16 08:08:57 --> Config Class Initialized
INFO - 2021-12-16 08:08:57 --> Loader Class Initialized
INFO - 2021-12-16 08:08:57 --> Helper loaded: url_helper
INFO - 2021-12-16 08:08:57 --> Helper loaded: file_helper
INFO - 2021-12-16 08:08:57 --> Helper loaded: form_helper
INFO - 2021-12-16 08:08:57 --> Helper loaded: my_helper
INFO - 2021-12-16 08:08:57 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:08:57 --> Controller Class Initialized
INFO - 2021-12-16 08:08:59 --> Config Class Initialized
INFO - 2021-12-16 08:08:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:08:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:08:59 --> Utf8 Class Initialized
INFO - 2021-12-16 08:08:59 --> URI Class Initialized
INFO - 2021-12-16 08:08:59 --> Router Class Initialized
INFO - 2021-12-16 08:08:59 --> Output Class Initialized
INFO - 2021-12-16 08:08:59 --> Security Class Initialized
DEBUG - 2021-12-16 08:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:08:59 --> Input Class Initialized
INFO - 2021-12-16 08:08:59 --> Language Class Initialized
INFO - 2021-12-16 08:08:59 --> Language Class Initialized
INFO - 2021-12-16 08:08:59 --> Config Class Initialized
INFO - 2021-12-16 08:08:59 --> Loader Class Initialized
INFO - 2021-12-16 08:08:59 --> Helper loaded: url_helper
INFO - 2021-12-16 08:08:59 --> Helper loaded: file_helper
INFO - 2021-12-16 08:08:59 --> Helper loaded: form_helper
INFO - 2021-12-16 08:08:59 --> Helper loaded: my_helper
INFO - 2021-12-16 08:08:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:09:00 --> Controller Class Initialized
INFO - 2021-12-16 08:09:00 --> Final output sent to browser
DEBUG - 2021-12-16 08:09:00 --> Total execution time: 0.0540
INFO - 2021-12-16 08:09:00 --> Config Class Initialized
INFO - 2021-12-16 08:09:00 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:09:00 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:09:00 --> Utf8 Class Initialized
INFO - 2021-12-16 08:09:00 --> URI Class Initialized
INFO - 2021-12-16 08:09:00 --> Router Class Initialized
INFO - 2021-12-16 08:09:00 --> Output Class Initialized
INFO - 2021-12-16 08:09:00 --> Security Class Initialized
DEBUG - 2021-12-16 08:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:09:00 --> Input Class Initialized
INFO - 2021-12-16 08:09:00 --> Language Class Initialized
INFO - 2021-12-16 08:09:00 --> Language Class Initialized
INFO - 2021-12-16 08:09:00 --> Config Class Initialized
INFO - 2021-12-16 08:09:00 --> Loader Class Initialized
INFO - 2021-12-16 08:09:00 --> Helper loaded: url_helper
INFO - 2021-12-16 08:09:00 --> Helper loaded: file_helper
INFO - 2021-12-16 08:09:00 --> Helper loaded: form_helper
INFO - 2021-12-16 08:09:00 --> Helper loaded: my_helper
INFO - 2021-12-16 08:09:00 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:09:00 --> Controller Class Initialized
INFO - 2021-12-16 08:09:02 --> Config Class Initialized
INFO - 2021-12-16 08:09:02 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:09:02 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:09:02 --> Utf8 Class Initialized
INFO - 2021-12-16 08:09:02 --> URI Class Initialized
INFO - 2021-12-16 08:09:02 --> Router Class Initialized
INFO - 2021-12-16 08:09:02 --> Output Class Initialized
INFO - 2021-12-16 08:09:02 --> Security Class Initialized
DEBUG - 2021-12-16 08:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:09:02 --> Input Class Initialized
INFO - 2021-12-16 08:09:02 --> Language Class Initialized
INFO - 2021-12-16 08:09:02 --> Language Class Initialized
INFO - 2021-12-16 08:09:02 --> Config Class Initialized
INFO - 2021-12-16 08:09:02 --> Loader Class Initialized
INFO - 2021-12-16 08:09:02 --> Helper loaded: url_helper
INFO - 2021-12-16 08:09:02 --> Helper loaded: file_helper
INFO - 2021-12-16 08:09:02 --> Helper loaded: form_helper
INFO - 2021-12-16 08:09:02 --> Helper loaded: my_helper
INFO - 2021-12-16 08:09:02 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:09:02 --> Controller Class Initialized
DEBUG - 2021-12-16 08:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:09:02 --> Final output sent to browser
DEBUG - 2021-12-16 08:09:02 --> Total execution time: 0.0550
INFO - 2021-12-16 08:09:03 --> Config Class Initialized
INFO - 2021-12-16 08:09:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:09:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:09:03 --> Utf8 Class Initialized
INFO - 2021-12-16 08:09:03 --> URI Class Initialized
INFO - 2021-12-16 08:09:03 --> Router Class Initialized
INFO - 2021-12-16 08:09:03 --> Output Class Initialized
INFO - 2021-12-16 08:09:03 --> Security Class Initialized
DEBUG - 2021-12-16 08:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:09:03 --> Input Class Initialized
INFO - 2021-12-16 08:09:03 --> Language Class Initialized
INFO - 2021-12-16 08:09:03 --> Language Class Initialized
INFO - 2021-12-16 08:09:03 --> Config Class Initialized
INFO - 2021-12-16 08:09:03 --> Loader Class Initialized
INFO - 2021-12-16 08:09:03 --> Helper loaded: url_helper
INFO - 2021-12-16 08:09:03 --> Helper loaded: file_helper
INFO - 2021-12-16 08:09:03 --> Helper loaded: form_helper
INFO - 2021-12-16 08:09:03 --> Helper loaded: my_helper
INFO - 2021-12-16 08:09:03 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:09:03 --> Controller Class Initialized
DEBUG - 2021-12-16 08:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 08:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:09:03 --> Final output sent to browser
DEBUG - 2021-12-16 08:09:03 --> Total execution time: 0.0470
INFO - 2021-12-16 08:11:02 --> Config Class Initialized
INFO - 2021-12-16 08:11:02 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:11:02 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:11:02 --> Utf8 Class Initialized
INFO - 2021-12-16 08:11:02 --> URI Class Initialized
INFO - 2021-12-16 08:11:02 --> Router Class Initialized
INFO - 2021-12-16 08:11:02 --> Output Class Initialized
INFO - 2021-12-16 08:11:02 --> Security Class Initialized
DEBUG - 2021-12-16 08:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:11:02 --> Input Class Initialized
INFO - 2021-12-16 08:11:02 --> Language Class Initialized
INFO - 2021-12-16 08:11:02 --> Language Class Initialized
INFO - 2021-12-16 08:11:02 --> Config Class Initialized
INFO - 2021-12-16 08:11:02 --> Loader Class Initialized
INFO - 2021-12-16 08:11:02 --> Helper loaded: url_helper
INFO - 2021-12-16 08:11:02 --> Helper loaded: file_helper
INFO - 2021-12-16 08:11:02 --> Helper loaded: form_helper
INFO - 2021-12-16 08:11:02 --> Helper loaded: my_helper
INFO - 2021-12-16 08:11:02 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:11:02 --> Controller Class Initialized
INFO - 2021-12-16 08:11:02 --> Config Class Initialized
INFO - 2021-12-16 08:11:02 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:11:02 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:11:02 --> Utf8 Class Initialized
INFO - 2021-12-16 08:11:02 --> URI Class Initialized
INFO - 2021-12-16 08:11:02 --> Router Class Initialized
INFO - 2021-12-16 08:11:02 --> Output Class Initialized
INFO - 2021-12-16 08:11:02 --> Security Class Initialized
DEBUG - 2021-12-16 08:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:11:02 --> Input Class Initialized
INFO - 2021-12-16 08:11:02 --> Language Class Initialized
INFO - 2021-12-16 08:11:02 --> Language Class Initialized
INFO - 2021-12-16 08:11:02 --> Config Class Initialized
INFO - 2021-12-16 08:11:02 --> Loader Class Initialized
INFO - 2021-12-16 08:11:02 --> Helper loaded: url_helper
INFO - 2021-12-16 08:11:02 --> Helper loaded: file_helper
INFO - 2021-12-16 08:11:02 --> Helper loaded: form_helper
INFO - 2021-12-16 08:11:02 --> Helper loaded: my_helper
INFO - 2021-12-16 08:11:02 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:11:02 --> Controller Class Initialized
DEBUG - 2021-12-16 08:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:11:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:11:02 --> Final output sent to browser
DEBUG - 2021-12-16 08:11:02 --> Total execution time: 0.0450
INFO - 2021-12-16 08:11:12 --> Config Class Initialized
INFO - 2021-12-16 08:11:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:11:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:11:12 --> Utf8 Class Initialized
INFO - 2021-12-16 08:11:12 --> URI Class Initialized
INFO - 2021-12-16 08:11:12 --> Router Class Initialized
INFO - 2021-12-16 08:11:12 --> Output Class Initialized
INFO - 2021-12-16 08:11:12 --> Security Class Initialized
DEBUG - 2021-12-16 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:11:12 --> Input Class Initialized
INFO - 2021-12-16 08:11:12 --> Language Class Initialized
INFO - 2021-12-16 08:11:12 --> Language Class Initialized
INFO - 2021-12-16 08:11:12 --> Config Class Initialized
INFO - 2021-12-16 08:11:12 --> Loader Class Initialized
INFO - 2021-12-16 08:11:12 --> Helper loaded: url_helper
INFO - 2021-12-16 08:11:12 --> Helper loaded: file_helper
INFO - 2021-12-16 08:11:12 --> Helper loaded: form_helper
INFO - 2021-12-16 08:11:12 --> Helper loaded: my_helper
INFO - 2021-12-16 08:11:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:11:12 --> Controller Class Initialized
DEBUG - 2021-12-16 08:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 08:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:11:12 --> Final output sent to browser
DEBUG - 2021-12-16 08:11:12 --> Total execution time: 0.0510
INFO - 2021-12-16 08:12:17 --> Config Class Initialized
INFO - 2021-12-16 08:12:17 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:12:17 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:12:17 --> Utf8 Class Initialized
INFO - 2021-12-16 08:12:17 --> URI Class Initialized
INFO - 2021-12-16 08:12:17 --> Router Class Initialized
INFO - 2021-12-16 08:12:17 --> Output Class Initialized
INFO - 2021-12-16 08:12:17 --> Security Class Initialized
DEBUG - 2021-12-16 08:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:12:17 --> Input Class Initialized
INFO - 2021-12-16 08:12:17 --> Language Class Initialized
INFO - 2021-12-16 08:12:17 --> Language Class Initialized
INFO - 2021-12-16 08:12:17 --> Config Class Initialized
INFO - 2021-12-16 08:12:17 --> Loader Class Initialized
INFO - 2021-12-16 08:12:17 --> Helper loaded: url_helper
INFO - 2021-12-16 08:12:17 --> Helper loaded: file_helper
INFO - 2021-12-16 08:12:17 --> Helper loaded: form_helper
INFO - 2021-12-16 08:12:17 --> Helper loaded: my_helper
INFO - 2021-12-16 08:12:17 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:12:17 --> Controller Class Initialized
INFO - 2021-12-16 08:12:17 --> Config Class Initialized
INFO - 2021-12-16 08:12:17 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:12:17 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:12:17 --> Utf8 Class Initialized
INFO - 2021-12-16 08:12:17 --> URI Class Initialized
INFO - 2021-12-16 08:12:17 --> Router Class Initialized
INFO - 2021-12-16 08:12:17 --> Output Class Initialized
INFO - 2021-12-16 08:12:17 --> Security Class Initialized
DEBUG - 2021-12-16 08:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:12:17 --> Input Class Initialized
INFO - 2021-12-16 08:12:17 --> Language Class Initialized
INFO - 2021-12-16 08:12:17 --> Language Class Initialized
INFO - 2021-12-16 08:12:17 --> Config Class Initialized
INFO - 2021-12-16 08:12:17 --> Loader Class Initialized
INFO - 2021-12-16 08:12:17 --> Helper loaded: url_helper
INFO - 2021-12-16 08:12:17 --> Helper loaded: file_helper
INFO - 2021-12-16 08:12:17 --> Helper loaded: form_helper
INFO - 2021-12-16 08:12:17 --> Helper loaded: my_helper
INFO - 2021-12-16 08:12:17 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:12:17 --> Controller Class Initialized
DEBUG - 2021-12-16 08:12:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:12:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:12:17 --> Final output sent to browser
DEBUG - 2021-12-16 08:12:17 --> Total execution time: 0.0440
INFO - 2021-12-16 08:12:31 --> Config Class Initialized
INFO - 2021-12-16 08:12:31 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:12:31 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:12:31 --> Utf8 Class Initialized
INFO - 2021-12-16 08:12:31 --> URI Class Initialized
INFO - 2021-12-16 08:12:31 --> Router Class Initialized
INFO - 2021-12-16 08:12:31 --> Output Class Initialized
INFO - 2021-12-16 08:12:31 --> Security Class Initialized
DEBUG - 2021-12-16 08:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:12:31 --> Input Class Initialized
INFO - 2021-12-16 08:12:31 --> Language Class Initialized
INFO - 2021-12-16 08:12:31 --> Language Class Initialized
INFO - 2021-12-16 08:12:31 --> Config Class Initialized
INFO - 2021-12-16 08:12:31 --> Loader Class Initialized
INFO - 2021-12-16 08:12:31 --> Helper loaded: url_helper
INFO - 2021-12-16 08:12:31 --> Helper loaded: file_helper
INFO - 2021-12-16 08:12:31 --> Helper loaded: form_helper
INFO - 2021-12-16 08:12:31 --> Helper loaded: my_helper
INFO - 2021-12-16 08:12:31 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:12:31 --> Controller Class Initialized
DEBUG - 2021-12-16 08:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 08:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:12:31 --> Final output sent to browser
DEBUG - 2021-12-16 08:12:31 --> Total execution time: 0.0480
INFO - 2021-12-16 08:12:59 --> Config Class Initialized
INFO - 2021-12-16 08:12:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:12:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:12:59 --> Utf8 Class Initialized
INFO - 2021-12-16 08:12:59 --> URI Class Initialized
INFO - 2021-12-16 08:12:59 --> Router Class Initialized
INFO - 2021-12-16 08:12:59 --> Output Class Initialized
INFO - 2021-12-16 08:12:59 --> Security Class Initialized
DEBUG - 2021-12-16 08:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:12:59 --> Input Class Initialized
INFO - 2021-12-16 08:12:59 --> Language Class Initialized
INFO - 2021-12-16 08:12:59 --> Language Class Initialized
INFO - 2021-12-16 08:12:59 --> Config Class Initialized
INFO - 2021-12-16 08:12:59 --> Loader Class Initialized
INFO - 2021-12-16 08:12:59 --> Helper loaded: url_helper
INFO - 2021-12-16 08:12:59 --> Helper loaded: file_helper
INFO - 2021-12-16 08:12:59 --> Helper loaded: form_helper
INFO - 2021-12-16 08:12:59 --> Helper loaded: my_helper
INFO - 2021-12-16 08:12:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:12:59 --> Controller Class Initialized
INFO - 2021-12-16 08:12:59 --> Config Class Initialized
INFO - 2021-12-16 08:12:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:12:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:12:59 --> Utf8 Class Initialized
INFO - 2021-12-16 08:12:59 --> URI Class Initialized
INFO - 2021-12-16 08:12:59 --> Router Class Initialized
INFO - 2021-12-16 08:12:59 --> Output Class Initialized
INFO - 2021-12-16 08:12:59 --> Security Class Initialized
DEBUG - 2021-12-16 08:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:12:59 --> Input Class Initialized
INFO - 2021-12-16 08:12:59 --> Language Class Initialized
INFO - 2021-12-16 08:12:59 --> Language Class Initialized
INFO - 2021-12-16 08:12:59 --> Config Class Initialized
INFO - 2021-12-16 08:12:59 --> Loader Class Initialized
INFO - 2021-12-16 08:12:59 --> Helper loaded: url_helper
INFO - 2021-12-16 08:12:59 --> Helper loaded: file_helper
INFO - 2021-12-16 08:12:59 --> Helper loaded: form_helper
INFO - 2021-12-16 08:12:59 --> Helper loaded: my_helper
INFO - 2021-12-16 08:12:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:12:59 --> Controller Class Initialized
DEBUG - 2021-12-16 08:12:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:12:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:12:59 --> Final output sent to browser
DEBUG - 2021-12-16 08:12:59 --> Total execution time: 0.0530
INFO - 2021-12-16 08:13:05 --> Config Class Initialized
INFO - 2021-12-16 08:13:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:13:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:13:05 --> Utf8 Class Initialized
INFO - 2021-12-16 08:13:05 --> URI Class Initialized
INFO - 2021-12-16 08:13:05 --> Router Class Initialized
INFO - 2021-12-16 08:13:05 --> Output Class Initialized
INFO - 2021-12-16 08:13:05 --> Security Class Initialized
DEBUG - 2021-12-16 08:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:13:05 --> Input Class Initialized
INFO - 2021-12-16 08:13:05 --> Language Class Initialized
INFO - 2021-12-16 08:13:05 --> Language Class Initialized
INFO - 2021-12-16 08:13:05 --> Config Class Initialized
INFO - 2021-12-16 08:13:05 --> Loader Class Initialized
INFO - 2021-12-16 08:13:05 --> Helper loaded: url_helper
INFO - 2021-12-16 08:13:05 --> Helper loaded: file_helper
INFO - 2021-12-16 08:13:05 --> Helper loaded: form_helper
INFO - 2021-12-16 08:13:05 --> Helper loaded: my_helper
INFO - 2021-12-16 08:13:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:13:05 --> Controller Class Initialized
DEBUG - 2021-12-16 08:13:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 08:13:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:13:05 --> Final output sent to browser
DEBUG - 2021-12-16 08:13:05 --> Total execution time: 0.0470
INFO - 2021-12-16 08:13:47 --> Config Class Initialized
INFO - 2021-12-16 08:13:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:13:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:13:47 --> Utf8 Class Initialized
INFO - 2021-12-16 08:13:47 --> URI Class Initialized
INFO - 2021-12-16 08:13:47 --> Router Class Initialized
INFO - 2021-12-16 08:13:47 --> Output Class Initialized
INFO - 2021-12-16 08:13:47 --> Security Class Initialized
DEBUG - 2021-12-16 08:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:13:47 --> Input Class Initialized
INFO - 2021-12-16 08:13:47 --> Language Class Initialized
INFO - 2021-12-16 08:13:47 --> Language Class Initialized
INFO - 2021-12-16 08:13:47 --> Config Class Initialized
INFO - 2021-12-16 08:13:47 --> Loader Class Initialized
INFO - 2021-12-16 08:13:47 --> Helper loaded: url_helper
INFO - 2021-12-16 08:13:47 --> Helper loaded: file_helper
INFO - 2021-12-16 08:13:47 --> Helper loaded: form_helper
INFO - 2021-12-16 08:13:47 --> Helper loaded: my_helper
INFO - 2021-12-16 08:13:47 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:13:47 --> Controller Class Initialized
INFO - 2021-12-16 08:13:47 --> Config Class Initialized
INFO - 2021-12-16 08:13:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:13:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:13:47 --> Utf8 Class Initialized
INFO - 2021-12-16 08:13:47 --> URI Class Initialized
INFO - 2021-12-16 08:13:47 --> Router Class Initialized
INFO - 2021-12-16 08:13:47 --> Output Class Initialized
INFO - 2021-12-16 08:13:47 --> Security Class Initialized
DEBUG - 2021-12-16 08:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:13:47 --> Input Class Initialized
INFO - 2021-12-16 08:13:47 --> Language Class Initialized
INFO - 2021-12-16 08:13:47 --> Language Class Initialized
INFO - 2021-12-16 08:13:47 --> Config Class Initialized
INFO - 2021-12-16 08:13:47 --> Loader Class Initialized
INFO - 2021-12-16 08:13:47 --> Helper loaded: url_helper
INFO - 2021-12-16 08:13:47 --> Helper loaded: file_helper
INFO - 2021-12-16 08:13:47 --> Helper loaded: form_helper
INFO - 2021-12-16 08:13:47 --> Helper loaded: my_helper
INFO - 2021-12-16 08:13:47 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:13:47 --> Controller Class Initialized
DEBUG - 2021-12-16 08:13:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:13:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:13:47 --> Final output sent to browser
DEBUG - 2021-12-16 08:13:47 --> Total execution time: 0.0460
INFO - 2021-12-16 08:13:54 --> Config Class Initialized
INFO - 2021-12-16 08:13:54 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:13:54 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:13:54 --> Utf8 Class Initialized
INFO - 2021-12-16 08:13:54 --> URI Class Initialized
INFO - 2021-12-16 08:13:54 --> Router Class Initialized
INFO - 2021-12-16 08:13:54 --> Output Class Initialized
INFO - 2021-12-16 08:13:54 --> Security Class Initialized
DEBUG - 2021-12-16 08:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:13:54 --> Input Class Initialized
INFO - 2021-12-16 08:13:54 --> Language Class Initialized
INFO - 2021-12-16 08:13:54 --> Language Class Initialized
INFO - 2021-12-16 08:13:54 --> Config Class Initialized
INFO - 2021-12-16 08:13:54 --> Loader Class Initialized
INFO - 2021-12-16 08:13:54 --> Helper loaded: url_helper
INFO - 2021-12-16 08:13:54 --> Helper loaded: file_helper
INFO - 2021-12-16 08:13:54 --> Helper loaded: form_helper
INFO - 2021-12-16 08:13:54 --> Helper loaded: my_helper
INFO - 2021-12-16 08:13:54 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:13:54 --> Controller Class Initialized
DEBUG - 2021-12-16 08:13:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 08:13:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:13:54 --> Final output sent to browser
DEBUG - 2021-12-16 08:13:54 --> Total execution time: 0.0430
INFO - 2021-12-16 08:14:25 --> Config Class Initialized
INFO - 2021-12-16 08:14:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:14:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:14:25 --> Utf8 Class Initialized
INFO - 2021-12-16 08:14:25 --> URI Class Initialized
INFO - 2021-12-16 08:14:25 --> Router Class Initialized
INFO - 2021-12-16 08:14:25 --> Output Class Initialized
INFO - 2021-12-16 08:14:25 --> Security Class Initialized
DEBUG - 2021-12-16 08:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:14:25 --> Input Class Initialized
INFO - 2021-12-16 08:14:25 --> Language Class Initialized
INFO - 2021-12-16 08:14:25 --> Language Class Initialized
INFO - 2021-12-16 08:14:25 --> Config Class Initialized
INFO - 2021-12-16 08:14:25 --> Loader Class Initialized
INFO - 2021-12-16 08:14:25 --> Helper loaded: url_helper
INFO - 2021-12-16 08:14:25 --> Helper loaded: file_helper
INFO - 2021-12-16 08:14:25 --> Helper loaded: form_helper
INFO - 2021-12-16 08:14:25 --> Helper loaded: my_helper
INFO - 2021-12-16 08:14:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:14:25 --> Controller Class Initialized
INFO - 2021-12-16 08:14:25 --> Config Class Initialized
INFO - 2021-12-16 08:14:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:14:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:14:25 --> Utf8 Class Initialized
INFO - 2021-12-16 08:14:25 --> URI Class Initialized
INFO - 2021-12-16 08:14:25 --> Router Class Initialized
INFO - 2021-12-16 08:14:25 --> Output Class Initialized
INFO - 2021-12-16 08:14:25 --> Security Class Initialized
DEBUG - 2021-12-16 08:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:14:25 --> Input Class Initialized
INFO - 2021-12-16 08:14:25 --> Language Class Initialized
INFO - 2021-12-16 08:14:25 --> Language Class Initialized
INFO - 2021-12-16 08:14:25 --> Config Class Initialized
INFO - 2021-12-16 08:14:25 --> Loader Class Initialized
INFO - 2021-12-16 08:14:25 --> Helper loaded: url_helper
INFO - 2021-12-16 08:14:25 --> Helper loaded: file_helper
INFO - 2021-12-16 08:14:25 --> Helper loaded: form_helper
INFO - 2021-12-16 08:14:25 --> Helper loaded: my_helper
INFO - 2021-12-16 08:14:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:14:25 --> Controller Class Initialized
DEBUG - 2021-12-16 08:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:14:25 --> Final output sent to browser
DEBUG - 2021-12-16 08:14:25 --> Total execution time: 0.0450
INFO - 2021-12-16 08:15:00 --> Config Class Initialized
INFO - 2021-12-16 08:15:00 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:15:00 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:15:00 --> Utf8 Class Initialized
INFO - 2021-12-16 08:15:00 --> URI Class Initialized
INFO - 2021-12-16 08:15:00 --> Router Class Initialized
INFO - 2021-12-16 08:15:00 --> Output Class Initialized
INFO - 2021-12-16 08:15:00 --> Security Class Initialized
DEBUG - 2021-12-16 08:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:15:00 --> Input Class Initialized
INFO - 2021-12-16 08:15:00 --> Language Class Initialized
INFO - 2021-12-16 08:15:00 --> Language Class Initialized
INFO - 2021-12-16 08:15:00 --> Config Class Initialized
INFO - 2021-12-16 08:15:00 --> Loader Class Initialized
INFO - 2021-12-16 08:15:00 --> Helper loaded: url_helper
INFO - 2021-12-16 08:15:00 --> Helper loaded: file_helper
INFO - 2021-12-16 08:15:00 --> Helper loaded: form_helper
INFO - 2021-12-16 08:15:00 --> Helper loaded: my_helper
INFO - 2021-12-16 08:15:00 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:15:00 --> Controller Class Initialized
DEBUG - 2021-12-16 08:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 08:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:15:00 --> Final output sent to browser
DEBUG - 2021-12-16 08:15:00 --> Total execution time: 0.0460
INFO - 2021-12-16 08:15:24 --> Config Class Initialized
INFO - 2021-12-16 08:15:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:15:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:15:24 --> Utf8 Class Initialized
INFO - 2021-12-16 08:15:24 --> URI Class Initialized
INFO - 2021-12-16 08:15:24 --> Router Class Initialized
INFO - 2021-12-16 08:15:24 --> Output Class Initialized
INFO - 2021-12-16 08:15:24 --> Security Class Initialized
DEBUG - 2021-12-16 08:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:15:24 --> Input Class Initialized
INFO - 2021-12-16 08:15:24 --> Language Class Initialized
INFO - 2021-12-16 08:15:24 --> Language Class Initialized
INFO - 2021-12-16 08:15:24 --> Config Class Initialized
INFO - 2021-12-16 08:15:24 --> Loader Class Initialized
INFO - 2021-12-16 08:15:24 --> Helper loaded: url_helper
INFO - 2021-12-16 08:15:24 --> Helper loaded: file_helper
INFO - 2021-12-16 08:15:24 --> Helper loaded: form_helper
INFO - 2021-12-16 08:15:24 --> Helper loaded: my_helper
INFO - 2021-12-16 08:15:24 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:15:24 --> Controller Class Initialized
INFO - 2021-12-16 08:15:24 --> Config Class Initialized
INFO - 2021-12-16 08:15:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:15:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:15:24 --> Utf8 Class Initialized
INFO - 2021-12-16 08:15:24 --> URI Class Initialized
INFO - 2021-12-16 08:15:24 --> Router Class Initialized
INFO - 2021-12-16 08:15:24 --> Output Class Initialized
INFO - 2021-12-16 08:15:24 --> Security Class Initialized
DEBUG - 2021-12-16 08:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:15:24 --> Input Class Initialized
INFO - 2021-12-16 08:15:24 --> Language Class Initialized
INFO - 2021-12-16 08:15:24 --> Language Class Initialized
INFO - 2021-12-16 08:15:24 --> Config Class Initialized
INFO - 2021-12-16 08:15:24 --> Loader Class Initialized
INFO - 2021-12-16 08:15:24 --> Helper loaded: url_helper
INFO - 2021-12-16 08:15:24 --> Helper loaded: file_helper
INFO - 2021-12-16 08:15:24 --> Helper loaded: form_helper
INFO - 2021-12-16 08:15:24 --> Helper loaded: my_helper
INFO - 2021-12-16 08:15:24 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:15:24 --> Controller Class Initialized
DEBUG - 2021-12-16 08:15:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:15:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:15:24 --> Final output sent to browser
DEBUG - 2021-12-16 08:15:24 --> Total execution time: 0.0490
INFO - 2021-12-16 08:15:36 --> Config Class Initialized
INFO - 2021-12-16 08:15:36 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:15:36 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:15:36 --> Utf8 Class Initialized
INFO - 2021-12-16 08:15:36 --> URI Class Initialized
INFO - 2021-12-16 08:15:36 --> Router Class Initialized
INFO - 2021-12-16 08:15:36 --> Output Class Initialized
INFO - 2021-12-16 08:15:36 --> Security Class Initialized
DEBUG - 2021-12-16 08:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:15:36 --> Input Class Initialized
INFO - 2021-12-16 08:15:36 --> Language Class Initialized
INFO - 2021-12-16 08:15:36 --> Language Class Initialized
INFO - 2021-12-16 08:15:36 --> Config Class Initialized
INFO - 2021-12-16 08:15:36 --> Loader Class Initialized
INFO - 2021-12-16 08:15:36 --> Helper loaded: url_helper
INFO - 2021-12-16 08:15:36 --> Helper loaded: file_helper
INFO - 2021-12-16 08:15:36 --> Helper loaded: form_helper
INFO - 2021-12-16 08:15:36 --> Helper loaded: my_helper
INFO - 2021-12-16 08:15:36 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:15:36 --> Controller Class Initialized
DEBUG - 2021-12-16 08:15:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 08:15:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:15:37 --> Final output sent to browser
DEBUG - 2021-12-16 08:15:37 --> Total execution time: 0.0520
INFO - 2021-12-16 08:16:21 --> Config Class Initialized
INFO - 2021-12-16 08:16:21 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:16:21 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:16:21 --> Utf8 Class Initialized
INFO - 2021-12-16 08:16:21 --> URI Class Initialized
INFO - 2021-12-16 08:16:21 --> Router Class Initialized
INFO - 2021-12-16 08:16:21 --> Output Class Initialized
INFO - 2021-12-16 08:16:21 --> Security Class Initialized
DEBUG - 2021-12-16 08:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:16:21 --> Input Class Initialized
INFO - 2021-12-16 08:16:21 --> Language Class Initialized
INFO - 2021-12-16 08:16:21 --> Language Class Initialized
INFO - 2021-12-16 08:16:21 --> Config Class Initialized
INFO - 2021-12-16 08:16:21 --> Loader Class Initialized
INFO - 2021-12-16 08:16:21 --> Helper loaded: url_helper
INFO - 2021-12-16 08:16:21 --> Helper loaded: file_helper
INFO - 2021-12-16 08:16:21 --> Helper loaded: form_helper
INFO - 2021-12-16 08:16:21 --> Helper loaded: my_helper
INFO - 2021-12-16 08:16:21 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:16:21 --> Controller Class Initialized
INFO - 2021-12-16 08:16:21 --> Config Class Initialized
INFO - 2021-12-16 08:16:21 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:16:21 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:16:21 --> Utf8 Class Initialized
INFO - 2021-12-16 08:16:21 --> URI Class Initialized
INFO - 2021-12-16 08:16:21 --> Router Class Initialized
INFO - 2021-12-16 08:16:21 --> Output Class Initialized
INFO - 2021-12-16 08:16:21 --> Security Class Initialized
DEBUG - 2021-12-16 08:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:16:21 --> Input Class Initialized
INFO - 2021-12-16 08:16:21 --> Language Class Initialized
INFO - 2021-12-16 08:16:21 --> Language Class Initialized
INFO - 2021-12-16 08:16:21 --> Config Class Initialized
INFO - 2021-12-16 08:16:21 --> Loader Class Initialized
INFO - 2021-12-16 08:16:21 --> Helper loaded: url_helper
INFO - 2021-12-16 08:16:21 --> Helper loaded: file_helper
INFO - 2021-12-16 08:16:21 --> Helper loaded: form_helper
INFO - 2021-12-16 08:16:21 --> Helper loaded: my_helper
INFO - 2021-12-16 08:16:21 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:16:21 --> Controller Class Initialized
DEBUG - 2021-12-16 08:16:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:16:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:16:21 --> Final output sent to browser
DEBUG - 2021-12-16 08:16:21 --> Total execution time: 0.0450
INFO - 2021-12-16 08:16:34 --> Config Class Initialized
INFO - 2021-12-16 08:16:34 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:16:34 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:16:34 --> Utf8 Class Initialized
INFO - 2021-12-16 08:16:34 --> URI Class Initialized
INFO - 2021-12-16 08:16:34 --> Router Class Initialized
INFO - 2021-12-16 08:16:34 --> Output Class Initialized
INFO - 2021-12-16 08:16:34 --> Security Class Initialized
DEBUG - 2021-12-16 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:16:34 --> Input Class Initialized
INFO - 2021-12-16 08:16:34 --> Language Class Initialized
INFO - 2021-12-16 08:16:34 --> Language Class Initialized
INFO - 2021-12-16 08:16:34 --> Config Class Initialized
INFO - 2021-12-16 08:16:34 --> Loader Class Initialized
INFO - 2021-12-16 08:16:34 --> Helper loaded: url_helper
INFO - 2021-12-16 08:16:34 --> Helper loaded: file_helper
INFO - 2021-12-16 08:16:34 --> Helper loaded: form_helper
INFO - 2021-12-16 08:16:34 --> Helper loaded: my_helper
INFO - 2021-12-16 08:16:34 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:16:34 --> Controller Class Initialized
DEBUG - 2021-12-16 08:16:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-16 08:16:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:16:34 --> Final output sent to browser
DEBUG - 2021-12-16 08:16:34 --> Total execution time: 0.0530
INFO - 2021-12-16 08:17:13 --> Config Class Initialized
INFO - 2021-12-16 08:17:13 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:17:13 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:17:13 --> Utf8 Class Initialized
INFO - 2021-12-16 08:17:13 --> URI Class Initialized
INFO - 2021-12-16 08:17:13 --> Router Class Initialized
INFO - 2021-12-16 08:17:13 --> Output Class Initialized
INFO - 2021-12-16 08:17:13 --> Security Class Initialized
DEBUG - 2021-12-16 08:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:17:13 --> Input Class Initialized
INFO - 2021-12-16 08:17:13 --> Language Class Initialized
INFO - 2021-12-16 08:17:13 --> Language Class Initialized
INFO - 2021-12-16 08:17:13 --> Config Class Initialized
INFO - 2021-12-16 08:17:13 --> Loader Class Initialized
INFO - 2021-12-16 08:17:13 --> Helper loaded: url_helper
INFO - 2021-12-16 08:17:13 --> Helper loaded: file_helper
INFO - 2021-12-16 08:17:13 --> Helper loaded: form_helper
INFO - 2021-12-16 08:17:13 --> Helper loaded: my_helper
INFO - 2021-12-16 08:17:13 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:17:13 --> Controller Class Initialized
INFO - 2021-12-16 08:17:13 --> Config Class Initialized
INFO - 2021-12-16 08:17:13 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:17:13 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:17:13 --> Utf8 Class Initialized
INFO - 2021-12-16 08:17:13 --> URI Class Initialized
INFO - 2021-12-16 08:17:13 --> Router Class Initialized
INFO - 2021-12-16 08:17:13 --> Output Class Initialized
INFO - 2021-12-16 08:17:13 --> Security Class Initialized
DEBUG - 2021-12-16 08:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:17:13 --> Input Class Initialized
INFO - 2021-12-16 08:17:13 --> Language Class Initialized
INFO - 2021-12-16 08:17:13 --> Language Class Initialized
INFO - 2021-12-16 08:17:13 --> Config Class Initialized
INFO - 2021-12-16 08:17:13 --> Loader Class Initialized
INFO - 2021-12-16 08:17:13 --> Helper loaded: url_helper
INFO - 2021-12-16 08:17:13 --> Helper loaded: file_helper
INFO - 2021-12-16 08:17:13 --> Helper loaded: form_helper
INFO - 2021-12-16 08:17:13 --> Helper loaded: my_helper
INFO - 2021-12-16 08:17:13 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:17:13 --> Controller Class Initialized
DEBUG - 2021-12-16 08:17:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:17:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:17:13 --> Final output sent to browser
DEBUG - 2021-12-16 08:17:13 --> Total execution time: 0.0470
INFO - 2021-12-16 08:17:58 --> Config Class Initialized
INFO - 2021-12-16 08:17:58 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:17:58 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:17:58 --> Utf8 Class Initialized
INFO - 2021-12-16 08:17:58 --> URI Class Initialized
INFO - 2021-12-16 08:17:58 --> Router Class Initialized
INFO - 2021-12-16 08:17:58 --> Output Class Initialized
INFO - 2021-12-16 08:17:58 --> Security Class Initialized
DEBUG - 2021-12-16 08:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:17:58 --> Input Class Initialized
INFO - 2021-12-16 08:17:58 --> Language Class Initialized
INFO - 2021-12-16 08:17:58 --> Language Class Initialized
INFO - 2021-12-16 08:17:58 --> Config Class Initialized
INFO - 2021-12-16 08:17:58 --> Loader Class Initialized
INFO - 2021-12-16 08:17:58 --> Helper loaded: url_helper
INFO - 2021-12-16 08:17:58 --> Helper loaded: file_helper
INFO - 2021-12-16 08:17:58 --> Helper loaded: form_helper
INFO - 2021-12-16 08:17:58 --> Helper loaded: my_helper
INFO - 2021-12-16 08:17:58 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:17:58 --> Controller Class Initialized
DEBUG - 2021-12-16 08:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-12-16 08:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:17:58 --> Final output sent to browser
DEBUG - 2021-12-16 08:17:58 --> Total execution time: 0.0490
INFO - 2021-12-16 08:17:58 --> Config Class Initialized
INFO - 2021-12-16 08:17:58 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:17:58 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:17:58 --> Utf8 Class Initialized
INFO - 2021-12-16 08:17:58 --> URI Class Initialized
INFO - 2021-12-16 08:17:58 --> Router Class Initialized
INFO - 2021-12-16 08:17:58 --> Output Class Initialized
INFO - 2021-12-16 08:17:58 --> Security Class Initialized
DEBUG - 2021-12-16 08:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:17:58 --> Input Class Initialized
INFO - 2021-12-16 08:17:58 --> Language Class Initialized
INFO - 2021-12-16 08:17:58 --> Language Class Initialized
INFO - 2021-12-16 08:17:58 --> Config Class Initialized
INFO - 2021-12-16 08:17:58 --> Loader Class Initialized
INFO - 2021-12-16 08:17:58 --> Helper loaded: url_helper
INFO - 2021-12-16 08:17:58 --> Helper loaded: file_helper
INFO - 2021-12-16 08:17:58 --> Helper loaded: form_helper
INFO - 2021-12-16 08:17:58 --> Helper loaded: my_helper
INFO - 2021-12-16 08:17:58 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:17:58 --> Controller Class Initialized
INFO - 2021-12-16 08:18:08 --> Config Class Initialized
INFO - 2021-12-16 08:18:08 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:08 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:08 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:08 --> URI Class Initialized
INFO - 2021-12-16 08:18:08 --> Router Class Initialized
INFO - 2021-12-16 08:18:08 --> Output Class Initialized
INFO - 2021-12-16 08:18:08 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:08 --> Input Class Initialized
INFO - 2021-12-16 08:18:08 --> Language Class Initialized
INFO - 2021-12-16 08:18:08 --> Language Class Initialized
INFO - 2021-12-16 08:18:08 --> Config Class Initialized
INFO - 2021-12-16 08:18:08 --> Loader Class Initialized
INFO - 2021-12-16 08:18:08 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:08 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:08 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:08 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:08 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:08 --> Controller Class Initialized
INFO - 2021-12-16 08:18:08 --> Final output sent to browser
DEBUG - 2021-12-16 08:18:08 --> Total execution time: 0.0450
INFO - 2021-12-16 08:18:20 --> Config Class Initialized
INFO - 2021-12-16 08:18:20 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:20 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:20 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:20 --> URI Class Initialized
INFO - 2021-12-16 08:18:20 --> Router Class Initialized
INFO - 2021-12-16 08:18:20 --> Output Class Initialized
INFO - 2021-12-16 08:18:20 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:20 --> Input Class Initialized
INFO - 2021-12-16 08:18:20 --> Language Class Initialized
INFO - 2021-12-16 08:18:20 --> Language Class Initialized
INFO - 2021-12-16 08:18:20 --> Config Class Initialized
INFO - 2021-12-16 08:18:20 --> Loader Class Initialized
INFO - 2021-12-16 08:18:20 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:20 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:20 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:20 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:20 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:20 --> Controller Class Initialized
INFO - 2021-12-16 08:18:20 --> Final output sent to browser
DEBUG - 2021-12-16 08:18:20 --> Total execution time: 0.0500
INFO - 2021-12-16 08:18:20 --> Config Class Initialized
INFO - 2021-12-16 08:18:20 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:20 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:20 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:20 --> URI Class Initialized
INFO - 2021-12-16 08:18:20 --> Router Class Initialized
INFO - 2021-12-16 08:18:20 --> Output Class Initialized
INFO - 2021-12-16 08:18:20 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:20 --> Input Class Initialized
INFO - 2021-12-16 08:18:20 --> Language Class Initialized
INFO - 2021-12-16 08:18:20 --> Language Class Initialized
INFO - 2021-12-16 08:18:20 --> Config Class Initialized
INFO - 2021-12-16 08:18:20 --> Loader Class Initialized
INFO - 2021-12-16 08:18:20 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:20 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:20 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:20 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:20 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:20 --> Controller Class Initialized
INFO - 2021-12-16 08:18:24 --> Config Class Initialized
INFO - 2021-12-16 08:18:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:24 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:24 --> URI Class Initialized
INFO - 2021-12-16 08:18:24 --> Router Class Initialized
INFO - 2021-12-16 08:18:24 --> Output Class Initialized
INFO - 2021-12-16 08:18:24 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:24 --> Input Class Initialized
INFO - 2021-12-16 08:18:24 --> Language Class Initialized
INFO - 2021-12-16 08:18:24 --> Language Class Initialized
INFO - 2021-12-16 08:18:24 --> Config Class Initialized
INFO - 2021-12-16 08:18:24 --> Loader Class Initialized
INFO - 2021-12-16 08:18:24 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:24 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:24 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:24 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:24 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:24 --> Controller Class Initialized
INFO - 2021-12-16 08:18:24 --> Final output sent to browser
DEBUG - 2021-12-16 08:18:24 --> Total execution time: 0.0460
INFO - 2021-12-16 08:18:30 --> Config Class Initialized
INFO - 2021-12-16 08:18:30 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:30 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:30 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:30 --> URI Class Initialized
INFO - 2021-12-16 08:18:30 --> Router Class Initialized
INFO - 2021-12-16 08:18:30 --> Output Class Initialized
INFO - 2021-12-16 08:18:30 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:30 --> Input Class Initialized
INFO - 2021-12-16 08:18:30 --> Language Class Initialized
INFO - 2021-12-16 08:18:30 --> Language Class Initialized
INFO - 2021-12-16 08:18:30 --> Config Class Initialized
INFO - 2021-12-16 08:18:30 --> Loader Class Initialized
INFO - 2021-12-16 08:18:30 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:30 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:30 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:30 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:30 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:30 --> Controller Class Initialized
INFO - 2021-12-16 08:18:30 --> Final output sent to browser
DEBUG - 2021-12-16 08:18:30 --> Total execution time: 0.0500
INFO - 2021-12-16 08:18:30 --> Config Class Initialized
INFO - 2021-12-16 08:18:30 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:30 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:30 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:30 --> URI Class Initialized
INFO - 2021-12-16 08:18:30 --> Router Class Initialized
INFO - 2021-12-16 08:18:30 --> Output Class Initialized
INFO - 2021-12-16 08:18:30 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:30 --> Input Class Initialized
INFO - 2021-12-16 08:18:30 --> Language Class Initialized
INFO - 2021-12-16 08:18:30 --> Language Class Initialized
INFO - 2021-12-16 08:18:30 --> Config Class Initialized
INFO - 2021-12-16 08:18:30 --> Loader Class Initialized
INFO - 2021-12-16 08:18:30 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:30 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:30 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:30 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:30 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:30 --> Controller Class Initialized
INFO - 2021-12-16 08:18:32 --> Config Class Initialized
INFO - 2021-12-16 08:18:32 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:32 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:32 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:32 --> URI Class Initialized
INFO - 2021-12-16 08:18:32 --> Router Class Initialized
INFO - 2021-12-16 08:18:32 --> Output Class Initialized
INFO - 2021-12-16 08:18:32 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:32 --> Input Class Initialized
INFO - 2021-12-16 08:18:32 --> Language Class Initialized
INFO - 2021-12-16 08:18:32 --> Language Class Initialized
INFO - 2021-12-16 08:18:32 --> Config Class Initialized
INFO - 2021-12-16 08:18:32 --> Loader Class Initialized
INFO - 2021-12-16 08:18:32 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:32 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:32 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:32 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:32 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:32 --> Controller Class Initialized
INFO - 2021-12-16 08:18:32 --> Final output sent to browser
DEBUG - 2021-12-16 08:18:32 --> Total execution time: 0.0470
INFO - 2021-12-16 08:18:43 --> Config Class Initialized
INFO - 2021-12-16 08:18:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:43 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:43 --> URI Class Initialized
INFO - 2021-12-16 08:18:43 --> Router Class Initialized
INFO - 2021-12-16 08:18:43 --> Output Class Initialized
INFO - 2021-12-16 08:18:43 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:43 --> Input Class Initialized
INFO - 2021-12-16 08:18:43 --> Language Class Initialized
INFO - 2021-12-16 08:18:43 --> Language Class Initialized
INFO - 2021-12-16 08:18:43 --> Config Class Initialized
INFO - 2021-12-16 08:18:43 --> Loader Class Initialized
INFO - 2021-12-16 08:18:43 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:43 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:43 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:43 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:43 --> Controller Class Initialized
INFO - 2021-12-16 08:18:43 --> Final output sent to browser
DEBUG - 2021-12-16 08:18:43 --> Total execution time: 0.0380
INFO - 2021-12-16 08:18:43 --> Config Class Initialized
INFO - 2021-12-16 08:18:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:43 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:43 --> URI Class Initialized
INFO - 2021-12-16 08:18:43 --> Router Class Initialized
INFO - 2021-12-16 08:18:43 --> Output Class Initialized
INFO - 2021-12-16 08:18:43 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:43 --> Input Class Initialized
INFO - 2021-12-16 08:18:43 --> Language Class Initialized
INFO - 2021-12-16 08:18:43 --> Language Class Initialized
INFO - 2021-12-16 08:18:43 --> Config Class Initialized
INFO - 2021-12-16 08:18:43 --> Loader Class Initialized
INFO - 2021-12-16 08:18:43 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:43 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:43 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:43 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:43 --> Controller Class Initialized
INFO - 2021-12-16 08:18:45 --> Config Class Initialized
INFO - 2021-12-16 08:18:45 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:45 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:45 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:45 --> URI Class Initialized
INFO - 2021-12-16 08:18:45 --> Router Class Initialized
INFO - 2021-12-16 08:18:45 --> Output Class Initialized
INFO - 2021-12-16 08:18:45 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:45 --> Input Class Initialized
INFO - 2021-12-16 08:18:45 --> Language Class Initialized
INFO - 2021-12-16 08:18:45 --> Language Class Initialized
INFO - 2021-12-16 08:18:45 --> Config Class Initialized
INFO - 2021-12-16 08:18:45 --> Loader Class Initialized
INFO - 2021-12-16 08:18:45 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:45 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:45 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:45 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:45 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:45 --> Controller Class Initialized
INFO - 2021-12-16 08:18:45 --> Final output sent to browser
DEBUG - 2021-12-16 08:18:45 --> Total execution time: 0.0510
INFO - 2021-12-16 08:18:54 --> Config Class Initialized
INFO - 2021-12-16 08:18:54 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:54 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:54 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:54 --> URI Class Initialized
INFO - 2021-12-16 08:18:54 --> Router Class Initialized
INFO - 2021-12-16 08:18:54 --> Output Class Initialized
INFO - 2021-12-16 08:18:54 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:54 --> Input Class Initialized
INFO - 2021-12-16 08:18:54 --> Language Class Initialized
INFO - 2021-12-16 08:18:54 --> Language Class Initialized
INFO - 2021-12-16 08:18:54 --> Config Class Initialized
INFO - 2021-12-16 08:18:54 --> Loader Class Initialized
INFO - 2021-12-16 08:18:54 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:54 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:54 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:54 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:54 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:54 --> Controller Class Initialized
INFO - 2021-12-16 08:18:54 --> Final output sent to browser
DEBUG - 2021-12-16 08:18:54 --> Total execution time: 0.0520
INFO - 2021-12-16 08:18:54 --> Config Class Initialized
INFO - 2021-12-16 08:18:54 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:54 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:54 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:54 --> URI Class Initialized
INFO - 2021-12-16 08:18:54 --> Router Class Initialized
INFO - 2021-12-16 08:18:54 --> Output Class Initialized
INFO - 2021-12-16 08:18:54 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:54 --> Input Class Initialized
INFO - 2021-12-16 08:18:54 --> Language Class Initialized
INFO - 2021-12-16 08:18:54 --> Language Class Initialized
INFO - 2021-12-16 08:18:54 --> Config Class Initialized
INFO - 2021-12-16 08:18:54 --> Loader Class Initialized
INFO - 2021-12-16 08:18:54 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:54 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:54 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:54 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:54 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:54 --> Controller Class Initialized
INFO - 2021-12-16 08:18:56 --> Config Class Initialized
INFO - 2021-12-16 08:18:56 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:18:56 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:18:56 --> Utf8 Class Initialized
INFO - 2021-12-16 08:18:56 --> URI Class Initialized
INFO - 2021-12-16 08:18:56 --> Router Class Initialized
INFO - 2021-12-16 08:18:56 --> Output Class Initialized
INFO - 2021-12-16 08:18:56 --> Security Class Initialized
DEBUG - 2021-12-16 08:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:18:56 --> Input Class Initialized
INFO - 2021-12-16 08:18:56 --> Language Class Initialized
INFO - 2021-12-16 08:18:56 --> Language Class Initialized
INFO - 2021-12-16 08:18:56 --> Config Class Initialized
INFO - 2021-12-16 08:18:56 --> Loader Class Initialized
INFO - 2021-12-16 08:18:56 --> Helper loaded: url_helper
INFO - 2021-12-16 08:18:56 --> Helper loaded: file_helper
INFO - 2021-12-16 08:18:56 --> Helper loaded: form_helper
INFO - 2021-12-16 08:18:56 --> Helper loaded: my_helper
INFO - 2021-12-16 08:18:56 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:18:56 --> Controller Class Initialized
INFO - 2021-12-16 08:18:56 --> Final output sent to browser
DEBUG - 2021-12-16 08:18:56 --> Total execution time: 0.0460
INFO - 2021-12-16 08:19:09 --> Config Class Initialized
INFO - 2021-12-16 08:19:09 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:09 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:09 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:09 --> URI Class Initialized
INFO - 2021-12-16 08:19:09 --> Router Class Initialized
INFO - 2021-12-16 08:19:09 --> Output Class Initialized
INFO - 2021-12-16 08:19:09 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:09 --> Input Class Initialized
INFO - 2021-12-16 08:19:09 --> Language Class Initialized
INFO - 2021-12-16 08:19:09 --> Language Class Initialized
INFO - 2021-12-16 08:19:09 --> Config Class Initialized
INFO - 2021-12-16 08:19:09 --> Loader Class Initialized
INFO - 2021-12-16 08:19:09 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:09 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:09 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:09 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:09 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:09 --> Controller Class Initialized
INFO - 2021-12-16 08:19:09 --> Final output sent to browser
DEBUG - 2021-12-16 08:19:09 --> Total execution time: 0.0540
INFO - 2021-12-16 08:19:09 --> Config Class Initialized
INFO - 2021-12-16 08:19:09 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:09 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:09 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:09 --> URI Class Initialized
INFO - 2021-12-16 08:19:09 --> Router Class Initialized
INFO - 2021-12-16 08:19:09 --> Output Class Initialized
INFO - 2021-12-16 08:19:09 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:09 --> Input Class Initialized
INFO - 2021-12-16 08:19:09 --> Language Class Initialized
INFO - 2021-12-16 08:19:09 --> Language Class Initialized
INFO - 2021-12-16 08:19:09 --> Config Class Initialized
INFO - 2021-12-16 08:19:09 --> Loader Class Initialized
INFO - 2021-12-16 08:19:09 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:09 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:09 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:09 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:09 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:09 --> Controller Class Initialized
INFO - 2021-12-16 08:19:12 --> Config Class Initialized
INFO - 2021-12-16 08:19:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:12 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:12 --> URI Class Initialized
INFO - 2021-12-16 08:19:12 --> Router Class Initialized
INFO - 2021-12-16 08:19:12 --> Output Class Initialized
INFO - 2021-12-16 08:19:12 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:12 --> Input Class Initialized
INFO - 2021-12-16 08:19:12 --> Language Class Initialized
INFO - 2021-12-16 08:19:12 --> Language Class Initialized
INFO - 2021-12-16 08:19:12 --> Config Class Initialized
INFO - 2021-12-16 08:19:12 --> Loader Class Initialized
INFO - 2021-12-16 08:19:12 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:12 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:12 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:12 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:12 --> Controller Class Initialized
INFO - 2021-12-16 08:19:12 --> Final output sent to browser
DEBUG - 2021-12-16 08:19:12 --> Total execution time: 0.0410
INFO - 2021-12-16 08:19:25 --> Config Class Initialized
INFO - 2021-12-16 08:19:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:25 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:25 --> URI Class Initialized
INFO - 2021-12-16 08:19:25 --> Router Class Initialized
INFO - 2021-12-16 08:19:25 --> Output Class Initialized
INFO - 2021-12-16 08:19:25 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:25 --> Input Class Initialized
INFO - 2021-12-16 08:19:25 --> Language Class Initialized
INFO - 2021-12-16 08:19:25 --> Language Class Initialized
INFO - 2021-12-16 08:19:25 --> Config Class Initialized
INFO - 2021-12-16 08:19:25 --> Loader Class Initialized
INFO - 2021-12-16 08:19:25 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:25 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:25 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:25 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:25 --> Controller Class Initialized
INFO - 2021-12-16 08:19:25 --> Final output sent to browser
DEBUG - 2021-12-16 08:19:25 --> Total execution time: 0.0540
INFO - 2021-12-16 08:19:25 --> Config Class Initialized
INFO - 2021-12-16 08:19:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:25 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:25 --> URI Class Initialized
INFO - 2021-12-16 08:19:25 --> Router Class Initialized
INFO - 2021-12-16 08:19:25 --> Output Class Initialized
INFO - 2021-12-16 08:19:25 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:25 --> Input Class Initialized
INFO - 2021-12-16 08:19:25 --> Language Class Initialized
INFO - 2021-12-16 08:19:25 --> Language Class Initialized
INFO - 2021-12-16 08:19:25 --> Config Class Initialized
INFO - 2021-12-16 08:19:25 --> Loader Class Initialized
INFO - 2021-12-16 08:19:25 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:25 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:25 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:25 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:25 --> Controller Class Initialized
INFO - 2021-12-16 08:19:26 --> Config Class Initialized
INFO - 2021-12-16 08:19:26 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:26 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:26 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:26 --> URI Class Initialized
INFO - 2021-12-16 08:19:26 --> Router Class Initialized
INFO - 2021-12-16 08:19:26 --> Output Class Initialized
INFO - 2021-12-16 08:19:26 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:26 --> Input Class Initialized
INFO - 2021-12-16 08:19:26 --> Language Class Initialized
INFO - 2021-12-16 08:19:26 --> Language Class Initialized
INFO - 2021-12-16 08:19:26 --> Config Class Initialized
INFO - 2021-12-16 08:19:26 --> Loader Class Initialized
INFO - 2021-12-16 08:19:26 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:26 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:26 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:26 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:26 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:26 --> Controller Class Initialized
INFO - 2021-12-16 08:19:26 --> Final output sent to browser
DEBUG - 2021-12-16 08:19:26 --> Total execution time: 0.0460
INFO - 2021-12-16 08:19:43 --> Config Class Initialized
INFO - 2021-12-16 08:19:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:43 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:43 --> URI Class Initialized
INFO - 2021-12-16 08:19:43 --> Router Class Initialized
INFO - 2021-12-16 08:19:43 --> Output Class Initialized
INFO - 2021-12-16 08:19:43 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:43 --> Input Class Initialized
INFO - 2021-12-16 08:19:43 --> Language Class Initialized
INFO - 2021-12-16 08:19:43 --> Language Class Initialized
INFO - 2021-12-16 08:19:43 --> Config Class Initialized
INFO - 2021-12-16 08:19:43 --> Loader Class Initialized
INFO - 2021-12-16 08:19:43 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:43 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:43 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:43 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:43 --> Controller Class Initialized
INFO - 2021-12-16 08:19:43 --> Final output sent to browser
DEBUG - 2021-12-16 08:19:43 --> Total execution time: 0.0550
INFO - 2021-12-16 08:19:43 --> Config Class Initialized
INFO - 2021-12-16 08:19:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:43 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:43 --> URI Class Initialized
INFO - 2021-12-16 08:19:43 --> Router Class Initialized
INFO - 2021-12-16 08:19:43 --> Output Class Initialized
INFO - 2021-12-16 08:19:43 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:43 --> Input Class Initialized
INFO - 2021-12-16 08:19:43 --> Language Class Initialized
INFO - 2021-12-16 08:19:43 --> Language Class Initialized
INFO - 2021-12-16 08:19:43 --> Config Class Initialized
INFO - 2021-12-16 08:19:43 --> Loader Class Initialized
INFO - 2021-12-16 08:19:43 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:43 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:43 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:43 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:43 --> Controller Class Initialized
INFO - 2021-12-16 08:19:47 --> Config Class Initialized
INFO - 2021-12-16 08:19:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:47 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:47 --> URI Class Initialized
INFO - 2021-12-16 08:19:47 --> Router Class Initialized
INFO - 2021-12-16 08:19:47 --> Output Class Initialized
INFO - 2021-12-16 08:19:47 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:47 --> Input Class Initialized
INFO - 2021-12-16 08:19:47 --> Language Class Initialized
INFO - 2021-12-16 08:19:47 --> Language Class Initialized
INFO - 2021-12-16 08:19:47 --> Config Class Initialized
INFO - 2021-12-16 08:19:47 --> Loader Class Initialized
INFO - 2021-12-16 08:19:47 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:47 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:47 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:47 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:47 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:47 --> Controller Class Initialized
INFO - 2021-12-16 08:19:47 --> Final output sent to browser
DEBUG - 2021-12-16 08:19:47 --> Total execution time: 0.0470
INFO - 2021-12-16 08:19:51 --> Config Class Initialized
INFO - 2021-12-16 08:19:51 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:51 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:51 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:51 --> URI Class Initialized
INFO - 2021-12-16 08:19:51 --> Router Class Initialized
INFO - 2021-12-16 08:19:51 --> Output Class Initialized
INFO - 2021-12-16 08:19:51 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:51 --> Input Class Initialized
INFO - 2021-12-16 08:19:51 --> Language Class Initialized
INFO - 2021-12-16 08:19:51 --> Language Class Initialized
INFO - 2021-12-16 08:19:51 --> Config Class Initialized
INFO - 2021-12-16 08:19:51 --> Loader Class Initialized
INFO - 2021-12-16 08:19:51 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:51 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:51 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:51 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:51 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:51 --> Controller Class Initialized
INFO - 2021-12-16 08:19:51 --> Final output sent to browser
DEBUG - 2021-12-16 08:19:51 --> Total execution time: 0.0510
INFO - 2021-12-16 08:19:51 --> Config Class Initialized
INFO - 2021-12-16 08:19:51 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:51 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:51 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:51 --> URI Class Initialized
INFO - 2021-12-16 08:19:51 --> Router Class Initialized
INFO - 2021-12-16 08:19:51 --> Output Class Initialized
INFO - 2021-12-16 08:19:51 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:51 --> Input Class Initialized
INFO - 2021-12-16 08:19:51 --> Language Class Initialized
INFO - 2021-12-16 08:19:51 --> Language Class Initialized
INFO - 2021-12-16 08:19:51 --> Config Class Initialized
INFO - 2021-12-16 08:19:51 --> Loader Class Initialized
INFO - 2021-12-16 08:19:51 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:51 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:51 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:51 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:51 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:51 --> Controller Class Initialized
INFO - 2021-12-16 08:19:54 --> Config Class Initialized
INFO - 2021-12-16 08:19:54 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:19:54 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:19:54 --> Utf8 Class Initialized
INFO - 2021-12-16 08:19:54 --> URI Class Initialized
INFO - 2021-12-16 08:19:54 --> Router Class Initialized
INFO - 2021-12-16 08:19:54 --> Output Class Initialized
INFO - 2021-12-16 08:19:54 --> Security Class Initialized
DEBUG - 2021-12-16 08:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:19:54 --> Input Class Initialized
INFO - 2021-12-16 08:19:54 --> Language Class Initialized
INFO - 2021-12-16 08:19:54 --> Language Class Initialized
INFO - 2021-12-16 08:19:54 --> Config Class Initialized
INFO - 2021-12-16 08:19:54 --> Loader Class Initialized
INFO - 2021-12-16 08:19:54 --> Helper loaded: url_helper
INFO - 2021-12-16 08:19:54 --> Helper loaded: file_helper
INFO - 2021-12-16 08:19:54 --> Helper loaded: form_helper
INFO - 2021-12-16 08:19:54 --> Helper loaded: my_helper
INFO - 2021-12-16 08:19:54 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:19:54 --> Controller Class Initialized
INFO - 2021-12-16 08:19:54 --> Final output sent to browser
DEBUG - 2021-12-16 08:19:54 --> Total execution time: 0.0480
INFO - 2021-12-16 08:20:04 --> Config Class Initialized
INFO - 2021-12-16 08:20:04 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:20:04 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:20:04 --> Utf8 Class Initialized
INFO - 2021-12-16 08:20:04 --> URI Class Initialized
INFO - 2021-12-16 08:20:04 --> Router Class Initialized
INFO - 2021-12-16 08:20:04 --> Output Class Initialized
INFO - 2021-12-16 08:20:04 --> Security Class Initialized
DEBUG - 2021-12-16 08:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:20:04 --> Input Class Initialized
INFO - 2021-12-16 08:20:04 --> Language Class Initialized
INFO - 2021-12-16 08:20:04 --> Language Class Initialized
INFO - 2021-12-16 08:20:04 --> Config Class Initialized
INFO - 2021-12-16 08:20:04 --> Loader Class Initialized
INFO - 2021-12-16 08:20:04 --> Helper loaded: url_helper
INFO - 2021-12-16 08:20:04 --> Helper loaded: file_helper
INFO - 2021-12-16 08:20:04 --> Helper loaded: form_helper
INFO - 2021-12-16 08:20:04 --> Helper loaded: my_helper
INFO - 2021-12-16 08:20:04 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:20:04 --> Controller Class Initialized
INFO - 2021-12-16 08:20:04 --> Final output sent to browser
DEBUG - 2021-12-16 08:20:04 --> Total execution time: 0.0470
INFO - 2021-12-16 08:20:04 --> Config Class Initialized
INFO - 2021-12-16 08:20:04 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:20:04 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:20:04 --> Utf8 Class Initialized
INFO - 2021-12-16 08:20:04 --> URI Class Initialized
INFO - 2021-12-16 08:20:04 --> Router Class Initialized
INFO - 2021-12-16 08:20:04 --> Output Class Initialized
INFO - 2021-12-16 08:20:04 --> Security Class Initialized
DEBUG - 2021-12-16 08:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:20:04 --> Input Class Initialized
INFO - 2021-12-16 08:20:04 --> Language Class Initialized
INFO - 2021-12-16 08:20:04 --> Language Class Initialized
INFO - 2021-12-16 08:20:04 --> Config Class Initialized
INFO - 2021-12-16 08:20:04 --> Loader Class Initialized
INFO - 2021-12-16 08:20:04 --> Helper loaded: url_helper
INFO - 2021-12-16 08:20:04 --> Helper loaded: file_helper
INFO - 2021-12-16 08:20:04 --> Helper loaded: form_helper
INFO - 2021-12-16 08:20:04 --> Helper loaded: my_helper
INFO - 2021-12-16 08:20:04 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:20:04 --> Controller Class Initialized
INFO - 2021-12-16 08:26:31 --> Config Class Initialized
INFO - 2021-12-16 08:26:31 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:26:31 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:26:31 --> Utf8 Class Initialized
INFO - 2021-12-16 08:26:31 --> URI Class Initialized
INFO - 2021-12-16 08:26:31 --> Router Class Initialized
INFO - 2021-12-16 08:26:31 --> Output Class Initialized
INFO - 2021-12-16 08:26:31 --> Security Class Initialized
DEBUG - 2021-12-16 08:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:26:31 --> Input Class Initialized
INFO - 2021-12-16 08:26:31 --> Language Class Initialized
INFO - 2021-12-16 08:26:31 --> Language Class Initialized
INFO - 2021-12-16 08:26:31 --> Config Class Initialized
INFO - 2021-12-16 08:26:31 --> Loader Class Initialized
INFO - 2021-12-16 08:26:31 --> Helper loaded: url_helper
INFO - 2021-12-16 08:26:31 --> Helper loaded: file_helper
INFO - 2021-12-16 08:26:31 --> Helper loaded: form_helper
INFO - 2021-12-16 08:26:31 --> Helper loaded: my_helper
INFO - 2021-12-16 08:26:31 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:26:31 --> Controller Class Initialized
INFO - 2021-12-16 08:26:31 --> Final output sent to browser
DEBUG - 2021-12-16 08:26:31 --> Total execution time: 0.0330
INFO - 2021-12-16 08:27:12 --> Config Class Initialized
INFO - 2021-12-16 08:27:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:27:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:27:12 --> Utf8 Class Initialized
INFO - 2021-12-16 08:27:12 --> URI Class Initialized
INFO - 2021-12-16 08:27:12 --> Router Class Initialized
INFO - 2021-12-16 08:27:12 --> Output Class Initialized
INFO - 2021-12-16 08:27:12 --> Security Class Initialized
DEBUG - 2021-12-16 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:27:12 --> Input Class Initialized
INFO - 2021-12-16 08:27:12 --> Language Class Initialized
INFO - 2021-12-16 08:27:12 --> Language Class Initialized
INFO - 2021-12-16 08:27:12 --> Config Class Initialized
INFO - 2021-12-16 08:27:12 --> Loader Class Initialized
INFO - 2021-12-16 08:27:12 --> Helper loaded: url_helper
INFO - 2021-12-16 08:27:12 --> Helper loaded: file_helper
INFO - 2021-12-16 08:27:12 --> Helper loaded: form_helper
INFO - 2021-12-16 08:27:12 --> Helper loaded: my_helper
INFO - 2021-12-16 08:27:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:27:12 --> Controller Class Initialized
DEBUG - 2021-12-16 08:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-16 08:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:27:12 --> Final output sent to browser
DEBUG - 2021-12-16 08:27:12 --> Total execution time: 0.0540
INFO - 2021-12-16 08:27:12 --> Config Class Initialized
INFO - 2021-12-16 08:27:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:27:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:27:12 --> Utf8 Class Initialized
INFO - 2021-12-16 08:27:12 --> URI Class Initialized
INFO - 2021-12-16 08:27:12 --> Router Class Initialized
INFO - 2021-12-16 08:27:12 --> Output Class Initialized
INFO - 2021-12-16 08:27:12 --> Security Class Initialized
DEBUG - 2021-12-16 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:27:12 --> Input Class Initialized
INFO - 2021-12-16 08:27:12 --> Language Class Initialized
INFO - 2021-12-16 08:27:12 --> Language Class Initialized
INFO - 2021-12-16 08:27:12 --> Config Class Initialized
INFO - 2021-12-16 08:27:12 --> Loader Class Initialized
INFO - 2021-12-16 08:27:12 --> Helper loaded: url_helper
INFO - 2021-12-16 08:27:12 --> Helper loaded: file_helper
INFO - 2021-12-16 08:27:12 --> Helper loaded: form_helper
INFO - 2021-12-16 08:27:12 --> Helper loaded: my_helper
INFO - 2021-12-16 08:27:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:27:12 --> Controller Class Initialized
INFO - 2021-12-16 08:27:17 --> Config Class Initialized
INFO - 2021-12-16 08:27:17 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:27:17 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:27:17 --> Utf8 Class Initialized
INFO - 2021-12-16 08:27:17 --> URI Class Initialized
INFO - 2021-12-16 08:27:17 --> Router Class Initialized
INFO - 2021-12-16 08:27:17 --> Output Class Initialized
INFO - 2021-12-16 08:27:17 --> Security Class Initialized
DEBUG - 2021-12-16 08:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:27:17 --> Input Class Initialized
INFO - 2021-12-16 08:27:17 --> Language Class Initialized
INFO - 2021-12-16 08:27:17 --> Language Class Initialized
INFO - 2021-12-16 08:27:17 --> Config Class Initialized
INFO - 2021-12-16 08:27:17 --> Loader Class Initialized
INFO - 2021-12-16 08:27:17 --> Helper loaded: url_helper
INFO - 2021-12-16 08:27:17 --> Helper loaded: file_helper
INFO - 2021-12-16 08:27:17 --> Helper loaded: form_helper
INFO - 2021-12-16 08:27:17 --> Helper loaded: my_helper
INFO - 2021-12-16 08:27:17 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:27:17 --> Controller Class Initialized
INFO - 2021-12-16 08:27:17 --> Final output sent to browser
DEBUG - 2021-12-16 08:27:17 --> Total execution time: 0.0500
INFO - 2021-12-16 08:27:26 --> Config Class Initialized
INFO - 2021-12-16 08:27:26 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:27:26 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:27:26 --> Utf8 Class Initialized
INFO - 2021-12-16 08:27:26 --> URI Class Initialized
INFO - 2021-12-16 08:27:26 --> Router Class Initialized
INFO - 2021-12-16 08:27:26 --> Output Class Initialized
INFO - 2021-12-16 08:27:26 --> Security Class Initialized
DEBUG - 2021-12-16 08:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:27:26 --> Input Class Initialized
INFO - 2021-12-16 08:27:26 --> Language Class Initialized
INFO - 2021-12-16 08:27:26 --> Language Class Initialized
INFO - 2021-12-16 08:27:26 --> Config Class Initialized
INFO - 2021-12-16 08:27:26 --> Loader Class Initialized
INFO - 2021-12-16 08:27:26 --> Helper loaded: url_helper
INFO - 2021-12-16 08:27:26 --> Helper loaded: file_helper
INFO - 2021-12-16 08:27:26 --> Helper loaded: form_helper
INFO - 2021-12-16 08:27:26 --> Helper loaded: my_helper
INFO - 2021-12-16 08:27:26 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:27:26 --> Controller Class Initialized
INFO - 2021-12-16 08:27:26 --> Final output sent to browser
DEBUG - 2021-12-16 08:27:26 --> Total execution time: 0.0500
INFO - 2021-12-16 08:27:53 --> Config Class Initialized
INFO - 2021-12-16 08:27:53 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:27:53 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:27:53 --> Utf8 Class Initialized
INFO - 2021-12-16 08:27:53 --> URI Class Initialized
INFO - 2021-12-16 08:27:53 --> Router Class Initialized
INFO - 2021-12-16 08:27:53 --> Output Class Initialized
INFO - 2021-12-16 08:27:53 --> Security Class Initialized
DEBUG - 2021-12-16 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:27:53 --> Input Class Initialized
INFO - 2021-12-16 08:27:53 --> Language Class Initialized
INFO - 2021-12-16 08:27:53 --> Language Class Initialized
INFO - 2021-12-16 08:27:53 --> Config Class Initialized
INFO - 2021-12-16 08:27:53 --> Loader Class Initialized
INFO - 2021-12-16 08:27:53 --> Helper loaded: url_helper
INFO - 2021-12-16 08:27:53 --> Helper loaded: file_helper
INFO - 2021-12-16 08:27:53 --> Helper loaded: form_helper
INFO - 2021-12-16 08:27:53 --> Helper loaded: my_helper
INFO - 2021-12-16 08:27:53 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:27:53 --> Controller Class Initialized
INFO - 2021-12-16 08:27:53 --> Final output sent to browser
DEBUG - 2021-12-16 08:27:53 --> Total execution time: 0.0490
INFO - 2021-12-16 08:27:53 --> Config Class Initialized
INFO - 2021-12-16 08:27:53 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:27:53 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:27:53 --> Utf8 Class Initialized
INFO - 2021-12-16 08:27:53 --> URI Class Initialized
INFO - 2021-12-16 08:27:53 --> Router Class Initialized
INFO - 2021-12-16 08:27:53 --> Output Class Initialized
INFO - 2021-12-16 08:27:53 --> Security Class Initialized
DEBUG - 2021-12-16 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:27:53 --> Input Class Initialized
INFO - 2021-12-16 08:27:53 --> Language Class Initialized
INFO - 2021-12-16 08:27:53 --> Language Class Initialized
INFO - 2021-12-16 08:27:53 --> Config Class Initialized
INFO - 2021-12-16 08:27:53 --> Loader Class Initialized
INFO - 2021-12-16 08:27:53 --> Helper loaded: url_helper
INFO - 2021-12-16 08:27:53 --> Helper loaded: file_helper
INFO - 2021-12-16 08:27:53 --> Helper loaded: form_helper
INFO - 2021-12-16 08:27:53 --> Helper loaded: my_helper
INFO - 2021-12-16 08:27:53 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:27:53 --> Controller Class Initialized
INFO - 2021-12-16 08:27:57 --> Config Class Initialized
INFO - 2021-12-16 08:27:57 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:27:57 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:27:57 --> Utf8 Class Initialized
INFO - 2021-12-16 08:27:57 --> URI Class Initialized
INFO - 2021-12-16 08:27:57 --> Router Class Initialized
INFO - 2021-12-16 08:27:57 --> Output Class Initialized
INFO - 2021-12-16 08:27:57 --> Security Class Initialized
DEBUG - 2021-12-16 08:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:27:57 --> Input Class Initialized
INFO - 2021-12-16 08:27:57 --> Language Class Initialized
INFO - 2021-12-16 08:27:57 --> Language Class Initialized
INFO - 2021-12-16 08:27:57 --> Config Class Initialized
INFO - 2021-12-16 08:27:57 --> Loader Class Initialized
INFO - 2021-12-16 08:27:57 --> Helper loaded: url_helper
INFO - 2021-12-16 08:27:57 --> Helper loaded: file_helper
INFO - 2021-12-16 08:27:57 --> Helper loaded: form_helper
INFO - 2021-12-16 08:27:57 --> Helper loaded: my_helper
INFO - 2021-12-16 08:27:57 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:27:57 --> Controller Class Initialized
DEBUG - 2021-12-16 08:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 08:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:27:57 --> Final output sent to browser
DEBUG - 2021-12-16 08:27:57 --> Total execution time: 0.0540
INFO - 2021-12-16 08:28:05 --> Config Class Initialized
INFO - 2021-12-16 08:28:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:28:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:28:05 --> Utf8 Class Initialized
INFO - 2021-12-16 08:28:05 --> URI Class Initialized
INFO - 2021-12-16 08:28:05 --> Router Class Initialized
INFO - 2021-12-16 08:28:05 --> Output Class Initialized
INFO - 2021-12-16 08:28:05 --> Security Class Initialized
DEBUG - 2021-12-16 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:28:05 --> Input Class Initialized
INFO - 2021-12-16 08:28:05 --> Language Class Initialized
INFO - 2021-12-16 08:28:05 --> Language Class Initialized
INFO - 2021-12-16 08:28:05 --> Config Class Initialized
INFO - 2021-12-16 08:28:05 --> Loader Class Initialized
INFO - 2021-12-16 08:28:05 --> Helper loaded: url_helper
INFO - 2021-12-16 08:28:05 --> Helper loaded: file_helper
INFO - 2021-12-16 08:28:05 --> Helper loaded: form_helper
INFO - 2021-12-16 08:28:05 --> Helper loaded: my_helper
INFO - 2021-12-16 08:28:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:28:06 --> Controller Class Initialized
DEBUG - 2021-12-16 08:28:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-12-16 08:28:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 08:28:06 --> Final output sent to browser
DEBUG - 2021-12-16 08:28:06 --> Total execution time: 0.0420
INFO - 2021-12-16 08:28:06 --> Config Class Initialized
INFO - 2021-12-16 08:28:06 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:28:06 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:28:06 --> Utf8 Class Initialized
INFO - 2021-12-16 08:28:06 --> URI Class Initialized
INFO - 2021-12-16 08:28:06 --> Router Class Initialized
INFO - 2021-12-16 08:28:06 --> Output Class Initialized
INFO - 2021-12-16 08:28:06 --> Security Class Initialized
DEBUG - 2021-12-16 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:28:06 --> Input Class Initialized
INFO - 2021-12-16 08:28:06 --> Language Class Initialized
INFO - 2021-12-16 08:28:06 --> Language Class Initialized
INFO - 2021-12-16 08:28:06 --> Config Class Initialized
INFO - 2021-12-16 08:28:06 --> Loader Class Initialized
INFO - 2021-12-16 08:28:06 --> Helper loaded: url_helper
INFO - 2021-12-16 08:28:06 --> Helper loaded: file_helper
INFO - 2021-12-16 08:28:06 --> Helper loaded: form_helper
INFO - 2021-12-16 08:28:06 --> Helper loaded: my_helper
INFO - 2021-12-16 08:28:06 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:28:06 --> Controller Class Initialized
INFO - 2021-12-16 08:28:07 --> Config Class Initialized
INFO - 2021-12-16 08:28:07 --> Hooks Class Initialized
DEBUG - 2021-12-16 08:28:07 --> UTF-8 Support Enabled
INFO - 2021-12-16 08:28:07 --> Utf8 Class Initialized
INFO - 2021-12-16 08:28:07 --> URI Class Initialized
INFO - 2021-12-16 08:28:07 --> Router Class Initialized
INFO - 2021-12-16 08:28:07 --> Output Class Initialized
INFO - 2021-12-16 08:28:07 --> Security Class Initialized
DEBUG - 2021-12-16 08:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 08:28:07 --> Input Class Initialized
INFO - 2021-12-16 08:28:07 --> Language Class Initialized
INFO - 2021-12-16 08:28:07 --> Language Class Initialized
INFO - 2021-12-16 08:28:07 --> Config Class Initialized
INFO - 2021-12-16 08:28:07 --> Loader Class Initialized
INFO - 2021-12-16 08:28:07 --> Helper loaded: url_helper
INFO - 2021-12-16 08:28:07 --> Helper loaded: file_helper
INFO - 2021-12-16 08:28:07 --> Helper loaded: form_helper
INFO - 2021-12-16 08:28:07 --> Helper loaded: my_helper
INFO - 2021-12-16 08:28:07 --> Database Driver Class Initialized
DEBUG - 2021-12-16 08:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 08:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 08:28:07 --> Controller Class Initialized
INFO - 2021-12-16 08:28:07 --> Final output sent to browser
DEBUG - 2021-12-16 08:28:07 --> Total execution time: 0.0450
INFO - 2021-12-16 09:13:18 --> Config Class Initialized
INFO - 2021-12-16 09:13:18 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:18 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:18 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:18 --> URI Class Initialized
INFO - 2021-12-16 09:13:18 --> Router Class Initialized
INFO - 2021-12-16 09:13:18 --> Output Class Initialized
INFO - 2021-12-16 09:13:18 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:18 --> Input Class Initialized
INFO - 2021-12-16 09:13:18 --> Language Class Initialized
INFO - 2021-12-16 09:13:18 --> Language Class Initialized
INFO - 2021-12-16 09:13:18 --> Config Class Initialized
INFO - 2021-12-16 09:13:18 --> Loader Class Initialized
INFO - 2021-12-16 09:13:18 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:18 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:18 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:18 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:18 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:18 --> Controller Class Initialized
INFO - 2021-12-16 09:13:18 --> Final output sent to browser
DEBUG - 2021-12-16 09:13:18 --> Total execution time: 0.0500
INFO - 2021-12-16 09:13:18 --> Config Class Initialized
INFO - 2021-12-16 09:13:18 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:18 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:18 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:18 --> URI Class Initialized
INFO - 2021-12-16 09:13:18 --> Router Class Initialized
INFO - 2021-12-16 09:13:18 --> Output Class Initialized
INFO - 2021-12-16 09:13:18 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:18 --> Input Class Initialized
INFO - 2021-12-16 09:13:18 --> Language Class Initialized
INFO - 2021-12-16 09:13:18 --> Language Class Initialized
INFO - 2021-12-16 09:13:18 --> Config Class Initialized
INFO - 2021-12-16 09:13:18 --> Loader Class Initialized
INFO - 2021-12-16 09:13:18 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:18 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:18 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:18 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:18 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:18 --> Controller Class Initialized
INFO - 2021-12-16 09:13:24 --> Config Class Initialized
INFO - 2021-12-16 09:13:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:24 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:24 --> URI Class Initialized
INFO - 2021-12-16 09:13:24 --> Router Class Initialized
INFO - 2021-12-16 09:13:24 --> Output Class Initialized
INFO - 2021-12-16 09:13:24 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:24 --> Input Class Initialized
INFO - 2021-12-16 09:13:24 --> Language Class Initialized
INFO - 2021-12-16 09:13:24 --> Language Class Initialized
INFO - 2021-12-16 09:13:24 --> Config Class Initialized
INFO - 2021-12-16 09:13:24 --> Loader Class Initialized
INFO - 2021-12-16 09:13:24 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:24 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:24 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:24 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:24 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:24 --> Controller Class Initialized
DEBUG - 2021-12-16 09:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-16 09:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 09:13:24 --> Final output sent to browser
DEBUG - 2021-12-16 09:13:24 --> Total execution time: 0.0420
INFO - 2021-12-16 09:13:24 --> Config Class Initialized
INFO - 2021-12-16 09:13:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:24 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:24 --> URI Class Initialized
INFO - 2021-12-16 09:13:25 --> Router Class Initialized
INFO - 2021-12-16 09:13:25 --> Output Class Initialized
INFO - 2021-12-16 09:13:25 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:25 --> Input Class Initialized
INFO - 2021-12-16 09:13:25 --> Language Class Initialized
INFO - 2021-12-16 09:13:25 --> Language Class Initialized
INFO - 2021-12-16 09:13:25 --> Config Class Initialized
INFO - 2021-12-16 09:13:25 --> Loader Class Initialized
INFO - 2021-12-16 09:13:25 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:25 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:25 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:25 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:25 --> Controller Class Initialized
INFO - 2021-12-16 09:13:26 --> Config Class Initialized
INFO - 2021-12-16 09:13:26 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:26 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:26 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:26 --> URI Class Initialized
INFO - 2021-12-16 09:13:26 --> Router Class Initialized
INFO - 2021-12-16 09:13:26 --> Output Class Initialized
INFO - 2021-12-16 09:13:26 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:26 --> Input Class Initialized
INFO - 2021-12-16 09:13:26 --> Language Class Initialized
INFO - 2021-12-16 09:13:26 --> Language Class Initialized
INFO - 2021-12-16 09:13:26 --> Config Class Initialized
INFO - 2021-12-16 09:13:26 --> Loader Class Initialized
INFO - 2021-12-16 09:13:26 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:26 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:26 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:26 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:26 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:26 --> Controller Class Initialized
INFO - 2021-12-16 09:13:27 --> Config Class Initialized
INFO - 2021-12-16 09:13:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:27 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:27 --> URI Class Initialized
INFO - 2021-12-16 09:13:27 --> Router Class Initialized
INFO - 2021-12-16 09:13:27 --> Output Class Initialized
INFO - 2021-12-16 09:13:27 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:27 --> Input Class Initialized
INFO - 2021-12-16 09:13:27 --> Language Class Initialized
INFO - 2021-12-16 09:13:27 --> Language Class Initialized
INFO - 2021-12-16 09:13:27 --> Config Class Initialized
INFO - 2021-12-16 09:13:27 --> Loader Class Initialized
INFO - 2021-12-16 09:13:27 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:27 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:27 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:27 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:27 --> Controller Class Initialized
INFO - 2021-12-16 09:13:27 --> Config Class Initialized
INFO - 2021-12-16 09:13:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:27 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:27 --> URI Class Initialized
INFO - 2021-12-16 09:13:27 --> Router Class Initialized
INFO - 2021-12-16 09:13:27 --> Output Class Initialized
INFO - 2021-12-16 09:13:27 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:27 --> Input Class Initialized
INFO - 2021-12-16 09:13:27 --> Language Class Initialized
INFO - 2021-12-16 09:13:27 --> Language Class Initialized
INFO - 2021-12-16 09:13:27 --> Config Class Initialized
INFO - 2021-12-16 09:13:27 --> Loader Class Initialized
INFO - 2021-12-16 09:13:27 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:27 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:27 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:27 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:27 --> Controller Class Initialized
INFO - 2021-12-16 09:13:31 --> Config Class Initialized
INFO - 2021-12-16 09:13:31 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:31 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:31 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:31 --> URI Class Initialized
INFO - 2021-12-16 09:13:31 --> Router Class Initialized
INFO - 2021-12-16 09:13:31 --> Output Class Initialized
INFO - 2021-12-16 09:13:31 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:31 --> Input Class Initialized
INFO - 2021-12-16 09:13:31 --> Language Class Initialized
INFO - 2021-12-16 09:13:31 --> Language Class Initialized
INFO - 2021-12-16 09:13:31 --> Config Class Initialized
INFO - 2021-12-16 09:13:31 --> Loader Class Initialized
INFO - 2021-12-16 09:13:31 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:31 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:31 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:31 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:31 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:31 --> Controller Class Initialized
INFO - 2021-12-16 09:13:31 --> Final output sent to browser
DEBUG - 2021-12-16 09:13:31 --> Total execution time: 0.0380
INFO - 2021-12-16 09:13:42 --> Config Class Initialized
INFO - 2021-12-16 09:13:42 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:42 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:42 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:42 --> URI Class Initialized
INFO - 2021-12-16 09:13:42 --> Router Class Initialized
INFO - 2021-12-16 09:13:42 --> Output Class Initialized
INFO - 2021-12-16 09:13:42 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:42 --> Input Class Initialized
INFO - 2021-12-16 09:13:42 --> Language Class Initialized
INFO - 2021-12-16 09:13:43 --> Language Class Initialized
INFO - 2021-12-16 09:13:43 --> Config Class Initialized
INFO - 2021-12-16 09:13:43 --> Loader Class Initialized
INFO - 2021-12-16 09:13:43 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:43 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:43 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:43 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:43 --> Controller Class Initialized
INFO - 2021-12-16 09:13:43 --> Final output sent to browser
DEBUG - 2021-12-16 09:13:43 --> Total execution time: 0.0500
INFO - 2021-12-16 09:13:49 --> Config Class Initialized
INFO - 2021-12-16 09:13:49 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:49 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:49 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:49 --> URI Class Initialized
INFO - 2021-12-16 09:13:49 --> Router Class Initialized
INFO - 2021-12-16 09:13:49 --> Output Class Initialized
INFO - 2021-12-16 09:13:49 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:49 --> Input Class Initialized
INFO - 2021-12-16 09:13:49 --> Language Class Initialized
INFO - 2021-12-16 09:13:49 --> Language Class Initialized
INFO - 2021-12-16 09:13:49 --> Config Class Initialized
INFO - 2021-12-16 09:13:49 --> Loader Class Initialized
INFO - 2021-12-16 09:13:49 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:49 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:49 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:49 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:49 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:49 --> Controller Class Initialized
INFO - 2021-12-16 09:13:49 --> Final output sent to browser
DEBUG - 2021-12-16 09:13:49 --> Total execution time: 0.0510
INFO - 2021-12-16 09:13:49 --> Config Class Initialized
INFO - 2021-12-16 09:13:49 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:49 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:49 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:49 --> URI Class Initialized
INFO - 2021-12-16 09:13:49 --> Router Class Initialized
INFO - 2021-12-16 09:13:49 --> Output Class Initialized
INFO - 2021-12-16 09:13:49 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:49 --> Input Class Initialized
INFO - 2021-12-16 09:13:49 --> Language Class Initialized
INFO - 2021-12-16 09:13:49 --> Language Class Initialized
INFO - 2021-12-16 09:13:49 --> Config Class Initialized
INFO - 2021-12-16 09:13:49 --> Loader Class Initialized
INFO - 2021-12-16 09:13:49 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:49 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:49 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:49 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:49 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:49 --> Controller Class Initialized
INFO - 2021-12-16 09:13:55 --> Config Class Initialized
INFO - 2021-12-16 09:13:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:55 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:55 --> URI Class Initialized
INFO - 2021-12-16 09:13:55 --> Router Class Initialized
INFO - 2021-12-16 09:13:55 --> Output Class Initialized
INFO - 2021-12-16 09:13:55 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:55 --> Input Class Initialized
INFO - 2021-12-16 09:13:55 --> Language Class Initialized
INFO - 2021-12-16 09:13:55 --> Language Class Initialized
INFO - 2021-12-16 09:13:55 --> Config Class Initialized
INFO - 2021-12-16 09:13:55 --> Loader Class Initialized
INFO - 2021-12-16 09:13:55 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:55 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:55 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:55 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:55 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:55 --> Controller Class Initialized
INFO - 2021-12-16 09:13:55 --> Final output sent to browser
DEBUG - 2021-12-16 09:13:55 --> Total execution time: 0.0590
INFO - 2021-12-16 09:13:55 --> Config Class Initialized
INFO - 2021-12-16 09:13:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:13:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:13:55 --> Utf8 Class Initialized
INFO - 2021-12-16 09:13:55 --> URI Class Initialized
INFO - 2021-12-16 09:13:55 --> Router Class Initialized
INFO - 2021-12-16 09:13:55 --> Output Class Initialized
INFO - 2021-12-16 09:13:55 --> Security Class Initialized
DEBUG - 2021-12-16 09:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:13:55 --> Input Class Initialized
INFO - 2021-12-16 09:13:55 --> Language Class Initialized
INFO - 2021-12-16 09:13:55 --> Language Class Initialized
INFO - 2021-12-16 09:13:55 --> Config Class Initialized
INFO - 2021-12-16 09:13:55 --> Loader Class Initialized
INFO - 2021-12-16 09:13:55 --> Helper loaded: url_helper
INFO - 2021-12-16 09:13:55 --> Helper loaded: file_helper
INFO - 2021-12-16 09:13:55 --> Helper loaded: form_helper
INFO - 2021-12-16 09:13:55 --> Helper loaded: my_helper
INFO - 2021-12-16 09:13:55 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:13:55 --> Controller Class Initialized
INFO - 2021-12-16 09:14:03 --> Config Class Initialized
INFO - 2021-12-16 09:14:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:14:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:14:03 --> Utf8 Class Initialized
INFO - 2021-12-16 09:14:03 --> URI Class Initialized
INFO - 2021-12-16 09:14:03 --> Router Class Initialized
INFO - 2021-12-16 09:14:03 --> Output Class Initialized
INFO - 2021-12-16 09:14:03 --> Security Class Initialized
DEBUG - 2021-12-16 09:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:14:03 --> Input Class Initialized
INFO - 2021-12-16 09:14:03 --> Language Class Initialized
INFO - 2021-12-16 09:14:03 --> Language Class Initialized
INFO - 2021-12-16 09:14:03 --> Config Class Initialized
INFO - 2021-12-16 09:14:03 --> Loader Class Initialized
INFO - 2021-12-16 09:14:03 --> Helper loaded: url_helper
INFO - 2021-12-16 09:14:03 --> Helper loaded: file_helper
INFO - 2021-12-16 09:14:03 --> Helper loaded: form_helper
INFO - 2021-12-16 09:14:03 --> Helper loaded: my_helper
INFO - 2021-12-16 09:14:03 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:14:03 --> Controller Class Initialized
DEBUG - 2021-12-16 09:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-12-16 09:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 09:14:03 --> Final output sent to browser
DEBUG - 2021-12-16 09:14:03 --> Total execution time: 0.0520
INFO - 2021-12-16 09:14:03 --> Config Class Initialized
INFO - 2021-12-16 09:14:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:14:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:14:03 --> Utf8 Class Initialized
INFO - 2021-12-16 09:14:03 --> URI Class Initialized
INFO - 2021-12-16 09:14:03 --> Router Class Initialized
INFO - 2021-12-16 09:14:03 --> Output Class Initialized
INFO - 2021-12-16 09:14:03 --> Security Class Initialized
DEBUG - 2021-12-16 09:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:14:03 --> Input Class Initialized
INFO - 2021-12-16 09:14:03 --> Language Class Initialized
INFO - 2021-12-16 09:14:03 --> Language Class Initialized
INFO - 2021-12-16 09:14:03 --> Config Class Initialized
INFO - 2021-12-16 09:14:03 --> Loader Class Initialized
INFO - 2021-12-16 09:14:03 --> Helper loaded: url_helper
INFO - 2021-12-16 09:14:03 --> Helper loaded: file_helper
INFO - 2021-12-16 09:14:03 --> Helper loaded: form_helper
INFO - 2021-12-16 09:14:03 --> Helper loaded: my_helper
INFO - 2021-12-16 09:14:03 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:14:03 --> Controller Class Initialized
INFO - 2021-12-16 09:14:06 --> Config Class Initialized
INFO - 2021-12-16 09:14:06 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:14:06 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:14:06 --> Utf8 Class Initialized
INFO - 2021-12-16 09:14:06 --> URI Class Initialized
INFO - 2021-12-16 09:14:06 --> Router Class Initialized
INFO - 2021-12-16 09:14:06 --> Output Class Initialized
INFO - 2021-12-16 09:14:06 --> Security Class Initialized
DEBUG - 2021-12-16 09:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:14:06 --> Input Class Initialized
INFO - 2021-12-16 09:14:06 --> Language Class Initialized
INFO - 2021-12-16 09:14:06 --> Language Class Initialized
INFO - 2021-12-16 09:14:06 --> Config Class Initialized
INFO - 2021-12-16 09:14:06 --> Loader Class Initialized
INFO - 2021-12-16 09:14:06 --> Helper loaded: url_helper
INFO - 2021-12-16 09:14:06 --> Helper loaded: file_helper
INFO - 2021-12-16 09:14:06 --> Helper loaded: form_helper
INFO - 2021-12-16 09:14:06 --> Helper loaded: my_helper
INFO - 2021-12-16 09:14:06 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:14:06 --> Controller Class Initialized
INFO - 2021-12-16 09:14:06 --> Final output sent to browser
DEBUG - 2021-12-16 09:14:06 --> Total execution time: 0.0480
INFO - 2021-12-16 09:14:26 --> Config Class Initialized
INFO - 2021-12-16 09:14:26 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:14:26 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:14:26 --> Utf8 Class Initialized
INFO - 2021-12-16 09:14:26 --> URI Class Initialized
INFO - 2021-12-16 09:14:26 --> Router Class Initialized
INFO - 2021-12-16 09:14:26 --> Output Class Initialized
INFO - 2021-12-16 09:14:26 --> Security Class Initialized
DEBUG - 2021-12-16 09:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:14:26 --> Input Class Initialized
INFO - 2021-12-16 09:14:26 --> Language Class Initialized
INFO - 2021-12-16 09:14:26 --> Language Class Initialized
INFO - 2021-12-16 09:14:26 --> Config Class Initialized
INFO - 2021-12-16 09:14:26 --> Loader Class Initialized
INFO - 2021-12-16 09:14:26 --> Helper loaded: url_helper
INFO - 2021-12-16 09:14:26 --> Helper loaded: file_helper
INFO - 2021-12-16 09:14:26 --> Helper loaded: form_helper
INFO - 2021-12-16 09:14:26 --> Helper loaded: my_helper
INFO - 2021-12-16 09:14:26 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:14:26 --> Controller Class Initialized
INFO - 2021-12-16 09:14:26 --> Final output sent to browser
DEBUG - 2021-12-16 09:14:26 --> Total execution time: 0.0500
INFO - 2021-12-16 09:14:26 --> Config Class Initialized
INFO - 2021-12-16 09:14:26 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:14:26 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:14:26 --> Utf8 Class Initialized
INFO - 2021-12-16 09:14:26 --> URI Class Initialized
INFO - 2021-12-16 09:14:26 --> Router Class Initialized
INFO - 2021-12-16 09:14:26 --> Output Class Initialized
INFO - 2021-12-16 09:14:26 --> Security Class Initialized
DEBUG - 2021-12-16 09:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:14:26 --> Input Class Initialized
INFO - 2021-12-16 09:14:26 --> Language Class Initialized
INFO - 2021-12-16 09:14:26 --> Language Class Initialized
INFO - 2021-12-16 09:14:26 --> Config Class Initialized
INFO - 2021-12-16 09:14:26 --> Loader Class Initialized
INFO - 2021-12-16 09:14:26 --> Helper loaded: url_helper
INFO - 2021-12-16 09:14:26 --> Helper loaded: file_helper
INFO - 2021-12-16 09:14:26 --> Helper loaded: form_helper
INFO - 2021-12-16 09:14:26 --> Helper loaded: my_helper
INFO - 2021-12-16 09:14:26 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:14:26 --> Controller Class Initialized
INFO - 2021-12-16 09:14:28 --> Config Class Initialized
INFO - 2021-12-16 09:14:28 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:14:28 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:14:28 --> Utf8 Class Initialized
INFO - 2021-12-16 09:14:28 --> URI Class Initialized
INFO - 2021-12-16 09:14:28 --> Router Class Initialized
INFO - 2021-12-16 09:14:28 --> Output Class Initialized
INFO - 2021-12-16 09:14:28 --> Security Class Initialized
DEBUG - 2021-12-16 09:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:14:28 --> Input Class Initialized
INFO - 2021-12-16 09:14:28 --> Language Class Initialized
INFO - 2021-12-16 09:14:28 --> Language Class Initialized
INFO - 2021-12-16 09:14:28 --> Config Class Initialized
INFO - 2021-12-16 09:14:28 --> Loader Class Initialized
INFO - 2021-12-16 09:14:28 --> Helper loaded: url_helper
INFO - 2021-12-16 09:14:28 --> Helper loaded: file_helper
INFO - 2021-12-16 09:14:28 --> Helper loaded: form_helper
INFO - 2021-12-16 09:14:28 --> Helper loaded: my_helper
INFO - 2021-12-16 09:14:28 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:14:28 --> Controller Class Initialized
INFO - 2021-12-16 09:14:28 --> Final output sent to browser
DEBUG - 2021-12-16 09:14:28 --> Total execution time: 0.0460
INFO - 2021-12-16 09:14:43 --> Config Class Initialized
INFO - 2021-12-16 09:14:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:14:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:14:43 --> Utf8 Class Initialized
INFO - 2021-12-16 09:14:43 --> URI Class Initialized
INFO - 2021-12-16 09:14:43 --> Router Class Initialized
INFO - 2021-12-16 09:14:43 --> Output Class Initialized
INFO - 2021-12-16 09:14:43 --> Security Class Initialized
DEBUG - 2021-12-16 09:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:14:43 --> Input Class Initialized
INFO - 2021-12-16 09:14:43 --> Language Class Initialized
INFO - 2021-12-16 09:14:43 --> Language Class Initialized
INFO - 2021-12-16 09:14:43 --> Config Class Initialized
INFO - 2021-12-16 09:14:43 --> Loader Class Initialized
INFO - 2021-12-16 09:14:43 --> Helper loaded: url_helper
INFO - 2021-12-16 09:14:43 --> Helper loaded: file_helper
INFO - 2021-12-16 09:14:43 --> Helper loaded: form_helper
INFO - 2021-12-16 09:14:43 --> Helper loaded: my_helper
INFO - 2021-12-16 09:14:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:14:43 --> Controller Class Initialized
INFO - 2021-12-16 09:14:43 --> Final output sent to browser
DEBUG - 2021-12-16 09:14:43 --> Total execution time: 0.0560
INFO - 2021-12-16 09:14:43 --> Config Class Initialized
INFO - 2021-12-16 09:14:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:14:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:14:43 --> Utf8 Class Initialized
INFO - 2021-12-16 09:14:43 --> URI Class Initialized
INFO - 2021-12-16 09:14:43 --> Router Class Initialized
INFO - 2021-12-16 09:14:43 --> Output Class Initialized
INFO - 2021-12-16 09:14:43 --> Security Class Initialized
DEBUG - 2021-12-16 09:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:14:43 --> Input Class Initialized
INFO - 2021-12-16 09:14:43 --> Language Class Initialized
INFO - 2021-12-16 09:14:43 --> Language Class Initialized
INFO - 2021-12-16 09:14:43 --> Config Class Initialized
INFO - 2021-12-16 09:14:43 --> Loader Class Initialized
INFO - 2021-12-16 09:14:43 --> Helper loaded: url_helper
INFO - 2021-12-16 09:14:43 --> Helper loaded: file_helper
INFO - 2021-12-16 09:14:43 --> Helper loaded: form_helper
INFO - 2021-12-16 09:14:43 --> Helper loaded: my_helper
INFO - 2021-12-16 09:14:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:14:43 --> Controller Class Initialized
INFO - 2021-12-16 09:14:45 --> Config Class Initialized
INFO - 2021-12-16 09:14:45 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:14:45 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:14:45 --> Utf8 Class Initialized
INFO - 2021-12-16 09:14:45 --> URI Class Initialized
INFO - 2021-12-16 09:14:45 --> Router Class Initialized
INFO - 2021-12-16 09:14:45 --> Output Class Initialized
INFO - 2021-12-16 09:14:45 --> Security Class Initialized
DEBUG - 2021-12-16 09:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:14:45 --> Input Class Initialized
INFO - 2021-12-16 09:14:45 --> Language Class Initialized
INFO - 2021-12-16 09:14:45 --> Language Class Initialized
INFO - 2021-12-16 09:14:45 --> Config Class Initialized
INFO - 2021-12-16 09:14:45 --> Loader Class Initialized
INFO - 2021-12-16 09:14:45 --> Helper loaded: url_helper
INFO - 2021-12-16 09:14:45 --> Helper loaded: file_helper
INFO - 2021-12-16 09:14:45 --> Helper loaded: form_helper
INFO - 2021-12-16 09:14:45 --> Helper loaded: my_helper
INFO - 2021-12-16 09:14:45 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:14:45 --> Controller Class Initialized
INFO - 2021-12-16 09:14:45 --> Final output sent to browser
DEBUG - 2021-12-16 09:14:45 --> Total execution time: 0.0480
INFO - 2021-12-16 09:15:01 --> Config Class Initialized
INFO - 2021-12-16 09:15:01 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:01 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:01 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:01 --> URI Class Initialized
INFO - 2021-12-16 09:15:01 --> Router Class Initialized
INFO - 2021-12-16 09:15:01 --> Output Class Initialized
INFO - 2021-12-16 09:15:01 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:01 --> Input Class Initialized
INFO - 2021-12-16 09:15:01 --> Language Class Initialized
INFO - 2021-12-16 09:15:01 --> Language Class Initialized
INFO - 2021-12-16 09:15:01 --> Config Class Initialized
INFO - 2021-12-16 09:15:01 --> Loader Class Initialized
INFO - 2021-12-16 09:15:01 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:01 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:01 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:01 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:01 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:01 --> Controller Class Initialized
INFO - 2021-12-16 09:15:01 --> Final output sent to browser
DEBUG - 2021-12-16 09:15:01 --> Total execution time: 0.0480
INFO - 2021-12-16 09:15:01 --> Config Class Initialized
INFO - 2021-12-16 09:15:01 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:01 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:01 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:01 --> URI Class Initialized
INFO - 2021-12-16 09:15:01 --> Router Class Initialized
INFO - 2021-12-16 09:15:01 --> Output Class Initialized
INFO - 2021-12-16 09:15:01 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:01 --> Input Class Initialized
INFO - 2021-12-16 09:15:01 --> Language Class Initialized
INFO - 2021-12-16 09:15:01 --> Language Class Initialized
INFO - 2021-12-16 09:15:01 --> Config Class Initialized
INFO - 2021-12-16 09:15:01 --> Loader Class Initialized
INFO - 2021-12-16 09:15:01 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:01 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:01 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:01 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:01 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:01 --> Controller Class Initialized
INFO - 2021-12-16 09:15:03 --> Config Class Initialized
INFO - 2021-12-16 09:15:03 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:03 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:03 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:03 --> URI Class Initialized
INFO - 2021-12-16 09:15:03 --> Router Class Initialized
INFO - 2021-12-16 09:15:03 --> Output Class Initialized
INFO - 2021-12-16 09:15:03 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:03 --> Input Class Initialized
INFO - 2021-12-16 09:15:03 --> Language Class Initialized
INFO - 2021-12-16 09:15:03 --> Language Class Initialized
INFO - 2021-12-16 09:15:03 --> Config Class Initialized
INFO - 2021-12-16 09:15:03 --> Loader Class Initialized
INFO - 2021-12-16 09:15:03 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:03 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:03 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:03 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:03 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:03 --> Controller Class Initialized
INFO - 2021-12-16 09:15:03 --> Final output sent to browser
DEBUG - 2021-12-16 09:15:03 --> Total execution time: 0.0430
INFO - 2021-12-16 09:15:19 --> Config Class Initialized
INFO - 2021-12-16 09:15:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:19 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:19 --> URI Class Initialized
INFO - 2021-12-16 09:15:19 --> Router Class Initialized
INFO - 2021-12-16 09:15:19 --> Output Class Initialized
INFO - 2021-12-16 09:15:19 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:19 --> Input Class Initialized
INFO - 2021-12-16 09:15:19 --> Language Class Initialized
INFO - 2021-12-16 09:15:19 --> Language Class Initialized
INFO - 2021-12-16 09:15:19 --> Config Class Initialized
INFO - 2021-12-16 09:15:19 --> Loader Class Initialized
INFO - 2021-12-16 09:15:19 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:19 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:19 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:19 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:19 --> Controller Class Initialized
INFO - 2021-12-16 09:15:19 --> Final output sent to browser
DEBUG - 2021-12-16 09:15:19 --> Total execution time: 0.0540
INFO - 2021-12-16 09:15:19 --> Config Class Initialized
INFO - 2021-12-16 09:15:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:19 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:19 --> URI Class Initialized
INFO - 2021-12-16 09:15:19 --> Router Class Initialized
INFO - 2021-12-16 09:15:19 --> Output Class Initialized
INFO - 2021-12-16 09:15:19 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:19 --> Input Class Initialized
INFO - 2021-12-16 09:15:19 --> Language Class Initialized
INFO - 2021-12-16 09:15:19 --> Language Class Initialized
INFO - 2021-12-16 09:15:19 --> Config Class Initialized
INFO - 2021-12-16 09:15:19 --> Loader Class Initialized
INFO - 2021-12-16 09:15:19 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:19 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:19 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:19 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:19 --> Controller Class Initialized
INFO - 2021-12-16 09:15:20 --> Config Class Initialized
INFO - 2021-12-16 09:15:20 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:20 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:20 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:20 --> URI Class Initialized
INFO - 2021-12-16 09:15:20 --> Router Class Initialized
INFO - 2021-12-16 09:15:20 --> Output Class Initialized
INFO - 2021-12-16 09:15:20 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:20 --> Input Class Initialized
INFO - 2021-12-16 09:15:20 --> Language Class Initialized
INFO - 2021-12-16 09:15:20 --> Language Class Initialized
INFO - 2021-12-16 09:15:20 --> Config Class Initialized
INFO - 2021-12-16 09:15:20 --> Loader Class Initialized
INFO - 2021-12-16 09:15:20 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:20 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:20 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:20 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:20 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:20 --> Controller Class Initialized
INFO - 2021-12-16 09:15:20 --> Final output sent to browser
DEBUG - 2021-12-16 09:15:20 --> Total execution time: 0.0450
INFO - 2021-12-16 09:15:40 --> Config Class Initialized
INFO - 2021-12-16 09:15:40 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:40 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:40 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:40 --> URI Class Initialized
INFO - 2021-12-16 09:15:40 --> Router Class Initialized
INFO - 2021-12-16 09:15:40 --> Output Class Initialized
INFO - 2021-12-16 09:15:40 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:40 --> Input Class Initialized
INFO - 2021-12-16 09:15:40 --> Language Class Initialized
INFO - 2021-12-16 09:15:40 --> Language Class Initialized
INFO - 2021-12-16 09:15:40 --> Config Class Initialized
INFO - 2021-12-16 09:15:40 --> Loader Class Initialized
INFO - 2021-12-16 09:15:40 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:40 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:40 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:40 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:40 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:40 --> Controller Class Initialized
INFO - 2021-12-16 09:15:40 --> Final output sent to browser
DEBUG - 2021-12-16 09:15:40 --> Total execution time: 0.0470
INFO - 2021-12-16 09:15:40 --> Config Class Initialized
INFO - 2021-12-16 09:15:40 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:40 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:40 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:40 --> URI Class Initialized
INFO - 2021-12-16 09:15:40 --> Router Class Initialized
INFO - 2021-12-16 09:15:40 --> Output Class Initialized
INFO - 2021-12-16 09:15:40 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:40 --> Input Class Initialized
INFO - 2021-12-16 09:15:40 --> Language Class Initialized
INFO - 2021-12-16 09:15:40 --> Language Class Initialized
INFO - 2021-12-16 09:15:40 --> Config Class Initialized
INFO - 2021-12-16 09:15:40 --> Loader Class Initialized
INFO - 2021-12-16 09:15:40 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:40 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:40 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:40 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:40 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:40 --> Controller Class Initialized
INFO - 2021-12-16 09:15:41 --> Config Class Initialized
INFO - 2021-12-16 09:15:41 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:41 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:41 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:41 --> URI Class Initialized
INFO - 2021-12-16 09:15:41 --> Router Class Initialized
INFO - 2021-12-16 09:15:41 --> Output Class Initialized
INFO - 2021-12-16 09:15:41 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:41 --> Input Class Initialized
INFO - 2021-12-16 09:15:41 --> Language Class Initialized
INFO - 2021-12-16 09:15:41 --> Language Class Initialized
INFO - 2021-12-16 09:15:41 --> Config Class Initialized
INFO - 2021-12-16 09:15:41 --> Loader Class Initialized
INFO - 2021-12-16 09:15:41 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:41 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:41 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:41 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:41 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:41 --> Controller Class Initialized
INFO - 2021-12-16 09:15:41 --> Final output sent to browser
DEBUG - 2021-12-16 09:15:41 --> Total execution time: 0.0370
INFO - 2021-12-16 09:15:55 --> Config Class Initialized
INFO - 2021-12-16 09:15:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:55 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:55 --> URI Class Initialized
INFO - 2021-12-16 09:15:55 --> Router Class Initialized
INFO - 2021-12-16 09:15:55 --> Output Class Initialized
INFO - 2021-12-16 09:15:55 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:55 --> Input Class Initialized
INFO - 2021-12-16 09:15:55 --> Language Class Initialized
INFO - 2021-12-16 09:15:55 --> Language Class Initialized
INFO - 2021-12-16 09:15:55 --> Config Class Initialized
INFO - 2021-12-16 09:15:55 --> Loader Class Initialized
INFO - 2021-12-16 09:15:55 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:55 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:55 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:55 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:55 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:55 --> Controller Class Initialized
INFO - 2021-12-16 09:15:55 --> Final output sent to browser
DEBUG - 2021-12-16 09:15:55 --> Total execution time: 0.0550
INFO - 2021-12-16 09:15:55 --> Config Class Initialized
INFO - 2021-12-16 09:15:55 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:55 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:55 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:55 --> URI Class Initialized
INFO - 2021-12-16 09:15:55 --> Router Class Initialized
INFO - 2021-12-16 09:15:55 --> Output Class Initialized
INFO - 2021-12-16 09:15:55 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:55 --> Input Class Initialized
INFO - 2021-12-16 09:15:55 --> Language Class Initialized
INFO - 2021-12-16 09:15:55 --> Language Class Initialized
INFO - 2021-12-16 09:15:55 --> Config Class Initialized
INFO - 2021-12-16 09:15:55 --> Loader Class Initialized
INFO - 2021-12-16 09:15:55 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:55 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:55 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:55 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:55 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:55 --> Controller Class Initialized
INFO - 2021-12-16 09:15:58 --> Config Class Initialized
INFO - 2021-12-16 09:15:58 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:15:58 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:15:58 --> Utf8 Class Initialized
INFO - 2021-12-16 09:15:58 --> URI Class Initialized
INFO - 2021-12-16 09:15:58 --> Router Class Initialized
INFO - 2021-12-16 09:15:58 --> Output Class Initialized
INFO - 2021-12-16 09:15:58 --> Security Class Initialized
DEBUG - 2021-12-16 09:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:15:58 --> Input Class Initialized
INFO - 2021-12-16 09:15:58 --> Language Class Initialized
INFO - 2021-12-16 09:15:58 --> Language Class Initialized
INFO - 2021-12-16 09:15:58 --> Config Class Initialized
INFO - 2021-12-16 09:15:58 --> Loader Class Initialized
INFO - 2021-12-16 09:15:58 --> Helper loaded: url_helper
INFO - 2021-12-16 09:15:58 --> Helper loaded: file_helper
INFO - 2021-12-16 09:15:58 --> Helper loaded: form_helper
INFO - 2021-12-16 09:15:58 --> Helper loaded: my_helper
INFO - 2021-12-16 09:15:58 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:15:58 --> Controller Class Initialized
INFO - 2021-12-16 09:15:58 --> Final output sent to browser
DEBUG - 2021-12-16 09:15:58 --> Total execution time: 0.0590
INFO - 2021-12-16 09:16:05 --> Config Class Initialized
INFO - 2021-12-16 09:16:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:05 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:05 --> URI Class Initialized
INFO - 2021-12-16 09:16:05 --> Router Class Initialized
INFO - 2021-12-16 09:16:05 --> Output Class Initialized
INFO - 2021-12-16 09:16:05 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:05 --> Input Class Initialized
INFO - 2021-12-16 09:16:05 --> Language Class Initialized
INFO - 2021-12-16 09:16:05 --> Language Class Initialized
INFO - 2021-12-16 09:16:05 --> Config Class Initialized
INFO - 2021-12-16 09:16:05 --> Loader Class Initialized
INFO - 2021-12-16 09:16:05 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:05 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:05 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:05 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:05 --> Controller Class Initialized
INFO - 2021-12-16 09:16:05 --> Final output sent to browser
DEBUG - 2021-12-16 09:16:05 --> Total execution time: 0.0500
INFO - 2021-12-16 09:16:05 --> Config Class Initialized
INFO - 2021-12-16 09:16:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:05 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:05 --> URI Class Initialized
INFO - 2021-12-16 09:16:05 --> Router Class Initialized
INFO - 2021-12-16 09:16:05 --> Output Class Initialized
INFO - 2021-12-16 09:16:05 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:05 --> Input Class Initialized
INFO - 2021-12-16 09:16:05 --> Language Class Initialized
INFO - 2021-12-16 09:16:05 --> Language Class Initialized
INFO - 2021-12-16 09:16:05 --> Config Class Initialized
INFO - 2021-12-16 09:16:05 --> Loader Class Initialized
INFO - 2021-12-16 09:16:05 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:05 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:05 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:05 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:05 --> Controller Class Initialized
INFO - 2021-12-16 09:16:07 --> Config Class Initialized
INFO - 2021-12-16 09:16:07 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:07 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:07 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:07 --> URI Class Initialized
INFO - 2021-12-16 09:16:07 --> Router Class Initialized
INFO - 2021-12-16 09:16:07 --> Output Class Initialized
INFO - 2021-12-16 09:16:07 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:07 --> Input Class Initialized
INFO - 2021-12-16 09:16:07 --> Language Class Initialized
INFO - 2021-12-16 09:16:07 --> Language Class Initialized
INFO - 2021-12-16 09:16:07 --> Config Class Initialized
INFO - 2021-12-16 09:16:07 --> Loader Class Initialized
INFO - 2021-12-16 09:16:07 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:07 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:07 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:07 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:07 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:07 --> Controller Class Initialized
INFO - 2021-12-16 09:16:10 --> Config Class Initialized
INFO - 2021-12-16 09:16:10 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:10 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:10 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:10 --> URI Class Initialized
INFO - 2021-12-16 09:16:10 --> Router Class Initialized
INFO - 2021-12-16 09:16:10 --> Output Class Initialized
INFO - 2021-12-16 09:16:10 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:10 --> Input Class Initialized
INFO - 2021-12-16 09:16:10 --> Language Class Initialized
INFO - 2021-12-16 09:16:10 --> Language Class Initialized
INFO - 2021-12-16 09:16:10 --> Config Class Initialized
INFO - 2021-12-16 09:16:10 --> Loader Class Initialized
INFO - 2021-12-16 09:16:10 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:10 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:10 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:10 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:10 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:10 --> Controller Class Initialized
INFO - 2021-12-16 09:16:10 --> Final output sent to browser
DEBUG - 2021-12-16 09:16:10 --> Total execution time: 0.0500
INFO - 2021-12-16 09:16:43 --> Config Class Initialized
INFO - 2021-12-16 09:16:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:43 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:43 --> URI Class Initialized
INFO - 2021-12-16 09:16:43 --> Router Class Initialized
INFO - 2021-12-16 09:16:43 --> Output Class Initialized
INFO - 2021-12-16 09:16:43 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:43 --> Input Class Initialized
INFO - 2021-12-16 09:16:43 --> Language Class Initialized
INFO - 2021-12-16 09:16:43 --> Language Class Initialized
INFO - 2021-12-16 09:16:43 --> Config Class Initialized
INFO - 2021-12-16 09:16:43 --> Loader Class Initialized
INFO - 2021-12-16 09:16:43 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:43 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:43 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:43 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:43 --> Controller Class Initialized
INFO - 2021-12-16 09:16:43 --> Final output sent to browser
DEBUG - 2021-12-16 09:16:43 --> Total execution time: 0.0600
INFO - 2021-12-16 09:16:43 --> Config Class Initialized
INFO - 2021-12-16 09:16:43 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:43 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:43 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:43 --> URI Class Initialized
INFO - 2021-12-16 09:16:43 --> Router Class Initialized
INFO - 2021-12-16 09:16:43 --> Output Class Initialized
INFO - 2021-12-16 09:16:43 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:43 --> Input Class Initialized
INFO - 2021-12-16 09:16:43 --> Language Class Initialized
INFO - 2021-12-16 09:16:43 --> Language Class Initialized
INFO - 2021-12-16 09:16:43 --> Config Class Initialized
INFO - 2021-12-16 09:16:43 --> Loader Class Initialized
INFO - 2021-12-16 09:16:43 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:43 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:43 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:43 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:43 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:43 --> Controller Class Initialized
INFO - 2021-12-16 09:16:45 --> Config Class Initialized
INFO - 2021-12-16 09:16:45 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:45 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:45 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:45 --> URI Class Initialized
INFO - 2021-12-16 09:16:45 --> Router Class Initialized
INFO - 2021-12-16 09:16:45 --> Output Class Initialized
INFO - 2021-12-16 09:16:45 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:45 --> Input Class Initialized
INFO - 2021-12-16 09:16:45 --> Language Class Initialized
INFO - 2021-12-16 09:16:45 --> Language Class Initialized
INFO - 2021-12-16 09:16:45 --> Config Class Initialized
INFO - 2021-12-16 09:16:45 --> Loader Class Initialized
INFO - 2021-12-16 09:16:45 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:45 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:45 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:45 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:45 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:45 --> Controller Class Initialized
INFO - 2021-12-16 09:16:47 --> Config Class Initialized
INFO - 2021-12-16 09:16:47 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:47 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:47 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:47 --> URI Class Initialized
INFO - 2021-12-16 09:16:47 --> Router Class Initialized
INFO - 2021-12-16 09:16:47 --> Output Class Initialized
INFO - 2021-12-16 09:16:47 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:47 --> Input Class Initialized
INFO - 2021-12-16 09:16:47 --> Language Class Initialized
INFO - 2021-12-16 09:16:47 --> Language Class Initialized
INFO - 2021-12-16 09:16:47 --> Config Class Initialized
INFO - 2021-12-16 09:16:47 --> Loader Class Initialized
INFO - 2021-12-16 09:16:47 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:47 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:47 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:47 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:47 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:47 --> Controller Class Initialized
INFO - 2021-12-16 09:16:47 --> Final output sent to browser
DEBUG - 2021-12-16 09:16:47 --> Total execution time: 0.0520
INFO - 2021-12-16 09:16:58 --> Config Class Initialized
INFO - 2021-12-16 09:16:58 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:58 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:58 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:58 --> URI Class Initialized
INFO - 2021-12-16 09:16:58 --> Router Class Initialized
INFO - 2021-12-16 09:16:58 --> Output Class Initialized
INFO - 2021-12-16 09:16:58 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:58 --> Input Class Initialized
INFO - 2021-12-16 09:16:58 --> Language Class Initialized
INFO - 2021-12-16 09:16:58 --> Language Class Initialized
INFO - 2021-12-16 09:16:58 --> Config Class Initialized
INFO - 2021-12-16 09:16:58 --> Loader Class Initialized
INFO - 2021-12-16 09:16:58 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:58 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:58 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:58 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:58 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:58 --> Controller Class Initialized
INFO - 2021-12-16 09:16:58 --> Final output sent to browser
DEBUG - 2021-12-16 09:16:58 --> Total execution time: 0.0490
INFO - 2021-12-16 09:16:58 --> Config Class Initialized
INFO - 2021-12-16 09:16:58 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:58 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:58 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:58 --> URI Class Initialized
INFO - 2021-12-16 09:16:58 --> Router Class Initialized
INFO - 2021-12-16 09:16:58 --> Output Class Initialized
INFO - 2021-12-16 09:16:58 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:58 --> Input Class Initialized
INFO - 2021-12-16 09:16:58 --> Language Class Initialized
INFO - 2021-12-16 09:16:58 --> Language Class Initialized
INFO - 2021-12-16 09:16:58 --> Config Class Initialized
INFO - 2021-12-16 09:16:58 --> Loader Class Initialized
INFO - 2021-12-16 09:16:58 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:58 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:58 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:58 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:58 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:58 --> Controller Class Initialized
INFO - 2021-12-16 09:16:59 --> Config Class Initialized
INFO - 2021-12-16 09:16:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:16:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:16:59 --> Utf8 Class Initialized
INFO - 2021-12-16 09:16:59 --> URI Class Initialized
INFO - 2021-12-16 09:16:59 --> Router Class Initialized
INFO - 2021-12-16 09:16:59 --> Output Class Initialized
INFO - 2021-12-16 09:16:59 --> Security Class Initialized
DEBUG - 2021-12-16 09:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:16:59 --> Input Class Initialized
INFO - 2021-12-16 09:16:59 --> Language Class Initialized
INFO - 2021-12-16 09:16:59 --> Language Class Initialized
INFO - 2021-12-16 09:16:59 --> Config Class Initialized
INFO - 2021-12-16 09:16:59 --> Loader Class Initialized
INFO - 2021-12-16 09:16:59 --> Helper loaded: url_helper
INFO - 2021-12-16 09:16:59 --> Helper loaded: file_helper
INFO - 2021-12-16 09:16:59 --> Helper loaded: form_helper
INFO - 2021-12-16 09:16:59 --> Helper loaded: my_helper
INFO - 2021-12-16 09:16:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:16:59 --> Controller Class Initialized
INFO - 2021-12-16 09:16:59 --> Final output sent to browser
DEBUG - 2021-12-16 09:16:59 --> Total execution time: 0.0450
INFO - 2021-12-16 09:17:11 --> Config Class Initialized
INFO - 2021-12-16 09:17:11 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:11 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:11 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:11 --> URI Class Initialized
INFO - 2021-12-16 09:17:11 --> Router Class Initialized
INFO - 2021-12-16 09:17:11 --> Output Class Initialized
INFO - 2021-12-16 09:17:11 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:11 --> Input Class Initialized
INFO - 2021-12-16 09:17:11 --> Language Class Initialized
INFO - 2021-12-16 09:17:11 --> Language Class Initialized
INFO - 2021-12-16 09:17:11 --> Config Class Initialized
INFO - 2021-12-16 09:17:11 --> Loader Class Initialized
INFO - 2021-12-16 09:17:11 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:11 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:11 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:11 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:11 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:11 --> Controller Class Initialized
INFO - 2021-12-16 09:17:11 --> Final output sent to browser
DEBUG - 2021-12-16 09:17:11 --> Total execution time: 0.0450
INFO - 2021-12-16 09:17:11 --> Config Class Initialized
INFO - 2021-12-16 09:17:11 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:11 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:11 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:11 --> URI Class Initialized
INFO - 2021-12-16 09:17:11 --> Router Class Initialized
INFO - 2021-12-16 09:17:11 --> Output Class Initialized
INFO - 2021-12-16 09:17:11 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:11 --> Input Class Initialized
INFO - 2021-12-16 09:17:11 --> Language Class Initialized
INFO - 2021-12-16 09:17:11 --> Language Class Initialized
INFO - 2021-12-16 09:17:11 --> Config Class Initialized
INFO - 2021-12-16 09:17:11 --> Loader Class Initialized
INFO - 2021-12-16 09:17:11 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:11 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:11 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:11 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:11 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:11 --> Controller Class Initialized
INFO - 2021-12-16 09:17:12 --> Config Class Initialized
INFO - 2021-12-16 09:17:12 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:12 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:12 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:12 --> URI Class Initialized
INFO - 2021-12-16 09:17:12 --> Router Class Initialized
INFO - 2021-12-16 09:17:12 --> Output Class Initialized
INFO - 2021-12-16 09:17:12 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:12 --> Input Class Initialized
INFO - 2021-12-16 09:17:12 --> Language Class Initialized
INFO - 2021-12-16 09:17:12 --> Language Class Initialized
INFO - 2021-12-16 09:17:12 --> Config Class Initialized
INFO - 2021-12-16 09:17:12 --> Loader Class Initialized
INFO - 2021-12-16 09:17:12 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:12 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:12 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:12 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:12 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:12 --> Controller Class Initialized
INFO - 2021-12-16 09:17:12 --> Final output sent to browser
DEBUG - 2021-12-16 09:17:12 --> Total execution time: 0.0510
INFO - 2021-12-16 09:17:24 --> Config Class Initialized
INFO - 2021-12-16 09:17:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:24 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:24 --> URI Class Initialized
INFO - 2021-12-16 09:17:24 --> Router Class Initialized
INFO - 2021-12-16 09:17:24 --> Output Class Initialized
INFO - 2021-12-16 09:17:24 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:24 --> Input Class Initialized
INFO - 2021-12-16 09:17:24 --> Language Class Initialized
INFO - 2021-12-16 09:17:24 --> Language Class Initialized
INFO - 2021-12-16 09:17:24 --> Config Class Initialized
INFO - 2021-12-16 09:17:24 --> Loader Class Initialized
INFO - 2021-12-16 09:17:24 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:24 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:24 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:24 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:24 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:24 --> Controller Class Initialized
INFO - 2021-12-16 09:17:24 --> Final output sent to browser
DEBUG - 2021-12-16 09:17:24 --> Total execution time: 0.0530
INFO - 2021-12-16 09:17:24 --> Config Class Initialized
INFO - 2021-12-16 09:17:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:24 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:24 --> URI Class Initialized
INFO - 2021-12-16 09:17:24 --> Router Class Initialized
INFO - 2021-12-16 09:17:24 --> Output Class Initialized
INFO - 2021-12-16 09:17:24 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:24 --> Input Class Initialized
INFO - 2021-12-16 09:17:24 --> Language Class Initialized
INFO - 2021-12-16 09:17:24 --> Language Class Initialized
INFO - 2021-12-16 09:17:24 --> Config Class Initialized
INFO - 2021-12-16 09:17:24 --> Loader Class Initialized
INFO - 2021-12-16 09:17:24 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:24 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:24 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:24 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:24 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:24 --> Controller Class Initialized
INFO - 2021-12-16 09:17:25 --> Config Class Initialized
INFO - 2021-12-16 09:17:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:25 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:25 --> URI Class Initialized
INFO - 2021-12-16 09:17:25 --> Router Class Initialized
INFO - 2021-12-16 09:17:25 --> Output Class Initialized
INFO - 2021-12-16 09:17:25 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:25 --> Input Class Initialized
INFO - 2021-12-16 09:17:25 --> Language Class Initialized
INFO - 2021-12-16 09:17:25 --> Language Class Initialized
INFO - 2021-12-16 09:17:25 --> Config Class Initialized
INFO - 2021-12-16 09:17:25 --> Loader Class Initialized
INFO - 2021-12-16 09:17:25 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:25 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:25 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:25 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:25 --> Controller Class Initialized
INFO - 2021-12-16 09:17:25 --> Final output sent to browser
DEBUG - 2021-12-16 09:17:25 --> Total execution time: 0.0520
INFO - 2021-12-16 09:17:36 --> Config Class Initialized
INFO - 2021-12-16 09:17:36 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:36 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:36 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:36 --> URI Class Initialized
INFO - 2021-12-16 09:17:36 --> Router Class Initialized
INFO - 2021-12-16 09:17:36 --> Output Class Initialized
INFO - 2021-12-16 09:17:36 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:36 --> Input Class Initialized
INFO - 2021-12-16 09:17:36 --> Language Class Initialized
INFO - 2021-12-16 09:17:36 --> Language Class Initialized
INFO - 2021-12-16 09:17:36 --> Config Class Initialized
INFO - 2021-12-16 09:17:36 --> Loader Class Initialized
INFO - 2021-12-16 09:17:36 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:36 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:36 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:36 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:36 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:36 --> Controller Class Initialized
INFO - 2021-12-16 09:17:36 --> Final output sent to browser
DEBUG - 2021-12-16 09:17:36 --> Total execution time: 0.0520
INFO - 2021-12-16 09:17:36 --> Config Class Initialized
INFO - 2021-12-16 09:17:36 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:36 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:36 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:36 --> URI Class Initialized
INFO - 2021-12-16 09:17:36 --> Router Class Initialized
INFO - 2021-12-16 09:17:36 --> Output Class Initialized
INFO - 2021-12-16 09:17:36 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:36 --> Input Class Initialized
INFO - 2021-12-16 09:17:36 --> Language Class Initialized
INFO - 2021-12-16 09:17:36 --> Language Class Initialized
INFO - 2021-12-16 09:17:36 --> Config Class Initialized
INFO - 2021-12-16 09:17:36 --> Loader Class Initialized
INFO - 2021-12-16 09:17:36 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:36 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:36 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:36 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:36 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:36 --> Controller Class Initialized
INFO - 2021-12-16 09:17:38 --> Config Class Initialized
INFO - 2021-12-16 09:17:38 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:38 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:38 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:38 --> URI Class Initialized
INFO - 2021-12-16 09:17:38 --> Router Class Initialized
INFO - 2021-12-16 09:17:38 --> Output Class Initialized
INFO - 2021-12-16 09:17:38 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:38 --> Input Class Initialized
INFO - 2021-12-16 09:17:38 --> Language Class Initialized
INFO - 2021-12-16 09:17:38 --> Language Class Initialized
INFO - 2021-12-16 09:17:38 --> Config Class Initialized
INFO - 2021-12-16 09:17:38 --> Loader Class Initialized
INFO - 2021-12-16 09:17:38 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:38 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:38 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:38 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:38 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:38 --> Controller Class Initialized
INFO - 2021-12-16 09:17:38 --> Final output sent to browser
DEBUG - 2021-12-16 09:17:38 --> Total execution time: 0.0510
INFO - 2021-12-16 09:17:48 --> Config Class Initialized
INFO - 2021-12-16 09:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:48 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:48 --> URI Class Initialized
INFO - 2021-12-16 09:17:48 --> Router Class Initialized
INFO - 2021-12-16 09:17:48 --> Output Class Initialized
INFO - 2021-12-16 09:17:48 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:48 --> Input Class Initialized
INFO - 2021-12-16 09:17:48 --> Language Class Initialized
INFO - 2021-12-16 09:17:48 --> Language Class Initialized
INFO - 2021-12-16 09:17:48 --> Config Class Initialized
INFO - 2021-12-16 09:17:48 --> Loader Class Initialized
INFO - 2021-12-16 09:17:48 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:48 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:48 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:48 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:48 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:48 --> Controller Class Initialized
INFO - 2021-12-16 09:17:48 --> Final output sent to browser
DEBUG - 2021-12-16 09:17:48 --> Total execution time: 0.0590
INFO - 2021-12-16 09:17:48 --> Config Class Initialized
INFO - 2021-12-16 09:17:48 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:48 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:48 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:48 --> URI Class Initialized
INFO - 2021-12-16 09:17:48 --> Router Class Initialized
INFO - 2021-12-16 09:17:48 --> Output Class Initialized
INFO - 2021-12-16 09:17:48 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:48 --> Input Class Initialized
INFO - 2021-12-16 09:17:48 --> Language Class Initialized
INFO - 2021-12-16 09:17:48 --> Language Class Initialized
INFO - 2021-12-16 09:17:48 --> Config Class Initialized
INFO - 2021-12-16 09:17:48 --> Loader Class Initialized
INFO - 2021-12-16 09:17:48 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:48 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:48 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:48 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:48 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:48 --> Controller Class Initialized
INFO - 2021-12-16 09:17:50 --> Config Class Initialized
INFO - 2021-12-16 09:17:50 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:17:50 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:17:50 --> Utf8 Class Initialized
INFO - 2021-12-16 09:17:50 --> URI Class Initialized
INFO - 2021-12-16 09:17:50 --> Router Class Initialized
INFO - 2021-12-16 09:17:50 --> Output Class Initialized
INFO - 2021-12-16 09:17:50 --> Security Class Initialized
DEBUG - 2021-12-16 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:17:50 --> Input Class Initialized
INFO - 2021-12-16 09:17:50 --> Language Class Initialized
INFO - 2021-12-16 09:17:50 --> Language Class Initialized
INFO - 2021-12-16 09:17:50 --> Config Class Initialized
INFO - 2021-12-16 09:17:50 --> Loader Class Initialized
INFO - 2021-12-16 09:17:50 --> Helper loaded: url_helper
INFO - 2021-12-16 09:17:50 --> Helper loaded: file_helper
INFO - 2021-12-16 09:17:50 --> Helper loaded: form_helper
INFO - 2021-12-16 09:17:50 --> Helper loaded: my_helper
INFO - 2021-12-16 09:17:50 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:17:50 --> Controller Class Initialized
INFO - 2021-12-16 09:17:50 --> Final output sent to browser
DEBUG - 2021-12-16 09:17:50 --> Total execution time: 0.0410
INFO - 2021-12-16 09:18:00 --> Config Class Initialized
INFO - 2021-12-16 09:18:00 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:00 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:00 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:00 --> URI Class Initialized
INFO - 2021-12-16 09:18:00 --> Router Class Initialized
INFO - 2021-12-16 09:18:00 --> Output Class Initialized
INFO - 2021-12-16 09:18:00 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:00 --> Input Class Initialized
INFO - 2021-12-16 09:18:00 --> Language Class Initialized
INFO - 2021-12-16 09:18:00 --> Language Class Initialized
INFO - 2021-12-16 09:18:00 --> Config Class Initialized
INFO - 2021-12-16 09:18:00 --> Loader Class Initialized
INFO - 2021-12-16 09:18:00 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:00 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:00 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:00 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:00 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:00 --> Controller Class Initialized
INFO - 2021-12-16 09:18:00 --> Final output sent to browser
DEBUG - 2021-12-16 09:18:00 --> Total execution time: 0.0500
INFO - 2021-12-16 09:18:00 --> Config Class Initialized
INFO - 2021-12-16 09:18:00 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:00 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:00 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:00 --> URI Class Initialized
INFO - 2021-12-16 09:18:00 --> Router Class Initialized
INFO - 2021-12-16 09:18:00 --> Output Class Initialized
INFO - 2021-12-16 09:18:00 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:00 --> Input Class Initialized
INFO - 2021-12-16 09:18:00 --> Language Class Initialized
INFO - 2021-12-16 09:18:00 --> Language Class Initialized
INFO - 2021-12-16 09:18:00 --> Config Class Initialized
INFO - 2021-12-16 09:18:00 --> Loader Class Initialized
INFO - 2021-12-16 09:18:00 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:00 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:00 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:00 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:00 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:00 --> Controller Class Initialized
INFO - 2021-12-16 09:18:05 --> Config Class Initialized
INFO - 2021-12-16 09:18:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:05 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:05 --> URI Class Initialized
INFO - 2021-12-16 09:18:05 --> Router Class Initialized
INFO - 2021-12-16 09:18:05 --> Output Class Initialized
INFO - 2021-12-16 09:18:05 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:05 --> Input Class Initialized
INFO - 2021-12-16 09:18:05 --> Language Class Initialized
INFO - 2021-12-16 09:18:05 --> Language Class Initialized
INFO - 2021-12-16 09:18:05 --> Config Class Initialized
INFO - 2021-12-16 09:18:05 --> Loader Class Initialized
INFO - 2021-12-16 09:18:05 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:05 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:05 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:05 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:05 --> Controller Class Initialized
DEBUG - 2021-12-16 09:18:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-16 09:18:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 09:18:05 --> Final output sent to browser
DEBUG - 2021-12-16 09:18:05 --> Total execution time: 0.0440
INFO - 2021-12-16 09:18:05 --> Config Class Initialized
INFO - 2021-12-16 09:18:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:05 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:05 --> URI Class Initialized
INFO - 2021-12-16 09:18:05 --> Router Class Initialized
INFO - 2021-12-16 09:18:05 --> Output Class Initialized
INFO - 2021-12-16 09:18:05 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:05 --> Input Class Initialized
INFO - 2021-12-16 09:18:05 --> Language Class Initialized
INFO - 2021-12-16 09:18:05 --> Language Class Initialized
INFO - 2021-12-16 09:18:05 --> Config Class Initialized
INFO - 2021-12-16 09:18:05 --> Loader Class Initialized
INFO - 2021-12-16 09:18:05 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:05 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:05 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:05 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:05 --> Controller Class Initialized
INFO - 2021-12-16 09:18:16 --> Config Class Initialized
INFO - 2021-12-16 09:18:16 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:16 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:16 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:16 --> URI Class Initialized
INFO - 2021-12-16 09:18:16 --> Router Class Initialized
INFO - 2021-12-16 09:18:16 --> Output Class Initialized
INFO - 2021-12-16 09:18:16 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:16 --> Input Class Initialized
INFO - 2021-12-16 09:18:16 --> Language Class Initialized
INFO - 2021-12-16 09:18:16 --> Language Class Initialized
INFO - 2021-12-16 09:18:16 --> Config Class Initialized
INFO - 2021-12-16 09:18:16 --> Loader Class Initialized
INFO - 2021-12-16 09:18:16 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:16 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:16 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:16 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:16 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:16 --> Controller Class Initialized
INFO - 2021-12-16 09:18:16 --> Final output sent to browser
DEBUG - 2021-12-16 09:18:16 --> Total execution time: 0.0410
INFO - 2021-12-16 09:18:19 --> Config Class Initialized
INFO - 2021-12-16 09:18:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:19 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:19 --> URI Class Initialized
INFO - 2021-12-16 09:18:19 --> Router Class Initialized
INFO - 2021-12-16 09:18:19 --> Output Class Initialized
INFO - 2021-12-16 09:18:19 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:19 --> Input Class Initialized
INFO - 2021-12-16 09:18:19 --> Language Class Initialized
INFO - 2021-12-16 09:18:19 --> Language Class Initialized
INFO - 2021-12-16 09:18:19 --> Config Class Initialized
INFO - 2021-12-16 09:18:19 --> Loader Class Initialized
INFO - 2021-12-16 09:18:19 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:19 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:19 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:19 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:19 --> Controller Class Initialized
INFO - 2021-12-16 09:18:19 --> Final output sent to browser
DEBUG - 2021-12-16 09:18:19 --> Total execution time: 0.0450
INFO - 2021-12-16 09:18:19 --> Config Class Initialized
INFO - 2021-12-16 09:18:19 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:19 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:19 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:19 --> URI Class Initialized
INFO - 2021-12-16 09:18:19 --> Router Class Initialized
INFO - 2021-12-16 09:18:19 --> Output Class Initialized
INFO - 2021-12-16 09:18:19 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:19 --> Input Class Initialized
INFO - 2021-12-16 09:18:19 --> Language Class Initialized
INFO - 2021-12-16 09:18:19 --> Language Class Initialized
INFO - 2021-12-16 09:18:19 --> Config Class Initialized
INFO - 2021-12-16 09:18:19 --> Loader Class Initialized
INFO - 2021-12-16 09:18:19 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:19 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:19 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:19 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:19 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:19 --> Controller Class Initialized
INFO - 2021-12-16 09:18:25 --> Config Class Initialized
INFO - 2021-12-16 09:18:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:25 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:25 --> URI Class Initialized
INFO - 2021-12-16 09:18:25 --> Router Class Initialized
INFO - 2021-12-16 09:18:25 --> Output Class Initialized
INFO - 2021-12-16 09:18:25 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:25 --> Input Class Initialized
INFO - 2021-12-16 09:18:25 --> Language Class Initialized
INFO - 2021-12-16 09:18:25 --> Language Class Initialized
INFO - 2021-12-16 09:18:25 --> Config Class Initialized
INFO - 2021-12-16 09:18:25 --> Loader Class Initialized
INFO - 2021-12-16 09:18:25 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:25 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:25 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:25 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:25 --> Controller Class Initialized
DEBUG - 2021-12-16 09:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-12-16 09:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 09:18:25 --> Final output sent to browser
DEBUG - 2021-12-16 09:18:25 --> Total execution time: 0.0510
INFO - 2021-12-16 09:18:25 --> Config Class Initialized
INFO - 2021-12-16 09:18:25 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:25 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:25 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:25 --> URI Class Initialized
INFO - 2021-12-16 09:18:25 --> Router Class Initialized
INFO - 2021-12-16 09:18:25 --> Output Class Initialized
INFO - 2021-12-16 09:18:25 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:25 --> Input Class Initialized
INFO - 2021-12-16 09:18:25 --> Language Class Initialized
INFO - 2021-12-16 09:18:25 --> Language Class Initialized
INFO - 2021-12-16 09:18:25 --> Config Class Initialized
INFO - 2021-12-16 09:18:25 --> Loader Class Initialized
INFO - 2021-12-16 09:18:25 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:25 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:25 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:25 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:25 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:25 --> Controller Class Initialized
INFO - 2021-12-16 09:18:27 --> Config Class Initialized
INFO - 2021-12-16 09:18:27 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:27 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:27 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:27 --> URI Class Initialized
INFO - 2021-12-16 09:18:27 --> Router Class Initialized
INFO - 2021-12-16 09:18:27 --> Output Class Initialized
INFO - 2021-12-16 09:18:27 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:27 --> Input Class Initialized
INFO - 2021-12-16 09:18:27 --> Language Class Initialized
INFO - 2021-12-16 09:18:27 --> Language Class Initialized
INFO - 2021-12-16 09:18:27 --> Config Class Initialized
INFO - 2021-12-16 09:18:27 --> Loader Class Initialized
INFO - 2021-12-16 09:18:27 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:27 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:27 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:27 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:27 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:27 --> Controller Class Initialized
INFO - 2021-12-16 09:18:34 --> Config Class Initialized
INFO - 2021-12-16 09:18:34 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:34 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:34 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:34 --> URI Class Initialized
INFO - 2021-12-16 09:18:34 --> Router Class Initialized
INFO - 2021-12-16 09:18:34 --> Output Class Initialized
INFO - 2021-12-16 09:18:34 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:34 --> Input Class Initialized
INFO - 2021-12-16 09:18:34 --> Language Class Initialized
INFO - 2021-12-16 09:18:34 --> Language Class Initialized
INFO - 2021-12-16 09:18:34 --> Config Class Initialized
INFO - 2021-12-16 09:18:34 --> Loader Class Initialized
INFO - 2021-12-16 09:18:34 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:34 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:34 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:34 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:34 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:34 --> Controller Class Initialized
INFO - 2021-12-16 09:18:37 --> Config Class Initialized
INFO - 2021-12-16 09:18:37 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:37 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:37 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:37 --> URI Class Initialized
INFO - 2021-12-16 09:18:37 --> Router Class Initialized
INFO - 2021-12-16 09:18:37 --> Output Class Initialized
INFO - 2021-12-16 09:18:37 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:37 --> Input Class Initialized
INFO - 2021-12-16 09:18:37 --> Language Class Initialized
INFO - 2021-12-16 09:18:37 --> Language Class Initialized
INFO - 2021-12-16 09:18:37 --> Config Class Initialized
INFO - 2021-12-16 09:18:37 --> Loader Class Initialized
INFO - 2021-12-16 09:18:37 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:37 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:37 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:37 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:37 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:37 --> Controller Class Initialized
INFO - 2021-12-16 09:18:38 --> Config Class Initialized
INFO - 2021-12-16 09:18:38 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:38 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:38 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:38 --> URI Class Initialized
INFO - 2021-12-16 09:18:38 --> Router Class Initialized
INFO - 2021-12-16 09:18:38 --> Output Class Initialized
INFO - 2021-12-16 09:18:38 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:38 --> Input Class Initialized
INFO - 2021-12-16 09:18:38 --> Language Class Initialized
INFO - 2021-12-16 09:18:38 --> Language Class Initialized
INFO - 2021-12-16 09:18:38 --> Config Class Initialized
INFO - 2021-12-16 09:18:38 --> Loader Class Initialized
INFO - 2021-12-16 09:18:38 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:38 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:38 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:38 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:38 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:38 --> Controller Class Initialized
INFO - 2021-12-16 09:18:59 --> Config Class Initialized
INFO - 2021-12-16 09:18:59 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:18:59 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:18:59 --> Utf8 Class Initialized
INFO - 2021-12-16 09:18:59 --> URI Class Initialized
INFO - 2021-12-16 09:18:59 --> Router Class Initialized
INFO - 2021-12-16 09:18:59 --> Output Class Initialized
INFO - 2021-12-16 09:18:59 --> Security Class Initialized
DEBUG - 2021-12-16 09:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:18:59 --> Input Class Initialized
INFO - 2021-12-16 09:18:59 --> Language Class Initialized
INFO - 2021-12-16 09:18:59 --> Language Class Initialized
INFO - 2021-12-16 09:18:59 --> Config Class Initialized
INFO - 2021-12-16 09:18:59 --> Loader Class Initialized
INFO - 2021-12-16 09:18:59 --> Helper loaded: url_helper
INFO - 2021-12-16 09:18:59 --> Helper loaded: file_helper
INFO - 2021-12-16 09:18:59 --> Helper loaded: form_helper
INFO - 2021-12-16 09:18:59 --> Helper loaded: my_helper
INFO - 2021-12-16 09:18:59 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:18:59 --> Controller Class Initialized
INFO - 2021-12-16 09:19:05 --> Config Class Initialized
INFO - 2021-12-16 09:19:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:19:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:19:05 --> Utf8 Class Initialized
INFO - 2021-12-16 09:19:05 --> URI Class Initialized
INFO - 2021-12-16 09:19:05 --> Router Class Initialized
INFO - 2021-12-16 09:19:05 --> Output Class Initialized
INFO - 2021-12-16 09:19:05 --> Security Class Initialized
DEBUG - 2021-12-16 09:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:19:05 --> Input Class Initialized
INFO - 2021-12-16 09:19:05 --> Language Class Initialized
INFO - 2021-12-16 09:19:05 --> Language Class Initialized
INFO - 2021-12-16 09:19:05 --> Config Class Initialized
INFO - 2021-12-16 09:19:05 --> Loader Class Initialized
INFO - 2021-12-16 09:19:05 --> Helper loaded: url_helper
INFO - 2021-12-16 09:19:05 --> Helper loaded: file_helper
INFO - 2021-12-16 09:19:05 --> Helper loaded: form_helper
INFO - 2021-12-16 09:19:05 --> Helper loaded: my_helper
INFO - 2021-12-16 09:19:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:19:05 --> Controller Class Initialized
DEBUG - 2021-12-16 09:19:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-16 09:19:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 09:19:05 --> Final output sent to browser
DEBUG - 2021-12-16 09:19:05 --> Total execution time: 0.0500
INFO - 2021-12-16 09:19:05 --> Config Class Initialized
INFO - 2021-12-16 09:19:05 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:19:05 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:19:05 --> Utf8 Class Initialized
INFO - 2021-12-16 09:19:05 --> URI Class Initialized
INFO - 2021-12-16 09:19:05 --> Router Class Initialized
INFO - 2021-12-16 09:19:05 --> Output Class Initialized
INFO - 2021-12-16 09:19:05 --> Security Class Initialized
DEBUG - 2021-12-16 09:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:19:05 --> Input Class Initialized
INFO - 2021-12-16 09:19:05 --> Language Class Initialized
INFO - 2021-12-16 09:19:05 --> Language Class Initialized
INFO - 2021-12-16 09:19:05 --> Config Class Initialized
INFO - 2021-12-16 09:19:05 --> Loader Class Initialized
INFO - 2021-12-16 09:19:05 --> Helper loaded: url_helper
INFO - 2021-12-16 09:19:05 --> Helper loaded: file_helper
INFO - 2021-12-16 09:19:05 --> Helper loaded: form_helper
INFO - 2021-12-16 09:19:05 --> Helper loaded: my_helper
INFO - 2021-12-16 09:19:05 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:19:05 --> Controller Class Initialized
INFO - 2021-12-16 09:19:24 --> Config Class Initialized
INFO - 2021-12-16 09:19:24 --> Hooks Class Initialized
DEBUG - 2021-12-16 09:19:24 --> UTF-8 Support Enabled
INFO - 2021-12-16 09:19:24 --> Utf8 Class Initialized
INFO - 2021-12-16 09:19:24 --> URI Class Initialized
INFO - 2021-12-16 09:19:24 --> Router Class Initialized
INFO - 2021-12-16 09:19:24 --> Output Class Initialized
INFO - 2021-12-16 09:19:24 --> Security Class Initialized
DEBUG - 2021-12-16 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-16 09:19:24 --> Input Class Initialized
INFO - 2021-12-16 09:19:24 --> Language Class Initialized
INFO - 2021-12-16 09:19:24 --> Language Class Initialized
INFO - 2021-12-16 09:19:24 --> Config Class Initialized
INFO - 2021-12-16 09:19:24 --> Loader Class Initialized
INFO - 2021-12-16 09:19:24 --> Helper loaded: url_helper
INFO - 2021-12-16 09:19:24 --> Helper loaded: file_helper
INFO - 2021-12-16 09:19:24 --> Helper loaded: form_helper
INFO - 2021-12-16 09:19:24 --> Helper loaded: my_helper
INFO - 2021-12-16 09:19:24 --> Database Driver Class Initialized
DEBUG - 2021-12-16 09:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-16 09:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-16 09:19:24 --> Controller Class Initialized
DEBUG - 2021-12-16 09:19:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-16 09:19:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-16 09:19:24 --> Final output sent to browser
DEBUG - 2021-12-16 09:19:24 --> Total execution time: 0.0670
