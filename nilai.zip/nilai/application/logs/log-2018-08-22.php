<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-08-22 11:11:08 --> Config Class Initialized
INFO - 2018-08-22 11:11:08 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:11:09 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:11:09 --> Utf8 Class Initialized
INFO - 2018-08-22 11:11:09 --> URI Class Initialized
INFO - 2018-08-22 11:11:09 --> Router Class Initialized
INFO - 2018-08-22 11:11:09 --> Output Class Initialized
INFO - 2018-08-22 11:11:09 --> Security Class Initialized
DEBUG - 2018-08-22 11:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:11:09 --> Input Class Initialized
INFO - 2018-08-22 11:11:09 --> Language Class Initialized
INFO - 2018-08-22 11:11:10 --> Language Class Initialized
INFO - 2018-08-22 11:11:10 --> Config Class Initialized
INFO - 2018-08-22 11:11:10 --> Loader Class Initialized
INFO - 2018-08-22 11:11:10 --> Helper loaded: url_helper
INFO - 2018-08-22 11:11:10 --> Helper loaded: file_helper
INFO - 2018-08-22 11:11:10 --> Helper loaded: form_helper
INFO - 2018-08-22 11:11:10 --> Helper loaded: my_helper
INFO - 2018-08-22 11:11:10 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:11:10 --> Controller Class Initialized
INFO - 2018-08-22 11:11:10 --> Config Class Initialized
INFO - 2018-08-22 11:11:10 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:11:10 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:11:10 --> Utf8 Class Initialized
INFO - 2018-08-22 11:11:10 --> URI Class Initialized
INFO - 2018-08-22 11:11:10 --> Router Class Initialized
INFO - 2018-08-22 11:11:10 --> Output Class Initialized
INFO - 2018-08-22 11:11:10 --> Security Class Initialized
DEBUG - 2018-08-22 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:11:10 --> Input Class Initialized
INFO - 2018-08-22 11:11:10 --> Language Class Initialized
INFO - 2018-08-22 11:11:10 --> Language Class Initialized
INFO - 2018-08-22 11:11:10 --> Config Class Initialized
INFO - 2018-08-22 11:11:10 --> Loader Class Initialized
INFO - 2018-08-22 11:11:10 --> Helper loaded: url_helper
INFO - 2018-08-22 11:11:10 --> Helper loaded: file_helper
INFO - 2018-08-22 11:11:10 --> Helper loaded: form_helper
INFO - 2018-08-22 11:11:10 --> Helper loaded: my_helper
INFO - 2018-08-22 11:11:10 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:11:10 --> Controller Class Initialized
DEBUG - 2018-08-22 11:11:10 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-22 11:11:10 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-22 11:11:11 --> Final output sent to browser
DEBUG - 2018-08-22 11:11:11 --> Total execution time: 0.4952
INFO - 2018-08-22 11:11:17 --> Config Class Initialized
INFO - 2018-08-22 11:11:17 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:11:17 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:11:17 --> Utf8 Class Initialized
INFO - 2018-08-22 11:11:17 --> URI Class Initialized
INFO - 2018-08-22 11:11:17 --> Router Class Initialized
INFO - 2018-08-22 11:11:17 --> Output Class Initialized
INFO - 2018-08-22 11:11:17 --> Security Class Initialized
DEBUG - 2018-08-22 11:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:11:17 --> Input Class Initialized
INFO - 2018-08-22 11:11:17 --> Language Class Initialized
INFO - 2018-08-22 11:11:17 --> Language Class Initialized
INFO - 2018-08-22 11:11:17 --> Config Class Initialized
INFO - 2018-08-22 11:11:17 --> Loader Class Initialized
INFO - 2018-08-22 11:11:17 --> Helper loaded: url_helper
INFO - 2018-08-22 11:11:17 --> Helper loaded: file_helper
INFO - 2018-08-22 11:11:17 --> Helper loaded: form_helper
INFO - 2018-08-22 11:11:17 --> Helper loaded: my_helper
INFO - 2018-08-22 11:11:17 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:11:17 --> Controller Class Initialized
INFO - 2018-08-22 11:11:17 --> Helper loaded: cookie_helper
INFO - 2018-08-22 11:11:17 --> Final output sent to browser
DEBUG - 2018-08-22 11:11:17 --> Total execution time: 0.5759
INFO - 2018-08-22 11:11:18 --> Config Class Initialized
INFO - 2018-08-22 11:11:18 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:11:18 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:11:18 --> Utf8 Class Initialized
INFO - 2018-08-22 11:11:18 --> URI Class Initialized
INFO - 2018-08-22 11:11:18 --> Router Class Initialized
INFO - 2018-08-22 11:11:18 --> Output Class Initialized
INFO - 2018-08-22 11:11:18 --> Security Class Initialized
DEBUG - 2018-08-22 11:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:11:18 --> Input Class Initialized
INFO - 2018-08-22 11:11:18 --> Language Class Initialized
INFO - 2018-08-22 11:11:18 --> Language Class Initialized
INFO - 2018-08-22 11:11:18 --> Config Class Initialized
INFO - 2018-08-22 11:11:18 --> Loader Class Initialized
INFO - 2018-08-22 11:11:18 --> Helper loaded: url_helper
INFO - 2018-08-22 11:11:18 --> Helper loaded: file_helper
INFO - 2018-08-22 11:11:18 --> Helper loaded: form_helper
INFO - 2018-08-22 11:11:18 --> Helper loaded: my_helper
INFO - 2018-08-22 11:11:18 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:11:18 --> Controller Class Initialized
DEBUG - 2018-08-22 11:11:18 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-22 11:11:18 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-22 11:11:18 --> Final output sent to browser
DEBUG - 2018-08-22 11:11:18 --> Total execution time: 0.4586
INFO - 2018-08-22 11:11:20 --> Config Class Initialized
INFO - 2018-08-22 11:11:20 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:11:20 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:11:20 --> Utf8 Class Initialized
INFO - 2018-08-22 11:11:20 --> URI Class Initialized
INFO - 2018-08-22 11:11:20 --> Router Class Initialized
INFO - 2018-08-22 11:11:20 --> Output Class Initialized
INFO - 2018-08-22 11:11:20 --> Security Class Initialized
DEBUG - 2018-08-22 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:11:20 --> Input Class Initialized
INFO - 2018-08-22 11:11:20 --> Language Class Initialized
INFO - 2018-08-22 11:11:20 --> Language Class Initialized
INFO - 2018-08-22 11:11:20 --> Config Class Initialized
INFO - 2018-08-22 11:11:20 --> Loader Class Initialized
INFO - 2018-08-22 11:11:20 --> Helper loaded: url_helper
INFO - 2018-08-22 11:11:20 --> Helper loaded: file_helper
INFO - 2018-08-22 11:11:20 --> Helper loaded: form_helper
INFO - 2018-08-22 11:11:20 --> Helper loaded: my_helper
INFO - 2018-08-22 11:11:20 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:11:20 --> Controller Class Initialized
DEBUG - 2018-08-22 11:11:20 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-22 11:11:20 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-22 11:11:20 --> Final output sent to browser
DEBUG - 2018-08-22 11:11:20 --> Total execution time: 0.3914
INFO - 2018-08-22 11:11:21 --> Config Class Initialized
INFO - 2018-08-22 11:11:21 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:11:21 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:11:21 --> Utf8 Class Initialized
INFO - 2018-08-22 11:11:21 --> URI Class Initialized
INFO - 2018-08-22 11:11:21 --> Router Class Initialized
INFO - 2018-08-22 11:11:21 --> Output Class Initialized
INFO - 2018-08-22 11:11:21 --> Security Class Initialized
DEBUG - 2018-08-22 11:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:11:21 --> Input Class Initialized
INFO - 2018-08-22 11:11:21 --> Language Class Initialized
INFO - 2018-08-22 11:11:21 --> Language Class Initialized
INFO - 2018-08-22 11:11:21 --> Config Class Initialized
INFO - 2018-08-22 11:11:21 --> Loader Class Initialized
INFO - 2018-08-22 11:11:21 --> Helper loaded: url_helper
INFO - 2018-08-22 11:11:21 --> Helper loaded: file_helper
INFO - 2018-08-22 11:11:21 --> Helper loaded: form_helper
INFO - 2018-08-22 11:11:21 --> Helper loaded: my_helper
INFO - 2018-08-22 11:11:21 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:11:21 --> Controller Class Initialized
INFO - 2018-08-22 11:13:38 --> Config Class Initialized
INFO - 2018-08-22 11:13:38 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:13:38 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:13:38 --> Utf8 Class Initialized
INFO - 2018-08-22 11:13:38 --> URI Class Initialized
DEBUG - 2018-08-22 11:13:38 --> No URI present. Default controller set.
INFO - 2018-08-22 11:13:38 --> Router Class Initialized
INFO - 2018-08-22 11:13:38 --> Output Class Initialized
INFO - 2018-08-22 11:13:38 --> Security Class Initialized
DEBUG - 2018-08-22 11:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:13:38 --> Input Class Initialized
INFO - 2018-08-22 11:13:38 --> Language Class Initialized
INFO - 2018-08-22 11:13:38 --> Language Class Initialized
INFO - 2018-08-22 11:13:38 --> Config Class Initialized
INFO - 2018-08-22 11:13:38 --> Loader Class Initialized
INFO - 2018-08-22 11:13:38 --> Helper loaded: url_helper
INFO - 2018-08-22 11:13:38 --> Helper loaded: file_helper
INFO - 2018-08-22 11:13:38 --> Helper loaded: form_helper
INFO - 2018-08-22 11:13:38 --> Helper loaded: my_helper
INFO - 2018-08-22 11:13:38 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:13:38 --> Controller Class Initialized
DEBUG - 2018-08-22 11:13:38 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-22 11:13:38 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-22 11:13:38 --> Final output sent to browser
DEBUG - 2018-08-22 11:13:38 --> Total execution time: 0.2914
INFO - 2018-08-22 11:13:43 --> Config Class Initialized
INFO - 2018-08-22 11:13:43 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:13:43 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:13:43 --> Utf8 Class Initialized
INFO - 2018-08-22 11:13:43 --> URI Class Initialized
INFO - 2018-08-22 11:13:43 --> Router Class Initialized
INFO - 2018-08-22 11:13:43 --> Output Class Initialized
INFO - 2018-08-22 11:13:43 --> Security Class Initialized
DEBUG - 2018-08-22 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:13:43 --> Input Class Initialized
INFO - 2018-08-22 11:13:43 --> Language Class Initialized
INFO - 2018-08-22 11:13:43 --> Language Class Initialized
INFO - 2018-08-22 11:13:43 --> Config Class Initialized
INFO - 2018-08-22 11:13:43 --> Loader Class Initialized
INFO - 2018-08-22 11:13:43 --> Helper loaded: url_helper
INFO - 2018-08-22 11:13:43 --> Helper loaded: file_helper
INFO - 2018-08-22 11:13:43 --> Helper loaded: form_helper
INFO - 2018-08-22 11:13:43 --> Helper loaded: my_helper
INFO - 2018-08-22 11:13:43 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:13:43 --> Controller Class Initialized
DEBUG - 2018-08-22 11:13:43 --> File loaded: D:\laragon\www\nilai\application\modules/data_guru/views/list.php
DEBUG - 2018-08-22 11:13:43 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-22 11:13:43 --> Final output sent to browser
DEBUG - 2018-08-22 11:13:43 --> Total execution time: 0.2420
INFO - 2018-08-22 11:13:44 --> Config Class Initialized
INFO - 2018-08-22 11:13:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:13:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:13:44 --> Utf8 Class Initialized
INFO - 2018-08-22 11:13:44 --> URI Class Initialized
INFO - 2018-08-22 11:13:44 --> Router Class Initialized
INFO - 2018-08-22 11:13:44 --> Output Class Initialized
INFO - 2018-08-22 11:13:44 --> Security Class Initialized
DEBUG - 2018-08-22 11:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:13:44 --> Input Class Initialized
INFO - 2018-08-22 11:13:44 --> Language Class Initialized
INFO - 2018-08-22 11:13:44 --> Language Class Initialized
INFO - 2018-08-22 11:13:44 --> Config Class Initialized
INFO - 2018-08-22 11:13:44 --> Loader Class Initialized
INFO - 2018-08-22 11:13:44 --> Helper loaded: url_helper
INFO - 2018-08-22 11:13:44 --> Helper loaded: file_helper
INFO - 2018-08-22 11:13:44 --> Helper loaded: form_helper
INFO - 2018-08-22 11:13:44 --> Helper loaded: my_helper
INFO - 2018-08-22 11:13:44 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:13:44 --> Controller Class Initialized
INFO - 2018-08-22 11:13:44 --> Config Class Initialized
INFO - 2018-08-22 11:13:44 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:13:44 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:13:44 --> Utf8 Class Initialized
INFO - 2018-08-22 11:13:44 --> URI Class Initialized
DEBUG - 2018-08-22 11:13:44 --> No URI present. Default controller set.
INFO - 2018-08-22 11:13:44 --> Router Class Initialized
INFO - 2018-08-22 11:13:44 --> Output Class Initialized
INFO - 2018-08-22 11:13:44 --> Security Class Initialized
DEBUG - 2018-08-22 11:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:13:44 --> Input Class Initialized
INFO - 2018-08-22 11:13:44 --> Language Class Initialized
INFO - 2018-08-22 11:13:44 --> Language Class Initialized
INFO - 2018-08-22 11:13:44 --> Config Class Initialized
INFO - 2018-08-22 11:13:44 --> Loader Class Initialized
INFO - 2018-08-22 11:13:44 --> Helper loaded: url_helper
INFO - 2018-08-22 11:13:44 --> Helper loaded: file_helper
INFO - 2018-08-22 11:13:44 --> Helper loaded: form_helper
INFO - 2018-08-22 11:13:44 --> Helper loaded: my_helper
INFO - 2018-08-22 11:13:44 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:13:44 --> Controller Class Initialized
DEBUG - 2018-08-22 11:13:44 --> File loaded: D:\laragon\www\nilai\application\modules/home/views/v_home.php
DEBUG - 2018-08-22 11:13:44 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-22 11:13:44 --> Final output sent to browser
DEBUG - 2018-08-22 11:13:44 --> Total execution time: 0.2568
INFO - 2018-08-22 11:13:45 --> Config Class Initialized
INFO - 2018-08-22 11:13:45 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:13:45 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:13:46 --> Utf8 Class Initialized
INFO - 2018-08-22 11:13:46 --> URI Class Initialized
INFO - 2018-08-22 11:13:46 --> Router Class Initialized
INFO - 2018-08-22 11:13:46 --> Output Class Initialized
INFO - 2018-08-22 11:13:46 --> Security Class Initialized
DEBUG - 2018-08-22 11:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:13:46 --> Input Class Initialized
INFO - 2018-08-22 11:13:46 --> Language Class Initialized
INFO - 2018-08-22 11:13:46 --> Language Class Initialized
INFO - 2018-08-22 11:13:46 --> Config Class Initialized
INFO - 2018-08-22 11:13:46 --> Loader Class Initialized
INFO - 2018-08-22 11:13:46 --> Helper loaded: url_helper
INFO - 2018-08-22 11:13:46 --> Helper loaded: file_helper
INFO - 2018-08-22 11:13:46 --> Helper loaded: form_helper
INFO - 2018-08-22 11:13:46 --> Helper loaded: my_helper
INFO - 2018-08-22 11:13:46 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:13:46 --> Controller Class Initialized
INFO - 2018-08-22 11:13:46 --> Helper loaded: cookie_helper
INFO - 2018-08-22 11:13:46 --> Config Class Initialized
INFO - 2018-08-22 11:13:46 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:13:46 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:13:46 --> Utf8 Class Initialized
INFO - 2018-08-22 11:13:46 --> URI Class Initialized
INFO - 2018-08-22 11:13:46 --> Router Class Initialized
INFO - 2018-08-22 11:13:46 --> Output Class Initialized
INFO - 2018-08-22 11:13:46 --> Security Class Initialized
DEBUG - 2018-08-22 11:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:13:46 --> Input Class Initialized
INFO - 2018-08-22 11:13:46 --> Language Class Initialized
INFO - 2018-08-22 11:13:46 --> Language Class Initialized
INFO - 2018-08-22 11:13:46 --> Config Class Initialized
INFO - 2018-08-22 11:13:46 --> Loader Class Initialized
INFO - 2018-08-22 11:13:46 --> Helper loaded: url_helper
INFO - 2018-08-22 11:13:46 --> Helper loaded: file_helper
INFO - 2018-08-22 11:13:46 --> Helper loaded: form_helper
INFO - 2018-08-22 11:13:46 --> Helper loaded: my_helper
INFO - 2018-08-22 11:13:46 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:13:46 --> Controller Class Initialized
INFO - 2018-08-22 11:13:46 --> Config Class Initialized
INFO - 2018-08-22 11:13:46 --> Hooks Class Initialized
DEBUG - 2018-08-22 11:13:46 --> UTF-8 Support Enabled
INFO - 2018-08-22 11:13:46 --> Utf8 Class Initialized
INFO - 2018-08-22 11:13:46 --> URI Class Initialized
INFO - 2018-08-22 11:13:46 --> Router Class Initialized
INFO - 2018-08-22 11:13:46 --> Output Class Initialized
INFO - 2018-08-22 11:13:46 --> Security Class Initialized
DEBUG - 2018-08-22 11:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-08-22 11:13:46 --> Input Class Initialized
INFO - 2018-08-22 11:13:46 --> Language Class Initialized
INFO - 2018-08-22 11:13:46 --> Language Class Initialized
INFO - 2018-08-22 11:13:46 --> Config Class Initialized
INFO - 2018-08-22 11:13:46 --> Loader Class Initialized
INFO - 2018-08-22 11:13:46 --> Helper loaded: url_helper
INFO - 2018-08-22 11:13:46 --> Helper loaded: file_helper
INFO - 2018-08-22 11:13:46 --> Helper loaded: form_helper
INFO - 2018-08-22 11:13:46 --> Helper loaded: my_helper
INFO - 2018-08-22 11:13:46 --> Database Driver Class Initialized
DEBUG - 2018-08-22 11:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-08-22 11:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-08-22 11:13:46 --> Controller Class Initialized
DEBUG - 2018-08-22 11:13:46 --> File loaded: D:\laragon\www\nilai\application\modules/login/views/login.php
DEBUG - 2018-08-22 11:13:46 --> File loaded: D:\laragon\www\nilai\application\views\template_utama.php
INFO - 2018-08-22 11:13:46 --> Final output sent to browser
DEBUG - 2018-08-22 11:13:46 --> Total execution time: 0.2791
