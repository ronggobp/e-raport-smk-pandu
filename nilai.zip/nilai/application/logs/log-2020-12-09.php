<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-09 02:46:36 --> Config Class Initialized
INFO - 2020-12-09 02:46:36 --> Hooks Class Initialized
DEBUG - 2020-12-09 02:46:36 --> UTF-8 Support Enabled
INFO - 2020-12-09 02:46:36 --> Utf8 Class Initialized
INFO - 2020-12-09 02:46:36 --> URI Class Initialized
DEBUG - 2020-12-09 02:46:37 --> No URI present. Default controller set.
INFO - 2020-12-09 02:46:37 --> Router Class Initialized
INFO - 2020-12-09 02:46:37 --> Output Class Initialized
INFO - 2020-12-09 02:46:37 --> Security Class Initialized
DEBUG - 2020-12-09 02:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-09 02:46:37 --> Input Class Initialized
INFO - 2020-12-09 02:46:37 --> Language Class Initialized
INFO - 2020-12-09 02:46:37 --> Language Class Initialized
INFO - 2020-12-09 02:46:37 --> Config Class Initialized
INFO - 2020-12-09 02:46:37 --> Loader Class Initialized
INFO - 2020-12-09 02:46:37 --> Helper loaded: url_helper
INFO - 2020-12-09 02:46:37 --> Helper loaded: file_helper
INFO - 2020-12-09 02:46:37 --> Helper loaded: form_helper
INFO - 2020-12-09 02:46:37 --> Helper loaded: my_helper
INFO - 2020-12-09 02:46:37 --> Database Driver Class Initialized
DEBUG - 2020-12-09 02:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-09 02:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-09 02:46:37 --> Controller Class Initialized
INFO - 2020-12-09 02:46:37 --> Config Class Initialized
INFO - 2020-12-09 02:46:37 --> Hooks Class Initialized
DEBUG - 2020-12-09 02:46:37 --> UTF-8 Support Enabled
INFO - 2020-12-09 02:46:37 --> Utf8 Class Initialized
INFO - 2020-12-09 02:46:37 --> URI Class Initialized
INFO - 2020-12-09 02:46:37 --> Router Class Initialized
INFO - 2020-12-09 02:46:37 --> Output Class Initialized
INFO - 2020-12-09 02:46:37 --> Security Class Initialized
DEBUG - 2020-12-09 02:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-09 02:46:37 --> Input Class Initialized
INFO - 2020-12-09 02:46:37 --> Language Class Initialized
INFO - 2020-12-09 02:46:37 --> Language Class Initialized
INFO - 2020-12-09 02:46:37 --> Config Class Initialized
INFO - 2020-12-09 02:46:37 --> Loader Class Initialized
INFO - 2020-12-09 02:46:37 --> Helper loaded: url_helper
INFO - 2020-12-09 02:46:37 --> Helper loaded: file_helper
INFO - 2020-12-09 02:46:37 --> Helper loaded: form_helper
INFO - 2020-12-09 02:46:37 --> Helper loaded: my_helper
INFO - 2020-12-09 02:46:37 --> Database Driver Class Initialized
DEBUG - 2020-12-09 02:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-09 02:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-09 02:46:37 --> Controller Class Initialized
DEBUG - 2020-12-09 02:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-09 02:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-09 02:46:37 --> Final output sent to browser
DEBUG - 2020-12-09 02:46:37 --> Total execution time: 0.2193
INFO - 2020-12-09 02:46:43 --> Config Class Initialized
INFO - 2020-12-09 02:46:43 --> Hooks Class Initialized
DEBUG - 2020-12-09 02:46:43 --> UTF-8 Support Enabled
INFO - 2020-12-09 02:46:43 --> Utf8 Class Initialized
INFO - 2020-12-09 02:46:43 --> URI Class Initialized
INFO - 2020-12-09 02:46:43 --> Router Class Initialized
INFO - 2020-12-09 02:46:43 --> Output Class Initialized
INFO - 2020-12-09 02:46:43 --> Security Class Initialized
DEBUG - 2020-12-09 02:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-09 02:46:43 --> Input Class Initialized
INFO - 2020-12-09 02:46:43 --> Language Class Initialized
INFO - 2020-12-09 02:46:43 --> Language Class Initialized
INFO - 2020-12-09 02:46:43 --> Config Class Initialized
INFO - 2020-12-09 02:46:43 --> Loader Class Initialized
INFO - 2020-12-09 02:46:43 --> Helper loaded: url_helper
INFO - 2020-12-09 02:46:43 --> Helper loaded: file_helper
INFO - 2020-12-09 02:46:43 --> Helper loaded: form_helper
INFO - 2020-12-09 02:46:43 --> Helper loaded: my_helper
INFO - 2020-12-09 02:46:43 --> Database Driver Class Initialized
DEBUG - 2020-12-09 02:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-09 02:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-09 02:46:43 --> Controller Class Initialized
INFO - 2020-12-09 02:46:43 --> Helper loaded: cookie_helper
INFO - 2020-12-09 02:46:43 --> Final output sent to browser
DEBUG - 2020-12-09 02:46:43 --> Total execution time: 0.2406
INFO - 2020-12-09 02:46:44 --> Config Class Initialized
INFO - 2020-12-09 02:46:44 --> Hooks Class Initialized
DEBUG - 2020-12-09 02:46:44 --> UTF-8 Support Enabled
INFO - 2020-12-09 02:46:44 --> Utf8 Class Initialized
INFO - 2020-12-09 02:46:44 --> URI Class Initialized
INFO - 2020-12-09 02:46:44 --> Router Class Initialized
INFO - 2020-12-09 02:46:44 --> Output Class Initialized
INFO - 2020-12-09 02:46:44 --> Security Class Initialized
DEBUG - 2020-12-09 02:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-09 02:46:44 --> Input Class Initialized
INFO - 2020-12-09 02:46:44 --> Language Class Initialized
INFO - 2020-12-09 02:46:44 --> Language Class Initialized
INFO - 2020-12-09 02:46:44 --> Config Class Initialized
INFO - 2020-12-09 02:46:44 --> Loader Class Initialized
INFO - 2020-12-09 02:46:44 --> Helper loaded: url_helper
INFO - 2020-12-09 02:46:44 --> Helper loaded: file_helper
INFO - 2020-12-09 02:46:44 --> Helper loaded: form_helper
INFO - 2020-12-09 02:46:44 --> Helper loaded: my_helper
INFO - 2020-12-09 02:46:44 --> Database Driver Class Initialized
DEBUG - 2020-12-09 02:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-09 02:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-09 02:46:44 --> Controller Class Initialized
DEBUG - 2020-12-09 02:46:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-09 02:46:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-09 02:46:44 --> Final output sent to browser
DEBUG - 2020-12-09 02:46:44 --> Total execution time: 0.2902
INFO - 2020-12-09 02:46:53 --> Config Class Initialized
INFO - 2020-12-09 02:46:53 --> Hooks Class Initialized
DEBUG - 2020-12-09 02:46:53 --> UTF-8 Support Enabled
INFO - 2020-12-09 02:46:53 --> Utf8 Class Initialized
INFO - 2020-12-09 02:46:53 --> URI Class Initialized
INFO - 2020-12-09 02:46:53 --> Router Class Initialized
INFO - 2020-12-09 02:46:53 --> Output Class Initialized
INFO - 2020-12-09 02:46:53 --> Security Class Initialized
DEBUG - 2020-12-09 02:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-09 02:46:53 --> Input Class Initialized
INFO - 2020-12-09 02:46:53 --> Language Class Initialized
INFO - 2020-12-09 02:46:53 --> Language Class Initialized
INFO - 2020-12-09 02:46:53 --> Config Class Initialized
INFO - 2020-12-09 02:46:53 --> Loader Class Initialized
INFO - 2020-12-09 02:46:53 --> Helper loaded: url_helper
INFO - 2020-12-09 02:46:53 --> Helper loaded: file_helper
INFO - 2020-12-09 02:46:53 --> Helper loaded: form_helper
INFO - 2020-12-09 02:46:53 --> Helper loaded: my_helper
INFO - 2020-12-09 02:46:53 --> Database Driver Class Initialized
DEBUG - 2020-12-09 02:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-09 02:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-09 02:46:53 --> Controller Class Initialized
DEBUG - 2020-12-09 02:46:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-12-09 02:46:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-09 02:46:53 --> Final output sent to browser
DEBUG - 2020-12-09 02:46:53 --> Total execution time: 0.2245
INFO - 2020-12-09 02:46:53 --> Config Class Initialized
INFO - 2020-12-09 02:46:53 --> Hooks Class Initialized
DEBUG - 2020-12-09 02:46:53 --> UTF-8 Support Enabled
INFO - 2020-12-09 02:46:53 --> Utf8 Class Initialized
INFO - 2020-12-09 02:46:53 --> URI Class Initialized
INFO - 2020-12-09 02:46:53 --> Router Class Initialized
INFO - 2020-12-09 02:46:53 --> Output Class Initialized
INFO - 2020-12-09 02:46:53 --> Security Class Initialized
DEBUG - 2020-12-09 02:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-09 02:46:53 --> Input Class Initialized
INFO - 2020-12-09 02:46:53 --> Language Class Initialized
INFO - 2020-12-09 02:46:54 --> Language Class Initialized
INFO - 2020-12-09 02:46:54 --> Config Class Initialized
INFO - 2020-12-09 02:46:54 --> Loader Class Initialized
INFO - 2020-12-09 02:46:54 --> Helper loaded: url_helper
INFO - 2020-12-09 02:46:54 --> Helper loaded: file_helper
INFO - 2020-12-09 02:46:54 --> Helper loaded: form_helper
INFO - 2020-12-09 02:46:54 --> Helper loaded: my_helper
INFO - 2020-12-09 02:46:54 --> Database Driver Class Initialized
DEBUG - 2020-12-09 02:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-09 02:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-09 02:46:54 --> Controller Class Initialized
