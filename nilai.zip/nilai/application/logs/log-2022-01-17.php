<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-01-17 05:00:28 --> Config Class Initialized
INFO - 2022-01-17 05:00:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:28 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:28 --> URI Class Initialized
DEBUG - 2022-01-17 05:00:28 --> No URI present. Default controller set.
INFO - 2022-01-17 05:00:28 --> Router Class Initialized
INFO - 2022-01-17 05:00:28 --> Output Class Initialized
INFO - 2022-01-17 05:00:28 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:28 --> Input Class Initialized
INFO - 2022-01-17 05:00:28 --> Language Class Initialized
INFO - 2022-01-17 05:00:28 --> Language Class Initialized
INFO - 2022-01-17 05:00:28 --> Config Class Initialized
INFO - 2022-01-17 05:00:28 --> Loader Class Initialized
INFO - 2022-01-17 05:00:28 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:28 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:28 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:28 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:28 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:28 --> Controller Class Initialized
INFO - 2022-01-17 05:00:28 --> Config Class Initialized
INFO - 2022-01-17 05:00:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:28 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:28 --> URI Class Initialized
INFO - 2022-01-17 05:00:28 --> Router Class Initialized
INFO - 2022-01-17 05:00:28 --> Output Class Initialized
INFO - 2022-01-17 05:00:28 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:28 --> Input Class Initialized
INFO - 2022-01-17 05:00:28 --> Language Class Initialized
INFO - 2022-01-17 05:00:28 --> Language Class Initialized
INFO - 2022-01-17 05:00:28 --> Config Class Initialized
INFO - 2022-01-17 05:00:28 --> Loader Class Initialized
INFO - 2022-01-17 05:00:28 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:28 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:28 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:28 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:28 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:28 --> Controller Class Initialized
DEBUG - 2022-01-17 05:00:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:00:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:00:28 --> Final output sent to browser
DEBUG - 2022-01-17 05:00:28 --> Total execution time: 0.0330
INFO - 2022-01-17 05:00:34 --> Config Class Initialized
INFO - 2022-01-17 05:00:34 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:34 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:34 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:34 --> URI Class Initialized
INFO - 2022-01-17 05:00:34 --> Router Class Initialized
INFO - 2022-01-17 05:00:34 --> Output Class Initialized
INFO - 2022-01-17 05:00:34 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:34 --> Input Class Initialized
INFO - 2022-01-17 05:00:34 --> Language Class Initialized
INFO - 2022-01-17 05:00:34 --> Language Class Initialized
INFO - 2022-01-17 05:00:34 --> Config Class Initialized
INFO - 2022-01-17 05:00:34 --> Loader Class Initialized
INFO - 2022-01-17 05:00:34 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:34 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:34 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:34 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:34 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:34 --> Controller Class Initialized
INFO - 2022-01-17 05:00:34 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:00:34 --> Final output sent to browser
DEBUG - 2022-01-17 05:00:34 --> Total execution time: 0.0570
INFO - 2022-01-17 05:00:34 --> Config Class Initialized
INFO - 2022-01-17 05:00:34 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:34 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:34 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:34 --> URI Class Initialized
INFO - 2022-01-17 05:00:34 --> Router Class Initialized
INFO - 2022-01-17 05:00:34 --> Output Class Initialized
INFO - 2022-01-17 05:00:34 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:34 --> Input Class Initialized
INFO - 2022-01-17 05:00:34 --> Language Class Initialized
INFO - 2022-01-17 05:00:34 --> Language Class Initialized
INFO - 2022-01-17 05:00:34 --> Config Class Initialized
INFO - 2022-01-17 05:00:34 --> Loader Class Initialized
INFO - 2022-01-17 05:00:34 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:34 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:34 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:34 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:34 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:34 --> Controller Class Initialized
DEBUG - 2022-01-17 05:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:00:35 --> Final output sent to browser
DEBUG - 2022-01-17 05:00:35 --> Total execution time: 0.8120
INFO - 2022-01-17 05:00:39 --> Config Class Initialized
INFO - 2022-01-17 05:00:39 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:39 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:39 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:39 --> URI Class Initialized
INFO - 2022-01-17 05:00:39 --> Router Class Initialized
INFO - 2022-01-17 05:00:39 --> Output Class Initialized
INFO - 2022-01-17 05:00:39 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:39 --> Input Class Initialized
INFO - 2022-01-17 05:00:39 --> Language Class Initialized
INFO - 2022-01-17 05:00:39 --> Language Class Initialized
INFO - 2022-01-17 05:00:39 --> Config Class Initialized
INFO - 2022-01-17 05:00:39 --> Loader Class Initialized
INFO - 2022-01-17 05:00:39 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:39 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:39 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:39 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:39 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:40 --> Controller Class Initialized
DEBUG - 2022-01-17 05:00:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-17 05:00:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:00:40 --> Final output sent to browser
DEBUG - 2022-01-17 05:00:40 --> Total execution time: 0.0520
INFO - 2022-01-17 05:00:40 --> Config Class Initialized
INFO - 2022-01-17 05:00:40 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:40 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:40 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:40 --> URI Class Initialized
INFO - 2022-01-17 05:00:40 --> Router Class Initialized
INFO - 2022-01-17 05:00:40 --> Output Class Initialized
INFO - 2022-01-17 05:00:40 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:40 --> Input Class Initialized
INFO - 2022-01-17 05:00:40 --> Language Class Initialized
INFO - 2022-01-17 05:00:40 --> Language Class Initialized
INFO - 2022-01-17 05:00:40 --> Config Class Initialized
INFO - 2022-01-17 05:00:40 --> Loader Class Initialized
INFO - 2022-01-17 05:00:40 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:40 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:40 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:40 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:40 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:40 --> Controller Class Initialized
INFO - 2022-01-17 05:00:44 --> Config Class Initialized
INFO - 2022-01-17 05:00:44 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:44 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:44 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:44 --> URI Class Initialized
INFO - 2022-01-17 05:00:44 --> Router Class Initialized
INFO - 2022-01-17 05:00:44 --> Output Class Initialized
INFO - 2022-01-17 05:00:44 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:44 --> Input Class Initialized
INFO - 2022-01-17 05:00:44 --> Language Class Initialized
INFO - 2022-01-17 05:00:44 --> Language Class Initialized
INFO - 2022-01-17 05:00:44 --> Config Class Initialized
INFO - 2022-01-17 05:00:44 --> Loader Class Initialized
INFO - 2022-01-17 05:00:44 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:44 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:44 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:44 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:44 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:44 --> Controller Class Initialized
INFO - 2022-01-17 05:00:44 --> Final output sent to browser
DEBUG - 2022-01-17 05:00:44 --> Total execution time: 0.0630
INFO - 2022-01-17 05:00:44 --> Config Class Initialized
INFO - 2022-01-17 05:00:44 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:44 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:44 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:44 --> URI Class Initialized
INFO - 2022-01-17 05:00:44 --> Router Class Initialized
INFO - 2022-01-17 05:00:44 --> Output Class Initialized
INFO - 2022-01-17 05:00:44 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:44 --> Input Class Initialized
INFO - 2022-01-17 05:00:44 --> Language Class Initialized
INFO - 2022-01-17 05:00:44 --> Language Class Initialized
INFO - 2022-01-17 05:00:44 --> Config Class Initialized
INFO - 2022-01-17 05:00:44 --> Loader Class Initialized
INFO - 2022-01-17 05:00:44 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:44 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:44 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:44 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:44 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:44 --> Controller Class Initialized
INFO - 2022-01-17 05:00:48 --> Config Class Initialized
INFO - 2022-01-17 05:00:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:48 --> URI Class Initialized
INFO - 2022-01-17 05:00:48 --> Router Class Initialized
INFO - 2022-01-17 05:00:48 --> Output Class Initialized
INFO - 2022-01-17 05:00:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:48 --> Input Class Initialized
INFO - 2022-01-17 05:00:48 --> Language Class Initialized
INFO - 2022-01-17 05:00:48 --> Language Class Initialized
INFO - 2022-01-17 05:00:48 --> Config Class Initialized
INFO - 2022-01-17 05:00:48 --> Loader Class Initialized
INFO - 2022-01-17 05:00:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:48 --> Controller Class Initialized
INFO - 2022-01-17 05:00:48 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:00:48 --> Config Class Initialized
INFO - 2022-01-17 05:00:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:48 --> URI Class Initialized
INFO - 2022-01-17 05:00:48 --> Router Class Initialized
INFO - 2022-01-17 05:00:48 --> Output Class Initialized
INFO - 2022-01-17 05:00:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:48 --> Input Class Initialized
INFO - 2022-01-17 05:00:48 --> Language Class Initialized
INFO - 2022-01-17 05:00:48 --> Language Class Initialized
INFO - 2022-01-17 05:00:48 --> Config Class Initialized
INFO - 2022-01-17 05:00:48 --> Loader Class Initialized
INFO - 2022-01-17 05:00:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:48 --> Controller Class Initialized
DEBUG - 2022-01-17 05:00:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:00:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:00:48 --> Final output sent to browser
DEBUG - 2022-01-17 05:00:48 --> Total execution time: 0.0360
INFO - 2022-01-17 05:00:57 --> Config Class Initialized
INFO - 2022-01-17 05:00:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:57 --> URI Class Initialized
INFO - 2022-01-17 05:00:57 --> Router Class Initialized
INFO - 2022-01-17 05:00:57 --> Output Class Initialized
INFO - 2022-01-17 05:00:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:57 --> Input Class Initialized
INFO - 2022-01-17 05:00:57 --> Language Class Initialized
INFO - 2022-01-17 05:00:57 --> Language Class Initialized
INFO - 2022-01-17 05:00:57 --> Config Class Initialized
INFO - 2022-01-17 05:00:57 --> Loader Class Initialized
INFO - 2022-01-17 05:00:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:57 --> Controller Class Initialized
INFO - 2022-01-17 05:00:57 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:00:57 --> Final output sent to browser
DEBUG - 2022-01-17 05:00:57 --> Total execution time: 0.0570
INFO - 2022-01-17 05:00:57 --> Config Class Initialized
INFO - 2022-01-17 05:00:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:00:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:00:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:00:57 --> URI Class Initialized
INFO - 2022-01-17 05:00:57 --> Router Class Initialized
INFO - 2022-01-17 05:00:57 --> Output Class Initialized
INFO - 2022-01-17 05:00:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:00:57 --> Input Class Initialized
INFO - 2022-01-17 05:00:57 --> Language Class Initialized
INFO - 2022-01-17 05:00:57 --> Language Class Initialized
INFO - 2022-01-17 05:00:57 --> Config Class Initialized
INFO - 2022-01-17 05:00:57 --> Loader Class Initialized
INFO - 2022-01-17 05:00:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:00:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:00:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:00:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:00:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:00:57 --> Controller Class Initialized
DEBUG - 2022-01-17 05:00:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:00:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:00:58 --> Final output sent to browser
DEBUG - 2022-01-17 05:00:58 --> Total execution time: 0.3320
INFO - 2022-01-17 05:02:34 --> Config Class Initialized
INFO - 2022-01-17 05:02:34 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:02:34 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:02:34 --> Utf8 Class Initialized
INFO - 2022-01-17 05:02:34 --> URI Class Initialized
INFO - 2022-01-17 05:02:34 --> Router Class Initialized
INFO - 2022-01-17 05:02:34 --> Output Class Initialized
INFO - 2022-01-17 05:02:34 --> Security Class Initialized
DEBUG - 2022-01-17 05:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:02:34 --> Input Class Initialized
INFO - 2022-01-17 05:02:34 --> Language Class Initialized
INFO - 2022-01-17 05:02:34 --> Language Class Initialized
INFO - 2022-01-17 05:02:34 --> Config Class Initialized
INFO - 2022-01-17 05:02:34 --> Loader Class Initialized
INFO - 2022-01-17 05:02:34 --> Helper loaded: url_helper
INFO - 2022-01-17 05:02:34 --> Helper loaded: file_helper
INFO - 2022-01-17 05:02:34 --> Helper loaded: form_helper
INFO - 2022-01-17 05:02:34 --> Helper loaded: my_helper
INFO - 2022-01-17 05:02:34 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:02:34 --> Controller Class Initialized
DEBUG - 2022-01-17 05:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:02:34 --> Final output sent to browser
DEBUG - 2022-01-17 05:02:34 --> Total execution time: 0.2920
INFO - 2022-01-17 05:03:42 --> Config Class Initialized
INFO - 2022-01-17 05:03:42 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:03:42 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:03:42 --> Utf8 Class Initialized
INFO - 2022-01-17 05:03:42 --> URI Class Initialized
INFO - 2022-01-17 05:03:42 --> Router Class Initialized
INFO - 2022-01-17 05:03:42 --> Output Class Initialized
INFO - 2022-01-17 05:03:42 --> Security Class Initialized
DEBUG - 2022-01-17 05:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:03:42 --> Input Class Initialized
INFO - 2022-01-17 05:03:42 --> Language Class Initialized
INFO - 2022-01-17 05:03:42 --> Language Class Initialized
INFO - 2022-01-17 05:03:42 --> Config Class Initialized
INFO - 2022-01-17 05:03:42 --> Loader Class Initialized
INFO - 2022-01-17 05:03:42 --> Helper loaded: url_helper
INFO - 2022-01-17 05:03:42 --> Helper loaded: file_helper
INFO - 2022-01-17 05:03:42 --> Helper loaded: form_helper
INFO - 2022-01-17 05:03:42 --> Helper loaded: my_helper
INFO - 2022-01-17 05:03:42 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:03:42 --> Controller Class Initialized
DEBUG - 2022-01-17 05:03:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:03:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:03:42 --> Final output sent to browser
DEBUG - 2022-01-17 05:03:42 --> Total execution time: 0.2970
INFO - 2022-01-17 05:03:43 --> Config Class Initialized
INFO - 2022-01-17 05:03:43 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:03:43 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:03:43 --> Utf8 Class Initialized
INFO - 2022-01-17 05:03:43 --> URI Class Initialized
INFO - 2022-01-17 05:03:43 --> Router Class Initialized
INFO - 2022-01-17 05:03:43 --> Output Class Initialized
INFO - 2022-01-17 05:03:43 --> Security Class Initialized
DEBUG - 2022-01-17 05:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:03:43 --> Input Class Initialized
INFO - 2022-01-17 05:03:43 --> Language Class Initialized
INFO - 2022-01-17 05:03:43 --> Language Class Initialized
INFO - 2022-01-17 05:03:43 --> Config Class Initialized
INFO - 2022-01-17 05:03:43 --> Loader Class Initialized
INFO - 2022-01-17 05:03:43 --> Helper loaded: url_helper
INFO - 2022-01-17 05:03:43 --> Helper loaded: file_helper
INFO - 2022-01-17 05:03:43 --> Helper loaded: form_helper
INFO - 2022-01-17 05:03:43 --> Helper loaded: my_helper
INFO - 2022-01-17 05:03:43 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:03:43 --> Controller Class Initialized
DEBUG - 2022-01-17 05:03:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:03:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:03:43 --> Final output sent to browser
DEBUG - 2022-01-17 05:03:43 --> Total execution time: 0.2840
INFO - 2022-01-17 05:03:54 --> Config Class Initialized
INFO - 2022-01-17 05:03:54 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:03:54 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:03:54 --> Utf8 Class Initialized
INFO - 2022-01-17 05:03:54 --> URI Class Initialized
INFO - 2022-01-17 05:03:54 --> Router Class Initialized
INFO - 2022-01-17 05:03:54 --> Output Class Initialized
INFO - 2022-01-17 05:03:54 --> Security Class Initialized
DEBUG - 2022-01-17 05:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:03:54 --> Input Class Initialized
INFO - 2022-01-17 05:03:54 --> Language Class Initialized
INFO - 2022-01-17 05:03:54 --> Language Class Initialized
INFO - 2022-01-17 05:03:54 --> Config Class Initialized
INFO - 2022-01-17 05:03:54 --> Loader Class Initialized
INFO - 2022-01-17 05:03:54 --> Helper loaded: url_helper
INFO - 2022-01-17 05:03:54 --> Helper loaded: file_helper
INFO - 2022-01-17 05:03:54 --> Helper loaded: form_helper
INFO - 2022-01-17 05:03:54 --> Helper loaded: my_helper
INFO - 2022-01-17 05:03:54 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:03:54 --> Controller Class Initialized
DEBUG - 2022-01-17 05:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-01-17 05:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:03:54 --> Final output sent to browser
DEBUG - 2022-01-17 05:03:54 --> Total execution time: 0.1990
INFO - 2022-01-17 05:03:56 --> Config Class Initialized
INFO - 2022-01-17 05:03:56 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:03:56 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:03:56 --> Utf8 Class Initialized
INFO - 2022-01-17 05:03:56 --> URI Class Initialized
DEBUG - 2022-01-17 05:03:56 --> No URI present. Default controller set.
INFO - 2022-01-17 05:03:56 --> Router Class Initialized
INFO - 2022-01-17 05:03:56 --> Output Class Initialized
INFO - 2022-01-17 05:03:56 --> Security Class Initialized
DEBUG - 2022-01-17 05:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:03:56 --> Input Class Initialized
INFO - 2022-01-17 05:03:56 --> Language Class Initialized
INFO - 2022-01-17 05:03:56 --> Language Class Initialized
INFO - 2022-01-17 05:03:56 --> Config Class Initialized
INFO - 2022-01-17 05:03:56 --> Loader Class Initialized
INFO - 2022-01-17 05:03:56 --> Helper loaded: url_helper
INFO - 2022-01-17 05:03:56 --> Helper loaded: file_helper
INFO - 2022-01-17 05:03:56 --> Helper loaded: form_helper
INFO - 2022-01-17 05:03:56 --> Helper loaded: my_helper
INFO - 2022-01-17 05:03:56 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:03:56 --> Controller Class Initialized
DEBUG - 2022-01-17 05:03:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:03:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:03:56 --> Final output sent to browser
DEBUG - 2022-01-17 05:03:56 --> Total execution time: 0.4030
INFO - 2022-01-17 05:03:59 --> Config Class Initialized
INFO - 2022-01-17 05:03:59 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:03:59 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:03:59 --> Utf8 Class Initialized
INFO - 2022-01-17 05:03:59 --> URI Class Initialized
INFO - 2022-01-17 05:03:59 --> Router Class Initialized
INFO - 2022-01-17 05:03:59 --> Output Class Initialized
INFO - 2022-01-17 05:03:59 --> Security Class Initialized
DEBUG - 2022-01-17 05:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:03:59 --> Input Class Initialized
INFO - 2022-01-17 05:03:59 --> Language Class Initialized
INFO - 2022-01-17 05:03:59 --> Language Class Initialized
INFO - 2022-01-17 05:03:59 --> Config Class Initialized
INFO - 2022-01-17 05:03:59 --> Loader Class Initialized
INFO - 2022-01-17 05:03:59 --> Helper loaded: url_helper
INFO - 2022-01-17 05:03:59 --> Helper loaded: file_helper
INFO - 2022-01-17 05:03:59 --> Helper loaded: form_helper
INFO - 2022-01-17 05:03:59 --> Helper loaded: my_helper
INFO - 2022-01-17 05:03:59 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:03:59 --> Controller Class Initialized
DEBUG - 2022-01-17 05:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-17 05:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:03:59 --> Final output sent to browser
DEBUG - 2022-01-17 05:03:59 --> Total execution time: 0.0700
INFO - 2022-01-17 05:04:01 --> Config Class Initialized
INFO - 2022-01-17 05:04:01 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:01 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:01 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:01 --> URI Class Initialized
INFO - 2022-01-17 05:04:01 --> Router Class Initialized
INFO - 2022-01-17 05:04:01 --> Output Class Initialized
INFO - 2022-01-17 05:04:01 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:01 --> Input Class Initialized
INFO - 2022-01-17 05:04:01 --> Language Class Initialized
INFO - 2022-01-17 05:04:01 --> Language Class Initialized
INFO - 2022-01-17 05:04:01 --> Config Class Initialized
INFO - 2022-01-17 05:04:01 --> Loader Class Initialized
INFO - 2022-01-17 05:04:01 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:01 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:01 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:01 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:01 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:01 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:01 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:01 --> Total execution time: 0.1230
INFO - 2022-01-17 05:04:10 --> Config Class Initialized
INFO - 2022-01-17 05:04:10 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:10 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:10 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:10 --> URI Class Initialized
INFO - 2022-01-17 05:04:10 --> Router Class Initialized
INFO - 2022-01-17 05:04:10 --> Output Class Initialized
INFO - 2022-01-17 05:04:10 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:10 --> Input Class Initialized
INFO - 2022-01-17 05:04:10 --> Language Class Initialized
INFO - 2022-01-17 05:04:10 --> Language Class Initialized
INFO - 2022-01-17 05:04:10 --> Config Class Initialized
INFO - 2022-01-17 05:04:10 --> Loader Class Initialized
INFO - 2022-01-17 05:04:10 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:10 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:10 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:10 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:10 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:10 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:10 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:10 --> Total execution time: 0.0620
INFO - 2022-01-17 05:04:28 --> Config Class Initialized
INFO - 2022-01-17 05:04:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:28 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:28 --> URI Class Initialized
INFO - 2022-01-17 05:04:28 --> Router Class Initialized
INFO - 2022-01-17 05:04:28 --> Output Class Initialized
INFO - 2022-01-17 05:04:28 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:28 --> Input Class Initialized
INFO - 2022-01-17 05:04:28 --> Language Class Initialized
INFO - 2022-01-17 05:04:28 --> Language Class Initialized
INFO - 2022-01-17 05:04:28 --> Config Class Initialized
INFO - 2022-01-17 05:04:28 --> Loader Class Initialized
INFO - 2022-01-17 05:04:28 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:28 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:28 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:28 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:28 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:28 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:28 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:28 --> Total execution time: 0.0550
INFO - 2022-01-17 05:04:29 --> Config Class Initialized
INFO - 2022-01-17 05:04:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:29 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:29 --> URI Class Initialized
INFO - 2022-01-17 05:04:29 --> Router Class Initialized
INFO - 2022-01-17 05:04:29 --> Output Class Initialized
INFO - 2022-01-17 05:04:29 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:29 --> Input Class Initialized
INFO - 2022-01-17 05:04:29 --> Language Class Initialized
INFO - 2022-01-17 05:04:29 --> Language Class Initialized
INFO - 2022-01-17 05:04:29 --> Config Class Initialized
INFO - 2022-01-17 05:04:29 --> Loader Class Initialized
INFO - 2022-01-17 05:04:29 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:29 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:29 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:29 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:29 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:29 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:30 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:30 --> Total execution time: 0.0660
INFO - 2022-01-17 05:04:31 --> Config Class Initialized
INFO - 2022-01-17 05:04:31 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:31 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:31 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:31 --> URI Class Initialized
INFO - 2022-01-17 05:04:31 --> Router Class Initialized
INFO - 2022-01-17 05:04:31 --> Output Class Initialized
INFO - 2022-01-17 05:04:31 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:31 --> Input Class Initialized
INFO - 2022-01-17 05:04:31 --> Language Class Initialized
INFO - 2022-01-17 05:04:31 --> Language Class Initialized
INFO - 2022-01-17 05:04:31 --> Config Class Initialized
INFO - 2022-01-17 05:04:31 --> Loader Class Initialized
INFO - 2022-01-17 05:04:31 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:31 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:31 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:31 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:31 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:31 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:32 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:32 --> Total execution time: 0.0700
INFO - 2022-01-17 05:04:37 --> Config Class Initialized
INFO - 2022-01-17 05:04:37 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:37 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:37 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:37 --> URI Class Initialized
INFO - 2022-01-17 05:04:37 --> Router Class Initialized
INFO - 2022-01-17 05:04:37 --> Output Class Initialized
INFO - 2022-01-17 05:04:37 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:37 --> Input Class Initialized
INFO - 2022-01-17 05:04:37 --> Language Class Initialized
INFO - 2022-01-17 05:04:37 --> Language Class Initialized
INFO - 2022-01-17 05:04:37 --> Config Class Initialized
INFO - 2022-01-17 05:04:37 --> Loader Class Initialized
INFO - 2022-01-17 05:04:37 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:37 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:37 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:37 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:37 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:37 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:37 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:37 --> Total execution time: 0.0660
INFO - 2022-01-17 05:04:40 --> Config Class Initialized
INFO - 2022-01-17 05:04:40 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:40 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:40 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:40 --> URI Class Initialized
INFO - 2022-01-17 05:04:40 --> Router Class Initialized
INFO - 2022-01-17 05:04:40 --> Output Class Initialized
INFO - 2022-01-17 05:04:40 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:40 --> Input Class Initialized
INFO - 2022-01-17 05:04:40 --> Language Class Initialized
INFO - 2022-01-17 05:04:40 --> Language Class Initialized
INFO - 2022-01-17 05:04:40 --> Config Class Initialized
INFO - 2022-01-17 05:04:40 --> Loader Class Initialized
INFO - 2022-01-17 05:04:40 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:40 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:40 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:40 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:40 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:40 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:41 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:41 --> Total execution time: 0.0690
INFO - 2022-01-17 05:04:42 --> Config Class Initialized
INFO - 2022-01-17 05:04:42 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:42 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:42 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:42 --> URI Class Initialized
INFO - 2022-01-17 05:04:42 --> Router Class Initialized
INFO - 2022-01-17 05:04:42 --> Output Class Initialized
INFO - 2022-01-17 05:04:42 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:42 --> Input Class Initialized
INFO - 2022-01-17 05:04:42 --> Language Class Initialized
INFO - 2022-01-17 05:04:42 --> Language Class Initialized
INFO - 2022-01-17 05:04:42 --> Config Class Initialized
INFO - 2022-01-17 05:04:42 --> Loader Class Initialized
INFO - 2022-01-17 05:04:42 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:42 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:42 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:42 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:42 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:42 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:42 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:42 --> Total execution time: 0.0720
INFO - 2022-01-17 05:04:44 --> Config Class Initialized
INFO - 2022-01-17 05:04:44 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:44 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:44 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:44 --> URI Class Initialized
INFO - 2022-01-17 05:04:44 --> Router Class Initialized
INFO - 2022-01-17 05:04:44 --> Output Class Initialized
INFO - 2022-01-17 05:04:44 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:44 --> Input Class Initialized
INFO - 2022-01-17 05:04:44 --> Language Class Initialized
INFO - 2022-01-17 05:04:44 --> Language Class Initialized
INFO - 2022-01-17 05:04:44 --> Config Class Initialized
INFO - 2022-01-17 05:04:44 --> Loader Class Initialized
INFO - 2022-01-17 05:04:44 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:44 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:44 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:44 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:44 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:44 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:44 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:44 --> Total execution time: 0.0680
INFO - 2022-01-17 05:04:46 --> Config Class Initialized
INFO - 2022-01-17 05:04:46 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:46 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:46 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:46 --> URI Class Initialized
INFO - 2022-01-17 05:04:46 --> Router Class Initialized
INFO - 2022-01-17 05:04:46 --> Output Class Initialized
INFO - 2022-01-17 05:04:46 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:46 --> Input Class Initialized
INFO - 2022-01-17 05:04:46 --> Language Class Initialized
INFO - 2022-01-17 05:04:46 --> Language Class Initialized
INFO - 2022-01-17 05:04:46 --> Config Class Initialized
INFO - 2022-01-17 05:04:46 --> Loader Class Initialized
INFO - 2022-01-17 05:04:46 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:46 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:46 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:46 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:46 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:46 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:46 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:46 --> Total execution time: 0.0570
INFO - 2022-01-17 05:04:49 --> Config Class Initialized
INFO - 2022-01-17 05:04:49 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:49 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:49 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:49 --> URI Class Initialized
INFO - 2022-01-17 05:04:49 --> Router Class Initialized
INFO - 2022-01-17 05:04:49 --> Output Class Initialized
INFO - 2022-01-17 05:04:49 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:49 --> Input Class Initialized
INFO - 2022-01-17 05:04:49 --> Language Class Initialized
INFO - 2022-01-17 05:04:49 --> Language Class Initialized
INFO - 2022-01-17 05:04:49 --> Config Class Initialized
INFO - 2022-01-17 05:04:49 --> Loader Class Initialized
INFO - 2022-01-17 05:04:49 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:49 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:49 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:49 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:49 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:49 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:49 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:49 --> Total execution time: 0.0660
INFO - 2022-01-17 05:04:51 --> Config Class Initialized
INFO - 2022-01-17 05:04:51 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:51 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:51 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:51 --> URI Class Initialized
INFO - 2022-01-17 05:04:51 --> Router Class Initialized
INFO - 2022-01-17 05:04:51 --> Output Class Initialized
INFO - 2022-01-17 05:04:51 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:51 --> Input Class Initialized
INFO - 2022-01-17 05:04:51 --> Language Class Initialized
INFO - 2022-01-17 05:04:51 --> Language Class Initialized
INFO - 2022-01-17 05:04:51 --> Config Class Initialized
INFO - 2022-01-17 05:04:51 --> Loader Class Initialized
INFO - 2022-01-17 05:04:51 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:51 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:51 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:51 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:51 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:51 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:51 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:51 --> Total execution time: 0.0670
INFO - 2022-01-17 05:04:54 --> Config Class Initialized
INFO - 2022-01-17 05:04:54 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:54 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:54 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:54 --> URI Class Initialized
INFO - 2022-01-17 05:04:54 --> Router Class Initialized
INFO - 2022-01-17 05:04:54 --> Output Class Initialized
INFO - 2022-01-17 05:04:54 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:54 --> Input Class Initialized
INFO - 2022-01-17 05:04:54 --> Language Class Initialized
INFO - 2022-01-17 05:04:54 --> Language Class Initialized
INFO - 2022-01-17 05:04:54 --> Config Class Initialized
INFO - 2022-01-17 05:04:54 --> Loader Class Initialized
INFO - 2022-01-17 05:04:54 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:54 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:54 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:54 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:54 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:54 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:54 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:54 --> Total execution time: 0.0550
INFO - 2022-01-17 05:04:56 --> Config Class Initialized
INFO - 2022-01-17 05:04:56 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:56 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:56 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:56 --> URI Class Initialized
INFO - 2022-01-17 05:04:56 --> Router Class Initialized
INFO - 2022-01-17 05:04:56 --> Output Class Initialized
INFO - 2022-01-17 05:04:56 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:56 --> Input Class Initialized
INFO - 2022-01-17 05:04:56 --> Language Class Initialized
INFO - 2022-01-17 05:04:56 --> Language Class Initialized
INFO - 2022-01-17 05:04:56 --> Config Class Initialized
INFO - 2022-01-17 05:04:56 --> Loader Class Initialized
INFO - 2022-01-17 05:04:56 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:56 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:56 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:56 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:56 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:56 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:56 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:56 --> Total execution time: 0.0650
INFO - 2022-01-17 05:04:57 --> Config Class Initialized
INFO - 2022-01-17 05:04:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:57 --> URI Class Initialized
INFO - 2022-01-17 05:04:57 --> Router Class Initialized
INFO - 2022-01-17 05:04:57 --> Output Class Initialized
INFO - 2022-01-17 05:04:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:57 --> Input Class Initialized
INFO - 2022-01-17 05:04:57 --> Language Class Initialized
INFO - 2022-01-17 05:04:57 --> Language Class Initialized
INFO - 2022-01-17 05:04:57 --> Config Class Initialized
INFO - 2022-01-17 05:04:57 --> Loader Class Initialized
INFO - 2022-01-17 05:04:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:57 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:57 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:57 --> Total execution time: 0.0670
INFO - 2022-01-17 05:04:59 --> Config Class Initialized
INFO - 2022-01-17 05:04:59 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:04:59 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:04:59 --> Utf8 Class Initialized
INFO - 2022-01-17 05:04:59 --> URI Class Initialized
INFO - 2022-01-17 05:04:59 --> Router Class Initialized
INFO - 2022-01-17 05:04:59 --> Output Class Initialized
INFO - 2022-01-17 05:04:59 --> Security Class Initialized
DEBUG - 2022-01-17 05:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:04:59 --> Input Class Initialized
INFO - 2022-01-17 05:04:59 --> Language Class Initialized
INFO - 2022-01-17 05:04:59 --> Language Class Initialized
INFO - 2022-01-17 05:04:59 --> Config Class Initialized
INFO - 2022-01-17 05:04:59 --> Loader Class Initialized
INFO - 2022-01-17 05:04:59 --> Helper loaded: url_helper
INFO - 2022-01-17 05:04:59 --> Helper loaded: file_helper
INFO - 2022-01-17 05:04:59 --> Helper loaded: form_helper
INFO - 2022-01-17 05:04:59 --> Helper loaded: my_helper
INFO - 2022-01-17 05:04:59 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:04:59 --> Controller Class Initialized
DEBUG - 2022-01-17 05:04:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:04:59 --> Final output sent to browser
DEBUG - 2022-01-17 05:04:59 --> Total execution time: 0.0690
INFO - 2022-01-17 05:05:01 --> Config Class Initialized
INFO - 2022-01-17 05:05:01 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:01 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:01 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:01 --> URI Class Initialized
INFO - 2022-01-17 05:05:01 --> Router Class Initialized
INFO - 2022-01-17 05:05:01 --> Output Class Initialized
INFO - 2022-01-17 05:05:01 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:01 --> Input Class Initialized
INFO - 2022-01-17 05:05:01 --> Language Class Initialized
INFO - 2022-01-17 05:05:01 --> Language Class Initialized
INFO - 2022-01-17 05:05:01 --> Config Class Initialized
INFO - 2022-01-17 05:05:01 --> Loader Class Initialized
INFO - 2022-01-17 05:05:01 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:01 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:01 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:01 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:01 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:01 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:01 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:01 --> Total execution time: 0.0580
INFO - 2022-01-17 05:05:04 --> Config Class Initialized
INFO - 2022-01-17 05:05:04 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:04 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:04 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:04 --> URI Class Initialized
INFO - 2022-01-17 05:05:04 --> Router Class Initialized
INFO - 2022-01-17 05:05:04 --> Output Class Initialized
INFO - 2022-01-17 05:05:04 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:04 --> Input Class Initialized
INFO - 2022-01-17 05:05:04 --> Language Class Initialized
INFO - 2022-01-17 05:05:04 --> Language Class Initialized
INFO - 2022-01-17 05:05:04 --> Config Class Initialized
INFO - 2022-01-17 05:05:04 --> Loader Class Initialized
INFO - 2022-01-17 05:05:04 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:04 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:04 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:04 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:04 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:04 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:04 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:04 --> Total execution time: 0.0660
INFO - 2022-01-17 05:05:05 --> Config Class Initialized
INFO - 2022-01-17 05:05:05 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:05 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:05 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:05 --> URI Class Initialized
INFO - 2022-01-17 05:05:05 --> Router Class Initialized
INFO - 2022-01-17 05:05:05 --> Output Class Initialized
INFO - 2022-01-17 05:05:05 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:05 --> Input Class Initialized
INFO - 2022-01-17 05:05:05 --> Language Class Initialized
INFO - 2022-01-17 05:05:05 --> Language Class Initialized
INFO - 2022-01-17 05:05:05 --> Config Class Initialized
INFO - 2022-01-17 05:05:05 --> Loader Class Initialized
INFO - 2022-01-17 05:05:05 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:05 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:05 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:05 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:05 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:05 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:05 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:05 --> Total execution time: 0.0670
INFO - 2022-01-17 05:05:07 --> Config Class Initialized
INFO - 2022-01-17 05:05:07 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:07 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:07 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:07 --> URI Class Initialized
INFO - 2022-01-17 05:05:07 --> Router Class Initialized
INFO - 2022-01-17 05:05:07 --> Output Class Initialized
INFO - 2022-01-17 05:05:07 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:07 --> Input Class Initialized
INFO - 2022-01-17 05:05:07 --> Language Class Initialized
INFO - 2022-01-17 05:05:07 --> Language Class Initialized
INFO - 2022-01-17 05:05:07 --> Config Class Initialized
INFO - 2022-01-17 05:05:07 --> Loader Class Initialized
INFO - 2022-01-17 05:05:07 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:07 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:07 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:07 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:07 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:07 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:07 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:07 --> Total execution time: 0.0750
INFO - 2022-01-17 05:05:09 --> Config Class Initialized
INFO - 2022-01-17 05:05:09 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:09 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:09 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:09 --> URI Class Initialized
INFO - 2022-01-17 05:05:09 --> Router Class Initialized
INFO - 2022-01-17 05:05:09 --> Output Class Initialized
INFO - 2022-01-17 05:05:10 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:10 --> Input Class Initialized
INFO - 2022-01-17 05:05:10 --> Language Class Initialized
INFO - 2022-01-17 05:05:10 --> Language Class Initialized
INFO - 2022-01-17 05:05:10 --> Config Class Initialized
INFO - 2022-01-17 05:05:10 --> Loader Class Initialized
INFO - 2022-01-17 05:05:10 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:10 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:10 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:10 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:10 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:10 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:10 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:10 --> Total execution time: 0.0670
INFO - 2022-01-17 05:05:11 --> Config Class Initialized
INFO - 2022-01-17 05:05:11 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:11 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:11 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:11 --> URI Class Initialized
INFO - 2022-01-17 05:05:11 --> Router Class Initialized
INFO - 2022-01-17 05:05:11 --> Output Class Initialized
INFO - 2022-01-17 05:05:11 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:11 --> Input Class Initialized
INFO - 2022-01-17 05:05:11 --> Language Class Initialized
INFO - 2022-01-17 05:05:11 --> Language Class Initialized
INFO - 2022-01-17 05:05:11 --> Config Class Initialized
INFO - 2022-01-17 05:05:11 --> Loader Class Initialized
INFO - 2022-01-17 05:05:11 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:11 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:11 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:11 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:11 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:11 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:11 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:11 --> Total execution time: 0.0720
INFO - 2022-01-17 05:05:13 --> Config Class Initialized
INFO - 2022-01-17 05:05:13 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:13 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:13 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:13 --> URI Class Initialized
INFO - 2022-01-17 05:05:13 --> Router Class Initialized
INFO - 2022-01-17 05:05:13 --> Output Class Initialized
INFO - 2022-01-17 05:05:13 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:13 --> Input Class Initialized
INFO - 2022-01-17 05:05:13 --> Language Class Initialized
INFO - 2022-01-17 05:05:13 --> Language Class Initialized
INFO - 2022-01-17 05:05:13 --> Config Class Initialized
INFO - 2022-01-17 05:05:13 --> Loader Class Initialized
INFO - 2022-01-17 05:05:13 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:13 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:13 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:13 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:13 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:13 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:14 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:14 --> Total execution time: 0.0600
INFO - 2022-01-17 05:05:15 --> Config Class Initialized
INFO - 2022-01-17 05:05:15 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:15 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:15 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:15 --> URI Class Initialized
INFO - 2022-01-17 05:05:15 --> Router Class Initialized
INFO - 2022-01-17 05:05:15 --> Output Class Initialized
INFO - 2022-01-17 05:05:15 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:15 --> Input Class Initialized
INFO - 2022-01-17 05:05:15 --> Language Class Initialized
INFO - 2022-01-17 05:05:15 --> Language Class Initialized
INFO - 2022-01-17 05:05:15 --> Config Class Initialized
INFO - 2022-01-17 05:05:15 --> Loader Class Initialized
INFO - 2022-01-17 05:05:15 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:15 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:15 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:15 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:15 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:15 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:15 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:15 --> Total execution time: 0.0680
INFO - 2022-01-17 05:05:18 --> Config Class Initialized
INFO - 2022-01-17 05:05:18 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:18 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:18 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:18 --> URI Class Initialized
INFO - 2022-01-17 05:05:18 --> Router Class Initialized
INFO - 2022-01-17 05:05:18 --> Output Class Initialized
INFO - 2022-01-17 05:05:18 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:18 --> Input Class Initialized
INFO - 2022-01-17 05:05:18 --> Language Class Initialized
INFO - 2022-01-17 05:05:18 --> Language Class Initialized
INFO - 2022-01-17 05:05:18 --> Config Class Initialized
INFO - 2022-01-17 05:05:18 --> Loader Class Initialized
INFO - 2022-01-17 05:05:18 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:18 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:18 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:18 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:18 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:18 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:18 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:18 --> Total execution time: 0.0740
INFO - 2022-01-17 05:05:19 --> Config Class Initialized
INFO - 2022-01-17 05:05:19 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:19 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:19 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:19 --> URI Class Initialized
INFO - 2022-01-17 05:05:19 --> Router Class Initialized
INFO - 2022-01-17 05:05:19 --> Output Class Initialized
INFO - 2022-01-17 05:05:19 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:19 --> Input Class Initialized
INFO - 2022-01-17 05:05:19 --> Language Class Initialized
INFO - 2022-01-17 05:05:19 --> Language Class Initialized
INFO - 2022-01-17 05:05:19 --> Config Class Initialized
INFO - 2022-01-17 05:05:19 --> Loader Class Initialized
INFO - 2022-01-17 05:05:19 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:19 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:19 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:19 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:19 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:19 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:19 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:19 --> Total execution time: 0.0670
INFO - 2022-01-17 05:05:21 --> Config Class Initialized
INFO - 2022-01-17 05:05:21 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:05:21 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:05:21 --> Utf8 Class Initialized
INFO - 2022-01-17 05:05:21 --> URI Class Initialized
INFO - 2022-01-17 05:05:21 --> Router Class Initialized
INFO - 2022-01-17 05:05:21 --> Output Class Initialized
INFO - 2022-01-17 05:05:21 --> Security Class Initialized
DEBUG - 2022-01-17 05:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:05:21 --> Input Class Initialized
INFO - 2022-01-17 05:05:21 --> Language Class Initialized
INFO - 2022-01-17 05:05:21 --> Language Class Initialized
INFO - 2022-01-17 05:05:21 --> Config Class Initialized
INFO - 2022-01-17 05:05:21 --> Loader Class Initialized
INFO - 2022-01-17 05:05:21 --> Helper loaded: url_helper
INFO - 2022-01-17 05:05:21 --> Helper loaded: file_helper
INFO - 2022-01-17 05:05:21 --> Helper loaded: form_helper
INFO - 2022-01-17 05:05:21 --> Helper loaded: my_helper
INFO - 2022-01-17 05:05:21 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:05:21 --> Controller Class Initialized
DEBUG - 2022-01-17 05:05:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:05:21 --> Final output sent to browser
DEBUG - 2022-01-17 05:05:21 --> Total execution time: 0.0710
INFO - 2022-01-17 05:09:48 --> Config Class Initialized
INFO - 2022-01-17 05:09:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:09:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:09:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:09:48 --> URI Class Initialized
INFO - 2022-01-17 05:09:48 --> Router Class Initialized
INFO - 2022-01-17 05:09:48 --> Output Class Initialized
INFO - 2022-01-17 05:09:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:09:48 --> Input Class Initialized
INFO - 2022-01-17 05:09:48 --> Language Class Initialized
INFO - 2022-01-17 05:09:48 --> Language Class Initialized
INFO - 2022-01-17 05:09:48 --> Config Class Initialized
INFO - 2022-01-17 05:09:48 --> Loader Class Initialized
INFO - 2022-01-17 05:09:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:09:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:09:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:09:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:09:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:09:48 --> Controller Class Initialized
DEBUG - 2022-01-17 05:09:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-17 05:09:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:09:48 --> Final output sent to browser
DEBUG - 2022-01-17 05:09:48 --> Total execution time: 0.0590
INFO - 2022-01-17 05:09:49 --> Config Class Initialized
INFO - 2022-01-17 05:09:49 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:09:49 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:09:49 --> Utf8 Class Initialized
INFO - 2022-01-17 05:09:49 --> URI Class Initialized
INFO - 2022-01-17 05:09:49 --> Router Class Initialized
INFO - 2022-01-17 05:09:49 --> Output Class Initialized
INFO - 2022-01-17 05:09:49 --> Security Class Initialized
DEBUG - 2022-01-17 05:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:09:49 --> Input Class Initialized
INFO - 2022-01-17 05:09:49 --> Language Class Initialized
INFO - 2022-01-17 05:09:49 --> Language Class Initialized
INFO - 2022-01-17 05:09:49 --> Config Class Initialized
INFO - 2022-01-17 05:09:49 --> Loader Class Initialized
INFO - 2022-01-17 05:09:49 --> Helper loaded: url_helper
INFO - 2022-01-17 05:09:49 --> Helper loaded: file_helper
INFO - 2022-01-17 05:09:49 --> Helper loaded: form_helper
INFO - 2022-01-17 05:09:49 --> Helper loaded: my_helper
INFO - 2022-01-17 05:09:49 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:09:49 --> Controller Class Initialized
DEBUG - 2022-01-17 05:09:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2022-01-17 05:09:49 --> Final output sent to browser
DEBUG - 2022-01-17 05:09:49 --> Total execution time: 0.0810
INFO - 2022-01-17 05:10:19 --> Config Class Initialized
INFO - 2022-01-17 05:10:19 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:19 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:19 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:19 --> URI Class Initialized
INFO - 2022-01-17 05:10:19 --> Router Class Initialized
INFO - 2022-01-17 05:10:19 --> Output Class Initialized
INFO - 2022-01-17 05:10:19 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:19 --> Input Class Initialized
INFO - 2022-01-17 05:10:19 --> Language Class Initialized
INFO - 2022-01-17 05:10:19 --> Language Class Initialized
INFO - 2022-01-17 05:10:19 --> Config Class Initialized
INFO - 2022-01-17 05:10:19 --> Loader Class Initialized
INFO - 2022-01-17 05:10:19 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:19 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:19 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:19 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:19 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:19 --> Controller Class Initialized
INFO - 2022-01-17 05:10:19 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:10:19 --> Config Class Initialized
INFO - 2022-01-17 05:10:19 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:19 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:19 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:19 --> URI Class Initialized
INFO - 2022-01-17 05:10:19 --> Router Class Initialized
INFO - 2022-01-17 05:10:19 --> Output Class Initialized
INFO - 2022-01-17 05:10:19 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:19 --> Input Class Initialized
INFO - 2022-01-17 05:10:19 --> Language Class Initialized
INFO - 2022-01-17 05:10:19 --> Language Class Initialized
INFO - 2022-01-17 05:10:19 --> Config Class Initialized
INFO - 2022-01-17 05:10:19 --> Loader Class Initialized
INFO - 2022-01-17 05:10:19 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:19 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:19 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:19 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:19 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:19 --> Controller Class Initialized
DEBUG - 2022-01-17 05:10:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:10:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:10:19 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:19 --> Total execution time: 0.0360
INFO - 2022-01-17 05:10:23 --> Config Class Initialized
INFO - 2022-01-17 05:10:23 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:23 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:23 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:23 --> URI Class Initialized
INFO - 2022-01-17 05:10:23 --> Router Class Initialized
INFO - 2022-01-17 05:10:23 --> Output Class Initialized
INFO - 2022-01-17 05:10:23 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:23 --> Input Class Initialized
INFO - 2022-01-17 05:10:23 --> Language Class Initialized
INFO - 2022-01-17 05:10:23 --> Language Class Initialized
INFO - 2022-01-17 05:10:23 --> Config Class Initialized
INFO - 2022-01-17 05:10:23 --> Loader Class Initialized
INFO - 2022-01-17 05:10:23 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:23 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:23 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:23 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:23 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:23 --> Controller Class Initialized
INFO - 2022-01-17 05:10:23 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:10:23 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:23 --> Total execution time: 0.0570
INFO - 2022-01-17 05:10:23 --> Config Class Initialized
INFO - 2022-01-17 05:10:23 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:23 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:23 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:23 --> URI Class Initialized
INFO - 2022-01-17 05:10:23 --> Router Class Initialized
INFO - 2022-01-17 05:10:23 --> Output Class Initialized
INFO - 2022-01-17 05:10:23 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:23 --> Input Class Initialized
INFO - 2022-01-17 05:10:23 --> Language Class Initialized
INFO - 2022-01-17 05:10:23 --> Language Class Initialized
INFO - 2022-01-17 05:10:23 --> Config Class Initialized
INFO - 2022-01-17 05:10:23 --> Loader Class Initialized
INFO - 2022-01-17 05:10:23 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:23 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:23 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:23 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:23 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:23 --> Controller Class Initialized
DEBUG - 2022-01-17 05:10:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:10:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:10:24 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:24 --> Total execution time: 0.3810
INFO - 2022-01-17 05:10:29 --> Config Class Initialized
INFO - 2022-01-17 05:10:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:29 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:29 --> URI Class Initialized
INFO - 2022-01-17 05:10:29 --> Router Class Initialized
INFO - 2022-01-17 05:10:29 --> Output Class Initialized
INFO - 2022-01-17 05:10:29 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:29 --> Input Class Initialized
INFO - 2022-01-17 05:10:29 --> Language Class Initialized
INFO - 2022-01-17 05:10:29 --> Language Class Initialized
INFO - 2022-01-17 05:10:29 --> Config Class Initialized
INFO - 2022-01-17 05:10:29 --> Loader Class Initialized
INFO - 2022-01-17 05:10:29 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:29 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:29 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:29 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:29 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:29 --> Controller Class Initialized
DEBUG - 2022-01-17 05:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-17 05:10:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:10:29 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:29 --> Total execution time: 0.0450
INFO - 2022-01-17 05:10:29 --> Config Class Initialized
INFO - 2022-01-17 05:10:29 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:29 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:29 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:29 --> URI Class Initialized
INFO - 2022-01-17 05:10:29 --> Router Class Initialized
INFO - 2022-01-17 05:10:29 --> Output Class Initialized
INFO - 2022-01-17 05:10:29 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:29 --> Input Class Initialized
INFO - 2022-01-17 05:10:29 --> Language Class Initialized
INFO - 2022-01-17 05:10:29 --> Language Class Initialized
INFO - 2022-01-17 05:10:29 --> Config Class Initialized
INFO - 2022-01-17 05:10:29 --> Loader Class Initialized
INFO - 2022-01-17 05:10:29 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:29 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:29 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:29 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:29 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:29 --> Controller Class Initialized
INFO - 2022-01-17 05:10:30 --> Config Class Initialized
INFO - 2022-01-17 05:10:30 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:30 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:30 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:30 --> URI Class Initialized
INFO - 2022-01-17 05:10:30 --> Router Class Initialized
INFO - 2022-01-17 05:10:30 --> Output Class Initialized
INFO - 2022-01-17 05:10:30 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:30 --> Input Class Initialized
INFO - 2022-01-17 05:10:30 --> Language Class Initialized
INFO - 2022-01-17 05:10:30 --> Language Class Initialized
INFO - 2022-01-17 05:10:30 --> Config Class Initialized
INFO - 2022-01-17 05:10:30 --> Loader Class Initialized
INFO - 2022-01-17 05:10:30 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:30 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:30 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:30 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:30 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:30 --> Controller Class Initialized
INFO - 2022-01-17 05:10:30 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:30 --> Total execution time: 0.0670
INFO - 2022-01-17 05:10:30 --> Config Class Initialized
INFO - 2022-01-17 05:10:30 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:30 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:30 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:30 --> URI Class Initialized
INFO - 2022-01-17 05:10:30 --> Router Class Initialized
INFO - 2022-01-17 05:10:30 --> Output Class Initialized
INFO - 2022-01-17 05:10:30 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:30 --> Input Class Initialized
INFO - 2022-01-17 05:10:30 --> Language Class Initialized
INFO - 2022-01-17 05:10:30 --> Language Class Initialized
INFO - 2022-01-17 05:10:30 --> Config Class Initialized
INFO - 2022-01-17 05:10:30 --> Loader Class Initialized
INFO - 2022-01-17 05:10:30 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:30 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:30 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:30 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:30 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:30 --> Controller Class Initialized
INFO - 2022-01-17 05:10:32 --> Config Class Initialized
INFO - 2022-01-17 05:10:32 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:32 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:32 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:32 --> URI Class Initialized
INFO - 2022-01-17 05:10:32 --> Router Class Initialized
INFO - 2022-01-17 05:10:32 --> Output Class Initialized
INFO - 2022-01-17 05:10:32 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:32 --> Input Class Initialized
INFO - 2022-01-17 05:10:32 --> Language Class Initialized
INFO - 2022-01-17 05:10:32 --> Language Class Initialized
INFO - 2022-01-17 05:10:32 --> Config Class Initialized
INFO - 2022-01-17 05:10:32 --> Loader Class Initialized
INFO - 2022-01-17 05:10:32 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:32 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:32 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:32 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:32 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:32 --> Controller Class Initialized
INFO - 2022-01-17 05:10:32 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:10:32 --> Config Class Initialized
INFO - 2022-01-17 05:10:32 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:32 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:32 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:32 --> URI Class Initialized
INFO - 2022-01-17 05:10:32 --> Router Class Initialized
INFO - 2022-01-17 05:10:32 --> Output Class Initialized
INFO - 2022-01-17 05:10:32 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:32 --> Input Class Initialized
INFO - 2022-01-17 05:10:32 --> Language Class Initialized
INFO - 2022-01-17 05:10:32 --> Language Class Initialized
INFO - 2022-01-17 05:10:32 --> Config Class Initialized
INFO - 2022-01-17 05:10:32 --> Loader Class Initialized
INFO - 2022-01-17 05:10:32 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:32 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:32 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:32 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:32 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:32 --> Controller Class Initialized
DEBUG - 2022-01-17 05:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:10:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:10:32 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:32 --> Total execution time: 0.0350
INFO - 2022-01-17 05:10:36 --> Config Class Initialized
INFO - 2022-01-17 05:10:36 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:36 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:36 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:36 --> URI Class Initialized
INFO - 2022-01-17 05:10:36 --> Router Class Initialized
INFO - 2022-01-17 05:10:36 --> Output Class Initialized
INFO - 2022-01-17 05:10:36 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:36 --> Input Class Initialized
INFO - 2022-01-17 05:10:36 --> Language Class Initialized
INFO - 2022-01-17 05:10:36 --> Language Class Initialized
INFO - 2022-01-17 05:10:36 --> Config Class Initialized
INFO - 2022-01-17 05:10:36 --> Loader Class Initialized
INFO - 2022-01-17 05:10:36 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:37 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:37 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:37 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:37 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:37 --> Controller Class Initialized
INFO - 2022-01-17 05:10:37 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:10:37 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:37 --> Total execution time: 0.0550
INFO - 2022-01-17 05:10:37 --> Config Class Initialized
INFO - 2022-01-17 05:10:37 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:37 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:37 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:37 --> URI Class Initialized
INFO - 2022-01-17 05:10:37 --> Router Class Initialized
INFO - 2022-01-17 05:10:37 --> Output Class Initialized
INFO - 2022-01-17 05:10:37 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:37 --> Input Class Initialized
INFO - 2022-01-17 05:10:37 --> Language Class Initialized
INFO - 2022-01-17 05:10:37 --> Language Class Initialized
INFO - 2022-01-17 05:10:37 --> Config Class Initialized
INFO - 2022-01-17 05:10:37 --> Loader Class Initialized
INFO - 2022-01-17 05:10:37 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:37 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:37 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:37 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:37 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:37 --> Controller Class Initialized
DEBUG - 2022-01-17 05:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:10:37 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:37 --> Total execution time: 0.2530
INFO - 2022-01-17 05:10:38 --> Config Class Initialized
INFO - 2022-01-17 05:10:38 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:38 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:38 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:38 --> URI Class Initialized
INFO - 2022-01-17 05:10:38 --> Router Class Initialized
INFO - 2022-01-17 05:10:38 --> Output Class Initialized
INFO - 2022-01-17 05:10:38 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:38 --> Input Class Initialized
INFO - 2022-01-17 05:10:38 --> Language Class Initialized
INFO - 2022-01-17 05:10:38 --> Language Class Initialized
INFO - 2022-01-17 05:10:38 --> Config Class Initialized
INFO - 2022-01-17 05:10:38 --> Loader Class Initialized
INFO - 2022-01-17 05:10:38 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:38 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:38 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:38 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:38 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:38 --> Controller Class Initialized
DEBUG - 2022-01-17 05:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-17 05:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:10:38 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:38 --> Total execution time: 0.0600
INFO - 2022-01-17 05:10:41 --> Config Class Initialized
INFO - 2022-01-17 05:10:41 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:10:41 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:10:41 --> Utf8 Class Initialized
INFO - 2022-01-17 05:10:41 --> URI Class Initialized
INFO - 2022-01-17 05:10:41 --> Router Class Initialized
INFO - 2022-01-17 05:10:41 --> Output Class Initialized
INFO - 2022-01-17 05:10:41 --> Security Class Initialized
DEBUG - 2022-01-17 05:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:10:41 --> Input Class Initialized
INFO - 2022-01-17 05:10:41 --> Language Class Initialized
INFO - 2022-01-17 05:10:41 --> Language Class Initialized
INFO - 2022-01-17 05:10:41 --> Config Class Initialized
INFO - 2022-01-17 05:10:41 --> Loader Class Initialized
INFO - 2022-01-17 05:10:41 --> Helper loaded: url_helper
INFO - 2022-01-17 05:10:41 --> Helper loaded: file_helper
INFO - 2022-01-17 05:10:41 --> Helper loaded: form_helper
INFO - 2022-01-17 05:10:41 --> Helper loaded: my_helper
INFO - 2022-01-17 05:10:41 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:10:41 --> Controller Class Initialized
DEBUG - 2022-01-17 05:10:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:10:41 --> Final output sent to browser
DEBUG - 2022-01-17 05:10:41 --> Total execution time: 0.0880
INFO - 2022-01-17 05:11:36 --> Config Class Initialized
INFO - 2022-01-17 05:11:36 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:11:36 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:11:36 --> Utf8 Class Initialized
INFO - 2022-01-17 05:11:36 --> URI Class Initialized
INFO - 2022-01-17 05:11:36 --> Router Class Initialized
INFO - 2022-01-17 05:11:36 --> Output Class Initialized
INFO - 2022-01-17 05:11:36 --> Security Class Initialized
DEBUG - 2022-01-17 05:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:11:36 --> Input Class Initialized
INFO - 2022-01-17 05:11:36 --> Language Class Initialized
INFO - 2022-01-17 05:11:36 --> Language Class Initialized
INFO - 2022-01-17 05:11:36 --> Config Class Initialized
INFO - 2022-01-17 05:11:36 --> Loader Class Initialized
INFO - 2022-01-17 05:11:36 --> Helper loaded: url_helper
INFO - 2022-01-17 05:11:36 --> Helper loaded: file_helper
INFO - 2022-01-17 05:11:36 --> Helper loaded: form_helper
INFO - 2022-01-17 05:11:36 --> Helper loaded: my_helper
INFO - 2022-01-17 05:11:36 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:11:36 --> Controller Class Initialized
DEBUG - 2022-01-17 05:11:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-17 05:11:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:11:36 --> Final output sent to browser
DEBUG - 2022-01-17 05:11:36 --> Total execution time: 0.0570
INFO - 2022-01-17 05:12:34 --> Config Class Initialized
INFO - 2022-01-17 05:12:34 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:12:34 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:12:34 --> Utf8 Class Initialized
INFO - 2022-01-17 05:12:34 --> URI Class Initialized
INFO - 2022-01-17 05:12:34 --> Router Class Initialized
INFO - 2022-01-17 05:12:34 --> Output Class Initialized
INFO - 2022-01-17 05:12:34 --> Security Class Initialized
DEBUG - 2022-01-17 05:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:12:34 --> Input Class Initialized
INFO - 2022-01-17 05:12:34 --> Language Class Initialized
INFO - 2022-01-17 05:12:34 --> Language Class Initialized
INFO - 2022-01-17 05:12:34 --> Config Class Initialized
INFO - 2022-01-17 05:12:34 --> Loader Class Initialized
INFO - 2022-01-17 05:12:34 --> Helper loaded: url_helper
INFO - 2022-01-17 05:12:34 --> Helper loaded: file_helper
INFO - 2022-01-17 05:12:34 --> Helper loaded: form_helper
INFO - 2022-01-17 05:12:34 --> Helper loaded: my_helper
INFO - 2022-01-17 05:12:34 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:12:34 --> Controller Class Initialized
DEBUG - 2022-01-17 05:12:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:12:34 --> Final output sent to browser
DEBUG - 2022-01-17 05:12:34 --> Total execution time: 0.0960
INFO - 2022-01-17 05:13:09 --> Config Class Initialized
INFO - 2022-01-17 05:13:09 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:09 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:09 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:09 --> URI Class Initialized
INFO - 2022-01-17 05:13:09 --> Router Class Initialized
INFO - 2022-01-17 05:13:09 --> Output Class Initialized
INFO - 2022-01-17 05:13:09 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:09 --> Input Class Initialized
INFO - 2022-01-17 05:13:09 --> Language Class Initialized
INFO - 2022-01-17 05:13:10 --> Language Class Initialized
INFO - 2022-01-17 05:13:10 --> Config Class Initialized
INFO - 2022-01-17 05:13:10 --> Loader Class Initialized
INFO - 2022-01-17 05:13:10 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:10 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:10 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:10 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:10 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:10 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:10 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:10 --> Total execution time: 0.0700
INFO - 2022-01-17 05:13:12 --> Config Class Initialized
INFO - 2022-01-17 05:13:12 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:12 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:12 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:12 --> URI Class Initialized
INFO - 2022-01-17 05:13:12 --> Router Class Initialized
INFO - 2022-01-17 05:13:12 --> Output Class Initialized
INFO - 2022-01-17 05:13:12 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:12 --> Input Class Initialized
INFO - 2022-01-17 05:13:12 --> Language Class Initialized
INFO - 2022-01-17 05:13:12 --> Language Class Initialized
INFO - 2022-01-17 05:13:12 --> Config Class Initialized
INFO - 2022-01-17 05:13:12 --> Loader Class Initialized
INFO - 2022-01-17 05:13:12 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:12 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:12 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:12 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:12 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:12 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:12 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:12 --> Total execution time: 0.0650
INFO - 2022-01-17 05:13:14 --> Config Class Initialized
INFO - 2022-01-17 05:13:14 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:14 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:14 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:14 --> URI Class Initialized
INFO - 2022-01-17 05:13:14 --> Router Class Initialized
INFO - 2022-01-17 05:13:14 --> Output Class Initialized
INFO - 2022-01-17 05:13:14 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:14 --> Input Class Initialized
INFO - 2022-01-17 05:13:14 --> Language Class Initialized
INFO - 2022-01-17 05:13:14 --> Language Class Initialized
INFO - 2022-01-17 05:13:14 --> Config Class Initialized
INFO - 2022-01-17 05:13:14 --> Loader Class Initialized
INFO - 2022-01-17 05:13:14 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:14 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:14 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:14 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:14 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:14 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:14 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:14 --> Total execution time: 0.0720
INFO - 2022-01-17 05:13:17 --> Config Class Initialized
INFO - 2022-01-17 05:13:17 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:17 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:17 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:17 --> URI Class Initialized
INFO - 2022-01-17 05:13:17 --> Router Class Initialized
INFO - 2022-01-17 05:13:17 --> Output Class Initialized
INFO - 2022-01-17 05:13:17 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:17 --> Input Class Initialized
INFO - 2022-01-17 05:13:17 --> Language Class Initialized
INFO - 2022-01-17 05:13:17 --> Language Class Initialized
INFO - 2022-01-17 05:13:17 --> Config Class Initialized
INFO - 2022-01-17 05:13:17 --> Loader Class Initialized
INFO - 2022-01-17 05:13:17 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:17 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:17 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:17 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:17 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:17 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:17 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:17 --> Total execution time: 0.0690
INFO - 2022-01-17 05:13:19 --> Config Class Initialized
INFO - 2022-01-17 05:13:19 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:19 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:19 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:19 --> URI Class Initialized
INFO - 2022-01-17 05:13:19 --> Router Class Initialized
INFO - 2022-01-17 05:13:19 --> Output Class Initialized
INFO - 2022-01-17 05:13:19 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:19 --> Input Class Initialized
INFO - 2022-01-17 05:13:19 --> Language Class Initialized
INFO - 2022-01-17 05:13:19 --> Language Class Initialized
INFO - 2022-01-17 05:13:19 --> Config Class Initialized
INFO - 2022-01-17 05:13:19 --> Loader Class Initialized
INFO - 2022-01-17 05:13:19 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:19 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:19 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:19 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:19 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:19 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:19 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:19 --> Total execution time: 0.0650
INFO - 2022-01-17 05:13:21 --> Config Class Initialized
INFO - 2022-01-17 05:13:21 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:21 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:21 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:21 --> URI Class Initialized
INFO - 2022-01-17 05:13:21 --> Router Class Initialized
INFO - 2022-01-17 05:13:21 --> Output Class Initialized
INFO - 2022-01-17 05:13:21 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:21 --> Input Class Initialized
INFO - 2022-01-17 05:13:21 --> Language Class Initialized
INFO - 2022-01-17 05:13:21 --> Language Class Initialized
INFO - 2022-01-17 05:13:21 --> Config Class Initialized
INFO - 2022-01-17 05:13:21 --> Loader Class Initialized
INFO - 2022-01-17 05:13:21 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:21 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:21 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:21 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:21 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:21 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:21 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:21 --> Total execution time: 0.0620
INFO - 2022-01-17 05:13:23 --> Config Class Initialized
INFO - 2022-01-17 05:13:23 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:23 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:23 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:23 --> URI Class Initialized
INFO - 2022-01-17 05:13:23 --> Router Class Initialized
INFO - 2022-01-17 05:13:23 --> Output Class Initialized
INFO - 2022-01-17 05:13:23 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:23 --> Input Class Initialized
INFO - 2022-01-17 05:13:23 --> Language Class Initialized
INFO - 2022-01-17 05:13:23 --> Language Class Initialized
INFO - 2022-01-17 05:13:23 --> Config Class Initialized
INFO - 2022-01-17 05:13:23 --> Loader Class Initialized
INFO - 2022-01-17 05:13:23 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:23 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:23 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:23 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:23 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:24 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:24 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:24 --> Total execution time: 0.0610
INFO - 2022-01-17 05:13:25 --> Config Class Initialized
INFO - 2022-01-17 05:13:25 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:25 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:25 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:25 --> URI Class Initialized
INFO - 2022-01-17 05:13:25 --> Router Class Initialized
INFO - 2022-01-17 05:13:25 --> Output Class Initialized
INFO - 2022-01-17 05:13:25 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:25 --> Input Class Initialized
INFO - 2022-01-17 05:13:25 --> Language Class Initialized
INFO - 2022-01-17 05:13:25 --> Language Class Initialized
INFO - 2022-01-17 05:13:25 --> Config Class Initialized
INFO - 2022-01-17 05:13:25 --> Loader Class Initialized
INFO - 2022-01-17 05:13:25 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:25 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:25 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:25 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:25 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:25 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:25 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:25 --> Total execution time: 0.0570
INFO - 2022-01-17 05:13:28 --> Config Class Initialized
INFO - 2022-01-17 05:13:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:28 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:28 --> URI Class Initialized
INFO - 2022-01-17 05:13:28 --> Router Class Initialized
INFO - 2022-01-17 05:13:28 --> Output Class Initialized
INFO - 2022-01-17 05:13:28 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:28 --> Input Class Initialized
INFO - 2022-01-17 05:13:28 --> Language Class Initialized
INFO - 2022-01-17 05:13:28 --> Language Class Initialized
INFO - 2022-01-17 05:13:28 --> Config Class Initialized
INFO - 2022-01-17 05:13:28 --> Loader Class Initialized
INFO - 2022-01-17 05:13:28 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:28 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:28 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:28 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:28 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:28 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:28 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:28 --> Total execution time: 0.0520
INFO - 2022-01-17 05:13:30 --> Config Class Initialized
INFO - 2022-01-17 05:13:30 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:30 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:30 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:30 --> URI Class Initialized
INFO - 2022-01-17 05:13:30 --> Router Class Initialized
INFO - 2022-01-17 05:13:30 --> Output Class Initialized
INFO - 2022-01-17 05:13:30 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:30 --> Input Class Initialized
INFO - 2022-01-17 05:13:30 --> Language Class Initialized
INFO - 2022-01-17 05:13:30 --> Language Class Initialized
INFO - 2022-01-17 05:13:30 --> Config Class Initialized
INFO - 2022-01-17 05:13:30 --> Loader Class Initialized
INFO - 2022-01-17 05:13:30 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:30 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:30 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:30 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:30 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:30 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:30 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:30 --> Total execution time: 0.0630
INFO - 2022-01-17 05:13:33 --> Config Class Initialized
INFO - 2022-01-17 05:13:33 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:33 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:33 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:33 --> URI Class Initialized
INFO - 2022-01-17 05:13:33 --> Router Class Initialized
INFO - 2022-01-17 05:13:33 --> Output Class Initialized
INFO - 2022-01-17 05:13:33 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:33 --> Input Class Initialized
INFO - 2022-01-17 05:13:33 --> Language Class Initialized
INFO - 2022-01-17 05:13:33 --> Language Class Initialized
INFO - 2022-01-17 05:13:33 --> Config Class Initialized
INFO - 2022-01-17 05:13:33 --> Loader Class Initialized
INFO - 2022-01-17 05:13:33 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:33 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:33 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:33 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:33 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:33 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:33 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:33 --> Total execution time: 0.0630
INFO - 2022-01-17 05:13:35 --> Config Class Initialized
INFO - 2022-01-17 05:13:35 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:35 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:35 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:35 --> URI Class Initialized
INFO - 2022-01-17 05:13:35 --> Router Class Initialized
INFO - 2022-01-17 05:13:35 --> Output Class Initialized
INFO - 2022-01-17 05:13:35 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:35 --> Input Class Initialized
INFO - 2022-01-17 05:13:35 --> Language Class Initialized
INFO - 2022-01-17 05:13:35 --> Language Class Initialized
INFO - 2022-01-17 05:13:35 --> Config Class Initialized
INFO - 2022-01-17 05:13:35 --> Loader Class Initialized
INFO - 2022-01-17 05:13:35 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:35 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:35 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:35 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:35 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:35 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:35 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:35 --> Total execution time: 0.0560
INFO - 2022-01-17 05:13:38 --> Config Class Initialized
INFO - 2022-01-17 05:13:38 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:38 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:38 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:38 --> URI Class Initialized
INFO - 2022-01-17 05:13:38 --> Router Class Initialized
INFO - 2022-01-17 05:13:38 --> Output Class Initialized
INFO - 2022-01-17 05:13:38 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:38 --> Input Class Initialized
INFO - 2022-01-17 05:13:38 --> Language Class Initialized
INFO - 2022-01-17 05:13:38 --> Language Class Initialized
INFO - 2022-01-17 05:13:38 --> Config Class Initialized
INFO - 2022-01-17 05:13:38 --> Loader Class Initialized
INFO - 2022-01-17 05:13:38 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:38 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:38 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:38 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:38 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:38 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:38 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:38 --> Total execution time: 0.0620
INFO - 2022-01-17 05:13:40 --> Config Class Initialized
INFO - 2022-01-17 05:13:40 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:40 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:40 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:40 --> URI Class Initialized
INFO - 2022-01-17 05:13:40 --> Router Class Initialized
INFO - 2022-01-17 05:13:40 --> Output Class Initialized
INFO - 2022-01-17 05:13:40 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:40 --> Input Class Initialized
INFO - 2022-01-17 05:13:40 --> Language Class Initialized
INFO - 2022-01-17 05:13:40 --> Language Class Initialized
INFO - 2022-01-17 05:13:40 --> Config Class Initialized
INFO - 2022-01-17 05:13:40 --> Loader Class Initialized
INFO - 2022-01-17 05:13:40 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:40 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:40 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:40 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:40 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:40 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:40 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:40 --> Total execution time: 0.0660
INFO - 2022-01-17 05:13:42 --> Config Class Initialized
INFO - 2022-01-17 05:13:42 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:42 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:42 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:42 --> URI Class Initialized
INFO - 2022-01-17 05:13:42 --> Router Class Initialized
INFO - 2022-01-17 05:13:42 --> Output Class Initialized
INFO - 2022-01-17 05:13:42 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:42 --> Input Class Initialized
INFO - 2022-01-17 05:13:42 --> Language Class Initialized
INFO - 2022-01-17 05:13:43 --> Language Class Initialized
INFO - 2022-01-17 05:13:43 --> Config Class Initialized
INFO - 2022-01-17 05:13:43 --> Loader Class Initialized
INFO - 2022-01-17 05:13:43 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:43 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:43 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:43 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:43 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:43 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:43 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:43 --> Total execution time: 0.0650
INFO - 2022-01-17 05:13:46 --> Config Class Initialized
INFO - 2022-01-17 05:13:46 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:46 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:46 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:46 --> URI Class Initialized
INFO - 2022-01-17 05:13:46 --> Router Class Initialized
INFO - 2022-01-17 05:13:46 --> Output Class Initialized
INFO - 2022-01-17 05:13:46 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:46 --> Input Class Initialized
INFO - 2022-01-17 05:13:46 --> Language Class Initialized
INFO - 2022-01-17 05:13:46 --> Language Class Initialized
INFO - 2022-01-17 05:13:46 --> Config Class Initialized
INFO - 2022-01-17 05:13:46 --> Loader Class Initialized
INFO - 2022-01-17 05:13:46 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:46 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:46 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:46 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:46 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:46 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:46 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:46 --> Total execution time: 0.0560
INFO - 2022-01-17 05:13:48 --> Config Class Initialized
INFO - 2022-01-17 05:13:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:48 --> URI Class Initialized
INFO - 2022-01-17 05:13:48 --> Router Class Initialized
INFO - 2022-01-17 05:13:48 --> Output Class Initialized
INFO - 2022-01-17 05:13:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:48 --> Input Class Initialized
INFO - 2022-01-17 05:13:48 --> Language Class Initialized
INFO - 2022-01-17 05:13:48 --> Language Class Initialized
INFO - 2022-01-17 05:13:48 --> Config Class Initialized
INFO - 2022-01-17 05:13:48 --> Loader Class Initialized
INFO - 2022-01-17 05:13:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:48 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:48 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:48 --> Total execution time: 0.0630
INFO - 2022-01-17 05:13:50 --> Config Class Initialized
INFO - 2022-01-17 05:13:50 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:50 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:50 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:50 --> URI Class Initialized
INFO - 2022-01-17 05:13:50 --> Router Class Initialized
INFO - 2022-01-17 05:13:50 --> Output Class Initialized
INFO - 2022-01-17 05:13:50 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:50 --> Input Class Initialized
INFO - 2022-01-17 05:13:50 --> Language Class Initialized
INFO - 2022-01-17 05:13:50 --> Language Class Initialized
INFO - 2022-01-17 05:13:50 --> Config Class Initialized
INFO - 2022-01-17 05:13:50 --> Loader Class Initialized
INFO - 2022-01-17 05:13:50 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:50 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:50 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:50 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:50 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:50 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:50 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:50 --> Total execution time: 0.0620
INFO - 2022-01-17 05:13:53 --> Config Class Initialized
INFO - 2022-01-17 05:13:53 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:53 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:53 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:53 --> URI Class Initialized
INFO - 2022-01-17 05:13:53 --> Router Class Initialized
INFO - 2022-01-17 05:13:53 --> Output Class Initialized
INFO - 2022-01-17 05:13:53 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:53 --> Input Class Initialized
INFO - 2022-01-17 05:13:53 --> Language Class Initialized
INFO - 2022-01-17 05:13:53 --> Language Class Initialized
INFO - 2022-01-17 05:13:53 --> Config Class Initialized
INFO - 2022-01-17 05:13:53 --> Loader Class Initialized
INFO - 2022-01-17 05:13:53 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:53 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:53 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:53 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:53 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:53 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:53 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:53 --> Total execution time: 0.0660
INFO - 2022-01-17 05:13:55 --> Config Class Initialized
INFO - 2022-01-17 05:13:55 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:55 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:55 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:55 --> URI Class Initialized
INFO - 2022-01-17 05:13:55 --> Router Class Initialized
INFO - 2022-01-17 05:13:55 --> Output Class Initialized
INFO - 2022-01-17 05:13:55 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:55 --> Input Class Initialized
INFO - 2022-01-17 05:13:55 --> Language Class Initialized
INFO - 2022-01-17 05:13:55 --> Language Class Initialized
INFO - 2022-01-17 05:13:55 --> Config Class Initialized
INFO - 2022-01-17 05:13:55 --> Loader Class Initialized
INFO - 2022-01-17 05:13:55 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:55 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:55 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:55 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:55 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:55 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:55 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:55 --> Total execution time: 0.0620
INFO - 2022-01-17 05:13:58 --> Config Class Initialized
INFO - 2022-01-17 05:13:58 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:13:58 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:13:58 --> Utf8 Class Initialized
INFO - 2022-01-17 05:13:58 --> URI Class Initialized
INFO - 2022-01-17 05:13:58 --> Router Class Initialized
INFO - 2022-01-17 05:13:58 --> Output Class Initialized
INFO - 2022-01-17 05:13:58 --> Security Class Initialized
DEBUG - 2022-01-17 05:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:13:58 --> Input Class Initialized
INFO - 2022-01-17 05:13:58 --> Language Class Initialized
INFO - 2022-01-17 05:13:58 --> Language Class Initialized
INFO - 2022-01-17 05:13:58 --> Config Class Initialized
INFO - 2022-01-17 05:13:58 --> Loader Class Initialized
INFO - 2022-01-17 05:13:58 --> Helper loaded: url_helper
INFO - 2022-01-17 05:13:58 --> Helper loaded: file_helper
INFO - 2022-01-17 05:13:58 --> Helper loaded: form_helper
INFO - 2022-01-17 05:13:58 --> Helper loaded: my_helper
INFO - 2022-01-17 05:13:58 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:13:58 --> Controller Class Initialized
DEBUG - 2022-01-17 05:13:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:13:58 --> Final output sent to browser
DEBUG - 2022-01-17 05:13:58 --> Total execution time: 0.0640
INFO - 2022-01-17 05:14:00 --> Config Class Initialized
INFO - 2022-01-17 05:14:00 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:14:00 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:14:00 --> Utf8 Class Initialized
INFO - 2022-01-17 05:14:00 --> URI Class Initialized
INFO - 2022-01-17 05:14:00 --> Router Class Initialized
INFO - 2022-01-17 05:14:00 --> Output Class Initialized
INFO - 2022-01-17 05:14:00 --> Security Class Initialized
DEBUG - 2022-01-17 05:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:14:00 --> Input Class Initialized
INFO - 2022-01-17 05:14:00 --> Language Class Initialized
INFO - 2022-01-17 05:14:00 --> Language Class Initialized
INFO - 2022-01-17 05:14:00 --> Config Class Initialized
INFO - 2022-01-17 05:14:00 --> Loader Class Initialized
INFO - 2022-01-17 05:14:00 --> Helper loaded: url_helper
INFO - 2022-01-17 05:14:00 --> Helper loaded: file_helper
INFO - 2022-01-17 05:14:00 --> Helper loaded: form_helper
INFO - 2022-01-17 05:14:00 --> Helper loaded: my_helper
INFO - 2022-01-17 05:14:00 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:14:00 --> Controller Class Initialized
DEBUG - 2022-01-17 05:14:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:14:00 --> Final output sent to browser
DEBUG - 2022-01-17 05:14:00 --> Total execution time: 0.0720
INFO - 2022-01-17 05:14:03 --> Config Class Initialized
INFO - 2022-01-17 05:14:03 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:14:03 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:14:03 --> Utf8 Class Initialized
INFO - 2022-01-17 05:14:03 --> URI Class Initialized
INFO - 2022-01-17 05:14:03 --> Router Class Initialized
INFO - 2022-01-17 05:14:03 --> Output Class Initialized
INFO - 2022-01-17 05:14:03 --> Security Class Initialized
DEBUG - 2022-01-17 05:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:14:03 --> Input Class Initialized
INFO - 2022-01-17 05:14:03 --> Language Class Initialized
INFO - 2022-01-17 05:14:03 --> Language Class Initialized
INFO - 2022-01-17 05:14:03 --> Config Class Initialized
INFO - 2022-01-17 05:14:03 --> Loader Class Initialized
INFO - 2022-01-17 05:14:03 --> Helper loaded: url_helper
INFO - 2022-01-17 05:14:03 --> Helper loaded: file_helper
INFO - 2022-01-17 05:14:03 --> Helper loaded: form_helper
INFO - 2022-01-17 05:14:03 --> Helper loaded: my_helper
INFO - 2022-01-17 05:14:03 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:14:03 --> Controller Class Initialized
DEBUG - 2022-01-17 05:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:14:03 --> Final output sent to browser
DEBUG - 2022-01-17 05:14:03 --> Total execution time: 0.0640
INFO - 2022-01-17 05:14:05 --> Config Class Initialized
INFO - 2022-01-17 05:14:05 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:14:05 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:14:05 --> Utf8 Class Initialized
INFO - 2022-01-17 05:14:05 --> URI Class Initialized
INFO - 2022-01-17 05:14:05 --> Router Class Initialized
INFO - 2022-01-17 05:14:05 --> Output Class Initialized
INFO - 2022-01-17 05:14:05 --> Security Class Initialized
DEBUG - 2022-01-17 05:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:14:05 --> Input Class Initialized
INFO - 2022-01-17 05:14:05 --> Language Class Initialized
INFO - 2022-01-17 05:14:05 --> Language Class Initialized
INFO - 2022-01-17 05:14:05 --> Config Class Initialized
INFO - 2022-01-17 05:14:05 --> Loader Class Initialized
INFO - 2022-01-17 05:14:05 --> Helper loaded: url_helper
INFO - 2022-01-17 05:14:05 --> Helper loaded: file_helper
INFO - 2022-01-17 05:14:05 --> Helper loaded: form_helper
INFO - 2022-01-17 05:14:05 --> Helper loaded: my_helper
INFO - 2022-01-17 05:14:05 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:14:05 --> Controller Class Initialized
DEBUG - 2022-01-17 05:14:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:14:05 --> Final output sent to browser
DEBUG - 2022-01-17 05:14:05 --> Total execution time: 0.0540
INFO - 2022-01-17 05:14:06 --> Config Class Initialized
INFO - 2022-01-17 05:14:06 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:14:06 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:14:06 --> Utf8 Class Initialized
INFO - 2022-01-17 05:14:06 --> URI Class Initialized
INFO - 2022-01-17 05:14:06 --> Router Class Initialized
INFO - 2022-01-17 05:14:06 --> Output Class Initialized
INFO - 2022-01-17 05:14:06 --> Security Class Initialized
DEBUG - 2022-01-17 05:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:14:06 --> Input Class Initialized
INFO - 2022-01-17 05:14:06 --> Language Class Initialized
INFO - 2022-01-17 05:14:06 --> Language Class Initialized
INFO - 2022-01-17 05:14:06 --> Config Class Initialized
INFO - 2022-01-17 05:14:06 --> Loader Class Initialized
INFO - 2022-01-17 05:14:06 --> Helper loaded: url_helper
INFO - 2022-01-17 05:14:06 --> Helper loaded: file_helper
INFO - 2022-01-17 05:14:06 --> Helper loaded: form_helper
INFO - 2022-01-17 05:14:06 --> Helper loaded: my_helper
INFO - 2022-01-17 05:14:06 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:14:06 --> Controller Class Initialized
DEBUG - 2022-01-17 05:14:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:14:06 --> Final output sent to browser
DEBUG - 2022-01-17 05:14:06 --> Total execution time: 0.0680
INFO - 2022-01-17 05:22:18 --> Config Class Initialized
INFO - 2022-01-17 05:22:18 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:22:18 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:22:18 --> Utf8 Class Initialized
INFO - 2022-01-17 05:22:18 --> URI Class Initialized
INFO - 2022-01-17 05:22:18 --> Router Class Initialized
INFO - 2022-01-17 05:22:18 --> Output Class Initialized
INFO - 2022-01-17 05:22:18 --> Security Class Initialized
DEBUG - 2022-01-17 05:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:22:18 --> Input Class Initialized
INFO - 2022-01-17 05:22:18 --> Language Class Initialized
INFO - 2022-01-17 05:22:18 --> Language Class Initialized
INFO - 2022-01-17 05:22:18 --> Config Class Initialized
INFO - 2022-01-17 05:22:18 --> Loader Class Initialized
INFO - 2022-01-17 05:22:18 --> Helper loaded: url_helper
INFO - 2022-01-17 05:22:18 --> Helper loaded: file_helper
INFO - 2022-01-17 05:22:18 --> Helper loaded: form_helper
INFO - 2022-01-17 05:22:18 --> Helper loaded: my_helper
INFO - 2022-01-17 05:22:18 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:22:18 --> Controller Class Initialized
INFO - 2022-01-17 05:22:18 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:22:18 --> Config Class Initialized
INFO - 2022-01-17 05:22:18 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:22:18 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:22:18 --> Utf8 Class Initialized
INFO - 2022-01-17 05:22:18 --> URI Class Initialized
INFO - 2022-01-17 05:22:18 --> Router Class Initialized
INFO - 2022-01-17 05:22:18 --> Output Class Initialized
INFO - 2022-01-17 05:22:18 --> Security Class Initialized
DEBUG - 2022-01-17 05:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:22:18 --> Input Class Initialized
INFO - 2022-01-17 05:22:18 --> Language Class Initialized
INFO - 2022-01-17 05:22:18 --> Language Class Initialized
INFO - 2022-01-17 05:22:18 --> Config Class Initialized
INFO - 2022-01-17 05:22:18 --> Loader Class Initialized
INFO - 2022-01-17 05:22:18 --> Helper loaded: url_helper
INFO - 2022-01-17 05:22:18 --> Helper loaded: file_helper
INFO - 2022-01-17 05:22:18 --> Helper loaded: form_helper
INFO - 2022-01-17 05:22:18 --> Helper loaded: my_helper
INFO - 2022-01-17 05:22:18 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:22:18 --> Controller Class Initialized
DEBUG - 2022-01-17 05:22:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:22:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:22:18 --> Final output sent to browser
DEBUG - 2022-01-17 05:22:18 --> Total execution time: 0.0420
INFO - 2022-01-17 05:22:33 --> Config Class Initialized
INFO - 2022-01-17 05:22:33 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:22:33 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:22:33 --> Utf8 Class Initialized
INFO - 2022-01-17 05:22:33 --> URI Class Initialized
INFO - 2022-01-17 05:22:33 --> Router Class Initialized
INFO - 2022-01-17 05:22:33 --> Output Class Initialized
INFO - 2022-01-17 05:22:33 --> Security Class Initialized
DEBUG - 2022-01-17 05:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:22:33 --> Input Class Initialized
INFO - 2022-01-17 05:22:33 --> Language Class Initialized
INFO - 2022-01-17 05:22:33 --> Language Class Initialized
INFO - 2022-01-17 05:22:33 --> Config Class Initialized
INFO - 2022-01-17 05:22:33 --> Loader Class Initialized
INFO - 2022-01-17 05:22:33 --> Helper loaded: url_helper
INFO - 2022-01-17 05:22:33 --> Helper loaded: file_helper
INFO - 2022-01-17 05:22:33 --> Helper loaded: form_helper
INFO - 2022-01-17 05:22:33 --> Helper loaded: my_helper
INFO - 2022-01-17 05:22:33 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:22:33 --> Controller Class Initialized
INFO - 2022-01-17 05:22:33 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:22:33 --> Final output sent to browser
DEBUG - 2022-01-17 05:22:33 --> Total execution time: 0.0580
INFO - 2022-01-17 05:22:33 --> Config Class Initialized
INFO - 2022-01-17 05:22:33 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:22:33 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:22:33 --> Utf8 Class Initialized
INFO - 2022-01-17 05:22:33 --> URI Class Initialized
INFO - 2022-01-17 05:22:33 --> Router Class Initialized
INFO - 2022-01-17 05:22:33 --> Output Class Initialized
INFO - 2022-01-17 05:22:33 --> Security Class Initialized
DEBUG - 2022-01-17 05:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:22:33 --> Input Class Initialized
INFO - 2022-01-17 05:22:33 --> Language Class Initialized
INFO - 2022-01-17 05:22:33 --> Language Class Initialized
INFO - 2022-01-17 05:22:33 --> Config Class Initialized
INFO - 2022-01-17 05:22:33 --> Loader Class Initialized
INFO - 2022-01-17 05:22:33 --> Helper loaded: url_helper
INFO - 2022-01-17 05:22:33 --> Helper loaded: file_helper
INFO - 2022-01-17 05:22:33 --> Helper loaded: form_helper
INFO - 2022-01-17 05:22:33 --> Helper loaded: my_helper
INFO - 2022-01-17 05:22:33 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:22:33 --> Controller Class Initialized
DEBUG - 2022-01-17 05:22:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:22:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:22:34 --> Final output sent to browser
DEBUG - 2022-01-17 05:22:34 --> Total execution time: 0.3330
INFO - 2022-01-17 05:22:35 --> Config Class Initialized
INFO - 2022-01-17 05:22:35 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:22:35 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:22:35 --> Utf8 Class Initialized
INFO - 2022-01-17 05:22:35 --> URI Class Initialized
INFO - 2022-01-17 05:22:35 --> Router Class Initialized
INFO - 2022-01-17 05:22:35 --> Output Class Initialized
INFO - 2022-01-17 05:22:35 --> Security Class Initialized
DEBUG - 2022-01-17 05:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:22:35 --> Input Class Initialized
INFO - 2022-01-17 05:22:35 --> Language Class Initialized
INFO - 2022-01-17 05:22:35 --> Language Class Initialized
INFO - 2022-01-17 05:22:35 --> Config Class Initialized
INFO - 2022-01-17 05:22:35 --> Loader Class Initialized
INFO - 2022-01-17 05:22:35 --> Helper loaded: url_helper
INFO - 2022-01-17 05:22:35 --> Helper loaded: file_helper
INFO - 2022-01-17 05:22:35 --> Helper loaded: form_helper
INFO - 2022-01-17 05:22:35 --> Helper loaded: my_helper
INFO - 2022-01-17 05:22:35 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:22:35 --> Controller Class Initialized
DEBUG - 2022-01-17 05:22:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-01-17 05:22:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:22:35 --> Final output sent to browser
DEBUG - 2022-01-17 05:22:35 --> Total execution time: 0.0580
INFO - 2022-01-17 05:22:56 --> Config Class Initialized
INFO - 2022-01-17 05:22:56 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:22:56 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:22:56 --> Utf8 Class Initialized
INFO - 2022-01-17 05:22:56 --> URI Class Initialized
INFO - 2022-01-17 05:22:56 --> Router Class Initialized
INFO - 2022-01-17 05:22:56 --> Output Class Initialized
INFO - 2022-01-17 05:22:56 --> Security Class Initialized
DEBUG - 2022-01-17 05:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:22:56 --> Input Class Initialized
INFO - 2022-01-17 05:22:56 --> Language Class Initialized
INFO - 2022-01-17 05:22:56 --> Language Class Initialized
INFO - 2022-01-17 05:22:56 --> Config Class Initialized
INFO - 2022-01-17 05:22:56 --> Loader Class Initialized
INFO - 2022-01-17 05:22:56 --> Helper loaded: url_helper
INFO - 2022-01-17 05:22:56 --> Helper loaded: file_helper
INFO - 2022-01-17 05:22:56 --> Helper loaded: form_helper
INFO - 2022-01-17 05:22:56 --> Helper loaded: my_helper
INFO - 2022-01-17 05:22:56 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:22:56 --> Controller Class Initialized
DEBUG - 2022-01-17 05:22:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-01-17 05:22:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:22:56 --> Final output sent to browser
DEBUG - 2022-01-17 05:22:56 --> Total execution time: 0.0580
INFO - 2022-01-17 05:22:56 --> Config Class Initialized
INFO - 2022-01-17 05:22:56 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:22:56 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:22:56 --> Utf8 Class Initialized
INFO - 2022-01-17 05:22:56 --> URI Class Initialized
INFO - 2022-01-17 05:22:56 --> Router Class Initialized
INFO - 2022-01-17 05:22:56 --> Output Class Initialized
INFO - 2022-01-17 05:22:56 --> Security Class Initialized
DEBUG - 2022-01-17 05:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:22:56 --> Input Class Initialized
INFO - 2022-01-17 05:22:56 --> Language Class Initialized
INFO - 2022-01-17 05:22:56 --> Language Class Initialized
INFO - 2022-01-17 05:22:56 --> Config Class Initialized
INFO - 2022-01-17 05:22:56 --> Loader Class Initialized
INFO - 2022-01-17 05:22:56 --> Helper loaded: url_helper
INFO - 2022-01-17 05:22:56 --> Helper loaded: file_helper
INFO - 2022-01-17 05:22:56 --> Helper loaded: form_helper
INFO - 2022-01-17 05:22:56 --> Helper loaded: my_helper
INFO - 2022-01-17 05:22:56 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:22:56 --> Controller Class Initialized
INFO - 2022-01-17 05:22:58 --> Config Class Initialized
INFO - 2022-01-17 05:22:58 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:22:58 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:22:58 --> Utf8 Class Initialized
INFO - 2022-01-17 05:22:58 --> URI Class Initialized
INFO - 2022-01-17 05:22:58 --> Router Class Initialized
INFO - 2022-01-17 05:22:58 --> Output Class Initialized
INFO - 2022-01-17 05:22:58 --> Security Class Initialized
DEBUG - 2022-01-17 05:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:22:58 --> Input Class Initialized
INFO - 2022-01-17 05:22:58 --> Language Class Initialized
INFO - 2022-01-17 05:22:58 --> Language Class Initialized
INFO - 2022-01-17 05:22:58 --> Config Class Initialized
INFO - 2022-01-17 05:22:58 --> Loader Class Initialized
INFO - 2022-01-17 05:22:58 --> Helper loaded: url_helper
INFO - 2022-01-17 05:22:58 --> Helper loaded: file_helper
INFO - 2022-01-17 05:22:58 --> Helper loaded: form_helper
INFO - 2022-01-17 05:22:58 --> Helper loaded: my_helper
INFO - 2022-01-17 05:22:58 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:22:58 --> Controller Class Initialized
DEBUG - 2022-01-17 05:22:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-01-17 05:22:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:22:58 --> Final output sent to browser
DEBUG - 2022-01-17 05:22:58 --> Total execution time: 0.0510
INFO - 2022-01-17 05:23:09 --> Config Class Initialized
INFO - 2022-01-17 05:23:09 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:23:09 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:23:09 --> Utf8 Class Initialized
INFO - 2022-01-17 05:23:09 --> URI Class Initialized
INFO - 2022-01-17 05:23:09 --> Router Class Initialized
INFO - 2022-01-17 05:23:09 --> Output Class Initialized
INFO - 2022-01-17 05:23:09 --> Security Class Initialized
DEBUG - 2022-01-17 05:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:23:09 --> Input Class Initialized
INFO - 2022-01-17 05:23:09 --> Language Class Initialized
INFO - 2022-01-17 05:23:09 --> Language Class Initialized
INFO - 2022-01-17 05:23:09 --> Config Class Initialized
INFO - 2022-01-17 05:23:09 --> Loader Class Initialized
INFO - 2022-01-17 05:23:09 --> Helper loaded: url_helper
INFO - 2022-01-17 05:23:09 --> Helper loaded: file_helper
INFO - 2022-01-17 05:23:09 --> Helper loaded: form_helper
INFO - 2022-01-17 05:23:09 --> Helper loaded: my_helper
INFO - 2022-01-17 05:23:09 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:23:09 --> Controller Class Initialized
INFO - 2022-01-17 05:23:11 --> Config Class Initialized
INFO - 2022-01-17 05:23:11 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:23:11 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:23:11 --> Utf8 Class Initialized
INFO - 2022-01-17 05:23:11 --> URI Class Initialized
INFO - 2022-01-17 05:23:11 --> Router Class Initialized
INFO - 2022-01-17 05:23:11 --> Output Class Initialized
INFO - 2022-01-17 05:23:11 --> Security Class Initialized
DEBUG - 2022-01-17 05:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:23:11 --> Input Class Initialized
INFO - 2022-01-17 05:23:11 --> Language Class Initialized
INFO - 2022-01-17 05:23:11 --> Language Class Initialized
INFO - 2022-01-17 05:23:11 --> Config Class Initialized
INFO - 2022-01-17 05:23:11 --> Loader Class Initialized
INFO - 2022-01-17 05:23:11 --> Helper loaded: url_helper
INFO - 2022-01-17 05:23:11 --> Helper loaded: file_helper
INFO - 2022-01-17 05:23:11 --> Helper loaded: form_helper
INFO - 2022-01-17 05:23:11 --> Helper loaded: my_helper
INFO - 2022-01-17 05:23:11 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:23:11 --> Controller Class Initialized
INFO - 2022-01-17 05:24:42 --> Config Class Initialized
INFO - 2022-01-17 05:24:42 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:24:42 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:24:42 --> Utf8 Class Initialized
INFO - 2022-01-17 05:24:42 --> URI Class Initialized
INFO - 2022-01-17 05:24:42 --> Router Class Initialized
INFO - 2022-01-17 05:24:42 --> Output Class Initialized
INFO - 2022-01-17 05:24:42 --> Security Class Initialized
DEBUG - 2022-01-17 05:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:24:42 --> Input Class Initialized
INFO - 2022-01-17 05:24:42 --> Language Class Initialized
INFO - 2022-01-17 05:24:42 --> Language Class Initialized
INFO - 2022-01-17 05:24:42 --> Config Class Initialized
INFO - 2022-01-17 05:24:42 --> Loader Class Initialized
INFO - 2022-01-17 05:24:42 --> Helper loaded: url_helper
INFO - 2022-01-17 05:24:42 --> Helper loaded: file_helper
INFO - 2022-01-17 05:24:42 --> Helper loaded: form_helper
INFO - 2022-01-17 05:24:42 --> Helper loaded: my_helper
INFO - 2022-01-17 05:24:42 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:24:42 --> Controller Class Initialized
DEBUG - 2022-01-17 05:24:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-01-17 05:24:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:24:42 --> Final output sent to browser
DEBUG - 2022-01-17 05:24:42 --> Total execution time: 0.0450
INFO - 2022-01-17 05:24:43 --> Config Class Initialized
INFO - 2022-01-17 05:24:43 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:24:43 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:24:43 --> Utf8 Class Initialized
INFO - 2022-01-17 05:24:43 --> URI Class Initialized
INFO - 2022-01-17 05:24:43 --> Router Class Initialized
INFO - 2022-01-17 05:24:43 --> Output Class Initialized
INFO - 2022-01-17 05:24:43 --> Security Class Initialized
DEBUG - 2022-01-17 05:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:24:43 --> Input Class Initialized
INFO - 2022-01-17 05:24:43 --> Language Class Initialized
INFO - 2022-01-17 05:24:43 --> Language Class Initialized
INFO - 2022-01-17 05:24:43 --> Config Class Initialized
INFO - 2022-01-17 05:24:43 --> Loader Class Initialized
INFO - 2022-01-17 05:24:43 --> Helper loaded: url_helper
INFO - 2022-01-17 05:24:43 --> Helper loaded: file_helper
INFO - 2022-01-17 05:24:43 --> Helper loaded: form_helper
INFO - 2022-01-17 05:24:43 --> Helper loaded: my_helper
INFO - 2022-01-17 05:24:43 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:24:43 --> Controller Class Initialized
INFO - 2022-01-17 05:24:44 --> Config Class Initialized
INFO - 2022-01-17 05:24:44 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:24:44 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:24:44 --> Utf8 Class Initialized
INFO - 2022-01-17 05:24:44 --> URI Class Initialized
INFO - 2022-01-17 05:24:44 --> Router Class Initialized
INFO - 2022-01-17 05:24:44 --> Output Class Initialized
INFO - 2022-01-17 05:24:44 --> Security Class Initialized
DEBUG - 2022-01-17 05:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:24:44 --> Input Class Initialized
INFO - 2022-01-17 05:24:44 --> Language Class Initialized
INFO - 2022-01-17 05:24:44 --> Language Class Initialized
INFO - 2022-01-17 05:24:44 --> Config Class Initialized
INFO - 2022-01-17 05:24:44 --> Loader Class Initialized
INFO - 2022-01-17 05:24:44 --> Helper loaded: url_helper
INFO - 2022-01-17 05:24:44 --> Helper loaded: file_helper
INFO - 2022-01-17 05:24:44 --> Helper loaded: form_helper
INFO - 2022-01-17 05:24:44 --> Helper loaded: my_helper
INFO - 2022-01-17 05:24:44 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:24:44 --> Controller Class Initialized
DEBUG - 2022-01-17 05:24:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-01-17 05:24:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:24:44 --> Final output sent to browser
DEBUG - 2022-01-17 05:24:44 --> Total execution time: 0.0480
INFO - 2022-01-17 05:24:47 --> Config Class Initialized
INFO - 2022-01-17 05:24:47 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:24:47 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:24:47 --> Utf8 Class Initialized
INFO - 2022-01-17 05:24:47 --> URI Class Initialized
INFO - 2022-01-17 05:24:47 --> Router Class Initialized
INFO - 2022-01-17 05:24:47 --> Output Class Initialized
INFO - 2022-01-17 05:24:47 --> Security Class Initialized
DEBUG - 2022-01-17 05:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:24:47 --> Input Class Initialized
INFO - 2022-01-17 05:24:47 --> Language Class Initialized
INFO - 2022-01-17 05:24:47 --> Language Class Initialized
INFO - 2022-01-17 05:24:47 --> Config Class Initialized
INFO - 2022-01-17 05:24:47 --> Loader Class Initialized
INFO - 2022-01-17 05:24:47 --> Helper loaded: url_helper
INFO - 2022-01-17 05:24:47 --> Helper loaded: file_helper
INFO - 2022-01-17 05:24:47 --> Helper loaded: form_helper
INFO - 2022-01-17 05:24:47 --> Helper loaded: my_helper
INFO - 2022-01-17 05:24:47 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:24:47 --> Controller Class Initialized
INFO - 2022-01-17 05:24:48 --> Config Class Initialized
INFO - 2022-01-17 05:24:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:24:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:24:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:24:48 --> URI Class Initialized
INFO - 2022-01-17 05:24:48 --> Router Class Initialized
INFO - 2022-01-17 05:24:48 --> Output Class Initialized
INFO - 2022-01-17 05:24:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:24:48 --> Input Class Initialized
INFO - 2022-01-17 05:24:48 --> Language Class Initialized
INFO - 2022-01-17 05:24:48 --> Language Class Initialized
INFO - 2022-01-17 05:24:48 --> Config Class Initialized
INFO - 2022-01-17 05:24:48 --> Loader Class Initialized
INFO - 2022-01-17 05:24:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:24:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:24:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:24:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:24:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:24:48 --> Controller Class Initialized
INFO - 2022-01-17 05:26:20 --> Config Class Initialized
INFO - 2022-01-17 05:26:20 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:20 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:20 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:20 --> URI Class Initialized
INFO - 2022-01-17 05:26:20 --> Router Class Initialized
INFO - 2022-01-17 05:26:20 --> Output Class Initialized
INFO - 2022-01-17 05:26:20 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:20 --> Input Class Initialized
INFO - 2022-01-17 05:26:20 --> Language Class Initialized
INFO - 2022-01-17 05:26:20 --> Language Class Initialized
INFO - 2022-01-17 05:26:20 --> Config Class Initialized
INFO - 2022-01-17 05:26:20 --> Loader Class Initialized
INFO - 2022-01-17 05:26:20 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:20 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:20 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:20 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:20 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:20 --> Controller Class Initialized
DEBUG - 2022-01-17 05:26:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-01-17 05:26:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:26:20 --> Final output sent to browser
DEBUG - 2022-01-17 05:26:20 --> Total execution time: 0.0540
INFO - 2022-01-17 05:26:20 --> Config Class Initialized
INFO - 2022-01-17 05:26:20 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:20 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:20 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:20 --> URI Class Initialized
INFO - 2022-01-17 05:26:20 --> Router Class Initialized
INFO - 2022-01-17 05:26:20 --> Output Class Initialized
INFO - 2022-01-17 05:26:20 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:20 --> Input Class Initialized
INFO - 2022-01-17 05:26:20 --> Language Class Initialized
INFO - 2022-01-17 05:26:20 --> Language Class Initialized
INFO - 2022-01-17 05:26:20 --> Config Class Initialized
INFO - 2022-01-17 05:26:20 --> Loader Class Initialized
INFO - 2022-01-17 05:26:20 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:20 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:20 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:20 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:20 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:20 --> Controller Class Initialized
INFO - 2022-01-17 05:26:21 --> Config Class Initialized
INFO - 2022-01-17 05:26:21 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:21 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:21 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:21 --> URI Class Initialized
INFO - 2022-01-17 05:26:21 --> Router Class Initialized
INFO - 2022-01-17 05:26:21 --> Output Class Initialized
INFO - 2022-01-17 05:26:21 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:21 --> Input Class Initialized
INFO - 2022-01-17 05:26:21 --> Language Class Initialized
INFO - 2022-01-17 05:26:21 --> Language Class Initialized
INFO - 2022-01-17 05:26:21 --> Config Class Initialized
INFO - 2022-01-17 05:26:21 --> Loader Class Initialized
INFO - 2022-01-17 05:26:21 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:21 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:21 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:21 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:21 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:21 --> Controller Class Initialized
DEBUG - 2022-01-17 05:26:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-01-17 05:26:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:26:21 --> Final output sent to browser
DEBUG - 2022-01-17 05:26:21 --> Total execution time: 0.0560
INFO - 2022-01-17 05:26:38 --> Config Class Initialized
INFO - 2022-01-17 05:26:38 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:38 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:38 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:38 --> URI Class Initialized
INFO - 2022-01-17 05:26:38 --> Router Class Initialized
INFO - 2022-01-17 05:26:38 --> Output Class Initialized
INFO - 2022-01-17 05:26:38 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:38 --> Input Class Initialized
INFO - 2022-01-17 05:26:38 --> Language Class Initialized
INFO - 2022-01-17 05:26:38 --> Language Class Initialized
INFO - 2022-01-17 05:26:38 --> Config Class Initialized
INFO - 2022-01-17 05:26:38 --> Loader Class Initialized
INFO - 2022-01-17 05:26:38 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:38 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:38 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:38 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:38 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:38 --> Controller Class Initialized
DEBUG - 2022-01-17 05:26:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2022-01-17 05:26:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:26:38 --> Final output sent to browser
DEBUG - 2022-01-17 05:26:38 --> Total execution time: 0.0510
INFO - 2022-01-17 05:26:45 --> Config Class Initialized
INFO - 2022-01-17 05:26:45 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:45 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:45 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:45 --> URI Class Initialized
INFO - 2022-01-17 05:26:45 --> Router Class Initialized
INFO - 2022-01-17 05:26:45 --> Output Class Initialized
INFO - 2022-01-17 05:26:45 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:45 --> Input Class Initialized
INFO - 2022-01-17 05:26:45 --> Language Class Initialized
INFO - 2022-01-17 05:26:45 --> Language Class Initialized
INFO - 2022-01-17 05:26:45 --> Config Class Initialized
INFO - 2022-01-17 05:26:45 --> Loader Class Initialized
INFO - 2022-01-17 05:26:45 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:45 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:45 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:45 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:45 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:45 --> Controller Class Initialized
INFO - 2022-01-17 05:26:45 --> Config Class Initialized
INFO - 2022-01-17 05:26:45 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:45 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:45 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:45 --> URI Class Initialized
INFO - 2022-01-17 05:26:45 --> Router Class Initialized
INFO - 2022-01-17 05:26:45 --> Output Class Initialized
INFO - 2022-01-17 05:26:45 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:45 --> Input Class Initialized
INFO - 2022-01-17 05:26:45 --> Language Class Initialized
INFO - 2022-01-17 05:26:45 --> Language Class Initialized
INFO - 2022-01-17 05:26:45 --> Config Class Initialized
INFO - 2022-01-17 05:26:45 --> Loader Class Initialized
INFO - 2022-01-17 05:26:45 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:45 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:45 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:45 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:45 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:45 --> Controller Class Initialized
DEBUG - 2022-01-17 05:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-01-17 05:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:26:45 --> Final output sent to browser
DEBUG - 2022-01-17 05:26:45 --> Total execution time: 0.0400
INFO - 2022-01-17 05:26:45 --> Config Class Initialized
INFO - 2022-01-17 05:26:45 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:45 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:45 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:45 --> URI Class Initialized
INFO - 2022-01-17 05:26:45 --> Router Class Initialized
INFO - 2022-01-17 05:26:45 --> Output Class Initialized
INFO - 2022-01-17 05:26:45 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:45 --> Input Class Initialized
INFO - 2022-01-17 05:26:45 --> Language Class Initialized
INFO - 2022-01-17 05:26:45 --> Language Class Initialized
INFO - 2022-01-17 05:26:45 --> Config Class Initialized
INFO - 2022-01-17 05:26:45 --> Loader Class Initialized
INFO - 2022-01-17 05:26:45 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:45 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:45 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:45 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:45 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:45 --> Controller Class Initialized
INFO - 2022-01-17 05:26:47 --> Config Class Initialized
INFO - 2022-01-17 05:26:47 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:47 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:47 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:47 --> URI Class Initialized
INFO - 2022-01-17 05:26:47 --> Router Class Initialized
INFO - 2022-01-17 05:26:47 --> Output Class Initialized
INFO - 2022-01-17 05:26:47 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:47 --> Input Class Initialized
INFO - 2022-01-17 05:26:47 --> Language Class Initialized
INFO - 2022-01-17 05:26:47 --> Language Class Initialized
INFO - 2022-01-17 05:26:47 --> Config Class Initialized
INFO - 2022-01-17 05:26:47 --> Loader Class Initialized
INFO - 2022-01-17 05:26:47 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:47 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:47 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:47 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:47 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:47 --> Controller Class Initialized
DEBUG - 2022-01-17 05:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-01-17 05:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:26:47 --> Final output sent to browser
DEBUG - 2022-01-17 05:26:47 --> Total execution time: 0.0530
INFO - 2022-01-17 05:26:50 --> Config Class Initialized
INFO - 2022-01-17 05:26:50 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:50 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:50 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:50 --> URI Class Initialized
INFO - 2022-01-17 05:26:50 --> Router Class Initialized
INFO - 2022-01-17 05:26:50 --> Output Class Initialized
INFO - 2022-01-17 05:26:50 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:50 --> Input Class Initialized
INFO - 2022-01-17 05:26:50 --> Language Class Initialized
INFO - 2022-01-17 05:26:50 --> Language Class Initialized
INFO - 2022-01-17 05:26:50 --> Config Class Initialized
INFO - 2022-01-17 05:26:50 --> Loader Class Initialized
INFO - 2022-01-17 05:26:50 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:50 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:50 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:50 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:50 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:50 --> Controller Class Initialized
DEBUG - 2022-01-17 05:26:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-01-17 05:26:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:26:50 --> Final output sent to browser
DEBUG - 2022-01-17 05:26:50 --> Total execution time: 0.0460
INFO - 2022-01-17 05:26:57 --> Config Class Initialized
INFO - 2022-01-17 05:26:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:57 --> URI Class Initialized
INFO - 2022-01-17 05:26:57 --> Router Class Initialized
INFO - 2022-01-17 05:26:57 --> Output Class Initialized
INFO - 2022-01-17 05:26:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:57 --> Input Class Initialized
INFO - 2022-01-17 05:26:57 --> Language Class Initialized
INFO - 2022-01-17 05:26:57 --> Language Class Initialized
INFO - 2022-01-17 05:26:57 --> Config Class Initialized
INFO - 2022-01-17 05:26:57 --> Loader Class Initialized
INFO - 2022-01-17 05:26:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:57 --> Controller Class Initialized
INFO - 2022-01-17 05:26:57 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:26:57 --> Config Class Initialized
INFO - 2022-01-17 05:26:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:26:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:26:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:26:57 --> URI Class Initialized
INFO - 2022-01-17 05:26:57 --> Router Class Initialized
INFO - 2022-01-17 05:26:57 --> Output Class Initialized
INFO - 2022-01-17 05:26:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:26:57 --> Input Class Initialized
INFO - 2022-01-17 05:26:57 --> Language Class Initialized
INFO - 2022-01-17 05:26:57 --> Language Class Initialized
INFO - 2022-01-17 05:26:57 --> Config Class Initialized
INFO - 2022-01-17 05:26:57 --> Loader Class Initialized
INFO - 2022-01-17 05:26:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:26:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:26:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:26:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:26:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:26:57 --> Controller Class Initialized
DEBUG - 2022-01-17 05:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:26:57 --> Final output sent to browser
DEBUG - 2022-01-17 05:26:57 --> Total execution time: 0.0370
INFO - 2022-01-17 05:27:04 --> Config Class Initialized
INFO - 2022-01-17 05:27:04 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:04 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:04 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:04 --> URI Class Initialized
INFO - 2022-01-17 05:27:04 --> Router Class Initialized
INFO - 2022-01-17 05:27:04 --> Output Class Initialized
INFO - 2022-01-17 05:27:04 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:04 --> Input Class Initialized
INFO - 2022-01-17 05:27:04 --> Language Class Initialized
INFO - 2022-01-17 05:27:04 --> Language Class Initialized
INFO - 2022-01-17 05:27:04 --> Config Class Initialized
INFO - 2022-01-17 05:27:04 --> Loader Class Initialized
INFO - 2022-01-17 05:27:04 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:04 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:04 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:04 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:04 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:04 --> Controller Class Initialized
INFO - 2022-01-17 05:27:04 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:27:04 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:04 --> Total execution time: 0.0430
INFO - 2022-01-17 05:27:04 --> Config Class Initialized
INFO - 2022-01-17 05:27:04 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:04 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:04 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:04 --> URI Class Initialized
INFO - 2022-01-17 05:27:04 --> Router Class Initialized
INFO - 2022-01-17 05:27:04 --> Output Class Initialized
INFO - 2022-01-17 05:27:04 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:04 --> Input Class Initialized
INFO - 2022-01-17 05:27:04 --> Language Class Initialized
INFO - 2022-01-17 05:27:04 --> Language Class Initialized
INFO - 2022-01-17 05:27:04 --> Config Class Initialized
INFO - 2022-01-17 05:27:04 --> Loader Class Initialized
INFO - 2022-01-17 05:27:04 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:04 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:04 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:04 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:04 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:04 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:27:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:27:04 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:04 --> Total execution time: 0.2900
INFO - 2022-01-17 05:27:06 --> Config Class Initialized
INFO - 2022-01-17 05:27:06 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:06 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:06 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:06 --> URI Class Initialized
INFO - 2022-01-17 05:27:06 --> Router Class Initialized
INFO - 2022-01-17 05:27:06 --> Output Class Initialized
INFO - 2022-01-17 05:27:06 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:06 --> Input Class Initialized
INFO - 2022-01-17 05:27:06 --> Language Class Initialized
INFO - 2022-01-17 05:27:06 --> Language Class Initialized
INFO - 2022-01-17 05:27:06 --> Config Class Initialized
INFO - 2022-01-17 05:27:06 --> Loader Class Initialized
INFO - 2022-01-17 05:27:06 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:06 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:06 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:06 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:06 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:06 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-17 05:27:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:27:06 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:06 --> Total execution time: 0.0560
INFO - 2022-01-17 05:27:08 --> Config Class Initialized
INFO - 2022-01-17 05:27:08 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:08 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:08 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:08 --> URI Class Initialized
INFO - 2022-01-17 05:27:08 --> Router Class Initialized
INFO - 2022-01-17 05:27:08 --> Output Class Initialized
INFO - 2022-01-17 05:27:08 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:08 --> Input Class Initialized
INFO - 2022-01-17 05:27:08 --> Language Class Initialized
INFO - 2022-01-17 05:27:08 --> Language Class Initialized
INFO - 2022-01-17 05:27:08 --> Config Class Initialized
INFO - 2022-01-17 05:27:08 --> Loader Class Initialized
INFO - 2022-01-17 05:27:08 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:08 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:08 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:08 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:08 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:08 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:27:08 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:08 --> Total execution time: 0.0960
INFO - 2022-01-17 05:27:30 --> Config Class Initialized
INFO - 2022-01-17 05:27:30 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:30 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:30 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:30 --> URI Class Initialized
INFO - 2022-01-17 05:27:30 --> Router Class Initialized
INFO - 2022-01-17 05:27:30 --> Output Class Initialized
INFO - 2022-01-17 05:27:30 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:30 --> Input Class Initialized
INFO - 2022-01-17 05:27:30 --> Language Class Initialized
INFO - 2022-01-17 05:27:30 --> Language Class Initialized
INFO - 2022-01-17 05:27:30 --> Config Class Initialized
INFO - 2022-01-17 05:27:30 --> Loader Class Initialized
INFO - 2022-01-17 05:27:30 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:30 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:30 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:30 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:30 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:30 --> Controller Class Initialized
INFO - 2022-01-17 05:27:30 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:27:30 --> Config Class Initialized
INFO - 2022-01-17 05:27:30 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:30 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:30 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:30 --> URI Class Initialized
INFO - 2022-01-17 05:27:30 --> Router Class Initialized
INFO - 2022-01-17 05:27:30 --> Output Class Initialized
INFO - 2022-01-17 05:27:30 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:30 --> Input Class Initialized
INFO - 2022-01-17 05:27:30 --> Language Class Initialized
INFO - 2022-01-17 05:27:30 --> Language Class Initialized
INFO - 2022-01-17 05:27:30 --> Config Class Initialized
INFO - 2022-01-17 05:27:30 --> Loader Class Initialized
INFO - 2022-01-17 05:27:30 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:30 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:30 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:30 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:30 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:30 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:27:30 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:30 --> Total execution time: 0.0350
INFO - 2022-01-17 05:27:33 --> Config Class Initialized
INFO - 2022-01-17 05:27:33 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:33 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:33 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:33 --> URI Class Initialized
INFO - 2022-01-17 05:27:33 --> Router Class Initialized
INFO - 2022-01-17 05:27:33 --> Output Class Initialized
INFO - 2022-01-17 05:27:33 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:33 --> Input Class Initialized
INFO - 2022-01-17 05:27:33 --> Language Class Initialized
INFO - 2022-01-17 05:27:33 --> Language Class Initialized
INFO - 2022-01-17 05:27:33 --> Config Class Initialized
INFO - 2022-01-17 05:27:33 --> Loader Class Initialized
INFO - 2022-01-17 05:27:33 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:33 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:33 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:33 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:33 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:33 --> Controller Class Initialized
INFO - 2022-01-17 05:27:33 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:27:33 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:33 --> Total execution time: 0.0520
INFO - 2022-01-17 05:27:33 --> Config Class Initialized
INFO - 2022-01-17 05:27:33 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:33 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:33 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:33 --> URI Class Initialized
INFO - 2022-01-17 05:27:33 --> Router Class Initialized
INFO - 2022-01-17 05:27:33 --> Output Class Initialized
INFO - 2022-01-17 05:27:33 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:33 --> Input Class Initialized
INFO - 2022-01-17 05:27:33 --> Language Class Initialized
INFO - 2022-01-17 05:27:33 --> Language Class Initialized
INFO - 2022-01-17 05:27:33 --> Config Class Initialized
INFO - 2022-01-17 05:27:33 --> Loader Class Initialized
INFO - 2022-01-17 05:27:33 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:33 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:33 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:33 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:33 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:33 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:27:33 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:33 --> Total execution time: 0.2740
INFO - 2022-01-17 05:27:36 --> Config Class Initialized
INFO - 2022-01-17 05:27:36 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:36 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:36 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:36 --> URI Class Initialized
INFO - 2022-01-17 05:27:36 --> Router Class Initialized
INFO - 2022-01-17 05:27:36 --> Output Class Initialized
INFO - 2022-01-17 05:27:36 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:36 --> Input Class Initialized
INFO - 2022-01-17 05:27:36 --> Language Class Initialized
INFO - 2022-01-17 05:27:36 --> Language Class Initialized
INFO - 2022-01-17 05:27:36 --> Config Class Initialized
INFO - 2022-01-17 05:27:36 --> Loader Class Initialized
INFO - 2022-01-17 05:27:36 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:36 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:36 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:36 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:36 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:36 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-01-17 05:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:27:36 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:36 --> Total execution time: 0.0590
INFO - 2022-01-17 05:27:41 --> Config Class Initialized
INFO - 2022-01-17 05:27:41 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:41 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:41 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:41 --> URI Class Initialized
INFO - 2022-01-17 05:27:41 --> Router Class Initialized
INFO - 2022-01-17 05:27:41 --> Output Class Initialized
INFO - 2022-01-17 05:27:41 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:41 --> Input Class Initialized
INFO - 2022-01-17 05:27:41 --> Language Class Initialized
INFO - 2022-01-17 05:27:41 --> Language Class Initialized
INFO - 2022-01-17 05:27:41 --> Config Class Initialized
INFO - 2022-01-17 05:27:41 --> Loader Class Initialized
INFO - 2022-01-17 05:27:41 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:41 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:41 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:41 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:41 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:41 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-01-17 05:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:27:41 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:41 --> Total execution time: 0.0540
INFO - 2022-01-17 05:27:51 --> Config Class Initialized
INFO - 2022-01-17 05:27:51 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:51 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:51 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:51 --> URI Class Initialized
INFO - 2022-01-17 05:27:51 --> Router Class Initialized
INFO - 2022-01-17 05:27:51 --> Output Class Initialized
INFO - 2022-01-17 05:27:51 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:51 --> Input Class Initialized
INFO - 2022-01-17 05:27:51 --> Language Class Initialized
INFO - 2022-01-17 05:27:51 --> Language Class Initialized
INFO - 2022-01-17 05:27:51 --> Config Class Initialized
INFO - 2022-01-17 05:27:51 --> Loader Class Initialized
INFO - 2022-01-17 05:27:51 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:51 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:51 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:51 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:51 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:51 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2022-01-17 05:27:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:27:51 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:51 --> Total execution time: 0.0520
INFO - 2022-01-17 05:27:56 --> Config Class Initialized
INFO - 2022-01-17 05:27:56 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:56 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:56 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:56 --> URI Class Initialized
INFO - 2022-01-17 05:27:56 --> Router Class Initialized
INFO - 2022-01-17 05:27:56 --> Output Class Initialized
INFO - 2022-01-17 05:27:56 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:56 --> Input Class Initialized
INFO - 2022-01-17 05:27:56 --> Language Class Initialized
INFO - 2022-01-17 05:27:56 --> Language Class Initialized
INFO - 2022-01-17 05:27:56 --> Config Class Initialized
INFO - 2022-01-17 05:27:56 --> Loader Class Initialized
INFO - 2022-01-17 05:27:56 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:56 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:56 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:56 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:56 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:56 --> Controller Class Initialized
INFO - 2022-01-17 05:27:57 --> Config Class Initialized
INFO - 2022-01-17 05:27:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:57 --> URI Class Initialized
INFO - 2022-01-17 05:27:57 --> Router Class Initialized
INFO - 2022-01-17 05:27:57 --> Output Class Initialized
INFO - 2022-01-17 05:27:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:57 --> Input Class Initialized
INFO - 2022-01-17 05:27:57 --> Language Class Initialized
INFO - 2022-01-17 05:27:57 --> Language Class Initialized
INFO - 2022-01-17 05:27:57 --> Config Class Initialized
INFO - 2022-01-17 05:27:57 --> Loader Class Initialized
INFO - 2022-01-17 05:27:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:57 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-01-17 05:27:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:27:57 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:57 --> Total execution time: 0.0370
INFO - 2022-01-17 05:27:59 --> Config Class Initialized
INFO - 2022-01-17 05:27:59 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:27:59 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:27:59 --> Utf8 Class Initialized
INFO - 2022-01-17 05:27:59 --> URI Class Initialized
INFO - 2022-01-17 05:27:59 --> Router Class Initialized
INFO - 2022-01-17 05:27:59 --> Output Class Initialized
INFO - 2022-01-17 05:27:59 --> Security Class Initialized
DEBUG - 2022-01-17 05:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:27:59 --> Input Class Initialized
INFO - 2022-01-17 05:27:59 --> Language Class Initialized
INFO - 2022-01-17 05:27:59 --> Language Class Initialized
INFO - 2022-01-17 05:27:59 --> Config Class Initialized
INFO - 2022-01-17 05:27:59 --> Loader Class Initialized
INFO - 2022-01-17 05:27:59 --> Helper loaded: url_helper
INFO - 2022-01-17 05:27:59 --> Helper loaded: file_helper
INFO - 2022-01-17 05:27:59 --> Helper loaded: form_helper
INFO - 2022-01-17 05:27:59 --> Helper loaded: my_helper
INFO - 2022-01-17 05:27:59 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:27:59 --> Controller Class Initialized
DEBUG - 2022-01-17 05:27:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:27:59 --> Final output sent to browser
DEBUG - 2022-01-17 05:27:59 --> Total execution time: 0.1070
INFO - 2022-01-17 05:28:07 --> Config Class Initialized
INFO - 2022-01-17 05:28:07 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:28:07 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:28:07 --> Utf8 Class Initialized
INFO - 2022-01-17 05:28:07 --> URI Class Initialized
INFO - 2022-01-17 05:28:07 --> Router Class Initialized
INFO - 2022-01-17 05:28:07 --> Output Class Initialized
INFO - 2022-01-17 05:28:07 --> Security Class Initialized
DEBUG - 2022-01-17 05:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:28:07 --> Input Class Initialized
INFO - 2022-01-17 05:28:07 --> Language Class Initialized
INFO - 2022-01-17 05:28:07 --> Language Class Initialized
INFO - 2022-01-17 05:28:07 --> Config Class Initialized
INFO - 2022-01-17 05:28:07 --> Loader Class Initialized
INFO - 2022-01-17 05:28:07 --> Helper loaded: url_helper
INFO - 2022-01-17 05:28:07 --> Helper loaded: file_helper
INFO - 2022-01-17 05:28:07 --> Helper loaded: form_helper
INFO - 2022-01-17 05:28:07 --> Helper loaded: my_helper
INFO - 2022-01-17 05:28:07 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:28:07 --> Controller Class Initialized
INFO - 2022-01-17 05:28:07 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:28:07 --> Config Class Initialized
INFO - 2022-01-17 05:28:07 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:28:07 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:28:07 --> Utf8 Class Initialized
INFO - 2022-01-17 05:28:07 --> URI Class Initialized
INFO - 2022-01-17 05:28:07 --> Router Class Initialized
INFO - 2022-01-17 05:28:07 --> Output Class Initialized
INFO - 2022-01-17 05:28:07 --> Security Class Initialized
DEBUG - 2022-01-17 05:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:28:07 --> Input Class Initialized
INFO - 2022-01-17 05:28:07 --> Language Class Initialized
INFO - 2022-01-17 05:28:07 --> Language Class Initialized
INFO - 2022-01-17 05:28:07 --> Config Class Initialized
INFO - 2022-01-17 05:28:07 --> Loader Class Initialized
INFO - 2022-01-17 05:28:07 --> Helper loaded: url_helper
INFO - 2022-01-17 05:28:07 --> Helper loaded: file_helper
INFO - 2022-01-17 05:28:07 --> Helper loaded: form_helper
INFO - 2022-01-17 05:28:07 --> Helper loaded: my_helper
INFO - 2022-01-17 05:28:07 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:28:07 --> Controller Class Initialized
DEBUG - 2022-01-17 05:28:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:28:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:28:07 --> Final output sent to browser
DEBUG - 2022-01-17 05:28:07 --> Total execution time: 0.0350
INFO - 2022-01-17 05:28:17 --> Config Class Initialized
INFO - 2022-01-17 05:28:17 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:28:17 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:28:17 --> Utf8 Class Initialized
INFO - 2022-01-17 05:28:17 --> URI Class Initialized
INFO - 2022-01-17 05:28:17 --> Router Class Initialized
INFO - 2022-01-17 05:28:17 --> Output Class Initialized
INFO - 2022-01-17 05:28:17 --> Security Class Initialized
DEBUG - 2022-01-17 05:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:28:17 --> Input Class Initialized
INFO - 2022-01-17 05:28:17 --> Language Class Initialized
INFO - 2022-01-17 05:28:17 --> Language Class Initialized
INFO - 2022-01-17 05:28:17 --> Config Class Initialized
INFO - 2022-01-17 05:28:17 --> Loader Class Initialized
INFO - 2022-01-17 05:28:17 --> Helper loaded: url_helper
INFO - 2022-01-17 05:28:17 --> Helper loaded: file_helper
INFO - 2022-01-17 05:28:17 --> Helper loaded: form_helper
INFO - 2022-01-17 05:28:17 --> Helper loaded: my_helper
INFO - 2022-01-17 05:28:17 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:28:17 --> Controller Class Initialized
INFO - 2022-01-17 05:28:17 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:28:17 --> Final output sent to browser
DEBUG - 2022-01-17 05:28:17 --> Total execution time: 0.0530
INFO - 2022-01-17 05:28:18 --> Config Class Initialized
INFO - 2022-01-17 05:28:18 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:28:18 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:28:18 --> Utf8 Class Initialized
INFO - 2022-01-17 05:28:18 --> URI Class Initialized
INFO - 2022-01-17 05:28:18 --> Router Class Initialized
INFO - 2022-01-17 05:28:18 --> Output Class Initialized
INFO - 2022-01-17 05:28:18 --> Security Class Initialized
DEBUG - 2022-01-17 05:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:28:18 --> Input Class Initialized
INFO - 2022-01-17 05:28:18 --> Language Class Initialized
INFO - 2022-01-17 05:28:18 --> Language Class Initialized
INFO - 2022-01-17 05:28:18 --> Config Class Initialized
INFO - 2022-01-17 05:28:18 --> Loader Class Initialized
INFO - 2022-01-17 05:28:18 --> Helper loaded: url_helper
INFO - 2022-01-17 05:28:18 --> Helper loaded: file_helper
INFO - 2022-01-17 05:28:18 --> Helper loaded: form_helper
INFO - 2022-01-17 05:28:18 --> Helper loaded: my_helper
INFO - 2022-01-17 05:28:18 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:28:18 --> Controller Class Initialized
DEBUG - 2022-01-17 05:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:28:18 --> Final output sent to browser
DEBUG - 2022-01-17 05:28:18 --> Total execution time: 0.2880
INFO - 2022-01-17 05:28:19 --> Config Class Initialized
INFO - 2022-01-17 05:28:19 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:28:19 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:28:19 --> Utf8 Class Initialized
INFO - 2022-01-17 05:28:19 --> URI Class Initialized
INFO - 2022-01-17 05:28:19 --> Router Class Initialized
INFO - 2022-01-17 05:28:19 --> Output Class Initialized
INFO - 2022-01-17 05:28:19 --> Security Class Initialized
DEBUG - 2022-01-17 05:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:28:19 --> Input Class Initialized
INFO - 2022-01-17 05:28:19 --> Language Class Initialized
INFO - 2022-01-17 05:28:19 --> Language Class Initialized
INFO - 2022-01-17 05:28:19 --> Config Class Initialized
INFO - 2022-01-17 05:28:19 --> Loader Class Initialized
INFO - 2022-01-17 05:28:19 --> Helper loaded: url_helper
INFO - 2022-01-17 05:28:19 --> Helper loaded: file_helper
INFO - 2022-01-17 05:28:19 --> Helper loaded: form_helper
INFO - 2022-01-17 05:28:19 --> Helper loaded: my_helper
INFO - 2022-01-17 05:28:19 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:28:19 --> Controller Class Initialized
DEBUG - 2022-01-17 05:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-17 05:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:28:19 --> Final output sent to browser
DEBUG - 2022-01-17 05:28:19 --> Total execution time: 0.0600
INFO - 2022-01-17 05:28:20 --> Config Class Initialized
INFO - 2022-01-17 05:28:20 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:28:20 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:28:20 --> Utf8 Class Initialized
INFO - 2022-01-17 05:28:20 --> URI Class Initialized
INFO - 2022-01-17 05:28:20 --> Router Class Initialized
INFO - 2022-01-17 05:28:20 --> Output Class Initialized
INFO - 2022-01-17 05:28:20 --> Security Class Initialized
DEBUG - 2022-01-17 05:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:28:20 --> Input Class Initialized
INFO - 2022-01-17 05:28:20 --> Language Class Initialized
INFO - 2022-01-17 05:28:20 --> Language Class Initialized
INFO - 2022-01-17 05:28:20 --> Config Class Initialized
INFO - 2022-01-17 05:28:20 --> Loader Class Initialized
INFO - 2022-01-17 05:28:20 --> Helper loaded: url_helper
INFO - 2022-01-17 05:28:20 --> Helper loaded: file_helper
INFO - 2022-01-17 05:28:20 --> Helper loaded: form_helper
INFO - 2022-01-17 05:28:20 --> Helper loaded: my_helper
INFO - 2022-01-17 05:28:20 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:28:20 --> Controller Class Initialized
DEBUG - 2022-01-17 05:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:28:20 --> Final output sent to browser
DEBUG - 2022-01-17 05:28:20 --> Total execution time: 0.0940
INFO - 2022-01-17 05:44:44 --> Config Class Initialized
INFO - 2022-01-17 05:44:44 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:44:44 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:44:44 --> Utf8 Class Initialized
INFO - 2022-01-17 05:44:44 --> URI Class Initialized
INFO - 2022-01-17 05:44:44 --> Router Class Initialized
INFO - 2022-01-17 05:44:44 --> Output Class Initialized
INFO - 2022-01-17 05:44:44 --> Security Class Initialized
DEBUG - 2022-01-17 05:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:44:44 --> Input Class Initialized
INFO - 2022-01-17 05:44:44 --> Language Class Initialized
INFO - 2022-01-17 05:44:44 --> Language Class Initialized
INFO - 2022-01-17 05:44:44 --> Config Class Initialized
INFO - 2022-01-17 05:44:44 --> Loader Class Initialized
INFO - 2022-01-17 05:44:44 --> Helper loaded: url_helper
INFO - 2022-01-17 05:44:44 --> Helper loaded: file_helper
INFO - 2022-01-17 05:44:44 --> Helper loaded: form_helper
INFO - 2022-01-17 05:44:44 --> Helper loaded: my_helper
INFO - 2022-01-17 05:44:44 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:44:44 --> Controller Class Initialized
DEBUG - 2022-01-17 05:44:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-17 05:44:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:44:44 --> Final output sent to browser
DEBUG - 2022-01-17 05:44:44 --> Total execution time: 0.0640
INFO - 2022-01-17 05:44:46 --> Config Class Initialized
INFO - 2022-01-17 05:44:46 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:44:46 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:44:46 --> Utf8 Class Initialized
INFO - 2022-01-17 05:44:46 --> URI Class Initialized
INFO - 2022-01-17 05:44:46 --> Router Class Initialized
INFO - 2022-01-17 05:44:46 --> Output Class Initialized
INFO - 2022-01-17 05:44:46 --> Security Class Initialized
DEBUG - 2022-01-17 05:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:44:46 --> Input Class Initialized
INFO - 2022-01-17 05:44:46 --> Language Class Initialized
INFO - 2022-01-17 05:44:46 --> Language Class Initialized
INFO - 2022-01-17 05:44:46 --> Config Class Initialized
INFO - 2022-01-17 05:44:46 --> Loader Class Initialized
INFO - 2022-01-17 05:44:46 --> Helper loaded: url_helper
INFO - 2022-01-17 05:44:46 --> Helper loaded: file_helper
INFO - 2022-01-17 05:44:46 --> Helper loaded: form_helper
INFO - 2022-01-17 05:44:46 --> Helper loaded: my_helper
INFO - 2022-01-17 05:44:46 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:44:46 --> Controller Class Initialized
DEBUG - 2022-01-17 05:44:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:44:46 --> Final output sent to browser
DEBUG - 2022-01-17 05:44:46 --> Total execution time: 0.0730
INFO - 2022-01-17 05:45:31 --> Config Class Initialized
INFO - 2022-01-17 05:45:31 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:31 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:31 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:31 --> URI Class Initialized
INFO - 2022-01-17 05:45:31 --> Router Class Initialized
INFO - 2022-01-17 05:45:31 --> Output Class Initialized
INFO - 2022-01-17 05:45:31 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:31 --> Input Class Initialized
INFO - 2022-01-17 05:45:31 --> Language Class Initialized
INFO - 2022-01-17 05:45:31 --> Language Class Initialized
INFO - 2022-01-17 05:45:31 --> Config Class Initialized
INFO - 2022-01-17 05:45:31 --> Loader Class Initialized
INFO - 2022-01-17 05:45:31 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:31 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:31 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:31 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:32 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:32 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-17 05:45:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:45:32 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:32 --> Total execution time: 0.0720
INFO - 2022-01-17 05:45:34 --> Config Class Initialized
INFO - 2022-01-17 05:45:34 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:34 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:34 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:34 --> URI Class Initialized
INFO - 2022-01-17 05:45:34 --> Router Class Initialized
INFO - 2022-01-17 05:45:34 --> Output Class Initialized
INFO - 2022-01-17 05:45:34 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:34 --> Input Class Initialized
INFO - 2022-01-17 05:45:34 --> Language Class Initialized
INFO - 2022-01-17 05:45:34 --> Language Class Initialized
INFO - 2022-01-17 05:45:34 --> Config Class Initialized
INFO - 2022-01-17 05:45:34 --> Loader Class Initialized
INFO - 2022-01-17 05:45:34 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:34 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:34 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:34 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:34 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:34 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:35 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:35 --> Total execution time: 0.1070
INFO - 2022-01-17 05:45:36 --> Config Class Initialized
INFO - 2022-01-17 05:45:36 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:36 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:36 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:36 --> URI Class Initialized
INFO - 2022-01-17 05:45:36 --> Router Class Initialized
INFO - 2022-01-17 05:45:36 --> Output Class Initialized
INFO - 2022-01-17 05:45:36 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:36 --> Input Class Initialized
INFO - 2022-01-17 05:45:36 --> Language Class Initialized
INFO - 2022-01-17 05:45:37 --> Language Class Initialized
INFO - 2022-01-17 05:45:37 --> Config Class Initialized
INFO - 2022-01-17 05:45:37 --> Loader Class Initialized
INFO - 2022-01-17 05:45:37 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:37 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:37 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:37 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:37 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:37 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:37 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:37 --> Total execution time: 0.0700
INFO - 2022-01-17 05:45:38 --> Config Class Initialized
INFO - 2022-01-17 05:45:38 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:38 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:38 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:38 --> URI Class Initialized
INFO - 2022-01-17 05:45:38 --> Router Class Initialized
INFO - 2022-01-17 05:45:38 --> Output Class Initialized
INFO - 2022-01-17 05:45:38 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:38 --> Input Class Initialized
INFO - 2022-01-17 05:45:38 --> Language Class Initialized
INFO - 2022-01-17 05:45:38 --> Language Class Initialized
INFO - 2022-01-17 05:45:38 --> Config Class Initialized
INFO - 2022-01-17 05:45:38 --> Loader Class Initialized
INFO - 2022-01-17 05:45:38 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:38 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:38 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:38 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:38 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:38 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:38 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:38 --> Total execution time: 0.0690
INFO - 2022-01-17 05:45:40 --> Config Class Initialized
INFO - 2022-01-17 05:45:40 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:40 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:40 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:40 --> URI Class Initialized
INFO - 2022-01-17 05:45:40 --> Router Class Initialized
INFO - 2022-01-17 05:45:40 --> Output Class Initialized
INFO - 2022-01-17 05:45:40 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:40 --> Input Class Initialized
INFO - 2022-01-17 05:45:40 --> Language Class Initialized
INFO - 2022-01-17 05:45:40 --> Language Class Initialized
INFO - 2022-01-17 05:45:40 --> Config Class Initialized
INFO - 2022-01-17 05:45:40 --> Loader Class Initialized
INFO - 2022-01-17 05:45:40 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:40 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:40 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:40 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:40 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:40 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:40 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:40 --> Total execution time: 0.0660
INFO - 2022-01-17 05:45:42 --> Config Class Initialized
INFO - 2022-01-17 05:45:42 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:42 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:42 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:42 --> URI Class Initialized
INFO - 2022-01-17 05:45:42 --> Router Class Initialized
INFO - 2022-01-17 05:45:42 --> Output Class Initialized
INFO - 2022-01-17 05:45:42 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:42 --> Input Class Initialized
INFO - 2022-01-17 05:45:42 --> Language Class Initialized
INFO - 2022-01-17 05:45:42 --> Language Class Initialized
INFO - 2022-01-17 05:45:42 --> Config Class Initialized
INFO - 2022-01-17 05:45:42 --> Loader Class Initialized
INFO - 2022-01-17 05:45:42 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:42 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:42 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:42 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:42 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:42 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:42 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:42 --> Total execution time: 0.0720
INFO - 2022-01-17 05:45:44 --> Config Class Initialized
INFO - 2022-01-17 05:45:44 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:44 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:44 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:44 --> URI Class Initialized
INFO - 2022-01-17 05:45:44 --> Router Class Initialized
INFO - 2022-01-17 05:45:44 --> Output Class Initialized
INFO - 2022-01-17 05:45:44 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:44 --> Input Class Initialized
INFO - 2022-01-17 05:45:44 --> Language Class Initialized
INFO - 2022-01-17 05:45:44 --> Language Class Initialized
INFO - 2022-01-17 05:45:44 --> Config Class Initialized
INFO - 2022-01-17 05:45:44 --> Loader Class Initialized
INFO - 2022-01-17 05:45:44 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:44 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:44 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:44 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:44 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:44 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:44 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:44 --> Total execution time: 0.0740
INFO - 2022-01-17 05:45:45 --> Config Class Initialized
INFO - 2022-01-17 05:45:45 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:45 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:45 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:45 --> URI Class Initialized
INFO - 2022-01-17 05:45:45 --> Router Class Initialized
INFO - 2022-01-17 05:45:45 --> Output Class Initialized
INFO - 2022-01-17 05:45:45 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:45 --> Input Class Initialized
INFO - 2022-01-17 05:45:45 --> Language Class Initialized
INFO - 2022-01-17 05:45:45 --> Language Class Initialized
INFO - 2022-01-17 05:45:45 --> Config Class Initialized
INFO - 2022-01-17 05:45:45 --> Loader Class Initialized
INFO - 2022-01-17 05:45:45 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:45 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:45 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:45 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:45 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:45 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:45 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:45 --> Total execution time: 0.0640
INFO - 2022-01-17 05:45:48 --> Config Class Initialized
INFO - 2022-01-17 05:45:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:48 --> URI Class Initialized
INFO - 2022-01-17 05:45:48 --> Router Class Initialized
INFO - 2022-01-17 05:45:48 --> Output Class Initialized
INFO - 2022-01-17 05:45:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:48 --> Input Class Initialized
INFO - 2022-01-17 05:45:48 --> Language Class Initialized
INFO - 2022-01-17 05:45:48 --> Language Class Initialized
INFO - 2022-01-17 05:45:48 --> Config Class Initialized
INFO - 2022-01-17 05:45:48 --> Loader Class Initialized
INFO - 2022-01-17 05:45:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:48 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:48 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:48 --> Total execution time: 0.0650
INFO - 2022-01-17 05:45:49 --> Config Class Initialized
INFO - 2022-01-17 05:45:49 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:50 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:50 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:50 --> URI Class Initialized
INFO - 2022-01-17 05:45:50 --> Router Class Initialized
INFO - 2022-01-17 05:45:50 --> Output Class Initialized
INFO - 2022-01-17 05:45:50 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:50 --> Input Class Initialized
INFO - 2022-01-17 05:45:50 --> Language Class Initialized
INFO - 2022-01-17 05:45:50 --> Language Class Initialized
INFO - 2022-01-17 05:45:50 --> Config Class Initialized
INFO - 2022-01-17 05:45:50 --> Loader Class Initialized
INFO - 2022-01-17 05:45:50 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:50 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:50 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:50 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:50 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:50 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:50 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:50 --> Total execution time: 0.0600
INFO - 2022-01-17 05:45:52 --> Config Class Initialized
INFO - 2022-01-17 05:45:52 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:52 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:52 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:52 --> URI Class Initialized
INFO - 2022-01-17 05:45:52 --> Router Class Initialized
INFO - 2022-01-17 05:45:52 --> Output Class Initialized
INFO - 2022-01-17 05:45:52 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:52 --> Input Class Initialized
INFO - 2022-01-17 05:45:52 --> Language Class Initialized
INFO - 2022-01-17 05:45:52 --> Language Class Initialized
INFO - 2022-01-17 05:45:52 --> Config Class Initialized
INFO - 2022-01-17 05:45:52 --> Loader Class Initialized
INFO - 2022-01-17 05:45:52 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:52 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:52 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:52 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:52 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:52 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:52 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:52 --> Total execution time: 0.0640
INFO - 2022-01-17 05:45:54 --> Config Class Initialized
INFO - 2022-01-17 05:45:54 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:54 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:54 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:54 --> URI Class Initialized
INFO - 2022-01-17 05:45:54 --> Router Class Initialized
INFO - 2022-01-17 05:45:54 --> Output Class Initialized
INFO - 2022-01-17 05:45:54 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:54 --> Input Class Initialized
INFO - 2022-01-17 05:45:54 --> Language Class Initialized
INFO - 2022-01-17 05:45:54 --> Language Class Initialized
INFO - 2022-01-17 05:45:54 --> Config Class Initialized
INFO - 2022-01-17 05:45:54 --> Loader Class Initialized
INFO - 2022-01-17 05:45:54 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:54 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:54 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:54 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:54 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:54 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:54 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:54 --> Total execution time: 0.0590
INFO - 2022-01-17 05:45:56 --> Config Class Initialized
INFO - 2022-01-17 05:45:56 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:56 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:56 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:56 --> URI Class Initialized
INFO - 2022-01-17 05:45:56 --> Router Class Initialized
INFO - 2022-01-17 05:45:56 --> Output Class Initialized
INFO - 2022-01-17 05:45:56 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:56 --> Input Class Initialized
INFO - 2022-01-17 05:45:56 --> Language Class Initialized
INFO - 2022-01-17 05:45:56 --> Language Class Initialized
INFO - 2022-01-17 05:45:56 --> Config Class Initialized
INFO - 2022-01-17 05:45:56 --> Loader Class Initialized
INFO - 2022-01-17 05:45:56 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:56 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:56 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:56 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:56 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:56 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:56 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:56 --> Total execution time: 0.0680
INFO - 2022-01-17 05:45:57 --> Config Class Initialized
INFO - 2022-01-17 05:45:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:45:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:45:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:45:57 --> URI Class Initialized
INFO - 2022-01-17 05:45:57 --> Router Class Initialized
INFO - 2022-01-17 05:45:57 --> Output Class Initialized
INFO - 2022-01-17 05:45:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:45:57 --> Input Class Initialized
INFO - 2022-01-17 05:45:57 --> Language Class Initialized
INFO - 2022-01-17 05:45:57 --> Language Class Initialized
INFO - 2022-01-17 05:45:57 --> Config Class Initialized
INFO - 2022-01-17 05:45:57 --> Loader Class Initialized
INFO - 2022-01-17 05:45:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:45:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:45:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:45:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:45:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:45:57 --> Controller Class Initialized
DEBUG - 2022-01-17 05:45:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:45:57 --> Final output sent to browser
DEBUG - 2022-01-17 05:45:57 --> Total execution time: 0.0730
INFO - 2022-01-17 05:46:00 --> Config Class Initialized
INFO - 2022-01-17 05:46:00 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:00 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:00 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:00 --> URI Class Initialized
INFO - 2022-01-17 05:46:00 --> Router Class Initialized
INFO - 2022-01-17 05:46:00 --> Output Class Initialized
INFO - 2022-01-17 05:46:00 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:00 --> Input Class Initialized
INFO - 2022-01-17 05:46:00 --> Language Class Initialized
INFO - 2022-01-17 05:46:00 --> Language Class Initialized
INFO - 2022-01-17 05:46:00 --> Config Class Initialized
INFO - 2022-01-17 05:46:00 --> Loader Class Initialized
INFO - 2022-01-17 05:46:00 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:00 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:00 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:00 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:00 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:00 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:00 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:00 --> Total execution time: 0.0650
INFO - 2022-01-17 05:46:02 --> Config Class Initialized
INFO - 2022-01-17 05:46:02 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:02 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:02 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:02 --> URI Class Initialized
INFO - 2022-01-17 05:46:02 --> Router Class Initialized
INFO - 2022-01-17 05:46:02 --> Output Class Initialized
INFO - 2022-01-17 05:46:02 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:02 --> Input Class Initialized
INFO - 2022-01-17 05:46:02 --> Language Class Initialized
INFO - 2022-01-17 05:46:02 --> Language Class Initialized
INFO - 2022-01-17 05:46:02 --> Config Class Initialized
INFO - 2022-01-17 05:46:02 --> Loader Class Initialized
INFO - 2022-01-17 05:46:02 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:02 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:02 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:02 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:02 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:02 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:02 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:02 --> Total execution time: 0.0700
INFO - 2022-01-17 05:46:05 --> Config Class Initialized
INFO - 2022-01-17 05:46:05 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:05 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:05 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:05 --> URI Class Initialized
INFO - 2022-01-17 05:46:05 --> Router Class Initialized
INFO - 2022-01-17 05:46:05 --> Output Class Initialized
INFO - 2022-01-17 05:46:05 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:05 --> Input Class Initialized
INFO - 2022-01-17 05:46:05 --> Language Class Initialized
INFO - 2022-01-17 05:46:05 --> Language Class Initialized
INFO - 2022-01-17 05:46:05 --> Config Class Initialized
INFO - 2022-01-17 05:46:05 --> Loader Class Initialized
INFO - 2022-01-17 05:46:05 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:05 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:05 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:05 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:05 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:05 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:05 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:05 --> Total execution time: 0.0660
INFO - 2022-01-17 05:46:06 --> Config Class Initialized
INFO - 2022-01-17 05:46:06 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:06 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:06 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:06 --> URI Class Initialized
INFO - 2022-01-17 05:46:06 --> Router Class Initialized
INFO - 2022-01-17 05:46:06 --> Output Class Initialized
INFO - 2022-01-17 05:46:06 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:06 --> Input Class Initialized
INFO - 2022-01-17 05:46:06 --> Language Class Initialized
INFO - 2022-01-17 05:46:06 --> Language Class Initialized
INFO - 2022-01-17 05:46:06 --> Config Class Initialized
INFO - 2022-01-17 05:46:06 --> Loader Class Initialized
INFO - 2022-01-17 05:46:06 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:06 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:06 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:06 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:06 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:06 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:06 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:06 --> Total execution time: 0.0740
INFO - 2022-01-17 05:46:09 --> Config Class Initialized
INFO - 2022-01-17 05:46:09 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:09 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:09 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:09 --> URI Class Initialized
INFO - 2022-01-17 05:46:09 --> Router Class Initialized
INFO - 2022-01-17 05:46:09 --> Output Class Initialized
INFO - 2022-01-17 05:46:09 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:09 --> Input Class Initialized
INFO - 2022-01-17 05:46:09 --> Language Class Initialized
INFO - 2022-01-17 05:46:09 --> Language Class Initialized
INFO - 2022-01-17 05:46:09 --> Config Class Initialized
INFO - 2022-01-17 05:46:09 --> Loader Class Initialized
INFO - 2022-01-17 05:46:09 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:09 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:09 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:09 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:09 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:09 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:09 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:09 --> Total execution time: 0.0730
INFO - 2022-01-17 05:46:10 --> Config Class Initialized
INFO - 2022-01-17 05:46:10 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:10 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:10 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:10 --> URI Class Initialized
INFO - 2022-01-17 05:46:10 --> Router Class Initialized
INFO - 2022-01-17 05:46:10 --> Output Class Initialized
INFO - 2022-01-17 05:46:10 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:10 --> Input Class Initialized
INFO - 2022-01-17 05:46:10 --> Language Class Initialized
INFO - 2022-01-17 05:46:10 --> Language Class Initialized
INFO - 2022-01-17 05:46:10 --> Config Class Initialized
INFO - 2022-01-17 05:46:10 --> Loader Class Initialized
INFO - 2022-01-17 05:46:10 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:10 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:10 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:10 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:10 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:10 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:10 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:10 --> Total execution time: 0.0540
INFO - 2022-01-17 05:46:13 --> Config Class Initialized
INFO - 2022-01-17 05:46:13 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:13 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:13 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:13 --> URI Class Initialized
INFO - 2022-01-17 05:46:13 --> Router Class Initialized
INFO - 2022-01-17 05:46:13 --> Output Class Initialized
INFO - 2022-01-17 05:46:13 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:13 --> Input Class Initialized
INFO - 2022-01-17 05:46:13 --> Language Class Initialized
INFO - 2022-01-17 05:46:13 --> Language Class Initialized
INFO - 2022-01-17 05:46:13 --> Config Class Initialized
INFO - 2022-01-17 05:46:13 --> Loader Class Initialized
INFO - 2022-01-17 05:46:13 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:13 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:13 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:13 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:13 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:13 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:13 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:13 --> Total execution time: 0.0720
INFO - 2022-01-17 05:46:15 --> Config Class Initialized
INFO - 2022-01-17 05:46:15 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:15 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:15 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:15 --> URI Class Initialized
INFO - 2022-01-17 05:46:15 --> Router Class Initialized
INFO - 2022-01-17 05:46:15 --> Output Class Initialized
INFO - 2022-01-17 05:46:15 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:15 --> Input Class Initialized
INFO - 2022-01-17 05:46:15 --> Language Class Initialized
INFO - 2022-01-17 05:46:15 --> Language Class Initialized
INFO - 2022-01-17 05:46:15 --> Config Class Initialized
INFO - 2022-01-17 05:46:15 --> Loader Class Initialized
INFO - 2022-01-17 05:46:15 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:15 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:15 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:15 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:15 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:15 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:15 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:15 --> Total execution time: 0.0560
INFO - 2022-01-17 05:46:17 --> Config Class Initialized
INFO - 2022-01-17 05:46:17 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:17 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:17 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:17 --> URI Class Initialized
INFO - 2022-01-17 05:46:17 --> Router Class Initialized
INFO - 2022-01-17 05:46:17 --> Output Class Initialized
INFO - 2022-01-17 05:46:17 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:17 --> Input Class Initialized
INFO - 2022-01-17 05:46:17 --> Language Class Initialized
INFO - 2022-01-17 05:46:17 --> Language Class Initialized
INFO - 2022-01-17 05:46:17 --> Config Class Initialized
INFO - 2022-01-17 05:46:17 --> Loader Class Initialized
INFO - 2022-01-17 05:46:17 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:17 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:17 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:17 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:17 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:17 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:17 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:17 --> Total execution time: 0.0630
INFO - 2022-01-17 05:46:20 --> Config Class Initialized
INFO - 2022-01-17 05:46:20 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:20 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:20 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:20 --> URI Class Initialized
INFO - 2022-01-17 05:46:20 --> Router Class Initialized
INFO - 2022-01-17 05:46:20 --> Output Class Initialized
INFO - 2022-01-17 05:46:20 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:20 --> Input Class Initialized
INFO - 2022-01-17 05:46:20 --> Language Class Initialized
INFO - 2022-01-17 05:46:20 --> Language Class Initialized
INFO - 2022-01-17 05:46:20 --> Config Class Initialized
INFO - 2022-01-17 05:46:20 --> Loader Class Initialized
INFO - 2022-01-17 05:46:20 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:20 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:20 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:20 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:20 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:20 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:20 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:20 --> Total execution time: 0.0640
INFO - 2022-01-17 05:46:22 --> Config Class Initialized
INFO - 2022-01-17 05:46:22 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:22 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:22 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:22 --> URI Class Initialized
INFO - 2022-01-17 05:46:22 --> Router Class Initialized
INFO - 2022-01-17 05:46:22 --> Output Class Initialized
INFO - 2022-01-17 05:46:22 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:22 --> Input Class Initialized
INFO - 2022-01-17 05:46:22 --> Language Class Initialized
INFO - 2022-01-17 05:46:22 --> Language Class Initialized
INFO - 2022-01-17 05:46:22 --> Config Class Initialized
INFO - 2022-01-17 05:46:22 --> Loader Class Initialized
INFO - 2022-01-17 05:46:22 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:22 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:22 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:22 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:22 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:22 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:22 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:22 --> Total execution time: 0.0650
INFO - 2022-01-17 05:46:24 --> Config Class Initialized
INFO - 2022-01-17 05:46:24 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:24 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:24 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:24 --> URI Class Initialized
INFO - 2022-01-17 05:46:24 --> Router Class Initialized
INFO - 2022-01-17 05:46:24 --> Output Class Initialized
INFO - 2022-01-17 05:46:24 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:24 --> Input Class Initialized
INFO - 2022-01-17 05:46:24 --> Language Class Initialized
INFO - 2022-01-17 05:46:24 --> Language Class Initialized
INFO - 2022-01-17 05:46:24 --> Config Class Initialized
INFO - 2022-01-17 05:46:24 --> Loader Class Initialized
INFO - 2022-01-17 05:46:24 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:24 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:24 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:24 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:24 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:24 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:24 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:24 --> Total execution time: 0.0730
INFO - 2022-01-17 05:46:27 --> Config Class Initialized
INFO - 2022-01-17 05:46:27 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:27 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:27 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:27 --> URI Class Initialized
INFO - 2022-01-17 05:46:27 --> Router Class Initialized
INFO - 2022-01-17 05:46:27 --> Output Class Initialized
INFO - 2022-01-17 05:46:27 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:27 --> Input Class Initialized
INFO - 2022-01-17 05:46:27 --> Language Class Initialized
INFO - 2022-01-17 05:46:27 --> Language Class Initialized
INFO - 2022-01-17 05:46:27 --> Config Class Initialized
INFO - 2022-01-17 05:46:27 --> Loader Class Initialized
INFO - 2022-01-17 05:46:27 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:27 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:27 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:27 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:27 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:27 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:27 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:27 --> Total execution time: 0.0590
INFO - 2022-01-17 05:46:31 --> Config Class Initialized
INFO - 2022-01-17 05:46:31 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:46:31 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:46:31 --> Utf8 Class Initialized
INFO - 2022-01-17 05:46:31 --> URI Class Initialized
INFO - 2022-01-17 05:46:31 --> Router Class Initialized
INFO - 2022-01-17 05:46:31 --> Output Class Initialized
INFO - 2022-01-17 05:46:31 --> Security Class Initialized
DEBUG - 2022-01-17 05:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:46:31 --> Input Class Initialized
INFO - 2022-01-17 05:46:31 --> Language Class Initialized
INFO - 2022-01-17 05:46:31 --> Language Class Initialized
INFO - 2022-01-17 05:46:31 --> Config Class Initialized
INFO - 2022-01-17 05:46:31 --> Loader Class Initialized
INFO - 2022-01-17 05:46:31 --> Helper loaded: url_helper
INFO - 2022-01-17 05:46:31 --> Helper loaded: file_helper
INFO - 2022-01-17 05:46:31 --> Helper loaded: form_helper
INFO - 2022-01-17 05:46:31 --> Helper loaded: my_helper
INFO - 2022-01-17 05:46:31 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:46:31 --> Controller Class Initialized
DEBUG - 2022-01-17 05:46:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:46:31 --> Final output sent to browser
DEBUG - 2022-01-17 05:46:31 --> Total execution time: 0.0550
INFO - 2022-01-17 05:49:55 --> Config Class Initialized
INFO - 2022-01-17 05:49:55 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:49:55 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:49:55 --> Utf8 Class Initialized
INFO - 2022-01-17 05:49:55 --> URI Class Initialized
INFO - 2022-01-17 05:49:55 --> Router Class Initialized
INFO - 2022-01-17 05:49:55 --> Output Class Initialized
INFO - 2022-01-17 05:49:55 --> Security Class Initialized
DEBUG - 2022-01-17 05:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:49:55 --> Input Class Initialized
INFO - 2022-01-17 05:49:55 --> Language Class Initialized
INFO - 2022-01-17 05:49:55 --> Language Class Initialized
INFO - 2022-01-17 05:49:55 --> Config Class Initialized
INFO - 2022-01-17 05:49:55 --> Loader Class Initialized
INFO - 2022-01-17 05:49:55 --> Helper loaded: url_helper
INFO - 2022-01-17 05:49:55 --> Helper loaded: file_helper
INFO - 2022-01-17 05:49:55 --> Helper loaded: form_helper
INFO - 2022-01-17 05:49:55 --> Helper loaded: my_helper
INFO - 2022-01-17 05:49:55 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:49:55 --> Controller Class Initialized
INFO - 2022-01-17 05:49:55 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:49:55 --> Config Class Initialized
INFO - 2022-01-17 05:49:55 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:49:55 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:49:55 --> Utf8 Class Initialized
INFO - 2022-01-17 05:49:55 --> URI Class Initialized
INFO - 2022-01-17 05:49:55 --> Router Class Initialized
INFO - 2022-01-17 05:49:55 --> Output Class Initialized
INFO - 2022-01-17 05:49:55 --> Security Class Initialized
DEBUG - 2022-01-17 05:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:49:55 --> Input Class Initialized
INFO - 2022-01-17 05:49:55 --> Language Class Initialized
INFO - 2022-01-17 05:49:55 --> Language Class Initialized
INFO - 2022-01-17 05:49:55 --> Config Class Initialized
INFO - 2022-01-17 05:49:55 --> Loader Class Initialized
INFO - 2022-01-17 05:49:55 --> Helper loaded: url_helper
INFO - 2022-01-17 05:49:55 --> Helper loaded: file_helper
INFO - 2022-01-17 05:49:55 --> Helper loaded: form_helper
INFO - 2022-01-17 05:49:55 --> Helper loaded: my_helper
INFO - 2022-01-17 05:49:55 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:49:55 --> Controller Class Initialized
DEBUG - 2022-01-17 05:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:49:55 --> Final output sent to browser
DEBUG - 2022-01-17 05:49:55 --> Total execution time: 0.0400
INFO - 2022-01-17 05:49:59 --> Config Class Initialized
INFO - 2022-01-17 05:49:59 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:49:59 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:49:59 --> Utf8 Class Initialized
INFO - 2022-01-17 05:49:59 --> URI Class Initialized
INFO - 2022-01-17 05:49:59 --> Router Class Initialized
INFO - 2022-01-17 05:49:59 --> Output Class Initialized
INFO - 2022-01-17 05:49:59 --> Security Class Initialized
DEBUG - 2022-01-17 05:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:49:59 --> Input Class Initialized
INFO - 2022-01-17 05:49:59 --> Language Class Initialized
INFO - 2022-01-17 05:49:59 --> Language Class Initialized
INFO - 2022-01-17 05:49:59 --> Config Class Initialized
INFO - 2022-01-17 05:49:59 --> Loader Class Initialized
INFO - 2022-01-17 05:49:59 --> Helper loaded: url_helper
INFO - 2022-01-17 05:49:59 --> Helper loaded: file_helper
INFO - 2022-01-17 05:49:59 --> Helper loaded: form_helper
INFO - 2022-01-17 05:49:59 --> Helper loaded: my_helper
INFO - 2022-01-17 05:49:59 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:49:59 --> Controller Class Initialized
INFO - 2022-01-17 05:49:59 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:49:59 --> Final output sent to browser
DEBUG - 2022-01-17 05:49:59 --> Total execution time: 0.0600
INFO - 2022-01-17 05:50:00 --> Config Class Initialized
INFO - 2022-01-17 05:50:00 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:00 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:00 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:00 --> URI Class Initialized
INFO - 2022-01-17 05:50:00 --> Router Class Initialized
INFO - 2022-01-17 05:50:00 --> Output Class Initialized
INFO - 2022-01-17 05:50:00 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:00 --> Input Class Initialized
INFO - 2022-01-17 05:50:00 --> Language Class Initialized
INFO - 2022-01-17 05:50:00 --> Language Class Initialized
INFO - 2022-01-17 05:50:00 --> Config Class Initialized
INFO - 2022-01-17 05:50:00 --> Loader Class Initialized
INFO - 2022-01-17 05:50:00 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:00 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:00 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:00 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:00 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:00 --> Controller Class Initialized
DEBUG - 2022-01-17 05:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:50:00 --> Final output sent to browser
DEBUG - 2022-01-17 05:50:00 --> Total execution time: 0.3690
INFO - 2022-01-17 05:50:36 --> Config Class Initialized
INFO - 2022-01-17 05:50:36 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:36 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:36 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:36 --> URI Class Initialized
INFO - 2022-01-17 05:50:36 --> Router Class Initialized
INFO - 2022-01-17 05:50:36 --> Output Class Initialized
INFO - 2022-01-17 05:50:36 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:36 --> Input Class Initialized
INFO - 2022-01-17 05:50:36 --> Language Class Initialized
INFO - 2022-01-17 05:50:36 --> Language Class Initialized
INFO - 2022-01-17 05:50:36 --> Config Class Initialized
INFO - 2022-01-17 05:50:36 --> Loader Class Initialized
INFO - 2022-01-17 05:50:36 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:36 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:36 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:36 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:36 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:36 --> Controller Class Initialized
DEBUG - 2022-01-17 05:50:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-17 05:50:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:50:36 --> Final output sent to browser
DEBUG - 2022-01-17 05:50:36 --> Total execution time: 0.0570
INFO - 2022-01-17 05:50:36 --> Config Class Initialized
INFO - 2022-01-17 05:50:36 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:36 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:36 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:36 --> URI Class Initialized
INFO - 2022-01-17 05:50:36 --> Router Class Initialized
INFO - 2022-01-17 05:50:36 --> Output Class Initialized
INFO - 2022-01-17 05:50:36 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:36 --> Input Class Initialized
INFO - 2022-01-17 05:50:36 --> Language Class Initialized
INFO - 2022-01-17 05:50:36 --> Language Class Initialized
INFO - 2022-01-17 05:50:36 --> Config Class Initialized
INFO - 2022-01-17 05:50:36 --> Loader Class Initialized
INFO - 2022-01-17 05:50:36 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:36 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:36 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:36 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:36 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:36 --> Controller Class Initialized
INFO - 2022-01-17 05:50:37 --> Config Class Initialized
INFO - 2022-01-17 05:50:37 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:37 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:37 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:37 --> URI Class Initialized
INFO - 2022-01-17 05:50:37 --> Router Class Initialized
INFO - 2022-01-17 05:50:37 --> Output Class Initialized
INFO - 2022-01-17 05:50:37 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:37 --> Input Class Initialized
INFO - 2022-01-17 05:50:37 --> Language Class Initialized
INFO - 2022-01-17 05:50:37 --> Language Class Initialized
INFO - 2022-01-17 05:50:37 --> Config Class Initialized
INFO - 2022-01-17 05:50:37 --> Loader Class Initialized
INFO - 2022-01-17 05:50:37 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:37 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:37 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:37 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:37 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:37 --> Controller Class Initialized
INFO - 2022-01-17 05:50:37 --> Final output sent to browser
DEBUG - 2022-01-17 05:50:37 --> Total execution time: 0.0530
INFO - 2022-01-17 05:50:37 --> Config Class Initialized
INFO - 2022-01-17 05:50:37 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:37 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:37 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:37 --> URI Class Initialized
INFO - 2022-01-17 05:50:37 --> Router Class Initialized
INFO - 2022-01-17 05:50:37 --> Output Class Initialized
INFO - 2022-01-17 05:50:37 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:37 --> Input Class Initialized
INFO - 2022-01-17 05:50:37 --> Language Class Initialized
INFO - 2022-01-17 05:50:37 --> Language Class Initialized
INFO - 2022-01-17 05:50:37 --> Config Class Initialized
INFO - 2022-01-17 05:50:37 --> Loader Class Initialized
INFO - 2022-01-17 05:50:37 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:37 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:37 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:37 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:37 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:37 --> Controller Class Initialized
INFO - 2022-01-17 05:50:39 --> Config Class Initialized
INFO - 2022-01-17 05:50:39 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:39 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:39 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:39 --> URI Class Initialized
INFO - 2022-01-17 05:50:39 --> Router Class Initialized
INFO - 2022-01-17 05:50:39 --> Output Class Initialized
INFO - 2022-01-17 05:50:39 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:39 --> Input Class Initialized
INFO - 2022-01-17 05:50:39 --> Language Class Initialized
INFO - 2022-01-17 05:50:39 --> Language Class Initialized
INFO - 2022-01-17 05:50:39 --> Config Class Initialized
INFO - 2022-01-17 05:50:39 --> Loader Class Initialized
INFO - 2022-01-17 05:50:39 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:39 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:39 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:39 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:39 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:39 --> Controller Class Initialized
INFO - 2022-01-17 05:50:39 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:50:39 --> Config Class Initialized
INFO - 2022-01-17 05:50:39 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:39 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:39 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:39 --> URI Class Initialized
INFO - 2022-01-17 05:50:39 --> Router Class Initialized
INFO - 2022-01-17 05:50:39 --> Output Class Initialized
INFO - 2022-01-17 05:50:40 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:40 --> Input Class Initialized
INFO - 2022-01-17 05:50:40 --> Language Class Initialized
INFO - 2022-01-17 05:50:40 --> Language Class Initialized
INFO - 2022-01-17 05:50:40 --> Config Class Initialized
INFO - 2022-01-17 05:50:40 --> Loader Class Initialized
INFO - 2022-01-17 05:50:40 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:40 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:40 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:40 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:40 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:40 --> Controller Class Initialized
DEBUG - 2022-01-17 05:50:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:50:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:50:40 --> Final output sent to browser
DEBUG - 2022-01-17 05:50:40 --> Total execution time: 0.0360
INFO - 2022-01-17 05:50:43 --> Config Class Initialized
INFO - 2022-01-17 05:50:43 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:43 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:43 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:43 --> URI Class Initialized
INFO - 2022-01-17 05:50:43 --> Router Class Initialized
INFO - 2022-01-17 05:50:43 --> Output Class Initialized
INFO - 2022-01-17 05:50:43 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:43 --> Input Class Initialized
INFO - 2022-01-17 05:50:43 --> Language Class Initialized
INFO - 2022-01-17 05:50:43 --> Language Class Initialized
INFO - 2022-01-17 05:50:43 --> Config Class Initialized
INFO - 2022-01-17 05:50:43 --> Loader Class Initialized
INFO - 2022-01-17 05:50:43 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:43 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:43 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:43 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:43 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:43 --> Controller Class Initialized
INFO - 2022-01-17 05:50:43 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:50:43 --> Final output sent to browser
DEBUG - 2022-01-17 05:50:43 --> Total execution time: 0.0590
INFO - 2022-01-17 05:50:43 --> Config Class Initialized
INFO - 2022-01-17 05:50:43 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:43 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:43 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:43 --> URI Class Initialized
INFO - 2022-01-17 05:50:43 --> Router Class Initialized
INFO - 2022-01-17 05:50:43 --> Output Class Initialized
INFO - 2022-01-17 05:50:43 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:43 --> Input Class Initialized
INFO - 2022-01-17 05:50:43 --> Language Class Initialized
INFO - 2022-01-17 05:50:43 --> Language Class Initialized
INFO - 2022-01-17 05:50:43 --> Config Class Initialized
INFO - 2022-01-17 05:50:43 --> Loader Class Initialized
INFO - 2022-01-17 05:50:43 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:43 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:43 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:43 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:43 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:43 --> Controller Class Initialized
DEBUG - 2022-01-17 05:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:50:43 --> Final output sent to browser
DEBUG - 2022-01-17 05:50:43 --> Total execution time: 0.2650
INFO - 2022-01-17 05:50:45 --> Config Class Initialized
INFO - 2022-01-17 05:50:45 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:45 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:45 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:45 --> URI Class Initialized
INFO - 2022-01-17 05:50:45 --> Router Class Initialized
INFO - 2022-01-17 05:50:45 --> Output Class Initialized
INFO - 2022-01-17 05:50:45 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:45 --> Input Class Initialized
INFO - 2022-01-17 05:50:45 --> Language Class Initialized
INFO - 2022-01-17 05:50:45 --> Language Class Initialized
INFO - 2022-01-17 05:50:45 --> Config Class Initialized
INFO - 2022-01-17 05:50:45 --> Loader Class Initialized
INFO - 2022-01-17 05:50:45 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:45 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:45 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:45 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:45 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:45 --> Controller Class Initialized
DEBUG - 2022-01-17 05:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-17 05:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:50:45 --> Final output sent to browser
DEBUG - 2022-01-17 05:50:45 --> Total execution time: 0.0630
INFO - 2022-01-17 05:50:47 --> Config Class Initialized
INFO - 2022-01-17 05:50:47 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:50:47 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:50:47 --> Utf8 Class Initialized
INFO - 2022-01-17 05:50:47 --> URI Class Initialized
INFO - 2022-01-17 05:50:47 --> Router Class Initialized
INFO - 2022-01-17 05:50:47 --> Output Class Initialized
INFO - 2022-01-17 05:50:47 --> Security Class Initialized
DEBUG - 2022-01-17 05:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:50:47 --> Input Class Initialized
INFO - 2022-01-17 05:50:47 --> Language Class Initialized
INFO - 2022-01-17 05:50:47 --> Language Class Initialized
INFO - 2022-01-17 05:50:47 --> Config Class Initialized
INFO - 2022-01-17 05:50:47 --> Loader Class Initialized
INFO - 2022-01-17 05:50:47 --> Helper loaded: url_helper
INFO - 2022-01-17 05:50:47 --> Helper loaded: file_helper
INFO - 2022-01-17 05:50:47 --> Helper loaded: form_helper
INFO - 2022-01-17 05:50:47 --> Helper loaded: my_helper
INFO - 2022-01-17 05:50:47 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:50:47 --> Controller Class Initialized
DEBUG - 2022-01-17 05:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2022-01-17 05:50:47 --> Final output sent to browser
DEBUG - 2022-01-17 05:50:47 --> Total execution time: 0.0940
INFO - 2022-01-17 05:51:06 --> Config Class Initialized
INFO - 2022-01-17 05:51:06 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:51:06 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:51:06 --> Utf8 Class Initialized
INFO - 2022-01-17 05:51:06 --> URI Class Initialized
INFO - 2022-01-17 05:51:06 --> Router Class Initialized
INFO - 2022-01-17 05:51:06 --> Output Class Initialized
INFO - 2022-01-17 05:51:06 --> Security Class Initialized
DEBUG - 2022-01-17 05:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:51:06 --> Input Class Initialized
INFO - 2022-01-17 05:51:06 --> Language Class Initialized
INFO - 2022-01-17 05:51:06 --> Language Class Initialized
INFO - 2022-01-17 05:51:06 --> Config Class Initialized
INFO - 2022-01-17 05:51:06 --> Loader Class Initialized
INFO - 2022-01-17 05:51:06 --> Helper loaded: url_helper
INFO - 2022-01-17 05:51:06 --> Helper loaded: file_helper
INFO - 2022-01-17 05:51:06 --> Helper loaded: form_helper
INFO - 2022-01-17 05:51:06 --> Helper loaded: my_helper
INFO - 2022-01-17 05:51:06 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:51:06 --> Controller Class Initialized
INFO - 2022-01-17 05:51:06 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:51:06 --> Config Class Initialized
INFO - 2022-01-17 05:51:06 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:51:06 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:51:06 --> Utf8 Class Initialized
INFO - 2022-01-17 05:51:06 --> URI Class Initialized
INFO - 2022-01-17 05:51:06 --> Router Class Initialized
INFO - 2022-01-17 05:51:06 --> Output Class Initialized
INFO - 2022-01-17 05:51:06 --> Security Class Initialized
DEBUG - 2022-01-17 05:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:51:06 --> Input Class Initialized
INFO - 2022-01-17 05:51:06 --> Language Class Initialized
INFO - 2022-01-17 05:51:06 --> Language Class Initialized
INFO - 2022-01-17 05:51:06 --> Config Class Initialized
INFO - 2022-01-17 05:51:06 --> Loader Class Initialized
INFO - 2022-01-17 05:51:06 --> Helper loaded: url_helper
INFO - 2022-01-17 05:51:06 --> Helper loaded: file_helper
INFO - 2022-01-17 05:51:06 --> Helper loaded: form_helper
INFO - 2022-01-17 05:51:06 --> Helper loaded: my_helper
INFO - 2022-01-17 05:51:06 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:51:07 --> Controller Class Initialized
DEBUG - 2022-01-17 05:51:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:51:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:51:07 --> Final output sent to browser
DEBUG - 2022-01-17 05:51:07 --> Total execution time: 0.0370
INFO - 2022-01-17 05:51:14 --> Config Class Initialized
INFO - 2022-01-17 05:51:14 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:51:14 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:51:14 --> Utf8 Class Initialized
INFO - 2022-01-17 05:51:14 --> URI Class Initialized
INFO - 2022-01-17 05:51:14 --> Router Class Initialized
INFO - 2022-01-17 05:51:14 --> Output Class Initialized
INFO - 2022-01-17 05:51:14 --> Security Class Initialized
DEBUG - 2022-01-17 05:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:51:14 --> Input Class Initialized
INFO - 2022-01-17 05:51:14 --> Language Class Initialized
INFO - 2022-01-17 05:51:14 --> Language Class Initialized
INFO - 2022-01-17 05:51:14 --> Config Class Initialized
INFO - 2022-01-17 05:51:14 --> Loader Class Initialized
INFO - 2022-01-17 05:51:14 --> Helper loaded: url_helper
INFO - 2022-01-17 05:51:14 --> Helper loaded: file_helper
INFO - 2022-01-17 05:51:14 --> Helper loaded: form_helper
INFO - 2022-01-17 05:51:14 --> Helper loaded: my_helper
INFO - 2022-01-17 05:51:14 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:51:14 --> Controller Class Initialized
INFO - 2022-01-17 05:51:14 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:51:14 --> Final output sent to browser
DEBUG - 2022-01-17 05:51:14 --> Total execution time: 0.0480
INFO - 2022-01-17 05:51:14 --> Config Class Initialized
INFO - 2022-01-17 05:51:14 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:51:15 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:51:15 --> Utf8 Class Initialized
INFO - 2022-01-17 05:51:15 --> URI Class Initialized
INFO - 2022-01-17 05:51:15 --> Router Class Initialized
INFO - 2022-01-17 05:51:15 --> Output Class Initialized
INFO - 2022-01-17 05:51:15 --> Security Class Initialized
DEBUG - 2022-01-17 05:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:51:15 --> Input Class Initialized
INFO - 2022-01-17 05:51:15 --> Language Class Initialized
INFO - 2022-01-17 05:51:15 --> Language Class Initialized
INFO - 2022-01-17 05:51:15 --> Config Class Initialized
INFO - 2022-01-17 05:51:15 --> Loader Class Initialized
INFO - 2022-01-17 05:51:15 --> Helper loaded: url_helper
INFO - 2022-01-17 05:51:15 --> Helper loaded: file_helper
INFO - 2022-01-17 05:51:15 --> Helper loaded: form_helper
INFO - 2022-01-17 05:51:15 --> Helper loaded: my_helper
INFO - 2022-01-17 05:51:15 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:51:15 --> Controller Class Initialized
DEBUG - 2022-01-17 05:51:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:51:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:51:15 --> Final output sent to browser
DEBUG - 2022-01-17 05:51:15 --> Total execution time: 0.3820
INFO - 2022-01-17 05:51:16 --> Config Class Initialized
INFO - 2022-01-17 05:51:16 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:51:16 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:51:16 --> Utf8 Class Initialized
INFO - 2022-01-17 05:51:16 --> URI Class Initialized
INFO - 2022-01-17 05:51:16 --> Router Class Initialized
INFO - 2022-01-17 05:51:16 --> Output Class Initialized
INFO - 2022-01-17 05:51:16 --> Security Class Initialized
DEBUG - 2022-01-17 05:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:51:16 --> Input Class Initialized
INFO - 2022-01-17 05:51:16 --> Language Class Initialized
INFO - 2022-01-17 05:51:16 --> Language Class Initialized
INFO - 2022-01-17 05:51:16 --> Config Class Initialized
INFO - 2022-01-17 05:51:16 --> Loader Class Initialized
INFO - 2022-01-17 05:51:16 --> Helper loaded: url_helper
INFO - 2022-01-17 05:51:16 --> Helper loaded: file_helper
INFO - 2022-01-17 05:51:16 --> Helper loaded: form_helper
INFO - 2022-01-17 05:51:16 --> Helper loaded: my_helper
INFO - 2022-01-17 05:51:16 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:51:16 --> Controller Class Initialized
DEBUG - 2022-01-17 05:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-17 05:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:51:16 --> Final output sent to browser
DEBUG - 2022-01-17 05:51:16 --> Total execution time: 0.0600
INFO - 2022-01-17 05:51:20 --> Config Class Initialized
INFO - 2022-01-17 05:51:20 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:51:20 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:51:20 --> Utf8 Class Initialized
INFO - 2022-01-17 05:51:20 --> URI Class Initialized
INFO - 2022-01-17 05:51:20 --> Router Class Initialized
INFO - 2022-01-17 05:51:20 --> Output Class Initialized
INFO - 2022-01-17 05:51:20 --> Security Class Initialized
DEBUG - 2022-01-17 05:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:51:20 --> Input Class Initialized
INFO - 2022-01-17 05:51:20 --> Language Class Initialized
INFO - 2022-01-17 05:51:20 --> Language Class Initialized
INFO - 2022-01-17 05:51:20 --> Config Class Initialized
INFO - 2022-01-17 05:51:20 --> Loader Class Initialized
INFO - 2022-01-17 05:51:20 --> Helper loaded: url_helper
INFO - 2022-01-17 05:51:20 --> Helper loaded: file_helper
INFO - 2022-01-17 05:51:20 --> Helper loaded: form_helper
INFO - 2022-01-17 05:51:20 --> Helper loaded: my_helper
INFO - 2022-01-17 05:51:20 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:51:20 --> Controller Class Initialized
DEBUG - 2022-01-17 05:51:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:51:20 --> Final output sent to browser
DEBUG - 2022-01-17 05:51:20 --> Total execution time: 0.1090
INFO - 2022-01-17 05:52:46 --> Config Class Initialized
INFO - 2022-01-17 05:52:46 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:52:46 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:52:46 --> Utf8 Class Initialized
INFO - 2022-01-17 05:52:46 --> URI Class Initialized
INFO - 2022-01-17 05:52:46 --> Router Class Initialized
INFO - 2022-01-17 05:52:46 --> Output Class Initialized
INFO - 2022-01-17 05:52:46 --> Security Class Initialized
DEBUG - 2022-01-17 05:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:52:46 --> Input Class Initialized
INFO - 2022-01-17 05:52:46 --> Language Class Initialized
INFO - 2022-01-17 05:52:46 --> Language Class Initialized
INFO - 2022-01-17 05:52:46 --> Config Class Initialized
INFO - 2022-01-17 05:52:46 --> Loader Class Initialized
INFO - 2022-01-17 05:52:46 --> Helper loaded: url_helper
INFO - 2022-01-17 05:52:46 --> Helper loaded: file_helper
INFO - 2022-01-17 05:52:46 --> Helper loaded: form_helper
INFO - 2022-01-17 05:52:46 --> Helper loaded: my_helper
INFO - 2022-01-17 05:52:46 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:52:46 --> Controller Class Initialized
DEBUG - 2022-01-17 05:52:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:52:46 --> Final output sent to browser
DEBUG - 2022-01-17 05:52:46 --> Total execution time: 0.0760
INFO - 2022-01-17 05:52:48 --> Config Class Initialized
INFO - 2022-01-17 05:52:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:52:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:52:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:52:48 --> URI Class Initialized
INFO - 2022-01-17 05:52:48 --> Router Class Initialized
INFO - 2022-01-17 05:52:48 --> Output Class Initialized
INFO - 2022-01-17 05:52:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:52:48 --> Input Class Initialized
INFO - 2022-01-17 05:52:48 --> Language Class Initialized
INFO - 2022-01-17 05:52:48 --> Language Class Initialized
INFO - 2022-01-17 05:52:48 --> Config Class Initialized
INFO - 2022-01-17 05:52:48 --> Loader Class Initialized
INFO - 2022-01-17 05:52:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:52:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:52:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:52:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:52:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:52:48 --> Controller Class Initialized
DEBUG - 2022-01-17 05:52:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:52:48 --> Final output sent to browser
DEBUG - 2022-01-17 05:52:48 --> Total execution time: 0.0610
INFO - 2022-01-17 05:52:51 --> Config Class Initialized
INFO - 2022-01-17 05:52:51 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:52:51 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:52:51 --> Utf8 Class Initialized
INFO - 2022-01-17 05:52:51 --> URI Class Initialized
INFO - 2022-01-17 05:52:51 --> Router Class Initialized
INFO - 2022-01-17 05:52:51 --> Output Class Initialized
INFO - 2022-01-17 05:52:51 --> Security Class Initialized
DEBUG - 2022-01-17 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:52:51 --> Input Class Initialized
INFO - 2022-01-17 05:52:51 --> Language Class Initialized
INFO - 2022-01-17 05:52:51 --> Language Class Initialized
INFO - 2022-01-17 05:52:51 --> Config Class Initialized
INFO - 2022-01-17 05:52:51 --> Loader Class Initialized
INFO - 2022-01-17 05:52:51 --> Helper loaded: url_helper
INFO - 2022-01-17 05:52:51 --> Helper loaded: file_helper
INFO - 2022-01-17 05:52:51 --> Helper loaded: form_helper
INFO - 2022-01-17 05:52:51 --> Helper loaded: my_helper
INFO - 2022-01-17 05:52:51 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:52:51 --> Controller Class Initialized
DEBUG - 2022-01-17 05:52:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:52:51 --> Final output sent to browser
DEBUG - 2022-01-17 05:52:51 --> Total execution time: 0.0570
INFO - 2022-01-17 05:52:52 --> Config Class Initialized
INFO - 2022-01-17 05:52:52 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:52:52 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:52:52 --> Utf8 Class Initialized
INFO - 2022-01-17 05:52:52 --> URI Class Initialized
INFO - 2022-01-17 05:52:52 --> Router Class Initialized
INFO - 2022-01-17 05:52:52 --> Output Class Initialized
INFO - 2022-01-17 05:52:52 --> Security Class Initialized
DEBUG - 2022-01-17 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:52:52 --> Input Class Initialized
INFO - 2022-01-17 05:52:52 --> Language Class Initialized
INFO - 2022-01-17 05:52:52 --> Language Class Initialized
INFO - 2022-01-17 05:52:52 --> Config Class Initialized
INFO - 2022-01-17 05:52:52 --> Loader Class Initialized
INFO - 2022-01-17 05:52:52 --> Helper loaded: url_helper
INFO - 2022-01-17 05:52:52 --> Helper loaded: file_helper
INFO - 2022-01-17 05:52:52 --> Helper loaded: form_helper
INFO - 2022-01-17 05:52:52 --> Helper loaded: my_helper
INFO - 2022-01-17 05:52:52 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:52:52 --> Controller Class Initialized
DEBUG - 2022-01-17 05:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:52:52 --> Final output sent to browser
DEBUG - 2022-01-17 05:52:52 --> Total execution time: 0.0560
INFO - 2022-01-17 05:52:54 --> Config Class Initialized
INFO - 2022-01-17 05:52:54 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:52:54 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:52:54 --> Utf8 Class Initialized
INFO - 2022-01-17 05:52:54 --> URI Class Initialized
INFO - 2022-01-17 05:52:54 --> Router Class Initialized
INFO - 2022-01-17 05:52:54 --> Output Class Initialized
INFO - 2022-01-17 05:52:54 --> Security Class Initialized
DEBUG - 2022-01-17 05:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:52:54 --> Input Class Initialized
INFO - 2022-01-17 05:52:54 --> Language Class Initialized
INFO - 2022-01-17 05:52:54 --> Language Class Initialized
INFO - 2022-01-17 05:52:54 --> Config Class Initialized
INFO - 2022-01-17 05:52:54 --> Loader Class Initialized
INFO - 2022-01-17 05:52:54 --> Helper loaded: url_helper
INFO - 2022-01-17 05:52:54 --> Helper loaded: file_helper
INFO - 2022-01-17 05:52:54 --> Helper loaded: form_helper
INFO - 2022-01-17 05:52:54 --> Helper loaded: my_helper
INFO - 2022-01-17 05:52:54 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:52:54 --> Controller Class Initialized
DEBUG - 2022-01-17 05:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:52:54 --> Final output sent to browser
DEBUG - 2022-01-17 05:52:54 --> Total execution time: 0.0720
INFO - 2022-01-17 05:52:57 --> Config Class Initialized
INFO - 2022-01-17 05:52:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:52:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:52:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:52:57 --> URI Class Initialized
INFO - 2022-01-17 05:52:57 --> Router Class Initialized
INFO - 2022-01-17 05:52:57 --> Output Class Initialized
INFO - 2022-01-17 05:52:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:52:57 --> Input Class Initialized
INFO - 2022-01-17 05:52:57 --> Language Class Initialized
INFO - 2022-01-17 05:52:57 --> Language Class Initialized
INFO - 2022-01-17 05:52:57 --> Config Class Initialized
INFO - 2022-01-17 05:52:57 --> Loader Class Initialized
INFO - 2022-01-17 05:52:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:52:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:52:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:52:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:52:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:52:57 --> Controller Class Initialized
DEBUG - 2022-01-17 05:52:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:52:57 --> Final output sent to browser
DEBUG - 2022-01-17 05:52:57 --> Total execution time: 0.0670
INFO - 2022-01-17 05:52:58 --> Config Class Initialized
INFO - 2022-01-17 05:52:58 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:52:58 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:52:58 --> Utf8 Class Initialized
INFO - 2022-01-17 05:52:58 --> URI Class Initialized
INFO - 2022-01-17 05:52:58 --> Router Class Initialized
INFO - 2022-01-17 05:52:58 --> Output Class Initialized
INFO - 2022-01-17 05:52:58 --> Security Class Initialized
DEBUG - 2022-01-17 05:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:52:58 --> Input Class Initialized
INFO - 2022-01-17 05:52:58 --> Language Class Initialized
INFO - 2022-01-17 05:52:58 --> Language Class Initialized
INFO - 2022-01-17 05:52:58 --> Config Class Initialized
INFO - 2022-01-17 05:52:58 --> Loader Class Initialized
INFO - 2022-01-17 05:52:58 --> Helper loaded: url_helper
INFO - 2022-01-17 05:52:58 --> Helper loaded: file_helper
INFO - 2022-01-17 05:52:58 --> Helper loaded: form_helper
INFO - 2022-01-17 05:52:58 --> Helper loaded: my_helper
INFO - 2022-01-17 05:52:58 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:52:58 --> Controller Class Initialized
DEBUG - 2022-01-17 05:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:52:58 --> Final output sent to browser
DEBUG - 2022-01-17 05:52:58 --> Total execution time: 0.0680
INFO - 2022-01-17 05:52:59 --> Config Class Initialized
INFO - 2022-01-17 05:52:59 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:52:59 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:52:59 --> Utf8 Class Initialized
INFO - 2022-01-17 05:52:59 --> URI Class Initialized
INFO - 2022-01-17 05:52:59 --> Router Class Initialized
INFO - 2022-01-17 05:52:59 --> Output Class Initialized
INFO - 2022-01-17 05:52:59 --> Security Class Initialized
DEBUG - 2022-01-17 05:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:52:59 --> Input Class Initialized
INFO - 2022-01-17 05:52:59 --> Language Class Initialized
INFO - 2022-01-17 05:52:59 --> Language Class Initialized
INFO - 2022-01-17 05:52:59 --> Config Class Initialized
INFO - 2022-01-17 05:52:59 --> Loader Class Initialized
INFO - 2022-01-17 05:52:59 --> Helper loaded: url_helper
INFO - 2022-01-17 05:52:59 --> Helper loaded: file_helper
INFO - 2022-01-17 05:52:59 --> Helper loaded: form_helper
INFO - 2022-01-17 05:52:59 --> Helper loaded: my_helper
INFO - 2022-01-17 05:52:59 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:52:59 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:00 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:00 --> Total execution time: 0.0670
INFO - 2022-01-17 05:53:02 --> Config Class Initialized
INFO - 2022-01-17 05:53:02 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:02 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:02 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:02 --> URI Class Initialized
INFO - 2022-01-17 05:53:02 --> Router Class Initialized
INFO - 2022-01-17 05:53:02 --> Output Class Initialized
INFO - 2022-01-17 05:53:02 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:02 --> Input Class Initialized
INFO - 2022-01-17 05:53:02 --> Language Class Initialized
INFO - 2022-01-17 05:53:02 --> Language Class Initialized
INFO - 2022-01-17 05:53:02 --> Config Class Initialized
INFO - 2022-01-17 05:53:02 --> Loader Class Initialized
INFO - 2022-01-17 05:53:02 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:02 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:02 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:02 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:02 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:02 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:02 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:02 --> Total execution time: 0.0670
INFO - 2022-01-17 05:53:04 --> Config Class Initialized
INFO - 2022-01-17 05:53:04 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:04 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:04 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:04 --> URI Class Initialized
INFO - 2022-01-17 05:53:04 --> Router Class Initialized
INFO - 2022-01-17 05:53:04 --> Output Class Initialized
INFO - 2022-01-17 05:53:04 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:04 --> Input Class Initialized
INFO - 2022-01-17 05:53:04 --> Language Class Initialized
INFO - 2022-01-17 05:53:04 --> Language Class Initialized
INFO - 2022-01-17 05:53:04 --> Config Class Initialized
INFO - 2022-01-17 05:53:04 --> Loader Class Initialized
INFO - 2022-01-17 05:53:04 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:04 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:04 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:04 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:04 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:04 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:04 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:04 --> Total execution time: 0.0590
INFO - 2022-01-17 05:53:06 --> Config Class Initialized
INFO - 2022-01-17 05:53:06 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:06 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:06 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:06 --> URI Class Initialized
INFO - 2022-01-17 05:53:06 --> Router Class Initialized
INFO - 2022-01-17 05:53:06 --> Output Class Initialized
INFO - 2022-01-17 05:53:06 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:06 --> Input Class Initialized
INFO - 2022-01-17 05:53:06 --> Language Class Initialized
INFO - 2022-01-17 05:53:06 --> Language Class Initialized
INFO - 2022-01-17 05:53:06 --> Config Class Initialized
INFO - 2022-01-17 05:53:06 --> Loader Class Initialized
INFO - 2022-01-17 05:53:06 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:06 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:06 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:06 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:06 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:07 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:07 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:07 --> Total execution time: 0.0700
INFO - 2022-01-17 05:53:09 --> Config Class Initialized
INFO - 2022-01-17 05:53:09 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:09 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:09 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:09 --> URI Class Initialized
INFO - 2022-01-17 05:53:09 --> Router Class Initialized
INFO - 2022-01-17 05:53:09 --> Output Class Initialized
INFO - 2022-01-17 05:53:09 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:09 --> Input Class Initialized
INFO - 2022-01-17 05:53:09 --> Language Class Initialized
INFO - 2022-01-17 05:53:09 --> Language Class Initialized
INFO - 2022-01-17 05:53:09 --> Config Class Initialized
INFO - 2022-01-17 05:53:09 --> Loader Class Initialized
INFO - 2022-01-17 05:53:09 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:09 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:09 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:09 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:09 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:09 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:09 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:09 --> Total execution time: 0.0700
INFO - 2022-01-17 05:53:10 --> Config Class Initialized
INFO - 2022-01-17 05:53:10 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:10 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:10 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:11 --> URI Class Initialized
INFO - 2022-01-17 05:53:11 --> Router Class Initialized
INFO - 2022-01-17 05:53:11 --> Output Class Initialized
INFO - 2022-01-17 05:53:11 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:11 --> Input Class Initialized
INFO - 2022-01-17 05:53:11 --> Language Class Initialized
INFO - 2022-01-17 05:53:11 --> Language Class Initialized
INFO - 2022-01-17 05:53:11 --> Config Class Initialized
INFO - 2022-01-17 05:53:11 --> Loader Class Initialized
INFO - 2022-01-17 05:53:11 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:11 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:11 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:11 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:11 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:11 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:11 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:11 --> Total execution time: 0.0740
INFO - 2022-01-17 05:53:13 --> Config Class Initialized
INFO - 2022-01-17 05:53:13 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:13 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:13 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:13 --> URI Class Initialized
INFO - 2022-01-17 05:53:13 --> Router Class Initialized
INFO - 2022-01-17 05:53:13 --> Output Class Initialized
INFO - 2022-01-17 05:53:13 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:13 --> Input Class Initialized
INFO - 2022-01-17 05:53:13 --> Language Class Initialized
INFO - 2022-01-17 05:53:13 --> Language Class Initialized
INFO - 2022-01-17 05:53:13 --> Config Class Initialized
INFO - 2022-01-17 05:53:13 --> Loader Class Initialized
INFO - 2022-01-17 05:53:13 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:13 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:13 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:13 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:13 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:13 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:13 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:13 --> Total execution time: 0.0730
INFO - 2022-01-17 05:53:15 --> Config Class Initialized
INFO - 2022-01-17 05:53:15 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:15 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:15 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:15 --> URI Class Initialized
INFO - 2022-01-17 05:53:15 --> Router Class Initialized
INFO - 2022-01-17 05:53:15 --> Output Class Initialized
INFO - 2022-01-17 05:53:15 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:15 --> Input Class Initialized
INFO - 2022-01-17 05:53:15 --> Language Class Initialized
INFO - 2022-01-17 05:53:15 --> Language Class Initialized
INFO - 2022-01-17 05:53:15 --> Config Class Initialized
INFO - 2022-01-17 05:53:15 --> Loader Class Initialized
INFO - 2022-01-17 05:53:15 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:15 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:15 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:15 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:15 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:15 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:15 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:15 --> Total execution time: 0.0590
INFO - 2022-01-17 05:53:16 --> Config Class Initialized
INFO - 2022-01-17 05:53:16 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:16 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:16 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:16 --> URI Class Initialized
INFO - 2022-01-17 05:53:16 --> Router Class Initialized
INFO - 2022-01-17 05:53:16 --> Output Class Initialized
INFO - 2022-01-17 05:53:16 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:16 --> Input Class Initialized
INFO - 2022-01-17 05:53:16 --> Language Class Initialized
INFO - 2022-01-17 05:53:16 --> Language Class Initialized
INFO - 2022-01-17 05:53:16 --> Config Class Initialized
INFO - 2022-01-17 05:53:16 --> Loader Class Initialized
INFO - 2022-01-17 05:53:16 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:16 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:16 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:16 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:16 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:16 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:16 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:16 --> Total execution time: 0.0710
INFO - 2022-01-17 05:53:19 --> Config Class Initialized
INFO - 2022-01-17 05:53:19 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:19 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:19 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:19 --> URI Class Initialized
INFO - 2022-01-17 05:53:19 --> Router Class Initialized
INFO - 2022-01-17 05:53:19 --> Output Class Initialized
INFO - 2022-01-17 05:53:19 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:19 --> Input Class Initialized
INFO - 2022-01-17 05:53:19 --> Language Class Initialized
INFO - 2022-01-17 05:53:19 --> Language Class Initialized
INFO - 2022-01-17 05:53:19 --> Config Class Initialized
INFO - 2022-01-17 05:53:19 --> Loader Class Initialized
INFO - 2022-01-17 05:53:19 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:19 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:19 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:19 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:19 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:19 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:19 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:19 --> Total execution time: 0.0700
INFO - 2022-01-17 05:53:20 --> Config Class Initialized
INFO - 2022-01-17 05:53:20 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:20 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:20 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:20 --> URI Class Initialized
INFO - 2022-01-17 05:53:20 --> Router Class Initialized
INFO - 2022-01-17 05:53:20 --> Output Class Initialized
INFO - 2022-01-17 05:53:20 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:20 --> Input Class Initialized
INFO - 2022-01-17 05:53:20 --> Language Class Initialized
INFO - 2022-01-17 05:53:20 --> Language Class Initialized
INFO - 2022-01-17 05:53:20 --> Config Class Initialized
INFO - 2022-01-17 05:53:20 --> Loader Class Initialized
INFO - 2022-01-17 05:53:20 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:20 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:20 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:20 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:20 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:21 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:21 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:21 --> Total execution time: 0.0760
INFO - 2022-01-17 05:53:22 --> Config Class Initialized
INFO - 2022-01-17 05:53:22 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:22 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:22 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:22 --> URI Class Initialized
INFO - 2022-01-17 05:53:22 --> Router Class Initialized
INFO - 2022-01-17 05:53:22 --> Output Class Initialized
INFO - 2022-01-17 05:53:22 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:22 --> Input Class Initialized
INFO - 2022-01-17 05:53:22 --> Language Class Initialized
INFO - 2022-01-17 05:53:22 --> Language Class Initialized
INFO - 2022-01-17 05:53:22 --> Config Class Initialized
INFO - 2022-01-17 05:53:22 --> Loader Class Initialized
INFO - 2022-01-17 05:53:22 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:22 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:22 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:22 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:22 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:22 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:22 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:22 --> Total execution time: 0.0720
INFO - 2022-01-17 05:53:26 --> Config Class Initialized
INFO - 2022-01-17 05:53:26 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:26 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:26 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:26 --> URI Class Initialized
INFO - 2022-01-17 05:53:26 --> Router Class Initialized
INFO - 2022-01-17 05:53:26 --> Output Class Initialized
INFO - 2022-01-17 05:53:26 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:26 --> Input Class Initialized
INFO - 2022-01-17 05:53:26 --> Language Class Initialized
INFO - 2022-01-17 05:53:26 --> Language Class Initialized
INFO - 2022-01-17 05:53:26 --> Config Class Initialized
INFO - 2022-01-17 05:53:26 --> Loader Class Initialized
INFO - 2022-01-17 05:53:26 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:26 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:26 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:26 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:26 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:26 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:26 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:26 --> Total execution time: 0.0620
INFO - 2022-01-17 05:53:28 --> Config Class Initialized
INFO - 2022-01-17 05:53:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:28 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:28 --> URI Class Initialized
INFO - 2022-01-17 05:53:28 --> Router Class Initialized
INFO - 2022-01-17 05:53:28 --> Output Class Initialized
INFO - 2022-01-17 05:53:28 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:28 --> Input Class Initialized
INFO - 2022-01-17 05:53:28 --> Language Class Initialized
INFO - 2022-01-17 05:53:28 --> Language Class Initialized
INFO - 2022-01-17 05:53:28 --> Config Class Initialized
INFO - 2022-01-17 05:53:28 --> Loader Class Initialized
INFO - 2022-01-17 05:53:28 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:28 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:28 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:28 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:28 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:28 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:28 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:28 --> Total execution time: 0.0570
INFO - 2022-01-17 05:53:30 --> Config Class Initialized
INFO - 2022-01-17 05:53:30 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:30 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:30 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:30 --> URI Class Initialized
INFO - 2022-01-17 05:53:30 --> Router Class Initialized
INFO - 2022-01-17 05:53:30 --> Output Class Initialized
INFO - 2022-01-17 05:53:30 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:30 --> Input Class Initialized
INFO - 2022-01-17 05:53:30 --> Language Class Initialized
INFO - 2022-01-17 05:53:30 --> Language Class Initialized
INFO - 2022-01-17 05:53:30 --> Config Class Initialized
INFO - 2022-01-17 05:53:30 --> Loader Class Initialized
INFO - 2022-01-17 05:53:30 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:30 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:30 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:30 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:30 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:30 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:30 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:30 --> Total execution time: 0.0620
INFO - 2022-01-17 05:53:32 --> Config Class Initialized
INFO - 2022-01-17 05:53:32 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:32 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:32 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:32 --> URI Class Initialized
INFO - 2022-01-17 05:53:32 --> Router Class Initialized
INFO - 2022-01-17 05:53:32 --> Output Class Initialized
INFO - 2022-01-17 05:53:32 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:32 --> Input Class Initialized
INFO - 2022-01-17 05:53:32 --> Language Class Initialized
INFO - 2022-01-17 05:53:32 --> Language Class Initialized
INFO - 2022-01-17 05:53:32 --> Config Class Initialized
INFO - 2022-01-17 05:53:32 --> Loader Class Initialized
INFO - 2022-01-17 05:53:32 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:32 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:32 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:32 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:32 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:32 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:32 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:32 --> Total execution time: 0.0750
INFO - 2022-01-17 05:53:33 --> Config Class Initialized
INFO - 2022-01-17 05:53:33 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:33 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:33 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:33 --> URI Class Initialized
INFO - 2022-01-17 05:53:33 --> Router Class Initialized
INFO - 2022-01-17 05:53:33 --> Output Class Initialized
INFO - 2022-01-17 05:53:33 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:33 --> Input Class Initialized
INFO - 2022-01-17 05:53:33 --> Language Class Initialized
INFO - 2022-01-17 05:53:33 --> Language Class Initialized
INFO - 2022-01-17 05:53:33 --> Config Class Initialized
INFO - 2022-01-17 05:53:33 --> Loader Class Initialized
INFO - 2022-01-17 05:53:33 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:33 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:33 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:33 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:33 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:33 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:33 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:33 --> Total execution time: 0.0680
INFO - 2022-01-17 05:53:36 --> Config Class Initialized
INFO - 2022-01-17 05:53:36 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:53:36 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:53:36 --> Utf8 Class Initialized
INFO - 2022-01-17 05:53:36 --> URI Class Initialized
INFO - 2022-01-17 05:53:36 --> Router Class Initialized
INFO - 2022-01-17 05:53:36 --> Output Class Initialized
INFO - 2022-01-17 05:53:36 --> Security Class Initialized
DEBUG - 2022-01-17 05:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:53:36 --> Input Class Initialized
INFO - 2022-01-17 05:53:36 --> Language Class Initialized
INFO - 2022-01-17 05:53:36 --> Language Class Initialized
INFO - 2022-01-17 05:53:36 --> Config Class Initialized
INFO - 2022-01-17 05:53:36 --> Loader Class Initialized
INFO - 2022-01-17 05:53:36 --> Helper loaded: url_helper
INFO - 2022-01-17 05:53:36 --> Helper loaded: file_helper
INFO - 2022-01-17 05:53:36 --> Helper loaded: form_helper
INFO - 2022-01-17 05:53:36 --> Helper loaded: my_helper
INFO - 2022-01-17 05:53:36 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:53:36 --> Controller Class Initialized
DEBUG - 2022-01-17 05:53:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-01-17 05:53:36 --> Final output sent to browser
DEBUG - 2022-01-17 05:53:36 --> Total execution time: 0.0620
INFO - 2022-01-17 05:57:48 --> Config Class Initialized
INFO - 2022-01-17 05:57:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:57:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:57:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:57:48 --> URI Class Initialized
INFO - 2022-01-17 05:57:48 --> Router Class Initialized
INFO - 2022-01-17 05:57:48 --> Output Class Initialized
INFO - 2022-01-17 05:57:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:57:48 --> Input Class Initialized
INFO - 2022-01-17 05:57:48 --> Language Class Initialized
INFO - 2022-01-17 05:57:48 --> Language Class Initialized
INFO - 2022-01-17 05:57:48 --> Config Class Initialized
INFO - 2022-01-17 05:57:48 --> Loader Class Initialized
INFO - 2022-01-17 05:57:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:57:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:57:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:57:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:57:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:57:48 --> Controller Class Initialized
INFO - 2022-01-17 05:57:48 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:57:48 --> Config Class Initialized
INFO - 2022-01-17 05:57:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:57:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:57:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:57:48 --> URI Class Initialized
INFO - 2022-01-17 05:57:48 --> Router Class Initialized
INFO - 2022-01-17 05:57:48 --> Output Class Initialized
INFO - 2022-01-17 05:57:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:57:48 --> Input Class Initialized
INFO - 2022-01-17 05:57:48 --> Language Class Initialized
INFO - 2022-01-17 05:57:48 --> Language Class Initialized
INFO - 2022-01-17 05:57:48 --> Config Class Initialized
INFO - 2022-01-17 05:57:48 --> Loader Class Initialized
INFO - 2022-01-17 05:57:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:57:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:57:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:57:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:57:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:57:48 --> Controller Class Initialized
DEBUG - 2022-01-17 05:57:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:57:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:57:48 --> Final output sent to browser
DEBUG - 2022-01-17 05:57:48 --> Total execution time: 0.0360
INFO - 2022-01-17 05:57:53 --> Config Class Initialized
INFO - 2022-01-17 05:57:53 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:57:53 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:57:53 --> Utf8 Class Initialized
INFO - 2022-01-17 05:57:53 --> URI Class Initialized
INFO - 2022-01-17 05:57:53 --> Router Class Initialized
INFO - 2022-01-17 05:57:53 --> Output Class Initialized
INFO - 2022-01-17 05:57:53 --> Security Class Initialized
DEBUG - 2022-01-17 05:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:57:53 --> Input Class Initialized
INFO - 2022-01-17 05:57:53 --> Language Class Initialized
INFO - 2022-01-17 05:57:53 --> Language Class Initialized
INFO - 2022-01-17 05:57:53 --> Config Class Initialized
INFO - 2022-01-17 05:57:53 --> Loader Class Initialized
INFO - 2022-01-17 05:57:53 --> Helper loaded: url_helper
INFO - 2022-01-17 05:57:53 --> Helper loaded: file_helper
INFO - 2022-01-17 05:57:53 --> Helper loaded: form_helper
INFO - 2022-01-17 05:57:53 --> Helper loaded: my_helper
INFO - 2022-01-17 05:57:53 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:57:53 --> Controller Class Initialized
INFO - 2022-01-17 05:57:53 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:57:53 --> Final output sent to browser
DEBUG - 2022-01-17 05:57:53 --> Total execution time: 0.0450
INFO - 2022-01-17 05:57:53 --> Config Class Initialized
INFO - 2022-01-17 05:57:53 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:57:53 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:57:53 --> Utf8 Class Initialized
INFO - 2022-01-17 05:57:53 --> URI Class Initialized
INFO - 2022-01-17 05:57:53 --> Router Class Initialized
INFO - 2022-01-17 05:57:53 --> Output Class Initialized
INFO - 2022-01-17 05:57:53 --> Security Class Initialized
DEBUG - 2022-01-17 05:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:57:53 --> Input Class Initialized
INFO - 2022-01-17 05:57:53 --> Language Class Initialized
INFO - 2022-01-17 05:57:53 --> Language Class Initialized
INFO - 2022-01-17 05:57:53 --> Config Class Initialized
INFO - 2022-01-17 05:57:53 --> Loader Class Initialized
INFO - 2022-01-17 05:57:53 --> Helper loaded: url_helper
INFO - 2022-01-17 05:57:53 --> Helper loaded: file_helper
INFO - 2022-01-17 05:57:53 --> Helper loaded: form_helper
INFO - 2022-01-17 05:57:53 --> Helper loaded: my_helper
INFO - 2022-01-17 05:57:53 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:57:53 --> Controller Class Initialized
DEBUG - 2022-01-17 05:57:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:57:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:57:54 --> Final output sent to browser
DEBUG - 2022-01-17 05:57:54 --> Total execution time: 0.3820
INFO - 2022-01-17 05:57:57 --> Config Class Initialized
INFO - 2022-01-17 05:57:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:57:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:57:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:57:57 --> URI Class Initialized
INFO - 2022-01-17 05:57:57 --> Router Class Initialized
INFO - 2022-01-17 05:57:57 --> Output Class Initialized
INFO - 2022-01-17 05:57:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:57:57 --> Input Class Initialized
INFO - 2022-01-17 05:57:57 --> Language Class Initialized
INFO - 2022-01-17 05:57:57 --> Language Class Initialized
INFO - 2022-01-17 05:57:57 --> Config Class Initialized
INFO - 2022-01-17 05:57:57 --> Loader Class Initialized
INFO - 2022-01-17 05:57:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:57:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:57:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:57:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:57:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:57:57 --> Controller Class Initialized
DEBUG - 2022-01-17 05:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-01-17 05:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:57:57 --> Final output sent to browser
DEBUG - 2022-01-17 05:57:57 --> Total execution time: 0.0430
INFO - 2022-01-17 05:57:57 --> Config Class Initialized
INFO - 2022-01-17 05:57:57 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:57:57 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:57:57 --> Utf8 Class Initialized
INFO - 2022-01-17 05:57:57 --> URI Class Initialized
INFO - 2022-01-17 05:57:57 --> Router Class Initialized
INFO - 2022-01-17 05:57:57 --> Output Class Initialized
INFO - 2022-01-17 05:57:57 --> Security Class Initialized
DEBUG - 2022-01-17 05:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:57:57 --> Input Class Initialized
INFO - 2022-01-17 05:57:57 --> Language Class Initialized
INFO - 2022-01-17 05:57:57 --> Language Class Initialized
INFO - 2022-01-17 05:57:57 --> Config Class Initialized
INFO - 2022-01-17 05:57:57 --> Loader Class Initialized
INFO - 2022-01-17 05:57:57 --> Helper loaded: url_helper
INFO - 2022-01-17 05:57:57 --> Helper loaded: file_helper
INFO - 2022-01-17 05:57:57 --> Helper loaded: form_helper
INFO - 2022-01-17 05:57:57 --> Helper loaded: my_helper
INFO - 2022-01-17 05:57:57 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:57:57 --> Controller Class Initialized
INFO - 2022-01-17 05:57:58 --> Config Class Initialized
INFO - 2022-01-17 05:57:58 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:57:58 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:57:58 --> Utf8 Class Initialized
INFO - 2022-01-17 05:57:58 --> URI Class Initialized
INFO - 2022-01-17 05:57:58 --> Router Class Initialized
INFO - 2022-01-17 05:57:58 --> Output Class Initialized
INFO - 2022-01-17 05:57:58 --> Security Class Initialized
DEBUG - 2022-01-17 05:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:57:58 --> Input Class Initialized
INFO - 2022-01-17 05:57:58 --> Language Class Initialized
INFO - 2022-01-17 05:57:58 --> Language Class Initialized
INFO - 2022-01-17 05:57:58 --> Config Class Initialized
INFO - 2022-01-17 05:57:58 --> Loader Class Initialized
INFO - 2022-01-17 05:57:58 --> Helper loaded: url_helper
INFO - 2022-01-17 05:57:58 --> Helper loaded: file_helper
INFO - 2022-01-17 05:57:58 --> Helper loaded: form_helper
INFO - 2022-01-17 05:57:58 --> Helper loaded: my_helper
INFO - 2022-01-17 05:57:58 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:57:58 --> Controller Class Initialized
INFO - 2022-01-17 05:57:58 --> Final output sent to browser
DEBUG - 2022-01-17 05:57:58 --> Total execution time: 0.0510
INFO - 2022-01-17 05:57:58 --> Config Class Initialized
INFO - 2022-01-17 05:57:58 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:57:58 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:57:58 --> Utf8 Class Initialized
INFO - 2022-01-17 05:57:58 --> URI Class Initialized
INFO - 2022-01-17 05:57:58 --> Router Class Initialized
INFO - 2022-01-17 05:57:58 --> Output Class Initialized
INFO - 2022-01-17 05:57:58 --> Security Class Initialized
DEBUG - 2022-01-17 05:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:57:58 --> Input Class Initialized
INFO - 2022-01-17 05:57:58 --> Language Class Initialized
INFO - 2022-01-17 05:57:58 --> Language Class Initialized
INFO - 2022-01-17 05:57:58 --> Config Class Initialized
INFO - 2022-01-17 05:57:58 --> Loader Class Initialized
INFO - 2022-01-17 05:57:58 --> Helper loaded: url_helper
INFO - 2022-01-17 05:57:58 --> Helper loaded: file_helper
INFO - 2022-01-17 05:57:58 --> Helper loaded: form_helper
INFO - 2022-01-17 05:57:58 --> Helper loaded: my_helper
INFO - 2022-01-17 05:57:58 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:57:58 --> Controller Class Initialized
INFO - 2022-01-17 05:58:03 --> Config Class Initialized
INFO - 2022-01-17 05:58:03 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:58:03 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:58:03 --> Utf8 Class Initialized
INFO - 2022-01-17 05:58:03 --> URI Class Initialized
INFO - 2022-01-17 05:58:03 --> Router Class Initialized
INFO - 2022-01-17 05:58:03 --> Output Class Initialized
INFO - 2022-01-17 05:58:03 --> Security Class Initialized
DEBUG - 2022-01-17 05:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:58:03 --> Input Class Initialized
INFO - 2022-01-17 05:58:03 --> Language Class Initialized
INFO - 2022-01-17 05:58:03 --> Language Class Initialized
INFO - 2022-01-17 05:58:03 --> Config Class Initialized
INFO - 2022-01-17 05:58:03 --> Loader Class Initialized
INFO - 2022-01-17 05:58:03 --> Helper loaded: url_helper
INFO - 2022-01-17 05:58:03 --> Helper loaded: file_helper
INFO - 2022-01-17 05:58:03 --> Helper loaded: form_helper
INFO - 2022-01-17 05:58:03 --> Helper loaded: my_helper
INFO - 2022-01-17 05:58:03 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:58:03 --> Controller Class Initialized
INFO - 2022-01-17 05:58:03 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:58:03 --> Config Class Initialized
INFO - 2022-01-17 05:58:03 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:58:03 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:58:03 --> Utf8 Class Initialized
INFO - 2022-01-17 05:58:03 --> URI Class Initialized
INFO - 2022-01-17 05:58:03 --> Router Class Initialized
INFO - 2022-01-17 05:58:03 --> Output Class Initialized
INFO - 2022-01-17 05:58:03 --> Security Class Initialized
DEBUG - 2022-01-17 05:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:58:03 --> Input Class Initialized
INFO - 2022-01-17 05:58:03 --> Language Class Initialized
INFO - 2022-01-17 05:58:03 --> Language Class Initialized
INFO - 2022-01-17 05:58:03 --> Config Class Initialized
INFO - 2022-01-17 05:58:03 --> Loader Class Initialized
INFO - 2022-01-17 05:58:03 --> Helper loaded: url_helper
INFO - 2022-01-17 05:58:03 --> Helper loaded: file_helper
INFO - 2022-01-17 05:58:03 --> Helper loaded: form_helper
INFO - 2022-01-17 05:58:03 --> Helper loaded: my_helper
INFO - 2022-01-17 05:58:03 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:58:03 --> Controller Class Initialized
DEBUG - 2022-01-17 05:58:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-01-17 05:58:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:58:03 --> Final output sent to browser
DEBUG - 2022-01-17 05:58:03 --> Total execution time: 0.0390
INFO - 2022-01-17 05:58:08 --> Config Class Initialized
INFO - 2022-01-17 05:58:08 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:58:08 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:58:08 --> Utf8 Class Initialized
INFO - 2022-01-17 05:58:08 --> URI Class Initialized
INFO - 2022-01-17 05:58:08 --> Router Class Initialized
INFO - 2022-01-17 05:58:08 --> Output Class Initialized
INFO - 2022-01-17 05:58:08 --> Security Class Initialized
DEBUG - 2022-01-17 05:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:58:08 --> Input Class Initialized
INFO - 2022-01-17 05:58:08 --> Language Class Initialized
INFO - 2022-01-17 05:58:08 --> Language Class Initialized
INFO - 2022-01-17 05:58:08 --> Config Class Initialized
INFO - 2022-01-17 05:58:08 --> Loader Class Initialized
INFO - 2022-01-17 05:58:08 --> Helper loaded: url_helper
INFO - 2022-01-17 05:58:08 --> Helper loaded: file_helper
INFO - 2022-01-17 05:58:08 --> Helper loaded: form_helper
INFO - 2022-01-17 05:58:08 --> Helper loaded: my_helper
INFO - 2022-01-17 05:58:08 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:58:08 --> Controller Class Initialized
INFO - 2022-01-17 05:58:08 --> Helper loaded: cookie_helper
INFO - 2022-01-17 05:58:08 --> Final output sent to browser
DEBUG - 2022-01-17 05:58:08 --> Total execution time: 0.0570
INFO - 2022-01-17 05:58:08 --> Config Class Initialized
INFO - 2022-01-17 05:58:08 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:58:08 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:58:08 --> Utf8 Class Initialized
INFO - 2022-01-17 05:58:08 --> URI Class Initialized
INFO - 2022-01-17 05:58:08 --> Router Class Initialized
INFO - 2022-01-17 05:58:08 --> Output Class Initialized
INFO - 2022-01-17 05:58:08 --> Security Class Initialized
DEBUG - 2022-01-17 05:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:58:08 --> Input Class Initialized
INFO - 2022-01-17 05:58:08 --> Language Class Initialized
INFO - 2022-01-17 05:58:08 --> Language Class Initialized
INFO - 2022-01-17 05:58:08 --> Config Class Initialized
INFO - 2022-01-17 05:58:08 --> Loader Class Initialized
INFO - 2022-01-17 05:58:08 --> Helper loaded: url_helper
INFO - 2022-01-17 05:58:08 --> Helper loaded: file_helper
INFO - 2022-01-17 05:58:08 --> Helper loaded: form_helper
INFO - 2022-01-17 05:58:08 --> Helper loaded: my_helper
INFO - 2022-01-17 05:58:08 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:58:08 --> Controller Class Initialized
DEBUG - 2022-01-17 05:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-01-17 05:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:58:09 --> Final output sent to browser
DEBUG - 2022-01-17 05:58:09 --> Total execution time: 0.8300
INFO - 2022-01-17 05:58:40 --> Config Class Initialized
INFO - 2022-01-17 05:58:40 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:58:40 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:58:40 --> Utf8 Class Initialized
INFO - 2022-01-17 05:58:40 --> URI Class Initialized
INFO - 2022-01-17 05:58:40 --> Router Class Initialized
INFO - 2022-01-17 05:58:40 --> Output Class Initialized
INFO - 2022-01-17 05:58:40 --> Security Class Initialized
DEBUG - 2022-01-17 05:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:58:40 --> Input Class Initialized
INFO - 2022-01-17 05:58:40 --> Language Class Initialized
INFO - 2022-01-17 05:58:40 --> Language Class Initialized
INFO - 2022-01-17 05:58:40 --> Config Class Initialized
INFO - 2022-01-17 05:58:40 --> Loader Class Initialized
INFO - 2022-01-17 05:58:40 --> Helper loaded: url_helper
INFO - 2022-01-17 05:58:40 --> Helper loaded: file_helper
INFO - 2022-01-17 05:58:40 --> Helper loaded: form_helper
INFO - 2022-01-17 05:58:40 --> Helper loaded: my_helper
INFO - 2022-01-17 05:58:40 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:58:40 --> Controller Class Initialized
DEBUG - 2022-01-17 05:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-17 05:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:58:40 --> Final output sent to browser
DEBUG - 2022-01-17 05:58:40 --> Total execution time: 0.0620
INFO - 2022-01-17 05:58:46 --> Config Class Initialized
INFO - 2022-01-17 05:58:46 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:58:46 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:58:46 --> Utf8 Class Initialized
INFO - 2022-01-17 05:58:46 --> URI Class Initialized
INFO - 2022-01-17 05:58:46 --> Router Class Initialized
INFO - 2022-01-17 05:58:46 --> Output Class Initialized
INFO - 2022-01-17 05:58:46 --> Security Class Initialized
DEBUG - 2022-01-17 05:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:58:46 --> Input Class Initialized
INFO - 2022-01-17 05:58:46 --> Language Class Initialized
INFO - 2022-01-17 05:58:46 --> Language Class Initialized
INFO - 2022-01-17 05:58:46 --> Config Class Initialized
INFO - 2022-01-17 05:58:46 --> Loader Class Initialized
INFO - 2022-01-17 05:58:46 --> Helper loaded: url_helper
INFO - 2022-01-17 05:58:46 --> Helper loaded: file_helper
INFO - 2022-01-17 05:58:46 --> Helper loaded: form_helper
INFO - 2022-01-17 05:58:46 --> Helper loaded: my_helper
INFO - 2022-01-17 05:58:46 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:58:46 --> Controller Class Initialized
DEBUG - 2022-01-17 05:58:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-01-17 05:58:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:58:46 --> Final output sent to browser
DEBUG - 2022-01-17 05:58:46 --> Total execution time: 0.0610
INFO - 2022-01-17 05:58:48 --> Config Class Initialized
INFO - 2022-01-17 05:58:48 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:58:48 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:58:48 --> Utf8 Class Initialized
INFO - 2022-01-17 05:58:48 --> URI Class Initialized
INFO - 2022-01-17 05:58:48 --> Router Class Initialized
INFO - 2022-01-17 05:58:48 --> Output Class Initialized
INFO - 2022-01-17 05:58:48 --> Security Class Initialized
DEBUG - 2022-01-17 05:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:58:48 --> Input Class Initialized
INFO - 2022-01-17 05:58:48 --> Language Class Initialized
INFO - 2022-01-17 05:58:48 --> Language Class Initialized
INFO - 2022-01-17 05:58:48 --> Config Class Initialized
INFO - 2022-01-17 05:58:48 --> Loader Class Initialized
INFO - 2022-01-17 05:58:48 --> Helper loaded: url_helper
INFO - 2022-01-17 05:58:48 --> Helper loaded: file_helper
INFO - 2022-01-17 05:58:48 --> Helper loaded: form_helper
INFO - 2022-01-17 05:58:48 --> Helper loaded: my_helper
INFO - 2022-01-17 05:58:48 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:58:48 --> Controller Class Initialized
DEBUG - 2022-01-17 05:58:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:58:48 --> Final output sent to browser
DEBUG - 2022-01-17 05:58:48 --> Total execution time: 0.2480
INFO - 2022-01-17 05:59:21 --> Config Class Initialized
INFO - 2022-01-17 05:59:21 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:21 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:21 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:21 --> URI Class Initialized
INFO - 2022-01-17 05:59:21 --> Router Class Initialized
INFO - 2022-01-17 05:59:21 --> Output Class Initialized
INFO - 2022-01-17 05:59:21 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:21 --> Input Class Initialized
INFO - 2022-01-17 05:59:21 --> Language Class Initialized
INFO - 2022-01-17 05:59:21 --> Language Class Initialized
INFO - 2022-01-17 05:59:21 --> Config Class Initialized
INFO - 2022-01-17 05:59:21 --> Loader Class Initialized
INFO - 2022-01-17 05:59:21 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:21 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:21 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:21 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:21 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:21 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-01-17 05:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-01-17 05:59:21 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:21 --> Total execution time: 0.0590
INFO - 2022-01-17 05:59:24 --> Config Class Initialized
INFO - 2022-01-17 05:59:24 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:24 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:24 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:24 --> URI Class Initialized
INFO - 2022-01-17 05:59:24 --> Router Class Initialized
INFO - 2022-01-17 05:59:24 --> Output Class Initialized
INFO - 2022-01-17 05:59:24 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:24 --> Input Class Initialized
INFO - 2022-01-17 05:59:24 --> Language Class Initialized
INFO - 2022-01-17 05:59:24 --> Language Class Initialized
INFO - 2022-01-17 05:59:24 --> Config Class Initialized
INFO - 2022-01-17 05:59:24 --> Loader Class Initialized
INFO - 2022-01-17 05:59:24 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:24 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:24 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:24 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:24 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:24 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:24 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:24 --> Total execution time: 0.1520
INFO - 2022-01-17 05:59:26 --> Config Class Initialized
INFO - 2022-01-17 05:59:26 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:26 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:26 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:26 --> URI Class Initialized
INFO - 2022-01-17 05:59:26 --> Router Class Initialized
INFO - 2022-01-17 05:59:26 --> Output Class Initialized
INFO - 2022-01-17 05:59:26 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:26 --> Input Class Initialized
INFO - 2022-01-17 05:59:26 --> Language Class Initialized
INFO - 2022-01-17 05:59:26 --> Language Class Initialized
INFO - 2022-01-17 05:59:26 --> Config Class Initialized
INFO - 2022-01-17 05:59:26 --> Loader Class Initialized
INFO - 2022-01-17 05:59:26 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:26 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:26 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:26 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:26 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:26 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:26 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:26 --> Total execution time: 0.1950
INFO - 2022-01-17 05:59:28 --> Config Class Initialized
INFO - 2022-01-17 05:59:28 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:28 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:28 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:28 --> URI Class Initialized
INFO - 2022-01-17 05:59:28 --> Router Class Initialized
INFO - 2022-01-17 05:59:28 --> Output Class Initialized
INFO - 2022-01-17 05:59:28 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:28 --> Input Class Initialized
INFO - 2022-01-17 05:59:28 --> Language Class Initialized
INFO - 2022-01-17 05:59:28 --> Language Class Initialized
INFO - 2022-01-17 05:59:28 --> Config Class Initialized
INFO - 2022-01-17 05:59:28 --> Loader Class Initialized
INFO - 2022-01-17 05:59:28 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:28 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:28 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:28 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:28 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:28 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:28 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:28 --> Total execution time: 0.1480
INFO - 2022-01-17 05:59:31 --> Config Class Initialized
INFO - 2022-01-17 05:59:31 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:31 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:31 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:31 --> URI Class Initialized
INFO - 2022-01-17 05:59:31 --> Router Class Initialized
INFO - 2022-01-17 05:59:31 --> Output Class Initialized
INFO - 2022-01-17 05:59:31 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:31 --> Input Class Initialized
INFO - 2022-01-17 05:59:31 --> Language Class Initialized
INFO - 2022-01-17 05:59:31 --> Language Class Initialized
INFO - 2022-01-17 05:59:31 --> Config Class Initialized
INFO - 2022-01-17 05:59:31 --> Loader Class Initialized
INFO - 2022-01-17 05:59:31 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:31 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:31 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:31 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:31 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:31 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:31 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:31 --> Total execution time: 0.1390
INFO - 2022-01-17 05:59:32 --> Config Class Initialized
INFO - 2022-01-17 05:59:32 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:32 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:32 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:32 --> URI Class Initialized
INFO - 2022-01-17 05:59:32 --> Router Class Initialized
INFO - 2022-01-17 05:59:32 --> Output Class Initialized
INFO - 2022-01-17 05:59:32 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:32 --> Input Class Initialized
INFO - 2022-01-17 05:59:32 --> Language Class Initialized
INFO - 2022-01-17 05:59:32 --> Language Class Initialized
INFO - 2022-01-17 05:59:32 --> Config Class Initialized
INFO - 2022-01-17 05:59:32 --> Loader Class Initialized
INFO - 2022-01-17 05:59:32 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:32 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:32 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:32 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:32 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:32 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:32 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:32 --> Total execution time: 0.1240
INFO - 2022-01-17 05:59:34 --> Config Class Initialized
INFO - 2022-01-17 05:59:34 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:34 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:34 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:34 --> URI Class Initialized
INFO - 2022-01-17 05:59:34 --> Router Class Initialized
INFO - 2022-01-17 05:59:34 --> Output Class Initialized
INFO - 2022-01-17 05:59:34 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:34 --> Input Class Initialized
INFO - 2022-01-17 05:59:34 --> Language Class Initialized
INFO - 2022-01-17 05:59:34 --> Language Class Initialized
INFO - 2022-01-17 05:59:34 --> Config Class Initialized
INFO - 2022-01-17 05:59:34 --> Loader Class Initialized
INFO - 2022-01-17 05:59:34 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:34 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:34 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:34 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:34 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:34 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:34 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:34 --> Total execution time: 0.1420
INFO - 2022-01-17 05:59:37 --> Config Class Initialized
INFO - 2022-01-17 05:59:37 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:37 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:37 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:37 --> URI Class Initialized
INFO - 2022-01-17 05:59:37 --> Router Class Initialized
INFO - 2022-01-17 05:59:37 --> Output Class Initialized
INFO - 2022-01-17 05:59:37 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:37 --> Input Class Initialized
INFO - 2022-01-17 05:59:37 --> Language Class Initialized
INFO - 2022-01-17 05:59:37 --> Language Class Initialized
INFO - 2022-01-17 05:59:37 --> Config Class Initialized
INFO - 2022-01-17 05:59:37 --> Loader Class Initialized
INFO - 2022-01-17 05:59:37 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:37 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:37 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:37 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:37 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:37 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:37 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:37 --> Total execution time: 0.1340
INFO - 2022-01-17 05:59:39 --> Config Class Initialized
INFO - 2022-01-17 05:59:39 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:39 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:39 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:39 --> URI Class Initialized
INFO - 2022-01-17 05:59:39 --> Router Class Initialized
INFO - 2022-01-17 05:59:39 --> Output Class Initialized
INFO - 2022-01-17 05:59:39 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:39 --> Input Class Initialized
INFO - 2022-01-17 05:59:39 --> Language Class Initialized
INFO - 2022-01-17 05:59:39 --> Language Class Initialized
INFO - 2022-01-17 05:59:39 --> Config Class Initialized
INFO - 2022-01-17 05:59:39 --> Loader Class Initialized
INFO - 2022-01-17 05:59:39 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:39 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:39 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:39 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:39 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:39 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:39 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:39 --> Total execution time: 0.1600
INFO - 2022-01-17 05:59:42 --> Config Class Initialized
INFO - 2022-01-17 05:59:42 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:42 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:42 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:42 --> URI Class Initialized
INFO - 2022-01-17 05:59:42 --> Router Class Initialized
INFO - 2022-01-17 05:59:42 --> Output Class Initialized
INFO - 2022-01-17 05:59:42 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:42 --> Input Class Initialized
INFO - 2022-01-17 05:59:42 --> Language Class Initialized
INFO - 2022-01-17 05:59:42 --> Language Class Initialized
INFO - 2022-01-17 05:59:42 --> Config Class Initialized
INFO - 2022-01-17 05:59:42 --> Loader Class Initialized
INFO - 2022-01-17 05:59:42 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:42 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:42 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:42 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:42 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:42 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:42 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:42 --> Total execution time: 0.2080
INFO - 2022-01-17 05:59:45 --> Config Class Initialized
INFO - 2022-01-17 05:59:45 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:45 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:45 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:45 --> URI Class Initialized
INFO - 2022-01-17 05:59:45 --> Router Class Initialized
INFO - 2022-01-17 05:59:45 --> Output Class Initialized
INFO - 2022-01-17 05:59:45 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:45 --> Input Class Initialized
INFO - 2022-01-17 05:59:45 --> Language Class Initialized
INFO - 2022-01-17 05:59:45 --> Language Class Initialized
INFO - 2022-01-17 05:59:45 --> Config Class Initialized
INFO - 2022-01-17 05:59:45 --> Loader Class Initialized
INFO - 2022-01-17 05:59:45 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:45 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:45 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:45 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:45 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:45 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:45 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:45 --> Total execution time: 0.1450
INFO - 2022-01-17 05:59:47 --> Config Class Initialized
INFO - 2022-01-17 05:59:47 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:47 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:47 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:47 --> URI Class Initialized
INFO - 2022-01-17 05:59:47 --> Router Class Initialized
INFO - 2022-01-17 05:59:47 --> Output Class Initialized
INFO - 2022-01-17 05:59:47 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:47 --> Input Class Initialized
INFO - 2022-01-17 05:59:47 --> Language Class Initialized
INFO - 2022-01-17 05:59:47 --> Language Class Initialized
INFO - 2022-01-17 05:59:47 --> Config Class Initialized
INFO - 2022-01-17 05:59:47 --> Loader Class Initialized
INFO - 2022-01-17 05:59:47 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:47 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:47 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:47 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:47 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:47 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:47 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:47 --> Total execution time: 0.1380
INFO - 2022-01-17 05:59:50 --> Config Class Initialized
INFO - 2022-01-17 05:59:50 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:50 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:50 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:50 --> URI Class Initialized
INFO - 2022-01-17 05:59:50 --> Router Class Initialized
INFO - 2022-01-17 05:59:50 --> Output Class Initialized
INFO - 2022-01-17 05:59:50 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:50 --> Input Class Initialized
INFO - 2022-01-17 05:59:50 --> Language Class Initialized
INFO - 2022-01-17 05:59:50 --> Language Class Initialized
INFO - 2022-01-17 05:59:50 --> Config Class Initialized
INFO - 2022-01-17 05:59:50 --> Loader Class Initialized
INFO - 2022-01-17 05:59:50 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:50 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:50 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:50 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:50 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:50 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:50 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:50 --> Total execution time: 0.2200
INFO - 2022-01-17 05:59:52 --> Config Class Initialized
INFO - 2022-01-17 05:59:52 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:52 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:52 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:52 --> URI Class Initialized
INFO - 2022-01-17 05:59:52 --> Router Class Initialized
INFO - 2022-01-17 05:59:52 --> Output Class Initialized
INFO - 2022-01-17 05:59:52 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:52 --> Input Class Initialized
INFO - 2022-01-17 05:59:52 --> Language Class Initialized
INFO - 2022-01-17 05:59:52 --> Language Class Initialized
INFO - 2022-01-17 05:59:52 --> Config Class Initialized
INFO - 2022-01-17 05:59:52 --> Loader Class Initialized
INFO - 2022-01-17 05:59:52 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:52 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:52 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:52 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:52 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:52 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:52 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:52 --> Total execution time: 0.1420
INFO - 2022-01-17 05:59:54 --> Config Class Initialized
INFO - 2022-01-17 05:59:54 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:54 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:54 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:54 --> URI Class Initialized
INFO - 2022-01-17 05:59:54 --> Router Class Initialized
INFO - 2022-01-17 05:59:54 --> Output Class Initialized
INFO - 2022-01-17 05:59:54 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:54 --> Input Class Initialized
INFO - 2022-01-17 05:59:54 --> Language Class Initialized
INFO - 2022-01-17 05:59:54 --> Language Class Initialized
INFO - 2022-01-17 05:59:54 --> Config Class Initialized
INFO - 2022-01-17 05:59:54 --> Loader Class Initialized
INFO - 2022-01-17 05:59:54 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:54 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:54 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:54 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:54 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:54 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:54 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:54 --> Total execution time: 0.1380
INFO - 2022-01-17 05:59:56 --> Config Class Initialized
INFO - 2022-01-17 05:59:56 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:56 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:56 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:56 --> URI Class Initialized
INFO - 2022-01-17 05:59:56 --> Router Class Initialized
INFO - 2022-01-17 05:59:56 --> Output Class Initialized
INFO - 2022-01-17 05:59:56 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:56 --> Input Class Initialized
INFO - 2022-01-17 05:59:56 --> Language Class Initialized
INFO - 2022-01-17 05:59:56 --> Language Class Initialized
INFO - 2022-01-17 05:59:56 --> Config Class Initialized
INFO - 2022-01-17 05:59:56 --> Loader Class Initialized
INFO - 2022-01-17 05:59:56 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:56 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:56 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:56 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:56 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:56 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:56 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:56 --> Total execution time: 0.1340
INFO - 2022-01-17 05:59:59 --> Config Class Initialized
INFO - 2022-01-17 05:59:59 --> Hooks Class Initialized
DEBUG - 2022-01-17 05:59:59 --> UTF-8 Support Enabled
INFO - 2022-01-17 05:59:59 --> Utf8 Class Initialized
INFO - 2022-01-17 05:59:59 --> URI Class Initialized
INFO - 2022-01-17 05:59:59 --> Router Class Initialized
INFO - 2022-01-17 05:59:59 --> Output Class Initialized
INFO - 2022-01-17 05:59:59 --> Security Class Initialized
DEBUG - 2022-01-17 05:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 05:59:59 --> Input Class Initialized
INFO - 2022-01-17 05:59:59 --> Language Class Initialized
INFO - 2022-01-17 05:59:59 --> Language Class Initialized
INFO - 2022-01-17 05:59:59 --> Config Class Initialized
INFO - 2022-01-17 05:59:59 --> Loader Class Initialized
INFO - 2022-01-17 05:59:59 --> Helper loaded: url_helper
INFO - 2022-01-17 05:59:59 --> Helper loaded: file_helper
INFO - 2022-01-17 05:59:59 --> Helper loaded: form_helper
INFO - 2022-01-17 05:59:59 --> Helper loaded: my_helper
INFO - 2022-01-17 05:59:59 --> Database Driver Class Initialized
DEBUG - 2022-01-17 05:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 05:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 05:59:59 --> Controller Class Initialized
DEBUG - 2022-01-17 05:59:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 05:59:59 --> Final output sent to browser
DEBUG - 2022-01-17 05:59:59 --> Total execution time: 0.1790
INFO - 2022-01-17 06:00:01 --> Config Class Initialized
INFO - 2022-01-17 06:00:01 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:01 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:01 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:01 --> URI Class Initialized
INFO - 2022-01-17 06:00:01 --> Router Class Initialized
INFO - 2022-01-17 06:00:01 --> Output Class Initialized
INFO - 2022-01-17 06:00:01 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:01 --> Input Class Initialized
INFO - 2022-01-17 06:00:01 --> Language Class Initialized
INFO - 2022-01-17 06:00:01 --> Language Class Initialized
INFO - 2022-01-17 06:00:01 --> Config Class Initialized
INFO - 2022-01-17 06:00:01 --> Loader Class Initialized
INFO - 2022-01-17 06:00:01 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:01 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:01 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:01 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:01 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:01 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:02 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:02 --> Total execution time: 0.1390
INFO - 2022-01-17 06:00:04 --> Config Class Initialized
INFO - 2022-01-17 06:00:04 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:04 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:04 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:04 --> URI Class Initialized
INFO - 2022-01-17 06:00:04 --> Router Class Initialized
INFO - 2022-01-17 06:00:04 --> Output Class Initialized
INFO - 2022-01-17 06:00:04 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:04 --> Input Class Initialized
INFO - 2022-01-17 06:00:04 --> Language Class Initialized
INFO - 2022-01-17 06:00:04 --> Language Class Initialized
INFO - 2022-01-17 06:00:04 --> Config Class Initialized
INFO - 2022-01-17 06:00:04 --> Loader Class Initialized
INFO - 2022-01-17 06:00:04 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:04 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:04 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:04 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:04 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:04 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:04 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:04 --> Total execution time: 0.1810
INFO - 2022-01-17 06:00:07 --> Config Class Initialized
INFO - 2022-01-17 06:00:07 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:07 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:07 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:07 --> URI Class Initialized
INFO - 2022-01-17 06:00:07 --> Router Class Initialized
INFO - 2022-01-17 06:00:07 --> Output Class Initialized
INFO - 2022-01-17 06:00:07 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:07 --> Input Class Initialized
INFO - 2022-01-17 06:00:07 --> Language Class Initialized
INFO - 2022-01-17 06:00:07 --> Language Class Initialized
INFO - 2022-01-17 06:00:07 --> Config Class Initialized
INFO - 2022-01-17 06:00:07 --> Loader Class Initialized
INFO - 2022-01-17 06:00:07 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:07 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:07 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:07 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:07 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:07 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:07 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:07 --> Total execution time: 0.1260
INFO - 2022-01-17 06:00:09 --> Config Class Initialized
INFO - 2022-01-17 06:00:09 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:09 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:09 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:09 --> URI Class Initialized
INFO - 2022-01-17 06:00:09 --> Router Class Initialized
INFO - 2022-01-17 06:00:09 --> Output Class Initialized
INFO - 2022-01-17 06:00:09 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:09 --> Input Class Initialized
INFO - 2022-01-17 06:00:09 --> Language Class Initialized
INFO - 2022-01-17 06:00:09 --> Language Class Initialized
INFO - 2022-01-17 06:00:09 --> Config Class Initialized
INFO - 2022-01-17 06:00:09 --> Loader Class Initialized
INFO - 2022-01-17 06:00:09 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:09 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:09 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:09 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:09 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:09 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:09 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:09 --> Total execution time: 0.1720
INFO - 2022-01-17 06:00:11 --> Config Class Initialized
INFO - 2022-01-17 06:00:11 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:11 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:11 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:11 --> URI Class Initialized
INFO - 2022-01-17 06:00:11 --> Router Class Initialized
INFO - 2022-01-17 06:00:11 --> Output Class Initialized
INFO - 2022-01-17 06:00:11 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:11 --> Input Class Initialized
INFO - 2022-01-17 06:00:11 --> Language Class Initialized
INFO - 2022-01-17 06:00:11 --> Language Class Initialized
INFO - 2022-01-17 06:00:11 --> Config Class Initialized
INFO - 2022-01-17 06:00:11 --> Loader Class Initialized
INFO - 2022-01-17 06:00:11 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:11 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:11 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:11 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:11 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:11 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:11 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:11 --> Total execution time: 0.1420
INFO - 2022-01-17 06:00:14 --> Config Class Initialized
INFO - 2022-01-17 06:00:14 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:14 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:14 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:14 --> URI Class Initialized
INFO - 2022-01-17 06:00:14 --> Router Class Initialized
INFO - 2022-01-17 06:00:14 --> Output Class Initialized
INFO - 2022-01-17 06:00:14 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:14 --> Input Class Initialized
INFO - 2022-01-17 06:00:14 --> Language Class Initialized
INFO - 2022-01-17 06:00:14 --> Language Class Initialized
INFO - 2022-01-17 06:00:14 --> Config Class Initialized
INFO - 2022-01-17 06:00:14 --> Loader Class Initialized
INFO - 2022-01-17 06:00:14 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:14 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:14 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:14 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:14 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:14 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:14 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:14 --> Total execution time: 0.1930
INFO - 2022-01-17 06:00:15 --> Config Class Initialized
INFO - 2022-01-17 06:00:15 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:15 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:15 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:15 --> URI Class Initialized
INFO - 2022-01-17 06:00:15 --> Router Class Initialized
INFO - 2022-01-17 06:00:15 --> Output Class Initialized
INFO - 2022-01-17 06:00:15 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:15 --> Input Class Initialized
INFO - 2022-01-17 06:00:15 --> Language Class Initialized
INFO - 2022-01-17 06:00:15 --> Language Class Initialized
INFO - 2022-01-17 06:00:15 --> Config Class Initialized
INFO - 2022-01-17 06:00:15 --> Loader Class Initialized
INFO - 2022-01-17 06:00:15 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:15 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:15 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:15 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:15 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:15 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:15 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:15 --> Total execution time: 0.1470
INFO - 2022-01-17 06:00:18 --> Config Class Initialized
INFO - 2022-01-17 06:00:18 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:18 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:18 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:18 --> URI Class Initialized
INFO - 2022-01-17 06:00:18 --> Router Class Initialized
INFO - 2022-01-17 06:00:18 --> Output Class Initialized
INFO - 2022-01-17 06:00:18 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:18 --> Input Class Initialized
INFO - 2022-01-17 06:00:18 --> Language Class Initialized
INFO - 2022-01-17 06:00:18 --> Language Class Initialized
INFO - 2022-01-17 06:00:18 --> Config Class Initialized
INFO - 2022-01-17 06:00:18 --> Loader Class Initialized
INFO - 2022-01-17 06:00:18 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:18 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:18 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:18 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:18 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:18 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:18 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:18 --> Total execution time: 0.1510
INFO - 2022-01-17 06:00:21 --> Config Class Initialized
INFO - 2022-01-17 06:00:21 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:21 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:21 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:21 --> URI Class Initialized
INFO - 2022-01-17 06:00:21 --> Router Class Initialized
INFO - 2022-01-17 06:00:21 --> Output Class Initialized
INFO - 2022-01-17 06:00:21 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:21 --> Input Class Initialized
INFO - 2022-01-17 06:00:21 --> Language Class Initialized
INFO - 2022-01-17 06:00:21 --> Language Class Initialized
INFO - 2022-01-17 06:00:21 --> Config Class Initialized
INFO - 2022-01-17 06:00:21 --> Loader Class Initialized
INFO - 2022-01-17 06:00:21 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:21 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:21 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:21 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:21 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:21 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:21 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:21 --> Total execution time: 0.1340
INFO - 2022-01-17 06:00:23 --> Config Class Initialized
INFO - 2022-01-17 06:00:23 --> Hooks Class Initialized
DEBUG - 2022-01-17 06:00:23 --> UTF-8 Support Enabled
INFO - 2022-01-17 06:00:23 --> Utf8 Class Initialized
INFO - 2022-01-17 06:00:23 --> URI Class Initialized
INFO - 2022-01-17 06:00:23 --> Router Class Initialized
INFO - 2022-01-17 06:00:23 --> Output Class Initialized
INFO - 2022-01-17 06:00:23 --> Security Class Initialized
DEBUG - 2022-01-17 06:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-01-17 06:00:23 --> Input Class Initialized
INFO - 2022-01-17 06:00:23 --> Language Class Initialized
INFO - 2022-01-17 06:00:23 --> Language Class Initialized
INFO - 2022-01-17 06:00:23 --> Config Class Initialized
INFO - 2022-01-17 06:00:23 --> Loader Class Initialized
INFO - 2022-01-17 06:00:23 --> Helper loaded: url_helper
INFO - 2022-01-17 06:00:23 --> Helper loaded: file_helper
INFO - 2022-01-17 06:00:23 --> Helper loaded: form_helper
INFO - 2022-01-17 06:00:23 --> Helper loaded: my_helper
INFO - 2022-01-17 06:00:23 --> Database Driver Class Initialized
DEBUG - 2022-01-17 06:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-01-17 06:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-01-17 06:00:23 --> Controller Class Initialized
DEBUG - 2022-01-17 06:00:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-01-17 06:00:24 --> Final output sent to browser
DEBUG - 2022-01-17 06:00:24 --> Total execution time: 0.1240
