<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-29 02:40:55 --> Config Class Initialized
INFO - 2021-06-29 02:40:55 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:40:55 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:40:55 --> Utf8 Class Initialized
INFO - 2021-06-29 02:40:55 --> URI Class Initialized
DEBUG - 2021-06-29 02:40:55 --> No URI present. Default controller set.
INFO - 2021-06-29 02:40:55 --> Router Class Initialized
INFO - 2021-06-29 02:40:55 --> Output Class Initialized
INFO - 2021-06-29 02:40:55 --> Security Class Initialized
DEBUG - 2021-06-29 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:40:56 --> Input Class Initialized
INFO - 2021-06-29 02:40:56 --> Language Class Initialized
INFO - 2021-06-29 02:40:56 --> Language Class Initialized
INFO - 2021-06-29 02:40:56 --> Config Class Initialized
INFO - 2021-06-29 02:40:56 --> Loader Class Initialized
INFO - 2021-06-29 02:40:56 --> Helper loaded: url_helper
INFO - 2021-06-29 02:40:56 --> Helper loaded: file_helper
INFO - 2021-06-29 02:40:56 --> Helper loaded: form_helper
INFO - 2021-06-29 02:40:56 --> Helper loaded: my_helper
INFO - 2021-06-29 02:40:56 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:40:56 --> Controller Class Initialized
INFO - 2021-06-29 02:40:56 --> Config Class Initialized
INFO - 2021-06-29 02:40:56 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:40:56 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:40:56 --> Utf8 Class Initialized
INFO - 2021-06-29 02:40:56 --> URI Class Initialized
INFO - 2021-06-29 02:40:56 --> Router Class Initialized
INFO - 2021-06-29 02:40:56 --> Output Class Initialized
INFO - 2021-06-29 02:40:56 --> Security Class Initialized
DEBUG - 2021-06-29 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:40:56 --> Input Class Initialized
INFO - 2021-06-29 02:40:56 --> Language Class Initialized
INFO - 2021-06-29 02:40:56 --> Language Class Initialized
INFO - 2021-06-29 02:40:56 --> Config Class Initialized
INFO - 2021-06-29 02:40:56 --> Loader Class Initialized
INFO - 2021-06-29 02:40:56 --> Helper loaded: url_helper
INFO - 2021-06-29 02:40:56 --> Helper loaded: file_helper
INFO - 2021-06-29 02:40:56 --> Helper loaded: form_helper
INFO - 2021-06-29 02:40:56 --> Helper loaded: my_helper
INFO - 2021-06-29 02:40:56 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:40:56 --> Controller Class Initialized
DEBUG - 2021-06-29 02:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 02:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 02:40:56 --> Final output sent to browser
DEBUG - 2021-06-29 02:40:56 --> Total execution time: 0.1040
INFO - 2021-06-29 02:41:03 --> Config Class Initialized
INFO - 2021-06-29 02:41:03 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:41:03 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:41:03 --> Utf8 Class Initialized
INFO - 2021-06-29 02:41:03 --> URI Class Initialized
INFO - 2021-06-29 02:41:03 --> Router Class Initialized
INFO - 2021-06-29 02:41:03 --> Output Class Initialized
INFO - 2021-06-29 02:41:03 --> Security Class Initialized
DEBUG - 2021-06-29 02:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:41:03 --> Input Class Initialized
INFO - 2021-06-29 02:41:03 --> Language Class Initialized
INFO - 2021-06-29 02:41:03 --> Language Class Initialized
INFO - 2021-06-29 02:41:03 --> Config Class Initialized
INFO - 2021-06-29 02:41:03 --> Loader Class Initialized
INFO - 2021-06-29 02:41:03 --> Helper loaded: url_helper
INFO - 2021-06-29 02:41:03 --> Helper loaded: file_helper
INFO - 2021-06-29 02:41:03 --> Helper loaded: form_helper
INFO - 2021-06-29 02:41:03 --> Helper loaded: my_helper
INFO - 2021-06-29 02:41:03 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:41:03 --> Controller Class Initialized
INFO - 2021-06-29 02:41:03 --> Helper loaded: cookie_helper
INFO - 2021-06-29 02:41:03 --> Final output sent to browser
DEBUG - 2021-06-29 02:41:03 --> Total execution time: 0.0912
INFO - 2021-06-29 02:41:04 --> Config Class Initialized
INFO - 2021-06-29 02:41:04 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:41:04 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:41:04 --> Utf8 Class Initialized
INFO - 2021-06-29 02:41:04 --> URI Class Initialized
INFO - 2021-06-29 02:41:04 --> Router Class Initialized
INFO - 2021-06-29 02:41:04 --> Output Class Initialized
INFO - 2021-06-29 02:41:04 --> Security Class Initialized
DEBUG - 2021-06-29 02:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:41:04 --> Input Class Initialized
INFO - 2021-06-29 02:41:04 --> Language Class Initialized
INFO - 2021-06-29 02:41:04 --> Language Class Initialized
INFO - 2021-06-29 02:41:04 --> Config Class Initialized
INFO - 2021-06-29 02:41:04 --> Loader Class Initialized
INFO - 2021-06-29 02:41:04 --> Helper loaded: url_helper
INFO - 2021-06-29 02:41:04 --> Helper loaded: file_helper
INFO - 2021-06-29 02:41:04 --> Helper loaded: form_helper
INFO - 2021-06-29 02:41:04 --> Helper loaded: my_helper
INFO - 2021-06-29 02:41:04 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:41:04 --> Controller Class Initialized
DEBUG - 2021-06-29 02:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-29 02:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 02:41:05 --> Final output sent to browser
DEBUG - 2021-06-29 02:41:05 --> Total execution time: 0.7172
INFO - 2021-06-29 02:41:20 --> Config Class Initialized
INFO - 2021-06-29 02:41:20 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:41:20 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:41:20 --> Utf8 Class Initialized
INFO - 2021-06-29 02:41:20 --> URI Class Initialized
INFO - 2021-06-29 02:41:20 --> Router Class Initialized
INFO - 2021-06-29 02:41:20 --> Output Class Initialized
INFO - 2021-06-29 02:41:20 --> Security Class Initialized
DEBUG - 2021-06-29 02:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:41:20 --> Input Class Initialized
INFO - 2021-06-29 02:41:20 --> Language Class Initialized
INFO - 2021-06-29 02:41:20 --> Language Class Initialized
INFO - 2021-06-29 02:41:20 --> Config Class Initialized
INFO - 2021-06-29 02:41:20 --> Loader Class Initialized
INFO - 2021-06-29 02:41:20 --> Helper loaded: url_helper
INFO - 2021-06-29 02:41:20 --> Helper loaded: file_helper
INFO - 2021-06-29 02:41:20 --> Helper loaded: form_helper
INFO - 2021-06-29 02:41:20 --> Helper loaded: my_helper
INFO - 2021-06-29 02:41:20 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:41:20 --> Controller Class Initialized
DEBUG - 2021-06-29 02:41:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-29 02:41:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 02:41:21 --> Final output sent to browser
DEBUG - 2021-06-29 02:41:21 --> Total execution time: 0.1460
INFO - 2021-06-29 02:41:23 --> Config Class Initialized
INFO - 2021-06-29 02:41:23 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:41:23 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:41:23 --> Utf8 Class Initialized
INFO - 2021-06-29 02:41:23 --> URI Class Initialized
INFO - 2021-06-29 02:41:23 --> Router Class Initialized
INFO - 2021-06-29 02:41:23 --> Output Class Initialized
INFO - 2021-06-29 02:41:23 --> Security Class Initialized
DEBUG - 2021-06-29 02:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:41:23 --> Input Class Initialized
INFO - 2021-06-29 02:41:23 --> Language Class Initialized
INFO - 2021-06-29 02:41:23 --> Language Class Initialized
INFO - 2021-06-29 02:41:23 --> Config Class Initialized
INFO - 2021-06-29 02:41:23 --> Loader Class Initialized
INFO - 2021-06-29 02:41:23 --> Helper loaded: url_helper
INFO - 2021-06-29 02:41:23 --> Helper loaded: file_helper
INFO - 2021-06-29 02:41:23 --> Helper loaded: form_helper
INFO - 2021-06-29 02:41:23 --> Helper loaded: my_helper
INFO - 2021-06-29 02:41:23 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:41:23 --> Controller Class Initialized
DEBUG - 2021-06-29 02:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:41:23 --> Final output sent to browser
DEBUG - 2021-06-29 02:41:23 --> Total execution time: 0.0536
INFO - 2021-06-29 02:43:10 --> Config Class Initialized
INFO - 2021-06-29 02:43:10 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:43:10 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:43:10 --> Utf8 Class Initialized
INFO - 2021-06-29 02:43:10 --> URI Class Initialized
INFO - 2021-06-29 02:43:10 --> Router Class Initialized
INFO - 2021-06-29 02:43:10 --> Output Class Initialized
INFO - 2021-06-29 02:43:10 --> Security Class Initialized
DEBUG - 2021-06-29 02:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:43:10 --> Input Class Initialized
INFO - 2021-06-29 02:43:10 --> Language Class Initialized
INFO - 2021-06-29 02:43:10 --> Language Class Initialized
INFO - 2021-06-29 02:43:10 --> Config Class Initialized
INFO - 2021-06-29 02:43:10 --> Loader Class Initialized
INFO - 2021-06-29 02:43:10 --> Helper loaded: url_helper
INFO - 2021-06-29 02:43:10 --> Helper loaded: file_helper
INFO - 2021-06-29 02:43:10 --> Helper loaded: form_helper
INFO - 2021-06-29 02:43:10 --> Helper loaded: my_helper
INFO - 2021-06-29 02:43:10 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:43:10 --> Controller Class Initialized
DEBUG - 2021-06-29 02:43:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:43:10 --> Final output sent to browser
DEBUG - 2021-06-29 02:43:10 --> Total execution time: 0.0570
INFO - 2021-06-29 02:43:57 --> Config Class Initialized
INFO - 2021-06-29 02:43:57 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:43:57 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:43:57 --> Utf8 Class Initialized
INFO - 2021-06-29 02:43:57 --> URI Class Initialized
INFO - 2021-06-29 02:43:57 --> Router Class Initialized
INFO - 2021-06-29 02:43:57 --> Output Class Initialized
INFO - 2021-06-29 02:43:57 --> Security Class Initialized
DEBUG - 2021-06-29 02:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:43:57 --> Input Class Initialized
INFO - 2021-06-29 02:43:57 --> Language Class Initialized
INFO - 2021-06-29 02:43:57 --> Language Class Initialized
INFO - 2021-06-29 02:43:57 --> Config Class Initialized
INFO - 2021-06-29 02:43:57 --> Loader Class Initialized
INFO - 2021-06-29 02:43:57 --> Helper loaded: url_helper
INFO - 2021-06-29 02:43:57 --> Helper loaded: file_helper
INFO - 2021-06-29 02:43:57 --> Helper loaded: form_helper
INFO - 2021-06-29 02:43:57 --> Helper loaded: my_helper
INFO - 2021-06-29 02:43:57 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:43:57 --> Controller Class Initialized
DEBUG - 2021-06-29 02:43:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-06-29 02:43:57 --> Final output sent to browser
DEBUG - 2021-06-29 02:43:57 --> Total execution time: 0.3439
INFO - 2021-06-29 02:48:02 --> Config Class Initialized
INFO - 2021-06-29 02:48:02 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:48:02 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:48:02 --> Utf8 Class Initialized
INFO - 2021-06-29 02:48:02 --> URI Class Initialized
INFO - 2021-06-29 02:48:02 --> Router Class Initialized
INFO - 2021-06-29 02:48:02 --> Output Class Initialized
INFO - 2021-06-29 02:48:02 --> Security Class Initialized
DEBUG - 2021-06-29 02:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:48:02 --> Input Class Initialized
INFO - 2021-06-29 02:48:02 --> Language Class Initialized
INFO - 2021-06-29 02:48:02 --> Language Class Initialized
INFO - 2021-06-29 02:48:02 --> Config Class Initialized
INFO - 2021-06-29 02:48:02 --> Loader Class Initialized
INFO - 2021-06-29 02:48:02 --> Helper loaded: url_helper
INFO - 2021-06-29 02:48:02 --> Helper loaded: file_helper
INFO - 2021-06-29 02:48:02 --> Helper loaded: form_helper
INFO - 2021-06-29 02:48:02 --> Helper loaded: my_helper
INFO - 2021-06-29 02:48:02 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:48:02 --> Controller Class Initialized
DEBUG - 2021-06-29 02:48:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:48:02 --> Final output sent to browser
DEBUG - 2021-06-29 02:48:02 --> Total execution time: 0.0453
INFO - 2021-06-29 02:48:44 --> Config Class Initialized
INFO - 2021-06-29 02:48:44 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:48:44 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:48:44 --> Utf8 Class Initialized
INFO - 2021-06-29 02:48:44 --> URI Class Initialized
INFO - 2021-06-29 02:48:44 --> Router Class Initialized
INFO - 2021-06-29 02:48:44 --> Output Class Initialized
INFO - 2021-06-29 02:48:44 --> Security Class Initialized
DEBUG - 2021-06-29 02:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:48:44 --> Input Class Initialized
INFO - 2021-06-29 02:48:44 --> Language Class Initialized
INFO - 2021-06-29 02:48:44 --> Language Class Initialized
INFO - 2021-06-29 02:48:44 --> Config Class Initialized
INFO - 2021-06-29 02:48:44 --> Loader Class Initialized
INFO - 2021-06-29 02:48:44 --> Helper loaded: url_helper
INFO - 2021-06-29 02:48:44 --> Helper loaded: file_helper
INFO - 2021-06-29 02:48:44 --> Helper loaded: form_helper
INFO - 2021-06-29 02:48:44 --> Helper loaded: my_helper
INFO - 2021-06-29 02:48:44 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:48:44 --> Controller Class Initialized
DEBUG - 2021-06-29 02:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:48:44 --> Final output sent to browser
DEBUG - 2021-06-29 02:48:44 --> Total execution time: 0.0574
INFO - 2021-06-29 02:51:05 --> Config Class Initialized
INFO - 2021-06-29 02:51:05 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:51:05 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:51:05 --> Utf8 Class Initialized
INFO - 2021-06-29 02:51:05 --> URI Class Initialized
INFO - 2021-06-29 02:51:05 --> Router Class Initialized
INFO - 2021-06-29 02:51:05 --> Output Class Initialized
INFO - 2021-06-29 02:51:05 --> Security Class Initialized
DEBUG - 2021-06-29 02:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:51:05 --> Input Class Initialized
INFO - 2021-06-29 02:51:05 --> Language Class Initialized
INFO - 2021-06-29 02:51:05 --> Language Class Initialized
INFO - 2021-06-29 02:51:05 --> Config Class Initialized
INFO - 2021-06-29 02:51:05 --> Loader Class Initialized
INFO - 2021-06-29 02:51:05 --> Helper loaded: url_helper
INFO - 2021-06-29 02:51:05 --> Helper loaded: file_helper
INFO - 2021-06-29 02:51:05 --> Helper loaded: form_helper
INFO - 2021-06-29 02:51:05 --> Helper loaded: my_helper
INFO - 2021-06-29 02:51:05 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:51:05 --> Controller Class Initialized
DEBUG - 2021-06-29 02:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:51:05 --> Final output sent to browser
DEBUG - 2021-06-29 02:51:05 --> Total execution time: 0.0568
INFO - 2021-06-29 02:51:22 --> Config Class Initialized
INFO - 2021-06-29 02:51:22 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:51:22 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:51:22 --> Utf8 Class Initialized
INFO - 2021-06-29 02:51:22 --> URI Class Initialized
INFO - 2021-06-29 02:51:22 --> Router Class Initialized
INFO - 2021-06-29 02:51:22 --> Output Class Initialized
INFO - 2021-06-29 02:51:22 --> Security Class Initialized
DEBUG - 2021-06-29 02:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:51:22 --> Input Class Initialized
INFO - 2021-06-29 02:51:22 --> Language Class Initialized
INFO - 2021-06-29 02:51:22 --> Language Class Initialized
INFO - 2021-06-29 02:51:22 --> Config Class Initialized
INFO - 2021-06-29 02:51:22 --> Loader Class Initialized
INFO - 2021-06-29 02:51:22 --> Helper loaded: url_helper
INFO - 2021-06-29 02:51:22 --> Helper loaded: file_helper
INFO - 2021-06-29 02:51:22 --> Helper loaded: form_helper
INFO - 2021-06-29 02:51:22 --> Helper loaded: my_helper
INFO - 2021-06-29 02:51:22 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:51:22 --> Controller Class Initialized
DEBUG - 2021-06-29 02:51:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:51:22 --> Final output sent to browser
DEBUG - 2021-06-29 02:51:22 --> Total execution time: 0.0546
INFO - 2021-06-29 02:52:05 --> Config Class Initialized
INFO - 2021-06-29 02:52:05 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:52:05 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:52:05 --> Utf8 Class Initialized
INFO - 2021-06-29 02:52:05 --> URI Class Initialized
INFO - 2021-06-29 02:52:05 --> Router Class Initialized
INFO - 2021-06-29 02:52:05 --> Output Class Initialized
INFO - 2021-06-29 02:52:05 --> Security Class Initialized
DEBUG - 2021-06-29 02:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:52:05 --> Input Class Initialized
INFO - 2021-06-29 02:52:05 --> Language Class Initialized
INFO - 2021-06-29 02:52:05 --> Language Class Initialized
INFO - 2021-06-29 02:52:05 --> Config Class Initialized
INFO - 2021-06-29 02:52:05 --> Loader Class Initialized
INFO - 2021-06-29 02:52:05 --> Helper loaded: url_helper
INFO - 2021-06-29 02:52:05 --> Helper loaded: file_helper
INFO - 2021-06-29 02:52:05 --> Helper loaded: form_helper
INFO - 2021-06-29 02:52:05 --> Helper loaded: my_helper
INFO - 2021-06-29 02:52:05 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:52:05 --> Controller Class Initialized
DEBUG - 2021-06-29 02:52:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:52:05 --> Final output sent to browser
DEBUG - 2021-06-29 02:52:05 --> Total execution time: 0.0557
INFO - 2021-06-29 02:52:58 --> Config Class Initialized
INFO - 2021-06-29 02:52:58 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:52:58 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:52:58 --> Utf8 Class Initialized
INFO - 2021-06-29 02:52:58 --> URI Class Initialized
INFO - 2021-06-29 02:52:58 --> Router Class Initialized
INFO - 2021-06-29 02:52:58 --> Output Class Initialized
INFO - 2021-06-29 02:52:58 --> Security Class Initialized
DEBUG - 2021-06-29 02:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:52:58 --> Input Class Initialized
INFO - 2021-06-29 02:52:58 --> Language Class Initialized
INFO - 2021-06-29 02:52:58 --> Language Class Initialized
INFO - 2021-06-29 02:52:58 --> Config Class Initialized
INFO - 2021-06-29 02:52:58 --> Loader Class Initialized
INFO - 2021-06-29 02:52:58 --> Helper loaded: url_helper
INFO - 2021-06-29 02:52:58 --> Helper loaded: file_helper
INFO - 2021-06-29 02:52:58 --> Helper loaded: form_helper
INFO - 2021-06-29 02:52:58 --> Helper loaded: my_helper
INFO - 2021-06-29 02:52:58 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:52:58 --> Controller Class Initialized
DEBUG - 2021-06-29 02:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:52:58 --> Final output sent to browser
DEBUG - 2021-06-29 02:52:58 --> Total execution time: 0.0444
INFO - 2021-06-29 02:53:14 --> Config Class Initialized
INFO - 2021-06-29 02:53:14 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:53:14 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:53:14 --> Utf8 Class Initialized
INFO - 2021-06-29 02:53:14 --> URI Class Initialized
INFO - 2021-06-29 02:53:14 --> Router Class Initialized
INFO - 2021-06-29 02:53:14 --> Output Class Initialized
INFO - 2021-06-29 02:53:14 --> Security Class Initialized
DEBUG - 2021-06-29 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:53:14 --> Input Class Initialized
INFO - 2021-06-29 02:53:14 --> Language Class Initialized
INFO - 2021-06-29 02:53:14 --> Language Class Initialized
INFO - 2021-06-29 02:53:14 --> Config Class Initialized
INFO - 2021-06-29 02:53:14 --> Loader Class Initialized
INFO - 2021-06-29 02:53:14 --> Helper loaded: url_helper
INFO - 2021-06-29 02:53:14 --> Helper loaded: file_helper
INFO - 2021-06-29 02:53:14 --> Helper loaded: form_helper
INFO - 2021-06-29 02:53:14 --> Helper loaded: my_helper
INFO - 2021-06-29 02:53:14 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:53:14 --> Controller Class Initialized
DEBUG - 2021-06-29 02:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:53:14 --> Final output sent to browser
DEBUG - 2021-06-29 02:53:14 --> Total execution time: 0.0445
INFO - 2021-06-29 02:53:26 --> Config Class Initialized
INFO - 2021-06-29 02:53:26 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:53:26 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:53:26 --> Utf8 Class Initialized
INFO - 2021-06-29 02:53:26 --> URI Class Initialized
INFO - 2021-06-29 02:53:26 --> Router Class Initialized
INFO - 2021-06-29 02:53:26 --> Output Class Initialized
INFO - 2021-06-29 02:53:26 --> Security Class Initialized
DEBUG - 2021-06-29 02:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:53:26 --> Input Class Initialized
INFO - 2021-06-29 02:53:26 --> Language Class Initialized
INFO - 2021-06-29 02:53:26 --> Language Class Initialized
INFO - 2021-06-29 02:53:26 --> Config Class Initialized
INFO - 2021-06-29 02:53:26 --> Loader Class Initialized
INFO - 2021-06-29 02:53:26 --> Helper loaded: url_helper
INFO - 2021-06-29 02:53:26 --> Helper loaded: file_helper
INFO - 2021-06-29 02:53:26 --> Helper loaded: form_helper
INFO - 2021-06-29 02:53:26 --> Helper loaded: my_helper
INFO - 2021-06-29 02:53:26 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:53:26 --> Controller Class Initialized
DEBUG - 2021-06-29 02:53:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:53:26 --> Final output sent to browser
DEBUG - 2021-06-29 02:53:26 --> Total execution time: 0.0445
INFO - 2021-06-29 02:53:37 --> Config Class Initialized
INFO - 2021-06-29 02:53:37 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:53:37 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:53:37 --> Utf8 Class Initialized
INFO - 2021-06-29 02:53:37 --> URI Class Initialized
INFO - 2021-06-29 02:53:37 --> Router Class Initialized
INFO - 2021-06-29 02:53:37 --> Output Class Initialized
INFO - 2021-06-29 02:53:37 --> Security Class Initialized
DEBUG - 2021-06-29 02:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:53:37 --> Input Class Initialized
INFO - 2021-06-29 02:53:37 --> Language Class Initialized
INFO - 2021-06-29 02:53:37 --> Language Class Initialized
INFO - 2021-06-29 02:53:37 --> Config Class Initialized
INFO - 2021-06-29 02:53:37 --> Loader Class Initialized
INFO - 2021-06-29 02:53:37 --> Helper loaded: url_helper
INFO - 2021-06-29 02:53:37 --> Helper loaded: file_helper
INFO - 2021-06-29 02:53:37 --> Helper loaded: form_helper
INFO - 2021-06-29 02:53:37 --> Helper loaded: my_helper
INFO - 2021-06-29 02:53:37 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:53:37 --> Controller Class Initialized
DEBUG - 2021-06-29 02:53:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:53:37 --> Final output sent to browser
DEBUG - 2021-06-29 02:53:37 --> Total execution time: 0.0452
INFO - 2021-06-29 02:53:38 --> Config Class Initialized
INFO - 2021-06-29 02:53:38 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:53:38 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:53:38 --> Utf8 Class Initialized
INFO - 2021-06-29 02:53:38 --> URI Class Initialized
INFO - 2021-06-29 02:53:38 --> Router Class Initialized
INFO - 2021-06-29 02:53:38 --> Output Class Initialized
INFO - 2021-06-29 02:53:38 --> Security Class Initialized
DEBUG - 2021-06-29 02:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:53:38 --> Input Class Initialized
INFO - 2021-06-29 02:53:38 --> Language Class Initialized
INFO - 2021-06-29 02:53:38 --> Language Class Initialized
INFO - 2021-06-29 02:53:38 --> Config Class Initialized
INFO - 2021-06-29 02:53:38 --> Loader Class Initialized
INFO - 2021-06-29 02:53:38 --> Helper loaded: url_helper
INFO - 2021-06-29 02:53:38 --> Helper loaded: file_helper
INFO - 2021-06-29 02:53:38 --> Helper loaded: form_helper
INFO - 2021-06-29 02:53:38 --> Helper loaded: my_helper
INFO - 2021-06-29 02:53:38 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:53:38 --> Controller Class Initialized
DEBUG - 2021-06-29 02:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:53:38 --> Final output sent to browser
DEBUG - 2021-06-29 02:53:38 --> Total execution time: 0.0552
INFO - 2021-06-29 02:55:37 --> Config Class Initialized
INFO - 2021-06-29 02:55:37 --> Hooks Class Initialized
DEBUG - 2021-06-29 02:55:37 --> UTF-8 Support Enabled
INFO - 2021-06-29 02:55:37 --> Utf8 Class Initialized
INFO - 2021-06-29 02:55:37 --> URI Class Initialized
INFO - 2021-06-29 02:55:37 --> Router Class Initialized
INFO - 2021-06-29 02:55:37 --> Output Class Initialized
INFO - 2021-06-29 02:55:37 --> Security Class Initialized
DEBUG - 2021-06-29 02:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 02:55:37 --> Input Class Initialized
INFO - 2021-06-29 02:55:37 --> Language Class Initialized
INFO - 2021-06-29 02:55:37 --> Language Class Initialized
INFO - 2021-06-29 02:55:37 --> Config Class Initialized
INFO - 2021-06-29 02:55:37 --> Loader Class Initialized
INFO - 2021-06-29 02:55:37 --> Helper loaded: url_helper
INFO - 2021-06-29 02:55:37 --> Helper loaded: file_helper
INFO - 2021-06-29 02:55:37 --> Helper loaded: form_helper
INFO - 2021-06-29 02:55:37 --> Helper loaded: my_helper
INFO - 2021-06-29 02:55:37 --> Database Driver Class Initialized
DEBUG - 2021-06-29 02:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 02:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 02:55:37 --> Controller Class Initialized
DEBUG - 2021-06-29 02:55:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 02:55:37 --> Final output sent to browser
DEBUG - 2021-06-29 02:55:37 --> Total execution time: 0.0552
INFO - 2021-06-29 03:02:57 --> Config Class Initialized
INFO - 2021-06-29 03:02:57 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:02:57 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:02:57 --> Utf8 Class Initialized
INFO - 2021-06-29 03:02:57 --> URI Class Initialized
INFO - 2021-06-29 03:02:57 --> Router Class Initialized
INFO - 2021-06-29 03:02:57 --> Output Class Initialized
INFO - 2021-06-29 03:02:57 --> Security Class Initialized
DEBUG - 2021-06-29 03:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:02:57 --> Input Class Initialized
INFO - 2021-06-29 03:02:57 --> Language Class Initialized
INFO - 2021-06-29 03:02:57 --> Language Class Initialized
INFO - 2021-06-29 03:02:57 --> Config Class Initialized
INFO - 2021-06-29 03:02:57 --> Loader Class Initialized
INFO - 2021-06-29 03:02:57 --> Helper loaded: url_helper
INFO - 2021-06-29 03:02:57 --> Helper loaded: file_helper
INFO - 2021-06-29 03:02:57 --> Helper loaded: form_helper
INFO - 2021-06-29 03:02:57 --> Helper loaded: my_helper
INFO - 2021-06-29 03:02:57 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:02:57 --> Controller Class Initialized
DEBUG - 2021-06-29 03:02:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:02:57 --> Final output sent to browser
DEBUG - 2021-06-29 03:02:57 --> Total execution time: 0.0451
INFO - 2021-06-29 03:03:10 --> Config Class Initialized
INFO - 2021-06-29 03:03:10 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:03:10 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:03:10 --> Utf8 Class Initialized
INFO - 2021-06-29 03:03:10 --> URI Class Initialized
INFO - 2021-06-29 03:03:10 --> Router Class Initialized
INFO - 2021-06-29 03:03:10 --> Output Class Initialized
INFO - 2021-06-29 03:03:10 --> Security Class Initialized
DEBUG - 2021-06-29 03:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:03:10 --> Input Class Initialized
INFO - 2021-06-29 03:03:10 --> Language Class Initialized
INFO - 2021-06-29 03:03:10 --> Language Class Initialized
INFO - 2021-06-29 03:03:10 --> Config Class Initialized
INFO - 2021-06-29 03:03:10 --> Loader Class Initialized
INFO - 2021-06-29 03:03:10 --> Helper loaded: url_helper
INFO - 2021-06-29 03:03:10 --> Helper loaded: file_helper
INFO - 2021-06-29 03:03:10 --> Helper loaded: form_helper
INFO - 2021-06-29 03:03:10 --> Helper loaded: my_helper
INFO - 2021-06-29 03:03:10 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:03:10 --> Controller Class Initialized
DEBUG - 2021-06-29 03:03:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:03:10 --> Final output sent to browser
DEBUG - 2021-06-29 03:03:10 --> Total execution time: 0.0457
INFO - 2021-06-29 03:03:27 --> Config Class Initialized
INFO - 2021-06-29 03:03:27 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:03:27 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:03:27 --> Utf8 Class Initialized
INFO - 2021-06-29 03:03:27 --> URI Class Initialized
INFO - 2021-06-29 03:03:27 --> Router Class Initialized
INFO - 2021-06-29 03:03:27 --> Output Class Initialized
INFO - 2021-06-29 03:03:27 --> Security Class Initialized
DEBUG - 2021-06-29 03:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:03:27 --> Input Class Initialized
INFO - 2021-06-29 03:03:27 --> Language Class Initialized
INFO - 2021-06-29 03:03:27 --> Language Class Initialized
INFO - 2021-06-29 03:03:27 --> Config Class Initialized
INFO - 2021-06-29 03:03:27 --> Loader Class Initialized
INFO - 2021-06-29 03:03:27 --> Helper loaded: url_helper
INFO - 2021-06-29 03:03:27 --> Helper loaded: file_helper
INFO - 2021-06-29 03:03:27 --> Helper loaded: form_helper
INFO - 2021-06-29 03:03:27 --> Helper loaded: my_helper
INFO - 2021-06-29 03:03:27 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:03:27 --> Controller Class Initialized
DEBUG - 2021-06-29 03:03:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:03:27 --> Final output sent to browser
DEBUG - 2021-06-29 03:03:27 --> Total execution time: 0.0460
INFO - 2021-06-29 03:03:37 --> Config Class Initialized
INFO - 2021-06-29 03:03:37 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:03:37 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:03:37 --> Utf8 Class Initialized
INFO - 2021-06-29 03:03:37 --> URI Class Initialized
INFO - 2021-06-29 03:03:37 --> Router Class Initialized
INFO - 2021-06-29 03:03:37 --> Output Class Initialized
INFO - 2021-06-29 03:03:37 --> Security Class Initialized
DEBUG - 2021-06-29 03:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:03:37 --> Input Class Initialized
INFO - 2021-06-29 03:03:37 --> Language Class Initialized
INFO - 2021-06-29 03:03:37 --> Language Class Initialized
INFO - 2021-06-29 03:03:37 --> Config Class Initialized
INFO - 2021-06-29 03:03:37 --> Loader Class Initialized
INFO - 2021-06-29 03:03:37 --> Helper loaded: url_helper
INFO - 2021-06-29 03:03:37 --> Helper loaded: file_helper
INFO - 2021-06-29 03:03:37 --> Helper loaded: form_helper
INFO - 2021-06-29 03:03:37 --> Helper loaded: my_helper
INFO - 2021-06-29 03:03:37 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:03:37 --> Controller Class Initialized
DEBUG - 2021-06-29 03:03:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:03:37 --> Final output sent to browser
DEBUG - 2021-06-29 03:03:37 --> Total execution time: 0.0445
INFO - 2021-06-29 03:03:49 --> Config Class Initialized
INFO - 2021-06-29 03:03:49 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:03:49 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:03:49 --> Utf8 Class Initialized
INFO - 2021-06-29 03:03:49 --> URI Class Initialized
INFO - 2021-06-29 03:03:49 --> Router Class Initialized
INFO - 2021-06-29 03:03:49 --> Output Class Initialized
INFO - 2021-06-29 03:03:49 --> Security Class Initialized
DEBUG - 2021-06-29 03:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:03:49 --> Input Class Initialized
INFO - 2021-06-29 03:03:49 --> Language Class Initialized
INFO - 2021-06-29 03:03:49 --> Language Class Initialized
INFO - 2021-06-29 03:03:49 --> Config Class Initialized
INFO - 2021-06-29 03:03:49 --> Loader Class Initialized
INFO - 2021-06-29 03:03:49 --> Helper loaded: url_helper
INFO - 2021-06-29 03:03:49 --> Helper loaded: file_helper
INFO - 2021-06-29 03:03:49 --> Helper loaded: form_helper
INFO - 2021-06-29 03:03:49 --> Helper loaded: my_helper
INFO - 2021-06-29 03:03:49 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:03:49 --> Controller Class Initialized
DEBUG - 2021-06-29 03:03:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:03:49 --> Final output sent to browser
DEBUG - 2021-06-29 03:03:49 --> Total execution time: 0.0560
INFO - 2021-06-29 03:04:41 --> Config Class Initialized
INFO - 2021-06-29 03:04:41 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:04:41 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:04:41 --> Utf8 Class Initialized
INFO - 2021-06-29 03:04:41 --> URI Class Initialized
INFO - 2021-06-29 03:04:41 --> Router Class Initialized
INFO - 2021-06-29 03:04:41 --> Output Class Initialized
INFO - 2021-06-29 03:04:41 --> Security Class Initialized
DEBUG - 2021-06-29 03:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:04:41 --> Input Class Initialized
INFO - 2021-06-29 03:04:41 --> Language Class Initialized
INFO - 2021-06-29 03:04:41 --> Language Class Initialized
INFO - 2021-06-29 03:04:41 --> Config Class Initialized
INFO - 2021-06-29 03:04:41 --> Loader Class Initialized
INFO - 2021-06-29 03:04:41 --> Helper loaded: url_helper
INFO - 2021-06-29 03:04:41 --> Helper loaded: file_helper
INFO - 2021-06-29 03:04:41 --> Helper loaded: form_helper
INFO - 2021-06-29 03:04:41 --> Helper loaded: my_helper
INFO - 2021-06-29 03:04:41 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:04:41 --> Controller Class Initialized
DEBUG - 2021-06-29 03:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:04:41 --> Final output sent to browser
DEBUG - 2021-06-29 03:04:41 --> Total execution time: 0.0557
INFO - 2021-06-29 03:04:42 --> Config Class Initialized
INFO - 2021-06-29 03:04:42 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:04:42 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:04:42 --> Utf8 Class Initialized
INFO - 2021-06-29 03:04:42 --> URI Class Initialized
INFO - 2021-06-29 03:04:42 --> Router Class Initialized
INFO - 2021-06-29 03:04:42 --> Output Class Initialized
INFO - 2021-06-29 03:04:42 --> Security Class Initialized
DEBUG - 2021-06-29 03:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:04:42 --> Input Class Initialized
INFO - 2021-06-29 03:04:42 --> Language Class Initialized
INFO - 2021-06-29 03:04:42 --> Language Class Initialized
INFO - 2021-06-29 03:04:42 --> Config Class Initialized
INFO - 2021-06-29 03:04:42 --> Loader Class Initialized
INFO - 2021-06-29 03:04:42 --> Helper loaded: url_helper
INFO - 2021-06-29 03:04:42 --> Helper loaded: file_helper
INFO - 2021-06-29 03:04:42 --> Helper loaded: form_helper
INFO - 2021-06-29 03:04:42 --> Helper loaded: my_helper
INFO - 2021-06-29 03:04:42 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:04:42 --> Controller Class Initialized
DEBUG - 2021-06-29 03:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:04:42 --> Final output sent to browser
DEBUG - 2021-06-29 03:04:42 --> Total execution time: 0.0575
INFO - 2021-06-29 03:04:53 --> Config Class Initialized
INFO - 2021-06-29 03:04:53 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:04:53 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:04:53 --> Utf8 Class Initialized
INFO - 2021-06-29 03:04:53 --> URI Class Initialized
INFO - 2021-06-29 03:04:53 --> Router Class Initialized
INFO - 2021-06-29 03:04:53 --> Output Class Initialized
INFO - 2021-06-29 03:04:53 --> Security Class Initialized
DEBUG - 2021-06-29 03:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:04:53 --> Input Class Initialized
INFO - 2021-06-29 03:04:53 --> Language Class Initialized
INFO - 2021-06-29 03:04:53 --> Language Class Initialized
INFO - 2021-06-29 03:04:53 --> Config Class Initialized
INFO - 2021-06-29 03:04:53 --> Loader Class Initialized
INFO - 2021-06-29 03:04:53 --> Helper loaded: url_helper
INFO - 2021-06-29 03:04:53 --> Helper loaded: file_helper
INFO - 2021-06-29 03:04:53 --> Helper loaded: form_helper
INFO - 2021-06-29 03:04:53 --> Helper loaded: my_helper
INFO - 2021-06-29 03:04:53 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:04:53 --> Controller Class Initialized
DEBUG - 2021-06-29 03:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:04:53 --> Final output sent to browser
DEBUG - 2021-06-29 03:04:53 --> Total execution time: 0.0570
INFO - 2021-06-29 03:06:00 --> Config Class Initialized
INFO - 2021-06-29 03:06:00 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:06:00 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:06:00 --> Utf8 Class Initialized
INFO - 2021-06-29 03:06:00 --> URI Class Initialized
INFO - 2021-06-29 03:06:00 --> Router Class Initialized
INFO - 2021-06-29 03:06:00 --> Output Class Initialized
INFO - 2021-06-29 03:06:01 --> Security Class Initialized
DEBUG - 2021-06-29 03:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:06:01 --> Input Class Initialized
INFO - 2021-06-29 03:06:01 --> Language Class Initialized
INFO - 2021-06-29 03:06:01 --> Language Class Initialized
INFO - 2021-06-29 03:06:01 --> Config Class Initialized
INFO - 2021-06-29 03:06:01 --> Loader Class Initialized
INFO - 2021-06-29 03:06:01 --> Helper loaded: url_helper
INFO - 2021-06-29 03:06:01 --> Helper loaded: file_helper
INFO - 2021-06-29 03:06:01 --> Helper loaded: form_helper
INFO - 2021-06-29 03:06:01 --> Helper loaded: my_helper
INFO - 2021-06-29 03:06:01 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:06:01 --> Controller Class Initialized
DEBUG - 2021-06-29 03:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:06:01 --> Final output sent to browser
DEBUG - 2021-06-29 03:06:01 --> Total execution time: 0.0455
INFO - 2021-06-29 03:06:23 --> Config Class Initialized
INFO - 2021-06-29 03:06:23 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:06:23 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:06:23 --> Utf8 Class Initialized
INFO - 2021-06-29 03:06:23 --> URI Class Initialized
INFO - 2021-06-29 03:06:23 --> Router Class Initialized
INFO - 2021-06-29 03:06:23 --> Output Class Initialized
INFO - 2021-06-29 03:06:23 --> Security Class Initialized
DEBUG - 2021-06-29 03:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:06:23 --> Input Class Initialized
INFO - 2021-06-29 03:06:23 --> Language Class Initialized
INFO - 2021-06-29 03:06:23 --> Language Class Initialized
INFO - 2021-06-29 03:06:23 --> Config Class Initialized
INFO - 2021-06-29 03:06:23 --> Loader Class Initialized
INFO - 2021-06-29 03:06:23 --> Helper loaded: url_helper
INFO - 2021-06-29 03:06:23 --> Helper loaded: file_helper
INFO - 2021-06-29 03:06:23 --> Helper loaded: form_helper
INFO - 2021-06-29 03:06:23 --> Helper loaded: my_helper
INFO - 2021-06-29 03:06:23 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:06:23 --> Controller Class Initialized
DEBUG - 2021-06-29 03:06:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:06:23 --> Final output sent to browser
DEBUG - 2021-06-29 03:06:23 --> Total execution time: 0.0551
INFO - 2021-06-29 03:06:25 --> Config Class Initialized
INFO - 2021-06-29 03:06:25 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:06:25 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:06:25 --> Utf8 Class Initialized
INFO - 2021-06-29 03:06:25 --> URI Class Initialized
INFO - 2021-06-29 03:06:25 --> Router Class Initialized
INFO - 2021-06-29 03:06:25 --> Output Class Initialized
INFO - 2021-06-29 03:06:25 --> Security Class Initialized
DEBUG - 2021-06-29 03:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:06:25 --> Input Class Initialized
INFO - 2021-06-29 03:06:25 --> Language Class Initialized
INFO - 2021-06-29 03:06:25 --> Language Class Initialized
INFO - 2021-06-29 03:06:25 --> Config Class Initialized
INFO - 2021-06-29 03:06:25 --> Loader Class Initialized
INFO - 2021-06-29 03:06:25 --> Helper loaded: url_helper
INFO - 2021-06-29 03:06:25 --> Helper loaded: file_helper
INFO - 2021-06-29 03:06:25 --> Helper loaded: form_helper
INFO - 2021-06-29 03:06:25 --> Helper loaded: my_helper
INFO - 2021-06-29 03:06:25 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:06:25 --> Controller Class Initialized
DEBUG - 2021-06-29 03:06:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:06:25 --> Final output sent to browser
DEBUG - 2021-06-29 03:06:25 --> Total execution time: 0.0547
INFO - 2021-06-29 03:23:27 --> Config Class Initialized
INFO - 2021-06-29 03:23:27 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:23:27 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:23:27 --> Utf8 Class Initialized
INFO - 2021-06-29 03:23:27 --> URI Class Initialized
INFO - 2021-06-29 03:23:27 --> Router Class Initialized
INFO - 2021-06-29 03:23:27 --> Output Class Initialized
INFO - 2021-06-29 03:23:27 --> Security Class Initialized
DEBUG - 2021-06-29 03:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:23:27 --> Input Class Initialized
INFO - 2021-06-29 03:23:27 --> Language Class Initialized
INFO - 2021-06-29 03:23:27 --> Language Class Initialized
INFO - 2021-06-29 03:23:27 --> Config Class Initialized
INFO - 2021-06-29 03:23:27 --> Loader Class Initialized
INFO - 2021-06-29 03:23:27 --> Helper loaded: url_helper
INFO - 2021-06-29 03:23:28 --> Helper loaded: file_helper
INFO - 2021-06-29 03:23:28 --> Helper loaded: form_helper
INFO - 2021-06-29 03:23:28 --> Helper loaded: my_helper
INFO - 2021-06-29 03:23:28 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:23:28 --> Controller Class Initialized
DEBUG - 2021-06-29 03:23:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:23:28 --> Final output sent to browser
DEBUG - 2021-06-29 03:23:28 --> Total execution time: 0.0475
INFO - 2021-06-29 03:24:40 --> Config Class Initialized
INFO - 2021-06-29 03:24:40 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:24:40 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:24:40 --> Utf8 Class Initialized
INFO - 2021-06-29 03:24:40 --> URI Class Initialized
INFO - 2021-06-29 03:24:40 --> Router Class Initialized
INFO - 2021-06-29 03:24:40 --> Output Class Initialized
INFO - 2021-06-29 03:24:40 --> Security Class Initialized
DEBUG - 2021-06-29 03:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:24:40 --> Input Class Initialized
INFO - 2021-06-29 03:24:40 --> Language Class Initialized
INFO - 2021-06-29 03:24:40 --> Language Class Initialized
INFO - 2021-06-29 03:24:40 --> Config Class Initialized
INFO - 2021-06-29 03:24:40 --> Loader Class Initialized
INFO - 2021-06-29 03:24:40 --> Helper loaded: url_helper
INFO - 2021-06-29 03:24:40 --> Helper loaded: file_helper
INFO - 2021-06-29 03:24:40 --> Helper loaded: form_helper
INFO - 2021-06-29 03:24:40 --> Helper loaded: my_helper
INFO - 2021-06-29 03:24:40 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:24:40 --> Controller Class Initialized
DEBUG - 2021-06-29 03:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:24:40 --> Final output sent to browser
DEBUG - 2021-06-29 03:24:40 --> Total execution time: 0.0449
INFO - 2021-06-29 03:25:27 --> Config Class Initialized
INFO - 2021-06-29 03:25:27 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:25:27 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:25:27 --> Utf8 Class Initialized
INFO - 2021-06-29 03:25:27 --> URI Class Initialized
INFO - 2021-06-29 03:25:27 --> Router Class Initialized
INFO - 2021-06-29 03:25:27 --> Output Class Initialized
INFO - 2021-06-29 03:25:27 --> Security Class Initialized
DEBUG - 2021-06-29 03:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:25:27 --> Input Class Initialized
INFO - 2021-06-29 03:25:27 --> Language Class Initialized
INFO - 2021-06-29 03:25:27 --> Language Class Initialized
INFO - 2021-06-29 03:25:27 --> Config Class Initialized
INFO - 2021-06-29 03:25:27 --> Loader Class Initialized
INFO - 2021-06-29 03:25:27 --> Helper loaded: url_helper
INFO - 2021-06-29 03:25:27 --> Helper loaded: file_helper
INFO - 2021-06-29 03:25:27 --> Helper loaded: form_helper
INFO - 2021-06-29 03:25:27 --> Helper loaded: my_helper
INFO - 2021-06-29 03:25:27 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:25:27 --> Controller Class Initialized
DEBUG - 2021-06-29 03:25:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:25:27 --> Final output sent to browser
DEBUG - 2021-06-29 03:25:27 --> Total execution time: 0.0556
INFO - 2021-06-29 03:25:36 --> Config Class Initialized
INFO - 2021-06-29 03:25:36 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:25:36 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:25:36 --> Utf8 Class Initialized
INFO - 2021-06-29 03:25:36 --> URI Class Initialized
INFO - 2021-06-29 03:25:36 --> Router Class Initialized
INFO - 2021-06-29 03:25:36 --> Output Class Initialized
INFO - 2021-06-29 03:25:36 --> Security Class Initialized
DEBUG - 2021-06-29 03:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:25:36 --> Input Class Initialized
INFO - 2021-06-29 03:25:36 --> Language Class Initialized
INFO - 2021-06-29 03:25:36 --> Language Class Initialized
INFO - 2021-06-29 03:25:36 --> Config Class Initialized
INFO - 2021-06-29 03:25:36 --> Loader Class Initialized
INFO - 2021-06-29 03:25:36 --> Helper loaded: url_helper
INFO - 2021-06-29 03:25:36 --> Helper loaded: file_helper
INFO - 2021-06-29 03:25:36 --> Helper loaded: form_helper
INFO - 2021-06-29 03:25:36 --> Helper loaded: my_helper
INFO - 2021-06-29 03:25:36 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:25:36 --> Controller Class Initialized
DEBUG - 2021-06-29 03:25:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:25:36 --> Final output sent to browser
DEBUG - 2021-06-29 03:25:36 --> Total execution time: 0.0545
INFO - 2021-06-29 03:25:52 --> Config Class Initialized
INFO - 2021-06-29 03:25:52 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:25:52 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:25:52 --> Utf8 Class Initialized
INFO - 2021-06-29 03:25:52 --> URI Class Initialized
INFO - 2021-06-29 03:25:52 --> Router Class Initialized
INFO - 2021-06-29 03:25:52 --> Output Class Initialized
INFO - 2021-06-29 03:25:52 --> Security Class Initialized
DEBUG - 2021-06-29 03:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:25:52 --> Input Class Initialized
INFO - 2021-06-29 03:25:52 --> Language Class Initialized
INFO - 2021-06-29 03:25:52 --> Language Class Initialized
INFO - 2021-06-29 03:25:52 --> Config Class Initialized
INFO - 2021-06-29 03:25:52 --> Loader Class Initialized
INFO - 2021-06-29 03:25:52 --> Helper loaded: url_helper
INFO - 2021-06-29 03:25:52 --> Helper loaded: file_helper
INFO - 2021-06-29 03:25:52 --> Helper loaded: form_helper
INFO - 2021-06-29 03:25:52 --> Helper loaded: my_helper
INFO - 2021-06-29 03:25:52 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:25:52 --> Controller Class Initialized
DEBUG - 2021-06-29 03:25:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:25:52 --> Final output sent to browser
DEBUG - 2021-06-29 03:25:52 --> Total execution time: 0.0455
INFO - 2021-06-29 03:26:06 --> Config Class Initialized
INFO - 2021-06-29 03:26:06 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:26:06 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:26:06 --> Utf8 Class Initialized
INFO - 2021-06-29 03:26:06 --> URI Class Initialized
INFO - 2021-06-29 03:26:06 --> Router Class Initialized
INFO - 2021-06-29 03:26:06 --> Output Class Initialized
INFO - 2021-06-29 03:26:06 --> Security Class Initialized
DEBUG - 2021-06-29 03:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:26:06 --> Input Class Initialized
INFO - 2021-06-29 03:26:06 --> Language Class Initialized
INFO - 2021-06-29 03:26:06 --> Language Class Initialized
INFO - 2021-06-29 03:26:06 --> Config Class Initialized
INFO - 2021-06-29 03:26:06 --> Loader Class Initialized
INFO - 2021-06-29 03:26:06 --> Helper loaded: url_helper
INFO - 2021-06-29 03:26:06 --> Helper loaded: file_helper
INFO - 2021-06-29 03:26:06 --> Helper loaded: form_helper
INFO - 2021-06-29 03:26:06 --> Helper loaded: my_helper
INFO - 2021-06-29 03:26:06 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:26:06 --> Controller Class Initialized
DEBUG - 2021-06-29 03:26:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:26:06 --> Final output sent to browser
DEBUG - 2021-06-29 03:26:06 --> Total execution time: 0.0544
INFO - 2021-06-29 03:31:38 --> Config Class Initialized
INFO - 2021-06-29 03:31:38 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:31:38 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:31:38 --> Utf8 Class Initialized
INFO - 2021-06-29 03:31:38 --> URI Class Initialized
INFO - 2021-06-29 03:31:38 --> Router Class Initialized
INFO - 2021-06-29 03:31:38 --> Output Class Initialized
INFO - 2021-06-29 03:31:38 --> Security Class Initialized
DEBUG - 2021-06-29 03:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:31:38 --> Input Class Initialized
INFO - 2021-06-29 03:31:38 --> Language Class Initialized
INFO - 2021-06-29 03:31:38 --> Language Class Initialized
INFO - 2021-06-29 03:31:38 --> Config Class Initialized
INFO - 2021-06-29 03:31:38 --> Loader Class Initialized
INFO - 2021-06-29 03:31:38 --> Helper loaded: url_helper
INFO - 2021-06-29 03:31:38 --> Helper loaded: file_helper
INFO - 2021-06-29 03:31:38 --> Helper loaded: form_helper
INFO - 2021-06-29 03:31:38 --> Helper loaded: my_helper
INFO - 2021-06-29 03:31:38 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:31:38 --> Controller Class Initialized
INFO - 2021-06-29 03:31:38 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:31:38 --> Config Class Initialized
INFO - 2021-06-29 03:31:38 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:31:38 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:31:38 --> Utf8 Class Initialized
INFO - 2021-06-29 03:31:38 --> URI Class Initialized
INFO - 2021-06-29 03:31:38 --> Router Class Initialized
INFO - 2021-06-29 03:31:38 --> Output Class Initialized
INFO - 2021-06-29 03:31:38 --> Security Class Initialized
DEBUG - 2021-06-29 03:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:31:38 --> Input Class Initialized
INFO - 2021-06-29 03:31:38 --> Language Class Initialized
INFO - 2021-06-29 03:31:38 --> Language Class Initialized
INFO - 2021-06-29 03:31:38 --> Config Class Initialized
INFO - 2021-06-29 03:31:38 --> Loader Class Initialized
INFO - 2021-06-29 03:31:38 --> Helper loaded: url_helper
INFO - 2021-06-29 03:31:38 --> Helper loaded: file_helper
INFO - 2021-06-29 03:31:38 --> Helper loaded: form_helper
INFO - 2021-06-29 03:31:38 --> Helper loaded: my_helper
INFO - 2021-06-29 03:31:38 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:31:38 --> Controller Class Initialized
DEBUG - 2021-06-29 03:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 03:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:31:38 --> Final output sent to browser
DEBUG - 2021-06-29 03:31:38 --> Total execution time: 0.0408
INFO - 2021-06-29 03:31:44 --> Config Class Initialized
INFO - 2021-06-29 03:31:44 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:31:44 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:31:44 --> Utf8 Class Initialized
INFO - 2021-06-29 03:31:44 --> URI Class Initialized
INFO - 2021-06-29 03:31:44 --> Router Class Initialized
INFO - 2021-06-29 03:31:44 --> Output Class Initialized
INFO - 2021-06-29 03:31:44 --> Security Class Initialized
DEBUG - 2021-06-29 03:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:31:44 --> Input Class Initialized
INFO - 2021-06-29 03:31:44 --> Language Class Initialized
INFO - 2021-06-29 03:31:44 --> Language Class Initialized
INFO - 2021-06-29 03:31:44 --> Config Class Initialized
INFO - 2021-06-29 03:31:44 --> Loader Class Initialized
INFO - 2021-06-29 03:31:44 --> Helper loaded: url_helper
INFO - 2021-06-29 03:31:44 --> Helper loaded: file_helper
INFO - 2021-06-29 03:31:44 --> Helper loaded: form_helper
INFO - 2021-06-29 03:31:44 --> Helper loaded: my_helper
INFO - 2021-06-29 03:31:44 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:31:44 --> Controller Class Initialized
INFO - 2021-06-29 03:31:44 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:31:44 --> Final output sent to browser
DEBUG - 2021-06-29 03:31:44 --> Total execution time: 0.0441
INFO - 2021-06-29 03:31:44 --> Config Class Initialized
INFO - 2021-06-29 03:31:44 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:31:44 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:31:44 --> Utf8 Class Initialized
INFO - 2021-06-29 03:31:44 --> URI Class Initialized
INFO - 2021-06-29 03:31:44 --> Router Class Initialized
INFO - 2021-06-29 03:31:44 --> Output Class Initialized
INFO - 2021-06-29 03:31:44 --> Security Class Initialized
DEBUG - 2021-06-29 03:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:31:44 --> Input Class Initialized
INFO - 2021-06-29 03:31:44 --> Language Class Initialized
INFO - 2021-06-29 03:31:44 --> Language Class Initialized
INFO - 2021-06-29 03:31:44 --> Config Class Initialized
INFO - 2021-06-29 03:31:44 --> Loader Class Initialized
INFO - 2021-06-29 03:31:44 --> Helper loaded: url_helper
INFO - 2021-06-29 03:31:44 --> Helper loaded: file_helper
INFO - 2021-06-29 03:31:44 --> Helper loaded: form_helper
INFO - 2021-06-29 03:31:44 --> Helper loaded: my_helper
INFO - 2021-06-29 03:31:44 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:31:44 --> Controller Class Initialized
DEBUG - 2021-06-29 03:31:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-29 03:31:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:31:45 --> Final output sent to browser
DEBUG - 2021-06-29 03:31:45 --> Total execution time: 0.6540
INFO - 2021-06-29 03:31:49 --> Config Class Initialized
INFO - 2021-06-29 03:31:49 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:31:49 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:31:49 --> Utf8 Class Initialized
INFO - 2021-06-29 03:31:49 --> URI Class Initialized
INFO - 2021-06-29 03:31:49 --> Router Class Initialized
INFO - 2021-06-29 03:31:49 --> Output Class Initialized
INFO - 2021-06-29 03:31:49 --> Security Class Initialized
DEBUG - 2021-06-29 03:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:31:49 --> Input Class Initialized
INFO - 2021-06-29 03:31:49 --> Language Class Initialized
INFO - 2021-06-29 03:31:49 --> Language Class Initialized
INFO - 2021-06-29 03:31:49 --> Config Class Initialized
INFO - 2021-06-29 03:31:49 --> Loader Class Initialized
INFO - 2021-06-29 03:31:49 --> Helper loaded: url_helper
INFO - 2021-06-29 03:31:49 --> Helper loaded: file_helper
INFO - 2021-06-29 03:31:49 --> Helper loaded: form_helper
INFO - 2021-06-29 03:31:49 --> Helper loaded: my_helper
INFO - 2021-06-29 03:31:49 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:31:49 --> Controller Class Initialized
DEBUG - 2021-06-29 03:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-29 03:31:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:31:49 --> Final output sent to browser
DEBUG - 2021-06-29 03:31:49 --> Total execution time: 0.0887
INFO - 2021-06-29 03:31:53 --> Config Class Initialized
INFO - 2021-06-29 03:31:53 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:31:53 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:31:53 --> Utf8 Class Initialized
INFO - 2021-06-29 03:31:53 --> URI Class Initialized
INFO - 2021-06-29 03:31:53 --> Router Class Initialized
INFO - 2021-06-29 03:31:53 --> Output Class Initialized
INFO - 2021-06-29 03:31:53 --> Security Class Initialized
DEBUG - 2021-06-29 03:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:31:53 --> Input Class Initialized
INFO - 2021-06-29 03:31:53 --> Language Class Initialized
INFO - 2021-06-29 03:31:53 --> Language Class Initialized
INFO - 2021-06-29 03:31:53 --> Config Class Initialized
INFO - 2021-06-29 03:31:53 --> Loader Class Initialized
INFO - 2021-06-29 03:31:53 --> Helper loaded: url_helper
INFO - 2021-06-29 03:31:53 --> Helper loaded: file_helper
INFO - 2021-06-29 03:31:53 --> Helper loaded: form_helper
INFO - 2021-06-29 03:31:53 --> Helper loaded: my_helper
INFO - 2021-06-29 03:31:53 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:31:53 --> Controller Class Initialized
DEBUG - 2021-06-29 03:31:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-29 03:31:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:31:53 --> Final output sent to browser
DEBUG - 2021-06-29 03:31:53 --> Total execution time: 0.1025
INFO - 2021-06-29 03:31:53 --> Config Class Initialized
INFO - 2021-06-29 03:31:53 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:31:53 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:31:53 --> Utf8 Class Initialized
INFO - 2021-06-29 03:31:53 --> URI Class Initialized
INFO - 2021-06-29 03:31:53 --> Router Class Initialized
INFO - 2021-06-29 03:31:53 --> Output Class Initialized
INFO - 2021-06-29 03:31:53 --> Security Class Initialized
DEBUG - 2021-06-29 03:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:31:53 --> Input Class Initialized
INFO - 2021-06-29 03:31:53 --> Language Class Initialized
INFO - 2021-06-29 03:31:53 --> Language Class Initialized
INFO - 2021-06-29 03:31:53 --> Config Class Initialized
INFO - 2021-06-29 03:31:53 --> Loader Class Initialized
INFO - 2021-06-29 03:31:53 --> Helper loaded: url_helper
INFO - 2021-06-29 03:31:53 --> Helper loaded: file_helper
INFO - 2021-06-29 03:31:53 --> Helper loaded: form_helper
INFO - 2021-06-29 03:31:53 --> Helper loaded: my_helper
INFO - 2021-06-29 03:31:53 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:31:53 --> Controller Class Initialized
INFO - 2021-06-29 03:31:55 --> Config Class Initialized
INFO - 2021-06-29 03:31:55 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:31:55 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:31:55 --> Utf8 Class Initialized
INFO - 2021-06-29 03:31:55 --> URI Class Initialized
INFO - 2021-06-29 03:31:55 --> Router Class Initialized
INFO - 2021-06-29 03:31:55 --> Output Class Initialized
INFO - 2021-06-29 03:31:55 --> Security Class Initialized
DEBUG - 2021-06-29 03:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:31:55 --> Input Class Initialized
INFO - 2021-06-29 03:31:55 --> Language Class Initialized
INFO - 2021-06-29 03:31:55 --> Language Class Initialized
INFO - 2021-06-29 03:31:55 --> Config Class Initialized
INFO - 2021-06-29 03:31:55 --> Loader Class Initialized
INFO - 2021-06-29 03:31:55 --> Helper loaded: url_helper
INFO - 2021-06-29 03:31:55 --> Helper loaded: file_helper
INFO - 2021-06-29 03:31:55 --> Helper loaded: form_helper
INFO - 2021-06-29 03:31:55 --> Helper loaded: my_helper
INFO - 2021-06-29 03:31:55 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:31:55 --> Controller Class Initialized
INFO - 2021-06-29 03:31:55 --> Final output sent to browser
DEBUG - 2021-06-29 03:31:55 --> Total execution time: 0.1094
INFO - 2021-06-29 03:32:00 --> Config Class Initialized
INFO - 2021-06-29 03:32:00 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:32:00 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:32:00 --> Utf8 Class Initialized
INFO - 2021-06-29 03:32:00 --> URI Class Initialized
INFO - 2021-06-29 03:32:00 --> Router Class Initialized
INFO - 2021-06-29 03:32:00 --> Output Class Initialized
INFO - 2021-06-29 03:32:00 --> Security Class Initialized
DEBUG - 2021-06-29 03:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:32:00 --> Input Class Initialized
INFO - 2021-06-29 03:32:00 --> Language Class Initialized
INFO - 2021-06-29 03:32:00 --> Language Class Initialized
INFO - 2021-06-29 03:32:00 --> Config Class Initialized
INFO - 2021-06-29 03:32:00 --> Loader Class Initialized
INFO - 2021-06-29 03:32:00 --> Helper loaded: url_helper
INFO - 2021-06-29 03:32:00 --> Helper loaded: file_helper
INFO - 2021-06-29 03:32:00 --> Helper loaded: form_helper
INFO - 2021-06-29 03:32:00 --> Helper loaded: my_helper
INFO - 2021-06-29 03:32:00 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:32:00 --> Controller Class Initialized
DEBUG - 2021-06-29 03:32:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-29 03:32:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:32:00 --> Final output sent to browser
DEBUG - 2021-06-29 03:32:00 --> Total execution time: 0.1132
INFO - 2021-06-29 03:32:04 --> Config Class Initialized
INFO - 2021-06-29 03:32:04 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:32:04 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:32:04 --> Utf8 Class Initialized
INFO - 2021-06-29 03:32:04 --> URI Class Initialized
INFO - 2021-06-29 03:32:04 --> Router Class Initialized
INFO - 2021-06-29 03:32:04 --> Output Class Initialized
INFO - 2021-06-29 03:32:04 --> Security Class Initialized
DEBUG - 2021-06-29 03:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:32:04 --> Input Class Initialized
INFO - 2021-06-29 03:32:04 --> Language Class Initialized
INFO - 2021-06-29 03:32:04 --> Language Class Initialized
INFO - 2021-06-29 03:32:04 --> Config Class Initialized
INFO - 2021-06-29 03:32:04 --> Loader Class Initialized
INFO - 2021-06-29 03:32:04 --> Helper loaded: url_helper
INFO - 2021-06-29 03:32:04 --> Helper loaded: file_helper
INFO - 2021-06-29 03:32:04 --> Helper loaded: form_helper
INFO - 2021-06-29 03:32:04 --> Helper loaded: my_helper
INFO - 2021-06-29 03:32:04 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:32:04 --> Controller Class Initialized
INFO - 2021-06-29 03:32:04 --> Final output sent to browser
DEBUG - 2021-06-29 03:32:04 --> Total execution time: 0.1022
INFO - 2021-06-29 03:32:05 --> Config Class Initialized
INFO - 2021-06-29 03:32:05 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:32:05 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:32:05 --> Utf8 Class Initialized
INFO - 2021-06-29 03:32:05 --> URI Class Initialized
INFO - 2021-06-29 03:32:05 --> Router Class Initialized
INFO - 2021-06-29 03:32:05 --> Output Class Initialized
INFO - 2021-06-29 03:32:05 --> Security Class Initialized
DEBUG - 2021-06-29 03:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:32:05 --> Input Class Initialized
INFO - 2021-06-29 03:32:05 --> Language Class Initialized
INFO - 2021-06-29 03:32:05 --> Language Class Initialized
INFO - 2021-06-29 03:32:05 --> Config Class Initialized
INFO - 2021-06-29 03:32:05 --> Loader Class Initialized
INFO - 2021-06-29 03:32:05 --> Helper loaded: url_helper
INFO - 2021-06-29 03:32:05 --> Helper loaded: file_helper
INFO - 2021-06-29 03:32:05 --> Helper loaded: form_helper
INFO - 2021-06-29 03:32:05 --> Helper loaded: my_helper
INFO - 2021-06-29 03:32:06 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:32:06 --> Controller Class Initialized
INFO - 2021-06-29 03:32:09 --> Config Class Initialized
INFO - 2021-06-29 03:32:09 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:32:09 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:32:09 --> Utf8 Class Initialized
INFO - 2021-06-29 03:32:09 --> URI Class Initialized
INFO - 2021-06-29 03:32:09 --> Router Class Initialized
INFO - 2021-06-29 03:32:09 --> Output Class Initialized
INFO - 2021-06-29 03:32:09 --> Security Class Initialized
DEBUG - 2021-06-29 03:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:32:09 --> Input Class Initialized
INFO - 2021-06-29 03:32:09 --> Language Class Initialized
INFO - 2021-06-29 03:32:09 --> Language Class Initialized
INFO - 2021-06-29 03:32:09 --> Config Class Initialized
INFO - 2021-06-29 03:32:09 --> Loader Class Initialized
INFO - 2021-06-29 03:32:09 --> Helper loaded: url_helper
INFO - 2021-06-29 03:32:09 --> Helper loaded: file_helper
INFO - 2021-06-29 03:32:09 --> Helper loaded: form_helper
INFO - 2021-06-29 03:32:09 --> Helper loaded: my_helper
INFO - 2021-06-29 03:32:09 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:32:09 --> Controller Class Initialized
INFO - 2021-06-29 03:34:27 --> Config Class Initialized
INFO - 2021-06-29 03:34:27 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:27 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:27 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:27 --> URI Class Initialized
INFO - 2021-06-29 03:34:27 --> Router Class Initialized
INFO - 2021-06-29 03:34:27 --> Output Class Initialized
INFO - 2021-06-29 03:34:27 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:27 --> Input Class Initialized
INFO - 2021-06-29 03:34:27 --> Language Class Initialized
INFO - 2021-06-29 03:34:27 --> Language Class Initialized
INFO - 2021-06-29 03:34:27 --> Config Class Initialized
INFO - 2021-06-29 03:34:27 --> Loader Class Initialized
INFO - 2021-06-29 03:34:27 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:27 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:27 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:27 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:27 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:27 --> Controller Class Initialized
DEBUG - 2021-06-29 03:34:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-29 03:34:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:34:27 --> Final output sent to browser
DEBUG - 2021-06-29 03:34:27 --> Total execution time: 0.0583
INFO - 2021-06-29 03:34:31 --> Config Class Initialized
INFO - 2021-06-29 03:34:31 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:31 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:31 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:31 --> URI Class Initialized
INFO - 2021-06-29 03:34:31 --> Router Class Initialized
INFO - 2021-06-29 03:34:31 --> Output Class Initialized
INFO - 2021-06-29 03:34:31 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:31 --> Input Class Initialized
INFO - 2021-06-29 03:34:31 --> Language Class Initialized
INFO - 2021-06-29 03:34:31 --> Language Class Initialized
INFO - 2021-06-29 03:34:31 --> Config Class Initialized
INFO - 2021-06-29 03:34:31 --> Loader Class Initialized
INFO - 2021-06-29 03:34:31 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:31 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:31 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:31 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:31 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:31 --> Controller Class Initialized
INFO - 2021-06-29 03:34:31 --> Config Class Initialized
INFO - 2021-06-29 03:34:31 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:31 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:31 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:31 --> URI Class Initialized
INFO - 2021-06-29 03:34:31 --> Router Class Initialized
INFO - 2021-06-29 03:34:31 --> Output Class Initialized
INFO - 2021-06-29 03:34:31 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:31 --> Input Class Initialized
INFO - 2021-06-29 03:34:31 --> Language Class Initialized
INFO - 2021-06-29 03:34:31 --> Language Class Initialized
INFO - 2021-06-29 03:34:31 --> Config Class Initialized
INFO - 2021-06-29 03:34:31 --> Loader Class Initialized
INFO - 2021-06-29 03:34:31 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:31 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:31 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:31 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:31 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:31 --> Controller Class Initialized
DEBUG - 2021-06-29 03:34:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-29 03:34:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:34:31 --> Final output sent to browser
DEBUG - 2021-06-29 03:34:31 --> Total execution time: 0.0439
INFO - 2021-06-29 03:34:32 --> Config Class Initialized
INFO - 2021-06-29 03:34:32 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:32 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:32 --> URI Class Initialized
INFO - 2021-06-29 03:34:32 --> Router Class Initialized
INFO - 2021-06-29 03:34:32 --> Output Class Initialized
INFO - 2021-06-29 03:34:32 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:32 --> Input Class Initialized
INFO - 2021-06-29 03:34:32 --> Language Class Initialized
INFO - 2021-06-29 03:34:32 --> Language Class Initialized
INFO - 2021-06-29 03:34:32 --> Config Class Initialized
INFO - 2021-06-29 03:34:32 --> Loader Class Initialized
INFO - 2021-06-29 03:34:32 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:32 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:32 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:32 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:32 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:32 --> Controller Class Initialized
INFO - 2021-06-29 03:34:33 --> Config Class Initialized
INFO - 2021-06-29 03:34:33 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:33 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:33 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:33 --> URI Class Initialized
INFO - 2021-06-29 03:34:33 --> Router Class Initialized
INFO - 2021-06-29 03:34:33 --> Output Class Initialized
INFO - 2021-06-29 03:34:33 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:33 --> Input Class Initialized
INFO - 2021-06-29 03:34:33 --> Language Class Initialized
INFO - 2021-06-29 03:34:33 --> Language Class Initialized
INFO - 2021-06-29 03:34:33 --> Config Class Initialized
INFO - 2021-06-29 03:34:33 --> Loader Class Initialized
INFO - 2021-06-29 03:34:33 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:33 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:33 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:33 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:33 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:33 --> Controller Class Initialized
DEBUG - 2021-06-29 03:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-29 03:34:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:34:33 --> Final output sent to browser
DEBUG - 2021-06-29 03:34:33 --> Total execution time: 0.0586
INFO - 2021-06-29 03:34:37 --> Config Class Initialized
INFO - 2021-06-29 03:34:37 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:37 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:37 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:37 --> URI Class Initialized
INFO - 2021-06-29 03:34:37 --> Router Class Initialized
INFO - 2021-06-29 03:34:37 --> Output Class Initialized
INFO - 2021-06-29 03:34:37 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:37 --> Input Class Initialized
INFO - 2021-06-29 03:34:37 --> Language Class Initialized
INFO - 2021-06-29 03:34:37 --> Language Class Initialized
INFO - 2021-06-29 03:34:37 --> Config Class Initialized
INFO - 2021-06-29 03:34:37 --> Loader Class Initialized
INFO - 2021-06-29 03:34:37 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:37 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:37 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:37 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:37 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:37 --> Controller Class Initialized
INFO - 2021-06-29 03:34:37 --> Config Class Initialized
INFO - 2021-06-29 03:34:37 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:37 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:37 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:37 --> URI Class Initialized
INFO - 2021-06-29 03:34:37 --> Router Class Initialized
INFO - 2021-06-29 03:34:37 --> Output Class Initialized
INFO - 2021-06-29 03:34:37 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:37 --> Input Class Initialized
INFO - 2021-06-29 03:34:37 --> Language Class Initialized
INFO - 2021-06-29 03:34:37 --> Language Class Initialized
INFO - 2021-06-29 03:34:37 --> Config Class Initialized
INFO - 2021-06-29 03:34:37 --> Loader Class Initialized
INFO - 2021-06-29 03:34:37 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:37 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:37 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:37 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:37 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:37 --> Controller Class Initialized
DEBUG - 2021-06-29 03:34:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-29 03:34:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:34:37 --> Final output sent to browser
DEBUG - 2021-06-29 03:34:37 --> Total execution time: 0.0525
INFO - 2021-06-29 03:34:43 --> Config Class Initialized
INFO - 2021-06-29 03:34:43 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:43 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:43 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:43 --> URI Class Initialized
INFO - 2021-06-29 03:34:43 --> Router Class Initialized
INFO - 2021-06-29 03:34:43 --> Output Class Initialized
INFO - 2021-06-29 03:34:43 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:43 --> Input Class Initialized
INFO - 2021-06-29 03:34:43 --> Language Class Initialized
INFO - 2021-06-29 03:34:43 --> Language Class Initialized
INFO - 2021-06-29 03:34:43 --> Config Class Initialized
INFO - 2021-06-29 03:34:43 --> Loader Class Initialized
INFO - 2021-06-29 03:34:43 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:43 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:43 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:43 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:43 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:43 --> Controller Class Initialized
INFO - 2021-06-29 03:34:43 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:34:43 --> Config Class Initialized
INFO - 2021-06-29 03:34:43 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:43 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:43 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:43 --> URI Class Initialized
INFO - 2021-06-29 03:34:43 --> Router Class Initialized
INFO - 2021-06-29 03:34:43 --> Output Class Initialized
INFO - 2021-06-29 03:34:43 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:43 --> Input Class Initialized
INFO - 2021-06-29 03:34:43 --> Language Class Initialized
INFO - 2021-06-29 03:34:43 --> Language Class Initialized
INFO - 2021-06-29 03:34:43 --> Config Class Initialized
INFO - 2021-06-29 03:34:43 --> Loader Class Initialized
INFO - 2021-06-29 03:34:43 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:43 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:43 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:43 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:43 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:43 --> Controller Class Initialized
DEBUG - 2021-06-29 03:34:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 03:34:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:34:43 --> Final output sent to browser
DEBUG - 2021-06-29 03:34:43 --> Total execution time: 0.0484
INFO - 2021-06-29 03:34:50 --> Config Class Initialized
INFO - 2021-06-29 03:34:50 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:50 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:50 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:50 --> URI Class Initialized
INFO - 2021-06-29 03:34:50 --> Router Class Initialized
INFO - 2021-06-29 03:34:50 --> Output Class Initialized
INFO - 2021-06-29 03:34:50 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:50 --> Input Class Initialized
INFO - 2021-06-29 03:34:50 --> Language Class Initialized
INFO - 2021-06-29 03:34:50 --> Language Class Initialized
INFO - 2021-06-29 03:34:50 --> Config Class Initialized
INFO - 2021-06-29 03:34:50 --> Loader Class Initialized
INFO - 2021-06-29 03:34:50 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:50 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:50 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:50 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:50 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:50 --> Controller Class Initialized
INFO - 2021-06-29 03:34:50 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:34:50 --> Final output sent to browser
DEBUG - 2021-06-29 03:34:50 --> Total execution time: 0.0448
INFO - 2021-06-29 03:34:50 --> Config Class Initialized
INFO - 2021-06-29 03:34:50 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:34:50 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:34:50 --> Utf8 Class Initialized
INFO - 2021-06-29 03:34:50 --> URI Class Initialized
INFO - 2021-06-29 03:34:50 --> Router Class Initialized
INFO - 2021-06-29 03:34:50 --> Output Class Initialized
INFO - 2021-06-29 03:34:50 --> Security Class Initialized
DEBUG - 2021-06-29 03:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:34:50 --> Input Class Initialized
INFO - 2021-06-29 03:34:50 --> Language Class Initialized
INFO - 2021-06-29 03:34:50 --> Language Class Initialized
INFO - 2021-06-29 03:34:50 --> Config Class Initialized
INFO - 2021-06-29 03:34:50 --> Loader Class Initialized
INFO - 2021-06-29 03:34:50 --> Helper loaded: url_helper
INFO - 2021-06-29 03:34:50 --> Helper loaded: file_helper
INFO - 2021-06-29 03:34:50 --> Helper loaded: form_helper
INFO - 2021-06-29 03:34:50 --> Helper loaded: my_helper
INFO - 2021-06-29 03:34:50 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:34:50 --> Controller Class Initialized
DEBUG - 2021-06-29 03:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-29 03:34:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:34:51 --> Final output sent to browser
DEBUG - 2021-06-29 03:34:51 --> Total execution time: 0.6601
INFO - 2021-06-29 03:35:07 --> Config Class Initialized
INFO - 2021-06-29 03:35:07 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:35:07 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:35:07 --> Utf8 Class Initialized
INFO - 2021-06-29 03:35:07 --> URI Class Initialized
INFO - 2021-06-29 03:35:07 --> Router Class Initialized
INFO - 2021-06-29 03:35:07 --> Output Class Initialized
INFO - 2021-06-29 03:35:07 --> Security Class Initialized
DEBUG - 2021-06-29 03:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:35:07 --> Input Class Initialized
INFO - 2021-06-29 03:35:07 --> Language Class Initialized
INFO - 2021-06-29 03:35:07 --> Language Class Initialized
INFO - 2021-06-29 03:35:07 --> Config Class Initialized
INFO - 2021-06-29 03:35:07 --> Loader Class Initialized
INFO - 2021-06-29 03:35:07 --> Helper loaded: url_helper
INFO - 2021-06-29 03:35:07 --> Helper loaded: file_helper
INFO - 2021-06-29 03:35:07 --> Helper loaded: form_helper
INFO - 2021-06-29 03:35:07 --> Helper loaded: my_helper
INFO - 2021-06-29 03:35:07 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:35:07 --> Controller Class Initialized
DEBUG - 2021-06-29 03:35:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-29 03:35:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:35:07 --> Final output sent to browser
DEBUG - 2021-06-29 03:35:07 --> Total execution time: 0.0504
INFO - 2021-06-29 03:35:10 --> Config Class Initialized
INFO - 2021-06-29 03:35:10 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:35:10 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:35:10 --> Utf8 Class Initialized
INFO - 2021-06-29 03:35:10 --> URI Class Initialized
INFO - 2021-06-29 03:35:10 --> Router Class Initialized
INFO - 2021-06-29 03:35:10 --> Output Class Initialized
INFO - 2021-06-29 03:35:10 --> Security Class Initialized
DEBUG - 2021-06-29 03:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:35:10 --> Input Class Initialized
INFO - 2021-06-29 03:35:10 --> Language Class Initialized
INFO - 2021-06-29 03:35:10 --> Language Class Initialized
INFO - 2021-06-29 03:35:10 --> Config Class Initialized
INFO - 2021-06-29 03:35:10 --> Loader Class Initialized
INFO - 2021-06-29 03:35:10 --> Helper loaded: url_helper
INFO - 2021-06-29 03:35:10 --> Helper loaded: file_helper
INFO - 2021-06-29 03:35:10 --> Helper loaded: form_helper
INFO - 2021-06-29 03:35:10 --> Helper loaded: my_helper
INFO - 2021-06-29 03:35:10 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:35:10 --> Controller Class Initialized
DEBUG - 2021-06-29 03:35:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-29 03:35:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:35:10 --> Final output sent to browser
DEBUG - 2021-06-29 03:35:10 --> Total execution time: 0.0445
INFO - 2021-06-29 03:35:10 --> Config Class Initialized
INFO - 2021-06-29 03:35:10 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:35:10 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:35:10 --> Utf8 Class Initialized
INFO - 2021-06-29 03:35:10 --> URI Class Initialized
INFO - 2021-06-29 03:35:10 --> Router Class Initialized
INFO - 2021-06-29 03:35:10 --> Output Class Initialized
INFO - 2021-06-29 03:35:10 --> Security Class Initialized
DEBUG - 2021-06-29 03:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:35:10 --> Input Class Initialized
INFO - 2021-06-29 03:35:10 --> Language Class Initialized
INFO - 2021-06-29 03:35:10 --> Language Class Initialized
INFO - 2021-06-29 03:35:10 --> Config Class Initialized
INFO - 2021-06-29 03:35:10 --> Loader Class Initialized
INFO - 2021-06-29 03:35:10 --> Helper loaded: url_helper
INFO - 2021-06-29 03:35:10 --> Helper loaded: file_helper
INFO - 2021-06-29 03:35:10 --> Helper loaded: form_helper
INFO - 2021-06-29 03:35:10 --> Helper loaded: my_helper
INFO - 2021-06-29 03:35:10 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:35:10 --> Controller Class Initialized
INFO - 2021-06-29 03:35:12 --> Config Class Initialized
INFO - 2021-06-29 03:35:12 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:35:12 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:35:12 --> Utf8 Class Initialized
INFO - 2021-06-29 03:35:12 --> URI Class Initialized
INFO - 2021-06-29 03:35:12 --> Router Class Initialized
INFO - 2021-06-29 03:35:12 --> Output Class Initialized
INFO - 2021-06-29 03:35:12 --> Security Class Initialized
DEBUG - 2021-06-29 03:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:35:12 --> Input Class Initialized
INFO - 2021-06-29 03:35:12 --> Language Class Initialized
INFO - 2021-06-29 03:35:12 --> Language Class Initialized
INFO - 2021-06-29 03:35:12 --> Config Class Initialized
INFO - 2021-06-29 03:35:12 --> Loader Class Initialized
INFO - 2021-06-29 03:35:12 --> Helper loaded: url_helper
INFO - 2021-06-29 03:35:12 --> Helper loaded: file_helper
INFO - 2021-06-29 03:35:12 --> Helper loaded: form_helper
INFO - 2021-06-29 03:35:12 --> Helper loaded: my_helper
INFO - 2021-06-29 03:35:12 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:35:12 --> Controller Class Initialized
DEBUG - 2021-06-29 03:35:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-29 03:35:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:35:12 --> Final output sent to browser
DEBUG - 2021-06-29 03:35:12 --> Total execution time: 0.0450
INFO - 2021-06-29 03:35:15 --> Config Class Initialized
INFO - 2021-06-29 03:35:15 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:35:15 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:35:15 --> Utf8 Class Initialized
INFO - 2021-06-29 03:35:15 --> URI Class Initialized
INFO - 2021-06-29 03:35:15 --> Router Class Initialized
INFO - 2021-06-29 03:35:15 --> Output Class Initialized
INFO - 2021-06-29 03:35:15 --> Security Class Initialized
DEBUG - 2021-06-29 03:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:35:15 --> Input Class Initialized
INFO - 2021-06-29 03:35:15 --> Language Class Initialized
INFO - 2021-06-29 03:35:15 --> Language Class Initialized
INFO - 2021-06-29 03:35:15 --> Config Class Initialized
INFO - 2021-06-29 03:35:15 --> Loader Class Initialized
INFO - 2021-06-29 03:35:15 --> Helper loaded: url_helper
INFO - 2021-06-29 03:35:15 --> Helper loaded: file_helper
INFO - 2021-06-29 03:35:15 --> Helper loaded: form_helper
INFO - 2021-06-29 03:35:15 --> Helper loaded: my_helper
INFO - 2021-06-29 03:35:15 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:35:15 --> Controller Class Initialized
INFO - 2021-06-29 03:35:15 --> Final output sent to browser
DEBUG - 2021-06-29 03:35:15 --> Total execution time: 0.1169
INFO - 2021-06-29 03:35:30 --> Config Class Initialized
INFO - 2021-06-29 03:35:30 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:35:30 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:35:30 --> Utf8 Class Initialized
INFO - 2021-06-29 03:35:30 --> URI Class Initialized
INFO - 2021-06-29 03:35:30 --> Router Class Initialized
INFO - 2021-06-29 03:35:30 --> Output Class Initialized
INFO - 2021-06-29 03:35:30 --> Security Class Initialized
DEBUG - 2021-06-29 03:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:35:30 --> Input Class Initialized
INFO - 2021-06-29 03:35:30 --> Language Class Initialized
INFO - 2021-06-29 03:35:30 --> Language Class Initialized
INFO - 2021-06-29 03:35:30 --> Config Class Initialized
INFO - 2021-06-29 03:35:30 --> Loader Class Initialized
INFO - 2021-06-29 03:35:30 --> Helper loaded: url_helper
INFO - 2021-06-29 03:35:30 --> Helper loaded: file_helper
INFO - 2021-06-29 03:35:30 --> Helper loaded: form_helper
INFO - 2021-06-29 03:35:30 --> Helper loaded: my_helper
INFO - 2021-06-29 03:35:30 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:35:30 --> Controller Class Initialized
INFO - 2021-06-29 03:35:32 --> Config Class Initialized
INFO - 2021-06-29 03:35:32 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:35:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:35:32 --> Utf8 Class Initialized
INFO - 2021-06-29 03:35:32 --> URI Class Initialized
INFO - 2021-06-29 03:35:32 --> Router Class Initialized
INFO - 2021-06-29 03:35:32 --> Output Class Initialized
INFO - 2021-06-29 03:35:32 --> Security Class Initialized
DEBUG - 2021-06-29 03:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:35:32 --> Input Class Initialized
INFO - 2021-06-29 03:35:32 --> Language Class Initialized
INFO - 2021-06-29 03:35:32 --> Language Class Initialized
INFO - 2021-06-29 03:35:32 --> Config Class Initialized
INFO - 2021-06-29 03:35:32 --> Loader Class Initialized
INFO - 2021-06-29 03:35:32 --> Helper loaded: url_helper
INFO - 2021-06-29 03:35:32 --> Helper loaded: file_helper
INFO - 2021-06-29 03:35:32 --> Helper loaded: form_helper
INFO - 2021-06-29 03:35:32 --> Helper loaded: my_helper
INFO - 2021-06-29 03:35:32 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:35:32 --> Controller Class Initialized
INFO - 2021-06-29 03:36:19 --> Config Class Initialized
INFO - 2021-06-29 03:36:19 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:36:19 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:36:19 --> Utf8 Class Initialized
INFO - 2021-06-29 03:36:19 --> URI Class Initialized
INFO - 2021-06-29 03:36:19 --> Router Class Initialized
INFO - 2021-06-29 03:36:19 --> Output Class Initialized
INFO - 2021-06-29 03:36:19 --> Security Class Initialized
DEBUG - 2021-06-29 03:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:36:19 --> Input Class Initialized
INFO - 2021-06-29 03:36:19 --> Language Class Initialized
INFO - 2021-06-29 03:36:19 --> Language Class Initialized
INFO - 2021-06-29 03:36:19 --> Config Class Initialized
INFO - 2021-06-29 03:36:19 --> Loader Class Initialized
INFO - 2021-06-29 03:36:19 --> Helper loaded: url_helper
INFO - 2021-06-29 03:36:19 --> Helper loaded: file_helper
INFO - 2021-06-29 03:36:19 --> Helper loaded: form_helper
INFO - 2021-06-29 03:36:19 --> Helper loaded: my_helper
INFO - 2021-06-29 03:36:19 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:36:19 --> Controller Class Initialized
DEBUG - 2021-06-29 03:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-29 03:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:36:19 --> Final output sent to browser
DEBUG - 2021-06-29 03:36:19 --> Total execution time: 0.0442
INFO - 2021-06-29 03:36:24 --> Config Class Initialized
INFO - 2021-06-29 03:36:24 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:36:24 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:36:24 --> Utf8 Class Initialized
INFO - 2021-06-29 03:36:24 --> URI Class Initialized
INFO - 2021-06-29 03:36:24 --> Router Class Initialized
INFO - 2021-06-29 03:36:24 --> Output Class Initialized
INFO - 2021-06-29 03:36:24 --> Security Class Initialized
DEBUG - 2021-06-29 03:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:36:24 --> Input Class Initialized
INFO - 2021-06-29 03:36:24 --> Language Class Initialized
INFO - 2021-06-29 03:36:24 --> Language Class Initialized
INFO - 2021-06-29 03:36:24 --> Config Class Initialized
INFO - 2021-06-29 03:36:24 --> Loader Class Initialized
INFO - 2021-06-29 03:36:24 --> Helper loaded: url_helper
INFO - 2021-06-29 03:36:24 --> Helper loaded: file_helper
INFO - 2021-06-29 03:36:24 --> Helper loaded: form_helper
INFO - 2021-06-29 03:36:24 --> Helper loaded: my_helper
INFO - 2021-06-29 03:36:24 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:36:24 --> Controller Class Initialized
INFO - 2021-06-29 03:36:25 --> Config Class Initialized
INFO - 2021-06-29 03:36:25 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:36:25 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:36:25 --> Utf8 Class Initialized
INFO - 2021-06-29 03:36:25 --> URI Class Initialized
INFO - 2021-06-29 03:36:25 --> Router Class Initialized
INFO - 2021-06-29 03:36:25 --> Output Class Initialized
INFO - 2021-06-29 03:36:25 --> Security Class Initialized
DEBUG - 2021-06-29 03:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:36:25 --> Input Class Initialized
INFO - 2021-06-29 03:36:25 --> Language Class Initialized
INFO - 2021-06-29 03:36:25 --> Language Class Initialized
INFO - 2021-06-29 03:36:25 --> Config Class Initialized
INFO - 2021-06-29 03:36:25 --> Loader Class Initialized
INFO - 2021-06-29 03:36:25 --> Helper loaded: url_helper
INFO - 2021-06-29 03:36:25 --> Helper loaded: file_helper
INFO - 2021-06-29 03:36:25 --> Helper loaded: form_helper
INFO - 2021-06-29 03:36:25 --> Helper loaded: my_helper
INFO - 2021-06-29 03:36:25 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:36:25 --> Controller Class Initialized
DEBUG - 2021-06-29 03:36:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-29 03:36:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:36:25 --> Final output sent to browser
DEBUG - 2021-06-29 03:36:25 --> Total execution time: 0.0438
INFO - 2021-06-29 03:36:25 --> Config Class Initialized
INFO - 2021-06-29 03:36:25 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:36:25 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:36:25 --> Utf8 Class Initialized
INFO - 2021-06-29 03:36:25 --> URI Class Initialized
INFO - 2021-06-29 03:36:25 --> Router Class Initialized
INFO - 2021-06-29 03:36:25 --> Output Class Initialized
INFO - 2021-06-29 03:36:25 --> Security Class Initialized
DEBUG - 2021-06-29 03:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:36:25 --> Input Class Initialized
INFO - 2021-06-29 03:36:25 --> Language Class Initialized
INFO - 2021-06-29 03:36:25 --> Language Class Initialized
INFO - 2021-06-29 03:36:25 --> Config Class Initialized
INFO - 2021-06-29 03:36:25 --> Loader Class Initialized
INFO - 2021-06-29 03:36:25 --> Helper loaded: url_helper
INFO - 2021-06-29 03:36:25 --> Helper loaded: file_helper
INFO - 2021-06-29 03:36:25 --> Helper loaded: form_helper
INFO - 2021-06-29 03:36:25 --> Helper loaded: my_helper
INFO - 2021-06-29 03:36:25 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:36:25 --> Controller Class Initialized
INFO - 2021-06-29 03:36:27 --> Config Class Initialized
INFO - 2021-06-29 03:36:27 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:36:27 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:36:27 --> Utf8 Class Initialized
INFO - 2021-06-29 03:36:27 --> URI Class Initialized
INFO - 2021-06-29 03:36:27 --> Router Class Initialized
INFO - 2021-06-29 03:36:27 --> Output Class Initialized
INFO - 2021-06-29 03:36:27 --> Security Class Initialized
DEBUG - 2021-06-29 03:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:36:27 --> Input Class Initialized
INFO - 2021-06-29 03:36:27 --> Language Class Initialized
INFO - 2021-06-29 03:36:27 --> Language Class Initialized
INFO - 2021-06-29 03:36:27 --> Config Class Initialized
INFO - 2021-06-29 03:36:27 --> Loader Class Initialized
INFO - 2021-06-29 03:36:27 --> Helper loaded: url_helper
INFO - 2021-06-29 03:36:27 --> Helper loaded: file_helper
INFO - 2021-06-29 03:36:27 --> Helper loaded: form_helper
INFO - 2021-06-29 03:36:27 --> Helper loaded: my_helper
INFO - 2021-06-29 03:36:27 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:36:27 --> Controller Class Initialized
DEBUG - 2021-06-29 03:36:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-29 03:36:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:36:27 --> Final output sent to browser
DEBUG - 2021-06-29 03:36:27 --> Total execution time: 0.0526
INFO - 2021-06-29 03:36:30 --> Config Class Initialized
INFO - 2021-06-29 03:36:30 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:36:30 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:36:30 --> Utf8 Class Initialized
INFO - 2021-06-29 03:36:30 --> URI Class Initialized
INFO - 2021-06-29 03:36:30 --> Router Class Initialized
INFO - 2021-06-29 03:36:30 --> Output Class Initialized
INFO - 2021-06-29 03:36:30 --> Security Class Initialized
DEBUG - 2021-06-29 03:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:36:30 --> Input Class Initialized
INFO - 2021-06-29 03:36:30 --> Language Class Initialized
INFO - 2021-06-29 03:36:30 --> Language Class Initialized
INFO - 2021-06-29 03:36:30 --> Config Class Initialized
INFO - 2021-06-29 03:36:30 --> Loader Class Initialized
INFO - 2021-06-29 03:36:30 --> Helper loaded: url_helper
INFO - 2021-06-29 03:36:30 --> Helper loaded: file_helper
INFO - 2021-06-29 03:36:30 --> Helper loaded: form_helper
INFO - 2021-06-29 03:36:30 --> Helper loaded: my_helper
INFO - 2021-06-29 03:36:30 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:36:30 --> Controller Class Initialized
INFO - 2021-06-29 03:36:30 --> Config Class Initialized
INFO - 2021-06-29 03:36:30 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:36:30 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:36:30 --> Utf8 Class Initialized
INFO - 2021-06-29 03:36:30 --> URI Class Initialized
INFO - 2021-06-29 03:36:30 --> Router Class Initialized
INFO - 2021-06-29 03:36:30 --> Output Class Initialized
INFO - 2021-06-29 03:36:30 --> Security Class Initialized
DEBUG - 2021-06-29 03:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:36:30 --> Input Class Initialized
INFO - 2021-06-29 03:36:30 --> Language Class Initialized
INFO - 2021-06-29 03:36:30 --> Language Class Initialized
INFO - 2021-06-29 03:36:30 --> Config Class Initialized
INFO - 2021-06-29 03:36:30 --> Loader Class Initialized
INFO - 2021-06-29 03:36:30 --> Helper loaded: url_helper
INFO - 2021-06-29 03:36:30 --> Helper loaded: file_helper
INFO - 2021-06-29 03:36:30 --> Helper loaded: form_helper
INFO - 2021-06-29 03:36:30 --> Helper loaded: my_helper
INFO - 2021-06-29 03:36:30 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:36:30 --> Controller Class Initialized
DEBUG - 2021-06-29 03:36:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-29 03:36:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:36:30 --> Final output sent to browser
DEBUG - 2021-06-29 03:36:30 --> Total execution time: 0.0541
INFO - 2021-06-29 03:36:35 --> Config Class Initialized
INFO - 2021-06-29 03:36:35 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:36:35 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:36:35 --> Utf8 Class Initialized
INFO - 2021-06-29 03:36:35 --> URI Class Initialized
INFO - 2021-06-29 03:36:35 --> Router Class Initialized
INFO - 2021-06-29 03:36:35 --> Output Class Initialized
INFO - 2021-06-29 03:36:35 --> Security Class Initialized
DEBUG - 2021-06-29 03:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:36:35 --> Input Class Initialized
INFO - 2021-06-29 03:36:35 --> Language Class Initialized
INFO - 2021-06-29 03:36:35 --> Language Class Initialized
INFO - 2021-06-29 03:36:35 --> Config Class Initialized
INFO - 2021-06-29 03:36:35 --> Loader Class Initialized
INFO - 2021-06-29 03:36:35 --> Helper loaded: url_helper
INFO - 2021-06-29 03:36:35 --> Helper loaded: file_helper
INFO - 2021-06-29 03:36:35 --> Helper loaded: form_helper
INFO - 2021-06-29 03:36:35 --> Helper loaded: my_helper
INFO - 2021-06-29 03:36:35 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:36:35 --> Controller Class Initialized
INFO - 2021-06-29 03:36:35 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:36:35 --> Config Class Initialized
INFO - 2021-06-29 03:36:35 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:36:35 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:36:35 --> Utf8 Class Initialized
INFO - 2021-06-29 03:36:35 --> URI Class Initialized
INFO - 2021-06-29 03:36:35 --> Router Class Initialized
INFO - 2021-06-29 03:36:35 --> Output Class Initialized
INFO - 2021-06-29 03:36:35 --> Security Class Initialized
DEBUG - 2021-06-29 03:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:36:35 --> Input Class Initialized
INFO - 2021-06-29 03:36:35 --> Language Class Initialized
INFO - 2021-06-29 03:36:35 --> Language Class Initialized
INFO - 2021-06-29 03:36:35 --> Config Class Initialized
INFO - 2021-06-29 03:36:35 --> Loader Class Initialized
INFO - 2021-06-29 03:36:35 --> Helper loaded: url_helper
INFO - 2021-06-29 03:36:35 --> Helper loaded: file_helper
INFO - 2021-06-29 03:36:35 --> Helper loaded: form_helper
INFO - 2021-06-29 03:36:35 --> Helper loaded: my_helper
INFO - 2021-06-29 03:36:35 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:36:35 --> Controller Class Initialized
DEBUG - 2021-06-29 03:36:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 03:36:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:36:35 --> Final output sent to browser
DEBUG - 2021-06-29 03:36:35 --> Total execution time: 0.0486
INFO - 2021-06-29 03:37:38 --> Config Class Initialized
INFO - 2021-06-29 03:37:38 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:37:38 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:37:38 --> Utf8 Class Initialized
INFO - 2021-06-29 03:37:38 --> URI Class Initialized
INFO - 2021-06-29 03:37:38 --> Router Class Initialized
INFO - 2021-06-29 03:37:38 --> Output Class Initialized
INFO - 2021-06-29 03:37:38 --> Security Class Initialized
DEBUG - 2021-06-29 03:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:37:38 --> Input Class Initialized
INFO - 2021-06-29 03:37:38 --> Language Class Initialized
INFO - 2021-06-29 03:37:38 --> Language Class Initialized
INFO - 2021-06-29 03:37:38 --> Config Class Initialized
INFO - 2021-06-29 03:37:38 --> Loader Class Initialized
INFO - 2021-06-29 03:37:38 --> Helper loaded: url_helper
INFO - 2021-06-29 03:37:38 --> Helper loaded: file_helper
INFO - 2021-06-29 03:37:38 --> Helper loaded: form_helper
INFO - 2021-06-29 03:37:38 --> Helper loaded: my_helper
INFO - 2021-06-29 03:37:38 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:37:38 --> Controller Class Initialized
INFO - 2021-06-29 03:37:38 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:37:38 --> Final output sent to browser
DEBUG - 2021-06-29 03:37:38 --> Total execution time: 0.0444
INFO - 2021-06-29 03:37:38 --> Config Class Initialized
INFO - 2021-06-29 03:37:38 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:37:38 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:37:38 --> Utf8 Class Initialized
INFO - 2021-06-29 03:37:38 --> URI Class Initialized
INFO - 2021-06-29 03:37:38 --> Router Class Initialized
INFO - 2021-06-29 03:37:38 --> Output Class Initialized
INFO - 2021-06-29 03:37:38 --> Security Class Initialized
DEBUG - 2021-06-29 03:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:37:38 --> Input Class Initialized
INFO - 2021-06-29 03:37:38 --> Language Class Initialized
INFO - 2021-06-29 03:37:38 --> Language Class Initialized
INFO - 2021-06-29 03:37:38 --> Config Class Initialized
INFO - 2021-06-29 03:37:38 --> Loader Class Initialized
INFO - 2021-06-29 03:37:38 --> Helper loaded: url_helper
INFO - 2021-06-29 03:37:38 --> Helper loaded: file_helper
INFO - 2021-06-29 03:37:38 --> Helper loaded: form_helper
INFO - 2021-06-29 03:37:38 --> Helper loaded: my_helper
INFO - 2021-06-29 03:37:38 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:37:38 --> Controller Class Initialized
DEBUG - 2021-06-29 03:37:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-29 03:37:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:37:39 --> Final output sent to browser
DEBUG - 2021-06-29 03:37:39 --> Total execution time: 0.6389
INFO - 2021-06-29 03:37:41 --> Config Class Initialized
INFO - 2021-06-29 03:37:41 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:37:41 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:37:41 --> Utf8 Class Initialized
INFO - 2021-06-29 03:37:41 --> URI Class Initialized
INFO - 2021-06-29 03:37:41 --> Router Class Initialized
INFO - 2021-06-29 03:37:41 --> Output Class Initialized
INFO - 2021-06-29 03:37:41 --> Security Class Initialized
DEBUG - 2021-06-29 03:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:37:41 --> Input Class Initialized
INFO - 2021-06-29 03:37:41 --> Language Class Initialized
INFO - 2021-06-29 03:37:41 --> Language Class Initialized
INFO - 2021-06-29 03:37:41 --> Config Class Initialized
INFO - 2021-06-29 03:37:41 --> Loader Class Initialized
INFO - 2021-06-29 03:37:41 --> Helper loaded: url_helper
INFO - 2021-06-29 03:37:41 --> Helper loaded: file_helper
INFO - 2021-06-29 03:37:41 --> Helper loaded: form_helper
INFO - 2021-06-29 03:37:41 --> Helper loaded: my_helper
INFO - 2021-06-29 03:37:41 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:37:41 --> Controller Class Initialized
DEBUG - 2021-06-29 03:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-29 03:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:37:41 --> Final output sent to browser
DEBUG - 2021-06-29 03:37:41 --> Total execution time: 0.0840
INFO - 2021-06-29 03:37:43 --> Config Class Initialized
INFO - 2021-06-29 03:37:43 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:37:43 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:37:43 --> Utf8 Class Initialized
INFO - 2021-06-29 03:37:43 --> URI Class Initialized
INFO - 2021-06-29 03:37:43 --> Router Class Initialized
INFO - 2021-06-29 03:37:43 --> Output Class Initialized
INFO - 2021-06-29 03:37:43 --> Security Class Initialized
DEBUG - 2021-06-29 03:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:37:43 --> Input Class Initialized
INFO - 2021-06-29 03:37:43 --> Language Class Initialized
INFO - 2021-06-29 03:37:43 --> Language Class Initialized
INFO - 2021-06-29 03:37:43 --> Config Class Initialized
INFO - 2021-06-29 03:37:43 --> Loader Class Initialized
INFO - 2021-06-29 03:37:43 --> Helper loaded: url_helper
INFO - 2021-06-29 03:37:43 --> Helper loaded: file_helper
INFO - 2021-06-29 03:37:43 --> Helper loaded: form_helper
INFO - 2021-06-29 03:37:43 --> Helper loaded: my_helper
INFO - 2021-06-29 03:37:43 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:37:43 --> Controller Class Initialized
DEBUG - 2021-06-29 03:37:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-06-29 03:37:43 --> Final output sent to browser
DEBUG - 2021-06-29 03:37:43 --> Total execution time: 0.3466
INFO - 2021-06-29 03:38:25 --> Config Class Initialized
INFO - 2021-06-29 03:38:25 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:38:25 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:38:25 --> Utf8 Class Initialized
INFO - 2021-06-29 03:38:25 --> URI Class Initialized
INFO - 2021-06-29 03:38:25 --> Router Class Initialized
INFO - 2021-06-29 03:38:25 --> Output Class Initialized
INFO - 2021-06-29 03:38:25 --> Security Class Initialized
DEBUG - 2021-06-29 03:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:38:25 --> Input Class Initialized
INFO - 2021-06-29 03:38:25 --> Language Class Initialized
INFO - 2021-06-29 03:38:25 --> Language Class Initialized
INFO - 2021-06-29 03:38:25 --> Config Class Initialized
INFO - 2021-06-29 03:38:25 --> Loader Class Initialized
INFO - 2021-06-29 03:38:25 --> Helper loaded: url_helper
INFO - 2021-06-29 03:38:25 --> Helper loaded: file_helper
INFO - 2021-06-29 03:38:25 --> Helper loaded: form_helper
INFO - 2021-06-29 03:38:25 --> Helper loaded: my_helper
INFO - 2021-06-29 03:38:25 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:38:25 --> Controller Class Initialized
DEBUG - 2021-06-29 03:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-29 03:38:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:38:25 --> Final output sent to browser
DEBUG - 2021-06-29 03:38:25 --> Total execution time: 0.0625
INFO - 2021-06-29 03:40:17 --> Config Class Initialized
INFO - 2021-06-29 03:40:17 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:17 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:17 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:17 --> URI Class Initialized
INFO - 2021-06-29 03:40:17 --> Router Class Initialized
INFO - 2021-06-29 03:40:17 --> Output Class Initialized
INFO - 2021-06-29 03:40:17 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:17 --> Input Class Initialized
INFO - 2021-06-29 03:40:17 --> Language Class Initialized
INFO - 2021-06-29 03:40:17 --> Language Class Initialized
INFO - 2021-06-29 03:40:17 --> Config Class Initialized
INFO - 2021-06-29 03:40:17 --> Loader Class Initialized
INFO - 2021-06-29 03:40:17 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:17 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:17 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:17 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:17 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:17 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:17 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:17 --> Total execution time: 0.2736
INFO - 2021-06-29 03:40:33 --> Config Class Initialized
INFO - 2021-06-29 03:40:33 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:33 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:33 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:33 --> URI Class Initialized
INFO - 2021-06-29 03:40:33 --> Router Class Initialized
INFO - 2021-06-29 03:40:33 --> Output Class Initialized
INFO - 2021-06-29 03:40:33 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:33 --> Input Class Initialized
INFO - 2021-06-29 03:40:33 --> Language Class Initialized
INFO - 2021-06-29 03:40:33 --> Language Class Initialized
INFO - 2021-06-29 03:40:33 --> Config Class Initialized
INFO - 2021-06-29 03:40:33 --> Loader Class Initialized
INFO - 2021-06-29 03:40:33 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:33 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:33 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:33 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:33 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:33 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:33 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:33 --> Total execution time: 0.2001
INFO - 2021-06-29 03:40:35 --> Config Class Initialized
INFO - 2021-06-29 03:40:35 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:35 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:35 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:35 --> URI Class Initialized
INFO - 2021-06-29 03:40:35 --> Router Class Initialized
INFO - 2021-06-29 03:40:35 --> Output Class Initialized
INFO - 2021-06-29 03:40:35 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:35 --> Input Class Initialized
INFO - 2021-06-29 03:40:35 --> Language Class Initialized
INFO - 2021-06-29 03:40:35 --> Language Class Initialized
INFO - 2021-06-29 03:40:35 --> Config Class Initialized
INFO - 2021-06-29 03:40:35 --> Loader Class Initialized
INFO - 2021-06-29 03:40:35 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:35 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:35 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:35 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:35 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:35 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:36 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:36 --> Total execution time: 0.1918
INFO - 2021-06-29 03:40:37 --> Config Class Initialized
INFO - 2021-06-29 03:40:37 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:37 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:37 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:37 --> URI Class Initialized
INFO - 2021-06-29 03:40:37 --> Router Class Initialized
INFO - 2021-06-29 03:40:37 --> Output Class Initialized
INFO - 2021-06-29 03:40:37 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:37 --> Input Class Initialized
INFO - 2021-06-29 03:40:37 --> Language Class Initialized
INFO - 2021-06-29 03:40:37 --> Language Class Initialized
INFO - 2021-06-29 03:40:37 --> Config Class Initialized
INFO - 2021-06-29 03:40:37 --> Loader Class Initialized
INFO - 2021-06-29 03:40:37 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:37 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:37 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:37 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:37 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:37 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:37 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:37 --> Total execution time: 0.1932
INFO - 2021-06-29 03:40:39 --> Config Class Initialized
INFO - 2021-06-29 03:40:39 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:39 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:39 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:39 --> URI Class Initialized
INFO - 2021-06-29 03:40:39 --> Router Class Initialized
INFO - 2021-06-29 03:40:39 --> Output Class Initialized
INFO - 2021-06-29 03:40:39 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:39 --> Input Class Initialized
INFO - 2021-06-29 03:40:39 --> Language Class Initialized
INFO - 2021-06-29 03:40:39 --> Language Class Initialized
INFO - 2021-06-29 03:40:39 --> Config Class Initialized
INFO - 2021-06-29 03:40:39 --> Loader Class Initialized
INFO - 2021-06-29 03:40:39 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:39 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:39 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:39 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:39 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:39 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:39 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:39 --> Total execution time: 0.1929
INFO - 2021-06-29 03:40:40 --> Config Class Initialized
INFO - 2021-06-29 03:40:40 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:40 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:40 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:40 --> URI Class Initialized
INFO - 2021-06-29 03:40:40 --> Router Class Initialized
INFO - 2021-06-29 03:40:40 --> Output Class Initialized
INFO - 2021-06-29 03:40:40 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:40 --> Input Class Initialized
INFO - 2021-06-29 03:40:40 --> Language Class Initialized
INFO - 2021-06-29 03:40:40 --> Language Class Initialized
INFO - 2021-06-29 03:40:40 --> Config Class Initialized
INFO - 2021-06-29 03:40:40 --> Loader Class Initialized
INFO - 2021-06-29 03:40:40 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:40 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:40 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:40 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:40 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:40 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:40 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:40 --> Total execution time: 0.1897
INFO - 2021-06-29 03:40:41 --> Config Class Initialized
INFO - 2021-06-29 03:40:42 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:42 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:42 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:42 --> URI Class Initialized
INFO - 2021-06-29 03:40:42 --> Router Class Initialized
INFO - 2021-06-29 03:40:42 --> Output Class Initialized
INFO - 2021-06-29 03:40:42 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:42 --> Input Class Initialized
INFO - 2021-06-29 03:40:42 --> Language Class Initialized
INFO - 2021-06-29 03:40:42 --> Language Class Initialized
INFO - 2021-06-29 03:40:42 --> Config Class Initialized
INFO - 2021-06-29 03:40:42 --> Loader Class Initialized
INFO - 2021-06-29 03:40:42 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:42 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:42 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:42 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:42 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:42 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:42 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:42 --> Total execution time: 0.1968
INFO - 2021-06-29 03:40:43 --> Config Class Initialized
INFO - 2021-06-29 03:40:43 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:43 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:43 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:43 --> URI Class Initialized
INFO - 2021-06-29 03:40:43 --> Router Class Initialized
INFO - 2021-06-29 03:40:43 --> Output Class Initialized
INFO - 2021-06-29 03:40:43 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:43 --> Input Class Initialized
INFO - 2021-06-29 03:40:43 --> Language Class Initialized
INFO - 2021-06-29 03:40:43 --> Language Class Initialized
INFO - 2021-06-29 03:40:43 --> Config Class Initialized
INFO - 2021-06-29 03:40:43 --> Loader Class Initialized
INFO - 2021-06-29 03:40:43 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:43 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:43 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:43 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:43 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:43 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:43 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:43 --> Total execution time: 0.1934
INFO - 2021-06-29 03:40:45 --> Config Class Initialized
INFO - 2021-06-29 03:40:45 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:45 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:45 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:45 --> URI Class Initialized
INFO - 2021-06-29 03:40:45 --> Router Class Initialized
INFO - 2021-06-29 03:40:45 --> Output Class Initialized
INFO - 2021-06-29 03:40:45 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:45 --> Input Class Initialized
INFO - 2021-06-29 03:40:45 --> Language Class Initialized
INFO - 2021-06-29 03:40:45 --> Language Class Initialized
INFO - 2021-06-29 03:40:45 --> Config Class Initialized
INFO - 2021-06-29 03:40:45 --> Loader Class Initialized
INFO - 2021-06-29 03:40:45 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:45 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:45 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:45 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:45 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:45 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:45 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:45 --> Total execution time: 0.1900
INFO - 2021-06-29 03:40:47 --> Config Class Initialized
INFO - 2021-06-29 03:40:47 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:47 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:47 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:47 --> URI Class Initialized
INFO - 2021-06-29 03:40:47 --> Router Class Initialized
INFO - 2021-06-29 03:40:47 --> Output Class Initialized
INFO - 2021-06-29 03:40:47 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:47 --> Input Class Initialized
INFO - 2021-06-29 03:40:47 --> Language Class Initialized
INFO - 2021-06-29 03:40:47 --> Language Class Initialized
INFO - 2021-06-29 03:40:47 --> Config Class Initialized
INFO - 2021-06-29 03:40:47 --> Loader Class Initialized
INFO - 2021-06-29 03:40:47 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:47 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:47 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:47 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:47 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:47 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:47 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:47 --> Total execution time: 0.1955
INFO - 2021-06-29 03:40:49 --> Config Class Initialized
INFO - 2021-06-29 03:40:49 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:49 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:49 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:49 --> URI Class Initialized
INFO - 2021-06-29 03:40:49 --> Router Class Initialized
INFO - 2021-06-29 03:40:49 --> Output Class Initialized
INFO - 2021-06-29 03:40:49 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:49 --> Input Class Initialized
INFO - 2021-06-29 03:40:49 --> Language Class Initialized
INFO - 2021-06-29 03:40:49 --> Language Class Initialized
INFO - 2021-06-29 03:40:49 --> Config Class Initialized
INFO - 2021-06-29 03:40:49 --> Loader Class Initialized
INFO - 2021-06-29 03:40:49 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:49 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:49 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:49 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:49 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:49 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:49 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:49 --> Total execution time: 0.1938
INFO - 2021-06-29 03:40:50 --> Config Class Initialized
INFO - 2021-06-29 03:40:50 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:50 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:50 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:50 --> URI Class Initialized
INFO - 2021-06-29 03:40:50 --> Router Class Initialized
INFO - 2021-06-29 03:40:50 --> Output Class Initialized
INFO - 2021-06-29 03:40:50 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:50 --> Input Class Initialized
INFO - 2021-06-29 03:40:50 --> Language Class Initialized
INFO - 2021-06-29 03:40:50 --> Language Class Initialized
INFO - 2021-06-29 03:40:50 --> Config Class Initialized
INFO - 2021-06-29 03:40:50 --> Loader Class Initialized
INFO - 2021-06-29 03:40:50 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:50 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:50 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:50 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:51 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:51 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:51 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:51 --> Total execution time: 0.1942
INFO - 2021-06-29 03:40:53 --> Config Class Initialized
INFO - 2021-06-29 03:40:53 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:53 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:53 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:53 --> URI Class Initialized
INFO - 2021-06-29 03:40:53 --> Router Class Initialized
INFO - 2021-06-29 03:40:53 --> Output Class Initialized
INFO - 2021-06-29 03:40:53 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:53 --> Input Class Initialized
INFO - 2021-06-29 03:40:53 --> Language Class Initialized
INFO - 2021-06-29 03:40:53 --> Language Class Initialized
INFO - 2021-06-29 03:40:53 --> Config Class Initialized
INFO - 2021-06-29 03:40:53 --> Loader Class Initialized
INFO - 2021-06-29 03:40:53 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:53 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:53 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:53 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:53 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:53 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:53 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:53 --> Total execution time: 0.1933
INFO - 2021-06-29 03:40:54 --> Config Class Initialized
INFO - 2021-06-29 03:40:54 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:54 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:54 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:54 --> URI Class Initialized
INFO - 2021-06-29 03:40:54 --> Router Class Initialized
INFO - 2021-06-29 03:40:54 --> Output Class Initialized
INFO - 2021-06-29 03:40:54 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:54 --> Input Class Initialized
INFO - 2021-06-29 03:40:54 --> Language Class Initialized
INFO - 2021-06-29 03:40:54 --> Language Class Initialized
INFO - 2021-06-29 03:40:54 --> Config Class Initialized
INFO - 2021-06-29 03:40:54 --> Loader Class Initialized
INFO - 2021-06-29 03:40:54 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:54 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:54 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:54 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:54 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:54 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:55 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:55 --> Total execution time: 0.2595
INFO - 2021-06-29 03:40:57 --> Config Class Initialized
INFO - 2021-06-29 03:40:57 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:57 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:57 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:57 --> URI Class Initialized
INFO - 2021-06-29 03:40:57 --> Router Class Initialized
INFO - 2021-06-29 03:40:57 --> Output Class Initialized
INFO - 2021-06-29 03:40:57 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:57 --> Input Class Initialized
INFO - 2021-06-29 03:40:57 --> Language Class Initialized
INFO - 2021-06-29 03:40:57 --> Language Class Initialized
INFO - 2021-06-29 03:40:57 --> Config Class Initialized
INFO - 2021-06-29 03:40:57 --> Loader Class Initialized
INFO - 2021-06-29 03:40:57 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:57 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:57 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:57 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:57 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:57 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:57 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:57 --> Total execution time: 0.1944
INFO - 2021-06-29 03:40:59 --> Config Class Initialized
INFO - 2021-06-29 03:40:59 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:40:59 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:40:59 --> Utf8 Class Initialized
INFO - 2021-06-29 03:40:59 --> URI Class Initialized
INFO - 2021-06-29 03:40:59 --> Router Class Initialized
INFO - 2021-06-29 03:40:59 --> Output Class Initialized
INFO - 2021-06-29 03:40:59 --> Security Class Initialized
DEBUG - 2021-06-29 03:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:40:59 --> Input Class Initialized
INFO - 2021-06-29 03:40:59 --> Language Class Initialized
INFO - 2021-06-29 03:40:59 --> Language Class Initialized
INFO - 2021-06-29 03:40:59 --> Config Class Initialized
INFO - 2021-06-29 03:40:59 --> Loader Class Initialized
INFO - 2021-06-29 03:40:59 --> Helper loaded: url_helper
INFO - 2021-06-29 03:40:59 --> Helper loaded: file_helper
INFO - 2021-06-29 03:40:59 --> Helper loaded: form_helper
INFO - 2021-06-29 03:40:59 --> Helper loaded: my_helper
INFO - 2021-06-29 03:40:59 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:40:59 --> Controller Class Initialized
DEBUG - 2021-06-29 03:40:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:40:59 --> Final output sent to browser
DEBUG - 2021-06-29 03:40:59 --> Total execution time: 0.2057
INFO - 2021-06-29 03:41:01 --> Config Class Initialized
INFO - 2021-06-29 03:41:01 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:01 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:01 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:01 --> URI Class Initialized
INFO - 2021-06-29 03:41:01 --> Router Class Initialized
INFO - 2021-06-29 03:41:01 --> Output Class Initialized
INFO - 2021-06-29 03:41:01 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:01 --> Input Class Initialized
INFO - 2021-06-29 03:41:01 --> Language Class Initialized
INFO - 2021-06-29 03:41:01 --> Language Class Initialized
INFO - 2021-06-29 03:41:01 --> Config Class Initialized
INFO - 2021-06-29 03:41:01 --> Loader Class Initialized
INFO - 2021-06-29 03:41:01 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:01 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:01 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:01 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:01 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:01 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:02 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:02 --> Total execution time: 0.2180
INFO - 2021-06-29 03:41:05 --> Config Class Initialized
INFO - 2021-06-29 03:41:05 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:05 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:05 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:05 --> URI Class Initialized
INFO - 2021-06-29 03:41:05 --> Router Class Initialized
INFO - 2021-06-29 03:41:05 --> Output Class Initialized
INFO - 2021-06-29 03:41:05 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:05 --> Input Class Initialized
INFO - 2021-06-29 03:41:05 --> Language Class Initialized
INFO - 2021-06-29 03:41:05 --> Language Class Initialized
INFO - 2021-06-29 03:41:05 --> Config Class Initialized
INFO - 2021-06-29 03:41:05 --> Loader Class Initialized
INFO - 2021-06-29 03:41:05 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:05 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:05 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:05 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:05 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:05 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:05 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:05 --> Total execution time: 0.1953
INFO - 2021-06-29 03:41:07 --> Config Class Initialized
INFO - 2021-06-29 03:41:07 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:07 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:07 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:07 --> URI Class Initialized
INFO - 2021-06-29 03:41:07 --> Router Class Initialized
INFO - 2021-06-29 03:41:07 --> Output Class Initialized
INFO - 2021-06-29 03:41:07 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:07 --> Input Class Initialized
INFO - 2021-06-29 03:41:07 --> Language Class Initialized
INFO - 2021-06-29 03:41:07 --> Language Class Initialized
INFO - 2021-06-29 03:41:07 --> Config Class Initialized
INFO - 2021-06-29 03:41:07 --> Loader Class Initialized
INFO - 2021-06-29 03:41:07 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:07 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:07 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:07 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:07 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:07 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:07 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:07 --> Total execution time: 0.1939
INFO - 2021-06-29 03:41:09 --> Config Class Initialized
INFO - 2021-06-29 03:41:09 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:09 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:09 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:09 --> URI Class Initialized
INFO - 2021-06-29 03:41:09 --> Router Class Initialized
INFO - 2021-06-29 03:41:09 --> Output Class Initialized
INFO - 2021-06-29 03:41:09 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:09 --> Input Class Initialized
INFO - 2021-06-29 03:41:09 --> Language Class Initialized
INFO - 2021-06-29 03:41:09 --> Language Class Initialized
INFO - 2021-06-29 03:41:09 --> Config Class Initialized
INFO - 2021-06-29 03:41:09 --> Loader Class Initialized
INFO - 2021-06-29 03:41:09 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:09 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:09 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:09 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:09 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:09 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:09 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:09 --> Total execution time: 0.1947
INFO - 2021-06-29 03:41:12 --> Config Class Initialized
INFO - 2021-06-29 03:41:12 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:12 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:12 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:12 --> URI Class Initialized
INFO - 2021-06-29 03:41:12 --> Router Class Initialized
INFO - 2021-06-29 03:41:12 --> Output Class Initialized
INFO - 2021-06-29 03:41:12 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:12 --> Input Class Initialized
INFO - 2021-06-29 03:41:12 --> Language Class Initialized
INFO - 2021-06-29 03:41:12 --> Language Class Initialized
INFO - 2021-06-29 03:41:12 --> Config Class Initialized
INFO - 2021-06-29 03:41:12 --> Loader Class Initialized
INFO - 2021-06-29 03:41:12 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:12 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:12 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:12 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:12 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:12 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:12 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:12 --> Total execution time: 0.1937
INFO - 2021-06-29 03:41:15 --> Config Class Initialized
INFO - 2021-06-29 03:41:15 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:15 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:15 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:15 --> URI Class Initialized
INFO - 2021-06-29 03:41:15 --> Router Class Initialized
INFO - 2021-06-29 03:41:15 --> Output Class Initialized
INFO - 2021-06-29 03:41:15 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:15 --> Input Class Initialized
INFO - 2021-06-29 03:41:15 --> Language Class Initialized
INFO - 2021-06-29 03:41:15 --> Language Class Initialized
INFO - 2021-06-29 03:41:15 --> Config Class Initialized
INFO - 2021-06-29 03:41:15 --> Loader Class Initialized
INFO - 2021-06-29 03:41:15 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:15 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:15 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:15 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:15 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:15 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:15 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:15 --> Total execution time: 0.1936
INFO - 2021-06-29 03:41:18 --> Config Class Initialized
INFO - 2021-06-29 03:41:18 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:18 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:18 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:18 --> URI Class Initialized
INFO - 2021-06-29 03:41:18 --> Router Class Initialized
INFO - 2021-06-29 03:41:18 --> Output Class Initialized
INFO - 2021-06-29 03:41:18 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:18 --> Input Class Initialized
INFO - 2021-06-29 03:41:18 --> Language Class Initialized
INFO - 2021-06-29 03:41:18 --> Language Class Initialized
INFO - 2021-06-29 03:41:18 --> Config Class Initialized
INFO - 2021-06-29 03:41:18 --> Loader Class Initialized
INFO - 2021-06-29 03:41:18 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:18 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:18 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:18 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:18 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:18 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:18 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:18 --> Total execution time: 0.1903
INFO - 2021-06-29 03:41:20 --> Config Class Initialized
INFO - 2021-06-29 03:41:20 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:20 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:20 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:20 --> URI Class Initialized
INFO - 2021-06-29 03:41:20 --> Router Class Initialized
INFO - 2021-06-29 03:41:20 --> Output Class Initialized
INFO - 2021-06-29 03:41:20 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:20 --> Input Class Initialized
INFO - 2021-06-29 03:41:20 --> Language Class Initialized
INFO - 2021-06-29 03:41:20 --> Language Class Initialized
INFO - 2021-06-29 03:41:20 --> Config Class Initialized
INFO - 2021-06-29 03:41:20 --> Loader Class Initialized
INFO - 2021-06-29 03:41:20 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:20 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:20 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:20 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:20 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:20 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:20 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:20 --> Total execution time: 0.1915
INFO - 2021-06-29 03:41:22 --> Config Class Initialized
INFO - 2021-06-29 03:41:22 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:22 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:22 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:22 --> URI Class Initialized
INFO - 2021-06-29 03:41:22 --> Router Class Initialized
INFO - 2021-06-29 03:41:22 --> Output Class Initialized
INFO - 2021-06-29 03:41:22 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:22 --> Input Class Initialized
INFO - 2021-06-29 03:41:22 --> Language Class Initialized
INFO - 2021-06-29 03:41:22 --> Language Class Initialized
INFO - 2021-06-29 03:41:22 --> Config Class Initialized
INFO - 2021-06-29 03:41:22 --> Loader Class Initialized
INFO - 2021-06-29 03:41:22 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:22 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:22 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:22 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:22 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:22 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:22 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:22 --> Total execution time: 0.1931
INFO - 2021-06-29 03:41:24 --> Config Class Initialized
INFO - 2021-06-29 03:41:24 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:24 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:24 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:24 --> URI Class Initialized
INFO - 2021-06-29 03:41:24 --> Router Class Initialized
INFO - 2021-06-29 03:41:24 --> Output Class Initialized
INFO - 2021-06-29 03:41:24 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:24 --> Input Class Initialized
INFO - 2021-06-29 03:41:24 --> Language Class Initialized
INFO - 2021-06-29 03:41:24 --> Language Class Initialized
INFO - 2021-06-29 03:41:24 --> Config Class Initialized
INFO - 2021-06-29 03:41:24 --> Loader Class Initialized
INFO - 2021-06-29 03:41:24 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:24 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:24 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:24 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:24 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:24 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:24 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:24 --> Total execution time: 0.1869
INFO - 2021-06-29 03:41:26 --> Config Class Initialized
INFO - 2021-06-29 03:41:26 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:26 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:26 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:26 --> URI Class Initialized
INFO - 2021-06-29 03:41:26 --> Router Class Initialized
INFO - 2021-06-29 03:41:26 --> Output Class Initialized
INFO - 2021-06-29 03:41:26 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:26 --> Input Class Initialized
INFO - 2021-06-29 03:41:26 --> Language Class Initialized
INFO - 2021-06-29 03:41:26 --> Language Class Initialized
INFO - 2021-06-29 03:41:26 --> Config Class Initialized
INFO - 2021-06-29 03:41:26 --> Loader Class Initialized
INFO - 2021-06-29 03:41:26 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:26 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:26 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:26 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:26 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:26 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:26 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:26 --> Total execution time: 0.1964
INFO - 2021-06-29 03:41:28 --> Config Class Initialized
INFO - 2021-06-29 03:41:28 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:28 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:28 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:28 --> URI Class Initialized
INFO - 2021-06-29 03:41:28 --> Router Class Initialized
INFO - 2021-06-29 03:41:28 --> Output Class Initialized
INFO - 2021-06-29 03:41:28 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:28 --> Input Class Initialized
INFO - 2021-06-29 03:41:28 --> Language Class Initialized
INFO - 2021-06-29 03:41:28 --> Language Class Initialized
INFO - 2021-06-29 03:41:28 --> Config Class Initialized
INFO - 2021-06-29 03:41:28 --> Loader Class Initialized
INFO - 2021-06-29 03:41:28 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:28 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:28 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:28 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:28 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:28 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:28 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:28 --> Total execution time: 0.1929
INFO - 2021-06-29 03:41:30 --> Config Class Initialized
INFO - 2021-06-29 03:41:30 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:30 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:30 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:30 --> URI Class Initialized
INFO - 2021-06-29 03:41:30 --> Router Class Initialized
INFO - 2021-06-29 03:41:30 --> Output Class Initialized
INFO - 2021-06-29 03:41:30 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:30 --> Input Class Initialized
INFO - 2021-06-29 03:41:30 --> Language Class Initialized
INFO - 2021-06-29 03:41:30 --> Language Class Initialized
INFO - 2021-06-29 03:41:30 --> Config Class Initialized
INFO - 2021-06-29 03:41:30 --> Loader Class Initialized
INFO - 2021-06-29 03:41:30 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:30 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:30 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:30 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:30 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:30 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:30 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:30 --> Total execution time: 0.1971
INFO - 2021-06-29 03:41:31 --> Config Class Initialized
INFO - 2021-06-29 03:41:31 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:41:31 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:41:31 --> Utf8 Class Initialized
INFO - 2021-06-29 03:41:31 --> URI Class Initialized
INFO - 2021-06-29 03:41:31 --> Router Class Initialized
INFO - 2021-06-29 03:41:31 --> Output Class Initialized
INFO - 2021-06-29 03:41:31 --> Security Class Initialized
DEBUG - 2021-06-29 03:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:41:31 --> Input Class Initialized
INFO - 2021-06-29 03:41:31 --> Language Class Initialized
INFO - 2021-06-29 03:41:31 --> Language Class Initialized
INFO - 2021-06-29 03:41:32 --> Config Class Initialized
INFO - 2021-06-29 03:41:32 --> Loader Class Initialized
INFO - 2021-06-29 03:41:32 --> Helper loaded: url_helper
INFO - 2021-06-29 03:41:32 --> Helper loaded: file_helper
INFO - 2021-06-29 03:41:32 --> Helper loaded: form_helper
INFO - 2021-06-29 03:41:32 --> Helper loaded: my_helper
INFO - 2021-06-29 03:41:32 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:41:32 --> Controller Class Initialized
DEBUG - 2021-06-29 03:41:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:41:32 --> Final output sent to browser
DEBUG - 2021-06-29 03:41:32 --> Total execution time: 0.2072
INFO - 2021-06-29 03:47:14 --> Config Class Initialized
INFO - 2021-06-29 03:47:14 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:47:14 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:47:14 --> Utf8 Class Initialized
INFO - 2021-06-29 03:47:14 --> URI Class Initialized
INFO - 2021-06-29 03:47:14 --> Router Class Initialized
INFO - 2021-06-29 03:47:14 --> Output Class Initialized
INFO - 2021-06-29 03:47:14 --> Security Class Initialized
DEBUG - 2021-06-29 03:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:47:14 --> Input Class Initialized
INFO - 2021-06-29 03:47:14 --> Language Class Initialized
INFO - 2021-06-29 03:47:14 --> Language Class Initialized
INFO - 2021-06-29 03:47:14 --> Config Class Initialized
INFO - 2021-06-29 03:47:14 --> Loader Class Initialized
INFO - 2021-06-29 03:47:14 --> Helper loaded: url_helper
INFO - 2021-06-29 03:47:14 --> Helper loaded: file_helper
INFO - 2021-06-29 03:47:14 --> Helper loaded: form_helper
INFO - 2021-06-29 03:47:14 --> Helper loaded: my_helper
INFO - 2021-06-29 03:47:14 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:47:14 --> Controller Class Initialized
INFO - 2021-06-29 03:47:14 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:47:14 --> Config Class Initialized
INFO - 2021-06-29 03:47:14 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:47:14 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:47:14 --> Utf8 Class Initialized
INFO - 2021-06-29 03:47:14 --> URI Class Initialized
INFO - 2021-06-29 03:47:14 --> Router Class Initialized
INFO - 2021-06-29 03:47:14 --> Output Class Initialized
INFO - 2021-06-29 03:47:14 --> Security Class Initialized
DEBUG - 2021-06-29 03:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:47:14 --> Input Class Initialized
INFO - 2021-06-29 03:47:14 --> Language Class Initialized
INFO - 2021-06-29 03:47:14 --> Language Class Initialized
INFO - 2021-06-29 03:47:14 --> Config Class Initialized
INFO - 2021-06-29 03:47:14 --> Loader Class Initialized
INFO - 2021-06-29 03:47:14 --> Helper loaded: url_helper
INFO - 2021-06-29 03:47:14 --> Helper loaded: file_helper
INFO - 2021-06-29 03:47:14 --> Helper loaded: form_helper
INFO - 2021-06-29 03:47:14 --> Helper loaded: my_helper
INFO - 2021-06-29 03:47:14 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:47:14 --> Controller Class Initialized
DEBUG - 2021-06-29 03:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 03:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:47:14 --> Final output sent to browser
DEBUG - 2021-06-29 03:47:14 --> Total execution time: 0.0494
INFO - 2021-06-29 03:47:19 --> Config Class Initialized
INFO - 2021-06-29 03:47:19 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:47:19 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:47:19 --> Utf8 Class Initialized
INFO - 2021-06-29 03:47:19 --> URI Class Initialized
INFO - 2021-06-29 03:47:19 --> Router Class Initialized
INFO - 2021-06-29 03:47:19 --> Output Class Initialized
INFO - 2021-06-29 03:47:19 --> Security Class Initialized
DEBUG - 2021-06-29 03:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:47:19 --> Input Class Initialized
INFO - 2021-06-29 03:47:19 --> Language Class Initialized
INFO - 2021-06-29 03:47:19 --> Language Class Initialized
INFO - 2021-06-29 03:47:19 --> Config Class Initialized
INFO - 2021-06-29 03:47:19 --> Loader Class Initialized
INFO - 2021-06-29 03:47:19 --> Helper loaded: url_helper
INFO - 2021-06-29 03:47:19 --> Helper loaded: file_helper
INFO - 2021-06-29 03:47:19 --> Helper loaded: form_helper
INFO - 2021-06-29 03:47:19 --> Helper loaded: my_helper
INFO - 2021-06-29 03:47:19 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:47:19 --> Controller Class Initialized
INFO - 2021-06-29 03:47:19 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:47:19 --> Final output sent to browser
DEBUG - 2021-06-29 03:47:19 --> Total execution time: 0.0560
INFO - 2021-06-29 03:47:19 --> Config Class Initialized
INFO - 2021-06-29 03:47:19 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:47:19 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:47:19 --> Utf8 Class Initialized
INFO - 2021-06-29 03:47:19 --> URI Class Initialized
INFO - 2021-06-29 03:47:19 --> Router Class Initialized
INFO - 2021-06-29 03:47:19 --> Output Class Initialized
INFO - 2021-06-29 03:47:19 --> Security Class Initialized
DEBUG - 2021-06-29 03:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:47:19 --> Input Class Initialized
INFO - 2021-06-29 03:47:19 --> Language Class Initialized
INFO - 2021-06-29 03:47:19 --> Language Class Initialized
INFO - 2021-06-29 03:47:19 --> Config Class Initialized
INFO - 2021-06-29 03:47:19 --> Loader Class Initialized
INFO - 2021-06-29 03:47:19 --> Helper loaded: url_helper
INFO - 2021-06-29 03:47:19 --> Helper loaded: file_helper
INFO - 2021-06-29 03:47:19 --> Helper loaded: form_helper
INFO - 2021-06-29 03:47:19 --> Helper loaded: my_helper
INFO - 2021-06-29 03:47:19 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:47:19 --> Controller Class Initialized
DEBUG - 2021-06-29 03:47:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-29 03:47:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:47:20 --> Final output sent to browser
DEBUG - 2021-06-29 03:47:20 --> Total execution time: 0.6568
INFO - 2021-06-29 03:47:25 --> Config Class Initialized
INFO - 2021-06-29 03:47:25 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:47:25 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:47:25 --> Utf8 Class Initialized
INFO - 2021-06-29 03:47:25 --> URI Class Initialized
INFO - 2021-06-29 03:47:25 --> Router Class Initialized
INFO - 2021-06-29 03:47:25 --> Output Class Initialized
INFO - 2021-06-29 03:47:25 --> Security Class Initialized
DEBUG - 2021-06-29 03:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:47:25 --> Input Class Initialized
INFO - 2021-06-29 03:47:25 --> Language Class Initialized
INFO - 2021-06-29 03:47:25 --> Language Class Initialized
INFO - 2021-06-29 03:47:25 --> Config Class Initialized
INFO - 2021-06-29 03:47:25 --> Loader Class Initialized
INFO - 2021-06-29 03:47:25 --> Helper loaded: url_helper
INFO - 2021-06-29 03:47:25 --> Helper loaded: file_helper
INFO - 2021-06-29 03:47:25 --> Helper loaded: form_helper
INFO - 2021-06-29 03:47:25 --> Helper loaded: my_helper
INFO - 2021-06-29 03:47:25 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:47:25 --> Controller Class Initialized
DEBUG - 2021-06-29 03:47:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-06-29 03:47:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:47:25 --> Final output sent to browser
DEBUG - 2021-06-29 03:47:25 --> Total execution time: 0.0602
INFO - 2021-06-29 03:47:33 --> Config Class Initialized
INFO - 2021-06-29 03:47:33 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:47:33 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:47:33 --> Utf8 Class Initialized
INFO - 2021-06-29 03:47:33 --> URI Class Initialized
INFO - 2021-06-29 03:47:33 --> Router Class Initialized
INFO - 2021-06-29 03:47:33 --> Output Class Initialized
INFO - 2021-06-29 03:47:33 --> Security Class Initialized
DEBUG - 2021-06-29 03:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:47:33 --> Input Class Initialized
INFO - 2021-06-29 03:47:33 --> Language Class Initialized
INFO - 2021-06-29 03:47:33 --> Language Class Initialized
INFO - 2021-06-29 03:47:33 --> Config Class Initialized
INFO - 2021-06-29 03:47:33 --> Loader Class Initialized
INFO - 2021-06-29 03:47:33 --> Helper loaded: url_helper
INFO - 2021-06-29 03:47:33 --> Helper loaded: file_helper
INFO - 2021-06-29 03:47:33 --> Helper loaded: form_helper
INFO - 2021-06-29 03:47:33 --> Helper loaded: my_helper
INFO - 2021-06-29 03:47:33 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:47:33 --> Controller Class Initialized
DEBUG - 2021-06-29 03:47:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-06-29 03:47:33 --> Final output sent to browser
DEBUG - 2021-06-29 03:47:33 --> Total execution time: 0.3491
INFO - 2021-06-29 03:48:07 --> Config Class Initialized
INFO - 2021-06-29 03:48:07 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:48:07 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:48:07 --> Utf8 Class Initialized
INFO - 2021-06-29 03:48:07 --> URI Class Initialized
INFO - 2021-06-29 03:48:07 --> Router Class Initialized
INFO - 2021-06-29 03:48:07 --> Output Class Initialized
INFO - 2021-06-29 03:48:07 --> Security Class Initialized
DEBUG - 2021-06-29 03:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:48:07 --> Input Class Initialized
INFO - 2021-06-29 03:48:07 --> Language Class Initialized
INFO - 2021-06-29 03:48:07 --> Language Class Initialized
INFO - 2021-06-29 03:48:07 --> Config Class Initialized
INFO - 2021-06-29 03:48:07 --> Loader Class Initialized
INFO - 2021-06-29 03:48:07 --> Helper loaded: url_helper
INFO - 2021-06-29 03:48:07 --> Helper loaded: file_helper
INFO - 2021-06-29 03:48:07 --> Helper loaded: form_helper
INFO - 2021-06-29 03:48:07 --> Helper loaded: my_helper
INFO - 2021-06-29 03:48:07 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:48:07 --> Controller Class Initialized
DEBUG - 2021-06-29 03:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-29 03:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:48:07 --> Final output sent to browser
DEBUG - 2021-06-29 03:48:07 --> Total execution time: 0.0604
INFO - 2021-06-29 03:48:24 --> Config Class Initialized
INFO - 2021-06-29 03:48:24 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:48:24 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:48:24 --> Utf8 Class Initialized
INFO - 2021-06-29 03:48:24 --> URI Class Initialized
INFO - 2021-06-29 03:48:24 --> Router Class Initialized
INFO - 2021-06-29 03:48:24 --> Output Class Initialized
INFO - 2021-06-29 03:48:24 --> Security Class Initialized
DEBUG - 2021-06-29 03:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:48:24 --> Input Class Initialized
INFO - 2021-06-29 03:48:24 --> Language Class Initialized
INFO - 2021-06-29 03:48:24 --> Language Class Initialized
INFO - 2021-06-29 03:48:24 --> Config Class Initialized
INFO - 2021-06-29 03:48:24 --> Loader Class Initialized
INFO - 2021-06-29 03:48:24 --> Helper loaded: url_helper
INFO - 2021-06-29 03:48:24 --> Helper loaded: file_helper
INFO - 2021-06-29 03:48:24 --> Helper loaded: form_helper
INFO - 2021-06-29 03:48:24 --> Helper loaded: my_helper
INFO - 2021-06-29 03:48:24 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:48:24 --> Controller Class Initialized
DEBUG - 2021-06-29 03:48:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:48:24 --> Final output sent to browser
DEBUG - 2021-06-29 03:48:24 --> Total execution time: 0.2450
INFO - 2021-06-29 03:49:00 --> Config Class Initialized
INFO - 2021-06-29 03:49:00 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:49:00 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:49:00 --> Utf8 Class Initialized
INFO - 2021-06-29 03:49:00 --> URI Class Initialized
INFO - 2021-06-29 03:49:00 --> Router Class Initialized
INFO - 2021-06-29 03:49:00 --> Output Class Initialized
INFO - 2021-06-29 03:49:00 --> Security Class Initialized
DEBUG - 2021-06-29 03:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:49:00 --> Input Class Initialized
INFO - 2021-06-29 03:49:00 --> Language Class Initialized
INFO - 2021-06-29 03:49:00 --> Language Class Initialized
INFO - 2021-06-29 03:49:00 --> Config Class Initialized
INFO - 2021-06-29 03:49:00 --> Loader Class Initialized
INFO - 2021-06-29 03:49:00 --> Helper loaded: url_helper
INFO - 2021-06-29 03:49:00 --> Helper loaded: file_helper
INFO - 2021-06-29 03:49:00 --> Helper loaded: form_helper
INFO - 2021-06-29 03:49:00 --> Helper loaded: my_helper
INFO - 2021-06-29 03:49:00 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:49:00 --> Controller Class Initialized
DEBUG - 2021-06-29 03:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:49:00 --> Final output sent to browser
DEBUG - 2021-06-29 03:49:00 --> Total execution time: 0.1907
INFO - 2021-06-29 03:49:01 --> Config Class Initialized
INFO - 2021-06-29 03:49:01 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:49:01 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:49:01 --> Utf8 Class Initialized
INFO - 2021-06-29 03:49:01 --> URI Class Initialized
INFO - 2021-06-29 03:49:01 --> Router Class Initialized
INFO - 2021-06-29 03:49:01 --> Output Class Initialized
INFO - 2021-06-29 03:49:01 --> Security Class Initialized
DEBUG - 2021-06-29 03:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:49:01 --> Input Class Initialized
INFO - 2021-06-29 03:49:01 --> Language Class Initialized
INFO - 2021-06-29 03:49:01 --> Language Class Initialized
INFO - 2021-06-29 03:49:01 --> Config Class Initialized
INFO - 2021-06-29 03:49:01 --> Loader Class Initialized
INFO - 2021-06-29 03:49:01 --> Helper loaded: url_helper
INFO - 2021-06-29 03:49:01 --> Helper loaded: file_helper
INFO - 2021-06-29 03:49:01 --> Helper loaded: form_helper
INFO - 2021-06-29 03:49:01 --> Helper loaded: my_helper
INFO - 2021-06-29 03:49:01 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:49:01 --> Controller Class Initialized
DEBUG - 2021-06-29 03:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:49:01 --> Final output sent to browser
DEBUG - 2021-06-29 03:49:01 --> Total execution time: 0.1904
INFO - 2021-06-29 03:50:46 --> Config Class Initialized
INFO - 2021-06-29 03:50:46 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:50:46 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:50:46 --> Utf8 Class Initialized
INFO - 2021-06-29 03:50:46 --> URI Class Initialized
INFO - 2021-06-29 03:50:46 --> Router Class Initialized
INFO - 2021-06-29 03:50:46 --> Output Class Initialized
INFO - 2021-06-29 03:50:46 --> Security Class Initialized
DEBUG - 2021-06-29 03:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:50:46 --> Input Class Initialized
INFO - 2021-06-29 03:50:46 --> Language Class Initialized
INFO - 2021-06-29 03:50:46 --> Language Class Initialized
INFO - 2021-06-29 03:50:46 --> Config Class Initialized
INFO - 2021-06-29 03:50:46 --> Loader Class Initialized
INFO - 2021-06-29 03:50:46 --> Helper loaded: url_helper
INFO - 2021-06-29 03:50:46 --> Helper loaded: file_helper
INFO - 2021-06-29 03:50:46 --> Helper loaded: form_helper
INFO - 2021-06-29 03:50:46 --> Helper loaded: my_helper
INFO - 2021-06-29 03:50:46 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:50:46 --> Controller Class Initialized
DEBUG - 2021-06-29 03:50:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-06-29 03:50:46 --> Final output sent to browser
DEBUG - 2021-06-29 03:50:46 --> Total execution time: 0.2204
INFO - 2021-06-29 03:52:14 --> Config Class Initialized
INFO - 2021-06-29 03:52:14 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:52:14 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:52:14 --> Utf8 Class Initialized
INFO - 2021-06-29 03:52:14 --> URI Class Initialized
INFO - 2021-06-29 03:52:14 --> Router Class Initialized
INFO - 2021-06-29 03:52:14 --> Output Class Initialized
INFO - 2021-06-29 03:52:14 --> Security Class Initialized
DEBUG - 2021-06-29 03:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:52:14 --> Input Class Initialized
INFO - 2021-06-29 03:52:14 --> Language Class Initialized
INFO - 2021-06-29 03:52:14 --> Language Class Initialized
INFO - 2021-06-29 03:52:14 --> Config Class Initialized
INFO - 2021-06-29 03:52:14 --> Loader Class Initialized
INFO - 2021-06-29 03:52:14 --> Helper loaded: url_helper
INFO - 2021-06-29 03:52:14 --> Helper loaded: file_helper
INFO - 2021-06-29 03:52:14 --> Helper loaded: form_helper
INFO - 2021-06-29 03:52:14 --> Helper loaded: my_helper
INFO - 2021-06-29 03:52:14 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:52:14 --> Controller Class Initialized
INFO - 2021-06-29 03:52:14 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:52:14 --> Config Class Initialized
INFO - 2021-06-29 03:52:14 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:52:14 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:52:14 --> Utf8 Class Initialized
INFO - 2021-06-29 03:52:14 --> URI Class Initialized
INFO - 2021-06-29 03:52:14 --> Router Class Initialized
INFO - 2021-06-29 03:52:14 --> Output Class Initialized
INFO - 2021-06-29 03:52:14 --> Security Class Initialized
DEBUG - 2021-06-29 03:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:52:14 --> Input Class Initialized
INFO - 2021-06-29 03:52:14 --> Language Class Initialized
INFO - 2021-06-29 03:52:14 --> Language Class Initialized
INFO - 2021-06-29 03:52:14 --> Config Class Initialized
INFO - 2021-06-29 03:52:14 --> Loader Class Initialized
INFO - 2021-06-29 03:52:14 --> Helper loaded: url_helper
INFO - 2021-06-29 03:52:14 --> Helper loaded: file_helper
INFO - 2021-06-29 03:52:14 --> Helper loaded: form_helper
INFO - 2021-06-29 03:52:14 --> Helper loaded: my_helper
INFO - 2021-06-29 03:52:14 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:52:14 --> Controller Class Initialized
DEBUG - 2021-06-29 03:52:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 03:52:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:52:14 --> Final output sent to browser
DEBUG - 2021-06-29 03:52:14 --> Total execution time: 0.0398
INFO - 2021-06-29 03:52:20 --> Config Class Initialized
INFO - 2021-06-29 03:52:20 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:52:20 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:52:20 --> Utf8 Class Initialized
INFO - 2021-06-29 03:52:20 --> URI Class Initialized
INFO - 2021-06-29 03:52:20 --> Router Class Initialized
INFO - 2021-06-29 03:52:20 --> Output Class Initialized
INFO - 2021-06-29 03:52:20 --> Security Class Initialized
DEBUG - 2021-06-29 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:52:20 --> Input Class Initialized
INFO - 2021-06-29 03:52:20 --> Language Class Initialized
INFO - 2021-06-29 03:52:20 --> Language Class Initialized
INFO - 2021-06-29 03:52:20 --> Config Class Initialized
INFO - 2021-06-29 03:52:20 --> Loader Class Initialized
INFO - 2021-06-29 03:52:20 --> Helper loaded: url_helper
INFO - 2021-06-29 03:52:20 --> Helper loaded: file_helper
INFO - 2021-06-29 03:52:20 --> Helper loaded: form_helper
INFO - 2021-06-29 03:52:20 --> Helper loaded: my_helper
INFO - 2021-06-29 03:52:20 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:52:20 --> Controller Class Initialized
INFO - 2021-06-29 03:52:20 --> Final output sent to browser
DEBUG - 2021-06-29 03:52:20 --> Total execution time: 0.0516
INFO - 2021-06-29 03:52:24 --> Config Class Initialized
INFO - 2021-06-29 03:52:24 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:52:24 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:52:24 --> Utf8 Class Initialized
INFO - 2021-06-29 03:52:24 --> URI Class Initialized
INFO - 2021-06-29 03:52:24 --> Router Class Initialized
INFO - 2021-06-29 03:52:24 --> Output Class Initialized
INFO - 2021-06-29 03:52:24 --> Security Class Initialized
DEBUG - 2021-06-29 03:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:52:24 --> Input Class Initialized
INFO - 2021-06-29 03:52:24 --> Language Class Initialized
INFO - 2021-06-29 03:52:24 --> Language Class Initialized
INFO - 2021-06-29 03:52:24 --> Config Class Initialized
INFO - 2021-06-29 03:52:24 --> Loader Class Initialized
INFO - 2021-06-29 03:52:24 --> Helper loaded: url_helper
INFO - 2021-06-29 03:52:24 --> Helper loaded: file_helper
INFO - 2021-06-29 03:52:24 --> Helper loaded: form_helper
INFO - 2021-06-29 03:52:24 --> Helper loaded: my_helper
INFO - 2021-06-29 03:52:24 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:52:24 --> Controller Class Initialized
INFO - 2021-06-29 03:52:24 --> Helper loaded: cookie_helper
INFO - 2021-06-29 03:52:24 --> Final output sent to browser
DEBUG - 2021-06-29 03:52:24 --> Total execution time: 0.0438
INFO - 2021-06-29 03:52:24 --> Config Class Initialized
INFO - 2021-06-29 03:52:24 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:52:24 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:52:24 --> Utf8 Class Initialized
INFO - 2021-06-29 03:52:24 --> URI Class Initialized
INFO - 2021-06-29 03:52:24 --> Router Class Initialized
INFO - 2021-06-29 03:52:24 --> Output Class Initialized
INFO - 2021-06-29 03:52:24 --> Security Class Initialized
DEBUG - 2021-06-29 03:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:52:24 --> Input Class Initialized
INFO - 2021-06-29 03:52:25 --> Language Class Initialized
INFO - 2021-06-29 03:52:25 --> Language Class Initialized
INFO - 2021-06-29 03:52:25 --> Config Class Initialized
INFO - 2021-06-29 03:52:25 --> Loader Class Initialized
INFO - 2021-06-29 03:52:25 --> Helper loaded: url_helper
INFO - 2021-06-29 03:52:25 --> Helper loaded: file_helper
INFO - 2021-06-29 03:52:25 --> Helper loaded: form_helper
INFO - 2021-06-29 03:52:25 --> Helper loaded: my_helper
INFO - 2021-06-29 03:52:25 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:52:25 --> Controller Class Initialized
DEBUG - 2021-06-29 03:52:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-29 03:52:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:52:25 --> Final output sent to browser
DEBUG - 2021-06-29 03:52:25 --> Total execution time: 0.6579
INFO - 2021-06-29 03:52:35 --> Config Class Initialized
INFO - 2021-06-29 03:52:35 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:52:35 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:52:35 --> Utf8 Class Initialized
INFO - 2021-06-29 03:52:35 --> URI Class Initialized
INFO - 2021-06-29 03:52:35 --> Router Class Initialized
INFO - 2021-06-29 03:52:35 --> Output Class Initialized
INFO - 2021-06-29 03:52:35 --> Security Class Initialized
DEBUG - 2021-06-29 03:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:52:35 --> Input Class Initialized
INFO - 2021-06-29 03:52:35 --> Language Class Initialized
INFO - 2021-06-29 03:52:35 --> Language Class Initialized
INFO - 2021-06-29 03:52:35 --> Config Class Initialized
INFO - 2021-06-29 03:52:35 --> Loader Class Initialized
INFO - 2021-06-29 03:52:35 --> Helper loaded: url_helper
INFO - 2021-06-29 03:52:35 --> Helper loaded: file_helper
INFO - 2021-06-29 03:52:35 --> Helper loaded: form_helper
INFO - 2021-06-29 03:52:35 --> Helper loaded: my_helper
INFO - 2021-06-29 03:52:35 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:52:35 --> Controller Class Initialized
DEBUG - 2021-06-29 03:52:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-29 03:52:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 03:52:35 --> Final output sent to browser
DEBUG - 2021-06-29 03:52:35 --> Total execution time: 0.0606
INFO - 2021-06-29 03:56:33 --> Config Class Initialized
INFO - 2021-06-29 03:56:33 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:56:33 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:56:33 --> Utf8 Class Initialized
INFO - 2021-06-29 03:56:33 --> URI Class Initialized
INFO - 2021-06-29 03:56:33 --> Router Class Initialized
INFO - 2021-06-29 03:56:33 --> Output Class Initialized
INFO - 2021-06-29 03:56:33 --> Security Class Initialized
DEBUG - 2021-06-29 03:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:56:33 --> Input Class Initialized
INFO - 2021-06-29 03:56:33 --> Language Class Initialized
INFO - 2021-06-29 03:56:33 --> Language Class Initialized
INFO - 2021-06-29 03:56:33 --> Config Class Initialized
INFO - 2021-06-29 03:56:33 --> Loader Class Initialized
INFO - 2021-06-29 03:56:33 --> Helper loaded: url_helper
INFO - 2021-06-29 03:56:33 --> Helper loaded: file_helper
INFO - 2021-06-29 03:56:33 --> Helper loaded: form_helper
INFO - 2021-06-29 03:56:33 --> Helper loaded: my_helper
INFO - 2021-06-29 03:56:33 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:56:33 --> Controller Class Initialized
DEBUG - 2021-06-29 03:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:56:33 --> Final output sent to browser
DEBUG - 2021-06-29 03:56:33 --> Total execution time: 0.0467
INFO - 2021-06-29 03:59:02 --> Config Class Initialized
INFO - 2021-06-29 03:59:02 --> Hooks Class Initialized
DEBUG - 2021-06-29 03:59:02 --> UTF-8 Support Enabled
INFO - 2021-06-29 03:59:02 --> Utf8 Class Initialized
INFO - 2021-06-29 03:59:02 --> URI Class Initialized
INFO - 2021-06-29 03:59:02 --> Router Class Initialized
INFO - 2021-06-29 03:59:02 --> Output Class Initialized
INFO - 2021-06-29 03:59:02 --> Security Class Initialized
DEBUG - 2021-06-29 03:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 03:59:02 --> Input Class Initialized
INFO - 2021-06-29 03:59:02 --> Language Class Initialized
INFO - 2021-06-29 03:59:02 --> Language Class Initialized
INFO - 2021-06-29 03:59:02 --> Config Class Initialized
INFO - 2021-06-29 03:59:02 --> Loader Class Initialized
INFO - 2021-06-29 03:59:02 --> Helper loaded: url_helper
INFO - 2021-06-29 03:59:02 --> Helper loaded: file_helper
INFO - 2021-06-29 03:59:02 --> Helper loaded: form_helper
INFO - 2021-06-29 03:59:02 --> Helper loaded: my_helper
INFO - 2021-06-29 03:59:02 --> Database Driver Class Initialized
DEBUG - 2021-06-29 03:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 03:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 03:59:02 --> Controller Class Initialized
DEBUG - 2021-06-29 03:59:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 03:59:02 --> Final output sent to browser
DEBUG - 2021-06-29 03:59:02 --> Total execution time: 0.0463
INFO - 2021-06-29 04:00:04 --> Config Class Initialized
INFO - 2021-06-29 04:00:04 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:00:04 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:00:04 --> Utf8 Class Initialized
INFO - 2021-06-29 04:00:04 --> URI Class Initialized
INFO - 2021-06-29 04:00:04 --> Router Class Initialized
INFO - 2021-06-29 04:00:04 --> Output Class Initialized
INFO - 2021-06-29 04:00:04 --> Security Class Initialized
DEBUG - 2021-06-29 04:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:00:04 --> Input Class Initialized
INFO - 2021-06-29 04:00:04 --> Language Class Initialized
INFO - 2021-06-29 04:00:04 --> Language Class Initialized
INFO - 2021-06-29 04:00:04 --> Config Class Initialized
INFO - 2021-06-29 04:00:04 --> Loader Class Initialized
INFO - 2021-06-29 04:00:04 --> Helper loaded: url_helper
INFO - 2021-06-29 04:00:04 --> Helper loaded: file_helper
INFO - 2021-06-29 04:00:04 --> Helper loaded: form_helper
INFO - 2021-06-29 04:00:04 --> Helper loaded: my_helper
INFO - 2021-06-29 04:00:04 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:00:04 --> Controller Class Initialized
DEBUG - 2021-06-29 04:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:00:04 --> Final output sent to browser
DEBUG - 2021-06-29 04:00:04 --> Total execution time: 0.0552
INFO - 2021-06-29 04:02:04 --> Config Class Initialized
INFO - 2021-06-29 04:02:04 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:02:04 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:02:04 --> Utf8 Class Initialized
INFO - 2021-06-29 04:02:04 --> URI Class Initialized
INFO - 2021-06-29 04:02:04 --> Router Class Initialized
INFO - 2021-06-29 04:02:04 --> Output Class Initialized
INFO - 2021-06-29 04:02:04 --> Security Class Initialized
DEBUG - 2021-06-29 04:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:02:04 --> Input Class Initialized
INFO - 2021-06-29 04:02:04 --> Language Class Initialized
INFO - 2021-06-29 04:02:04 --> Language Class Initialized
INFO - 2021-06-29 04:02:04 --> Config Class Initialized
INFO - 2021-06-29 04:02:04 --> Loader Class Initialized
INFO - 2021-06-29 04:02:04 --> Helper loaded: url_helper
INFO - 2021-06-29 04:02:04 --> Helper loaded: file_helper
INFO - 2021-06-29 04:02:04 --> Helper loaded: form_helper
INFO - 2021-06-29 04:02:04 --> Helper loaded: my_helper
INFO - 2021-06-29 04:02:04 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:02:04 --> Controller Class Initialized
DEBUG - 2021-06-29 04:02:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:02:04 --> Final output sent to browser
DEBUG - 2021-06-29 04:02:04 --> Total execution time: 0.0553
INFO - 2021-06-29 04:02:17 --> Config Class Initialized
INFO - 2021-06-29 04:02:17 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:02:17 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:02:17 --> Utf8 Class Initialized
INFO - 2021-06-29 04:02:17 --> URI Class Initialized
INFO - 2021-06-29 04:02:17 --> Router Class Initialized
INFO - 2021-06-29 04:02:17 --> Output Class Initialized
INFO - 2021-06-29 04:02:17 --> Security Class Initialized
DEBUG - 2021-06-29 04:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:02:17 --> Input Class Initialized
INFO - 2021-06-29 04:02:17 --> Language Class Initialized
INFO - 2021-06-29 04:02:17 --> Language Class Initialized
INFO - 2021-06-29 04:02:17 --> Config Class Initialized
INFO - 2021-06-29 04:02:17 --> Loader Class Initialized
INFO - 2021-06-29 04:02:17 --> Helper loaded: url_helper
INFO - 2021-06-29 04:02:17 --> Helper loaded: file_helper
INFO - 2021-06-29 04:02:17 --> Helper loaded: form_helper
INFO - 2021-06-29 04:02:17 --> Helper loaded: my_helper
INFO - 2021-06-29 04:02:17 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:02:17 --> Controller Class Initialized
DEBUG - 2021-06-29 04:02:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:02:17 --> Final output sent to browser
DEBUG - 2021-06-29 04:02:17 --> Total execution time: 0.0553
INFO - 2021-06-29 04:03:04 --> Config Class Initialized
INFO - 2021-06-29 04:03:04 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:03:04 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:03:04 --> Utf8 Class Initialized
INFO - 2021-06-29 04:03:04 --> URI Class Initialized
INFO - 2021-06-29 04:03:04 --> Router Class Initialized
INFO - 2021-06-29 04:03:04 --> Output Class Initialized
INFO - 2021-06-29 04:03:04 --> Security Class Initialized
DEBUG - 2021-06-29 04:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:03:04 --> Input Class Initialized
INFO - 2021-06-29 04:03:04 --> Language Class Initialized
INFO - 2021-06-29 04:03:04 --> Language Class Initialized
INFO - 2021-06-29 04:03:04 --> Config Class Initialized
INFO - 2021-06-29 04:03:04 --> Loader Class Initialized
INFO - 2021-06-29 04:03:04 --> Helper loaded: url_helper
INFO - 2021-06-29 04:03:04 --> Helper loaded: file_helper
INFO - 2021-06-29 04:03:04 --> Helper loaded: form_helper
INFO - 2021-06-29 04:03:04 --> Helper loaded: my_helper
INFO - 2021-06-29 04:03:04 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:03:04 --> Controller Class Initialized
DEBUG - 2021-06-29 04:03:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:03:04 --> Final output sent to browser
DEBUG - 2021-06-29 04:03:04 --> Total execution time: 0.0452
INFO - 2021-06-29 04:03:29 --> Config Class Initialized
INFO - 2021-06-29 04:03:29 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:03:29 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:03:29 --> Utf8 Class Initialized
INFO - 2021-06-29 04:03:29 --> URI Class Initialized
INFO - 2021-06-29 04:03:29 --> Router Class Initialized
INFO - 2021-06-29 04:03:29 --> Output Class Initialized
INFO - 2021-06-29 04:03:29 --> Security Class Initialized
DEBUG - 2021-06-29 04:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:03:29 --> Input Class Initialized
INFO - 2021-06-29 04:03:29 --> Language Class Initialized
INFO - 2021-06-29 04:03:29 --> Language Class Initialized
INFO - 2021-06-29 04:03:29 --> Config Class Initialized
INFO - 2021-06-29 04:03:29 --> Loader Class Initialized
INFO - 2021-06-29 04:03:29 --> Helper loaded: url_helper
INFO - 2021-06-29 04:03:29 --> Helper loaded: file_helper
INFO - 2021-06-29 04:03:29 --> Helper loaded: form_helper
INFO - 2021-06-29 04:03:29 --> Helper loaded: my_helper
INFO - 2021-06-29 04:03:29 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:03:29 --> Controller Class Initialized
DEBUG - 2021-06-29 04:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:03:29 --> Final output sent to browser
DEBUG - 2021-06-29 04:03:29 --> Total execution time: 0.0553
INFO - 2021-06-29 04:03:40 --> Config Class Initialized
INFO - 2021-06-29 04:03:40 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:03:40 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:03:40 --> Utf8 Class Initialized
INFO - 2021-06-29 04:03:40 --> URI Class Initialized
INFO - 2021-06-29 04:03:40 --> Router Class Initialized
INFO - 2021-06-29 04:03:40 --> Output Class Initialized
INFO - 2021-06-29 04:03:40 --> Security Class Initialized
DEBUG - 2021-06-29 04:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:03:40 --> Input Class Initialized
INFO - 2021-06-29 04:03:40 --> Language Class Initialized
INFO - 2021-06-29 04:03:40 --> Language Class Initialized
INFO - 2021-06-29 04:03:40 --> Config Class Initialized
INFO - 2021-06-29 04:03:40 --> Loader Class Initialized
INFO - 2021-06-29 04:03:40 --> Helper loaded: url_helper
INFO - 2021-06-29 04:03:40 --> Helper loaded: file_helper
INFO - 2021-06-29 04:03:40 --> Helper loaded: form_helper
INFO - 2021-06-29 04:03:40 --> Helper loaded: my_helper
INFO - 2021-06-29 04:03:41 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:03:41 --> Controller Class Initialized
DEBUG - 2021-06-29 04:03:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:03:41 --> Final output sent to browser
DEBUG - 2021-06-29 04:03:41 --> Total execution time: 0.0543
INFO - 2021-06-29 04:04:06 --> Config Class Initialized
INFO - 2021-06-29 04:04:06 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:04:06 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:04:06 --> Utf8 Class Initialized
INFO - 2021-06-29 04:04:06 --> URI Class Initialized
INFO - 2021-06-29 04:04:06 --> Router Class Initialized
INFO - 2021-06-29 04:04:06 --> Output Class Initialized
INFO - 2021-06-29 04:04:06 --> Security Class Initialized
DEBUG - 2021-06-29 04:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:04:06 --> Input Class Initialized
INFO - 2021-06-29 04:04:06 --> Language Class Initialized
INFO - 2021-06-29 04:04:06 --> Language Class Initialized
INFO - 2021-06-29 04:04:06 --> Config Class Initialized
INFO - 2021-06-29 04:04:06 --> Loader Class Initialized
INFO - 2021-06-29 04:04:06 --> Helper loaded: url_helper
INFO - 2021-06-29 04:04:06 --> Helper loaded: file_helper
INFO - 2021-06-29 04:04:06 --> Helper loaded: form_helper
INFO - 2021-06-29 04:04:06 --> Helper loaded: my_helper
INFO - 2021-06-29 04:04:06 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:04:06 --> Controller Class Initialized
DEBUG - 2021-06-29 04:04:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:04:06 --> Final output sent to browser
DEBUG - 2021-06-29 04:04:06 --> Total execution time: 0.0450
INFO - 2021-06-29 04:05:09 --> Config Class Initialized
INFO - 2021-06-29 04:05:09 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:05:09 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:05:09 --> Utf8 Class Initialized
INFO - 2021-06-29 04:05:09 --> URI Class Initialized
INFO - 2021-06-29 04:05:09 --> Router Class Initialized
INFO - 2021-06-29 04:05:09 --> Output Class Initialized
INFO - 2021-06-29 04:05:09 --> Security Class Initialized
DEBUG - 2021-06-29 04:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:05:09 --> Input Class Initialized
INFO - 2021-06-29 04:05:09 --> Language Class Initialized
INFO - 2021-06-29 04:05:09 --> Language Class Initialized
INFO - 2021-06-29 04:05:09 --> Config Class Initialized
INFO - 2021-06-29 04:05:09 --> Loader Class Initialized
INFO - 2021-06-29 04:05:09 --> Helper loaded: url_helper
INFO - 2021-06-29 04:05:09 --> Helper loaded: file_helper
INFO - 2021-06-29 04:05:09 --> Helper loaded: form_helper
INFO - 2021-06-29 04:05:09 --> Helper loaded: my_helper
INFO - 2021-06-29 04:05:09 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:05:09 --> Controller Class Initialized
DEBUG - 2021-06-29 04:05:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:05:09 --> Final output sent to browser
DEBUG - 2021-06-29 04:05:09 --> Total execution time: 0.0544
INFO - 2021-06-29 04:05:49 --> Config Class Initialized
INFO - 2021-06-29 04:05:49 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:05:49 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:05:49 --> Utf8 Class Initialized
INFO - 2021-06-29 04:05:49 --> URI Class Initialized
INFO - 2021-06-29 04:05:49 --> Router Class Initialized
INFO - 2021-06-29 04:05:49 --> Output Class Initialized
INFO - 2021-06-29 04:05:49 --> Security Class Initialized
DEBUG - 2021-06-29 04:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:05:49 --> Input Class Initialized
INFO - 2021-06-29 04:05:49 --> Language Class Initialized
INFO - 2021-06-29 04:05:49 --> Language Class Initialized
INFO - 2021-06-29 04:05:49 --> Config Class Initialized
INFO - 2021-06-29 04:05:49 --> Loader Class Initialized
INFO - 2021-06-29 04:05:49 --> Helper loaded: url_helper
INFO - 2021-06-29 04:05:49 --> Helper loaded: file_helper
INFO - 2021-06-29 04:05:49 --> Helper loaded: form_helper
INFO - 2021-06-29 04:05:49 --> Helper loaded: my_helper
INFO - 2021-06-29 04:05:49 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:05:49 --> Controller Class Initialized
DEBUG - 2021-06-29 04:05:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:05:49 --> Final output sent to browser
DEBUG - 2021-06-29 04:05:49 --> Total execution time: 0.0560
INFO - 2021-06-29 04:06:53 --> Config Class Initialized
INFO - 2021-06-29 04:06:53 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:06:53 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:06:53 --> Utf8 Class Initialized
INFO - 2021-06-29 04:06:53 --> URI Class Initialized
INFO - 2021-06-29 04:06:53 --> Router Class Initialized
INFO - 2021-06-29 04:06:53 --> Output Class Initialized
INFO - 2021-06-29 04:06:53 --> Security Class Initialized
DEBUG - 2021-06-29 04:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:06:53 --> Input Class Initialized
INFO - 2021-06-29 04:06:53 --> Language Class Initialized
INFO - 2021-06-29 04:06:53 --> Language Class Initialized
INFO - 2021-06-29 04:06:53 --> Config Class Initialized
INFO - 2021-06-29 04:06:53 --> Loader Class Initialized
INFO - 2021-06-29 04:06:53 --> Helper loaded: url_helper
INFO - 2021-06-29 04:06:53 --> Helper loaded: file_helper
INFO - 2021-06-29 04:06:53 --> Helper loaded: form_helper
INFO - 2021-06-29 04:06:53 --> Helper loaded: my_helper
INFO - 2021-06-29 04:06:53 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:06:53 --> Controller Class Initialized
DEBUG - 2021-06-29 04:06:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:06:53 --> Final output sent to browser
DEBUG - 2021-06-29 04:06:53 --> Total execution time: 0.0539
INFO - 2021-06-29 04:07:14 --> Config Class Initialized
INFO - 2021-06-29 04:07:14 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:07:14 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:07:14 --> Utf8 Class Initialized
INFO - 2021-06-29 04:07:14 --> URI Class Initialized
INFO - 2021-06-29 04:07:14 --> Router Class Initialized
INFO - 2021-06-29 04:07:14 --> Output Class Initialized
INFO - 2021-06-29 04:07:14 --> Security Class Initialized
DEBUG - 2021-06-29 04:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:07:14 --> Input Class Initialized
INFO - 2021-06-29 04:07:14 --> Language Class Initialized
INFO - 2021-06-29 04:07:14 --> Language Class Initialized
INFO - 2021-06-29 04:07:14 --> Config Class Initialized
INFO - 2021-06-29 04:07:14 --> Loader Class Initialized
INFO - 2021-06-29 04:07:14 --> Helper loaded: url_helper
INFO - 2021-06-29 04:07:14 --> Helper loaded: file_helper
INFO - 2021-06-29 04:07:14 --> Helper loaded: form_helper
INFO - 2021-06-29 04:07:14 --> Helper loaded: my_helper
INFO - 2021-06-29 04:07:14 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:07:14 --> Controller Class Initialized
DEBUG - 2021-06-29 04:07:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:07:14 --> Final output sent to browser
DEBUG - 2021-06-29 04:07:14 --> Total execution time: 0.0446
INFO - 2021-06-29 04:07:57 --> Config Class Initialized
INFO - 2021-06-29 04:07:57 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:07:57 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:07:57 --> Utf8 Class Initialized
INFO - 2021-06-29 04:07:57 --> URI Class Initialized
INFO - 2021-06-29 04:07:57 --> Router Class Initialized
INFO - 2021-06-29 04:07:57 --> Output Class Initialized
INFO - 2021-06-29 04:07:57 --> Security Class Initialized
DEBUG - 2021-06-29 04:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:07:57 --> Input Class Initialized
INFO - 2021-06-29 04:07:57 --> Language Class Initialized
INFO - 2021-06-29 04:07:57 --> Language Class Initialized
INFO - 2021-06-29 04:07:57 --> Config Class Initialized
INFO - 2021-06-29 04:07:57 --> Loader Class Initialized
INFO - 2021-06-29 04:07:57 --> Helper loaded: url_helper
INFO - 2021-06-29 04:07:57 --> Helper loaded: file_helper
INFO - 2021-06-29 04:07:57 --> Helper loaded: form_helper
INFO - 2021-06-29 04:07:57 --> Helper loaded: my_helper
INFO - 2021-06-29 04:07:57 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:07:57 --> Controller Class Initialized
DEBUG - 2021-06-29 04:07:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:07:57 --> Final output sent to browser
DEBUG - 2021-06-29 04:07:57 --> Total execution time: 0.0455
INFO - 2021-06-29 04:08:08 --> Config Class Initialized
INFO - 2021-06-29 04:08:08 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:08:08 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:08:08 --> Utf8 Class Initialized
INFO - 2021-06-29 04:08:08 --> URI Class Initialized
INFO - 2021-06-29 04:08:08 --> Router Class Initialized
INFO - 2021-06-29 04:08:08 --> Output Class Initialized
INFO - 2021-06-29 04:08:08 --> Security Class Initialized
DEBUG - 2021-06-29 04:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:08:08 --> Input Class Initialized
INFO - 2021-06-29 04:08:08 --> Language Class Initialized
INFO - 2021-06-29 04:08:08 --> Language Class Initialized
INFO - 2021-06-29 04:08:08 --> Config Class Initialized
INFO - 2021-06-29 04:08:08 --> Loader Class Initialized
INFO - 2021-06-29 04:08:08 --> Helper loaded: url_helper
INFO - 2021-06-29 04:08:08 --> Helper loaded: file_helper
INFO - 2021-06-29 04:08:08 --> Helper loaded: form_helper
INFO - 2021-06-29 04:08:08 --> Helper loaded: my_helper
INFO - 2021-06-29 04:08:08 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:08:08 --> Controller Class Initialized
DEBUG - 2021-06-29 04:08:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:08:08 --> Final output sent to browser
DEBUG - 2021-06-29 04:08:08 --> Total execution time: 0.0563
INFO - 2021-06-29 04:09:23 --> Config Class Initialized
INFO - 2021-06-29 04:09:23 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:09:23 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:09:23 --> Utf8 Class Initialized
INFO - 2021-06-29 04:09:23 --> URI Class Initialized
INFO - 2021-06-29 04:09:23 --> Router Class Initialized
INFO - 2021-06-29 04:09:23 --> Output Class Initialized
INFO - 2021-06-29 04:09:23 --> Security Class Initialized
DEBUG - 2021-06-29 04:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:09:23 --> Input Class Initialized
INFO - 2021-06-29 04:09:23 --> Language Class Initialized
INFO - 2021-06-29 04:09:23 --> Language Class Initialized
INFO - 2021-06-29 04:09:23 --> Config Class Initialized
INFO - 2021-06-29 04:09:23 --> Loader Class Initialized
INFO - 2021-06-29 04:09:23 --> Helper loaded: url_helper
INFO - 2021-06-29 04:09:23 --> Helper loaded: file_helper
INFO - 2021-06-29 04:09:23 --> Helper loaded: form_helper
INFO - 2021-06-29 04:09:23 --> Helper loaded: my_helper
INFO - 2021-06-29 04:09:23 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:09:23 --> Controller Class Initialized
DEBUG - 2021-06-29 04:09:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:09:23 --> Final output sent to browser
DEBUG - 2021-06-29 04:09:23 --> Total execution time: 0.0544
INFO - 2021-06-29 04:11:57 --> Config Class Initialized
INFO - 2021-06-29 04:11:57 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:11:57 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:11:57 --> Utf8 Class Initialized
INFO - 2021-06-29 04:11:57 --> URI Class Initialized
INFO - 2021-06-29 04:11:57 --> Router Class Initialized
INFO - 2021-06-29 04:11:57 --> Output Class Initialized
INFO - 2021-06-29 04:11:57 --> Security Class Initialized
DEBUG - 2021-06-29 04:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:11:57 --> Input Class Initialized
INFO - 2021-06-29 04:11:57 --> Language Class Initialized
INFO - 2021-06-29 04:11:57 --> Language Class Initialized
INFO - 2021-06-29 04:11:57 --> Config Class Initialized
INFO - 2021-06-29 04:11:57 --> Loader Class Initialized
INFO - 2021-06-29 04:11:57 --> Helper loaded: url_helper
INFO - 2021-06-29 04:11:57 --> Helper loaded: file_helper
INFO - 2021-06-29 04:11:57 --> Helper loaded: form_helper
INFO - 2021-06-29 04:11:57 --> Helper loaded: my_helper
INFO - 2021-06-29 04:11:57 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:11:57 --> Controller Class Initialized
DEBUG - 2021-06-29 04:11:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:11:57 --> Final output sent to browser
DEBUG - 2021-06-29 04:11:57 --> Total execution time: 0.0558
INFO - 2021-06-29 04:12:22 --> Config Class Initialized
INFO - 2021-06-29 04:12:22 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:12:22 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:12:22 --> Utf8 Class Initialized
INFO - 2021-06-29 04:12:22 --> URI Class Initialized
INFO - 2021-06-29 04:12:22 --> Router Class Initialized
INFO - 2021-06-29 04:12:22 --> Output Class Initialized
INFO - 2021-06-29 04:12:22 --> Security Class Initialized
DEBUG - 2021-06-29 04:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:12:22 --> Input Class Initialized
INFO - 2021-06-29 04:12:22 --> Language Class Initialized
INFO - 2021-06-29 04:12:22 --> Language Class Initialized
INFO - 2021-06-29 04:12:22 --> Config Class Initialized
INFO - 2021-06-29 04:12:22 --> Loader Class Initialized
INFO - 2021-06-29 04:12:22 --> Helper loaded: url_helper
INFO - 2021-06-29 04:12:22 --> Helper loaded: file_helper
INFO - 2021-06-29 04:12:22 --> Helper loaded: form_helper
INFO - 2021-06-29 04:12:22 --> Helper loaded: my_helper
INFO - 2021-06-29 04:12:22 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:12:22 --> Controller Class Initialized
DEBUG - 2021-06-29 04:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:12:22 --> Final output sent to browser
DEBUG - 2021-06-29 04:12:22 --> Total execution time: 0.0565
INFO - 2021-06-29 04:13:59 --> Config Class Initialized
INFO - 2021-06-29 04:13:59 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:13:59 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:13:59 --> Utf8 Class Initialized
INFO - 2021-06-29 04:13:59 --> URI Class Initialized
INFO - 2021-06-29 04:13:59 --> Router Class Initialized
INFO - 2021-06-29 04:13:59 --> Output Class Initialized
INFO - 2021-06-29 04:13:59 --> Security Class Initialized
DEBUG - 2021-06-29 04:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:13:59 --> Input Class Initialized
INFO - 2021-06-29 04:13:59 --> Language Class Initialized
INFO - 2021-06-29 04:13:59 --> Language Class Initialized
INFO - 2021-06-29 04:13:59 --> Config Class Initialized
INFO - 2021-06-29 04:13:59 --> Loader Class Initialized
INFO - 2021-06-29 04:13:59 --> Helper loaded: url_helper
INFO - 2021-06-29 04:13:59 --> Helper loaded: file_helper
INFO - 2021-06-29 04:13:59 --> Helper loaded: form_helper
INFO - 2021-06-29 04:13:59 --> Helper loaded: my_helper
INFO - 2021-06-29 04:13:59 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:13:59 --> Controller Class Initialized
DEBUG - 2021-06-29 04:13:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:13:59 --> Final output sent to browser
DEBUG - 2021-06-29 04:13:59 --> Total execution time: 0.0549
INFO - 2021-06-29 04:19:34 --> Config Class Initialized
INFO - 2021-06-29 04:19:34 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:19:34 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:19:34 --> Utf8 Class Initialized
INFO - 2021-06-29 04:19:34 --> URI Class Initialized
INFO - 2021-06-29 04:19:34 --> Router Class Initialized
INFO - 2021-06-29 04:19:34 --> Output Class Initialized
INFO - 2021-06-29 04:19:34 --> Security Class Initialized
DEBUG - 2021-06-29 04:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:19:34 --> Input Class Initialized
INFO - 2021-06-29 04:19:34 --> Language Class Initialized
INFO - 2021-06-29 04:19:34 --> Language Class Initialized
INFO - 2021-06-29 04:19:34 --> Config Class Initialized
INFO - 2021-06-29 04:19:34 --> Loader Class Initialized
INFO - 2021-06-29 04:19:34 --> Helper loaded: url_helper
INFO - 2021-06-29 04:19:34 --> Helper loaded: file_helper
INFO - 2021-06-29 04:19:34 --> Helper loaded: form_helper
INFO - 2021-06-29 04:19:34 --> Helper loaded: my_helper
INFO - 2021-06-29 04:19:34 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:19:34 --> Controller Class Initialized
DEBUG - 2021-06-29 04:19:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:19:34 --> Final output sent to browser
DEBUG - 2021-06-29 04:19:34 --> Total execution time: 0.0563
INFO - 2021-06-29 04:20:05 --> Config Class Initialized
INFO - 2021-06-29 04:20:05 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:20:05 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:20:05 --> Utf8 Class Initialized
INFO - 2021-06-29 04:20:05 --> URI Class Initialized
INFO - 2021-06-29 04:20:05 --> Router Class Initialized
INFO - 2021-06-29 04:20:05 --> Output Class Initialized
INFO - 2021-06-29 04:20:05 --> Security Class Initialized
DEBUG - 2021-06-29 04:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:20:05 --> Input Class Initialized
INFO - 2021-06-29 04:20:05 --> Language Class Initialized
INFO - 2021-06-29 04:20:05 --> Language Class Initialized
INFO - 2021-06-29 04:20:05 --> Config Class Initialized
INFO - 2021-06-29 04:20:05 --> Loader Class Initialized
INFO - 2021-06-29 04:20:05 --> Helper loaded: url_helper
INFO - 2021-06-29 04:20:05 --> Helper loaded: file_helper
INFO - 2021-06-29 04:20:05 --> Helper loaded: form_helper
INFO - 2021-06-29 04:20:05 --> Helper loaded: my_helper
INFO - 2021-06-29 04:20:05 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:20:05 --> Controller Class Initialized
DEBUG - 2021-06-29 04:20:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:20:05 --> Final output sent to browser
DEBUG - 2021-06-29 04:20:05 --> Total execution time: 0.0535
INFO - 2021-06-29 04:20:54 --> Config Class Initialized
INFO - 2021-06-29 04:20:54 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:20:54 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:20:54 --> Utf8 Class Initialized
INFO - 2021-06-29 04:20:54 --> URI Class Initialized
INFO - 2021-06-29 04:20:54 --> Router Class Initialized
INFO - 2021-06-29 04:20:54 --> Output Class Initialized
INFO - 2021-06-29 04:20:54 --> Security Class Initialized
DEBUG - 2021-06-29 04:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:20:54 --> Input Class Initialized
INFO - 2021-06-29 04:20:54 --> Language Class Initialized
INFO - 2021-06-29 04:20:54 --> Language Class Initialized
INFO - 2021-06-29 04:20:54 --> Config Class Initialized
INFO - 2021-06-29 04:20:54 --> Loader Class Initialized
INFO - 2021-06-29 04:20:54 --> Helper loaded: url_helper
INFO - 2021-06-29 04:20:54 --> Helper loaded: file_helper
INFO - 2021-06-29 04:20:54 --> Helper loaded: form_helper
INFO - 2021-06-29 04:20:54 --> Helper loaded: my_helper
INFO - 2021-06-29 04:20:54 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:20:54 --> Controller Class Initialized
DEBUG - 2021-06-29 04:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 04:20:54 --> Final output sent to browser
DEBUG - 2021-06-29 04:20:54 --> Total execution time: 0.0563
INFO - 2021-06-29 04:21:18 --> Config Class Initialized
INFO - 2021-06-29 04:21:18 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:21:18 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:21:18 --> Utf8 Class Initialized
INFO - 2021-06-29 04:21:18 --> URI Class Initialized
INFO - 2021-06-29 04:21:18 --> Router Class Initialized
INFO - 2021-06-29 04:21:18 --> Output Class Initialized
INFO - 2021-06-29 04:21:18 --> Security Class Initialized
DEBUG - 2021-06-29 04:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:21:18 --> Input Class Initialized
INFO - 2021-06-29 04:21:18 --> Language Class Initialized
INFO - 2021-06-29 04:21:18 --> Language Class Initialized
INFO - 2021-06-29 04:21:18 --> Config Class Initialized
INFO - 2021-06-29 04:21:18 --> Loader Class Initialized
INFO - 2021-06-29 04:21:18 --> Helper loaded: url_helper
INFO - 2021-06-29 04:21:18 --> Helper loaded: file_helper
INFO - 2021-06-29 04:21:18 --> Helper loaded: form_helper
INFO - 2021-06-29 04:21:18 --> Helper loaded: my_helper
INFO - 2021-06-29 04:21:18 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:21:18 --> Controller Class Initialized
INFO - 2021-06-29 04:21:18 --> Helper loaded: cookie_helper
INFO - 2021-06-29 04:21:18 --> Config Class Initialized
INFO - 2021-06-29 04:21:18 --> Hooks Class Initialized
DEBUG - 2021-06-29 04:21:18 --> UTF-8 Support Enabled
INFO - 2021-06-29 04:21:18 --> Utf8 Class Initialized
INFO - 2021-06-29 04:21:18 --> URI Class Initialized
INFO - 2021-06-29 04:21:18 --> Router Class Initialized
INFO - 2021-06-29 04:21:18 --> Output Class Initialized
INFO - 2021-06-29 04:21:18 --> Security Class Initialized
DEBUG - 2021-06-29 04:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 04:21:18 --> Input Class Initialized
INFO - 2021-06-29 04:21:18 --> Language Class Initialized
INFO - 2021-06-29 04:21:18 --> Language Class Initialized
INFO - 2021-06-29 04:21:18 --> Config Class Initialized
INFO - 2021-06-29 04:21:18 --> Loader Class Initialized
INFO - 2021-06-29 04:21:18 --> Helper loaded: url_helper
INFO - 2021-06-29 04:21:18 --> Helper loaded: file_helper
INFO - 2021-06-29 04:21:18 --> Helper loaded: form_helper
INFO - 2021-06-29 04:21:18 --> Helper loaded: my_helper
INFO - 2021-06-29 04:21:18 --> Database Driver Class Initialized
DEBUG - 2021-06-29 04:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 04:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 04:21:18 --> Controller Class Initialized
DEBUG - 2021-06-29 04:21:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 04:21:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 04:21:18 --> Final output sent to browser
DEBUG - 2021-06-29 04:21:18 --> Total execution time: 0.0395
INFO - 2021-06-29 05:00:32 --> Config Class Initialized
INFO - 2021-06-29 05:00:32 --> Hooks Class Initialized
DEBUG - 2021-06-29 05:00:33 --> UTF-8 Support Enabled
INFO - 2021-06-29 05:00:33 --> Utf8 Class Initialized
INFO - 2021-06-29 05:00:33 --> URI Class Initialized
DEBUG - 2021-06-29 05:00:33 --> No URI present. Default controller set.
INFO - 2021-06-29 05:00:33 --> Router Class Initialized
INFO - 2021-06-29 05:00:33 --> Output Class Initialized
INFO - 2021-06-29 05:00:33 --> Security Class Initialized
DEBUG - 2021-06-29 05:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 05:00:33 --> Input Class Initialized
INFO - 2021-06-29 05:00:33 --> Language Class Initialized
INFO - 2021-06-29 05:00:33 --> Language Class Initialized
INFO - 2021-06-29 05:00:33 --> Config Class Initialized
INFO - 2021-06-29 05:00:33 --> Loader Class Initialized
INFO - 2021-06-29 05:00:33 --> Helper loaded: url_helper
INFO - 2021-06-29 05:00:33 --> Helper loaded: file_helper
INFO - 2021-06-29 05:00:33 --> Helper loaded: form_helper
INFO - 2021-06-29 05:00:34 --> Helper loaded: my_helper
INFO - 2021-06-29 05:00:34 --> Database Driver Class Initialized
DEBUG - 2021-06-29 05:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 05:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 05:00:34 --> Controller Class Initialized
INFO - 2021-06-29 05:01:09 --> Config Class Initialized
INFO - 2021-06-29 05:01:09 --> Hooks Class Initialized
DEBUG - 2021-06-29 05:01:09 --> UTF-8 Support Enabled
INFO - 2021-06-29 05:01:09 --> Utf8 Class Initialized
INFO - 2021-06-29 05:01:09 --> URI Class Initialized
INFO - 2021-06-29 05:01:09 --> Router Class Initialized
INFO - 2021-06-29 05:01:09 --> Output Class Initialized
INFO - 2021-06-29 05:01:09 --> Security Class Initialized
DEBUG - 2021-06-29 05:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 05:01:09 --> Input Class Initialized
INFO - 2021-06-29 05:01:09 --> Language Class Initialized
INFO - 2021-06-29 05:01:09 --> Language Class Initialized
INFO - 2021-06-29 05:01:09 --> Config Class Initialized
INFO - 2021-06-29 05:01:09 --> Loader Class Initialized
INFO - 2021-06-29 05:01:09 --> Helper loaded: url_helper
INFO - 2021-06-29 05:01:09 --> Helper loaded: file_helper
INFO - 2021-06-29 05:01:09 --> Helper loaded: form_helper
INFO - 2021-06-29 05:01:09 --> Helper loaded: my_helper
INFO - 2021-06-29 05:01:09 --> Database Driver Class Initialized
DEBUG - 2021-06-29 05:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 05:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 05:01:09 --> Controller Class Initialized
DEBUG - 2021-06-29 05:01:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 05:01:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 05:01:09 --> Final output sent to browser
DEBUG - 2021-06-29 05:01:09 --> Total execution time: 0.2901
INFO - 2021-06-29 05:01:50 --> Config Class Initialized
INFO - 2021-06-29 05:01:50 --> Hooks Class Initialized
DEBUG - 2021-06-29 05:01:50 --> UTF-8 Support Enabled
INFO - 2021-06-29 05:01:50 --> Utf8 Class Initialized
INFO - 2021-06-29 05:01:50 --> URI Class Initialized
INFO - 2021-06-29 05:01:50 --> Router Class Initialized
INFO - 2021-06-29 05:01:50 --> Output Class Initialized
INFO - 2021-06-29 05:01:50 --> Security Class Initialized
DEBUG - 2021-06-29 05:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 05:01:50 --> Input Class Initialized
INFO - 2021-06-29 05:01:50 --> Language Class Initialized
INFO - 2021-06-29 05:01:50 --> Language Class Initialized
INFO - 2021-06-29 05:01:50 --> Config Class Initialized
INFO - 2021-06-29 05:01:50 --> Loader Class Initialized
INFO - 2021-06-29 05:01:50 --> Helper loaded: url_helper
INFO - 2021-06-29 05:01:50 --> Helper loaded: file_helper
INFO - 2021-06-29 05:01:50 --> Helper loaded: form_helper
INFO - 2021-06-29 05:01:50 --> Helper loaded: my_helper
INFO - 2021-06-29 05:01:50 --> Database Driver Class Initialized
DEBUG - 2021-06-29 05:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 05:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 05:01:50 --> Controller Class Initialized
DEBUG - 2021-06-29 05:01:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 05:01:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 05:01:50 --> Final output sent to browser
DEBUG - 2021-06-29 05:01:50 --> Total execution time: 0.1124
INFO - 2021-06-29 05:01:56 --> Config Class Initialized
INFO - 2021-06-29 05:01:56 --> Hooks Class Initialized
DEBUG - 2021-06-29 05:01:56 --> UTF-8 Support Enabled
INFO - 2021-06-29 05:01:56 --> Utf8 Class Initialized
INFO - 2021-06-29 05:01:56 --> URI Class Initialized
INFO - 2021-06-29 05:01:56 --> Router Class Initialized
INFO - 2021-06-29 05:01:56 --> Output Class Initialized
INFO - 2021-06-29 05:01:56 --> Security Class Initialized
DEBUG - 2021-06-29 05:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 05:01:56 --> Input Class Initialized
INFO - 2021-06-29 05:01:56 --> Language Class Initialized
INFO - 2021-06-29 05:01:56 --> Language Class Initialized
INFO - 2021-06-29 05:01:56 --> Config Class Initialized
INFO - 2021-06-29 05:01:56 --> Loader Class Initialized
INFO - 2021-06-29 05:01:56 --> Helper loaded: url_helper
INFO - 2021-06-29 05:01:56 --> Helper loaded: file_helper
INFO - 2021-06-29 05:01:56 --> Helper loaded: form_helper
INFO - 2021-06-29 05:01:56 --> Helper loaded: my_helper
INFO - 2021-06-29 05:01:56 --> Database Driver Class Initialized
DEBUG - 2021-06-29 05:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 05:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 05:01:56 --> Controller Class Initialized
INFO - 2021-06-29 05:01:56 --> Helper loaded: cookie_helper
INFO - 2021-06-29 05:01:56 --> Final output sent to browser
DEBUG - 2021-06-29 05:01:56 --> Total execution time: 0.1462
INFO - 2021-06-29 05:01:56 --> Config Class Initialized
INFO - 2021-06-29 05:01:56 --> Hooks Class Initialized
DEBUG - 2021-06-29 05:01:56 --> UTF-8 Support Enabled
INFO - 2021-06-29 05:01:56 --> Utf8 Class Initialized
INFO - 2021-06-29 05:01:56 --> URI Class Initialized
INFO - 2021-06-29 05:01:56 --> Router Class Initialized
INFO - 2021-06-29 05:01:57 --> Output Class Initialized
INFO - 2021-06-29 05:01:57 --> Security Class Initialized
DEBUG - 2021-06-29 05:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 05:01:57 --> Input Class Initialized
INFO - 2021-06-29 05:01:57 --> Language Class Initialized
INFO - 2021-06-29 05:01:57 --> Language Class Initialized
INFO - 2021-06-29 05:01:57 --> Config Class Initialized
INFO - 2021-06-29 05:01:57 --> Loader Class Initialized
INFO - 2021-06-29 05:01:57 --> Helper loaded: url_helper
INFO - 2021-06-29 05:01:57 --> Helper loaded: file_helper
INFO - 2021-06-29 05:01:57 --> Helper loaded: form_helper
INFO - 2021-06-29 05:01:57 --> Helper loaded: my_helper
INFO - 2021-06-29 05:01:57 --> Database Driver Class Initialized
DEBUG - 2021-06-29 05:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 05:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 05:01:57 --> Controller Class Initialized
DEBUG - 2021-06-29 05:01:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-29 05:01:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 05:01:59 --> Final output sent to browser
DEBUG - 2021-06-29 05:01:59 --> Total execution time: 2.4341
INFO - 2021-06-29 05:28:34 --> Config Class Initialized
INFO - 2021-06-29 05:28:34 --> Hooks Class Initialized
DEBUG - 2021-06-29 05:28:34 --> UTF-8 Support Enabled
INFO - 2021-06-29 05:28:34 --> Utf8 Class Initialized
INFO - 2021-06-29 05:28:34 --> URI Class Initialized
INFO - 2021-06-29 05:28:34 --> Router Class Initialized
INFO - 2021-06-29 05:28:34 --> Output Class Initialized
INFO - 2021-06-29 05:28:34 --> Security Class Initialized
DEBUG - 2021-06-29 05:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 05:28:34 --> Input Class Initialized
INFO - 2021-06-29 05:28:34 --> Language Class Initialized
INFO - 2021-06-29 05:28:34 --> Language Class Initialized
INFO - 2021-06-29 05:28:34 --> Config Class Initialized
INFO - 2021-06-29 05:28:34 --> Loader Class Initialized
INFO - 2021-06-29 05:28:34 --> Helper loaded: url_helper
INFO - 2021-06-29 05:28:34 --> Helper loaded: file_helper
INFO - 2021-06-29 05:28:34 --> Helper loaded: form_helper
INFO - 2021-06-29 05:28:34 --> Helper loaded: my_helper
INFO - 2021-06-29 05:28:34 --> Database Driver Class Initialized
DEBUG - 2021-06-29 05:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 05:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 05:28:34 --> Controller Class Initialized
INFO - 2021-06-29 05:28:34 --> Helper loaded: cookie_helper
INFO - 2021-06-29 05:28:34 --> Config Class Initialized
INFO - 2021-06-29 05:28:34 --> Hooks Class Initialized
DEBUG - 2021-06-29 05:28:34 --> UTF-8 Support Enabled
INFO - 2021-06-29 05:28:34 --> Utf8 Class Initialized
INFO - 2021-06-29 05:28:34 --> URI Class Initialized
INFO - 2021-06-29 05:28:35 --> Router Class Initialized
INFO - 2021-06-29 05:28:35 --> Output Class Initialized
INFO - 2021-06-29 05:28:35 --> Security Class Initialized
DEBUG - 2021-06-29 05:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 05:28:35 --> Input Class Initialized
INFO - 2021-06-29 05:28:35 --> Language Class Initialized
INFO - 2021-06-29 05:28:35 --> Language Class Initialized
INFO - 2021-06-29 05:28:35 --> Config Class Initialized
INFO - 2021-06-29 05:28:35 --> Loader Class Initialized
INFO - 2021-06-29 05:28:35 --> Helper loaded: url_helper
INFO - 2021-06-29 05:28:35 --> Helper loaded: file_helper
INFO - 2021-06-29 05:28:35 --> Helper loaded: form_helper
INFO - 2021-06-29 05:28:35 --> Helper loaded: my_helper
INFO - 2021-06-29 05:28:35 --> Database Driver Class Initialized
DEBUG - 2021-06-29 05:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 05:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 05:28:35 --> Controller Class Initialized
DEBUG - 2021-06-29 05:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 05:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 05:28:35 --> Final output sent to browser
DEBUG - 2021-06-29 05:28:35 --> Total execution time: 0.1915
INFO - 2021-06-29 08:26:44 --> Config Class Initialized
INFO - 2021-06-29 08:26:44 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:26:44 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:26:44 --> Utf8 Class Initialized
INFO - 2021-06-29 08:26:44 --> URI Class Initialized
DEBUG - 2021-06-29 08:26:44 --> No URI present. Default controller set.
INFO - 2021-06-29 08:26:44 --> Router Class Initialized
INFO - 2021-06-29 08:26:44 --> Output Class Initialized
INFO - 2021-06-29 08:26:45 --> Security Class Initialized
DEBUG - 2021-06-29 08:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:26:45 --> Input Class Initialized
INFO - 2021-06-29 08:26:45 --> Language Class Initialized
INFO - 2021-06-29 08:26:45 --> Language Class Initialized
INFO - 2021-06-29 08:26:45 --> Config Class Initialized
INFO - 2021-06-29 08:26:45 --> Loader Class Initialized
INFO - 2021-06-29 08:26:45 --> Helper loaded: url_helper
INFO - 2021-06-29 08:26:45 --> Helper loaded: file_helper
INFO - 2021-06-29 08:26:45 --> Helper loaded: form_helper
INFO - 2021-06-29 08:26:45 --> Helper loaded: my_helper
INFO - 2021-06-29 08:26:45 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:26:45 --> Controller Class Initialized
INFO - 2021-06-29 08:26:45 --> Config Class Initialized
INFO - 2021-06-29 08:26:45 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:26:45 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:26:45 --> Utf8 Class Initialized
INFO - 2021-06-29 08:26:45 --> URI Class Initialized
INFO - 2021-06-29 08:26:45 --> Router Class Initialized
INFO - 2021-06-29 08:26:45 --> Output Class Initialized
INFO - 2021-06-29 08:26:45 --> Security Class Initialized
DEBUG - 2021-06-29 08:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:26:45 --> Input Class Initialized
INFO - 2021-06-29 08:26:45 --> Language Class Initialized
INFO - 2021-06-29 08:26:45 --> Language Class Initialized
INFO - 2021-06-29 08:26:45 --> Config Class Initialized
INFO - 2021-06-29 08:26:45 --> Loader Class Initialized
INFO - 2021-06-29 08:26:45 --> Helper loaded: url_helper
INFO - 2021-06-29 08:26:45 --> Helper loaded: file_helper
INFO - 2021-06-29 08:26:45 --> Helper loaded: form_helper
INFO - 2021-06-29 08:26:45 --> Helper loaded: my_helper
INFO - 2021-06-29 08:26:45 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:26:45 --> Controller Class Initialized
DEBUG - 2021-06-29 08:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-29 08:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 08:26:45 --> Final output sent to browser
DEBUG - 2021-06-29 08:26:45 --> Total execution time: 0.1069
INFO - 2021-06-29 08:26:54 --> Config Class Initialized
INFO - 2021-06-29 08:26:54 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:26:54 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:26:54 --> Utf8 Class Initialized
INFO - 2021-06-29 08:26:54 --> URI Class Initialized
INFO - 2021-06-29 08:26:54 --> Router Class Initialized
INFO - 2021-06-29 08:26:54 --> Output Class Initialized
INFO - 2021-06-29 08:26:54 --> Security Class Initialized
DEBUG - 2021-06-29 08:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:26:54 --> Input Class Initialized
INFO - 2021-06-29 08:26:54 --> Language Class Initialized
INFO - 2021-06-29 08:26:54 --> Language Class Initialized
INFO - 2021-06-29 08:26:54 --> Config Class Initialized
INFO - 2021-06-29 08:26:54 --> Loader Class Initialized
INFO - 2021-06-29 08:26:54 --> Helper loaded: url_helper
INFO - 2021-06-29 08:26:54 --> Helper loaded: file_helper
INFO - 2021-06-29 08:26:54 --> Helper loaded: form_helper
INFO - 2021-06-29 08:26:54 --> Helper loaded: my_helper
INFO - 2021-06-29 08:26:54 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:26:54 --> Controller Class Initialized
INFO - 2021-06-29 08:26:54 --> Helper loaded: cookie_helper
INFO - 2021-06-29 08:26:54 --> Final output sent to browser
DEBUG - 2021-06-29 08:26:54 --> Total execution time: 0.1204
INFO - 2021-06-29 08:26:54 --> Config Class Initialized
INFO - 2021-06-29 08:26:54 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:26:54 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:26:54 --> Utf8 Class Initialized
INFO - 2021-06-29 08:26:54 --> URI Class Initialized
INFO - 2021-06-29 08:26:54 --> Router Class Initialized
INFO - 2021-06-29 08:26:54 --> Output Class Initialized
INFO - 2021-06-29 08:26:54 --> Security Class Initialized
DEBUG - 2021-06-29 08:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:26:54 --> Input Class Initialized
INFO - 2021-06-29 08:26:54 --> Language Class Initialized
INFO - 2021-06-29 08:26:54 --> Language Class Initialized
INFO - 2021-06-29 08:26:54 --> Config Class Initialized
INFO - 2021-06-29 08:26:54 --> Loader Class Initialized
INFO - 2021-06-29 08:26:54 --> Helper loaded: url_helper
INFO - 2021-06-29 08:26:54 --> Helper loaded: file_helper
INFO - 2021-06-29 08:26:54 --> Helper loaded: form_helper
INFO - 2021-06-29 08:26:54 --> Helper loaded: my_helper
INFO - 2021-06-29 08:26:54 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:26:54 --> Controller Class Initialized
DEBUG - 2021-06-29 08:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-29 08:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 08:26:55 --> Final output sent to browser
DEBUG - 2021-06-29 08:26:55 --> Total execution time: 0.8994
INFO - 2021-06-29 08:27:12 --> Config Class Initialized
INFO - 2021-06-29 08:27:12 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:27:12 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:27:12 --> Utf8 Class Initialized
INFO - 2021-06-29 08:27:12 --> URI Class Initialized
INFO - 2021-06-29 08:27:12 --> Router Class Initialized
INFO - 2021-06-29 08:27:12 --> Output Class Initialized
INFO - 2021-06-29 08:27:13 --> Security Class Initialized
DEBUG - 2021-06-29 08:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:27:13 --> Input Class Initialized
INFO - 2021-06-29 08:27:13 --> Language Class Initialized
INFO - 2021-06-29 08:27:13 --> Language Class Initialized
INFO - 2021-06-29 08:27:13 --> Config Class Initialized
INFO - 2021-06-29 08:27:13 --> Loader Class Initialized
INFO - 2021-06-29 08:27:13 --> Helper loaded: url_helper
INFO - 2021-06-29 08:27:13 --> Helper loaded: file_helper
INFO - 2021-06-29 08:27:13 --> Helper loaded: form_helper
INFO - 2021-06-29 08:27:13 --> Helper loaded: my_helper
INFO - 2021-06-29 08:27:13 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:27:13 --> Controller Class Initialized
DEBUG - 2021-06-29 08:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-06-29 08:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-29 08:27:13 --> Final output sent to browser
DEBUG - 2021-06-29 08:27:13 --> Total execution time: 0.1723
INFO - 2021-06-29 08:27:50 --> Config Class Initialized
INFO - 2021-06-29 08:27:50 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:27:50 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:27:50 --> Utf8 Class Initialized
INFO - 2021-06-29 08:27:50 --> URI Class Initialized
INFO - 2021-06-29 08:27:50 --> Router Class Initialized
INFO - 2021-06-29 08:27:50 --> Output Class Initialized
INFO - 2021-06-29 08:27:50 --> Security Class Initialized
DEBUG - 2021-06-29 08:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:27:50 --> Input Class Initialized
INFO - 2021-06-29 08:27:50 --> Language Class Initialized
INFO - 2021-06-29 08:27:50 --> Language Class Initialized
INFO - 2021-06-29 08:27:50 --> Config Class Initialized
INFO - 2021-06-29 08:27:50 --> Loader Class Initialized
INFO - 2021-06-29 08:27:50 --> Helper loaded: url_helper
INFO - 2021-06-29 08:27:50 --> Helper loaded: file_helper
INFO - 2021-06-29 08:27:50 --> Helper loaded: form_helper
INFO - 2021-06-29 08:27:50 --> Helper loaded: my_helper
INFO - 2021-06-29 08:27:50 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:27:50 --> Controller Class Initialized
DEBUG - 2021-06-29 08:27:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:27:50 --> Final output sent to browser
DEBUG - 2021-06-29 08:27:50 --> Total execution time: 0.1046
INFO - 2021-06-29 08:30:41 --> Config Class Initialized
INFO - 2021-06-29 08:30:41 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:30:41 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:30:41 --> Utf8 Class Initialized
INFO - 2021-06-29 08:30:41 --> URI Class Initialized
INFO - 2021-06-29 08:30:41 --> Router Class Initialized
INFO - 2021-06-29 08:30:41 --> Output Class Initialized
INFO - 2021-06-29 08:30:41 --> Security Class Initialized
DEBUG - 2021-06-29 08:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:30:41 --> Input Class Initialized
INFO - 2021-06-29 08:30:41 --> Language Class Initialized
INFO - 2021-06-29 08:30:41 --> Language Class Initialized
INFO - 2021-06-29 08:30:41 --> Config Class Initialized
INFO - 2021-06-29 08:30:41 --> Loader Class Initialized
INFO - 2021-06-29 08:30:41 --> Helper loaded: url_helper
INFO - 2021-06-29 08:30:41 --> Helper loaded: file_helper
INFO - 2021-06-29 08:30:41 --> Helper loaded: form_helper
INFO - 2021-06-29 08:30:41 --> Helper loaded: my_helper
INFO - 2021-06-29 08:30:41 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:30:41 --> Controller Class Initialized
DEBUG - 2021-06-29 08:30:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:30:41 --> Final output sent to browser
DEBUG - 2021-06-29 08:30:41 --> Total execution time: 0.0791
INFO - 2021-06-29 08:30:43 --> Config Class Initialized
INFO - 2021-06-29 08:30:43 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:30:43 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:30:43 --> Utf8 Class Initialized
INFO - 2021-06-29 08:30:43 --> URI Class Initialized
INFO - 2021-06-29 08:30:43 --> Router Class Initialized
INFO - 2021-06-29 08:30:43 --> Output Class Initialized
INFO - 2021-06-29 08:30:43 --> Security Class Initialized
DEBUG - 2021-06-29 08:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:30:43 --> Input Class Initialized
INFO - 2021-06-29 08:30:43 --> Language Class Initialized
INFO - 2021-06-29 08:30:43 --> Language Class Initialized
INFO - 2021-06-29 08:30:43 --> Config Class Initialized
INFO - 2021-06-29 08:30:43 --> Loader Class Initialized
INFO - 2021-06-29 08:30:43 --> Helper loaded: url_helper
INFO - 2021-06-29 08:30:43 --> Helper loaded: file_helper
INFO - 2021-06-29 08:30:43 --> Helper loaded: form_helper
INFO - 2021-06-29 08:30:43 --> Helper loaded: my_helper
INFO - 2021-06-29 08:30:43 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:30:43 --> Controller Class Initialized
DEBUG - 2021-06-29 08:30:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:30:43 --> Final output sent to browser
DEBUG - 2021-06-29 08:30:43 --> Total execution time: 0.0618
INFO - 2021-06-29 08:31:17 --> Config Class Initialized
INFO - 2021-06-29 08:31:17 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:31:17 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:31:17 --> Utf8 Class Initialized
INFO - 2021-06-29 08:31:17 --> URI Class Initialized
INFO - 2021-06-29 08:31:17 --> Router Class Initialized
INFO - 2021-06-29 08:31:17 --> Output Class Initialized
INFO - 2021-06-29 08:31:17 --> Security Class Initialized
DEBUG - 2021-06-29 08:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:31:17 --> Input Class Initialized
INFO - 2021-06-29 08:31:17 --> Language Class Initialized
INFO - 2021-06-29 08:31:17 --> Language Class Initialized
INFO - 2021-06-29 08:31:17 --> Config Class Initialized
INFO - 2021-06-29 08:31:17 --> Loader Class Initialized
INFO - 2021-06-29 08:31:17 --> Helper loaded: url_helper
INFO - 2021-06-29 08:31:17 --> Helper loaded: file_helper
INFO - 2021-06-29 08:31:17 --> Helper loaded: form_helper
INFO - 2021-06-29 08:31:17 --> Helper loaded: my_helper
INFO - 2021-06-29 08:31:17 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:31:17 --> Controller Class Initialized
DEBUG - 2021-06-29 08:31:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:31:17 --> Final output sent to browser
DEBUG - 2021-06-29 08:31:17 --> Total execution time: 0.0715
INFO - 2021-06-29 08:31:25 --> Config Class Initialized
INFO - 2021-06-29 08:31:25 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:31:25 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:31:25 --> Utf8 Class Initialized
INFO - 2021-06-29 08:31:25 --> URI Class Initialized
INFO - 2021-06-29 08:31:25 --> Router Class Initialized
INFO - 2021-06-29 08:31:25 --> Output Class Initialized
INFO - 2021-06-29 08:31:25 --> Security Class Initialized
DEBUG - 2021-06-29 08:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:31:25 --> Input Class Initialized
INFO - 2021-06-29 08:31:25 --> Language Class Initialized
INFO - 2021-06-29 08:31:25 --> Language Class Initialized
INFO - 2021-06-29 08:31:25 --> Config Class Initialized
INFO - 2021-06-29 08:31:25 --> Loader Class Initialized
INFO - 2021-06-29 08:31:25 --> Helper loaded: url_helper
INFO - 2021-06-29 08:31:25 --> Helper loaded: file_helper
INFO - 2021-06-29 08:31:25 --> Helper loaded: form_helper
INFO - 2021-06-29 08:31:25 --> Helper loaded: my_helper
INFO - 2021-06-29 08:31:25 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:31:25 --> Controller Class Initialized
DEBUG - 2021-06-29 08:31:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:31:25 --> Final output sent to browser
DEBUG - 2021-06-29 08:31:25 --> Total execution time: 0.0677
INFO - 2021-06-29 08:41:32 --> Config Class Initialized
INFO - 2021-06-29 08:41:32 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:41:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:41:32 --> Utf8 Class Initialized
INFO - 2021-06-29 08:41:32 --> URI Class Initialized
INFO - 2021-06-29 08:41:32 --> Router Class Initialized
INFO - 2021-06-29 08:41:32 --> Output Class Initialized
INFO - 2021-06-29 08:41:32 --> Security Class Initialized
DEBUG - 2021-06-29 08:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:41:32 --> Input Class Initialized
INFO - 2021-06-29 08:41:32 --> Language Class Initialized
INFO - 2021-06-29 08:41:32 --> Language Class Initialized
INFO - 2021-06-29 08:41:32 --> Config Class Initialized
INFO - 2021-06-29 08:41:32 --> Loader Class Initialized
INFO - 2021-06-29 08:41:32 --> Helper loaded: url_helper
INFO - 2021-06-29 08:41:32 --> Helper loaded: file_helper
INFO - 2021-06-29 08:41:32 --> Helper loaded: form_helper
INFO - 2021-06-29 08:41:32 --> Helper loaded: my_helper
INFO - 2021-06-29 08:41:32 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:41:32 --> Controller Class Initialized
DEBUG - 2021-06-29 08:41:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:41:32 --> Final output sent to browser
DEBUG - 2021-06-29 08:41:32 --> Total execution time: 0.0669
INFO - 2021-06-29 08:41:58 --> Config Class Initialized
INFO - 2021-06-29 08:41:58 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:41:59 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:41:59 --> Utf8 Class Initialized
INFO - 2021-06-29 08:41:59 --> URI Class Initialized
INFO - 2021-06-29 08:41:59 --> Router Class Initialized
INFO - 2021-06-29 08:41:59 --> Output Class Initialized
INFO - 2021-06-29 08:41:59 --> Security Class Initialized
DEBUG - 2021-06-29 08:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:41:59 --> Input Class Initialized
INFO - 2021-06-29 08:41:59 --> Language Class Initialized
INFO - 2021-06-29 08:41:59 --> Language Class Initialized
INFO - 2021-06-29 08:41:59 --> Config Class Initialized
INFO - 2021-06-29 08:41:59 --> Loader Class Initialized
INFO - 2021-06-29 08:41:59 --> Helper loaded: url_helper
INFO - 2021-06-29 08:41:59 --> Helper loaded: file_helper
INFO - 2021-06-29 08:41:59 --> Helper loaded: form_helper
INFO - 2021-06-29 08:41:59 --> Helper loaded: my_helper
INFO - 2021-06-29 08:41:59 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:41:59 --> Controller Class Initialized
DEBUG - 2021-06-29 08:41:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:41:59 --> Final output sent to browser
DEBUG - 2021-06-29 08:41:59 --> Total execution time: 0.0595
INFO - 2021-06-29 08:42:15 --> Config Class Initialized
INFO - 2021-06-29 08:42:15 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:42:15 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:42:15 --> Utf8 Class Initialized
INFO - 2021-06-29 08:42:15 --> URI Class Initialized
INFO - 2021-06-29 08:42:15 --> Router Class Initialized
INFO - 2021-06-29 08:42:15 --> Output Class Initialized
INFO - 2021-06-29 08:42:15 --> Security Class Initialized
DEBUG - 2021-06-29 08:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:42:15 --> Input Class Initialized
INFO - 2021-06-29 08:42:15 --> Language Class Initialized
INFO - 2021-06-29 08:42:15 --> Language Class Initialized
INFO - 2021-06-29 08:42:15 --> Config Class Initialized
INFO - 2021-06-29 08:42:15 --> Loader Class Initialized
INFO - 2021-06-29 08:42:15 --> Helper loaded: url_helper
INFO - 2021-06-29 08:42:15 --> Helper loaded: file_helper
INFO - 2021-06-29 08:42:15 --> Helper loaded: form_helper
INFO - 2021-06-29 08:42:15 --> Helper loaded: my_helper
INFO - 2021-06-29 08:42:15 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:42:15 --> Controller Class Initialized
DEBUG - 2021-06-29 08:42:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:42:15 --> Final output sent to browser
DEBUG - 2021-06-29 08:42:15 --> Total execution time: 0.0705
INFO - 2021-06-29 08:42:26 --> Config Class Initialized
INFO - 2021-06-29 08:42:26 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:42:26 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:42:26 --> Utf8 Class Initialized
INFO - 2021-06-29 08:42:26 --> URI Class Initialized
INFO - 2021-06-29 08:42:26 --> Router Class Initialized
INFO - 2021-06-29 08:42:26 --> Output Class Initialized
INFO - 2021-06-29 08:42:26 --> Security Class Initialized
DEBUG - 2021-06-29 08:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:42:26 --> Input Class Initialized
INFO - 2021-06-29 08:42:26 --> Language Class Initialized
INFO - 2021-06-29 08:42:26 --> Language Class Initialized
INFO - 2021-06-29 08:42:26 --> Config Class Initialized
INFO - 2021-06-29 08:42:26 --> Loader Class Initialized
INFO - 2021-06-29 08:42:26 --> Helper loaded: url_helper
INFO - 2021-06-29 08:42:26 --> Helper loaded: file_helper
INFO - 2021-06-29 08:42:26 --> Helper loaded: form_helper
INFO - 2021-06-29 08:42:26 --> Helper loaded: my_helper
INFO - 2021-06-29 08:42:26 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:42:26 --> Controller Class Initialized
DEBUG - 2021-06-29 08:42:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:42:26 --> Final output sent to browser
DEBUG - 2021-06-29 08:42:26 --> Total execution time: 0.0632
INFO - 2021-06-29 08:43:21 --> Config Class Initialized
INFO - 2021-06-29 08:43:21 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:43:21 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:43:21 --> Utf8 Class Initialized
INFO - 2021-06-29 08:43:21 --> URI Class Initialized
INFO - 2021-06-29 08:43:21 --> Router Class Initialized
INFO - 2021-06-29 08:43:21 --> Output Class Initialized
INFO - 2021-06-29 08:43:21 --> Security Class Initialized
DEBUG - 2021-06-29 08:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:43:21 --> Input Class Initialized
INFO - 2021-06-29 08:43:21 --> Language Class Initialized
INFO - 2021-06-29 08:43:21 --> Language Class Initialized
INFO - 2021-06-29 08:43:21 --> Config Class Initialized
INFO - 2021-06-29 08:43:21 --> Loader Class Initialized
INFO - 2021-06-29 08:43:21 --> Helper loaded: url_helper
INFO - 2021-06-29 08:43:21 --> Helper loaded: file_helper
INFO - 2021-06-29 08:43:21 --> Helper loaded: form_helper
INFO - 2021-06-29 08:43:21 --> Helper loaded: my_helper
INFO - 2021-06-29 08:43:21 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:43:21 --> Controller Class Initialized
DEBUG - 2021-06-29 08:43:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:43:21 --> Final output sent to browser
DEBUG - 2021-06-29 08:43:21 --> Total execution time: 0.0499
INFO - 2021-06-29 08:49:00 --> Config Class Initialized
INFO - 2021-06-29 08:49:00 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:49:00 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:49:00 --> Utf8 Class Initialized
INFO - 2021-06-29 08:49:00 --> URI Class Initialized
INFO - 2021-06-29 08:49:00 --> Router Class Initialized
INFO - 2021-06-29 08:49:00 --> Output Class Initialized
INFO - 2021-06-29 08:49:00 --> Security Class Initialized
DEBUG - 2021-06-29 08:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:49:00 --> Input Class Initialized
INFO - 2021-06-29 08:49:00 --> Language Class Initialized
INFO - 2021-06-29 08:49:00 --> Language Class Initialized
INFO - 2021-06-29 08:49:00 --> Config Class Initialized
INFO - 2021-06-29 08:49:00 --> Loader Class Initialized
INFO - 2021-06-29 08:49:00 --> Helper loaded: url_helper
INFO - 2021-06-29 08:49:00 --> Helper loaded: file_helper
INFO - 2021-06-29 08:49:00 --> Helper loaded: form_helper
INFO - 2021-06-29 08:49:00 --> Helper loaded: my_helper
INFO - 2021-06-29 08:49:00 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:49:00 --> Controller Class Initialized
DEBUG - 2021-06-29 08:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:49:00 --> Final output sent to browser
DEBUG - 2021-06-29 08:49:00 --> Total execution time: 0.0757
INFO - 2021-06-29 08:52:39 --> Config Class Initialized
INFO - 2021-06-29 08:52:39 --> Hooks Class Initialized
DEBUG - 2021-06-29 08:52:39 --> UTF-8 Support Enabled
INFO - 2021-06-29 08:52:39 --> Utf8 Class Initialized
INFO - 2021-06-29 08:52:39 --> URI Class Initialized
INFO - 2021-06-29 08:52:39 --> Router Class Initialized
INFO - 2021-06-29 08:52:39 --> Output Class Initialized
INFO - 2021-06-29 08:52:39 --> Security Class Initialized
DEBUG - 2021-06-29 08:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 08:52:39 --> Input Class Initialized
INFO - 2021-06-29 08:52:39 --> Language Class Initialized
INFO - 2021-06-29 08:52:39 --> Language Class Initialized
INFO - 2021-06-29 08:52:39 --> Config Class Initialized
INFO - 2021-06-29 08:52:39 --> Loader Class Initialized
INFO - 2021-06-29 08:52:39 --> Helper loaded: url_helper
INFO - 2021-06-29 08:52:39 --> Helper loaded: file_helper
INFO - 2021-06-29 08:52:39 --> Helper loaded: form_helper
INFO - 2021-06-29 08:52:39 --> Helper loaded: my_helper
INFO - 2021-06-29 08:52:39 --> Database Driver Class Initialized
DEBUG - 2021-06-29 08:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 08:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 08:52:39 --> Controller Class Initialized
DEBUG - 2021-06-29 08:52:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 08:52:39 --> Final output sent to browser
DEBUG - 2021-06-29 08:52:39 --> Total execution time: 0.0882
INFO - 2021-06-29 09:30:26 --> Config Class Initialized
INFO - 2021-06-29 09:30:26 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:30:26 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:30:26 --> Utf8 Class Initialized
INFO - 2021-06-29 09:30:26 --> URI Class Initialized
INFO - 2021-06-29 09:30:26 --> Router Class Initialized
INFO - 2021-06-29 09:30:26 --> Output Class Initialized
INFO - 2021-06-29 09:30:26 --> Security Class Initialized
DEBUG - 2021-06-29 09:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:30:26 --> Input Class Initialized
INFO - 2021-06-29 09:30:26 --> Language Class Initialized
INFO - 2021-06-29 09:30:26 --> Language Class Initialized
INFO - 2021-06-29 09:30:26 --> Config Class Initialized
INFO - 2021-06-29 09:30:26 --> Loader Class Initialized
INFO - 2021-06-29 09:30:26 --> Helper loaded: url_helper
INFO - 2021-06-29 09:30:26 --> Helper loaded: file_helper
INFO - 2021-06-29 09:30:26 --> Helper loaded: form_helper
INFO - 2021-06-29 09:30:26 --> Helper loaded: my_helper
INFO - 2021-06-29 09:30:26 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:30:26 --> Controller Class Initialized
DEBUG - 2021-06-29 09:30:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:30:26 --> Final output sent to browser
DEBUG - 2021-06-29 09:30:26 --> Total execution time: 0.0540
INFO - 2021-06-29 09:32:09 --> Config Class Initialized
INFO - 2021-06-29 09:32:09 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:32:09 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:32:09 --> Utf8 Class Initialized
INFO - 2021-06-29 09:32:09 --> URI Class Initialized
INFO - 2021-06-29 09:32:09 --> Router Class Initialized
INFO - 2021-06-29 09:32:09 --> Output Class Initialized
INFO - 2021-06-29 09:32:09 --> Security Class Initialized
DEBUG - 2021-06-29 09:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:32:09 --> Input Class Initialized
INFO - 2021-06-29 09:32:09 --> Language Class Initialized
INFO - 2021-06-29 09:32:09 --> Language Class Initialized
INFO - 2021-06-29 09:32:09 --> Config Class Initialized
INFO - 2021-06-29 09:32:09 --> Loader Class Initialized
INFO - 2021-06-29 09:32:09 --> Helper loaded: url_helper
INFO - 2021-06-29 09:32:09 --> Helper loaded: file_helper
INFO - 2021-06-29 09:32:09 --> Helper loaded: form_helper
INFO - 2021-06-29 09:32:09 --> Helper loaded: my_helper
INFO - 2021-06-29 09:32:09 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:32:09 --> Controller Class Initialized
DEBUG - 2021-06-29 09:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:32:09 --> Final output sent to browser
DEBUG - 2021-06-29 09:32:09 --> Total execution time: 0.0692
INFO - 2021-06-29 09:36:41 --> Config Class Initialized
INFO - 2021-06-29 09:36:41 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:36:41 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:36:41 --> Utf8 Class Initialized
INFO - 2021-06-29 09:36:41 --> URI Class Initialized
INFO - 2021-06-29 09:36:41 --> Router Class Initialized
INFO - 2021-06-29 09:36:41 --> Output Class Initialized
INFO - 2021-06-29 09:36:41 --> Security Class Initialized
DEBUG - 2021-06-29 09:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:36:41 --> Input Class Initialized
INFO - 2021-06-29 09:36:41 --> Language Class Initialized
INFO - 2021-06-29 09:36:41 --> Language Class Initialized
INFO - 2021-06-29 09:36:41 --> Config Class Initialized
INFO - 2021-06-29 09:36:41 --> Loader Class Initialized
INFO - 2021-06-29 09:36:41 --> Helper loaded: url_helper
INFO - 2021-06-29 09:36:41 --> Helper loaded: file_helper
INFO - 2021-06-29 09:36:41 --> Helper loaded: form_helper
INFO - 2021-06-29 09:36:41 --> Helper loaded: my_helper
INFO - 2021-06-29 09:36:41 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:36:42 --> Controller Class Initialized
DEBUG - 2021-06-29 09:36:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:36:42 --> Final output sent to browser
DEBUG - 2021-06-29 09:36:42 --> Total execution time: 0.0688
INFO - 2021-06-29 09:40:04 --> Config Class Initialized
INFO - 2021-06-29 09:40:04 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:40:04 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:40:04 --> Utf8 Class Initialized
INFO - 2021-06-29 09:40:04 --> URI Class Initialized
INFO - 2021-06-29 09:40:04 --> Router Class Initialized
INFO - 2021-06-29 09:40:04 --> Output Class Initialized
INFO - 2021-06-29 09:40:04 --> Security Class Initialized
DEBUG - 2021-06-29 09:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:40:04 --> Input Class Initialized
INFO - 2021-06-29 09:40:04 --> Language Class Initialized
INFO - 2021-06-29 09:40:04 --> Language Class Initialized
INFO - 2021-06-29 09:40:04 --> Config Class Initialized
INFO - 2021-06-29 09:40:04 --> Loader Class Initialized
INFO - 2021-06-29 09:40:04 --> Helper loaded: url_helper
INFO - 2021-06-29 09:40:04 --> Helper loaded: file_helper
INFO - 2021-06-29 09:40:04 --> Helper loaded: form_helper
INFO - 2021-06-29 09:40:04 --> Helper loaded: my_helper
INFO - 2021-06-29 09:40:04 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:40:04 --> Controller Class Initialized
DEBUG - 2021-06-29 09:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:40:04 --> Final output sent to browser
DEBUG - 2021-06-29 09:40:04 --> Total execution time: 0.0513
INFO - 2021-06-29 09:42:30 --> Config Class Initialized
INFO - 2021-06-29 09:42:30 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:42:30 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:42:30 --> Utf8 Class Initialized
INFO - 2021-06-29 09:42:30 --> URI Class Initialized
INFO - 2021-06-29 09:42:30 --> Router Class Initialized
INFO - 2021-06-29 09:42:30 --> Output Class Initialized
INFO - 2021-06-29 09:42:30 --> Security Class Initialized
DEBUG - 2021-06-29 09:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:42:30 --> Input Class Initialized
INFO - 2021-06-29 09:42:30 --> Language Class Initialized
INFO - 2021-06-29 09:42:30 --> Language Class Initialized
INFO - 2021-06-29 09:42:30 --> Config Class Initialized
INFO - 2021-06-29 09:42:30 --> Loader Class Initialized
INFO - 2021-06-29 09:42:30 --> Helper loaded: url_helper
INFO - 2021-06-29 09:42:30 --> Helper loaded: file_helper
INFO - 2021-06-29 09:42:30 --> Helper loaded: form_helper
INFO - 2021-06-29 09:42:30 --> Helper loaded: my_helper
INFO - 2021-06-29 09:42:30 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:42:30 --> Controller Class Initialized
DEBUG - 2021-06-29 09:42:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:42:30 --> Final output sent to browser
DEBUG - 2021-06-29 09:42:30 --> Total execution time: 0.0599
INFO - 2021-06-29 09:42:50 --> Config Class Initialized
INFO - 2021-06-29 09:42:50 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:42:50 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:42:50 --> Utf8 Class Initialized
INFO - 2021-06-29 09:42:50 --> URI Class Initialized
INFO - 2021-06-29 09:42:50 --> Router Class Initialized
INFO - 2021-06-29 09:42:50 --> Output Class Initialized
INFO - 2021-06-29 09:42:50 --> Security Class Initialized
DEBUG - 2021-06-29 09:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:42:50 --> Input Class Initialized
INFO - 2021-06-29 09:42:50 --> Language Class Initialized
INFO - 2021-06-29 09:42:50 --> Language Class Initialized
INFO - 2021-06-29 09:42:50 --> Config Class Initialized
INFO - 2021-06-29 09:42:50 --> Loader Class Initialized
INFO - 2021-06-29 09:42:50 --> Helper loaded: url_helper
INFO - 2021-06-29 09:42:50 --> Helper loaded: file_helper
INFO - 2021-06-29 09:42:50 --> Helper loaded: form_helper
INFO - 2021-06-29 09:42:50 --> Helper loaded: my_helper
INFO - 2021-06-29 09:42:50 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:42:50 --> Controller Class Initialized
DEBUG - 2021-06-29 09:42:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:42:50 --> Final output sent to browser
DEBUG - 2021-06-29 09:42:50 --> Total execution time: 0.0681
INFO - 2021-06-29 09:43:39 --> Config Class Initialized
INFO - 2021-06-29 09:43:39 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:43:39 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:43:39 --> Utf8 Class Initialized
INFO - 2021-06-29 09:43:39 --> URI Class Initialized
INFO - 2021-06-29 09:43:39 --> Router Class Initialized
INFO - 2021-06-29 09:43:39 --> Output Class Initialized
INFO - 2021-06-29 09:43:39 --> Security Class Initialized
DEBUG - 2021-06-29 09:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:43:39 --> Input Class Initialized
INFO - 2021-06-29 09:43:39 --> Language Class Initialized
INFO - 2021-06-29 09:43:39 --> Language Class Initialized
INFO - 2021-06-29 09:43:39 --> Config Class Initialized
INFO - 2021-06-29 09:43:39 --> Loader Class Initialized
INFO - 2021-06-29 09:43:39 --> Helper loaded: url_helper
INFO - 2021-06-29 09:43:39 --> Helper loaded: file_helper
INFO - 2021-06-29 09:43:39 --> Helper loaded: form_helper
INFO - 2021-06-29 09:43:39 --> Helper loaded: my_helper
INFO - 2021-06-29 09:43:39 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:43:39 --> Controller Class Initialized
DEBUG - 2021-06-29 09:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:43:39 --> Final output sent to browser
DEBUG - 2021-06-29 09:43:39 --> Total execution time: 0.0648
INFO - 2021-06-29 09:43:56 --> Config Class Initialized
INFO - 2021-06-29 09:43:56 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:43:56 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:43:56 --> Utf8 Class Initialized
INFO - 2021-06-29 09:43:56 --> URI Class Initialized
INFO - 2021-06-29 09:43:56 --> Router Class Initialized
INFO - 2021-06-29 09:43:56 --> Output Class Initialized
INFO - 2021-06-29 09:43:56 --> Security Class Initialized
DEBUG - 2021-06-29 09:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:43:56 --> Input Class Initialized
INFO - 2021-06-29 09:43:56 --> Language Class Initialized
INFO - 2021-06-29 09:43:56 --> Language Class Initialized
INFO - 2021-06-29 09:43:56 --> Config Class Initialized
INFO - 2021-06-29 09:43:56 --> Loader Class Initialized
INFO - 2021-06-29 09:43:56 --> Helper loaded: url_helper
INFO - 2021-06-29 09:43:56 --> Helper loaded: file_helper
INFO - 2021-06-29 09:43:56 --> Helper loaded: form_helper
INFO - 2021-06-29 09:43:56 --> Helper loaded: my_helper
INFO - 2021-06-29 09:43:56 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:43:56 --> Controller Class Initialized
DEBUG - 2021-06-29 09:43:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:43:56 --> Final output sent to browser
DEBUG - 2021-06-29 09:43:56 --> Total execution time: 0.0688
INFO - 2021-06-29 09:44:57 --> Config Class Initialized
INFO - 2021-06-29 09:44:57 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:44:57 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:44:57 --> Utf8 Class Initialized
INFO - 2021-06-29 09:44:57 --> URI Class Initialized
INFO - 2021-06-29 09:44:57 --> Router Class Initialized
INFO - 2021-06-29 09:44:57 --> Output Class Initialized
INFO - 2021-06-29 09:44:57 --> Security Class Initialized
DEBUG - 2021-06-29 09:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:44:57 --> Input Class Initialized
INFO - 2021-06-29 09:44:57 --> Language Class Initialized
INFO - 2021-06-29 09:44:57 --> Language Class Initialized
INFO - 2021-06-29 09:44:57 --> Config Class Initialized
INFO - 2021-06-29 09:44:57 --> Loader Class Initialized
INFO - 2021-06-29 09:44:57 --> Helper loaded: url_helper
INFO - 2021-06-29 09:44:57 --> Helper loaded: file_helper
INFO - 2021-06-29 09:44:57 --> Helper loaded: form_helper
INFO - 2021-06-29 09:44:57 --> Helper loaded: my_helper
INFO - 2021-06-29 09:44:57 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:44:57 --> Controller Class Initialized
DEBUG - 2021-06-29 09:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:44:57 --> Final output sent to browser
DEBUG - 2021-06-29 09:44:57 --> Total execution time: 0.0676
INFO - 2021-06-29 09:45:45 --> Config Class Initialized
INFO - 2021-06-29 09:45:45 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:45:45 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:45:45 --> Utf8 Class Initialized
INFO - 2021-06-29 09:45:45 --> URI Class Initialized
INFO - 2021-06-29 09:45:45 --> Router Class Initialized
INFO - 2021-06-29 09:45:45 --> Output Class Initialized
INFO - 2021-06-29 09:45:45 --> Security Class Initialized
DEBUG - 2021-06-29 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:45:45 --> Input Class Initialized
INFO - 2021-06-29 09:45:45 --> Language Class Initialized
INFO - 2021-06-29 09:45:45 --> Language Class Initialized
INFO - 2021-06-29 09:45:45 --> Config Class Initialized
INFO - 2021-06-29 09:45:45 --> Loader Class Initialized
INFO - 2021-06-29 09:45:45 --> Helper loaded: url_helper
INFO - 2021-06-29 09:45:45 --> Helper loaded: file_helper
INFO - 2021-06-29 09:45:45 --> Helper loaded: form_helper
INFO - 2021-06-29 09:45:45 --> Helper loaded: my_helper
INFO - 2021-06-29 09:45:45 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:45:45 --> Controller Class Initialized
DEBUG - 2021-06-29 09:45:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:45:45 --> Final output sent to browser
DEBUG - 2021-06-29 09:45:45 --> Total execution time: 0.0745
INFO - 2021-06-29 09:45:53 --> Config Class Initialized
INFO - 2021-06-29 09:45:53 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:45:53 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:45:53 --> Utf8 Class Initialized
INFO - 2021-06-29 09:45:53 --> URI Class Initialized
INFO - 2021-06-29 09:45:53 --> Router Class Initialized
INFO - 2021-06-29 09:45:53 --> Output Class Initialized
INFO - 2021-06-29 09:45:53 --> Security Class Initialized
DEBUG - 2021-06-29 09:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:45:53 --> Input Class Initialized
INFO - 2021-06-29 09:45:53 --> Language Class Initialized
INFO - 2021-06-29 09:45:53 --> Language Class Initialized
INFO - 2021-06-29 09:45:53 --> Config Class Initialized
INFO - 2021-06-29 09:45:53 --> Loader Class Initialized
INFO - 2021-06-29 09:45:53 --> Helper loaded: url_helper
INFO - 2021-06-29 09:45:53 --> Helper loaded: file_helper
INFO - 2021-06-29 09:45:53 --> Helper loaded: form_helper
INFO - 2021-06-29 09:45:53 --> Helper loaded: my_helper
INFO - 2021-06-29 09:45:53 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:45:53 --> Controller Class Initialized
DEBUG - 2021-06-29 09:45:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:45:53 --> Final output sent to browser
DEBUG - 2021-06-29 09:45:53 --> Total execution time: 0.0682
INFO - 2021-06-29 09:52:54 --> Config Class Initialized
INFO - 2021-06-29 09:52:54 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:52:54 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:52:54 --> Utf8 Class Initialized
INFO - 2021-06-29 09:52:54 --> URI Class Initialized
INFO - 2021-06-29 09:52:54 --> Router Class Initialized
INFO - 2021-06-29 09:52:54 --> Output Class Initialized
INFO - 2021-06-29 09:52:54 --> Security Class Initialized
DEBUG - 2021-06-29 09:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:52:54 --> Input Class Initialized
INFO - 2021-06-29 09:52:54 --> Language Class Initialized
INFO - 2021-06-29 09:52:54 --> Language Class Initialized
INFO - 2021-06-29 09:52:54 --> Config Class Initialized
INFO - 2021-06-29 09:52:54 --> Loader Class Initialized
INFO - 2021-06-29 09:52:54 --> Helper loaded: url_helper
INFO - 2021-06-29 09:52:54 --> Helper loaded: file_helper
INFO - 2021-06-29 09:52:54 --> Helper loaded: form_helper
INFO - 2021-06-29 09:52:54 --> Helper loaded: my_helper
INFO - 2021-06-29 09:52:54 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:52:54 --> Controller Class Initialized
DEBUG - 2021-06-29 09:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:52:54 --> Final output sent to browser
DEBUG - 2021-06-29 09:52:54 --> Total execution time: 0.0976
INFO - 2021-06-29 09:56:07 --> Config Class Initialized
INFO - 2021-06-29 09:56:07 --> Hooks Class Initialized
DEBUG - 2021-06-29 09:56:07 --> UTF-8 Support Enabled
INFO - 2021-06-29 09:56:07 --> Utf8 Class Initialized
INFO - 2021-06-29 09:56:07 --> URI Class Initialized
INFO - 2021-06-29 09:56:07 --> Router Class Initialized
INFO - 2021-06-29 09:56:07 --> Output Class Initialized
INFO - 2021-06-29 09:56:07 --> Security Class Initialized
DEBUG - 2021-06-29 09:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 09:56:07 --> Input Class Initialized
INFO - 2021-06-29 09:56:07 --> Language Class Initialized
INFO - 2021-06-29 09:56:07 --> Language Class Initialized
INFO - 2021-06-29 09:56:07 --> Config Class Initialized
INFO - 2021-06-29 09:56:07 --> Loader Class Initialized
INFO - 2021-06-29 09:56:07 --> Helper loaded: url_helper
INFO - 2021-06-29 09:56:07 --> Helper loaded: file_helper
INFO - 2021-06-29 09:56:07 --> Helper loaded: form_helper
INFO - 2021-06-29 09:56:07 --> Helper loaded: my_helper
INFO - 2021-06-29 09:56:07 --> Database Driver Class Initialized
DEBUG - 2021-06-29 09:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 09:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 09:56:07 --> Controller Class Initialized
DEBUG - 2021-06-29 09:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 09:56:07 --> Final output sent to browser
DEBUG - 2021-06-29 09:56:07 --> Total execution time: 0.0668
INFO - 2021-06-29 10:06:31 --> Config Class Initialized
INFO - 2021-06-29 10:06:31 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:06:31 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:06:31 --> Utf8 Class Initialized
INFO - 2021-06-29 10:06:31 --> URI Class Initialized
INFO - 2021-06-29 10:06:31 --> Router Class Initialized
INFO - 2021-06-29 10:06:31 --> Output Class Initialized
INFO - 2021-06-29 10:06:31 --> Security Class Initialized
DEBUG - 2021-06-29 10:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:06:31 --> Input Class Initialized
INFO - 2021-06-29 10:06:31 --> Language Class Initialized
INFO - 2021-06-29 10:06:31 --> Language Class Initialized
INFO - 2021-06-29 10:06:31 --> Config Class Initialized
INFO - 2021-06-29 10:06:31 --> Loader Class Initialized
INFO - 2021-06-29 10:06:31 --> Helper loaded: url_helper
INFO - 2021-06-29 10:06:31 --> Helper loaded: file_helper
INFO - 2021-06-29 10:06:31 --> Helper loaded: form_helper
INFO - 2021-06-29 10:06:31 --> Helper loaded: my_helper
INFO - 2021-06-29 10:06:31 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:06:31 --> Controller Class Initialized
DEBUG - 2021-06-29 10:06:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:06:31 --> Final output sent to browser
DEBUG - 2021-06-29 10:06:31 --> Total execution time: 0.0566
INFO - 2021-06-29 10:06:43 --> Config Class Initialized
INFO - 2021-06-29 10:06:43 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:06:43 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:06:43 --> Utf8 Class Initialized
INFO - 2021-06-29 10:06:43 --> URI Class Initialized
INFO - 2021-06-29 10:06:43 --> Router Class Initialized
INFO - 2021-06-29 10:06:43 --> Output Class Initialized
INFO - 2021-06-29 10:06:43 --> Security Class Initialized
DEBUG - 2021-06-29 10:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:06:43 --> Input Class Initialized
INFO - 2021-06-29 10:06:43 --> Language Class Initialized
INFO - 2021-06-29 10:06:43 --> Language Class Initialized
INFO - 2021-06-29 10:06:43 --> Config Class Initialized
INFO - 2021-06-29 10:06:43 --> Loader Class Initialized
INFO - 2021-06-29 10:06:43 --> Helper loaded: url_helper
INFO - 2021-06-29 10:06:43 --> Helper loaded: file_helper
INFO - 2021-06-29 10:06:43 --> Helper loaded: form_helper
INFO - 2021-06-29 10:06:43 --> Helper loaded: my_helper
INFO - 2021-06-29 10:06:43 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:06:43 --> Controller Class Initialized
DEBUG - 2021-06-29 10:06:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:06:43 --> Final output sent to browser
DEBUG - 2021-06-29 10:06:43 --> Total execution time: 0.0498
INFO - 2021-06-29 10:06:51 --> Config Class Initialized
INFO - 2021-06-29 10:06:51 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:06:51 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:06:51 --> Utf8 Class Initialized
INFO - 2021-06-29 10:06:51 --> URI Class Initialized
INFO - 2021-06-29 10:06:51 --> Router Class Initialized
INFO - 2021-06-29 10:06:51 --> Output Class Initialized
INFO - 2021-06-29 10:06:51 --> Security Class Initialized
DEBUG - 2021-06-29 10:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:06:51 --> Input Class Initialized
INFO - 2021-06-29 10:06:51 --> Language Class Initialized
INFO - 2021-06-29 10:06:51 --> Language Class Initialized
INFO - 2021-06-29 10:06:51 --> Config Class Initialized
INFO - 2021-06-29 10:06:51 --> Loader Class Initialized
INFO - 2021-06-29 10:06:51 --> Helper loaded: url_helper
INFO - 2021-06-29 10:06:51 --> Helper loaded: file_helper
INFO - 2021-06-29 10:06:51 --> Helper loaded: form_helper
INFO - 2021-06-29 10:06:51 --> Helper loaded: my_helper
INFO - 2021-06-29 10:06:51 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:06:51 --> Controller Class Initialized
DEBUG - 2021-06-29 10:06:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:06:51 --> Final output sent to browser
DEBUG - 2021-06-29 10:06:51 --> Total execution time: 0.0651
INFO - 2021-06-29 10:07:01 --> Config Class Initialized
INFO - 2021-06-29 10:07:01 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:07:01 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:07:01 --> Utf8 Class Initialized
INFO - 2021-06-29 10:07:01 --> URI Class Initialized
INFO - 2021-06-29 10:07:01 --> Router Class Initialized
INFO - 2021-06-29 10:07:01 --> Output Class Initialized
INFO - 2021-06-29 10:07:01 --> Security Class Initialized
DEBUG - 2021-06-29 10:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:07:01 --> Input Class Initialized
INFO - 2021-06-29 10:07:01 --> Language Class Initialized
INFO - 2021-06-29 10:07:01 --> Language Class Initialized
INFO - 2021-06-29 10:07:01 --> Config Class Initialized
INFO - 2021-06-29 10:07:01 --> Loader Class Initialized
INFO - 2021-06-29 10:07:01 --> Helper loaded: url_helper
INFO - 2021-06-29 10:07:01 --> Helper loaded: file_helper
INFO - 2021-06-29 10:07:01 --> Helper loaded: form_helper
INFO - 2021-06-29 10:07:01 --> Helper loaded: my_helper
INFO - 2021-06-29 10:07:01 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:07:01 --> Controller Class Initialized
DEBUG - 2021-06-29 10:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:07:01 --> Final output sent to browser
DEBUG - 2021-06-29 10:07:01 --> Total execution time: 0.0618
INFO - 2021-06-29 10:09:38 --> Config Class Initialized
INFO - 2021-06-29 10:09:38 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:09:38 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:09:38 --> Utf8 Class Initialized
INFO - 2021-06-29 10:09:38 --> URI Class Initialized
INFO - 2021-06-29 10:09:38 --> Router Class Initialized
INFO - 2021-06-29 10:09:38 --> Output Class Initialized
INFO - 2021-06-29 10:09:38 --> Security Class Initialized
DEBUG - 2021-06-29 10:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:09:38 --> Input Class Initialized
INFO - 2021-06-29 10:09:38 --> Language Class Initialized
INFO - 2021-06-29 10:09:38 --> Language Class Initialized
INFO - 2021-06-29 10:09:38 --> Config Class Initialized
INFO - 2021-06-29 10:09:38 --> Loader Class Initialized
INFO - 2021-06-29 10:09:38 --> Helper loaded: url_helper
INFO - 2021-06-29 10:09:38 --> Helper loaded: file_helper
INFO - 2021-06-29 10:09:38 --> Helper loaded: form_helper
INFO - 2021-06-29 10:09:38 --> Helper loaded: my_helper
INFO - 2021-06-29 10:09:38 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:09:38 --> Controller Class Initialized
DEBUG - 2021-06-29 10:09:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:09:38 --> Final output sent to browser
DEBUG - 2021-06-29 10:09:38 --> Total execution time: 0.0676
INFO - 2021-06-29 10:22:36 --> Config Class Initialized
INFO - 2021-06-29 10:22:36 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:22:36 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:22:36 --> Utf8 Class Initialized
INFO - 2021-06-29 10:22:36 --> URI Class Initialized
INFO - 2021-06-29 10:22:36 --> Router Class Initialized
INFO - 2021-06-29 10:22:36 --> Output Class Initialized
INFO - 2021-06-29 10:22:36 --> Security Class Initialized
DEBUG - 2021-06-29 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:22:36 --> Input Class Initialized
INFO - 2021-06-29 10:22:36 --> Language Class Initialized
INFO - 2021-06-29 10:22:36 --> Language Class Initialized
INFO - 2021-06-29 10:22:36 --> Config Class Initialized
INFO - 2021-06-29 10:22:36 --> Loader Class Initialized
INFO - 2021-06-29 10:22:36 --> Helper loaded: url_helper
INFO - 2021-06-29 10:22:36 --> Helper loaded: file_helper
INFO - 2021-06-29 10:22:36 --> Helper loaded: form_helper
INFO - 2021-06-29 10:22:36 --> Helper loaded: my_helper
INFO - 2021-06-29 10:22:36 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:22:36 --> Controller Class Initialized
DEBUG - 2021-06-29 10:22:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:22:36 --> Final output sent to browser
DEBUG - 2021-06-29 10:22:36 --> Total execution time: 0.0779
INFO - 2021-06-29 10:23:02 --> Config Class Initialized
INFO - 2021-06-29 10:23:02 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:23:02 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:23:02 --> Utf8 Class Initialized
INFO - 2021-06-29 10:23:02 --> URI Class Initialized
INFO - 2021-06-29 10:23:02 --> Router Class Initialized
INFO - 2021-06-29 10:23:02 --> Output Class Initialized
INFO - 2021-06-29 10:23:02 --> Security Class Initialized
DEBUG - 2021-06-29 10:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:23:02 --> Input Class Initialized
INFO - 2021-06-29 10:23:02 --> Language Class Initialized
INFO - 2021-06-29 10:23:02 --> Language Class Initialized
INFO - 2021-06-29 10:23:02 --> Config Class Initialized
INFO - 2021-06-29 10:23:02 --> Loader Class Initialized
INFO - 2021-06-29 10:23:02 --> Helper loaded: url_helper
INFO - 2021-06-29 10:23:02 --> Helper loaded: file_helper
INFO - 2021-06-29 10:23:02 --> Helper loaded: form_helper
INFO - 2021-06-29 10:23:02 --> Helper loaded: my_helper
INFO - 2021-06-29 10:23:02 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:23:02 --> Controller Class Initialized
DEBUG - 2021-06-29 10:23:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:23:02 --> Final output sent to browser
DEBUG - 2021-06-29 10:23:02 --> Total execution time: 0.0831
INFO - 2021-06-29 10:24:31 --> Config Class Initialized
INFO - 2021-06-29 10:24:31 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:24:31 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:24:31 --> Utf8 Class Initialized
INFO - 2021-06-29 10:24:31 --> URI Class Initialized
INFO - 2021-06-29 10:24:31 --> Router Class Initialized
INFO - 2021-06-29 10:24:31 --> Output Class Initialized
INFO - 2021-06-29 10:24:31 --> Security Class Initialized
DEBUG - 2021-06-29 10:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:24:31 --> Input Class Initialized
INFO - 2021-06-29 10:24:31 --> Language Class Initialized
INFO - 2021-06-29 10:24:31 --> Language Class Initialized
INFO - 2021-06-29 10:24:31 --> Config Class Initialized
INFO - 2021-06-29 10:24:31 --> Loader Class Initialized
INFO - 2021-06-29 10:24:31 --> Helper loaded: url_helper
INFO - 2021-06-29 10:24:31 --> Helper loaded: file_helper
INFO - 2021-06-29 10:24:31 --> Helper loaded: form_helper
INFO - 2021-06-29 10:24:31 --> Helper loaded: my_helper
INFO - 2021-06-29 10:24:31 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:24:31 --> Controller Class Initialized
DEBUG - 2021-06-29 10:24:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:24:31 --> Final output sent to browser
DEBUG - 2021-06-29 10:24:31 --> Total execution time: 0.0486
INFO - 2021-06-29 10:26:26 --> Config Class Initialized
INFO - 2021-06-29 10:26:26 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:26:26 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:26:26 --> Utf8 Class Initialized
INFO - 2021-06-29 10:26:26 --> URI Class Initialized
INFO - 2021-06-29 10:26:26 --> Router Class Initialized
INFO - 2021-06-29 10:26:26 --> Output Class Initialized
INFO - 2021-06-29 10:26:26 --> Security Class Initialized
DEBUG - 2021-06-29 10:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:26:26 --> Input Class Initialized
INFO - 2021-06-29 10:26:26 --> Language Class Initialized
INFO - 2021-06-29 10:26:27 --> Language Class Initialized
INFO - 2021-06-29 10:26:27 --> Config Class Initialized
INFO - 2021-06-29 10:26:27 --> Loader Class Initialized
INFO - 2021-06-29 10:26:27 --> Helper loaded: url_helper
INFO - 2021-06-29 10:26:27 --> Helper loaded: file_helper
INFO - 2021-06-29 10:26:27 --> Helper loaded: form_helper
INFO - 2021-06-29 10:26:27 --> Helper loaded: my_helper
INFO - 2021-06-29 10:26:27 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:26:27 --> Controller Class Initialized
DEBUG - 2021-06-29 10:26:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:26:27 --> Final output sent to browser
DEBUG - 2021-06-29 10:26:27 --> Total execution time: 0.0625
INFO - 2021-06-29 10:26:55 --> Config Class Initialized
INFO - 2021-06-29 10:26:55 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:26:55 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:26:55 --> Utf8 Class Initialized
INFO - 2021-06-29 10:26:55 --> URI Class Initialized
INFO - 2021-06-29 10:26:55 --> Router Class Initialized
INFO - 2021-06-29 10:26:55 --> Output Class Initialized
INFO - 2021-06-29 10:26:55 --> Security Class Initialized
DEBUG - 2021-06-29 10:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:26:55 --> Input Class Initialized
INFO - 2021-06-29 10:26:55 --> Language Class Initialized
INFO - 2021-06-29 10:26:55 --> Language Class Initialized
INFO - 2021-06-29 10:26:55 --> Config Class Initialized
INFO - 2021-06-29 10:26:55 --> Loader Class Initialized
INFO - 2021-06-29 10:26:55 --> Helper loaded: url_helper
INFO - 2021-06-29 10:26:55 --> Helper loaded: file_helper
INFO - 2021-06-29 10:26:55 --> Helper loaded: form_helper
INFO - 2021-06-29 10:26:55 --> Helper loaded: my_helper
INFO - 2021-06-29 10:26:55 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:26:55 --> Controller Class Initialized
DEBUG - 2021-06-29 10:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:26:55 --> Final output sent to browser
DEBUG - 2021-06-29 10:26:55 --> Total execution time: 0.0741
INFO - 2021-06-29 10:28:21 --> Config Class Initialized
INFO - 2021-06-29 10:28:21 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:28:21 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:28:21 --> Utf8 Class Initialized
INFO - 2021-06-29 10:28:21 --> URI Class Initialized
INFO - 2021-06-29 10:28:21 --> Router Class Initialized
INFO - 2021-06-29 10:28:21 --> Output Class Initialized
INFO - 2021-06-29 10:28:21 --> Security Class Initialized
DEBUG - 2021-06-29 10:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:28:21 --> Input Class Initialized
INFO - 2021-06-29 10:28:21 --> Language Class Initialized
INFO - 2021-06-29 10:28:21 --> Language Class Initialized
INFO - 2021-06-29 10:28:21 --> Config Class Initialized
INFO - 2021-06-29 10:28:21 --> Loader Class Initialized
INFO - 2021-06-29 10:28:21 --> Helper loaded: url_helper
INFO - 2021-06-29 10:28:21 --> Helper loaded: file_helper
INFO - 2021-06-29 10:28:21 --> Helper loaded: form_helper
INFO - 2021-06-29 10:28:21 --> Helper loaded: my_helper
INFO - 2021-06-29 10:28:21 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:28:21 --> Controller Class Initialized
DEBUG - 2021-06-29 10:28:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:28:21 --> Final output sent to browser
DEBUG - 2021-06-29 10:28:21 --> Total execution time: 0.0582
INFO - 2021-06-29 10:28:32 --> Config Class Initialized
INFO - 2021-06-29 10:28:32 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:28:32 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:28:32 --> Utf8 Class Initialized
INFO - 2021-06-29 10:28:32 --> URI Class Initialized
INFO - 2021-06-29 10:28:32 --> Router Class Initialized
INFO - 2021-06-29 10:28:32 --> Output Class Initialized
INFO - 2021-06-29 10:28:32 --> Security Class Initialized
DEBUG - 2021-06-29 10:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:28:32 --> Input Class Initialized
INFO - 2021-06-29 10:28:32 --> Language Class Initialized
INFO - 2021-06-29 10:28:32 --> Language Class Initialized
INFO - 2021-06-29 10:28:32 --> Config Class Initialized
INFO - 2021-06-29 10:28:32 --> Loader Class Initialized
INFO - 2021-06-29 10:28:32 --> Helper loaded: url_helper
INFO - 2021-06-29 10:28:32 --> Helper loaded: file_helper
INFO - 2021-06-29 10:28:32 --> Helper loaded: form_helper
INFO - 2021-06-29 10:28:32 --> Helper loaded: my_helper
INFO - 2021-06-29 10:28:32 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:28:32 --> Controller Class Initialized
DEBUG - 2021-06-29 10:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:28:32 --> Final output sent to browser
DEBUG - 2021-06-29 10:28:32 --> Total execution time: 0.0514
INFO - 2021-06-29 10:28:44 --> Config Class Initialized
INFO - 2021-06-29 10:28:44 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:28:44 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:28:44 --> Utf8 Class Initialized
INFO - 2021-06-29 10:28:44 --> URI Class Initialized
INFO - 2021-06-29 10:28:44 --> Router Class Initialized
INFO - 2021-06-29 10:28:44 --> Output Class Initialized
INFO - 2021-06-29 10:28:44 --> Security Class Initialized
DEBUG - 2021-06-29 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:28:44 --> Input Class Initialized
INFO - 2021-06-29 10:28:44 --> Language Class Initialized
INFO - 2021-06-29 10:28:44 --> Language Class Initialized
INFO - 2021-06-29 10:28:44 --> Config Class Initialized
INFO - 2021-06-29 10:28:44 --> Loader Class Initialized
INFO - 2021-06-29 10:28:44 --> Helper loaded: url_helper
INFO - 2021-06-29 10:28:44 --> Helper loaded: file_helper
INFO - 2021-06-29 10:28:44 --> Helper loaded: form_helper
INFO - 2021-06-29 10:28:44 --> Helper loaded: my_helper
INFO - 2021-06-29 10:28:44 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:28:44 --> Controller Class Initialized
DEBUG - 2021-06-29 10:28:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:28:44 --> Final output sent to browser
DEBUG - 2021-06-29 10:28:44 --> Total execution time: 0.0724
INFO - 2021-06-29 10:28:52 --> Config Class Initialized
INFO - 2021-06-29 10:28:52 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:28:52 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:28:52 --> Utf8 Class Initialized
INFO - 2021-06-29 10:28:52 --> URI Class Initialized
INFO - 2021-06-29 10:28:52 --> Router Class Initialized
INFO - 2021-06-29 10:28:52 --> Output Class Initialized
INFO - 2021-06-29 10:28:52 --> Security Class Initialized
DEBUG - 2021-06-29 10:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:28:52 --> Input Class Initialized
INFO - 2021-06-29 10:28:52 --> Language Class Initialized
INFO - 2021-06-29 10:28:52 --> Language Class Initialized
INFO - 2021-06-29 10:28:52 --> Config Class Initialized
INFO - 2021-06-29 10:28:52 --> Loader Class Initialized
INFO - 2021-06-29 10:28:52 --> Helper loaded: url_helper
INFO - 2021-06-29 10:28:52 --> Helper loaded: file_helper
INFO - 2021-06-29 10:28:52 --> Helper loaded: form_helper
INFO - 2021-06-29 10:28:52 --> Helper loaded: my_helper
INFO - 2021-06-29 10:28:52 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:28:52 --> Controller Class Initialized
DEBUG - 2021-06-29 10:28:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:28:52 --> Final output sent to browser
DEBUG - 2021-06-29 10:28:52 --> Total execution time: 0.0491
INFO - 2021-06-29 10:29:05 --> Config Class Initialized
INFO - 2021-06-29 10:29:05 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:29:05 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:29:05 --> Utf8 Class Initialized
INFO - 2021-06-29 10:29:05 --> URI Class Initialized
INFO - 2021-06-29 10:29:05 --> Router Class Initialized
INFO - 2021-06-29 10:29:05 --> Output Class Initialized
INFO - 2021-06-29 10:29:05 --> Security Class Initialized
DEBUG - 2021-06-29 10:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:29:05 --> Input Class Initialized
INFO - 2021-06-29 10:29:05 --> Language Class Initialized
INFO - 2021-06-29 10:29:05 --> Language Class Initialized
INFO - 2021-06-29 10:29:05 --> Config Class Initialized
INFO - 2021-06-29 10:29:05 --> Loader Class Initialized
INFO - 2021-06-29 10:29:05 --> Helper loaded: url_helper
INFO - 2021-06-29 10:29:05 --> Helper loaded: file_helper
INFO - 2021-06-29 10:29:05 --> Helper loaded: form_helper
INFO - 2021-06-29 10:29:05 --> Helper loaded: my_helper
INFO - 2021-06-29 10:29:05 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:29:05 --> Controller Class Initialized
DEBUG - 2021-06-29 10:29:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:29:05 --> Final output sent to browser
DEBUG - 2021-06-29 10:29:05 --> Total execution time: 0.0657
INFO - 2021-06-29 10:29:55 --> Config Class Initialized
INFO - 2021-06-29 10:29:55 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:29:55 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:29:55 --> Utf8 Class Initialized
INFO - 2021-06-29 10:29:55 --> URI Class Initialized
INFO - 2021-06-29 10:29:55 --> Router Class Initialized
INFO - 2021-06-29 10:29:55 --> Output Class Initialized
INFO - 2021-06-29 10:29:55 --> Security Class Initialized
DEBUG - 2021-06-29 10:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:29:55 --> Input Class Initialized
INFO - 2021-06-29 10:29:55 --> Language Class Initialized
INFO - 2021-06-29 10:29:55 --> Language Class Initialized
INFO - 2021-06-29 10:29:55 --> Config Class Initialized
INFO - 2021-06-29 10:29:55 --> Loader Class Initialized
INFO - 2021-06-29 10:29:55 --> Helper loaded: url_helper
INFO - 2021-06-29 10:29:55 --> Helper loaded: file_helper
INFO - 2021-06-29 10:29:55 --> Helper loaded: form_helper
INFO - 2021-06-29 10:29:55 --> Helper loaded: my_helper
INFO - 2021-06-29 10:29:55 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:29:55 --> Controller Class Initialized
DEBUG - 2021-06-29 10:29:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:29:55 --> Final output sent to browser
DEBUG - 2021-06-29 10:29:55 --> Total execution time: 0.0516
INFO - 2021-06-29 10:30:14 --> Config Class Initialized
INFO - 2021-06-29 10:30:14 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:30:14 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:30:14 --> Utf8 Class Initialized
INFO - 2021-06-29 10:30:14 --> URI Class Initialized
INFO - 2021-06-29 10:30:14 --> Router Class Initialized
INFO - 2021-06-29 10:30:14 --> Output Class Initialized
INFO - 2021-06-29 10:30:14 --> Security Class Initialized
DEBUG - 2021-06-29 10:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:30:14 --> Input Class Initialized
INFO - 2021-06-29 10:30:14 --> Language Class Initialized
INFO - 2021-06-29 10:30:14 --> Language Class Initialized
INFO - 2021-06-29 10:30:14 --> Config Class Initialized
INFO - 2021-06-29 10:30:14 --> Loader Class Initialized
INFO - 2021-06-29 10:30:14 --> Helper loaded: url_helper
INFO - 2021-06-29 10:30:14 --> Helper loaded: file_helper
INFO - 2021-06-29 10:30:14 --> Helper loaded: form_helper
INFO - 2021-06-29 10:30:14 --> Helper loaded: my_helper
INFO - 2021-06-29 10:30:14 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:30:14 --> Controller Class Initialized
DEBUG - 2021-06-29 10:30:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:30:14 --> Final output sent to browser
DEBUG - 2021-06-29 10:30:14 --> Total execution time: 0.0688
INFO - 2021-06-29 10:30:39 --> Config Class Initialized
INFO - 2021-06-29 10:30:39 --> Hooks Class Initialized
DEBUG - 2021-06-29 10:30:39 --> UTF-8 Support Enabled
INFO - 2021-06-29 10:30:39 --> Utf8 Class Initialized
INFO - 2021-06-29 10:30:39 --> URI Class Initialized
INFO - 2021-06-29 10:30:39 --> Router Class Initialized
INFO - 2021-06-29 10:30:39 --> Output Class Initialized
INFO - 2021-06-29 10:30:39 --> Security Class Initialized
DEBUG - 2021-06-29 10:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-29 10:30:39 --> Input Class Initialized
INFO - 2021-06-29 10:30:39 --> Language Class Initialized
INFO - 2021-06-29 10:30:39 --> Language Class Initialized
INFO - 2021-06-29 10:30:39 --> Config Class Initialized
INFO - 2021-06-29 10:30:39 --> Loader Class Initialized
INFO - 2021-06-29 10:30:39 --> Helper loaded: url_helper
INFO - 2021-06-29 10:30:39 --> Helper loaded: file_helper
INFO - 2021-06-29 10:30:39 --> Helper loaded: form_helper
INFO - 2021-06-29 10:30:39 --> Helper loaded: my_helper
INFO - 2021-06-29 10:30:39 --> Database Driver Class Initialized
DEBUG - 2021-06-29 10:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-29 10:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-29 10:30:39 --> Controller Class Initialized
DEBUG - 2021-06-29 10:30:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-06-29 10:30:39 --> Final output sent to browser
DEBUG - 2021-06-29 10:30:39 --> Total execution time: 0.0603
