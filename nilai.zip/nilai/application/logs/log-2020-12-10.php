<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-10 01:02:49 --> Config Class Initialized
INFO - 2020-12-10 01:02:49 --> Hooks Class Initialized
DEBUG - 2020-12-10 01:02:49 --> UTF-8 Support Enabled
INFO - 2020-12-10 01:02:49 --> Utf8 Class Initialized
INFO - 2020-12-10 01:02:49 --> URI Class Initialized
DEBUG - 2020-12-10 01:02:49 --> No URI present. Default controller set.
INFO - 2020-12-10 01:02:49 --> Router Class Initialized
INFO - 2020-12-10 01:02:49 --> Output Class Initialized
INFO - 2020-12-10 01:02:49 --> Security Class Initialized
DEBUG - 2020-12-10 01:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 01:02:49 --> Input Class Initialized
INFO - 2020-12-10 01:02:49 --> Language Class Initialized
INFO - 2020-12-10 01:02:50 --> Language Class Initialized
INFO - 2020-12-10 01:02:50 --> Config Class Initialized
INFO - 2020-12-10 01:02:50 --> Loader Class Initialized
INFO - 2020-12-10 01:02:50 --> Helper loaded: url_helper
INFO - 2020-12-10 01:02:50 --> Helper loaded: file_helper
INFO - 2020-12-10 01:02:50 --> Helper loaded: form_helper
INFO - 2020-12-10 01:02:50 --> Helper loaded: my_helper
INFO - 2020-12-10 01:02:50 --> Database Driver Class Initialized
DEBUG - 2020-12-10 01:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 01:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 01:02:50 --> Controller Class Initialized
INFO - 2020-12-10 01:02:50 --> Config Class Initialized
INFO - 2020-12-10 01:02:50 --> Hooks Class Initialized
DEBUG - 2020-12-10 01:02:50 --> UTF-8 Support Enabled
INFO - 2020-12-10 01:02:50 --> Utf8 Class Initialized
INFO - 2020-12-10 01:02:50 --> URI Class Initialized
INFO - 2020-12-10 01:02:50 --> Router Class Initialized
INFO - 2020-12-10 01:02:50 --> Output Class Initialized
INFO - 2020-12-10 01:02:50 --> Security Class Initialized
DEBUG - 2020-12-10 01:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 01:02:50 --> Input Class Initialized
INFO - 2020-12-10 01:02:50 --> Language Class Initialized
INFO - 2020-12-10 01:02:50 --> Language Class Initialized
INFO - 2020-12-10 01:02:50 --> Config Class Initialized
INFO - 2020-12-10 01:02:50 --> Loader Class Initialized
INFO - 2020-12-10 01:02:50 --> Helper loaded: url_helper
INFO - 2020-12-10 01:02:50 --> Helper loaded: file_helper
INFO - 2020-12-10 01:02:50 --> Helper loaded: form_helper
INFO - 2020-12-10 01:02:50 --> Helper loaded: my_helper
INFO - 2020-12-10 01:02:50 --> Database Driver Class Initialized
DEBUG - 2020-12-10 01:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 01:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 01:02:50 --> Controller Class Initialized
DEBUG - 2020-12-10 01:02:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 01:02:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 01:02:50 --> Final output sent to browser
DEBUG - 2020-12-10 01:02:50 --> Total execution time: 0.1077
INFO - 2020-12-10 01:03:13 --> Config Class Initialized
INFO - 2020-12-10 01:03:13 --> Hooks Class Initialized
DEBUG - 2020-12-10 01:03:13 --> UTF-8 Support Enabled
INFO - 2020-12-10 01:03:13 --> Utf8 Class Initialized
INFO - 2020-12-10 01:03:13 --> URI Class Initialized
INFO - 2020-12-10 01:03:13 --> Router Class Initialized
INFO - 2020-12-10 01:03:13 --> Output Class Initialized
INFO - 2020-12-10 01:03:13 --> Security Class Initialized
DEBUG - 2020-12-10 01:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 01:03:13 --> Input Class Initialized
INFO - 2020-12-10 01:03:13 --> Language Class Initialized
INFO - 2020-12-10 01:03:13 --> Language Class Initialized
INFO - 2020-12-10 01:03:13 --> Config Class Initialized
INFO - 2020-12-10 01:03:13 --> Loader Class Initialized
INFO - 2020-12-10 01:03:13 --> Helper loaded: url_helper
INFO - 2020-12-10 01:03:13 --> Helper loaded: file_helper
INFO - 2020-12-10 01:03:13 --> Helper loaded: form_helper
INFO - 2020-12-10 01:03:13 --> Helper loaded: my_helper
INFO - 2020-12-10 01:03:13 --> Database Driver Class Initialized
DEBUG - 2020-12-10 01:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 01:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 01:03:13 --> Controller Class Initialized
INFO - 2020-12-10 01:03:13 --> Helper loaded: cookie_helper
INFO - 2020-12-10 01:03:13 --> Final output sent to browser
DEBUG - 2020-12-10 01:03:13 --> Total execution time: 0.3183
INFO - 2020-12-10 01:03:19 --> Config Class Initialized
INFO - 2020-12-10 01:03:19 --> Hooks Class Initialized
DEBUG - 2020-12-10 01:03:19 --> UTF-8 Support Enabled
INFO - 2020-12-10 01:03:19 --> Utf8 Class Initialized
INFO - 2020-12-10 01:03:19 --> URI Class Initialized
INFO - 2020-12-10 01:03:19 --> Router Class Initialized
INFO - 2020-12-10 01:03:19 --> Output Class Initialized
INFO - 2020-12-10 01:03:19 --> Security Class Initialized
DEBUG - 2020-12-10 01:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 01:03:19 --> Input Class Initialized
INFO - 2020-12-10 01:03:19 --> Language Class Initialized
INFO - 2020-12-10 01:03:19 --> Language Class Initialized
INFO - 2020-12-10 01:03:19 --> Config Class Initialized
INFO - 2020-12-10 01:03:19 --> Loader Class Initialized
INFO - 2020-12-10 01:03:19 --> Helper loaded: url_helper
INFO - 2020-12-10 01:03:19 --> Helper loaded: file_helper
INFO - 2020-12-10 01:03:19 --> Helper loaded: form_helper
INFO - 2020-12-10 01:03:19 --> Helper loaded: my_helper
INFO - 2020-12-10 01:03:19 --> Database Driver Class Initialized
DEBUG - 2020-12-10 01:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 01:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 01:03:19 --> Controller Class Initialized
DEBUG - 2020-12-10 01:03:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-10 01:03:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 01:03:19 --> Final output sent to browser
DEBUG - 2020-12-10 01:03:19 --> Total execution time: 0.1698
INFO - 2020-12-10 01:03:25 --> Config Class Initialized
INFO - 2020-12-10 01:03:25 --> Hooks Class Initialized
DEBUG - 2020-12-10 01:03:25 --> UTF-8 Support Enabled
INFO - 2020-12-10 01:03:25 --> Utf8 Class Initialized
INFO - 2020-12-10 01:03:25 --> URI Class Initialized
INFO - 2020-12-10 01:03:25 --> Router Class Initialized
INFO - 2020-12-10 01:03:25 --> Output Class Initialized
INFO - 2020-12-10 01:03:25 --> Security Class Initialized
DEBUG - 2020-12-10 01:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 01:03:25 --> Input Class Initialized
INFO - 2020-12-10 01:03:25 --> Language Class Initialized
INFO - 2020-12-10 01:03:25 --> Language Class Initialized
INFO - 2020-12-10 01:03:25 --> Config Class Initialized
INFO - 2020-12-10 01:03:25 --> Loader Class Initialized
INFO - 2020-12-10 01:03:25 --> Helper loaded: url_helper
INFO - 2020-12-10 01:03:25 --> Helper loaded: file_helper
INFO - 2020-12-10 01:03:25 --> Helper loaded: form_helper
INFO - 2020-12-10 01:03:25 --> Helper loaded: my_helper
INFO - 2020-12-10 01:03:25 --> Database Driver Class Initialized
DEBUG - 2020-12-10 01:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 01:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 01:03:25 --> Controller Class Initialized
DEBUG - 2020-12-10 01:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-10 01:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 01:03:25 --> Final output sent to browser
DEBUG - 2020-12-10 01:03:25 --> Total execution time: 0.1489
INFO - 2020-12-10 01:03:31 --> Config Class Initialized
INFO - 2020-12-10 01:03:31 --> Hooks Class Initialized
DEBUG - 2020-12-10 01:03:31 --> UTF-8 Support Enabled
INFO - 2020-12-10 01:03:31 --> Utf8 Class Initialized
INFO - 2020-12-10 01:03:31 --> URI Class Initialized
INFO - 2020-12-10 01:03:31 --> Router Class Initialized
INFO - 2020-12-10 01:03:31 --> Output Class Initialized
INFO - 2020-12-10 01:03:31 --> Security Class Initialized
DEBUG - 2020-12-10 01:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 01:03:31 --> Input Class Initialized
INFO - 2020-12-10 01:03:31 --> Language Class Initialized
INFO - 2020-12-10 01:03:31 --> Language Class Initialized
INFO - 2020-12-10 01:03:31 --> Config Class Initialized
INFO - 2020-12-10 01:03:31 --> Loader Class Initialized
INFO - 2020-12-10 01:03:31 --> Helper loaded: url_helper
INFO - 2020-12-10 01:03:31 --> Helper loaded: file_helper
INFO - 2020-12-10 01:03:31 --> Helper loaded: form_helper
INFO - 2020-12-10 01:03:31 --> Helper loaded: my_helper
INFO - 2020-12-10 01:03:31 --> Database Driver Class Initialized
DEBUG - 2020-12-10 01:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 01:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 01:03:31 --> Controller Class Initialized
DEBUG - 2020-12-10 01:03:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-10 01:03:31 --> Final output sent to browser
DEBUG - 2020-12-10 01:03:31 --> Total execution time: 0.3922
INFO - 2020-12-10 02:34:58 --> Config Class Initialized
INFO - 2020-12-10 02:34:58 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:34:58 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:34:58 --> Utf8 Class Initialized
INFO - 2020-12-10 02:34:58 --> URI Class Initialized
INFO - 2020-12-10 02:34:58 --> Router Class Initialized
INFO - 2020-12-10 02:34:58 --> Output Class Initialized
INFO - 2020-12-10 02:34:58 --> Security Class Initialized
DEBUG - 2020-12-10 02:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:34:58 --> Input Class Initialized
INFO - 2020-12-10 02:34:58 --> Language Class Initialized
INFO - 2020-12-10 02:34:58 --> Language Class Initialized
INFO - 2020-12-10 02:34:58 --> Config Class Initialized
INFO - 2020-12-10 02:34:58 --> Loader Class Initialized
INFO - 2020-12-10 02:34:58 --> Helper loaded: url_helper
INFO - 2020-12-10 02:34:58 --> Helper loaded: file_helper
INFO - 2020-12-10 02:34:58 --> Helper loaded: form_helper
INFO - 2020-12-10 02:34:58 --> Helper loaded: my_helper
INFO - 2020-12-10 02:34:58 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:34:58 --> Controller Class Initialized
DEBUG - 2020-12-10 02:34:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-12-10 02:34:58 --> Final output sent to browser
DEBUG - 2020-12-10 02:34:58 --> Total execution time: 0.0521
INFO - 2020-12-10 02:35:06 --> Config Class Initialized
INFO - 2020-12-10 02:35:06 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:06 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:06 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:06 --> URI Class Initialized
INFO - 2020-12-10 02:35:06 --> Router Class Initialized
INFO - 2020-12-10 02:35:06 --> Output Class Initialized
INFO - 2020-12-10 02:35:06 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:06 --> Input Class Initialized
INFO - 2020-12-10 02:35:06 --> Language Class Initialized
INFO - 2020-12-10 02:35:06 --> Language Class Initialized
INFO - 2020-12-10 02:35:06 --> Config Class Initialized
INFO - 2020-12-10 02:35:06 --> Loader Class Initialized
INFO - 2020-12-10 02:35:06 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:06 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:06 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:06 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:06 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:06 --> Controller Class Initialized
DEBUG - 2020-12-10 02:35:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-12-10 02:35:06 --> Final output sent to browser
DEBUG - 2020-12-10 02:35:06 --> Total execution time: 0.0580
INFO - 2020-12-10 02:35:15 --> Config Class Initialized
INFO - 2020-12-10 02:35:15 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:15 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:15 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:15 --> URI Class Initialized
INFO - 2020-12-10 02:35:15 --> Router Class Initialized
INFO - 2020-12-10 02:35:15 --> Output Class Initialized
INFO - 2020-12-10 02:35:15 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:15 --> Input Class Initialized
INFO - 2020-12-10 02:35:15 --> Language Class Initialized
INFO - 2020-12-10 02:35:15 --> Language Class Initialized
INFO - 2020-12-10 02:35:15 --> Config Class Initialized
INFO - 2020-12-10 02:35:15 --> Loader Class Initialized
INFO - 2020-12-10 02:35:15 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:15 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:15 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:15 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:15 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:15 --> Controller Class Initialized
DEBUG - 2020-12-10 02:35:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-12-10 02:35:15 --> Final output sent to browser
DEBUG - 2020-12-10 02:35:15 --> Total execution time: 0.0670
INFO - 2020-12-10 02:35:37 --> Config Class Initialized
INFO - 2020-12-10 02:35:37 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:37 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:37 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:37 --> URI Class Initialized
INFO - 2020-12-10 02:35:37 --> Router Class Initialized
INFO - 2020-12-10 02:35:37 --> Output Class Initialized
INFO - 2020-12-10 02:35:37 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:37 --> Input Class Initialized
INFO - 2020-12-10 02:35:37 --> Language Class Initialized
INFO - 2020-12-10 02:35:37 --> Language Class Initialized
INFO - 2020-12-10 02:35:37 --> Config Class Initialized
INFO - 2020-12-10 02:35:37 --> Loader Class Initialized
INFO - 2020-12-10 02:35:37 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:37 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:37 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:37 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:37 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:37 --> Controller Class Initialized
INFO - 2020-12-10 02:35:37 --> Helper loaded: cookie_helper
INFO - 2020-12-10 02:35:37 --> Config Class Initialized
INFO - 2020-12-10 02:35:37 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:37 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:37 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:37 --> URI Class Initialized
INFO - 2020-12-10 02:35:37 --> Router Class Initialized
INFO - 2020-12-10 02:35:37 --> Output Class Initialized
INFO - 2020-12-10 02:35:37 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:37 --> Input Class Initialized
INFO - 2020-12-10 02:35:37 --> Language Class Initialized
INFO - 2020-12-10 02:35:37 --> Language Class Initialized
INFO - 2020-12-10 02:35:37 --> Config Class Initialized
INFO - 2020-12-10 02:35:37 --> Loader Class Initialized
INFO - 2020-12-10 02:35:37 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:37 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:37 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:37 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:37 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:37 --> Controller Class Initialized
DEBUG - 2020-12-10 02:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 02:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:35:37 --> Final output sent to browser
DEBUG - 2020-12-10 02:35:37 --> Total execution time: 0.0309
INFO - 2020-12-10 02:35:42 --> Config Class Initialized
INFO - 2020-12-10 02:35:42 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:42 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:42 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:42 --> URI Class Initialized
INFO - 2020-12-10 02:35:42 --> Router Class Initialized
INFO - 2020-12-10 02:35:42 --> Output Class Initialized
INFO - 2020-12-10 02:35:42 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:42 --> Input Class Initialized
INFO - 2020-12-10 02:35:42 --> Language Class Initialized
INFO - 2020-12-10 02:35:42 --> Language Class Initialized
INFO - 2020-12-10 02:35:42 --> Config Class Initialized
INFO - 2020-12-10 02:35:42 --> Loader Class Initialized
INFO - 2020-12-10 02:35:42 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:42 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:42 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:42 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:42 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:42 --> Controller Class Initialized
INFO - 2020-12-10 02:35:42 --> Helper loaded: cookie_helper
INFO - 2020-12-10 02:35:42 --> Final output sent to browser
DEBUG - 2020-12-10 02:35:42 --> Total execution time: 0.0411
INFO - 2020-12-10 02:35:43 --> Config Class Initialized
INFO - 2020-12-10 02:35:43 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:43 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:43 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:43 --> URI Class Initialized
INFO - 2020-12-10 02:35:43 --> Router Class Initialized
INFO - 2020-12-10 02:35:43 --> Output Class Initialized
INFO - 2020-12-10 02:35:43 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:43 --> Input Class Initialized
INFO - 2020-12-10 02:35:43 --> Language Class Initialized
INFO - 2020-12-10 02:35:43 --> Language Class Initialized
INFO - 2020-12-10 02:35:43 --> Config Class Initialized
INFO - 2020-12-10 02:35:43 --> Loader Class Initialized
INFO - 2020-12-10 02:35:43 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:43 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:43 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:43 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:43 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:43 --> Controller Class Initialized
DEBUG - 2020-12-10 02:35:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-10 02:35:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:35:43 --> Final output sent to browser
DEBUG - 2020-12-10 02:35:43 --> Total execution time: 0.0484
INFO - 2020-12-10 02:35:50 --> Config Class Initialized
INFO - 2020-12-10 02:35:50 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:50 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:50 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:50 --> URI Class Initialized
INFO - 2020-12-10 02:35:50 --> Router Class Initialized
INFO - 2020-12-10 02:35:50 --> Output Class Initialized
INFO - 2020-12-10 02:35:50 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:50 --> Input Class Initialized
INFO - 2020-12-10 02:35:50 --> Language Class Initialized
INFO - 2020-12-10 02:35:50 --> Language Class Initialized
INFO - 2020-12-10 02:35:50 --> Config Class Initialized
INFO - 2020-12-10 02:35:50 --> Loader Class Initialized
INFO - 2020-12-10 02:35:50 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:50 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:50 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:50 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:50 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:50 --> Controller Class Initialized
DEBUG - 2020-12-10 02:35:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:35:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:35:50 --> Final output sent to browser
DEBUG - 2020-12-10 02:35:50 --> Total execution time: 0.0862
INFO - 2020-12-10 02:35:50 --> Config Class Initialized
INFO - 2020-12-10 02:35:50 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:50 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:50 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:50 --> URI Class Initialized
INFO - 2020-12-10 02:35:50 --> Router Class Initialized
INFO - 2020-12-10 02:35:50 --> Output Class Initialized
INFO - 2020-12-10 02:35:50 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:50 --> Input Class Initialized
INFO - 2020-12-10 02:35:50 --> Language Class Initialized
INFO - 2020-12-10 02:35:50 --> Language Class Initialized
INFO - 2020-12-10 02:35:50 --> Config Class Initialized
INFO - 2020-12-10 02:35:50 --> Loader Class Initialized
INFO - 2020-12-10 02:35:50 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:50 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:50 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:50 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:50 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:50 --> Controller Class Initialized
INFO - 2020-12-10 02:35:58 --> Config Class Initialized
INFO - 2020-12-10 02:35:58 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:58 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:58 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:58 --> URI Class Initialized
INFO - 2020-12-10 02:35:58 --> Router Class Initialized
INFO - 2020-12-10 02:35:58 --> Output Class Initialized
INFO - 2020-12-10 02:35:58 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:58 --> Input Class Initialized
INFO - 2020-12-10 02:35:58 --> Language Class Initialized
INFO - 2020-12-10 02:35:58 --> Language Class Initialized
INFO - 2020-12-10 02:35:58 --> Config Class Initialized
INFO - 2020-12-10 02:35:58 --> Loader Class Initialized
INFO - 2020-12-10 02:35:58 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:58 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:58 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:58 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:58 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:58 --> Controller Class Initialized
INFO - 2020-12-10 02:35:59 --> Config Class Initialized
INFO - 2020-12-10 02:35:59 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:35:59 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:35:59 --> Utf8 Class Initialized
INFO - 2020-12-10 02:35:59 --> URI Class Initialized
INFO - 2020-12-10 02:35:59 --> Router Class Initialized
INFO - 2020-12-10 02:35:59 --> Output Class Initialized
INFO - 2020-12-10 02:35:59 --> Security Class Initialized
DEBUG - 2020-12-10 02:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:35:59 --> Input Class Initialized
INFO - 2020-12-10 02:35:59 --> Language Class Initialized
INFO - 2020-12-10 02:35:59 --> Language Class Initialized
INFO - 2020-12-10 02:35:59 --> Config Class Initialized
INFO - 2020-12-10 02:35:59 --> Loader Class Initialized
INFO - 2020-12-10 02:35:59 --> Helper loaded: url_helper
INFO - 2020-12-10 02:35:59 --> Helper loaded: file_helper
INFO - 2020-12-10 02:35:59 --> Helper loaded: form_helper
INFO - 2020-12-10 02:35:59 --> Helper loaded: my_helper
INFO - 2020-12-10 02:35:59 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:35:59 --> Controller Class Initialized
ERROR - 2020-12-10 02:36:00 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-12-10 02:36:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-12-10 02:36:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:36:00 --> Final output sent to browser
DEBUG - 2020-12-10 02:36:00 --> Total execution time: 0.1351
INFO - 2020-12-10 02:37:12 --> Config Class Initialized
INFO - 2020-12-10 02:37:12 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:37:12 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:37:12 --> Utf8 Class Initialized
INFO - 2020-12-10 02:37:12 --> URI Class Initialized
INFO - 2020-12-10 02:37:12 --> Router Class Initialized
INFO - 2020-12-10 02:37:12 --> Output Class Initialized
INFO - 2020-12-10 02:37:12 --> Security Class Initialized
DEBUG - 2020-12-10 02:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:37:12 --> Input Class Initialized
INFO - 2020-12-10 02:37:12 --> Language Class Initialized
INFO - 2020-12-10 02:37:12 --> Language Class Initialized
INFO - 2020-12-10 02:37:12 --> Config Class Initialized
INFO - 2020-12-10 02:37:12 --> Loader Class Initialized
INFO - 2020-12-10 02:37:12 --> Helper loaded: url_helper
INFO - 2020-12-10 02:37:12 --> Helper loaded: file_helper
INFO - 2020-12-10 02:37:12 --> Helper loaded: form_helper
INFO - 2020-12-10 02:37:12 --> Helper loaded: my_helper
INFO - 2020-12-10 02:37:12 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:37:12 --> Controller Class Initialized
INFO - 2020-12-10 02:37:22 --> Upload Class Initialized
INFO - 2020-12-10 02:37:22 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-12-10 02:37:22 --> The upload path does not appear to be valid.
INFO - 2020-12-10 02:37:22 --> Config Class Initialized
INFO - 2020-12-10 02:37:22 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:37:22 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:37:22 --> Utf8 Class Initialized
INFO - 2020-12-10 02:37:22 --> URI Class Initialized
INFO - 2020-12-10 02:37:22 --> Router Class Initialized
INFO - 2020-12-10 02:37:22 --> Output Class Initialized
INFO - 2020-12-10 02:37:22 --> Security Class Initialized
DEBUG - 2020-12-10 02:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:37:22 --> Input Class Initialized
INFO - 2020-12-10 02:37:22 --> Language Class Initialized
INFO - 2020-12-10 02:37:22 --> Language Class Initialized
INFO - 2020-12-10 02:37:22 --> Config Class Initialized
INFO - 2020-12-10 02:37:22 --> Loader Class Initialized
INFO - 2020-12-10 02:37:22 --> Helper loaded: url_helper
INFO - 2020-12-10 02:37:22 --> Helper loaded: file_helper
INFO - 2020-12-10 02:37:22 --> Helper loaded: form_helper
INFO - 2020-12-10 02:37:22 --> Helper loaded: my_helper
INFO - 2020-12-10 02:37:22 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:37:22 --> Controller Class Initialized
DEBUG - 2020-12-10 02:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:37:22 --> Final output sent to browser
DEBUG - 2020-12-10 02:37:22 --> Total execution time: 0.0508
INFO - 2020-12-10 02:37:23 --> Config Class Initialized
INFO - 2020-12-10 02:37:23 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:37:23 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:37:23 --> Utf8 Class Initialized
INFO - 2020-12-10 02:37:23 --> URI Class Initialized
INFO - 2020-12-10 02:37:23 --> Router Class Initialized
INFO - 2020-12-10 02:37:23 --> Output Class Initialized
INFO - 2020-12-10 02:37:23 --> Security Class Initialized
DEBUG - 2020-12-10 02:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:37:23 --> Input Class Initialized
INFO - 2020-12-10 02:37:23 --> Language Class Initialized
INFO - 2020-12-10 02:37:23 --> Language Class Initialized
INFO - 2020-12-10 02:37:23 --> Config Class Initialized
INFO - 2020-12-10 02:37:23 --> Loader Class Initialized
INFO - 2020-12-10 02:37:23 --> Helper loaded: url_helper
INFO - 2020-12-10 02:37:23 --> Helper loaded: file_helper
INFO - 2020-12-10 02:37:23 --> Helper loaded: form_helper
INFO - 2020-12-10 02:37:23 --> Helper loaded: my_helper
INFO - 2020-12-10 02:37:23 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:37:23 --> Controller Class Initialized
INFO - 2020-12-10 02:37:35 --> Config Class Initialized
INFO - 2020-12-10 02:37:35 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:37:35 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:37:35 --> Utf8 Class Initialized
INFO - 2020-12-10 02:37:35 --> URI Class Initialized
INFO - 2020-12-10 02:37:35 --> Router Class Initialized
INFO - 2020-12-10 02:37:35 --> Output Class Initialized
INFO - 2020-12-10 02:37:35 --> Security Class Initialized
DEBUG - 2020-12-10 02:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:37:35 --> Input Class Initialized
INFO - 2020-12-10 02:37:35 --> Language Class Initialized
INFO - 2020-12-10 02:37:35 --> Language Class Initialized
INFO - 2020-12-10 02:37:35 --> Config Class Initialized
INFO - 2020-12-10 02:37:35 --> Loader Class Initialized
INFO - 2020-12-10 02:37:35 --> Helper loaded: url_helper
INFO - 2020-12-10 02:37:35 --> Helper loaded: file_helper
INFO - 2020-12-10 02:37:35 --> Helper loaded: form_helper
INFO - 2020-12-10 02:37:35 --> Helper loaded: my_helper
INFO - 2020-12-10 02:37:35 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:37:35 --> Controller Class Initialized
INFO - 2020-12-10 02:37:36 --> Config Class Initialized
INFO - 2020-12-10 02:37:36 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:37:36 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:37:36 --> Utf8 Class Initialized
INFO - 2020-12-10 02:37:36 --> URI Class Initialized
INFO - 2020-12-10 02:37:36 --> Router Class Initialized
INFO - 2020-12-10 02:37:36 --> Output Class Initialized
INFO - 2020-12-10 02:37:36 --> Security Class Initialized
DEBUG - 2020-12-10 02:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:37:36 --> Input Class Initialized
INFO - 2020-12-10 02:37:36 --> Language Class Initialized
INFO - 2020-12-10 02:37:36 --> Language Class Initialized
INFO - 2020-12-10 02:37:36 --> Config Class Initialized
INFO - 2020-12-10 02:37:36 --> Loader Class Initialized
INFO - 2020-12-10 02:37:36 --> Helper loaded: url_helper
INFO - 2020-12-10 02:37:36 --> Helper loaded: file_helper
INFO - 2020-12-10 02:37:36 --> Helper loaded: form_helper
INFO - 2020-12-10 02:37:36 --> Helper loaded: my_helper
INFO - 2020-12-10 02:37:36 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:37:36 --> Controller Class Initialized
ERROR - 2020-12-10 02:37:36 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-12-10 02:37:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-12-10 02:37:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:37:36 --> Final output sent to browser
DEBUG - 2020-12-10 02:37:36 --> Total execution time: 0.0441
INFO - 2020-12-10 02:38:54 --> Config Class Initialized
INFO - 2020-12-10 02:38:54 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:38:54 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:38:54 --> Utf8 Class Initialized
INFO - 2020-12-10 02:38:54 --> URI Class Initialized
INFO - 2020-12-10 02:38:54 --> Router Class Initialized
INFO - 2020-12-10 02:38:54 --> Output Class Initialized
INFO - 2020-12-10 02:38:54 --> Security Class Initialized
DEBUG - 2020-12-10 02:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:38:54 --> Input Class Initialized
INFO - 2020-12-10 02:38:54 --> Language Class Initialized
INFO - 2020-12-10 02:38:54 --> Language Class Initialized
INFO - 2020-12-10 02:38:54 --> Config Class Initialized
INFO - 2020-12-10 02:38:54 --> Loader Class Initialized
INFO - 2020-12-10 02:38:54 --> Helper loaded: url_helper
INFO - 2020-12-10 02:38:54 --> Helper loaded: file_helper
INFO - 2020-12-10 02:38:54 --> Helper loaded: form_helper
INFO - 2020-12-10 02:38:54 --> Helper loaded: my_helper
INFO - 2020-12-10 02:38:54 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:38:54 --> Controller Class Initialized
DEBUG - 2020-12-10 02:38:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:38:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:38:54 --> Final output sent to browser
DEBUG - 2020-12-10 02:38:54 --> Total execution time: 0.0446
INFO - 2020-12-10 02:38:54 --> Config Class Initialized
INFO - 2020-12-10 02:38:54 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:38:54 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:38:54 --> Utf8 Class Initialized
INFO - 2020-12-10 02:38:54 --> URI Class Initialized
INFO - 2020-12-10 02:38:54 --> Router Class Initialized
INFO - 2020-12-10 02:38:54 --> Output Class Initialized
INFO - 2020-12-10 02:38:54 --> Security Class Initialized
DEBUG - 2020-12-10 02:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:38:54 --> Input Class Initialized
INFO - 2020-12-10 02:38:54 --> Language Class Initialized
INFO - 2020-12-10 02:38:54 --> Language Class Initialized
INFO - 2020-12-10 02:38:54 --> Config Class Initialized
INFO - 2020-12-10 02:38:54 --> Loader Class Initialized
INFO - 2020-12-10 02:38:54 --> Helper loaded: url_helper
INFO - 2020-12-10 02:38:54 --> Helper loaded: file_helper
INFO - 2020-12-10 02:38:54 --> Helper loaded: form_helper
INFO - 2020-12-10 02:38:54 --> Helper loaded: my_helper
INFO - 2020-12-10 02:38:54 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:38:54 --> Controller Class Initialized
INFO - 2020-12-10 02:39:11 --> Config Class Initialized
INFO - 2020-12-10 02:39:11 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:39:11 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:39:11 --> Utf8 Class Initialized
INFO - 2020-12-10 02:39:11 --> URI Class Initialized
INFO - 2020-12-10 02:39:11 --> Router Class Initialized
INFO - 2020-12-10 02:39:11 --> Output Class Initialized
INFO - 2020-12-10 02:39:11 --> Security Class Initialized
DEBUG - 2020-12-10 02:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:39:11 --> Input Class Initialized
INFO - 2020-12-10 02:39:11 --> Language Class Initialized
INFO - 2020-12-10 02:39:11 --> Language Class Initialized
INFO - 2020-12-10 02:39:11 --> Config Class Initialized
INFO - 2020-12-10 02:39:11 --> Loader Class Initialized
INFO - 2020-12-10 02:39:11 --> Helper loaded: url_helper
INFO - 2020-12-10 02:39:11 --> Helper loaded: file_helper
INFO - 2020-12-10 02:39:11 --> Helper loaded: form_helper
INFO - 2020-12-10 02:39:11 --> Helper loaded: my_helper
INFO - 2020-12-10 02:39:11 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:39:11 --> Controller Class Initialized
DEBUG - 2020-12-10 02:39:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:39:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:39:11 --> Final output sent to browser
DEBUG - 2020-12-10 02:39:11 --> Total execution time: 0.0427
INFO - 2020-12-10 02:39:11 --> Config Class Initialized
INFO - 2020-12-10 02:39:11 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:39:11 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:39:11 --> Utf8 Class Initialized
INFO - 2020-12-10 02:39:11 --> URI Class Initialized
INFO - 2020-12-10 02:39:11 --> Router Class Initialized
INFO - 2020-12-10 02:39:11 --> Output Class Initialized
INFO - 2020-12-10 02:39:11 --> Security Class Initialized
DEBUG - 2020-12-10 02:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:39:11 --> Input Class Initialized
INFO - 2020-12-10 02:39:11 --> Language Class Initialized
INFO - 2020-12-10 02:39:11 --> Language Class Initialized
INFO - 2020-12-10 02:39:11 --> Config Class Initialized
INFO - 2020-12-10 02:39:11 --> Loader Class Initialized
INFO - 2020-12-10 02:39:11 --> Helper loaded: url_helper
INFO - 2020-12-10 02:39:11 --> Helper loaded: file_helper
INFO - 2020-12-10 02:39:11 --> Helper loaded: form_helper
INFO - 2020-12-10 02:39:11 --> Helper loaded: my_helper
INFO - 2020-12-10 02:39:11 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:39:11 --> Controller Class Initialized
INFO - 2020-12-10 02:39:30 --> Config Class Initialized
INFO - 2020-12-10 02:39:30 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:39:30 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:39:30 --> Utf8 Class Initialized
INFO - 2020-12-10 02:39:30 --> URI Class Initialized
INFO - 2020-12-10 02:39:30 --> Router Class Initialized
INFO - 2020-12-10 02:39:30 --> Output Class Initialized
INFO - 2020-12-10 02:39:30 --> Security Class Initialized
DEBUG - 2020-12-10 02:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:39:30 --> Input Class Initialized
INFO - 2020-12-10 02:39:30 --> Language Class Initialized
INFO - 2020-12-10 02:39:30 --> Language Class Initialized
INFO - 2020-12-10 02:39:30 --> Config Class Initialized
INFO - 2020-12-10 02:39:30 --> Loader Class Initialized
INFO - 2020-12-10 02:39:30 --> Helper loaded: url_helper
INFO - 2020-12-10 02:39:30 --> Helper loaded: file_helper
INFO - 2020-12-10 02:39:30 --> Helper loaded: form_helper
INFO - 2020-12-10 02:39:30 --> Helper loaded: my_helper
INFO - 2020-12-10 02:39:30 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:39:30 --> Controller Class Initialized
INFO - 2020-12-10 02:39:32 --> Config Class Initialized
INFO - 2020-12-10 02:39:32 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:39:32 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:39:32 --> Utf8 Class Initialized
INFO - 2020-12-10 02:39:32 --> URI Class Initialized
INFO - 2020-12-10 02:39:32 --> Router Class Initialized
INFO - 2020-12-10 02:39:32 --> Output Class Initialized
INFO - 2020-12-10 02:39:32 --> Security Class Initialized
DEBUG - 2020-12-10 02:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:39:32 --> Input Class Initialized
INFO - 2020-12-10 02:39:32 --> Language Class Initialized
INFO - 2020-12-10 02:39:32 --> Language Class Initialized
INFO - 2020-12-10 02:39:32 --> Config Class Initialized
INFO - 2020-12-10 02:39:32 --> Loader Class Initialized
INFO - 2020-12-10 02:39:32 --> Helper loaded: url_helper
INFO - 2020-12-10 02:39:32 --> Helper loaded: file_helper
INFO - 2020-12-10 02:39:32 --> Helper loaded: form_helper
INFO - 2020-12-10 02:39:32 --> Helper loaded: my_helper
INFO - 2020-12-10 02:39:32 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:39:32 --> Controller Class Initialized
ERROR - 2020-12-10 02:39:32 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-12-10 02:39:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-12-10 02:39:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:39:32 --> Final output sent to browser
DEBUG - 2020-12-10 02:39:32 --> Total execution time: 0.0366
INFO - 2020-12-10 02:39:43 --> Config Class Initialized
INFO - 2020-12-10 02:39:43 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:39:43 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:39:43 --> Utf8 Class Initialized
INFO - 2020-12-10 02:39:43 --> URI Class Initialized
INFO - 2020-12-10 02:39:43 --> Router Class Initialized
INFO - 2020-12-10 02:39:43 --> Output Class Initialized
INFO - 2020-12-10 02:39:43 --> Security Class Initialized
DEBUG - 2020-12-10 02:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:39:43 --> Input Class Initialized
INFO - 2020-12-10 02:39:43 --> Language Class Initialized
INFO - 2020-12-10 02:39:43 --> Language Class Initialized
INFO - 2020-12-10 02:39:43 --> Config Class Initialized
INFO - 2020-12-10 02:39:43 --> Loader Class Initialized
INFO - 2020-12-10 02:39:43 --> Helper loaded: url_helper
INFO - 2020-12-10 02:39:43 --> Helper loaded: file_helper
INFO - 2020-12-10 02:39:43 --> Helper loaded: form_helper
INFO - 2020-12-10 02:39:43 --> Helper loaded: my_helper
INFO - 2020-12-10 02:39:43 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:39:43 --> Controller Class Initialized
INFO - 2020-12-10 02:39:43 --> Upload Class Initialized
INFO - 2020-12-10 02:39:43 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-12-10 02:39:43 --> The upload path does not appear to be valid.
INFO - 2020-12-10 02:39:43 --> Config Class Initialized
INFO - 2020-12-10 02:39:43 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:39:43 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:39:43 --> Utf8 Class Initialized
INFO - 2020-12-10 02:39:43 --> URI Class Initialized
INFO - 2020-12-10 02:39:43 --> Router Class Initialized
INFO - 2020-12-10 02:39:43 --> Output Class Initialized
INFO - 2020-12-10 02:39:43 --> Security Class Initialized
DEBUG - 2020-12-10 02:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:39:43 --> Input Class Initialized
INFO - 2020-12-10 02:39:43 --> Language Class Initialized
INFO - 2020-12-10 02:39:43 --> Language Class Initialized
INFO - 2020-12-10 02:39:43 --> Config Class Initialized
INFO - 2020-12-10 02:39:43 --> Loader Class Initialized
INFO - 2020-12-10 02:39:43 --> Helper loaded: url_helper
INFO - 2020-12-10 02:39:43 --> Helper loaded: file_helper
INFO - 2020-12-10 02:39:43 --> Helper loaded: form_helper
INFO - 2020-12-10 02:39:43 --> Helper loaded: my_helper
INFO - 2020-12-10 02:39:43 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:39:43 --> Controller Class Initialized
DEBUG - 2020-12-10 02:39:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:39:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:39:43 --> Final output sent to browser
DEBUG - 2020-12-10 02:39:43 --> Total execution time: 0.0432
INFO - 2020-12-10 02:39:43 --> Config Class Initialized
INFO - 2020-12-10 02:39:43 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:39:43 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:39:43 --> Utf8 Class Initialized
INFO - 2020-12-10 02:39:43 --> URI Class Initialized
INFO - 2020-12-10 02:39:43 --> Router Class Initialized
INFO - 2020-12-10 02:39:43 --> Output Class Initialized
INFO - 2020-12-10 02:39:43 --> Security Class Initialized
DEBUG - 2020-12-10 02:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:39:43 --> Input Class Initialized
INFO - 2020-12-10 02:39:43 --> Language Class Initialized
INFO - 2020-12-10 02:39:43 --> Language Class Initialized
INFO - 2020-12-10 02:39:43 --> Config Class Initialized
INFO - 2020-12-10 02:39:43 --> Loader Class Initialized
INFO - 2020-12-10 02:39:43 --> Helper loaded: url_helper
INFO - 2020-12-10 02:39:43 --> Helper loaded: file_helper
INFO - 2020-12-10 02:39:43 --> Helper loaded: form_helper
INFO - 2020-12-10 02:39:43 --> Helper loaded: my_helper
INFO - 2020-12-10 02:39:43 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:39:43 --> Controller Class Initialized
INFO - 2020-12-10 02:40:18 --> Config Class Initialized
INFO - 2020-12-10 02:40:18 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:40:18 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:40:18 --> Utf8 Class Initialized
INFO - 2020-12-10 02:40:18 --> URI Class Initialized
INFO - 2020-12-10 02:40:18 --> Router Class Initialized
INFO - 2020-12-10 02:40:18 --> Output Class Initialized
INFO - 2020-12-10 02:40:18 --> Security Class Initialized
DEBUG - 2020-12-10 02:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:40:18 --> Input Class Initialized
INFO - 2020-12-10 02:40:18 --> Language Class Initialized
INFO - 2020-12-10 02:40:18 --> Language Class Initialized
INFO - 2020-12-10 02:40:18 --> Config Class Initialized
INFO - 2020-12-10 02:40:18 --> Loader Class Initialized
INFO - 2020-12-10 02:40:18 --> Helper loaded: url_helper
INFO - 2020-12-10 02:40:18 --> Helper loaded: file_helper
INFO - 2020-12-10 02:40:18 --> Helper loaded: form_helper
INFO - 2020-12-10 02:40:18 --> Helper loaded: my_helper
INFO - 2020-12-10 02:40:18 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:40:18 --> Controller Class Initialized
ERROR - 2020-12-10 02:40:18 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-12-10 02:40:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-12-10 02:40:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:40:18 --> Final output sent to browser
DEBUG - 2020-12-10 02:40:18 --> Total execution time: 0.0477
INFO - 2020-12-10 02:40:21 --> Config Class Initialized
INFO - 2020-12-10 02:40:21 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:40:21 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:40:21 --> Utf8 Class Initialized
INFO - 2020-12-10 02:40:21 --> URI Class Initialized
INFO - 2020-12-10 02:40:21 --> Router Class Initialized
INFO - 2020-12-10 02:40:21 --> Output Class Initialized
INFO - 2020-12-10 02:40:21 --> Security Class Initialized
DEBUG - 2020-12-10 02:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:40:21 --> Input Class Initialized
INFO - 2020-12-10 02:40:21 --> Language Class Initialized
INFO - 2020-12-10 02:40:21 --> Language Class Initialized
INFO - 2020-12-10 02:40:21 --> Config Class Initialized
INFO - 2020-12-10 02:40:21 --> Loader Class Initialized
INFO - 2020-12-10 02:40:21 --> Helper loaded: url_helper
INFO - 2020-12-10 02:40:21 --> Helper loaded: file_helper
INFO - 2020-12-10 02:40:21 --> Helper loaded: form_helper
INFO - 2020-12-10 02:40:21 --> Helper loaded: my_helper
INFO - 2020-12-10 02:40:21 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:40:21 --> Controller Class Initialized
INFO - 2020-12-10 02:40:21 --> Upload Class Initialized
INFO - 2020-12-10 02:40:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-12-10 02:40:21 --> The upload path does not appear to be valid.
INFO - 2020-12-10 02:40:21 --> Config Class Initialized
INFO - 2020-12-10 02:40:21 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:40:21 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:40:21 --> Utf8 Class Initialized
INFO - 2020-12-10 02:40:21 --> URI Class Initialized
INFO - 2020-12-10 02:40:21 --> Router Class Initialized
INFO - 2020-12-10 02:40:21 --> Output Class Initialized
INFO - 2020-12-10 02:40:21 --> Security Class Initialized
DEBUG - 2020-12-10 02:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:40:21 --> Input Class Initialized
INFO - 2020-12-10 02:40:21 --> Language Class Initialized
INFO - 2020-12-10 02:40:21 --> Language Class Initialized
INFO - 2020-12-10 02:40:21 --> Config Class Initialized
INFO - 2020-12-10 02:40:21 --> Loader Class Initialized
INFO - 2020-12-10 02:40:21 --> Helper loaded: url_helper
INFO - 2020-12-10 02:40:21 --> Helper loaded: file_helper
INFO - 2020-12-10 02:40:21 --> Helper loaded: form_helper
INFO - 2020-12-10 02:40:21 --> Helper loaded: my_helper
INFO - 2020-12-10 02:40:21 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:40:21 --> Controller Class Initialized
DEBUG - 2020-12-10 02:40:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:40:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:40:21 --> Final output sent to browser
DEBUG - 2020-12-10 02:40:21 --> Total execution time: 0.0419
INFO - 2020-12-10 02:40:27 --> Config Class Initialized
INFO - 2020-12-10 02:40:27 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:40:27 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:40:27 --> Utf8 Class Initialized
INFO - 2020-12-10 02:40:27 --> URI Class Initialized
INFO - 2020-12-10 02:40:27 --> Router Class Initialized
INFO - 2020-12-10 02:40:27 --> Output Class Initialized
INFO - 2020-12-10 02:40:27 --> Security Class Initialized
DEBUG - 2020-12-10 02:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:40:27 --> Input Class Initialized
INFO - 2020-12-10 02:40:27 --> Language Class Initialized
INFO - 2020-12-10 02:40:27 --> Language Class Initialized
INFO - 2020-12-10 02:40:27 --> Config Class Initialized
INFO - 2020-12-10 02:40:27 --> Loader Class Initialized
INFO - 2020-12-10 02:40:27 --> Helper loaded: url_helper
INFO - 2020-12-10 02:40:27 --> Helper loaded: file_helper
INFO - 2020-12-10 02:40:27 --> Helper loaded: form_helper
INFO - 2020-12-10 02:40:27 --> Helper loaded: my_helper
INFO - 2020-12-10 02:40:27 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:40:27 --> Controller Class Initialized
INFO - 2020-12-10 02:40:40 --> Config Class Initialized
INFO - 2020-12-10 02:40:40 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:40:40 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:40:40 --> Utf8 Class Initialized
INFO - 2020-12-10 02:40:40 --> URI Class Initialized
INFO - 2020-12-10 02:40:40 --> Router Class Initialized
INFO - 2020-12-10 02:40:40 --> Output Class Initialized
INFO - 2020-12-10 02:40:40 --> Security Class Initialized
DEBUG - 2020-12-10 02:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:40:40 --> Input Class Initialized
INFO - 2020-12-10 02:40:40 --> Language Class Initialized
INFO - 2020-12-10 02:40:40 --> Language Class Initialized
INFO - 2020-12-10 02:40:40 --> Config Class Initialized
INFO - 2020-12-10 02:40:40 --> Loader Class Initialized
INFO - 2020-12-10 02:40:40 --> Helper loaded: url_helper
INFO - 2020-12-10 02:40:40 --> Helper loaded: file_helper
INFO - 2020-12-10 02:40:40 --> Helper loaded: form_helper
INFO - 2020-12-10 02:40:40 --> Helper loaded: my_helper
INFO - 2020-12-10 02:40:40 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:40:40 --> Controller Class Initialized
ERROR - 2020-12-10 02:40:40 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-12-10 02:40:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-12-10 02:40:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:40:40 --> Final output sent to browser
DEBUG - 2020-12-10 02:40:40 --> Total execution time: 0.0357
INFO - 2020-12-10 02:46:13 --> Config Class Initialized
INFO - 2020-12-10 02:46:13 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:46:13 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:46:13 --> Utf8 Class Initialized
INFO - 2020-12-10 02:46:13 --> URI Class Initialized
INFO - 2020-12-10 02:46:13 --> Router Class Initialized
INFO - 2020-12-10 02:46:13 --> Output Class Initialized
INFO - 2020-12-10 02:46:13 --> Security Class Initialized
DEBUG - 2020-12-10 02:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:46:13 --> Input Class Initialized
INFO - 2020-12-10 02:46:13 --> Language Class Initialized
INFO - 2020-12-10 02:46:13 --> Language Class Initialized
INFO - 2020-12-10 02:46:13 --> Config Class Initialized
INFO - 2020-12-10 02:46:13 --> Loader Class Initialized
INFO - 2020-12-10 02:46:13 --> Helper loaded: url_helper
INFO - 2020-12-10 02:46:13 --> Helper loaded: file_helper
INFO - 2020-12-10 02:46:13 --> Helper loaded: form_helper
INFO - 2020-12-10 02:46:13 --> Helper loaded: my_helper
INFO - 2020-12-10 02:46:13 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:46:13 --> Controller Class Initialized
ERROR - 2020-12-10 02:46:13 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-12-10 02:46:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-12-10 02:46:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:46:13 --> Final output sent to browser
DEBUG - 2020-12-10 02:46:13 --> Total execution time: 0.0382
INFO - 2020-12-10 02:46:17 --> Config Class Initialized
INFO - 2020-12-10 02:46:17 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:46:17 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:46:17 --> Utf8 Class Initialized
INFO - 2020-12-10 02:46:17 --> URI Class Initialized
INFO - 2020-12-10 02:46:17 --> Router Class Initialized
INFO - 2020-12-10 02:46:17 --> Output Class Initialized
INFO - 2020-12-10 02:46:17 --> Security Class Initialized
DEBUG - 2020-12-10 02:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:46:17 --> Input Class Initialized
INFO - 2020-12-10 02:46:17 --> Language Class Initialized
INFO - 2020-12-10 02:46:17 --> Language Class Initialized
INFO - 2020-12-10 02:46:17 --> Config Class Initialized
INFO - 2020-12-10 02:46:17 --> Loader Class Initialized
INFO - 2020-12-10 02:46:17 --> Helper loaded: url_helper
INFO - 2020-12-10 02:46:17 --> Helper loaded: file_helper
INFO - 2020-12-10 02:46:17 --> Helper loaded: form_helper
INFO - 2020-12-10 02:46:17 --> Helper loaded: my_helper
INFO - 2020-12-10 02:46:17 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:46:17 --> Controller Class Initialized
INFO - 2020-12-10 02:46:17 --> Upload Class Initialized
INFO - 2020-12-10 02:46:17 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-12-10 02:46:17 --> The upload path does not appear to be valid.
INFO - 2020-12-10 02:46:17 --> Config Class Initialized
INFO - 2020-12-10 02:46:17 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:46:17 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:46:17 --> Utf8 Class Initialized
INFO - 2020-12-10 02:46:17 --> URI Class Initialized
INFO - 2020-12-10 02:46:17 --> Router Class Initialized
INFO - 2020-12-10 02:46:17 --> Output Class Initialized
INFO - 2020-12-10 02:46:17 --> Security Class Initialized
DEBUG - 2020-12-10 02:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:46:17 --> Input Class Initialized
INFO - 2020-12-10 02:46:17 --> Language Class Initialized
INFO - 2020-12-10 02:46:17 --> Language Class Initialized
INFO - 2020-12-10 02:46:17 --> Config Class Initialized
INFO - 2020-12-10 02:46:17 --> Loader Class Initialized
INFO - 2020-12-10 02:46:17 --> Helper loaded: url_helper
INFO - 2020-12-10 02:46:17 --> Helper loaded: file_helper
INFO - 2020-12-10 02:46:17 --> Helper loaded: form_helper
INFO - 2020-12-10 02:46:17 --> Helper loaded: my_helper
INFO - 2020-12-10 02:46:17 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:46:17 --> Controller Class Initialized
DEBUG - 2020-12-10 02:46:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:46:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:46:17 --> Final output sent to browser
DEBUG - 2020-12-10 02:46:17 --> Total execution time: 0.0551
INFO - 2020-12-10 02:46:17 --> Config Class Initialized
INFO - 2020-12-10 02:46:17 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:46:17 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:46:17 --> Utf8 Class Initialized
INFO - 2020-12-10 02:46:17 --> URI Class Initialized
INFO - 2020-12-10 02:46:17 --> Router Class Initialized
INFO - 2020-12-10 02:46:17 --> Output Class Initialized
INFO - 2020-12-10 02:46:17 --> Security Class Initialized
DEBUG - 2020-12-10 02:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:46:17 --> Input Class Initialized
INFO - 2020-12-10 02:46:17 --> Language Class Initialized
INFO - 2020-12-10 02:46:17 --> Language Class Initialized
INFO - 2020-12-10 02:46:17 --> Config Class Initialized
INFO - 2020-12-10 02:46:17 --> Loader Class Initialized
INFO - 2020-12-10 02:46:17 --> Helper loaded: url_helper
INFO - 2020-12-10 02:46:17 --> Helper loaded: file_helper
INFO - 2020-12-10 02:46:17 --> Helper loaded: form_helper
INFO - 2020-12-10 02:46:17 --> Helper loaded: my_helper
INFO - 2020-12-10 02:46:17 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:46:17 --> Controller Class Initialized
INFO - 2020-12-10 02:47:06 --> Config Class Initialized
INFO - 2020-12-10 02:47:06 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:47:06 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:47:06 --> Utf8 Class Initialized
INFO - 2020-12-10 02:47:06 --> URI Class Initialized
INFO - 2020-12-10 02:47:06 --> Router Class Initialized
INFO - 2020-12-10 02:47:06 --> Output Class Initialized
INFO - 2020-12-10 02:47:06 --> Security Class Initialized
DEBUG - 2020-12-10 02:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:47:06 --> Input Class Initialized
INFO - 2020-12-10 02:47:06 --> Language Class Initialized
INFO - 2020-12-10 02:47:06 --> Language Class Initialized
INFO - 2020-12-10 02:47:06 --> Config Class Initialized
INFO - 2020-12-10 02:47:06 --> Loader Class Initialized
INFO - 2020-12-10 02:47:06 --> Helper loaded: url_helper
INFO - 2020-12-10 02:47:06 --> Helper loaded: file_helper
INFO - 2020-12-10 02:47:06 --> Helper loaded: form_helper
INFO - 2020-12-10 02:47:06 --> Helper loaded: my_helper
INFO - 2020-12-10 02:47:06 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:47:06 --> Controller Class Initialized
INFO - 2020-12-10 02:47:07 --> Config Class Initialized
INFO - 2020-12-10 02:47:07 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:47:07 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:47:07 --> Utf8 Class Initialized
INFO - 2020-12-10 02:47:07 --> URI Class Initialized
INFO - 2020-12-10 02:47:07 --> Router Class Initialized
INFO - 2020-12-10 02:47:07 --> Output Class Initialized
INFO - 2020-12-10 02:47:07 --> Security Class Initialized
DEBUG - 2020-12-10 02:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:47:07 --> Input Class Initialized
INFO - 2020-12-10 02:47:07 --> Language Class Initialized
INFO - 2020-12-10 02:47:07 --> Language Class Initialized
INFO - 2020-12-10 02:47:07 --> Config Class Initialized
INFO - 2020-12-10 02:47:07 --> Loader Class Initialized
INFO - 2020-12-10 02:47:07 --> Helper loaded: url_helper
INFO - 2020-12-10 02:47:07 --> Helper loaded: file_helper
INFO - 2020-12-10 02:47:07 --> Helper loaded: form_helper
INFO - 2020-12-10 02:47:07 --> Helper loaded: my_helper
INFO - 2020-12-10 02:47:07 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:47:07 --> Controller Class Initialized
ERROR - 2020-12-10 02:47:07 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-12-10 02:47:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-12-10 02:47:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:47:07 --> Final output sent to browser
DEBUG - 2020-12-10 02:47:07 --> Total execution time: 0.0488
INFO - 2020-12-10 02:47:11 --> Config Class Initialized
INFO - 2020-12-10 02:47:11 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:47:11 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:47:11 --> Utf8 Class Initialized
INFO - 2020-12-10 02:47:11 --> URI Class Initialized
INFO - 2020-12-10 02:47:11 --> Router Class Initialized
INFO - 2020-12-10 02:47:11 --> Output Class Initialized
INFO - 2020-12-10 02:47:11 --> Security Class Initialized
DEBUG - 2020-12-10 02:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:47:11 --> Input Class Initialized
INFO - 2020-12-10 02:47:11 --> Language Class Initialized
INFO - 2020-12-10 02:47:11 --> Language Class Initialized
INFO - 2020-12-10 02:47:11 --> Config Class Initialized
INFO - 2020-12-10 02:47:11 --> Loader Class Initialized
INFO - 2020-12-10 02:47:11 --> Helper loaded: url_helper
INFO - 2020-12-10 02:47:11 --> Helper loaded: file_helper
INFO - 2020-12-10 02:47:11 --> Helper loaded: form_helper
INFO - 2020-12-10 02:47:11 --> Helper loaded: my_helper
INFO - 2020-12-10 02:47:11 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:47:11 --> Controller Class Initialized
INFO - 2020-12-10 02:47:11 --> Upload Class Initialized
INFO - 2020-12-10 02:47:11 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-12-10 02:47:11 --> The upload path does not appear to be valid.
INFO - 2020-12-10 02:47:11 --> Config Class Initialized
INFO - 2020-12-10 02:47:11 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:47:11 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:47:11 --> Utf8 Class Initialized
INFO - 2020-12-10 02:47:11 --> URI Class Initialized
INFO - 2020-12-10 02:47:11 --> Router Class Initialized
INFO - 2020-12-10 02:47:11 --> Output Class Initialized
INFO - 2020-12-10 02:47:11 --> Security Class Initialized
DEBUG - 2020-12-10 02:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:47:11 --> Input Class Initialized
INFO - 2020-12-10 02:47:11 --> Language Class Initialized
INFO - 2020-12-10 02:47:11 --> Language Class Initialized
INFO - 2020-12-10 02:47:11 --> Config Class Initialized
INFO - 2020-12-10 02:47:11 --> Loader Class Initialized
INFO - 2020-12-10 02:47:11 --> Helper loaded: url_helper
INFO - 2020-12-10 02:47:11 --> Helper loaded: file_helper
INFO - 2020-12-10 02:47:11 --> Helper loaded: form_helper
INFO - 2020-12-10 02:47:11 --> Helper loaded: my_helper
INFO - 2020-12-10 02:47:11 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:47:11 --> Controller Class Initialized
DEBUG - 2020-12-10 02:47:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:47:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:47:11 --> Final output sent to browser
DEBUG - 2020-12-10 02:47:11 --> Total execution time: 0.0453
INFO - 2020-12-10 02:47:12 --> Config Class Initialized
INFO - 2020-12-10 02:47:12 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:47:12 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:47:12 --> Utf8 Class Initialized
INFO - 2020-12-10 02:47:12 --> URI Class Initialized
INFO - 2020-12-10 02:47:12 --> Router Class Initialized
INFO - 2020-12-10 02:47:12 --> Output Class Initialized
INFO - 2020-12-10 02:47:12 --> Security Class Initialized
DEBUG - 2020-12-10 02:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:47:12 --> Input Class Initialized
INFO - 2020-12-10 02:47:12 --> Language Class Initialized
INFO - 2020-12-10 02:47:12 --> Language Class Initialized
INFO - 2020-12-10 02:47:12 --> Config Class Initialized
INFO - 2020-12-10 02:47:12 --> Loader Class Initialized
INFO - 2020-12-10 02:47:12 --> Helper loaded: url_helper
INFO - 2020-12-10 02:47:12 --> Helper loaded: file_helper
INFO - 2020-12-10 02:47:12 --> Helper loaded: form_helper
INFO - 2020-12-10 02:47:12 --> Helper loaded: my_helper
INFO - 2020-12-10 02:47:12 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:47:12 --> Controller Class Initialized
INFO - 2020-12-10 02:56:53 --> Config Class Initialized
INFO - 2020-12-10 02:56:53 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:56:53 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:56:53 --> Utf8 Class Initialized
INFO - 2020-12-10 02:56:53 --> URI Class Initialized
INFO - 2020-12-10 02:56:53 --> Router Class Initialized
INFO - 2020-12-10 02:56:53 --> Output Class Initialized
INFO - 2020-12-10 02:56:53 --> Security Class Initialized
DEBUG - 2020-12-10 02:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:56:53 --> Input Class Initialized
INFO - 2020-12-10 02:56:53 --> Language Class Initialized
INFO - 2020-12-10 02:56:53 --> Language Class Initialized
INFO - 2020-12-10 02:56:53 --> Config Class Initialized
INFO - 2020-12-10 02:56:53 --> Loader Class Initialized
INFO - 2020-12-10 02:56:53 --> Helper loaded: url_helper
INFO - 2020-12-10 02:56:53 --> Helper loaded: file_helper
INFO - 2020-12-10 02:56:53 --> Helper loaded: form_helper
INFO - 2020-12-10 02:56:53 --> Helper loaded: my_helper
INFO - 2020-12-10 02:56:53 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:56:53 --> Controller Class Initialized
INFO - 2020-12-10 02:56:53 --> Helper loaded: cookie_helper
INFO - 2020-12-10 02:56:53 --> Config Class Initialized
INFO - 2020-12-10 02:56:53 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:56:53 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:56:53 --> Utf8 Class Initialized
INFO - 2020-12-10 02:56:53 --> URI Class Initialized
INFO - 2020-12-10 02:56:53 --> Router Class Initialized
INFO - 2020-12-10 02:56:53 --> Output Class Initialized
INFO - 2020-12-10 02:56:53 --> Security Class Initialized
DEBUG - 2020-12-10 02:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:56:53 --> Input Class Initialized
INFO - 2020-12-10 02:56:53 --> Language Class Initialized
INFO - 2020-12-10 02:56:53 --> Language Class Initialized
INFO - 2020-12-10 02:56:53 --> Config Class Initialized
INFO - 2020-12-10 02:56:53 --> Loader Class Initialized
INFO - 2020-12-10 02:56:53 --> Helper loaded: url_helper
INFO - 2020-12-10 02:56:53 --> Helper loaded: file_helper
INFO - 2020-12-10 02:56:53 --> Helper loaded: form_helper
INFO - 2020-12-10 02:56:53 --> Helper loaded: my_helper
INFO - 2020-12-10 02:56:53 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:56:53 --> Controller Class Initialized
DEBUG - 2020-12-10 02:56:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 02:56:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:56:53 --> Final output sent to browser
DEBUG - 2020-12-10 02:56:53 --> Total execution time: 0.0392
INFO - 2020-12-10 02:57:06 --> Config Class Initialized
INFO - 2020-12-10 02:57:06 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:57:06 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:57:06 --> Utf8 Class Initialized
INFO - 2020-12-10 02:57:06 --> URI Class Initialized
INFO - 2020-12-10 02:57:06 --> Router Class Initialized
INFO - 2020-12-10 02:57:06 --> Output Class Initialized
INFO - 2020-12-10 02:57:06 --> Security Class Initialized
DEBUG - 2020-12-10 02:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:57:06 --> Input Class Initialized
INFO - 2020-12-10 02:57:06 --> Language Class Initialized
INFO - 2020-12-10 02:57:06 --> Language Class Initialized
INFO - 2020-12-10 02:57:06 --> Config Class Initialized
INFO - 2020-12-10 02:57:06 --> Loader Class Initialized
INFO - 2020-12-10 02:57:06 --> Helper loaded: url_helper
INFO - 2020-12-10 02:57:06 --> Helper loaded: file_helper
INFO - 2020-12-10 02:57:06 --> Helper loaded: form_helper
INFO - 2020-12-10 02:57:06 --> Helper loaded: my_helper
INFO - 2020-12-10 02:57:06 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:57:06 --> Controller Class Initialized
DEBUG - 2020-12-10 02:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:57:06 --> Final output sent to browser
DEBUG - 2020-12-10 02:57:06 --> Total execution time: 0.0336
INFO - 2020-12-10 02:57:06 --> Config Class Initialized
INFO - 2020-12-10 02:57:06 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:57:06 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:57:06 --> Utf8 Class Initialized
INFO - 2020-12-10 02:57:06 --> URI Class Initialized
INFO - 2020-12-10 02:57:06 --> Router Class Initialized
INFO - 2020-12-10 02:57:06 --> Output Class Initialized
INFO - 2020-12-10 02:57:06 --> Security Class Initialized
DEBUG - 2020-12-10 02:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:57:06 --> Input Class Initialized
INFO - 2020-12-10 02:57:06 --> Language Class Initialized
INFO - 2020-12-10 02:57:06 --> Language Class Initialized
INFO - 2020-12-10 02:57:06 --> Config Class Initialized
INFO - 2020-12-10 02:57:06 --> Loader Class Initialized
INFO - 2020-12-10 02:57:06 --> Helper loaded: url_helper
INFO - 2020-12-10 02:57:06 --> Helper loaded: file_helper
INFO - 2020-12-10 02:57:06 --> Helper loaded: form_helper
INFO - 2020-12-10 02:57:06 --> Helper loaded: my_helper
INFO - 2020-12-10 02:57:06 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:57:06 --> Controller Class Initialized
INFO - 2020-12-10 02:57:11 --> Config Class Initialized
INFO - 2020-12-10 02:57:11 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:57:11 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:57:11 --> Utf8 Class Initialized
INFO - 2020-12-10 02:57:11 --> URI Class Initialized
INFO - 2020-12-10 02:57:11 --> Router Class Initialized
INFO - 2020-12-10 02:57:11 --> Output Class Initialized
INFO - 2020-12-10 02:57:11 --> Security Class Initialized
DEBUG - 2020-12-10 02:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:57:11 --> Input Class Initialized
INFO - 2020-12-10 02:57:11 --> Language Class Initialized
INFO - 2020-12-10 02:57:11 --> Language Class Initialized
INFO - 2020-12-10 02:57:11 --> Config Class Initialized
INFO - 2020-12-10 02:57:11 --> Loader Class Initialized
INFO - 2020-12-10 02:57:11 --> Helper loaded: url_helper
INFO - 2020-12-10 02:57:11 --> Helper loaded: file_helper
INFO - 2020-12-10 02:57:11 --> Helper loaded: form_helper
INFO - 2020-12-10 02:57:11 --> Helper loaded: my_helper
INFO - 2020-12-10 02:57:11 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:57:11 --> Controller Class Initialized
ERROR - 2020-12-10 02:57:11 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-12-10 02:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-12-10 02:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:57:11 --> Final output sent to browser
DEBUG - 2020-12-10 02:57:11 --> Total execution time: 0.0445
INFO - 2020-12-10 02:59:04 --> Config Class Initialized
INFO - 2020-12-10 02:59:04 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:04 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:04 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:04 --> URI Class Initialized
INFO - 2020-12-10 02:59:04 --> Router Class Initialized
INFO - 2020-12-10 02:59:04 --> Output Class Initialized
INFO - 2020-12-10 02:59:04 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:04 --> Input Class Initialized
INFO - 2020-12-10 02:59:04 --> Language Class Initialized
INFO - 2020-12-10 02:59:04 --> Language Class Initialized
INFO - 2020-12-10 02:59:04 --> Config Class Initialized
INFO - 2020-12-10 02:59:04 --> Loader Class Initialized
INFO - 2020-12-10 02:59:04 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:04 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:04 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:04 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:04 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:04 --> Controller Class Initialized
INFO - 2020-12-10 02:59:04 --> Upload Class Initialized
INFO - 2020-12-10 02:59:04 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-12-10 02:59:04 --> The upload path does not appear to be valid.
INFO - 2020-12-10 02:59:04 --> Config Class Initialized
INFO - 2020-12-10 02:59:04 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:04 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:04 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:04 --> URI Class Initialized
INFO - 2020-12-10 02:59:04 --> Router Class Initialized
INFO - 2020-12-10 02:59:04 --> Output Class Initialized
INFO - 2020-12-10 02:59:04 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:04 --> Input Class Initialized
INFO - 2020-12-10 02:59:04 --> Language Class Initialized
INFO - 2020-12-10 02:59:04 --> Language Class Initialized
INFO - 2020-12-10 02:59:04 --> Config Class Initialized
INFO - 2020-12-10 02:59:04 --> Loader Class Initialized
INFO - 2020-12-10 02:59:04 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:04 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:04 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:04 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:04 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:04 --> Controller Class Initialized
DEBUG - 2020-12-10 02:59:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:59:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:59:04 --> Final output sent to browser
DEBUG - 2020-12-10 02:59:04 --> Total execution time: 0.0623
INFO - 2020-12-10 02:59:10 --> Config Class Initialized
INFO - 2020-12-10 02:59:10 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:10 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:10 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:10 --> URI Class Initialized
INFO - 2020-12-10 02:59:10 --> Router Class Initialized
INFO - 2020-12-10 02:59:10 --> Output Class Initialized
INFO - 2020-12-10 02:59:10 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:10 --> Input Class Initialized
INFO - 2020-12-10 02:59:10 --> Language Class Initialized
INFO - 2020-12-10 02:59:10 --> Language Class Initialized
INFO - 2020-12-10 02:59:10 --> Config Class Initialized
INFO - 2020-12-10 02:59:10 --> Loader Class Initialized
INFO - 2020-12-10 02:59:10 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:10 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:10 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:10 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:10 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:10 --> Controller Class Initialized
INFO - 2020-12-10 02:59:16 --> Config Class Initialized
INFO - 2020-12-10 02:59:16 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:16 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:16 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:16 --> URI Class Initialized
INFO - 2020-12-10 02:59:16 --> Router Class Initialized
INFO - 2020-12-10 02:59:16 --> Output Class Initialized
INFO - 2020-12-10 02:59:16 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:16 --> Input Class Initialized
INFO - 2020-12-10 02:59:16 --> Language Class Initialized
INFO - 2020-12-10 02:59:16 --> Language Class Initialized
INFO - 2020-12-10 02:59:16 --> Config Class Initialized
INFO - 2020-12-10 02:59:16 --> Loader Class Initialized
INFO - 2020-12-10 02:59:16 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:16 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:16 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:16 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:16 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:16 --> Controller Class Initialized
INFO - 2020-12-10 02:59:16 --> Config Class Initialized
INFO - 2020-12-10 02:59:16 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:16 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:16 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:16 --> URI Class Initialized
INFO - 2020-12-10 02:59:16 --> Router Class Initialized
INFO - 2020-12-10 02:59:16 --> Output Class Initialized
INFO - 2020-12-10 02:59:16 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:16 --> Input Class Initialized
INFO - 2020-12-10 02:59:16 --> Language Class Initialized
INFO - 2020-12-10 02:59:16 --> Language Class Initialized
INFO - 2020-12-10 02:59:16 --> Config Class Initialized
INFO - 2020-12-10 02:59:16 --> Loader Class Initialized
INFO - 2020-12-10 02:59:16 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:16 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:16 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:16 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:16 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:16 --> Controller Class Initialized
INFO - 2020-12-10 02:59:17 --> Config Class Initialized
INFO - 2020-12-10 02:59:17 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:17 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:17 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:17 --> URI Class Initialized
INFO - 2020-12-10 02:59:17 --> Router Class Initialized
INFO - 2020-12-10 02:59:17 --> Output Class Initialized
INFO - 2020-12-10 02:59:17 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:17 --> Input Class Initialized
INFO - 2020-12-10 02:59:17 --> Language Class Initialized
INFO - 2020-12-10 02:59:17 --> Language Class Initialized
INFO - 2020-12-10 02:59:17 --> Config Class Initialized
INFO - 2020-12-10 02:59:17 --> Loader Class Initialized
INFO - 2020-12-10 02:59:17 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:17 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:17 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:17 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:17 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:17 --> Controller Class Initialized
INFO - 2020-12-10 02:59:37 --> Config Class Initialized
INFO - 2020-12-10 02:59:37 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:37 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:37 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:37 --> URI Class Initialized
INFO - 2020-12-10 02:59:37 --> Router Class Initialized
INFO - 2020-12-10 02:59:37 --> Output Class Initialized
INFO - 2020-12-10 02:59:37 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:37 --> Input Class Initialized
INFO - 2020-12-10 02:59:37 --> Language Class Initialized
INFO - 2020-12-10 02:59:37 --> Language Class Initialized
INFO - 2020-12-10 02:59:37 --> Config Class Initialized
INFO - 2020-12-10 02:59:37 --> Loader Class Initialized
INFO - 2020-12-10 02:59:37 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:37 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:37 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:37 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:37 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:37 --> Controller Class Initialized
INFO - 2020-12-10 02:59:40 --> Config Class Initialized
INFO - 2020-12-10 02:59:40 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:40 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:40 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:40 --> URI Class Initialized
INFO - 2020-12-10 02:59:40 --> Router Class Initialized
INFO - 2020-12-10 02:59:40 --> Output Class Initialized
INFO - 2020-12-10 02:59:40 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:40 --> Input Class Initialized
INFO - 2020-12-10 02:59:40 --> Language Class Initialized
INFO - 2020-12-10 02:59:40 --> Language Class Initialized
INFO - 2020-12-10 02:59:40 --> Config Class Initialized
INFO - 2020-12-10 02:59:40 --> Loader Class Initialized
INFO - 2020-12-10 02:59:40 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:40 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:40 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:40 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:40 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:40 --> Controller Class Initialized
INFO - 2020-12-10 02:59:45 --> Config Class Initialized
INFO - 2020-12-10 02:59:45 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:46 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:46 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:46 --> URI Class Initialized
INFO - 2020-12-10 02:59:46 --> Router Class Initialized
INFO - 2020-12-10 02:59:46 --> Output Class Initialized
INFO - 2020-12-10 02:59:46 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:46 --> Input Class Initialized
INFO - 2020-12-10 02:59:46 --> Language Class Initialized
INFO - 2020-12-10 02:59:46 --> Language Class Initialized
INFO - 2020-12-10 02:59:46 --> Config Class Initialized
INFO - 2020-12-10 02:59:46 --> Loader Class Initialized
INFO - 2020-12-10 02:59:46 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:46 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:46 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:46 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:46 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:46 --> Controller Class Initialized
INFO - 2020-12-10 02:59:46 --> Config Class Initialized
INFO - 2020-12-10 02:59:46 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:46 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:46 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:46 --> URI Class Initialized
INFO - 2020-12-10 02:59:46 --> Router Class Initialized
INFO - 2020-12-10 02:59:46 --> Output Class Initialized
INFO - 2020-12-10 02:59:46 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:46 --> Input Class Initialized
INFO - 2020-12-10 02:59:46 --> Language Class Initialized
INFO - 2020-12-10 02:59:46 --> Language Class Initialized
INFO - 2020-12-10 02:59:46 --> Config Class Initialized
INFO - 2020-12-10 02:59:46 --> Loader Class Initialized
INFO - 2020-12-10 02:59:46 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:46 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:46 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:46 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:46 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:46 --> Controller Class Initialized
DEBUG - 2020-12-10 02:59:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:59:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:59:46 --> Final output sent to browser
DEBUG - 2020-12-10 02:59:46 --> Total execution time: 0.0459
INFO - 2020-12-10 02:59:46 --> Config Class Initialized
INFO - 2020-12-10 02:59:46 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:46 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:46 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:46 --> URI Class Initialized
INFO - 2020-12-10 02:59:46 --> Router Class Initialized
INFO - 2020-12-10 02:59:46 --> Output Class Initialized
INFO - 2020-12-10 02:59:46 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:46 --> Input Class Initialized
INFO - 2020-12-10 02:59:46 --> Language Class Initialized
INFO - 2020-12-10 02:59:46 --> Language Class Initialized
INFO - 2020-12-10 02:59:46 --> Config Class Initialized
INFO - 2020-12-10 02:59:46 --> Loader Class Initialized
INFO - 2020-12-10 02:59:46 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:46 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:46 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:46 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:46 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:46 --> Controller Class Initialized
INFO - 2020-12-10 02:59:48 --> Config Class Initialized
INFO - 2020-12-10 02:59:48 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:48 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:48 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:48 --> URI Class Initialized
DEBUG - 2020-12-10 02:59:48 --> No URI present. Default controller set.
INFO - 2020-12-10 02:59:48 --> Router Class Initialized
INFO - 2020-12-10 02:59:48 --> Output Class Initialized
INFO - 2020-12-10 02:59:48 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:48 --> Input Class Initialized
INFO - 2020-12-10 02:59:48 --> Language Class Initialized
INFO - 2020-12-10 02:59:48 --> Language Class Initialized
INFO - 2020-12-10 02:59:48 --> Config Class Initialized
INFO - 2020-12-10 02:59:48 --> Loader Class Initialized
INFO - 2020-12-10 02:59:48 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:48 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:48 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:48 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:48 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:48 --> Controller Class Initialized
INFO - 2020-12-10 02:59:48 --> Config Class Initialized
INFO - 2020-12-10 02:59:48 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:48 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:48 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:48 --> URI Class Initialized
INFO - 2020-12-10 02:59:48 --> Router Class Initialized
INFO - 2020-12-10 02:59:48 --> Output Class Initialized
INFO - 2020-12-10 02:59:48 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:48 --> Input Class Initialized
INFO - 2020-12-10 02:59:48 --> Language Class Initialized
INFO - 2020-12-10 02:59:48 --> Language Class Initialized
INFO - 2020-12-10 02:59:48 --> Config Class Initialized
INFO - 2020-12-10 02:59:48 --> Loader Class Initialized
INFO - 2020-12-10 02:59:48 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:48 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:48 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:48 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:48 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:48 --> Controller Class Initialized
DEBUG - 2020-12-10 02:59:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 02:59:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:59:48 --> Final output sent to browser
DEBUG - 2020-12-10 02:59:48 --> Total execution time: 0.0396
INFO - 2020-12-10 02:59:56 --> Config Class Initialized
INFO - 2020-12-10 02:59:56 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:56 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:56 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:56 --> URI Class Initialized
INFO - 2020-12-10 02:59:56 --> Router Class Initialized
INFO - 2020-12-10 02:59:56 --> Output Class Initialized
INFO - 2020-12-10 02:59:56 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:56 --> Input Class Initialized
INFO - 2020-12-10 02:59:56 --> Language Class Initialized
INFO - 2020-12-10 02:59:56 --> Language Class Initialized
INFO - 2020-12-10 02:59:56 --> Config Class Initialized
INFO - 2020-12-10 02:59:56 --> Loader Class Initialized
INFO - 2020-12-10 02:59:56 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:56 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:56 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:56 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:56 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:56 --> Controller Class Initialized
DEBUG - 2020-12-10 02:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-12-10 02:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 02:59:56 --> Final output sent to browser
DEBUG - 2020-12-10 02:59:56 --> Total execution time: 0.0433
INFO - 2020-12-10 02:59:59 --> Config Class Initialized
INFO - 2020-12-10 02:59:59 --> Hooks Class Initialized
DEBUG - 2020-12-10 02:59:59 --> UTF-8 Support Enabled
INFO - 2020-12-10 02:59:59 --> Utf8 Class Initialized
INFO - 2020-12-10 02:59:59 --> URI Class Initialized
INFO - 2020-12-10 02:59:59 --> Router Class Initialized
INFO - 2020-12-10 02:59:59 --> Output Class Initialized
INFO - 2020-12-10 02:59:59 --> Security Class Initialized
DEBUG - 2020-12-10 02:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 02:59:59 --> Input Class Initialized
INFO - 2020-12-10 02:59:59 --> Language Class Initialized
INFO - 2020-12-10 02:59:59 --> Language Class Initialized
INFO - 2020-12-10 02:59:59 --> Config Class Initialized
INFO - 2020-12-10 02:59:59 --> Loader Class Initialized
INFO - 2020-12-10 02:59:59 --> Helper loaded: url_helper
INFO - 2020-12-10 02:59:59 --> Helper loaded: file_helper
INFO - 2020-12-10 02:59:59 --> Helper loaded: form_helper
INFO - 2020-12-10 02:59:59 --> Helper loaded: my_helper
INFO - 2020-12-10 02:59:59 --> Database Driver Class Initialized
DEBUG - 2020-12-10 02:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 02:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 02:59:59 --> Controller Class Initialized
INFO - 2020-12-10 03:00:01 --> Config Class Initialized
INFO - 2020-12-10 03:00:01 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:00:01 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:00:01 --> Utf8 Class Initialized
INFO - 2020-12-10 03:00:01 --> URI Class Initialized
INFO - 2020-12-10 03:00:01 --> Router Class Initialized
INFO - 2020-12-10 03:00:01 --> Output Class Initialized
INFO - 2020-12-10 03:00:01 --> Security Class Initialized
DEBUG - 2020-12-10 03:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:00:01 --> Input Class Initialized
INFO - 2020-12-10 03:00:01 --> Language Class Initialized
INFO - 2020-12-10 03:00:01 --> Language Class Initialized
INFO - 2020-12-10 03:00:01 --> Config Class Initialized
INFO - 2020-12-10 03:00:01 --> Loader Class Initialized
INFO - 2020-12-10 03:00:01 --> Helper loaded: url_helper
INFO - 2020-12-10 03:00:01 --> Helper loaded: file_helper
INFO - 2020-12-10 03:00:01 --> Helper loaded: form_helper
INFO - 2020-12-10 03:00:01 --> Helper loaded: my_helper
INFO - 2020-12-10 03:00:01 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:00:01 --> Controller Class Initialized
DEBUG - 2020-12-10 03:00:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 03:00:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:00:01 --> Final output sent to browser
DEBUG - 2020-12-10 03:00:01 --> Total execution time: 0.0348
INFO - 2020-12-10 03:00:02 --> Config Class Initialized
INFO - 2020-12-10 03:00:02 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:00:02 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:00:02 --> Utf8 Class Initialized
INFO - 2020-12-10 03:00:02 --> URI Class Initialized
DEBUG - 2020-12-10 03:00:02 --> No URI present. Default controller set.
INFO - 2020-12-10 03:00:02 --> Router Class Initialized
INFO - 2020-12-10 03:00:02 --> Output Class Initialized
INFO - 2020-12-10 03:00:02 --> Security Class Initialized
DEBUG - 2020-12-10 03:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:00:02 --> Input Class Initialized
INFO - 2020-12-10 03:00:02 --> Language Class Initialized
INFO - 2020-12-10 03:00:02 --> Language Class Initialized
INFO - 2020-12-10 03:00:02 --> Config Class Initialized
INFO - 2020-12-10 03:00:02 --> Loader Class Initialized
INFO - 2020-12-10 03:00:02 --> Helper loaded: url_helper
INFO - 2020-12-10 03:00:02 --> Helper loaded: file_helper
INFO - 2020-12-10 03:00:02 --> Helper loaded: form_helper
INFO - 2020-12-10 03:00:02 --> Helper loaded: my_helper
INFO - 2020-12-10 03:00:02 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:00:02 --> Controller Class Initialized
INFO - 2020-12-10 03:00:02 --> Config Class Initialized
INFO - 2020-12-10 03:00:02 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:00:02 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:00:02 --> Utf8 Class Initialized
INFO - 2020-12-10 03:00:02 --> URI Class Initialized
INFO - 2020-12-10 03:00:02 --> Router Class Initialized
INFO - 2020-12-10 03:00:02 --> Output Class Initialized
INFO - 2020-12-10 03:00:02 --> Security Class Initialized
DEBUG - 2020-12-10 03:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:00:02 --> Input Class Initialized
INFO - 2020-12-10 03:00:02 --> Language Class Initialized
INFO - 2020-12-10 03:00:02 --> Language Class Initialized
INFO - 2020-12-10 03:00:02 --> Config Class Initialized
INFO - 2020-12-10 03:00:02 --> Loader Class Initialized
INFO - 2020-12-10 03:00:02 --> Helper loaded: url_helper
INFO - 2020-12-10 03:00:02 --> Helper loaded: file_helper
INFO - 2020-12-10 03:00:02 --> Helper loaded: form_helper
INFO - 2020-12-10 03:00:02 --> Helper loaded: my_helper
INFO - 2020-12-10 03:00:02 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:00:02 --> Controller Class Initialized
DEBUG - 2020-12-10 03:00:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 03:00:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:00:02 --> Final output sent to browser
DEBUG - 2020-12-10 03:00:02 --> Total execution time: 0.0431
INFO - 2020-12-10 03:00:03 --> Config Class Initialized
INFO - 2020-12-10 03:00:03 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:00:03 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:00:03 --> Utf8 Class Initialized
INFO - 2020-12-10 03:00:03 --> URI Class Initialized
INFO - 2020-12-10 03:00:03 --> Router Class Initialized
INFO - 2020-12-10 03:00:03 --> Output Class Initialized
INFO - 2020-12-10 03:00:03 --> Security Class Initialized
DEBUG - 2020-12-10 03:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:00:03 --> Input Class Initialized
INFO - 2020-12-10 03:00:03 --> Language Class Initialized
INFO - 2020-12-10 03:00:03 --> Language Class Initialized
INFO - 2020-12-10 03:00:03 --> Config Class Initialized
INFO - 2020-12-10 03:00:03 --> Loader Class Initialized
INFO - 2020-12-10 03:00:03 --> Helper loaded: url_helper
INFO - 2020-12-10 03:00:03 --> Helper loaded: file_helper
INFO - 2020-12-10 03:00:03 --> Helper loaded: form_helper
INFO - 2020-12-10 03:00:03 --> Helper loaded: my_helper
INFO - 2020-12-10 03:00:03 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:00:03 --> Controller Class Initialized
DEBUG - 2020-12-10 03:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 03:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:00:03 --> Final output sent to browser
DEBUG - 2020-12-10 03:00:03 --> Total execution time: 0.0467
INFO - 2020-12-10 03:00:04 --> Config Class Initialized
INFO - 2020-12-10 03:00:04 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:00:04 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:00:04 --> Utf8 Class Initialized
INFO - 2020-12-10 03:00:04 --> URI Class Initialized
DEBUG - 2020-12-10 03:00:04 --> No URI present. Default controller set.
INFO - 2020-12-10 03:00:04 --> Router Class Initialized
INFO - 2020-12-10 03:00:04 --> Output Class Initialized
INFO - 2020-12-10 03:00:04 --> Security Class Initialized
DEBUG - 2020-12-10 03:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:00:04 --> Input Class Initialized
INFO - 2020-12-10 03:00:04 --> Language Class Initialized
INFO - 2020-12-10 03:00:04 --> Language Class Initialized
INFO - 2020-12-10 03:00:04 --> Config Class Initialized
INFO - 2020-12-10 03:00:04 --> Loader Class Initialized
INFO - 2020-12-10 03:00:04 --> Helper loaded: url_helper
INFO - 2020-12-10 03:00:04 --> Helper loaded: file_helper
INFO - 2020-12-10 03:00:04 --> Helper loaded: form_helper
INFO - 2020-12-10 03:00:04 --> Helper loaded: my_helper
INFO - 2020-12-10 03:00:04 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:00:04 --> Controller Class Initialized
INFO - 2020-12-10 03:00:04 --> Config Class Initialized
INFO - 2020-12-10 03:00:04 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:00:04 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:00:04 --> Utf8 Class Initialized
INFO - 2020-12-10 03:00:04 --> URI Class Initialized
INFO - 2020-12-10 03:00:04 --> Router Class Initialized
INFO - 2020-12-10 03:00:04 --> Output Class Initialized
INFO - 2020-12-10 03:00:04 --> Security Class Initialized
DEBUG - 2020-12-10 03:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:00:04 --> Input Class Initialized
INFO - 2020-12-10 03:00:04 --> Language Class Initialized
INFO - 2020-12-10 03:00:04 --> Language Class Initialized
INFO - 2020-12-10 03:00:04 --> Config Class Initialized
INFO - 2020-12-10 03:00:04 --> Loader Class Initialized
INFO - 2020-12-10 03:00:04 --> Helper loaded: url_helper
INFO - 2020-12-10 03:00:04 --> Helper loaded: file_helper
INFO - 2020-12-10 03:00:04 --> Helper loaded: form_helper
INFO - 2020-12-10 03:00:04 --> Helper loaded: my_helper
INFO - 2020-12-10 03:00:04 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:00:04 --> Controller Class Initialized
DEBUG - 2020-12-10 03:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 03:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:00:04 --> Final output sent to browser
DEBUG - 2020-12-10 03:00:04 --> Total execution time: 0.0307
INFO - 2020-12-10 03:00:04 --> Config Class Initialized
INFO - 2020-12-10 03:00:04 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:00:04 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:00:04 --> Utf8 Class Initialized
INFO - 2020-12-10 03:00:04 --> URI Class Initialized
INFO - 2020-12-10 03:00:04 --> Router Class Initialized
INFO - 2020-12-10 03:00:04 --> Output Class Initialized
INFO - 2020-12-10 03:00:04 --> Security Class Initialized
DEBUG - 2020-12-10 03:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:00:04 --> Input Class Initialized
INFO - 2020-12-10 03:00:04 --> Language Class Initialized
INFO - 2020-12-10 03:00:04 --> Language Class Initialized
INFO - 2020-12-10 03:00:04 --> Config Class Initialized
INFO - 2020-12-10 03:00:04 --> Loader Class Initialized
INFO - 2020-12-10 03:00:04 --> Helper loaded: url_helper
INFO - 2020-12-10 03:00:04 --> Helper loaded: file_helper
INFO - 2020-12-10 03:00:04 --> Helper loaded: form_helper
INFO - 2020-12-10 03:00:04 --> Helper loaded: my_helper
INFO - 2020-12-10 03:00:04 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:00:04 --> Controller Class Initialized
DEBUG - 2020-12-10 03:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 03:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:00:04 --> Final output sent to browser
DEBUG - 2020-12-10 03:00:04 --> Total execution time: 0.0454
INFO - 2020-12-10 03:11:51 --> Config Class Initialized
INFO - 2020-12-10 03:11:51 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:11:51 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:11:51 --> Utf8 Class Initialized
INFO - 2020-12-10 03:11:51 --> URI Class Initialized
INFO - 2020-12-10 03:11:51 --> Router Class Initialized
INFO - 2020-12-10 03:11:51 --> Output Class Initialized
INFO - 2020-12-10 03:11:51 --> Security Class Initialized
DEBUG - 2020-12-10 03:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:11:51 --> Input Class Initialized
INFO - 2020-12-10 03:11:51 --> Language Class Initialized
INFO - 2020-12-10 03:11:51 --> Language Class Initialized
INFO - 2020-12-10 03:11:51 --> Config Class Initialized
INFO - 2020-12-10 03:11:51 --> Loader Class Initialized
INFO - 2020-12-10 03:11:51 --> Helper loaded: url_helper
INFO - 2020-12-10 03:11:51 --> Helper loaded: file_helper
INFO - 2020-12-10 03:11:51 --> Helper loaded: form_helper
INFO - 2020-12-10 03:11:51 --> Helper loaded: my_helper
INFO - 2020-12-10 03:11:51 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:11:51 --> Controller Class Initialized
INFO - 2020-12-10 03:11:51 --> Helper loaded: cookie_helper
INFO - 2020-12-10 03:11:51 --> Final output sent to browser
DEBUG - 2020-12-10 03:11:51 --> Total execution time: 0.0455
INFO - 2020-12-10 03:11:54 --> Config Class Initialized
INFO - 2020-12-10 03:11:54 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:11:54 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:11:54 --> Utf8 Class Initialized
INFO - 2020-12-10 03:11:54 --> URI Class Initialized
INFO - 2020-12-10 03:11:54 --> Router Class Initialized
INFO - 2020-12-10 03:11:54 --> Output Class Initialized
INFO - 2020-12-10 03:11:54 --> Security Class Initialized
DEBUG - 2020-12-10 03:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:11:54 --> Input Class Initialized
INFO - 2020-12-10 03:11:54 --> Language Class Initialized
INFO - 2020-12-10 03:11:54 --> Language Class Initialized
INFO - 2020-12-10 03:11:54 --> Config Class Initialized
INFO - 2020-12-10 03:11:54 --> Loader Class Initialized
INFO - 2020-12-10 03:11:54 --> Helper loaded: url_helper
INFO - 2020-12-10 03:11:54 --> Helper loaded: file_helper
INFO - 2020-12-10 03:11:54 --> Helper loaded: form_helper
INFO - 2020-12-10 03:11:54 --> Helper loaded: my_helper
INFO - 2020-12-10 03:11:54 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:11:54 --> Controller Class Initialized
DEBUG - 2020-12-10 03:11:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-10 03:11:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:11:54 --> Final output sent to browser
DEBUG - 2020-12-10 03:11:54 --> Total execution time: 0.0484
INFO - 2020-12-10 03:12:31 --> Config Class Initialized
INFO - 2020-12-10 03:12:31 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:12:31 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:12:31 --> Utf8 Class Initialized
INFO - 2020-12-10 03:12:31 --> URI Class Initialized
INFO - 2020-12-10 03:12:31 --> Router Class Initialized
INFO - 2020-12-10 03:12:31 --> Output Class Initialized
INFO - 2020-12-10 03:12:31 --> Security Class Initialized
DEBUG - 2020-12-10 03:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:12:31 --> Input Class Initialized
INFO - 2020-12-10 03:12:31 --> Language Class Initialized
INFO - 2020-12-10 03:12:31 --> Language Class Initialized
INFO - 2020-12-10 03:12:31 --> Config Class Initialized
INFO - 2020-12-10 03:12:31 --> Loader Class Initialized
INFO - 2020-12-10 03:12:31 --> Helper loaded: url_helper
INFO - 2020-12-10 03:12:31 --> Helper loaded: file_helper
INFO - 2020-12-10 03:12:31 --> Helper loaded: form_helper
INFO - 2020-12-10 03:12:31 --> Helper loaded: my_helper
INFO - 2020-12-10 03:12:31 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:12:31 --> Controller Class Initialized
DEBUG - 2020-12-10 03:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-10 03:12:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:12:31 --> Final output sent to browser
DEBUG - 2020-12-10 03:12:31 --> Total execution time: 0.0982
INFO - 2020-12-10 03:12:42 --> Config Class Initialized
INFO - 2020-12-10 03:12:42 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:12:42 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:12:42 --> Utf8 Class Initialized
INFO - 2020-12-10 03:12:42 --> URI Class Initialized
INFO - 2020-12-10 03:12:42 --> Router Class Initialized
INFO - 2020-12-10 03:12:42 --> Output Class Initialized
INFO - 2020-12-10 03:12:42 --> Security Class Initialized
DEBUG - 2020-12-10 03:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:12:42 --> Input Class Initialized
INFO - 2020-12-10 03:12:42 --> Language Class Initialized
INFO - 2020-12-10 03:12:42 --> Language Class Initialized
INFO - 2020-12-10 03:12:42 --> Config Class Initialized
INFO - 2020-12-10 03:12:42 --> Loader Class Initialized
INFO - 2020-12-10 03:12:42 --> Helper loaded: url_helper
INFO - 2020-12-10 03:12:42 --> Helper loaded: file_helper
INFO - 2020-12-10 03:12:42 --> Helper loaded: form_helper
INFO - 2020-12-10 03:12:42 --> Helper loaded: my_helper
INFO - 2020-12-10 03:12:42 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:12:42 --> Controller Class Initialized
DEBUG - 2020-12-10 03:12:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-12-10 03:12:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:12:42 --> Final output sent to browser
DEBUG - 2020-12-10 03:12:42 --> Total execution time: 0.0816
INFO - 2020-12-10 03:12:43 --> Config Class Initialized
INFO - 2020-12-10 03:12:43 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:12:43 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:12:43 --> Utf8 Class Initialized
INFO - 2020-12-10 03:12:43 --> URI Class Initialized
INFO - 2020-12-10 03:12:43 --> Router Class Initialized
INFO - 2020-12-10 03:12:43 --> Output Class Initialized
INFO - 2020-12-10 03:12:43 --> Security Class Initialized
DEBUG - 2020-12-10 03:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:12:43 --> Input Class Initialized
INFO - 2020-12-10 03:12:43 --> Language Class Initialized
INFO - 2020-12-10 03:12:43 --> Language Class Initialized
INFO - 2020-12-10 03:12:43 --> Config Class Initialized
INFO - 2020-12-10 03:12:43 --> Loader Class Initialized
INFO - 2020-12-10 03:12:43 --> Helper loaded: url_helper
INFO - 2020-12-10 03:12:43 --> Helper loaded: file_helper
INFO - 2020-12-10 03:12:43 --> Helper loaded: form_helper
INFO - 2020-12-10 03:12:43 --> Helper loaded: my_helper
INFO - 2020-12-10 03:12:43 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:12:43 --> Controller Class Initialized
DEBUG - 2020-12-10 03:12:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-10 03:12:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:12:43 --> Final output sent to browser
DEBUG - 2020-12-10 03:12:43 --> Total execution time: 0.0476
INFO - 2020-12-10 03:12:44 --> Config Class Initialized
INFO - 2020-12-10 03:12:44 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:12:44 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:12:44 --> Utf8 Class Initialized
INFO - 2020-12-10 03:12:44 --> URI Class Initialized
INFO - 2020-12-10 03:12:44 --> Router Class Initialized
INFO - 2020-12-10 03:12:44 --> Output Class Initialized
INFO - 2020-12-10 03:12:44 --> Security Class Initialized
DEBUG - 2020-12-10 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:12:44 --> Input Class Initialized
INFO - 2020-12-10 03:12:44 --> Language Class Initialized
INFO - 2020-12-10 03:12:44 --> Language Class Initialized
INFO - 2020-12-10 03:12:44 --> Config Class Initialized
INFO - 2020-12-10 03:12:44 --> Loader Class Initialized
INFO - 2020-12-10 03:12:44 --> Helper loaded: url_helper
INFO - 2020-12-10 03:12:44 --> Helper loaded: file_helper
INFO - 2020-12-10 03:12:44 --> Helper loaded: form_helper
INFO - 2020-12-10 03:12:44 --> Helper loaded: my_helper
INFO - 2020-12-10 03:12:44 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:12:44 --> Controller Class Initialized
DEBUG - 2020-12-10 03:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-10 03:12:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:12:44 --> Final output sent to browser
DEBUG - 2020-12-10 03:12:44 --> Total execution time: 0.0861
INFO - 2020-12-10 03:12:47 --> Config Class Initialized
INFO - 2020-12-10 03:12:47 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:12:47 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:12:47 --> Utf8 Class Initialized
INFO - 2020-12-10 03:12:47 --> URI Class Initialized
INFO - 2020-12-10 03:12:47 --> Router Class Initialized
INFO - 2020-12-10 03:12:47 --> Output Class Initialized
INFO - 2020-12-10 03:12:47 --> Security Class Initialized
DEBUG - 2020-12-10 03:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:12:47 --> Input Class Initialized
INFO - 2020-12-10 03:12:47 --> Language Class Initialized
INFO - 2020-12-10 03:12:47 --> Language Class Initialized
INFO - 2020-12-10 03:12:47 --> Config Class Initialized
INFO - 2020-12-10 03:12:47 --> Loader Class Initialized
INFO - 2020-12-10 03:12:47 --> Helper loaded: url_helper
INFO - 2020-12-10 03:12:47 --> Helper loaded: file_helper
INFO - 2020-12-10 03:12:47 --> Helper loaded: form_helper
INFO - 2020-12-10 03:12:47 --> Helper loaded: my_helper
INFO - 2020-12-10 03:12:47 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:12:47 --> Controller Class Initialized
DEBUG - 2020-12-10 03:12:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-10 03:12:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:12:47 --> Final output sent to browser
DEBUG - 2020-12-10 03:12:47 --> Total execution time: 0.0451
INFO - 2020-12-10 03:13:44 --> Config Class Initialized
INFO - 2020-12-10 03:13:44 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:13:44 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:13:44 --> Utf8 Class Initialized
INFO - 2020-12-10 03:13:44 --> URI Class Initialized
INFO - 2020-12-10 03:13:44 --> Router Class Initialized
INFO - 2020-12-10 03:13:44 --> Output Class Initialized
INFO - 2020-12-10 03:13:44 --> Security Class Initialized
DEBUG - 2020-12-10 03:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:13:44 --> Input Class Initialized
INFO - 2020-12-10 03:13:44 --> Language Class Initialized
INFO - 2020-12-10 03:13:44 --> Language Class Initialized
INFO - 2020-12-10 03:13:44 --> Config Class Initialized
INFO - 2020-12-10 03:13:44 --> Loader Class Initialized
INFO - 2020-12-10 03:13:44 --> Helper loaded: url_helper
INFO - 2020-12-10 03:13:44 --> Helper loaded: file_helper
INFO - 2020-12-10 03:13:44 --> Helper loaded: form_helper
INFO - 2020-12-10 03:13:44 --> Helper loaded: my_helper
INFO - 2020-12-10 03:13:44 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:13:44 --> Controller Class Initialized
DEBUG - 2020-12-10 03:13:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-12-10 03:13:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:13:44 --> Final output sent to browser
DEBUG - 2020-12-10 03:13:44 --> Total execution time: 0.0472
INFO - 2020-12-10 03:14:09 --> Config Class Initialized
INFO - 2020-12-10 03:14:09 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:14:09 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:14:09 --> Utf8 Class Initialized
INFO - 2020-12-10 03:14:09 --> URI Class Initialized
INFO - 2020-12-10 03:14:09 --> Router Class Initialized
INFO - 2020-12-10 03:14:09 --> Output Class Initialized
INFO - 2020-12-10 03:14:09 --> Security Class Initialized
DEBUG - 2020-12-10 03:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:14:09 --> Input Class Initialized
INFO - 2020-12-10 03:14:09 --> Language Class Initialized
INFO - 2020-12-10 03:14:09 --> Language Class Initialized
INFO - 2020-12-10 03:14:09 --> Config Class Initialized
INFO - 2020-12-10 03:14:09 --> Loader Class Initialized
INFO - 2020-12-10 03:14:09 --> Helper loaded: url_helper
INFO - 2020-12-10 03:14:09 --> Helper loaded: file_helper
INFO - 2020-12-10 03:14:09 --> Helper loaded: form_helper
INFO - 2020-12-10 03:14:09 --> Helper loaded: my_helper
INFO - 2020-12-10 03:14:09 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:14:09 --> Controller Class Initialized
DEBUG - 2020-12-10 03:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-12-10 03:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:14:09 --> Final output sent to browser
DEBUG - 2020-12-10 03:14:09 --> Total execution time: 0.0717
INFO - 2020-12-10 03:14:20 --> Config Class Initialized
INFO - 2020-12-10 03:14:20 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:14:20 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:14:20 --> Utf8 Class Initialized
INFO - 2020-12-10 03:14:20 --> URI Class Initialized
INFO - 2020-12-10 03:14:20 --> Router Class Initialized
INFO - 2020-12-10 03:14:20 --> Output Class Initialized
INFO - 2020-12-10 03:14:20 --> Security Class Initialized
DEBUG - 2020-12-10 03:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:14:20 --> Input Class Initialized
INFO - 2020-12-10 03:14:20 --> Language Class Initialized
INFO - 2020-12-10 03:14:20 --> Language Class Initialized
INFO - 2020-12-10 03:14:20 --> Config Class Initialized
INFO - 2020-12-10 03:14:20 --> Loader Class Initialized
INFO - 2020-12-10 03:14:20 --> Helper loaded: url_helper
INFO - 2020-12-10 03:14:20 --> Helper loaded: file_helper
INFO - 2020-12-10 03:14:20 --> Helper loaded: form_helper
INFO - 2020-12-10 03:14:20 --> Helper loaded: my_helper
INFO - 2020-12-10 03:14:20 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:14:20 --> Controller Class Initialized
INFO - 2020-12-10 03:14:30 --> Config Class Initialized
INFO - 2020-12-10 03:14:30 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:14:30 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:14:30 --> Utf8 Class Initialized
INFO - 2020-12-10 03:14:30 --> URI Class Initialized
INFO - 2020-12-10 03:14:30 --> Router Class Initialized
INFO - 2020-12-10 03:14:30 --> Output Class Initialized
INFO - 2020-12-10 03:14:30 --> Security Class Initialized
DEBUG - 2020-12-10 03:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:14:30 --> Input Class Initialized
INFO - 2020-12-10 03:14:30 --> Language Class Initialized
INFO - 2020-12-10 03:14:30 --> Language Class Initialized
INFO - 2020-12-10 03:14:30 --> Config Class Initialized
INFO - 2020-12-10 03:14:30 --> Loader Class Initialized
INFO - 2020-12-10 03:14:30 --> Helper loaded: url_helper
INFO - 2020-12-10 03:14:30 --> Helper loaded: file_helper
INFO - 2020-12-10 03:14:30 --> Helper loaded: form_helper
INFO - 2020-12-10 03:14:30 --> Helper loaded: my_helper
INFO - 2020-12-10 03:14:30 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:14:30 --> Controller Class Initialized
DEBUG - 2020-12-10 03:14:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-12-10 03:14:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:14:30 --> Final output sent to browser
DEBUG - 2020-12-10 03:14:30 --> Total execution time: 0.1201
INFO - 2020-12-10 03:14:38 --> Config Class Initialized
INFO - 2020-12-10 03:14:38 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:14:38 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:14:38 --> Utf8 Class Initialized
INFO - 2020-12-10 03:14:38 --> URI Class Initialized
INFO - 2020-12-10 03:14:38 --> Router Class Initialized
INFO - 2020-12-10 03:14:38 --> Output Class Initialized
INFO - 2020-12-10 03:14:38 --> Security Class Initialized
DEBUG - 2020-12-10 03:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:14:38 --> Input Class Initialized
INFO - 2020-12-10 03:14:38 --> Language Class Initialized
INFO - 2020-12-10 03:14:38 --> Language Class Initialized
INFO - 2020-12-10 03:14:38 --> Config Class Initialized
INFO - 2020-12-10 03:14:38 --> Loader Class Initialized
INFO - 2020-12-10 03:14:38 --> Helper loaded: url_helper
INFO - 2020-12-10 03:14:38 --> Helper loaded: file_helper
INFO - 2020-12-10 03:14:38 --> Helper loaded: form_helper
INFO - 2020-12-10 03:14:38 --> Helper loaded: my_helper
INFO - 2020-12-10 03:14:38 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:14:38 --> Controller Class Initialized
DEBUG - 2020-12-10 03:14:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2020-12-10 03:14:38 --> Final output sent to browser
DEBUG - 2020-12-10 03:14:38 --> Total execution time: 0.0958
INFO - 2020-12-10 03:15:02 --> Config Class Initialized
INFO - 2020-12-10 03:15:02 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:15:02 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:15:02 --> Utf8 Class Initialized
INFO - 2020-12-10 03:15:02 --> URI Class Initialized
INFO - 2020-12-10 03:15:02 --> Router Class Initialized
INFO - 2020-12-10 03:15:02 --> Output Class Initialized
INFO - 2020-12-10 03:15:02 --> Security Class Initialized
DEBUG - 2020-12-10 03:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:15:02 --> Input Class Initialized
INFO - 2020-12-10 03:15:02 --> Language Class Initialized
INFO - 2020-12-10 03:15:02 --> Language Class Initialized
INFO - 2020-12-10 03:15:02 --> Config Class Initialized
INFO - 2020-12-10 03:15:02 --> Loader Class Initialized
INFO - 2020-12-10 03:15:02 --> Helper loaded: url_helper
INFO - 2020-12-10 03:15:02 --> Helper loaded: file_helper
INFO - 2020-12-10 03:15:02 --> Helper loaded: form_helper
INFO - 2020-12-10 03:15:02 --> Helper loaded: my_helper
INFO - 2020-12-10 03:15:02 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:15:02 --> Controller Class Initialized
DEBUG - 2020-12-10 03:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2020-12-10 03:15:02 --> Final output sent to browser
DEBUG - 2020-12-10 03:15:02 --> Total execution time: 0.0491
INFO - 2020-12-10 03:15:29 --> Config Class Initialized
INFO - 2020-12-10 03:15:29 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:15:29 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:15:29 --> Utf8 Class Initialized
INFO - 2020-12-10 03:15:29 --> URI Class Initialized
INFO - 2020-12-10 03:15:29 --> Router Class Initialized
INFO - 2020-12-10 03:15:29 --> Output Class Initialized
INFO - 2020-12-10 03:15:29 --> Security Class Initialized
DEBUG - 2020-12-10 03:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:15:29 --> Input Class Initialized
INFO - 2020-12-10 03:15:29 --> Language Class Initialized
INFO - 2020-12-10 03:15:29 --> Language Class Initialized
INFO - 2020-12-10 03:15:29 --> Config Class Initialized
INFO - 2020-12-10 03:15:29 --> Loader Class Initialized
INFO - 2020-12-10 03:15:29 --> Helper loaded: url_helper
INFO - 2020-12-10 03:15:29 --> Helper loaded: file_helper
INFO - 2020-12-10 03:15:29 --> Helper loaded: form_helper
INFO - 2020-12-10 03:15:29 --> Helper loaded: my_helper
INFO - 2020-12-10 03:15:29 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:15:29 --> Controller Class Initialized
DEBUG - 2020-12-10 03:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-12-10 03:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:15:29 --> Final output sent to browser
DEBUG - 2020-12-10 03:15:29 --> Total execution time: 0.0364
INFO - 2020-12-10 03:15:40 --> Config Class Initialized
INFO - 2020-12-10 03:15:40 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:15:40 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:15:40 --> Utf8 Class Initialized
INFO - 2020-12-10 03:15:40 --> URI Class Initialized
INFO - 2020-12-10 03:15:40 --> Router Class Initialized
INFO - 2020-12-10 03:15:40 --> Output Class Initialized
INFO - 2020-12-10 03:15:40 --> Security Class Initialized
DEBUG - 2020-12-10 03:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:15:40 --> Input Class Initialized
INFO - 2020-12-10 03:15:40 --> Language Class Initialized
INFO - 2020-12-10 03:15:40 --> Language Class Initialized
INFO - 2020-12-10 03:15:40 --> Config Class Initialized
INFO - 2020-12-10 03:15:40 --> Loader Class Initialized
INFO - 2020-12-10 03:15:40 --> Helper loaded: url_helper
INFO - 2020-12-10 03:15:40 --> Helper loaded: file_helper
INFO - 2020-12-10 03:15:40 --> Helper loaded: form_helper
INFO - 2020-12-10 03:15:40 --> Helper loaded: my_helper
INFO - 2020-12-10 03:15:40 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:15:40 --> Controller Class Initialized
INFO - 2020-12-10 03:15:42 --> Config Class Initialized
INFO - 2020-12-10 03:15:42 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:15:42 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:15:42 --> Utf8 Class Initialized
INFO - 2020-12-10 03:15:42 --> URI Class Initialized
INFO - 2020-12-10 03:15:42 --> Router Class Initialized
INFO - 2020-12-10 03:15:42 --> Output Class Initialized
INFO - 2020-12-10 03:15:42 --> Security Class Initialized
DEBUG - 2020-12-10 03:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:15:42 --> Input Class Initialized
INFO - 2020-12-10 03:15:42 --> Language Class Initialized
INFO - 2020-12-10 03:15:42 --> Language Class Initialized
INFO - 2020-12-10 03:15:42 --> Config Class Initialized
INFO - 2020-12-10 03:15:42 --> Loader Class Initialized
INFO - 2020-12-10 03:15:42 --> Helper loaded: url_helper
INFO - 2020-12-10 03:15:42 --> Helper loaded: file_helper
INFO - 2020-12-10 03:15:42 --> Helper loaded: form_helper
INFO - 2020-12-10 03:15:42 --> Helper loaded: my_helper
INFO - 2020-12-10 03:15:42 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:15:42 --> Controller Class Initialized
DEBUG - 2020-12-10 03:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-10 03:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:15:42 --> Final output sent to browser
DEBUG - 2020-12-10 03:15:42 --> Total execution time: 0.0441
INFO - 2020-12-10 03:15:43 --> Config Class Initialized
INFO - 2020-12-10 03:15:43 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:15:43 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:15:43 --> Utf8 Class Initialized
INFO - 2020-12-10 03:15:43 --> URI Class Initialized
INFO - 2020-12-10 03:15:43 --> Router Class Initialized
INFO - 2020-12-10 03:15:43 --> Output Class Initialized
INFO - 2020-12-10 03:15:43 --> Security Class Initialized
DEBUG - 2020-12-10 03:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:15:43 --> Input Class Initialized
INFO - 2020-12-10 03:15:43 --> Language Class Initialized
INFO - 2020-12-10 03:15:43 --> Language Class Initialized
INFO - 2020-12-10 03:15:43 --> Config Class Initialized
INFO - 2020-12-10 03:15:43 --> Loader Class Initialized
INFO - 2020-12-10 03:15:43 --> Helper loaded: url_helper
INFO - 2020-12-10 03:15:43 --> Helper loaded: file_helper
INFO - 2020-12-10 03:15:43 --> Helper loaded: form_helper
INFO - 2020-12-10 03:15:43 --> Helper loaded: my_helper
INFO - 2020-12-10 03:15:43 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:15:43 --> Controller Class Initialized
DEBUG - 2020-12-10 03:15:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-12-10 03:15:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:15:43 --> Final output sent to browser
DEBUG - 2020-12-10 03:15:43 --> Total execution time: 0.0356
INFO - 2020-12-10 03:15:45 --> Config Class Initialized
INFO - 2020-12-10 03:15:45 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:15:45 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:15:45 --> Utf8 Class Initialized
INFO - 2020-12-10 03:15:45 --> URI Class Initialized
INFO - 2020-12-10 03:15:45 --> Router Class Initialized
INFO - 2020-12-10 03:15:45 --> Output Class Initialized
INFO - 2020-12-10 03:15:45 --> Security Class Initialized
DEBUG - 2020-12-10 03:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:15:45 --> Input Class Initialized
INFO - 2020-12-10 03:15:45 --> Language Class Initialized
INFO - 2020-12-10 03:15:45 --> Language Class Initialized
INFO - 2020-12-10 03:15:45 --> Config Class Initialized
INFO - 2020-12-10 03:15:45 --> Loader Class Initialized
INFO - 2020-12-10 03:15:45 --> Helper loaded: url_helper
INFO - 2020-12-10 03:15:45 --> Helper loaded: file_helper
INFO - 2020-12-10 03:15:45 --> Helper loaded: form_helper
INFO - 2020-12-10 03:15:45 --> Helper loaded: my_helper
INFO - 2020-12-10 03:15:45 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:15:45 --> Controller Class Initialized
DEBUG - 2020-12-10 03:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-10 03:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:15:45 --> Final output sent to browser
DEBUG - 2020-12-10 03:15:45 --> Total execution time: 0.0471
INFO - 2020-12-10 03:39:29 --> Config Class Initialized
INFO - 2020-12-10 03:39:29 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:39:29 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:39:29 --> Utf8 Class Initialized
INFO - 2020-12-10 03:39:29 --> URI Class Initialized
DEBUG - 2020-12-10 03:39:30 --> No URI present. Default controller set.
INFO - 2020-12-10 03:39:30 --> Router Class Initialized
INFO - 2020-12-10 03:39:30 --> Output Class Initialized
INFO - 2020-12-10 03:39:30 --> Security Class Initialized
DEBUG - 2020-12-10 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:39:30 --> Input Class Initialized
INFO - 2020-12-10 03:39:30 --> Language Class Initialized
INFO - 2020-12-10 03:39:30 --> Language Class Initialized
INFO - 2020-12-10 03:39:30 --> Config Class Initialized
INFO - 2020-12-10 03:39:30 --> Loader Class Initialized
INFO - 2020-12-10 03:39:30 --> Helper loaded: url_helper
INFO - 2020-12-10 03:39:30 --> Helper loaded: file_helper
INFO - 2020-12-10 03:39:30 --> Helper loaded: form_helper
INFO - 2020-12-10 03:39:30 --> Helper loaded: my_helper
INFO - 2020-12-10 03:39:30 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:39:30 --> Controller Class Initialized
INFO - 2020-12-10 03:39:30 --> Config Class Initialized
INFO - 2020-12-10 03:39:30 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:39:30 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:39:30 --> Utf8 Class Initialized
INFO - 2020-12-10 03:39:30 --> URI Class Initialized
INFO - 2020-12-10 03:39:30 --> Router Class Initialized
INFO - 2020-12-10 03:39:30 --> Output Class Initialized
INFO - 2020-12-10 03:39:30 --> Security Class Initialized
DEBUG - 2020-12-10 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:39:30 --> Input Class Initialized
INFO - 2020-12-10 03:39:30 --> Language Class Initialized
INFO - 2020-12-10 03:39:30 --> Language Class Initialized
INFO - 2020-12-10 03:39:30 --> Config Class Initialized
INFO - 2020-12-10 03:39:30 --> Loader Class Initialized
INFO - 2020-12-10 03:39:30 --> Helper loaded: url_helper
INFO - 2020-12-10 03:39:30 --> Helper loaded: file_helper
INFO - 2020-12-10 03:39:30 --> Helper loaded: form_helper
INFO - 2020-12-10 03:39:30 --> Helper loaded: my_helper
INFO - 2020-12-10 03:39:30 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:39:30 --> Controller Class Initialized
DEBUG - 2020-12-10 03:39:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 03:39:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:39:30 --> Final output sent to browser
DEBUG - 2020-12-10 03:39:30 --> Total execution time: 0.1157
INFO - 2020-12-10 03:39:37 --> Config Class Initialized
INFO - 2020-12-10 03:39:37 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:39:37 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:39:37 --> Utf8 Class Initialized
INFO - 2020-12-10 03:39:37 --> URI Class Initialized
INFO - 2020-12-10 03:39:37 --> Router Class Initialized
INFO - 2020-12-10 03:39:37 --> Output Class Initialized
INFO - 2020-12-10 03:39:37 --> Security Class Initialized
DEBUG - 2020-12-10 03:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:39:37 --> Input Class Initialized
INFO - 2020-12-10 03:39:37 --> Language Class Initialized
INFO - 2020-12-10 03:39:37 --> Language Class Initialized
INFO - 2020-12-10 03:39:37 --> Config Class Initialized
INFO - 2020-12-10 03:39:37 --> Loader Class Initialized
INFO - 2020-12-10 03:39:37 --> Helper loaded: url_helper
INFO - 2020-12-10 03:39:37 --> Helper loaded: file_helper
INFO - 2020-12-10 03:39:37 --> Helper loaded: form_helper
INFO - 2020-12-10 03:39:37 --> Helper loaded: my_helper
INFO - 2020-12-10 03:39:37 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:39:37 --> Controller Class Initialized
INFO - 2020-12-10 03:39:38 --> Helper loaded: cookie_helper
INFO - 2020-12-10 03:39:38 --> Final output sent to browser
DEBUG - 2020-12-10 03:39:38 --> Total execution time: 0.3168
INFO - 2020-12-10 03:39:39 --> Config Class Initialized
INFO - 2020-12-10 03:39:39 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:39:39 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:39:39 --> Utf8 Class Initialized
INFO - 2020-12-10 03:39:39 --> URI Class Initialized
INFO - 2020-12-10 03:39:39 --> Router Class Initialized
INFO - 2020-12-10 03:39:39 --> Output Class Initialized
INFO - 2020-12-10 03:39:39 --> Security Class Initialized
DEBUG - 2020-12-10 03:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:39:39 --> Input Class Initialized
INFO - 2020-12-10 03:39:39 --> Language Class Initialized
INFO - 2020-12-10 03:39:39 --> Language Class Initialized
INFO - 2020-12-10 03:39:39 --> Config Class Initialized
INFO - 2020-12-10 03:39:39 --> Loader Class Initialized
INFO - 2020-12-10 03:39:39 --> Helper loaded: url_helper
INFO - 2020-12-10 03:39:39 --> Helper loaded: file_helper
INFO - 2020-12-10 03:39:39 --> Helper loaded: form_helper
INFO - 2020-12-10 03:39:39 --> Helper loaded: my_helper
INFO - 2020-12-10 03:39:39 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:39:39 --> Controller Class Initialized
DEBUG - 2020-12-10 03:39:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-10 03:39:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:39:39 --> Final output sent to browser
DEBUG - 2020-12-10 03:39:39 --> Total execution time: 0.2781
INFO - 2020-12-10 03:40:11 --> Config Class Initialized
INFO - 2020-12-10 03:40:11 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:40:11 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:40:11 --> Utf8 Class Initialized
INFO - 2020-12-10 03:40:11 --> URI Class Initialized
INFO - 2020-12-10 03:40:11 --> Router Class Initialized
INFO - 2020-12-10 03:40:11 --> Output Class Initialized
INFO - 2020-12-10 03:40:11 --> Security Class Initialized
DEBUG - 2020-12-10 03:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:40:11 --> Input Class Initialized
INFO - 2020-12-10 03:40:11 --> Language Class Initialized
INFO - 2020-12-10 03:40:11 --> Language Class Initialized
INFO - 2020-12-10 03:40:11 --> Config Class Initialized
INFO - 2020-12-10 03:40:11 --> Loader Class Initialized
INFO - 2020-12-10 03:40:11 --> Helper loaded: url_helper
INFO - 2020-12-10 03:40:11 --> Helper loaded: file_helper
INFO - 2020-12-10 03:40:11 --> Helper loaded: form_helper
INFO - 2020-12-10 03:40:11 --> Helper loaded: my_helper
INFO - 2020-12-10 03:40:11 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:40:11 --> Controller Class Initialized
DEBUG - 2020-12-10 03:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-10 03:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:40:11 --> Final output sent to browser
DEBUG - 2020-12-10 03:40:11 --> Total execution time: 0.1124
INFO - 2020-12-10 03:42:04 --> Config Class Initialized
INFO - 2020-12-10 03:42:04 --> Hooks Class Initialized
DEBUG - 2020-12-10 03:42:04 --> UTF-8 Support Enabled
INFO - 2020-12-10 03:42:04 --> Utf8 Class Initialized
INFO - 2020-12-10 03:42:04 --> URI Class Initialized
INFO - 2020-12-10 03:42:04 --> Router Class Initialized
INFO - 2020-12-10 03:42:04 --> Output Class Initialized
INFO - 2020-12-10 03:42:04 --> Security Class Initialized
DEBUG - 2020-12-10 03:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 03:42:04 --> Input Class Initialized
INFO - 2020-12-10 03:42:04 --> Language Class Initialized
INFO - 2020-12-10 03:42:04 --> Language Class Initialized
INFO - 2020-12-10 03:42:04 --> Config Class Initialized
INFO - 2020-12-10 03:42:04 --> Loader Class Initialized
INFO - 2020-12-10 03:42:04 --> Helper loaded: url_helper
INFO - 2020-12-10 03:42:04 --> Helper loaded: file_helper
INFO - 2020-12-10 03:42:04 --> Helper loaded: form_helper
INFO - 2020-12-10 03:42:04 --> Helper loaded: my_helper
INFO - 2020-12-10 03:42:04 --> Database Driver Class Initialized
DEBUG - 2020-12-10 03:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 03:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 03:42:04 --> Controller Class Initialized
DEBUG - 2020-12-10 03:42:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-10 03:42:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 03:42:04 --> Final output sent to browser
DEBUG - 2020-12-10 03:42:04 --> Total execution time: 0.0500
INFO - 2020-12-10 04:20:05 --> Config Class Initialized
INFO - 2020-12-10 04:20:05 --> Hooks Class Initialized
DEBUG - 2020-12-10 04:20:05 --> UTF-8 Support Enabled
INFO - 2020-12-10 04:20:05 --> Utf8 Class Initialized
INFO - 2020-12-10 04:20:05 --> URI Class Initialized
DEBUG - 2020-12-10 04:20:06 --> No URI present. Default controller set.
INFO - 2020-12-10 04:20:06 --> Router Class Initialized
INFO - 2020-12-10 04:20:06 --> Output Class Initialized
INFO - 2020-12-10 04:20:06 --> Security Class Initialized
DEBUG - 2020-12-10 04:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 04:20:06 --> Input Class Initialized
INFO - 2020-12-10 04:20:06 --> Language Class Initialized
INFO - 2020-12-10 04:20:06 --> Language Class Initialized
INFO - 2020-12-10 04:20:06 --> Config Class Initialized
INFO - 2020-12-10 04:20:06 --> Loader Class Initialized
INFO - 2020-12-10 04:20:06 --> Helper loaded: url_helper
INFO - 2020-12-10 04:20:06 --> Helper loaded: file_helper
INFO - 2020-12-10 04:20:06 --> Helper loaded: form_helper
INFO - 2020-12-10 04:20:06 --> Helper loaded: my_helper
INFO - 2020-12-10 04:20:06 --> Database Driver Class Initialized
DEBUG - 2020-12-10 04:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 04:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 04:20:06 --> Controller Class Initialized
INFO - 2020-12-10 04:20:06 --> Config Class Initialized
INFO - 2020-12-10 04:20:06 --> Hooks Class Initialized
DEBUG - 2020-12-10 04:20:06 --> UTF-8 Support Enabled
INFO - 2020-12-10 04:20:06 --> Utf8 Class Initialized
INFO - 2020-12-10 04:20:06 --> URI Class Initialized
INFO - 2020-12-10 04:20:06 --> Router Class Initialized
INFO - 2020-12-10 04:20:06 --> Output Class Initialized
INFO - 2020-12-10 04:20:06 --> Security Class Initialized
DEBUG - 2020-12-10 04:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 04:20:06 --> Input Class Initialized
INFO - 2020-12-10 04:20:06 --> Language Class Initialized
INFO - 2020-12-10 04:20:07 --> Language Class Initialized
INFO - 2020-12-10 04:20:07 --> Config Class Initialized
INFO - 2020-12-10 04:20:07 --> Loader Class Initialized
INFO - 2020-12-10 04:20:07 --> Helper loaded: url_helper
INFO - 2020-12-10 04:20:07 --> Helper loaded: file_helper
INFO - 2020-12-10 04:20:07 --> Helper loaded: form_helper
INFO - 2020-12-10 04:20:07 --> Helper loaded: my_helper
INFO - 2020-12-10 04:20:07 --> Database Driver Class Initialized
DEBUG - 2020-12-10 04:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 04:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 04:20:07 --> Controller Class Initialized
DEBUG - 2020-12-10 04:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-10 04:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 04:20:07 --> Final output sent to browser
DEBUG - 2020-12-10 04:20:07 --> Total execution time: 0.1294
INFO - 2020-12-10 08:29:31 --> Config Class Initialized
INFO - 2020-12-10 08:29:31 --> Hooks Class Initialized
DEBUG - 2020-12-10 08:29:31 --> UTF-8 Support Enabled
INFO - 2020-12-10 08:29:31 --> Utf8 Class Initialized
INFO - 2020-12-10 08:29:31 --> URI Class Initialized
INFO - 2020-12-10 08:29:31 --> Router Class Initialized
INFO - 2020-12-10 08:29:31 --> Output Class Initialized
INFO - 2020-12-10 08:29:31 --> Security Class Initialized
DEBUG - 2020-12-10 08:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 08:29:31 --> Input Class Initialized
INFO - 2020-12-10 08:29:31 --> Language Class Initialized
INFO - 2020-12-10 08:29:31 --> Language Class Initialized
INFO - 2020-12-10 08:29:31 --> Config Class Initialized
INFO - 2020-12-10 08:29:31 --> Loader Class Initialized
INFO - 2020-12-10 08:29:31 --> Helper loaded: url_helper
INFO - 2020-12-10 08:29:31 --> Helper loaded: file_helper
INFO - 2020-12-10 08:29:31 --> Helper loaded: form_helper
INFO - 2020-12-10 08:29:31 --> Helper loaded: my_helper
INFO - 2020-12-10 08:29:31 --> Database Driver Class Initialized
DEBUG - 2020-12-10 08:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 08:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 08:29:31 --> Controller Class Initialized
INFO - 2020-12-10 08:29:31 --> Helper loaded: cookie_helper
INFO - 2020-12-10 08:29:31 --> Final output sent to browser
DEBUG - 2020-12-10 08:29:31 --> Total execution time: 0.2837
INFO - 2020-12-10 08:29:32 --> Config Class Initialized
INFO - 2020-12-10 08:29:32 --> Hooks Class Initialized
DEBUG - 2020-12-10 08:29:32 --> UTF-8 Support Enabled
INFO - 2020-12-10 08:29:32 --> Utf8 Class Initialized
INFO - 2020-12-10 08:29:32 --> URI Class Initialized
INFO - 2020-12-10 08:29:32 --> Router Class Initialized
INFO - 2020-12-10 08:29:32 --> Output Class Initialized
INFO - 2020-12-10 08:29:32 --> Security Class Initialized
DEBUG - 2020-12-10 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 08:29:32 --> Input Class Initialized
INFO - 2020-12-10 08:29:32 --> Language Class Initialized
INFO - 2020-12-10 08:29:32 --> Language Class Initialized
INFO - 2020-12-10 08:29:32 --> Config Class Initialized
INFO - 2020-12-10 08:29:32 --> Loader Class Initialized
INFO - 2020-12-10 08:29:32 --> Helper loaded: url_helper
INFO - 2020-12-10 08:29:32 --> Helper loaded: file_helper
INFO - 2020-12-10 08:29:32 --> Helper loaded: form_helper
INFO - 2020-12-10 08:29:32 --> Helper loaded: my_helper
INFO - 2020-12-10 08:29:32 --> Database Driver Class Initialized
DEBUG - 2020-12-10 08:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 08:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 08:29:32 --> Controller Class Initialized
DEBUG - 2020-12-10 08:29:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-10 08:29:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 08:29:32 --> Final output sent to browser
DEBUG - 2020-12-10 08:29:32 --> Total execution time: 0.0947
INFO - 2020-12-10 08:29:34 --> Config Class Initialized
INFO - 2020-12-10 08:29:34 --> Hooks Class Initialized
DEBUG - 2020-12-10 08:29:34 --> UTF-8 Support Enabled
INFO - 2020-12-10 08:29:34 --> Utf8 Class Initialized
INFO - 2020-12-10 08:29:34 --> URI Class Initialized
INFO - 2020-12-10 08:29:34 --> Router Class Initialized
INFO - 2020-12-10 08:29:34 --> Output Class Initialized
INFO - 2020-12-10 08:29:34 --> Security Class Initialized
DEBUG - 2020-12-10 08:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 08:29:34 --> Input Class Initialized
INFO - 2020-12-10 08:29:34 --> Language Class Initialized
INFO - 2020-12-10 08:29:34 --> Language Class Initialized
INFO - 2020-12-10 08:29:34 --> Config Class Initialized
INFO - 2020-12-10 08:29:34 --> Loader Class Initialized
INFO - 2020-12-10 08:29:34 --> Helper loaded: url_helper
INFO - 2020-12-10 08:29:34 --> Helper loaded: file_helper
INFO - 2020-12-10 08:29:34 --> Helper loaded: form_helper
INFO - 2020-12-10 08:29:34 --> Helper loaded: my_helper
INFO - 2020-12-10 08:29:34 --> Database Driver Class Initialized
DEBUG - 2020-12-10 08:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 08:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 08:29:34 --> Controller Class Initialized
DEBUG - 2020-12-10 08:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-10 08:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-10 08:29:35 --> Final output sent to browser
DEBUG - 2020-12-10 08:29:35 --> Total execution time: 0.0876
INFO - 2020-12-10 08:29:36 --> Config Class Initialized
INFO - 2020-12-10 08:29:36 --> Hooks Class Initialized
DEBUG - 2020-12-10 08:29:36 --> UTF-8 Support Enabled
INFO - 2020-12-10 08:29:36 --> Utf8 Class Initialized
INFO - 2020-12-10 08:29:36 --> URI Class Initialized
INFO - 2020-12-10 08:29:36 --> Router Class Initialized
INFO - 2020-12-10 08:29:36 --> Output Class Initialized
INFO - 2020-12-10 08:29:36 --> Security Class Initialized
DEBUG - 2020-12-10 08:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 08:29:36 --> Input Class Initialized
INFO - 2020-12-10 08:29:36 --> Language Class Initialized
INFO - 2020-12-10 08:29:36 --> Language Class Initialized
INFO - 2020-12-10 08:29:36 --> Config Class Initialized
INFO - 2020-12-10 08:29:36 --> Loader Class Initialized
INFO - 2020-12-10 08:29:36 --> Helper loaded: url_helper
INFO - 2020-12-10 08:29:36 --> Helper loaded: file_helper
INFO - 2020-12-10 08:29:36 --> Helper loaded: form_helper
INFO - 2020-12-10 08:29:36 --> Helper loaded: my_helper
INFO - 2020-12-10 08:29:36 --> Database Driver Class Initialized
DEBUG - 2020-12-10 08:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-10 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 08:29:36 --> Controller Class Initialized
DEBUG - 2020-12-10 08:29:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-12-10 08:29:36 --> Final output sent to browser
DEBUG - 2020-12-10 08:29:36 --> Total execution time: 0.1704
