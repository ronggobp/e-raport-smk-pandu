<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-03 01:44:41 --> Config Class Initialized
INFO - 2020-12-03 01:44:41 --> Hooks Class Initialized
DEBUG - 2020-12-03 01:44:41 --> UTF-8 Support Enabled
INFO - 2020-12-03 01:44:41 --> Utf8 Class Initialized
INFO - 2020-12-03 01:44:41 --> URI Class Initialized
DEBUG - 2020-12-03 01:44:41 --> No URI present. Default controller set.
INFO - 2020-12-03 01:44:41 --> Router Class Initialized
INFO - 2020-12-03 01:44:42 --> Output Class Initialized
INFO - 2020-12-03 01:44:42 --> Security Class Initialized
DEBUG - 2020-12-03 01:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 01:44:42 --> Input Class Initialized
INFO - 2020-12-03 01:44:42 --> Language Class Initialized
INFO - 2020-12-03 01:44:42 --> Language Class Initialized
INFO - 2020-12-03 01:44:42 --> Config Class Initialized
INFO - 2020-12-03 01:44:42 --> Loader Class Initialized
INFO - 2020-12-03 01:44:42 --> Helper loaded: url_helper
INFO - 2020-12-03 01:44:42 --> Helper loaded: file_helper
INFO - 2020-12-03 01:44:42 --> Helper loaded: form_helper
INFO - 2020-12-03 01:44:42 --> Helper loaded: my_helper
INFO - 2020-12-03 01:44:42 --> Database Driver Class Initialized
DEBUG - 2020-12-03 01:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 01:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 01:44:42 --> Controller Class Initialized
INFO - 2020-12-03 01:44:42 --> Config Class Initialized
INFO - 2020-12-03 01:44:42 --> Hooks Class Initialized
DEBUG - 2020-12-03 01:44:42 --> UTF-8 Support Enabled
INFO - 2020-12-03 01:44:42 --> Utf8 Class Initialized
INFO - 2020-12-03 01:44:42 --> URI Class Initialized
INFO - 2020-12-03 01:44:42 --> Router Class Initialized
INFO - 2020-12-03 01:44:42 --> Output Class Initialized
INFO - 2020-12-03 01:44:42 --> Security Class Initialized
DEBUG - 2020-12-03 01:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 01:44:43 --> Input Class Initialized
INFO - 2020-12-03 01:44:43 --> Language Class Initialized
INFO - 2020-12-03 01:44:43 --> Language Class Initialized
INFO - 2020-12-03 01:44:43 --> Config Class Initialized
INFO - 2020-12-03 01:44:43 --> Loader Class Initialized
INFO - 2020-12-03 01:44:43 --> Helper loaded: url_helper
INFO - 2020-12-03 01:44:43 --> Helper loaded: file_helper
INFO - 2020-12-03 01:44:43 --> Helper loaded: form_helper
INFO - 2020-12-03 01:44:43 --> Helper loaded: my_helper
INFO - 2020-12-03 01:44:43 --> Database Driver Class Initialized
DEBUG - 2020-12-03 01:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 01:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 01:44:43 --> Controller Class Initialized
DEBUG - 2020-12-03 01:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-03 01:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 01:44:43 --> Final output sent to browser
DEBUG - 2020-12-03 01:44:43 --> Total execution time: 0.4016
INFO - 2020-12-03 02:43:52 --> Config Class Initialized
INFO - 2020-12-03 02:43:52 --> Hooks Class Initialized
DEBUG - 2020-12-03 02:43:52 --> UTF-8 Support Enabled
INFO - 2020-12-03 02:43:52 --> Utf8 Class Initialized
INFO - 2020-12-03 02:43:52 --> URI Class Initialized
INFO - 2020-12-03 02:43:52 --> Router Class Initialized
INFO - 2020-12-03 02:43:52 --> Output Class Initialized
INFO - 2020-12-03 02:43:52 --> Security Class Initialized
DEBUG - 2020-12-03 02:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 02:43:52 --> Input Class Initialized
INFO - 2020-12-03 02:43:52 --> Language Class Initialized
INFO - 2020-12-03 02:43:52 --> Language Class Initialized
INFO - 2020-12-03 02:43:52 --> Config Class Initialized
INFO - 2020-12-03 02:43:52 --> Loader Class Initialized
INFO - 2020-12-03 02:43:52 --> Helper loaded: url_helper
INFO - 2020-12-03 02:43:52 --> Helper loaded: file_helper
INFO - 2020-12-03 02:43:52 --> Helper loaded: form_helper
INFO - 2020-12-03 02:43:52 --> Helper loaded: my_helper
INFO - 2020-12-03 02:43:52 --> Database Driver Class Initialized
DEBUG - 2020-12-03 02:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 02:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 02:43:52 --> Controller Class Initialized
INFO - 2020-12-03 02:43:53 --> Helper loaded: cookie_helper
INFO - 2020-12-03 02:43:53 --> Final output sent to browser
DEBUG - 2020-12-03 02:43:53 --> Total execution time: 0.4199
INFO - 2020-12-03 02:43:55 --> Config Class Initialized
INFO - 2020-12-03 02:43:55 --> Hooks Class Initialized
DEBUG - 2020-12-03 02:43:55 --> UTF-8 Support Enabled
INFO - 2020-12-03 02:43:55 --> Utf8 Class Initialized
INFO - 2020-12-03 02:43:55 --> URI Class Initialized
INFO - 2020-12-03 02:43:55 --> Router Class Initialized
INFO - 2020-12-03 02:43:55 --> Output Class Initialized
INFO - 2020-12-03 02:43:55 --> Security Class Initialized
DEBUG - 2020-12-03 02:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 02:43:55 --> Input Class Initialized
INFO - 2020-12-03 02:43:55 --> Language Class Initialized
INFO - 2020-12-03 02:43:55 --> Language Class Initialized
INFO - 2020-12-03 02:43:55 --> Config Class Initialized
INFO - 2020-12-03 02:43:55 --> Loader Class Initialized
INFO - 2020-12-03 02:43:55 --> Helper loaded: url_helper
INFO - 2020-12-03 02:43:55 --> Helper loaded: file_helper
INFO - 2020-12-03 02:43:55 --> Helper loaded: form_helper
INFO - 2020-12-03 02:43:55 --> Helper loaded: my_helper
INFO - 2020-12-03 02:43:55 --> Database Driver Class Initialized
DEBUG - 2020-12-03 02:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 02:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 02:43:55 --> Controller Class Initialized
DEBUG - 2020-12-03 02:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-03 02:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 02:43:55 --> Final output sent to browser
DEBUG - 2020-12-03 02:43:55 --> Total execution time: 0.3445
INFO - 2020-12-03 02:44:51 --> Config Class Initialized
INFO - 2020-12-03 02:44:51 --> Hooks Class Initialized
DEBUG - 2020-12-03 02:44:51 --> UTF-8 Support Enabled
INFO - 2020-12-03 02:44:51 --> Utf8 Class Initialized
INFO - 2020-12-03 02:44:51 --> URI Class Initialized
INFO - 2020-12-03 02:44:51 --> Router Class Initialized
INFO - 2020-12-03 02:44:51 --> Output Class Initialized
INFO - 2020-12-03 02:44:51 --> Security Class Initialized
DEBUG - 2020-12-03 02:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 02:44:51 --> Input Class Initialized
INFO - 2020-12-03 02:44:51 --> Language Class Initialized
INFO - 2020-12-03 02:44:51 --> Language Class Initialized
INFO - 2020-12-03 02:44:51 --> Config Class Initialized
INFO - 2020-12-03 02:44:51 --> Loader Class Initialized
INFO - 2020-12-03 02:44:51 --> Helper loaded: url_helper
INFO - 2020-12-03 02:44:51 --> Helper loaded: file_helper
INFO - 2020-12-03 02:44:51 --> Helper loaded: form_helper
INFO - 2020-12-03 02:44:51 --> Helper loaded: my_helper
INFO - 2020-12-03 02:44:51 --> Database Driver Class Initialized
DEBUG - 2020-12-03 02:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 02:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 02:44:51 --> Controller Class Initialized
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 02:44:51 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
DEBUG - 2020-12-03 02:44:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 02:44:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 02:44:51 --> Final output sent to browser
DEBUG - 2020-12-03 02:44:51 --> Total execution time: 0.6313
INFO - 2020-12-03 03:59:20 --> Config Class Initialized
INFO - 2020-12-03 03:59:20 --> Hooks Class Initialized
DEBUG - 2020-12-03 03:59:20 --> UTF-8 Support Enabled
INFO - 2020-12-03 03:59:20 --> Utf8 Class Initialized
INFO - 2020-12-03 03:59:20 --> URI Class Initialized
INFO - 2020-12-03 03:59:20 --> Router Class Initialized
INFO - 2020-12-03 03:59:20 --> Output Class Initialized
INFO - 2020-12-03 03:59:20 --> Security Class Initialized
DEBUG - 2020-12-03 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 03:59:20 --> Input Class Initialized
INFO - 2020-12-03 03:59:20 --> Language Class Initialized
INFO - 2020-12-03 03:59:20 --> Language Class Initialized
INFO - 2020-12-03 03:59:20 --> Config Class Initialized
INFO - 2020-12-03 03:59:20 --> Loader Class Initialized
INFO - 2020-12-03 03:59:20 --> Helper loaded: url_helper
INFO - 2020-12-03 03:59:20 --> Helper loaded: file_helper
INFO - 2020-12-03 03:59:20 --> Helper loaded: form_helper
INFO - 2020-12-03 03:59:20 --> Helper loaded: my_helper
INFO - 2020-12-03 03:59:20 --> Database Driver Class Initialized
DEBUG - 2020-12-03 03:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 03:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 03:59:20 --> Controller Class Initialized
DEBUG - 2020-12-03 03:59:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-03 03:59:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 03:59:20 --> Final output sent to browser
DEBUG - 2020-12-03 03:59:20 --> Total execution time: 0.2230
INFO - 2020-12-03 03:59:22 --> Config Class Initialized
INFO - 2020-12-03 03:59:22 --> Hooks Class Initialized
DEBUG - 2020-12-03 03:59:22 --> UTF-8 Support Enabled
INFO - 2020-12-03 03:59:22 --> Utf8 Class Initialized
INFO - 2020-12-03 03:59:22 --> URI Class Initialized
INFO - 2020-12-03 03:59:22 --> Router Class Initialized
INFO - 2020-12-03 03:59:22 --> Output Class Initialized
INFO - 2020-12-03 03:59:22 --> Security Class Initialized
DEBUG - 2020-12-03 03:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 03:59:22 --> Input Class Initialized
INFO - 2020-12-03 03:59:22 --> Language Class Initialized
INFO - 2020-12-03 03:59:22 --> Language Class Initialized
INFO - 2020-12-03 03:59:22 --> Config Class Initialized
INFO - 2020-12-03 03:59:22 --> Loader Class Initialized
INFO - 2020-12-03 03:59:22 --> Helper loaded: url_helper
INFO - 2020-12-03 03:59:22 --> Helper loaded: file_helper
INFO - 2020-12-03 03:59:22 --> Helper loaded: form_helper
INFO - 2020-12-03 03:59:22 --> Helper loaded: my_helper
INFO - 2020-12-03 03:59:22 --> Database Driver Class Initialized
DEBUG - 2020-12-03 03:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 03:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 03:59:22 --> Controller Class Initialized
INFO - 2020-12-03 03:59:22 --> Final output sent to browser
DEBUG - 2020-12-03 03:59:22 --> Total execution time: 0.1686
INFO - 2020-12-03 03:59:22 --> Config Class Initialized
INFO - 2020-12-03 03:59:22 --> Hooks Class Initialized
DEBUG - 2020-12-03 03:59:22 --> UTF-8 Support Enabled
INFO - 2020-12-03 03:59:22 --> Utf8 Class Initialized
INFO - 2020-12-03 03:59:22 --> URI Class Initialized
INFO - 2020-12-03 03:59:22 --> Router Class Initialized
INFO - 2020-12-03 03:59:22 --> Output Class Initialized
INFO - 2020-12-03 03:59:22 --> Security Class Initialized
DEBUG - 2020-12-03 03:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 03:59:22 --> Input Class Initialized
INFO - 2020-12-03 03:59:22 --> Language Class Initialized
INFO - 2020-12-03 03:59:22 --> Language Class Initialized
INFO - 2020-12-03 03:59:22 --> Config Class Initialized
INFO - 2020-12-03 03:59:22 --> Loader Class Initialized
INFO - 2020-12-03 03:59:22 --> Helper loaded: url_helper
INFO - 2020-12-03 03:59:22 --> Helper loaded: file_helper
INFO - 2020-12-03 03:59:22 --> Helper loaded: form_helper
INFO - 2020-12-03 03:59:22 --> Helper loaded: my_helper
INFO - 2020-12-03 03:59:22 --> Database Driver Class Initialized
DEBUG - 2020-12-03 03:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 03:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 03:59:22 --> Controller Class Initialized
INFO - 2020-12-03 03:59:22 --> Final output sent to browser
DEBUG - 2020-12-03 03:59:22 --> Total execution time: 0.1554
INFO - 2020-12-03 03:59:27 --> Config Class Initialized
INFO - 2020-12-03 03:59:27 --> Hooks Class Initialized
DEBUG - 2020-12-03 03:59:28 --> UTF-8 Support Enabled
INFO - 2020-12-03 03:59:28 --> Utf8 Class Initialized
INFO - 2020-12-03 03:59:28 --> URI Class Initialized
INFO - 2020-12-03 03:59:28 --> Router Class Initialized
INFO - 2020-12-03 03:59:28 --> Output Class Initialized
INFO - 2020-12-03 03:59:28 --> Security Class Initialized
DEBUG - 2020-12-03 03:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 03:59:28 --> Input Class Initialized
INFO - 2020-12-03 03:59:28 --> Language Class Initialized
INFO - 2020-12-03 03:59:28 --> Language Class Initialized
INFO - 2020-12-03 03:59:28 --> Config Class Initialized
INFO - 2020-12-03 03:59:28 --> Loader Class Initialized
INFO - 2020-12-03 03:59:28 --> Helper loaded: url_helper
INFO - 2020-12-03 03:59:28 --> Helper loaded: file_helper
INFO - 2020-12-03 03:59:28 --> Helper loaded: form_helper
INFO - 2020-12-03 03:59:28 --> Helper loaded: my_helper
INFO - 2020-12-03 03:59:28 --> Database Driver Class Initialized
DEBUG - 2020-12-03 03:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 03:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 03:59:28 --> Controller Class Initialized
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 03:59:28 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
DEBUG - 2020-12-03 03:59:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 03:59:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 03:59:28 --> Final output sent to browser
DEBUG - 2020-12-03 03:59:28 --> Total execution time: 0.4697
INFO - 2020-12-03 03:59:34 --> Config Class Initialized
INFO - 2020-12-03 03:59:34 --> Hooks Class Initialized
DEBUG - 2020-12-03 03:59:34 --> UTF-8 Support Enabled
INFO - 2020-12-03 03:59:34 --> Utf8 Class Initialized
INFO - 2020-12-03 03:59:34 --> URI Class Initialized
INFO - 2020-12-03 03:59:34 --> Router Class Initialized
INFO - 2020-12-03 03:59:34 --> Output Class Initialized
INFO - 2020-12-03 03:59:34 --> Security Class Initialized
DEBUG - 2020-12-03 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 03:59:34 --> Input Class Initialized
INFO - 2020-12-03 03:59:34 --> Language Class Initialized
INFO - 2020-12-03 03:59:34 --> Language Class Initialized
INFO - 2020-12-03 03:59:34 --> Config Class Initialized
INFO - 2020-12-03 03:59:34 --> Loader Class Initialized
INFO - 2020-12-03 03:59:34 --> Helper loaded: url_helper
INFO - 2020-12-03 03:59:34 --> Helper loaded: file_helper
INFO - 2020-12-03 03:59:34 --> Helper loaded: form_helper
INFO - 2020-12-03 03:59:34 --> Helper loaded: my_helper
INFO - 2020-12-03 03:59:34 --> Database Driver Class Initialized
DEBUG - 2020-12-03 03:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 03:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 03:59:35 --> Controller Class Initialized
DEBUG - 2020-12-03 03:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-03 03:59:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 03:59:35 --> Final output sent to browser
DEBUG - 2020-12-03 03:59:35 --> Total execution time: 0.1812
INFO - 2020-12-03 03:59:36 --> Config Class Initialized
INFO - 2020-12-03 03:59:36 --> Hooks Class Initialized
DEBUG - 2020-12-03 03:59:36 --> UTF-8 Support Enabled
INFO - 2020-12-03 03:59:36 --> Utf8 Class Initialized
INFO - 2020-12-03 03:59:36 --> URI Class Initialized
INFO - 2020-12-03 03:59:36 --> Router Class Initialized
INFO - 2020-12-03 03:59:36 --> Output Class Initialized
INFO - 2020-12-03 03:59:36 --> Security Class Initialized
DEBUG - 2020-12-03 03:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 03:59:36 --> Input Class Initialized
INFO - 2020-12-03 03:59:36 --> Language Class Initialized
INFO - 2020-12-03 03:59:36 --> Language Class Initialized
INFO - 2020-12-03 03:59:36 --> Config Class Initialized
INFO - 2020-12-03 03:59:36 --> Loader Class Initialized
INFO - 2020-12-03 03:59:36 --> Helper loaded: url_helper
INFO - 2020-12-03 03:59:36 --> Helper loaded: file_helper
INFO - 2020-12-03 03:59:36 --> Helper loaded: form_helper
INFO - 2020-12-03 03:59:36 --> Helper loaded: my_helper
INFO - 2020-12-03 03:59:36 --> Database Driver Class Initialized
DEBUG - 2020-12-03 03:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 03:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 03:59:36 --> Controller Class Initialized
INFO - 2020-12-03 03:59:36 --> Final output sent to browser
DEBUG - 2020-12-03 03:59:36 --> Total execution time: 0.1561
INFO - 2020-12-03 04:50:45 --> Config Class Initialized
INFO - 2020-12-03 04:50:45 --> Hooks Class Initialized
DEBUG - 2020-12-03 04:50:45 --> UTF-8 Support Enabled
INFO - 2020-12-03 04:50:45 --> Utf8 Class Initialized
INFO - 2020-12-03 04:50:45 --> URI Class Initialized
INFO - 2020-12-03 04:50:45 --> Router Class Initialized
INFO - 2020-12-03 04:50:45 --> Output Class Initialized
INFO - 2020-12-03 04:50:45 --> Security Class Initialized
DEBUG - 2020-12-03 04:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 04:50:45 --> Input Class Initialized
INFO - 2020-12-03 04:50:45 --> Language Class Initialized
INFO - 2020-12-03 04:50:45 --> Language Class Initialized
INFO - 2020-12-03 04:50:45 --> Config Class Initialized
INFO - 2020-12-03 04:50:45 --> Loader Class Initialized
INFO - 2020-12-03 04:50:45 --> Helper loaded: url_helper
INFO - 2020-12-03 04:50:45 --> Helper loaded: file_helper
INFO - 2020-12-03 04:50:45 --> Helper loaded: form_helper
INFO - 2020-12-03 04:50:45 --> Helper loaded: my_helper
INFO - 2020-12-03 04:50:45 --> Database Driver Class Initialized
DEBUG - 2020-12-03 04:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 04:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 04:50:45 --> Controller Class Initialized
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 04:50:45 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
DEBUG - 2020-12-03 04:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 04:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 04:50:45 --> Final output sent to browser
DEBUG - 2020-12-03 04:50:45 --> Total execution time: 0.4128
INFO - 2020-12-03 09:08:18 --> Config Class Initialized
INFO - 2020-12-03 09:08:18 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:08:18 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:08:18 --> Utf8 Class Initialized
INFO - 2020-12-03 09:08:18 --> URI Class Initialized
INFO - 2020-12-03 09:08:18 --> Router Class Initialized
INFO - 2020-12-03 09:08:18 --> Output Class Initialized
INFO - 2020-12-03 09:08:18 --> Security Class Initialized
DEBUG - 2020-12-03 09:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:08:18 --> Input Class Initialized
INFO - 2020-12-03 09:08:18 --> Language Class Initialized
INFO - 2020-12-03 09:08:18 --> Language Class Initialized
INFO - 2020-12-03 09:08:18 --> Config Class Initialized
INFO - 2020-12-03 09:08:18 --> Loader Class Initialized
INFO - 2020-12-03 09:08:18 --> Helper loaded: url_helper
INFO - 2020-12-03 09:08:19 --> Helper loaded: file_helper
INFO - 2020-12-03 09:08:19 --> Helper loaded: form_helper
INFO - 2020-12-03 09:08:19 --> Helper loaded: my_helper
INFO - 2020-12-03 09:08:19 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:08:19 --> Controller Class Initialized
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-03 09:08:19 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
DEBUG - 2020-12-03 09:08:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 09:08:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 09:08:19 --> Final output sent to browser
DEBUG - 2020-12-03 09:08:19 --> Total execution time: 0.4336
INFO - 2020-12-03 09:15:08 --> Config Class Initialized
INFO - 2020-12-03 09:15:08 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:15:08 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:15:08 --> Utf8 Class Initialized
INFO - 2020-12-03 09:15:08 --> URI Class Initialized
INFO - 2020-12-03 09:15:08 --> Router Class Initialized
INFO - 2020-12-03 09:15:08 --> Output Class Initialized
INFO - 2020-12-03 09:15:08 --> Security Class Initialized
DEBUG - 2020-12-03 09:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:15:08 --> Input Class Initialized
INFO - 2020-12-03 09:15:08 --> Language Class Initialized
INFO - 2020-12-03 09:15:08 --> Language Class Initialized
INFO - 2020-12-03 09:15:08 --> Config Class Initialized
INFO - 2020-12-03 09:15:08 --> Loader Class Initialized
INFO - 2020-12-03 09:15:08 --> Helper loaded: url_helper
INFO - 2020-12-03 09:15:08 --> Helper loaded: file_helper
INFO - 2020-12-03 09:15:08 --> Helper loaded: form_helper
INFO - 2020-12-03 09:15:08 --> Helper loaded: my_helper
INFO - 2020-12-03 09:15:08 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:15:08 --> Controller Class Initialized
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:15:09 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-03 09:15:09 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-03 09:15:09 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 97
ERROR - 2020-12-03 09:15:09 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 113
DEBUG - 2020-12-03 09:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 09:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 09:15:09 --> Final output sent to browser
DEBUG - 2020-12-03 09:15:09 --> Total execution time: 0.5108
INFO - 2020-12-03 09:17:31 --> Config Class Initialized
INFO - 2020-12-03 09:17:31 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:17:31 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:17:31 --> Utf8 Class Initialized
INFO - 2020-12-03 09:17:31 --> URI Class Initialized
INFO - 2020-12-03 09:17:31 --> Router Class Initialized
INFO - 2020-12-03 09:17:31 --> Output Class Initialized
INFO - 2020-12-03 09:17:31 --> Security Class Initialized
DEBUG - 2020-12-03 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:17:31 --> Input Class Initialized
INFO - 2020-12-03 09:17:31 --> Language Class Initialized
INFO - 2020-12-03 09:17:31 --> Language Class Initialized
INFO - 2020-12-03 09:17:31 --> Config Class Initialized
INFO - 2020-12-03 09:17:31 --> Loader Class Initialized
INFO - 2020-12-03 09:17:31 --> Helper loaded: url_helper
INFO - 2020-12-03 09:17:31 --> Helper loaded: file_helper
INFO - 2020-12-03 09:17:31 --> Helper loaded: form_helper
INFO - 2020-12-03 09:17:31 --> Helper loaded: my_helper
INFO - 2020-12-03 09:17:31 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:17:31 --> Controller Class Initialized
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:17:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
DEBUG - 2020-12-03 09:17:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 09:17:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 09:17:32 --> Final output sent to browser
DEBUG - 2020-12-03 09:17:32 --> Total execution time: 0.4745
INFO - 2020-12-03 09:17:49 --> Config Class Initialized
INFO - 2020-12-03 09:17:49 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:17:49 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:17:49 --> Utf8 Class Initialized
INFO - 2020-12-03 09:17:49 --> URI Class Initialized
INFO - 2020-12-03 09:17:49 --> Router Class Initialized
INFO - 2020-12-03 09:17:49 --> Output Class Initialized
INFO - 2020-12-03 09:17:49 --> Security Class Initialized
DEBUG - 2020-12-03 09:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:17:49 --> Input Class Initialized
INFO - 2020-12-03 09:17:49 --> Language Class Initialized
INFO - 2020-12-03 09:17:49 --> Language Class Initialized
INFO - 2020-12-03 09:17:49 --> Config Class Initialized
INFO - 2020-12-03 09:17:49 --> Loader Class Initialized
INFO - 2020-12-03 09:17:49 --> Helper loaded: url_helper
INFO - 2020-12-03 09:17:49 --> Helper loaded: file_helper
INFO - 2020-12-03 09:17:49 --> Helper loaded: form_helper
INFO - 2020-12-03 09:17:49 --> Helper loaded: my_helper
INFO - 2020-12-03 09:17:49 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:17:49 --> Controller Class Initialized
DEBUG - 2020-12-03 09:17:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 09:17:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 09:17:49 --> Final output sent to browser
DEBUG - 2020-12-03 09:17:49 --> Total execution time: 0.2050
INFO - 2020-12-03 09:47:30 --> Config Class Initialized
INFO - 2020-12-03 09:47:30 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:47:30 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:47:30 --> Utf8 Class Initialized
INFO - 2020-12-03 09:47:30 --> URI Class Initialized
INFO - 2020-12-03 09:47:30 --> Router Class Initialized
INFO - 2020-12-03 09:47:30 --> Output Class Initialized
INFO - 2020-12-03 09:47:30 --> Security Class Initialized
DEBUG - 2020-12-03 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:47:30 --> Input Class Initialized
INFO - 2020-12-03 09:47:30 --> Language Class Initialized
INFO - 2020-12-03 09:47:30 --> Language Class Initialized
INFO - 2020-12-03 09:47:30 --> Config Class Initialized
INFO - 2020-12-03 09:47:30 --> Loader Class Initialized
INFO - 2020-12-03 09:47:30 --> Helper loaded: url_helper
INFO - 2020-12-03 09:47:30 --> Helper loaded: file_helper
INFO - 2020-12-03 09:47:30 --> Helper loaded: form_helper
INFO - 2020-12-03 09:47:30 --> Helper loaded: my_helper
INFO - 2020-12-03 09:47:30 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:47:30 --> Controller Class Initialized
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:30 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 97
ERROR - 2020-12-03 09:47:31 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 113
DEBUG - 2020-12-03 09:47:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 09:47:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 09:47:31 --> Final output sent to browser
DEBUG - 2020-12-03 09:47:31 --> Total execution time: 0.4726
INFO - 2020-12-03 09:48:04 --> Config Class Initialized
INFO - 2020-12-03 09:48:04 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:48:04 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:48:04 --> Utf8 Class Initialized
INFO - 2020-12-03 09:48:04 --> URI Class Initialized
INFO - 2020-12-03 09:48:04 --> Router Class Initialized
INFO - 2020-12-03 09:48:04 --> Output Class Initialized
INFO - 2020-12-03 09:48:04 --> Security Class Initialized
DEBUG - 2020-12-03 09:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:48:04 --> Input Class Initialized
INFO - 2020-12-03 09:48:04 --> Language Class Initialized
INFO - 2020-12-03 09:48:04 --> Language Class Initialized
INFO - 2020-12-03 09:48:04 --> Config Class Initialized
INFO - 2020-12-03 09:48:04 --> Loader Class Initialized
INFO - 2020-12-03 09:48:04 --> Helper loaded: url_helper
INFO - 2020-12-03 09:48:04 --> Helper loaded: file_helper
INFO - 2020-12-03 09:48:04 --> Helper loaded: form_helper
INFO - 2020-12-03 09:48:04 --> Helper loaded: my_helper
INFO - 2020-12-03 09:48:04 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:48:04 --> Controller Class Initialized
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 97
ERROR - 2020-12-03 09:48:04 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 113
DEBUG - 2020-12-03 09:48:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 09:48:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 09:48:04 --> Final output sent to browser
DEBUG - 2020-12-03 09:48:04 --> Total execution time: 0.4821
INFO - 2020-12-03 09:49:36 --> Config Class Initialized
INFO - 2020-12-03 09:49:36 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:49:36 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:49:36 --> Utf8 Class Initialized
INFO - 2020-12-03 09:49:36 --> URI Class Initialized
INFO - 2020-12-03 09:49:36 --> Router Class Initialized
INFO - 2020-12-03 09:49:36 --> Output Class Initialized
INFO - 2020-12-03 09:49:36 --> Security Class Initialized
DEBUG - 2020-12-03 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:49:36 --> Input Class Initialized
INFO - 2020-12-03 09:49:36 --> Language Class Initialized
INFO - 2020-12-03 09:49:36 --> Language Class Initialized
INFO - 2020-12-03 09:49:36 --> Config Class Initialized
INFO - 2020-12-03 09:49:36 --> Loader Class Initialized
INFO - 2020-12-03 09:49:36 --> Helper loaded: url_helper
INFO - 2020-12-03 09:49:36 --> Helper loaded: file_helper
INFO - 2020-12-03 09:49:36 --> Helper loaded: form_helper
INFO - 2020-12-03 09:49:36 --> Helper loaded: my_helper
INFO - 2020-12-03 09:49:36 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:49:37 --> Controller Class Initialized
ERROR - 2020-12-03 09:49:37 --> Severity: Error --> Call to undefined function base_catatan() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 10
INFO - 2020-12-03 09:49:56 --> Config Class Initialized
INFO - 2020-12-03 09:49:56 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:49:56 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:49:56 --> Utf8 Class Initialized
INFO - 2020-12-03 09:49:56 --> URI Class Initialized
INFO - 2020-12-03 09:49:56 --> Router Class Initialized
INFO - 2020-12-03 09:49:56 --> Output Class Initialized
INFO - 2020-12-03 09:49:56 --> Security Class Initialized
DEBUG - 2020-12-03 09:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:49:56 --> Input Class Initialized
INFO - 2020-12-03 09:49:56 --> Language Class Initialized
INFO - 2020-12-03 09:49:56 --> Language Class Initialized
INFO - 2020-12-03 09:49:56 --> Config Class Initialized
INFO - 2020-12-03 09:49:56 --> Loader Class Initialized
INFO - 2020-12-03 09:49:56 --> Helper loaded: url_helper
INFO - 2020-12-03 09:49:56 --> Helper loaded: file_helper
INFO - 2020-12-03 09:49:56 --> Helper loaded: form_helper
INFO - 2020-12-03 09:49:56 --> Helper loaded: my_helper
INFO - 2020-12-03 09:49:56 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:49:56 --> Controller Class Initialized
DEBUG - 2020-12-03 09:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-03 09:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 09:49:56 --> Final output sent to browser
DEBUG - 2020-12-03 09:49:56 --> Total execution time: 0.2018
INFO - 2020-12-03 09:49:58 --> Config Class Initialized
INFO - 2020-12-03 09:49:58 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:49:58 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:49:58 --> Utf8 Class Initialized
INFO - 2020-12-03 09:49:58 --> URI Class Initialized
INFO - 2020-12-03 09:49:58 --> Router Class Initialized
INFO - 2020-12-03 09:49:58 --> Output Class Initialized
INFO - 2020-12-03 09:49:58 --> Security Class Initialized
DEBUG - 2020-12-03 09:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:49:58 --> Input Class Initialized
INFO - 2020-12-03 09:49:58 --> Language Class Initialized
INFO - 2020-12-03 09:49:58 --> Language Class Initialized
INFO - 2020-12-03 09:49:58 --> Config Class Initialized
INFO - 2020-12-03 09:49:58 --> Loader Class Initialized
INFO - 2020-12-03 09:49:58 --> Helper loaded: url_helper
INFO - 2020-12-03 09:49:58 --> Helper loaded: file_helper
INFO - 2020-12-03 09:49:58 --> Helper loaded: form_helper
INFO - 2020-12-03 09:49:58 --> Helper loaded: my_helper
INFO - 2020-12-03 09:49:58 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:49:58 --> Controller Class Initialized
INFO - 2020-12-03 09:49:58 --> Final output sent to browser
DEBUG - 2020-12-03 09:49:58 --> Total execution time: 0.1690
INFO - 2020-12-03 09:50:10 --> Config Class Initialized
INFO - 2020-12-03 09:50:10 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:50:10 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:50:10 --> Utf8 Class Initialized
INFO - 2020-12-03 09:50:10 --> URI Class Initialized
INFO - 2020-12-03 09:50:10 --> Router Class Initialized
INFO - 2020-12-03 09:50:10 --> Output Class Initialized
INFO - 2020-12-03 09:50:10 --> Security Class Initialized
DEBUG - 2020-12-03 09:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:50:10 --> Input Class Initialized
INFO - 2020-12-03 09:50:10 --> Language Class Initialized
INFO - 2020-12-03 09:50:10 --> Language Class Initialized
INFO - 2020-12-03 09:50:10 --> Config Class Initialized
INFO - 2020-12-03 09:50:10 --> Loader Class Initialized
INFO - 2020-12-03 09:50:10 --> Helper loaded: url_helper
INFO - 2020-12-03 09:50:10 --> Helper loaded: file_helper
INFO - 2020-12-03 09:50:10 --> Helper loaded: form_helper
INFO - 2020-12-03 09:50:10 --> Helper loaded: my_helper
INFO - 2020-12-03 09:50:10 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:50:10 --> Controller Class Initialized
DEBUG - 2020-12-03 09:50:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-12-03 09:50:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 09:50:11 --> Final output sent to browser
DEBUG - 2020-12-03 09:50:11 --> Total execution time: 0.2734
INFO - 2020-12-03 09:50:12 --> Config Class Initialized
INFO - 2020-12-03 09:50:12 --> Hooks Class Initialized
DEBUG - 2020-12-03 09:50:12 --> UTF-8 Support Enabled
INFO - 2020-12-03 09:50:12 --> Utf8 Class Initialized
INFO - 2020-12-03 09:50:12 --> URI Class Initialized
INFO - 2020-12-03 09:50:12 --> Router Class Initialized
INFO - 2020-12-03 09:50:12 --> Output Class Initialized
INFO - 2020-12-03 09:50:12 --> Security Class Initialized
DEBUG - 2020-12-03 09:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-03 09:50:12 --> Input Class Initialized
INFO - 2020-12-03 09:50:12 --> Language Class Initialized
INFO - 2020-12-03 09:50:12 --> Language Class Initialized
INFO - 2020-12-03 09:50:12 --> Config Class Initialized
INFO - 2020-12-03 09:50:12 --> Loader Class Initialized
INFO - 2020-12-03 09:50:12 --> Helper loaded: url_helper
INFO - 2020-12-03 09:50:12 --> Helper loaded: file_helper
INFO - 2020-12-03 09:50:12 --> Helper loaded: form_helper
INFO - 2020-12-03 09:50:12 --> Helper loaded: my_helper
INFO - 2020-12-03 09:50:12 --> Database Driver Class Initialized
DEBUG - 2020-12-03 09:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-03 09:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-03 09:50:12 --> Controller Class Initialized
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 10
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 81
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 87
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 98
ERROR - 2020-12-03 09:50:12 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 114
DEBUG - 2020-12-03 09:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-03 09:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-03 09:50:12 --> Final output sent to browser
DEBUG - 2020-12-03 09:50:13 --> Total execution time: 0.5398
