<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-12 08:40:10 --> Config Class Initialized
INFO - 2022-07-12 08:40:10 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:40:10 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:40:10 --> Utf8 Class Initialized
INFO - 2022-07-12 08:40:10 --> URI Class Initialized
DEBUG - 2022-07-12 08:40:10 --> No URI present. Default controller set.
INFO - 2022-07-12 08:40:10 --> Router Class Initialized
INFO - 2022-07-12 08:40:10 --> Output Class Initialized
INFO - 2022-07-12 08:40:10 --> Security Class Initialized
DEBUG - 2022-07-12 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:40:10 --> Input Class Initialized
INFO - 2022-07-12 08:40:10 --> Language Class Initialized
INFO - 2022-07-12 08:40:10 --> Language Class Initialized
INFO - 2022-07-12 08:40:10 --> Config Class Initialized
INFO - 2022-07-12 08:40:10 --> Loader Class Initialized
INFO - 2022-07-12 08:40:10 --> Helper loaded: url_helper
INFO - 2022-07-12 08:40:10 --> Helper loaded: file_helper
INFO - 2022-07-12 08:40:10 --> Helper loaded: form_helper
INFO - 2022-07-12 08:40:10 --> Helper loaded: my_helper
INFO - 2022-07-12 08:40:10 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:40:10 --> Controller Class Initialized
INFO - 2022-07-12 08:40:10 --> Config Class Initialized
INFO - 2022-07-12 08:40:10 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:40:10 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:40:10 --> Utf8 Class Initialized
INFO - 2022-07-12 08:40:11 --> URI Class Initialized
INFO - 2022-07-12 08:40:11 --> Router Class Initialized
INFO - 2022-07-12 08:40:11 --> Output Class Initialized
INFO - 2022-07-12 08:40:11 --> Security Class Initialized
DEBUG - 2022-07-12 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:40:11 --> Input Class Initialized
INFO - 2022-07-12 08:40:11 --> Language Class Initialized
INFO - 2022-07-12 08:40:11 --> Language Class Initialized
INFO - 2022-07-12 08:40:11 --> Config Class Initialized
INFO - 2022-07-12 08:40:11 --> Loader Class Initialized
INFO - 2022-07-12 08:40:11 --> Helper loaded: url_helper
INFO - 2022-07-12 08:40:11 --> Helper loaded: file_helper
INFO - 2022-07-12 08:40:11 --> Helper loaded: form_helper
INFO - 2022-07-12 08:40:11 --> Helper loaded: my_helper
INFO - 2022-07-12 08:40:11 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:40:11 --> Controller Class Initialized
DEBUG - 2022-07-12 08:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-12 08:40:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:40:11 --> Final output sent to browser
DEBUG - 2022-07-12 08:40:11 --> Total execution time: 0.0484
INFO - 2022-07-12 08:40:52 --> Config Class Initialized
INFO - 2022-07-12 08:40:52 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:40:52 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:40:52 --> Utf8 Class Initialized
INFO - 2022-07-12 08:40:52 --> URI Class Initialized
INFO - 2022-07-12 08:40:52 --> Router Class Initialized
INFO - 2022-07-12 08:40:52 --> Output Class Initialized
INFO - 2022-07-12 08:40:52 --> Security Class Initialized
DEBUG - 2022-07-12 08:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:40:52 --> Input Class Initialized
INFO - 2022-07-12 08:40:52 --> Language Class Initialized
INFO - 2022-07-12 08:40:52 --> Language Class Initialized
INFO - 2022-07-12 08:40:52 --> Config Class Initialized
INFO - 2022-07-12 08:40:52 --> Loader Class Initialized
INFO - 2022-07-12 08:40:52 --> Helper loaded: url_helper
INFO - 2022-07-12 08:40:52 --> Helper loaded: file_helper
INFO - 2022-07-12 08:40:52 --> Helper loaded: form_helper
INFO - 2022-07-12 08:40:52 --> Helper loaded: my_helper
INFO - 2022-07-12 08:40:52 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:40:52 --> Controller Class Initialized
INFO - 2022-07-12 08:40:52 --> Helper loaded: cookie_helper
INFO - 2022-07-12 08:40:52 --> Final output sent to browser
DEBUG - 2022-07-12 08:40:52 --> Total execution time: 0.0766
INFO - 2022-07-12 08:40:55 --> Config Class Initialized
INFO - 2022-07-12 08:40:55 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:40:55 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:40:55 --> Utf8 Class Initialized
INFO - 2022-07-12 08:40:55 --> URI Class Initialized
INFO - 2022-07-12 08:40:55 --> Router Class Initialized
INFO - 2022-07-12 08:40:55 --> Output Class Initialized
INFO - 2022-07-12 08:40:55 --> Security Class Initialized
DEBUG - 2022-07-12 08:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:40:55 --> Input Class Initialized
INFO - 2022-07-12 08:40:55 --> Language Class Initialized
INFO - 2022-07-12 08:40:55 --> Language Class Initialized
INFO - 2022-07-12 08:40:55 --> Config Class Initialized
INFO - 2022-07-12 08:40:55 --> Loader Class Initialized
INFO - 2022-07-12 08:40:55 --> Helper loaded: url_helper
INFO - 2022-07-12 08:40:55 --> Helper loaded: file_helper
INFO - 2022-07-12 08:40:55 --> Helper loaded: form_helper
INFO - 2022-07-12 08:40:55 --> Helper loaded: my_helper
INFO - 2022-07-12 08:40:55 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:40:55 --> Controller Class Initialized
DEBUG - 2022-07-12 08:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-12 08:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:40:56 --> Final output sent to browser
DEBUG - 2022-07-12 08:40:56 --> Total execution time: 0.5888
INFO - 2022-07-12 08:41:11 --> Config Class Initialized
INFO - 2022-07-12 08:41:11 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:41:11 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:41:11 --> Utf8 Class Initialized
INFO - 2022-07-12 08:41:11 --> URI Class Initialized
INFO - 2022-07-12 08:41:11 --> Router Class Initialized
INFO - 2022-07-12 08:41:11 --> Output Class Initialized
INFO - 2022-07-12 08:41:11 --> Security Class Initialized
DEBUG - 2022-07-12 08:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:41:11 --> Input Class Initialized
INFO - 2022-07-12 08:41:11 --> Language Class Initialized
INFO - 2022-07-12 08:41:11 --> Language Class Initialized
INFO - 2022-07-12 08:41:11 --> Config Class Initialized
INFO - 2022-07-12 08:41:11 --> Loader Class Initialized
INFO - 2022-07-12 08:41:11 --> Helper loaded: url_helper
INFO - 2022-07-12 08:41:11 --> Helper loaded: file_helper
INFO - 2022-07-12 08:41:11 --> Helper loaded: form_helper
INFO - 2022-07-12 08:41:11 --> Helper loaded: my_helper
INFO - 2022-07-12 08:41:11 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:41:11 --> Controller Class Initialized
DEBUG - 2022-07-12 08:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 08:41:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:41:11 --> Final output sent to browser
DEBUG - 2022-07-12 08:41:11 --> Total execution time: 0.0616
INFO - 2022-07-12 08:53:05 --> Config Class Initialized
INFO - 2022-07-12 08:53:05 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:53:05 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:53:05 --> Utf8 Class Initialized
INFO - 2022-07-12 08:53:05 --> URI Class Initialized
INFO - 2022-07-12 08:53:05 --> Router Class Initialized
INFO - 2022-07-12 08:53:05 --> Output Class Initialized
INFO - 2022-07-12 08:53:05 --> Security Class Initialized
DEBUG - 2022-07-12 08:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:53:05 --> Input Class Initialized
INFO - 2022-07-12 08:53:05 --> Language Class Initialized
INFO - 2022-07-12 08:53:05 --> Language Class Initialized
INFO - 2022-07-12 08:53:05 --> Config Class Initialized
INFO - 2022-07-12 08:53:05 --> Loader Class Initialized
INFO - 2022-07-12 08:53:05 --> Helper loaded: url_helper
INFO - 2022-07-12 08:53:05 --> Helper loaded: file_helper
INFO - 2022-07-12 08:53:05 --> Helper loaded: form_helper
INFO - 2022-07-12 08:53:05 --> Helper loaded: my_helper
INFO - 2022-07-12 08:53:05 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:53:05 --> Controller Class Initialized
ERROR - 2022-07-12 08:53:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND Jaya Motor','Jl. Raya Cibungbulang, Cemplang','2','Baik')' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('604','20212','D'ND Jaya Motor','Jl. Raya Cibungbulang, Cemplang','2','Baik')
INFO - 2022-07-12 08:53:05 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-12 08:53:05 --> Config Class Initialized
INFO - 2022-07-12 08:53:05 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:53:05 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:53:05 --> Utf8 Class Initialized
INFO - 2022-07-12 08:53:05 --> URI Class Initialized
INFO - 2022-07-12 08:53:05 --> Router Class Initialized
INFO - 2022-07-12 08:53:05 --> Output Class Initialized
INFO - 2022-07-12 08:53:05 --> Security Class Initialized
DEBUG - 2022-07-12 08:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:53:05 --> Input Class Initialized
INFO - 2022-07-12 08:53:05 --> Language Class Initialized
INFO - 2022-07-12 08:53:05 --> Language Class Initialized
INFO - 2022-07-12 08:53:05 --> Config Class Initialized
INFO - 2022-07-12 08:53:05 --> Loader Class Initialized
INFO - 2022-07-12 08:53:05 --> Helper loaded: url_helper
INFO - 2022-07-12 08:53:05 --> Helper loaded: file_helper
INFO - 2022-07-12 08:53:05 --> Helper loaded: form_helper
INFO - 2022-07-12 08:53:05 --> Helper loaded: my_helper
INFO - 2022-07-12 08:53:05 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:53:05 --> Controller Class Initialized
ERROR - 2022-07-12 08:53:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ND Jaya Motor','Jl. Raya Cibungbulang, Cemplang','2','Baik')' at line 1 - Invalid query: INSERT INTO t_pkl (id_siswa,ta,mitra,lokasi,lama,keterangan) VALUES ('604','20212','D'ND Jaya Motor','Jl. Raya Cibungbulang, Cemplang','2','Baik')
INFO - 2022-07-12 08:53:05 --> Language file loaded: language/english/db_lang.php
INFO - 2022-07-12 08:53:32 --> Config Class Initialized
INFO - 2022-07-12 08:53:32 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:53:32 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:53:32 --> Utf8 Class Initialized
INFO - 2022-07-12 08:53:32 --> URI Class Initialized
INFO - 2022-07-12 08:53:32 --> Router Class Initialized
INFO - 2022-07-12 08:53:32 --> Output Class Initialized
INFO - 2022-07-12 08:53:32 --> Security Class Initialized
DEBUG - 2022-07-12 08:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:53:32 --> Input Class Initialized
INFO - 2022-07-12 08:53:32 --> Language Class Initialized
INFO - 2022-07-12 08:53:32 --> Language Class Initialized
INFO - 2022-07-12 08:53:32 --> Config Class Initialized
INFO - 2022-07-12 08:53:32 --> Loader Class Initialized
INFO - 2022-07-12 08:53:32 --> Helper loaded: url_helper
INFO - 2022-07-12 08:53:32 --> Helper loaded: file_helper
INFO - 2022-07-12 08:53:32 --> Helper loaded: form_helper
INFO - 2022-07-12 08:53:32 --> Helper loaded: my_helper
INFO - 2022-07-12 08:53:32 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:53:32 --> Controller Class Initialized
DEBUG - 2022-07-12 08:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-12 08:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:53:32 --> Final output sent to browser
DEBUG - 2022-07-12 08:53:32 --> Total execution time: 0.1445
INFO - 2022-07-12 08:53:32 --> Config Class Initialized
INFO - 2022-07-12 08:53:32 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:53:32 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:53:32 --> Utf8 Class Initialized
INFO - 2022-07-12 08:53:32 --> URI Class Initialized
INFO - 2022-07-12 08:53:32 --> Router Class Initialized
INFO - 2022-07-12 08:53:32 --> Output Class Initialized
INFO - 2022-07-12 08:53:32 --> Security Class Initialized
DEBUG - 2022-07-12 08:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:53:32 --> Input Class Initialized
INFO - 2022-07-12 08:53:32 --> Language Class Initialized
INFO - 2022-07-12 08:53:32 --> Language Class Initialized
INFO - 2022-07-12 08:53:32 --> Config Class Initialized
INFO - 2022-07-12 08:53:32 --> Loader Class Initialized
INFO - 2022-07-12 08:53:32 --> Helper loaded: url_helper
INFO - 2022-07-12 08:53:32 --> Helper loaded: file_helper
INFO - 2022-07-12 08:53:32 --> Helper loaded: form_helper
INFO - 2022-07-12 08:53:32 --> Helper loaded: my_helper
INFO - 2022-07-12 08:53:32 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:53:32 --> Controller Class Initialized
DEBUG - 2022-07-12 08:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-12 08:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:53:32 --> Final output sent to browser
DEBUG - 2022-07-12 08:53:32 --> Total execution time: 0.0520
INFO - 2022-07-12 08:53:39 --> Config Class Initialized
INFO - 2022-07-12 08:53:39 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:53:39 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:53:39 --> Utf8 Class Initialized
INFO - 2022-07-12 08:53:39 --> URI Class Initialized
INFO - 2022-07-12 08:53:39 --> Router Class Initialized
INFO - 2022-07-12 08:53:39 --> Output Class Initialized
INFO - 2022-07-12 08:53:39 --> Security Class Initialized
DEBUG - 2022-07-12 08:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:53:39 --> Input Class Initialized
INFO - 2022-07-12 08:53:39 --> Language Class Initialized
INFO - 2022-07-12 08:53:39 --> Language Class Initialized
INFO - 2022-07-12 08:53:39 --> Config Class Initialized
INFO - 2022-07-12 08:53:39 --> Loader Class Initialized
INFO - 2022-07-12 08:53:39 --> Helper loaded: url_helper
INFO - 2022-07-12 08:53:39 --> Helper loaded: file_helper
INFO - 2022-07-12 08:53:39 --> Helper loaded: form_helper
INFO - 2022-07-12 08:53:39 --> Helper loaded: my_helper
INFO - 2022-07-12 08:53:39 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:53:39 --> Controller Class Initialized
DEBUG - 2022-07-12 08:53:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-12 08:53:39 --> Final output sent to browser
DEBUG - 2022-07-12 08:53:39 --> Total execution time: 0.3201
INFO - 2022-07-12 08:53:50 --> Config Class Initialized
INFO - 2022-07-12 08:53:50 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:53:50 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:53:50 --> Utf8 Class Initialized
INFO - 2022-07-12 08:53:50 --> URI Class Initialized
INFO - 2022-07-12 08:53:50 --> Router Class Initialized
INFO - 2022-07-12 08:53:50 --> Output Class Initialized
INFO - 2022-07-12 08:53:50 --> Security Class Initialized
DEBUG - 2022-07-12 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:53:50 --> Input Class Initialized
INFO - 2022-07-12 08:53:50 --> Language Class Initialized
INFO - 2022-07-12 08:53:50 --> Language Class Initialized
INFO - 2022-07-12 08:53:50 --> Config Class Initialized
INFO - 2022-07-12 08:53:50 --> Loader Class Initialized
INFO - 2022-07-12 08:53:50 --> Helper loaded: url_helper
INFO - 2022-07-12 08:53:50 --> Helper loaded: file_helper
INFO - 2022-07-12 08:53:50 --> Helper loaded: form_helper
INFO - 2022-07-12 08:53:50 --> Helper loaded: my_helper
INFO - 2022-07-12 08:53:50 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:53:50 --> Controller Class Initialized
DEBUG - 2022-07-12 08:53:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 08:53:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:53:50 --> Final output sent to browser
DEBUG - 2022-07-12 08:53:50 --> Total execution time: 0.0709
INFO - 2022-07-12 08:54:18 --> Config Class Initialized
INFO - 2022-07-12 08:54:18 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:18 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:18 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:18 --> URI Class Initialized
DEBUG - 2022-07-12 08:54:18 --> No URI present. Default controller set.
INFO - 2022-07-12 08:54:18 --> Router Class Initialized
INFO - 2022-07-12 08:54:18 --> Output Class Initialized
INFO - 2022-07-12 08:54:18 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:18 --> Input Class Initialized
INFO - 2022-07-12 08:54:18 --> Language Class Initialized
INFO - 2022-07-12 08:54:18 --> Language Class Initialized
INFO - 2022-07-12 08:54:18 --> Config Class Initialized
INFO - 2022-07-12 08:54:18 --> Loader Class Initialized
INFO - 2022-07-12 08:54:18 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:18 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:18 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:18 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:18 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:18 --> Controller Class Initialized
DEBUG - 2022-07-12 08:54:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-12 08:54:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:54:18 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:18 --> Total execution time: 0.6358
INFO - 2022-07-12 08:54:18 --> Config Class Initialized
INFO - 2022-07-12 08:54:18 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:18 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:18 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:18 --> URI Class Initialized
DEBUG - 2022-07-12 08:54:18 --> No URI present. Default controller set.
INFO - 2022-07-12 08:54:18 --> Router Class Initialized
INFO - 2022-07-12 08:54:18 --> Output Class Initialized
INFO - 2022-07-12 08:54:18 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:18 --> Input Class Initialized
INFO - 2022-07-12 08:54:18 --> Language Class Initialized
INFO - 2022-07-12 08:54:18 --> Language Class Initialized
INFO - 2022-07-12 08:54:18 --> Config Class Initialized
INFO - 2022-07-12 08:54:18 --> Loader Class Initialized
INFO - 2022-07-12 08:54:18 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:18 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:18 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:18 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:18 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:18 --> Controller Class Initialized
DEBUG - 2022-07-12 08:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-12 08:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:54:19 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:19 --> Total execution time: 0.5178
INFO - 2022-07-12 08:54:19 --> Config Class Initialized
INFO - 2022-07-12 08:54:19 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:19 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:19 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:19 --> URI Class Initialized
DEBUG - 2022-07-12 08:54:19 --> No URI present. Default controller set.
INFO - 2022-07-12 08:54:19 --> Router Class Initialized
INFO - 2022-07-12 08:54:19 --> Output Class Initialized
INFO - 2022-07-12 08:54:19 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:19 --> Input Class Initialized
INFO - 2022-07-12 08:54:19 --> Language Class Initialized
INFO - 2022-07-12 08:54:19 --> Language Class Initialized
INFO - 2022-07-12 08:54:19 --> Config Class Initialized
INFO - 2022-07-12 08:54:19 --> Loader Class Initialized
INFO - 2022-07-12 08:54:19 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:19 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:19 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:19 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:19 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:19 --> Controller Class Initialized
DEBUG - 2022-07-12 08:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-12 08:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:54:19 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:19 --> Total execution time: 0.5142
INFO - 2022-07-12 08:54:25 --> Config Class Initialized
INFO - 2022-07-12 08:54:25 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:25 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:25 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:25 --> URI Class Initialized
INFO - 2022-07-12 08:54:25 --> Router Class Initialized
INFO - 2022-07-12 08:54:25 --> Output Class Initialized
INFO - 2022-07-12 08:54:25 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:25 --> Input Class Initialized
INFO - 2022-07-12 08:54:25 --> Language Class Initialized
INFO - 2022-07-12 08:54:25 --> Language Class Initialized
INFO - 2022-07-12 08:54:25 --> Config Class Initialized
INFO - 2022-07-12 08:54:25 --> Loader Class Initialized
INFO - 2022-07-12 08:54:25 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:25 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:25 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:25 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:25 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:25 --> Controller Class Initialized
DEBUG - 2022-07-12 08:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-12 08:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:54:25 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:25 --> Total execution time: 0.0670
INFO - 2022-07-12 08:54:25 --> Config Class Initialized
INFO - 2022-07-12 08:54:25 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:25 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:25 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:25 --> URI Class Initialized
INFO - 2022-07-12 08:54:25 --> Router Class Initialized
INFO - 2022-07-12 08:54:25 --> Output Class Initialized
INFO - 2022-07-12 08:54:25 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:25 --> Input Class Initialized
INFO - 2022-07-12 08:54:25 --> Language Class Initialized
INFO - 2022-07-12 08:54:25 --> Language Class Initialized
INFO - 2022-07-12 08:54:25 --> Config Class Initialized
INFO - 2022-07-12 08:54:25 --> Loader Class Initialized
INFO - 2022-07-12 08:54:25 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:25 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:25 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:25 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:25 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:25 --> Controller Class Initialized
DEBUG - 2022-07-12 08:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-12 08:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:54:25 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:25 --> Total execution time: 0.0508
INFO - 2022-07-12 08:54:31 --> Config Class Initialized
INFO - 2022-07-12 08:54:31 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:31 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:31 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:31 --> URI Class Initialized
INFO - 2022-07-12 08:54:31 --> Router Class Initialized
INFO - 2022-07-12 08:54:31 --> Output Class Initialized
INFO - 2022-07-12 08:54:31 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:31 --> Input Class Initialized
INFO - 2022-07-12 08:54:31 --> Language Class Initialized
INFO - 2022-07-12 08:54:31 --> Language Class Initialized
INFO - 2022-07-12 08:54:31 --> Config Class Initialized
INFO - 2022-07-12 08:54:31 --> Loader Class Initialized
INFO - 2022-07-12 08:54:31 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:31 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:31 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:31 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:31 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:31 --> Controller Class Initialized
DEBUG - 2022-07-12 08:54:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-07-12 08:54:31 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:31 --> Total execution time: 0.2147
INFO - 2022-07-12 08:54:41 --> Config Class Initialized
INFO - 2022-07-12 08:54:41 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:41 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:41 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:41 --> URI Class Initialized
INFO - 2022-07-12 08:54:41 --> Router Class Initialized
INFO - 2022-07-12 08:54:41 --> Output Class Initialized
INFO - 2022-07-12 08:54:41 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:41 --> Input Class Initialized
INFO - 2022-07-12 08:54:41 --> Language Class Initialized
INFO - 2022-07-12 08:54:41 --> Language Class Initialized
INFO - 2022-07-12 08:54:41 --> Config Class Initialized
INFO - 2022-07-12 08:54:41 --> Loader Class Initialized
INFO - 2022-07-12 08:54:41 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:41 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:41 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:41 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:41 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:41 --> Controller Class Initialized
DEBUG - 2022-07-12 08:54:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 08:54:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:54:41 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:41 --> Total execution time: 0.0714
INFO - 2022-07-12 08:54:41 --> Config Class Initialized
INFO - 2022-07-12 08:54:41 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:41 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:41 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:41 --> URI Class Initialized
INFO - 2022-07-12 08:54:41 --> Router Class Initialized
INFO - 2022-07-12 08:54:41 --> Output Class Initialized
INFO - 2022-07-12 08:54:41 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:41 --> Input Class Initialized
INFO - 2022-07-12 08:54:41 --> Language Class Initialized
INFO - 2022-07-12 08:54:41 --> Language Class Initialized
INFO - 2022-07-12 08:54:41 --> Config Class Initialized
INFO - 2022-07-12 08:54:41 --> Loader Class Initialized
INFO - 2022-07-12 08:54:41 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:41 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:41 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:41 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:41 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:41 --> Controller Class Initialized
DEBUG - 2022-07-12 08:54:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 08:54:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:54:41 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:41 --> Total execution time: 0.0484
INFO - 2022-07-12 08:54:45 --> Config Class Initialized
INFO - 2022-07-12 08:54:45 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:45 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:45 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:45 --> URI Class Initialized
INFO - 2022-07-12 08:54:45 --> Router Class Initialized
INFO - 2022-07-12 08:54:45 --> Output Class Initialized
INFO - 2022-07-12 08:54:45 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:45 --> Input Class Initialized
INFO - 2022-07-12 08:54:45 --> Language Class Initialized
INFO - 2022-07-12 08:54:45 --> Language Class Initialized
INFO - 2022-07-12 08:54:45 --> Config Class Initialized
INFO - 2022-07-12 08:54:45 --> Loader Class Initialized
INFO - 2022-07-12 08:54:45 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:45 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:45 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:45 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:45 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:45 --> Controller Class Initialized
INFO - 2022-07-12 08:54:45 --> Helper loaded: cookie_helper
INFO - 2022-07-12 08:54:45 --> Config Class Initialized
INFO - 2022-07-12 08:54:45 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:45 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:45 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:45 --> URI Class Initialized
INFO - 2022-07-12 08:54:45 --> Router Class Initialized
INFO - 2022-07-12 08:54:45 --> Output Class Initialized
INFO - 2022-07-12 08:54:45 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:45 --> Input Class Initialized
INFO - 2022-07-12 08:54:45 --> Language Class Initialized
INFO - 2022-07-12 08:54:45 --> Language Class Initialized
INFO - 2022-07-12 08:54:45 --> Config Class Initialized
INFO - 2022-07-12 08:54:45 --> Loader Class Initialized
INFO - 2022-07-12 08:54:45 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:45 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:45 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:45 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:45 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:45 --> Controller Class Initialized
DEBUG - 2022-07-12 08:54:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-12 08:54:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:54:45 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:45 --> Total execution time: 0.0515
INFO - 2022-07-12 08:54:59 --> Config Class Initialized
INFO - 2022-07-12 08:54:59 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:54:59 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:54:59 --> Utf8 Class Initialized
INFO - 2022-07-12 08:54:59 --> URI Class Initialized
INFO - 2022-07-12 08:54:59 --> Router Class Initialized
INFO - 2022-07-12 08:54:59 --> Output Class Initialized
INFO - 2022-07-12 08:54:59 --> Security Class Initialized
DEBUG - 2022-07-12 08:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:54:59 --> Input Class Initialized
INFO - 2022-07-12 08:54:59 --> Language Class Initialized
INFO - 2022-07-12 08:54:59 --> Language Class Initialized
INFO - 2022-07-12 08:54:59 --> Config Class Initialized
INFO - 2022-07-12 08:54:59 --> Loader Class Initialized
INFO - 2022-07-12 08:54:59 --> Helper loaded: url_helper
INFO - 2022-07-12 08:54:59 --> Helper loaded: file_helper
INFO - 2022-07-12 08:54:59 --> Helper loaded: form_helper
INFO - 2022-07-12 08:54:59 --> Helper loaded: my_helper
INFO - 2022-07-12 08:54:59 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:54:59 --> Controller Class Initialized
INFO - 2022-07-12 08:54:59 --> Helper loaded: cookie_helper
INFO - 2022-07-12 08:54:59 --> Final output sent to browser
DEBUG - 2022-07-12 08:54:59 --> Total execution time: 0.0493
INFO - 2022-07-12 08:55:01 --> Config Class Initialized
INFO - 2022-07-12 08:55:01 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:01 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:01 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:01 --> URI Class Initialized
INFO - 2022-07-12 08:55:01 --> Router Class Initialized
INFO - 2022-07-12 08:55:01 --> Output Class Initialized
INFO - 2022-07-12 08:55:01 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:01 --> Input Class Initialized
INFO - 2022-07-12 08:55:01 --> Language Class Initialized
INFO - 2022-07-12 08:55:01 --> Language Class Initialized
INFO - 2022-07-12 08:55:01 --> Config Class Initialized
INFO - 2022-07-12 08:55:01 --> Loader Class Initialized
INFO - 2022-07-12 08:55:01 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:01 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:01 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:01 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:01 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:01 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-12 08:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:02 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:02 --> Total execution time: 0.5936
INFO - 2022-07-12 08:55:04 --> Config Class Initialized
INFO - 2022-07-12 08:55:04 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:04 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:04 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:04 --> URI Class Initialized
INFO - 2022-07-12 08:55:04 --> Router Class Initialized
INFO - 2022-07-12 08:55:04 --> Output Class Initialized
INFO - 2022-07-12 08:55:04 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:04 --> Input Class Initialized
INFO - 2022-07-12 08:55:04 --> Language Class Initialized
INFO - 2022-07-12 08:55:04 --> Language Class Initialized
INFO - 2022-07-12 08:55:04 --> Config Class Initialized
INFO - 2022-07-12 08:55:04 --> Loader Class Initialized
INFO - 2022-07-12 08:55:04 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:04 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:04 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:04 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:04 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:04 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 08:55:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:04 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:04 --> Total execution time: 0.0525
INFO - 2022-07-12 08:55:04 --> Config Class Initialized
INFO - 2022-07-12 08:55:04 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:04 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:04 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:05 --> URI Class Initialized
INFO - 2022-07-12 08:55:05 --> Router Class Initialized
INFO - 2022-07-12 08:55:05 --> Output Class Initialized
INFO - 2022-07-12 08:55:05 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:05 --> Input Class Initialized
INFO - 2022-07-12 08:55:05 --> Language Class Initialized
INFO - 2022-07-12 08:55:05 --> Language Class Initialized
INFO - 2022-07-12 08:55:05 --> Config Class Initialized
INFO - 2022-07-12 08:55:05 --> Loader Class Initialized
INFO - 2022-07-12 08:55:05 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:05 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:05 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:05 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:05 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:05 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 08:55:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:05 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:05 --> Total execution time: 0.0568
INFO - 2022-07-12 08:55:34 --> Config Class Initialized
INFO - 2022-07-12 08:55:34 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:34 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:34 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:34 --> URI Class Initialized
INFO - 2022-07-12 08:55:34 --> Router Class Initialized
INFO - 2022-07-12 08:55:34 --> Output Class Initialized
INFO - 2022-07-12 08:55:34 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:34 --> Input Class Initialized
INFO - 2022-07-12 08:55:34 --> Language Class Initialized
INFO - 2022-07-12 08:55:34 --> Language Class Initialized
INFO - 2022-07-12 08:55:34 --> Config Class Initialized
INFO - 2022-07-12 08:55:34 --> Loader Class Initialized
INFO - 2022-07-12 08:55:34 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:34 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:34 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:34 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:34 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:34 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 08:55:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:34 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:34 --> Total execution time: 0.0469
INFO - 2022-07-12 08:55:37 --> Config Class Initialized
INFO - 2022-07-12 08:55:37 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:37 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:37 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:37 --> URI Class Initialized
INFO - 2022-07-12 08:55:37 --> Router Class Initialized
INFO - 2022-07-12 08:55:37 --> Output Class Initialized
INFO - 2022-07-12 08:55:37 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:37 --> Input Class Initialized
INFO - 2022-07-12 08:55:37 --> Language Class Initialized
INFO - 2022-07-12 08:55:37 --> Language Class Initialized
INFO - 2022-07-12 08:55:37 --> Config Class Initialized
INFO - 2022-07-12 08:55:37 --> Loader Class Initialized
INFO - 2022-07-12 08:55:37 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:37 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:37 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:37 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:37 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:37 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-07-12 08:55:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:37 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:37 --> Total execution time: 0.1297
INFO - 2022-07-12 08:55:38 --> Config Class Initialized
INFO - 2022-07-12 08:55:38 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:38 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:38 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:38 --> URI Class Initialized
INFO - 2022-07-12 08:55:38 --> Router Class Initialized
INFO - 2022-07-12 08:55:38 --> Output Class Initialized
INFO - 2022-07-12 08:55:38 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:38 --> Input Class Initialized
INFO - 2022-07-12 08:55:38 --> Language Class Initialized
INFO - 2022-07-12 08:55:38 --> Language Class Initialized
INFO - 2022-07-12 08:55:38 --> Config Class Initialized
INFO - 2022-07-12 08:55:38 --> Loader Class Initialized
INFO - 2022-07-12 08:55:38 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:39 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:39 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:39 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:39 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:39 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 08:55:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:39 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:39 --> Total execution time: 0.0684
INFO - 2022-07-12 08:55:42 --> Config Class Initialized
INFO - 2022-07-12 08:55:42 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:42 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:42 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:42 --> URI Class Initialized
INFO - 2022-07-12 08:55:42 --> Router Class Initialized
INFO - 2022-07-12 08:55:42 --> Output Class Initialized
INFO - 2022-07-12 08:55:42 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:42 --> Input Class Initialized
INFO - 2022-07-12 08:55:42 --> Language Class Initialized
INFO - 2022-07-12 08:55:42 --> Language Class Initialized
INFO - 2022-07-12 08:55:42 --> Config Class Initialized
INFO - 2022-07-12 08:55:42 --> Loader Class Initialized
INFO - 2022-07-12 08:55:42 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:42 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:42 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:42 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:42 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:42 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-07-12 08:55:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:42 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:42 --> Total execution time: 0.0968
INFO - 2022-07-12 08:55:43 --> Config Class Initialized
INFO - 2022-07-12 08:55:43 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:43 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:43 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:43 --> URI Class Initialized
INFO - 2022-07-12 08:55:43 --> Router Class Initialized
INFO - 2022-07-12 08:55:43 --> Output Class Initialized
INFO - 2022-07-12 08:55:43 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:43 --> Input Class Initialized
INFO - 2022-07-12 08:55:43 --> Language Class Initialized
INFO - 2022-07-12 08:55:43 --> Language Class Initialized
INFO - 2022-07-12 08:55:43 --> Config Class Initialized
INFO - 2022-07-12 08:55:43 --> Loader Class Initialized
INFO - 2022-07-12 08:55:43 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:43 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:43 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:43 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:43 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:43 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-07-12 08:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:43 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:43 --> Total execution time: 0.1062
INFO - 2022-07-12 08:55:46 --> Config Class Initialized
INFO - 2022-07-12 08:55:46 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:46 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:46 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:46 --> URI Class Initialized
INFO - 2022-07-12 08:55:46 --> Router Class Initialized
INFO - 2022-07-12 08:55:46 --> Output Class Initialized
INFO - 2022-07-12 08:55:46 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:46 --> Input Class Initialized
INFO - 2022-07-12 08:55:46 --> Language Class Initialized
INFO - 2022-07-12 08:55:46 --> Language Class Initialized
INFO - 2022-07-12 08:55:46 --> Config Class Initialized
INFO - 2022-07-12 08:55:46 --> Loader Class Initialized
INFO - 2022-07-12 08:55:46 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:46 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:46 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:46 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:46 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:46 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-07-12 08:55:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:46 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:46 --> Total execution time: 0.1606
INFO - 2022-07-12 08:55:48 --> Config Class Initialized
INFO - 2022-07-12 08:55:48 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:48 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:48 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:48 --> URI Class Initialized
INFO - 2022-07-12 08:55:48 --> Router Class Initialized
INFO - 2022-07-12 08:55:48 --> Output Class Initialized
INFO - 2022-07-12 08:55:48 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:48 --> Input Class Initialized
INFO - 2022-07-12 08:55:48 --> Language Class Initialized
INFO - 2022-07-12 08:55:48 --> Language Class Initialized
INFO - 2022-07-12 08:55:48 --> Config Class Initialized
INFO - 2022-07-12 08:55:48 --> Loader Class Initialized
INFO - 2022-07-12 08:55:48 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:48 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:48 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:48 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:48 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:48 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2022-07-12 08:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:48 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:48 --> Total execution time: 0.0807
INFO - 2022-07-12 08:55:48 --> Config Class Initialized
INFO - 2022-07-12 08:55:48 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:55:48 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:55:48 --> Utf8 Class Initialized
INFO - 2022-07-12 08:55:48 --> URI Class Initialized
INFO - 2022-07-12 08:55:48 --> Router Class Initialized
INFO - 2022-07-12 08:55:48 --> Output Class Initialized
INFO - 2022-07-12 08:55:48 --> Security Class Initialized
DEBUG - 2022-07-12 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:55:48 --> Input Class Initialized
INFO - 2022-07-12 08:55:48 --> Language Class Initialized
INFO - 2022-07-12 08:55:48 --> Language Class Initialized
INFO - 2022-07-12 08:55:48 --> Config Class Initialized
INFO - 2022-07-12 08:55:48 --> Loader Class Initialized
INFO - 2022-07-12 08:55:48 --> Helper loaded: url_helper
INFO - 2022-07-12 08:55:48 --> Helper loaded: file_helper
INFO - 2022-07-12 08:55:48 --> Helper loaded: form_helper
INFO - 2022-07-12 08:55:48 --> Helper loaded: my_helper
INFO - 2022-07-12 08:55:48 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:55:48 --> Controller Class Initialized
DEBUG - 2022-07-12 08:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-07-12 08:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:55:48 --> Final output sent to browser
DEBUG - 2022-07-12 08:55:48 --> Total execution time: 0.0769
INFO - 2022-07-12 08:56:04 --> Config Class Initialized
INFO - 2022-07-12 08:56:04 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:04 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:04 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:04 --> URI Class Initialized
INFO - 2022-07-12 08:56:05 --> Router Class Initialized
INFO - 2022-07-12 08:56:05 --> Output Class Initialized
INFO - 2022-07-12 08:56:05 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:05 --> Input Class Initialized
INFO - 2022-07-12 08:56:05 --> Language Class Initialized
INFO - 2022-07-12 08:56:05 --> Language Class Initialized
INFO - 2022-07-12 08:56:05 --> Config Class Initialized
INFO - 2022-07-12 08:56:05 --> Loader Class Initialized
INFO - 2022-07-12 08:56:05 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:05 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:05 --> Controller Class Initialized
INFO - 2022-07-12 08:56:05 --> Helper loaded: cookie_helper
INFO - 2022-07-12 08:56:05 --> Config Class Initialized
INFO - 2022-07-12 08:56:05 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:05 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:05 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:05 --> URI Class Initialized
INFO - 2022-07-12 08:56:05 --> Router Class Initialized
INFO - 2022-07-12 08:56:05 --> Output Class Initialized
INFO - 2022-07-12 08:56:05 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:05 --> Input Class Initialized
INFO - 2022-07-12 08:56:05 --> Language Class Initialized
INFO - 2022-07-12 08:56:05 --> Language Class Initialized
INFO - 2022-07-12 08:56:05 --> Config Class Initialized
INFO - 2022-07-12 08:56:05 --> Loader Class Initialized
INFO - 2022-07-12 08:56:05 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:05 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:05 --> Controller Class Initialized
DEBUG - 2022-07-12 08:56:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-12 08:56:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:56:05 --> Final output sent to browser
DEBUG - 2022-07-12 08:56:05 --> Total execution time: 0.0482
INFO - 2022-07-12 08:56:05 --> Config Class Initialized
INFO - 2022-07-12 08:56:05 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:05 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:05 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:05 --> URI Class Initialized
INFO - 2022-07-12 08:56:05 --> Router Class Initialized
INFO - 2022-07-12 08:56:05 --> Output Class Initialized
INFO - 2022-07-12 08:56:05 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:05 --> Input Class Initialized
INFO - 2022-07-12 08:56:05 --> Language Class Initialized
INFO - 2022-07-12 08:56:05 --> Language Class Initialized
INFO - 2022-07-12 08:56:05 --> Config Class Initialized
INFO - 2022-07-12 08:56:05 --> Loader Class Initialized
INFO - 2022-07-12 08:56:05 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:05 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:05 --> Controller Class Initialized
INFO - 2022-07-12 08:56:05 --> Helper loaded: cookie_helper
INFO - 2022-07-12 08:56:05 --> Config Class Initialized
INFO - 2022-07-12 08:56:05 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:05 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:05 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:05 --> URI Class Initialized
INFO - 2022-07-12 08:56:05 --> Router Class Initialized
INFO - 2022-07-12 08:56:05 --> Output Class Initialized
INFO - 2022-07-12 08:56:05 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:05 --> Input Class Initialized
INFO - 2022-07-12 08:56:05 --> Language Class Initialized
INFO - 2022-07-12 08:56:05 --> Language Class Initialized
INFO - 2022-07-12 08:56:05 --> Config Class Initialized
INFO - 2022-07-12 08:56:05 --> Loader Class Initialized
INFO - 2022-07-12 08:56:05 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:05 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:05 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:05 --> Controller Class Initialized
DEBUG - 2022-07-12 08:56:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-12 08:56:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:56:05 --> Final output sent to browser
DEBUG - 2022-07-12 08:56:05 --> Total execution time: 0.0544
INFO - 2022-07-12 08:56:23 --> Config Class Initialized
INFO - 2022-07-12 08:56:23 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:23 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:23 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:23 --> URI Class Initialized
INFO - 2022-07-12 08:56:23 --> Router Class Initialized
INFO - 2022-07-12 08:56:23 --> Output Class Initialized
INFO - 2022-07-12 08:56:23 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:23 --> Input Class Initialized
INFO - 2022-07-12 08:56:23 --> Language Class Initialized
INFO - 2022-07-12 08:56:23 --> Language Class Initialized
INFO - 2022-07-12 08:56:23 --> Config Class Initialized
INFO - 2022-07-12 08:56:23 --> Loader Class Initialized
INFO - 2022-07-12 08:56:23 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:23 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:23 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:23 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:23 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:23 --> Controller Class Initialized
INFO - 2022-07-12 08:56:23 --> Helper loaded: cookie_helper
INFO - 2022-07-12 08:56:23 --> Final output sent to browser
DEBUG - 2022-07-12 08:56:23 --> Total execution time: 0.0472
INFO - 2022-07-12 08:56:25 --> Config Class Initialized
INFO - 2022-07-12 08:56:25 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:25 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:25 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:25 --> URI Class Initialized
INFO - 2022-07-12 08:56:25 --> Router Class Initialized
INFO - 2022-07-12 08:56:25 --> Output Class Initialized
INFO - 2022-07-12 08:56:25 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:25 --> Input Class Initialized
INFO - 2022-07-12 08:56:25 --> Language Class Initialized
INFO - 2022-07-12 08:56:25 --> Language Class Initialized
INFO - 2022-07-12 08:56:25 --> Config Class Initialized
INFO - 2022-07-12 08:56:25 --> Loader Class Initialized
INFO - 2022-07-12 08:56:25 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:25 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:25 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:25 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:25 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:25 --> Controller Class Initialized
DEBUG - 2022-07-12 08:56:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-12 08:56:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:56:25 --> Final output sent to browser
DEBUG - 2022-07-12 08:56:25 --> Total execution time: 0.5545
INFO - 2022-07-12 08:56:27 --> Config Class Initialized
INFO - 2022-07-12 08:56:27 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:27 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:27 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:27 --> URI Class Initialized
INFO - 2022-07-12 08:56:27 --> Router Class Initialized
INFO - 2022-07-12 08:56:27 --> Output Class Initialized
INFO - 2022-07-12 08:56:27 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:27 --> Input Class Initialized
INFO - 2022-07-12 08:56:27 --> Language Class Initialized
INFO - 2022-07-12 08:56:27 --> Language Class Initialized
INFO - 2022-07-12 08:56:27 --> Config Class Initialized
INFO - 2022-07-12 08:56:27 --> Loader Class Initialized
INFO - 2022-07-12 08:56:27 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:27 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:27 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:27 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:27 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:27 --> Controller Class Initialized
DEBUG - 2022-07-12 08:56:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-12 08:56:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:56:27 --> Final output sent to browser
DEBUG - 2022-07-12 08:56:27 --> Total execution time: 0.0537
INFO - 2022-07-12 08:56:28 --> Config Class Initialized
INFO - 2022-07-12 08:56:28 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:28 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:28 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:28 --> URI Class Initialized
INFO - 2022-07-12 08:56:28 --> Router Class Initialized
INFO - 2022-07-12 08:56:28 --> Output Class Initialized
INFO - 2022-07-12 08:56:28 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:28 --> Input Class Initialized
INFO - 2022-07-12 08:56:28 --> Language Class Initialized
INFO - 2022-07-12 08:56:28 --> Language Class Initialized
INFO - 2022-07-12 08:56:28 --> Config Class Initialized
INFO - 2022-07-12 08:56:28 --> Loader Class Initialized
INFO - 2022-07-12 08:56:28 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:28 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:28 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:28 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:28 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:28 --> Controller Class Initialized
DEBUG - 2022-07-12 08:56:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-12 08:56:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:56:28 --> Final output sent to browser
DEBUG - 2022-07-12 08:56:28 --> Total execution time: 0.0782
INFO - 2022-07-12 08:56:28 --> Config Class Initialized
INFO - 2022-07-12 08:56:28 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:28 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:28 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:28 --> URI Class Initialized
INFO - 2022-07-12 08:56:28 --> Router Class Initialized
INFO - 2022-07-12 08:56:28 --> Output Class Initialized
INFO - 2022-07-12 08:56:28 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:28 --> Input Class Initialized
INFO - 2022-07-12 08:56:28 --> Language Class Initialized
INFO - 2022-07-12 08:56:28 --> Language Class Initialized
INFO - 2022-07-12 08:56:28 --> Config Class Initialized
INFO - 2022-07-12 08:56:28 --> Loader Class Initialized
INFO - 2022-07-12 08:56:28 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:28 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:28 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:28 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:28 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:28 --> Controller Class Initialized
DEBUG - 2022-07-12 08:56:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-07-12 08:56:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 08:56:28 --> Final output sent to browser
DEBUG - 2022-07-12 08:56:28 --> Total execution time: 0.0514
INFO - 2022-07-12 08:56:30 --> Config Class Initialized
INFO - 2022-07-12 08:56:30 --> Hooks Class Initialized
DEBUG - 2022-07-12 08:56:30 --> UTF-8 Support Enabled
INFO - 2022-07-12 08:56:30 --> Utf8 Class Initialized
INFO - 2022-07-12 08:56:30 --> URI Class Initialized
INFO - 2022-07-12 08:56:30 --> Router Class Initialized
INFO - 2022-07-12 08:56:30 --> Output Class Initialized
INFO - 2022-07-12 08:56:30 --> Security Class Initialized
DEBUG - 2022-07-12 08:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 08:56:30 --> Input Class Initialized
INFO - 2022-07-12 08:56:30 --> Language Class Initialized
INFO - 2022-07-12 08:56:30 --> Language Class Initialized
INFO - 2022-07-12 08:56:30 --> Config Class Initialized
INFO - 2022-07-12 08:56:30 --> Loader Class Initialized
INFO - 2022-07-12 08:56:30 --> Helper loaded: url_helper
INFO - 2022-07-12 08:56:30 --> Helper loaded: file_helper
INFO - 2022-07-12 08:56:30 --> Helper loaded: form_helper
INFO - 2022-07-12 08:56:30 --> Helper loaded: my_helper
INFO - 2022-07-12 08:56:30 --> Database Driver Class Initialized
DEBUG - 2022-07-12 08:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 08:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 08:56:30 --> Controller Class Initialized
DEBUG - 2022-07-12 08:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2022-07-12 08:56:30 --> Final output sent to browser
DEBUG - 2022-07-12 08:56:30 --> Total execution time: 0.3098
INFO - 2022-07-12 10:11:26 --> Config Class Initialized
INFO - 2022-07-12 10:11:26 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:11:26 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:11:26 --> Utf8 Class Initialized
INFO - 2022-07-12 10:11:26 --> URI Class Initialized
DEBUG - 2022-07-12 10:11:26 --> No URI present. Default controller set.
INFO - 2022-07-12 10:11:26 --> Router Class Initialized
INFO - 2022-07-12 10:11:26 --> Output Class Initialized
INFO - 2022-07-12 10:11:26 --> Security Class Initialized
DEBUG - 2022-07-12 10:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:11:26 --> Input Class Initialized
INFO - 2022-07-12 10:11:26 --> Language Class Initialized
INFO - 2022-07-12 10:11:26 --> Language Class Initialized
INFO - 2022-07-12 10:11:26 --> Config Class Initialized
INFO - 2022-07-12 10:11:26 --> Loader Class Initialized
INFO - 2022-07-12 10:11:26 --> Helper loaded: url_helper
INFO - 2022-07-12 10:11:26 --> Helper loaded: file_helper
INFO - 2022-07-12 10:11:26 --> Helper loaded: form_helper
INFO - 2022-07-12 10:11:26 --> Helper loaded: my_helper
INFO - 2022-07-12 10:11:26 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:11:26 --> Controller Class Initialized
INFO - 2022-07-12 10:11:26 --> Config Class Initialized
INFO - 2022-07-12 10:11:26 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:11:26 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:11:26 --> Utf8 Class Initialized
INFO - 2022-07-12 10:11:26 --> URI Class Initialized
INFO - 2022-07-12 10:11:26 --> Router Class Initialized
INFO - 2022-07-12 10:11:26 --> Output Class Initialized
INFO - 2022-07-12 10:11:26 --> Security Class Initialized
DEBUG - 2022-07-12 10:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:11:26 --> Input Class Initialized
INFO - 2022-07-12 10:11:26 --> Language Class Initialized
INFO - 2022-07-12 10:11:26 --> Language Class Initialized
INFO - 2022-07-12 10:11:26 --> Config Class Initialized
INFO - 2022-07-12 10:11:26 --> Loader Class Initialized
INFO - 2022-07-12 10:11:26 --> Helper loaded: url_helper
INFO - 2022-07-12 10:11:26 --> Helper loaded: file_helper
INFO - 2022-07-12 10:11:26 --> Helper loaded: form_helper
INFO - 2022-07-12 10:11:26 --> Helper loaded: my_helper
INFO - 2022-07-12 10:11:26 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:11:26 --> Controller Class Initialized
DEBUG - 2022-07-12 10:11:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-12 10:11:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:11:26 --> Final output sent to browser
DEBUG - 2022-07-12 10:11:26 --> Total execution time: 0.1030
INFO - 2022-07-12 10:14:26 --> Config Class Initialized
INFO - 2022-07-12 10:14:26 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:14:26 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:14:26 --> Utf8 Class Initialized
INFO - 2022-07-12 10:14:26 --> URI Class Initialized
INFO - 2022-07-12 10:14:26 --> Router Class Initialized
INFO - 2022-07-12 10:14:26 --> Output Class Initialized
INFO - 2022-07-12 10:14:26 --> Security Class Initialized
DEBUG - 2022-07-12 10:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:14:26 --> Input Class Initialized
INFO - 2022-07-12 10:14:26 --> Language Class Initialized
INFO - 2022-07-12 10:14:26 --> Language Class Initialized
INFO - 2022-07-12 10:14:26 --> Config Class Initialized
INFO - 2022-07-12 10:14:26 --> Loader Class Initialized
INFO - 2022-07-12 10:14:26 --> Helper loaded: url_helper
INFO - 2022-07-12 10:14:26 --> Helper loaded: file_helper
INFO - 2022-07-12 10:14:26 --> Helper loaded: form_helper
INFO - 2022-07-12 10:14:26 --> Helper loaded: my_helper
INFO - 2022-07-12 10:14:26 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:14:26 --> Controller Class Initialized
INFO - 2022-07-12 10:14:26 --> Helper loaded: cookie_helper
INFO - 2022-07-12 10:14:26 --> Final output sent to browser
DEBUG - 2022-07-12 10:14:26 --> Total execution time: 0.0993
INFO - 2022-07-12 10:14:26 --> Config Class Initialized
INFO - 2022-07-12 10:14:26 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:14:26 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:14:26 --> Utf8 Class Initialized
INFO - 2022-07-12 10:14:26 --> URI Class Initialized
INFO - 2022-07-12 10:14:26 --> Router Class Initialized
INFO - 2022-07-12 10:14:26 --> Output Class Initialized
INFO - 2022-07-12 10:14:26 --> Security Class Initialized
DEBUG - 2022-07-12 10:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:14:26 --> Input Class Initialized
INFO - 2022-07-12 10:14:26 --> Language Class Initialized
INFO - 2022-07-12 10:14:26 --> Language Class Initialized
INFO - 2022-07-12 10:14:26 --> Config Class Initialized
INFO - 2022-07-12 10:14:26 --> Loader Class Initialized
INFO - 2022-07-12 10:14:26 --> Helper loaded: url_helper
INFO - 2022-07-12 10:14:26 --> Helper loaded: file_helper
INFO - 2022-07-12 10:14:26 --> Helper loaded: form_helper
INFO - 2022-07-12 10:14:26 --> Helper loaded: my_helper
INFO - 2022-07-12 10:14:26 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:14:26 --> Controller Class Initialized
DEBUG - 2022-07-12 10:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-12 10:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:14:27 --> Final output sent to browser
DEBUG - 2022-07-12 10:14:27 --> Total execution time: 0.5903
INFO - 2022-07-12 10:14:36 --> Config Class Initialized
INFO - 2022-07-12 10:14:36 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:14:36 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:14:36 --> Utf8 Class Initialized
INFO - 2022-07-12 10:14:36 --> URI Class Initialized
INFO - 2022-07-12 10:14:36 --> Router Class Initialized
INFO - 2022-07-12 10:14:36 --> Output Class Initialized
INFO - 2022-07-12 10:14:36 --> Security Class Initialized
DEBUG - 2022-07-12 10:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:14:36 --> Input Class Initialized
INFO - 2022-07-12 10:14:36 --> Language Class Initialized
INFO - 2022-07-12 10:14:36 --> Language Class Initialized
INFO - 2022-07-12 10:14:36 --> Config Class Initialized
INFO - 2022-07-12 10:14:36 --> Loader Class Initialized
INFO - 2022-07-12 10:14:36 --> Helper loaded: url_helper
INFO - 2022-07-12 10:14:36 --> Helper loaded: file_helper
INFO - 2022-07-12 10:14:36 --> Helper loaded: form_helper
INFO - 2022-07-12 10:14:36 --> Helper loaded: my_helper
INFO - 2022-07-12 10:14:36 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:14:36 --> Controller Class Initialized
DEBUG - 2022-07-12 10:14:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 10:14:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:14:36 --> Final output sent to browser
DEBUG - 2022-07-12 10:14:36 --> Total execution time: 0.1082
INFO - 2022-07-12 10:14:36 --> Config Class Initialized
INFO - 2022-07-12 10:14:36 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:14:36 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:14:36 --> Utf8 Class Initialized
INFO - 2022-07-12 10:14:36 --> URI Class Initialized
INFO - 2022-07-12 10:14:36 --> Router Class Initialized
INFO - 2022-07-12 10:14:36 --> Output Class Initialized
INFO - 2022-07-12 10:14:36 --> Security Class Initialized
DEBUG - 2022-07-12 10:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:14:36 --> Input Class Initialized
INFO - 2022-07-12 10:14:36 --> Language Class Initialized
INFO - 2022-07-12 10:14:36 --> Language Class Initialized
INFO - 2022-07-12 10:14:36 --> Config Class Initialized
INFO - 2022-07-12 10:14:36 --> Loader Class Initialized
INFO - 2022-07-12 10:14:36 --> Helper loaded: url_helper
INFO - 2022-07-12 10:14:36 --> Helper loaded: file_helper
INFO - 2022-07-12 10:14:36 --> Helper loaded: form_helper
INFO - 2022-07-12 10:14:36 --> Helper loaded: my_helper
INFO - 2022-07-12 10:14:36 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:14:36 --> Controller Class Initialized
DEBUG - 2022-07-12 10:14:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 10:14:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:14:36 --> Final output sent to browser
DEBUG - 2022-07-12 10:14:36 --> Total execution time: 0.0487
INFO - 2022-07-12 10:25:03 --> Config Class Initialized
INFO - 2022-07-12 10:25:03 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:25:03 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:25:03 --> Utf8 Class Initialized
INFO - 2022-07-12 10:25:03 --> URI Class Initialized
INFO - 2022-07-12 10:25:03 --> Router Class Initialized
INFO - 2022-07-12 10:25:03 --> Output Class Initialized
INFO - 2022-07-12 10:25:03 --> Security Class Initialized
DEBUG - 2022-07-12 10:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:25:03 --> Input Class Initialized
INFO - 2022-07-12 10:25:03 --> Language Class Initialized
INFO - 2022-07-12 10:25:03 --> Language Class Initialized
INFO - 2022-07-12 10:25:03 --> Config Class Initialized
INFO - 2022-07-12 10:25:03 --> Loader Class Initialized
INFO - 2022-07-12 10:25:03 --> Helper loaded: url_helper
INFO - 2022-07-12 10:25:03 --> Helper loaded: file_helper
INFO - 2022-07-12 10:25:03 --> Helper loaded: form_helper
INFO - 2022-07-12 10:25:03 --> Helper loaded: my_helper
INFO - 2022-07-12 10:25:03 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:25:03 --> Controller Class Initialized
INFO - 2022-07-12 10:25:03 --> Final output sent to browser
DEBUG - 2022-07-12 10:25:03 --> Total execution time: 0.1087
INFO - 2022-07-12 10:25:03 --> Config Class Initialized
INFO - 2022-07-12 10:25:03 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:25:03 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:25:03 --> Utf8 Class Initialized
INFO - 2022-07-12 10:25:03 --> URI Class Initialized
INFO - 2022-07-12 10:25:03 --> Router Class Initialized
INFO - 2022-07-12 10:25:03 --> Output Class Initialized
INFO - 2022-07-12 10:25:03 --> Security Class Initialized
DEBUG - 2022-07-12 10:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:25:03 --> Input Class Initialized
INFO - 2022-07-12 10:25:03 --> Language Class Initialized
INFO - 2022-07-12 10:25:03 --> Language Class Initialized
INFO - 2022-07-12 10:25:03 --> Config Class Initialized
INFO - 2022-07-12 10:25:03 --> Loader Class Initialized
INFO - 2022-07-12 10:25:03 --> Helper loaded: url_helper
INFO - 2022-07-12 10:25:03 --> Helper loaded: file_helper
INFO - 2022-07-12 10:25:03 --> Helper loaded: form_helper
INFO - 2022-07-12 10:25:03 --> Helper loaded: my_helper
INFO - 2022-07-12 10:25:03 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:25:03 --> Controller Class Initialized
INFO - 2022-07-12 10:25:03 --> Final output sent to browser
DEBUG - 2022-07-12 10:25:03 --> Total execution time: 0.1094
INFO - 2022-07-12 10:25:05 --> Config Class Initialized
INFO - 2022-07-12 10:25:05 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:25:05 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:25:05 --> Utf8 Class Initialized
INFO - 2022-07-12 10:25:05 --> URI Class Initialized
INFO - 2022-07-12 10:25:05 --> Router Class Initialized
INFO - 2022-07-12 10:25:05 --> Output Class Initialized
INFO - 2022-07-12 10:25:05 --> Security Class Initialized
DEBUG - 2022-07-12 10:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:25:05 --> Input Class Initialized
INFO - 2022-07-12 10:25:05 --> Language Class Initialized
INFO - 2022-07-12 10:25:05 --> Language Class Initialized
INFO - 2022-07-12 10:25:05 --> Config Class Initialized
INFO - 2022-07-12 10:25:05 --> Loader Class Initialized
INFO - 2022-07-12 10:25:05 --> Helper loaded: url_helper
INFO - 2022-07-12 10:25:05 --> Helper loaded: file_helper
INFO - 2022-07-12 10:25:05 --> Helper loaded: form_helper
INFO - 2022-07-12 10:25:05 --> Helper loaded: my_helper
INFO - 2022-07-12 10:25:05 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:25:05 --> Controller Class Initialized
DEBUG - 2022-07-12 10:25:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-07-12 10:25:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:25:05 --> Final output sent to browser
DEBUG - 2022-07-12 10:25:05 --> Total execution time: 0.0763
INFO - 2022-07-12 10:25:17 --> Config Class Initialized
INFO - 2022-07-12 10:25:17 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:25:17 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:25:17 --> Utf8 Class Initialized
INFO - 2022-07-12 10:25:17 --> URI Class Initialized
INFO - 2022-07-12 10:25:17 --> Router Class Initialized
INFO - 2022-07-12 10:25:17 --> Output Class Initialized
INFO - 2022-07-12 10:25:17 --> Security Class Initialized
DEBUG - 2022-07-12 10:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:25:17 --> Input Class Initialized
INFO - 2022-07-12 10:25:17 --> Language Class Initialized
INFO - 2022-07-12 10:25:17 --> Language Class Initialized
INFO - 2022-07-12 10:25:17 --> Config Class Initialized
INFO - 2022-07-12 10:25:17 --> Loader Class Initialized
INFO - 2022-07-12 10:25:17 --> Helper loaded: url_helper
INFO - 2022-07-12 10:25:17 --> Helper loaded: file_helper
INFO - 2022-07-12 10:25:17 --> Helper loaded: form_helper
INFO - 2022-07-12 10:25:17 --> Helper loaded: my_helper
INFO - 2022-07-12 10:25:17 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:25:17 --> Controller Class Initialized
DEBUG - 2022-07-12 10:25:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-12 10:25:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:25:17 --> Final output sent to browser
DEBUG - 2022-07-12 10:25:17 --> Total execution time: 0.1154
INFO - 2022-07-12 10:25:28 --> Config Class Initialized
INFO - 2022-07-12 10:25:28 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:25:28 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:25:28 --> Utf8 Class Initialized
INFO - 2022-07-12 10:25:28 --> URI Class Initialized
INFO - 2022-07-12 10:25:28 --> Router Class Initialized
INFO - 2022-07-12 10:25:28 --> Output Class Initialized
INFO - 2022-07-12 10:25:28 --> Security Class Initialized
DEBUG - 2022-07-12 10:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:25:28 --> Input Class Initialized
INFO - 2022-07-12 10:25:28 --> Language Class Initialized
INFO - 2022-07-12 10:25:28 --> Language Class Initialized
INFO - 2022-07-12 10:25:28 --> Config Class Initialized
INFO - 2022-07-12 10:25:28 --> Loader Class Initialized
INFO - 2022-07-12 10:25:28 --> Helper loaded: url_helper
INFO - 2022-07-12 10:25:28 --> Helper loaded: file_helper
INFO - 2022-07-12 10:25:28 --> Helper loaded: form_helper
INFO - 2022-07-12 10:25:28 --> Helper loaded: my_helper
INFO - 2022-07-12 10:25:28 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:25:28 --> Controller Class Initialized
DEBUG - 2022-07-12 10:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2022-07-12 10:25:28 --> Final output sent to browser
DEBUG - 2022-07-12 10:25:28 --> Total execution time: 0.2911
INFO - 2022-07-12 10:26:57 --> Config Class Initialized
INFO - 2022-07-12 10:26:57 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:26:57 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:26:57 --> Utf8 Class Initialized
INFO - 2022-07-12 10:26:57 --> URI Class Initialized
INFO - 2022-07-12 10:26:57 --> Router Class Initialized
INFO - 2022-07-12 10:26:57 --> Output Class Initialized
INFO - 2022-07-12 10:26:57 --> Security Class Initialized
DEBUG - 2022-07-12 10:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:26:57 --> Input Class Initialized
INFO - 2022-07-12 10:26:57 --> Language Class Initialized
INFO - 2022-07-12 10:26:57 --> Language Class Initialized
INFO - 2022-07-12 10:26:57 --> Config Class Initialized
INFO - 2022-07-12 10:26:57 --> Loader Class Initialized
INFO - 2022-07-12 10:26:57 --> Helper loaded: url_helper
INFO - 2022-07-12 10:26:57 --> Helper loaded: file_helper
INFO - 2022-07-12 10:26:57 --> Helper loaded: form_helper
INFO - 2022-07-12 10:26:57 --> Helper loaded: my_helper
INFO - 2022-07-12 10:26:57 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:26:57 --> Controller Class Initialized
INFO - 2022-07-12 10:26:57 --> Helper loaded: cookie_helper
INFO - 2022-07-12 10:26:57 --> Config Class Initialized
INFO - 2022-07-12 10:26:57 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:26:57 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:26:57 --> Utf8 Class Initialized
INFO - 2022-07-12 10:26:57 --> URI Class Initialized
INFO - 2022-07-12 10:26:57 --> Router Class Initialized
INFO - 2022-07-12 10:26:57 --> Output Class Initialized
INFO - 2022-07-12 10:26:57 --> Security Class Initialized
DEBUG - 2022-07-12 10:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:26:57 --> Input Class Initialized
INFO - 2022-07-12 10:26:57 --> Language Class Initialized
INFO - 2022-07-12 10:26:57 --> Language Class Initialized
INFO - 2022-07-12 10:26:57 --> Config Class Initialized
INFO - 2022-07-12 10:26:57 --> Loader Class Initialized
INFO - 2022-07-12 10:26:57 --> Helper loaded: url_helper
INFO - 2022-07-12 10:26:57 --> Helper loaded: file_helper
INFO - 2022-07-12 10:26:57 --> Helper loaded: form_helper
INFO - 2022-07-12 10:26:57 --> Helper loaded: my_helper
INFO - 2022-07-12 10:26:57 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:26:57 --> Controller Class Initialized
INFO - 2022-07-12 10:26:57 --> Helper loaded: cookie_helper
INFO - 2022-07-12 10:26:57 --> Config Class Initialized
INFO - 2022-07-12 10:26:57 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:26:57 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:26:57 --> Utf8 Class Initialized
INFO - 2022-07-12 10:26:57 --> URI Class Initialized
INFO - 2022-07-12 10:26:57 --> Router Class Initialized
INFO - 2022-07-12 10:26:57 --> Output Class Initialized
INFO - 2022-07-12 10:26:57 --> Security Class Initialized
DEBUG - 2022-07-12 10:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:26:57 --> Input Class Initialized
INFO - 2022-07-12 10:26:57 --> Language Class Initialized
INFO - 2022-07-12 10:26:57 --> Language Class Initialized
INFO - 2022-07-12 10:26:57 --> Config Class Initialized
INFO - 2022-07-12 10:26:57 --> Loader Class Initialized
INFO - 2022-07-12 10:26:57 --> Helper loaded: url_helper
INFO - 2022-07-12 10:26:57 --> Helper loaded: file_helper
INFO - 2022-07-12 10:26:57 --> Helper loaded: form_helper
INFO - 2022-07-12 10:26:57 --> Helper loaded: my_helper
INFO - 2022-07-12 10:26:57 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:26:57 --> Controller Class Initialized
DEBUG - 2022-07-12 10:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-12 10:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:26:57 --> Final output sent to browser
DEBUG - 2022-07-12 10:26:57 --> Total execution time: 0.0551
INFO - 2022-07-12 10:27:02 --> Config Class Initialized
INFO - 2022-07-12 10:27:02 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:27:02 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:27:02 --> Utf8 Class Initialized
INFO - 2022-07-12 10:27:02 --> URI Class Initialized
INFO - 2022-07-12 10:27:02 --> Router Class Initialized
INFO - 2022-07-12 10:27:02 --> Output Class Initialized
INFO - 2022-07-12 10:27:02 --> Security Class Initialized
DEBUG - 2022-07-12 10:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:27:02 --> Input Class Initialized
INFO - 2022-07-12 10:27:02 --> Language Class Initialized
INFO - 2022-07-12 10:27:02 --> Language Class Initialized
INFO - 2022-07-12 10:27:02 --> Config Class Initialized
INFO - 2022-07-12 10:27:02 --> Loader Class Initialized
INFO - 2022-07-12 10:27:02 --> Helper loaded: url_helper
INFO - 2022-07-12 10:27:02 --> Helper loaded: file_helper
INFO - 2022-07-12 10:27:02 --> Helper loaded: form_helper
INFO - 2022-07-12 10:27:02 --> Helper loaded: my_helper
INFO - 2022-07-12 10:27:02 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:27:02 --> Controller Class Initialized
INFO - 2022-07-12 10:27:02 --> Helper loaded: cookie_helper
INFO - 2022-07-12 10:27:02 --> Final output sent to browser
DEBUG - 2022-07-12 10:27:02 --> Total execution time: 0.0531
INFO - 2022-07-12 10:27:02 --> Config Class Initialized
INFO - 2022-07-12 10:27:02 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:27:02 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:27:02 --> Utf8 Class Initialized
INFO - 2022-07-12 10:27:02 --> URI Class Initialized
INFO - 2022-07-12 10:27:02 --> Router Class Initialized
INFO - 2022-07-12 10:27:02 --> Output Class Initialized
INFO - 2022-07-12 10:27:02 --> Security Class Initialized
DEBUG - 2022-07-12 10:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:27:02 --> Input Class Initialized
INFO - 2022-07-12 10:27:02 --> Language Class Initialized
INFO - 2022-07-12 10:27:02 --> Language Class Initialized
INFO - 2022-07-12 10:27:02 --> Config Class Initialized
INFO - 2022-07-12 10:27:02 --> Loader Class Initialized
INFO - 2022-07-12 10:27:02 --> Helper loaded: url_helper
INFO - 2022-07-12 10:27:02 --> Helper loaded: file_helper
INFO - 2022-07-12 10:27:02 --> Helper loaded: form_helper
INFO - 2022-07-12 10:27:02 --> Helper loaded: my_helper
INFO - 2022-07-12 10:27:02 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:27:02 --> Controller Class Initialized
DEBUG - 2022-07-12 10:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-12 10:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:27:03 --> Final output sent to browser
DEBUG - 2022-07-12 10:27:03 --> Total execution time: 0.5396
INFO - 2022-07-12 10:54:31 --> Config Class Initialized
INFO - 2022-07-12 10:54:31 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:54:31 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:54:31 --> Utf8 Class Initialized
INFO - 2022-07-12 10:54:31 --> URI Class Initialized
INFO - 2022-07-12 10:54:31 --> Router Class Initialized
INFO - 2022-07-12 10:54:31 --> Output Class Initialized
INFO - 2022-07-12 10:54:31 --> Security Class Initialized
DEBUG - 2022-07-12 10:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:54:31 --> Input Class Initialized
INFO - 2022-07-12 10:54:31 --> Language Class Initialized
INFO - 2022-07-12 10:54:31 --> Language Class Initialized
INFO - 2022-07-12 10:54:31 --> Config Class Initialized
INFO - 2022-07-12 10:54:31 --> Loader Class Initialized
INFO - 2022-07-12 10:54:31 --> Helper loaded: url_helper
INFO - 2022-07-12 10:54:31 --> Helper loaded: file_helper
INFO - 2022-07-12 10:54:31 --> Helper loaded: form_helper
INFO - 2022-07-12 10:54:31 --> Helper loaded: my_helper
INFO - 2022-07-12 10:54:31 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:54:31 --> Controller Class Initialized
DEBUG - 2022-07-12 10:54:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-12 10:54:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:54:31 --> Final output sent to browser
DEBUG - 2022-07-12 10:54:31 --> Total execution time: 0.0691
INFO - 2022-07-12 10:54:31 --> Config Class Initialized
INFO - 2022-07-12 10:54:31 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:54:31 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:54:31 --> Utf8 Class Initialized
INFO - 2022-07-12 10:54:31 --> URI Class Initialized
INFO - 2022-07-12 10:54:31 --> Router Class Initialized
INFO - 2022-07-12 10:54:31 --> Output Class Initialized
INFO - 2022-07-12 10:54:31 --> Security Class Initialized
DEBUG - 2022-07-12 10:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:54:31 --> Input Class Initialized
INFO - 2022-07-12 10:54:31 --> Language Class Initialized
INFO - 2022-07-12 10:54:31 --> Language Class Initialized
INFO - 2022-07-12 10:54:31 --> Config Class Initialized
INFO - 2022-07-12 10:54:31 --> Loader Class Initialized
INFO - 2022-07-12 10:54:31 --> Helper loaded: url_helper
INFO - 2022-07-12 10:54:31 --> Helper loaded: file_helper
INFO - 2022-07-12 10:54:31 --> Helper loaded: form_helper
INFO - 2022-07-12 10:54:31 --> Helper loaded: my_helper
INFO - 2022-07-12 10:54:31 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:54:31 --> Controller Class Initialized
INFO - 2022-07-12 10:54:59 --> Config Class Initialized
INFO - 2022-07-12 10:54:59 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:54:59 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:54:59 --> Utf8 Class Initialized
INFO - 2022-07-12 10:54:59 --> URI Class Initialized
INFO - 2022-07-12 10:54:59 --> Router Class Initialized
INFO - 2022-07-12 10:54:59 --> Output Class Initialized
INFO - 2022-07-12 10:54:59 --> Security Class Initialized
DEBUG - 2022-07-12 10:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:54:59 --> Input Class Initialized
INFO - 2022-07-12 10:54:59 --> Language Class Initialized
INFO - 2022-07-12 10:54:59 --> Language Class Initialized
INFO - 2022-07-12 10:54:59 --> Config Class Initialized
INFO - 2022-07-12 10:54:59 --> Loader Class Initialized
INFO - 2022-07-12 10:54:59 --> Helper loaded: url_helper
INFO - 2022-07-12 10:54:59 --> Helper loaded: file_helper
INFO - 2022-07-12 10:54:59 --> Helper loaded: form_helper
INFO - 2022-07-12 10:54:59 --> Helper loaded: my_helper
INFO - 2022-07-12 10:54:59 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:54:59 --> Controller Class Initialized
INFO - 2022-07-12 10:54:59 --> Config Class Initialized
INFO - 2022-07-12 10:54:59 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:54:59 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:54:59 --> Utf8 Class Initialized
INFO - 2022-07-12 10:54:59 --> URI Class Initialized
INFO - 2022-07-12 10:55:00 --> Router Class Initialized
INFO - 2022-07-12 10:55:00 --> Output Class Initialized
INFO - 2022-07-12 10:55:00 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:00 --> Input Class Initialized
INFO - 2022-07-12 10:55:00 --> Language Class Initialized
INFO - 2022-07-12 10:55:00 --> Language Class Initialized
INFO - 2022-07-12 10:55:00 --> Config Class Initialized
INFO - 2022-07-12 10:55:00 --> Loader Class Initialized
INFO - 2022-07-12 10:55:00 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:00 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:00 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:00 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:00 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:00 --> Controller Class Initialized
INFO - 2022-07-12 10:55:02 --> Config Class Initialized
INFO - 2022-07-12 10:55:02 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:02 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:02 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:02 --> URI Class Initialized
INFO - 2022-07-12 10:55:02 --> Router Class Initialized
INFO - 2022-07-12 10:55:02 --> Output Class Initialized
INFO - 2022-07-12 10:55:02 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:02 --> Input Class Initialized
INFO - 2022-07-12 10:55:02 --> Language Class Initialized
INFO - 2022-07-12 10:55:02 --> Language Class Initialized
INFO - 2022-07-12 10:55:02 --> Config Class Initialized
INFO - 2022-07-12 10:55:02 --> Loader Class Initialized
INFO - 2022-07-12 10:55:02 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:02 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:02 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:02 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:02 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:02 --> Controller Class Initialized
INFO - 2022-07-12 10:55:02 --> Config Class Initialized
INFO - 2022-07-12 10:55:02 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:02 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:02 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:02 --> URI Class Initialized
INFO - 2022-07-12 10:55:02 --> Router Class Initialized
INFO - 2022-07-12 10:55:02 --> Output Class Initialized
INFO - 2022-07-12 10:55:02 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:02 --> Input Class Initialized
INFO - 2022-07-12 10:55:02 --> Language Class Initialized
INFO - 2022-07-12 10:55:02 --> Language Class Initialized
INFO - 2022-07-12 10:55:02 --> Config Class Initialized
INFO - 2022-07-12 10:55:02 --> Loader Class Initialized
INFO - 2022-07-12 10:55:02 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:02 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:02 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:02 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:02 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:02 --> Controller Class Initialized
INFO - 2022-07-12 10:55:03 --> Config Class Initialized
INFO - 2022-07-12 10:55:03 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:03 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:03 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:03 --> URI Class Initialized
INFO - 2022-07-12 10:55:03 --> Router Class Initialized
INFO - 2022-07-12 10:55:03 --> Output Class Initialized
INFO - 2022-07-12 10:55:03 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:03 --> Input Class Initialized
INFO - 2022-07-12 10:55:03 --> Language Class Initialized
INFO - 2022-07-12 10:55:03 --> Language Class Initialized
INFO - 2022-07-12 10:55:03 --> Config Class Initialized
INFO - 2022-07-12 10:55:03 --> Loader Class Initialized
INFO - 2022-07-12 10:55:03 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:03 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:03 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:03 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:03 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:03 --> Controller Class Initialized
INFO - 2022-07-12 10:55:03 --> Config Class Initialized
INFO - 2022-07-12 10:55:03 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:03 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:03 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:03 --> URI Class Initialized
INFO - 2022-07-12 10:55:03 --> Router Class Initialized
INFO - 2022-07-12 10:55:03 --> Output Class Initialized
INFO - 2022-07-12 10:55:03 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:03 --> Input Class Initialized
INFO - 2022-07-12 10:55:03 --> Language Class Initialized
INFO - 2022-07-12 10:55:03 --> Language Class Initialized
INFO - 2022-07-12 10:55:03 --> Config Class Initialized
INFO - 2022-07-12 10:55:03 --> Loader Class Initialized
INFO - 2022-07-12 10:55:03 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:03 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:03 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:03 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:03 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:03 --> Controller Class Initialized
INFO - 2022-07-12 10:55:04 --> Config Class Initialized
INFO - 2022-07-12 10:55:04 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:04 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:04 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:04 --> URI Class Initialized
INFO - 2022-07-12 10:55:04 --> Router Class Initialized
INFO - 2022-07-12 10:55:04 --> Output Class Initialized
INFO - 2022-07-12 10:55:04 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:04 --> Input Class Initialized
INFO - 2022-07-12 10:55:04 --> Language Class Initialized
INFO - 2022-07-12 10:55:04 --> Language Class Initialized
INFO - 2022-07-12 10:55:04 --> Config Class Initialized
INFO - 2022-07-12 10:55:04 --> Loader Class Initialized
INFO - 2022-07-12 10:55:04 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:04 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:04 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:04 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:04 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:04 --> Controller Class Initialized
INFO - 2022-07-12 10:55:04 --> Config Class Initialized
INFO - 2022-07-12 10:55:04 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:04 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:04 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:04 --> URI Class Initialized
INFO - 2022-07-12 10:55:04 --> Router Class Initialized
INFO - 2022-07-12 10:55:04 --> Output Class Initialized
INFO - 2022-07-12 10:55:04 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:04 --> Input Class Initialized
INFO - 2022-07-12 10:55:04 --> Language Class Initialized
INFO - 2022-07-12 10:55:04 --> Language Class Initialized
INFO - 2022-07-12 10:55:04 --> Config Class Initialized
INFO - 2022-07-12 10:55:04 --> Loader Class Initialized
INFO - 2022-07-12 10:55:04 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:04 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:04 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:04 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:04 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:04 --> Controller Class Initialized
INFO - 2022-07-12 10:55:11 --> Config Class Initialized
INFO - 2022-07-12 10:55:11 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:11 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:11 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:11 --> URI Class Initialized
INFO - 2022-07-12 10:55:11 --> Router Class Initialized
INFO - 2022-07-12 10:55:11 --> Output Class Initialized
INFO - 2022-07-12 10:55:11 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:11 --> Input Class Initialized
INFO - 2022-07-12 10:55:11 --> Language Class Initialized
INFO - 2022-07-12 10:55:11 --> Language Class Initialized
INFO - 2022-07-12 10:55:11 --> Config Class Initialized
INFO - 2022-07-12 10:55:11 --> Loader Class Initialized
INFO - 2022-07-12 10:55:11 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:11 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:11 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:11 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:11 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:12 --> Controller Class Initialized
INFO - 2022-07-12 10:55:12 --> Config Class Initialized
INFO - 2022-07-12 10:55:12 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:12 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:12 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:12 --> URI Class Initialized
INFO - 2022-07-12 10:55:12 --> Router Class Initialized
INFO - 2022-07-12 10:55:12 --> Output Class Initialized
INFO - 2022-07-12 10:55:12 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:12 --> Input Class Initialized
INFO - 2022-07-12 10:55:12 --> Language Class Initialized
INFO - 2022-07-12 10:55:12 --> Language Class Initialized
INFO - 2022-07-12 10:55:12 --> Config Class Initialized
INFO - 2022-07-12 10:55:12 --> Loader Class Initialized
INFO - 2022-07-12 10:55:12 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:12 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:12 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:12 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:12 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:12 --> Controller Class Initialized
INFO - 2022-07-12 10:55:12 --> Config Class Initialized
INFO - 2022-07-12 10:55:12 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:12 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:12 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:12 --> URI Class Initialized
INFO - 2022-07-12 10:55:12 --> Router Class Initialized
INFO - 2022-07-12 10:55:12 --> Output Class Initialized
INFO - 2022-07-12 10:55:12 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:12 --> Input Class Initialized
INFO - 2022-07-12 10:55:12 --> Language Class Initialized
INFO - 2022-07-12 10:55:12 --> Language Class Initialized
INFO - 2022-07-12 10:55:12 --> Config Class Initialized
INFO - 2022-07-12 10:55:12 --> Loader Class Initialized
INFO - 2022-07-12 10:55:12 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:12 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:12 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:12 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:12 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:13 --> Controller Class Initialized
INFO - 2022-07-12 10:55:13 --> Config Class Initialized
INFO - 2022-07-12 10:55:13 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:13 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:13 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:13 --> URI Class Initialized
INFO - 2022-07-12 10:55:13 --> Router Class Initialized
INFO - 2022-07-12 10:55:13 --> Output Class Initialized
INFO - 2022-07-12 10:55:13 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:13 --> Input Class Initialized
INFO - 2022-07-12 10:55:13 --> Language Class Initialized
INFO - 2022-07-12 10:55:13 --> Language Class Initialized
INFO - 2022-07-12 10:55:13 --> Config Class Initialized
INFO - 2022-07-12 10:55:13 --> Loader Class Initialized
INFO - 2022-07-12 10:55:13 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:13 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:13 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:13 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:13 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:13 --> Controller Class Initialized
INFO - 2022-07-12 10:55:13 --> Config Class Initialized
INFO - 2022-07-12 10:55:13 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:13 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:13 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:13 --> URI Class Initialized
INFO - 2022-07-12 10:55:13 --> Router Class Initialized
INFO - 2022-07-12 10:55:13 --> Output Class Initialized
INFO - 2022-07-12 10:55:13 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:13 --> Input Class Initialized
INFO - 2022-07-12 10:55:13 --> Language Class Initialized
INFO - 2022-07-12 10:55:13 --> Language Class Initialized
INFO - 2022-07-12 10:55:13 --> Config Class Initialized
INFO - 2022-07-12 10:55:13 --> Loader Class Initialized
INFO - 2022-07-12 10:55:13 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:13 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:13 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:13 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:13 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:13 --> Controller Class Initialized
INFO - 2022-07-12 10:55:14 --> Config Class Initialized
INFO - 2022-07-12 10:55:14 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:14 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:14 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:14 --> URI Class Initialized
INFO - 2022-07-12 10:55:14 --> Router Class Initialized
INFO - 2022-07-12 10:55:14 --> Output Class Initialized
INFO - 2022-07-12 10:55:14 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:14 --> Input Class Initialized
INFO - 2022-07-12 10:55:14 --> Language Class Initialized
INFO - 2022-07-12 10:55:14 --> Language Class Initialized
INFO - 2022-07-12 10:55:14 --> Config Class Initialized
INFO - 2022-07-12 10:55:14 --> Loader Class Initialized
INFO - 2022-07-12 10:55:14 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:14 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:14 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:14 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:14 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:14 --> Controller Class Initialized
INFO - 2022-07-12 10:55:15 --> Config Class Initialized
INFO - 2022-07-12 10:55:15 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:15 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:15 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:15 --> URI Class Initialized
INFO - 2022-07-12 10:55:15 --> Router Class Initialized
INFO - 2022-07-12 10:55:15 --> Output Class Initialized
INFO - 2022-07-12 10:55:15 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:15 --> Input Class Initialized
INFO - 2022-07-12 10:55:15 --> Language Class Initialized
INFO - 2022-07-12 10:55:15 --> Language Class Initialized
INFO - 2022-07-12 10:55:15 --> Config Class Initialized
INFO - 2022-07-12 10:55:15 --> Loader Class Initialized
INFO - 2022-07-12 10:55:15 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:15 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:15 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:15 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:15 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:15 --> Controller Class Initialized
ERROR - 2022-07-12 10:55:15 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-12 10:55:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-12 10:55:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:55:15 --> Final output sent to browser
DEBUG - 2022-07-12 10:55:15 --> Total execution time: 0.1187
INFO - 2022-07-12 10:55:20 --> Config Class Initialized
INFO - 2022-07-12 10:55:20 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:20 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:20 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:20 --> URI Class Initialized
INFO - 2022-07-12 10:55:20 --> Router Class Initialized
INFO - 2022-07-12 10:55:20 --> Output Class Initialized
INFO - 2022-07-12 10:55:20 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:20 --> Input Class Initialized
INFO - 2022-07-12 10:55:20 --> Language Class Initialized
INFO - 2022-07-12 10:55:20 --> Language Class Initialized
INFO - 2022-07-12 10:55:20 --> Config Class Initialized
INFO - 2022-07-12 10:55:20 --> Loader Class Initialized
INFO - 2022-07-12 10:55:20 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:20 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:20 --> Controller Class Initialized
INFO - 2022-07-12 10:55:20 --> Helper loaded: cookie_helper
INFO - 2022-07-12 10:55:20 --> Config Class Initialized
INFO - 2022-07-12 10:55:20 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:20 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:20 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:20 --> URI Class Initialized
INFO - 2022-07-12 10:55:20 --> Router Class Initialized
INFO - 2022-07-12 10:55:20 --> Output Class Initialized
INFO - 2022-07-12 10:55:20 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:20 --> Input Class Initialized
INFO - 2022-07-12 10:55:20 --> Language Class Initialized
INFO - 2022-07-12 10:55:20 --> Language Class Initialized
INFO - 2022-07-12 10:55:20 --> Config Class Initialized
INFO - 2022-07-12 10:55:20 --> Loader Class Initialized
INFO - 2022-07-12 10:55:20 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:20 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:20 --> Controller Class Initialized
INFO - 2022-07-12 10:55:20 --> Helper loaded: cookie_helper
INFO - 2022-07-12 10:55:20 --> Config Class Initialized
INFO - 2022-07-12 10:55:20 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:20 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:20 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:20 --> URI Class Initialized
INFO - 2022-07-12 10:55:20 --> Router Class Initialized
INFO - 2022-07-12 10:55:20 --> Output Class Initialized
INFO - 2022-07-12 10:55:20 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:20 --> Input Class Initialized
INFO - 2022-07-12 10:55:20 --> Language Class Initialized
INFO - 2022-07-12 10:55:20 --> Language Class Initialized
INFO - 2022-07-12 10:55:20 --> Config Class Initialized
INFO - 2022-07-12 10:55:20 --> Loader Class Initialized
INFO - 2022-07-12 10:55:20 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:20 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:20 --> Controller Class Initialized
INFO - 2022-07-12 10:55:20 --> Helper loaded: cookie_helper
INFO - 2022-07-12 10:55:20 --> Config Class Initialized
INFO - 2022-07-12 10:55:20 --> Hooks Class Initialized
DEBUG - 2022-07-12 10:55:20 --> UTF-8 Support Enabled
INFO - 2022-07-12 10:55:20 --> Utf8 Class Initialized
INFO - 2022-07-12 10:55:20 --> URI Class Initialized
INFO - 2022-07-12 10:55:20 --> Router Class Initialized
INFO - 2022-07-12 10:55:20 --> Output Class Initialized
INFO - 2022-07-12 10:55:20 --> Security Class Initialized
DEBUG - 2022-07-12 10:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-12 10:55:20 --> Input Class Initialized
INFO - 2022-07-12 10:55:20 --> Language Class Initialized
INFO - 2022-07-12 10:55:20 --> Language Class Initialized
INFO - 2022-07-12 10:55:20 --> Config Class Initialized
INFO - 2022-07-12 10:55:20 --> Loader Class Initialized
INFO - 2022-07-12 10:55:20 --> Helper loaded: url_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: file_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: form_helper
INFO - 2022-07-12 10:55:20 --> Helper loaded: my_helper
INFO - 2022-07-12 10:55:20 --> Database Driver Class Initialized
DEBUG - 2022-07-12 10:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-12 10:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-12 10:55:20 --> Controller Class Initialized
DEBUG - 2022-07-12 10:55:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-12 10:55:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-12 10:55:20 --> Final output sent to browser
DEBUG - 2022-07-12 10:55:20 --> Total execution time: 0.0534
