<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-08 03:28:27 --> Config Class Initialized
INFO - 2021-01-08 03:28:27 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:28:27 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:28:27 --> Utf8 Class Initialized
INFO - 2021-01-08 03:28:27 --> URI Class Initialized
DEBUG - 2021-01-08 03:28:27 --> No URI present. Default controller set.
INFO - 2021-01-08 03:28:27 --> Router Class Initialized
INFO - 2021-01-08 03:28:27 --> Output Class Initialized
INFO - 2021-01-08 03:28:27 --> Security Class Initialized
DEBUG - 2021-01-08 03:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:28:27 --> Input Class Initialized
INFO - 2021-01-08 03:28:27 --> Language Class Initialized
INFO - 2021-01-08 03:28:27 --> Language Class Initialized
INFO - 2021-01-08 03:28:27 --> Config Class Initialized
INFO - 2021-01-08 03:28:28 --> Loader Class Initialized
INFO - 2021-01-08 03:28:28 --> Helper loaded: url_helper
INFO - 2021-01-08 03:28:28 --> Helper loaded: file_helper
INFO - 2021-01-08 03:28:28 --> Helper loaded: form_helper
INFO - 2021-01-08 03:28:28 --> Helper loaded: my_helper
INFO - 2021-01-08 03:28:28 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:28:28 --> Controller Class Initialized
INFO - 2021-01-08 03:28:28 --> Config Class Initialized
INFO - 2021-01-08 03:28:28 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:28:28 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:28:28 --> Utf8 Class Initialized
INFO - 2021-01-08 03:28:28 --> URI Class Initialized
INFO - 2021-01-08 03:28:28 --> Router Class Initialized
INFO - 2021-01-08 03:28:28 --> Output Class Initialized
INFO - 2021-01-08 03:28:28 --> Security Class Initialized
DEBUG - 2021-01-08 03:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:28:28 --> Input Class Initialized
INFO - 2021-01-08 03:28:28 --> Language Class Initialized
INFO - 2021-01-08 03:28:28 --> Language Class Initialized
INFO - 2021-01-08 03:28:28 --> Config Class Initialized
INFO - 2021-01-08 03:28:28 --> Loader Class Initialized
INFO - 2021-01-08 03:28:28 --> Helper loaded: url_helper
INFO - 2021-01-08 03:28:28 --> Helper loaded: file_helper
INFO - 2021-01-08 03:28:28 --> Helper loaded: form_helper
INFO - 2021-01-08 03:28:28 --> Helper loaded: my_helper
INFO - 2021-01-08 03:28:28 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:28:28 --> Controller Class Initialized
DEBUG - 2021-01-08 03:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-08 03:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:28:28 --> Final output sent to browser
DEBUG - 2021-01-08 03:28:28 --> Total execution time: 0.2280
INFO - 2021-01-08 03:28:32 --> Config Class Initialized
INFO - 2021-01-08 03:28:32 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:28:32 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:28:32 --> Utf8 Class Initialized
INFO - 2021-01-08 03:28:32 --> URI Class Initialized
INFO - 2021-01-08 03:28:32 --> Router Class Initialized
INFO - 2021-01-08 03:28:32 --> Output Class Initialized
INFO - 2021-01-08 03:28:32 --> Security Class Initialized
DEBUG - 2021-01-08 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:28:32 --> Input Class Initialized
INFO - 2021-01-08 03:28:32 --> Language Class Initialized
INFO - 2021-01-08 03:28:32 --> Language Class Initialized
INFO - 2021-01-08 03:28:32 --> Config Class Initialized
INFO - 2021-01-08 03:28:32 --> Loader Class Initialized
INFO - 2021-01-08 03:28:32 --> Helper loaded: url_helper
INFO - 2021-01-08 03:28:32 --> Helper loaded: file_helper
INFO - 2021-01-08 03:28:32 --> Helper loaded: form_helper
INFO - 2021-01-08 03:28:32 --> Helper loaded: my_helper
INFO - 2021-01-08 03:28:32 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:28:32 --> Controller Class Initialized
INFO - 2021-01-08 03:28:32 --> Helper loaded: cookie_helper
INFO - 2021-01-08 03:28:32 --> Final output sent to browser
DEBUG - 2021-01-08 03:28:32 --> Total execution time: 0.2901
INFO - 2021-01-08 03:28:33 --> Config Class Initialized
INFO - 2021-01-08 03:28:33 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:28:33 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:28:33 --> Utf8 Class Initialized
INFO - 2021-01-08 03:28:33 --> URI Class Initialized
INFO - 2021-01-08 03:28:33 --> Router Class Initialized
INFO - 2021-01-08 03:28:33 --> Output Class Initialized
INFO - 2021-01-08 03:28:33 --> Security Class Initialized
DEBUG - 2021-01-08 03:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:28:33 --> Input Class Initialized
INFO - 2021-01-08 03:28:33 --> Language Class Initialized
INFO - 2021-01-08 03:28:33 --> Language Class Initialized
INFO - 2021-01-08 03:28:33 --> Config Class Initialized
INFO - 2021-01-08 03:28:33 --> Loader Class Initialized
INFO - 2021-01-08 03:28:33 --> Helper loaded: url_helper
INFO - 2021-01-08 03:28:33 --> Helper loaded: file_helper
INFO - 2021-01-08 03:28:33 --> Helper loaded: form_helper
INFO - 2021-01-08 03:28:33 --> Helper loaded: my_helper
INFO - 2021-01-08 03:28:33 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:28:33 --> Controller Class Initialized
DEBUG - 2021-01-08 03:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-08 03:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:28:33 --> Final output sent to browser
DEBUG - 2021-01-08 03:28:33 --> Total execution time: 0.3409
INFO - 2021-01-08 03:28:41 --> Config Class Initialized
INFO - 2021-01-08 03:28:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:28:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:28:41 --> Utf8 Class Initialized
INFO - 2021-01-08 03:28:41 --> URI Class Initialized
INFO - 2021-01-08 03:28:41 --> Router Class Initialized
INFO - 2021-01-08 03:28:41 --> Output Class Initialized
INFO - 2021-01-08 03:28:41 --> Security Class Initialized
DEBUG - 2021-01-08 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:28:41 --> Input Class Initialized
INFO - 2021-01-08 03:28:41 --> Language Class Initialized
INFO - 2021-01-08 03:28:41 --> Language Class Initialized
INFO - 2021-01-08 03:28:41 --> Config Class Initialized
INFO - 2021-01-08 03:28:41 --> Loader Class Initialized
INFO - 2021-01-08 03:28:41 --> Helper loaded: url_helper
INFO - 2021-01-08 03:28:41 --> Helper loaded: file_helper
INFO - 2021-01-08 03:28:41 --> Helper loaded: form_helper
INFO - 2021-01-08 03:28:41 --> Helper loaded: my_helper
INFO - 2021-01-08 03:28:41 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:28:41 --> Controller Class Initialized
DEBUG - 2021-01-08 03:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-08 03:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:28:41 --> Final output sent to browser
DEBUG - 2021-01-08 03:28:41 --> Total execution time: 0.3222
INFO - 2021-01-08 03:28:42 --> Config Class Initialized
INFO - 2021-01-08 03:28:42 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:28:42 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:28:42 --> Utf8 Class Initialized
INFO - 2021-01-08 03:28:42 --> URI Class Initialized
INFO - 2021-01-08 03:28:42 --> Router Class Initialized
INFO - 2021-01-08 03:28:42 --> Output Class Initialized
INFO - 2021-01-08 03:28:42 --> Security Class Initialized
DEBUG - 2021-01-08 03:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:28:42 --> Input Class Initialized
INFO - 2021-01-08 03:28:42 --> Language Class Initialized
INFO - 2021-01-08 03:28:42 --> Language Class Initialized
INFO - 2021-01-08 03:28:42 --> Config Class Initialized
INFO - 2021-01-08 03:28:42 --> Loader Class Initialized
INFO - 2021-01-08 03:28:42 --> Helper loaded: url_helper
INFO - 2021-01-08 03:28:42 --> Helper loaded: file_helper
INFO - 2021-01-08 03:28:42 --> Helper loaded: form_helper
INFO - 2021-01-08 03:28:42 --> Helper loaded: my_helper
INFO - 2021-01-08 03:28:42 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:28:43 --> Controller Class Initialized
DEBUG - 2021-01-08 03:28:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:28:43 --> Final output sent to browser
DEBUG - 2021-01-08 03:28:43 --> Total execution time: 0.2798
INFO - 2021-01-08 03:29:13 --> Config Class Initialized
INFO - 2021-01-08 03:29:13 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:29:13 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:29:13 --> Utf8 Class Initialized
INFO - 2021-01-08 03:29:13 --> URI Class Initialized
INFO - 2021-01-08 03:29:13 --> Router Class Initialized
INFO - 2021-01-08 03:29:13 --> Output Class Initialized
INFO - 2021-01-08 03:29:13 --> Security Class Initialized
DEBUG - 2021-01-08 03:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:29:13 --> Input Class Initialized
INFO - 2021-01-08 03:29:13 --> Language Class Initialized
INFO - 2021-01-08 03:29:13 --> Language Class Initialized
INFO - 2021-01-08 03:29:13 --> Config Class Initialized
INFO - 2021-01-08 03:29:13 --> Loader Class Initialized
INFO - 2021-01-08 03:29:13 --> Helper loaded: url_helper
INFO - 2021-01-08 03:29:13 --> Helper loaded: file_helper
INFO - 2021-01-08 03:29:13 --> Helper loaded: form_helper
INFO - 2021-01-08 03:29:13 --> Helper loaded: my_helper
INFO - 2021-01-08 03:29:13 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:29:13 --> Controller Class Initialized
DEBUG - 2021-01-08 03:29:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:29:13 --> Final output sent to browser
DEBUG - 2021-01-08 03:29:13 --> Total execution time: 0.2256
INFO - 2021-01-08 03:44:52 --> Config Class Initialized
INFO - 2021-01-08 03:44:52 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:44:52 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:44:52 --> Utf8 Class Initialized
INFO - 2021-01-08 03:44:52 --> URI Class Initialized
INFO - 2021-01-08 03:44:52 --> Router Class Initialized
INFO - 2021-01-08 03:44:52 --> Output Class Initialized
INFO - 2021-01-08 03:44:52 --> Security Class Initialized
DEBUG - 2021-01-08 03:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:44:52 --> Input Class Initialized
INFO - 2021-01-08 03:44:52 --> Language Class Initialized
INFO - 2021-01-08 03:44:52 --> Language Class Initialized
INFO - 2021-01-08 03:44:52 --> Config Class Initialized
INFO - 2021-01-08 03:44:52 --> Loader Class Initialized
INFO - 2021-01-08 03:44:52 --> Helper loaded: url_helper
INFO - 2021-01-08 03:44:52 --> Helper loaded: file_helper
INFO - 2021-01-08 03:44:52 --> Helper loaded: form_helper
INFO - 2021-01-08 03:44:52 --> Helper loaded: my_helper
INFO - 2021-01-08 03:44:52 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:44:52 --> Controller Class Initialized
ERROR - 2021-01-08 03:44:52 --> Query error: Unknown column 'nama_kelas' in 'where clause' - Invalid query: SELECT * FROM m_mapel INNER JOIN m_siswa WHERE kelompok = 'H' AND tambahan_sub = 'KOMPETENSI' AND nama_kelas = 'XI TKRO A'
INFO - 2021-01-08 03:44:52 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-08 03:46:24 --> Config Class Initialized
INFO - 2021-01-08 03:46:25 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:46:25 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:46:25 --> Utf8 Class Initialized
INFO - 2021-01-08 03:46:25 --> URI Class Initialized
INFO - 2021-01-08 03:46:25 --> Router Class Initialized
INFO - 2021-01-08 03:46:25 --> Output Class Initialized
INFO - 2021-01-08 03:46:25 --> Security Class Initialized
DEBUG - 2021-01-08 03:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:46:25 --> Input Class Initialized
INFO - 2021-01-08 03:46:25 --> Language Class Initialized
INFO - 2021-01-08 03:46:25 --> Language Class Initialized
INFO - 2021-01-08 03:46:25 --> Config Class Initialized
INFO - 2021-01-08 03:46:25 --> Loader Class Initialized
INFO - 2021-01-08 03:46:25 --> Helper loaded: url_helper
INFO - 2021-01-08 03:46:25 --> Helper loaded: file_helper
INFO - 2021-01-08 03:46:25 --> Helper loaded: form_helper
INFO - 2021-01-08 03:46:25 --> Helper loaded: my_helper
INFO - 2021-01-08 03:46:25 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:46:25 --> Controller Class Initialized
ERROR - 2021-01-08 03:46:25 --> Query error: Unknown column 'nama_kelas' in 'where clause' - Invalid query: SELECT * FROM m_mapel INNER JOIN m_siswa WHERE kelompok = 'H' AND tambahan_sub = 'KOMPETENSI' AND nama_kelas = 'XI TKRO A'
INFO - 2021-01-08 03:46:25 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-08 03:47:22 --> Config Class Initialized
INFO - 2021-01-08 03:47:22 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:47:22 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:47:22 --> Utf8 Class Initialized
INFO - 2021-01-08 03:47:22 --> URI Class Initialized
INFO - 2021-01-08 03:47:22 --> Router Class Initialized
INFO - 2021-01-08 03:47:22 --> Output Class Initialized
INFO - 2021-01-08 03:47:22 --> Security Class Initialized
DEBUG - 2021-01-08 03:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:47:22 --> Input Class Initialized
INFO - 2021-01-08 03:47:22 --> Language Class Initialized
INFO - 2021-01-08 03:47:22 --> Language Class Initialized
INFO - 2021-01-08 03:47:22 --> Config Class Initialized
INFO - 2021-01-08 03:47:22 --> Loader Class Initialized
INFO - 2021-01-08 03:47:23 --> Helper loaded: url_helper
INFO - 2021-01-08 03:47:23 --> Helper loaded: file_helper
INFO - 2021-01-08 03:47:23 --> Helper loaded: form_helper
INFO - 2021-01-08 03:47:23 --> Helper loaded: my_helper
INFO - 2021-01-08 03:47:23 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:47:23 --> Controller Class Initialized
ERROR - 2021-01-08 03:47:23 --> Query error: Unknown column 'nama_kelas' in 'where clause' - Invalid query: SELECT * FROM m_siswa WHERE nama_kelas = 'XI TKRO A'
INFO - 2021-01-08 03:47:23 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-08 03:50:25 --> Config Class Initialized
INFO - 2021-01-08 03:50:25 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:50:25 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:50:25 --> Utf8 Class Initialized
INFO - 2021-01-08 03:50:25 --> URI Class Initialized
INFO - 2021-01-08 03:50:25 --> Router Class Initialized
INFO - 2021-01-08 03:50:25 --> Output Class Initialized
INFO - 2021-01-08 03:50:25 --> Security Class Initialized
DEBUG - 2021-01-08 03:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:50:25 --> Input Class Initialized
INFO - 2021-01-08 03:50:25 --> Language Class Initialized
INFO - 2021-01-08 03:50:25 --> Language Class Initialized
INFO - 2021-01-08 03:50:25 --> Config Class Initialized
INFO - 2021-01-08 03:50:25 --> Loader Class Initialized
INFO - 2021-01-08 03:50:25 --> Helper loaded: url_helper
INFO - 2021-01-08 03:50:25 --> Helper loaded: file_helper
INFO - 2021-01-08 03:50:25 --> Helper loaded: form_helper
INFO - 2021-01-08 03:50:25 --> Helper loaded: my_helper
INFO - 2021-01-08 03:50:25 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:50:25 --> Controller Class Initialized
DEBUG - 2021-01-08 03:50:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:50:25 --> Final output sent to browser
DEBUG - 2021-01-08 03:50:25 --> Total execution time: 0.2376
INFO - 2021-01-08 03:53:21 --> Config Class Initialized
INFO - 2021-01-08 03:53:21 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:53:21 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:53:21 --> Utf8 Class Initialized
INFO - 2021-01-08 03:53:21 --> URI Class Initialized
INFO - 2021-01-08 03:53:21 --> Router Class Initialized
INFO - 2021-01-08 03:53:21 --> Output Class Initialized
INFO - 2021-01-08 03:53:21 --> Security Class Initialized
DEBUG - 2021-01-08 03:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:53:21 --> Input Class Initialized
INFO - 2021-01-08 03:53:21 --> Language Class Initialized
INFO - 2021-01-08 03:53:21 --> Language Class Initialized
INFO - 2021-01-08 03:53:21 --> Config Class Initialized
INFO - 2021-01-08 03:53:21 --> Loader Class Initialized
INFO - 2021-01-08 03:53:21 --> Helper loaded: url_helper
INFO - 2021-01-08 03:53:21 --> Helper loaded: file_helper
INFO - 2021-01-08 03:53:21 --> Helper loaded: form_helper
INFO - 2021-01-08 03:53:21 --> Helper loaded: my_helper
INFO - 2021-01-08 03:53:21 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:53:21 --> Controller Class Initialized
DEBUG - 2021-01-08 03:53:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:53:21 --> Final output sent to browser
DEBUG - 2021-01-08 03:53:21 --> Total execution time: 0.2288
INFO - 2021-01-08 03:53:42 --> Config Class Initialized
INFO - 2021-01-08 03:53:42 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:53:42 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:53:42 --> Utf8 Class Initialized
INFO - 2021-01-08 03:53:42 --> URI Class Initialized
INFO - 2021-01-08 03:53:42 --> Router Class Initialized
INFO - 2021-01-08 03:53:42 --> Output Class Initialized
INFO - 2021-01-08 03:53:42 --> Security Class Initialized
DEBUG - 2021-01-08 03:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:53:42 --> Input Class Initialized
INFO - 2021-01-08 03:53:42 --> Language Class Initialized
INFO - 2021-01-08 03:53:42 --> Language Class Initialized
INFO - 2021-01-08 03:53:42 --> Config Class Initialized
INFO - 2021-01-08 03:53:42 --> Loader Class Initialized
INFO - 2021-01-08 03:53:42 --> Helper loaded: url_helper
INFO - 2021-01-08 03:53:42 --> Helper loaded: file_helper
INFO - 2021-01-08 03:53:42 --> Helper loaded: form_helper
INFO - 2021-01-08 03:53:42 --> Helper loaded: my_helper
INFO - 2021-01-08 03:53:42 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:53:42 --> Controller Class Initialized
DEBUG - 2021-01-08 03:53:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:53:42 --> Final output sent to browser
DEBUG - 2021-01-08 03:53:42 --> Total execution time: 0.2424
INFO - 2021-01-08 03:54:08 --> Config Class Initialized
INFO - 2021-01-08 03:54:08 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:54:08 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:54:08 --> Utf8 Class Initialized
INFO - 2021-01-08 03:54:08 --> URI Class Initialized
INFO - 2021-01-08 03:54:08 --> Router Class Initialized
INFO - 2021-01-08 03:54:08 --> Output Class Initialized
INFO - 2021-01-08 03:54:08 --> Security Class Initialized
DEBUG - 2021-01-08 03:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:54:08 --> Input Class Initialized
INFO - 2021-01-08 03:54:08 --> Language Class Initialized
INFO - 2021-01-08 03:54:08 --> Language Class Initialized
INFO - 2021-01-08 03:54:08 --> Config Class Initialized
INFO - 2021-01-08 03:54:08 --> Loader Class Initialized
INFO - 2021-01-08 03:54:08 --> Helper loaded: url_helper
INFO - 2021-01-08 03:54:08 --> Helper loaded: file_helper
INFO - 2021-01-08 03:54:08 --> Helper loaded: form_helper
INFO - 2021-01-08 03:54:08 --> Helper loaded: my_helper
INFO - 2021-01-08 03:54:08 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:54:08 --> Controller Class Initialized
ERROR - 2021-01-08 03:54:08 --> Severity: Notice --> Undefined index: nilai_utama_tkro C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 481
DEBUG - 2021-01-08 03:54:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:54:08 --> Final output sent to browser
DEBUG - 2021-01-08 03:54:09 --> Total execution time: 0.2713
INFO - 2021-01-08 03:54:22 --> Config Class Initialized
INFO - 2021-01-08 03:54:22 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:54:22 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:54:22 --> Utf8 Class Initialized
INFO - 2021-01-08 03:54:22 --> URI Class Initialized
INFO - 2021-01-08 03:54:22 --> Router Class Initialized
INFO - 2021-01-08 03:54:22 --> Output Class Initialized
INFO - 2021-01-08 03:54:22 --> Security Class Initialized
DEBUG - 2021-01-08 03:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:54:22 --> Input Class Initialized
INFO - 2021-01-08 03:54:22 --> Language Class Initialized
INFO - 2021-01-08 03:54:22 --> Language Class Initialized
INFO - 2021-01-08 03:54:22 --> Config Class Initialized
INFO - 2021-01-08 03:54:22 --> Loader Class Initialized
INFO - 2021-01-08 03:54:22 --> Helper loaded: url_helper
INFO - 2021-01-08 03:54:22 --> Helper loaded: file_helper
INFO - 2021-01-08 03:54:22 --> Helper loaded: form_helper
INFO - 2021-01-08 03:54:22 --> Helper loaded: my_helper
INFO - 2021-01-08 03:54:22 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:54:22 --> Controller Class Initialized
INFO - 2021-01-08 03:54:22 --> Helper loaded: cookie_helper
INFO - 2021-01-08 03:54:22 --> Config Class Initialized
INFO - 2021-01-08 03:54:22 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:54:22 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:54:22 --> Utf8 Class Initialized
INFO - 2021-01-08 03:54:22 --> URI Class Initialized
INFO - 2021-01-08 03:54:22 --> Router Class Initialized
INFO - 2021-01-08 03:54:22 --> Output Class Initialized
INFO - 2021-01-08 03:54:22 --> Security Class Initialized
DEBUG - 2021-01-08 03:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:54:22 --> Input Class Initialized
INFO - 2021-01-08 03:54:22 --> Language Class Initialized
INFO - 2021-01-08 03:54:22 --> Language Class Initialized
INFO - 2021-01-08 03:54:22 --> Config Class Initialized
INFO - 2021-01-08 03:54:22 --> Loader Class Initialized
INFO - 2021-01-08 03:54:22 --> Helper loaded: url_helper
INFO - 2021-01-08 03:54:22 --> Helper loaded: file_helper
INFO - 2021-01-08 03:54:22 --> Helper loaded: form_helper
INFO - 2021-01-08 03:54:22 --> Helper loaded: my_helper
INFO - 2021-01-08 03:54:22 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:54:22 --> Controller Class Initialized
DEBUG - 2021-01-08 03:54:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-08 03:54:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:54:22 --> Final output sent to browser
DEBUG - 2021-01-08 03:54:22 --> Total execution time: 0.2434
INFO - 2021-01-08 03:54:44 --> Config Class Initialized
INFO - 2021-01-08 03:54:44 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:54:44 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:54:44 --> Utf8 Class Initialized
INFO - 2021-01-08 03:54:44 --> URI Class Initialized
INFO - 2021-01-08 03:54:44 --> Router Class Initialized
INFO - 2021-01-08 03:54:44 --> Output Class Initialized
INFO - 2021-01-08 03:54:44 --> Security Class Initialized
DEBUG - 2021-01-08 03:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:54:44 --> Input Class Initialized
INFO - 2021-01-08 03:54:44 --> Language Class Initialized
INFO - 2021-01-08 03:54:44 --> Language Class Initialized
INFO - 2021-01-08 03:54:44 --> Config Class Initialized
INFO - 2021-01-08 03:54:44 --> Loader Class Initialized
INFO - 2021-01-08 03:54:44 --> Helper loaded: url_helper
INFO - 2021-01-08 03:54:44 --> Helper loaded: file_helper
INFO - 2021-01-08 03:54:44 --> Helper loaded: form_helper
INFO - 2021-01-08 03:54:44 --> Helper loaded: my_helper
INFO - 2021-01-08 03:54:44 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:54:44 --> Controller Class Initialized
INFO - 2021-01-08 03:54:44 --> Helper loaded: cookie_helper
INFO - 2021-01-08 03:54:44 --> Final output sent to browser
DEBUG - 2021-01-08 03:54:44 --> Total execution time: 0.3376
INFO - 2021-01-08 03:54:46 --> Config Class Initialized
INFO - 2021-01-08 03:54:46 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:54:46 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:54:46 --> Utf8 Class Initialized
INFO - 2021-01-08 03:54:46 --> URI Class Initialized
INFO - 2021-01-08 03:54:46 --> Router Class Initialized
INFO - 2021-01-08 03:54:46 --> Output Class Initialized
INFO - 2021-01-08 03:54:46 --> Security Class Initialized
DEBUG - 2021-01-08 03:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:54:46 --> Input Class Initialized
INFO - 2021-01-08 03:54:46 --> Language Class Initialized
INFO - 2021-01-08 03:54:46 --> Language Class Initialized
INFO - 2021-01-08 03:54:46 --> Config Class Initialized
INFO - 2021-01-08 03:54:46 --> Loader Class Initialized
INFO - 2021-01-08 03:54:46 --> Helper loaded: url_helper
INFO - 2021-01-08 03:54:46 --> Helper loaded: file_helper
INFO - 2021-01-08 03:54:46 --> Helper loaded: form_helper
INFO - 2021-01-08 03:54:46 --> Helper loaded: my_helper
INFO - 2021-01-08 03:54:46 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:54:46 --> Controller Class Initialized
DEBUG - 2021-01-08 03:54:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-08 03:54:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:54:46 --> Final output sent to browser
DEBUG - 2021-01-08 03:54:46 --> Total execution time: 0.4005
INFO - 2021-01-08 03:54:50 --> Config Class Initialized
INFO - 2021-01-08 03:54:50 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:54:50 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:54:50 --> Utf8 Class Initialized
INFO - 2021-01-08 03:54:50 --> URI Class Initialized
INFO - 2021-01-08 03:54:50 --> Router Class Initialized
INFO - 2021-01-08 03:54:50 --> Output Class Initialized
INFO - 2021-01-08 03:54:50 --> Security Class Initialized
DEBUG - 2021-01-08 03:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:54:50 --> Input Class Initialized
INFO - 2021-01-08 03:54:50 --> Language Class Initialized
INFO - 2021-01-08 03:54:50 --> Language Class Initialized
INFO - 2021-01-08 03:54:50 --> Config Class Initialized
INFO - 2021-01-08 03:54:50 --> Loader Class Initialized
INFO - 2021-01-08 03:54:50 --> Helper loaded: url_helper
INFO - 2021-01-08 03:54:50 --> Helper loaded: file_helper
INFO - 2021-01-08 03:54:50 --> Helper loaded: form_helper
INFO - 2021-01-08 03:54:50 --> Helper loaded: my_helper
INFO - 2021-01-08 03:54:50 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:54:50 --> Controller Class Initialized
DEBUG - 2021-01-08 03:54:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-01-08 03:54:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:54:50 --> Final output sent to browser
DEBUG - 2021-01-08 03:54:50 --> Total execution time: 0.2565
INFO - 2021-01-08 03:54:52 --> Config Class Initialized
INFO - 2021-01-08 03:54:52 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:54:52 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:54:52 --> Utf8 Class Initialized
INFO - 2021-01-08 03:54:52 --> URI Class Initialized
INFO - 2021-01-08 03:54:52 --> Router Class Initialized
INFO - 2021-01-08 03:54:52 --> Output Class Initialized
INFO - 2021-01-08 03:54:52 --> Security Class Initialized
DEBUG - 2021-01-08 03:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:54:52 --> Input Class Initialized
INFO - 2021-01-08 03:54:52 --> Language Class Initialized
INFO - 2021-01-08 03:54:52 --> Language Class Initialized
INFO - 2021-01-08 03:54:52 --> Config Class Initialized
INFO - 2021-01-08 03:54:52 --> Loader Class Initialized
INFO - 2021-01-08 03:54:52 --> Helper loaded: url_helper
INFO - 2021-01-08 03:54:52 --> Helper loaded: file_helper
INFO - 2021-01-08 03:54:52 --> Helper loaded: form_helper
INFO - 2021-01-08 03:54:52 --> Helper loaded: my_helper
INFO - 2021-01-08 03:54:52 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:54:52 --> Controller Class Initialized
DEBUG - 2021-01-08 03:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-08 03:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:54:52 --> Final output sent to browser
DEBUG - 2021-01-08 03:54:52 --> Total execution time: 0.3001
INFO - 2021-01-08 03:54:53 --> Config Class Initialized
INFO - 2021-01-08 03:54:53 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:54:53 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:54:53 --> Utf8 Class Initialized
INFO - 2021-01-08 03:54:53 --> URI Class Initialized
INFO - 2021-01-08 03:54:53 --> Router Class Initialized
INFO - 2021-01-08 03:54:53 --> Output Class Initialized
INFO - 2021-01-08 03:54:53 --> Security Class Initialized
DEBUG - 2021-01-08 03:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:54:53 --> Input Class Initialized
INFO - 2021-01-08 03:54:53 --> Language Class Initialized
INFO - 2021-01-08 03:54:53 --> Language Class Initialized
INFO - 2021-01-08 03:54:53 --> Config Class Initialized
INFO - 2021-01-08 03:54:53 --> Loader Class Initialized
INFO - 2021-01-08 03:54:53 --> Helper loaded: url_helper
INFO - 2021-01-08 03:54:53 --> Helper loaded: file_helper
INFO - 2021-01-08 03:54:53 --> Helper loaded: form_helper
INFO - 2021-01-08 03:54:53 --> Helper loaded: my_helper
INFO - 2021-01-08 03:54:53 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:54:53 --> Controller Class Initialized
INFO - 2021-01-08 03:54:53 --> Config Class Initialized
INFO - 2021-01-08 03:54:53 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:54:53 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:54:53 --> Utf8 Class Initialized
INFO - 2021-01-08 03:54:54 --> URI Class Initialized
INFO - 2021-01-08 03:54:54 --> Router Class Initialized
INFO - 2021-01-08 03:54:54 --> Output Class Initialized
INFO - 2021-01-08 03:54:54 --> Security Class Initialized
DEBUG - 2021-01-08 03:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:54:54 --> Input Class Initialized
INFO - 2021-01-08 03:54:54 --> Language Class Initialized
INFO - 2021-01-08 03:54:54 --> Language Class Initialized
INFO - 2021-01-08 03:54:54 --> Config Class Initialized
INFO - 2021-01-08 03:54:54 --> Loader Class Initialized
INFO - 2021-01-08 03:54:54 --> Helper loaded: url_helper
INFO - 2021-01-08 03:54:54 --> Helper loaded: file_helper
INFO - 2021-01-08 03:54:54 --> Helper loaded: form_helper
INFO - 2021-01-08 03:54:54 --> Helper loaded: my_helper
INFO - 2021-01-08 03:54:54 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:54:54 --> Controller Class Initialized
INFO - 2021-01-08 03:54:54 --> Final output sent to browser
DEBUG - 2021-01-08 03:54:54 --> Total execution time: 0.2564
INFO - 2021-01-08 03:55:01 --> Config Class Initialized
INFO - 2021-01-08 03:55:01 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:01 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:01 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:01 --> URI Class Initialized
INFO - 2021-01-08 03:55:01 --> Router Class Initialized
INFO - 2021-01-08 03:55:01 --> Output Class Initialized
INFO - 2021-01-08 03:55:01 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:01 --> Input Class Initialized
INFO - 2021-01-08 03:55:01 --> Language Class Initialized
INFO - 2021-01-08 03:55:01 --> Language Class Initialized
INFO - 2021-01-08 03:55:01 --> Config Class Initialized
INFO - 2021-01-08 03:55:01 --> Loader Class Initialized
INFO - 2021-01-08 03:55:01 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:01 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:01 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:01 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:01 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:01 --> Controller Class Initialized
INFO - 2021-01-08 03:55:01 --> Final output sent to browser
DEBUG - 2021-01-08 03:55:01 --> Total execution time: 0.2667
INFO - 2021-01-08 03:55:01 --> Config Class Initialized
INFO - 2021-01-08 03:55:01 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:01 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:01 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:01 --> URI Class Initialized
INFO - 2021-01-08 03:55:01 --> Router Class Initialized
INFO - 2021-01-08 03:55:01 --> Output Class Initialized
INFO - 2021-01-08 03:55:01 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:01 --> Input Class Initialized
INFO - 2021-01-08 03:55:01 --> Language Class Initialized
INFO - 2021-01-08 03:55:01 --> Language Class Initialized
INFO - 2021-01-08 03:55:01 --> Config Class Initialized
INFO - 2021-01-08 03:55:01 --> Loader Class Initialized
INFO - 2021-01-08 03:55:01 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:01 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:01 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:01 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:02 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:02 --> Controller Class Initialized
INFO - 2021-01-08 03:55:05 --> Config Class Initialized
INFO - 2021-01-08 03:55:05 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:05 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:05 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:05 --> URI Class Initialized
INFO - 2021-01-08 03:55:05 --> Router Class Initialized
INFO - 2021-01-08 03:55:05 --> Output Class Initialized
INFO - 2021-01-08 03:55:05 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:05 --> Input Class Initialized
INFO - 2021-01-08 03:55:05 --> Language Class Initialized
INFO - 2021-01-08 03:55:05 --> Language Class Initialized
INFO - 2021-01-08 03:55:05 --> Config Class Initialized
INFO - 2021-01-08 03:55:05 --> Loader Class Initialized
INFO - 2021-01-08 03:55:05 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:05 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:05 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:05 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:05 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:05 --> Controller Class Initialized
INFO - 2021-01-08 03:55:05 --> Helper loaded: cookie_helper
INFO - 2021-01-08 03:55:05 --> Config Class Initialized
INFO - 2021-01-08 03:55:05 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:05 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:05 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:05 --> URI Class Initialized
INFO - 2021-01-08 03:55:05 --> Router Class Initialized
INFO - 2021-01-08 03:55:05 --> Output Class Initialized
INFO - 2021-01-08 03:55:05 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:05 --> Input Class Initialized
INFO - 2021-01-08 03:55:05 --> Language Class Initialized
INFO - 2021-01-08 03:55:05 --> Language Class Initialized
INFO - 2021-01-08 03:55:05 --> Config Class Initialized
INFO - 2021-01-08 03:55:05 --> Loader Class Initialized
INFO - 2021-01-08 03:55:05 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:05 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:05 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:05 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:05 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:05 --> Controller Class Initialized
DEBUG - 2021-01-08 03:55:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-08 03:55:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:55:05 --> Final output sent to browser
DEBUG - 2021-01-08 03:55:05 --> Total execution time: 0.2358
INFO - 2021-01-08 03:55:12 --> Config Class Initialized
INFO - 2021-01-08 03:55:12 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:12 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:12 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:12 --> URI Class Initialized
INFO - 2021-01-08 03:55:12 --> Router Class Initialized
INFO - 2021-01-08 03:55:12 --> Output Class Initialized
INFO - 2021-01-08 03:55:12 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:12 --> Input Class Initialized
INFO - 2021-01-08 03:55:12 --> Language Class Initialized
INFO - 2021-01-08 03:55:12 --> Language Class Initialized
INFO - 2021-01-08 03:55:12 --> Config Class Initialized
INFO - 2021-01-08 03:55:12 --> Loader Class Initialized
INFO - 2021-01-08 03:55:12 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:12 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:12 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:12 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:12 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:12 --> Controller Class Initialized
INFO - 2021-01-08 03:55:12 --> Final output sent to browser
DEBUG - 2021-01-08 03:55:12 --> Total execution time: 0.3121
INFO - 2021-01-08 03:55:17 --> Config Class Initialized
INFO - 2021-01-08 03:55:17 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:17 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:17 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:17 --> URI Class Initialized
INFO - 2021-01-08 03:55:17 --> Router Class Initialized
INFO - 2021-01-08 03:55:17 --> Output Class Initialized
INFO - 2021-01-08 03:55:17 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:17 --> Input Class Initialized
INFO - 2021-01-08 03:55:17 --> Language Class Initialized
INFO - 2021-01-08 03:55:17 --> Language Class Initialized
INFO - 2021-01-08 03:55:17 --> Config Class Initialized
INFO - 2021-01-08 03:55:17 --> Loader Class Initialized
INFO - 2021-01-08 03:55:17 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:17 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:17 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:17 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:17 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:17 --> Controller Class Initialized
INFO - 2021-01-08 03:55:17 --> Helper loaded: cookie_helper
INFO - 2021-01-08 03:55:17 --> Final output sent to browser
DEBUG - 2021-01-08 03:55:17 --> Total execution time: 0.3239
INFO - 2021-01-08 03:55:18 --> Config Class Initialized
INFO - 2021-01-08 03:55:18 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:18 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:18 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:18 --> URI Class Initialized
INFO - 2021-01-08 03:55:18 --> Router Class Initialized
INFO - 2021-01-08 03:55:18 --> Output Class Initialized
INFO - 2021-01-08 03:55:18 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:18 --> Input Class Initialized
INFO - 2021-01-08 03:55:18 --> Language Class Initialized
INFO - 2021-01-08 03:55:18 --> Language Class Initialized
INFO - 2021-01-08 03:55:18 --> Config Class Initialized
INFO - 2021-01-08 03:55:18 --> Loader Class Initialized
INFO - 2021-01-08 03:55:18 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:18 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:18 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:18 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:18 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:18 --> Controller Class Initialized
DEBUG - 2021-01-08 03:55:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-08 03:55:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:55:18 --> Final output sent to browser
DEBUG - 2021-01-08 03:55:18 --> Total execution time: 0.3917
INFO - 2021-01-08 03:55:20 --> Config Class Initialized
INFO - 2021-01-08 03:55:20 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:20 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:20 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:20 --> URI Class Initialized
INFO - 2021-01-08 03:55:20 --> Router Class Initialized
INFO - 2021-01-08 03:55:20 --> Output Class Initialized
INFO - 2021-01-08 03:55:20 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:20 --> Input Class Initialized
INFO - 2021-01-08 03:55:20 --> Language Class Initialized
INFO - 2021-01-08 03:55:20 --> Language Class Initialized
INFO - 2021-01-08 03:55:20 --> Config Class Initialized
INFO - 2021-01-08 03:55:20 --> Loader Class Initialized
INFO - 2021-01-08 03:55:20 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:21 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:21 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:21 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:21 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:21 --> Controller Class Initialized
DEBUG - 2021-01-08 03:55:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-08 03:55:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 03:55:21 --> Final output sent to browser
DEBUG - 2021-01-08 03:55:21 --> Total execution time: 0.2899
INFO - 2021-01-08 03:55:22 --> Config Class Initialized
INFO - 2021-01-08 03:55:22 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:22 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:22 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:22 --> URI Class Initialized
INFO - 2021-01-08 03:55:22 --> Router Class Initialized
INFO - 2021-01-08 03:55:22 --> Output Class Initialized
INFO - 2021-01-08 03:55:22 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:22 --> Input Class Initialized
INFO - 2021-01-08 03:55:22 --> Language Class Initialized
INFO - 2021-01-08 03:55:22 --> Language Class Initialized
INFO - 2021-01-08 03:55:22 --> Config Class Initialized
INFO - 2021-01-08 03:55:22 --> Loader Class Initialized
INFO - 2021-01-08 03:55:22 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:22 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:22 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:22 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:22 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:22 --> Controller Class Initialized
ERROR - 2021-01-08 03:55:22 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 258
ERROR - 2021-01-08 03:55:22 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 258
ERROR - 2021-01-08 03:55:22 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 260
ERROR - 2021-01-08 03:55:22 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-08 03:55:22 --> Severity: Notice --> Undefined index: nilai_utama_tkro C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 481
DEBUG - 2021-01-08 03:55:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:55:22 --> Final output sent to browser
DEBUG - 2021-01-08 03:55:22 --> Total execution time: 0.3632
INFO - 2021-01-08 03:55:52 --> Config Class Initialized
INFO - 2021-01-08 03:55:52 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:55:52 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:55:52 --> Utf8 Class Initialized
INFO - 2021-01-08 03:55:52 --> URI Class Initialized
INFO - 2021-01-08 03:55:52 --> Router Class Initialized
INFO - 2021-01-08 03:55:52 --> Output Class Initialized
INFO - 2021-01-08 03:55:52 --> Security Class Initialized
DEBUG - 2021-01-08 03:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:55:52 --> Input Class Initialized
INFO - 2021-01-08 03:55:52 --> Language Class Initialized
INFO - 2021-01-08 03:55:52 --> Language Class Initialized
INFO - 2021-01-08 03:55:52 --> Config Class Initialized
INFO - 2021-01-08 03:55:52 --> Loader Class Initialized
INFO - 2021-01-08 03:55:52 --> Helper loaded: url_helper
INFO - 2021-01-08 03:55:52 --> Helper loaded: file_helper
INFO - 2021-01-08 03:55:52 --> Helper loaded: form_helper
INFO - 2021-01-08 03:55:52 --> Helper loaded: my_helper
INFO - 2021-01-08 03:55:52 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:55:52 --> Controller Class Initialized
ERROR - 2021-01-08 03:55:52 --> Severity: Notice --> Undefined index: nilai_utama_tkro C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 481
DEBUG - 2021-01-08 03:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:55:52 --> Final output sent to browser
DEBUG - 2021-01-08 03:55:52 --> Total execution time: 0.2534
INFO - 2021-01-08 03:57:17 --> Config Class Initialized
INFO - 2021-01-08 03:57:17 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:57:17 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:57:17 --> Utf8 Class Initialized
INFO - 2021-01-08 03:57:17 --> URI Class Initialized
INFO - 2021-01-08 03:57:17 --> Router Class Initialized
INFO - 2021-01-08 03:57:17 --> Output Class Initialized
INFO - 2021-01-08 03:57:17 --> Security Class Initialized
DEBUG - 2021-01-08 03:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:57:17 --> Input Class Initialized
INFO - 2021-01-08 03:57:17 --> Language Class Initialized
INFO - 2021-01-08 03:57:17 --> Language Class Initialized
INFO - 2021-01-08 03:57:17 --> Config Class Initialized
INFO - 2021-01-08 03:57:17 --> Loader Class Initialized
INFO - 2021-01-08 03:57:17 --> Helper loaded: url_helper
INFO - 2021-01-08 03:57:17 --> Helper loaded: file_helper
INFO - 2021-01-08 03:57:17 --> Helper loaded: form_helper
INFO - 2021-01-08 03:57:17 --> Helper loaded: my_helper
INFO - 2021-01-08 03:57:17 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:57:17 --> Controller Class Initialized
ERROR - 2021-01-08 03:57:17 --> Severity: Notice --> Undefined index: nilai_utama_tkro C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 481
DEBUG - 2021-01-08 03:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:57:17 --> Final output sent to browser
DEBUG - 2021-01-08 03:57:17 --> Total execution time: 0.2487
INFO - 2021-01-08 03:57:30 --> Config Class Initialized
INFO - 2021-01-08 03:57:30 --> Hooks Class Initialized
DEBUG - 2021-01-08 03:57:30 --> UTF-8 Support Enabled
INFO - 2021-01-08 03:57:30 --> Utf8 Class Initialized
INFO - 2021-01-08 03:57:30 --> URI Class Initialized
INFO - 2021-01-08 03:57:30 --> Router Class Initialized
INFO - 2021-01-08 03:57:30 --> Output Class Initialized
INFO - 2021-01-08 03:57:30 --> Security Class Initialized
DEBUG - 2021-01-08 03:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 03:57:30 --> Input Class Initialized
INFO - 2021-01-08 03:57:30 --> Language Class Initialized
INFO - 2021-01-08 03:57:30 --> Language Class Initialized
INFO - 2021-01-08 03:57:31 --> Config Class Initialized
INFO - 2021-01-08 03:57:31 --> Loader Class Initialized
INFO - 2021-01-08 03:57:31 --> Helper loaded: url_helper
INFO - 2021-01-08 03:57:31 --> Helper loaded: file_helper
INFO - 2021-01-08 03:57:31 --> Helper loaded: form_helper
INFO - 2021-01-08 03:57:31 --> Helper loaded: my_helper
INFO - 2021-01-08 03:57:31 --> Database Driver Class Initialized
DEBUG - 2021-01-08 03:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 03:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 03:57:31 --> Controller Class Initialized
DEBUG - 2021-01-08 03:57:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 03:57:31 --> Final output sent to browser
DEBUG - 2021-01-08 03:57:31 --> Total execution time: 0.2557
INFO - 2021-01-08 04:10:02 --> Config Class Initialized
INFO - 2021-01-08 04:10:02 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:10:02 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:10:02 --> Utf8 Class Initialized
INFO - 2021-01-08 04:10:02 --> URI Class Initialized
INFO - 2021-01-08 04:10:02 --> Router Class Initialized
INFO - 2021-01-08 04:10:02 --> Output Class Initialized
INFO - 2021-01-08 04:10:02 --> Security Class Initialized
DEBUG - 2021-01-08 04:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:10:02 --> Input Class Initialized
INFO - 2021-01-08 04:10:02 --> Language Class Initialized
INFO - 2021-01-08 04:10:02 --> Language Class Initialized
INFO - 2021-01-08 04:10:02 --> Config Class Initialized
INFO - 2021-01-08 04:10:02 --> Loader Class Initialized
INFO - 2021-01-08 04:10:02 --> Helper loaded: url_helper
INFO - 2021-01-08 04:10:02 --> Helper loaded: file_helper
INFO - 2021-01-08 04:10:02 --> Helper loaded: form_helper
INFO - 2021-01-08 04:10:02 --> Helper loaded: my_helper
INFO - 2021-01-08 04:10:02 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:10:02 --> Controller Class Initialized
DEBUG - 2021-01-08 04:10:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:10:02 --> Final output sent to browser
DEBUG - 2021-01-08 04:10:02 --> Total execution time: 0.2512
INFO - 2021-01-08 04:10:59 --> Config Class Initialized
INFO - 2021-01-08 04:10:59 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:10:59 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:10:59 --> Utf8 Class Initialized
INFO - 2021-01-08 04:10:59 --> URI Class Initialized
INFO - 2021-01-08 04:10:59 --> Router Class Initialized
INFO - 2021-01-08 04:10:59 --> Output Class Initialized
INFO - 2021-01-08 04:10:59 --> Security Class Initialized
DEBUG - 2021-01-08 04:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:10:59 --> Input Class Initialized
INFO - 2021-01-08 04:10:59 --> Language Class Initialized
INFO - 2021-01-08 04:10:59 --> Language Class Initialized
INFO - 2021-01-08 04:10:59 --> Config Class Initialized
INFO - 2021-01-08 04:10:59 --> Loader Class Initialized
INFO - 2021-01-08 04:10:59 --> Helper loaded: url_helper
INFO - 2021-01-08 04:10:59 --> Helper loaded: file_helper
INFO - 2021-01-08 04:10:59 --> Helper loaded: form_helper
INFO - 2021-01-08 04:10:59 --> Helper loaded: my_helper
INFO - 2021-01-08 04:10:59 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:10:59 --> Controller Class Initialized
DEBUG - 2021-01-08 04:10:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:10:59 --> Final output sent to browser
DEBUG - 2021-01-08 04:10:59 --> Total execution time: 0.2422
INFO - 2021-01-08 04:11:49 --> Config Class Initialized
INFO - 2021-01-08 04:11:49 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:11:49 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:11:49 --> Utf8 Class Initialized
INFO - 2021-01-08 04:11:49 --> URI Class Initialized
INFO - 2021-01-08 04:11:49 --> Router Class Initialized
INFO - 2021-01-08 04:11:49 --> Output Class Initialized
INFO - 2021-01-08 04:11:49 --> Security Class Initialized
DEBUG - 2021-01-08 04:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:11:49 --> Input Class Initialized
INFO - 2021-01-08 04:11:49 --> Language Class Initialized
INFO - 2021-01-08 04:11:49 --> Language Class Initialized
INFO - 2021-01-08 04:11:49 --> Config Class Initialized
INFO - 2021-01-08 04:11:49 --> Loader Class Initialized
INFO - 2021-01-08 04:11:49 --> Helper loaded: url_helper
INFO - 2021-01-08 04:11:49 --> Helper loaded: file_helper
INFO - 2021-01-08 04:11:49 --> Helper loaded: form_helper
INFO - 2021-01-08 04:11:49 --> Helper loaded: my_helper
INFO - 2021-01-08 04:11:49 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:11:49 --> Controller Class Initialized
DEBUG - 2021-01-08 04:11:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:11:49 --> Final output sent to browser
DEBUG - 2021-01-08 04:11:49 --> Total execution time: 0.2429
INFO - 2021-01-08 04:12:11 --> Config Class Initialized
INFO - 2021-01-08 04:12:11 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:12:11 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:12:11 --> Utf8 Class Initialized
INFO - 2021-01-08 04:12:11 --> URI Class Initialized
INFO - 2021-01-08 04:12:11 --> Router Class Initialized
INFO - 2021-01-08 04:12:11 --> Output Class Initialized
INFO - 2021-01-08 04:12:11 --> Security Class Initialized
DEBUG - 2021-01-08 04:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:12:12 --> Input Class Initialized
INFO - 2021-01-08 04:12:12 --> Language Class Initialized
ERROR - 2021-01-08 04:12:12 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 516
INFO - 2021-01-08 04:12:25 --> Config Class Initialized
INFO - 2021-01-08 04:12:25 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:12:25 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:12:25 --> Utf8 Class Initialized
INFO - 2021-01-08 04:12:25 --> URI Class Initialized
INFO - 2021-01-08 04:12:25 --> Router Class Initialized
INFO - 2021-01-08 04:12:25 --> Output Class Initialized
INFO - 2021-01-08 04:12:25 --> Security Class Initialized
DEBUG - 2021-01-08 04:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:12:25 --> Input Class Initialized
INFO - 2021-01-08 04:12:25 --> Language Class Initialized
INFO - 2021-01-08 04:12:25 --> Language Class Initialized
INFO - 2021-01-08 04:12:25 --> Config Class Initialized
INFO - 2021-01-08 04:12:25 --> Loader Class Initialized
INFO - 2021-01-08 04:12:25 --> Helper loaded: url_helper
INFO - 2021-01-08 04:12:25 --> Helper loaded: file_helper
INFO - 2021-01-08 04:12:25 --> Helper loaded: form_helper
INFO - 2021-01-08 04:12:25 --> Helper loaded: my_helper
INFO - 2021-01-08 04:12:25 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:12:25 --> Controller Class Initialized
DEBUG - 2021-01-08 04:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:12:25 --> Final output sent to browser
DEBUG - 2021-01-08 04:12:25 --> Total execution time: 0.2766
INFO - 2021-01-08 04:13:38 --> Config Class Initialized
INFO - 2021-01-08 04:13:38 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:13:38 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:13:38 --> Utf8 Class Initialized
INFO - 2021-01-08 04:13:38 --> URI Class Initialized
INFO - 2021-01-08 04:13:38 --> Router Class Initialized
INFO - 2021-01-08 04:13:38 --> Output Class Initialized
INFO - 2021-01-08 04:13:38 --> Security Class Initialized
DEBUG - 2021-01-08 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:13:38 --> Input Class Initialized
INFO - 2021-01-08 04:13:38 --> Language Class Initialized
INFO - 2021-01-08 04:13:38 --> Language Class Initialized
INFO - 2021-01-08 04:13:38 --> Config Class Initialized
INFO - 2021-01-08 04:13:38 --> Loader Class Initialized
INFO - 2021-01-08 04:13:38 --> Helper loaded: url_helper
INFO - 2021-01-08 04:13:38 --> Helper loaded: file_helper
INFO - 2021-01-08 04:13:39 --> Helper loaded: form_helper
INFO - 2021-01-08 04:13:39 --> Helper loaded: my_helper
INFO - 2021-01-08 04:13:39 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:13:39 --> Controller Class Initialized
DEBUG - 2021-01-08 04:13:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:13:39 --> Final output sent to browser
DEBUG - 2021-01-08 04:13:39 --> Total execution time: 0.2546
INFO - 2021-01-08 04:13:41 --> Config Class Initialized
INFO - 2021-01-08 04:13:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:13:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:13:41 --> Utf8 Class Initialized
INFO - 2021-01-08 04:13:41 --> URI Class Initialized
INFO - 2021-01-08 04:13:41 --> Router Class Initialized
INFO - 2021-01-08 04:13:41 --> Output Class Initialized
INFO - 2021-01-08 04:13:41 --> Security Class Initialized
DEBUG - 2021-01-08 04:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:13:41 --> Input Class Initialized
INFO - 2021-01-08 04:13:41 --> Language Class Initialized
INFO - 2021-01-08 04:13:41 --> Language Class Initialized
INFO - 2021-01-08 04:13:41 --> Config Class Initialized
INFO - 2021-01-08 04:13:41 --> Loader Class Initialized
INFO - 2021-01-08 04:13:41 --> Helper loaded: url_helper
INFO - 2021-01-08 04:13:41 --> Helper loaded: file_helper
INFO - 2021-01-08 04:13:41 --> Helper loaded: form_helper
INFO - 2021-01-08 04:13:41 --> Helper loaded: my_helper
INFO - 2021-01-08 04:13:41 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:13:41 --> Controller Class Initialized
ERROR - 2021-01-08 04:13:41 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 258
ERROR - 2021-01-08 04:13:41 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 258
ERROR - 2021-01-08 04:13:41 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 260
ERROR - 2021-01-08 04:13:41 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
DEBUG - 2021-01-08 04:13:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:13:41 --> Final output sent to browser
DEBUG - 2021-01-08 04:13:41 --> Total execution time: 0.3181
INFO - 2021-01-08 04:15:24 --> Config Class Initialized
INFO - 2021-01-08 04:15:24 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:15:24 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:15:24 --> Utf8 Class Initialized
INFO - 2021-01-08 04:15:24 --> URI Class Initialized
INFO - 2021-01-08 04:15:24 --> Router Class Initialized
INFO - 2021-01-08 04:15:24 --> Output Class Initialized
INFO - 2021-01-08 04:15:24 --> Security Class Initialized
DEBUG - 2021-01-08 04:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:15:24 --> Input Class Initialized
INFO - 2021-01-08 04:15:24 --> Language Class Initialized
INFO - 2021-01-08 04:15:24 --> Language Class Initialized
INFO - 2021-01-08 04:15:24 --> Config Class Initialized
INFO - 2021-01-08 04:15:24 --> Loader Class Initialized
INFO - 2021-01-08 04:15:24 --> Helper loaded: url_helper
INFO - 2021-01-08 04:15:24 --> Helper loaded: file_helper
INFO - 2021-01-08 04:15:24 --> Helper loaded: form_helper
INFO - 2021-01-08 04:15:24 --> Helper loaded: my_helper
INFO - 2021-01-08 04:15:24 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:15:24 --> Controller Class Initialized
ERROR - 2021-01-08 04:15:24 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 258
ERROR - 2021-01-08 04:15:24 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 258
ERROR - 2021-01-08 04:15:24 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 260
ERROR - 2021-01-08 04:15:24 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
DEBUG - 2021-01-08 04:15:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:15:24 --> Final output sent to browser
DEBUG - 2021-01-08 04:15:24 --> Total execution time: 0.3079
INFO - 2021-01-08 04:16:41 --> Config Class Initialized
INFO - 2021-01-08 04:16:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:16:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:16:41 --> Utf8 Class Initialized
INFO - 2021-01-08 04:16:41 --> URI Class Initialized
INFO - 2021-01-08 04:16:41 --> Router Class Initialized
INFO - 2021-01-08 04:16:41 --> Output Class Initialized
INFO - 2021-01-08 04:16:41 --> Security Class Initialized
DEBUG - 2021-01-08 04:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:16:41 --> Input Class Initialized
INFO - 2021-01-08 04:16:41 --> Language Class Initialized
INFO - 2021-01-08 04:16:41 --> Language Class Initialized
INFO - 2021-01-08 04:16:41 --> Config Class Initialized
INFO - 2021-01-08 04:16:41 --> Loader Class Initialized
INFO - 2021-01-08 04:16:41 --> Helper loaded: url_helper
INFO - 2021-01-08 04:16:41 --> Helper loaded: file_helper
INFO - 2021-01-08 04:16:41 --> Helper loaded: form_helper
INFO - 2021-01-08 04:16:41 --> Helper loaded: my_helper
INFO - 2021-01-08 04:16:41 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:16:41 --> Controller Class Initialized
INFO - 2021-01-08 04:16:41 --> Helper loaded: cookie_helper
INFO - 2021-01-08 04:16:41 --> Config Class Initialized
INFO - 2021-01-08 04:16:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:16:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:16:41 --> Utf8 Class Initialized
INFO - 2021-01-08 04:16:41 --> URI Class Initialized
INFO - 2021-01-08 04:16:41 --> Router Class Initialized
INFO - 2021-01-08 04:16:41 --> Output Class Initialized
INFO - 2021-01-08 04:16:41 --> Security Class Initialized
DEBUG - 2021-01-08 04:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:16:41 --> Input Class Initialized
INFO - 2021-01-08 04:16:41 --> Language Class Initialized
INFO - 2021-01-08 04:16:41 --> Language Class Initialized
INFO - 2021-01-08 04:16:41 --> Config Class Initialized
INFO - 2021-01-08 04:16:41 --> Loader Class Initialized
INFO - 2021-01-08 04:16:41 --> Helper loaded: url_helper
INFO - 2021-01-08 04:16:41 --> Helper loaded: file_helper
INFO - 2021-01-08 04:16:41 --> Helper loaded: form_helper
INFO - 2021-01-08 04:16:41 --> Helper loaded: my_helper
INFO - 2021-01-08 04:16:42 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:16:42 --> Controller Class Initialized
DEBUG - 2021-01-08 04:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-08 04:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:16:42 --> Final output sent to browser
DEBUG - 2021-01-08 04:16:42 --> Total execution time: 0.2848
INFO - 2021-01-08 04:16:50 --> Config Class Initialized
INFO - 2021-01-08 04:16:50 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:16:50 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:16:50 --> Utf8 Class Initialized
INFO - 2021-01-08 04:16:50 --> URI Class Initialized
INFO - 2021-01-08 04:16:50 --> Router Class Initialized
INFO - 2021-01-08 04:16:50 --> Output Class Initialized
INFO - 2021-01-08 04:16:50 --> Security Class Initialized
DEBUG - 2021-01-08 04:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:16:50 --> Input Class Initialized
INFO - 2021-01-08 04:16:50 --> Language Class Initialized
INFO - 2021-01-08 04:16:50 --> Language Class Initialized
INFO - 2021-01-08 04:16:50 --> Config Class Initialized
INFO - 2021-01-08 04:16:50 --> Loader Class Initialized
INFO - 2021-01-08 04:16:50 --> Helper loaded: url_helper
INFO - 2021-01-08 04:16:50 --> Helper loaded: file_helper
INFO - 2021-01-08 04:16:50 --> Helper loaded: form_helper
INFO - 2021-01-08 04:16:50 --> Helper loaded: my_helper
INFO - 2021-01-08 04:16:50 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:16:50 --> Controller Class Initialized
INFO - 2021-01-08 04:16:50 --> Helper loaded: cookie_helper
INFO - 2021-01-08 04:16:50 --> Final output sent to browser
DEBUG - 2021-01-08 04:16:50 --> Total execution time: 0.3347
INFO - 2021-01-08 04:16:50 --> Config Class Initialized
INFO - 2021-01-08 04:16:50 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:16:50 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:16:50 --> Utf8 Class Initialized
INFO - 2021-01-08 04:16:50 --> URI Class Initialized
INFO - 2021-01-08 04:16:50 --> Router Class Initialized
INFO - 2021-01-08 04:16:50 --> Output Class Initialized
INFO - 2021-01-08 04:16:50 --> Security Class Initialized
DEBUG - 2021-01-08 04:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:16:50 --> Input Class Initialized
INFO - 2021-01-08 04:16:50 --> Language Class Initialized
INFO - 2021-01-08 04:16:51 --> Language Class Initialized
INFO - 2021-01-08 04:16:51 --> Config Class Initialized
INFO - 2021-01-08 04:16:51 --> Loader Class Initialized
INFO - 2021-01-08 04:16:51 --> Helper loaded: url_helper
INFO - 2021-01-08 04:16:51 --> Helper loaded: file_helper
INFO - 2021-01-08 04:16:51 --> Helper loaded: form_helper
INFO - 2021-01-08 04:16:51 --> Helper loaded: my_helper
INFO - 2021-01-08 04:16:51 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:16:51 --> Controller Class Initialized
DEBUG - 2021-01-08 04:16:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-08 04:16:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:16:51 --> Final output sent to browser
DEBUG - 2021-01-08 04:16:51 --> Total execution time: 0.4269
INFO - 2021-01-08 04:16:54 --> Config Class Initialized
INFO - 2021-01-08 04:16:54 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:16:54 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:16:54 --> Utf8 Class Initialized
INFO - 2021-01-08 04:16:54 --> URI Class Initialized
INFO - 2021-01-08 04:16:54 --> Router Class Initialized
INFO - 2021-01-08 04:16:54 --> Output Class Initialized
INFO - 2021-01-08 04:16:54 --> Security Class Initialized
DEBUG - 2021-01-08 04:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:16:54 --> Input Class Initialized
INFO - 2021-01-08 04:16:54 --> Language Class Initialized
INFO - 2021-01-08 04:16:54 --> Language Class Initialized
INFO - 2021-01-08 04:16:54 --> Config Class Initialized
INFO - 2021-01-08 04:16:54 --> Loader Class Initialized
INFO - 2021-01-08 04:16:54 --> Helper loaded: url_helper
INFO - 2021-01-08 04:16:54 --> Helper loaded: file_helper
INFO - 2021-01-08 04:16:54 --> Helper loaded: form_helper
INFO - 2021-01-08 04:16:54 --> Helper loaded: my_helper
INFO - 2021-01-08 04:16:54 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:16:54 --> Controller Class Initialized
DEBUG - 2021-01-08 04:16:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-08 04:16:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:16:54 --> Final output sent to browser
DEBUG - 2021-01-08 04:16:54 --> Total execution time: 0.2756
INFO - 2021-01-08 04:16:56 --> Config Class Initialized
INFO - 2021-01-08 04:16:56 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:16:56 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:16:56 --> Utf8 Class Initialized
INFO - 2021-01-08 04:16:56 --> URI Class Initialized
INFO - 2021-01-08 04:16:56 --> Router Class Initialized
INFO - 2021-01-08 04:16:56 --> Output Class Initialized
INFO - 2021-01-08 04:16:56 --> Security Class Initialized
DEBUG - 2021-01-08 04:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:16:56 --> Input Class Initialized
INFO - 2021-01-08 04:16:56 --> Language Class Initialized
INFO - 2021-01-08 04:16:56 --> Language Class Initialized
INFO - 2021-01-08 04:16:56 --> Config Class Initialized
INFO - 2021-01-08 04:16:56 --> Loader Class Initialized
INFO - 2021-01-08 04:16:56 --> Helper loaded: url_helper
INFO - 2021-01-08 04:16:56 --> Helper loaded: file_helper
INFO - 2021-01-08 04:16:56 --> Helper loaded: form_helper
INFO - 2021-01-08 04:16:56 --> Helper loaded: my_helper
INFO - 2021-01-08 04:16:56 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:16:56 --> Controller Class Initialized
INFO - 2021-01-08 04:16:56 --> Helper loaded: cookie_helper
INFO - 2021-01-08 04:16:56 --> Config Class Initialized
INFO - 2021-01-08 04:16:56 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:16:56 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:16:56 --> Utf8 Class Initialized
INFO - 2021-01-08 04:16:56 --> URI Class Initialized
INFO - 2021-01-08 04:16:56 --> Router Class Initialized
INFO - 2021-01-08 04:16:56 --> Output Class Initialized
INFO - 2021-01-08 04:16:56 --> Security Class Initialized
DEBUG - 2021-01-08 04:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:16:56 --> Input Class Initialized
INFO - 2021-01-08 04:16:56 --> Language Class Initialized
INFO - 2021-01-08 04:16:56 --> Language Class Initialized
INFO - 2021-01-08 04:16:56 --> Config Class Initialized
INFO - 2021-01-08 04:16:56 --> Loader Class Initialized
INFO - 2021-01-08 04:16:56 --> Helper loaded: url_helper
INFO - 2021-01-08 04:16:56 --> Helper loaded: file_helper
INFO - 2021-01-08 04:16:56 --> Helper loaded: form_helper
INFO - 2021-01-08 04:16:56 --> Helper loaded: my_helper
INFO - 2021-01-08 04:16:56 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:16:56 --> Controller Class Initialized
DEBUG - 2021-01-08 04:16:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-08 04:16:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:16:56 --> Final output sent to browser
DEBUG - 2021-01-08 04:16:56 --> Total execution time: 0.3473
INFO - 2021-01-08 04:17:08 --> Config Class Initialized
INFO - 2021-01-08 04:17:08 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:17:08 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:17:08 --> Utf8 Class Initialized
INFO - 2021-01-08 04:17:08 --> URI Class Initialized
INFO - 2021-01-08 04:17:08 --> Router Class Initialized
INFO - 2021-01-08 04:17:08 --> Output Class Initialized
INFO - 2021-01-08 04:17:08 --> Security Class Initialized
DEBUG - 2021-01-08 04:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:17:08 --> Input Class Initialized
INFO - 2021-01-08 04:17:08 --> Language Class Initialized
INFO - 2021-01-08 04:17:08 --> Language Class Initialized
INFO - 2021-01-08 04:17:08 --> Config Class Initialized
INFO - 2021-01-08 04:17:08 --> Loader Class Initialized
INFO - 2021-01-08 04:17:08 --> Helper loaded: url_helper
INFO - 2021-01-08 04:17:08 --> Helper loaded: file_helper
INFO - 2021-01-08 04:17:08 --> Helper loaded: form_helper
INFO - 2021-01-08 04:17:08 --> Helper loaded: my_helper
INFO - 2021-01-08 04:17:08 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:17:08 --> Controller Class Initialized
INFO - 2021-01-08 04:17:08 --> Final output sent to browser
DEBUG - 2021-01-08 04:17:08 --> Total execution time: 0.3264
INFO - 2021-01-08 04:17:12 --> Config Class Initialized
INFO - 2021-01-08 04:17:12 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:17:12 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:17:12 --> Utf8 Class Initialized
INFO - 2021-01-08 04:17:12 --> URI Class Initialized
INFO - 2021-01-08 04:17:12 --> Router Class Initialized
INFO - 2021-01-08 04:17:12 --> Output Class Initialized
INFO - 2021-01-08 04:17:12 --> Security Class Initialized
DEBUG - 2021-01-08 04:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:17:12 --> Input Class Initialized
INFO - 2021-01-08 04:17:12 --> Language Class Initialized
INFO - 2021-01-08 04:17:12 --> Language Class Initialized
INFO - 2021-01-08 04:17:12 --> Config Class Initialized
INFO - 2021-01-08 04:17:12 --> Loader Class Initialized
INFO - 2021-01-08 04:17:12 --> Helper loaded: url_helper
INFO - 2021-01-08 04:17:12 --> Helper loaded: file_helper
INFO - 2021-01-08 04:17:12 --> Helper loaded: form_helper
INFO - 2021-01-08 04:17:12 --> Helper loaded: my_helper
INFO - 2021-01-08 04:17:12 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:17:12 --> Controller Class Initialized
INFO - 2021-01-08 04:17:12 --> Helper loaded: cookie_helper
INFO - 2021-01-08 04:17:12 --> Final output sent to browser
DEBUG - 2021-01-08 04:17:12 --> Total execution time: 0.3625
INFO - 2021-01-08 04:17:12 --> Config Class Initialized
INFO - 2021-01-08 04:17:12 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:17:12 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:17:12 --> Utf8 Class Initialized
INFO - 2021-01-08 04:17:12 --> URI Class Initialized
INFO - 2021-01-08 04:17:12 --> Router Class Initialized
INFO - 2021-01-08 04:17:12 --> Output Class Initialized
INFO - 2021-01-08 04:17:12 --> Security Class Initialized
DEBUG - 2021-01-08 04:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:17:12 --> Input Class Initialized
INFO - 2021-01-08 04:17:12 --> Language Class Initialized
INFO - 2021-01-08 04:17:12 --> Language Class Initialized
INFO - 2021-01-08 04:17:12 --> Config Class Initialized
INFO - 2021-01-08 04:17:12 --> Loader Class Initialized
INFO - 2021-01-08 04:17:12 --> Helper loaded: url_helper
INFO - 2021-01-08 04:17:13 --> Helper loaded: file_helper
INFO - 2021-01-08 04:17:13 --> Helper loaded: form_helper
INFO - 2021-01-08 04:17:13 --> Helper loaded: my_helper
INFO - 2021-01-08 04:17:13 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:17:13 --> Controller Class Initialized
DEBUG - 2021-01-08 04:17:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-08 04:17:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:17:13 --> Final output sent to browser
DEBUG - 2021-01-08 04:17:13 --> Total execution time: 0.4816
INFO - 2021-01-08 04:17:16 --> Config Class Initialized
INFO - 2021-01-08 04:17:16 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:17:16 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:17:16 --> Utf8 Class Initialized
INFO - 2021-01-08 04:17:16 --> URI Class Initialized
INFO - 2021-01-08 04:17:16 --> Router Class Initialized
INFO - 2021-01-08 04:17:16 --> Output Class Initialized
INFO - 2021-01-08 04:17:16 --> Security Class Initialized
DEBUG - 2021-01-08 04:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:17:16 --> Input Class Initialized
INFO - 2021-01-08 04:17:16 --> Language Class Initialized
INFO - 2021-01-08 04:17:16 --> Language Class Initialized
INFO - 2021-01-08 04:17:16 --> Config Class Initialized
INFO - 2021-01-08 04:17:16 --> Loader Class Initialized
INFO - 2021-01-08 04:17:16 --> Helper loaded: url_helper
INFO - 2021-01-08 04:17:16 --> Helper loaded: file_helper
INFO - 2021-01-08 04:17:16 --> Helper loaded: form_helper
INFO - 2021-01-08 04:17:16 --> Helper loaded: my_helper
INFO - 2021-01-08 04:17:16 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:17:16 --> Controller Class Initialized
DEBUG - 2021-01-08 04:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-08 04:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:17:16 --> Final output sent to browser
DEBUG - 2021-01-08 04:17:16 --> Total execution time: 0.3262
INFO - 2021-01-08 04:17:16 --> Config Class Initialized
INFO - 2021-01-08 04:17:16 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:17:16 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:17:16 --> Utf8 Class Initialized
INFO - 2021-01-08 04:17:16 --> URI Class Initialized
INFO - 2021-01-08 04:17:16 --> Router Class Initialized
INFO - 2021-01-08 04:17:16 --> Output Class Initialized
INFO - 2021-01-08 04:17:16 --> Security Class Initialized
DEBUG - 2021-01-08 04:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:17:16 --> Input Class Initialized
INFO - 2021-01-08 04:17:16 --> Language Class Initialized
INFO - 2021-01-08 04:17:16 --> Language Class Initialized
INFO - 2021-01-08 04:17:16 --> Config Class Initialized
INFO - 2021-01-08 04:17:16 --> Loader Class Initialized
INFO - 2021-01-08 04:17:16 --> Helper loaded: url_helper
INFO - 2021-01-08 04:17:16 --> Helper loaded: file_helper
INFO - 2021-01-08 04:17:16 --> Helper loaded: form_helper
INFO - 2021-01-08 04:17:16 --> Helper loaded: my_helper
INFO - 2021-01-08 04:17:16 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:17:16 --> Controller Class Initialized
INFO - 2021-01-08 04:17:18 --> Config Class Initialized
INFO - 2021-01-08 04:17:19 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:17:19 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:17:19 --> Utf8 Class Initialized
INFO - 2021-01-08 04:17:19 --> URI Class Initialized
INFO - 2021-01-08 04:17:19 --> Router Class Initialized
INFO - 2021-01-08 04:17:19 --> Output Class Initialized
INFO - 2021-01-08 04:17:19 --> Security Class Initialized
DEBUG - 2021-01-08 04:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:17:19 --> Input Class Initialized
INFO - 2021-01-08 04:17:19 --> Language Class Initialized
INFO - 2021-01-08 04:17:19 --> Language Class Initialized
INFO - 2021-01-08 04:17:19 --> Config Class Initialized
INFO - 2021-01-08 04:17:19 --> Loader Class Initialized
INFO - 2021-01-08 04:17:19 --> Helper loaded: url_helper
INFO - 2021-01-08 04:17:19 --> Helper loaded: file_helper
INFO - 2021-01-08 04:17:19 --> Helper loaded: form_helper
INFO - 2021-01-08 04:17:19 --> Helper loaded: my_helper
INFO - 2021-01-08 04:17:19 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:17:19 --> Controller Class Initialized
DEBUG - 2021-01-08 04:17:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-08 04:17:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:17:19 --> Final output sent to browser
DEBUG - 2021-01-08 04:17:19 --> Total execution time: 0.2814
INFO - 2021-01-08 04:17:31 --> Config Class Initialized
INFO - 2021-01-08 04:17:31 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:17:31 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:17:31 --> Utf8 Class Initialized
INFO - 2021-01-08 04:17:31 --> URI Class Initialized
INFO - 2021-01-08 04:17:31 --> Router Class Initialized
INFO - 2021-01-08 04:17:31 --> Output Class Initialized
INFO - 2021-01-08 04:17:31 --> Security Class Initialized
DEBUG - 2021-01-08 04:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:17:31 --> Input Class Initialized
INFO - 2021-01-08 04:17:31 --> Language Class Initialized
INFO - 2021-01-08 04:17:31 --> Language Class Initialized
INFO - 2021-01-08 04:17:31 --> Config Class Initialized
INFO - 2021-01-08 04:17:32 --> Loader Class Initialized
INFO - 2021-01-08 04:17:32 --> Helper loaded: url_helper
INFO - 2021-01-08 04:17:32 --> Helper loaded: file_helper
INFO - 2021-01-08 04:17:32 --> Helper loaded: form_helper
INFO - 2021-01-08 04:17:32 --> Helper loaded: my_helper
INFO - 2021-01-08 04:17:32 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:17:32 --> Controller Class Initialized
INFO - 2021-01-08 04:17:32 --> Config Class Initialized
INFO - 2021-01-08 04:17:32 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:17:32 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:17:32 --> Utf8 Class Initialized
INFO - 2021-01-08 04:17:32 --> URI Class Initialized
INFO - 2021-01-08 04:17:32 --> Router Class Initialized
INFO - 2021-01-08 04:17:32 --> Output Class Initialized
INFO - 2021-01-08 04:17:32 --> Security Class Initialized
DEBUG - 2021-01-08 04:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:17:32 --> Input Class Initialized
INFO - 2021-01-08 04:17:32 --> Language Class Initialized
INFO - 2021-01-08 04:17:32 --> Language Class Initialized
INFO - 2021-01-08 04:17:32 --> Config Class Initialized
INFO - 2021-01-08 04:17:32 --> Loader Class Initialized
INFO - 2021-01-08 04:17:32 --> Helper loaded: url_helper
INFO - 2021-01-08 04:17:32 --> Helper loaded: file_helper
INFO - 2021-01-08 04:17:32 --> Helper loaded: form_helper
INFO - 2021-01-08 04:17:32 --> Helper loaded: my_helper
INFO - 2021-01-08 04:17:32 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:17:32 --> Controller Class Initialized
DEBUG - 2021-01-08 04:17:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-08 04:17:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:17:32 --> Final output sent to browser
DEBUG - 2021-01-08 04:17:32 --> Total execution time: 0.2894
INFO - 2021-01-08 04:17:32 --> Config Class Initialized
INFO - 2021-01-08 04:17:32 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:17:32 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:17:32 --> Utf8 Class Initialized
INFO - 2021-01-08 04:17:32 --> URI Class Initialized
INFO - 2021-01-08 04:17:32 --> Router Class Initialized
INFO - 2021-01-08 04:17:32 --> Output Class Initialized
INFO - 2021-01-08 04:17:32 --> Security Class Initialized
DEBUG - 2021-01-08 04:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:17:32 --> Input Class Initialized
INFO - 2021-01-08 04:17:32 --> Language Class Initialized
INFO - 2021-01-08 04:17:32 --> Language Class Initialized
INFO - 2021-01-08 04:17:32 --> Config Class Initialized
INFO - 2021-01-08 04:17:32 --> Loader Class Initialized
INFO - 2021-01-08 04:17:32 --> Helper loaded: url_helper
INFO - 2021-01-08 04:17:32 --> Helper loaded: file_helper
INFO - 2021-01-08 04:17:32 --> Helper loaded: form_helper
INFO - 2021-01-08 04:17:32 --> Helper loaded: my_helper
INFO - 2021-01-08 04:17:32 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:17:32 --> Controller Class Initialized
INFO - 2021-01-08 04:18:16 --> Config Class Initialized
INFO - 2021-01-08 04:18:16 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:16 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:16 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:16 --> URI Class Initialized
INFO - 2021-01-08 04:18:16 --> Router Class Initialized
INFO - 2021-01-08 04:18:16 --> Output Class Initialized
INFO - 2021-01-08 04:18:16 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:16 --> Input Class Initialized
INFO - 2021-01-08 04:18:16 --> Language Class Initialized
INFO - 2021-01-08 04:18:16 --> Language Class Initialized
INFO - 2021-01-08 04:18:16 --> Config Class Initialized
INFO - 2021-01-08 04:18:16 --> Loader Class Initialized
INFO - 2021-01-08 04:18:16 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:16 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:16 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:16 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:16 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:16 --> Controller Class Initialized
DEBUG - 2021-01-08 04:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-08 04:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:18:16 --> Final output sent to browser
DEBUG - 2021-01-08 04:18:16 --> Total execution time: 0.2749
INFO - 2021-01-08 04:18:16 --> Config Class Initialized
INFO - 2021-01-08 04:18:16 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:16 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:16 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:16 --> URI Class Initialized
INFO - 2021-01-08 04:18:16 --> Router Class Initialized
INFO - 2021-01-08 04:18:16 --> Output Class Initialized
INFO - 2021-01-08 04:18:16 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:16 --> Input Class Initialized
INFO - 2021-01-08 04:18:16 --> Language Class Initialized
INFO - 2021-01-08 04:18:16 --> Language Class Initialized
INFO - 2021-01-08 04:18:16 --> Config Class Initialized
INFO - 2021-01-08 04:18:16 --> Loader Class Initialized
INFO - 2021-01-08 04:18:16 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:16 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:16 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:16 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:16 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:16 --> Controller Class Initialized
INFO - 2021-01-08 04:18:18 --> Config Class Initialized
INFO - 2021-01-08 04:18:18 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:18 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:18 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:18 --> URI Class Initialized
INFO - 2021-01-08 04:18:18 --> Router Class Initialized
INFO - 2021-01-08 04:18:18 --> Output Class Initialized
INFO - 2021-01-08 04:18:18 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:18 --> Input Class Initialized
INFO - 2021-01-08 04:18:18 --> Language Class Initialized
INFO - 2021-01-08 04:18:18 --> Language Class Initialized
INFO - 2021-01-08 04:18:18 --> Config Class Initialized
INFO - 2021-01-08 04:18:18 --> Loader Class Initialized
INFO - 2021-01-08 04:18:18 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:18 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:18 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:18 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:18 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:18 --> Controller Class Initialized
DEBUG - 2021-01-08 04:18:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-08 04:18:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:18:18 --> Final output sent to browser
DEBUG - 2021-01-08 04:18:18 --> Total execution time: 0.3184
INFO - 2021-01-08 04:18:29 --> Config Class Initialized
INFO - 2021-01-08 04:18:29 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:29 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:29 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:29 --> URI Class Initialized
INFO - 2021-01-08 04:18:29 --> Router Class Initialized
INFO - 2021-01-08 04:18:29 --> Output Class Initialized
INFO - 2021-01-08 04:18:29 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:29 --> Input Class Initialized
INFO - 2021-01-08 04:18:29 --> Language Class Initialized
INFO - 2021-01-08 04:18:29 --> Language Class Initialized
INFO - 2021-01-08 04:18:29 --> Config Class Initialized
INFO - 2021-01-08 04:18:29 --> Loader Class Initialized
INFO - 2021-01-08 04:18:29 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:29 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:29 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:29 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:29 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:29 --> Controller Class Initialized
INFO - 2021-01-08 04:18:29 --> Config Class Initialized
INFO - 2021-01-08 04:18:29 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:29 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:29 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:30 --> URI Class Initialized
INFO - 2021-01-08 04:18:30 --> Router Class Initialized
INFO - 2021-01-08 04:18:30 --> Output Class Initialized
INFO - 2021-01-08 04:18:30 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:30 --> Input Class Initialized
INFO - 2021-01-08 04:18:30 --> Language Class Initialized
INFO - 2021-01-08 04:18:30 --> Language Class Initialized
INFO - 2021-01-08 04:18:30 --> Config Class Initialized
INFO - 2021-01-08 04:18:30 --> Loader Class Initialized
INFO - 2021-01-08 04:18:30 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:30 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:30 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:30 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:30 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:30 --> Controller Class Initialized
DEBUG - 2021-01-08 04:18:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-08 04:18:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:18:30 --> Final output sent to browser
DEBUG - 2021-01-08 04:18:30 --> Total execution time: 0.2518
INFO - 2021-01-08 04:18:30 --> Config Class Initialized
INFO - 2021-01-08 04:18:30 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:30 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:30 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:30 --> URI Class Initialized
INFO - 2021-01-08 04:18:30 --> Router Class Initialized
INFO - 2021-01-08 04:18:30 --> Output Class Initialized
INFO - 2021-01-08 04:18:30 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:30 --> Input Class Initialized
INFO - 2021-01-08 04:18:30 --> Language Class Initialized
INFO - 2021-01-08 04:18:30 --> Language Class Initialized
INFO - 2021-01-08 04:18:30 --> Config Class Initialized
INFO - 2021-01-08 04:18:30 --> Loader Class Initialized
INFO - 2021-01-08 04:18:30 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:30 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:30 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:30 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:30 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:30 --> Controller Class Initialized
INFO - 2021-01-08 04:18:35 --> Config Class Initialized
INFO - 2021-01-08 04:18:35 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:35 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:35 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:36 --> URI Class Initialized
INFO - 2021-01-08 04:18:36 --> Router Class Initialized
INFO - 2021-01-08 04:18:36 --> Output Class Initialized
INFO - 2021-01-08 04:18:36 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:36 --> Input Class Initialized
INFO - 2021-01-08 04:18:36 --> Language Class Initialized
INFO - 2021-01-08 04:18:36 --> Language Class Initialized
INFO - 2021-01-08 04:18:36 --> Config Class Initialized
INFO - 2021-01-08 04:18:36 --> Loader Class Initialized
INFO - 2021-01-08 04:18:36 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:36 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:36 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:36 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:36 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:36 --> Controller Class Initialized
INFO - 2021-01-08 04:18:36 --> Helper loaded: cookie_helper
INFO - 2021-01-08 04:18:36 --> Config Class Initialized
INFO - 2021-01-08 04:18:36 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:36 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:36 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:36 --> URI Class Initialized
INFO - 2021-01-08 04:18:36 --> Router Class Initialized
INFO - 2021-01-08 04:18:36 --> Output Class Initialized
INFO - 2021-01-08 04:18:36 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:36 --> Input Class Initialized
INFO - 2021-01-08 04:18:36 --> Language Class Initialized
INFO - 2021-01-08 04:18:36 --> Language Class Initialized
INFO - 2021-01-08 04:18:36 --> Config Class Initialized
INFO - 2021-01-08 04:18:36 --> Loader Class Initialized
INFO - 2021-01-08 04:18:36 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:36 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:36 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:36 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:36 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:36 --> Controller Class Initialized
DEBUG - 2021-01-08 04:18:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-08 04:18:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:18:36 --> Final output sent to browser
DEBUG - 2021-01-08 04:18:36 --> Total execution time: 0.3031
INFO - 2021-01-08 04:18:41 --> Config Class Initialized
INFO - 2021-01-08 04:18:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:41 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:41 --> URI Class Initialized
INFO - 2021-01-08 04:18:41 --> Router Class Initialized
INFO - 2021-01-08 04:18:41 --> Output Class Initialized
INFO - 2021-01-08 04:18:41 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:41 --> Input Class Initialized
INFO - 2021-01-08 04:18:41 --> Language Class Initialized
INFO - 2021-01-08 04:18:41 --> Language Class Initialized
INFO - 2021-01-08 04:18:41 --> Config Class Initialized
INFO - 2021-01-08 04:18:41 --> Loader Class Initialized
INFO - 2021-01-08 04:18:41 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:41 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:41 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:41 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:41 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:41 --> Controller Class Initialized
INFO - 2021-01-08 04:18:41 --> Helper loaded: cookie_helper
INFO - 2021-01-08 04:18:41 --> Final output sent to browser
DEBUG - 2021-01-08 04:18:41 --> Total execution time: 0.3499
INFO - 2021-01-08 04:18:41 --> Config Class Initialized
INFO - 2021-01-08 04:18:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:41 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:41 --> URI Class Initialized
INFO - 2021-01-08 04:18:42 --> Router Class Initialized
INFO - 2021-01-08 04:18:42 --> Output Class Initialized
INFO - 2021-01-08 04:18:42 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:42 --> Input Class Initialized
INFO - 2021-01-08 04:18:42 --> Language Class Initialized
INFO - 2021-01-08 04:18:42 --> Language Class Initialized
INFO - 2021-01-08 04:18:42 --> Config Class Initialized
INFO - 2021-01-08 04:18:42 --> Loader Class Initialized
INFO - 2021-01-08 04:18:42 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:42 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:42 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:42 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:42 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:42 --> Controller Class Initialized
DEBUG - 2021-01-08 04:18:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-08 04:18:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:18:42 --> Final output sent to browser
DEBUG - 2021-01-08 04:18:42 --> Total execution time: 0.3886
INFO - 2021-01-08 04:18:46 --> Config Class Initialized
INFO - 2021-01-08 04:18:46 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:46 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:46 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:46 --> URI Class Initialized
INFO - 2021-01-08 04:18:46 --> Router Class Initialized
INFO - 2021-01-08 04:18:46 --> Output Class Initialized
INFO - 2021-01-08 04:18:46 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:46 --> Input Class Initialized
INFO - 2021-01-08 04:18:46 --> Language Class Initialized
INFO - 2021-01-08 04:18:46 --> Language Class Initialized
INFO - 2021-01-08 04:18:46 --> Config Class Initialized
INFO - 2021-01-08 04:18:46 --> Loader Class Initialized
INFO - 2021-01-08 04:18:46 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:46 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:46 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:46 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:46 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:46 --> Controller Class Initialized
DEBUG - 2021-01-08 04:18:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-08 04:18:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:18:46 --> Final output sent to browser
DEBUG - 2021-01-08 04:18:46 --> Total execution time: 0.2857
INFO - 2021-01-08 04:18:58 --> Config Class Initialized
INFO - 2021-01-08 04:18:58 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:58 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:58 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:58 --> URI Class Initialized
INFO - 2021-01-08 04:18:58 --> Router Class Initialized
INFO - 2021-01-08 04:18:58 --> Output Class Initialized
INFO - 2021-01-08 04:18:58 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:58 --> Input Class Initialized
INFO - 2021-01-08 04:18:58 --> Language Class Initialized
INFO - 2021-01-08 04:18:58 --> Language Class Initialized
INFO - 2021-01-08 04:18:58 --> Config Class Initialized
INFO - 2021-01-08 04:18:58 --> Loader Class Initialized
INFO - 2021-01-08 04:18:58 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:58 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:58 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:58 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:58 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:58 --> Controller Class Initialized
DEBUG - 2021-01-08 04:18:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-08 04:18:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:18:58 --> Final output sent to browser
DEBUG - 2021-01-08 04:18:58 --> Total execution time: 0.2578
INFO - 2021-01-08 04:18:59 --> Config Class Initialized
INFO - 2021-01-08 04:18:59 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:18:59 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:18:59 --> Utf8 Class Initialized
INFO - 2021-01-08 04:18:59 --> URI Class Initialized
INFO - 2021-01-08 04:18:59 --> Router Class Initialized
INFO - 2021-01-08 04:18:59 --> Output Class Initialized
INFO - 2021-01-08 04:18:59 --> Security Class Initialized
DEBUG - 2021-01-08 04:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:18:59 --> Input Class Initialized
INFO - 2021-01-08 04:18:59 --> Language Class Initialized
INFO - 2021-01-08 04:18:59 --> Language Class Initialized
INFO - 2021-01-08 04:18:59 --> Config Class Initialized
INFO - 2021-01-08 04:18:59 --> Loader Class Initialized
INFO - 2021-01-08 04:18:59 --> Helper loaded: url_helper
INFO - 2021-01-08 04:18:59 --> Helper loaded: file_helper
INFO - 2021-01-08 04:18:59 --> Helper loaded: form_helper
INFO - 2021-01-08 04:18:59 --> Helper loaded: my_helper
INFO - 2021-01-08 04:18:59 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:18:59 --> Controller Class Initialized
INFO - 2021-01-08 04:19:00 --> Config Class Initialized
INFO - 2021-01-08 04:19:00 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:00 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:00 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:00 --> URI Class Initialized
INFO - 2021-01-08 04:19:00 --> Router Class Initialized
INFO - 2021-01-08 04:19:00 --> Output Class Initialized
INFO - 2021-01-08 04:19:00 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:00 --> Input Class Initialized
INFO - 2021-01-08 04:19:00 --> Language Class Initialized
INFO - 2021-01-08 04:19:00 --> Language Class Initialized
INFO - 2021-01-08 04:19:00 --> Config Class Initialized
INFO - 2021-01-08 04:19:00 --> Loader Class Initialized
INFO - 2021-01-08 04:19:00 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:00 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:00 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:00 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:00 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:00 --> Controller Class Initialized
INFO - 2021-01-08 04:19:00 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:00 --> Total execution time: 0.3019
INFO - 2021-01-08 04:19:14 --> Config Class Initialized
INFO - 2021-01-08 04:19:15 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:15 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:15 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:15 --> URI Class Initialized
INFO - 2021-01-08 04:19:15 --> Router Class Initialized
INFO - 2021-01-08 04:19:15 --> Output Class Initialized
INFO - 2021-01-08 04:19:15 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:15 --> Input Class Initialized
INFO - 2021-01-08 04:19:15 --> Language Class Initialized
INFO - 2021-01-08 04:19:15 --> Language Class Initialized
INFO - 2021-01-08 04:19:15 --> Config Class Initialized
INFO - 2021-01-08 04:19:15 --> Loader Class Initialized
INFO - 2021-01-08 04:19:15 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:15 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:15 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:15 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:15 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:15 --> Controller Class Initialized
INFO - 2021-01-08 04:19:15 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:15 --> Total execution time: 0.3507
INFO - 2021-01-08 04:19:15 --> Config Class Initialized
INFO - 2021-01-08 04:19:15 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:15 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:15 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:15 --> URI Class Initialized
INFO - 2021-01-08 04:19:15 --> Router Class Initialized
INFO - 2021-01-08 04:19:15 --> Output Class Initialized
INFO - 2021-01-08 04:19:15 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:15 --> Input Class Initialized
INFO - 2021-01-08 04:19:15 --> Language Class Initialized
INFO - 2021-01-08 04:19:15 --> Language Class Initialized
INFO - 2021-01-08 04:19:15 --> Config Class Initialized
INFO - 2021-01-08 04:19:15 --> Loader Class Initialized
INFO - 2021-01-08 04:19:15 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:15 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:15 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:15 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:15 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:15 --> Controller Class Initialized
INFO - 2021-01-08 04:19:16 --> Config Class Initialized
INFO - 2021-01-08 04:19:16 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:17 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:17 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:17 --> URI Class Initialized
INFO - 2021-01-08 04:19:17 --> Router Class Initialized
INFO - 2021-01-08 04:19:17 --> Output Class Initialized
INFO - 2021-01-08 04:19:17 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:17 --> Input Class Initialized
INFO - 2021-01-08 04:19:17 --> Language Class Initialized
INFO - 2021-01-08 04:19:17 --> Language Class Initialized
INFO - 2021-01-08 04:19:17 --> Config Class Initialized
INFO - 2021-01-08 04:19:17 --> Loader Class Initialized
INFO - 2021-01-08 04:19:17 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:17 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:17 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:17 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:17 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:17 --> Controller Class Initialized
INFO - 2021-01-08 04:19:17 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:17 --> Total execution time: 0.2589
INFO - 2021-01-08 04:19:27 --> Config Class Initialized
INFO - 2021-01-08 04:19:27 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:27 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:27 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:27 --> URI Class Initialized
INFO - 2021-01-08 04:19:27 --> Router Class Initialized
INFO - 2021-01-08 04:19:27 --> Output Class Initialized
INFO - 2021-01-08 04:19:27 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:27 --> Input Class Initialized
INFO - 2021-01-08 04:19:27 --> Language Class Initialized
INFO - 2021-01-08 04:19:27 --> Language Class Initialized
INFO - 2021-01-08 04:19:27 --> Config Class Initialized
INFO - 2021-01-08 04:19:27 --> Loader Class Initialized
INFO - 2021-01-08 04:19:27 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:27 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:27 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:27 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:27 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:27 --> Controller Class Initialized
INFO - 2021-01-08 04:19:27 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:27 --> Total execution time: 0.2872
INFO - 2021-01-08 04:19:27 --> Config Class Initialized
INFO - 2021-01-08 04:19:27 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:27 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:27 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:27 --> URI Class Initialized
INFO - 2021-01-08 04:19:27 --> Router Class Initialized
INFO - 2021-01-08 04:19:27 --> Output Class Initialized
INFO - 2021-01-08 04:19:27 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:27 --> Input Class Initialized
INFO - 2021-01-08 04:19:28 --> Language Class Initialized
INFO - 2021-01-08 04:19:28 --> Language Class Initialized
INFO - 2021-01-08 04:19:28 --> Config Class Initialized
INFO - 2021-01-08 04:19:28 --> Loader Class Initialized
INFO - 2021-01-08 04:19:28 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:28 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:28 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:28 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:28 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:28 --> Controller Class Initialized
INFO - 2021-01-08 04:19:29 --> Config Class Initialized
INFO - 2021-01-08 04:19:29 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:29 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:29 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:29 --> URI Class Initialized
INFO - 2021-01-08 04:19:29 --> Router Class Initialized
INFO - 2021-01-08 04:19:29 --> Output Class Initialized
INFO - 2021-01-08 04:19:30 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:30 --> Input Class Initialized
INFO - 2021-01-08 04:19:30 --> Language Class Initialized
INFO - 2021-01-08 04:19:30 --> Language Class Initialized
INFO - 2021-01-08 04:19:30 --> Config Class Initialized
INFO - 2021-01-08 04:19:30 --> Loader Class Initialized
INFO - 2021-01-08 04:19:30 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:30 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:30 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:30 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:30 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:30 --> Controller Class Initialized
INFO - 2021-01-08 04:19:30 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:30 --> Total execution time: 0.2297
INFO - 2021-01-08 04:19:35 --> Config Class Initialized
INFO - 2021-01-08 04:19:35 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:35 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:35 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:35 --> URI Class Initialized
INFO - 2021-01-08 04:19:35 --> Router Class Initialized
INFO - 2021-01-08 04:19:35 --> Output Class Initialized
INFO - 2021-01-08 04:19:35 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:35 --> Input Class Initialized
INFO - 2021-01-08 04:19:35 --> Language Class Initialized
INFO - 2021-01-08 04:19:35 --> Language Class Initialized
INFO - 2021-01-08 04:19:35 --> Config Class Initialized
INFO - 2021-01-08 04:19:35 --> Loader Class Initialized
INFO - 2021-01-08 04:19:35 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:35 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:35 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:35 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:35 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:35 --> Controller Class Initialized
INFO - 2021-01-08 04:19:35 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:35 --> Total execution time: 0.3699
INFO - 2021-01-08 04:19:38 --> Config Class Initialized
INFO - 2021-01-08 04:19:38 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:38 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:38 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:38 --> URI Class Initialized
INFO - 2021-01-08 04:19:38 --> Router Class Initialized
INFO - 2021-01-08 04:19:38 --> Output Class Initialized
INFO - 2021-01-08 04:19:38 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:38 --> Input Class Initialized
INFO - 2021-01-08 04:19:38 --> Language Class Initialized
INFO - 2021-01-08 04:19:38 --> Language Class Initialized
INFO - 2021-01-08 04:19:38 --> Config Class Initialized
INFO - 2021-01-08 04:19:38 --> Loader Class Initialized
INFO - 2021-01-08 04:19:38 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:38 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:38 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:38 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:38 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:38 --> Controller Class Initialized
INFO - 2021-01-08 04:19:38 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:38 --> Total execution time: 0.2143
INFO - 2021-01-08 04:19:43 --> Config Class Initialized
INFO - 2021-01-08 04:19:43 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:43 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:43 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:43 --> URI Class Initialized
INFO - 2021-01-08 04:19:43 --> Router Class Initialized
INFO - 2021-01-08 04:19:43 --> Output Class Initialized
INFO - 2021-01-08 04:19:43 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:43 --> Input Class Initialized
INFO - 2021-01-08 04:19:43 --> Language Class Initialized
INFO - 2021-01-08 04:19:43 --> Language Class Initialized
INFO - 2021-01-08 04:19:43 --> Config Class Initialized
INFO - 2021-01-08 04:19:43 --> Loader Class Initialized
INFO - 2021-01-08 04:19:43 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:43 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:43 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:43 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:43 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:43 --> Controller Class Initialized
INFO - 2021-01-08 04:19:43 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:43 --> Total execution time: 0.3514
INFO - 2021-01-08 04:19:46 --> Config Class Initialized
INFO - 2021-01-08 04:19:46 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:46 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:46 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:46 --> URI Class Initialized
INFO - 2021-01-08 04:19:46 --> Router Class Initialized
INFO - 2021-01-08 04:19:46 --> Output Class Initialized
INFO - 2021-01-08 04:19:46 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:46 --> Input Class Initialized
INFO - 2021-01-08 04:19:46 --> Language Class Initialized
INFO - 2021-01-08 04:19:46 --> Language Class Initialized
INFO - 2021-01-08 04:19:46 --> Config Class Initialized
INFO - 2021-01-08 04:19:46 --> Loader Class Initialized
INFO - 2021-01-08 04:19:46 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:46 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:46 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:46 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:46 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:46 --> Controller Class Initialized
INFO - 2021-01-08 04:19:46 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:46 --> Total execution time: 0.2229
INFO - 2021-01-08 04:19:51 --> Config Class Initialized
INFO - 2021-01-08 04:19:51 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:51 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:51 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:51 --> URI Class Initialized
INFO - 2021-01-08 04:19:51 --> Router Class Initialized
INFO - 2021-01-08 04:19:51 --> Output Class Initialized
INFO - 2021-01-08 04:19:51 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:51 --> Input Class Initialized
INFO - 2021-01-08 04:19:51 --> Language Class Initialized
INFO - 2021-01-08 04:19:51 --> Language Class Initialized
INFO - 2021-01-08 04:19:51 --> Config Class Initialized
INFO - 2021-01-08 04:19:51 --> Loader Class Initialized
INFO - 2021-01-08 04:19:51 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:51 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:51 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:51 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:51 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:51 --> Controller Class Initialized
INFO - 2021-01-08 04:19:51 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:52 --> Total execution time: 0.3579
INFO - 2021-01-08 04:19:53 --> Config Class Initialized
INFO - 2021-01-08 04:19:53 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:53 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:54 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:54 --> URI Class Initialized
INFO - 2021-01-08 04:19:54 --> Router Class Initialized
INFO - 2021-01-08 04:19:54 --> Output Class Initialized
INFO - 2021-01-08 04:19:54 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:54 --> Input Class Initialized
INFO - 2021-01-08 04:19:54 --> Language Class Initialized
INFO - 2021-01-08 04:19:54 --> Language Class Initialized
INFO - 2021-01-08 04:19:54 --> Config Class Initialized
INFO - 2021-01-08 04:19:54 --> Loader Class Initialized
INFO - 2021-01-08 04:19:54 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:54 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:54 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:54 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:54 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:54 --> Controller Class Initialized
INFO - 2021-01-08 04:19:54 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:54 --> Total execution time: 0.2426
INFO - 2021-01-08 04:19:57 --> Config Class Initialized
INFO - 2021-01-08 04:19:57 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:19:57 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:19:57 --> Utf8 Class Initialized
INFO - 2021-01-08 04:19:57 --> URI Class Initialized
INFO - 2021-01-08 04:19:57 --> Router Class Initialized
INFO - 2021-01-08 04:19:57 --> Output Class Initialized
INFO - 2021-01-08 04:19:57 --> Security Class Initialized
DEBUG - 2021-01-08 04:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:19:57 --> Input Class Initialized
INFO - 2021-01-08 04:19:57 --> Language Class Initialized
INFO - 2021-01-08 04:19:57 --> Language Class Initialized
INFO - 2021-01-08 04:19:57 --> Config Class Initialized
INFO - 2021-01-08 04:19:57 --> Loader Class Initialized
INFO - 2021-01-08 04:19:58 --> Helper loaded: url_helper
INFO - 2021-01-08 04:19:58 --> Helper loaded: file_helper
INFO - 2021-01-08 04:19:58 --> Helper loaded: form_helper
INFO - 2021-01-08 04:19:58 --> Helper loaded: my_helper
INFO - 2021-01-08 04:19:58 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:19:58 --> Controller Class Initialized
INFO - 2021-01-08 04:19:58 --> Final output sent to browser
DEBUG - 2021-01-08 04:19:58 --> Total execution time: 0.3300
INFO - 2021-01-08 04:20:01 --> Config Class Initialized
INFO - 2021-01-08 04:20:01 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:20:01 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:20:01 --> Utf8 Class Initialized
INFO - 2021-01-08 04:20:01 --> URI Class Initialized
INFO - 2021-01-08 04:20:01 --> Router Class Initialized
INFO - 2021-01-08 04:20:01 --> Output Class Initialized
INFO - 2021-01-08 04:20:01 --> Security Class Initialized
DEBUG - 2021-01-08 04:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:20:01 --> Input Class Initialized
INFO - 2021-01-08 04:20:01 --> Language Class Initialized
INFO - 2021-01-08 04:20:01 --> Language Class Initialized
INFO - 2021-01-08 04:20:01 --> Config Class Initialized
INFO - 2021-01-08 04:20:01 --> Loader Class Initialized
INFO - 2021-01-08 04:20:01 --> Helper loaded: url_helper
INFO - 2021-01-08 04:20:01 --> Helper loaded: file_helper
INFO - 2021-01-08 04:20:01 --> Helper loaded: form_helper
INFO - 2021-01-08 04:20:01 --> Helper loaded: my_helper
INFO - 2021-01-08 04:20:01 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:20:02 --> Controller Class Initialized
ERROR - 2021-01-08 04:20:02 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 258
DEBUG - 2021-01-08 04:20:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:20:02 --> Final output sent to browser
DEBUG - 2021-01-08 04:20:02 --> Total execution time: 0.2778
INFO - 2021-01-08 04:20:08 --> Config Class Initialized
INFO - 2021-01-08 04:20:08 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:20:08 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:20:08 --> Utf8 Class Initialized
INFO - 2021-01-08 04:20:08 --> URI Class Initialized
INFO - 2021-01-08 04:20:08 --> Router Class Initialized
INFO - 2021-01-08 04:20:08 --> Output Class Initialized
INFO - 2021-01-08 04:20:08 --> Security Class Initialized
DEBUG - 2021-01-08 04:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:20:08 --> Input Class Initialized
INFO - 2021-01-08 04:20:08 --> Language Class Initialized
INFO - 2021-01-08 04:20:08 --> Language Class Initialized
INFO - 2021-01-08 04:20:08 --> Config Class Initialized
INFO - 2021-01-08 04:20:08 --> Loader Class Initialized
INFO - 2021-01-08 04:20:08 --> Helper loaded: url_helper
INFO - 2021-01-08 04:20:08 --> Helper loaded: file_helper
INFO - 2021-01-08 04:20:08 --> Helper loaded: form_helper
INFO - 2021-01-08 04:20:08 --> Helper loaded: my_helper
INFO - 2021-01-08 04:20:08 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:20:08 --> Controller Class Initialized
DEBUG - 2021-01-08 04:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-08 04:20:08 --> Final output sent to browser
DEBUG - 2021-01-08 04:20:08 --> Total execution time: 0.3216
INFO - 2021-01-08 04:22:45 --> Config Class Initialized
INFO - 2021-01-08 04:22:45 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:22:45 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:22:45 --> Utf8 Class Initialized
INFO - 2021-01-08 04:22:45 --> URI Class Initialized
INFO - 2021-01-08 04:22:45 --> Router Class Initialized
INFO - 2021-01-08 04:22:45 --> Output Class Initialized
INFO - 2021-01-08 04:22:45 --> Security Class Initialized
DEBUG - 2021-01-08 04:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:22:45 --> Input Class Initialized
INFO - 2021-01-08 04:22:45 --> Language Class Initialized
INFO - 2021-01-08 04:22:45 --> Language Class Initialized
INFO - 2021-01-08 04:22:45 --> Config Class Initialized
INFO - 2021-01-08 04:22:45 --> Loader Class Initialized
INFO - 2021-01-08 04:22:45 --> Helper loaded: url_helper
INFO - 2021-01-08 04:22:45 --> Helper loaded: file_helper
INFO - 2021-01-08 04:22:45 --> Helper loaded: form_helper
INFO - 2021-01-08 04:22:46 --> Helper loaded: my_helper
INFO - 2021-01-08 04:22:46 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:22:46 --> Controller Class Initialized
DEBUG - 2021-01-08 04:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-08 04:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:22:46 --> Final output sent to browser
DEBUG - 2021-01-08 04:22:46 --> Total execution time: 0.3081
INFO - 2021-01-08 04:22:52 --> Config Class Initialized
INFO - 2021-01-08 04:22:52 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:22:52 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:22:52 --> Utf8 Class Initialized
INFO - 2021-01-08 04:22:52 --> URI Class Initialized
INFO - 2021-01-08 04:22:53 --> Router Class Initialized
INFO - 2021-01-08 04:22:53 --> Output Class Initialized
INFO - 2021-01-08 04:22:53 --> Security Class Initialized
DEBUG - 2021-01-08 04:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:22:53 --> Input Class Initialized
INFO - 2021-01-08 04:22:53 --> Language Class Initialized
INFO - 2021-01-08 04:22:53 --> Language Class Initialized
INFO - 2021-01-08 04:22:53 --> Config Class Initialized
INFO - 2021-01-08 04:22:53 --> Loader Class Initialized
INFO - 2021-01-08 04:22:53 --> Helper loaded: url_helper
INFO - 2021-01-08 04:22:53 --> Helper loaded: file_helper
INFO - 2021-01-08 04:22:53 --> Helper loaded: form_helper
INFO - 2021-01-08 04:22:53 --> Helper loaded: my_helper
INFO - 2021-01-08 04:22:53 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:22:53 --> Controller Class Initialized
DEBUG - 2021-01-08 04:22:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-08 04:22:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:22:53 --> Final output sent to browser
DEBUG - 2021-01-08 04:22:53 --> Total execution time: 0.2994
INFO - 2021-01-08 04:22:55 --> Config Class Initialized
INFO - 2021-01-08 04:22:55 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:22:55 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:22:55 --> Utf8 Class Initialized
INFO - 2021-01-08 04:22:55 --> URI Class Initialized
INFO - 2021-01-08 04:22:55 --> Router Class Initialized
INFO - 2021-01-08 04:22:55 --> Output Class Initialized
INFO - 2021-01-08 04:22:55 --> Security Class Initialized
DEBUG - 2021-01-08 04:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:22:55 --> Input Class Initialized
INFO - 2021-01-08 04:22:55 --> Language Class Initialized
INFO - 2021-01-08 04:22:55 --> Language Class Initialized
INFO - 2021-01-08 04:22:55 --> Config Class Initialized
INFO - 2021-01-08 04:22:55 --> Loader Class Initialized
INFO - 2021-01-08 04:22:55 --> Helper loaded: url_helper
INFO - 2021-01-08 04:22:55 --> Helper loaded: file_helper
INFO - 2021-01-08 04:22:55 --> Helper loaded: form_helper
INFO - 2021-01-08 04:22:55 --> Helper loaded: my_helper
INFO - 2021-01-08 04:22:55 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:22:55 --> Controller Class Initialized
INFO - 2021-01-08 04:22:55 --> Final output sent to browser
DEBUG - 2021-01-08 04:22:55 --> Total execution time: 0.2825
INFO - 2021-01-08 04:23:02 --> Config Class Initialized
INFO - 2021-01-08 04:23:02 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:02 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:02 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:02 --> URI Class Initialized
INFO - 2021-01-08 04:23:02 --> Router Class Initialized
INFO - 2021-01-08 04:23:02 --> Output Class Initialized
INFO - 2021-01-08 04:23:02 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:02 --> Input Class Initialized
INFO - 2021-01-08 04:23:02 --> Language Class Initialized
INFO - 2021-01-08 04:23:02 --> Language Class Initialized
INFO - 2021-01-08 04:23:02 --> Config Class Initialized
INFO - 2021-01-08 04:23:02 --> Loader Class Initialized
INFO - 2021-01-08 04:23:02 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:02 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:02 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:02 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:02 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:02 --> Controller Class Initialized
INFO - 2021-01-08 04:23:02 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:02 --> Total execution time: 0.3204
INFO - 2021-01-08 04:23:02 --> Config Class Initialized
INFO - 2021-01-08 04:23:02 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:02 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:02 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:02 --> URI Class Initialized
INFO - 2021-01-08 04:23:02 --> Router Class Initialized
INFO - 2021-01-08 04:23:02 --> Output Class Initialized
INFO - 2021-01-08 04:23:02 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:02 --> Input Class Initialized
INFO - 2021-01-08 04:23:02 --> Language Class Initialized
INFO - 2021-01-08 04:23:02 --> Language Class Initialized
INFO - 2021-01-08 04:23:02 --> Config Class Initialized
INFO - 2021-01-08 04:23:02 --> Loader Class Initialized
INFO - 2021-01-08 04:23:02 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:02 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:02 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:02 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:02 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:02 --> Controller Class Initialized
DEBUG - 2021-01-08 04:23:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-08 04:23:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:23:02 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:02 --> Total execution time: 0.3965
INFO - 2021-01-08 04:23:03 --> Config Class Initialized
INFO - 2021-01-08 04:23:03 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:03 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:03 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:03 --> URI Class Initialized
INFO - 2021-01-08 04:23:03 --> Router Class Initialized
INFO - 2021-01-08 04:23:03 --> Output Class Initialized
INFO - 2021-01-08 04:23:03 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:03 --> Input Class Initialized
INFO - 2021-01-08 04:23:03 --> Language Class Initialized
INFO - 2021-01-08 04:23:03 --> Language Class Initialized
INFO - 2021-01-08 04:23:03 --> Config Class Initialized
INFO - 2021-01-08 04:23:03 --> Loader Class Initialized
INFO - 2021-01-08 04:23:03 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:03 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:03 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:03 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:03 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:03 --> Controller Class Initialized
INFO - 2021-01-08 04:23:03 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:03 --> Total execution time: 0.2704
INFO - 2021-01-08 04:23:15 --> Config Class Initialized
INFO - 2021-01-08 04:23:15 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:15 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:15 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:15 --> URI Class Initialized
INFO - 2021-01-08 04:23:15 --> Router Class Initialized
INFO - 2021-01-08 04:23:15 --> Output Class Initialized
INFO - 2021-01-08 04:23:15 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:15 --> Input Class Initialized
INFO - 2021-01-08 04:23:15 --> Language Class Initialized
INFO - 2021-01-08 04:23:15 --> Language Class Initialized
INFO - 2021-01-08 04:23:15 --> Config Class Initialized
INFO - 2021-01-08 04:23:15 --> Loader Class Initialized
INFO - 2021-01-08 04:23:15 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:15 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:15 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:15 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:15 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:15 --> Controller Class Initialized
INFO - 2021-01-08 04:23:15 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:15 --> Total execution time: 0.3114
INFO - 2021-01-08 04:23:15 --> Config Class Initialized
INFO - 2021-01-08 04:23:15 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:15 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:15 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:15 --> URI Class Initialized
INFO - 2021-01-08 04:23:15 --> Router Class Initialized
INFO - 2021-01-08 04:23:15 --> Output Class Initialized
INFO - 2021-01-08 04:23:15 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:15 --> Input Class Initialized
INFO - 2021-01-08 04:23:15 --> Language Class Initialized
INFO - 2021-01-08 04:23:15 --> Language Class Initialized
INFO - 2021-01-08 04:23:15 --> Config Class Initialized
INFO - 2021-01-08 04:23:15 --> Loader Class Initialized
INFO - 2021-01-08 04:23:15 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:15 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:15 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:15 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:16 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:16 --> Controller Class Initialized
DEBUG - 2021-01-08 04:23:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-08 04:23:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 04:23:16 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:16 --> Total execution time: 0.4338
INFO - 2021-01-08 04:23:17 --> Config Class Initialized
INFO - 2021-01-08 04:23:17 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:17 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:17 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:17 --> URI Class Initialized
INFO - 2021-01-08 04:23:17 --> Router Class Initialized
INFO - 2021-01-08 04:23:17 --> Output Class Initialized
INFO - 2021-01-08 04:23:17 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:17 --> Input Class Initialized
INFO - 2021-01-08 04:23:17 --> Language Class Initialized
INFO - 2021-01-08 04:23:17 --> Language Class Initialized
INFO - 2021-01-08 04:23:17 --> Config Class Initialized
INFO - 2021-01-08 04:23:17 --> Loader Class Initialized
INFO - 2021-01-08 04:23:17 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:17 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:17 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:17 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:17 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:17 --> Controller Class Initialized
INFO - 2021-01-08 04:23:17 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:17 --> Total execution time: 0.2612
INFO - 2021-01-08 04:23:22 --> Config Class Initialized
INFO - 2021-01-08 04:23:22 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:22 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:22 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:22 --> URI Class Initialized
INFO - 2021-01-08 04:23:22 --> Router Class Initialized
INFO - 2021-01-08 04:23:22 --> Output Class Initialized
INFO - 2021-01-08 04:23:22 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:22 --> Input Class Initialized
INFO - 2021-01-08 04:23:22 --> Language Class Initialized
INFO - 2021-01-08 04:23:22 --> Language Class Initialized
INFO - 2021-01-08 04:23:22 --> Config Class Initialized
INFO - 2021-01-08 04:23:22 --> Loader Class Initialized
INFO - 2021-01-08 04:23:22 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:22 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:22 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:22 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:22 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:22 --> Controller Class Initialized
INFO - 2021-01-08 04:23:22 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:22 --> Total execution time: 0.3502
INFO - 2021-01-08 04:23:24 --> Config Class Initialized
INFO - 2021-01-08 04:23:24 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:24 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:24 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:24 --> URI Class Initialized
INFO - 2021-01-08 04:23:24 --> Router Class Initialized
INFO - 2021-01-08 04:23:24 --> Output Class Initialized
INFO - 2021-01-08 04:23:24 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:24 --> Input Class Initialized
INFO - 2021-01-08 04:23:24 --> Language Class Initialized
INFO - 2021-01-08 04:23:24 --> Language Class Initialized
INFO - 2021-01-08 04:23:24 --> Config Class Initialized
INFO - 2021-01-08 04:23:24 --> Loader Class Initialized
INFO - 2021-01-08 04:23:24 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:24 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:24 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:24 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:24 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:24 --> Controller Class Initialized
INFO - 2021-01-08 04:23:24 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:24 --> Total execution time: 0.2542
INFO - 2021-01-08 04:23:28 --> Config Class Initialized
INFO - 2021-01-08 04:23:28 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:28 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:28 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:28 --> URI Class Initialized
INFO - 2021-01-08 04:23:28 --> Router Class Initialized
INFO - 2021-01-08 04:23:28 --> Output Class Initialized
INFO - 2021-01-08 04:23:28 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:28 --> Input Class Initialized
INFO - 2021-01-08 04:23:28 --> Language Class Initialized
INFO - 2021-01-08 04:23:28 --> Language Class Initialized
INFO - 2021-01-08 04:23:28 --> Config Class Initialized
INFO - 2021-01-08 04:23:28 --> Loader Class Initialized
INFO - 2021-01-08 04:23:28 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:28 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:28 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:28 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:28 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:28 --> Controller Class Initialized
INFO - 2021-01-08 04:23:28 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:28 --> Total execution time: 0.3407
INFO - 2021-01-08 04:23:33 --> Config Class Initialized
INFO - 2021-01-08 04:23:33 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:33 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:33 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:33 --> URI Class Initialized
INFO - 2021-01-08 04:23:33 --> Router Class Initialized
INFO - 2021-01-08 04:23:33 --> Output Class Initialized
INFO - 2021-01-08 04:23:33 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:33 --> Input Class Initialized
INFO - 2021-01-08 04:23:33 --> Language Class Initialized
INFO - 2021-01-08 04:23:33 --> Language Class Initialized
INFO - 2021-01-08 04:23:33 --> Config Class Initialized
INFO - 2021-01-08 04:23:33 --> Loader Class Initialized
INFO - 2021-01-08 04:23:33 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:33 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:33 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:34 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:34 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:34 --> Controller Class Initialized
DEBUG - 2021-01-08 04:23:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-08 04:23:34 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:34 --> Total execution time: 0.2949
INFO - 2021-01-08 04:23:37 --> Config Class Initialized
INFO - 2021-01-08 04:23:37 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:23:37 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:23:37 --> Utf8 Class Initialized
INFO - 2021-01-08 04:23:37 --> URI Class Initialized
INFO - 2021-01-08 04:23:37 --> Router Class Initialized
INFO - 2021-01-08 04:23:37 --> Output Class Initialized
INFO - 2021-01-08 04:23:37 --> Security Class Initialized
DEBUG - 2021-01-08 04:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:23:37 --> Input Class Initialized
INFO - 2021-01-08 04:23:37 --> Language Class Initialized
INFO - 2021-01-08 04:23:37 --> Language Class Initialized
INFO - 2021-01-08 04:23:37 --> Config Class Initialized
INFO - 2021-01-08 04:23:37 --> Loader Class Initialized
INFO - 2021-01-08 04:23:37 --> Helper loaded: url_helper
INFO - 2021-01-08 04:23:37 --> Helper loaded: file_helper
INFO - 2021-01-08 04:23:37 --> Helper loaded: form_helper
INFO - 2021-01-08 04:23:37 --> Helper loaded: my_helper
INFO - 2021-01-08 04:23:37 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:23:37 --> Controller Class Initialized
DEBUG - 2021-01-08 04:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:23:37 --> Final output sent to browser
DEBUG - 2021-01-08 04:23:37 --> Total execution time: 0.2656
INFO - 2021-01-08 04:25:31 --> Config Class Initialized
INFO - 2021-01-08 04:25:31 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:25:31 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:25:31 --> Utf8 Class Initialized
INFO - 2021-01-08 04:25:31 --> URI Class Initialized
INFO - 2021-01-08 04:25:31 --> Router Class Initialized
INFO - 2021-01-08 04:25:31 --> Output Class Initialized
INFO - 2021-01-08 04:25:31 --> Security Class Initialized
DEBUG - 2021-01-08 04:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:25:31 --> Input Class Initialized
INFO - 2021-01-08 04:25:31 --> Language Class Initialized
INFO - 2021-01-08 04:25:31 --> Language Class Initialized
INFO - 2021-01-08 04:25:31 --> Config Class Initialized
INFO - 2021-01-08 04:25:31 --> Loader Class Initialized
INFO - 2021-01-08 04:25:31 --> Helper loaded: url_helper
INFO - 2021-01-08 04:25:31 --> Helper loaded: file_helper
INFO - 2021-01-08 04:25:31 --> Helper loaded: form_helper
INFO - 2021-01-08 04:25:31 --> Helper loaded: my_helper
INFO - 2021-01-08 04:25:31 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:25:31 --> Controller Class Initialized
DEBUG - 2021-01-08 04:25:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:25:31 --> Final output sent to browser
DEBUG - 2021-01-08 04:25:31 --> Total execution time: 0.3256
INFO - 2021-01-08 04:25:38 --> Config Class Initialized
INFO - 2021-01-08 04:25:38 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:25:38 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:25:38 --> Utf8 Class Initialized
INFO - 2021-01-08 04:25:38 --> URI Class Initialized
INFO - 2021-01-08 04:25:38 --> Router Class Initialized
INFO - 2021-01-08 04:25:38 --> Output Class Initialized
INFO - 2021-01-08 04:25:38 --> Security Class Initialized
DEBUG - 2021-01-08 04:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:25:38 --> Input Class Initialized
INFO - 2021-01-08 04:25:38 --> Language Class Initialized
INFO - 2021-01-08 04:25:38 --> Language Class Initialized
INFO - 2021-01-08 04:25:38 --> Config Class Initialized
INFO - 2021-01-08 04:25:38 --> Loader Class Initialized
INFO - 2021-01-08 04:25:39 --> Helper loaded: url_helper
INFO - 2021-01-08 04:25:39 --> Helper loaded: file_helper
INFO - 2021-01-08 04:25:39 --> Helper loaded: form_helper
INFO - 2021-01-08 04:25:39 --> Helper loaded: my_helper
INFO - 2021-01-08 04:25:39 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:25:39 --> Controller Class Initialized
DEBUG - 2021-01-08 04:25:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:25:39 --> Final output sent to browser
DEBUG - 2021-01-08 04:25:39 --> Total execution time: 0.3367
INFO - 2021-01-08 04:25:52 --> Config Class Initialized
INFO - 2021-01-08 04:25:52 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:25:52 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:25:52 --> Utf8 Class Initialized
INFO - 2021-01-08 04:25:52 --> URI Class Initialized
INFO - 2021-01-08 04:25:52 --> Router Class Initialized
INFO - 2021-01-08 04:25:52 --> Output Class Initialized
INFO - 2021-01-08 04:25:52 --> Security Class Initialized
DEBUG - 2021-01-08 04:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:25:52 --> Input Class Initialized
INFO - 2021-01-08 04:25:52 --> Language Class Initialized
INFO - 2021-01-08 04:25:52 --> Language Class Initialized
INFO - 2021-01-08 04:25:52 --> Config Class Initialized
INFO - 2021-01-08 04:25:52 --> Loader Class Initialized
INFO - 2021-01-08 04:25:52 --> Helper loaded: url_helper
INFO - 2021-01-08 04:25:52 --> Helper loaded: file_helper
INFO - 2021-01-08 04:25:52 --> Helper loaded: form_helper
INFO - 2021-01-08 04:25:52 --> Helper loaded: my_helper
INFO - 2021-01-08 04:25:52 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:25:52 --> Controller Class Initialized
DEBUG - 2021-01-08 04:25:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:25:52 --> Final output sent to browser
DEBUG - 2021-01-08 04:25:52 --> Total execution time: 0.3549
INFO - 2021-01-08 04:26:02 --> Config Class Initialized
INFO - 2021-01-08 04:26:02 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:26:02 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:26:02 --> Utf8 Class Initialized
INFO - 2021-01-08 04:26:02 --> URI Class Initialized
INFO - 2021-01-08 04:26:03 --> Router Class Initialized
INFO - 2021-01-08 04:26:03 --> Output Class Initialized
INFO - 2021-01-08 04:26:03 --> Security Class Initialized
DEBUG - 2021-01-08 04:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:26:03 --> Input Class Initialized
INFO - 2021-01-08 04:26:03 --> Language Class Initialized
INFO - 2021-01-08 04:26:03 --> Language Class Initialized
INFO - 2021-01-08 04:26:03 --> Config Class Initialized
INFO - 2021-01-08 04:26:03 --> Loader Class Initialized
INFO - 2021-01-08 04:26:03 --> Helper loaded: url_helper
INFO - 2021-01-08 04:26:03 --> Helper loaded: file_helper
INFO - 2021-01-08 04:26:03 --> Helper loaded: form_helper
INFO - 2021-01-08 04:26:03 --> Helper loaded: my_helper
INFO - 2021-01-08 04:26:03 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:26:03 --> Controller Class Initialized
DEBUG - 2021-01-08 04:26:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:26:03 --> Final output sent to browser
DEBUG - 2021-01-08 04:26:03 --> Total execution time: 0.3718
INFO - 2021-01-08 04:26:19 --> Config Class Initialized
INFO - 2021-01-08 04:26:19 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:26:19 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:26:19 --> Utf8 Class Initialized
INFO - 2021-01-08 04:26:19 --> URI Class Initialized
INFO - 2021-01-08 04:26:19 --> Router Class Initialized
INFO - 2021-01-08 04:26:19 --> Output Class Initialized
INFO - 2021-01-08 04:26:19 --> Security Class Initialized
DEBUG - 2021-01-08 04:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:26:19 --> Input Class Initialized
INFO - 2021-01-08 04:26:19 --> Language Class Initialized
INFO - 2021-01-08 04:26:19 --> Language Class Initialized
INFO - 2021-01-08 04:26:19 --> Config Class Initialized
INFO - 2021-01-08 04:26:19 --> Loader Class Initialized
INFO - 2021-01-08 04:26:19 --> Helper loaded: url_helper
INFO - 2021-01-08 04:26:19 --> Helper loaded: file_helper
INFO - 2021-01-08 04:26:19 --> Helper loaded: form_helper
INFO - 2021-01-08 04:26:19 --> Helper loaded: my_helper
INFO - 2021-01-08 04:26:19 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:26:19 --> Controller Class Initialized
DEBUG - 2021-01-08 04:26:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:26:19 --> Final output sent to browser
DEBUG - 2021-01-08 04:26:19 --> Total execution time: 0.3696
INFO - 2021-01-08 04:26:49 --> Config Class Initialized
INFO - 2021-01-08 04:26:49 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:26:49 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:26:49 --> Utf8 Class Initialized
INFO - 2021-01-08 04:26:49 --> URI Class Initialized
INFO - 2021-01-08 04:26:49 --> Router Class Initialized
INFO - 2021-01-08 04:26:49 --> Output Class Initialized
INFO - 2021-01-08 04:26:49 --> Security Class Initialized
DEBUG - 2021-01-08 04:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:26:49 --> Input Class Initialized
INFO - 2021-01-08 04:26:49 --> Language Class Initialized
INFO - 2021-01-08 04:26:49 --> Language Class Initialized
INFO - 2021-01-08 04:26:49 --> Config Class Initialized
INFO - 2021-01-08 04:26:49 --> Loader Class Initialized
INFO - 2021-01-08 04:26:49 --> Helper loaded: url_helper
INFO - 2021-01-08 04:26:49 --> Helper loaded: file_helper
INFO - 2021-01-08 04:26:49 --> Helper loaded: form_helper
INFO - 2021-01-08 04:26:49 --> Helper loaded: my_helper
INFO - 2021-01-08 04:26:49 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:26:49 --> Controller Class Initialized
DEBUG - 2021-01-08 04:26:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:26:49 --> Final output sent to browser
DEBUG - 2021-01-08 04:26:49 --> Total execution time: 0.3420
INFO - 2021-01-08 04:26:56 --> Config Class Initialized
INFO - 2021-01-08 04:26:56 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:26:56 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:26:56 --> Utf8 Class Initialized
INFO - 2021-01-08 04:26:56 --> URI Class Initialized
INFO - 2021-01-08 04:26:56 --> Router Class Initialized
INFO - 2021-01-08 04:26:56 --> Output Class Initialized
INFO - 2021-01-08 04:26:56 --> Security Class Initialized
DEBUG - 2021-01-08 04:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:26:56 --> Input Class Initialized
INFO - 2021-01-08 04:26:56 --> Language Class Initialized
INFO - 2021-01-08 04:26:56 --> Language Class Initialized
INFO - 2021-01-08 04:26:56 --> Config Class Initialized
INFO - 2021-01-08 04:26:56 --> Loader Class Initialized
INFO - 2021-01-08 04:26:56 --> Helper loaded: url_helper
INFO - 2021-01-08 04:26:56 --> Helper loaded: file_helper
INFO - 2021-01-08 04:26:56 --> Helper loaded: form_helper
INFO - 2021-01-08 04:26:56 --> Helper loaded: my_helper
INFO - 2021-01-08 04:26:56 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:26:56 --> Controller Class Initialized
DEBUG - 2021-01-08 04:26:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:26:56 --> Final output sent to browser
DEBUG - 2021-01-08 04:26:56 --> Total execution time: 0.3393
INFO - 2021-01-08 04:27:10 --> Config Class Initialized
INFO - 2021-01-08 04:27:10 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:27:10 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:27:10 --> Utf8 Class Initialized
INFO - 2021-01-08 04:27:10 --> URI Class Initialized
INFO - 2021-01-08 04:27:10 --> Router Class Initialized
INFO - 2021-01-08 04:27:10 --> Output Class Initialized
INFO - 2021-01-08 04:27:10 --> Security Class Initialized
DEBUG - 2021-01-08 04:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:27:10 --> Input Class Initialized
INFO - 2021-01-08 04:27:10 --> Language Class Initialized
INFO - 2021-01-08 04:27:10 --> Language Class Initialized
INFO - 2021-01-08 04:27:10 --> Config Class Initialized
INFO - 2021-01-08 04:27:10 --> Loader Class Initialized
INFO - 2021-01-08 04:27:10 --> Helper loaded: url_helper
INFO - 2021-01-08 04:27:10 --> Helper loaded: file_helper
INFO - 2021-01-08 04:27:10 --> Helper loaded: form_helper
INFO - 2021-01-08 04:27:10 --> Helper loaded: my_helper
INFO - 2021-01-08 04:27:10 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:27:10 --> Controller Class Initialized
DEBUG - 2021-01-08 04:27:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:27:10 --> Final output sent to browser
DEBUG - 2021-01-08 04:27:10 --> Total execution time: 0.3411
INFO - 2021-01-08 04:27:27 --> Config Class Initialized
INFO - 2021-01-08 04:27:27 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:27:27 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:27:27 --> Utf8 Class Initialized
INFO - 2021-01-08 04:27:27 --> URI Class Initialized
INFO - 2021-01-08 04:27:27 --> Router Class Initialized
INFO - 2021-01-08 04:27:27 --> Output Class Initialized
INFO - 2021-01-08 04:27:27 --> Security Class Initialized
DEBUG - 2021-01-08 04:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:27:27 --> Input Class Initialized
INFO - 2021-01-08 04:27:27 --> Language Class Initialized
INFO - 2021-01-08 04:27:27 --> Language Class Initialized
INFO - 2021-01-08 04:27:27 --> Config Class Initialized
INFO - 2021-01-08 04:27:27 --> Loader Class Initialized
INFO - 2021-01-08 04:27:27 --> Helper loaded: url_helper
INFO - 2021-01-08 04:27:27 --> Helper loaded: file_helper
INFO - 2021-01-08 04:27:27 --> Helper loaded: form_helper
INFO - 2021-01-08 04:27:27 --> Helper loaded: my_helper
INFO - 2021-01-08 04:27:27 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:27:27 --> Controller Class Initialized
DEBUG - 2021-01-08 04:27:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:27:27 --> Final output sent to browser
DEBUG - 2021-01-08 04:27:27 --> Total execution time: 0.3492
INFO - 2021-01-08 04:27:37 --> Config Class Initialized
INFO - 2021-01-08 04:27:37 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:27:37 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:27:37 --> Utf8 Class Initialized
INFO - 2021-01-08 04:27:37 --> URI Class Initialized
INFO - 2021-01-08 04:27:37 --> Router Class Initialized
INFO - 2021-01-08 04:27:37 --> Output Class Initialized
INFO - 2021-01-08 04:27:37 --> Security Class Initialized
DEBUG - 2021-01-08 04:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:27:37 --> Input Class Initialized
INFO - 2021-01-08 04:27:37 --> Language Class Initialized
INFO - 2021-01-08 04:27:37 --> Language Class Initialized
INFO - 2021-01-08 04:27:37 --> Config Class Initialized
INFO - 2021-01-08 04:27:37 --> Loader Class Initialized
INFO - 2021-01-08 04:27:37 --> Helper loaded: url_helper
INFO - 2021-01-08 04:27:37 --> Helper loaded: file_helper
INFO - 2021-01-08 04:27:37 --> Helper loaded: form_helper
INFO - 2021-01-08 04:27:37 --> Helper loaded: my_helper
INFO - 2021-01-08 04:27:37 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:27:37 --> Controller Class Initialized
DEBUG - 2021-01-08 04:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:27:37 --> Final output sent to browser
DEBUG - 2021-01-08 04:27:37 --> Total execution time: 0.3625
INFO - 2021-01-08 04:28:47 --> Config Class Initialized
INFO - 2021-01-08 04:28:47 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:28:47 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:28:47 --> Utf8 Class Initialized
INFO - 2021-01-08 04:28:47 --> URI Class Initialized
INFO - 2021-01-08 04:28:47 --> Router Class Initialized
INFO - 2021-01-08 04:28:47 --> Output Class Initialized
INFO - 2021-01-08 04:28:47 --> Security Class Initialized
DEBUG - 2021-01-08 04:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:28:47 --> Input Class Initialized
INFO - 2021-01-08 04:28:47 --> Language Class Initialized
INFO - 2021-01-08 04:28:47 --> Language Class Initialized
INFO - 2021-01-08 04:28:47 --> Config Class Initialized
INFO - 2021-01-08 04:28:47 --> Loader Class Initialized
INFO - 2021-01-08 04:28:47 --> Helper loaded: url_helper
INFO - 2021-01-08 04:28:47 --> Helper loaded: file_helper
INFO - 2021-01-08 04:28:47 --> Helper loaded: form_helper
INFO - 2021-01-08 04:28:47 --> Helper loaded: my_helper
INFO - 2021-01-08 04:28:47 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:28:47 --> Controller Class Initialized
DEBUG - 2021-01-08 04:28:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:28:47 --> Final output sent to browser
DEBUG - 2021-01-08 04:28:47 --> Total execution time: 0.3698
INFO - 2021-01-08 04:28:56 --> Config Class Initialized
INFO - 2021-01-08 04:28:56 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:28:56 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:28:56 --> Utf8 Class Initialized
INFO - 2021-01-08 04:28:56 --> URI Class Initialized
INFO - 2021-01-08 04:28:56 --> Router Class Initialized
INFO - 2021-01-08 04:28:56 --> Output Class Initialized
INFO - 2021-01-08 04:28:56 --> Security Class Initialized
DEBUG - 2021-01-08 04:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:28:56 --> Input Class Initialized
INFO - 2021-01-08 04:28:56 --> Language Class Initialized
INFO - 2021-01-08 04:28:56 --> Language Class Initialized
INFO - 2021-01-08 04:28:56 --> Config Class Initialized
INFO - 2021-01-08 04:28:56 --> Loader Class Initialized
INFO - 2021-01-08 04:28:56 --> Helper loaded: url_helper
INFO - 2021-01-08 04:28:56 --> Helper loaded: file_helper
INFO - 2021-01-08 04:28:56 --> Helper loaded: form_helper
INFO - 2021-01-08 04:28:56 --> Helper loaded: my_helper
INFO - 2021-01-08 04:28:56 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:28:56 --> Controller Class Initialized
DEBUG - 2021-01-08 04:28:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:28:56 --> Final output sent to browser
DEBUG - 2021-01-08 04:28:56 --> Total execution time: 0.3460
INFO - 2021-01-08 04:29:33 --> Config Class Initialized
INFO - 2021-01-08 04:29:33 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:29:33 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:29:33 --> Utf8 Class Initialized
INFO - 2021-01-08 04:29:33 --> URI Class Initialized
INFO - 2021-01-08 04:29:33 --> Router Class Initialized
INFO - 2021-01-08 04:29:33 --> Output Class Initialized
INFO - 2021-01-08 04:29:33 --> Security Class Initialized
DEBUG - 2021-01-08 04:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:29:33 --> Input Class Initialized
INFO - 2021-01-08 04:29:33 --> Language Class Initialized
INFO - 2021-01-08 04:29:33 --> Language Class Initialized
INFO - 2021-01-08 04:29:33 --> Config Class Initialized
INFO - 2021-01-08 04:29:33 --> Loader Class Initialized
INFO - 2021-01-08 04:29:33 --> Helper loaded: url_helper
INFO - 2021-01-08 04:29:33 --> Helper loaded: file_helper
INFO - 2021-01-08 04:29:33 --> Helper loaded: form_helper
INFO - 2021-01-08 04:29:33 --> Helper loaded: my_helper
INFO - 2021-01-08 04:29:33 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:29:33 --> Controller Class Initialized
DEBUG - 2021-01-08 04:29:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:29:33 --> Final output sent to browser
DEBUG - 2021-01-08 04:29:33 --> Total execution time: 0.3800
INFO - 2021-01-08 04:29:56 --> Config Class Initialized
INFO - 2021-01-08 04:29:56 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:29:56 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:29:56 --> Utf8 Class Initialized
INFO - 2021-01-08 04:29:56 --> URI Class Initialized
INFO - 2021-01-08 04:29:56 --> Router Class Initialized
INFO - 2021-01-08 04:29:56 --> Output Class Initialized
INFO - 2021-01-08 04:29:56 --> Security Class Initialized
DEBUG - 2021-01-08 04:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:29:56 --> Input Class Initialized
INFO - 2021-01-08 04:29:56 --> Language Class Initialized
INFO - 2021-01-08 04:29:56 --> Language Class Initialized
INFO - 2021-01-08 04:29:56 --> Config Class Initialized
INFO - 2021-01-08 04:29:56 --> Loader Class Initialized
INFO - 2021-01-08 04:29:56 --> Helper loaded: url_helper
INFO - 2021-01-08 04:29:56 --> Helper loaded: file_helper
INFO - 2021-01-08 04:29:56 --> Helper loaded: form_helper
INFO - 2021-01-08 04:29:56 --> Helper loaded: my_helper
INFO - 2021-01-08 04:29:56 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:29:56 --> Controller Class Initialized
DEBUG - 2021-01-08 04:29:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:29:56 --> Final output sent to browser
DEBUG - 2021-01-08 04:29:56 --> Total execution time: 0.3487
INFO - 2021-01-08 04:30:55 --> Config Class Initialized
INFO - 2021-01-08 04:30:55 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:30:55 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:30:55 --> Utf8 Class Initialized
INFO - 2021-01-08 04:30:55 --> URI Class Initialized
INFO - 2021-01-08 04:30:55 --> Router Class Initialized
INFO - 2021-01-08 04:30:55 --> Output Class Initialized
INFO - 2021-01-08 04:30:55 --> Security Class Initialized
DEBUG - 2021-01-08 04:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:30:55 --> Input Class Initialized
INFO - 2021-01-08 04:30:55 --> Language Class Initialized
INFO - 2021-01-08 04:30:56 --> Language Class Initialized
INFO - 2021-01-08 04:30:56 --> Config Class Initialized
INFO - 2021-01-08 04:30:56 --> Loader Class Initialized
INFO - 2021-01-08 04:30:56 --> Helper loaded: url_helper
INFO - 2021-01-08 04:30:56 --> Helper loaded: file_helper
INFO - 2021-01-08 04:30:56 --> Helper loaded: form_helper
INFO - 2021-01-08 04:30:56 --> Helper loaded: my_helper
INFO - 2021-01-08 04:30:56 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:30:56 --> Controller Class Initialized
DEBUG - 2021-01-08 04:30:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:30:56 --> Final output sent to browser
DEBUG - 2021-01-08 04:30:56 --> Total execution time: 0.3600
INFO - 2021-01-08 04:31:06 --> Config Class Initialized
INFO - 2021-01-08 04:31:06 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:31:06 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:31:06 --> Utf8 Class Initialized
INFO - 2021-01-08 04:31:06 --> URI Class Initialized
INFO - 2021-01-08 04:31:07 --> Router Class Initialized
INFO - 2021-01-08 04:31:07 --> Output Class Initialized
INFO - 2021-01-08 04:31:07 --> Security Class Initialized
DEBUG - 2021-01-08 04:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:31:07 --> Input Class Initialized
INFO - 2021-01-08 04:31:07 --> Language Class Initialized
INFO - 2021-01-08 04:31:07 --> Language Class Initialized
INFO - 2021-01-08 04:31:07 --> Config Class Initialized
INFO - 2021-01-08 04:31:07 --> Loader Class Initialized
INFO - 2021-01-08 04:31:07 --> Helper loaded: url_helper
INFO - 2021-01-08 04:31:07 --> Helper loaded: file_helper
INFO - 2021-01-08 04:31:07 --> Helper loaded: form_helper
INFO - 2021-01-08 04:31:07 --> Helper loaded: my_helper
INFO - 2021-01-08 04:31:07 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:31:07 --> Controller Class Initialized
DEBUG - 2021-01-08 04:31:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:31:07 --> Final output sent to browser
DEBUG - 2021-01-08 04:31:07 --> Total execution time: 0.3470
INFO - 2021-01-08 04:33:36 --> Config Class Initialized
INFO - 2021-01-08 04:33:36 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:33:36 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:33:36 --> Utf8 Class Initialized
INFO - 2021-01-08 04:33:36 --> URI Class Initialized
INFO - 2021-01-08 04:33:36 --> Router Class Initialized
INFO - 2021-01-08 04:33:36 --> Output Class Initialized
INFO - 2021-01-08 04:33:36 --> Security Class Initialized
DEBUG - 2021-01-08 04:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:33:36 --> Input Class Initialized
INFO - 2021-01-08 04:33:36 --> Language Class Initialized
INFO - 2021-01-08 04:33:36 --> Language Class Initialized
INFO - 2021-01-08 04:33:36 --> Config Class Initialized
INFO - 2021-01-08 04:33:36 --> Loader Class Initialized
INFO - 2021-01-08 04:33:36 --> Helper loaded: url_helper
INFO - 2021-01-08 04:33:37 --> Helper loaded: file_helper
INFO - 2021-01-08 04:33:37 --> Helper loaded: form_helper
INFO - 2021-01-08 04:33:37 --> Helper loaded: my_helper
INFO - 2021-01-08 04:33:37 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:33:37 --> Controller Class Initialized
DEBUG - 2021-01-08 04:33:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:33:37 --> Final output sent to browser
DEBUG - 2021-01-08 04:33:37 --> Total execution time: 0.3813
INFO - 2021-01-08 04:33:46 --> Config Class Initialized
INFO - 2021-01-08 04:33:46 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:33:46 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:33:46 --> Utf8 Class Initialized
INFO - 2021-01-08 04:33:46 --> URI Class Initialized
INFO - 2021-01-08 04:33:46 --> Router Class Initialized
INFO - 2021-01-08 04:33:47 --> Output Class Initialized
INFO - 2021-01-08 04:33:47 --> Security Class Initialized
DEBUG - 2021-01-08 04:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:33:47 --> Input Class Initialized
INFO - 2021-01-08 04:33:47 --> Language Class Initialized
INFO - 2021-01-08 04:33:47 --> Language Class Initialized
INFO - 2021-01-08 04:33:47 --> Config Class Initialized
INFO - 2021-01-08 04:33:47 --> Loader Class Initialized
INFO - 2021-01-08 04:33:47 --> Helper loaded: url_helper
INFO - 2021-01-08 04:33:47 --> Helper loaded: file_helper
INFO - 2021-01-08 04:33:47 --> Helper loaded: form_helper
INFO - 2021-01-08 04:33:47 --> Helper loaded: my_helper
INFO - 2021-01-08 04:33:47 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:33:47 --> Controller Class Initialized
DEBUG - 2021-01-08 04:33:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:33:47 --> Final output sent to browser
DEBUG - 2021-01-08 04:33:47 --> Total execution time: 0.3340
INFO - 2021-01-08 04:33:53 --> Config Class Initialized
INFO - 2021-01-08 04:33:53 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:33:53 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:33:53 --> Utf8 Class Initialized
INFO - 2021-01-08 04:33:53 --> URI Class Initialized
INFO - 2021-01-08 04:33:53 --> Router Class Initialized
INFO - 2021-01-08 04:33:53 --> Output Class Initialized
INFO - 2021-01-08 04:33:53 --> Security Class Initialized
DEBUG - 2021-01-08 04:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:33:53 --> Input Class Initialized
INFO - 2021-01-08 04:33:53 --> Language Class Initialized
INFO - 2021-01-08 04:33:53 --> Language Class Initialized
INFO - 2021-01-08 04:33:53 --> Config Class Initialized
INFO - 2021-01-08 04:33:53 --> Loader Class Initialized
INFO - 2021-01-08 04:33:53 --> Helper loaded: url_helper
INFO - 2021-01-08 04:33:53 --> Helper loaded: file_helper
INFO - 2021-01-08 04:33:53 --> Helper loaded: form_helper
INFO - 2021-01-08 04:33:53 --> Helper loaded: my_helper
INFO - 2021-01-08 04:33:53 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:33:53 --> Controller Class Initialized
DEBUG - 2021-01-08 04:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:33:53 --> Final output sent to browser
DEBUG - 2021-01-08 04:33:53 --> Total execution time: 0.3644
INFO - 2021-01-08 04:34:03 --> Config Class Initialized
INFO - 2021-01-08 04:34:03 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:34:03 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:34:03 --> Utf8 Class Initialized
INFO - 2021-01-08 04:34:03 --> URI Class Initialized
INFO - 2021-01-08 04:34:03 --> Router Class Initialized
INFO - 2021-01-08 04:34:03 --> Output Class Initialized
INFO - 2021-01-08 04:34:03 --> Security Class Initialized
DEBUG - 2021-01-08 04:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:34:03 --> Input Class Initialized
INFO - 2021-01-08 04:34:03 --> Language Class Initialized
INFO - 2021-01-08 04:34:03 --> Language Class Initialized
INFO - 2021-01-08 04:34:03 --> Config Class Initialized
INFO - 2021-01-08 04:34:03 --> Loader Class Initialized
INFO - 2021-01-08 04:34:03 --> Helper loaded: url_helper
INFO - 2021-01-08 04:34:03 --> Helper loaded: file_helper
INFO - 2021-01-08 04:34:03 --> Helper loaded: form_helper
INFO - 2021-01-08 04:34:03 --> Helper loaded: my_helper
INFO - 2021-01-08 04:34:03 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:34:03 --> Controller Class Initialized
DEBUG - 2021-01-08 04:34:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:34:03 --> Final output sent to browser
DEBUG - 2021-01-08 04:34:03 --> Total execution time: 0.3511
INFO - 2021-01-08 04:34:08 --> Config Class Initialized
INFO - 2021-01-08 04:34:08 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:34:08 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:34:08 --> Utf8 Class Initialized
INFO - 2021-01-08 04:34:08 --> URI Class Initialized
INFO - 2021-01-08 04:34:08 --> Router Class Initialized
INFO - 2021-01-08 04:34:08 --> Output Class Initialized
INFO - 2021-01-08 04:34:08 --> Security Class Initialized
DEBUG - 2021-01-08 04:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:34:08 --> Input Class Initialized
INFO - 2021-01-08 04:34:08 --> Language Class Initialized
INFO - 2021-01-08 04:34:08 --> Language Class Initialized
INFO - 2021-01-08 04:34:08 --> Config Class Initialized
INFO - 2021-01-08 04:34:08 --> Loader Class Initialized
INFO - 2021-01-08 04:34:08 --> Helper loaded: url_helper
INFO - 2021-01-08 04:34:08 --> Helper loaded: file_helper
INFO - 2021-01-08 04:34:08 --> Helper loaded: form_helper
INFO - 2021-01-08 04:34:08 --> Helper loaded: my_helper
INFO - 2021-01-08 04:34:08 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:34:08 --> Controller Class Initialized
DEBUG - 2021-01-08 04:34:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:34:08 --> Final output sent to browser
DEBUG - 2021-01-08 04:34:08 --> Total execution time: 0.3792
INFO - 2021-01-08 04:34:12 --> Config Class Initialized
INFO - 2021-01-08 04:34:12 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:34:12 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:34:12 --> Utf8 Class Initialized
INFO - 2021-01-08 04:34:12 --> URI Class Initialized
INFO - 2021-01-08 04:34:12 --> Router Class Initialized
INFO - 2021-01-08 04:34:12 --> Output Class Initialized
INFO - 2021-01-08 04:34:12 --> Security Class Initialized
DEBUG - 2021-01-08 04:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:34:12 --> Input Class Initialized
INFO - 2021-01-08 04:34:12 --> Language Class Initialized
INFO - 2021-01-08 04:34:12 --> Language Class Initialized
INFO - 2021-01-08 04:34:13 --> Config Class Initialized
INFO - 2021-01-08 04:34:13 --> Loader Class Initialized
INFO - 2021-01-08 04:34:13 --> Helper loaded: url_helper
INFO - 2021-01-08 04:34:13 --> Helper loaded: file_helper
INFO - 2021-01-08 04:34:13 --> Helper loaded: form_helper
INFO - 2021-01-08 04:34:13 --> Helper loaded: my_helper
INFO - 2021-01-08 04:34:13 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:34:13 --> Controller Class Initialized
DEBUG - 2021-01-08 04:34:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:34:13 --> Final output sent to browser
DEBUG - 2021-01-08 04:34:13 --> Total execution time: 0.3548
INFO - 2021-01-08 04:35:11 --> Config Class Initialized
INFO - 2021-01-08 04:35:11 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:35:11 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:35:11 --> Utf8 Class Initialized
INFO - 2021-01-08 04:35:11 --> URI Class Initialized
INFO - 2021-01-08 04:35:11 --> Router Class Initialized
INFO - 2021-01-08 04:35:11 --> Output Class Initialized
INFO - 2021-01-08 04:35:11 --> Security Class Initialized
DEBUG - 2021-01-08 04:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:35:11 --> Input Class Initialized
INFO - 2021-01-08 04:35:11 --> Language Class Initialized
INFO - 2021-01-08 04:35:11 --> Language Class Initialized
INFO - 2021-01-08 04:35:11 --> Config Class Initialized
INFO - 2021-01-08 04:35:11 --> Loader Class Initialized
INFO - 2021-01-08 04:35:11 --> Helper loaded: url_helper
INFO - 2021-01-08 04:35:11 --> Helper loaded: file_helper
INFO - 2021-01-08 04:35:11 --> Helper loaded: form_helper
INFO - 2021-01-08 04:35:11 --> Helper loaded: my_helper
INFO - 2021-01-08 04:35:12 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:35:12 --> Controller Class Initialized
DEBUG - 2021-01-08 04:35:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:35:12 --> Final output sent to browser
DEBUG - 2021-01-08 04:35:12 --> Total execution time: 0.3695
INFO - 2021-01-08 04:35:20 --> Config Class Initialized
INFO - 2021-01-08 04:35:20 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:35:20 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:35:20 --> Utf8 Class Initialized
INFO - 2021-01-08 04:35:20 --> URI Class Initialized
INFO - 2021-01-08 04:35:20 --> Router Class Initialized
INFO - 2021-01-08 04:35:20 --> Output Class Initialized
INFO - 2021-01-08 04:35:20 --> Security Class Initialized
DEBUG - 2021-01-08 04:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:35:20 --> Input Class Initialized
INFO - 2021-01-08 04:35:20 --> Language Class Initialized
INFO - 2021-01-08 04:35:20 --> Language Class Initialized
INFO - 2021-01-08 04:35:20 --> Config Class Initialized
INFO - 2021-01-08 04:35:20 --> Loader Class Initialized
INFO - 2021-01-08 04:35:20 --> Helper loaded: url_helper
INFO - 2021-01-08 04:35:20 --> Helper loaded: file_helper
INFO - 2021-01-08 04:35:20 --> Helper loaded: form_helper
INFO - 2021-01-08 04:35:20 --> Helper loaded: my_helper
INFO - 2021-01-08 04:35:20 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:35:20 --> Controller Class Initialized
DEBUG - 2021-01-08 04:35:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:35:20 --> Final output sent to browser
DEBUG - 2021-01-08 04:35:20 --> Total execution time: 0.3655
INFO - 2021-01-08 04:35:26 --> Config Class Initialized
INFO - 2021-01-08 04:35:26 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:35:26 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:35:26 --> Utf8 Class Initialized
INFO - 2021-01-08 04:35:26 --> URI Class Initialized
INFO - 2021-01-08 04:35:26 --> Router Class Initialized
INFO - 2021-01-08 04:35:26 --> Output Class Initialized
INFO - 2021-01-08 04:35:26 --> Security Class Initialized
DEBUG - 2021-01-08 04:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:35:26 --> Input Class Initialized
INFO - 2021-01-08 04:35:26 --> Language Class Initialized
INFO - 2021-01-08 04:35:26 --> Language Class Initialized
INFO - 2021-01-08 04:35:26 --> Config Class Initialized
INFO - 2021-01-08 04:35:26 --> Loader Class Initialized
INFO - 2021-01-08 04:35:26 --> Helper loaded: url_helper
INFO - 2021-01-08 04:35:26 --> Helper loaded: file_helper
INFO - 2021-01-08 04:35:26 --> Helper loaded: form_helper
INFO - 2021-01-08 04:35:26 --> Helper loaded: my_helper
INFO - 2021-01-08 04:35:26 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:35:26 --> Controller Class Initialized
DEBUG - 2021-01-08 04:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:35:26 --> Final output sent to browser
DEBUG - 2021-01-08 04:35:26 --> Total execution time: 0.3493
INFO - 2021-01-08 04:35:49 --> Config Class Initialized
INFO - 2021-01-08 04:35:49 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:35:49 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:35:49 --> Utf8 Class Initialized
INFO - 2021-01-08 04:35:49 --> URI Class Initialized
INFO - 2021-01-08 04:35:49 --> Router Class Initialized
INFO - 2021-01-08 04:35:49 --> Output Class Initialized
INFO - 2021-01-08 04:35:49 --> Security Class Initialized
DEBUG - 2021-01-08 04:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:35:49 --> Input Class Initialized
INFO - 2021-01-08 04:35:49 --> Language Class Initialized
INFO - 2021-01-08 04:35:49 --> Language Class Initialized
INFO - 2021-01-08 04:35:49 --> Config Class Initialized
INFO - 2021-01-08 04:35:49 --> Loader Class Initialized
INFO - 2021-01-08 04:35:49 --> Helper loaded: url_helper
INFO - 2021-01-08 04:35:49 --> Helper loaded: file_helper
INFO - 2021-01-08 04:35:49 --> Helper loaded: form_helper
INFO - 2021-01-08 04:35:49 --> Helper loaded: my_helper
INFO - 2021-01-08 04:35:49 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:35:49 --> Controller Class Initialized
DEBUG - 2021-01-08 04:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:35:49 --> Final output sent to browser
DEBUG - 2021-01-08 04:35:49 --> Total execution time: 0.4558
INFO - 2021-01-08 04:35:55 --> Config Class Initialized
INFO - 2021-01-08 04:35:55 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:35:55 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:35:55 --> Utf8 Class Initialized
INFO - 2021-01-08 04:35:55 --> URI Class Initialized
INFO - 2021-01-08 04:35:55 --> Router Class Initialized
INFO - 2021-01-08 04:35:55 --> Output Class Initialized
INFO - 2021-01-08 04:35:55 --> Security Class Initialized
DEBUG - 2021-01-08 04:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:35:55 --> Input Class Initialized
INFO - 2021-01-08 04:35:55 --> Language Class Initialized
INFO - 2021-01-08 04:35:55 --> Language Class Initialized
INFO - 2021-01-08 04:35:55 --> Config Class Initialized
INFO - 2021-01-08 04:35:55 --> Loader Class Initialized
INFO - 2021-01-08 04:35:55 --> Helper loaded: url_helper
INFO - 2021-01-08 04:35:55 --> Helper loaded: file_helper
INFO - 2021-01-08 04:35:55 --> Helper loaded: form_helper
INFO - 2021-01-08 04:35:55 --> Helper loaded: my_helper
INFO - 2021-01-08 04:35:55 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:35:55 --> Controller Class Initialized
DEBUG - 2021-01-08 04:35:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:35:55 --> Final output sent to browser
DEBUG - 2021-01-08 04:35:55 --> Total execution time: 0.3479
INFO - 2021-01-08 04:36:03 --> Config Class Initialized
INFO - 2021-01-08 04:36:03 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:36:03 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:36:03 --> Utf8 Class Initialized
INFO - 2021-01-08 04:36:03 --> URI Class Initialized
INFO - 2021-01-08 04:36:03 --> Router Class Initialized
INFO - 2021-01-08 04:36:03 --> Output Class Initialized
INFO - 2021-01-08 04:36:03 --> Security Class Initialized
DEBUG - 2021-01-08 04:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:36:03 --> Input Class Initialized
INFO - 2021-01-08 04:36:03 --> Language Class Initialized
INFO - 2021-01-08 04:36:03 --> Language Class Initialized
INFO - 2021-01-08 04:36:03 --> Config Class Initialized
INFO - 2021-01-08 04:36:03 --> Loader Class Initialized
INFO - 2021-01-08 04:36:03 --> Helper loaded: url_helper
INFO - 2021-01-08 04:36:03 --> Helper loaded: file_helper
INFO - 2021-01-08 04:36:03 --> Helper loaded: form_helper
INFO - 2021-01-08 04:36:03 --> Helper loaded: my_helper
INFO - 2021-01-08 04:36:03 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:36:04 --> Controller Class Initialized
DEBUG - 2021-01-08 04:36:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:36:04 --> Final output sent to browser
DEBUG - 2021-01-08 04:36:04 --> Total execution time: 0.3755
INFO - 2021-01-08 04:36:08 --> Config Class Initialized
INFO - 2021-01-08 04:36:08 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:36:08 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:36:08 --> Utf8 Class Initialized
INFO - 2021-01-08 04:36:08 --> URI Class Initialized
INFO - 2021-01-08 04:36:08 --> Router Class Initialized
INFO - 2021-01-08 04:36:08 --> Output Class Initialized
INFO - 2021-01-08 04:36:08 --> Security Class Initialized
DEBUG - 2021-01-08 04:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:36:08 --> Input Class Initialized
INFO - 2021-01-08 04:36:08 --> Language Class Initialized
INFO - 2021-01-08 04:36:08 --> Language Class Initialized
INFO - 2021-01-08 04:36:08 --> Config Class Initialized
INFO - 2021-01-08 04:36:08 --> Loader Class Initialized
INFO - 2021-01-08 04:36:08 --> Helper loaded: url_helper
INFO - 2021-01-08 04:36:08 --> Helper loaded: file_helper
INFO - 2021-01-08 04:36:08 --> Helper loaded: form_helper
INFO - 2021-01-08 04:36:08 --> Helper loaded: my_helper
INFO - 2021-01-08 04:36:08 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:36:08 --> Controller Class Initialized
DEBUG - 2021-01-08 04:36:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:36:08 --> Final output sent to browser
DEBUG - 2021-01-08 04:36:08 --> Total execution time: 0.3706
INFO - 2021-01-08 04:37:33 --> Config Class Initialized
INFO - 2021-01-08 04:37:33 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:37:33 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:37:33 --> Utf8 Class Initialized
INFO - 2021-01-08 04:37:33 --> URI Class Initialized
INFO - 2021-01-08 04:37:33 --> Router Class Initialized
INFO - 2021-01-08 04:37:33 --> Output Class Initialized
INFO - 2021-01-08 04:37:33 --> Security Class Initialized
DEBUG - 2021-01-08 04:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:37:33 --> Input Class Initialized
INFO - 2021-01-08 04:37:33 --> Language Class Initialized
INFO - 2021-01-08 04:37:33 --> Language Class Initialized
INFO - 2021-01-08 04:37:33 --> Config Class Initialized
INFO - 2021-01-08 04:37:33 --> Loader Class Initialized
INFO - 2021-01-08 04:37:33 --> Helper loaded: url_helper
INFO - 2021-01-08 04:37:33 --> Helper loaded: file_helper
INFO - 2021-01-08 04:37:33 --> Helper loaded: form_helper
INFO - 2021-01-08 04:37:33 --> Helper loaded: my_helper
INFO - 2021-01-08 04:37:33 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:37:33 --> Controller Class Initialized
DEBUG - 2021-01-08 04:37:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:37:34 --> Final output sent to browser
DEBUG - 2021-01-08 04:37:34 --> Total execution time: 0.3653
INFO - 2021-01-08 04:37:41 --> Config Class Initialized
INFO - 2021-01-08 04:37:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:37:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:37:41 --> Utf8 Class Initialized
INFO - 2021-01-08 04:37:41 --> URI Class Initialized
INFO - 2021-01-08 04:37:42 --> Router Class Initialized
INFO - 2021-01-08 04:37:42 --> Output Class Initialized
INFO - 2021-01-08 04:37:42 --> Security Class Initialized
DEBUG - 2021-01-08 04:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:37:42 --> Input Class Initialized
INFO - 2021-01-08 04:37:42 --> Language Class Initialized
INFO - 2021-01-08 04:37:42 --> Language Class Initialized
INFO - 2021-01-08 04:37:42 --> Config Class Initialized
INFO - 2021-01-08 04:37:42 --> Loader Class Initialized
INFO - 2021-01-08 04:37:42 --> Helper loaded: url_helper
INFO - 2021-01-08 04:37:42 --> Helper loaded: file_helper
INFO - 2021-01-08 04:37:42 --> Helper loaded: form_helper
INFO - 2021-01-08 04:37:42 --> Helper loaded: my_helper
INFO - 2021-01-08 04:37:42 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:37:42 --> Controller Class Initialized
DEBUG - 2021-01-08 04:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:37:42 --> Final output sent to browser
DEBUG - 2021-01-08 04:37:42 --> Total execution time: 0.3691
INFO - 2021-01-08 04:44:32 --> Config Class Initialized
INFO - 2021-01-08 04:44:32 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:44:32 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:44:32 --> Utf8 Class Initialized
INFO - 2021-01-08 04:44:32 --> URI Class Initialized
INFO - 2021-01-08 04:44:32 --> Router Class Initialized
INFO - 2021-01-08 04:44:32 --> Output Class Initialized
INFO - 2021-01-08 04:44:32 --> Security Class Initialized
DEBUG - 2021-01-08 04:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:44:32 --> Input Class Initialized
INFO - 2021-01-08 04:44:32 --> Language Class Initialized
INFO - 2021-01-08 04:44:32 --> Language Class Initialized
INFO - 2021-01-08 04:44:32 --> Config Class Initialized
INFO - 2021-01-08 04:44:32 --> Loader Class Initialized
INFO - 2021-01-08 04:44:32 --> Helper loaded: url_helper
INFO - 2021-01-08 04:44:32 --> Helper loaded: file_helper
INFO - 2021-01-08 04:44:32 --> Helper loaded: form_helper
INFO - 2021-01-08 04:44:32 --> Helper loaded: my_helper
INFO - 2021-01-08 04:44:32 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:44:32 --> Controller Class Initialized
DEBUG - 2021-01-08 04:44:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:44:32 --> Final output sent to browser
DEBUG - 2021-01-08 04:44:32 --> Total execution time: 0.4196
INFO - 2021-01-08 04:45:23 --> Config Class Initialized
INFO - 2021-01-08 04:45:23 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:45:23 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:45:23 --> Utf8 Class Initialized
INFO - 2021-01-08 04:45:23 --> URI Class Initialized
INFO - 2021-01-08 04:45:23 --> Router Class Initialized
INFO - 2021-01-08 04:45:23 --> Output Class Initialized
INFO - 2021-01-08 04:45:23 --> Security Class Initialized
DEBUG - 2021-01-08 04:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:45:23 --> Input Class Initialized
INFO - 2021-01-08 04:45:23 --> Language Class Initialized
INFO - 2021-01-08 04:45:23 --> Language Class Initialized
INFO - 2021-01-08 04:45:23 --> Config Class Initialized
INFO - 2021-01-08 04:45:23 --> Loader Class Initialized
INFO - 2021-01-08 04:45:23 --> Helper loaded: url_helper
INFO - 2021-01-08 04:45:23 --> Helper loaded: file_helper
INFO - 2021-01-08 04:45:23 --> Helper loaded: form_helper
INFO - 2021-01-08 04:45:23 --> Helper loaded: my_helper
INFO - 2021-01-08 04:45:23 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:45:23 --> Controller Class Initialized
DEBUG - 2021-01-08 04:45:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:45:23 --> Final output sent to browser
DEBUG - 2021-01-08 04:45:23 --> Total execution time: 0.4239
INFO - 2021-01-08 04:45:29 --> Config Class Initialized
INFO - 2021-01-08 04:45:29 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:45:29 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:45:29 --> Utf8 Class Initialized
INFO - 2021-01-08 04:45:29 --> URI Class Initialized
INFO - 2021-01-08 04:45:29 --> Router Class Initialized
INFO - 2021-01-08 04:45:29 --> Output Class Initialized
INFO - 2021-01-08 04:45:29 --> Security Class Initialized
DEBUG - 2021-01-08 04:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:45:30 --> Input Class Initialized
INFO - 2021-01-08 04:45:30 --> Language Class Initialized
INFO - 2021-01-08 04:45:30 --> Language Class Initialized
INFO - 2021-01-08 04:45:30 --> Config Class Initialized
INFO - 2021-01-08 04:45:30 --> Loader Class Initialized
INFO - 2021-01-08 04:45:30 --> Helper loaded: url_helper
INFO - 2021-01-08 04:45:30 --> Helper loaded: file_helper
INFO - 2021-01-08 04:45:30 --> Helper loaded: form_helper
INFO - 2021-01-08 04:45:30 --> Helper loaded: my_helper
INFO - 2021-01-08 04:45:30 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:45:30 --> Controller Class Initialized
DEBUG - 2021-01-08 04:45:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:45:30 --> Final output sent to browser
DEBUG - 2021-01-08 04:45:30 --> Total execution time: 0.4388
INFO - 2021-01-08 04:45:44 --> Config Class Initialized
INFO - 2021-01-08 04:45:44 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:45:44 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:45:44 --> Utf8 Class Initialized
INFO - 2021-01-08 04:45:44 --> URI Class Initialized
INFO - 2021-01-08 04:45:44 --> Router Class Initialized
INFO - 2021-01-08 04:45:44 --> Output Class Initialized
INFO - 2021-01-08 04:45:44 --> Security Class Initialized
DEBUG - 2021-01-08 04:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:45:44 --> Input Class Initialized
INFO - 2021-01-08 04:45:44 --> Language Class Initialized
INFO - 2021-01-08 04:45:44 --> Language Class Initialized
INFO - 2021-01-08 04:45:44 --> Config Class Initialized
INFO - 2021-01-08 04:45:44 --> Loader Class Initialized
INFO - 2021-01-08 04:45:44 --> Helper loaded: url_helper
INFO - 2021-01-08 04:45:44 --> Helper loaded: file_helper
INFO - 2021-01-08 04:45:44 --> Helper loaded: form_helper
INFO - 2021-01-08 04:45:44 --> Helper loaded: my_helper
INFO - 2021-01-08 04:45:44 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:45:44 --> Controller Class Initialized
DEBUG - 2021-01-08 04:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:45:44 --> Final output sent to browser
DEBUG - 2021-01-08 04:45:44 --> Total execution time: 0.4400
INFO - 2021-01-08 04:45:46 --> Config Class Initialized
INFO - 2021-01-08 04:45:46 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:45:46 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:45:46 --> Utf8 Class Initialized
INFO - 2021-01-08 04:45:46 --> URI Class Initialized
INFO - 2021-01-08 04:45:46 --> Router Class Initialized
INFO - 2021-01-08 04:45:46 --> Output Class Initialized
INFO - 2021-01-08 04:45:46 --> Security Class Initialized
DEBUG - 2021-01-08 04:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:45:46 --> Input Class Initialized
INFO - 2021-01-08 04:45:46 --> Language Class Initialized
INFO - 2021-01-08 04:45:46 --> Language Class Initialized
INFO - 2021-01-08 04:45:46 --> Config Class Initialized
INFO - 2021-01-08 04:45:46 --> Loader Class Initialized
INFO - 2021-01-08 04:45:46 --> Helper loaded: url_helper
INFO - 2021-01-08 04:45:46 --> Helper loaded: file_helper
INFO - 2021-01-08 04:45:47 --> Helper loaded: form_helper
INFO - 2021-01-08 04:45:47 --> Helper loaded: my_helper
INFO - 2021-01-08 04:45:47 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:45:47 --> Controller Class Initialized
DEBUG - 2021-01-08 04:45:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:45:47 --> Final output sent to browser
DEBUG - 2021-01-08 04:45:47 --> Total execution time: 0.2974
INFO - 2021-01-08 04:45:48 --> Config Class Initialized
INFO - 2021-01-08 04:45:48 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:45:48 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:45:48 --> Utf8 Class Initialized
INFO - 2021-01-08 04:45:48 --> URI Class Initialized
INFO - 2021-01-08 04:45:48 --> Router Class Initialized
INFO - 2021-01-08 04:45:49 --> Output Class Initialized
INFO - 2021-01-08 04:45:49 --> Security Class Initialized
DEBUG - 2021-01-08 04:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:45:49 --> Input Class Initialized
INFO - 2021-01-08 04:45:49 --> Language Class Initialized
INFO - 2021-01-08 04:45:49 --> Language Class Initialized
INFO - 2021-01-08 04:45:49 --> Config Class Initialized
INFO - 2021-01-08 04:45:49 --> Loader Class Initialized
INFO - 2021-01-08 04:45:49 --> Helper loaded: url_helper
INFO - 2021-01-08 04:45:49 --> Helper loaded: file_helper
INFO - 2021-01-08 04:45:49 --> Helper loaded: form_helper
INFO - 2021-01-08 04:45:49 --> Helper loaded: my_helper
INFO - 2021-01-08 04:45:49 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:45:49 --> Controller Class Initialized
DEBUG - 2021-01-08 04:45:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:45:49 --> Final output sent to browser
DEBUG - 2021-01-08 04:45:49 --> Total execution time: 0.3054
INFO - 2021-01-08 04:46:07 --> Config Class Initialized
INFO - 2021-01-08 04:46:07 --> Hooks Class Initialized
DEBUG - 2021-01-08 04:46:07 --> UTF-8 Support Enabled
INFO - 2021-01-08 04:46:07 --> Utf8 Class Initialized
INFO - 2021-01-08 04:46:07 --> URI Class Initialized
INFO - 2021-01-08 04:46:07 --> Router Class Initialized
INFO - 2021-01-08 04:46:07 --> Output Class Initialized
INFO - 2021-01-08 04:46:07 --> Security Class Initialized
DEBUG - 2021-01-08 04:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 04:46:07 --> Input Class Initialized
INFO - 2021-01-08 04:46:07 --> Language Class Initialized
INFO - 2021-01-08 04:46:07 --> Language Class Initialized
INFO - 2021-01-08 04:46:07 --> Config Class Initialized
INFO - 2021-01-08 04:46:07 --> Loader Class Initialized
INFO - 2021-01-08 04:46:07 --> Helper loaded: url_helper
INFO - 2021-01-08 04:46:07 --> Helper loaded: file_helper
INFO - 2021-01-08 04:46:07 --> Helper loaded: form_helper
INFO - 2021-01-08 04:46:07 --> Helper loaded: my_helper
INFO - 2021-01-08 04:46:07 --> Database Driver Class Initialized
DEBUG - 2021-01-08 04:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 04:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 04:46:07 --> Controller Class Initialized
DEBUG - 2021-01-08 04:46:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 04:46:07 --> Final output sent to browser
DEBUG - 2021-01-08 04:46:07 --> Total execution time: 0.3737
INFO - 2021-01-08 05:10:05 --> Config Class Initialized
INFO - 2021-01-08 05:10:05 --> Hooks Class Initialized
DEBUG - 2021-01-08 05:10:05 --> UTF-8 Support Enabled
INFO - 2021-01-08 05:10:05 --> Utf8 Class Initialized
INFO - 2021-01-08 05:10:05 --> URI Class Initialized
INFO - 2021-01-08 05:10:05 --> Router Class Initialized
INFO - 2021-01-08 05:10:05 --> Output Class Initialized
INFO - 2021-01-08 05:10:05 --> Security Class Initialized
DEBUG - 2021-01-08 05:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 05:10:05 --> Input Class Initialized
INFO - 2021-01-08 05:10:05 --> Language Class Initialized
INFO - 2021-01-08 05:10:05 --> Language Class Initialized
INFO - 2021-01-08 05:10:05 --> Config Class Initialized
INFO - 2021-01-08 05:10:06 --> Loader Class Initialized
INFO - 2021-01-08 05:10:06 --> Helper loaded: url_helper
INFO - 2021-01-08 05:10:06 --> Helper loaded: file_helper
INFO - 2021-01-08 05:10:06 --> Helper loaded: form_helper
INFO - 2021-01-08 05:10:06 --> Helper loaded: my_helper
INFO - 2021-01-08 05:10:06 --> Database Driver Class Initialized
DEBUG - 2021-01-08 05:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 05:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 05:10:06 --> Controller Class Initialized
DEBUG - 2021-01-08 05:10:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 05:10:06 --> Final output sent to browser
DEBUG - 2021-01-08 05:10:06 --> Total execution time: 1.1531
INFO - 2021-01-08 05:10:15 --> Config Class Initialized
INFO - 2021-01-08 05:10:15 --> Hooks Class Initialized
DEBUG - 2021-01-08 05:10:15 --> UTF-8 Support Enabled
INFO - 2021-01-08 05:10:15 --> Utf8 Class Initialized
INFO - 2021-01-08 05:10:15 --> URI Class Initialized
INFO - 2021-01-08 05:10:15 --> Router Class Initialized
INFO - 2021-01-08 05:10:15 --> Output Class Initialized
INFO - 2021-01-08 05:10:15 --> Security Class Initialized
DEBUG - 2021-01-08 05:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 05:10:15 --> Input Class Initialized
INFO - 2021-01-08 05:10:15 --> Language Class Initialized
INFO - 2021-01-08 05:10:15 --> Language Class Initialized
INFO - 2021-01-08 05:10:15 --> Config Class Initialized
INFO - 2021-01-08 05:10:15 --> Loader Class Initialized
INFO - 2021-01-08 05:10:15 --> Helper loaded: url_helper
INFO - 2021-01-08 05:10:15 --> Helper loaded: file_helper
INFO - 2021-01-08 05:10:15 --> Helper loaded: form_helper
INFO - 2021-01-08 05:10:16 --> Helper loaded: my_helper
INFO - 2021-01-08 05:10:16 --> Database Driver Class Initialized
DEBUG - 2021-01-08 05:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 05:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 05:10:16 --> Controller Class Initialized
DEBUG - 2021-01-08 05:10:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 05:10:16 --> Final output sent to browser
DEBUG - 2021-01-08 05:10:16 --> Total execution time: 1.0927
INFO - 2021-01-08 05:10:22 --> Config Class Initialized
INFO - 2021-01-08 05:10:22 --> Hooks Class Initialized
DEBUG - 2021-01-08 05:10:22 --> UTF-8 Support Enabled
INFO - 2021-01-08 05:10:22 --> Utf8 Class Initialized
INFO - 2021-01-08 05:10:23 --> URI Class Initialized
INFO - 2021-01-08 05:10:23 --> Router Class Initialized
INFO - 2021-01-08 05:10:23 --> Output Class Initialized
INFO - 2021-01-08 05:10:23 --> Security Class Initialized
DEBUG - 2021-01-08 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 05:10:23 --> Input Class Initialized
INFO - 2021-01-08 05:10:23 --> Language Class Initialized
INFO - 2021-01-08 05:10:23 --> Language Class Initialized
INFO - 2021-01-08 05:10:23 --> Config Class Initialized
INFO - 2021-01-08 05:10:23 --> Loader Class Initialized
INFO - 2021-01-08 05:10:23 --> Helper loaded: url_helper
INFO - 2021-01-08 05:10:23 --> Helper loaded: file_helper
INFO - 2021-01-08 05:10:23 --> Helper loaded: form_helper
INFO - 2021-01-08 05:10:23 --> Helper loaded: my_helper
INFO - 2021-01-08 05:10:23 --> Database Driver Class Initialized
DEBUG - 2021-01-08 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 05:10:23 --> Controller Class Initialized
DEBUG - 2021-01-08 05:10:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 05:10:23 --> Final output sent to browser
DEBUG - 2021-01-08 05:10:23 --> Total execution time: 1.0079
INFO - 2021-01-08 08:05:46 --> Config Class Initialized
INFO - 2021-01-08 08:05:46 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:05:46 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:05:46 --> Utf8 Class Initialized
INFO - 2021-01-08 08:05:46 --> URI Class Initialized
DEBUG - 2021-01-08 08:05:46 --> No URI present. Default controller set.
INFO - 2021-01-08 08:05:46 --> Router Class Initialized
INFO - 2021-01-08 08:05:46 --> Output Class Initialized
INFO - 2021-01-08 08:05:46 --> Security Class Initialized
DEBUG - 2021-01-08 08:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:05:46 --> Input Class Initialized
INFO - 2021-01-08 08:05:46 --> Language Class Initialized
INFO - 2021-01-08 08:05:46 --> Language Class Initialized
INFO - 2021-01-08 08:05:46 --> Config Class Initialized
INFO - 2021-01-08 08:05:46 --> Loader Class Initialized
INFO - 2021-01-08 08:05:46 --> Helper loaded: url_helper
INFO - 2021-01-08 08:05:46 --> Helper loaded: file_helper
INFO - 2021-01-08 08:05:46 --> Helper loaded: form_helper
INFO - 2021-01-08 08:05:46 --> Helper loaded: my_helper
INFO - 2021-01-08 08:05:46 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:05:46 --> Controller Class Initialized
INFO - 2021-01-08 08:05:47 --> Config Class Initialized
INFO - 2021-01-08 08:05:47 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:05:47 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:05:47 --> Utf8 Class Initialized
INFO - 2021-01-08 08:05:47 --> URI Class Initialized
INFO - 2021-01-08 08:05:47 --> Router Class Initialized
INFO - 2021-01-08 08:05:47 --> Output Class Initialized
INFO - 2021-01-08 08:05:47 --> Security Class Initialized
DEBUG - 2021-01-08 08:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:05:47 --> Input Class Initialized
INFO - 2021-01-08 08:05:47 --> Language Class Initialized
INFO - 2021-01-08 08:05:47 --> Language Class Initialized
INFO - 2021-01-08 08:05:47 --> Config Class Initialized
INFO - 2021-01-08 08:05:47 --> Loader Class Initialized
INFO - 2021-01-08 08:05:47 --> Helper loaded: url_helper
INFO - 2021-01-08 08:05:47 --> Helper loaded: file_helper
INFO - 2021-01-08 08:05:47 --> Helper loaded: form_helper
INFO - 2021-01-08 08:05:47 --> Helper loaded: my_helper
INFO - 2021-01-08 08:05:47 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:05:47 --> Controller Class Initialized
DEBUG - 2021-01-08 08:05:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-08 08:05:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 08:05:47 --> Final output sent to browser
DEBUG - 2021-01-08 08:05:47 --> Total execution time: 0.3140
INFO - 2021-01-08 08:07:55 --> Config Class Initialized
INFO - 2021-01-08 08:07:55 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:07:55 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:07:55 --> Utf8 Class Initialized
INFO - 2021-01-08 08:07:55 --> URI Class Initialized
INFO - 2021-01-08 08:07:55 --> Router Class Initialized
INFO - 2021-01-08 08:07:55 --> Output Class Initialized
INFO - 2021-01-08 08:07:55 --> Security Class Initialized
DEBUG - 2021-01-08 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:07:55 --> Input Class Initialized
INFO - 2021-01-08 08:07:55 --> Language Class Initialized
INFO - 2021-01-08 08:07:55 --> Language Class Initialized
INFO - 2021-01-08 08:07:55 --> Config Class Initialized
INFO - 2021-01-08 08:07:55 --> Loader Class Initialized
INFO - 2021-01-08 08:07:55 --> Helper loaded: url_helper
INFO - 2021-01-08 08:07:55 --> Helper loaded: file_helper
INFO - 2021-01-08 08:07:55 --> Helper loaded: form_helper
INFO - 2021-01-08 08:07:55 --> Helper loaded: my_helper
INFO - 2021-01-08 08:07:55 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:07:55 --> Controller Class Initialized
INFO - 2021-01-08 08:07:55 --> Helper loaded: cookie_helper
INFO - 2021-01-08 08:07:55 --> Final output sent to browser
DEBUG - 2021-01-08 08:07:55 --> Total execution time: 0.3978
INFO - 2021-01-08 08:07:55 --> Config Class Initialized
INFO - 2021-01-08 08:07:56 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:07:56 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:07:56 --> Utf8 Class Initialized
INFO - 2021-01-08 08:07:56 --> URI Class Initialized
INFO - 2021-01-08 08:07:56 --> Router Class Initialized
INFO - 2021-01-08 08:07:56 --> Output Class Initialized
INFO - 2021-01-08 08:07:56 --> Security Class Initialized
DEBUG - 2021-01-08 08:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:07:56 --> Input Class Initialized
INFO - 2021-01-08 08:07:56 --> Language Class Initialized
INFO - 2021-01-08 08:07:56 --> Language Class Initialized
INFO - 2021-01-08 08:07:56 --> Config Class Initialized
INFO - 2021-01-08 08:07:56 --> Loader Class Initialized
INFO - 2021-01-08 08:07:56 --> Helper loaded: url_helper
INFO - 2021-01-08 08:07:56 --> Helper loaded: file_helper
INFO - 2021-01-08 08:07:56 --> Helper loaded: form_helper
INFO - 2021-01-08 08:07:56 --> Helper loaded: my_helper
INFO - 2021-01-08 08:07:56 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:07:56 --> Controller Class Initialized
DEBUG - 2021-01-08 08:07:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-08 08:07:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 08:07:56 --> Final output sent to browser
DEBUG - 2021-01-08 08:07:56 --> Total execution time: 0.4505
INFO - 2021-01-08 08:08:06 --> Config Class Initialized
INFO - 2021-01-08 08:08:06 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:08:06 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:08:06 --> Utf8 Class Initialized
INFO - 2021-01-08 08:08:06 --> URI Class Initialized
INFO - 2021-01-08 08:08:06 --> Router Class Initialized
INFO - 2021-01-08 08:08:06 --> Output Class Initialized
INFO - 2021-01-08 08:08:06 --> Security Class Initialized
DEBUG - 2021-01-08 08:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:08:06 --> Input Class Initialized
INFO - 2021-01-08 08:08:06 --> Language Class Initialized
INFO - 2021-01-08 08:08:06 --> Language Class Initialized
INFO - 2021-01-08 08:08:06 --> Config Class Initialized
INFO - 2021-01-08 08:08:06 --> Loader Class Initialized
INFO - 2021-01-08 08:08:06 --> Helper loaded: url_helper
INFO - 2021-01-08 08:08:06 --> Helper loaded: file_helper
INFO - 2021-01-08 08:08:06 --> Helper loaded: form_helper
INFO - 2021-01-08 08:08:06 --> Helper loaded: my_helper
INFO - 2021-01-08 08:08:06 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:08:06 --> Controller Class Initialized
DEBUG - 2021-01-08 08:08:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-08 08:08:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-08 08:08:06 --> Final output sent to browser
DEBUG - 2021-01-08 08:08:06 --> Total execution time: 0.3923
INFO - 2021-01-08 08:08:08 --> Config Class Initialized
INFO - 2021-01-08 08:08:08 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:08:08 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:08:08 --> Utf8 Class Initialized
INFO - 2021-01-08 08:08:08 --> URI Class Initialized
INFO - 2021-01-08 08:08:08 --> Router Class Initialized
INFO - 2021-01-08 08:08:08 --> Output Class Initialized
INFO - 2021-01-08 08:08:08 --> Security Class Initialized
DEBUG - 2021-01-08 08:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:08:08 --> Input Class Initialized
INFO - 2021-01-08 08:08:08 --> Language Class Initialized
INFO - 2021-01-08 08:08:08 --> Language Class Initialized
INFO - 2021-01-08 08:08:08 --> Config Class Initialized
INFO - 2021-01-08 08:08:08 --> Loader Class Initialized
INFO - 2021-01-08 08:08:08 --> Helper loaded: url_helper
INFO - 2021-01-08 08:08:08 --> Helper loaded: file_helper
INFO - 2021-01-08 08:08:08 --> Helper loaded: form_helper
INFO - 2021-01-08 08:08:08 --> Helper loaded: my_helper
INFO - 2021-01-08 08:08:08 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:08:08 --> Controller Class Initialized
DEBUG - 2021-01-08 08:08:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:08:08 --> Final output sent to browser
DEBUG - 2021-01-08 08:08:08 --> Total execution time: 0.3412
INFO - 2021-01-08 08:08:33 --> Config Class Initialized
INFO - 2021-01-08 08:08:33 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:08:33 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:08:33 --> Utf8 Class Initialized
INFO - 2021-01-08 08:08:33 --> URI Class Initialized
INFO - 2021-01-08 08:08:33 --> Router Class Initialized
INFO - 2021-01-08 08:08:33 --> Output Class Initialized
INFO - 2021-01-08 08:08:33 --> Security Class Initialized
DEBUG - 2021-01-08 08:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:08:33 --> Input Class Initialized
INFO - 2021-01-08 08:08:33 --> Language Class Initialized
INFO - 2021-01-08 08:08:33 --> Language Class Initialized
INFO - 2021-01-08 08:08:33 --> Config Class Initialized
INFO - 2021-01-08 08:08:33 --> Loader Class Initialized
INFO - 2021-01-08 08:08:33 --> Helper loaded: url_helper
INFO - 2021-01-08 08:08:33 --> Helper loaded: file_helper
INFO - 2021-01-08 08:08:33 --> Helper loaded: form_helper
INFO - 2021-01-08 08:08:33 --> Helper loaded: my_helper
INFO - 2021-01-08 08:08:33 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:08:33 --> Controller Class Initialized
DEBUG - 2021-01-08 08:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:08:33 --> Final output sent to browser
DEBUG - 2021-01-08 08:08:33 --> Total execution time: 0.3792
INFO - 2021-01-08 08:09:10 --> Config Class Initialized
INFO - 2021-01-08 08:09:10 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:09:10 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:09:10 --> Utf8 Class Initialized
INFO - 2021-01-08 08:09:10 --> URI Class Initialized
INFO - 2021-01-08 08:09:10 --> Router Class Initialized
INFO - 2021-01-08 08:09:10 --> Output Class Initialized
INFO - 2021-01-08 08:09:10 --> Security Class Initialized
DEBUG - 2021-01-08 08:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:09:10 --> Input Class Initialized
INFO - 2021-01-08 08:09:10 --> Language Class Initialized
INFO - 2021-01-08 08:09:10 --> Language Class Initialized
INFO - 2021-01-08 08:09:10 --> Config Class Initialized
INFO - 2021-01-08 08:09:10 --> Loader Class Initialized
INFO - 2021-01-08 08:09:10 --> Helper loaded: url_helper
INFO - 2021-01-08 08:09:10 --> Helper loaded: file_helper
INFO - 2021-01-08 08:09:10 --> Helper loaded: form_helper
INFO - 2021-01-08 08:09:10 --> Helper loaded: my_helper
INFO - 2021-01-08 08:09:10 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:09:10 --> Controller Class Initialized
DEBUG - 2021-01-08 08:09:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:09:10 --> Final output sent to browser
DEBUG - 2021-01-08 08:09:10 --> Total execution time: 0.3679
INFO - 2021-01-08 08:09:40 --> Config Class Initialized
INFO - 2021-01-08 08:09:40 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:09:40 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:09:40 --> Utf8 Class Initialized
INFO - 2021-01-08 08:09:40 --> URI Class Initialized
INFO - 2021-01-08 08:09:40 --> Router Class Initialized
INFO - 2021-01-08 08:09:40 --> Output Class Initialized
INFO - 2021-01-08 08:09:40 --> Security Class Initialized
DEBUG - 2021-01-08 08:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:09:40 --> Input Class Initialized
INFO - 2021-01-08 08:09:40 --> Language Class Initialized
INFO - 2021-01-08 08:09:40 --> Language Class Initialized
INFO - 2021-01-08 08:09:40 --> Config Class Initialized
INFO - 2021-01-08 08:09:40 --> Loader Class Initialized
INFO - 2021-01-08 08:09:40 --> Helper loaded: url_helper
INFO - 2021-01-08 08:09:40 --> Helper loaded: file_helper
INFO - 2021-01-08 08:09:40 --> Helper loaded: form_helper
INFO - 2021-01-08 08:09:40 --> Helper loaded: my_helper
INFO - 2021-01-08 08:09:40 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:09:41 --> Controller Class Initialized
DEBUG - 2021-01-08 08:09:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:09:41 --> Final output sent to browser
DEBUG - 2021-01-08 08:09:41 --> Total execution time: 0.3545
INFO - 2021-01-08 08:09:59 --> Config Class Initialized
INFO - 2021-01-08 08:09:59 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:09:59 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:09:59 --> Utf8 Class Initialized
INFO - 2021-01-08 08:09:59 --> URI Class Initialized
INFO - 2021-01-08 08:09:59 --> Router Class Initialized
INFO - 2021-01-08 08:09:59 --> Output Class Initialized
INFO - 2021-01-08 08:09:59 --> Security Class Initialized
DEBUG - 2021-01-08 08:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:09:59 --> Input Class Initialized
INFO - 2021-01-08 08:09:59 --> Language Class Initialized
INFO - 2021-01-08 08:10:00 --> Language Class Initialized
INFO - 2021-01-08 08:10:00 --> Config Class Initialized
INFO - 2021-01-08 08:10:00 --> Loader Class Initialized
INFO - 2021-01-08 08:10:00 --> Helper loaded: url_helper
INFO - 2021-01-08 08:10:00 --> Helper loaded: file_helper
INFO - 2021-01-08 08:10:00 --> Helper loaded: form_helper
INFO - 2021-01-08 08:10:00 --> Helper loaded: my_helper
INFO - 2021-01-08 08:10:00 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:10:00 --> Controller Class Initialized
DEBUG - 2021-01-08 08:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:10:00 --> Final output sent to browser
DEBUG - 2021-01-08 08:10:00 --> Total execution time: 0.4110
INFO - 2021-01-08 08:16:44 --> Config Class Initialized
INFO - 2021-01-08 08:16:44 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:16:44 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:16:44 --> Utf8 Class Initialized
INFO - 2021-01-08 08:16:44 --> URI Class Initialized
INFO - 2021-01-08 08:16:44 --> Router Class Initialized
INFO - 2021-01-08 08:16:44 --> Output Class Initialized
INFO - 2021-01-08 08:16:44 --> Security Class Initialized
DEBUG - 2021-01-08 08:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:16:44 --> Input Class Initialized
INFO - 2021-01-08 08:16:44 --> Language Class Initialized
INFO - 2021-01-08 08:16:44 --> Language Class Initialized
INFO - 2021-01-08 08:16:44 --> Config Class Initialized
INFO - 2021-01-08 08:16:44 --> Loader Class Initialized
INFO - 2021-01-08 08:16:44 --> Helper loaded: url_helper
INFO - 2021-01-08 08:16:44 --> Helper loaded: file_helper
INFO - 2021-01-08 08:16:44 --> Helper loaded: form_helper
INFO - 2021-01-08 08:16:44 --> Helper loaded: my_helper
INFO - 2021-01-08 08:16:44 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:16:44 --> Controller Class Initialized
DEBUG - 2021-01-08 08:16:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:16:44 --> Final output sent to browser
DEBUG - 2021-01-08 08:16:44 --> Total execution time: 0.4159
INFO - 2021-01-08 08:17:26 --> Config Class Initialized
INFO - 2021-01-08 08:17:26 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:17:26 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:17:26 --> Utf8 Class Initialized
INFO - 2021-01-08 08:17:26 --> URI Class Initialized
INFO - 2021-01-08 08:17:26 --> Router Class Initialized
INFO - 2021-01-08 08:17:26 --> Output Class Initialized
INFO - 2021-01-08 08:17:26 --> Security Class Initialized
DEBUG - 2021-01-08 08:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:17:26 --> Input Class Initialized
INFO - 2021-01-08 08:17:26 --> Language Class Initialized
INFO - 2021-01-08 08:17:26 --> Language Class Initialized
INFO - 2021-01-08 08:17:26 --> Config Class Initialized
INFO - 2021-01-08 08:17:26 --> Loader Class Initialized
INFO - 2021-01-08 08:17:26 --> Helper loaded: url_helper
INFO - 2021-01-08 08:17:26 --> Helper loaded: file_helper
INFO - 2021-01-08 08:17:26 --> Helper loaded: form_helper
INFO - 2021-01-08 08:17:26 --> Helper loaded: my_helper
INFO - 2021-01-08 08:17:26 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:17:26 --> Controller Class Initialized
DEBUG - 2021-01-08 08:17:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:17:26 --> Final output sent to browser
DEBUG - 2021-01-08 08:17:26 --> Total execution time: 0.3662
INFO - 2021-01-08 08:17:39 --> Config Class Initialized
INFO - 2021-01-08 08:17:39 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:17:39 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:17:39 --> Utf8 Class Initialized
INFO - 2021-01-08 08:17:39 --> URI Class Initialized
INFO - 2021-01-08 08:17:39 --> Router Class Initialized
INFO - 2021-01-08 08:17:39 --> Output Class Initialized
INFO - 2021-01-08 08:17:39 --> Security Class Initialized
DEBUG - 2021-01-08 08:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:17:39 --> Input Class Initialized
INFO - 2021-01-08 08:17:39 --> Language Class Initialized
INFO - 2021-01-08 08:17:39 --> Language Class Initialized
INFO - 2021-01-08 08:17:40 --> Config Class Initialized
INFO - 2021-01-08 08:17:40 --> Loader Class Initialized
INFO - 2021-01-08 08:17:40 --> Helper loaded: url_helper
INFO - 2021-01-08 08:17:40 --> Helper loaded: file_helper
INFO - 2021-01-08 08:17:40 --> Helper loaded: form_helper
INFO - 2021-01-08 08:17:40 --> Helper loaded: my_helper
INFO - 2021-01-08 08:17:40 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:17:40 --> Controller Class Initialized
DEBUG - 2021-01-08 08:17:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:17:40 --> Final output sent to browser
DEBUG - 2021-01-08 08:17:40 --> Total execution time: 0.4789
INFO - 2021-01-08 08:17:58 --> Config Class Initialized
INFO - 2021-01-08 08:17:58 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:17:58 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:17:58 --> Utf8 Class Initialized
INFO - 2021-01-08 08:17:58 --> URI Class Initialized
INFO - 2021-01-08 08:17:58 --> Router Class Initialized
INFO - 2021-01-08 08:17:58 --> Output Class Initialized
INFO - 2021-01-08 08:17:58 --> Security Class Initialized
DEBUG - 2021-01-08 08:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:17:58 --> Input Class Initialized
INFO - 2021-01-08 08:17:58 --> Language Class Initialized
INFO - 2021-01-08 08:17:58 --> Language Class Initialized
INFO - 2021-01-08 08:17:58 --> Config Class Initialized
INFO - 2021-01-08 08:17:58 --> Loader Class Initialized
INFO - 2021-01-08 08:17:58 --> Helper loaded: url_helper
INFO - 2021-01-08 08:17:58 --> Helper loaded: file_helper
INFO - 2021-01-08 08:17:58 --> Helper loaded: form_helper
INFO - 2021-01-08 08:17:58 --> Helper loaded: my_helper
INFO - 2021-01-08 08:17:58 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:17:58 --> Controller Class Initialized
DEBUG - 2021-01-08 08:17:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:17:59 --> Final output sent to browser
DEBUG - 2021-01-08 08:17:59 --> Total execution time: 0.3745
INFO - 2021-01-08 08:18:10 --> Config Class Initialized
INFO - 2021-01-08 08:18:10 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:18:10 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:18:10 --> Utf8 Class Initialized
INFO - 2021-01-08 08:18:10 --> URI Class Initialized
INFO - 2021-01-08 08:18:10 --> Router Class Initialized
INFO - 2021-01-08 08:18:10 --> Output Class Initialized
INFO - 2021-01-08 08:18:10 --> Security Class Initialized
DEBUG - 2021-01-08 08:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:18:10 --> Input Class Initialized
INFO - 2021-01-08 08:18:10 --> Language Class Initialized
INFO - 2021-01-08 08:18:10 --> Language Class Initialized
INFO - 2021-01-08 08:18:10 --> Config Class Initialized
INFO - 2021-01-08 08:18:10 --> Loader Class Initialized
INFO - 2021-01-08 08:18:10 --> Helper loaded: url_helper
INFO - 2021-01-08 08:18:10 --> Helper loaded: file_helper
INFO - 2021-01-08 08:18:10 --> Helper loaded: form_helper
INFO - 2021-01-08 08:18:10 --> Helper loaded: my_helper
INFO - 2021-01-08 08:18:10 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:18:10 --> Controller Class Initialized
DEBUG - 2021-01-08 08:18:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:18:10 --> Final output sent to browser
DEBUG - 2021-01-08 08:18:10 --> Total execution time: 0.3807
INFO - 2021-01-08 08:18:38 --> Config Class Initialized
INFO - 2021-01-08 08:18:38 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:18:38 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:18:38 --> Utf8 Class Initialized
INFO - 2021-01-08 08:18:38 --> URI Class Initialized
INFO - 2021-01-08 08:18:39 --> Router Class Initialized
INFO - 2021-01-08 08:18:39 --> Output Class Initialized
INFO - 2021-01-08 08:18:39 --> Security Class Initialized
DEBUG - 2021-01-08 08:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:18:39 --> Input Class Initialized
INFO - 2021-01-08 08:18:39 --> Language Class Initialized
INFO - 2021-01-08 08:18:39 --> Language Class Initialized
INFO - 2021-01-08 08:18:39 --> Config Class Initialized
INFO - 2021-01-08 08:18:39 --> Loader Class Initialized
INFO - 2021-01-08 08:18:39 --> Helper loaded: url_helper
INFO - 2021-01-08 08:18:39 --> Helper loaded: file_helper
INFO - 2021-01-08 08:18:39 --> Helper loaded: form_helper
INFO - 2021-01-08 08:18:39 --> Helper loaded: my_helper
INFO - 2021-01-08 08:18:39 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:18:39 --> Controller Class Initialized
DEBUG - 2021-01-08 08:18:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:18:39 --> Final output sent to browser
DEBUG - 2021-01-08 08:18:39 --> Total execution time: 0.3750
INFO - 2021-01-08 08:19:08 --> Config Class Initialized
INFO - 2021-01-08 08:19:08 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:19:08 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:19:08 --> Utf8 Class Initialized
INFO - 2021-01-08 08:19:08 --> URI Class Initialized
INFO - 2021-01-08 08:19:08 --> Router Class Initialized
INFO - 2021-01-08 08:19:08 --> Output Class Initialized
INFO - 2021-01-08 08:19:08 --> Security Class Initialized
DEBUG - 2021-01-08 08:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:19:08 --> Input Class Initialized
INFO - 2021-01-08 08:19:08 --> Language Class Initialized
INFO - 2021-01-08 08:19:08 --> Language Class Initialized
INFO - 2021-01-08 08:19:08 --> Config Class Initialized
INFO - 2021-01-08 08:19:08 --> Loader Class Initialized
INFO - 2021-01-08 08:19:08 --> Helper loaded: url_helper
INFO - 2021-01-08 08:19:08 --> Helper loaded: file_helper
INFO - 2021-01-08 08:19:08 --> Helper loaded: form_helper
INFO - 2021-01-08 08:19:08 --> Helper loaded: my_helper
INFO - 2021-01-08 08:19:08 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:19:08 --> Controller Class Initialized
DEBUG - 2021-01-08 08:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:19:09 --> Final output sent to browser
DEBUG - 2021-01-08 08:19:09 --> Total execution time: 0.3824
INFO - 2021-01-08 08:19:20 --> Config Class Initialized
INFO - 2021-01-08 08:19:20 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:19:20 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:19:20 --> Utf8 Class Initialized
INFO - 2021-01-08 08:19:20 --> URI Class Initialized
INFO - 2021-01-08 08:19:20 --> Router Class Initialized
INFO - 2021-01-08 08:19:20 --> Output Class Initialized
INFO - 2021-01-08 08:19:20 --> Security Class Initialized
DEBUG - 2021-01-08 08:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:19:20 --> Input Class Initialized
INFO - 2021-01-08 08:19:20 --> Language Class Initialized
INFO - 2021-01-08 08:19:20 --> Language Class Initialized
INFO - 2021-01-08 08:19:20 --> Config Class Initialized
INFO - 2021-01-08 08:19:20 --> Loader Class Initialized
INFO - 2021-01-08 08:19:20 --> Helper loaded: url_helper
INFO - 2021-01-08 08:19:21 --> Helper loaded: file_helper
INFO - 2021-01-08 08:19:21 --> Helper loaded: form_helper
INFO - 2021-01-08 08:19:21 --> Helper loaded: my_helper
INFO - 2021-01-08 08:19:21 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:19:21 --> Controller Class Initialized
DEBUG - 2021-01-08 08:19:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:19:21 --> Final output sent to browser
DEBUG - 2021-01-08 08:19:21 --> Total execution time: 0.3851
INFO - 2021-01-08 08:19:41 --> Config Class Initialized
INFO - 2021-01-08 08:19:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:19:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:19:41 --> Utf8 Class Initialized
INFO - 2021-01-08 08:19:41 --> URI Class Initialized
INFO - 2021-01-08 08:19:41 --> Router Class Initialized
INFO - 2021-01-08 08:19:41 --> Output Class Initialized
INFO - 2021-01-08 08:19:41 --> Security Class Initialized
DEBUG - 2021-01-08 08:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:19:42 --> Input Class Initialized
INFO - 2021-01-08 08:19:42 --> Language Class Initialized
INFO - 2021-01-08 08:19:42 --> Language Class Initialized
INFO - 2021-01-08 08:19:42 --> Config Class Initialized
INFO - 2021-01-08 08:19:42 --> Loader Class Initialized
INFO - 2021-01-08 08:19:42 --> Helper loaded: url_helper
INFO - 2021-01-08 08:19:42 --> Helper loaded: file_helper
INFO - 2021-01-08 08:19:42 --> Helper loaded: form_helper
INFO - 2021-01-08 08:19:42 --> Helper loaded: my_helper
INFO - 2021-01-08 08:19:42 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:19:42 --> Controller Class Initialized
DEBUG - 2021-01-08 08:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:19:42 --> Final output sent to browser
DEBUG - 2021-01-08 08:19:42 --> Total execution time: 0.4185
INFO - 2021-01-08 08:19:53 --> Config Class Initialized
INFO - 2021-01-08 08:19:53 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:19:53 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:19:53 --> Utf8 Class Initialized
INFO - 2021-01-08 08:19:53 --> URI Class Initialized
INFO - 2021-01-08 08:19:53 --> Router Class Initialized
INFO - 2021-01-08 08:19:53 --> Output Class Initialized
INFO - 2021-01-08 08:19:53 --> Security Class Initialized
DEBUG - 2021-01-08 08:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:19:53 --> Input Class Initialized
INFO - 2021-01-08 08:19:53 --> Language Class Initialized
INFO - 2021-01-08 08:19:53 --> Language Class Initialized
INFO - 2021-01-08 08:19:53 --> Config Class Initialized
INFO - 2021-01-08 08:19:53 --> Loader Class Initialized
INFO - 2021-01-08 08:19:53 --> Helper loaded: url_helper
INFO - 2021-01-08 08:19:53 --> Helper loaded: file_helper
INFO - 2021-01-08 08:19:53 --> Helper loaded: form_helper
INFO - 2021-01-08 08:19:53 --> Helper loaded: my_helper
INFO - 2021-01-08 08:19:53 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:19:53 --> Controller Class Initialized
DEBUG - 2021-01-08 08:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:19:53 --> Final output sent to browser
DEBUG - 2021-01-08 08:19:53 --> Total execution time: 0.3930
INFO - 2021-01-08 08:20:35 --> Config Class Initialized
INFO - 2021-01-08 08:20:35 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:20:35 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:20:35 --> Utf8 Class Initialized
INFO - 2021-01-08 08:20:35 --> URI Class Initialized
INFO - 2021-01-08 08:20:35 --> Router Class Initialized
INFO - 2021-01-08 08:20:35 --> Output Class Initialized
INFO - 2021-01-08 08:20:35 --> Security Class Initialized
DEBUG - 2021-01-08 08:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:20:35 --> Input Class Initialized
INFO - 2021-01-08 08:20:35 --> Language Class Initialized
INFO - 2021-01-08 08:20:35 --> Language Class Initialized
INFO - 2021-01-08 08:20:35 --> Config Class Initialized
INFO - 2021-01-08 08:20:35 --> Loader Class Initialized
INFO - 2021-01-08 08:20:35 --> Helper loaded: url_helper
INFO - 2021-01-08 08:20:35 --> Helper loaded: file_helper
INFO - 2021-01-08 08:20:35 --> Helper loaded: form_helper
INFO - 2021-01-08 08:20:35 --> Helper loaded: my_helper
INFO - 2021-01-08 08:20:35 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:20:35 --> Controller Class Initialized
DEBUG - 2021-01-08 08:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:20:36 --> Final output sent to browser
DEBUG - 2021-01-08 08:20:36 --> Total execution time: 0.4279
INFO - 2021-01-08 08:21:05 --> Config Class Initialized
INFO - 2021-01-08 08:21:05 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:21:05 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:21:05 --> Utf8 Class Initialized
INFO - 2021-01-08 08:21:05 --> URI Class Initialized
INFO - 2021-01-08 08:21:05 --> Router Class Initialized
INFO - 2021-01-08 08:21:05 --> Output Class Initialized
INFO - 2021-01-08 08:21:05 --> Security Class Initialized
DEBUG - 2021-01-08 08:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:21:05 --> Input Class Initialized
INFO - 2021-01-08 08:21:05 --> Language Class Initialized
INFO - 2021-01-08 08:21:05 --> Language Class Initialized
INFO - 2021-01-08 08:21:05 --> Config Class Initialized
INFO - 2021-01-08 08:21:05 --> Loader Class Initialized
INFO - 2021-01-08 08:21:05 --> Helper loaded: url_helper
INFO - 2021-01-08 08:21:06 --> Helper loaded: file_helper
INFO - 2021-01-08 08:21:06 --> Helper loaded: form_helper
INFO - 2021-01-08 08:21:06 --> Helper loaded: my_helper
INFO - 2021-01-08 08:21:06 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:21:06 --> Controller Class Initialized
DEBUG - 2021-01-08 08:21:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:21:06 --> Final output sent to browser
DEBUG - 2021-01-08 08:21:06 --> Total execution time: 0.4122
INFO - 2021-01-08 08:21:12 --> Config Class Initialized
INFO - 2021-01-08 08:21:12 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:21:12 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:21:12 --> Utf8 Class Initialized
INFO - 2021-01-08 08:21:12 --> URI Class Initialized
INFO - 2021-01-08 08:21:12 --> Router Class Initialized
INFO - 2021-01-08 08:21:12 --> Output Class Initialized
INFO - 2021-01-08 08:21:12 --> Security Class Initialized
DEBUG - 2021-01-08 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:21:12 --> Input Class Initialized
INFO - 2021-01-08 08:21:12 --> Language Class Initialized
INFO - 2021-01-08 08:21:12 --> Language Class Initialized
INFO - 2021-01-08 08:21:12 --> Config Class Initialized
INFO - 2021-01-08 08:21:12 --> Loader Class Initialized
INFO - 2021-01-08 08:21:12 --> Helper loaded: url_helper
INFO - 2021-01-08 08:21:12 --> Helper loaded: file_helper
INFO - 2021-01-08 08:21:12 --> Helper loaded: form_helper
INFO - 2021-01-08 08:21:12 --> Helper loaded: my_helper
INFO - 2021-01-08 08:21:12 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:21:12 --> Controller Class Initialized
DEBUG - 2021-01-08 08:21:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:21:13 --> Final output sent to browser
DEBUG - 2021-01-08 08:21:13 --> Total execution time: 0.3924
INFO - 2021-01-08 08:21:24 --> Config Class Initialized
INFO - 2021-01-08 08:21:24 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:21:24 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:21:24 --> Utf8 Class Initialized
INFO - 2021-01-08 08:21:24 --> URI Class Initialized
INFO - 2021-01-08 08:21:24 --> Router Class Initialized
INFO - 2021-01-08 08:21:24 --> Output Class Initialized
INFO - 2021-01-08 08:21:24 --> Security Class Initialized
DEBUG - 2021-01-08 08:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:21:24 --> Input Class Initialized
INFO - 2021-01-08 08:21:24 --> Language Class Initialized
INFO - 2021-01-08 08:21:24 --> Language Class Initialized
INFO - 2021-01-08 08:21:24 --> Config Class Initialized
INFO - 2021-01-08 08:21:24 --> Loader Class Initialized
INFO - 2021-01-08 08:21:24 --> Helper loaded: url_helper
INFO - 2021-01-08 08:21:24 --> Helper loaded: file_helper
INFO - 2021-01-08 08:21:24 --> Helper loaded: form_helper
INFO - 2021-01-08 08:21:24 --> Helper loaded: my_helper
INFO - 2021-01-08 08:21:24 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:21:24 --> Controller Class Initialized
DEBUG - 2021-01-08 08:21:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:21:24 --> Final output sent to browser
DEBUG - 2021-01-08 08:21:24 --> Total execution time: 0.3827
INFO - 2021-01-08 08:26:41 --> Config Class Initialized
INFO - 2021-01-08 08:26:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:26:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:26:41 --> Utf8 Class Initialized
INFO - 2021-01-08 08:26:42 --> URI Class Initialized
INFO - 2021-01-08 08:26:42 --> Router Class Initialized
INFO - 2021-01-08 08:26:42 --> Output Class Initialized
INFO - 2021-01-08 08:26:42 --> Security Class Initialized
DEBUG - 2021-01-08 08:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:26:42 --> Input Class Initialized
INFO - 2021-01-08 08:26:42 --> Language Class Initialized
INFO - 2021-01-08 08:26:42 --> Language Class Initialized
INFO - 2021-01-08 08:26:42 --> Config Class Initialized
INFO - 2021-01-08 08:26:42 --> Loader Class Initialized
INFO - 2021-01-08 08:26:42 --> Helper loaded: url_helper
INFO - 2021-01-08 08:26:42 --> Helper loaded: file_helper
INFO - 2021-01-08 08:26:42 --> Helper loaded: form_helper
INFO - 2021-01-08 08:26:42 --> Helper loaded: my_helper
INFO - 2021-01-08 08:26:42 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:26:42 --> Controller Class Initialized
DEBUG - 2021-01-08 08:26:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:26:42 --> Final output sent to browser
DEBUG - 2021-01-08 08:26:42 --> Total execution time: 0.4604
INFO - 2021-01-08 08:27:14 --> Config Class Initialized
INFO - 2021-01-08 08:27:14 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:27:14 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:27:14 --> Utf8 Class Initialized
INFO - 2021-01-08 08:27:14 --> URI Class Initialized
INFO - 2021-01-08 08:27:14 --> Router Class Initialized
INFO - 2021-01-08 08:27:14 --> Output Class Initialized
INFO - 2021-01-08 08:27:14 --> Security Class Initialized
DEBUG - 2021-01-08 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:27:14 --> Input Class Initialized
INFO - 2021-01-08 08:27:14 --> Language Class Initialized
INFO - 2021-01-08 08:27:14 --> Language Class Initialized
INFO - 2021-01-08 08:27:14 --> Config Class Initialized
INFO - 2021-01-08 08:27:14 --> Loader Class Initialized
INFO - 2021-01-08 08:27:14 --> Helper loaded: url_helper
INFO - 2021-01-08 08:27:14 --> Helper loaded: file_helper
INFO - 2021-01-08 08:27:15 --> Helper loaded: form_helper
INFO - 2021-01-08 08:27:15 --> Helper loaded: my_helper
INFO - 2021-01-08 08:27:15 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:27:15 --> Controller Class Initialized
DEBUG - 2021-01-08 08:27:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:27:15 --> Final output sent to browser
DEBUG - 2021-01-08 08:27:15 --> Total execution time: 0.3945
INFO - 2021-01-08 08:28:20 --> Config Class Initialized
INFO - 2021-01-08 08:28:20 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:28:20 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:28:20 --> Utf8 Class Initialized
INFO - 2021-01-08 08:28:20 --> URI Class Initialized
INFO - 2021-01-08 08:28:20 --> Router Class Initialized
INFO - 2021-01-08 08:28:20 --> Output Class Initialized
INFO - 2021-01-08 08:28:20 --> Security Class Initialized
DEBUG - 2021-01-08 08:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:28:20 --> Input Class Initialized
INFO - 2021-01-08 08:28:20 --> Language Class Initialized
INFO - 2021-01-08 08:28:20 --> Language Class Initialized
INFO - 2021-01-08 08:28:20 --> Config Class Initialized
INFO - 2021-01-08 08:28:20 --> Loader Class Initialized
INFO - 2021-01-08 08:28:20 --> Helper loaded: url_helper
INFO - 2021-01-08 08:28:20 --> Helper loaded: file_helper
INFO - 2021-01-08 08:28:20 --> Helper loaded: form_helper
INFO - 2021-01-08 08:28:20 --> Helper loaded: my_helper
INFO - 2021-01-08 08:28:20 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:28:20 --> Controller Class Initialized
DEBUG - 2021-01-08 08:28:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:28:21 --> Final output sent to browser
DEBUG - 2021-01-08 08:28:21 --> Total execution time: 0.4455
INFO - 2021-01-08 08:28:53 --> Config Class Initialized
INFO - 2021-01-08 08:28:53 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:28:53 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:28:53 --> Utf8 Class Initialized
INFO - 2021-01-08 08:28:53 --> URI Class Initialized
INFO - 2021-01-08 08:28:53 --> Router Class Initialized
INFO - 2021-01-08 08:28:53 --> Output Class Initialized
INFO - 2021-01-08 08:28:53 --> Security Class Initialized
DEBUG - 2021-01-08 08:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:28:53 --> Input Class Initialized
INFO - 2021-01-08 08:28:53 --> Language Class Initialized
INFO - 2021-01-08 08:28:53 --> Language Class Initialized
INFO - 2021-01-08 08:28:53 --> Config Class Initialized
INFO - 2021-01-08 08:28:53 --> Loader Class Initialized
INFO - 2021-01-08 08:28:53 --> Helper loaded: url_helper
INFO - 2021-01-08 08:28:53 --> Helper loaded: file_helper
INFO - 2021-01-08 08:28:53 --> Helper loaded: form_helper
INFO - 2021-01-08 08:28:53 --> Helper loaded: my_helper
INFO - 2021-01-08 08:28:53 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:28:53 --> Controller Class Initialized
DEBUG - 2021-01-08 08:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:28:53 --> Final output sent to browser
DEBUG - 2021-01-08 08:28:53 --> Total execution time: 0.3731
INFO - 2021-01-08 08:29:03 --> Config Class Initialized
INFO - 2021-01-08 08:29:03 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:29:03 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:29:03 --> Utf8 Class Initialized
INFO - 2021-01-08 08:29:03 --> URI Class Initialized
INFO - 2021-01-08 08:29:03 --> Router Class Initialized
INFO - 2021-01-08 08:29:03 --> Output Class Initialized
INFO - 2021-01-08 08:29:03 --> Security Class Initialized
DEBUG - 2021-01-08 08:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:29:03 --> Input Class Initialized
INFO - 2021-01-08 08:29:03 --> Language Class Initialized
INFO - 2021-01-08 08:29:03 --> Language Class Initialized
INFO - 2021-01-08 08:29:03 --> Config Class Initialized
INFO - 2021-01-08 08:29:03 --> Loader Class Initialized
INFO - 2021-01-08 08:29:03 --> Helper loaded: url_helper
INFO - 2021-01-08 08:29:03 --> Helper loaded: file_helper
INFO - 2021-01-08 08:29:03 --> Helper loaded: form_helper
INFO - 2021-01-08 08:29:03 --> Helper loaded: my_helper
INFO - 2021-01-08 08:29:03 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:29:03 --> Controller Class Initialized
DEBUG - 2021-01-08 08:29:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:29:03 --> Final output sent to browser
DEBUG - 2021-01-08 08:29:03 --> Total execution time: 0.3829
INFO - 2021-01-08 08:29:12 --> Config Class Initialized
INFO - 2021-01-08 08:29:12 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:29:12 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:29:12 --> Utf8 Class Initialized
INFO - 2021-01-08 08:29:12 --> URI Class Initialized
INFO - 2021-01-08 08:29:12 --> Router Class Initialized
INFO - 2021-01-08 08:29:12 --> Output Class Initialized
INFO - 2021-01-08 08:29:12 --> Security Class Initialized
DEBUG - 2021-01-08 08:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:29:12 --> Input Class Initialized
INFO - 2021-01-08 08:29:12 --> Language Class Initialized
INFO - 2021-01-08 08:29:12 --> Language Class Initialized
INFO - 2021-01-08 08:29:12 --> Config Class Initialized
INFO - 2021-01-08 08:29:12 --> Loader Class Initialized
INFO - 2021-01-08 08:29:12 --> Helper loaded: url_helper
INFO - 2021-01-08 08:29:12 --> Helper loaded: file_helper
INFO - 2021-01-08 08:29:12 --> Helper loaded: form_helper
INFO - 2021-01-08 08:29:12 --> Helper loaded: my_helper
INFO - 2021-01-08 08:29:12 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:29:12 --> Controller Class Initialized
DEBUG - 2021-01-08 08:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:29:12 --> Final output sent to browser
DEBUG - 2021-01-08 08:29:12 --> Total execution time: 0.3725
INFO - 2021-01-08 08:29:23 --> Config Class Initialized
INFO - 2021-01-08 08:29:23 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:29:23 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:29:23 --> Utf8 Class Initialized
INFO - 2021-01-08 08:29:23 --> URI Class Initialized
INFO - 2021-01-08 08:29:23 --> Router Class Initialized
INFO - 2021-01-08 08:29:23 --> Output Class Initialized
INFO - 2021-01-08 08:29:23 --> Security Class Initialized
DEBUG - 2021-01-08 08:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:29:24 --> Input Class Initialized
INFO - 2021-01-08 08:29:24 --> Language Class Initialized
INFO - 2021-01-08 08:29:24 --> Language Class Initialized
INFO - 2021-01-08 08:29:24 --> Config Class Initialized
INFO - 2021-01-08 08:29:24 --> Loader Class Initialized
INFO - 2021-01-08 08:29:24 --> Helper loaded: url_helper
INFO - 2021-01-08 08:29:24 --> Helper loaded: file_helper
INFO - 2021-01-08 08:29:24 --> Helper loaded: form_helper
INFO - 2021-01-08 08:29:24 --> Helper loaded: my_helper
INFO - 2021-01-08 08:29:24 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:29:24 --> Controller Class Initialized
DEBUG - 2021-01-08 08:29:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:29:24 --> Final output sent to browser
DEBUG - 2021-01-08 08:29:24 --> Total execution time: 0.3823
INFO - 2021-01-08 08:29:30 --> Config Class Initialized
INFO - 2021-01-08 08:29:30 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:29:30 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:29:30 --> Utf8 Class Initialized
INFO - 2021-01-08 08:29:30 --> URI Class Initialized
INFO - 2021-01-08 08:29:30 --> Router Class Initialized
INFO - 2021-01-08 08:29:30 --> Output Class Initialized
INFO - 2021-01-08 08:29:30 --> Security Class Initialized
DEBUG - 2021-01-08 08:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:29:30 --> Input Class Initialized
INFO - 2021-01-08 08:29:30 --> Language Class Initialized
INFO - 2021-01-08 08:29:31 --> Language Class Initialized
INFO - 2021-01-08 08:29:31 --> Config Class Initialized
INFO - 2021-01-08 08:29:31 --> Loader Class Initialized
INFO - 2021-01-08 08:29:31 --> Helper loaded: url_helper
INFO - 2021-01-08 08:29:31 --> Helper loaded: file_helper
INFO - 2021-01-08 08:29:31 --> Helper loaded: form_helper
INFO - 2021-01-08 08:29:31 --> Helper loaded: my_helper
INFO - 2021-01-08 08:29:31 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:29:31 --> Controller Class Initialized
DEBUG - 2021-01-08 08:29:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:29:31 --> Final output sent to browser
DEBUG - 2021-01-08 08:29:31 --> Total execution time: 0.4097
INFO - 2021-01-08 08:52:20 --> Config Class Initialized
INFO - 2021-01-08 08:52:20 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:52:20 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:52:20 --> Utf8 Class Initialized
INFO - 2021-01-08 08:52:20 --> URI Class Initialized
INFO - 2021-01-08 08:52:20 --> Router Class Initialized
INFO - 2021-01-08 08:52:20 --> Output Class Initialized
INFO - 2021-01-08 08:52:20 --> Security Class Initialized
DEBUG - 2021-01-08 08:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:52:20 --> Input Class Initialized
INFO - 2021-01-08 08:52:20 --> Language Class Initialized
INFO - 2021-01-08 08:52:20 --> Language Class Initialized
INFO - 2021-01-08 08:52:20 --> Config Class Initialized
INFO - 2021-01-08 08:52:20 --> Loader Class Initialized
INFO - 2021-01-08 08:52:20 --> Helper loaded: url_helper
INFO - 2021-01-08 08:52:20 --> Helper loaded: file_helper
INFO - 2021-01-08 08:52:20 --> Helper loaded: form_helper
INFO - 2021-01-08 08:52:20 --> Helper loaded: my_helper
INFO - 2021-01-08 08:52:20 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:52:20 --> Controller Class Initialized
DEBUG - 2021-01-08 08:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:52:20 --> Final output sent to browser
DEBUG - 2021-01-08 08:52:20 --> Total execution time: 0.4030
INFO - 2021-01-08 08:52:33 --> Config Class Initialized
INFO - 2021-01-08 08:52:33 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:52:33 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:52:33 --> Utf8 Class Initialized
INFO - 2021-01-08 08:52:33 --> URI Class Initialized
INFO - 2021-01-08 08:52:33 --> Router Class Initialized
INFO - 2021-01-08 08:52:33 --> Output Class Initialized
INFO - 2021-01-08 08:52:33 --> Security Class Initialized
DEBUG - 2021-01-08 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:52:33 --> Input Class Initialized
INFO - 2021-01-08 08:52:33 --> Language Class Initialized
INFO - 2021-01-08 08:52:33 --> Language Class Initialized
INFO - 2021-01-08 08:52:33 --> Config Class Initialized
INFO - 2021-01-08 08:52:33 --> Loader Class Initialized
INFO - 2021-01-08 08:52:33 --> Helper loaded: url_helper
INFO - 2021-01-08 08:52:33 --> Helper loaded: file_helper
INFO - 2021-01-08 08:52:33 --> Helper loaded: form_helper
INFO - 2021-01-08 08:52:33 --> Helper loaded: my_helper
INFO - 2021-01-08 08:52:33 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:52:33 --> Controller Class Initialized
DEBUG - 2021-01-08 08:52:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:52:33 --> Final output sent to browser
DEBUG - 2021-01-08 08:52:33 --> Total execution time: 0.3746
INFO - 2021-01-08 08:54:09 --> Config Class Initialized
INFO - 2021-01-08 08:54:09 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:54:09 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:54:09 --> Utf8 Class Initialized
INFO - 2021-01-08 08:54:09 --> URI Class Initialized
INFO - 2021-01-08 08:54:09 --> Router Class Initialized
INFO - 2021-01-08 08:54:09 --> Output Class Initialized
INFO - 2021-01-08 08:54:09 --> Security Class Initialized
DEBUG - 2021-01-08 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:54:09 --> Input Class Initialized
INFO - 2021-01-08 08:54:09 --> Language Class Initialized
INFO - 2021-01-08 08:54:09 --> Language Class Initialized
INFO - 2021-01-08 08:54:09 --> Config Class Initialized
INFO - 2021-01-08 08:54:09 --> Loader Class Initialized
INFO - 2021-01-08 08:54:09 --> Helper loaded: url_helper
INFO - 2021-01-08 08:54:09 --> Helper loaded: file_helper
INFO - 2021-01-08 08:54:09 --> Helper loaded: form_helper
INFO - 2021-01-08 08:54:09 --> Helper loaded: my_helper
INFO - 2021-01-08 08:54:09 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:54:09 --> Controller Class Initialized
DEBUG - 2021-01-08 08:54:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:54:09 --> Final output sent to browser
DEBUG - 2021-01-08 08:54:09 --> Total execution time: 0.4079
INFO - 2021-01-08 08:54:25 --> Config Class Initialized
INFO - 2021-01-08 08:54:26 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:54:26 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:54:26 --> Utf8 Class Initialized
INFO - 2021-01-08 08:54:26 --> URI Class Initialized
INFO - 2021-01-08 08:54:26 --> Router Class Initialized
INFO - 2021-01-08 08:54:26 --> Output Class Initialized
INFO - 2021-01-08 08:54:26 --> Security Class Initialized
DEBUG - 2021-01-08 08:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:54:26 --> Input Class Initialized
INFO - 2021-01-08 08:54:26 --> Language Class Initialized
INFO - 2021-01-08 08:54:26 --> Language Class Initialized
INFO - 2021-01-08 08:54:26 --> Config Class Initialized
INFO - 2021-01-08 08:54:26 --> Loader Class Initialized
INFO - 2021-01-08 08:54:26 --> Helper loaded: url_helper
INFO - 2021-01-08 08:54:26 --> Helper loaded: file_helper
INFO - 2021-01-08 08:54:26 --> Helper loaded: form_helper
INFO - 2021-01-08 08:54:26 --> Helper loaded: my_helper
INFO - 2021-01-08 08:54:26 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:54:26 --> Controller Class Initialized
DEBUG - 2021-01-08 08:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:54:26 --> Final output sent to browser
DEBUG - 2021-01-08 08:54:26 --> Total execution time: 0.3802
INFO - 2021-01-08 08:54:39 --> Config Class Initialized
INFO - 2021-01-08 08:54:39 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:54:39 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:54:39 --> Utf8 Class Initialized
INFO - 2021-01-08 08:54:39 --> URI Class Initialized
INFO - 2021-01-08 08:54:39 --> Router Class Initialized
INFO - 2021-01-08 08:54:39 --> Output Class Initialized
INFO - 2021-01-08 08:54:39 --> Security Class Initialized
DEBUG - 2021-01-08 08:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:54:40 --> Input Class Initialized
INFO - 2021-01-08 08:54:40 --> Language Class Initialized
INFO - 2021-01-08 08:54:40 --> Language Class Initialized
INFO - 2021-01-08 08:54:40 --> Config Class Initialized
INFO - 2021-01-08 08:54:40 --> Loader Class Initialized
INFO - 2021-01-08 08:54:40 --> Helper loaded: url_helper
INFO - 2021-01-08 08:54:40 --> Helper loaded: file_helper
INFO - 2021-01-08 08:54:40 --> Helper loaded: form_helper
INFO - 2021-01-08 08:54:40 --> Helper loaded: my_helper
INFO - 2021-01-08 08:54:40 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:54:40 --> Controller Class Initialized
DEBUG - 2021-01-08 08:54:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:54:40 --> Final output sent to browser
DEBUG - 2021-01-08 08:54:40 --> Total execution time: 0.4867
INFO - 2021-01-08 08:55:06 --> Config Class Initialized
INFO - 2021-01-08 08:55:06 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:55:06 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:55:06 --> Utf8 Class Initialized
INFO - 2021-01-08 08:55:06 --> URI Class Initialized
INFO - 2021-01-08 08:55:06 --> Router Class Initialized
INFO - 2021-01-08 08:55:06 --> Output Class Initialized
INFO - 2021-01-08 08:55:06 --> Security Class Initialized
DEBUG - 2021-01-08 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:55:06 --> Input Class Initialized
INFO - 2021-01-08 08:55:06 --> Language Class Initialized
INFO - 2021-01-08 08:55:06 --> Language Class Initialized
INFO - 2021-01-08 08:55:06 --> Config Class Initialized
INFO - 2021-01-08 08:55:06 --> Loader Class Initialized
INFO - 2021-01-08 08:55:06 --> Helper loaded: url_helper
INFO - 2021-01-08 08:55:06 --> Helper loaded: file_helper
INFO - 2021-01-08 08:55:06 --> Helper loaded: form_helper
INFO - 2021-01-08 08:55:06 --> Helper loaded: my_helper
INFO - 2021-01-08 08:55:06 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:55:06 --> Controller Class Initialized
DEBUG - 2021-01-08 08:55:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:55:06 --> Final output sent to browser
DEBUG - 2021-01-08 08:55:06 --> Total execution time: 0.3919
INFO - 2021-01-08 08:55:30 --> Config Class Initialized
INFO - 2021-01-08 08:55:30 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:55:30 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:55:30 --> Utf8 Class Initialized
INFO - 2021-01-08 08:55:31 --> URI Class Initialized
INFO - 2021-01-08 08:55:31 --> Router Class Initialized
INFO - 2021-01-08 08:55:31 --> Output Class Initialized
INFO - 2021-01-08 08:55:31 --> Security Class Initialized
DEBUG - 2021-01-08 08:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:55:31 --> Input Class Initialized
INFO - 2021-01-08 08:55:31 --> Language Class Initialized
INFO - 2021-01-08 08:55:31 --> Language Class Initialized
INFO - 2021-01-08 08:55:31 --> Config Class Initialized
INFO - 2021-01-08 08:55:31 --> Loader Class Initialized
INFO - 2021-01-08 08:55:31 --> Helper loaded: url_helper
INFO - 2021-01-08 08:55:31 --> Helper loaded: file_helper
INFO - 2021-01-08 08:55:31 --> Helper loaded: form_helper
INFO - 2021-01-08 08:55:31 --> Helper loaded: my_helper
INFO - 2021-01-08 08:55:31 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:55:31 --> Controller Class Initialized
DEBUG - 2021-01-08 08:55:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:55:31 --> Final output sent to browser
DEBUG - 2021-01-08 08:55:31 --> Total execution time: 0.4113
INFO - 2021-01-08 08:55:41 --> Config Class Initialized
INFO - 2021-01-08 08:55:41 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:55:41 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:55:41 --> Utf8 Class Initialized
INFO - 2021-01-08 08:55:41 --> URI Class Initialized
INFO - 2021-01-08 08:55:41 --> Router Class Initialized
INFO - 2021-01-08 08:55:41 --> Output Class Initialized
INFO - 2021-01-08 08:55:41 --> Security Class Initialized
DEBUG - 2021-01-08 08:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:55:41 --> Input Class Initialized
INFO - 2021-01-08 08:55:41 --> Language Class Initialized
INFO - 2021-01-08 08:55:41 --> Language Class Initialized
INFO - 2021-01-08 08:55:41 --> Config Class Initialized
INFO - 2021-01-08 08:55:41 --> Loader Class Initialized
INFO - 2021-01-08 08:55:41 --> Helper loaded: url_helper
INFO - 2021-01-08 08:55:41 --> Helper loaded: file_helper
INFO - 2021-01-08 08:55:41 --> Helper loaded: form_helper
INFO - 2021-01-08 08:55:41 --> Helper loaded: my_helper
INFO - 2021-01-08 08:55:41 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:55:41 --> Controller Class Initialized
DEBUG - 2021-01-08 08:55:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:55:41 --> Final output sent to browser
DEBUG - 2021-01-08 08:55:41 --> Total execution time: 0.3839
INFO - 2021-01-08 08:56:00 --> Config Class Initialized
INFO - 2021-01-08 08:56:00 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:56:00 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:56:00 --> Utf8 Class Initialized
INFO - 2021-01-08 08:56:00 --> URI Class Initialized
INFO - 2021-01-08 08:56:00 --> Router Class Initialized
INFO - 2021-01-08 08:56:00 --> Output Class Initialized
INFO - 2021-01-08 08:56:00 --> Security Class Initialized
DEBUG - 2021-01-08 08:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:56:00 --> Input Class Initialized
INFO - 2021-01-08 08:56:00 --> Language Class Initialized
INFO - 2021-01-08 08:56:00 --> Language Class Initialized
INFO - 2021-01-08 08:56:00 --> Config Class Initialized
INFO - 2021-01-08 08:56:00 --> Loader Class Initialized
INFO - 2021-01-08 08:56:00 --> Helper loaded: url_helper
INFO - 2021-01-08 08:56:00 --> Helper loaded: file_helper
INFO - 2021-01-08 08:56:00 --> Helper loaded: form_helper
INFO - 2021-01-08 08:56:00 --> Helper loaded: my_helper
INFO - 2021-01-08 08:56:00 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:56:00 --> Controller Class Initialized
DEBUG - 2021-01-08 08:56:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:56:00 --> Final output sent to browser
DEBUG - 2021-01-08 08:56:00 --> Total execution time: 0.4549
INFO - 2021-01-08 08:57:02 --> Config Class Initialized
INFO - 2021-01-08 08:57:02 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:57:02 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:57:02 --> Utf8 Class Initialized
INFO - 2021-01-08 08:57:02 --> URI Class Initialized
INFO - 2021-01-08 08:57:02 --> Router Class Initialized
INFO - 2021-01-08 08:57:02 --> Output Class Initialized
INFO - 2021-01-08 08:57:02 --> Security Class Initialized
DEBUG - 2021-01-08 08:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:57:02 --> Input Class Initialized
INFO - 2021-01-08 08:57:02 --> Language Class Initialized
INFO - 2021-01-08 08:57:02 --> Language Class Initialized
INFO - 2021-01-08 08:57:02 --> Config Class Initialized
INFO - 2021-01-08 08:57:02 --> Loader Class Initialized
INFO - 2021-01-08 08:57:02 --> Helper loaded: url_helper
INFO - 2021-01-08 08:57:02 --> Helper loaded: file_helper
INFO - 2021-01-08 08:57:02 --> Helper loaded: form_helper
INFO - 2021-01-08 08:57:02 --> Helper loaded: my_helper
INFO - 2021-01-08 08:57:02 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:57:02 --> Controller Class Initialized
DEBUG - 2021-01-08 08:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:57:03 --> Final output sent to browser
DEBUG - 2021-01-08 08:57:03 --> Total execution time: 0.3627
INFO - 2021-01-08 08:57:15 --> Config Class Initialized
INFO - 2021-01-08 08:57:15 --> Hooks Class Initialized
DEBUG - 2021-01-08 08:57:15 --> UTF-8 Support Enabled
INFO - 2021-01-08 08:57:16 --> Utf8 Class Initialized
INFO - 2021-01-08 08:57:16 --> URI Class Initialized
INFO - 2021-01-08 08:57:16 --> Router Class Initialized
INFO - 2021-01-08 08:57:16 --> Output Class Initialized
INFO - 2021-01-08 08:57:16 --> Security Class Initialized
DEBUG - 2021-01-08 08:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 08:57:16 --> Input Class Initialized
INFO - 2021-01-08 08:57:16 --> Language Class Initialized
INFO - 2021-01-08 08:57:16 --> Language Class Initialized
INFO - 2021-01-08 08:57:16 --> Config Class Initialized
INFO - 2021-01-08 08:57:16 --> Loader Class Initialized
INFO - 2021-01-08 08:57:16 --> Helper loaded: url_helper
INFO - 2021-01-08 08:57:16 --> Helper loaded: file_helper
INFO - 2021-01-08 08:57:16 --> Helper loaded: form_helper
INFO - 2021-01-08 08:57:16 --> Helper loaded: my_helper
INFO - 2021-01-08 08:57:16 --> Database Driver Class Initialized
DEBUG - 2021-01-08 08:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 08:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 08:57:16 --> Controller Class Initialized
DEBUG - 2021-01-08 08:57:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 08:57:16 --> Final output sent to browser
DEBUG - 2021-01-08 08:57:16 --> Total execution time: 0.4011
INFO - 2021-01-08 09:02:46 --> Config Class Initialized
INFO - 2021-01-08 09:02:46 --> Hooks Class Initialized
DEBUG - 2021-01-08 09:02:47 --> UTF-8 Support Enabled
INFO - 2021-01-08 09:02:47 --> Utf8 Class Initialized
INFO - 2021-01-08 09:02:47 --> URI Class Initialized
INFO - 2021-01-08 09:02:47 --> Router Class Initialized
INFO - 2021-01-08 09:02:47 --> Output Class Initialized
INFO - 2021-01-08 09:02:47 --> Security Class Initialized
DEBUG - 2021-01-08 09:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 09:02:47 --> Input Class Initialized
INFO - 2021-01-08 09:02:47 --> Language Class Initialized
INFO - 2021-01-08 09:02:47 --> Language Class Initialized
INFO - 2021-01-08 09:02:47 --> Config Class Initialized
INFO - 2021-01-08 09:02:47 --> Loader Class Initialized
INFO - 2021-01-08 09:02:47 --> Helper loaded: url_helper
INFO - 2021-01-08 09:02:47 --> Helper loaded: file_helper
INFO - 2021-01-08 09:02:47 --> Helper loaded: form_helper
INFO - 2021-01-08 09:02:47 --> Helper loaded: my_helper
INFO - 2021-01-08 09:02:47 --> Database Driver Class Initialized
DEBUG - 2021-01-08 09:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 09:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 09:02:47 --> Controller Class Initialized
DEBUG - 2021-01-08 09:02:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 09:02:47 --> Final output sent to browser
DEBUG - 2021-01-08 09:02:47 --> Total execution time: 0.3720
INFO - 2021-01-08 09:04:57 --> Config Class Initialized
INFO - 2021-01-08 09:04:57 --> Hooks Class Initialized
DEBUG - 2021-01-08 09:04:57 --> UTF-8 Support Enabled
INFO - 2021-01-08 09:04:57 --> Utf8 Class Initialized
INFO - 2021-01-08 09:04:57 --> URI Class Initialized
INFO - 2021-01-08 09:04:57 --> Router Class Initialized
INFO - 2021-01-08 09:04:57 --> Output Class Initialized
INFO - 2021-01-08 09:04:57 --> Security Class Initialized
DEBUG - 2021-01-08 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 09:04:57 --> Input Class Initialized
INFO - 2021-01-08 09:04:57 --> Language Class Initialized
INFO - 2021-01-08 09:04:57 --> Language Class Initialized
INFO - 2021-01-08 09:04:57 --> Config Class Initialized
INFO - 2021-01-08 09:04:57 --> Loader Class Initialized
INFO - 2021-01-08 09:04:57 --> Helper loaded: url_helper
INFO - 2021-01-08 09:04:57 --> Helper loaded: file_helper
INFO - 2021-01-08 09:04:57 --> Helper loaded: form_helper
INFO - 2021-01-08 09:04:57 --> Helper loaded: my_helper
INFO - 2021-01-08 09:04:57 --> Database Driver Class Initialized
DEBUG - 2021-01-08 09:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 09:04:57 --> Controller Class Initialized
DEBUG - 2021-01-08 09:04:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 09:04:57 --> Final output sent to browser
DEBUG - 2021-01-08 09:04:57 --> Total execution time: 0.4661
INFO - 2021-01-08 09:05:07 --> Config Class Initialized
INFO - 2021-01-08 09:05:07 --> Hooks Class Initialized
DEBUG - 2021-01-08 09:05:07 --> UTF-8 Support Enabled
INFO - 2021-01-08 09:05:07 --> Utf8 Class Initialized
INFO - 2021-01-08 09:05:07 --> URI Class Initialized
INFO - 2021-01-08 09:05:07 --> Router Class Initialized
INFO - 2021-01-08 09:05:07 --> Output Class Initialized
INFO - 2021-01-08 09:05:07 --> Security Class Initialized
DEBUG - 2021-01-08 09:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 09:05:08 --> Input Class Initialized
INFO - 2021-01-08 09:05:08 --> Language Class Initialized
INFO - 2021-01-08 09:05:08 --> Language Class Initialized
INFO - 2021-01-08 09:05:08 --> Config Class Initialized
INFO - 2021-01-08 09:05:08 --> Loader Class Initialized
INFO - 2021-01-08 09:05:08 --> Helper loaded: url_helper
INFO - 2021-01-08 09:05:08 --> Helper loaded: file_helper
INFO - 2021-01-08 09:05:08 --> Helper loaded: form_helper
INFO - 2021-01-08 09:05:08 --> Helper loaded: my_helper
INFO - 2021-01-08 09:05:08 --> Database Driver Class Initialized
DEBUG - 2021-01-08 09:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 09:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 09:05:08 --> Controller Class Initialized
DEBUG - 2021-01-08 09:05:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 09:05:08 --> Final output sent to browser
DEBUG - 2021-01-08 09:05:08 --> Total execution time: 0.4008
INFO - 2021-01-08 09:05:39 --> Config Class Initialized
INFO - 2021-01-08 09:05:39 --> Hooks Class Initialized
DEBUG - 2021-01-08 09:05:39 --> UTF-8 Support Enabled
INFO - 2021-01-08 09:05:39 --> Utf8 Class Initialized
INFO - 2021-01-08 09:05:39 --> URI Class Initialized
INFO - 2021-01-08 09:05:39 --> Router Class Initialized
INFO - 2021-01-08 09:05:39 --> Output Class Initialized
INFO - 2021-01-08 09:05:39 --> Security Class Initialized
DEBUG - 2021-01-08 09:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 09:05:39 --> Input Class Initialized
INFO - 2021-01-08 09:05:39 --> Language Class Initialized
INFO - 2021-01-08 09:05:39 --> Language Class Initialized
INFO - 2021-01-08 09:05:39 --> Config Class Initialized
INFO - 2021-01-08 09:05:39 --> Loader Class Initialized
INFO - 2021-01-08 09:05:39 --> Helper loaded: url_helper
INFO - 2021-01-08 09:05:39 --> Helper loaded: file_helper
INFO - 2021-01-08 09:05:39 --> Helper loaded: form_helper
INFO - 2021-01-08 09:05:39 --> Helper loaded: my_helper
INFO - 2021-01-08 09:05:39 --> Database Driver Class Initialized
DEBUG - 2021-01-08 09:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 09:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 09:05:40 --> Controller Class Initialized
DEBUG - 2021-01-08 09:05:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 09:05:40 --> Final output sent to browser
DEBUG - 2021-01-08 09:05:40 --> Total execution time: 0.4285
INFO - 2021-01-08 09:05:54 --> Config Class Initialized
INFO - 2021-01-08 09:05:54 --> Hooks Class Initialized
DEBUG - 2021-01-08 09:05:54 --> UTF-8 Support Enabled
INFO - 2021-01-08 09:05:54 --> Utf8 Class Initialized
INFO - 2021-01-08 09:05:54 --> URI Class Initialized
INFO - 2021-01-08 09:05:54 --> Router Class Initialized
INFO - 2021-01-08 09:05:54 --> Output Class Initialized
INFO - 2021-01-08 09:05:54 --> Security Class Initialized
DEBUG - 2021-01-08 09:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 09:05:54 --> Input Class Initialized
INFO - 2021-01-08 09:05:54 --> Language Class Initialized
INFO - 2021-01-08 09:05:54 --> Language Class Initialized
INFO - 2021-01-08 09:05:54 --> Config Class Initialized
INFO - 2021-01-08 09:05:54 --> Loader Class Initialized
INFO - 2021-01-08 09:05:54 --> Helper loaded: url_helper
INFO - 2021-01-08 09:05:54 --> Helper loaded: file_helper
INFO - 2021-01-08 09:05:54 --> Helper loaded: form_helper
INFO - 2021-01-08 09:05:54 --> Helper loaded: my_helper
INFO - 2021-01-08 09:05:54 --> Database Driver Class Initialized
DEBUG - 2021-01-08 09:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 09:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 09:05:54 --> Controller Class Initialized
DEBUG - 2021-01-08 09:05:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 09:05:55 --> Final output sent to browser
DEBUG - 2021-01-08 09:05:55 --> Total execution time: 0.3929
INFO - 2021-01-08 09:08:58 --> Config Class Initialized
INFO - 2021-01-08 09:08:58 --> Hooks Class Initialized
DEBUG - 2021-01-08 09:08:58 --> UTF-8 Support Enabled
INFO - 2021-01-08 09:08:59 --> Utf8 Class Initialized
INFO - 2021-01-08 09:08:59 --> URI Class Initialized
INFO - 2021-01-08 09:08:59 --> Router Class Initialized
INFO - 2021-01-08 09:08:59 --> Output Class Initialized
INFO - 2021-01-08 09:08:59 --> Security Class Initialized
DEBUG - 2021-01-08 09:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 09:08:59 --> Input Class Initialized
INFO - 2021-01-08 09:08:59 --> Language Class Initialized
INFO - 2021-01-08 09:08:59 --> Language Class Initialized
INFO - 2021-01-08 09:08:59 --> Config Class Initialized
INFO - 2021-01-08 09:08:59 --> Loader Class Initialized
INFO - 2021-01-08 09:08:59 --> Helper loaded: url_helper
INFO - 2021-01-08 09:08:59 --> Helper loaded: file_helper
INFO - 2021-01-08 09:08:59 --> Helper loaded: form_helper
INFO - 2021-01-08 09:08:59 --> Helper loaded: my_helper
INFO - 2021-01-08 09:08:59 --> Database Driver Class Initialized
DEBUG - 2021-01-08 09:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 09:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 09:08:59 --> Controller Class Initialized
DEBUG - 2021-01-08 09:08:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 09:08:59 --> Final output sent to browser
DEBUG - 2021-01-08 09:08:59 --> Total execution time: 0.3969
INFO - 2021-01-08 09:13:55 --> Config Class Initialized
INFO - 2021-01-08 09:13:55 --> Hooks Class Initialized
DEBUG - 2021-01-08 09:13:55 --> UTF-8 Support Enabled
INFO - 2021-01-08 09:13:55 --> Utf8 Class Initialized
INFO - 2021-01-08 09:13:55 --> URI Class Initialized
INFO - 2021-01-08 09:13:55 --> Router Class Initialized
INFO - 2021-01-08 09:13:55 --> Output Class Initialized
INFO - 2021-01-08 09:13:55 --> Security Class Initialized
DEBUG - 2021-01-08 09:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 09:13:55 --> Input Class Initialized
INFO - 2021-01-08 09:13:55 --> Language Class Initialized
INFO - 2021-01-08 09:13:55 --> Language Class Initialized
INFO - 2021-01-08 09:13:55 --> Config Class Initialized
INFO - 2021-01-08 09:13:55 --> Loader Class Initialized
INFO - 2021-01-08 09:13:55 --> Helper loaded: url_helper
INFO - 2021-01-08 09:13:55 --> Helper loaded: file_helper
INFO - 2021-01-08 09:13:55 --> Helper loaded: form_helper
INFO - 2021-01-08 09:13:55 --> Helper loaded: my_helper
INFO - 2021-01-08 09:13:55 --> Database Driver Class Initialized
DEBUG - 2021-01-08 09:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 09:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 09:13:55 --> Controller Class Initialized
DEBUG - 2021-01-08 09:13:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 09:13:55 --> Final output sent to browser
DEBUG - 2021-01-08 09:13:55 --> Total execution time: 0.3965
INFO - 2021-01-08 09:15:16 --> Config Class Initialized
INFO - 2021-01-08 09:15:16 --> Hooks Class Initialized
DEBUG - 2021-01-08 09:15:16 --> UTF-8 Support Enabled
INFO - 2021-01-08 09:15:16 --> Utf8 Class Initialized
INFO - 2021-01-08 09:15:16 --> URI Class Initialized
INFO - 2021-01-08 09:15:16 --> Router Class Initialized
INFO - 2021-01-08 09:15:16 --> Output Class Initialized
INFO - 2021-01-08 09:15:16 --> Security Class Initialized
DEBUG - 2021-01-08 09:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-08 09:15:16 --> Input Class Initialized
INFO - 2021-01-08 09:15:16 --> Language Class Initialized
INFO - 2021-01-08 09:15:16 --> Language Class Initialized
INFO - 2021-01-08 09:15:16 --> Config Class Initialized
INFO - 2021-01-08 09:15:16 --> Loader Class Initialized
INFO - 2021-01-08 09:15:16 --> Helper loaded: url_helper
INFO - 2021-01-08 09:15:16 --> Helper loaded: file_helper
INFO - 2021-01-08 09:15:16 --> Helper loaded: form_helper
INFO - 2021-01-08 09:15:16 --> Helper loaded: my_helper
INFO - 2021-01-08 09:15:16 --> Database Driver Class Initialized
DEBUG - 2021-01-08 09:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-08 09:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-08 09:15:16 --> Controller Class Initialized
DEBUG - 2021-01-08 09:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-08 09:15:16 --> Final output sent to browser
DEBUG - 2021-01-08 09:15:16 --> Total execution time: 0.4033
