<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-02-27 01:56:06 --> Config Class Initialized
INFO - 2021-02-27 01:56:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:56:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:56:06 --> Utf8 Class Initialized
INFO - 2021-02-27 01:56:06 --> URI Class Initialized
DEBUG - 2021-02-27 01:56:06 --> No URI present. Default controller set.
INFO - 2021-02-27 01:56:06 --> Router Class Initialized
INFO - 2021-02-27 01:56:06 --> Output Class Initialized
INFO - 2021-02-27 01:56:06 --> Security Class Initialized
DEBUG - 2021-02-27 01:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:56:06 --> Input Class Initialized
INFO - 2021-02-27 01:56:06 --> Language Class Initialized
INFO - 2021-02-27 01:56:06 --> Language Class Initialized
INFO - 2021-02-27 01:56:06 --> Config Class Initialized
INFO - 2021-02-27 01:56:06 --> Loader Class Initialized
INFO - 2021-02-27 01:56:06 --> Helper loaded: url_helper
INFO - 2021-02-27 01:56:06 --> Helper loaded: file_helper
INFO - 2021-02-27 01:56:06 --> Helper loaded: form_helper
INFO - 2021-02-27 01:56:06 --> Helper loaded: my_helper
INFO - 2021-02-27 01:56:06 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:56:06 --> Controller Class Initialized
INFO - 2021-02-27 01:56:06 --> Config Class Initialized
INFO - 2021-02-27 01:56:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:56:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:56:06 --> Utf8 Class Initialized
INFO - 2021-02-27 01:56:06 --> URI Class Initialized
INFO - 2021-02-27 01:56:06 --> Router Class Initialized
INFO - 2021-02-27 01:56:06 --> Output Class Initialized
INFO - 2021-02-27 01:56:06 --> Security Class Initialized
DEBUG - 2021-02-27 01:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:56:06 --> Input Class Initialized
INFO - 2021-02-27 01:56:06 --> Language Class Initialized
INFO - 2021-02-27 01:56:06 --> Language Class Initialized
INFO - 2021-02-27 01:56:06 --> Config Class Initialized
INFO - 2021-02-27 01:56:06 --> Loader Class Initialized
INFO - 2021-02-27 01:56:06 --> Helper loaded: url_helper
INFO - 2021-02-27 01:56:06 --> Helper loaded: file_helper
INFO - 2021-02-27 01:56:06 --> Helper loaded: form_helper
INFO - 2021-02-27 01:56:06 --> Helper loaded: my_helper
INFO - 2021-02-27 01:56:07 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:56:07 --> Controller Class Initialized
DEBUG - 2021-02-27 01:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 01:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 01:56:07 --> Final output sent to browser
DEBUG - 2021-02-27 01:56:07 --> Total execution time: 0.1848
INFO - 2021-02-27 01:56:52 --> Config Class Initialized
INFO - 2021-02-27 01:56:53 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:56:53 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:56:53 --> Utf8 Class Initialized
INFO - 2021-02-27 01:56:53 --> URI Class Initialized
INFO - 2021-02-27 01:56:53 --> Router Class Initialized
INFO - 2021-02-27 01:56:53 --> Output Class Initialized
INFO - 2021-02-27 01:56:53 --> Security Class Initialized
DEBUG - 2021-02-27 01:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:56:53 --> Input Class Initialized
INFO - 2021-02-27 01:56:53 --> Language Class Initialized
INFO - 2021-02-27 01:56:53 --> Language Class Initialized
INFO - 2021-02-27 01:56:53 --> Config Class Initialized
INFO - 2021-02-27 01:56:53 --> Loader Class Initialized
INFO - 2021-02-27 01:56:53 --> Helper loaded: url_helper
INFO - 2021-02-27 01:56:53 --> Helper loaded: file_helper
INFO - 2021-02-27 01:56:53 --> Helper loaded: form_helper
INFO - 2021-02-27 01:56:53 --> Helper loaded: my_helper
INFO - 2021-02-27 01:56:53 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:56:53 --> Controller Class Initialized
INFO - 2021-02-27 01:56:53 --> Helper loaded: cookie_helper
INFO - 2021-02-27 01:56:53 --> Final output sent to browser
DEBUG - 2021-02-27 01:56:53 --> Total execution time: 0.2498
INFO - 2021-02-27 01:56:53 --> Config Class Initialized
INFO - 2021-02-27 01:56:53 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:56:53 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:56:53 --> Utf8 Class Initialized
INFO - 2021-02-27 01:56:53 --> URI Class Initialized
INFO - 2021-02-27 01:56:53 --> Router Class Initialized
INFO - 2021-02-27 01:56:53 --> Output Class Initialized
INFO - 2021-02-27 01:56:53 --> Security Class Initialized
DEBUG - 2021-02-27 01:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:56:53 --> Input Class Initialized
INFO - 2021-02-27 01:56:53 --> Language Class Initialized
INFO - 2021-02-27 01:56:53 --> Language Class Initialized
INFO - 2021-02-27 01:56:53 --> Config Class Initialized
INFO - 2021-02-27 01:56:53 --> Loader Class Initialized
INFO - 2021-02-27 01:56:53 --> Helper loaded: url_helper
INFO - 2021-02-27 01:56:53 --> Helper loaded: file_helper
INFO - 2021-02-27 01:56:53 --> Helper loaded: form_helper
INFO - 2021-02-27 01:56:53 --> Helper loaded: my_helper
INFO - 2021-02-27 01:56:53 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:56:53 --> Controller Class Initialized
DEBUG - 2021-02-27 01:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 01:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 01:56:54 --> Final output sent to browser
DEBUG - 2021-02-27 01:56:54 --> Total execution time: 0.3347
INFO - 2021-02-27 01:56:55 --> Config Class Initialized
INFO - 2021-02-27 01:56:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:56:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:56:55 --> Utf8 Class Initialized
INFO - 2021-02-27 01:56:55 --> URI Class Initialized
INFO - 2021-02-27 01:56:55 --> Router Class Initialized
INFO - 2021-02-27 01:56:55 --> Output Class Initialized
INFO - 2021-02-27 01:56:55 --> Security Class Initialized
DEBUG - 2021-02-27 01:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:56:55 --> Input Class Initialized
INFO - 2021-02-27 01:56:55 --> Language Class Initialized
INFO - 2021-02-27 01:56:55 --> Language Class Initialized
INFO - 2021-02-27 01:56:55 --> Config Class Initialized
INFO - 2021-02-27 01:56:55 --> Loader Class Initialized
INFO - 2021-02-27 01:56:55 --> Helper loaded: url_helper
INFO - 2021-02-27 01:56:55 --> Helper loaded: file_helper
INFO - 2021-02-27 01:56:55 --> Helper loaded: form_helper
INFO - 2021-02-27 01:56:55 --> Helper loaded: my_helper
INFO - 2021-02-27 01:56:56 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:56:56 --> Controller Class Initialized
DEBUG - 2021-02-27 01:56:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-02-27 01:56:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 01:56:56 --> Final output sent to browser
DEBUG - 2021-02-27 01:56:56 --> Total execution time: 0.2591
INFO - 2021-02-27 01:56:57 --> Config Class Initialized
INFO - 2021-02-27 01:56:57 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:56:57 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:56:57 --> Utf8 Class Initialized
INFO - 2021-02-27 01:56:57 --> URI Class Initialized
INFO - 2021-02-27 01:56:57 --> Router Class Initialized
INFO - 2021-02-27 01:56:57 --> Output Class Initialized
INFO - 2021-02-27 01:56:57 --> Security Class Initialized
DEBUG - 2021-02-27 01:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:56:57 --> Input Class Initialized
INFO - 2021-02-27 01:56:57 --> Language Class Initialized
INFO - 2021-02-27 01:56:57 --> Language Class Initialized
INFO - 2021-02-27 01:56:57 --> Config Class Initialized
INFO - 2021-02-27 01:56:57 --> Loader Class Initialized
INFO - 2021-02-27 01:56:57 --> Helper loaded: url_helper
INFO - 2021-02-27 01:56:57 --> Helper loaded: file_helper
INFO - 2021-02-27 01:56:57 --> Helper loaded: form_helper
INFO - 2021-02-27 01:56:57 --> Helper loaded: my_helper
INFO - 2021-02-27 01:56:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:56:57 --> Controller Class Initialized
DEBUG - 2021-02-27 01:56:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-27 01:56:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 01:56:57 --> Final output sent to browser
DEBUG - 2021-02-27 01:56:57 --> Total execution time: 0.2252
INFO - 2021-02-27 01:57:03 --> Config Class Initialized
INFO - 2021-02-27 01:57:03 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:57:03 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:57:03 --> Utf8 Class Initialized
INFO - 2021-02-27 01:57:03 --> URI Class Initialized
DEBUG - 2021-02-27 01:57:03 --> No URI present. Default controller set.
INFO - 2021-02-27 01:57:03 --> Router Class Initialized
INFO - 2021-02-27 01:57:03 --> Output Class Initialized
INFO - 2021-02-27 01:57:03 --> Security Class Initialized
DEBUG - 2021-02-27 01:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:57:03 --> Input Class Initialized
INFO - 2021-02-27 01:57:03 --> Language Class Initialized
INFO - 2021-02-27 01:57:03 --> Language Class Initialized
INFO - 2021-02-27 01:57:03 --> Config Class Initialized
INFO - 2021-02-27 01:57:03 --> Loader Class Initialized
INFO - 2021-02-27 01:57:03 --> Helper loaded: url_helper
INFO - 2021-02-27 01:57:03 --> Helper loaded: file_helper
INFO - 2021-02-27 01:57:03 --> Helper loaded: form_helper
INFO - 2021-02-27 01:57:03 --> Helper loaded: my_helper
INFO - 2021-02-27 01:57:03 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:57:03 --> Controller Class Initialized
DEBUG - 2021-02-27 01:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 01:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 01:57:03 --> Final output sent to browser
DEBUG - 2021-02-27 01:57:03 --> Total execution time: 0.3095
INFO - 2021-02-27 01:57:06 --> Config Class Initialized
INFO - 2021-02-27 01:57:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:57:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:57:06 --> Utf8 Class Initialized
INFO - 2021-02-27 01:57:06 --> URI Class Initialized
INFO - 2021-02-27 01:57:06 --> Router Class Initialized
INFO - 2021-02-27 01:57:06 --> Output Class Initialized
INFO - 2021-02-27 01:57:06 --> Security Class Initialized
DEBUG - 2021-02-27 01:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:57:06 --> Input Class Initialized
INFO - 2021-02-27 01:57:06 --> Language Class Initialized
INFO - 2021-02-27 01:57:06 --> Language Class Initialized
INFO - 2021-02-27 01:57:06 --> Config Class Initialized
INFO - 2021-02-27 01:57:06 --> Loader Class Initialized
INFO - 2021-02-27 01:57:06 --> Helper loaded: url_helper
INFO - 2021-02-27 01:57:06 --> Helper loaded: file_helper
INFO - 2021-02-27 01:57:06 --> Helper loaded: form_helper
INFO - 2021-02-27 01:57:06 --> Helper loaded: my_helper
INFO - 2021-02-27 01:57:06 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:57:06 --> Controller Class Initialized
DEBUG - 2021-02-27 01:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-27 01:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 01:57:07 --> Final output sent to browser
DEBUG - 2021-02-27 01:57:07 --> Total execution time: 0.2423
INFO - 2021-02-27 01:57:13 --> Config Class Initialized
INFO - 2021-02-27 01:57:13 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:57:13 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:57:13 --> Utf8 Class Initialized
INFO - 2021-02-27 01:57:13 --> URI Class Initialized
INFO - 2021-02-27 01:57:13 --> Router Class Initialized
INFO - 2021-02-27 01:57:13 --> Output Class Initialized
INFO - 2021-02-27 01:57:13 --> Security Class Initialized
DEBUG - 2021-02-27 01:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:57:13 --> Input Class Initialized
INFO - 2021-02-27 01:57:13 --> Language Class Initialized
INFO - 2021-02-27 01:57:13 --> Language Class Initialized
INFO - 2021-02-27 01:57:13 --> Config Class Initialized
INFO - 2021-02-27 01:57:13 --> Loader Class Initialized
INFO - 2021-02-27 01:57:13 --> Helper loaded: url_helper
INFO - 2021-02-27 01:57:13 --> Helper loaded: file_helper
INFO - 2021-02-27 01:57:13 --> Helper loaded: form_helper
INFO - 2021-02-27 01:57:13 --> Helper loaded: my_helper
INFO - 2021-02-27 01:57:13 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:57:13 --> Controller Class Initialized
DEBUG - 2021-02-27 01:57:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-27 01:57:13 --> Final output sent to browser
DEBUG - 2021-02-27 01:57:13 --> Total execution time: 0.2989
INFO - 2021-02-27 01:57:21 --> Config Class Initialized
INFO - 2021-02-27 01:57:21 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:57:21 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:57:21 --> Utf8 Class Initialized
INFO - 2021-02-27 01:57:21 --> URI Class Initialized
INFO - 2021-02-27 01:57:21 --> Router Class Initialized
INFO - 2021-02-27 01:57:22 --> Output Class Initialized
INFO - 2021-02-27 01:57:22 --> Security Class Initialized
DEBUG - 2021-02-27 01:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:57:22 --> Input Class Initialized
INFO - 2021-02-27 01:57:22 --> Language Class Initialized
INFO - 2021-02-27 01:57:22 --> Language Class Initialized
INFO - 2021-02-27 01:57:22 --> Config Class Initialized
INFO - 2021-02-27 01:57:22 --> Loader Class Initialized
INFO - 2021-02-27 01:57:22 --> Helper loaded: url_helper
INFO - 2021-02-27 01:57:22 --> Helper loaded: file_helper
INFO - 2021-02-27 01:57:22 --> Helper loaded: form_helper
INFO - 2021-02-27 01:57:22 --> Helper loaded: my_helper
INFO - 2021-02-27 01:57:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:57:22 --> Controller Class Initialized
INFO - 2021-02-27 01:57:22 --> Helper loaded: cookie_helper
INFO - 2021-02-27 01:57:22 --> Config Class Initialized
INFO - 2021-02-27 01:57:22 --> Hooks Class Initialized
DEBUG - 2021-02-27 01:57:22 --> UTF-8 Support Enabled
INFO - 2021-02-27 01:57:22 --> Utf8 Class Initialized
INFO - 2021-02-27 01:57:22 --> URI Class Initialized
INFO - 2021-02-27 01:57:22 --> Router Class Initialized
INFO - 2021-02-27 01:57:22 --> Output Class Initialized
INFO - 2021-02-27 01:57:22 --> Security Class Initialized
DEBUG - 2021-02-27 01:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 01:57:22 --> Input Class Initialized
INFO - 2021-02-27 01:57:22 --> Language Class Initialized
INFO - 2021-02-27 01:57:22 --> Language Class Initialized
INFO - 2021-02-27 01:57:22 --> Config Class Initialized
INFO - 2021-02-27 01:57:22 --> Loader Class Initialized
INFO - 2021-02-27 01:57:22 --> Helper loaded: url_helper
INFO - 2021-02-27 01:57:22 --> Helper loaded: file_helper
INFO - 2021-02-27 01:57:22 --> Helper loaded: form_helper
INFO - 2021-02-27 01:57:22 --> Helper loaded: my_helper
INFO - 2021-02-27 01:57:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 01:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 01:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 01:57:22 --> Controller Class Initialized
DEBUG - 2021-02-27 01:57:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 01:57:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 01:57:22 --> Final output sent to browser
DEBUG - 2021-02-27 01:57:22 --> Total execution time: 0.2403
INFO - 2021-02-27 02:19:32 --> Config Class Initialized
INFO - 2021-02-27 02:19:32 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:19:32 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:19:32 --> Utf8 Class Initialized
INFO - 2021-02-27 02:19:32 --> URI Class Initialized
DEBUG - 2021-02-27 02:19:32 --> No URI present. Default controller set.
INFO - 2021-02-27 02:19:32 --> Router Class Initialized
INFO - 2021-02-27 02:19:32 --> Output Class Initialized
INFO - 2021-02-27 02:19:32 --> Security Class Initialized
DEBUG - 2021-02-27 02:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:19:32 --> Input Class Initialized
INFO - 2021-02-27 02:19:32 --> Language Class Initialized
INFO - 2021-02-27 02:19:32 --> Language Class Initialized
INFO - 2021-02-27 02:19:32 --> Config Class Initialized
INFO - 2021-02-27 02:19:32 --> Loader Class Initialized
INFO - 2021-02-27 02:19:32 --> Helper loaded: url_helper
INFO - 2021-02-27 02:19:32 --> Helper loaded: file_helper
INFO - 2021-02-27 02:19:32 --> Helper loaded: form_helper
INFO - 2021-02-27 02:19:32 --> Helper loaded: my_helper
INFO - 2021-02-27 02:19:32 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:19:32 --> Controller Class Initialized
INFO - 2021-02-27 02:19:32 --> Config Class Initialized
INFO - 2021-02-27 02:19:32 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:19:32 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:19:32 --> Utf8 Class Initialized
INFO - 2021-02-27 02:19:32 --> URI Class Initialized
INFO - 2021-02-27 02:19:32 --> Router Class Initialized
INFO - 2021-02-27 02:19:32 --> Output Class Initialized
INFO - 2021-02-27 02:19:32 --> Security Class Initialized
DEBUG - 2021-02-27 02:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:19:32 --> Input Class Initialized
INFO - 2021-02-27 02:19:32 --> Language Class Initialized
INFO - 2021-02-27 02:19:32 --> Language Class Initialized
INFO - 2021-02-27 02:19:32 --> Config Class Initialized
INFO - 2021-02-27 02:19:32 --> Loader Class Initialized
INFO - 2021-02-27 02:19:32 --> Helper loaded: url_helper
INFO - 2021-02-27 02:19:32 --> Helper loaded: file_helper
INFO - 2021-02-27 02:19:32 --> Helper loaded: form_helper
INFO - 2021-02-27 02:19:32 --> Helper loaded: my_helper
INFO - 2021-02-27 02:19:32 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:19:32 --> Controller Class Initialized
DEBUG - 2021-02-27 02:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:19:32 --> Final output sent to browser
DEBUG - 2021-02-27 02:19:32 --> Total execution time: 0.2459
INFO - 2021-02-27 02:19:56 --> Config Class Initialized
INFO - 2021-02-27 02:19:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:19:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:19:56 --> Utf8 Class Initialized
INFO - 2021-02-27 02:19:56 --> URI Class Initialized
DEBUG - 2021-02-27 02:19:56 --> No URI present. Default controller set.
INFO - 2021-02-27 02:19:56 --> Router Class Initialized
INFO - 2021-02-27 02:19:56 --> Output Class Initialized
INFO - 2021-02-27 02:19:56 --> Security Class Initialized
DEBUG - 2021-02-27 02:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:19:56 --> Input Class Initialized
INFO - 2021-02-27 02:19:56 --> Language Class Initialized
INFO - 2021-02-27 02:19:56 --> Language Class Initialized
INFO - 2021-02-27 02:19:56 --> Config Class Initialized
INFO - 2021-02-27 02:19:56 --> Loader Class Initialized
INFO - 2021-02-27 02:19:56 --> Helper loaded: url_helper
INFO - 2021-02-27 02:19:56 --> Helper loaded: file_helper
INFO - 2021-02-27 02:19:56 --> Helper loaded: form_helper
INFO - 2021-02-27 02:19:56 --> Helper loaded: my_helper
INFO - 2021-02-27 02:19:56 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:19:56 --> Controller Class Initialized
INFO - 2021-02-27 02:19:56 --> Config Class Initialized
INFO - 2021-02-27 02:19:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:19:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:19:56 --> Utf8 Class Initialized
INFO - 2021-02-27 02:19:56 --> URI Class Initialized
INFO - 2021-02-27 02:19:56 --> Router Class Initialized
INFO - 2021-02-27 02:19:56 --> Output Class Initialized
INFO - 2021-02-27 02:19:56 --> Security Class Initialized
DEBUG - 2021-02-27 02:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:19:56 --> Input Class Initialized
INFO - 2021-02-27 02:19:56 --> Language Class Initialized
INFO - 2021-02-27 02:19:56 --> Language Class Initialized
INFO - 2021-02-27 02:19:56 --> Config Class Initialized
INFO - 2021-02-27 02:19:56 --> Loader Class Initialized
INFO - 2021-02-27 02:19:56 --> Helper loaded: url_helper
INFO - 2021-02-27 02:19:56 --> Helper loaded: file_helper
INFO - 2021-02-27 02:19:56 --> Helper loaded: form_helper
INFO - 2021-02-27 02:19:56 --> Helper loaded: my_helper
INFO - 2021-02-27 02:19:56 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:19:56 --> Controller Class Initialized
DEBUG - 2021-02-27 02:19:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:19:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:19:56 --> Final output sent to browser
DEBUG - 2021-02-27 02:19:56 --> Total execution time: 0.2198
INFO - 2021-02-27 02:20:17 --> Config Class Initialized
INFO - 2021-02-27 02:20:17 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:17 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:17 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:17 --> URI Class Initialized
INFO - 2021-02-27 02:20:17 --> Router Class Initialized
INFO - 2021-02-27 02:20:17 --> Output Class Initialized
INFO - 2021-02-27 02:20:17 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:17 --> Input Class Initialized
INFO - 2021-02-27 02:20:17 --> Language Class Initialized
INFO - 2021-02-27 02:20:17 --> Language Class Initialized
INFO - 2021-02-27 02:20:17 --> Config Class Initialized
INFO - 2021-02-27 02:20:17 --> Loader Class Initialized
INFO - 2021-02-27 02:20:17 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:17 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:17 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:17 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:17 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:17 --> Controller Class Initialized
INFO - 2021-02-27 02:20:17 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:20:17 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:17 --> Total execution time: 0.2758
INFO - 2021-02-27 02:20:20 --> Config Class Initialized
INFO - 2021-02-27 02:20:20 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:20 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:20 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:20 --> URI Class Initialized
INFO - 2021-02-27 02:20:20 --> Router Class Initialized
INFO - 2021-02-27 02:20:20 --> Output Class Initialized
INFO - 2021-02-27 02:20:20 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:20 --> Input Class Initialized
INFO - 2021-02-27 02:20:20 --> Language Class Initialized
INFO - 2021-02-27 02:20:20 --> Language Class Initialized
INFO - 2021-02-27 02:20:20 --> Config Class Initialized
INFO - 2021-02-27 02:20:20 --> Loader Class Initialized
INFO - 2021-02-27 02:20:20 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:20 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:20 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:20 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:20 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:20 --> Controller Class Initialized
DEBUG - 2021-02-27 02:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 02:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:20:20 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:20 --> Total execution time: 0.3455
INFO - 2021-02-27 02:20:22 --> Config Class Initialized
INFO - 2021-02-27 02:20:22 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:22 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:22 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:22 --> URI Class Initialized
INFO - 2021-02-27 02:20:22 --> Router Class Initialized
INFO - 2021-02-27 02:20:22 --> Output Class Initialized
INFO - 2021-02-27 02:20:22 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:22 --> Input Class Initialized
INFO - 2021-02-27 02:20:22 --> Language Class Initialized
INFO - 2021-02-27 02:20:22 --> Language Class Initialized
INFO - 2021-02-27 02:20:22 --> Config Class Initialized
INFO - 2021-02-27 02:20:22 --> Loader Class Initialized
INFO - 2021-02-27 02:20:22 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:22 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:22 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:22 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:22 --> Controller Class Initialized
INFO - 2021-02-27 02:20:22 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:20:22 --> Config Class Initialized
INFO - 2021-02-27 02:20:22 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:22 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:22 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:22 --> URI Class Initialized
INFO - 2021-02-27 02:20:22 --> Router Class Initialized
INFO - 2021-02-27 02:20:22 --> Output Class Initialized
INFO - 2021-02-27 02:20:22 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:22 --> Input Class Initialized
INFO - 2021-02-27 02:20:22 --> Language Class Initialized
INFO - 2021-02-27 02:20:22 --> Language Class Initialized
INFO - 2021-02-27 02:20:22 --> Config Class Initialized
INFO - 2021-02-27 02:20:22 --> Loader Class Initialized
INFO - 2021-02-27 02:20:22 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:22 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:22 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:22 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:22 --> Controller Class Initialized
DEBUG - 2021-02-27 02:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:20:22 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:22 --> Total execution time: 0.2129
INFO - 2021-02-27 02:20:27 --> Config Class Initialized
INFO - 2021-02-27 02:20:27 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:27 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:27 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:27 --> URI Class Initialized
INFO - 2021-02-27 02:20:27 --> Router Class Initialized
INFO - 2021-02-27 02:20:27 --> Output Class Initialized
INFO - 2021-02-27 02:20:27 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:27 --> Input Class Initialized
INFO - 2021-02-27 02:20:27 --> Language Class Initialized
INFO - 2021-02-27 02:20:27 --> Language Class Initialized
INFO - 2021-02-27 02:20:27 --> Config Class Initialized
INFO - 2021-02-27 02:20:27 --> Loader Class Initialized
INFO - 2021-02-27 02:20:27 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:27 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:27 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:27 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:27 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:27 --> Controller Class Initialized
INFO - 2021-02-27 02:20:27 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:27 --> Total execution time: 0.2404
INFO - 2021-02-27 02:20:33 --> Config Class Initialized
INFO - 2021-02-27 02:20:33 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:33 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:33 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:33 --> URI Class Initialized
INFO - 2021-02-27 02:20:33 --> Router Class Initialized
INFO - 2021-02-27 02:20:33 --> Output Class Initialized
INFO - 2021-02-27 02:20:33 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:33 --> Input Class Initialized
INFO - 2021-02-27 02:20:33 --> Language Class Initialized
INFO - 2021-02-27 02:20:33 --> Language Class Initialized
INFO - 2021-02-27 02:20:33 --> Config Class Initialized
INFO - 2021-02-27 02:20:33 --> Loader Class Initialized
INFO - 2021-02-27 02:20:33 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:33 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:33 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:33 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:33 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:33 --> Controller Class Initialized
INFO - 2021-02-27 02:20:33 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:20:33 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:33 --> Total execution time: 0.2606
INFO - 2021-02-27 02:20:34 --> Config Class Initialized
INFO - 2021-02-27 02:20:34 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:34 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:34 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:34 --> URI Class Initialized
INFO - 2021-02-27 02:20:34 --> Router Class Initialized
INFO - 2021-02-27 02:20:34 --> Output Class Initialized
INFO - 2021-02-27 02:20:34 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:34 --> Input Class Initialized
INFO - 2021-02-27 02:20:34 --> Language Class Initialized
INFO - 2021-02-27 02:20:34 --> Language Class Initialized
INFO - 2021-02-27 02:20:34 --> Config Class Initialized
INFO - 2021-02-27 02:20:34 --> Loader Class Initialized
INFO - 2021-02-27 02:20:34 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:34 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:34 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:34 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:34 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:34 --> Controller Class Initialized
DEBUG - 2021-02-27 02:20:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 02:20:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:20:34 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:34 --> Total execution time: 0.3483
INFO - 2021-02-27 02:20:37 --> Config Class Initialized
INFO - 2021-02-27 02:20:37 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:37 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:37 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:37 --> URI Class Initialized
INFO - 2021-02-27 02:20:37 --> Router Class Initialized
INFO - 2021-02-27 02:20:37 --> Output Class Initialized
INFO - 2021-02-27 02:20:37 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:37 --> Input Class Initialized
INFO - 2021-02-27 02:20:37 --> Language Class Initialized
INFO - 2021-02-27 02:20:37 --> Language Class Initialized
INFO - 2021-02-27 02:20:37 --> Config Class Initialized
INFO - 2021-02-27 02:20:37 --> Loader Class Initialized
INFO - 2021-02-27 02:20:37 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:37 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:37 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:37 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:37 --> Controller Class Initialized
INFO - 2021-02-27 02:20:37 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:20:37 --> Config Class Initialized
INFO - 2021-02-27 02:20:37 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:38 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:38 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:38 --> URI Class Initialized
INFO - 2021-02-27 02:20:38 --> Router Class Initialized
INFO - 2021-02-27 02:20:38 --> Output Class Initialized
INFO - 2021-02-27 02:20:38 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:38 --> Input Class Initialized
INFO - 2021-02-27 02:20:38 --> Language Class Initialized
INFO - 2021-02-27 02:20:38 --> Language Class Initialized
INFO - 2021-02-27 02:20:38 --> Config Class Initialized
INFO - 2021-02-27 02:20:38 --> Loader Class Initialized
INFO - 2021-02-27 02:20:38 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:38 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:38 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:38 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:38 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:38 --> Controller Class Initialized
DEBUG - 2021-02-27 02:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:20:38 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:38 --> Total execution time: 0.2487
INFO - 2021-02-27 02:20:45 --> Config Class Initialized
INFO - 2021-02-27 02:20:45 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:45 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:45 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:45 --> URI Class Initialized
INFO - 2021-02-27 02:20:45 --> Router Class Initialized
INFO - 2021-02-27 02:20:45 --> Output Class Initialized
INFO - 2021-02-27 02:20:45 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:45 --> Input Class Initialized
INFO - 2021-02-27 02:20:45 --> Language Class Initialized
INFO - 2021-02-27 02:20:45 --> Language Class Initialized
INFO - 2021-02-27 02:20:45 --> Config Class Initialized
INFO - 2021-02-27 02:20:45 --> Loader Class Initialized
INFO - 2021-02-27 02:20:45 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:45 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:45 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:45 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:45 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:45 --> Controller Class Initialized
INFO - 2021-02-27 02:20:45 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:20:45 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:45 --> Total execution time: 0.2650
INFO - 2021-02-27 02:20:51 --> Config Class Initialized
INFO - 2021-02-27 02:20:51 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:51 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:51 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:51 --> URI Class Initialized
INFO - 2021-02-27 02:20:51 --> Router Class Initialized
INFO - 2021-02-27 02:20:51 --> Output Class Initialized
INFO - 2021-02-27 02:20:51 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:51 --> Input Class Initialized
INFO - 2021-02-27 02:20:51 --> Language Class Initialized
INFO - 2021-02-27 02:20:51 --> Language Class Initialized
INFO - 2021-02-27 02:20:51 --> Config Class Initialized
INFO - 2021-02-27 02:20:51 --> Loader Class Initialized
INFO - 2021-02-27 02:20:51 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:51 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:51 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:51 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:51 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:51 --> Controller Class Initialized
DEBUG - 2021-02-27 02:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 02:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:20:51 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:51 --> Total execution time: 0.3477
INFO - 2021-02-27 02:20:54 --> Config Class Initialized
INFO - 2021-02-27 02:20:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:54 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:54 --> URI Class Initialized
INFO - 2021-02-27 02:20:54 --> Router Class Initialized
INFO - 2021-02-27 02:20:54 --> Output Class Initialized
INFO - 2021-02-27 02:20:54 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:54 --> Input Class Initialized
INFO - 2021-02-27 02:20:54 --> Language Class Initialized
INFO - 2021-02-27 02:20:54 --> Language Class Initialized
INFO - 2021-02-27 02:20:54 --> Config Class Initialized
INFO - 2021-02-27 02:20:54 --> Loader Class Initialized
INFO - 2021-02-27 02:20:54 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:54 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:54 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:54 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:54 --> Controller Class Initialized
DEBUG - 2021-02-27 02:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-02-27 02:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:20:54 --> Final output sent to browser
DEBUG - 2021-02-27 02:20:54 --> Total execution time: 0.2648
INFO - 2021-02-27 02:20:54 --> Config Class Initialized
INFO - 2021-02-27 02:20:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:20:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:20:55 --> Utf8 Class Initialized
INFO - 2021-02-27 02:20:55 --> URI Class Initialized
INFO - 2021-02-27 02:20:55 --> Router Class Initialized
INFO - 2021-02-27 02:20:55 --> Output Class Initialized
INFO - 2021-02-27 02:20:55 --> Security Class Initialized
DEBUG - 2021-02-27 02:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:20:55 --> Input Class Initialized
INFO - 2021-02-27 02:20:55 --> Language Class Initialized
INFO - 2021-02-27 02:20:55 --> Language Class Initialized
INFO - 2021-02-27 02:20:55 --> Config Class Initialized
INFO - 2021-02-27 02:20:55 --> Loader Class Initialized
INFO - 2021-02-27 02:20:55 --> Helper loaded: url_helper
INFO - 2021-02-27 02:20:55 --> Helper loaded: file_helper
INFO - 2021-02-27 02:20:55 --> Helper loaded: form_helper
INFO - 2021-02-27 02:20:55 --> Helper loaded: my_helper
INFO - 2021-02-27 02:20:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:20:55 --> Controller Class Initialized
INFO - 2021-02-27 02:21:00 --> Config Class Initialized
INFO - 2021-02-27 02:21:00 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:21:00 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:21:00 --> Utf8 Class Initialized
INFO - 2021-02-27 02:21:00 --> URI Class Initialized
INFO - 2021-02-27 02:21:00 --> Router Class Initialized
INFO - 2021-02-27 02:21:00 --> Output Class Initialized
INFO - 2021-02-27 02:21:00 --> Security Class Initialized
DEBUG - 2021-02-27 02:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:21:00 --> Input Class Initialized
INFO - 2021-02-27 02:21:00 --> Language Class Initialized
INFO - 2021-02-27 02:21:00 --> Language Class Initialized
INFO - 2021-02-27 02:21:00 --> Config Class Initialized
INFO - 2021-02-27 02:21:00 --> Loader Class Initialized
INFO - 2021-02-27 02:21:00 --> Helper loaded: url_helper
INFO - 2021-02-27 02:21:00 --> Helper loaded: file_helper
INFO - 2021-02-27 02:21:00 --> Helper loaded: form_helper
INFO - 2021-02-27 02:21:00 --> Helper loaded: my_helper
INFO - 2021-02-27 02:21:00 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:21:00 --> Controller Class Initialized
INFO - 2021-02-27 02:21:00 --> Final output sent to browser
DEBUG - 2021-02-27 02:21:00 --> Total execution time: 0.2270
INFO - 2021-02-27 02:21:50 --> Config Class Initialized
INFO - 2021-02-27 02:21:50 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:21:50 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:21:50 --> Utf8 Class Initialized
INFO - 2021-02-27 02:21:50 --> URI Class Initialized
INFO - 2021-02-27 02:21:50 --> Router Class Initialized
INFO - 2021-02-27 02:21:50 --> Output Class Initialized
INFO - 2021-02-27 02:21:50 --> Security Class Initialized
DEBUG - 2021-02-27 02:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:21:50 --> Input Class Initialized
INFO - 2021-02-27 02:21:50 --> Language Class Initialized
INFO - 2021-02-27 02:21:50 --> Language Class Initialized
INFO - 2021-02-27 02:21:50 --> Config Class Initialized
INFO - 2021-02-27 02:21:50 --> Loader Class Initialized
INFO - 2021-02-27 02:21:50 --> Helper loaded: url_helper
INFO - 2021-02-27 02:21:50 --> Helper loaded: file_helper
INFO - 2021-02-27 02:21:50 --> Helper loaded: form_helper
INFO - 2021-02-27 02:21:50 --> Helper loaded: my_helper
INFO - 2021-02-27 02:21:50 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:21:50 --> Controller Class Initialized
INFO - 2021-02-27 02:21:50 --> Final output sent to browser
DEBUG - 2021-02-27 02:21:50 --> Total execution time: 0.2664
INFO - 2021-02-27 02:22:01 --> Config Class Initialized
INFO - 2021-02-27 02:22:01 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:22:01 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:22:01 --> Utf8 Class Initialized
INFO - 2021-02-27 02:22:01 --> URI Class Initialized
INFO - 2021-02-27 02:22:01 --> Router Class Initialized
INFO - 2021-02-27 02:22:01 --> Output Class Initialized
INFO - 2021-02-27 02:22:01 --> Security Class Initialized
DEBUG - 2021-02-27 02:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:22:01 --> Input Class Initialized
INFO - 2021-02-27 02:22:01 --> Language Class Initialized
INFO - 2021-02-27 02:22:01 --> Language Class Initialized
INFO - 2021-02-27 02:22:01 --> Config Class Initialized
INFO - 2021-02-27 02:22:01 --> Loader Class Initialized
INFO - 2021-02-27 02:22:01 --> Helper loaded: url_helper
INFO - 2021-02-27 02:22:01 --> Helper loaded: file_helper
INFO - 2021-02-27 02:22:01 --> Helper loaded: form_helper
INFO - 2021-02-27 02:22:01 --> Helper loaded: my_helper
INFO - 2021-02-27 02:22:01 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:22:01 --> Controller Class Initialized
DEBUG - 2021-02-27 02:22:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-02-27 02:22:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:22:01 --> Final output sent to browser
DEBUG - 2021-02-27 02:22:01 --> Total execution time: 0.2492
INFO - 2021-02-27 02:22:01 --> Config Class Initialized
INFO - 2021-02-27 02:22:01 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:22:01 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:22:01 --> Utf8 Class Initialized
INFO - 2021-02-27 02:22:01 --> URI Class Initialized
INFO - 2021-02-27 02:22:01 --> Router Class Initialized
INFO - 2021-02-27 02:22:01 --> Output Class Initialized
INFO - 2021-02-27 02:22:01 --> Security Class Initialized
DEBUG - 2021-02-27 02:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:22:01 --> Input Class Initialized
INFO - 2021-02-27 02:22:01 --> Language Class Initialized
INFO - 2021-02-27 02:22:01 --> Language Class Initialized
INFO - 2021-02-27 02:22:01 --> Config Class Initialized
INFO - 2021-02-27 02:22:01 --> Loader Class Initialized
INFO - 2021-02-27 02:22:01 --> Helper loaded: url_helper
INFO - 2021-02-27 02:22:01 --> Helper loaded: file_helper
INFO - 2021-02-27 02:22:01 --> Helper loaded: form_helper
INFO - 2021-02-27 02:22:01 --> Helper loaded: my_helper
INFO - 2021-02-27 02:22:01 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:22:01 --> Controller Class Initialized
INFO - 2021-02-27 02:23:38 --> Config Class Initialized
INFO - 2021-02-27 02:23:38 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:23:38 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:23:38 --> Utf8 Class Initialized
INFO - 2021-02-27 02:23:38 --> URI Class Initialized
DEBUG - 2021-02-27 02:23:38 --> No URI present. Default controller set.
INFO - 2021-02-27 02:23:38 --> Router Class Initialized
INFO - 2021-02-27 02:23:38 --> Output Class Initialized
INFO - 2021-02-27 02:23:38 --> Security Class Initialized
DEBUG - 2021-02-27 02:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:23:38 --> Input Class Initialized
INFO - 2021-02-27 02:23:38 --> Language Class Initialized
INFO - 2021-02-27 02:23:38 --> Language Class Initialized
INFO - 2021-02-27 02:23:38 --> Config Class Initialized
INFO - 2021-02-27 02:23:38 --> Loader Class Initialized
INFO - 2021-02-27 02:23:38 --> Helper loaded: url_helper
INFO - 2021-02-27 02:23:38 --> Helper loaded: file_helper
INFO - 2021-02-27 02:23:38 --> Helper loaded: form_helper
INFO - 2021-02-27 02:23:38 --> Helper loaded: my_helper
INFO - 2021-02-27 02:23:38 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:23:38 --> Controller Class Initialized
INFO - 2021-02-27 02:23:38 --> Config Class Initialized
INFO - 2021-02-27 02:23:38 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:23:38 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:23:38 --> Utf8 Class Initialized
INFO - 2021-02-27 02:23:38 --> URI Class Initialized
INFO - 2021-02-27 02:23:38 --> Router Class Initialized
INFO - 2021-02-27 02:23:38 --> Output Class Initialized
INFO - 2021-02-27 02:23:38 --> Security Class Initialized
DEBUG - 2021-02-27 02:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:23:38 --> Input Class Initialized
INFO - 2021-02-27 02:23:38 --> Language Class Initialized
INFO - 2021-02-27 02:23:38 --> Language Class Initialized
INFO - 2021-02-27 02:23:38 --> Config Class Initialized
INFO - 2021-02-27 02:23:38 --> Loader Class Initialized
INFO - 2021-02-27 02:23:38 --> Helper loaded: url_helper
INFO - 2021-02-27 02:23:38 --> Helper loaded: file_helper
INFO - 2021-02-27 02:23:38 --> Helper loaded: form_helper
INFO - 2021-02-27 02:23:38 --> Helper loaded: my_helper
INFO - 2021-02-27 02:23:38 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:23:38 --> Controller Class Initialized
DEBUG - 2021-02-27 02:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:23:38 --> Final output sent to browser
DEBUG - 2021-02-27 02:23:38 --> Total execution time: 0.2528
INFO - 2021-02-27 02:23:44 --> Config Class Initialized
INFO - 2021-02-27 02:23:44 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:23:44 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:23:44 --> Utf8 Class Initialized
INFO - 2021-02-27 02:23:44 --> URI Class Initialized
INFO - 2021-02-27 02:23:44 --> Router Class Initialized
INFO - 2021-02-27 02:23:44 --> Output Class Initialized
INFO - 2021-02-27 02:23:44 --> Security Class Initialized
DEBUG - 2021-02-27 02:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:23:44 --> Input Class Initialized
INFO - 2021-02-27 02:23:44 --> Language Class Initialized
INFO - 2021-02-27 02:23:44 --> Language Class Initialized
INFO - 2021-02-27 02:23:44 --> Config Class Initialized
INFO - 2021-02-27 02:23:44 --> Loader Class Initialized
INFO - 2021-02-27 02:23:44 --> Helper loaded: url_helper
INFO - 2021-02-27 02:23:44 --> Helper loaded: file_helper
INFO - 2021-02-27 02:23:44 --> Helper loaded: form_helper
INFO - 2021-02-27 02:23:44 --> Helper loaded: my_helper
INFO - 2021-02-27 02:23:44 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:23:44 --> Controller Class Initialized
INFO - 2021-02-27 02:23:44 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:23:44 --> Final output sent to browser
DEBUG - 2021-02-27 02:23:44 --> Total execution time: 0.2682
INFO - 2021-02-27 02:23:45 --> Config Class Initialized
INFO - 2021-02-27 02:23:45 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:23:45 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:23:45 --> Utf8 Class Initialized
INFO - 2021-02-27 02:23:45 --> URI Class Initialized
INFO - 2021-02-27 02:23:45 --> Router Class Initialized
INFO - 2021-02-27 02:23:45 --> Output Class Initialized
INFO - 2021-02-27 02:23:45 --> Security Class Initialized
DEBUG - 2021-02-27 02:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:23:45 --> Input Class Initialized
INFO - 2021-02-27 02:23:45 --> Language Class Initialized
INFO - 2021-02-27 02:23:45 --> Language Class Initialized
INFO - 2021-02-27 02:23:45 --> Config Class Initialized
INFO - 2021-02-27 02:23:45 --> Loader Class Initialized
INFO - 2021-02-27 02:23:45 --> Helper loaded: url_helper
INFO - 2021-02-27 02:23:45 --> Helper loaded: file_helper
INFO - 2021-02-27 02:23:45 --> Helper loaded: form_helper
INFO - 2021-02-27 02:23:45 --> Helper loaded: my_helper
INFO - 2021-02-27 02:23:45 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:23:45 --> Controller Class Initialized
DEBUG - 2021-02-27 02:23:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 02:23:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:23:45 --> Final output sent to browser
DEBUG - 2021-02-27 02:23:45 --> Total execution time: 0.3208
INFO - 2021-02-27 02:23:57 --> Config Class Initialized
INFO - 2021-02-27 02:23:57 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:23:57 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:23:57 --> Utf8 Class Initialized
INFO - 2021-02-27 02:23:57 --> URI Class Initialized
INFO - 2021-02-27 02:23:57 --> Router Class Initialized
INFO - 2021-02-27 02:23:57 --> Output Class Initialized
INFO - 2021-02-27 02:23:57 --> Security Class Initialized
DEBUG - 2021-02-27 02:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:23:57 --> Input Class Initialized
INFO - 2021-02-27 02:23:57 --> Language Class Initialized
INFO - 2021-02-27 02:23:57 --> Language Class Initialized
INFO - 2021-02-27 02:23:57 --> Config Class Initialized
INFO - 2021-02-27 02:23:57 --> Loader Class Initialized
INFO - 2021-02-27 02:23:57 --> Helper loaded: url_helper
INFO - 2021-02-27 02:23:57 --> Helper loaded: file_helper
INFO - 2021-02-27 02:23:57 --> Helper loaded: form_helper
INFO - 2021-02-27 02:23:57 --> Helper loaded: my_helper
INFO - 2021-02-27 02:23:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:23:57 --> Controller Class Initialized
DEBUG - 2021-02-27 02:23:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-02-27 02:23:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:23:57 --> Final output sent to browser
DEBUG - 2021-02-27 02:23:57 --> Total execution time: 0.2172
INFO - 2021-02-27 02:23:57 --> Config Class Initialized
INFO - 2021-02-27 02:23:57 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:23:57 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:23:57 --> Utf8 Class Initialized
INFO - 2021-02-27 02:23:57 --> URI Class Initialized
INFO - 2021-02-27 02:23:57 --> Router Class Initialized
INFO - 2021-02-27 02:23:57 --> Output Class Initialized
INFO - 2021-02-27 02:23:57 --> Security Class Initialized
DEBUG - 2021-02-27 02:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:23:57 --> Input Class Initialized
INFO - 2021-02-27 02:23:57 --> Language Class Initialized
INFO - 2021-02-27 02:23:57 --> Language Class Initialized
INFO - 2021-02-27 02:23:57 --> Config Class Initialized
INFO - 2021-02-27 02:23:57 --> Loader Class Initialized
INFO - 2021-02-27 02:23:57 --> Helper loaded: url_helper
INFO - 2021-02-27 02:23:57 --> Helper loaded: file_helper
INFO - 2021-02-27 02:23:57 --> Helper loaded: form_helper
INFO - 2021-02-27 02:23:57 --> Helper loaded: my_helper
INFO - 2021-02-27 02:23:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:23:57 --> Controller Class Initialized
INFO - 2021-02-27 02:24:18 --> Config Class Initialized
INFO - 2021-02-27 02:24:18 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:24:18 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:24:18 --> Utf8 Class Initialized
INFO - 2021-02-27 02:24:18 --> URI Class Initialized
INFO - 2021-02-27 02:24:18 --> Router Class Initialized
INFO - 2021-02-27 02:24:18 --> Output Class Initialized
INFO - 2021-02-27 02:24:18 --> Security Class Initialized
DEBUG - 2021-02-27 02:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:24:18 --> Input Class Initialized
INFO - 2021-02-27 02:24:18 --> Language Class Initialized
INFO - 2021-02-27 02:24:18 --> Language Class Initialized
INFO - 2021-02-27 02:24:18 --> Config Class Initialized
INFO - 2021-02-27 02:24:18 --> Loader Class Initialized
INFO - 2021-02-27 02:24:18 --> Helper loaded: url_helper
INFO - 2021-02-27 02:24:18 --> Helper loaded: file_helper
INFO - 2021-02-27 02:24:18 --> Helper loaded: form_helper
INFO - 2021-02-27 02:24:18 --> Helper loaded: my_helper
INFO - 2021-02-27 02:24:18 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:24:18 --> Controller Class Initialized
DEBUG - 2021-02-27 02:24:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-02-27 02:24:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:24:18 --> Final output sent to browser
DEBUG - 2021-02-27 02:24:18 --> Total execution time: 0.2362
INFO - 2021-02-27 02:24:18 --> Config Class Initialized
INFO - 2021-02-27 02:24:18 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:24:18 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:24:18 --> Utf8 Class Initialized
INFO - 2021-02-27 02:24:18 --> URI Class Initialized
INFO - 2021-02-27 02:24:18 --> Router Class Initialized
INFO - 2021-02-27 02:24:18 --> Output Class Initialized
INFO - 2021-02-27 02:24:18 --> Security Class Initialized
DEBUG - 2021-02-27 02:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:24:18 --> Input Class Initialized
INFO - 2021-02-27 02:24:18 --> Language Class Initialized
INFO - 2021-02-27 02:24:18 --> Language Class Initialized
INFO - 2021-02-27 02:24:18 --> Config Class Initialized
INFO - 2021-02-27 02:24:18 --> Loader Class Initialized
INFO - 2021-02-27 02:24:18 --> Helper loaded: url_helper
INFO - 2021-02-27 02:24:18 --> Helper loaded: file_helper
INFO - 2021-02-27 02:24:18 --> Helper loaded: form_helper
INFO - 2021-02-27 02:24:18 --> Helper loaded: my_helper
INFO - 2021-02-27 02:24:18 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:24:18 --> Controller Class Initialized
INFO - 2021-02-27 02:24:20 --> Config Class Initialized
INFO - 2021-02-27 02:24:20 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:24:20 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:24:20 --> Utf8 Class Initialized
INFO - 2021-02-27 02:24:20 --> URI Class Initialized
INFO - 2021-02-27 02:24:20 --> Router Class Initialized
INFO - 2021-02-27 02:24:20 --> Output Class Initialized
INFO - 2021-02-27 02:24:20 --> Security Class Initialized
DEBUG - 2021-02-27 02:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:24:20 --> Input Class Initialized
INFO - 2021-02-27 02:24:20 --> Language Class Initialized
INFO - 2021-02-27 02:24:20 --> Language Class Initialized
INFO - 2021-02-27 02:24:20 --> Config Class Initialized
INFO - 2021-02-27 02:24:20 --> Loader Class Initialized
INFO - 2021-02-27 02:24:20 --> Helper loaded: url_helper
INFO - 2021-02-27 02:24:20 --> Helper loaded: file_helper
INFO - 2021-02-27 02:24:20 --> Helper loaded: form_helper
INFO - 2021-02-27 02:24:20 --> Helper loaded: my_helper
INFO - 2021-02-27 02:24:21 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:24:21 --> Controller Class Initialized
INFO - 2021-02-27 02:24:21 --> Final output sent to browser
DEBUG - 2021-02-27 02:24:21 --> Total execution time: 0.2609
INFO - 2021-02-27 02:24:31 --> Config Class Initialized
INFO - 2021-02-27 02:24:31 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:24:31 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:24:31 --> Utf8 Class Initialized
INFO - 2021-02-27 02:24:31 --> URI Class Initialized
INFO - 2021-02-27 02:24:31 --> Router Class Initialized
INFO - 2021-02-27 02:24:31 --> Output Class Initialized
INFO - 2021-02-27 02:24:31 --> Security Class Initialized
DEBUG - 2021-02-27 02:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:24:31 --> Input Class Initialized
INFO - 2021-02-27 02:24:31 --> Language Class Initialized
INFO - 2021-02-27 02:24:31 --> Language Class Initialized
INFO - 2021-02-27 02:24:31 --> Config Class Initialized
INFO - 2021-02-27 02:24:31 --> Loader Class Initialized
INFO - 2021-02-27 02:24:31 --> Helper loaded: url_helper
INFO - 2021-02-27 02:24:31 --> Helper loaded: file_helper
INFO - 2021-02-27 02:24:31 --> Helper loaded: form_helper
INFO - 2021-02-27 02:24:31 --> Helper loaded: my_helper
INFO - 2021-02-27 02:24:31 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:24:31 --> Controller Class Initialized
INFO - 2021-02-27 02:24:37 --> Config Class Initialized
INFO - 2021-02-27 02:24:37 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:24:37 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:24:37 --> Utf8 Class Initialized
INFO - 2021-02-27 02:24:37 --> URI Class Initialized
INFO - 2021-02-27 02:24:37 --> Router Class Initialized
INFO - 2021-02-27 02:24:37 --> Output Class Initialized
INFO - 2021-02-27 02:24:37 --> Security Class Initialized
DEBUG - 2021-02-27 02:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:24:37 --> Input Class Initialized
INFO - 2021-02-27 02:24:37 --> Language Class Initialized
INFO - 2021-02-27 02:24:37 --> Language Class Initialized
INFO - 2021-02-27 02:24:37 --> Config Class Initialized
INFO - 2021-02-27 02:24:37 --> Loader Class Initialized
INFO - 2021-02-27 02:24:37 --> Helper loaded: url_helper
INFO - 2021-02-27 02:24:37 --> Helper loaded: file_helper
INFO - 2021-02-27 02:24:37 --> Helper loaded: form_helper
INFO - 2021-02-27 02:24:37 --> Helper loaded: my_helper
INFO - 2021-02-27 02:24:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:24:37 --> Controller Class Initialized
DEBUG - 2021-02-27 02:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2021-02-27 02:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:24:37 --> Final output sent to browser
DEBUG - 2021-02-27 02:24:37 --> Total execution time: 0.2383
INFO - 2021-02-27 02:24:37 --> Config Class Initialized
INFO - 2021-02-27 02:24:37 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:24:37 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:24:37 --> Utf8 Class Initialized
INFO - 2021-02-27 02:24:37 --> URI Class Initialized
INFO - 2021-02-27 02:24:37 --> Router Class Initialized
INFO - 2021-02-27 02:24:37 --> Output Class Initialized
INFO - 2021-02-27 02:24:37 --> Security Class Initialized
DEBUG - 2021-02-27 02:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:24:37 --> Input Class Initialized
INFO - 2021-02-27 02:24:37 --> Language Class Initialized
INFO - 2021-02-27 02:24:37 --> Language Class Initialized
INFO - 2021-02-27 02:24:37 --> Config Class Initialized
INFO - 2021-02-27 02:24:37 --> Loader Class Initialized
INFO - 2021-02-27 02:24:37 --> Helper loaded: url_helper
INFO - 2021-02-27 02:24:37 --> Helper loaded: file_helper
INFO - 2021-02-27 02:24:37 --> Helper loaded: form_helper
INFO - 2021-02-27 02:24:37 --> Helper loaded: my_helper
INFO - 2021-02-27 02:24:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:24:37 --> Controller Class Initialized
INFO - 2021-02-27 02:24:55 --> Config Class Initialized
INFO - 2021-02-27 02:24:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:24:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:24:55 --> Utf8 Class Initialized
INFO - 2021-02-27 02:24:55 --> URI Class Initialized
INFO - 2021-02-27 02:24:55 --> Router Class Initialized
INFO - 2021-02-27 02:24:55 --> Output Class Initialized
INFO - 2021-02-27 02:24:55 --> Security Class Initialized
DEBUG - 2021-02-27 02:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:24:55 --> Input Class Initialized
INFO - 2021-02-27 02:24:55 --> Language Class Initialized
INFO - 2021-02-27 02:24:55 --> Language Class Initialized
INFO - 2021-02-27 02:24:55 --> Config Class Initialized
INFO - 2021-02-27 02:24:55 --> Loader Class Initialized
INFO - 2021-02-27 02:24:55 --> Helper loaded: url_helper
INFO - 2021-02-27 02:24:55 --> Helper loaded: file_helper
INFO - 2021-02-27 02:24:55 --> Helper loaded: form_helper
INFO - 2021-02-27 02:24:55 --> Helper loaded: my_helper
INFO - 2021-02-27 02:24:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:24:55 --> Controller Class Initialized
INFO - 2021-02-27 02:25:50 --> Config Class Initialized
INFO - 2021-02-27 02:25:50 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:25:50 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:25:50 --> Utf8 Class Initialized
INFO - 2021-02-27 02:25:50 --> URI Class Initialized
INFO - 2021-02-27 02:25:50 --> Router Class Initialized
INFO - 2021-02-27 02:25:50 --> Output Class Initialized
INFO - 2021-02-27 02:25:50 --> Security Class Initialized
DEBUG - 2021-02-27 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:25:51 --> Input Class Initialized
INFO - 2021-02-27 02:25:51 --> Language Class Initialized
INFO - 2021-02-27 02:25:51 --> Language Class Initialized
INFO - 2021-02-27 02:25:51 --> Config Class Initialized
INFO - 2021-02-27 02:25:51 --> Loader Class Initialized
INFO - 2021-02-27 02:25:51 --> Helper loaded: url_helper
INFO - 2021-02-27 02:25:51 --> Helper loaded: file_helper
INFO - 2021-02-27 02:25:51 --> Helper loaded: form_helper
INFO - 2021-02-27 02:25:51 --> Helper loaded: my_helper
INFO - 2021-02-27 02:25:51 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:25:51 --> Controller Class Initialized
DEBUG - 2021-02-27 02:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2021-02-27 02:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:25:51 --> Final output sent to browser
DEBUG - 2021-02-27 02:25:51 --> Total execution time: 0.2413
INFO - 2021-02-27 02:25:51 --> Config Class Initialized
INFO - 2021-02-27 02:25:51 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:25:51 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:25:51 --> Utf8 Class Initialized
INFO - 2021-02-27 02:25:51 --> URI Class Initialized
INFO - 2021-02-27 02:25:51 --> Router Class Initialized
INFO - 2021-02-27 02:25:51 --> Output Class Initialized
INFO - 2021-02-27 02:25:51 --> Security Class Initialized
DEBUG - 2021-02-27 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:25:51 --> Input Class Initialized
INFO - 2021-02-27 02:25:51 --> Language Class Initialized
INFO - 2021-02-27 02:25:51 --> Language Class Initialized
INFO - 2021-02-27 02:25:51 --> Config Class Initialized
INFO - 2021-02-27 02:25:51 --> Loader Class Initialized
INFO - 2021-02-27 02:25:51 --> Helper loaded: url_helper
INFO - 2021-02-27 02:25:51 --> Helper loaded: file_helper
INFO - 2021-02-27 02:25:51 --> Helper loaded: form_helper
INFO - 2021-02-27 02:25:51 --> Helper loaded: my_helper
INFO - 2021-02-27 02:25:51 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:25:51 --> Controller Class Initialized
INFO - 2021-02-27 02:25:53 --> Config Class Initialized
INFO - 2021-02-27 02:25:53 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:25:53 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:25:53 --> Utf8 Class Initialized
INFO - 2021-02-27 02:25:53 --> URI Class Initialized
INFO - 2021-02-27 02:25:53 --> Router Class Initialized
INFO - 2021-02-27 02:25:53 --> Output Class Initialized
INFO - 2021-02-27 02:25:53 --> Security Class Initialized
DEBUG - 2021-02-27 02:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:25:53 --> Input Class Initialized
INFO - 2021-02-27 02:25:53 --> Language Class Initialized
INFO - 2021-02-27 02:25:53 --> Language Class Initialized
INFO - 2021-02-27 02:25:53 --> Config Class Initialized
INFO - 2021-02-27 02:25:53 --> Loader Class Initialized
INFO - 2021-02-27 02:25:53 --> Helper loaded: url_helper
INFO - 2021-02-27 02:25:53 --> Helper loaded: file_helper
INFO - 2021-02-27 02:25:53 --> Helper loaded: form_helper
INFO - 2021-02-27 02:25:53 --> Helper loaded: my_helper
INFO - 2021-02-27 02:25:53 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:25:53 --> Controller Class Initialized
INFO - 2021-02-27 02:25:53 --> Final output sent to browser
DEBUG - 2021-02-27 02:25:53 --> Total execution time: 0.2232
INFO - 2021-02-27 02:26:51 --> Config Class Initialized
INFO - 2021-02-27 02:26:51 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:26:51 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:26:51 --> Utf8 Class Initialized
INFO - 2021-02-27 02:26:51 --> URI Class Initialized
INFO - 2021-02-27 02:26:51 --> Router Class Initialized
INFO - 2021-02-27 02:26:51 --> Output Class Initialized
INFO - 2021-02-27 02:26:51 --> Security Class Initialized
DEBUG - 2021-02-27 02:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:26:51 --> Input Class Initialized
INFO - 2021-02-27 02:26:51 --> Language Class Initialized
INFO - 2021-02-27 02:26:51 --> Language Class Initialized
INFO - 2021-02-27 02:26:51 --> Config Class Initialized
INFO - 2021-02-27 02:26:51 --> Loader Class Initialized
INFO - 2021-02-27 02:26:51 --> Helper loaded: url_helper
INFO - 2021-02-27 02:26:51 --> Helper loaded: file_helper
INFO - 2021-02-27 02:26:51 --> Helper loaded: form_helper
INFO - 2021-02-27 02:26:51 --> Helper loaded: my_helper
INFO - 2021-02-27 02:26:51 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:26:51 --> Controller Class Initialized
INFO - 2021-02-27 02:26:51 --> Final output sent to browser
DEBUG - 2021-02-27 02:26:51 --> Total execution time: 0.2616
INFO - 2021-02-27 02:26:56 --> Config Class Initialized
INFO - 2021-02-27 02:26:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:26:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:26:56 --> Utf8 Class Initialized
INFO - 2021-02-27 02:26:56 --> URI Class Initialized
INFO - 2021-02-27 02:26:56 --> Router Class Initialized
INFO - 2021-02-27 02:26:56 --> Output Class Initialized
INFO - 2021-02-27 02:26:56 --> Security Class Initialized
DEBUG - 2021-02-27 02:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:26:56 --> Input Class Initialized
INFO - 2021-02-27 02:26:56 --> Language Class Initialized
INFO - 2021-02-27 02:26:56 --> Language Class Initialized
INFO - 2021-02-27 02:26:56 --> Config Class Initialized
INFO - 2021-02-27 02:26:56 --> Loader Class Initialized
INFO - 2021-02-27 02:26:56 --> Helper loaded: url_helper
INFO - 2021-02-27 02:26:56 --> Helper loaded: file_helper
INFO - 2021-02-27 02:26:56 --> Helper loaded: form_helper
INFO - 2021-02-27 02:26:56 --> Helper loaded: my_helper
INFO - 2021-02-27 02:26:56 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:26:56 --> Controller Class Initialized
DEBUG - 2021-02-27 02:26:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-27 02:26:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:26:56 --> Final output sent to browser
DEBUG - 2021-02-27 02:26:56 --> Total execution time: 0.2688
INFO - 2021-02-27 02:26:56 --> Config Class Initialized
INFO - 2021-02-27 02:26:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:26:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:26:56 --> Utf8 Class Initialized
INFO - 2021-02-27 02:26:56 --> URI Class Initialized
INFO - 2021-02-27 02:26:56 --> Router Class Initialized
INFO - 2021-02-27 02:26:56 --> Output Class Initialized
INFO - 2021-02-27 02:26:56 --> Security Class Initialized
DEBUG - 2021-02-27 02:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:26:56 --> Input Class Initialized
INFO - 2021-02-27 02:26:56 --> Language Class Initialized
INFO - 2021-02-27 02:26:56 --> Language Class Initialized
INFO - 2021-02-27 02:26:56 --> Config Class Initialized
INFO - 2021-02-27 02:26:56 --> Loader Class Initialized
INFO - 2021-02-27 02:26:56 --> Helper loaded: url_helper
INFO - 2021-02-27 02:26:56 --> Helper loaded: file_helper
INFO - 2021-02-27 02:26:56 --> Helper loaded: form_helper
INFO - 2021-02-27 02:26:56 --> Helper loaded: my_helper
INFO - 2021-02-27 02:26:56 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:26:56 --> Controller Class Initialized
INFO - 2021-02-27 02:27:04 --> Config Class Initialized
INFO - 2021-02-27 02:27:04 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:27:04 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:27:04 --> Utf8 Class Initialized
INFO - 2021-02-27 02:27:04 --> URI Class Initialized
INFO - 2021-02-27 02:27:04 --> Router Class Initialized
INFO - 2021-02-27 02:27:04 --> Output Class Initialized
INFO - 2021-02-27 02:27:04 --> Security Class Initialized
DEBUG - 2021-02-27 02:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:27:04 --> Input Class Initialized
INFO - 2021-02-27 02:27:04 --> Language Class Initialized
INFO - 2021-02-27 02:27:04 --> Language Class Initialized
INFO - 2021-02-27 02:27:04 --> Config Class Initialized
INFO - 2021-02-27 02:27:04 --> Loader Class Initialized
INFO - 2021-02-27 02:27:04 --> Helper loaded: url_helper
INFO - 2021-02-27 02:27:04 --> Helper loaded: file_helper
INFO - 2021-02-27 02:27:04 --> Helper loaded: form_helper
INFO - 2021-02-27 02:27:04 --> Helper loaded: my_helper
INFO - 2021-02-27 02:27:04 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:27:05 --> Controller Class Initialized
INFO - 2021-02-27 02:27:05 --> Final output sent to browser
DEBUG - 2021-02-27 02:27:05 --> Total execution time: 0.2896
INFO - 2021-02-27 02:28:27 --> Config Class Initialized
INFO - 2021-02-27 02:28:27 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:28:27 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:28:27 --> Utf8 Class Initialized
INFO - 2021-02-27 02:28:27 --> URI Class Initialized
INFO - 2021-02-27 02:28:27 --> Router Class Initialized
INFO - 2021-02-27 02:28:27 --> Output Class Initialized
INFO - 2021-02-27 02:28:27 --> Security Class Initialized
DEBUG - 2021-02-27 02:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:28:27 --> Input Class Initialized
INFO - 2021-02-27 02:28:27 --> Language Class Initialized
INFO - 2021-02-27 02:28:27 --> Language Class Initialized
INFO - 2021-02-27 02:28:27 --> Config Class Initialized
INFO - 2021-02-27 02:28:27 --> Loader Class Initialized
INFO - 2021-02-27 02:28:27 --> Helper loaded: url_helper
INFO - 2021-02-27 02:28:27 --> Helper loaded: file_helper
INFO - 2021-02-27 02:28:27 --> Helper loaded: form_helper
INFO - 2021-02-27 02:28:27 --> Helper loaded: my_helper
INFO - 2021-02-27 02:28:27 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:28:27 --> Controller Class Initialized
DEBUG - 2021-02-27 02:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:28:27 --> Final output sent to browser
DEBUG - 2021-02-27 02:28:27 --> Total execution time: 0.2649
INFO - 2021-02-27 02:28:36 --> Config Class Initialized
INFO - 2021-02-27 02:28:36 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:28:36 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:28:36 --> Utf8 Class Initialized
INFO - 2021-02-27 02:28:36 --> URI Class Initialized
INFO - 2021-02-27 02:28:36 --> Router Class Initialized
INFO - 2021-02-27 02:28:36 --> Output Class Initialized
INFO - 2021-02-27 02:28:36 --> Security Class Initialized
DEBUG - 2021-02-27 02:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:28:36 --> Input Class Initialized
INFO - 2021-02-27 02:28:36 --> Language Class Initialized
INFO - 2021-02-27 02:28:36 --> Language Class Initialized
INFO - 2021-02-27 02:28:36 --> Config Class Initialized
INFO - 2021-02-27 02:28:36 --> Loader Class Initialized
INFO - 2021-02-27 02:28:36 --> Helper loaded: url_helper
INFO - 2021-02-27 02:28:36 --> Helper loaded: file_helper
INFO - 2021-02-27 02:28:36 --> Helper loaded: form_helper
INFO - 2021-02-27 02:28:36 --> Helper loaded: my_helper
INFO - 2021-02-27 02:28:36 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:28:36 --> Controller Class Initialized
DEBUG - 2021-02-27 02:28:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-02-27 02:28:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:28:36 --> Final output sent to browser
DEBUG - 2021-02-27 02:28:36 --> Total execution time: 0.2889
INFO - 2021-02-27 02:28:38 --> Config Class Initialized
INFO - 2021-02-27 02:28:38 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:28:38 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:28:38 --> Utf8 Class Initialized
INFO - 2021-02-27 02:28:38 --> URI Class Initialized
INFO - 2021-02-27 02:28:38 --> Router Class Initialized
INFO - 2021-02-27 02:28:38 --> Output Class Initialized
INFO - 2021-02-27 02:28:38 --> Security Class Initialized
DEBUG - 2021-02-27 02:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:28:38 --> Input Class Initialized
INFO - 2021-02-27 02:28:38 --> Language Class Initialized
INFO - 2021-02-27 02:28:38 --> Language Class Initialized
INFO - 2021-02-27 02:28:38 --> Config Class Initialized
INFO - 2021-02-27 02:28:38 --> Loader Class Initialized
INFO - 2021-02-27 02:28:38 --> Helper loaded: url_helper
INFO - 2021-02-27 02:28:38 --> Helper loaded: file_helper
INFO - 2021-02-27 02:28:38 --> Helper loaded: form_helper
INFO - 2021-02-27 02:28:38 --> Helper loaded: my_helper
INFO - 2021-02-27 02:28:38 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:28:38 --> Controller Class Initialized
DEBUG - 2021-02-27 02:28:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:28:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:28:38 --> Final output sent to browser
DEBUG - 2021-02-27 02:28:38 --> Total execution time: 0.3059
INFO - 2021-02-27 02:29:14 --> Config Class Initialized
INFO - 2021-02-27 02:29:14 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:29:14 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:29:14 --> Utf8 Class Initialized
INFO - 2021-02-27 02:29:14 --> URI Class Initialized
INFO - 2021-02-27 02:29:14 --> Router Class Initialized
INFO - 2021-02-27 02:29:14 --> Output Class Initialized
INFO - 2021-02-27 02:29:14 --> Security Class Initialized
DEBUG - 2021-02-27 02:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:29:14 --> Input Class Initialized
INFO - 2021-02-27 02:29:14 --> Language Class Initialized
INFO - 2021-02-27 02:29:14 --> Language Class Initialized
INFO - 2021-02-27 02:29:14 --> Config Class Initialized
INFO - 2021-02-27 02:29:14 --> Loader Class Initialized
INFO - 2021-02-27 02:29:14 --> Helper loaded: url_helper
INFO - 2021-02-27 02:29:14 --> Helper loaded: file_helper
INFO - 2021-02-27 02:29:14 --> Helper loaded: form_helper
INFO - 2021-02-27 02:29:14 --> Helper loaded: my_helper
INFO - 2021-02-27 02:29:14 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:29:14 --> Controller Class Initialized
ERROR - 2021-02-27 02:29:14 --> Query error: Table 'db_nilai.t_nilai_sikap_so' doesn't exist - Invalid query: DELETE FROM t_nilai_sikap_so WHERE id_siswa = '471' AND tasm = '20201'
INFO - 2021-02-27 02:29:14 --> Language file loaded: language/english/db_lang.php
INFO - 2021-02-27 02:29:17 --> Config Class Initialized
INFO - 2021-02-27 02:29:17 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:29:17 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:29:17 --> Utf8 Class Initialized
INFO - 2021-02-27 02:29:17 --> URI Class Initialized
INFO - 2021-02-27 02:29:17 --> Router Class Initialized
INFO - 2021-02-27 02:29:17 --> Output Class Initialized
INFO - 2021-02-27 02:29:17 --> Security Class Initialized
DEBUG - 2021-02-27 02:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:29:17 --> Input Class Initialized
INFO - 2021-02-27 02:29:17 --> Language Class Initialized
INFO - 2021-02-27 02:29:17 --> Language Class Initialized
INFO - 2021-02-27 02:29:17 --> Config Class Initialized
INFO - 2021-02-27 02:29:17 --> Loader Class Initialized
INFO - 2021-02-27 02:29:17 --> Helper loaded: url_helper
INFO - 2021-02-27 02:29:17 --> Helper loaded: file_helper
INFO - 2021-02-27 02:29:17 --> Helper loaded: form_helper
INFO - 2021-02-27 02:29:17 --> Helper loaded: my_helper
INFO - 2021-02-27 02:29:17 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:29:17 --> Controller Class Initialized
ERROR - 2021-02-27 02:29:17 --> Query error: Table 'db_nilai.t_nilai_sikap_so' doesn't exist - Invalid query: DELETE FROM t_nilai_sikap_so WHERE id_siswa = '471' AND tasm = '20201'
INFO - 2021-02-27 02:29:17 --> Language file loaded: language/english/db_lang.php
INFO - 2021-02-27 02:29:19 --> Config Class Initialized
INFO - 2021-02-27 02:29:19 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:29:19 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:29:19 --> Utf8 Class Initialized
INFO - 2021-02-27 02:29:19 --> URI Class Initialized
INFO - 2021-02-27 02:29:19 --> Router Class Initialized
INFO - 2021-02-27 02:29:19 --> Output Class Initialized
INFO - 2021-02-27 02:29:19 --> Security Class Initialized
DEBUG - 2021-02-27 02:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:29:19 --> Input Class Initialized
INFO - 2021-02-27 02:29:19 --> Language Class Initialized
INFO - 2021-02-27 02:29:19 --> Language Class Initialized
INFO - 2021-02-27 02:29:19 --> Config Class Initialized
INFO - 2021-02-27 02:29:19 --> Loader Class Initialized
INFO - 2021-02-27 02:29:19 --> Helper loaded: url_helper
INFO - 2021-02-27 02:29:19 --> Helper loaded: file_helper
INFO - 2021-02-27 02:29:19 --> Helper loaded: form_helper
INFO - 2021-02-27 02:29:19 --> Helper loaded: my_helper
INFO - 2021-02-27 02:29:19 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:29:19 --> Controller Class Initialized
ERROR - 2021-02-27 02:29:19 --> Query error: Table 'db_nilai.t_nilai_sikap_so' doesn't exist - Invalid query: DELETE FROM t_nilai_sikap_so WHERE id_siswa = '472' AND tasm = '20201'
INFO - 2021-02-27 02:29:19 --> Language file loaded: language/english/db_lang.php
INFO - 2021-02-27 02:29:23 --> Config Class Initialized
INFO - 2021-02-27 02:29:23 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:29:23 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:29:23 --> Utf8 Class Initialized
INFO - 2021-02-27 02:29:23 --> URI Class Initialized
INFO - 2021-02-27 02:29:23 --> Router Class Initialized
INFO - 2021-02-27 02:29:23 --> Output Class Initialized
INFO - 2021-02-27 02:29:23 --> Security Class Initialized
DEBUG - 2021-02-27 02:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:29:23 --> Input Class Initialized
INFO - 2021-02-27 02:29:23 --> Language Class Initialized
INFO - 2021-02-27 02:29:23 --> Language Class Initialized
INFO - 2021-02-27 02:29:23 --> Config Class Initialized
INFO - 2021-02-27 02:29:23 --> Loader Class Initialized
INFO - 2021-02-27 02:29:23 --> Helper loaded: url_helper
INFO - 2021-02-27 02:29:23 --> Helper loaded: file_helper
INFO - 2021-02-27 02:29:23 --> Helper loaded: form_helper
INFO - 2021-02-27 02:29:23 --> Helper loaded: my_helper
INFO - 2021-02-27 02:29:23 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:29:23 --> Controller Class Initialized
ERROR - 2021-02-27 02:29:23 --> Query error: Table 'db_nilai.t_nilai_sikap_so' doesn't exist - Invalid query: DELETE FROM t_nilai_sikap_so WHERE id_siswa = '477' AND tasm = '20201'
INFO - 2021-02-27 02:29:23 --> Language file loaded: language/english/db_lang.php
INFO - 2021-02-27 02:29:28 --> Config Class Initialized
INFO - 2021-02-27 02:29:28 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:29:28 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:29:28 --> Utf8 Class Initialized
INFO - 2021-02-27 02:29:28 --> URI Class Initialized
INFO - 2021-02-27 02:29:28 --> Router Class Initialized
INFO - 2021-02-27 02:29:28 --> Output Class Initialized
INFO - 2021-02-27 02:29:28 --> Security Class Initialized
DEBUG - 2021-02-27 02:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:29:28 --> Input Class Initialized
INFO - 2021-02-27 02:29:28 --> Language Class Initialized
INFO - 2021-02-27 02:29:28 --> Language Class Initialized
INFO - 2021-02-27 02:29:28 --> Config Class Initialized
INFO - 2021-02-27 02:29:28 --> Loader Class Initialized
INFO - 2021-02-27 02:29:28 --> Helper loaded: url_helper
INFO - 2021-02-27 02:29:28 --> Helper loaded: file_helper
INFO - 2021-02-27 02:29:28 --> Helper loaded: form_helper
INFO - 2021-02-27 02:29:28 --> Helper loaded: my_helper
INFO - 2021-02-27 02:29:28 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:29:28 --> Controller Class Initialized
DEBUG - 2021-02-27 02:29:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-02-27 02:29:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:29:28 --> Final output sent to browser
DEBUG - 2021-02-27 02:29:28 --> Total execution time: 0.2726
INFO - 2021-02-27 02:29:28 --> Config Class Initialized
INFO - 2021-02-27 02:29:28 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:29:28 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:29:28 --> Utf8 Class Initialized
INFO - 2021-02-27 02:29:28 --> URI Class Initialized
INFO - 2021-02-27 02:29:28 --> Router Class Initialized
INFO - 2021-02-27 02:29:28 --> Output Class Initialized
INFO - 2021-02-27 02:29:28 --> Security Class Initialized
DEBUG - 2021-02-27 02:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:29:28 --> Input Class Initialized
INFO - 2021-02-27 02:29:28 --> Language Class Initialized
INFO - 2021-02-27 02:29:28 --> Language Class Initialized
INFO - 2021-02-27 02:29:28 --> Config Class Initialized
INFO - 2021-02-27 02:29:28 --> Loader Class Initialized
INFO - 2021-02-27 02:29:28 --> Helper loaded: url_helper
INFO - 2021-02-27 02:29:28 --> Helper loaded: file_helper
INFO - 2021-02-27 02:29:28 --> Helper loaded: form_helper
INFO - 2021-02-27 02:29:28 --> Helper loaded: my_helper
INFO - 2021-02-27 02:29:28 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:29:28 --> Controller Class Initialized
INFO - 2021-02-27 02:29:29 --> Config Class Initialized
INFO - 2021-02-27 02:29:29 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:29:29 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:29:29 --> Utf8 Class Initialized
INFO - 2021-02-27 02:29:29 --> URI Class Initialized
INFO - 2021-02-27 02:29:29 --> Router Class Initialized
INFO - 2021-02-27 02:29:29 --> Output Class Initialized
INFO - 2021-02-27 02:29:29 --> Security Class Initialized
DEBUG - 2021-02-27 02:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:29:29 --> Input Class Initialized
INFO - 2021-02-27 02:29:29 --> Language Class Initialized
INFO - 2021-02-27 02:29:29 --> Language Class Initialized
INFO - 2021-02-27 02:29:29 --> Config Class Initialized
INFO - 2021-02-27 02:29:29 --> Loader Class Initialized
INFO - 2021-02-27 02:29:29 --> Helper loaded: url_helper
INFO - 2021-02-27 02:29:29 --> Helper loaded: file_helper
INFO - 2021-02-27 02:29:29 --> Helper loaded: form_helper
INFO - 2021-02-27 02:29:29 --> Helper loaded: my_helper
INFO - 2021-02-27 02:29:29 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:29:30 --> Controller Class Initialized
ERROR - 2021-02-27 02:29:30 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-02-27 02:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-02-27 02:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:29:30 --> Final output sent to browser
DEBUG - 2021-02-27 02:29:30 --> Total execution time: 0.3417
INFO - 2021-02-27 02:30:46 --> Config Class Initialized
INFO - 2021-02-27 02:30:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:30:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:30:46 --> Utf8 Class Initialized
INFO - 2021-02-27 02:30:46 --> URI Class Initialized
INFO - 2021-02-27 02:30:46 --> Router Class Initialized
INFO - 2021-02-27 02:30:46 --> Output Class Initialized
INFO - 2021-02-27 02:30:46 --> Security Class Initialized
DEBUG - 2021-02-27 02:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:30:46 --> Input Class Initialized
INFO - 2021-02-27 02:30:46 --> Language Class Initialized
INFO - 2021-02-27 02:30:46 --> Language Class Initialized
INFO - 2021-02-27 02:30:46 --> Config Class Initialized
INFO - 2021-02-27 02:30:46 --> Loader Class Initialized
INFO - 2021-02-27 02:30:46 --> Helper loaded: url_helper
INFO - 2021-02-27 02:30:46 --> Helper loaded: file_helper
INFO - 2021-02-27 02:30:46 --> Helper loaded: form_helper
INFO - 2021-02-27 02:30:46 --> Helper loaded: my_helper
INFO - 2021-02-27 02:30:46 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:30:46 --> Controller Class Initialized
INFO - 2021-02-27 02:30:46 --> Upload Class Initialized
INFO - 2021-02-27 02:30:46 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-02-27 02:30:46 --> The upload path does not appear to be valid.
INFO - 2021-02-27 02:30:46 --> Config Class Initialized
INFO - 2021-02-27 02:30:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:30:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:30:46 --> Utf8 Class Initialized
INFO - 2021-02-27 02:30:46 --> URI Class Initialized
INFO - 2021-02-27 02:30:46 --> Router Class Initialized
INFO - 2021-02-27 02:30:46 --> Output Class Initialized
INFO - 2021-02-27 02:30:46 --> Security Class Initialized
DEBUG - 2021-02-27 02:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:30:46 --> Input Class Initialized
INFO - 2021-02-27 02:30:46 --> Language Class Initialized
INFO - 2021-02-27 02:30:46 --> Language Class Initialized
INFO - 2021-02-27 02:30:46 --> Config Class Initialized
INFO - 2021-02-27 02:30:46 --> Loader Class Initialized
INFO - 2021-02-27 02:30:47 --> Helper loaded: url_helper
INFO - 2021-02-27 02:30:47 --> Helper loaded: file_helper
INFO - 2021-02-27 02:30:47 --> Helper loaded: form_helper
INFO - 2021-02-27 02:30:47 --> Helper loaded: my_helper
INFO - 2021-02-27 02:30:47 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:30:47 --> Controller Class Initialized
DEBUG - 2021-02-27 02:30:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-02-27 02:30:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:30:47 --> Final output sent to browser
DEBUG - 2021-02-27 02:30:47 --> Total execution time: 0.2333
INFO - 2021-02-27 02:30:47 --> Config Class Initialized
INFO - 2021-02-27 02:30:47 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:30:47 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:30:47 --> Utf8 Class Initialized
INFO - 2021-02-27 02:30:47 --> URI Class Initialized
INFO - 2021-02-27 02:30:47 --> Router Class Initialized
INFO - 2021-02-27 02:30:47 --> Output Class Initialized
INFO - 2021-02-27 02:30:47 --> Security Class Initialized
DEBUG - 2021-02-27 02:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:30:47 --> Input Class Initialized
INFO - 2021-02-27 02:30:47 --> Language Class Initialized
INFO - 2021-02-27 02:30:47 --> Language Class Initialized
INFO - 2021-02-27 02:30:47 --> Config Class Initialized
INFO - 2021-02-27 02:30:47 --> Loader Class Initialized
INFO - 2021-02-27 02:30:47 --> Helper loaded: url_helper
INFO - 2021-02-27 02:30:47 --> Helper loaded: file_helper
INFO - 2021-02-27 02:30:47 --> Helper loaded: form_helper
INFO - 2021-02-27 02:30:47 --> Helper loaded: my_helper
INFO - 2021-02-27 02:30:47 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:30:47 --> Controller Class Initialized
INFO - 2021-02-27 02:30:54 --> Config Class Initialized
INFO - 2021-02-27 02:30:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:30:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:30:54 --> Utf8 Class Initialized
INFO - 2021-02-27 02:30:54 --> URI Class Initialized
INFO - 2021-02-27 02:30:54 --> Router Class Initialized
INFO - 2021-02-27 02:30:54 --> Output Class Initialized
INFO - 2021-02-27 02:30:54 --> Security Class Initialized
DEBUG - 2021-02-27 02:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:30:54 --> Input Class Initialized
INFO - 2021-02-27 02:30:54 --> Language Class Initialized
INFO - 2021-02-27 02:30:54 --> Language Class Initialized
INFO - 2021-02-27 02:30:54 --> Config Class Initialized
INFO - 2021-02-27 02:30:54 --> Loader Class Initialized
INFO - 2021-02-27 02:30:54 --> Helper loaded: url_helper
INFO - 2021-02-27 02:30:54 --> Helper loaded: file_helper
INFO - 2021-02-27 02:30:54 --> Helper loaded: form_helper
INFO - 2021-02-27 02:30:54 --> Helper loaded: my_helper
INFO - 2021-02-27 02:30:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:30:54 --> Controller Class Initialized
INFO - 2021-02-27 02:30:54 --> Config Class Initialized
INFO - 2021-02-27 02:30:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:30:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:30:54 --> Utf8 Class Initialized
INFO - 2021-02-27 02:30:54 --> URI Class Initialized
INFO - 2021-02-27 02:30:54 --> Router Class Initialized
INFO - 2021-02-27 02:30:54 --> Output Class Initialized
INFO - 2021-02-27 02:30:54 --> Security Class Initialized
DEBUG - 2021-02-27 02:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:30:54 --> Input Class Initialized
INFO - 2021-02-27 02:30:54 --> Language Class Initialized
INFO - 2021-02-27 02:30:54 --> Language Class Initialized
INFO - 2021-02-27 02:30:54 --> Config Class Initialized
INFO - 2021-02-27 02:30:54 --> Loader Class Initialized
INFO - 2021-02-27 02:30:54 --> Helper loaded: url_helper
INFO - 2021-02-27 02:30:54 --> Helper loaded: file_helper
INFO - 2021-02-27 02:30:54 --> Helper loaded: form_helper
INFO - 2021-02-27 02:30:54 --> Helper loaded: my_helper
INFO - 2021-02-27 02:30:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:30:54 --> Controller Class Initialized
INFO - 2021-02-27 02:30:54 --> Config Class Initialized
INFO - 2021-02-27 02:30:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:30:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:30:54 --> Utf8 Class Initialized
INFO - 2021-02-27 02:30:55 --> URI Class Initialized
INFO - 2021-02-27 02:30:55 --> Router Class Initialized
INFO - 2021-02-27 02:30:55 --> Output Class Initialized
INFO - 2021-02-27 02:30:55 --> Security Class Initialized
DEBUG - 2021-02-27 02:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:30:55 --> Input Class Initialized
INFO - 2021-02-27 02:30:55 --> Language Class Initialized
INFO - 2021-02-27 02:30:55 --> Language Class Initialized
INFO - 2021-02-27 02:30:55 --> Config Class Initialized
INFO - 2021-02-27 02:30:55 --> Loader Class Initialized
INFO - 2021-02-27 02:30:55 --> Helper loaded: url_helper
INFO - 2021-02-27 02:30:55 --> Helper loaded: file_helper
INFO - 2021-02-27 02:30:55 --> Helper loaded: form_helper
INFO - 2021-02-27 02:30:55 --> Helper loaded: my_helper
INFO - 2021-02-27 02:30:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:30:55 --> Controller Class Initialized
INFO - 2021-02-27 02:31:05 --> Config Class Initialized
INFO - 2021-02-27 02:31:05 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:31:05 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:31:05 --> Utf8 Class Initialized
INFO - 2021-02-27 02:31:05 --> URI Class Initialized
INFO - 2021-02-27 02:31:05 --> Router Class Initialized
INFO - 2021-02-27 02:31:05 --> Output Class Initialized
INFO - 2021-02-27 02:31:05 --> Security Class Initialized
DEBUG - 2021-02-27 02:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:31:05 --> Input Class Initialized
INFO - 2021-02-27 02:31:05 --> Language Class Initialized
INFO - 2021-02-27 02:31:05 --> Language Class Initialized
INFO - 2021-02-27 02:31:05 --> Config Class Initialized
INFO - 2021-02-27 02:31:05 --> Loader Class Initialized
INFO - 2021-02-27 02:31:05 --> Helper loaded: url_helper
INFO - 2021-02-27 02:31:05 --> Helper loaded: file_helper
INFO - 2021-02-27 02:31:05 --> Helper loaded: form_helper
INFO - 2021-02-27 02:31:05 --> Helper loaded: my_helper
INFO - 2021-02-27 02:31:05 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:31:05 --> Controller Class Initialized
DEBUG - 2021-02-27 02:31:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:31:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:31:05 --> Final output sent to browser
DEBUG - 2021-02-27 02:31:05 --> Total execution time: 0.3080
INFO - 2021-02-27 02:31:06 --> Config Class Initialized
INFO - 2021-02-27 02:31:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:31:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:31:06 --> Utf8 Class Initialized
INFO - 2021-02-27 02:31:06 --> URI Class Initialized
INFO - 2021-02-27 02:31:07 --> Router Class Initialized
INFO - 2021-02-27 02:31:07 --> Output Class Initialized
INFO - 2021-02-27 02:31:07 --> Security Class Initialized
DEBUG - 2021-02-27 02:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:31:07 --> Input Class Initialized
INFO - 2021-02-27 02:31:07 --> Language Class Initialized
INFO - 2021-02-27 02:31:07 --> Language Class Initialized
INFO - 2021-02-27 02:31:07 --> Config Class Initialized
INFO - 2021-02-27 02:31:07 --> Loader Class Initialized
INFO - 2021-02-27 02:31:07 --> Helper loaded: url_helper
INFO - 2021-02-27 02:31:07 --> Helper loaded: file_helper
INFO - 2021-02-27 02:31:07 --> Helper loaded: form_helper
INFO - 2021-02-27 02:31:07 --> Helper loaded: my_helper
INFO - 2021-02-27 02:31:07 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:31:07 --> Controller Class Initialized
DEBUG - 2021-02-27 02:31:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-02-27 02:31:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:31:07 --> Final output sent to browser
DEBUG - 2021-02-27 02:31:07 --> Total execution time: 0.2762
INFO - 2021-02-27 02:31:30 --> Config Class Initialized
INFO - 2021-02-27 02:31:30 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:31:30 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:31:30 --> Utf8 Class Initialized
INFO - 2021-02-27 02:31:30 --> URI Class Initialized
INFO - 2021-02-27 02:31:30 --> Router Class Initialized
INFO - 2021-02-27 02:31:30 --> Output Class Initialized
INFO - 2021-02-27 02:31:30 --> Security Class Initialized
DEBUG - 2021-02-27 02:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:31:30 --> Input Class Initialized
INFO - 2021-02-27 02:31:30 --> Language Class Initialized
INFO - 2021-02-27 02:31:30 --> Language Class Initialized
INFO - 2021-02-27 02:31:30 --> Config Class Initialized
INFO - 2021-02-27 02:31:30 --> Loader Class Initialized
INFO - 2021-02-27 02:31:30 --> Helper loaded: url_helper
INFO - 2021-02-27 02:31:30 --> Helper loaded: file_helper
INFO - 2021-02-27 02:31:30 --> Helper loaded: form_helper
INFO - 2021-02-27 02:31:30 --> Helper loaded: my_helper
INFO - 2021-02-27 02:31:30 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:31:30 --> Controller Class Initialized
INFO - 2021-02-27 02:31:30 --> Config Class Initialized
INFO - 2021-02-27 02:31:30 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:31:30 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:31:30 --> Utf8 Class Initialized
INFO - 2021-02-27 02:31:30 --> URI Class Initialized
INFO - 2021-02-27 02:31:30 --> Router Class Initialized
INFO - 2021-02-27 02:31:30 --> Output Class Initialized
INFO - 2021-02-27 02:31:30 --> Security Class Initialized
DEBUG - 2021-02-27 02:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:31:30 --> Input Class Initialized
INFO - 2021-02-27 02:31:30 --> Language Class Initialized
INFO - 2021-02-27 02:31:30 --> Language Class Initialized
INFO - 2021-02-27 02:31:30 --> Config Class Initialized
INFO - 2021-02-27 02:31:30 --> Loader Class Initialized
INFO - 2021-02-27 02:31:30 --> Helper loaded: url_helper
INFO - 2021-02-27 02:31:30 --> Helper loaded: file_helper
INFO - 2021-02-27 02:31:30 --> Helper loaded: form_helper
INFO - 2021-02-27 02:31:30 --> Helper loaded: my_helper
INFO - 2021-02-27 02:31:30 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:31:30 --> Controller Class Initialized
DEBUG - 2021-02-27 02:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:31:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:31:30 --> Final output sent to browser
DEBUG - 2021-02-27 02:31:30 --> Total execution time: 0.2742
INFO - 2021-02-27 02:31:36 --> Config Class Initialized
INFO - 2021-02-27 02:31:36 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:31:36 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:31:36 --> Utf8 Class Initialized
INFO - 2021-02-27 02:31:36 --> URI Class Initialized
INFO - 2021-02-27 02:31:36 --> Router Class Initialized
INFO - 2021-02-27 02:31:37 --> Output Class Initialized
INFO - 2021-02-27 02:31:37 --> Security Class Initialized
DEBUG - 2021-02-27 02:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:31:37 --> Input Class Initialized
INFO - 2021-02-27 02:31:37 --> Language Class Initialized
INFO - 2021-02-27 02:31:37 --> Language Class Initialized
INFO - 2021-02-27 02:31:37 --> Config Class Initialized
INFO - 2021-02-27 02:31:37 --> Loader Class Initialized
INFO - 2021-02-27 02:31:37 --> Helper loaded: url_helper
INFO - 2021-02-27 02:31:37 --> Helper loaded: file_helper
INFO - 2021-02-27 02:31:37 --> Helper loaded: form_helper
INFO - 2021-02-27 02:31:37 --> Helper loaded: my_helper
INFO - 2021-02-27 02:31:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:31:37 --> Controller Class Initialized
DEBUG - 2021-02-27 02:31:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:31:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:31:37 --> Final output sent to browser
DEBUG - 2021-02-27 02:31:37 --> Total execution time: 0.2778
INFO - 2021-02-27 02:31:44 --> Config Class Initialized
INFO - 2021-02-27 02:31:45 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:31:45 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:31:45 --> Utf8 Class Initialized
INFO - 2021-02-27 02:31:45 --> URI Class Initialized
INFO - 2021-02-27 02:31:45 --> Router Class Initialized
INFO - 2021-02-27 02:31:45 --> Output Class Initialized
INFO - 2021-02-27 02:31:45 --> Security Class Initialized
DEBUG - 2021-02-27 02:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:31:45 --> Input Class Initialized
INFO - 2021-02-27 02:31:45 --> Language Class Initialized
INFO - 2021-02-27 02:31:45 --> Language Class Initialized
INFO - 2021-02-27 02:31:45 --> Config Class Initialized
INFO - 2021-02-27 02:31:45 --> Loader Class Initialized
INFO - 2021-02-27 02:31:45 --> Helper loaded: url_helper
INFO - 2021-02-27 02:31:45 --> Helper loaded: file_helper
INFO - 2021-02-27 02:31:45 --> Helper loaded: form_helper
INFO - 2021-02-27 02:31:45 --> Helper loaded: my_helper
INFO - 2021-02-27 02:31:45 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:31:45 --> Controller Class Initialized
DEBUG - 2021-02-27 02:31:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-02-27 02:31:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:31:45 --> Final output sent to browser
DEBUG - 2021-02-27 02:31:45 --> Total execution time: 0.2908
INFO - 2021-02-27 02:31:56 --> Config Class Initialized
INFO - 2021-02-27 02:31:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:31:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:31:56 --> Utf8 Class Initialized
INFO - 2021-02-27 02:31:57 --> URI Class Initialized
INFO - 2021-02-27 02:31:57 --> Router Class Initialized
INFO - 2021-02-27 02:31:57 --> Output Class Initialized
INFO - 2021-02-27 02:31:57 --> Security Class Initialized
DEBUG - 2021-02-27 02:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:31:57 --> Input Class Initialized
INFO - 2021-02-27 02:31:57 --> Language Class Initialized
INFO - 2021-02-27 02:31:57 --> Language Class Initialized
INFO - 2021-02-27 02:31:57 --> Config Class Initialized
INFO - 2021-02-27 02:31:57 --> Loader Class Initialized
INFO - 2021-02-27 02:31:57 --> Helper loaded: url_helper
INFO - 2021-02-27 02:31:57 --> Helper loaded: file_helper
INFO - 2021-02-27 02:31:57 --> Helper loaded: form_helper
INFO - 2021-02-27 02:31:57 --> Helper loaded: my_helper
INFO - 2021-02-27 02:31:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:31:57 --> Controller Class Initialized
INFO - 2021-02-27 02:31:57 --> Config Class Initialized
INFO - 2021-02-27 02:31:57 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:31:57 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:31:57 --> Utf8 Class Initialized
INFO - 2021-02-27 02:31:57 --> URI Class Initialized
INFO - 2021-02-27 02:31:57 --> Router Class Initialized
INFO - 2021-02-27 02:31:57 --> Output Class Initialized
INFO - 2021-02-27 02:31:57 --> Security Class Initialized
DEBUG - 2021-02-27 02:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:31:57 --> Input Class Initialized
INFO - 2021-02-27 02:31:57 --> Language Class Initialized
INFO - 2021-02-27 02:31:57 --> Language Class Initialized
INFO - 2021-02-27 02:31:57 --> Config Class Initialized
INFO - 2021-02-27 02:31:57 --> Loader Class Initialized
INFO - 2021-02-27 02:31:57 --> Helper loaded: url_helper
INFO - 2021-02-27 02:31:57 --> Helper loaded: file_helper
INFO - 2021-02-27 02:31:57 --> Helper loaded: form_helper
INFO - 2021-02-27 02:31:57 --> Helper loaded: my_helper
INFO - 2021-02-27 02:31:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:31:57 --> Controller Class Initialized
DEBUG - 2021-02-27 02:31:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:31:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:31:57 --> Final output sent to browser
DEBUG - 2021-02-27 02:31:57 --> Total execution time: 0.2807
INFO - 2021-02-27 02:32:04 --> Config Class Initialized
INFO - 2021-02-27 02:32:04 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:04 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:04 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:04 --> URI Class Initialized
INFO - 2021-02-27 02:32:04 --> Router Class Initialized
INFO - 2021-02-27 02:32:04 --> Output Class Initialized
INFO - 2021-02-27 02:32:04 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:04 --> Input Class Initialized
INFO - 2021-02-27 02:32:04 --> Language Class Initialized
INFO - 2021-02-27 02:32:04 --> Language Class Initialized
INFO - 2021-02-27 02:32:04 --> Config Class Initialized
INFO - 2021-02-27 02:32:04 --> Loader Class Initialized
INFO - 2021-02-27 02:32:04 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:04 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:04 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:04 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:04 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:04 --> Controller Class Initialized
INFO - 2021-02-27 02:32:04 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:32:04 --> Config Class Initialized
INFO - 2021-02-27 02:32:04 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:04 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:04 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:04 --> URI Class Initialized
INFO - 2021-02-27 02:32:04 --> Router Class Initialized
INFO - 2021-02-27 02:32:04 --> Output Class Initialized
INFO - 2021-02-27 02:32:04 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:04 --> Input Class Initialized
INFO - 2021-02-27 02:32:04 --> Language Class Initialized
INFO - 2021-02-27 02:32:04 --> Language Class Initialized
INFO - 2021-02-27 02:32:05 --> Config Class Initialized
INFO - 2021-02-27 02:32:05 --> Loader Class Initialized
INFO - 2021-02-27 02:32:05 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:05 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:05 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:05 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:05 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:05 --> Controller Class Initialized
DEBUG - 2021-02-27 02:32:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:32:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:32:05 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:05 --> Total execution time: 0.2511
INFO - 2021-02-27 02:32:12 --> Config Class Initialized
INFO - 2021-02-27 02:32:12 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:12 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:12 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:12 --> URI Class Initialized
INFO - 2021-02-27 02:32:12 --> Router Class Initialized
INFO - 2021-02-27 02:32:12 --> Output Class Initialized
INFO - 2021-02-27 02:32:12 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:12 --> Input Class Initialized
INFO - 2021-02-27 02:32:12 --> Language Class Initialized
INFO - 2021-02-27 02:32:12 --> Language Class Initialized
INFO - 2021-02-27 02:32:12 --> Config Class Initialized
INFO - 2021-02-27 02:32:12 --> Loader Class Initialized
INFO - 2021-02-27 02:32:12 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:12 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:12 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:12 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:12 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:12 --> Controller Class Initialized
INFO - 2021-02-27 02:32:12 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:32:12 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:12 --> Total execution time: 0.3130
INFO - 2021-02-27 02:32:12 --> Config Class Initialized
INFO - 2021-02-27 02:32:12 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:12 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:12 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:12 --> URI Class Initialized
INFO - 2021-02-27 02:32:12 --> Router Class Initialized
INFO - 2021-02-27 02:32:12 --> Output Class Initialized
INFO - 2021-02-27 02:32:12 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:12 --> Input Class Initialized
INFO - 2021-02-27 02:32:12 --> Language Class Initialized
INFO - 2021-02-27 02:32:12 --> Language Class Initialized
INFO - 2021-02-27 02:32:12 --> Config Class Initialized
INFO - 2021-02-27 02:32:13 --> Loader Class Initialized
INFO - 2021-02-27 02:32:13 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:13 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:13 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:13 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:13 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:13 --> Controller Class Initialized
DEBUG - 2021-02-27 02:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 02:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:32:13 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:13 --> Total execution time: 0.3526
INFO - 2021-02-27 02:32:15 --> Config Class Initialized
INFO - 2021-02-27 02:32:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:15 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:15 --> URI Class Initialized
INFO - 2021-02-27 02:32:15 --> Router Class Initialized
INFO - 2021-02-27 02:32:15 --> Output Class Initialized
INFO - 2021-02-27 02:32:15 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:15 --> Input Class Initialized
INFO - 2021-02-27 02:32:15 --> Language Class Initialized
INFO - 2021-02-27 02:32:15 --> Language Class Initialized
INFO - 2021-02-27 02:32:15 --> Config Class Initialized
INFO - 2021-02-27 02:32:15 --> Loader Class Initialized
INFO - 2021-02-27 02:32:15 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:15 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:15 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:15 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:15 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:15 --> Controller Class Initialized
DEBUG - 2021-02-27 02:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-27 02:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:32:15 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:15 --> Total execution time: 0.2941
INFO - 2021-02-27 02:32:15 --> Config Class Initialized
INFO - 2021-02-27 02:32:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:15 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:15 --> URI Class Initialized
INFO - 2021-02-27 02:32:15 --> Router Class Initialized
INFO - 2021-02-27 02:32:15 --> Output Class Initialized
INFO - 2021-02-27 02:32:15 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:15 --> Input Class Initialized
INFO - 2021-02-27 02:32:15 --> Language Class Initialized
INFO - 2021-02-27 02:32:15 --> Language Class Initialized
INFO - 2021-02-27 02:32:15 --> Config Class Initialized
INFO - 2021-02-27 02:32:15 --> Loader Class Initialized
INFO - 2021-02-27 02:32:15 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:15 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:15 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:15 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:15 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:15 --> Controller Class Initialized
INFO - 2021-02-27 02:32:15 --> Config Class Initialized
INFO - 2021-02-27 02:32:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:15 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:15 --> URI Class Initialized
INFO - 2021-02-27 02:32:15 --> Router Class Initialized
INFO - 2021-02-27 02:32:16 --> Output Class Initialized
INFO - 2021-02-27 02:32:16 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:16 --> Input Class Initialized
INFO - 2021-02-27 02:32:16 --> Language Class Initialized
INFO - 2021-02-27 02:32:16 --> Language Class Initialized
INFO - 2021-02-27 02:32:16 --> Config Class Initialized
INFO - 2021-02-27 02:32:16 --> Loader Class Initialized
INFO - 2021-02-27 02:32:16 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:16 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:16 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:16 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:16 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:16 --> Controller Class Initialized
DEBUG - 2021-02-27 02:32:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:32:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:32:16 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:16 --> Total execution time: 0.2739
INFO - 2021-02-27 02:32:22 --> Config Class Initialized
INFO - 2021-02-27 02:32:22 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:22 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:22 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:22 --> URI Class Initialized
INFO - 2021-02-27 02:32:22 --> Router Class Initialized
INFO - 2021-02-27 02:32:22 --> Output Class Initialized
INFO - 2021-02-27 02:32:22 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:22 --> Input Class Initialized
INFO - 2021-02-27 02:32:22 --> Language Class Initialized
INFO - 2021-02-27 02:32:22 --> Language Class Initialized
INFO - 2021-02-27 02:32:22 --> Config Class Initialized
INFO - 2021-02-27 02:32:22 --> Loader Class Initialized
INFO - 2021-02-27 02:32:22 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:22 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:22 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:22 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:22 --> Controller Class Initialized
DEBUG - 2021-02-27 02:32:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-02-27 02:32:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:32:22 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:22 --> Total execution time: 0.3002
INFO - 2021-02-27 02:32:30 --> Config Class Initialized
INFO - 2021-02-27 02:32:30 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:30 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:30 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:30 --> URI Class Initialized
INFO - 2021-02-27 02:32:30 --> Router Class Initialized
INFO - 2021-02-27 02:32:30 --> Output Class Initialized
INFO - 2021-02-27 02:32:30 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:30 --> Input Class Initialized
INFO - 2021-02-27 02:32:30 --> Language Class Initialized
INFO - 2021-02-27 02:32:30 --> Language Class Initialized
INFO - 2021-02-27 02:32:30 --> Config Class Initialized
INFO - 2021-02-27 02:32:30 --> Loader Class Initialized
INFO - 2021-02-27 02:32:30 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:30 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:30 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:30 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:30 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:30 --> Controller Class Initialized
INFO - 2021-02-27 02:32:30 --> Config Class Initialized
INFO - 2021-02-27 02:32:30 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:30 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:30 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:30 --> URI Class Initialized
INFO - 2021-02-27 02:32:30 --> Router Class Initialized
INFO - 2021-02-27 02:32:30 --> Output Class Initialized
INFO - 2021-02-27 02:32:30 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:30 --> Input Class Initialized
INFO - 2021-02-27 02:32:30 --> Language Class Initialized
INFO - 2021-02-27 02:32:30 --> Language Class Initialized
INFO - 2021-02-27 02:32:30 --> Config Class Initialized
INFO - 2021-02-27 02:32:30 --> Loader Class Initialized
INFO - 2021-02-27 02:32:30 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:30 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:30 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:30 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:30 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:30 --> Controller Class Initialized
DEBUG - 2021-02-27 02:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:32:30 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:30 --> Total execution time: 0.2869
INFO - 2021-02-27 02:32:46 --> Config Class Initialized
INFO - 2021-02-27 02:32:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:47 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:47 --> URI Class Initialized
INFO - 2021-02-27 02:32:47 --> Router Class Initialized
INFO - 2021-02-27 02:32:47 --> Output Class Initialized
INFO - 2021-02-27 02:32:47 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:47 --> Input Class Initialized
INFO - 2021-02-27 02:32:47 --> Language Class Initialized
INFO - 2021-02-27 02:32:47 --> Language Class Initialized
INFO - 2021-02-27 02:32:47 --> Config Class Initialized
INFO - 2021-02-27 02:32:47 --> Loader Class Initialized
INFO - 2021-02-27 02:32:47 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:47 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:47 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:47 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:47 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:47 --> Controller Class Initialized
DEBUG - 2021-02-27 02:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-02-27 02:32:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:32:47 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:47 --> Total execution time: 0.2818
INFO - 2021-02-27 02:32:56 --> Config Class Initialized
INFO - 2021-02-27 02:32:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:56 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:56 --> URI Class Initialized
INFO - 2021-02-27 02:32:56 --> Router Class Initialized
INFO - 2021-02-27 02:32:56 --> Output Class Initialized
INFO - 2021-02-27 02:32:56 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:56 --> Input Class Initialized
INFO - 2021-02-27 02:32:56 --> Language Class Initialized
INFO - 2021-02-27 02:32:56 --> Language Class Initialized
INFO - 2021-02-27 02:32:56 --> Config Class Initialized
INFO - 2021-02-27 02:32:56 --> Loader Class Initialized
INFO - 2021-02-27 02:32:56 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:56 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:56 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:56 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:56 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:56 --> Controller Class Initialized
INFO - 2021-02-27 02:32:56 --> Config Class Initialized
INFO - 2021-02-27 02:32:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:56 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:56 --> URI Class Initialized
INFO - 2021-02-27 02:32:56 --> Router Class Initialized
INFO - 2021-02-27 02:32:56 --> Output Class Initialized
INFO - 2021-02-27 02:32:56 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:56 --> Input Class Initialized
INFO - 2021-02-27 02:32:56 --> Language Class Initialized
INFO - 2021-02-27 02:32:56 --> Language Class Initialized
INFO - 2021-02-27 02:32:56 --> Config Class Initialized
INFO - 2021-02-27 02:32:56 --> Loader Class Initialized
INFO - 2021-02-27 02:32:56 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:56 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:56 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:56 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:56 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:56 --> Controller Class Initialized
DEBUG - 2021-02-27 02:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:32:56 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:56 --> Total execution time: 0.2594
INFO - 2021-02-27 02:32:57 --> Config Class Initialized
INFO - 2021-02-27 02:32:57 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:32:57 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:32:57 --> Utf8 Class Initialized
INFO - 2021-02-27 02:32:57 --> URI Class Initialized
INFO - 2021-02-27 02:32:57 --> Router Class Initialized
INFO - 2021-02-27 02:32:57 --> Output Class Initialized
INFO - 2021-02-27 02:32:57 --> Security Class Initialized
DEBUG - 2021-02-27 02:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:32:57 --> Input Class Initialized
INFO - 2021-02-27 02:32:57 --> Language Class Initialized
INFO - 2021-02-27 02:32:57 --> Language Class Initialized
INFO - 2021-02-27 02:32:57 --> Config Class Initialized
INFO - 2021-02-27 02:32:57 --> Loader Class Initialized
INFO - 2021-02-27 02:32:57 --> Helper loaded: url_helper
INFO - 2021-02-27 02:32:57 --> Helper loaded: file_helper
INFO - 2021-02-27 02:32:57 --> Helper loaded: form_helper
INFO - 2021-02-27 02:32:57 --> Helper loaded: my_helper
INFO - 2021-02-27 02:32:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:32:57 --> Controller Class Initialized
DEBUG - 2021-02-27 02:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-02-27 02:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:32:57 --> Final output sent to browser
DEBUG - 2021-02-27 02:32:57 --> Total execution time: 0.2630
INFO - 2021-02-27 02:33:09 --> Config Class Initialized
INFO - 2021-02-27 02:33:09 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:33:09 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:33:09 --> Utf8 Class Initialized
INFO - 2021-02-27 02:33:09 --> URI Class Initialized
INFO - 2021-02-27 02:33:09 --> Router Class Initialized
INFO - 2021-02-27 02:33:09 --> Output Class Initialized
INFO - 2021-02-27 02:33:09 --> Security Class Initialized
DEBUG - 2021-02-27 02:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:33:09 --> Input Class Initialized
INFO - 2021-02-27 02:33:09 --> Language Class Initialized
INFO - 2021-02-27 02:33:09 --> Language Class Initialized
INFO - 2021-02-27 02:33:09 --> Config Class Initialized
INFO - 2021-02-27 02:33:09 --> Loader Class Initialized
INFO - 2021-02-27 02:33:09 --> Helper loaded: url_helper
INFO - 2021-02-27 02:33:09 --> Helper loaded: file_helper
INFO - 2021-02-27 02:33:09 --> Helper loaded: form_helper
INFO - 2021-02-27 02:33:09 --> Helper loaded: my_helper
INFO - 2021-02-27 02:33:09 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:33:09 --> Controller Class Initialized
INFO - 2021-02-27 02:33:09 --> Config Class Initialized
INFO - 2021-02-27 02:33:09 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:33:09 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:33:09 --> Utf8 Class Initialized
INFO - 2021-02-27 02:33:09 --> URI Class Initialized
INFO - 2021-02-27 02:33:09 --> Router Class Initialized
INFO - 2021-02-27 02:33:09 --> Output Class Initialized
INFO - 2021-02-27 02:33:09 --> Security Class Initialized
DEBUG - 2021-02-27 02:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:33:09 --> Input Class Initialized
INFO - 2021-02-27 02:33:09 --> Language Class Initialized
INFO - 2021-02-27 02:33:09 --> Language Class Initialized
INFO - 2021-02-27 02:33:09 --> Config Class Initialized
INFO - 2021-02-27 02:33:09 --> Loader Class Initialized
INFO - 2021-02-27 02:33:09 --> Helper loaded: url_helper
INFO - 2021-02-27 02:33:09 --> Helper loaded: file_helper
INFO - 2021-02-27 02:33:09 --> Helper loaded: form_helper
INFO - 2021-02-27 02:33:09 --> Helper loaded: my_helper
INFO - 2021-02-27 02:33:09 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:33:10 --> Controller Class Initialized
DEBUG - 2021-02-27 02:33:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 02:33:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:33:10 --> Final output sent to browser
DEBUG - 2021-02-27 02:33:10 --> Total execution time: 0.3002
INFO - 2021-02-27 02:33:18 --> Config Class Initialized
INFO - 2021-02-27 02:33:18 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:33:18 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:33:18 --> Utf8 Class Initialized
INFO - 2021-02-27 02:33:18 --> URI Class Initialized
INFO - 2021-02-27 02:33:18 --> Router Class Initialized
INFO - 2021-02-27 02:33:18 --> Output Class Initialized
INFO - 2021-02-27 02:33:18 --> Security Class Initialized
DEBUG - 2021-02-27 02:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:33:19 --> Input Class Initialized
INFO - 2021-02-27 02:33:19 --> Language Class Initialized
INFO - 2021-02-27 02:33:19 --> Language Class Initialized
INFO - 2021-02-27 02:33:19 --> Config Class Initialized
INFO - 2021-02-27 02:33:19 --> Loader Class Initialized
INFO - 2021-02-27 02:33:19 --> Helper loaded: url_helper
INFO - 2021-02-27 02:33:19 --> Helper loaded: file_helper
INFO - 2021-02-27 02:33:19 --> Helper loaded: form_helper
INFO - 2021-02-27 02:33:19 --> Helper loaded: my_helper
INFO - 2021-02-27 02:33:19 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:33:19 --> Controller Class Initialized
DEBUG - 2021-02-27 02:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-27 02:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:33:19 --> Final output sent to browser
DEBUG - 2021-02-27 02:33:19 --> Total execution time: 0.2924
INFO - 2021-02-27 02:33:19 --> Config Class Initialized
INFO - 2021-02-27 02:33:19 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:33:19 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:33:19 --> Utf8 Class Initialized
INFO - 2021-02-27 02:33:19 --> URI Class Initialized
INFO - 2021-02-27 02:33:19 --> Router Class Initialized
INFO - 2021-02-27 02:33:19 --> Output Class Initialized
INFO - 2021-02-27 02:33:19 --> Security Class Initialized
DEBUG - 2021-02-27 02:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:33:19 --> Input Class Initialized
INFO - 2021-02-27 02:33:19 --> Language Class Initialized
INFO - 2021-02-27 02:33:19 --> Language Class Initialized
INFO - 2021-02-27 02:33:19 --> Config Class Initialized
INFO - 2021-02-27 02:33:19 --> Loader Class Initialized
INFO - 2021-02-27 02:33:19 --> Helper loaded: url_helper
INFO - 2021-02-27 02:33:19 --> Helper loaded: file_helper
INFO - 2021-02-27 02:33:19 --> Helper loaded: form_helper
INFO - 2021-02-27 02:33:19 --> Helper loaded: my_helper
INFO - 2021-02-27 02:33:19 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:33:19 --> Controller Class Initialized
INFO - 2021-02-27 02:33:23 --> Config Class Initialized
INFO - 2021-02-27 02:33:23 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:33:23 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:33:23 --> Utf8 Class Initialized
INFO - 2021-02-27 02:33:23 --> URI Class Initialized
INFO - 2021-02-27 02:33:23 --> Router Class Initialized
INFO - 2021-02-27 02:33:23 --> Output Class Initialized
INFO - 2021-02-27 02:33:23 --> Security Class Initialized
DEBUG - 2021-02-27 02:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:33:23 --> Input Class Initialized
INFO - 2021-02-27 02:33:23 --> Language Class Initialized
INFO - 2021-02-27 02:33:23 --> Language Class Initialized
INFO - 2021-02-27 02:33:23 --> Config Class Initialized
INFO - 2021-02-27 02:33:23 --> Loader Class Initialized
INFO - 2021-02-27 02:33:23 --> Helper loaded: url_helper
INFO - 2021-02-27 02:33:23 --> Helper loaded: file_helper
INFO - 2021-02-27 02:33:23 --> Helper loaded: form_helper
INFO - 2021-02-27 02:33:23 --> Helper loaded: my_helper
INFO - 2021-02-27 02:33:23 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:33:23 --> Controller Class Initialized
DEBUG - 2021-02-27 02:33:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-02-27 02:33:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:33:23 --> Final output sent to browser
DEBUG - 2021-02-27 02:33:23 --> Total execution time: 0.2852
INFO - 2021-02-27 02:33:51 --> Config Class Initialized
INFO - 2021-02-27 02:33:51 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:33:51 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:33:51 --> Utf8 Class Initialized
INFO - 2021-02-27 02:33:51 --> URI Class Initialized
INFO - 2021-02-27 02:33:51 --> Router Class Initialized
INFO - 2021-02-27 02:33:51 --> Output Class Initialized
INFO - 2021-02-27 02:33:51 --> Security Class Initialized
DEBUG - 2021-02-27 02:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:33:51 --> Input Class Initialized
INFO - 2021-02-27 02:33:51 --> Language Class Initialized
INFO - 2021-02-27 02:33:51 --> Language Class Initialized
INFO - 2021-02-27 02:33:51 --> Config Class Initialized
INFO - 2021-02-27 02:33:51 --> Loader Class Initialized
INFO - 2021-02-27 02:33:51 --> Helper loaded: url_helper
INFO - 2021-02-27 02:33:51 --> Helper loaded: file_helper
INFO - 2021-02-27 02:33:51 --> Helper loaded: form_helper
INFO - 2021-02-27 02:33:51 --> Helper loaded: my_helper
INFO - 2021-02-27 02:33:51 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:33:51 --> Controller Class Initialized
INFO - 2021-02-27 02:33:51 --> Config Class Initialized
INFO - 2021-02-27 02:33:51 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:33:51 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:33:51 --> Utf8 Class Initialized
INFO - 2021-02-27 02:33:51 --> URI Class Initialized
INFO - 2021-02-27 02:33:51 --> Router Class Initialized
INFO - 2021-02-27 02:33:51 --> Output Class Initialized
INFO - 2021-02-27 02:33:51 --> Security Class Initialized
DEBUG - 2021-02-27 02:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:33:51 --> Input Class Initialized
INFO - 2021-02-27 02:33:51 --> Language Class Initialized
INFO - 2021-02-27 02:33:51 --> Language Class Initialized
INFO - 2021-02-27 02:33:51 --> Config Class Initialized
INFO - 2021-02-27 02:33:51 --> Loader Class Initialized
INFO - 2021-02-27 02:33:51 --> Helper loaded: url_helper
INFO - 2021-02-27 02:33:51 --> Helper loaded: file_helper
INFO - 2021-02-27 02:33:51 --> Helper loaded: form_helper
INFO - 2021-02-27 02:33:51 --> Helper loaded: my_helper
INFO - 2021-02-27 02:33:51 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:33:51 --> Controller Class Initialized
DEBUG - 2021-02-27 02:33:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-27 02:33:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:33:51 --> Final output sent to browser
DEBUG - 2021-02-27 02:33:51 --> Total execution time: 0.2691
INFO - 2021-02-27 02:33:52 --> Config Class Initialized
INFO - 2021-02-27 02:33:52 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:33:52 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:33:52 --> Utf8 Class Initialized
INFO - 2021-02-27 02:33:52 --> URI Class Initialized
INFO - 2021-02-27 02:33:52 --> Router Class Initialized
INFO - 2021-02-27 02:33:52 --> Output Class Initialized
INFO - 2021-02-27 02:33:52 --> Security Class Initialized
DEBUG - 2021-02-27 02:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:33:52 --> Input Class Initialized
INFO - 2021-02-27 02:33:52 --> Language Class Initialized
INFO - 2021-02-27 02:33:52 --> Language Class Initialized
INFO - 2021-02-27 02:33:52 --> Config Class Initialized
INFO - 2021-02-27 02:33:52 --> Loader Class Initialized
INFO - 2021-02-27 02:33:52 --> Helper loaded: url_helper
INFO - 2021-02-27 02:33:52 --> Helper loaded: file_helper
INFO - 2021-02-27 02:33:52 --> Helper loaded: form_helper
INFO - 2021-02-27 02:33:52 --> Helper loaded: my_helper
INFO - 2021-02-27 02:33:52 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:33:52 --> Controller Class Initialized
INFO - 2021-02-27 02:33:58 --> Config Class Initialized
INFO - 2021-02-27 02:33:58 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:33:58 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:33:58 --> Utf8 Class Initialized
INFO - 2021-02-27 02:33:58 --> URI Class Initialized
INFO - 2021-02-27 02:33:58 --> Router Class Initialized
INFO - 2021-02-27 02:33:58 --> Output Class Initialized
INFO - 2021-02-27 02:33:58 --> Security Class Initialized
DEBUG - 2021-02-27 02:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:33:58 --> Input Class Initialized
INFO - 2021-02-27 02:33:58 --> Language Class Initialized
INFO - 2021-02-27 02:33:58 --> Language Class Initialized
INFO - 2021-02-27 02:33:58 --> Config Class Initialized
INFO - 2021-02-27 02:33:58 --> Loader Class Initialized
INFO - 2021-02-27 02:33:58 --> Helper loaded: url_helper
INFO - 2021-02-27 02:33:58 --> Helper loaded: file_helper
INFO - 2021-02-27 02:33:58 --> Helper loaded: form_helper
INFO - 2021-02-27 02:33:58 --> Helper loaded: my_helper
INFO - 2021-02-27 02:33:58 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:33:58 --> Controller Class Initialized
INFO - 2021-02-27 02:34:29 --> Config Class Initialized
INFO - 2021-02-27 02:34:29 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:34:29 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:34:29 --> Utf8 Class Initialized
INFO - 2021-02-27 02:34:29 --> URI Class Initialized
INFO - 2021-02-27 02:34:29 --> Router Class Initialized
INFO - 2021-02-27 02:34:29 --> Output Class Initialized
INFO - 2021-02-27 02:34:29 --> Security Class Initialized
DEBUG - 2021-02-27 02:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:34:29 --> Input Class Initialized
INFO - 2021-02-27 02:34:29 --> Language Class Initialized
INFO - 2021-02-27 02:34:29 --> Language Class Initialized
INFO - 2021-02-27 02:34:29 --> Config Class Initialized
INFO - 2021-02-27 02:34:29 --> Loader Class Initialized
INFO - 2021-02-27 02:34:29 --> Helper loaded: url_helper
INFO - 2021-02-27 02:34:29 --> Helper loaded: file_helper
INFO - 2021-02-27 02:34:29 --> Helper loaded: form_helper
INFO - 2021-02-27 02:34:29 --> Helper loaded: my_helper
INFO - 2021-02-27 02:34:29 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:34:29 --> Controller Class Initialized
DEBUG - 2021-02-27 02:34:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-02-27 02:34:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:34:29 --> Final output sent to browser
DEBUG - 2021-02-27 02:34:29 --> Total execution time: 0.2924
INFO - 2021-02-27 02:34:29 --> Config Class Initialized
INFO - 2021-02-27 02:34:29 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:34:29 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:34:29 --> Utf8 Class Initialized
INFO - 2021-02-27 02:34:29 --> URI Class Initialized
INFO - 2021-02-27 02:34:29 --> Router Class Initialized
INFO - 2021-02-27 02:34:29 --> Output Class Initialized
INFO - 2021-02-27 02:34:29 --> Security Class Initialized
DEBUG - 2021-02-27 02:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:34:29 --> Input Class Initialized
INFO - 2021-02-27 02:34:29 --> Language Class Initialized
INFO - 2021-02-27 02:34:29 --> Language Class Initialized
INFO - 2021-02-27 02:34:29 --> Config Class Initialized
INFO - 2021-02-27 02:34:29 --> Loader Class Initialized
INFO - 2021-02-27 02:34:29 --> Helper loaded: url_helper
INFO - 2021-02-27 02:34:29 --> Helper loaded: file_helper
INFO - 2021-02-27 02:34:29 --> Helper loaded: form_helper
INFO - 2021-02-27 02:34:29 --> Helper loaded: my_helper
INFO - 2021-02-27 02:34:29 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:34:29 --> Controller Class Initialized
INFO - 2021-02-27 02:34:33 --> Config Class Initialized
INFO - 2021-02-27 02:34:33 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:34:33 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:34:33 --> Utf8 Class Initialized
INFO - 2021-02-27 02:34:33 --> URI Class Initialized
INFO - 2021-02-27 02:34:33 --> Router Class Initialized
INFO - 2021-02-27 02:34:33 --> Output Class Initialized
INFO - 2021-02-27 02:34:33 --> Security Class Initialized
DEBUG - 2021-02-27 02:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:34:33 --> Input Class Initialized
INFO - 2021-02-27 02:34:33 --> Language Class Initialized
INFO - 2021-02-27 02:34:33 --> Language Class Initialized
INFO - 2021-02-27 02:34:33 --> Config Class Initialized
INFO - 2021-02-27 02:34:33 --> Loader Class Initialized
INFO - 2021-02-27 02:34:33 --> Helper loaded: url_helper
INFO - 2021-02-27 02:34:33 --> Helper loaded: file_helper
INFO - 2021-02-27 02:34:33 --> Helper loaded: form_helper
INFO - 2021-02-27 02:34:33 --> Helper loaded: my_helper
INFO - 2021-02-27 02:34:33 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:34:33 --> Controller Class Initialized
INFO - 2021-02-27 02:34:33 --> Final output sent to browser
DEBUG - 2021-02-27 02:34:33 --> Total execution time: 0.2968
INFO - 2021-02-27 02:34:43 --> Config Class Initialized
INFO - 2021-02-27 02:34:43 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:34:43 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:34:43 --> Utf8 Class Initialized
INFO - 2021-02-27 02:34:43 --> URI Class Initialized
INFO - 2021-02-27 02:34:44 --> Router Class Initialized
INFO - 2021-02-27 02:34:44 --> Output Class Initialized
INFO - 2021-02-27 02:34:44 --> Security Class Initialized
DEBUG - 2021-02-27 02:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:34:44 --> Input Class Initialized
INFO - 2021-02-27 02:34:44 --> Language Class Initialized
INFO - 2021-02-27 02:34:44 --> Language Class Initialized
INFO - 2021-02-27 02:34:44 --> Config Class Initialized
INFO - 2021-02-27 02:34:44 --> Loader Class Initialized
INFO - 2021-02-27 02:34:44 --> Helper loaded: url_helper
INFO - 2021-02-27 02:34:44 --> Helper loaded: file_helper
INFO - 2021-02-27 02:34:44 --> Helper loaded: form_helper
INFO - 2021-02-27 02:34:44 --> Helper loaded: my_helper
INFO - 2021-02-27 02:34:44 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:34:44 --> Controller Class Initialized
INFO - 2021-02-27 02:34:44 --> Final output sent to browser
DEBUG - 2021-02-27 02:34:44 --> Total execution time: 0.3136
INFO - 2021-02-27 02:34:44 --> Config Class Initialized
INFO - 2021-02-27 02:34:44 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:34:44 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:34:44 --> Utf8 Class Initialized
INFO - 2021-02-27 02:34:44 --> URI Class Initialized
INFO - 2021-02-27 02:34:44 --> Router Class Initialized
INFO - 2021-02-27 02:34:44 --> Output Class Initialized
INFO - 2021-02-27 02:34:44 --> Security Class Initialized
DEBUG - 2021-02-27 02:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:34:44 --> Input Class Initialized
INFO - 2021-02-27 02:34:44 --> Language Class Initialized
INFO - 2021-02-27 02:34:44 --> Language Class Initialized
INFO - 2021-02-27 02:34:44 --> Config Class Initialized
INFO - 2021-02-27 02:34:44 --> Loader Class Initialized
INFO - 2021-02-27 02:34:44 --> Helper loaded: url_helper
INFO - 2021-02-27 02:34:44 --> Helper loaded: file_helper
INFO - 2021-02-27 02:34:44 --> Helper loaded: form_helper
INFO - 2021-02-27 02:34:44 --> Helper loaded: my_helper
INFO - 2021-02-27 02:34:44 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:34:44 --> Controller Class Initialized
INFO - 2021-02-27 02:34:46 --> Config Class Initialized
INFO - 2021-02-27 02:34:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:34:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:34:46 --> Utf8 Class Initialized
INFO - 2021-02-27 02:34:46 --> URI Class Initialized
INFO - 2021-02-27 02:34:46 --> Router Class Initialized
INFO - 2021-02-27 02:34:46 --> Output Class Initialized
INFO - 2021-02-27 02:34:46 --> Security Class Initialized
DEBUG - 2021-02-27 02:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:34:46 --> Input Class Initialized
INFO - 2021-02-27 02:34:46 --> Language Class Initialized
INFO - 2021-02-27 02:34:46 --> Language Class Initialized
INFO - 2021-02-27 02:34:46 --> Config Class Initialized
INFO - 2021-02-27 02:34:46 --> Loader Class Initialized
INFO - 2021-02-27 02:34:46 --> Helper loaded: url_helper
INFO - 2021-02-27 02:34:46 --> Helper loaded: file_helper
INFO - 2021-02-27 02:34:46 --> Helper loaded: form_helper
INFO - 2021-02-27 02:34:46 --> Helper loaded: my_helper
INFO - 2021-02-27 02:34:46 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:34:46 --> Controller Class Initialized
INFO - 2021-02-27 02:34:49 --> Config Class Initialized
INFO - 2021-02-27 02:34:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:34:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:34:49 --> Utf8 Class Initialized
INFO - 2021-02-27 02:34:49 --> URI Class Initialized
INFO - 2021-02-27 02:34:49 --> Router Class Initialized
INFO - 2021-02-27 02:34:49 --> Output Class Initialized
INFO - 2021-02-27 02:34:49 --> Security Class Initialized
DEBUG - 2021-02-27 02:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:34:49 --> Input Class Initialized
INFO - 2021-02-27 02:34:49 --> Language Class Initialized
INFO - 2021-02-27 02:34:49 --> Language Class Initialized
INFO - 2021-02-27 02:34:49 --> Config Class Initialized
INFO - 2021-02-27 02:34:49 --> Loader Class Initialized
INFO - 2021-02-27 02:34:49 --> Helper loaded: url_helper
INFO - 2021-02-27 02:34:49 --> Helper loaded: file_helper
INFO - 2021-02-27 02:34:49 --> Helper loaded: form_helper
INFO - 2021-02-27 02:34:49 --> Helper loaded: my_helper
INFO - 2021-02-27 02:34:49 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:34:49 --> Controller Class Initialized
INFO - 2021-02-27 02:34:49 --> Final output sent to browser
DEBUG - 2021-02-27 02:34:49 --> Total execution time: 0.2688
INFO - 2021-02-27 02:34:57 --> Config Class Initialized
INFO - 2021-02-27 02:34:57 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:34:57 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:34:57 --> Utf8 Class Initialized
INFO - 2021-02-27 02:34:57 --> URI Class Initialized
INFO - 2021-02-27 02:34:57 --> Router Class Initialized
INFO - 2021-02-27 02:34:57 --> Output Class Initialized
INFO - 2021-02-27 02:34:57 --> Security Class Initialized
DEBUG - 2021-02-27 02:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:34:57 --> Input Class Initialized
INFO - 2021-02-27 02:34:57 --> Language Class Initialized
INFO - 2021-02-27 02:34:57 --> Language Class Initialized
INFO - 2021-02-27 02:34:57 --> Config Class Initialized
INFO - 2021-02-27 02:34:57 --> Loader Class Initialized
INFO - 2021-02-27 02:34:57 --> Helper loaded: url_helper
INFO - 2021-02-27 02:34:57 --> Helper loaded: file_helper
INFO - 2021-02-27 02:34:57 --> Helper loaded: form_helper
INFO - 2021-02-27 02:34:57 --> Helper loaded: my_helper
INFO - 2021-02-27 02:34:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:34:57 --> Controller Class Initialized
INFO - 2021-02-27 02:34:57 --> Final output sent to browser
DEBUG - 2021-02-27 02:34:57 --> Total execution time: 0.2944
INFO - 2021-02-27 02:35:01 --> Config Class Initialized
INFO - 2021-02-27 02:35:01 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:35:01 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:35:01 --> Utf8 Class Initialized
INFO - 2021-02-27 02:35:01 --> URI Class Initialized
INFO - 2021-02-27 02:35:01 --> Router Class Initialized
INFO - 2021-02-27 02:35:01 --> Output Class Initialized
INFO - 2021-02-27 02:35:01 --> Security Class Initialized
DEBUG - 2021-02-27 02:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:35:01 --> Input Class Initialized
INFO - 2021-02-27 02:35:01 --> Language Class Initialized
INFO - 2021-02-27 02:35:01 --> Language Class Initialized
INFO - 2021-02-27 02:35:01 --> Config Class Initialized
INFO - 2021-02-27 02:35:01 --> Loader Class Initialized
INFO - 2021-02-27 02:35:01 --> Helper loaded: url_helper
INFO - 2021-02-27 02:35:01 --> Helper loaded: file_helper
INFO - 2021-02-27 02:35:01 --> Helper loaded: form_helper
INFO - 2021-02-27 02:35:01 --> Helper loaded: my_helper
INFO - 2021-02-27 02:35:01 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:35:01 --> Controller Class Initialized
INFO - 2021-02-27 02:35:05 --> Config Class Initialized
INFO - 2021-02-27 02:35:05 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:35:05 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:35:05 --> Utf8 Class Initialized
INFO - 2021-02-27 02:35:05 --> URI Class Initialized
INFO - 2021-02-27 02:35:05 --> Router Class Initialized
INFO - 2021-02-27 02:35:05 --> Output Class Initialized
INFO - 2021-02-27 02:35:05 --> Security Class Initialized
DEBUG - 2021-02-27 02:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:35:05 --> Input Class Initialized
INFO - 2021-02-27 02:35:05 --> Language Class Initialized
INFO - 2021-02-27 02:35:05 --> Language Class Initialized
INFO - 2021-02-27 02:35:05 --> Config Class Initialized
INFO - 2021-02-27 02:35:05 --> Loader Class Initialized
INFO - 2021-02-27 02:35:05 --> Helper loaded: url_helper
INFO - 2021-02-27 02:35:05 --> Helper loaded: file_helper
INFO - 2021-02-27 02:35:05 --> Helper loaded: form_helper
INFO - 2021-02-27 02:35:05 --> Helper loaded: my_helper
INFO - 2021-02-27 02:35:05 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:35:05 --> Controller Class Initialized
INFO - 2021-02-27 02:35:09 --> Config Class Initialized
INFO - 2021-02-27 02:35:09 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:35:09 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:35:09 --> Utf8 Class Initialized
INFO - 2021-02-27 02:35:09 --> URI Class Initialized
INFO - 2021-02-27 02:35:09 --> Router Class Initialized
INFO - 2021-02-27 02:35:09 --> Output Class Initialized
INFO - 2021-02-27 02:35:09 --> Security Class Initialized
DEBUG - 2021-02-27 02:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:35:09 --> Input Class Initialized
INFO - 2021-02-27 02:35:09 --> Language Class Initialized
INFO - 2021-02-27 02:35:09 --> Language Class Initialized
INFO - 2021-02-27 02:35:09 --> Config Class Initialized
INFO - 2021-02-27 02:35:09 --> Loader Class Initialized
INFO - 2021-02-27 02:35:09 --> Helper loaded: url_helper
INFO - 2021-02-27 02:35:09 --> Helper loaded: file_helper
INFO - 2021-02-27 02:35:09 --> Helper loaded: form_helper
INFO - 2021-02-27 02:35:09 --> Helper loaded: my_helper
INFO - 2021-02-27 02:35:09 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:35:09 --> Controller Class Initialized
INFO - 2021-02-27 02:35:09 --> Final output sent to browser
DEBUG - 2021-02-27 02:35:09 --> Total execution time: 0.3315
INFO - 2021-02-27 02:35:09 --> Config Class Initialized
INFO - 2021-02-27 02:35:09 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:35:09 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:35:09 --> Utf8 Class Initialized
INFO - 2021-02-27 02:35:09 --> URI Class Initialized
INFO - 2021-02-27 02:35:09 --> Router Class Initialized
INFO - 2021-02-27 02:35:09 --> Output Class Initialized
INFO - 2021-02-27 02:35:09 --> Security Class Initialized
DEBUG - 2021-02-27 02:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:35:09 --> Input Class Initialized
INFO - 2021-02-27 02:35:09 --> Language Class Initialized
INFO - 2021-02-27 02:35:09 --> Language Class Initialized
INFO - 2021-02-27 02:35:09 --> Config Class Initialized
INFO - 2021-02-27 02:35:09 --> Loader Class Initialized
INFO - 2021-02-27 02:35:09 --> Helper loaded: url_helper
INFO - 2021-02-27 02:35:09 --> Helper loaded: file_helper
INFO - 2021-02-27 02:35:09 --> Helper loaded: form_helper
INFO - 2021-02-27 02:35:09 --> Helper loaded: my_helper
INFO - 2021-02-27 02:35:09 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:35:09 --> Controller Class Initialized
INFO - 2021-02-27 02:35:12 --> Config Class Initialized
INFO - 2021-02-27 02:35:12 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:35:12 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:35:12 --> Utf8 Class Initialized
INFO - 2021-02-27 02:35:12 --> URI Class Initialized
INFO - 2021-02-27 02:35:12 --> Router Class Initialized
INFO - 2021-02-27 02:35:12 --> Output Class Initialized
INFO - 2021-02-27 02:35:12 --> Security Class Initialized
DEBUG - 2021-02-27 02:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:35:12 --> Input Class Initialized
INFO - 2021-02-27 02:35:12 --> Language Class Initialized
INFO - 2021-02-27 02:35:12 --> Language Class Initialized
INFO - 2021-02-27 02:35:12 --> Config Class Initialized
INFO - 2021-02-27 02:35:12 --> Loader Class Initialized
INFO - 2021-02-27 02:35:12 --> Helper loaded: url_helper
INFO - 2021-02-27 02:35:12 --> Helper loaded: file_helper
INFO - 2021-02-27 02:35:12 --> Helper loaded: form_helper
INFO - 2021-02-27 02:35:12 --> Helper loaded: my_helper
INFO - 2021-02-27 02:35:12 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:35:12 --> Controller Class Initialized
INFO - 2021-02-27 02:35:36 --> Config Class Initialized
INFO - 2021-02-27 02:35:36 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:35:36 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:35:36 --> Utf8 Class Initialized
INFO - 2021-02-27 02:35:36 --> URI Class Initialized
INFO - 2021-02-27 02:35:36 --> Router Class Initialized
INFO - 2021-02-27 02:35:36 --> Output Class Initialized
INFO - 2021-02-27 02:35:36 --> Security Class Initialized
DEBUG - 2021-02-27 02:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:35:36 --> Input Class Initialized
INFO - 2021-02-27 02:35:36 --> Language Class Initialized
INFO - 2021-02-27 02:35:36 --> Language Class Initialized
INFO - 2021-02-27 02:35:36 --> Config Class Initialized
INFO - 2021-02-27 02:35:36 --> Loader Class Initialized
INFO - 2021-02-27 02:35:36 --> Helper loaded: url_helper
INFO - 2021-02-27 02:35:36 --> Helper loaded: file_helper
INFO - 2021-02-27 02:35:36 --> Helper loaded: form_helper
INFO - 2021-02-27 02:35:36 --> Helper loaded: my_helper
INFO - 2021-02-27 02:35:36 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:35:37 --> Controller Class Initialized
DEBUG - 2021-02-27 02:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-02-27 02:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:35:37 --> Final output sent to browser
DEBUG - 2021-02-27 02:35:37 --> Total execution time: 0.2774
INFO - 2021-02-27 02:35:37 --> Config Class Initialized
INFO - 2021-02-27 02:35:37 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:35:37 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:35:37 --> Utf8 Class Initialized
INFO - 2021-02-27 02:35:37 --> URI Class Initialized
INFO - 2021-02-27 02:35:37 --> Router Class Initialized
INFO - 2021-02-27 02:35:37 --> Output Class Initialized
INFO - 2021-02-27 02:35:37 --> Security Class Initialized
DEBUG - 2021-02-27 02:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:35:37 --> Input Class Initialized
INFO - 2021-02-27 02:35:37 --> Language Class Initialized
INFO - 2021-02-27 02:35:37 --> Language Class Initialized
INFO - 2021-02-27 02:35:37 --> Config Class Initialized
INFO - 2021-02-27 02:35:37 --> Loader Class Initialized
INFO - 2021-02-27 02:35:37 --> Helper loaded: url_helper
INFO - 2021-02-27 02:35:37 --> Helper loaded: file_helper
INFO - 2021-02-27 02:35:37 --> Helper loaded: form_helper
INFO - 2021-02-27 02:35:37 --> Helper loaded: my_helper
INFO - 2021-02-27 02:35:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:35:37 --> Controller Class Initialized
INFO - 2021-02-27 02:35:44 --> Config Class Initialized
INFO - 2021-02-27 02:35:44 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:35:44 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:35:45 --> Utf8 Class Initialized
INFO - 2021-02-27 02:35:45 --> URI Class Initialized
INFO - 2021-02-27 02:35:45 --> Router Class Initialized
INFO - 2021-02-27 02:35:45 --> Output Class Initialized
INFO - 2021-02-27 02:35:45 --> Security Class Initialized
DEBUG - 2021-02-27 02:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:35:45 --> Input Class Initialized
INFO - 2021-02-27 02:35:45 --> Language Class Initialized
INFO - 2021-02-27 02:35:45 --> Language Class Initialized
INFO - 2021-02-27 02:35:45 --> Config Class Initialized
INFO - 2021-02-27 02:35:45 --> Loader Class Initialized
INFO - 2021-02-27 02:35:45 --> Helper loaded: url_helper
INFO - 2021-02-27 02:35:45 --> Helper loaded: file_helper
INFO - 2021-02-27 02:35:45 --> Helper loaded: form_helper
INFO - 2021-02-27 02:35:45 --> Helper loaded: my_helper
INFO - 2021-02-27 02:35:45 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:35:45 --> Controller Class Initialized
DEBUG - 2021-02-27 02:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-27 02:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:35:45 --> Final output sent to browser
DEBUG - 2021-02-27 02:35:45 --> Total execution time: 0.2960
INFO - 2021-02-27 02:35:45 --> Config Class Initialized
INFO - 2021-02-27 02:35:45 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:35:45 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:35:45 --> Utf8 Class Initialized
INFO - 2021-02-27 02:35:45 --> URI Class Initialized
INFO - 2021-02-27 02:35:45 --> Router Class Initialized
INFO - 2021-02-27 02:35:45 --> Output Class Initialized
INFO - 2021-02-27 02:35:45 --> Security Class Initialized
DEBUG - 2021-02-27 02:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:35:45 --> Input Class Initialized
INFO - 2021-02-27 02:35:45 --> Language Class Initialized
INFO - 2021-02-27 02:35:45 --> Language Class Initialized
INFO - 2021-02-27 02:35:45 --> Config Class Initialized
INFO - 2021-02-27 02:35:45 --> Loader Class Initialized
INFO - 2021-02-27 02:35:45 --> Helper loaded: url_helper
INFO - 2021-02-27 02:35:45 --> Helper loaded: file_helper
INFO - 2021-02-27 02:35:45 --> Helper loaded: form_helper
INFO - 2021-02-27 02:35:45 --> Helper loaded: my_helper
INFO - 2021-02-27 02:35:45 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:35:45 --> Controller Class Initialized
INFO - 2021-02-27 02:36:00 --> Config Class Initialized
INFO - 2021-02-27 02:36:00 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:36:00 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:36:00 --> Utf8 Class Initialized
INFO - 2021-02-27 02:36:00 --> URI Class Initialized
INFO - 2021-02-27 02:36:00 --> Router Class Initialized
INFO - 2021-02-27 02:36:00 --> Output Class Initialized
INFO - 2021-02-27 02:36:00 --> Security Class Initialized
DEBUG - 2021-02-27 02:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:36:00 --> Input Class Initialized
INFO - 2021-02-27 02:36:00 --> Language Class Initialized
INFO - 2021-02-27 02:36:00 --> Language Class Initialized
INFO - 2021-02-27 02:36:00 --> Config Class Initialized
INFO - 2021-02-27 02:36:00 --> Loader Class Initialized
INFO - 2021-02-27 02:36:00 --> Helper loaded: url_helper
INFO - 2021-02-27 02:36:00 --> Helper loaded: file_helper
INFO - 2021-02-27 02:36:00 --> Helper loaded: form_helper
INFO - 2021-02-27 02:36:00 --> Helper loaded: my_helper
INFO - 2021-02-27 02:36:00 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:36:00 --> Controller Class Initialized
DEBUG - 2021-02-27 02:36:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2021-02-27 02:36:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:36:00 --> Final output sent to browser
DEBUG - 2021-02-27 02:36:00 --> Total execution time: 0.3198
INFO - 2021-02-27 02:36:09 --> Config Class Initialized
INFO - 2021-02-27 02:36:09 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:36:09 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:36:09 --> Utf8 Class Initialized
INFO - 2021-02-27 02:36:09 --> URI Class Initialized
INFO - 2021-02-27 02:36:09 --> Router Class Initialized
INFO - 2021-02-27 02:36:09 --> Output Class Initialized
INFO - 2021-02-27 02:36:09 --> Security Class Initialized
DEBUG - 2021-02-27 02:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:36:09 --> Input Class Initialized
INFO - 2021-02-27 02:36:09 --> Language Class Initialized
INFO - 2021-02-27 02:36:09 --> Language Class Initialized
INFO - 2021-02-27 02:36:09 --> Config Class Initialized
INFO - 2021-02-27 02:36:09 --> Loader Class Initialized
INFO - 2021-02-27 02:36:09 --> Helper loaded: url_helper
INFO - 2021-02-27 02:36:09 --> Helper loaded: file_helper
INFO - 2021-02-27 02:36:09 --> Helper loaded: form_helper
INFO - 2021-02-27 02:36:09 --> Helper loaded: my_helper
INFO - 2021-02-27 02:36:09 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:36:09 --> Controller Class Initialized
INFO - 2021-02-27 02:36:09 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:36:09 --> Config Class Initialized
INFO - 2021-02-27 02:36:09 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:36:09 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:36:09 --> Utf8 Class Initialized
INFO - 2021-02-27 02:36:09 --> URI Class Initialized
INFO - 2021-02-27 02:36:09 --> Router Class Initialized
INFO - 2021-02-27 02:36:09 --> Output Class Initialized
INFO - 2021-02-27 02:36:09 --> Security Class Initialized
DEBUG - 2021-02-27 02:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:36:09 --> Input Class Initialized
INFO - 2021-02-27 02:36:09 --> Language Class Initialized
INFO - 2021-02-27 02:36:09 --> Language Class Initialized
INFO - 2021-02-27 02:36:09 --> Config Class Initialized
INFO - 2021-02-27 02:36:09 --> Loader Class Initialized
INFO - 2021-02-27 02:36:09 --> Helper loaded: url_helper
INFO - 2021-02-27 02:36:10 --> Helper loaded: file_helper
INFO - 2021-02-27 02:36:10 --> Helper loaded: form_helper
INFO - 2021-02-27 02:36:10 --> Helper loaded: my_helper
INFO - 2021-02-27 02:36:10 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:36:10 --> Controller Class Initialized
DEBUG - 2021-02-27 02:36:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:36:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:36:10 --> Final output sent to browser
DEBUG - 2021-02-27 02:36:10 --> Total execution time: 0.2439
INFO - 2021-02-27 02:36:21 --> Config Class Initialized
INFO - 2021-02-27 02:36:21 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:36:21 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:36:21 --> Utf8 Class Initialized
INFO - 2021-02-27 02:36:21 --> URI Class Initialized
INFO - 2021-02-27 02:36:21 --> Router Class Initialized
INFO - 2021-02-27 02:36:21 --> Output Class Initialized
INFO - 2021-02-27 02:36:21 --> Security Class Initialized
DEBUG - 2021-02-27 02:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:36:21 --> Input Class Initialized
INFO - 2021-02-27 02:36:21 --> Language Class Initialized
INFO - 2021-02-27 02:36:21 --> Language Class Initialized
INFO - 2021-02-27 02:36:21 --> Config Class Initialized
INFO - 2021-02-27 02:36:21 --> Loader Class Initialized
INFO - 2021-02-27 02:36:21 --> Helper loaded: url_helper
INFO - 2021-02-27 02:36:21 --> Helper loaded: file_helper
INFO - 2021-02-27 02:36:22 --> Helper loaded: form_helper
INFO - 2021-02-27 02:36:22 --> Helper loaded: my_helper
INFO - 2021-02-27 02:36:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:36:22 --> Controller Class Initialized
INFO - 2021-02-27 02:36:22 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:36:22 --> Final output sent to browser
DEBUG - 2021-02-27 02:36:22 --> Total execution time: 0.3599
INFO - 2021-02-27 02:36:23 --> Config Class Initialized
INFO - 2021-02-27 02:36:23 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:36:23 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:36:23 --> Utf8 Class Initialized
INFO - 2021-02-27 02:36:23 --> URI Class Initialized
INFO - 2021-02-27 02:36:23 --> Router Class Initialized
INFO - 2021-02-27 02:36:23 --> Output Class Initialized
INFO - 2021-02-27 02:36:23 --> Security Class Initialized
DEBUG - 2021-02-27 02:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:36:23 --> Input Class Initialized
INFO - 2021-02-27 02:36:23 --> Language Class Initialized
INFO - 2021-02-27 02:36:23 --> Language Class Initialized
INFO - 2021-02-27 02:36:23 --> Config Class Initialized
INFO - 2021-02-27 02:36:23 --> Loader Class Initialized
INFO - 2021-02-27 02:36:23 --> Helper loaded: url_helper
INFO - 2021-02-27 02:36:23 --> Helper loaded: file_helper
INFO - 2021-02-27 02:36:23 --> Helper loaded: form_helper
INFO - 2021-02-27 02:36:23 --> Helper loaded: my_helper
INFO - 2021-02-27 02:36:23 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:36:23 --> Controller Class Initialized
DEBUG - 2021-02-27 02:36:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 02:36:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:36:24 --> Final output sent to browser
DEBUG - 2021-02-27 02:36:24 --> Total execution time: 0.4297
INFO - 2021-02-27 02:36:37 --> Config Class Initialized
INFO - 2021-02-27 02:36:37 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:36:37 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:36:37 --> Utf8 Class Initialized
INFO - 2021-02-27 02:36:37 --> URI Class Initialized
INFO - 2021-02-27 02:36:37 --> Router Class Initialized
INFO - 2021-02-27 02:36:37 --> Output Class Initialized
INFO - 2021-02-27 02:36:37 --> Security Class Initialized
DEBUG - 2021-02-27 02:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:36:37 --> Input Class Initialized
INFO - 2021-02-27 02:36:37 --> Language Class Initialized
INFO - 2021-02-27 02:36:37 --> Language Class Initialized
INFO - 2021-02-27 02:36:37 --> Config Class Initialized
INFO - 2021-02-27 02:36:37 --> Loader Class Initialized
INFO - 2021-02-27 02:36:37 --> Helper loaded: url_helper
INFO - 2021-02-27 02:36:37 --> Helper loaded: file_helper
INFO - 2021-02-27 02:36:37 --> Helper loaded: form_helper
INFO - 2021-02-27 02:36:37 --> Helper loaded: my_helper
INFO - 2021-02-27 02:36:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:36:37 --> Controller Class Initialized
DEBUG - 2021-02-27 02:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2021-02-27 02:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:36:37 --> Final output sent to browser
DEBUG - 2021-02-27 02:36:37 --> Total execution time: 0.2768
INFO - 2021-02-27 02:36:43 --> Config Class Initialized
INFO - 2021-02-27 02:36:43 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:36:43 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:36:43 --> Utf8 Class Initialized
INFO - 2021-02-27 02:36:43 --> URI Class Initialized
INFO - 2021-02-27 02:36:43 --> Router Class Initialized
INFO - 2021-02-27 02:36:43 --> Output Class Initialized
INFO - 2021-02-27 02:36:43 --> Security Class Initialized
DEBUG - 2021-02-27 02:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:36:43 --> Input Class Initialized
INFO - 2021-02-27 02:36:43 --> Language Class Initialized
INFO - 2021-02-27 02:36:43 --> Language Class Initialized
INFO - 2021-02-27 02:36:43 --> Config Class Initialized
INFO - 2021-02-27 02:36:43 --> Loader Class Initialized
INFO - 2021-02-27 02:36:43 --> Helper loaded: url_helper
INFO - 2021-02-27 02:36:43 --> Helper loaded: file_helper
INFO - 2021-02-27 02:36:43 --> Helper loaded: form_helper
INFO - 2021-02-27 02:36:43 --> Helper loaded: my_helper
INFO - 2021-02-27 02:36:43 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:36:44 --> Controller Class Initialized
DEBUG - 2021-02-27 02:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-02-27 02:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:36:44 --> Final output sent to browser
DEBUG - 2021-02-27 02:36:44 --> Total execution time: 0.2760
INFO - 2021-02-27 02:36:53 --> Config Class Initialized
INFO - 2021-02-27 02:36:53 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:36:53 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:36:53 --> Utf8 Class Initialized
INFO - 2021-02-27 02:36:53 --> URI Class Initialized
INFO - 2021-02-27 02:36:53 --> Router Class Initialized
INFO - 2021-02-27 02:36:53 --> Output Class Initialized
INFO - 2021-02-27 02:36:53 --> Security Class Initialized
DEBUG - 2021-02-27 02:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:36:53 --> Input Class Initialized
INFO - 2021-02-27 02:36:53 --> Language Class Initialized
INFO - 2021-02-27 02:36:53 --> Language Class Initialized
INFO - 2021-02-27 02:36:53 --> Config Class Initialized
INFO - 2021-02-27 02:36:53 --> Loader Class Initialized
INFO - 2021-02-27 02:36:53 --> Helper loaded: url_helper
INFO - 2021-02-27 02:36:53 --> Helper loaded: file_helper
INFO - 2021-02-27 02:36:53 --> Helper loaded: form_helper
INFO - 2021-02-27 02:36:53 --> Helper loaded: my_helper
INFO - 2021-02-27 02:36:53 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:36:53 --> Controller Class Initialized
DEBUG - 2021-02-27 02:36:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-02-27 02:36:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:36:53 --> Final output sent to browser
DEBUG - 2021-02-27 02:36:53 --> Total execution time: 0.3136
INFO - 2021-02-27 02:36:53 --> Config Class Initialized
INFO - 2021-02-27 02:36:53 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:36:53 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:36:53 --> Utf8 Class Initialized
INFO - 2021-02-27 02:36:53 --> URI Class Initialized
INFO - 2021-02-27 02:36:53 --> Router Class Initialized
INFO - 2021-02-27 02:36:53 --> Output Class Initialized
INFO - 2021-02-27 02:36:53 --> Security Class Initialized
DEBUG - 2021-02-27 02:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:36:53 --> Input Class Initialized
INFO - 2021-02-27 02:36:53 --> Language Class Initialized
INFO - 2021-02-27 02:36:53 --> Language Class Initialized
INFO - 2021-02-27 02:36:54 --> Config Class Initialized
INFO - 2021-02-27 02:36:54 --> Loader Class Initialized
INFO - 2021-02-27 02:36:54 --> Helper loaded: url_helper
INFO - 2021-02-27 02:36:54 --> Helper loaded: file_helper
INFO - 2021-02-27 02:36:54 --> Helper loaded: form_helper
INFO - 2021-02-27 02:36:54 --> Helper loaded: my_helper
INFO - 2021-02-27 02:36:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:36:54 --> Controller Class Initialized
INFO - 2021-02-27 02:37:05 --> Config Class Initialized
INFO - 2021-02-27 02:37:05 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:37:05 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:37:05 --> Utf8 Class Initialized
INFO - 2021-02-27 02:37:05 --> URI Class Initialized
INFO - 2021-02-27 02:37:05 --> Router Class Initialized
INFO - 2021-02-27 02:37:05 --> Output Class Initialized
INFO - 2021-02-27 02:37:05 --> Security Class Initialized
DEBUG - 2021-02-27 02:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:37:05 --> Input Class Initialized
INFO - 2021-02-27 02:37:05 --> Language Class Initialized
INFO - 2021-02-27 02:37:05 --> Language Class Initialized
INFO - 2021-02-27 02:37:05 --> Config Class Initialized
INFO - 2021-02-27 02:37:05 --> Loader Class Initialized
INFO - 2021-02-27 02:37:05 --> Helper loaded: url_helper
INFO - 2021-02-27 02:37:05 --> Helper loaded: file_helper
INFO - 2021-02-27 02:37:05 --> Helper loaded: form_helper
INFO - 2021-02-27 02:37:05 --> Helper loaded: my_helper
INFO - 2021-02-27 02:37:05 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:37:05 --> Controller Class Initialized
INFO - 2021-02-27 02:37:05 --> Final output sent to browser
DEBUG - 2021-02-27 02:37:05 --> Total execution time: 0.3149
INFO - 2021-02-27 02:37:11 --> Config Class Initialized
INFO - 2021-02-27 02:37:11 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:37:11 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:37:11 --> Utf8 Class Initialized
INFO - 2021-02-27 02:37:11 --> URI Class Initialized
INFO - 2021-02-27 02:37:11 --> Router Class Initialized
INFO - 2021-02-27 02:37:11 --> Output Class Initialized
INFO - 2021-02-27 02:37:11 --> Security Class Initialized
DEBUG - 2021-02-27 02:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:37:11 --> Input Class Initialized
INFO - 2021-02-27 02:37:11 --> Language Class Initialized
INFO - 2021-02-27 02:37:11 --> Language Class Initialized
INFO - 2021-02-27 02:37:11 --> Config Class Initialized
INFO - 2021-02-27 02:37:11 --> Loader Class Initialized
INFO - 2021-02-27 02:37:11 --> Helper loaded: url_helper
INFO - 2021-02-27 02:37:11 --> Helper loaded: file_helper
INFO - 2021-02-27 02:37:11 --> Helper loaded: form_helper
INFO - 2021-02-27 02:37:11 --> Helper loaded: my_helper
INFO - 2021-02-27 02:37:11 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:37:11 --> Controller Class Initialized
INFO - 2021-02-27 02:37:11 --> Final output sent to browser
DEBUG - 2021-02-27 02:37:11 --> Total execution time: 0.2613
INFO - 2021-02-27 02:37:16 --> Config Class Initialized
INFO - 2021-02-27 02:37:16 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:37:16 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:37:16 --> Utf8 Class Initialized
INFO - 2021-02-27 02:37:16 --> URI Class Initialized
INFO - 2021-02-27 02:37:16 --> Router Class Initialized
INFO - 2021-02-27 02:37:16 --> Output Class Initialized
INFO - 2021-02-27 02:37:16 --> Security Class Initialized
DEBUG - 2021-02-27 02:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:37:16 --> Input Class Initialized
INFO - 2021-02-27 02:37:16 --> Language Class Initialized
INFO - 2021-02-27 02:37:16 --> Language Class Initialized
INFO - 2021-02-27 02:37:16 --> Config Class Initialized
INFO - 2021-02-27 02:37:16 --> Loader Class Initialized
INFO - 2021-02-27 02:37:16 --> Helper loaded: url_helper
INFO - 2021-02-27 02:37:16 --> Helper loaded: file_helper
INFO - 2021-02-27 02:37:16 --> Helper loaded: form_helper
INFO - 2021-02-27 02:37:16 --> Helper loaded: my_helper
INFO - 2021-02-27 02:37:16 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:37:16 --> Controller Class Initialized
INFO - 2021-02-27 02:37:16 --> Final output sent to browser
DEBUG - 2021-02-27 02:37:16 --> Total execution time: 0.3089
INFO - 2021-02-27 02:37:16 --> Config Class Initialized
INFO - 2021-02-27 02:37:16 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:37:16 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:37:16 --> Utf8 Class Initialized
INFO - 2021-02-27 02:37:16 --> URI Class Initialized
INFO - 2021-02-27 02:37:16 --> Router Class Initialized
INFO - 2021-02-27 02:37:16 --> Output Class Initialized
INFO - 2021-02-27 02:37:16 --> Security Class Initialized
DEBUG - 2021-02-27 02:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:37:16 --> Input Class Initialized
INFO - 2021-02-27 02:37:16 --> Language Class Initialized
INFO - 2021-02-27 02:37:16 --> Language Class Initialized
INFO - 2021-02-27 02:37:16 --> Config Class Initialized
INFO - 2021-02-27 02:37:16 --> Loader Class Initialized
INFO - 2021-02-27 02:37:16 --> Helper loaded: url_helper
INFO - 2021-02-27 02:37:16 --> Helper loaded: file_helper
INFO - 2021-02-27 02:37:16 --> Helper loaded: form_helper
INFO - 2021-02-27 02:37:16 --> Helper loaded: my_helper
INFO - 2021-02-27 02:37:16 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:37:16 --> Controller Class Initialized
INFO - 2021-02-27 02:37:22 --> Config Class Initialized
INFO - 2021-02-27 02:37:22 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:37:22 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:37:22 --> Utf8 Class Initialized
INFO - 2021-02-27 02:37:22 --> URI Class Initialized
INFO - 2021-02-27 02:37:22 --> Router Class Initialized
INFO - 2021-02-27 02:37:22 --> Output Class Initialized
INFO - 2021-02-27 02:37:22 --> Security Class Initialized
DEBUG - 2021-02-27 02:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:37:22 --> Input Class Initialized
INFO - 2021-02-27 02:37:22 --> Language Class Initialized
INFO - 2021-02-27 02:37:22 --> Language Class Initialized
INFO - 2021-02-27 02:37:22 --> Config Class Initialized
INFO - 2021-02-27 02:37:22 --> Loader Class Initialized
INFO - 2021-02-27 02:37:22 --> Helper loaded: url_helper
INFO - 2021-02-27 02:37:22 --> Helper loaded: file_helper
INFO - 2021-02-27 02:37:22 --> Helper loaded: form_helper
INFO - 2021-02-27 02:37:22 --> Helper loaded: my_helper
INFO - 2021-02-27 02:37:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:37:22 --> Controller Class Initialized
INFO - 2021-02-27 02:37:22 --> Final output sent to browser
DEBUG - 2021-02-27 02:37:22 --> Total execution time: 0.2462
INFO - 2021-02-27 02:37:34 --> Config Class Initialized
INFO - 2021-02-27 02:37:34 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:37:34 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:37:34 --> Utf8 Class Initialized
INFO - 2021-02-27 02:37:34 --> URI Class Initialized
INFO - 2021-02-27 02:37:34 --> Router Class Initialized
INFO - 2021-02-27 02:37:34 --> Output Class Initialized
INFO - 2021-02-27 02:37:34 --> Security Class Initialized
DEBUG - 2021-02-27 02:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:37:34 --> Input Class Initialized
INFO - 2021-02-27 02:37:34 --> Language Class Initialized
INFO - 2021-02-27 02:37:34 --> Language Class Initialized
INFO - 2021-02-27 02:37:34 --> Config Class Initialized
INFO - 2021-02-27 02:37:34 --> Loader Class Initialized
INFO - 2021-02-27 02:37:34 --> Helper loaded: url_helper
INFO - 2021-02-27 02:37:34 --> Helper loaded: file_helper
INFO - 2021-02-27 02:37:34 --> Helper loaded: form_helper
INFO - 2021-02-27 02:37:34 --> Helper loaded: my_helper
INFO - 2021-02-27 02:37:34 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:37:34 --> Controller Class Initialized
INFO - 2021-02-27 02:38:30 --> Config Class Initialized
INFO - 2021-02-27 02:38:30 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:30 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:30 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:30 --> URI Class Initialized
INFO - 2021-02-27 02:38:30 --> Router Class Initialized
INFO - 2021-02-27 02:38:30 --> Output Class Initialized
INFO - 2021-02-27 02:38:30 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:30 --> Input Class Initialized
INFO - 2021-02-27 02:38:30 --> Language Class Initialized
INFO - 2021-02-27 02:38:30 --> Language Class Initialized
INFO - 2021-02-27 02:38:30 --> Config Class Initialized
INFO - 2021-02-27 02:38:30 --> Loader Class Initialized
INFO - 2021-02-27 02:38:30 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:30 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:30 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:30 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:30 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:30 --> Controller Class Initialized
DEBUG - 2021-02-27 02:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-02-27 02:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:38:30 --> Final output sent to browser
DEBUG - 2021-02-27 02:38:30 --> Total execution time: 0.3290
INFO - 2021-02-27 02:38:39 --> Config Class Initialized
INFO - 2021-02-27 02:38:39 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:40 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:40 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:40 --> URI Class Initialized
INFO - 2021-02-27 02:38:40 --> Router Class Initialized
INFO - 2021-02-27 02:38:40 --> Output Class Initialized
INFO - 2021-02-27 02:38:40 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:40 --> Input Class Initialized
INFO - 2021-02-27 02:38:40 --> Language Class Initialized
INFO - 2021-02-27 02:38:40 --> Language Class Initialized
INFO - 2021-02-27 02:38:40 --> Config Class Initialized
INFO - 2021-02-27 02:38:40 --> Loader Class Initialized
INFO - 2021-02-27 02:38:40 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:40 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:40 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:40 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:40 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:40 --> Controller Class Initialized
INFO - 2021-02-27 02:38:40 --> Config Class Initialized
INFO - 2021-02-27 02:38:40 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:40 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:40 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:40 --> URI Class Initialized
INFO - 2021-02-27 02:38:40 --> Router Class Initialized
INFO - 2021-02-27 02:38:40 --> Output Class Initialized
INFO - 2021-02-27 02:38:40 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:40 --> Input Class Initialized
INFO - 2021-02-27 02:38:40 --> Language Class Initialized
INFO - 2021-02-27 02:38:40 --> Language Class Initialized
INFO - 2021-02-27 02:38:40 --> Config Class Initialized
INFO - 2021-02-27 02:38:40 --> Loader Class Initialized
INFO - 2021-02-27 02:38:40 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:40 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:40 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:40 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:40 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:40 --> Controller Class Initialized
DEBUG - 2021-02-27 02:38:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-02-27 02:38:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:38:40 --> Final output sent to browser
DEBUG - 2021-02-27 02:38:40 --> Total execution time: 0.2554
INFO - 2021-02-27 02:38:40 --> Config Class Initialized
INFO - 2021-02-27 02:38:40 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:40 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:40 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:40 --> URI Class Initialized
INFO - 2021-02-27 02:38:40 --> Router Class Initialized
INFO - 2021-02-27 02:38:40 --> Output Class Initialized
INFO - 2021-02-27 02:38:40 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:40 --> Input Class Initialized
INFO - 2021-02-27 02:38:40 --> Language Class Initialized
INFO - 2021-02-27 02:38:40 --> Language Class Initialized
INFO - 2021-02-27 02:38:40 --> Config Class Initialized
INFO - 2021-02-27 02:38:40 --> Loader Class Initialized
INFO - 2021-02-27 02:38:40 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:40 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:40 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:40 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:41 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:41 --> Controller Class Initialized
INFO - 2021-02-27 02:38:42 --> Config Class Initialized
INFO - 2021-02-27 02:38:42 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:42 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:42 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:42 --> URI Class Initialized
INFO - 2021-02-27 02:38:42 --> Router Class Initialized
INFO - 2021-02-27 02:38:42 --> Output Class Initialized
INFO - 2021-02-27 02:38:42 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:42 --> Input Class Initialized
INFO - 2021-02-27 02:38:42 --> Language Class Initialized
INFO - 2021-02-27 02:38:42 --> Language Class Initialized
INFO - 2021-02-27 02:38:42 --> Config Class Initialized
INFO - 2021-02-27 02:38:42 --> Loader Class Initialized
INFO - 2021-02-27 02:38:42 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:42 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:42 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:42 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:42 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:42 --> Controller Class Initialized
INFO - 2021-02-27 02:38:42 --> Final output sent to browser
DEBUG - 2021-02-27 02:38:42 --> Total execution time: 0.2412
INFO - 2021-02-27 02:38:46 --> Config Class Initialized
INFO - 2021-02-27 02:38:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:46 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:46 --> URI Class Initialized
INFO - 2021-02-27 02:38:46 --> Router Class Initialized
INFO - 2021-02-27 02:38:46 --> Output Class Initialized
INFO - 2021-02-27 02:38:46 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:46 --> Input Class Initialized
INFO - 2021-02-27 02:38:46 --> Language Class Initialized
INFO - 2021-02-27 02:38:46 --> Language Class Initialized
INFO - 2021-02-27 02:38:46 --> Config Class Initialized
INFO - 2021-02-27 02:38:46 --> Loader Class Initialized
INFO - 2021-02-27 02:38:46 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:46 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:46 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:46 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:46 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:46 --> Controller Class Initialized
INFO - 2021-02-27 02:38:46 --> Final output sent to browser
DEBUG - 2021-02-27 02:38:46 --> Total execution time: 0.2432
INFO - 2021-02-27 02:38:47 --> Config Class Initialized
INFO - 2021-02-27 02:38:47 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:47 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:48 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:48 --> URI Class Initialized
INFO - 2021-02-27 02:38:48 --> Router Class Initialized
INFO - 2021-02-27 02:38:48 --> Output Class Initialized
INFO - 2021-02-27 02:38:48 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:48 --> Input Class Initialized
INFO - 2021-02-27 02:38:48 --> Language Class Initialized
INFO - 2021-02-27 02:38:48 --> Language Class Initialized
INFO - 2021-02-27 02:38:48 --> Config Class Initialized
INFO - 2021-02-27 02:38:48 --> Loader Class Initialized
INFO - 2021-02-27 02:38:48 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:48 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:48 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:48 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:48 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:48 --> Controller Class Initialized
INFO - 2021-02-27 02:38:48 --> Final output sent to browser
DEBUG - 2021-02-27 02:38:48 --> Total execution time: 0.2282
INFO - 2021-02-27 02:38:49 --> Config Class Initialized
INFO - 2021-02-27 02:38:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:49 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:49 --> URI Class Initialized
INFO - 2021-02-27 02:38:49 --> Router Class Initialized
INFO - 2021-02-27 02:38:49 --> Output Class Initialized
INFO - 2021-02-27 02:38:49 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:49 --> Input Class Initialized
INFO - 2021-02-27 02:38:49 --> Language Class Initialized
INFO - 2021-02-27 02:38:49 --> Language Class Initialized
INFO - 2021-02-27 02:38:49 --> Config Class Initialized
INFO - 2021-02-27 02:38:49 --> Loader Class Initialized
INFO - 2021-02-27 02:38:50 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:50 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:50 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:50 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:50 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:50 --> Controller Class Initialized
INFO - 2021-02-27 02:38:50 --> Final output sent to browser
DEBUG - 2021-02-27 02:38:50 --> Total execution time: 0.2562
INFO - 2021-02-27 02:38:55 --> Config Class Initialized
INFO - 2021-02-27 02:38:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:55 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:55 --> URI Class Initialized
INFO - 2021-02-27 02:38:55 --> Router Class Initialized
INFO - 2021-02-27 02:38:55 --> Output Class Initialized
INFO - 2021-02-27 02:38:55 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:55 --> Input Class Initialized
INFO - 2021-02-27 02:38:55 --> Language Class Initialized
INFO - 2021-02-27 02:38:55 --> Language Class Initialized
INFO - 2021-02-27 02:38:55 --> Config Class Initialized
INFO - 2021-02-27 02:38:55 --> Loader Class Initialized
INFO - 2021-02-27 02:38:55 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:55 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:55 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:55 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:55 --> Controller Class Initialized
DEBUG - 2021-02-27 02:38:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-02-27 02:38:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:38:55 --> Final output sent to browser
DEBUG - 2021-02-27 02:38:55 --> Total execution time: 0.3168
INFO - 2021-02-27 02:38:56 --> Config Class Initialized
INFO - 2021-02-27 02:38:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:56 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:56 --> URI Class Initialized
INFO - 2021-02-27 02:38:56 --> Router Class Initialized
INFO - 2021-02-27 02:38:56 --> Output Class Initialized
INFO - 2021-02-27 02:38:56 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:56 --> Input Class Initialized
INFO - 2021-02-27 02:38:56 --> Language Class Initialized
INFO - 2021-02-27 02:38:56 --> Language Class Initialized
INFO - 2021-02-27 02:38:56 --> Config Class Initialized
INFO - 2021-02-27 02:38:56 --> Loader Class Initialized
INFO - 2021-02-27 02:38:56 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:56 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:57 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:57 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:57 --> Controller Class Initialized
DEBUG - 2021-02-27 02:38:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-02-27 02:38:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:38:57 --> Final output sent to browser
DEBUG - 2021-02-27 02:38:57 --> Total execution time: 0.3299
INFO - 2021-02-27 02:38:58 --> Config Class Initialized
INFO - 2021-02-27 02:38:58 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:38:58 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:38:58 --> Utf8 Class Initialized
INFO - 2021-02-27 02:38:58 --> URI Class Initialized
INFO - 2021-02-27 02:38:58 --> Router Class Initialized
INFO - 2021-02-27 02:38:58 --> Output Class Initialized
INFO - 2021-02-27 02:38:58 --> Security Class Initialized
DEBUG - 2021-02-27 02:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:38:58 --> Input Class Initialized
INFO - 2021-02-27 02:38:58 --> Language Class Initialized
INFO - 2021-02-27 02:38:58 --> Language Class Initialized
INFO - 2021-02-27 02:38:58 --> Config Class Initialized
INFO - 2021-02-27 02:38:58 --> Loader Class Initialized
INFO - 2021-02-27 02:38:58 --> Helper loaded: url_helper
INFO - 2021-02-27 02:38:58 --> Helper loaded: file_helper
INFO - 2021-02-27 02:38:58 --> Helper loaded: form_helper
INFO - 2021-02-27 02:38:58 --> Helper loaded: my_helper
INFO - 2021-02-27 02:38:58 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:38:58 --> Controller Class Initialized
INFO - 2021-02-27 02:38:58 --> Final output sent to browser
DEBUG - 2021-02-27 02:38:58 --> Total execution time: 0.2762
INFO - 2021-02-27 02:39:03 --> Config Class Initialized
INFO - 2021-02-27 02:39:03 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:39:03 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:39:03 --> Utf8 Class Initialized
INFO - 2021-02-27 02:39:03 --> URI Class Initialized
INFO - 2021-02-27 02:39:03 --> Router Class Initialized
INFO - 2021-02-27 02:39:03 --> Output Class Initialized
INFO - 2021-02-27 02:39:03 --> Security Class Initialized
DEBUG - 2021-02-27 02:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:39:03 --> Input Class Initialized
INFO - 2021-02-27 02:39:03 --> Language Class Initialized
INFO - 2021-02-27 02:39:03 --> Language Class Initialized
INFO - 2021-02-27 02:39:03 --> Config Class Initialized
INFO - 2021-02-27 02:39:03 --> Loader Class Initialized
INFO - 2021-02-27 02:39:03 --> Helper loaded: url_helper
INFO - 2021-02-27 02:39:03 --> Helper loaded: file_helper
INFO - 2021-02-27 02:39:03 --> Helper loaded: form_helper
INFO - 2021-02-27 02:39:03 --> Helper loaded: my_helper
INFO - 2021-02-27 02:39:04 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:39:04 --> Controller Class Initialized
DEBUG - 2021-02-27 02:39:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-02-27 02:39:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:39:04 --> Final output sent to browser
DEBUG - 2021-02-27 02:39:04 --> Total execution time: 0.2939
INFO - 2021-02-27 02:39:14 --> Config Class Initialized
INFO - 2021-02-27 02:39:14 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:39:14 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:39:14 --> Utf8 Class Initialized
INFO - 2021-02-27 02:39:14 --> URI Class Initialized
INFO - 2021-02-27 02:39:14 --> Router Class Initialized
INFO - 2021-02-27 02:39:14 --> Output Class Initialized
INFO - 2021-02-27 02:39:14 --> Security Class Initialized
DEBUG - 2021-02-27 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:39:14 --> Input Class Initialized
INFO - 2021-02-27 02:39:14 --> Language Class Initialized
INFO - 2021-02-27 02:39:14 --> Language Class Initialized
INFO - 2021-02-27 02:39:14 --> Config Class Initialized
INFO - 2021-02-27 02:39:14 --> Loader Class Initialized
INFO - 2021-02-27 02:39:14 --> Helper loaded: url_helper
INFO - 2021-02-27 02:39:14 --> Helper loaded: file_helper
INFO - 2021-02-27 02:39:14 --> Helper loaded: form_helper
INFO - 2021-02-27 02:39:14 --> Helper loaded: my_helper
INFO - 2021-02-27 02:39:14 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:39:14 --> Controller Class Initialized
DEBUG - 2021-02-27 02:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-27 02:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:39:14 --> Final output sent to browser
DEBUG - 2021-02-27 02:39:14 --> Total execution time: 0.3395
INFO - 2021-02-27 02:39:19 --> Config Class Initialized
INFO - 2021-02-27 02:39:19 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:39:19 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:39:19 --> Utf8 Class Initialized
INFO - 2021-02-27 02:39:19 --> URI Class Initialized
INFO - 2021-02-27 02:39:19 --> Router Class Initialized
INFO - 2021-02-27 02:39:19 --> Output Class Initialized
INFO - 2021-02-27 02:39:19 --> Security Class Initialized
DEBUG - 2021-02-27 02:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:39:19 --> Input Class Initialized
INFO - 2021-02-27 02:39:19 --> Language Class Initialized
INFO - 2021-02-27 02:39:19 --> Language Class Initialized
INFO - 2021-02-27 02:39:19 --> Config Class Initialized
INFO - 2021-02-27 02:39:19 --> Loader Class Initialized
INFO - 2021-02-27 02:39:19 --> Helper loaded: url_helper
INFO - 2021-02-27 02:39:19 --> Helper loaded: file_helper
INFO - 2021-02-27 02:39:19 --> Helper loaded: form_helper
INFO - 2021-02-27 02:39:19 --> Helper loaded: my_helper
INFO - 2021-02-27 02:39:19 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:39:19 --> Controller Class Initialized
DEBUG - 2021-02-27 02:39:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-27 02:39:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:39:19 --> Final output sent to browser
DEBUG - 2021-02-27 02:39:19 --> Total execution time: 0.3325
INFO - 2021-02-27 02:39:22 --> Config Class Initialized
INFO - 2021-02-27 02:39:22 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:39:22 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:39:22 --> Utf8 Class Initialized
INFO - 2021-02-27 02:39:22 --> URI Class Initialized
INFO - 2021-02-27 02:39:22 --> Router Class Initialized
INFO - 2021-02-27 02:39:22 --> Output Class Initialized
INFO - 2021-02-27 02:39:22 --> Security Class Initialized
DEBUG - 2021-02-27 02:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:39:22 --> Input Class Initialized
INFO - 2021-02-27 02:39:22 --> Language Class Initialized
INFO - 2021-02-27 02:39:22 --> Language Class Initialized
INFO - 2021-02-27 02:39:22 --> Config Class Initialized
INFO - 2021-02-27 02:39:22 --> Loader Class Initialized
INFO - 2021-02-27 02:39:22 --> Helper loaded: url_helper
INFO - 2021-02-27 02:39:22 --> Helper loaded: file_helper
INFO - 2021-02-27 02:39:22 --> Helper loaded: form_helper
INFO - 2021-02-27 02:39:22 --> Helper loaded: my_helper
INFO - 2021-02-27 02:39:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:39:22 --> Controller Class Initialized
DEBUG - 2021-02-27 02:39:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-27 02:39:22 --> Final output sent to browser
DEBUG - 2021-02-27 02:39:22 --> Total execution time: 0.3148
INFO - 2021-02-27 02:39:24 --> Config Class Initialized
INFO - 2021-02-27 02:39:24 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:39:24 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:39:24 --> Utf8 Class Initialized
INFO - 2021-02-27 02:39:24 --> URI Class Initialized
INFO - 2021-02-27 02:39:24 --> Router Class Initialized
INFO - 2021-02-27 02:39:24 --> Output Class Initialized
INFO - 2021-02-27 02:39:24 --> Security Class Initialized
DEBUG - 2021-02-27 02:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:39:24 --> Input Class Initialized
INFO - 2021-02-27 02:39:24 --> Language Class Initialized
INFO - 2021-02-27 02:39:24 --> Language Class Initialized
INFO - 2021-02-27 02:39:24 --> Config Class Initialized
INFO - 2021-02-27 02:39:25 --> Loader Class Initialized
INFO - 2021-02-27 02:39:25 --> Helper loaded: url_helper
INFO - 2021-02-27 02:39:25 --> Helper loaded: file_helper
INFO - 2021-02-27 02:39:25 --> Helper loaded: form_helper
INFO - 2021-02-27 02:39:25 --> Helper loaded: my_helper
INFO - 2021-02-27 02:39:25 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:39:25 --> Controller Class Initialized
DEBUG - 2021-02-27 02:39:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-02-27 02:39:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:39:25 --> Final output sent to browser
DEBUG - 2021-02-27 02:39:25 --> Total execution time: 0.4445
INFO - 2021-02-27 02:43:04 --> Config Class Initialized
INFO - 2021-02-27 02:43:04 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:43:04 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:43:04 --> Utf8 Class Initialized
INFO - 2021-02-27 02:43:04 --> URI Class Initialized
INFO - 2021-02-27 02:43:04 --> Router Class Initialized
INFO - 2021-02-27 02:43:04 --> Output Class Initialized
INFO - 2021-02-27 02:43:04 --> Security Class Initialized
DEBUG - 2021-02-27 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:43:04 --> Input Class Initialized
INFO - 2021-02-27 02:43:04 --> Language Class Initialized
INFO - 2021-02-27 02:43:04 --> Language Class Initialized
INFO - 2021-02-27 02:43:04 --> Config Class Initialized
INFO - 2021-02-27 02:43:04 --> Loader Class Initialized
INFO - 2021-02-27 02:43:04 --> Helper loaded: url_helper
INFO - 2021-02-27 02:43:04 --> Helper loaded: file_helper
INFO - 2021-02-27 02:43:04 --> Helper loaded: form_helper
INFO - 2021-02-27 02:43:04 --> Helper loaded: my_helper
INFO - 2021-02-27 02:43:04 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:43:04 --> Controller Class Initialized
DEBUG - 2021-02-27 02:43:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-02-27 02:43:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:43:04 --> Final output sent to browser
DEBUG - 2021-02-27 02:43:04 --> Total execution time: 0.3451
INFO - 2021-02-27 02:43:13 --> Config Class Initialized
INFO - 2021-02-27 02:43:13 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:43:13 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:43:13 --> Utf8 Class Initialized
INFO - 2021-02-27 02:43:13 --> URI Class Initialized
INFO - 2021-02-27 02:43:13 --> Router Class Initialized
INFO - 2021-02-27 02:43:13 --> Output Class Initialized
INFO - 2021-02-27 02:43:13 --> Security Class Initialized
DEBUG - 2021-02-27 02:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:43:13 --> Input Class Initialized
INFO - 2021-02-27 02:43:13 --> Language Class Initialized
INFO - 2021-02-27 02:43:13 --> Language Class Initialized
INFO - 2021-02-27 02:43:13 --> Config Class Initialized
INFO - 2021-02-27 02:43:13 --> Loader Class Initialized
INFO - 2021-02-27 02:43:13 --> Helper loaded: url_helper
INFO - 2021-02-27 02:43:13 --> Helper loaded: file_helper
INFO - 2021-02-27 02:43:13 --> Helper loaded: form_helper
INFO - 2021-02-27 02:43:13 --> Helper loaded: my_helper
INFO - 2021-02-27 02:43:13 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:43:13 --> Controller Class Initialized
DEBUG - 2021-02-27 02:43:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-02-27 02:43:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:43:13 --> Final output sent to browser
DEBUG - 2021-02-27 02:43:13 --> Total execution time: 0.2991
INFO - 2021-02-27 02:43:18 --> Config Class Initialized
INFO - 2021-02-27 02:43:18 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:43:18 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:43:18 --> Utf8 Class Initialized
INFO - 2021-02-27 02:43:18 --> URI Class Initialized
INFO - 2021-02-27 02:43:18 --> Router Class Initialized
INFO - 2021-02-27 02:43:18 --> Output Class Initialized
INFO - 2021-02-27 02:43:18 --> Security Class Initialized
DEBUG - 2021-02-27 02:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:43:18 --> Input Class Initialized
INFO - 2021-02-27 02:43:18 --> Language Class Initialized
INFO - 2021-02-27 02:43:18 --> Language Class Initialized
INFO - 2021-02-27 02:43:18 --> Config Class Initialized
INFO - 2021-02-27 02:43:18 --> Loader Class Initialized
INFO - 2021-02-27 02:43:18 --> Helper loaded: url_helper
INFO - 2021-02-27 02:43:18 --> Helper loaded: file_helper
INFO - 2021-02-27 02:43:18 --> Helper loaded: form_helper
INFO - 2021-02-27 02:43:19 --> Helper loaded: my_helper
INFO - 2021-02-27 02:43:19 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:43:19 --> Controller Class Initialized
INFO - 2021-02-27 02:43:19 --> Final output sent to browser
DEBUG - 2021-02-27 02:43:19 --> Total execution time: 0.2488
INFO - 2021-02-27 02:43:39 --> Config Class Initialized
INFO - 2021-02-27 02:43:39 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:43:39 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:43:39 --> Utf8 Class Initialized
INFO - 2021-02-27 02:43:39 --> URI Class Initialized
INFO - 2021-02-27 02:43:39 --> Router Class Initialized
INFO - 2021-02-27 02:43:39 --> Output Class Initialized
INFO - 2021-02-27 02:43:39 --> Security Class Initialized
DEBUG - 2021-02-27 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:43:40 --> Input Class Initialized
INFO - 2021-02-27 02:43:40 --> Language Class Initialized
INFO - 2021-02-27 02:43:40 --> Language Class Initialized
INFO - 2021-02-27 02:43:40 --> Config Class Initialized
INFO - 2021-02-27 02:43:40 --> Loader Class Initialized
INFO - 2021-02-27 02:43:40 --> Helper loaded: url_helper
INFO - 2021-02-27 02:43:40 --> Helper loaded: file_helper
INFO - 2021-02-27 02:43:40 --> Helper loaded: form_helper
INFO - 2021-02-27 02:43:40 --> Helper loaded: my_helper
INFO - 2021-02-27 02:43:40 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:43:40 --> Controller Class Initialized
INFO - 2021-02-27 02:43:40 --> Final output sent to browser
DEBUG - 2021-02-27 02:43:40 --> Total execution time: 0.2621
INFO - 2021-02-27 02:43:55 --> Config Class Initialized
INFO - 2021-02-27 02:43:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:43:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:43:55 --> Utf8 Class Initialized
INFO - 2021-02-27 02:43:55 --> URI Class Initialized
INFO - 2021-02-27 02:43:55 --> Router Class Initialized
INFO - 2021-02-27 02:43:55 --> Output Class Initialized
INFO - 2021-02-27 02:43:55 --> Security Class Initialized
DEBUG - 2021-02-27 02:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:43:55 --> Input Class Initialized
INFO - 2021-02-27 02:43:55 --> Language Class Initialized
INFO - 2021-02-27 02:43:55 --> Language Class Initialized
INFO - 2021-02-27 02:43:55 --> Config Class Initialized
INFO - 2021-02-27 02:43:55 --> Loader Class Initialized
INFO - 2021-02-27 02:43:55 --> Helper loaded: url_helper
INFO - 2021-02-27 02:43:55 --> Helper loaded: file_helper
INFO - 2021-02-27 02:43:55 --> Helper loaded: form_helper
INFO - 2021-02-27 02:43:55 --> Helper loaded: my_helper
INFO - 2021-02-27 02:43:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:43:55 --> Controller Class Initialized
DEBUG - 2021-02-27 02:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-02-27 02:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:43:55 --> Final output sent to browser
DEBUG - 2021-02-27 02:43:55 --> Total execution time: 0.3847
INFO - 2021-02-27 02:44:23 --> Config Class Initialized
INFO - 2021-02-27 02:44:23 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:44:23 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:44:23 --> Utf8 Class Initialized
INFO - 2021-02-27 02:44:23 --> URI Class Initialized
INFO - 2021-02-27 02:44:23 --> Router Class Initialized
INFO - 2021-02-27 02:44:23 --> Output Class Initialized
INFO - 2021-02-27 02:44:23 --> Security Class Initialized
DEBUG - 2021-02-27 02:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:44:23 --> Input Class Initialized
INFO - 2021-02-27 02:44:23 --> Language Class Initialized
INFO - 2021-02-27 02:44:23 --> Language Class Initialized
INFO - 2021-02-27 02:44:23 --> Config Class Initialized
INFO - 2021-02-27 02:44:23 --> Loader Class Initialized
INFO - 2021-02-27 02:44:23 --> Helper loaded: url_helper
INFO - 2021-02-27 02:44:23 --> Helper loaded: file_helper
INFO - 2021-02-27 02:44:23 --> Helper loaded: form_helper
INFO - 2021-02-27 02:44:23 --> Helper loaded: my_helper
INFO - 2021-02-27 02:44:23 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:44:23 --> Controller Class Initialized
DEBUG - 2021-02-27 02:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-02-27 02:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:44:23 --> Final output sent to browser
DEBUG - 2021-02-27 02:44:23 --> Total execution time: 0.3039
INFO - 2021-02-27 02:44:25 --> Config Class Initialized
INFO - 2021-02-27 02:44:25 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:44:25 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:44:25 --> Utf8 Class Initialized
INFO - 2021-02-27 02:44:25 --> URI Class Initialized
INFO - 2021-02-27 02:44:25 --> Router Class Initialized
INFO - 2021-02-27 02:44:25 --> Output Class Initialized
INFO - 2021-02-27 02:44:25 --> Security Class Initialized
DEBUG - 2021-02-27 02:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:44:25 --> Input Class Initialized
INFO - 2021-02-27 02:44:25 --> Language Class Initialized
INFO - 2021-02-27 02:44:25 --> Language Class Initialized
INFO - 2021-02-27 02:44:25 --> Config Class Initialized
INFO - 2021-02-27 02:44:25 --> Loader Class Initialized
INFO - 2021-02-27 02:44:25 --> Helper loaded: url_helper
INFO - 2021-02-27 02:44:26 --> Helper loaded: file_helper
INFO - 2021-02-27 02:44:26 --> Helper loaded: form_helper
INFO - 2021-02-27 02:44:26 --> Helper loaded: my_helper
INFO - 2021-02-27 02:44:26 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:44:26 --> Controller Class Initialized
DEBUG - 2021-02-27 02:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2021-02-27 02:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:44:26 --> Final output sent to browser
DEBUG - 2021-02-27 02:44:26 --> Total execution time: 0.3322
INFO - 2021-02-27 02:44:44 --> Config Class Initialized
INFO - 2021-02-27 02:44:44 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:44:44 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:44:44 --> Utf8 Class Initialized
INFO - 2021-02-27 02:44:44 --> URI Class Initialized
INFO - 2021-02-27 02:44:44 --> Router Class Initialized
INFO - 2021-02-27 02:44:44 --> Output Class Initialized
INFO - 2021-02-27 02:44:44 --> Security Class Initialized
DEBUG - 2021-02-27 02:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:44:44 --> Input Class Initialized
INFO - 2021-02-27 02:44:44 --> Language Class Initialized
INFO - 2021-02-27 02:44:44 --> Language Class Initialized
INFO - 2021-02-27 02:44:44 --> Config Class Initialized
INFO - 2021-02-27 02:44:44 --> Loader Class Initialized
INFO - 2021-02-27 02:44:44 --> Helper loaded: url_helper
INFO - 2021-02-27 02:44:44 --> Helper loaded: file_helper
INFO - 2021-02-27 02:44:44 --> Helper loaded: form_helper
INFO - 2021-02-27 02:44:44 --> Helper loaded: my_helper
INFO - 2021-02-27 02:44:44 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:44:44 --> Controller Class Initialized
DEBUG - 2021-02-27 02:44:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-02-27 02:44:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:44:44 --> Final output sent to browser
DEBUG - 2021-02-27 02:44:44 --> Total execution time: 0.3297
INFO - 2021-02-27 02:44:49 --> Config Class Initialized
INFO - 2021-02-27 02:44:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:44:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:44:49 --> Utf8 Class Initialized
INFO - 2021-02-27 02:44:49 --> URI Class Initialized
INFO - 2021-02-27 02:44:49 --> Router Class Initialized
INFO - 2021-02-27 02:44:49 --> Output Class Initialized
INFO - 2021-02-27 02:44:49 --> Security Class Initialized
DEBUG - 2021-02-27 02:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:44:49 --> Input Class Initialized
INFO - 2021-02-27 02:44:49 --> Language Class Initialized
INFO - 2021-02-27 02:44:49 --> Language Class Initialized
INFO - 2021-02-27 02:44:49 --> Config Class Initialized
INFO - 2021-02-27 02:44:49 --> Loader Class Initialized
INFO - 2021-02-27 02:44:49 --> Helper loaded: url_helper
INFO - 2021-02-27 02:44:49 --> Helper loaded: file_helper
INFO - 2021-02-27 02:44:49 --> Helper loaded: form_helper
INFO - 2021-02-27 02:44:49 --> Helper loaded: my_helper
INFO - 2021-02-27 02:44:49 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:44:50 --> Controller Class Initialized
DEBUG - 2021-02-27 02:44:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-02-27 02:44:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:44:50 --> Final output sent to browser
DEBUG - 2021-02-27 02:44:50 --> Total execution time: 0.2984
INFO - 2021-02-27 02:44:57 --> Config Class Initialized
INFO - 2021-02-27 02:44:57 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:44:57 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:44:57 --> Utf8 Class Initialized
INFO - 2021-02-27 02:44:57 --> URI Class Initialized
INFO - 2021-02-27 02:44:57 --> Router Class Initialized
INFO - 2021-02-27 02:44:57 --> Output Class Initialized
INFO - 2021-02-27 02:44:57 --> Security Class Initialized
DEBUG - 2021-02-27 02:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:44:57 --> Input Class Initialized
INFO - 2021-02-27 02:44:57 --> Language Class Initialized
INFO - 2021-02-27 02:44:57 --> Language Class Initialized
INFO - 2021-02-27 02:44:57 --> Config Class Initialized
INFO - 2021-02-27 02:44:57 --> Loader Class Initialized
INFO - 2021-02-27 02:44:57 --> Helper loaded: url_helper
INFO - 2021-02-27 02:44:57 --> Helper loaded: file_helper
INFO - 2021-02-27 02:44:57 --> Helper loaded: form_helper
INFO - 2021-02-27 02:44:57 --> Helper loaded: my_helper
INFO - 2021-02-27 02:44:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:44:57 --> Controller Class Initialized
DEBUG - 2021-02-27 02:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-02-27 02:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:44:57 --> Final output sent to browser
DEBUG - 2021-02-27 02:44:57 --> Total execution time: 0.3213
INFO - 2021-02-27 02:44:58 --> Config Class Initialized
INFO - 2021-02-27 02:44:58 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:44:59 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:44:59 --> Utf8 Class Initialized
INFO - 2021-02-27 02:44:59 --> URI Class Initialized
INFO - 2021-02-27 02:44:59 --> Router Class Initialized
INFO - 2021-02-27 02:44:59 --> Output Class Initialized
INFO - 2021-02-27 02:44:59 --> Security Class Initialized
DEBUG - 2021-02-27 02:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:44:59 --> Input Class Initialized
INFO - 2021-02-27 02:44:59 --> Language Class Initialized
INFO - 2021-02-27 02:44:59 --> Language Class Initialized
INFO - 2021-02-27 02:44:59 --> Config Class Initialized
INFO - 2021-02-27 02:44:59 --> Loader Class Initialized
INFO - 2021-02-27 02:44:59 --> Helper loaded: url_helper
INFO - 2021-02-27 02:44:59 --> Helper loaded: file_helper
INFO - 2021-02-27 02:44:59 --> Helper loaded: form_helper
INFO - 2021-02-27 02:44:59 --> Helper loaded: my_helper
INFO - 2021-02-27 02:44:59 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:44:59 --> Controller Class Initialized
DEBUG - 2021-02-27 02:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-27 02:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:44:59 --> Final output sent to browser
DEBUG - 2021-02-27 02:44:59 --> Total execution time: 0.2802
INFO - 2021-02-27 02:45:05 --> Config Class Initialized
INFO - 2021-02-27 02:45:05 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:45:05 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:45:05 --> Utf8 Class Initialized
INFO - 2021-02-27 02:45:05 --> URI Class Initialized
INFO - 2021-02-27 02:45:05 --> Router Class Initialized
INFO - 2021-02-27 02:45:05 --> Output Class Initialized
INFO - 2021-02-27 02:45:05 --> Security Class Initialized
DEBUG - 2021-02-27 02:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:45:05 --> Input Class Initialized
INFO - 2021-02-27 02:45:05 --> Language Class Initialized
INFO - 2021-02-27 02:45:05 --> Language Class Initialized
INFO - 2021-02-27 02:45:05 --> Config Class Initialized
INFO - 2021-02-27 02:45:05 --> Loader Class Initialized
INFO - 2021-02-27 02:45:05 --> Helper loaded: url_helper
INFO - 2021-02-27 02:45:05 --> Helper loaded: file_helper
INFO - 2021-02-27 02:45:05 --> Helper loaded: form_helper
INFO - 2021-02-27 02:45:05 --> Helper loaded: my_helper
INFO - 2021-02-27 02:45:05 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:45:05 --> Controller Class Initialized
DEBUG - 2021-02-27 02:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-27 02:45:05 --> Final output sent to browser
DEBUG - 2021-02-27 02:45:05 --> Total execution time: 0.3611
INFO - 2021-02-27 02:45:17 --> Config Class Initialized
INFO - 2021-02-27 02:45:17 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:45:17 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:45:17 --> Utf8 Class Initialized
INFO - 2021-02-27 02:45:17 --> URI Class Initialized
INFO - 2021-02-27 02:45:17 --> Router Class Initialized
INFO - 2021-02-27 02:45:17 --> Output Class Initialized
INFO - 2021-02-27 02:45:17 --> Security Class Initialized
DEBUG - 2021-02-27 02:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:45:17 --> Input Class Initialized
INFO - 2021-02-27 02:45:18 --> Language Class Initialized
INFO - 2021-02-27 02:45:18 --> Language Class Initialized
INFO - 2021-02-27 02:45:18 --> Config Class Initialized
INFO - 2021-02-27 02:45:18 --> Loader Class Initialized
INFO - 2021-02-27 02:45:18 --> Helper loaded: url_helper
INFO - 2021-02-27 02:45:18 --> Helper loaded: file_helper
INFO - 2021-02-27 02:45:18 --> Helper loaded: form_helper
INFO - 2021-02-27 02:45:18 --> Helper loaded: my_helper
INFO - 2021-02-27 02:45:18 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:45:18 --> Controller Class Initialized
DEBUG - 2021-02-27 02:45:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-27 02:45:18 --> Final output sent to browser
DEBUG - 2021-02-27 02:45:18 --> Total execution time: 0.3446
INFO - 2021-02-27 02:45:28 --> Config Class Initialized
INFO - 2021-02-27 02:45:28 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:45:28 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:45:28 --> Utf8 Class Initialized
INFO - 2021-02-27 02:45:28 --> URI Class Initialized
INFO - 2021-02-27 02:45:28 --> Router Class Initialized
INFO - 2021-02-27 02:45:28 --> Output Class Initialized
INFO - 2021-02-27 02:45:28 --> Security Class Initialized
DEBUG - 2021-02-27 02:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:45:28 --> Input Class Initialized
INFO - 2021-02-27 02:45:28 --> Language Class Initialized
INFO - 2021-02-27 02:45:28 --> Language Class Initialized
INFO - 2021-02-27 02:45:28 --> Config Class Initialized
INFO - 2021-02-27 02:45:28 --> Loader Class Initialized
INFO - 2021-02-27 02:45:28 --> Helper loaded: url_helper
INFO - 2021-02-27 02:45:28 --> Helper loaded: file_helper
INFO - 2021-02-27 02:45:28 --> Helper loaded: form_helper
INFO - 2021-02-27 02:45:28 --> Helper loaded: my_helper
INFO - 2021-02-27 02:45:28 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:45:28 --> Controller Class Initialized
DEBUG - 2021-02-27 02:45:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-02-27 02:45:28 --> Final output sent to browser
DEBUG - 2021-02-27 02:45:28 --> Total execution time: 0.3649
INFO - 2021-02-27 02:45:54 --> Config Class Initialized
INFO - 2021-02-27 02:45:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:45:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:45:54 --> Utf8 Class Initialized
INFO - 2021-02-27 02:45:54 --> URI Class Initialized
INFO - 2021-02-27 02:45:54 --> Router Class Initialized
INFO - 2021-02-27 02:45:54 --> Output Class Initialized
INFO - 2021-02-27 02:45:54 --> Security Class Initialized
DEBUG - 2021-02-27 02:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:45:54 --> Input Class Initialized
INFO - 2021-02-27 02:45:54 --> Language Class Initialized
INFO - 2021-02-27 02:45:54 --> Language Class Initialized
INFO - 2021-02-27 02:45:54 --> Config Class Initialized
INFO - 2021-02-27 02:45:54 --> Loader Class Initialized
INFO - 2021-02-27 02:45:54 --> Helper loaded: url_helper
INFO - 2021-02-27 02:45:54 --> Helper loaded: file_helper
INFO - 2021-02-27 02:45:54 --> Helper loaded: form_helper
INFO - 2021-02-27 02:45:54 --> Helper loaded: my_helper
INFO - 2021-02-27 02:45:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:45:55 --> Controller Class Initialized
DEBUG - 2021-02-27 02:45:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-02-27 02:45:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:45:55 --> Final output sent to browser
DEBUG - 2021-02-27 02:45:55 --> Total execution time: 0.3047
INFO - 2021-02-27 02:45:57 --> Config Class Initialized
INFO - 2021-02-27 02:45:57 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:45:57 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:45:57 --> Utf8 Class Initialized
INFO - 2021-02-27 02:45:57 --> URI Class Initialized
INFO - 2021-02-27 02:45:57 --> Router Class Initialized
INFO - 2021-02-27 02:45:57 --> Output Class Initialized
INFO - 2021-02-27 02:45:57 --> Security Class Initialized
DEBUG - 2021-02-27 02:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:45:57 --> Input Class Initialized
INFO - 2021-02-27 02:45:57 --> Language Class Initialized
INFO - 2021-02-27 02:45:57 --> Language Class Initialized
INFO - 2021-02-27 02:45:57 --> Config Class Initialized
INFO - 2021-02-27 02:45:57 --> Loader Class Initialized
INFO - 2021-02-27 02:45:57 --> Helper loaded: url_helper
INFO - 2021-02-27 02:45:57 --> Helper loaded: file_helper
INFO - 2021-02-27 02:45:57 --> Helper loaded: form_helper
INFO - 2021-02-27 02:45:57 --> Helper loaded: my_helper
INFO - 2021-02-27 02:45:57 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:45:57 --> Controller Class Initialized
DEBUG - 2021-02-27 02:45:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-02-27 02:45:57 --> Final output sent to browser
DEBUG - 2021-02-27 02:45:57 --> Total execution time: 0.3423
INFO - 2021-02-27 02:46:24 --> Config Class Initialized
INFO - 2021-02-27 02:46:24 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:46:24 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:46:24 --> Utf8 Class Initialized
INFO - 2021-02-27 02:46:24 --> URI Class Initialized
INFO - 2021-02-27 02:46:24 --> Router Class Initialized
INFO - 2021-02-27 02:46:24 --> Output Class Initialized
INFO - 2021-02-27 02:46:24 --> Security Class Initialized
DEBUG - 2021-02-27 02:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:46:24 --> Input Class Initialized
INFO - 2021-02-27 02:46:24 --> Language Class Initialized
INFO - 2021-02-27 02:46:24 --> Language Class Initialized
INFO - 2021-02-27 02:46:24 --> Config Class Initialized
INFO - 2021-02-27 02:46:24 --> Loader Class Initialized
INFO - 2021-02-27 02:46:24 --> Helper loaded: url_helper
INFO - 2021-02-27 02:46:24 --> Helper loaded: file_helper
INFO - 2021-02-27 02:46:24 --> Helper loaded: form_helper
INFO - 2021-02-27 02:46:24 --> Helper loaded: my_helper
INFO - 2021-02-27 02:46:24 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:46:24 --> Controller Class Initialized
DEBUG - 2021-02-27 02:46:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-27 02:46:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:46:24 --> Final output sent to browser
DEBUG - 2021-02-27 02:46:24 --> Total execution time: 0.3710
INFO - 2021-02-27 02:46:25 --> Config Class Initialized
INFO - 2021-02-27 02:46:25 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:46:25 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:46:25 --> Utf8 Class Initialized
INFO - 2021-02-27 02:46:25 --> URI Class Initialized
INFO - 2021-02-27 02:46:25 --> Router Class Initialized
INFO - 2021-02-27 02:46:25 --> Output Class Initialized
INFO - 2021-02-27 02:46:25 --> Security Class Initialized
DEBUG - 2021-02-27 02:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:46:25 --> Input Class Initialized
INFO - 2021-02-27 02:46:26 --> Language Class Initialized
INFO - 2021-02-27 02:46:26 --> Language Class Initialized
INFO - 2021-02-27 02:46:26 --> Config Class Initialized
INFO - 2021-02-27 02:46:26 --> Loader Class Initialized
INFO - 2021-02-27 02:46:26 --> Helper loaded: url_helper
INFO - 2021-02-27 02:46:26 --> Helper loaded: file_helper
INFO - 2021-02-27 02:46:26 --> Helper loaded: form_helper
INFO - 2021-02-27 02:46:26 --> Helper loaded: my_helper
INFO - 2021-02-27 02:46:26 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:46:26 --> Controller Class Initialized
DEBUG - 2021-02-27 02:46:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-02-27 02:46:26 --> Final output sent to browser
DEBUG - 2021-02-27 02:46:26 --> Total execution time: 0.3511
INFO - 2021-02-27 02:46:49 --> Config Class Initialized
INFO - 2021-02-27 02:46:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:46:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:46:49 --> Utf8 Class Initialized
INFO - 2021-02-27 02:46:49 --> URI Class Initialized
INFO - 2021-02-27 02:46:49 --> Router Class Initialized
INFO - 2021-02-27 02:46:49 --> Output Class Initialized
INFO - 2021-02-27 02:46:49 --> Security Class Initialized
DEBUG - 2021-02-27 02:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:46:49 --> Input Class Initialized
INFO - 2021-02-27 02:46:49 --> Language Class Initialized
INFO - 2021-02-27 02:46:49 --> Language Class Initialized
INFO - 2021-02-27 02:46:49 --> Config Class Initialized
INFO - 2021-02-27 02:46:49 --> Loader Class Initialized
INFO - 2021-02-27 02:46:49 --> Helper loaded: url_helper
INFO - 2021-02-27 02:46:49 --> Helper loaded: file_helper
INFO - 2021-02-27 02:46:49 --> Helper loaded: form_helper
INFO - 2021-02-27 02:46:49 --> Helper loaded: my_helper
INFO - 2021-02-27 02:46:49 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:46:49 --> Controller Class Initialized
INFO - 2021-02-27 02:46:49 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:46:49 --> Config Class Initialized
INFO - 2021-02-27 02:46:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:46:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:46:49 --> Utf8 Class Initialized
INFO - 2021-02-27 02:46:49 --> URI Class Initialized
INFO - 2021-02-27 02:46:49 --> Router Class Initialized
INFO - 2021-02-27 02:46:49 --> Output Class Initialized
INFO - 2021-02-27 02:46:49 --> Security Class Initialized
DEBUG - 2021-02-27 02:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:46:49 --> Input Class Initialized
INFO - 2021-02-27 02:46:49 --> Language Class Initialized
INFO - 2021-02-27 02:46:49 --> Language Class Initialized
INFO - 2021-02-27 02:46:49 --> Config Class Initialized
INFO - 2021-02-27 02:46:49 --> Loader Class Initialized
INFO - 2021-02-27 02:46:49 --> Helper loaded: url_helper
INFO - 2021-02-27 02:46:49 --> Helper loaded: file_helper
INFO - 2021-02-27 02:46:49 --> Helper loaded: form_helper
INFO - 2021-02-27 02:46:49 --> Helper loaded: my_helper
INFO - 2021-02-27 02:46:49 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:46:50 --> Controller Class Initialized
DEBUG - 2021-02-27 02:46:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:46:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:46:50 --> Final output sent to browser
DEBUG - 2021-02-27 02:46:50 --> Total execution time: 0.3343
INFO - 2021-02-27 02:46:54 --> Config Class Initialized
INFO - 2021-02-27 02:46:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:46:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:46:54 --> Utf8 Class Initialized
INFO - 2021-02-27 02:46:54 --> URI Class Initialized
INFO - 2021-02-27 02:46:54 --> Router Class Initialized
INFO - 2021-02-27 02:46:54 --> Output Class Initialized
INFO - 2021-02-27 02:46:54 --> Security Class Initialized
DEBUG - 2021-02-27 02:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:46:54 --> Input Class Initialized
INFO - 2021-02-27 02:46:54 --> Language Class Initialized
INFO - 2021-02-27 02:46:54 --> Language Class Initialized
INFO - 2021-02-27 02:46:54 --> Config Class Initialized
INFO - 2021-02-27 02:46:54 --> Loader Class Initialized
INFO - 2021-02-27 02:46:54 --> Helper loaded: url_helper
INFO - 2021-02-27 02:46:54 --> Helper loaded: file_helper
INFO - 2021-02-27 02:46:54 --> Helper loaded: form_helper
INFO - 2021-02-27 02:46:54 --> Helper loaded: my_helper
INFO - 2021-02-27 02:46:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:46:54 --> Controller Class Initialized
INFO - 2021-02-27 02:46:54 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:46:54 --> Final output sent to browser
DEBUG - 2021-02-27 02:46:54 --> Total execution time: 0.3479
INFO - 2021-02-27 02:46:55 --> Config Class Initialized
INFO - 2021-02-27 02:46:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:46:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:46:55 --> Utf8 Class Initialized
INFO - 2021-02-27 02:46:55 --> URI Class Initialized
INFO - 2021-02-27 02:46:55 --> Router Class Initialized
INFO - 2021-02-27 02:46:55 --> Output Class Initialized
INFO - 2021-02-27 02:46:55 --> Security Class Initialized
DEBUG - 2021-02-27 02:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:46:55 --> Input Class Initialized
INFO - 2021-02-27 02:46:55 --> Language Class Initialized
INFO - 2021-02-27 02:46:55 --> Language Class Initialized
INFO - 2021-02-27 02:46:55 --> Config Class Initialized
INFO - 2021-02-27 02:46:55 --> Loader Class Initialized
INFO - 2021-02-27 02:46:55 --> Helper loaded: url_helper
INFO - 2021-02-27 02:46:55 --> Helper loaded: file_helper
INFO - 2021-02-27 02:46:55 --> Helper loaded: form_helper
INFO - 2021-02-27 02:46:55 --> Helper loaded: my_helper
INFO - 2021-02-27 02:46:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:46:55 --> Controller Class Initialized
DEBUG - 2021-02-27 02:46:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 02:46:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:46:55 --> Final output sent to browser
DEBUG - 2021-02-27 02:46:55 --> Total execution time: 0.4117
INFO - 2021-02-27 02:46:59 --> Config Class Initialized
INFO - 2021-02-27 02:47:00 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:47:00 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:47:00 --> Utf8 Class Initialized
INFO - 2021-02-27 02:47:00 --> URI Class Initialized
INFO - 2021-02-27 02:47:00 --> Router Class Initialized
INFO - 2021-02-27 02:47:00 --> Output Class Initialized
INFO - 2021-02-27 02:47:00 --> Security Class Initialized
DEBUG - 2021-02-27 02:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:47:00 --> Input Class Initialized
INFO - 2021-02-27 02:47:00 --> Language Class Initialized
INFO - 2021-02-27 02:47:00 --> Language Class Initialized
INFO - 2021-02-27 02:47:00 --> Config Class Initialized
INFO - 2021-02-27 02:47:00 --> Loader Class Initialized
INFO - 2021-02-27 02:47:00 --> Helper loaded: url_helper
INFO - 2021-02-27 02:47:00 --> Helper loaded: file_helper
INFO - 2021-02-27 02:47:00 --> Helper loaded: form_helper
INFO - 2021-02-27 02:47:00 --> Helper loaded: my_helper
INFO - 2021-02-27 02:47:00 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:47:00 --> Controller Class Initialized
DEBUG - 2021-02-27 02:47:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-27 02:47:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:47:00 --> Final output sent to browser
DEBUG - 2021-02-27 02:47:00 --> Total execution time: 0.3619
INFO - 2021-02-27 02:47:04 --> Config Class Initialized
INFO - 2021-02-27 02:47:04 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:47:04 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:47:04 --> Utf8 Class Initialized
INFO - 2021-02-27 02:47:04 --> URI Class Initialized
INFO - 2021-02-27 02:47:04 --> Router Class Initialized
INFO - 2021-02-27 02:47:04 --> Output Class Initialized
INFO - 2021-02-27 02:47:04 --> Security Class Initialized
DEBUG - 2021-02-27 02:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:47:04 --> Input Class Initialized
INFO - 2021-02-27 02:47:04 --> Language Class Initialized
INFO - 2021-02-27 02:47:04 --> Language Class Initialized
INFO - 2021-02-27 02:47:04 --> Config Class Initialized
INFO - 2021-02-27 02:47:04 --> Loader Class Initialized
INFO - 2021-02-27 02:47:04 --> Helper loaded: url_helper
INFO - 2021-02-27 02:47:04 --> Helper loaded: file_helper
INFO - 2021-02-27 02:47:04 --> Helper loaded: form_helper
INFO - 2021-02-27 02:47:04 --> Helper loaded: my_helper
INFO - 2021-02-27 02:47:04 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:47:04 --> Controller Class Initialized
DEBUG - 2021-02-27 02:47:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-02-27 02:47:04 --> Final output sent to browser
DEBUG - 2021-02-27 02:47:04 --> Total execution time: 0.3723
INFO - 2021-02-27 02:49:15 --> Config Class Initialized
INFO - 2021-02-27 02:49:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:49:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:49:15 --> Utf8 Class Initialized
INFO - 2021-02-27 02:49:15 --> URI Class Initialized
INFO - 2021-02-27 02:49:15 --> Router Class Initialized
INFO - 2021-02-27 02:49:15 --> Output Class Initialized
INFO - 2021-02-27 02:49:15 --> Security Class Initialized
DEBUG - 2021-02-27 02:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:49:15 --> Input Class Initialized
INFO - 2021-02-27 02:49:15 --> Language Class Initialized
INFO - 2021-02-27 02:49:15 --> Language Class Initialized
INFO - 2021-02-27 02:49:15 --> Config Class Initialized
INFO - 2021-02-27 02:49:15 --> Loader Class Initialized
INFO - 2021-02-27 02:49:15 --> Helper loaded: url_helper
INFO - 2021-02-27 02:49:15 --> Helper loaded: file_helper
INFO - 2021-02-27 02:49:15 --> Helper loaded: form_helper
INFO - 2021-02-27 02:49:15 --> Helper loaded: my_helper
INFO - 2021-02-27 02:49:15 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:49:15 --> Controller Class Initialized
INFO - 2021-02-27 02:49:15 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:49:15 --> Config Class Initialized
INFO - 2021-02-27 02:49:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:49:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:49:15 --> Utf8 Class Initialized
INFO - 2021-02-27 02:49:15 --> URI Class Initialized
INFO - 2021-02-27 02:49:15 --> Router Class Initialized
INFO - 2021-02-27 02:49:15 --> Output Class Initialized
INFO - 2021-02-27 02:49:15 --> Security Class Initialized
DEBUG - 2021-02-27 02:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:49:15 --> Input Class Initialized
INFO - 2021-02-27 02:49:15 --> Language Class Initialized
INFO - 2021-02-27 02:49:15 --> Language Class Initialized
INFO - 2021-02-27 02:49:15 --> Config Class Initialized
INFO - 2021-02-27 02:49:15 --> Loader Class Initialized
INFO - 2021-02-27 02:49:15 --> Helper loaded: url_helper
INFO - 2021-02-27 02:49:15 --> Helper loaded: file_helper
INFO - 2021-02-27 02:49:15 --> Helper loaded: form_helper
INFO - 2021-02-27 02:49:15 --> Helper loaded: my_helper
INFO - 2021-02-27 02:49:15 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:49:15 --> Controller Class Initialized
DEBUG - 2021-02-27 02:49:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:49:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:49:15 --> Final output sent to browser
DEBUG - 2021-02-27 02:49:15 --> Total execution time: 0.3029
INFO - 2021-02-27 02:49:27 --> Config Class Initialized
INFO - 2021-02-27 02:49:27 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:49:27 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:49:27 --> Utf8 Class Initialized
INFO - 2021-02-27 02:49:27 --> URI Class Initialized
INFO - 2021-02-27 02:49:27 --> Router Class Initialized
INFO - 2021-02-27 02:49:27 --> Output Class Initialized
INFO - 2021-02-27 02:49:27 --> Security Class Initialized
DEBUG - 2021-02-27 02:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:49:27 --> Input Class Initialized
INFO - 2021-02-27 02:49:27 --> Language Class Initialized
INFO - 2021-02-27 02:49:27 --> Language Class Initialized
INFO - 2021-02-27 02:49:27 --> Config Class Initialized
INFO - 2021-02-27 02:49:27 --> Loader Class Initialized
INFO - 2021-02-27 02:49:27 --> Helper loaded: url_helper
INFO - 2021-02-27 02:49:27 --> Helper loaded: file_helper
INFO - 2021-02-27 02:49:27 --> Helper loaded: form_helper
INFO - 2021-02-27 02:49:27 --> Helper loaded: my_helper
INFO - 2021-02-27 02:49:27 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:49:27 --> Controller Class Initialized
INFO - 2021-02-27 02:49:27 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:49:27 --> Final output sent to browser
DEBUG - 2021-02-27 02:49:27 --> Total execution time: 0.3823
INFO - 2021-02-27 02:49:28 --> Config Class Initialized
INFO - 2021-02-27 02:49:28 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:49:28 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:49:28 --> Utf8 Class Initialized
INFO - 2021-02-27 02:49:28 --> URI Class Initialized
INFO - 2021-02-27 02:49:28 --> Router Class Initialized
INFO - 2021-02-27 02:49:28 --> Output Class Initialized
INFO - 2021-02-27 02:49:28 --> Security Class Initialized
DEBUG - 2021-02-27 02:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:49:28 --> Input Class Initialized
INFO - 2021-02-27 02:49:28 --> Language Class Initialized
INFO - 2021-02-27 02:49:28 --> Language Class Initialized
INFO - 2021-02-27 02:49:28 --> Config Class Initialized
INFO - 2021-02-27 02:49:28 --> Loader Class Initialized
INFO - 2021-02-27 02:49:28 --> Helper loaded: url_helper
INFO - 2021-02-27 02:49:28 --> Helper loaded: file_helper
INFO - 2021-02-27 02:49:28 --> Helper loaded: form_helper
INFO - 2021-02-27 02:49:28 --> Helper loaded: my_helper
INFO - 2021-02-27 02:49:28 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:49:28 --> Controller Class Initialized
DEBUG - 2021-02-27 02:49:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 02:49:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:49:29 --> Final output sent to browser
DEBUG - 2021-02-27 02:49:29 --> Total execution time: 0.4212
INFO - 2021-02-27 02:49:30 --> Config Class Initialized
INFO - 2021-02-27 02:49:30 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:49:30 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:49:30 --> Utf8 Class Initialized
INFO - 2021-02-27 02:49:30 --> URI Class Initialized
INFO - 2021-02-27 02:49:30 --> Router Class Initialized
INFO - 2021-02-27 02:49:30 --> Output Class Initialized
INFO - 2021-02-27 02:49:30 --> Security Class Initialized
DEBUG - 2021-02-27 02:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:49:30 --> Input Class Initialized
INFO - 2021-02-27 02:49:30 --> Language Class Initialized
INFO - 2021-02-27 02:49:30 --> Language Class Initialized
INFO - 2021-02-27 02:49:30 --> Config Class Initialized
INFO - 2021-02-27 02:49:30 --> Loader Class Initialized
INFO - 2021-02-27 02:49:30 --> Helper loaded: url_helper
INFO - 2021-02-27 02:49:30 --> Helper loaded: file_helper
INFO - 2021-02-27 02:49:31 --> Helper loaded: form_helper
INFO - 2021-02-27 02:49:31 --> Helper loaded: my_helper
INFO - 2021-02-27 02:49:31 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:49:31 --> Controller Class Initialized
DEBUG - 2021-02-27 02:49:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-27 02:49:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:49:31 --> Final output sent to browser
DEBUG - 2021-02-27 02:49:31 --> Total execution time: 0.3790
INFO - 2021-02-27 02:49:32 --> Config Class Initialized
INFO - 2021-02-27 02:49:32 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:49:32 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:49:32 --> Utf8 Class Initialized
INFO - 2021-02-27 02:49:32 --> URI Class Initialized
INFO - 2021-02-27 02:49:32 --> Router Class Initialized
INFO - 2021-02-27 02:49:32 --> Output Class Initialized
INFO - 2021-02-27 02:49:32 --> Security Class Initialized
DEBUG - 2021-02-27 02:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:49:32 --> Input Class Initialized
INFO - 2021-02-27 02:49:32 --> Language Class Initialized
INFO - 2021-02-27 02:49:32 --> Language Class Initialized
INFO - 2021-02-27 02:49:32 --> Config Class Initialized
INFO - 2021-02-27 02:49:32 --> Loader Class Initialized
INFO - 2021-02-27 02:49:32 --> Helper loaded: url_helper
INFO - 2021-02-27 02:49:32 --> Helper loaded: file_helper
INFO - 2021-02-27 02:49:32 --> Helper loaded: form_helper
INFO - 2021-02-27 02:49:32 --> Helper loaded: my_helper
INFO - 2021-02-27 02:49:32 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:49:32 --> Controller Class Initialized
DEBUG - 2021-02-27 02:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-27 02:49:32 --> Final output sent to browser
DEBUG - 2021-02-27 02:49:32 --> Total execution time: 0.3277
INFO - 2021-02-27 02:57:35 --> Config Class Initialized
INFO - 2021-02-27 02:57:35 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:57:35 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:57:35 --> Utf8 Class Initialized
INFO - 2021-02-27 02:57:35 --> URI Class Initialized
INFO - 2021-02-27 02:57:35 --> Router Class Initialized
INFO - 2021-02-27 02:57:35 --> Output Class Initialized
INFO - 2021-02-27 02:57:35 --> Security Class Initialized
DEBUG - 2021-02-27 02:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:57:35 --> Input Class Initialized
INFO - 2021-02-27 02:57:35 --> Language Class Initialized
INFO - 2021-02-27 02:57:35 --> Language Class Initialized
INFO - 2021-02-27 02:57:35 --> Config Class Initialized
INFO - 2021-02-27 02:57:35 --> Loader Class Initialized
INFO - 2021-02-27 02:57:35 --> Helper loaded: url_helper
INFO - 2021-02-27 02:57:35 --> Helper loaded: file_helper
INFO - 2021-02-27 02:57:35 --> Helper loaded: form_helper
INFO - 2021-02-27 02:57:35 --> Helper loaded: my_helper
INFO - 2021-02-27 02:57:35 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:57:35 --> Controller Class Initialized
DEBUG - 2021-02-27 02:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-02-27 02:57:35 --> Final output sent to browser
DEBUG - 2021-02-27 02:57:35 --> Total execution time: 0.3332
INFO - 2021-02-27 02:57:46 --> Config Class Initialized
INFO - 2021-02-27 02:57:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:57:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:57:46 --> Utf8 Class Initialized
INFO - 2021-02-27 02:57:46 --> URI Class Initialized
INFO - 2021-02-27 02:57:46 --> Router Class Initialized
INFO - 2021-02-27 02:57:46 --> Output Class Initialized
INFO - 2021-02-27 02:57:46 --> Security Class Initialized
DEBUG - 2021-02-27 02:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:57:46 --> Input Class Initialized
INFO - 2021-02-27 02:57:46 --> Language Class Initialized
INFO - 2021-02-27 02:57:46 --> Language Class Initialized
INFO - 2021-02-27 02:57:46 --> Config Class Initialized
INFO - 2021-02-27 02:57:46 --> Loader Class Initialized
INFO - 2021-02-27 02:57:46 --> Helper loaded: url_helper
INFO - 2021-02-27 02:57:46 --> Helper loaded: file_helper
INFO - 2021-02-27 02:57:46 --> Helper loaded: form_helper
INFO - 2021-02-27 02:57:46 --> Helper loaded: my_helper
INFO - 2021-02-27 02:57:46 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:57:46 --> Controller Class Initialized
INFO - 2021-02-27 02:57:46 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:57:46 --> Config Class Initialized
INFO - 2021-02-27 02:57:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:57:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:57:46 --> Utf8 Class Initialized
INFO - 2021-02-27 02:57:46 --> URI Class Initialized
INFO - 2021-02-27 02:57:46 --> Router Class Initialized
INFO - 2021-02-27 02:57:46 --> Output Class Initialized
INFO - 2021-02-27 02:57:46 --> Security Class Initialized
DEBUG - 2021-02-27 02:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:57:46 --> Input Class Initialized
INFO - 2021-02-27 02:57:46 --> Language Class Initialized
INFO - 2021-02-27 02:57:46 --> Language Class Initialized
INFO - 2021-02-27 02:57:46 --> Config Class Initialized
INFO - 2021-02-27 02:57:46 --> Loader Class Initialized
INFO - 2021-02-27 02:57:46 --> Helper loaded: url_helper
INFO - 2021-02-27 02:57:46 --> Helper loaded: file_helper
INFO - 2021-02-27 02:57:46 --> Helper loaded: form_helper
INFO - 2021-02-27 02:57:46 --> Helper loaded: my_helper
INFO - 2021-02-27 02:57:46 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:57:46 --> Controller Class Initialized
DEBUG - 2021-02-27 02:57:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 02:57:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:57:46 --> Final output sent to browser
DEBUG - 2021-02-27 02:57:46 --> Total execution time: 0.3105
INFO - 2021-02-27 02:57:52 --> Config Class Initialized
INFO - 2021-02-27 02:57:52 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:57:52 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:57:52 --> Utf8 Class Initialized
INFO - 2021-02-27 02:57:52 --> URI Class Initialized
INFO - 2021-02-27 02:57:52 --> Router Class Initialized
INFO - 2021-02-27 02:57:52 --> Output Class Initialized
INFO - 2021-02-27 02:57:52 --> Security Class Initialized
DEBUG - 2021-02-27 02:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:57:52 --> Input Class Initialized
INFO - 2021-02-27 02:57:52 --> Language Class Initialized
INFO - 2021-02-27 02:57:52 --> Language Class Initialized
INFO - 2021-02-27 02:57:52 --> Config Class Initialized
INFO - 2021-02-27 02:57:52 --> Loader Class Initialized
INFO - 2021-02-27 02:57:52 --> Helper loaded: url_helper
INFO - 2021-02-27 02:57:52 --> Helper loaded: file_helper
INFO - 2021-02-27 02:57:52 --> Helper loaded: form_helper
INFO - 2021-02-27 02:57:52 --> Helper loaded: my_helper
INFO - 2021-02-27 02:57:52 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:57:52 --> Controller Class Initialized
INFO - 2021-02-27 02:57:52 --> Helper loaded: cookie_helper
INFO - 2021-02-27 02:57:52 --> Final output sent to browser
DEBUG - 2021-02-27 02:57:52 --> Total execution time: 0.3702
INFO - 2021-02-27 02:57:53 --> Config Class Initialized
INFO - 2021-02-27 02:57:53 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:57:53 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:57:53 --> Utf8 Class Initialized
INFO - 2021-02-27 02:57:53 --> URI Class Initialized
INFO - 2021-02-27 02:57:53 --> Router Class Initialized
INFO - 2021-02-27 02:57:53 --> Output Class Initialized
INFO - 2021-02-27 02:57:53 --> Security Class Initialized
DEBUG - 2021-02-27 02:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:57:53 --> Input Class Initialized
INFO - 2021-02-27 02:57:53 --> Language Class Initialized
INFO - 2021-02-27 02:57:53 --> Language Class Initialized
INFO - 2021-02-27 02:57:53 --> Config Class Initialized
INFO - 2021-02-27 02:57:53 --> Loader Class Initialized
INFO - 2021-02-27 02:57:53 --> Helper loaded: url_helper
INFO - 2021-02-27 02:57:53 --> Helper loaded: file_helper
INFO - 2021-02-27 02:57:53 --> Helper loaded: form_helper
INFO - 2021-02-27 02:57:53 --> Helper loaded: my_helper
INFO - 2021-02-27 02:57:53 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:57:53 --> Controller Class Initialized
DEBUG - 2021-02-27 02:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 02:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:57:53 --> Final output sent to browser
DEBUG - 2021-02-27 02:57:53 --> Total execution time: 0.4355
INFO - 2021-02-27 02:57:54 --> Config Class Initialized
INFO - 2021-02-27 02:57:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:57:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:57:54 --> Utf8 Class Initialized
INFO - 2021-02-27 02:57:54 --> URI Class Initialized
INFO - 2021-02-27 02:57:54 --> Router Class Initialized
INFO - 2021-02-27 02:57:54 --> Output Class Initialized
INFO - 2021-02-27 02:57:54 --> Security Class Initialized
DEBUG - 2021-02-27 02:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:57:54 --> Input Class Initialized
INFO - 2021-02-27 02:57:54 --> Language Class Initialized
INFO - 2021-02-27 02:57:54 --> Language Class Initialized
INFO - 2021-02-27 02:57:54 --> Config Class Initialized
INFO - 2021-02-27 02:57:54 --> Loader Class Initialized
INFO - 2021-02-27 02:57:54 --> Helper loaded: url_helper
INFO - 2021-02-27 02:57:54 --> Helper loaded: file_helper
INFO - 2021-02-27 02:57:54 --> Helper loaded: form_helper
INFO - 2021-02-27 02:57:54 --> Helper loaded: my_helper
INFO - 2021-02-27 02:57:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:57:55 --> Controller Class Initialized
DEBUG - 2021-02-27 02:57:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-27 02:57:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:57:55 --> Final output sent to browser
DEBUG - 2021-02-27 02:57:55 --> Total execution time: 0.3323
INFO - 2021-02-27 02:57:55 --> Config Class Initialized
INFO - 2021-02-27 02:57:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:57:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:57:55 --> Utf8 Class Initialized
INFO - 2021-02-27 02:57:55 --> URI Class Initialized
INFO - 2021-02-27 02:57:55 --> Router Class Initialized
INFO - 2021-02-27 02:57:55 --> Output Class Initialized
INFO - 2021-02-27 02:57:55 --> Security Class Initialized
DEBUG - 2021-02-27 02:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:57:55 --> Input Class Initialized
INFO - 2021-02-27 02:57:55 --> Language Class Initialized
INFO - 2021-02-27 02:57:55 --> Language Class Initialized
INFO - 2021-02-27 02:57:55 --> Config Class Initialized
INFO - 2021-02-27 02:57:55 --> Loader Class Initialized
INFO - 2021-02-27 02:57:55 --> Helper loaded: url_helper
INFO - 2021-02-27 02:57:55 --> Helper loaded: file_helper
INFO - 2021-02-27 02:57:55 --> Helper loaded: form_helper
INFO - 2021-02-27 02:57:55 --> Helper loaded: my_helper
INFO - 2021-02-27 02:57:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:57:55 --> Controller Class Initialized
INFO - 2021-02-27 02:57:59 --> Config Class Initialized
INFO - 2021-02-27 02:57:59 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:57:59 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:57:59 --> Utf8 Class Initialized
INFO - 2021-02-27 02:57:59 --> URI Class Initialized
INFO - 2021-02-27 02:57:59 --> Router Class Initialized
INFO - 2021-02-27 02:57:59 --> Output Class Initialized
INFO - 2021-02-27 02:57:59 --> Security Class Initialized
DEBUG - 2021-02-27 02:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:57:59 --> Input Class Initialized
INFO - 2021-02-27 02:57:59 --> Language Class Initialized
INFO - 2021-02-27 02:57:59 --> Language Class Initialized
INFO - 2021-02-27 02:57:59 --> Config Class Initialized
INFO - 2021-02-27 02:57:59 --> Loader Class Initialized
INFO - 2021-02-27 02:57:59 --> Helper loaded: url_helper
INFO - 2021-02-27 02:57:59 --> Helper loaded: file_helper
INFO - 2021-02-27 02:57:59 --> Helper loaded: form_helper
INFO - 2021-02-27 02:57:59 --> Helper loaded: my_helper
INFO - 2021-02-27 02:57:59 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:57:59 --> Controller Class Initialized
INFO - 2021-02-27 02:57:59 --> Final output sent to browser
DEBUG - 2021-02-27 02:57:59 --> Total execution time: 0.3418
INFO - 2021-02-27 02:59:21 --> Config Class Initialized
INFO - 2021-02-27 02:59:21 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:59:21 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:59:21 --> Utf8 Class Initialized
INFO - 2021-02-27 02:59:21 --> URI Class Initialized
INFO - 2021-02-27 02:59:21 --> Router Class Initialized
INFO - 2021-02-27 02:59:21 --> Output Class Initialized
INFO - 2021-02-27 02:59:21 --> Security Class Initialized
DEBUG - 2021-02-27 02:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:59:21 --> Input Class Initialized
INFO - 2021-02-27 02:59:21 --> Language Class Initialized
INFO - 2021-02-27 02:59:21 --> Language Class Initialized
INFO - 2021-02-27 02:59:21 --> Config Class Initialized
INFO - 2021-02-27 02:59:21 --> Loader Class Initialized
INFO - 2021-02-27 02:59:21 --> Helper loaded: url_helper
INFO - 2021-02-27 02:59:21 --> Helper loaded: file_helper
INFO - 2021-02-27 02:59:21 --> Helper loaded: form_helper
INFO - 2021-02-27 02:59:21 --> Helper loaded: my_helper
INFO - 2021-02-27 02:59:21 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:59:21 --> Controller Class Initialized
DEBUG - 2021-02-27 02:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-27 02:59:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 02:59:22 --> Final output sent to browser
DEBUG - 2021-02-27 02:59:22 --> Total execution time: 0.3078
INFO - 2021-02-27 02:59:22 --> Config Class Initialized
INFO - 2021-02-27 02:59:22 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:59:22 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:59:22 --> Utf8 Class Initialized
INFO - 2021-02-27 02:59:22 --> URI Class Initialized
INFO - 2021-02-27 02:59:22 --> Router Class Initialized
INFO - 2021-02-27 02:59:22 --> Output Class Initialized
INFO - 2021-02-27 02:59:22 --> Security Class Initialized
DEBUG - 2021-02-27 02:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:59:22 --> Input Class Initialized
INFO - 2021-02-27 02:59:22 --> Language Class Initialized
INFO - 2021-02-27 02:59:22 --> Language Class Initialized
INFO - 2021-02-27 02:59:22 --> Config Class Initialized
INFO - 2021-02-27 02:59:22 --> Loader Class Initialized
INFO - 2021-02-27 02:59:22 --> Helper loaded: url_helper
INFO - 2021-02-27 02:59:22 --> Helper loaded: file_helper
INFO - 2021-02-27 02:59:22 --> Helper loaded: form_helper
INFO - 2021-02-27 02:59:22 --> Helper loaded: my_helper
INFO - 2021-02-27 02:59:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:59:22 --> Controller Class Initialized
INFO - 2021-02-27 02:59:23 --> Config Class Initialized
INFO - 2021-02-27 02:59:23 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:59:23 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:59:23 --> Utf8 Class Initialized
INFO - 2021-02-27 02:59:23 --> URI Class Initialized
INFO - 2021-02-27 02:59:23 --> Router Class Initialized
INFO - 2021-02-27 02:59:23 --> Output Class Initialized
INFO - 2021-02-27 02:59:23 --> Security Class Initialized
DEBUG - 2021-02-27 02:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:59:23 --> Input Class Initialized
INFO - 2021-02-27 02:59:23 --> Language Class Initialized
INFO - 2021-02-27 02:59:24 --> Language Class Initialized
INFO - 2021-02-27 02:59:24 --> Config Class Initialized
INFO - 2021-02-27 02:59:24 --> Loader Class Initialized
INFO - 2021-02-27 02:59:24 --> Helper loaded: url_helper
INFO - 2021-02-27 02:59:24 --> Helper loaded: file_helper
INFO - 2021-02-27 02:59:24 --> Helper loaded: form_helper
INFO - 2021-02-27 02:59:24 --> Helper loaded: my_helper
INFO - 2021-02-27 02:59:24 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:59:24 --> Controller Class Initialized
INFO - 2021-02-27 02:59:24 --> Final output sent to browser
DEBUG - 2021-02-27 02:59:24 --> Total execution time: 0.3772
INFO - 2021-02-27 02:59:58 --> Config Class Initialized
INFO - 2021-02-27 02:59:58 --> Hooks Class Initialized
DEBUG - 2021-02-27 02:59:58 --> UTF-8 Support Enabled
INFO - 2021-02-27 02:59:58 --> Utf8 Class Initialized
INFO - 2021-02-27 02:59:58 --> URI Class Initialized
INFO - 2021-02-27 02:59:58 --> Router Class Initialized
INFO - 2021-02-27 02:59:58 --> Output Class Initialized
INFO - 2021-02-27 02:59:58 --> Security Class Initialized
DEBUG - 2021-02-27 02:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 02:59:58 --> Input Class Initialized
INFO - 2021-02-27 02:59:58 --> Language Class Initialized
INFO - 2021-02-27 02:59:58 --> Language Class Initialized
INFO - 2021-02-27 02:59:58 --> Config Class Initialized
INFO - 2021-02-27 02:59:58 --> Loader Class Initialized
INFO - 2021-02-27 02:59:58 --> Helper loaded: url_helper
INFO - 2021-02-27 02:59:58 --> Helper loaded: file_helper
INFO - 2021-02-27 02:59:58 --> Helper loaded: form_helper
INFO - 2021-02-27 02:59:58 --> Helper loaded: my_helper
INFO - 2021-02-27 02:59:58 --> Database Driver Class Initialized
DEBUG - 2021-02-27 02:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 02:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 02:59:58 --> Controller Class Initialized
INFO - 2021-02-27 02:59:58 --> Final output sent to browser
DEBUG - 2021-02-27 02:59:58 --> Total execution time: 0.3795
INFO - 2021-02-27 03:00:19 --> Config Class Initialized
INFO - 2021-02-27 03:00:20 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:20 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:20 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:20 --> URI Class Initialized
INFO - 2021-02-27 03:00:20 --> Router Class Initialized
INFO - 2021-02-27 03:00:20 --> Output Class Initialized
INFO - 2021-02-27 03:00:20 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:20 --> Input Class Initialized
INFO - 2021-02-27 03:00:20 --> Language Class Initialized
INFO - 2021-02-27 03:00:20 --> Language Class Initialized
INFO - 2021-02-27 03:00:20 --> Config Class Initialized
INFO - 2021-02-27 03:00:20 --> Loader Class Initialized
INFO - 2021-02-27 03:00:20 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:20 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:20 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:20 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:20 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:20 --> Controller Class Initialized
INFO - 2021-02-27 03:00:20 --> Final output sent to browser
DEBUG - 2021-02-27 03:00:20 --> Total execution time: 0.3472
INFO - 2021-02-27 03:00:20 --> Config Class Initialized
INFO - 2021-02-27 03:00:20 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:20 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:20 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:20 --> URI Class Initialized
INFO - 2021-02-27 03:00:20 --> Router Class Initialized
INFO - 2021-02-27 03:00:20 --> Output Class Initialized
INFO - 2021-02-27 03:00:20 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:20 --> Input Class Initialized
INFO - 2021-02-27 03:00:20 --> Language Class Initialized
INFO - 2021-02-27 03:00:20 --> Language Class Initialized
INFO - 2021-02-27 03:00:20 --> Config Class Initialized
INFO - 2021-02-27 03:00:20 --> Loader Class Initialized
INFO - 2021-02-27 03:00:20 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:20 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:20 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:20 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:20 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:20 --> Controller Class Initialized
INFO - 2021-02-27 03:00:34 --> Config Class Initialized
INFO - 2021-02-27 03:00:34 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:34 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:34 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:34 --> URI Class Initialized
INFO - 2021-02-27 03:00:34 --> Router Class Initialized
INFO - 2021-02-27 03:00:34 --> Output Class Initialized
INFO - 2021-02-27 03:00:34 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:34 --> Input Class Initialized
INFO - 2021-02-27 03:00:34 --> Language Class Initialized
INFO - 2021-02-27 03:00:34 --> Language Class Initialized
INFO - 2021-02-27 03:00:34 --> Config Class Initialized
INFO - 2021-02-27 03:00:34 --> Loader Class Initialized
INFO - 2021-02-27 03:00:34 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:34 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:34 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:34 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:34 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:34 --> Controller Class Initialized
INFO - 2021-02-27 03:00:34 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:00:34 --> Config Class Initialized
INFO - 2021-02-27 03:00:34 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:34 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:34 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:34 --> URI Class Initialized
INFO - 2021-02-27 03:00:34 --> Router Class Initialized
INFO - 2021-02-27 03:00:34 --> Output Class Initialized
INFO - 2021-02-27 03:00:34 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:34 --> Input Class Initialized
INFO - 2021-02-27 03:00:34 --> Language Class Initialized
INFO - 2021-02-27 03:00:34 --> Language Class Initialized
INFO - 2021-02-27 03:00:34 --> Config Class Initialized
INFO - 2021-02-27 03:00:34 --> Loader Class Initialized
INFO - 2021-02-27 03:00:34 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:34 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:34 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:34 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:35 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:35 --> Controller Class Initialized
DEBUG - 2021-02-27 03:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:00:35 --> Final output sent to browser
DEBUG - 2021-02-27 03:00:35 --> Total execution time: 0.3139
INFO - 2021-02-27 03:00:41 --> Config Class Initialized
INFO - 2021-02-27 03:00:41 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:41 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:41 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:41 --> URI Class Initialized
INFO - 2021-02-27 03:00:41 --> Router Class Initialized
INFO - 2021-02-27 03:00:41 --> Output Class Initialized
INFO - 2021-02-27 03:00:41 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:41 --> Input Class Initialized
INFO - 2021-02-27 03:00:41 --> Language Class Initialized
INFO - 2021-02-27 03:00:41 --> Language Class Initialized
INFO - 2021-02-27 03:00:41 --> Config Class Initialized
INFO - 2021-02-27 03:00:41 --> Loader Class Initialized
INFO - 2021-02-27 03:00:41 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:41 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:41 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:41 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:41 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:41 --> Controller Class Initialized
INFO - 2021-02-27 03:00:41 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:00:41 --> Final output sent to browser
DEBUG - 2021-02-27 03:00:41 --> Total execution time: 0.3375
INFO - 2021-02-27 03:00:41 --> Config Class Initialized
INFO - 2021-02-27 03:00:41 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:41 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:41 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:41 --> URI Class Initialized
INFO - 2021-02-27 03:00:41 --> Router Class Initialized
INFO - 2021-02-27 03:00:41 --> Output Class Initialized
INFO - 2021-02-27 03:00:41 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:41 --> Input Class Initialized
INFO - 2021-02-27 03:00:41 --> Language Class Initialized
INFO - 2021-02-27 03:00:42 --> Language Class Initialized
INFO - 2021-02-27 03:00:42 --> Config Class Initialized
INFO - 2021-02-27 03:00:42 --> Loader Class Initialized
INFO - 2021-02-27 03:00:42 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:42 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:42 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:42 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:42 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:42 --> Controller Class Initialized
DEBUG - 2021-02-27 03:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:00:42 --> Final output sent to browser
DEBUG - 2021-02-27 03:00:42 --> Total execution time: 0.4076
INFO - 2021-02-27 03:00:46 --> Config Class Initialized
INFO - 2021-02-27 03:00:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:46 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:46 --> URI Class Initialized
INFO - 2021-02-27 03:00:46 --> Router Class Initialized
INFO - 2021-02-27 03:00:46 --> Output Class Initialized
INFO - 2021-02-27 03:00:46 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:46 --> Input Class Initialized
INFO - 2021-02-27 03:00:46 --> Language Class Initialized
INFO - 2021-02-27 03:00:46 --> Language Class Initialized
INFO - 2021-02-27 03:00:46 --> Config Class Initialized
INFO - 2021-02-27 03:00:46 --> Loader Class Initialized
INFO - 2021-02-27 03:00:46 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:46 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:46 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:46 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:46 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:46 --> Controller Class Initialized
DEBUG - 2021-02-27 03:00:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-27 03:00:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:00:46 --> Final output sent to browser
DEBUG - 2021-02-27 03:00:46 --> Total execution time: 0.3630
INFO - 2021-02-27 03:00:49 --> Config Class Initialized
INFO - 2021-02-27 03:00:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:49 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:49 --> URI Class Initialized
INFO - 2021-02-27 03:00:49 --> Router Class Initialized
INFO - 2021-02-27 03:00:49 --> Output Class Initialized
INFO - 2021-02-27 03:00:49 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:49 --> Input Class Initialized
INFO - 2021-02-27 03:00:49 --> Language Class Initialized
INFO - 2021-02-27 03:00:49 --> Language Class Initialized
INFO - 2021-02-27 03:00:49 --> Config Class Initialized
INFO - 2021-02-27 03:00:49 --> Loader Class Initialized
INFO - 2021-02-27 03:00:49 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:49 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:49 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:49 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:49 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:49 --> Controller Class Initialized
DEBUG - 2021-02-27 03:00:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-27 03:00:49 --> Final output sent to browser
DEBUG - 2021-02-27 03:00:49 --> Total execution time: 0.3437
INFO - 2021-02-27 03:00:55 --> Config Class Initialized
INFO - 2021-02-27 03:00:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:55 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:55 --> URI Class Initialized
INFO - 2021-02-27 03:00:55 --> Router Class Initialized
INFO - 2021-02-27 03:00:55 --> Output Class Initialized
INFO - 2021-02-27 03:00:55 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:55 --> Input Class Initialized
INFO - 2021-02-27 03:00:55 --> Language Class Initialized
INFO - 2021-02-27 03:00:55 --> Language Class Initialized
INFO - 2021-02-27 03:00:55 --> Config Class Initialized
INFO - 2021-02-27 03:00:55 --> Loader Class Initialized
INFO - 2021-02-27 03:00:55 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:55 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:55 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:55 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:55 --> Controller Class Initialized
INFO - 2021-02-27 03:00:55 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:00:55 --> Config Class Initialized
INFO - 2021-02-27 03:00:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:55 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:55 --> URI Class Initialized
INFO - 2021-02-27 03:00:55 --> Router Class Initialized
INFO - 2021-02-27 03:00:55 --> Output Class Initialized
INFO - 2021-02-27 03:00:55 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:55 --> Input Class Initialized
INFO - 2021-02-27 03:00:55 --> Language Class Initialized
INFO - 2021-02-27 03:00:55 --> Language Class Initialized
INFO - 2021-02-27 03:00:55 --> Config Class Initialized
INFO - 2021-02-27 03:00:55 --> Loader Class Initialized
INFO - 2021-02-27 03:00:55 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:55 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:55 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:55 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:55 --> Controller Class Initialized
DEBUG - 2021-02-27 03:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:00:55 --> Final output sent to browser
DEBUG - 2021-02-27 03:00:55 --> Total execution time: 0.3283
INFO - 2021-02-27 03:00:59 --> Config Class Initialized
INFO - 2021-02-27 03:00:59 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:00:59 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:00:59 --> Utf8 Class Initialized
INFO - 2021-02-27 03:00:59 --> URI Class Initialized
INFO - 2021-02-27 03:00:59 --> Router Class Initialized
INFO - 2021-02-27 03:00:59 --> Output Class Initialized
INFO - 2021-02-27 03:00:59 --> Security Class Initialized
DEBUG - 2021-02-27 03:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:00:59 --> Input Class Initialized
INFO - 2021-02-27 03:00:59 --> Language Class Initialized
INFO - 2021-02-27 03:00:59 --> Language Class Initialized
INFO - 2021-02-27 03:00:59 --> Config Class Initialized
INFO - 2021-02-27 03:00:59 --> Loader Class Initialized
INFO - 2021-02-27 03:00:59 --> Helper loaded: url_helper
INFO - 2021-02-27 03:00:59 --> Helper loaded: file_helper
INFO - 2021-02-27 03:00:59 --> Helper loaded: form_helper
INFO - 2021-02-27 03:00:59 --> Helper loaded: my_helper
INFO - 2021-02-27 03:00:59 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:00:59 --> Controller Class Initialized
INFO - 2021-02-27 03:00:59 --> Final output sent to browser
DEBUG - 2021-02-27 03:00:59 --> Total execution time: 0.3592
INFO - 2021-02-27 03:01:03 --> Config Class Initialized
INFO - 2021-02-27 03:01:03 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:03 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:03 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:03 --> URI Class Initialized
INFO - 2021-02-27 03:01:03 --> Router Class Initialized
INFO - 2021-02-27 03:01:03 --> Output Class Initialized
INFO - 2021-02-27 03:01:03 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:03 --> Input Class Initialized
INFO - 2021-02-27 03:01:03 --> Language Class Initialized
INFO - 2021-02-27 03:01:03 --> Language Class Initialized
INFO - 2021-02-27 03:01:03 --> Config Class Initialized
INFO - 2021-02-27 03:01:03 --> Loader Class Initialized
INFO - 2021-02-27 03:01:03 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:03 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:03 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:03 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:04 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:04 --> Controller Class Initialized
INFO - 2021-02-27 03:01:04 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:01:04 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:04 --> Total execution time: 0.3651
INFO - 2021-02-27 03:01:04 --> Config Class Initialized
INFO - 2021-02-27 03:01:04 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:04 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:04 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:04 --> URI Class Initialized
INFO - 2021-02-27 03:01:04 --> Router Class Initialized
INFO - 2021-02-27 03:01:04 --> Output Class Initialized
INFO - 2021-02-27 03:01:04 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:04 --> Input Class Initialized
INFO - 2021-02-27 03:01:04 --> Language Class Initialized
INFO - 2021-02-27 03:01:04 --> Language Class Initialized
INFO - 2021-02-27 03:01:04 --> Config Class Initialized
INFO - 2021-02-27 03:01:04 --> Loader Class Initialized
INFO - 2021-02-27 03:01:04 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:04 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:04 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:04 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:04 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:04 --> Controller Class Initialized
DEBUG - 2021-02-27 03:01:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:01:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:01:04 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:04 --> Total execution time: 0.4367
INFO - 2021-02-27 03:01:06 --> Config Class Initialized
INFO - 2021-02-27 03:01:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:06 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:06 --> URI Class Initialized
INFO - 2021-02-27 03:01:06 --> Router Class Initialized
INFO - 2021-02-27 03:01:06 --> Output Class Initialized
INFO - 2021-02-27 03:01:06 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:06 --> Input Class Initialized
INFO - 2021-02-27 03:01:06 --> Language Class Initialized
INFO - 2021-02-27 03:01:06 --> Language Class Initialized
INFO - 2021-02-27 03:01:06 --> Config Class Initialized
INFO - 2021-02-27 03:01:06 --> Loader Class Initialized
INFO - 2021-02-27 03:01:06 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:06 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:06 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:06 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:06 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:06 --> Controller Class Initialized
DEBUG - 2021-02-27 03:01:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 03:01:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:01:06 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:06 --> Total execution time: 0.3793
INFO - 2021-02-27 03:01:08 --> Config Class Initialized
INFO - 2021-02-27 03:01:08 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:08 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:08 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:08 --> URI Class Initialized
INFO - 2021-02-27 03:01:08 --> Router Class Initialized
INFO - 2021-02-27 03:01:08 --> Output Class Initialized
INFO - 2021-02-27 03:01:08 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:08 --> Input Class Initialized
INFO - 2021-02-27 03:01:08 --> Language Class Initialized
INFO - 2021-02-27 03:01:08 --> Language Class Initialized
INFO - 2021-02-27 03:01:08 --> Config Class Initialized
INFO - 2021-02-27 03:01:08 --> Loader Class Initialized
INFO - 2021-02-27 03:01:08 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:08 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:08 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:08 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:08 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:09 --> Controller Class Initialized
DEBUG - 2021-02-27 03:01:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-27 03:01:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:01:09 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:09 --> Total execution time: 0.3491
INFO - 2021-02-27 03:01:09 --> Config Class Initialized
INFO - 2021-02-27 03:01:09 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:09 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:09 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:09 --> URI Class Initialized
INFO - 2021-02-27 03:01:09 --> Router Class Initialized
INFO - 2021-02-27 03:01:09 --> Output Class Initialized
INFO - 2021-02-27 03:01:09 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:09 --> Input Class Initialized
INFO - 2021-02-27 03:01:09 --> Language Class Initialized
INFO - 2021-02-27 03:01:09 --> Language Class Initialized
INFO - 2021-02-27 03:01:09 --> Config Class Initialized
INFO - 2021-02-27 03:01:09 --> Loader Class Initialized
INFO - 2021-02-27 03:01:09 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:09 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:09 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:09 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:09 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:09 --> Controller Class Initialized
INFO - 2021-02-27 03:01:12 --> Config Class Initialized
INFO - 2021-02-27 03:01:12 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:12 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:12 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:12 --> URI Class Initialized
INFO - 2021-02-27 03:01:12 --> Router Class Initialized
INFO - 2021-02-27 03:01:12 --> Output Class Initialized
INFO - 2021-02-27 03:01:12 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:13 --> Input Class Initialized
INFO - 2021-02-27 03:01:13 --> Language Class Initialized
INFO - 2021-02-27 03:01:13 --> Language Class Initialized
INFO - 2021-02-27 03:01:13 --> Config Class Initialized
INFO - 2021-02-27 03:01:13 --> Loader Class Initialized
INFO - 2021-02-27 03:01:13 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:13 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:13 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:13 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:13 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:13 --> Controller Class Initialized
INFO - 2021-02-27 03:01:13 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:13 --> Total execution time: 0.3146
INFO - 2021-02-27 03:01:13 --> Config Class Initialized
INFO - 2021-02-27 03:01:13 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:13 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:13 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:13 --> URI Class Initialized
INFO - 2021-02-27 03:01:13 --> Router Class Initialized
INFO - 2021-02-27 03:01:13 --> Output Class Initialized
INFO - 2021-02-27 03:01:13 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:13 --> Input Class Initialized
INFO - 2021-02-27 03:01:13 --> Language Class Initialized
INFO - 2021-02-27 03:01:13 --> Language Class Initialized
INFO - 2021-02-27 03:01:13 --> Config Class Initialized
INFO - 2021-02-27 03:01:13 --> Loader Class Initialized
INFO - 2021-02-27 03:01:13 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:13 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:13 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:13 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:13 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:13 --> Controller Class Initialized
INFO - 2021-02-27 03:01:21 --> Config Class Initialized
INFO - 2021-02-27 03:01:21 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:21 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:21 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:21 --> URI Class Initialized
INFO - 2021-02-27 03:01:21 --> Router Class Initialized
INFO - 2021-02-27 03:01:21 --> Output Class Initialized
INFO - 2021-02-27 03:01:21 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:21 --> Input Class Initialized
INFO - 2021-02-27 03:01:21 --> Language Class Initialized
INFO - 2021-02-27 03:01:21 --> Language Class Initialized
INFO - 2021-02-27 03:01:21 --> Config Class Initialized
INFO - 2021-02-27 03:01:21 --> Loader Class Initialized
INFO - 2021-02-27 03:01:21 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:21 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:21 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:21 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:21 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:21 --> Controller Class Initialized
INFO - 2021-02-27 03:01:21 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:01:21 --> Config Class Initialized
INFO - 2021-02-27 03:01:21 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:21 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:21 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:21 --> URI Class Initialized
INFO - 2021-02-27 03:01:21 --> Router Class Initialized
INFO - 2021-02-27 03:01:21 --> Output Class Initialized
INFO - 2021-02-27 03:01:21 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:21 --> Input Class Initialized
INFO - 2021-02-27 03:01:21 --> Language Class Initialized
INFO - 2021-02-27 03:01:21 --> Language Class Initialized
INFO - 2021-02-27 03:01:21 --> Config Class Initialized
INFO - 2021-02-27 03:01:21 --> Loader Class Initialized
INFO - 2021-02-27 03:01:21 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:21 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:21 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:21 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:21 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:22 --> Controller Class Initialized
DEBUG - 2021-02-27 03:01:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:01:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:01:22 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:22 --> Total execution time: 0.3639
INFO - 2021-02-27 03:01:26 --> Config Class Initialized
INFO - 2021-02-27 03:01:26 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:26 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:26 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:26 --> URI Class Initialized
INFO - 2021-02-27 03:01:26 --> Router Class Initialized
INFO - 2021-02-27 03:01:26 --> Output Class Initialized
INFO - 2021-02-27 03:01:26 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:26 --> Input Class Initialized
INFO - 2021-02-27 03:01:26 --> Language Class Initialized
INFO - 2021-02-27 03:01:26 --> Language Class Initialized
INFO - 2021-02-27 03:01:26 --> Config Class Initialized
INFO - 2021-02-27 03:01:26 --> Loader Class Initialized
INFO - 2021-02-27 03:01:26 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:26 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:26 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:26 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:26 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:26 --> Controller Class Initialized
INFO - 2021-02-27 03:01:26 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:01:26 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:26 --> Total execution time: 0.3793
INFO - 2021-02-27 03:01:27 --> Config Class Initialized
INFO - 2021-02-27 03:01:27 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:27 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:27 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:27 --> URI Class Initialized
INFO - 2021-02-27 03:01:27 --> Router Class Initialized
INFO - 2021-02-27 03:01:27 --> Output Class Initialized
INFO - 2021-02-27 03:01:27 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:27 --> Input Class Initialized
INFO - 2021-02-27 03:01:27 --> Language Class Initialized
INFO - 2021-02-27 03:01:27 --> Language Class Initialized
INFO - 2021-02-27 03:01:27 --> Config Class Initialized
INFO - 2021-02-27 03:01:27 --> Loader Class Initialized
INFO - 2021-02-27 03:01:27 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:27 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:27 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:27 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:27 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:27 --> Controller Class Initialized
DEBUG - 2021-02-27 03:01:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:01:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:01:27 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:27 --> Total execution time: 0.3965
INFO - 2021-02-27 03:01:40 --> Config Class Initialized
INFO - 2021-02-27 03:01:40 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:40 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:40 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:40 --> URI Class Initialized
INFO - 2021-02-27 03:01:40 --> Router Class Initialized
INFO - 2021-02-27 03:01:40 --> Output Class Initialized
INFO - 2021-02-27 03:01:40 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:40 --> Input Class Initialized
INFO - 2021-02-27 03:01:40 --> Language Class Initialized
INFO - 2021-02-27 03:01:40 --> Language Class Initialized
INFO - 2021-02-27 03:01:40 --> Config Class Initialized
INFO - 2021-02-27 03:01:40 --> Loader Class Initialized
INFO - 2021-02-27 03:01:40 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:40 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:40 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:40 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:40 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:40 --> Controller Class Initialized
INFO - 2021-02-27 03:01:41 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:01:41 --> Config Class Initialized
INFO - 2021-02-27 03:01:41 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:41 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:41 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:41 --> URI Class Initialized
INFO - 2021-02-27 03:01:41 --> Router Class Initialized
INFO - 2021-02-27 03:01:41 --> Output Class Initialized
INFO - 2021-02-27 03:01:41 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:41 --> Input Class Initialized
INFO - 2021-02-27 03:01:41 --> Language Class Initialized
INFO - 2021-02-27 03:01:41 --> Language Class Initialized
INFO - 2021-02-27 03:01:41 --> Config Class Initialized
INFO - 2021-02-27 03:01:41 --> Loader Class Initialized
INFO - 2021-02-27 03:01:41 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:41 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:41 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:41 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:41 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:41 --> Controller Class Initialized
DEBUG - 2021-02-27 03:01:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:01:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:01:41 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:41 --> Total execution time: 0.3702
INFO - 2021-02-27 03:01:46 --> Config Class Initialized
INFO - 2021-02-27 03:01:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:46 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:46 --> URI Class Initialized
INFO - 2021-02-27 03:01:46 --> Router Class Initialized
INFO - 2021-02-27 03:01:47 --> Output Class Initialized
INFO - 2021-02-27 03:01:47 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:47 --> Input Class Initialized
INFO - 2021-02-27 03:01:47 --> Language Class Initialized
INFO - 2021-02-27 03:01:47 --> Language Class Initialized
INFO - 2021-02-27 03:01:47 --> Config Class Initialized
INFO - 2021-02-27 03:01:47 --> Loader Class Initialized
INFO - 2021-02-27 03:01:47 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:47 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:47 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:47 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:47 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:47 --> Controller Class Initialized
INFO - 2021-02-27 03:01:47 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:47 --> Total execution time: 0.3432
INFO - 2021-02-27 03:01:53 --> Config Class Initialized
INFO - 2021-02-27 03:01:53 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:53 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:53 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:53 --> URI Class Initialized
INFO - 2021-02-27 03:01:53 --> Router Class Initialized
INFO - 2021-02-27 03:01:53 --> Output Class Initialized
INFO - 2021-02-27 03:01:53 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:53 --> Input Class Initialized
INFO - 2021-02-27 03:01:53 --> Language Class Initialized
INFO - 2021-02-27 03:01:53 --> Language Class Initialized
INFO - 2021-02-27 03:01:53 --> Config Class Initialized
INFO - 2021-02-27 03:01:53 --> Loader Class Initialized
INFO - 2021-02-27 03:01:53 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:53 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:53 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:53 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:53 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:53 --> Controller Class Initialized
INFO - 2021-02-27 03:01:53 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:01:53 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:53 --> Total execution time: 0.3406
INFO - 2021-02-27 03:01:55 --> Config Class Initialized
INFO - 2021-02-27 03:01:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:01:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:01:55 --> Utf8 Class Initialized
INFO - 2021-02-27 03:01:55 --> URI Class Initialized
INFO - 2021-02-27 03:01:55 --> Router Class Initialized
INFO - 2021-02-27 03:01:55 --> Output Class Initialized
INFO - 2021-02-27 03:01:55 --> Security Class Initialized
DEBUG - 2021-02-27 03:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:01:55 --> Input Class Initialized
INFO - 2021-02-27 03:01:55 --> Language Class Initialized
INFO - 2021-02-27 03:01:55 --> Language Class Initialized
INFO - 2021-02-27 03:01:55 --> Config Class Initialized
INFO - 2021-02-27 03:01:55 --> Loader Class Initialized
INFO - 2021-02-27 03:01:55 --> Helper loaded: url_helper
INFO - 2021-02-27 03:01:55 --> Helper loaded: file_helper
INFO - 2021-02-27 03:01:55 --> Helper loaded: form_helper
INFO - 2021-02-27 03:01:55 --> Helper loaded: my_helper
INFO - 2021-02-27 03:01:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:01:56 --> Controller Class Initialized
DEBUG - 2021-02-27 03:01:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:01:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:01:56 --> Final output sent to browser
DEBUG - 2021-02-27 03:01:56 --> Total execution time: 0.4215
INFO - 2021-02-27 03:02:00 --> Config Class Initialized
INFO - 2021-02-27 03:02:00 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:02:00 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:02:00 --> Utf8 Class Initialized
INFO - 2021-02-27 03:02:00 --> URI Class Initialized
INFO - 2021-02-27 03:02:00 --> Router Class Initialized
INFO - 2021-02-27 03:02:00 --> Output Class Initialized
INFO - 2021-02-27 03:02:00 --> Security Class Initialized
DEBUG - 2021-02-27 03:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:02:00 --> Input Class Initialized
INFO - 2021-02-27 03:02:00 --> Language Class Initialized
INFO - 2021-02-27 03:02:00 --> Language Class Initialized
INFO - 2021-02-27 03:02:00 --> Config Class Initialized
INFO - 2021-02-27 03:02:00 --> Loader Class Initialized
INFO - 2021-02-27 03:02:00 --> Helper loaded: url_helper
INFO - 2021-02-27 03:02:00 --> Helper loaded: file_helper
INFO - 2021-02-27 03:02:00 --> Helper loaded: form_helper
INFO - 2021-02-27 03:02:00 --> Helper loaded: my_helper
INFO - 2021-02-27 03:02:00 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:02:00 --> Controller Class Initialized
DEBUG - 2021-02-27 03:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-27 03:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:02:00 --> Final output sent to browser
DEBUG - 2021-02-27 03:02:00 --> Total execution time: 0.3227
INFO - 2021-02-27 03:02:00 --> Config Class Initialized
INFO - 2021-02-27 03:02:00 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:02:00 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:02:00 --> Utf8 Class Initialized
INFO - 2021-02-27 03:02:00 --> URI Class Initialized
INFO - 2021-02-27 03:02:00 --> Router Class Initialized
INFO - 2021-02-27 03:02:00 --> Output Class Initialized
INFO - 2021-02-27 03:02:00 --> Security Class Initialized
DEBUG - 2021-02-27 03:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:02:00 --> Input Class Initialized
INFO - 2021-02-27 03:02:00 --> Language Class Initialized
INFO - 2021-02-27 03:02:00 --> Language Class Initialized
INFO - 2021-02-27 03:02:00 --> Config Class Initialized
INFO - 2021-02-27 03:02:00 --> Loader Class Initialized
INFO - 2021-02-27 03:02:00 --> Helper loaded: url_helper
INFO - 2021-02-27 03:02:00 --> Helper loaded: file_helper
INFO - 2021-02-27 03:02:00 --> Helper loaded: form_helper
INFO - 2021-02-27 03:02:00 --> Helper loaded: my_helper
INFO - 2021-02-27 03:02:00 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:02:00 --> Controller Class Initialized
INFO - 2021-02-27 03:03:20 --> Config Class Initialized
INFO - 2021-02-27 03:03:20 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:03:20 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:03:20 --> Utf8 Class Initialized
INFO - 2021-02-27 03:03:20 --> URI Class Initialized
INFO - 2021-02-27 03:03:20 --> Router Class Initialized
INFO - 2021-02-27 03:03:20 --> Output Class Initialized
INFO - 2021-02-27 03:03:20 --> Security Class Initialized
DEBUG - 2021-02-27 03:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:03:20 --> Input Class Initialized
INFO - 2021-02-27 03:03:20 --> Language Class Initialized
INFO - 2021-02-27 03:03:20 --> Language Class Initialized
INFO - 2021-02-27 03:03:20 --> Config Class Initialized
INFO - 2021-02-27 03:03:20 --> Loader Class Initialized
INFO - 2021-02-27 03:03:20 --> Helper loaded: url_helper
INFO - 2021-02-27 03:03:20 --> Helper loaded: file_helper
INFO - 2021-02-27 03:03:20 --> Helper loaded: form_helper
INFO - 2021-02-27 03:03:20 --> Helper loaded: my_helper
INFO - 2021-02-27 03:03:20 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:03:20 --> Controller Class Initialized
INFO - 2021-02-27 03:03:20 --> Final output sent to browser
DEBUG - 2021-02-27 03:03:20 --> Total execution time: 0.3036
INFO - 2021-02-27 03:03:20 --> Config Class Initialized
INFO - 2021-02-27 03:03:20 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:03:20 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:03:20 --> Utf8 Class Initialized
INFO - 2021-02-27 03:03:20 --> URI Class Initialized
INFO - 2021-02-27 03:03:20 --> Router Class Initialized
INFO - 2021-02-27 03:03:20 --> Output Class Initialized
INFO - 2021-02-27 03:03:20 --> Security Class Initialized
DEBUG - 2021-02-27 03:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:03:20 --> Input Class Initialized
INFO - 2021-02-27 03:03:20 --> Language Class Initialized
INFO - 2021-02-27 03:03:21 --> Language Class Initialized
INFO - 2021-02-27 03:03:21 --> Config Class Initialized
INFO - 2021-02-27 03:03:21 --> Loader Class Initialized
INFO - 2021-02-27 03:03:21 --> Helper loaded: url_helper
INFO - 2021-02-27 03:03:21 --> Helper loaded: file_helper
INFO - 2021-02-27 03:03:21 --> Helper loaded: form_helper
INFO - 2021-02-27 03:03:21 --> Helper loaded: my_helper
INFO - 2021-02-27 03:03:21 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:03:21 --> Controller Class Initialized
INFO - 2021-02-27 03:04:06 --> Config Class Initialized
INFO - 2021-02-27 03:04:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:04:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:04:06 --> Utf8 Class Initialized
INFO - 2021-02-27 03:04:06 --> URI Class Initialized
INFO - 2021-02-27 03:04:06 --> Router Class Initialized
INFO - 2021-02-27 03:04:06 --> Output Class Initialized
INFO - 2021-02-27 03:04:06 --> Security Class Initialized
DEBUG - 2021-02-27 03:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:04:06 --> Input Class Initialized
INFO - 2021-02-27 03:04:06 --> Language Class Initialized
INFO - 2021-02-27 03:04:06 --> Language Class Initialized
INFO - 2021-02-27 03:04:06 --> Config Class Initialized
INFO - 2021-02-27 03:04:06 --> Loader Class Initialized
INFO - 2021-02-27 03:04:06 --> Helper loaded: url_helper
INFO - 2021-02-27 03:04:06 --> Helper loaded: file_helper
INFO - 2021-02-27 03:04:06 --> Helper loaded: form_helper
INFO - 2021-02-27 03:04:06 --> Helper loaded: my_helper
INFO - 2021-02-27 03:04:06 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:04:06 --> Controller Class Initialized
INFO - 2021-02-27 03:04:06 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:04:06 --> Config Class Initialized
INFO - 2021-02-27 03:04:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:04:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:04:06 --> Utf8 Class Initialized
INFO - 2021-02-27 03:04:06 --> URI Class Initialized
INFO - 2021-02-27 03:04:06 --> Router Class Initialized
INFO - 2021-02-27 03:04:06 --> Output Class Initialized
INFO - 2021-02-27 03:04:06 --> Security Class Initialized
DEBUG - 2021-02-27 03:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:04:06 --> Input Class Initialized
INFO - 2021-02-27 03:04:06 --> Language Class Initialized
INFO - 2021-02-27 03:04:06 --> Language Class Initialized
INFO - 2021-02-27 03:04:06 --> Config Class Initialized
INFO - 2021-02-27 03:04:06 --> Loader Class Initialized
INFO - 2021-02-27 03:04:06 --> Helper loaded: url_helper
INFO - 2021-02-27 03:04:06 --> Helper loaded: file_helper
INFO - 2021-02-27 03:04:06 --> Helper loaded: form_helper
INFO - 2021-02-27 03:04:06 --> Helper loaded: my_helper
INFO - 2021-02-27 03:04:06 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:04:06 --> Controller Class Initialized
DEBUG - 2021-02-27 03:04:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:04:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:04:06 --> Final output sent to browser
DEBUG - 2021-02-27 03:04:06 --> Total execution time: 0.3384
INFO - 2021-02-27 03:04:11 --> Config Class Initialized
INFO - 2021-02-27 03:04:11 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:04:11 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:04:11 --> Utf8 Class Initialized
INFO - 2021-02-27 03:04:11 --> URI Class Initialized
INFO - 2021-02-27 03:04:11 --> Router Class Initialized
INFO - 2021-02-27 03:04:11 --> Output Class Initialized
INFO - 2021-02-27 03:04:11 --> Security Class Initialized
DEBUG - 2021-02-27 03:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:04:11 --> Input Class Initialized
INFO - 2021-02-27 03:04:12 --> Language Class Initialized
INFO - 2021-02-27 03:04:12 --> Language Class Initialized
INFO - 2021-02-27 03:04:12 --> Config Class Initialized
INFO - 2021-02-27 03:04:12 --> Loader Class Initialized
INFO - 2021-02-27 03:04:12 --> Helper loaded: url_helper
INFO - 2021-02-27 03:04:12 --> Helper loaded: file_helper
INFO - 2021-02-27 03:04:12 --> Helper loaded: form_helper
INFO - 2021-02-27 03:04:12 --> Helper loaded: my_helper
INFO - 2021-02-27 03:04:12 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:04:12 --> Controller Class Initialized
INFO - 2021-02-27 03:04:12 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:04:12 --> Final output sent to browser
DEBUG - 2021-02-27 03:04:12 --> Total execution time: 0.3534
INFO - 2021-02-27 03:04:20 --> Config Class Initialized
INFO - 2021-02-27 03:04:20 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:04:20 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:04:20 --> Utf8 Class Initialized
INFO - 2021-02-27 03:04:20 --> URI Class Initialized
INFO - 2021-02-27 03:04:20 --> Router Class Initialized
INFO - 2021-02-27 03:04:20 --> Output Class Initialized
INFO - 2021-02-27 03:04:20 --> Security Class Initialized
DEBUG - 2021-02-27 03:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:04:20 --> Input Class Initialized
INFO - 2021-02-27 03:04:20 --> Language Class Initialized
INFO - 2021-02-27 03:04:20 --> Language Class Initialized
INFO - 2021-02-27 03:04:20 --> Config Class Initialized
INFO - 2021-02-27 03:04:20 --> Loader Class Initialized
INFO - 2021-02-27 03:04:20 --> Helper loaded: url_helper
INFO - 2021-02-27 03:04:20 --> Helper loaded: file_helper
INFO - 2021-02-27 03:04:20 --> Helper loaded: form_helper
INFO - 2021-02-27 03:04:20 --> Helper loaded: my_helper
INFO - 2021-02-27 03:04:20 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:04:20 --> Controller Class Initialized
DEBUG - 2021-02-27 03:04:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:04:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:04:20 --> Final output sent to browser
DEBUG - 2021-02-27 03:04:20 --> Total execution time: 0.4828
INFO - 2021-02-27 03:04:22 --> Config Class Initialized
INFO - 2021-02-27 03:04:22 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:04:22 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:04:22 --> Utf8 Class Initialized
INFO - 2021-02-27 03:04:22 --> URI Class Initialized
INFO - 2021-02-27 03:04:22 --> Router Class Initialized
INFO - 2021-02-27 03:04:22 --> Output Class Initialized
INFO - 2021-02-27 03:04:22 --> Security Class Initialized
DEBUG - 2021-02-27 03:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:04:22 --> Input Class Initialized
INFO - 2021-02-27 03:04:22 --> Language Class Initialized
INFO - 2021-02-27 03:04:22 --> Language Class Initialized
INFO - 2021-02-27 03:04:22 --> Config Class Initialized
INFO - 2021-02-27 03:04:22 --> Loader Class Initialized
INFO - 2021-02-27 03:04:22 --> Helper loaded: url_helper
INFO - 2021-02-27 03:04:22 --> Helper loaded: file_helper
INFO - 2021-02-27 03:04:22 --> Helper loaded: form_helper
INFO - 2021-02-27 03:04:22 --> Helper loaded: my_helper
INFO - 2021-02-27 03:04:22 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:04:22 --> Controller Class Initialized
DEBUG - 2021-02-27 03:04:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-02-27 03:04:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:04:22 --> Final output sent to browser
DEBUG - 2021-02-27 03:04:22 --> Total execution time: 0.3545
INFO - 2021-02-27 03:04:26 --> Config Class Initialized
INFO - 2021-02-27 03:04:26 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:04:26 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:04:26 --> Utf8 Class Initialized
INFO - 2021-02-27 03:04:26 --> URI Class Initialized
INFO - 2021-02-27 03:04:26 --> Router Class Initialized
INFO - 2021-02-27 03:04:26 --> Output Class Initialized
INFO - 2021-02-27 03:04:26 --> Security Class Initialized
DEBUG - 2021-02-27 03:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:04:26 --> Input Class Initialized
INFO - 2021-02-27 03:04:26 --> Language Class Initialized
INFO - 2021-02-27 03:04:26 --> Language Class Initialized
INFO - 2021-02-27 03:04:26 --> Config Class Initialized
INFO - 2021-02-27 03:04:26 --> Loader Class Initialized
INFO - 2021-02-27 03:04:26 --> Helper loaded: url_helper
INFO - 2021-02-27 03:04:26 --> Helper loaded: file_helper
INFO - 2021-02-27 03:04:26 --> Helper loaded: form_helper
INFO - 2021-02-27 03:04:26 --> Helper loaded: my_helper
INFO - 2021-02-27 03:04:26 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:04:26 --> Controller Class Initialized
DEBUG - 2021-02-27 03:04:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-02-27 03:04:26 --> Final output sent to browser
DEBUG - 2021-02-27 03:04:26 --> Total execution time: 0.3767
INFO - 2021-02-27 03:11:56 --> Config Class Initialized
INFO - 2021-02-27 03:11:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:11:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:11:56 --> Utf8 Class Initialized
INFO - 2021-02-27 03:11:56 --> URI Class Initialized
INFO - 2021-02-27 03:11:56 --> Router Class Initialized
INFO - 2021-02-27 03:11:56 --> Output Class Initialized
INFO - 2021-02-27 03:11:56 --> Security Class Initialized
DEBUG - 2021-02-27 03:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:11:56 --> Input Class Initialized
INFO - 2021-02-27 03:11:56 --> Language Class Initialized
INFO - 2021-02-27 03:11:56 --> Language Class Initialized
INFO - 2021-02-27 03:11:56 --> Config Class Initialized
INFO - 2021-02-27 03:11:56 --> Loader Class Initialized
INFO - 2021-02-27 03:11:56 --> Helper loaded: url_helper
INFO - 2021-02-27 03:11:56 --> Helper loaded: file_helper
INFO - 2021-02-27 03:11:56 --> Helper loaded: form_helper
INFO - 2021-02-27 03:11:56 --> Helper loaded: my_helper
INFO - 2021-02-27 03:11:56 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:11:56 --> Controller Class Initialized
INFO - 2021-02-27 03:11:56 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:11:56 --> Config Class Initialized
INFO - 2021-02-27 03:11:56 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:11:56 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:11:56 --> Utf8 Class Initialized
INFO - 2021-02-27 03:11:56 --> URI Class Initialized
INFO - 2021-02-27 03:11:56 --> Router Class Initialized
INFO - 2021-02-27 03:11:56 --> Output Class Initialized
INFO - 2021-02-27 03:11:56 --> Security Class Initialized
DEBUG - 2021-02-27 03:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:11:56 --> Input Class Initialized
INFO - 2021-02-27 03:11:56 --> Language Class Initialized
INFO - 2021-02-27 03:11:56 --> Language Class Initialized
INFO - 2021-02-27 03:11:56 --> Config Class Initialized
INFO - 2021-02-27 03:11:56 --> Loader Class Initialized
INFO - 2021-02-27 03:11:56 --> Helper loaded: url_helper
INFO - 2021-02-27 03:11:56 --> Helper loaded: file_helper
INFO - 2021-02-27 03:11:56 --> Helper loaded: form_helper
INFO - 2021-02-27 03:11:56 --> Helper loaded: my_helper
INFO - 2021-02-27 03:11:56 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:11:56 --> Controller Class Initialized
DEBUG - 2021-02-27 03:11:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:11:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:11:56 --> Final output sent to browser
DEBUG - 2021-02-27 03:11:56 --> Total execution time: 0.3411
INFO - 2021-02-27 03:12:09 --> Config Class Initialized
INFO - 2021-02-27 03:12:09 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:09 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:09 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:09 --> URI Class Initialized
INFO - 2021-02-27 03:12:09 --> Router Class Initialized
INFO - 2021-02-27 03:12:09 --> Output Class Initialized
INFO - 2021-02-27 03:12:09 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:09 --> Input Class Initialized
INFO - 2021-02-27 03:12:09 --> Language Class Initialized
INFO - 2021-02-27 03:12:09 --> Language Class Initialized
INFO - 2021-02-27 03:12:09 --> Config Class Initialized
INFO - 2021-02-27 03:12:09 --> Loader Class Initialized
INFO - 2021-02-27 03:12:09 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:09 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:09 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:09 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:09 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:09 --> Controller Class Initialized
INFO - 2021-02-27 03:12:09 --> Final output sent to browser
DEBUG - 2021-02-27 03:12:09 --> Total execution time: 0.3621
INFO - 2021-02-27 03:12:23 --> Config Class Initialized
INFO - 2021-02-27 03:12:23 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:23 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:23 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:23 --> URI Class Initialized
INFO - 2021-02-27 03:12:23 --> Router Class Initialized
INFO - 2021-02-27 03:12:23 --> Output Class Initialized
INFO - 2021-02-27 03:12:23 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:23 --> Input Class Initialized
INFO - 2021-02-27 03:12:23 --> Language Class Initialized
INFO - 2021-02-27 03:12:23 --> Language Class Initialized
INFO - 2021-02-27 03:12:23 --> Config Class Initialized
INFO - 2021-02-27 03:12:23 --> Loader Class Initialized
INFO - 2021-02-27 03:12:23 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:23 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:23 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:23 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:23 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:23 --> Controller Class Initialized
INFO - 2021-02-27 03:12:23 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:12:23 --> Final output sent to browser
DEBUG - 2021-02-27 03:12:23 --> Total execution time: 0.3750
INFO - 2021-02-27 03:12:25 --> Config Class Initialized
INFO - 2021-02-27 03:12:25 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:25 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:25 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:25 --> URI Class Initialized
INFO - 2021-02-27 03:12:25 --> Router Class Initialized
INFO - 2021-02-27 03:12:25 --> Output Class Initialized
INFO - 2021-02-27 03:12:25 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:25 --> Input Class Initialized
INFO - 2021-02-27 03:12:25 --> Language Class Initialized
INFO - 2021-02-27 03:12:25 --> Language Class Initialized
INFO - 2021-02-27 03:12:25 --> Config Class Initialized
INFO - 2021-02-27 03:12:25 --> Loader Class Initialized
INFO - 2021-02-27 03:12:25 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:25 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:25 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:25 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:25 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:25 --> Controller Class Initialized
DEBUG - 2021-02-27 03:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:12:25 --> Final output sent to browser
DEBUG - 2021-02-27 03:12:25 --> Total execution time: 0.4848
INFO - 2021-02-27 03:12:29 --> Config Class Initialized
INFO - 2021-02-27 03:12:29 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:29 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:29 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:29 --> URI Class Initialized
INFO - 2021-02-27 03:12:29 --> Router Class Initialized
INFO - 2021-02-27 03:12:29 --> Output Class Initialized
INFO - 2021-02-27 03:12:29 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:29 --> Input Class Initialized
INFO - 2021-02-27 03:12:29 --> Language Class Initialized
INFO - 2021-02-27 03:12:29 --> Language Class Initialized
INFO - 2021-02-27 03:12:29 --> Config Class Initialized
INFO - 2021-02-27 03:12:29 --> Loader Class Initialized
INFO - 2021-02-27 03:12:29 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:29 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:29 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:29 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:29 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:29 --> Controller Class Initialized
DEBUG - 2021-02-27 03:12:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-02-27 03:12:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:12:29 --> Final output sent to browser
DEBUG - 2021-02-27 03:12:29 --> Total execution time: 0.3688
INFO - 2021-02-27 03:12:29 --> Config Class Initialized
INFO - 2021-02-27 03:12:29 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:29 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:29 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:29 --> URI Class Initialized
INFO - 2021-02-27 03:12:29 --> Router Class Initialized
INFO - 2021-02-27 03:12:29 --> Output Class Initialized
INFO - 2021-02-27 03:12:29 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:29 --> Input Class Initialized
INFO - 2021-02-27 03:12:29 --> Language Class Initialized
INFO - 2021-02-27 03:12:29 --> Language Class Initialized
INFO - 2021-02-27 03:12:29 --> Config Class Initialized
INFO - 2021-02-27 03:12:29 --> Loader Class Initialized
INFO - 2021-02-27 03:12:29 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:29 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:29 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:29 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:29 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:29 --> Controller Class Initialized
INFO - 2021-02-27 03:12:35 --> Config Class Initialized
INFO - 2021-02-27 03:12:35 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:35 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:35 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:35 --> URI Class Initialized
INFO - 2021-02-27 03:12:35 --> Router Class Initialized
INFO - 2021-02-27 03:12:35 --> Output Class Initialized
INFO - 2021-02-27 03:12:35 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:35 --> Input Class Initialized
INFO - 2021-02-27 03:12:35 --> Language Class Initialized
INFO - 2021-02-27 03:12:35 --> Language Class Initialized
INFO - 2021-02-27 03:12:35 --> Config Class Initialized
INFO - 2021-02-27 03:12:35 --> Loader Class Initialized
INFO - 2021-02-27 03:12:35 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:35 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:35 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:35 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:35 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:35 --> Controller Class Initialized
INFO - 2021-02-27 03:12:48 --> Config Class Initialized
INFO - 2021-02-27 03:12:48 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:48 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:48 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:48 --> URI Class Initialized
INFO - 2021-02-27 03:12:48 --> Router Class Initialized
INFO - 2021-02-27 03:12:49 --> Output Class Initialized
INFO - 2021-02-27 03:12:49 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:49 --> Input Class Initialized
INFO - 2021-02-27 03:12:49 --> Language Class Initialized
INFO - 2021-02-27 03:12:49 --> Language Class Initialized
INFO - 2021-02-27 03:12:49 --> Config Class Initialized
INFO - 2021-02-27 03:12:49 --> Loader Class Initialized
INFO - 2021-02-27 03:12:49 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:49 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:49 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:49 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:49 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:49 --> Controller Class Initialized
INFO - 2021-02-27 03:12:49 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:12:49 --> Config Class Initialized
INFO - 2021-02-27 03:12:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:49 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:49 --> URI Class Initialized
INFO - 2021-02-27 03:12:49 --> Router Class Initialized
INFO - 2021-02-27 03:12:49 --> Output Class Initialized
INFO - 2021-02-27 03:12:49 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:49 --> Input Class Initialized
INFO - 2021-02-27 03:12:49 --> Language Class Initialized
INFO - 2021-02-27 03:12:49 --> Language Class Initialized
INFO - 2021-02-27 03:12:49 --> Config Class Initialized
INFO - 2021-02-27 03:12:49 --> Loader Class Initialized
INFO - 2021-02-27 03:12:49 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:49 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:49 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:49 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:49 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:49 --> Controller Class Initialized
DEBUG - 2021-02-27 03:12:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:12:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:12:49 --> Final output sent to browser
DEBUG - 2021-02-27 03:12:49 --> Total execution time: 0.3455
INFO - 2021-02-27 03:12:54 --> Config Class Initialized
INFO - 2021-02-27 03:12:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:54 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:54 --> URI Class Initialized
INFO - 2021-02-27 03:12:54 --> Router Class Initialized
INFO - 2021-02-27 03:12:54 --> Output Class Initialized
INFO - 2021-02-27 03:12:54 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:54 --> Input Class Initialized
INFO - 2021-02-27 03:12:54 --> Language Class Initialized
INFO - 2021-02-27 03:12:54 --> Language Class Initialized
INFO - 2021-02-27 03:12:54 --> Config Class Initialized
INFO - 2021-02-27 03:12:54 --> Loader Class Initialized
INFO - 2021-02-27 03:12:54 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:54 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:54 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:54 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:54 --> Controller Class Initialized
INFO - 2021-02-27 03:12:54 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:12:54 --> Final output sent to browser
DEBUG - 2021-02-27 03:12:54 --> Total execution time: 0.4201
INFO - 2021-02-27 03:12:55 --> Config Class Initialized
INFO - 2021-02-27 03:12:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:55 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:55 --> URI Class Initialized
INFO - 2021-02-27 03:12:55 --> Router Class Initialized
INFO - 2021-02-27 03:12:55 --> Output Class Initialized
INFO - 2021-02-27 03:12:55 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:55 --> Input Class Initialized
INFO - 2021-02-27 03:12:55 --> Language Class Initialized
INFO - 2021-02-27 03:12:55 --> Language Class Initialized
INFO - 2021-02-27 03:12:55 --> Config Class Initialized
INFO - 2021-02-27 03:12:55 --> Loader Class Initialized
INFO - 2021-02-27 03:12:55 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:55 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:55 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:55 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:55 --> Controller Class Initialized
DEBUG - 2021-02-27 03:12:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:12:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:12:55 --> Final output sent to browser
DEBUG - 2021-02-27 03:12:55 --> Total execution time: 0.4712
INFO - 2021-02-27 03:12:59 --> Config Class Initialized
INFO - 2021-02-27 03:12:59 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:12:59 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:12:59 --> Utf8 Class Initialized
INFO - 2021-02-27 03:12:59 --> URI Class Initialized
INFO - 2021-02-27 03:12:59 --> Router Class Initialized
INFO - 2021-02-27 03:12:59 --> Output Class Initialized
INFO - 2021-02-27 03:12:59 --> Security Class Initialized
DEBUG - 2021-02-27 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:12:59 --> Input Class Initialized
INFO - 2021-02-27 03:12:59 --> Language Class Initialized
INFO - 2021-02-27 03:12:59 --> Language Class Initialized
INFO - 2021-02-27 03:12:59 --> Config Class Initialized
INFO - 2021-02-27 03:12:59 --> Loader Class Initialized
INFO - 2021-02-27 03:12:59 --> Helper loaded: url_helper
INFO - 2021-02-27 03:12:59 --> Helper loaded: file_helper
INFO - 2021-02-27 03:12:59 --> Helper loaded: form_helper
INFO - 2021-02-27 03:12:59 --> Helper loaded: my_helper
INFO - 2021-02-27 03:12:59 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:12:59 --> Controller Class Initialized
DEBUG - 2021-02-27 03:12:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-02-27 03:12:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:12:59 --> Final output sent to browser
DEBUG - 2021-02-27 03:12:59 --> Total execution time: 0.3513
INFO - 2021-02-27 03:13:04 --> Config Class Initialized
INFO - 2021-02-27 03:13:04 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:13:04 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:13:04 --> Utf8 Class Initialized
INFO - 2021-02-27 03:13:04 --> URI Class Initialized
INFO - 2021-02-27 03:13:04 --> Router Class Initialized
INFO - 2021-02-27 03:13:04 --> Output Class Initialized
INFO - 2021-02-27 03:13:04 --> Security Class Initialized
DEBUG - 2021-02-27 03:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:13:04 --> Input Class Initialized
INFO - 2021-02-27 03:13:04 --> Language Class Initialized
INFO - 2021-02-27 03:13:04 --> Language Class Initialized
INFO - 2021-02-27 03:13:04 --> Config Class Initialized
INFO - 2021-02-27 03:13:04 --> Loader Class Initialized
INFO - 2021-02-27 03:13:04 --> Helper loaded: url_helper
INFO - 2021-02-27 03:13:04 --> Helper loaded: file_helper
INFO - 2021-02-27 03:13:04 --> Helper loaded: form_helper
INFO - 2021-02-27 03:13:04 --> Helper loaded: my_helper
INFO - 2021-02-27 03:13:05 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:13:05 --> Controller Class Initialized
DEBUG - 2021-02-27 03:13:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-02-27 03:13:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:13:05 --> Final output sent to browser
DEBUG - 2021-02-27 03:13:05 --> Total execution time: 0.3181
INFO - 2021-02-27 03:13:06 --> Config Class Initialized
INFO - 2021-02-27 03:13:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:13:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:13:06 --> Utf8 Class Initialized
INFO - 2021-02-27 03:13:06 --> URI Class Initialized
INFO - 2021-02-27 03:13:06 --> Router Class Initialized
INFO - 2021-02-27 03:13:06 --> Output Class Initialized
INFO - 2021-02-27 03:13:06 --> Security Class Initialized
DEBUG - 2021-02-27 03:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:13:06 --> Input Class Initialized
INFO - 2021-02-27 03:13:06 --> Language Class Initialized
INFO - 2021-02-27 03:13:06 --> Language Class Initialized
INFO - 2021-02-27 03:13:06 --> Config Class Initialized
INFO - 2021-02-27 03:13:06 --> Loader Class Initialized
INFO - 2021-02-27 03:13:06 --> Helper loaded: url_helper
INFO - 2021-02-27 03:13:06 --> Helper loaded: file_helper
INFO - 2021-02-27 03:13:06 --> Helper loaded: form_helper
INFO - 2021-02-27 03:13:06 --> Helper loaded: my_helper
INFO - 2021-02-27 03:13:06 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:13:06 --> Controller Class Initialized
DEBUG - 2021-02-27 03:13:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2021-02-27 03:13:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:13:06 --> Final output sent to browser
DEBUG - 2021-02-27 03:13:06 --> Total execution time: 0.3091
INFO - 2021-02-27 03:13:16 --> Config Class Initialized
INFO - 2021-02-27 03:13:16 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:13:16 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:13:17 --> Utf8 Class Initialized
INFO - 2021-02-27 03:13:17 --> URI Class Initialized
INFO - 2021-02-27 03:13:17 --> Router Class Initialized
INFO - 2021-02-27 03:13:17 --> Output Class Initialized
INFO - 2021-02-27 03:13:17 --> Security Class Initialized
DEBUG - 2021-02-27 03:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:13:17 --> Input Class Initialized
INFO - 2021-02-27 03:13:17 --> Language Class Initialized
INFO - 2021-02-27 03:13:17 --> Language Class Initialized
INFO - 2021-02-27 03:13:17 --> Config Class Initialized
INFO - 2021-02-27 03:13:17 --> Loader Class Initialized
INFO - 2021-02-27 03:13:17 --> Helper loaded: url_helper
INFO - 2021-02-27 03:13:17 --> Helper loaded: file_helper
INFO - 2021-02-27 03:13:17 --> Helper loaded: form_helper
INFO - 2021-02-27 03:13:17 --> Helper loaded: my_helper
INFO - 2021-02-27 03:13:17 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:13:17 --> Controller Class Initialized
DEBUG - 2021-02-27 03:13:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-02-27 03:13:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:13:17 --> Final output sent to browser
DEBUG - 2021-02-27 03:13:17 --> Total execution time: 0.3658
INFO - 2021-02-27 03:13:17 --> Config Class Initialized
INFO - 2021-02-27 03:13:17 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:13:17 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:13:17 --> Utf8 Class Initialized
INFO - 2021-02-27 03:13:17 --> URI Class Initialized
INFO - 2021-02-27 03:13:17 --> Router Class Initialized
INFO - 2021-02-27 03:13:17 --> Output Class Initialized
INFO - 2021-02-27 03:13:17 --> Security Class Initialized
DEBUG - 2021-02-27 03:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:13:17 --> Input Class Initialized
INFO - 2021-02-27 03:13:17 --> Language Class Initialized
INFO - 2021-02-27 03:13:17 --> Language Class Initialized
INFO - 2021-02-27 03:13:17 --> Config Class Initialized
INFO - 2021-02-27 03:13:17 --> Loader Class Initialized
INFO - 2021-02-27 03:13:17 --> Helper loaded: url_helper
INFO - 2021-02-27 03:13:17 --> Helper loaded: file_helper
INFO - 2021-02-27 03:13:17 --> Helper loaded: form_helper
INFO - 2021-02-27 03:13:17 --> Helper loaded: my_helper
INFO - 2021-02-27 03:13:17 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:13:17 --> Controller Class Initialized
DEBUG - 2021-02-27 03:13:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-02-27 03:13:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:13:17 --> Final output sent to browser
DEBUG - 2021-02-27 03:13:17 --> Total execution time: 0.3320
INFO - 2021-02-27 03:13:29 --> Config Class Initialized
INFO - 2021-02-27 03:13:29 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:13:29 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:13:29 --> Utf8 Class Initialized
INFO - 2021-02-27 03:13:29 --> URI Class Initialized
INFO - 2021-02-27 03:13:29 --> Router Class Initialized
INFO - 2021-02-27 03:13:29 --> Output Class Initialized
INFO - 2021-02-27 03:13:29 --> Security Class Initialized
DEBUG - 2021-02-27 03:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:13:29 --> Input Class Initialized
INFO - 2021-02-27 03:13:29 --> Language Class Initialized
INFO - 2021-02-27 03:13:29 --> Language Class Initialized
INFO - 2021-02-27 03:13:29 --> Config Class Initialized
INFO - 2021-02-27 03:13:29 --> Loader Class Initialized
INFO - 2021-02-27 03:13:29 --> Helper loaded: url_helper
INFO - 2021-02-27 03:13:29 --> Helper loaded: file_helper
INFO - 2021-02-27 03:13:29 --> Helper loaded: form_helper
INFO - 2021-02-27 03:13:29 --> Helper loaded: my_helper
INFO - 2021-02-27 03:13:29 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:13:29 --> Controller Class Initialized
INFO - 2021-02-27 03:13:29 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:13:29 --> Config Class Initialized
INFO - 2021-02-27 03:13:29 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:13:29 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:13:29 --> Utf8 Class Initialized
INFO - 2021-02-27 03:13:30 --> URI Class Initialized
INFO - 2021-02-27 03:13:30 --> Router Class Initialized
INFO - 2021-02-27 03:13:30 --> Output Class Initialized
INFO - 2021-02-27 03:13:30 --> Security Class Initialized
DEBUG - 2021-02-27 03:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:13:30 --> Input Class Initialized
INFO - 2021-02-27 03:13:30 --> Language Class Initialized
INFO - 2021-02-27 03:13:30 --> Language Class Initialized
INFO - 2021-02-27 03:13:30 --> Config Class Initialized
INFO - 2021-02-27 03:13:30 --> Loader Class Initialized
INFO - 2021-02-27 03:13:30 --> Helper loaded: url_helper
INFO - 2021-02-27 03:13:30 --> Helper loaded: file_helper
INFO - 2021-02-27 03:13:30 --> Helper loaded: form_helper
INFO - 2021-02-27 03:13:30 --> Helper loaded: my_helper
INFO - 2021-02-27 03:13:30 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:13:30 --> Controller Class Initialized
DEBUG - 2021-02-27 03:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:13:30 --> Final output sent to browser
DEBUG - 2021-02-27 03:13:30 --> Total execution time: 0.3442
INFO - 2021-02-27 03:14:15 --> Config Class Initialized
INFO - 2021-02-27 03:14:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:14:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:14:15 --> Utf8 Class Initialized
INFO - 2021-02-27 03:14:15 --> URI Class Initialized
INFO - 2021-02-27 03:14:16 --> Router Class Initialized
INFO - 2021-02-27 03:14:16 --> Output Class Initialized
INFO - 2021-02-27 03:14:16 --> Security Class Initialized
DEBUG - 2021-02-27 03:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:14:16 --> Input Class Initialized
INFO - 2021-02-27 03:14:16 --> Language Class Initialized
INFO - 2021-02-27 03:14:16 --> Language Class Initialized
INFO - 2021-02-27 03:14:16 --> Config Class Initialized
INFO - 2021-02-27 03:14:16 --> Loader Class Initialized
INFO - 2021-02-27 03:14:16 --> Helper loaded: url_helper
INFO - 2021-02-27 03:14:16 --> Helper loaded: file_helper
INFO - 2021-02-27 03:14:16 --> Helper loaded: form_helper
INFO - 2021-02-27 03:14:16 --> Helper loaded: my_helper
INFO - 2021-02-27 03:14:16 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:14:16 --> Controller Class Initialized
INFO - 2021-02-27 03:14:17 --> Final output sent to browser
DEBUG - 2021-02-27 03:14:17 --> Total execution time: 1.3465
INFO - 2021-02-27 03:14:21 --> Config Class Initialized
INFO - 2021-02-27 03:14:21 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:14:21 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:14:21 --> Utf8 Class Initialized
INFO - 2021-02-27 03:14:21 --> URI Class Initialized
INFO - 2021-02-27 03:14:21 --> Router Class Initialized
INFO - 2021-02-27 03:14:21 --> Output Class Initialized
INFO - 2021-02-27 03:14:21 --> Security Class Initialized
DEBUG - 2021-02-27 03:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:14:21 --> Input Class Initialized
INFO - 2021-02-27 03:14:21 --> Language Class Initialized
INFO - 2021-02-27 03:14:21 --> Language Class Initialized
INFO - 2021-02-27 03:14:21 --> Config Class Initialized
INFO - 2021-02-27 03:14:21 --> Loader Class Initialized
INFO - 2021-02-27 03:14:21 --> Helper loaded: url_helper
INFO - 2021-02-27 03:14:21 --> Helper loaded: file_helper
INFO - 2021-02-27 03:14:21 --> Helper loaded: form_helper
INFO - 2021-02-27 03:14:21 --> Helper loaded: my_helper
INFO - 2021-02-27 03:14:21 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:14:22 --> Controller Class Initialized
INFO - 2021-02-27 03:14:22 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:14:22 --> Final output sent to browser
DEBUG - 2021-02-27 03:14:22 --> Total execution time: 1.0470
INFO - 2021-02-27 03:14:22 --> Config Class Initialized
INFO - 2021-02-27 03:14:22 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:14:22 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:14:22 --> Utf8 Class Initialized
INFO - 2021-02-27 03:14:22 --> URI Class Initialized
INFO - 2021-02-27 03:14:22 --> Router Class Initialized
INFO - 2021-02-27 03:14:22 --> Output Class Initialized
INFO - 2021-02-27 03:14:22 --> Security Class Initialized
DEBUG - 2021-02-27 03:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:14:22 --> Input Class Initialized
INFO - 2021-02-27 03:14:22 --> Language Class Initialized
INFO - 2021-02-27 03:14:22 --> Language Class Initialized
INFO - 2021-02-27 03:14:23 --> Config Class Initialized
INFO - 2021-02-27 03:14:23 --> Loader Class Initialized
INFO - 2021-02-27 03:14:23 --> Helper loaded: url_helper
INFO - 2021-02-27 03:14:23 --> Helper loaded: file_helper
INFO - 2021-02-27 03:14:23 --> Helper loaded: form_helper
INFO - 2021-02-27 03:14:23 --> Helper loaded: my_helper
INFO - 2021-02-27 03:14:23 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:14:23 --> Controller Class Initialized
DEBUG - 2021-02-27 03:14:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:14:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:14:23 --> Final output sent to browser
DEBUG - 2021-02-27 03:14:23 --> Total execution time: 0.9090
INFO - 2021-02-27 03:14:25 --> Config Class Initialized
INFO - 2021-02-27 03:14:25 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:14:25 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:14:25 --> Utf8 Class Initialized
INFO - 2021-02-27 03:14:25 --> URI Class Initialized
INFO - 2021-02-27 03:14:25 --> Router Class Initialized
INFO - 2021-02-27 03:14:25 --> Output Class Initialized
INFO - 2021-02-27 03:14:25 --> Security Class Initialized
DEBUG - 2021-02-27 03:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:14:25 --> Input Class Initialized
INFO - 2021-02-27 03:14:25 --> Language Class Initialized
INFO - 2021-02-27 03:14:25 --> Language Class Initialized
INFO - 2021-02-27 03:14:25 --> Config Class Initialized
INFO - 2021-02-27 03:14:25 --> Loader Class Initialized
INFO - 2021-02-27 03:14:25 --> Helper loaded: url_helper
INFO - 2021-02-27 03:14:25 --> Helper loaded: file_helper
INFO - 2021-02-27 03:14:25 --> Helper loaded: form_helper
INFO - 2021-02-27 03:14:25 --> Helper loaded: my_helper
INFO - 2021-02-27 03:14:25 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:14:25 --> Controller Class Initialized
DEBUG - 2021-02-27 03:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-02-27 03:14:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:14:26 --> Final output sent to browser
DEBUG - 2021-02-27 03:14:26 --> Total execution time: 1.0389
INFO - 2021-02-27 03:14:26 --> Config Class Initialized
INFO - 2021-02-27 03:14:26 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:14:26 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:14:26 --> Utf8 Class Initialized
INFO - 2021-02-27 03:14:26 --> URI Class Initialized
INFO - 2021-02-27 03:14:26 --> Router Class Initialized
INFO - 2021-02-27 03:14:26 --> Output Class Initialized
INFO - 2021-02-27 03:14:26 --> Security Class Initialized
DEBUG - 2021-02-27 03:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:14:26 --> Input Class Initialized
INFO - 2021-02-27 03:14:26 --> Language Class Initialized
INFO - 2021-02-27 03:14:26 --> Language Class Initialized
INFO - 2021-02-27 03:14:26 --> Config Class Initialized
INFO - 2021-02-27 03:14:26 --> Loader Class Initialized
INFO - 2021-02-27 03:14:26 --> Helper loaded: url_helper
INFO - 2021-02-27 03:14:26 --> Helper loaded: file_helper
INFO - 2021-02-27 03:14:26 --> Helper loaded: form_helper
INFO - 2021-02-27 03:14:26 --> Helper loaded: my_helper
INFO - 2021-02-27 03:14:26 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:14:27 --> Controller Class Initialized
INFO - 2021-02-27 03:14:27 --> Config Class Initialized
INFO - 2021-02-27 03:14:27 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:14:27 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:14:27 --> Utf8 Class Initialized
INFO - 2021-02-27 03:14:27 --> URI Class Initialized
INFO - 2021-02-27 03:14:27 --> Router Class Initialized
INFO - 2021-02-27 03:14:27 --> Output Class Initialized
INFO - 2021-02-27 03:14:27 --> Security Class Initialized
DEBUG - 2021-02-27 03:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:14:27 --> Input Class Initialized
INFO - 2021-02-27 03:14:27 --> Language Class Initialized
INFO - 2021-02-27 03:14:27 --> Language Class Initialized
INFO - 2021-02-27 03:14:27 --> Config Class Initialized
INFO - 2021-02-27 03:14:27 --> Loader Class Initialized
INFO - 2021-02-27 03:14:27 --> Helper loaded: url_helper
INFO - 2021-02-27 03:14:28 --> Helper loaded: file_helper
INFO - 2021-02-27 03:14:28 --> Helper loaded: form_helper
INFO - 2021-02-27 03:14:28 --> Helper loaded: my_helper
INFO - 2021-02-27 03:14:28 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:14:28 --> Controller Class Initialized
ERROR - 2021-02-27 03:14:28 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-02-27 03:14:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-02-27 03:14:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:14:28 --> Final output sent to browser
DEBUG - 2021-02-27 03:14:28 --> Total execution time: 1.2325
INFO - 2021-02-27 03:15:04 --> Config Class Initialized
INFO - 2021-02-27 03:15:04 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:15:04 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:15:04 --> Utf8 Class Initialized
INFO - 2021-02-27 03:15:04 --> URI Class Initialized
INFO - 2021-02-27 03:15:04 --> Router Class Initialized
INFO - 2021-02-27 03:15:04 --> Output Class Initialized
INFO - 2021-02-27 03:15:04 --> Security Class Initialized
DEBUG - 2021-02-27 03:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:15:04 --> Input Class Initialized
INFO - 2021-02-27 03:15:04 --> Language Class Initialized
INFO - 2021-02-27 03:15:04 --> Language Class Initialized
INFO - 2021-02-27 03:15:04 --> Config Class Initialized
INFO - 2021-02-27 03:15:04 --> Loader Class Initialized
INFO - 2021-02-27 03:15:05 --> Helper loaded: url_helper
INFO - 2021-02-27 03:15:05 --> Helper loaded: file_helper
INFO - 2021-02-27 03:15:05 --> Helper loaded: form_helper
INFO - 2021-02-27 03:15:05 --> Helper loaded: my_helper
INFO - 2021-02-27 03:15:05 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:15:05 --> Controller Class Initialized
DEBUG - 2021-02-27 03:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-02-27 03:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:15:05 --> Final output sent to browser
DEBUG - 2021-02-27 03:15:05 --> Total execution time: 1.1411
INFO - 2021-02-27 03:15:05 --> Config Class Initialized
INFO - 2021-02-27 03:15:05 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:15:05 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:15:06 --> Utf8 Class Initialized
INFO - 2021-02-27 03:15:06 --> URI Class Initialized
INFO - 2021-02-27 03:15:06 --> Router Class Initialized
INFO - 2021-02-27 03:15:06 --> Output Class Initialized
INFO - 2021-02-27 03:15:06 --> Security Class Initialized
DEBUG - 2021-02-27 03:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:15:06 --> Input Class Initialized
INFO - 2021-02-27 03:15:06 --> Language Class Initialized
INFO - 2021-02-27 03:15:06 --> Language Class Initialized
INFO - 2021-02-27 03:15:06 --> Config Class Initialized
INFO - 2021-02-27 03:15:06 --> Loader Class Initialized
INFO - 2021-02-27 03:15:06 --> Helper loaded: url_helper
INFO - 2021-02-27 03:15:06 --> Helper loaded: file_helper
INFO - 2021-02-27 03:15:06 --> Helper loaded: form_helper
INFO - 2021-02-27 03:15:06 --> Helper loaded: my_helper
INFO - 2021-02-27 03:15:06 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:15:06 --> Controller Class Initialized
INFO - 2021-02-27 03:15:42 --> Config Class Initialized
INFO - 2021-02-27 03:15:42 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:15:42 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:15:42 --> Utf8 Class Initialized
INFO - 2021-02-27 03:15:42 --> URI Class Initialized
INFO - 2021-02-27 03:15:42 --> Router Class Initialized
INFO - 2021-02-27 03:15:42 --> Output Class Initialized
INFO - 2021-02-27 03:15:42 --> Security Class Initialized
DEBUG - 2021-02-27 03:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:15:42 --> Input Class Initialized
INFO - 2021-02-27 03:15:42 --> Language Class Initialized
INFO - 2021-02-27 03:15:42 --> Language Class Initialized
INFO - 2021-02-27 03:15:42 --> Config Class Initialized
INFO - 2021-02-27 03:15:42 --> Loader Class Initialized
INFO - 2021-02-27 03:15:42 --> Helper loaded: url_helper
INFO - 2021-02-27 03:15:42 --> Helper loaded: file_helper
INFO - 2021-02-27 03:15:42 --> Helper loaded: form_helper
INFO - 2021-02-27 03:15:42 --> Helper loaded: my_helper
INFO - 2021-02-27 03:15:42 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:15:42 --> Controller Class Initialized
INFO - 2021-02-27 03:15:47 --> Config Class Initialized
INFO - 2021-02-27 03:15:47 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:15:47 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:15:47 --> Utf8 Class Initialized
INFO - 2021-02-27 03:15:47 --> URI Class Initialized
INFO - 2021-02-27 03:15:47 --> Router Class Initialized
INFO - 2021-02-27 03:15:47 --> Output Class Initialized
INFO - 2021-02-27 03:15:47 --> Security Class Initialized
DEBUG - 2021-02-27 03:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:15:47 --> Input Class Initialized
INFO - 2021-02-27 03:15:47 --> Language Class Initialized
INFO - 2021-02-27 03:15:47 --> Language Class Initialized
INFO - 2021-02-27 03:15:48 --> Config Class Initialized
INFO - 2021-02-27 03:15:48 --> Loader Class Initialized
INFO - 2021-02-27 03:15:48 --> Helper loaded: url_helper
INFO - 2021-02-27 03:15:48 --> Helper loaded: file_helper
INFO - 2021-02-27 03:15:48 --> Helper loaded: form_helper
INFO - 2021-02-27 03:15:48 --> Helper loaded: my_helper
INFO - 2021-02-27 03:15:48 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:15:48 --> Controller Class Initialized
INFO - 2021-02-27 03:15:48 --> Config Class Initialized
INFO - 2021-02-27 03:15:48 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:15:48 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:15:48 --> Utf8 Class Initialized
INFO - 2021-02-27 03:15:48 --> URI Class Initialized
INFO - 2021-02-27 03:15:48 --> Router Class Initialized
INFO - 2021-02-27 03:15:48 --> Output Class Initialized
INFO - 2021-02-27 03:15:48 --> Security Class Initialized
DEBUG - 2021-02-27 03:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:15:48 --> Input Class Initialized
INFO - 2021-02-27 03:15:48 --> Language Class Initialized
INFO - 2021-02-27 03:15:48 --> Language Class Initialized
INFO - 2021-02-27 03:15:48 --> Config Class Initialized
INFO - 2021-02-27 03:15:48 --> Loader Class Initialized
INFO - 2021-02-27 03:15:49 --> Helper loaded: url_helper
INFO - 2021-02-27 03:15:49 --> Helper loaded: file_helper
INFO - 2021-02-27 03:15:49 --> Helper loaded: form_helper
INFO - 2021-02-27 03:15:49 --> Helper loaded: my_helper
INFO - 2021-02-27 03:15:49 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:15:49 --> Controller Class Initialized
INFO - 2021-02-27 03:15:49 --> Config Class Initialized
INFO - 2021-02-27 03:15:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:15:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:15:49 --> Utf8 Class Initialized
INFO - 2021-02-27 03:15:49 --> URI Class Initialized
INFO - 2021-02-27 03:15:49 --> Router Class Initialized
INFO - 2021-02-27 03:15:49 --> Output Class Initialized
INFO - 2021-02-27 03:15:49 --> Security Class Initialized
DEBUG - 2021-02-27 03:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:15:49 --> Input Class Initialized
INFO - 2021-02-27 03:15:49 --> Language Class Initialized
INFO - 2021-02-27 03:15:49 --> Language Class Initialized
INFO - 2021-02-27 03:15:49 --> Config Class Initialized
INFO - 2021-02-27 03:15:49 --> Loader Class Initialized
INFO - 2021-02-27 03:15:49 --> Helper loaded: url_helper
INFO - 2021-02-27 03:15:50 --> Helper loaded: file_helper
INFO - 2021-02-27 03:15:50 --> Helper loaded: form_helper
INFO - 2021-02-27 03:15:50 --> Helper loaded: my_helper
INFO - 2021-02-27 03:15:50 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:15:50 --> Controller Class Initialized
INFO - 2021-02-27 03:16:19 --> Config Class Initialized
INFO - 2021-02-27 03:16:19 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:19 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:19 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:20 --> URI Class Initialized
INFO - 2021-02-27 03:16:20 --> Router Class Initialized
INFO - 2021-02-27 03:16:20 --> Output Class Initialized
INFO - 2021-02-27 03:16:20 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:20 --> Input Class Initialized
INFO - 2021-02-27 03:16:20 --> Language Class Initialized
INFO - 2021-02-27 03:16:20 --> Language Class Initialized
INFO - 2021-02-27 03:16:20 --> Config Class Initialized
INFO - 2021-02-27 03:16:20 --> Loader Class Initialized
INFO - 2021-02-27 03:16:20 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:20 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:20 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:20 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:20 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:20 --> Controller Class Initialized
INFO - 2021-02-27 03:16:20 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:16:20 --> Config Class Initialized
INFO - 2021-02-27 03:16:20 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:20 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:20 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:20 --> URI Class Initialized
INFO - 2021-02-27 03:16:20 --> Router Class Initialized
INFO - 2021-02-27 03:16:21 --> Output Class Initialized
INFO - 2021-02-27 03:16:21 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:21 --> Input Class Initialized
INFO - 2021-02-27 03:16:21 --> Language Class Initialized
INFO - 2021-02-27 03:16:21 --> Language Class Initialized
INFO - 2021-02-27 03:16:21 --> Config Class Initialized
INFO - 2021-02-27 03:16:21 --> Loader Class Initialized
INFO - 2021-02-27 03:16:21 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:21 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:21 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:21 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:21 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:21 --> Controller Class Initialized
DEBUG - 2021-02-27 03:16:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:16:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:16:21 --> Final output sent to browser
DEBUG - 2021-02-27 03:16:21 --> Total execution time: 1.1706
INFO - 2021-02-27 03:16:36 --> Config Class Initialized
INFO - 2021-02-27 03:16:36 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:36 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:36 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:37 --> URI Class Initialized
INFO - 2021-02-27 03:16:37 --> Router Class Initialized
INFO - 2021-02-27 03:16:37 --> Output Class Initialized
INFO - 2021-02-27 03:16:37 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:37 --> Input Class Initialized
INFO - 2021-02-27 03:16:37 --> Language Class Initialized
INFO - 2021-02-27 03:16:37 --> Language Class Initialized
INFO - 2021-02-27 03:16:37 --> Config Class Initialized
INFO - 2021-02-27 03:16:37 --> Loader Class Initialized
INFO - 2021-02-27 03:16:37 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:37 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:37 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:37 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:37 --> Controller Class Initialized
INFO - 2021-02-27 03:16:38 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:16:38 --> Final output sent to browser
DEBUG - 2021-02-27 03:16:38 --> Total execution time: 1.1331
INFO - 2021-02-27 03:16:39 --> Config Class Initialized
INFO - 2021-02-27 03:16:39 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:39 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:39 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:39 --> URI Class Initialized
INFO - 2021-02-27 03:16:39 --> Router Class Initialized
INFO - 2021-02-27 03:16:39 --> Output Class Initialized
INFO - 2021-02-27 03:16:39 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:39 --> Input Class Initialized
INFO - 2021-02-27 03:16:39 --> Language Class Initialized
INFO - 2021-02-27 03:16:39 --> Language Class Initialized
INFO - 2021-02-27 03:16:39 --> Config Class Initialized
INFO - 2021-02-27 03:16:39 --> Loader Class Initialized
INFO - 2021-02-27 03:16:39 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:39 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:39 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:39 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:39 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:39 --> Controller Class Initialized
DEBUG - 2021-02-27 03:16:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:16:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:16:40 --> Final output sent to browser
DEBUG - 2021-02-27 03:16:40 --> Total execution time: 0.9190
INFO - 2021-02-27 03:16:41 --> Config Class Initialized
INFO - 2021-02-27 03:16:41 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:41 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:41 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:41 --> URI Class Initialized
INFO - 2021-02-27 03:16:41 --> Router Class Initialized
INFO - 2021-02-27 03:16:41 --> Output Class Initialized
INFO - 2021-02-27 03:16:41 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:41 --> Input Class Initialized
INFO - 2021-02-27 03:16:42 --> Language Class Initialized
INFO - 2021-02-27 03:16:42 --> Language Class Initialized
INFO - 2021-02-27 03:16:42 --> Config Class Initialized
INFO - 2021-02-27 03:16:42 --> Loader Class Initialized
INFO - 2021-02-27 03:16:42 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:42 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:42 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:42 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:42 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:42 --> Controller Class Initialized
DEBUG - 2021-02-27 03:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-27 03:16:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:16:42 --> Final output sent to browser
DEBUG - 2021-02-27 03:16:42 --> Total execution time: 0.9497
INFO - 2021-02-27 03:16:42 --> Config Class Initialized
INFO - 2021-02-27 03:16:42 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:42 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:43 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:43 --> URI Class Initialized
INFO - 2021-02-27 03:16:43 --> Router Class Initialized
INFO - 2021-02-27 03:16:43 --> Output Class Initialized
INFO - 2021-02-27 03:16:43 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:43 --> Input Class Initialized
INFO - 2021-02-27 03:16:43 --> Language Class Initialized
INFO - 2021-02-27 03:16:43 --> Language Class Initialized
INFO - 2021-02-27 03:16:43 --> Config Class Initialized
INFO - 2021-02-27 03:16:43 --> Loader Class Initialized
INFO - 2021-02-27 03:16:43 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:43 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:43 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:43 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:43 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:43 --> Controller Class Initialized
INFO - 2021-02-27 03:16:45 --> Config Class Initialized
INFO - 2021-02-27 03:16:45 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:46 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:46 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:46 --> URI Class Initialized
INFO - 2021-02-27 03:16:46 --> Router Class Initialized
INFO - 2021-02-27 03:16:46 --> Output Class Initialized
INFO - 2021-02-27 03:16:46 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:46 --> Input Class Initialized
INFO - 2021-02-27 03:16:46 --> Language Class Initialized
INFO - 2021-02-27 03:16:46 --> Language Class Initialized
INFO - 2021-02-27 03:16:46 --> Config Class Initialized
INFO - 2021-02-27 03:16:46 --> Loader Class Initialized
INFO - 2021-02-27 03:16:46 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:46 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:46 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:46 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:46 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:46 --> Controller Class Initialized
INFO - 2021-02-27 03:16:46 --> Final output sent to browser
DEBUG - 2021-02-27 03:16:46 --> Total execution time: 0.8621
INFO - 2021-02-27 03:16:46 --> Config Class Initialized
INFO - 2021-02-27 03:16:46 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:47 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:47 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:47 --> URI Class Initialized
INFO - 2021-02-27 03:16:47 --> Router Class Initialized
INFO - 2021-02-27 03:16:47 --> Output Class Initialized
INFO - 2021-02-27 03:16:47 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:47 --> Input Class Initialized
INFO - 2021-02-27 03:16:47 --> Language Class Initialized
INFO - 2021-02-27 03:16:47 --> Language Class Initialized
INFO - 2021-02-27 03:16:47 --> Config Class Initialized
INFO - 2021-02-27 03:16:47 --> Loader Class Initialized
INFO - 2021-02-27 03:16:47 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:47 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:47 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:47 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:47 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:48 --> Controller Class Initialized
INFO - 2021-02-27 03:16:50 --> Config Class Initialized
INFO - 2021-02-27 03:16:50 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:50 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:50 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:50 --> URI Class Initialized
INFO - 2021-02-27 03:16:50 --> Router Class Initialized
INFO - 2021-02-27 03:16:50 --> Output Class Initialized
INFO - 2021-02-27 03:16:50 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:50 --> Input Class Initialized
INFO - 2021-02-27 03:16:50 --> Language Class Initialized
INFO - 2021-02-27 03:16:50 --> Language Class Initialized
INFO - 2021-02-27 03:16:50 --> Config Class Initialized
INFO - 2021-02-27 03:16:51 --> Loader Class Initialized
INFO - 2021-02-27 03:16:51 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:51 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:51 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:51 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:51 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:51 --> Controller Class Initialized
DEBUG - 2021-02-27 03:16:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 03:16:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:16:51 --> Final output sent to browser
DEBUG - 2021-02-27 03:16:51 --> Total execution time: 1.1924
INFO - 2021-02-27 03:16:53 --> Config Class Initialized
INFO - 2021-02-27 03:16:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:54 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:54 --> URI Class Initialized
INFO - 2021-02-27 03:16:54 --> Router Class Initialized
INFO - 2021-02-27 03:16:54 --> Output Class Initialized
INFO - 2021-02-27 03:16:54 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:54 --> Input Class Initialized
INFO - 2021-02-27 03:16:54 --> Language Class Initialized
INFO - 2021-02-27 03:16:54 --> Language Class Initialized
INFO - 2021-02-27 03:16:54 --> Config Class Initialized
INFO - 2021-02-27 03:16:54 --> Loader Class Initialized
INFO - 2021-02-27 03:16:54 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:54 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:54 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:54 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:54 --> Controller Class Initialized
DEBUG - 2021-02-27 03:16:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-27 03:16:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:16:55 --> Final output sent to browser
DEBUG - 2021-02-27 03:16:55 --> Total execution time: 1.0474
INFO - 2021-02-27 03:16:55 --> Config Class Initialized
INFO - 2021-02-27 03:16:55 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:55 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:55 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:55 --> URI Class Initialized
INFO - 2021-02-27 03:16:55 --> Router Class Initialized
INFO - 2021-02-27 03:16:55 --> Output Class Initialized
INFO - 2021-02-27 03:16:55 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:55 --> Input Class Initialized
INFO - 2021-02-27 03:16:55 --> Language Class Initialized
INFO - 2021-02-27 03:16:55 --> Language Class Initialized
INFO - 2021-02-27 03:16:55 --> Config Class Initialized
INFO - 2021-02-27 03:16:55 --> Loader Class Initialized
INFO - 2021-02-27 03:16:55 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:55 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:55 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:55 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:55 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:55 --> Controller Class Initialized
INFO - 2021-02-27 03:16:57 --> Config Class Initialized
INFO - 2021-02-27 03:16:57 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:57 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:58 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:58 --> URI Class Initialized
INFO - 2021-02-27 03:16:58 --> Router Class Initialized
INFO - 2021-02-27 03:16:58 --> Output Class Initialized
INFO - 2021-02-27 03:16:58 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:58 --> Input Class Initialized
INFO - 2021-02-27 03:16:58 --> Language Class Initialized
INFO - 2021-02-27 03:16:58 --> Language Class Initialized
INFO - 2021-02-27 03:16:58 --> Config Class Initialized
INFO - 2021-02-27 03:16:58 --> Loader Class Initialized
INFO - 2021-02-27 03:16:58 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:58 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:58 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:58 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:58 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:16:58 --> Controller Class Initialized
INFO - 2021-02-27 03:16:58 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:16:59 --> Config Class Initialized
INFO - 2021-02-27 03:16:59 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:16:59 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:16:59 --> Utf8 Class Initialized
INFO - 2021-02-27 03:16:59 --> URI Class Initialized
INFO - 2021-02-27 03:16:59 --> Router Class Initialized
INFO - 2021-02-27 03:16:59 --> Output Class Initialized
INFO - 2021-02-27 03:16:59 --> Security Class Initialized
DEBUG - 2021-02-27 03:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:16:59 --> Input Class Initialized
INFO - 2021-02-27 03:16:59 --> Language Class Initialized
INFO - 2021-02-27 03:16:59 --> Language Class Initialized
INFO - 2021-02-27 03:16:59 --> Config Class Initialized
INFO - 2021-02-27 03:16:59 --> Loader Class Initialized
INFO - 2021-02-27 03:16:59 --> Helper loaded: url_helper
INFO - 2021-02-27 03:16:59 --> Helper loaded: file_helper
INFO - 2021-02-27 03:16:59 --> Helper loaded: form_helper
INFO - 2021-02-27 03:16:59 --> Helper loaded: my_helper
INFO - 2021-02-27 03:16:59 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:00 --> Controller Class Initialized
DEBUG - 2021-02-27 03:17:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:17:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:17:00 --> Final output sent to browser
DEBUG - 2021-02-27 03:17:00 --> Total execution time: 1.1227
INFO - 2021-02-27 03:17:06 --> Config Class Initialized
INFO - 2021-02-27 03:17:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:06 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:06 --> URI Class Initialized
INFO - 2021-02-27 03:17:06 --> Router Class Initialized
INFO - 2021-02-27 03:17:06 --> Output Class Initialized
INFO - 2021-02-27 03:17:06 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:06 --> Input Class Initialized
INFO - 2021-02-27 03:17:06 --> Language Class Initialized
INFO - 2021-02-27 03:17:06 --> Language Class Initialized
INFO - 2021-02-27 03:17:06 --> Config Class Initialized
INFO - 2021-02-27 03:17:06 --> Loader Class Initialized
INFO - 2021-02-27 03:17:06 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:06 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:06 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:06 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:06 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:07 --> Controller Class Initialized
INFO - 2021-02-27 03:17:07 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:17:07 --> Final output sent to browser
DEBUG - 2021-02-27 03:17:07 --> Total execution time: 0.9203
INFO - 2021-02-27 03:17:08 --> Config Class Initialized
INFO - 2021-02-27 03:17:08 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:08 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:08 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:08 --> URI Class Initialized
INFO - 2021-02-27 03:17:08 --> Router Class Initialized
INFO - 2021-02-27 03:17:08 --> Output Class Initialized
INFO - 2021-02-27 03:17:08 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:08 --> Input Class Initialized
INFO - 2021-02-27 03:17:08 --> Language Class Initialized
INFO - 2021-02-27 03:17:08 --> Language Class Initialized
INFO - 2021-02-27 03:17:08 --> Config Class Initialized
INFO - 2021-02-27 03:17:08 --> Loader Class Initialized
INFO - 2021-02-27 03:17:08 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:08 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:08 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:08 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:08 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:08 --> Controller Class Initialized
DEBUG - 2021-02-27 03:17:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:17:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:17:08 --> Final output sent to browser
DEBUG - 2021-02-27 03:17:09 --> Total execution time: 0.9635
INFO - 2021-02-27 03:17:10 --> Config Class Initialized
INFO - 2021-02-27 03:17:11 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:11 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:11 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:11 --> URI Class Initialized
INFO - 2021-02-27 03:17:11 --> Router Class Initialized
INFO - 2021-02-27 03:17:11 --> Output Class Initialized
INFO - 2021-02-27 03:17:11 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:11 --> Input Class Initialized
INFO - 2021-02-27 03:17:11 --> Language Class Initialized
INFO - 2021-02-27 03:17:11 --> Language Class Initialized
INFO - 2021-02-27 03:17:11 --> Config Class Initialized
INFO - 2021-02-27 03:17:11 --> Loader Class Initialized
INFO - 2021-02-27 03:17:11 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:11 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:11 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:11 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:11 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:11 --> Controller Class Initialized
DEBUG - 2021-02-27 03:17:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-27 03:17:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:17:11 --> Final output sent to browser
DEBUG - 2021-02-27 03:17:12 --> Total execution time: 1.0029
INFO - 2021-02-27 03:17:12 --> Config Class Initialized
INFO - 2021-02-27 03:17:12 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:12 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:12 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:12 --> URI Class Initialized
INFO - 2021-02-27 03:17:12 --> Router Class Initialized
INFO - 2021-02-27 03:17:12 --> Output Class Initialized
INFO - 2021-02-27 03:17:12 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:12 --> Input Class Initialized
INFO - 2021-02-27 03:17:12 --> Language Class Initialized
INFO - 2021-02-27 03:17:12 --> Language Class Initialized
INFO - 2021-02-27 03:17:12 --> Config Class Initialized
INFO - 2021-02-27 03:17:12 --> Loader Class Initialized
INFO - 2021-02-27 03:17:12 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:12 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:12 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:12 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:12 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:12 --> Controller Class Initialized
INFO - 2021-02-27 03:17:15 --> Config Class Initialized
INFO - 2021-02-27 03:17:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:15 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:15 --> URI Class Initialized
INFO - 2021-02-27 03:17:15 --> Router Class Initialized
INFO - 2021-02-27 03:17:15 --> Output Class Initialized
INFO - 2021-02-27 03:17:15 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:15 --> Input Class Initialized
INFO - 2021-02-27 03:17:15 --> Language Class Initialized
INFO - 2021-02-27 03:17:15 --> Language Class Initialized
INFO - 2021-02-27 03:17:15 --> Config Class Initialized
INFO - 2021-02-27 03:17:15 --> Loader Class Initialized
INFO - 2021-02-27 03:17:15 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:15 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:15 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:15 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:15 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:16 --> Controller Class Initialized
INFO - 2021-02-27 03:17:26 --> Config Class Initialized
INFO - 2021-02-27 03:17:26 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:26 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:26 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:26 --> URI Class Initialized
INFO - 2021-02-27 03:17:27 --> Router Class Initialized
INFO - 2021-02-27 03:17:27 --> Output Class Initialized
INFO - 2021-02-27 03:17:27 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:27 --> Input Class Initialized
INFO - 2021-02-27 03:17:27 --> Language Class Initialized
INFO - 2021-02-27 03:17:27 --> Language Class Initialized
INFO - 2021-02-27 03:17:27 --> Config Class Initialized
INFO - 2021-02-27 03:17:27 --> Loader Class Initialized
INFO - 2021-02-27 03:17:27 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:27 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:27 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:27 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:27 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:27 --> Controller Class Initialized
INFO - 2021-02-27 03:17:27 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:17:27 --> Config Class Initialized
INFO - 2021-02-27 03:17:28 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:28 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:28 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:28 --> URI Class Initialized
INFO - 2021-02-27 03:17:28 --> Router Class Initialized
INFO - 2021-02-27 03:17:28 --> Output Class Initialized
INFO - 2021-02-27 03:17:28 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:28 --> Input Class Initialized
INFO - 2021-02-27 03:17:28 --> Language Class Initialized
INFO - 2021-02-27 03:17:28 --> Language Class Initialized
INFO - 2021-02-27 03:17:28 --> Config Class Initialized
INFO - 2021-02-27 03:17:28 --> Loader Class Initialized
INFO - 2021-02-27 03:17:28 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:28 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:28 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:28 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:28 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:28 --> Controller Class Initialized
DEBUG - 2021-02-27 03:17:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:17:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:17:29 --> Final output sent to browser
DEBUG - 2021-02-27 03:17:29 --> Total execution time: 1.1859
INFO - 2021-02-27 03:17:35 --> Config Class Initialized
INFO - 2021-02-27 03:17:35 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:35 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:35 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:35 --> URI Class Initialized
INFO - 2021-02-27 03:17:35 --> Router Class Initialized
INFO - 2021-02-27 03:17:35 --> Output Class Initialized
INFO - 2021-02-27 03:17:35 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:35 --> Input Class Initialized
INFO - 2021-02-27 03:17:35 --> Language Class Initialized
INFO - 2021-02-27 03:17:35 --> Language Class Initialized
INFO - 2021-02-27 03:17:35 --> Config Class Initialized
INFO - 2021-02-27 03:17:35 --> Loader Class Initialized
INFO - 2021-02-27 03:17:35 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:35 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:35 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:35 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:35 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:35 --> Controller Class Initialized
INFO - 2021-02-27 03:17:36 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:17:36 --> Final output sent to browser
DEBUG - 2021-02-27 03:17:36 --> Total execution time: 0.9218
INFO - 2021-02-27 03:17:36 --> Config Class Initialized
INFO - 2021-02-27 03:17:36 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:36 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:36 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:36 --> URI Class Initialized
INFO - 2021-02-27 03:17:36 --> Router Class Initialized
INFO - 2021-02-27 03:17:36 --> Output Class Initialized
INFO - 2021-02-27 03:17:36 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:37 --> Input Class Initialized
INFO - 2021-02-27 03:17:37 --> Language Class Initialized
INFO - 2021-02-27 03:17:37 --> Language Class Initialized
INFO - 2021-02-27 03:17:37 --> Config Class Initialized
INFO - 2021-02-27 03:17:37 --> Loader Class Initialized
INFO - 2021-02-27 03:17:37 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:37 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:37 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:37 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:37 --> Controller Class Initialized
DEBUG - 2021-02-27 03:17:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:17:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:17:37 --> Final output sent to browser
DEBUG - 2021-02-27 03:17:37 --> Total execution time: 0.9020
INFO - 2021-02-27 03:17:41 --> Config Class Initialized
INFO - 2021-02-27 03:17:41 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:17:41 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:17:41 --> Utf8 Class Initialized
INFO - 2021-02-27 03:17:41 --> URI Class Initialized
INFO - 2021-02-27 03:17:41 --> Router Class Initialized
INFO - 2021-02-27 03:17:41 --> Output Class Initialized
INFO - 2021-02-27 03:17:41 --> Security Class Initialized
DEBUG - 2021-02-27 03:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:17:42 --> Input Class Initialized
INFO - 2021-02-27 03:17:42 --> Language Class Initialized
INFO - 2021-02-27 03:17:42 --> Language Class Initialized
INFO - 2021-02-27 03:17:42 --> Config Class Initialized
INFO - 2021-02-27 03:17:42 --> Loader Class Initialized
INFO - 2021-02-27 03:17:42 --> Helper loaded: url_helper
INFO - 2021-02-27 03:17:42 --> Helper loaded: file_helper
INFO - 2021-02-27 03:17:42 --> Helper loaded: form_helper
INFO - 2021-02-27 03:17:42 --> Helper loaded: my_helper
INFO - 2021-02-27 03:17:42 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:17:42 --> Controller Class Initialized
DEBUG - 2021-02-27 03:17:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-02-27 03:17:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:17:42 --> Final output sent to browser
DEBUG - 2021-02-27 03:17:42 --> Total execution time: 1.0667
INFO - 2021-02-27 03:18:14 --> Config Class Initialized
INFO - 2021-02-27 03:18:14 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:18:14 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:18:14 --> Utf8 Class Initialized
INFO - 2021-02-27 03:18:14 --> URI Class Initialized
INFO - 2021-02-27 03:18:14 --> Router Class Initialized
INFO - 2021-02-27 03:18:14 --> Output Class Initialized
INFO - 2021-02-27 03:18:14 --> Security Class Initialized
DEBUG - 2021-02-27 03:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:18:14 --> Input Class Initialized
INFO - 2021-02-27 03:18:14 --> Language Class Initialized
INFO - 2021-02-27 03:18:14 --> Language Class Initialized
INFO - 2021-02-27 03:18:14 --> Config Class Initialized
INFO - 2021-02-27 03:18:14 --> Loader Class Initialized
INFO - 2021-02-27 03:18:14 --> Helper loaded: url_helper
INFO - 2021-02-27 03:18:15 --> Helper loaded: file_helper
INFO - 2021-02-27 03:18:15 --> Helper loaded: form_helper
INFO - 2021-02-27 03:18:15 --> Helper loaded: my_helper
INFO - 2021-02-27 03:18:15 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:18:15 --> Controller Class Initialized
DEBUG - 2021-02-27 03:18:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2021-02-27 03:18:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:18:15 --> Final output sent to browser
DEBUG - 2021-02-27 03:18:15 --> Total execution time: 1.1310
INFO - 2021-02-27 03:19:15 --> Config Class Initialized
INFO - 2021-02-27 03:19:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:19:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:19:15 --> Utf8 Class Initialized
INFO - 2021-02-27 03:19:15 --> URI Class Initialized
INFO - 2021-02-27 03:19:15 --> Router Class Initialized
INFO - 2021-02-27 03:19:15 --> Output Class Initialized
INFO - 2021-02-27 03:19:15 --> Security Class Initialized
DEBUG - 2021-02-27 03:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:19:15 --> Input Class Initialized
INFO - 2021-02-27 03:19:15 --> Language Class Initialized
INFO - 2021-02-27 03:19:15 --> Language Class Initialized
INFO - 2021-02-27 03:19:15 --> Config Class Initialized
INFO - 2021-02-27 03:19:15 --> Loader Class Initialized
INFO - 2021-02-27 03:19:15 --> Helper loaded: url_helper
INFO - 2021-02-27 03:19:16 --> Helper loaded: file_helper
INFO - 2021-02-27 03:19:16 --> Helper loaded: form_helper
INFO - 2021-02-27 03:19:16 --> Helper loaded: my_helper
INFO - 2021-02-27 03:19:16 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:19:16 --> Controller Class Initialized
INFO - 2021-02-27 03:19:16 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:19:16 --> Config Class Initialized
INFO - 2021-02-27 03:19:16 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:19:16 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:19:16 --> Utf8 Class Initialized
INFO - 2021-02-27 03:19:16 --> URI Class Initialized
INFO - 2021-02-27 03:19:16 --> Router Class Initialized
INFO - 2021-02-27 03:19:16 --> Output Class Initialized
INFO - 2021-02-27 03:19:16 --> Security Class Initialized
DEBUG - 2021-02-27 03:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:19:16 --> Input Class Initialized
INFO - 2021-02-27 03:19:16 --> Language Class Initialized
INFO - 2021-02-27 03:19:16 --> Language Class Initialized
INFO - 2021-02-27 03:19:16 --> Config Class Initialized
INFO - 2021-02-27 03:19:17 --> Loader Class Initialized
INFO - 2021-02-27 03:19:17 --> Helper loaded: url_helper
INFO - 2021-02-27 03:19:17 --> Helper loaded: file_helper
INFO - 2021-02-27 03:19:17 --> Helper loaded: form_helper
INFO - 2021-02-27 03:19:17 --> Helper loaded: my_helper
INFO - 2021-02-27 03:19:17 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:19:17 --> Controller Class Initialized
DEBUG - 2021-02-27 03:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-02-27 03:19:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:19:17 --> Final output sent to browser
DEBUG - 2021-02-27 03:19:17 --> Total execution time: 1.1192
INFO - 2021-02-27 03:21:03 --> Config Class Initialized
INFO - 2021-02-27 03:21:03 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:21:03 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:21:03 --> Utf8 Class Initialized
INFO - 2021-02-27 03:21:03 --> URI Class Initialized
INFO - 2021-02-27 03:21:03 --> Router Class Initialized
INFO - 2021-02-27 03:21:03 --> Output Class Initialized
INFO - 2021-02-27 03:21:03 --> Security Class Initialized
DEBUG - 2021-02-27 03:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:21:04 --> Input Class Initialized
INFO - 2021-02-27 03:21:04 --> Language Class Initialized
INFO - 2021-02-27 03:21:04 --> Language Class Initialized
INFO - 2021-02-27 03:21:04 --> Config Class Initialized
INFO - 2021-02-27 03:21:04 --> Loader Class Initialized
INFO - 2021-02-27 03:21:04 --> Helper loaded: url_helper
INFO - 2021-02-27 03:21:04 --> Helper loaded: file_helper
INFO - 2021-02-27 03:21:04 --> Helper loaded: form_helper
INFO - 2021-02-27 03:21:04 --> Helper loaded: my_helper
INFO - 2021-02-27 03:21:04 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:21:04 --> Controller Class Initialized
INFO - 2021-02-27 03:21:04 --> Helper loaded: cookie_helper
INFO - 2021-02-27 03:21:04 --> Final output sent to browser
DEBUG - 2021-02-27 03:21:04 --> Total execution time: 1.0434
INFO - 2021-02-27 03:21:06 --> Config Class Initialized
INFO - 2021-02-27 03:21:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:21:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:21:06 --> Utf8 Class Initialized
INFO - 2021-02-27 03:21:06 --> URI Class Initialized
INFO - 2021-02-27 03:21:06 --> Router Class Initialized
INFO - 2021-02-27 03:21:06 --> Output Class Initialized
INFO - 2021-02-27 03:21:06 --> Security Class Initialized
DEBUG - 2021-02-27 03:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:21:06 --> Input Class Initialized
INFO - 2021-02-27 03:21:06 --> Language Class Initialized
INFO - 2021-02-27 03:21:06 --> Language Class Initialized
INFO - 2021-02-27 03:21:06 --> Config Class Initialized
INFO - 2021-02-27 03:21:06 --> Loader Class Initialized
INFO - 2021-02-27 03:21:06 --> Helper loaded: url_helper
INFO - 2021-02-27 03:21:06 --> Helper loaded: file_helper
INFO - 2021-02-27 03:21:06 --> Helper loaded: form_helper
INFO - 2021-02-27 03:21:06 --> Helper loaded: my_helper
INFO - 2021-02-27 03:21:06 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:21:07 --> Controller Class Initialized
DEBUG - 2021-02-27 03:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-02-27 03:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:21:07 --> Final output sent to browser
DEBUG - 2021-02-27 03:21:07 --> Total execution time: 0.9671
INFO - 2021-02-27 03:22:09 --> Config Class Initialized
INFO - 2021-02-27 03:22:09 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:22:09 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:22:09 --> Utf8 Class Initialized
INFO - 2021-02-27 03:22:09 --> URI Class Initialized
INFO - 2021-02-27 03:22:09 --> Router Class Initialized
INFO - 2021-02-27 03:22:09 --> Output Class Initialized
INFO - 2021-02-27 03:22:09 --> Security Class Initialized
DEBUG - 2021-02-27 03:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:22:09 --> Input Class Initialized
INFO - 2021-02-27 03:22:09 --> Language Class Initialized
INFO - 2021-02-27 03:22:09 --> Language Class Initialized
INFO - 2021-02-27 03:22:09 --> Config Class Initialized
INFO - 2021-02-27 03:22:09 --> Loader Class Initialized
INFO - 2021-02-27 03:22:09 --> Helper loaded: url_helper
INFO - 2021-02-27 03:22:09 --> Helper loaded: file_helper
INFO - 2021-02-27 03:22:10 --> Helper loaded: form_helper
INFO - 2021-02-27 03:22:10 --> Helper loaded: my_helper
INFO - 2021-02-27 03:22:10 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:22:10 --> Controller Class Initialized
DEBUG - 2021-02-27 03:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 03:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:22:10 --> Final output sent to browser
DEBUG - 2021-02-27 03:22:10 --> Total execution time: 1.1118
INFO - 2021-02-27 03:22:12 --> Config Class Initialized
INFO - 2021-02-27 03:22:12 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:22:12 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:22:12 --> Utf8 Class Initialized
INFO - 2021-02-27 03:22:12 --> URI Class Initialized
INFO - 2021-02-27 03:22:12 --> Router Class Initialized
INFO - 2021-02-27 03:22:12 --> Output Class Initialized
INFO - 2021-02-27 03:22:12 --> Security Class Initialized
DEBUG - 2021-02-27 03:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:22:12 --> Input Class Initialized
INFO - 2021-02-27 03:22:13 --> Language Class Initialized
INFO - 2021-02-27 03:22:13 --> Language Class Initialized
INFO - 2021-02-27 03:22:13 --> Config Class Initialized
INFO - 2021-02-27 03:22:13 --> Loader Class Initialized
INFO - 2021-02-27 03:22:13 --> Helper loaded: url_helper
INFO - 2021-02-27 03:22:13 --> Helper loaded: file_helper
INFO - 2021-02-27 03:22:13 --> Helper loaded: form_helper
INFO - 2021-02-27 03:22:13 --> Helper loaded: my_helper
INFO - 2021-02-27 03:22:13 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:22:13 --> Controller Class Initialized
DEBUG - 2021-02-27 03:22:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-27 03:22:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:22:13 --> Final output sent to browser
DEBUG - 2021-02-27 03:22:13 --> Total execution time: 1.1205
INFO - 2021-02-27 03:22:13 --> Config Class Initialized
INFO - 2021-02-27 03:22:13 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:22:13 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:22:14 --> Utf8 Class Initialized
INFO - 2021-02-27 03:22:14 --> URI Class Initialized
INFO - 2021-02-27 03:22:14 --> Router Class Initialized
INFO - 2021-02-27 03:22:14 --> Output Class Initialized
INFO - 2021-02-27 03:22:14 --> Security Class Initialized
DEBUG - 2021-02-27 03:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:22:14 --> Input Class Initialized
INFO - 2021-02-27 03:22:14 --> Language Class Initialized
INFO - 2021-02-27 03:22:14 --> Language Class Initialized
INFO - 2021-02-27 03:22:14 --> Config Class Initialized
INFO - 2021-02-27 03:22:14 --> Loader Class Initialized
INFO - 2021-02-27 03:22:14 --> Helper loaded: url_helper
INFO - 2021-02-27 03:22:14 --> Helper loaded: file_helper
INFO - 2021-02-27 03:22:14 --> Helper loaded: form_helper
INFO - 2021-02-27 03:22:14 --> Helper loaded: my_helper
INFO - 2021-02-27 03:22:14 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:22:15 --> Controller Class Initialized
INFO - 2021-02-27 03:22:18 --> Config Class Initialized
INFO - 2021-02-27 03:22:18 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:22:18 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:22:18 --> Utf8 Class Initialized
INFO - 2021-02-27 03:22:18 --> URI Class Initialized
INFO - 2021-02-27 03:22:18 --> Router Class Initialized
INFO - 2021-02-27 03:22:18 --> Output Class Initialized
INFO - 2021-02-27 03:22:18 --> Security Class Initialized
DEBUG - 2021-02-27 03:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:22:19 --> Input Class Initialized
INFO - 2021-02-27 03:22:19 --> Language Class Initialized
INFO - 2021-02-27 03:22:19 --> Language Class Initialized
INFO - 2021-02-27 03:22:19 --> Config Class Initialized
INFO - 2021-02-27 03:22:19 --> Loader Class Initialized
INFO - 2021-02-27 03:22:19 --> Helper loaded: url_helper
INFO - 2021-02-27 03:22:19 --> Helper loaded: file_helper
INFO - 2021-02-27 03:22:19 --> Helper loaded: form_helper
INFO - 2021-02-27 03:22:19 --> Helper loaded: my_helper
INFO - 2021-02-27 03:22:19 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:22:19 --> Controller Class Initialized
DEBUG - 2021-02-27 03:22:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-27 03:22:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:22:19 --> Final output sent to browser
DEBUG - 2021-02-27 03:22:19 --> Total execution time: 1.1092
INFO - 2021-02-27 03:22:19 --> Config Class Initialized
INFO - 2021-02-27 03:22:19 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:22:19 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:22:19 --> Utf8 Class Initialized
INFO - 2021-02-27 03:22:20 --> URI Class Initialized
INFO - 2021-02-27 03:22:20 --> Router Class Initialized
INFO - 2021-02-27 03:22:20 --> Output Class Initialized
INFO - 2021-02-27 03:22:20 --> Security Class Initialized
DEBUG - 2021-02-27 03:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:22:20 --> Input Class Initialized
INFO - 2021-02-27 03:22:20 --> Language Class Initialized
INFO - 2021-02-27 03:22:20 --> Language Class Initialized
INFO - 2021-02-27 03:22:20 --> Config Class Initialized
INFO - 2021-02-27 03:22:20 --> Loader Class Initialized
INFO - 2021-02-27 03:22:20 --> Helper loaded: url_helper
INFO - 2021-02-27 03:22:20 --> Helper loaded: file_helper
INFO - 2021-02-27 03:22:20 --> Helper loaded: form_helper
INFO - 2021-02-27 03:22:20 --> Helper loaded: my_helper
INFO - 2021-02-27 03:22:20 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:22:20 --> Controller Class Initialized
INFO - 2021-02-27 03:22:36 --> Config Class Initialized
INFO - 2021-02-27 03:22:36 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:22:36 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:22:36 --> Utf8 Class Initialized
INFO - 2021-02-27 03:22:36 --> URI Class Initialized
INFO - 2021-02-27 03:22:36 --> Router Class Initialized
INFO - 2021-02-27 03:22:36 --> Output Class Initialized
INFO - 2021-02-27 03:22:36 --> Security Class Initialized
DEBUG - 2021-02-27 03:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:22:36 --> Input Class Initialized
INFO - 2021-02-27 03:22:36 --> Language Class Initialized
INFO - 2021-02-27 03:22:36 --> Language Class Initialized
INFO - 2021-02-27 03:22:36 --> Config Class Initialized
INFO - 2021-02-27 03:22:36 --> Loader Class Initialized
INFO - 2021-02-27 03:22:36 --> Helper loaded: url_helper
INFO - 2021-02-27 03:22:37 --> Helper loaded: file_helper
INFO - 2021-02-27 03:22:37 --> Helper loaded: form_helper
INFO - 2021-02-27 03:22:37 --> Helper loaded: my_helper
INFO - 2021-02-27 03:22:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:22:37 --> Controller Class Initialized
DEBUG - 2021-02-27 03:22:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 03:22:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:22:37 --> Final output sent to browser
DEBUG - 2021-02-27 03:22:37 --> Total execution time: 1.2222
INFO - 2021-02-27 03:22:41 --> Config Class Initialized
INFO - 2021-02-27 03:22:41 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:22:41 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:22:41 --> Utf8 Class Initialized
INFO - 2021-02-27 03:22:41 --> URI Class Initialized
INFO - 2021-02-27 03:22:41 --> Router Class Initialized
INFO - 2021-02-27 03:22:41 --> Output Class Initialized
INFO - 2021-02-27 03:22:41 --> Security Class Initialized
DEBUG - 2021-02-27 03:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:22:41 --> Input Class Initialized
INFO - 2021-02-27 03:22:41 --> Language Class Initialized
INFO - 2021-02-27 03:22:41 --> Language Class Initialized
INFO - 2021-02-27 03:22:41 --> Config Class Initialized
INFO - 2021-02-27 03:22:41 --> Loader Class Initialized
INFO - 2021-02-27 03:22:41 --> Helper loaded: url_helper
INFO - 2021-02-27 03:22:41 --> Helper loaded: file_helper
INFO - 2021-02-27 03:22:41 --> Helper loaded: form_helper
INFO - 2021-02-27 03:22:42 --> Helper loaded: my_helper
INFO - 2021-02-27 03:22:42 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:22:42 --> Controller Class Initialized
DEBUG - 2021-02-27 03:22:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-02-27 03:22:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:22:42 --> Final output sent to browser
DEBUG - 2021-02-27 03:22:42 --> Total execution time: 0.9989
INFO - 2021-02-27 03:22:52 --> Config Class Initialized
INFO - 2021-02-27 03:22:52 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:22:52 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:22:52 --> Utf8 Class Initialized
INFO - 2021-02-27 03:22:52 --> URI Class Initialized
INFO - 2021-02-27 03:22:52 --> Router Class Initialized
INFO - 2021-02-27 03:22:52 --> Output Class Initialized
INFO - 2021-02-27 03:22:52 --> Security Class Initialized
DEBUG - 2021-02-27 03:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:22:52 --> Input Class Initialized
INFO - 2021-02-27 03:22:52 --> Language Class Initialized
INFO - 2021-02-27 03:22:52 --> Language Class Initialized
INFO - 2021-02-27 03:22:52 --> Config Class Initialized
INFO - 2021-02-27 03:22:52 --> Loader Class Initialized
INFO - 2021-02-27 03:22:52 --> Helper loaded: url_helper
INFO - 2021-02-27 03:22:52 --> Helper loaded: file_helper
INFO - 2021-02-27 03:22:52 --> Helper loaded: form_helper
INFO - 2021-02-27 03:22:52 --> Helper loaded: my_helper
INFO - 2021-02-27 03:22:52 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:22:52 --> Controller Class Initialized
INFO - 2021-02-27 03:22:52 --> Config Class Initialized
INFO - 2021-02-27 03:22:52 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:22:53 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:22:53 --> Utf8 Class Initialized
INFO - 2021-02-27 03:22:53 --> URI Class Initialized
INFO - 2021-02-27 03:22:53 --> Router Class Initialized
INFO - 2021-02-27 03:22:53 --> Output Class Initialized
INFO - 2021-02-27 03:22:53 --> Security Class Initialized
DEBUG - 2021-02-27 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:22:53 --> Input Class Initialized
INFO - 2021-02-27 03:22:53 --> Language Class Initialized
INFO - 2021-02-27 03:22:53 --> Language Class Initialized
INFO - 2021-02-27 03:22:53 --> Config Class Initialized
INFO - 2021-02-27 03:22:53 --> Loader Class Initialized
INFO - 2021-02-27 03:22:53 --> Helper loaded: url_helper
INFO - 2021-02-27 03:22:53 --> Helper loaded: file_helper
INFO - 2021-02-27 03:22:53 --> Helper loaded: form_helper
INFO - 2021-02-27 03:22:53 --> Helper loaded: my_helper
INFO - 2021-02-27 03:22:53 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:22:53 --> Controller Class Initialized
DEBUG - 2021-02-27 03:22:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 03:22:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:22:54 --> Final output sent to browser
DEBUG - 2021-02-27 03:22:54 --> Total execution time: 1.1154
INFO - 2021-02-27 03:23:07 --> Config Class Initialized
INFO - 2021-02-27 03:23:07 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:23:07 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:23:07 --> Utf8 Class Initialized
INFO - 2021-02-27 03:23:07 --> URI Class Initialized
INFO - 2021-02-27 03:23:07 --> Router Class Initialized
INFO - 2021-02-27 03:23:07 --> Output Class Initialized
INFO - 2021-02-27 03:23:07 --> Security Class Initialized
DEBUG - 2021-02-27 03:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:23:07 --> Input Class Initialized
INFO - 2021-02-27 03:23:07 --> Language Class Initialized
INFO - 2021-02-27 03:23:07 --> Language Class Initialized
INFO - 2021-02-27 03:23:07 --> Config Class Initialized
INFO - 2021-02-27 03:23:07 --> Loader Class Initialized
INFO - 2021-02-27 03:23:07 --> Helper loaded: url_helper
INFO - 2021-02-27 03:23:07 --> Helper loaded: file_helper
INFO - 2021-02-27 03:23:07 --> Helper loaded: form_helper
INFO - 2021-02-27 03:23:07 --> Helper loaded: my_helper
INFO - 2021-02-27 03:23:07 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:23:08 --> Controller Class Initialized
DEBUG - 2021-02-27 03:23:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-27 03:23:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:23:08 --> Final output sent to browser
DEBUG - 2021-02-27 03:23:08 --> Total execution time: 1.0798
INFO - 2021-02-27 03:23:08 --> Config Class Initialized
INFO - 2021-02-27 03:23:08 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:23:08 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:23:08 --> Utf8 Class Initialized
INFO - 2021-02-27 03:23:08 --> URI Class Initialized
INFO - 2021-02-27 03:23:08 --> Router Class Initialized
INFO - 2021-02-27 03:23:08 --> Output Class Initialized
INFO - 2021-02-27 03:23:08 --> Security Class Initialized
DEBUG - 2021-02-27 03:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:23:08 --> Input Class Initialized
INFO - 2021-02-27 03:23:08 --> Language Class Initialized
INFO - 2021-02-27 03:23:08 --> Language Class Initialized
INFO - 2021-02-27 03:23:08 --> Config Class Initialized
INFO - 2021-02-27 03:23:08 --> Loader Class Initialized
INFO - 2021-02-27 03:23:09 --> Helper loaded: url_helper
INFO - 2021-02-27 03:23:09 --> Helper loaded: file_helper
INFO - 2021-02-27 03:23:09 --> Helper loaded: form_helper
INFO - 2021-02-27 03:23:09 --> Helper loaded: my_helper
INFO - 2021-02-27 03:23:09 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:23:09 --> Controller Class Initialized
INFO - 2021-02-27 03:23:14 --> Config Class Initialized
INFO - 2021-02-27 03:23:14 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:23:14 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:23:14 --> Utf8 Class Initialized
INFO - 2021-02-27 03:23:14 --> URI Class Initialized
INFO - 2021-02-27 03:23:14 --> Router Class Initialized
INFO - 2021-02-27 03:23:14 --> Output Class Initialized
INFO - 2021-02-27 03:23:14 --> Security Class Initialized
DEBUG - 2021-02-27 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:23:14 --> Input Class Initialized
INFO - 2021-02-27 03:23:14 --> Language Class Initialized
INFO - 2021-02-27 03:23:14 --> Language Class Initialized
INFO - 2021-02-27 03:23:14 --> Config Class Initialized
INFO - 2021-02-27 03:23:14 --> Loader Class Initialized
INFO - 2021-02-27 03:23:14 --> Helper loaded: url_helper
INFO - 2021-02-27 03:23:14 --> Helper loaded: file_helper
INFO - 2021-02-27 03:23:14 --> Helper loaded: form_helper
INFO - 2021-02-27 03:23:15 --> Helper loaded: my_helper
INFO - 2021-02-27 03:23:15 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:23:15 --> Controller Class Initialized
INFO - 2021-02-27 03:23:15 --> Final output sent to browser
DEBUG - 2021-02-27 03:23:15 --> Total execution time: 0.9663
INFO - 2021-02-27 03:23:15 --> Config Class Initialized
INFO - 2021-02-27 03:23:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:23:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:23:15 --> Utf8 Class Initialized
INFO - 2021-02-27 03:23:15 --> URI Class Initialized
INFO - 2021-02-27 03:23:15 --> Router Class Initialized
INFO - 2021-02-27 03:23:15 --> Output Class Initialized
INFO - 2021-02-27 03:23:15 --> Security Class Initialized
DEBUG - 2021-02-27 03:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:23:15 --> Input Class Initialized
INFO - 2021-02-27 03:23:16 --> Language Class Initialized
INFO - 2021-02-27 03:23:16 --> Language Class Initialized
INFO - 2021-02-27 03:23:16 --> Config Class Initialized
INFO - 2021-02-27 03:23:16 --> Loader Class Initialized
INFO - 2021-02-27 03:23:16 --> Helper loaded: url_helper
INFO - 2021-02-27 03:23:16 --> Helper loaded: file_helper
INFO - 2021-02-27 03:23:16 --> Helper loaded: form_helper
INFO - 2021-02-27 03:23:16 --> Helper loaded: my_helper
INFO - 2021-02-27 03:23:16 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:23:16 --> Controller Class Initialized
INFO - 2021-02-27 03:23:17 --> Config Class Initialized
INFO - 2021-02-27 03:23:17 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:23:17 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:23:17 --> Utf8 Class Initialized
INFO - 2021-02-27 03:23:17 --> URI Class Initialized
INFO - 2021-02-27 03:23:17 --> Router Class Initialized
INFO - 2021-02-27 03:23:17 --> Output Class Initialized
INFO - 2021-02-27 03:23:17 --> Security Class Initialized
DEBUG - 2021-02-27 03:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:23:17 --> Input Class Initialized
INFO - 2021-02-27 03:23:17 --> Language Class Initialized
INFO - 2021-02-27 03:23:17 --> Language Class Initialized
INFO - 2021-02-27 03:23:18 --> Config Class Initialized
INFO - 2021-02-27 03:23:18 --> Loader Class Initialized
INFO - 2021-02-27 03:23:18 --> Helper loaded: url_helper
INFO - 2021-02-27 03:23:18 --> Helper loaded: file_helper
INFO - 2021-02-27 03:23:18 --> Helper loaded: form_helper
INFO - 2021-02-27 03:23:18 --> Helper loaded: my_helper
INFO - 2021-02-27 03:23:18 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:23:18 --> Controller Class Initialized
DEBUG - 2021-02-27 03:23:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 03:23:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:23:18 --> Final output sent to browser
DEBUG - 2021-02-27 03:23:18 --> Total execution time: 1.1233
INFO - 2021-02-27 03:23:27 --> Config Class Initialized
INFO - 2021-02-27 03:23:27 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:23:27 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:23:27 --> Utf8 Class Initialized
INFO - 2021-02-27 03:23:27 --> URI Class Initialized
INFO - 2021-02-27 03:23:27 --> Router Class Initialized
INFO - 2021-02-27 03:23:27 --> Output Class Initialized
INFO - 2021-02-27 03:23:27 --> Security Class Initialized
DEBUG - 2021-02-27 03:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:23:27 --> Input Class Initialized
INFO - 2021-02-27 03:23:27 --> Language Class Initialized
INFO - 2021-02-27 03:23:27 --> Language Class Initialized
INFO - 2021-02-27 03:23:27 --> Config Class Initialized
INFO - 2021-02-27 03:23:28 --> Loader Class Initialized
INFO - 2021-02-27 03:23:28 --> Helper loaded: url_helper
INFO - 2021-02-27 03:23:28 --> Helper loaded: file_helper
INFO - 2021-02-27 03:23:28 --> Helper loaded: form_helper
INFO - 2021-02-27 03:23:28 --> Helper loaded: my_helper
INFO - 2021-02-27 03:23:28 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:23:28 --> Controller Class Initialized
DEBUG - 2021-02-27 03:23:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-27 03:23:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:23:28 --> Final output sent to browser
DEBUG - 2021-02-27 03:23:28 --> Total execution time: 1.2150
INFO - 2021-02-27 03:23:28 --> Config Class Initialized
INFO - 2021-02-27 03:23:28 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:23:28 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:23:28 --> Utf8 Class Initialized
INFO - 2021-02-27 03:23:29 --> URI Class Initialized
INFO - 2021-02-27 03:23:29 --> Router Class Initialized
INFO - 2021-02-27 03:23:29 --> Output Class Initialized
INFO - 2021-02-27 03:23:29 --> Security Class Initialized
DEBUG - 2021-02-27 03:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:23:29 --> Input Class Initialized
INFO - 2021-02-27 03:23:29 --> Language Class Initialized
INFO - 2021-02-27 03:23:29 --> Language Class Initialized
INFO - 2021-02-27 03:23:29 --> Config Class Initialized
INFO - 2021-02-27 03:23:29 --> Loader Class Initialized
INFO - 2021-02-27 03:23:29 --> Helper loaded: url_helper
INFO - 2021-02-27 03:23:29 --> Helper loaded: file_helper
INFO - 2021-02-27 03:23:29 --> Helper loaded: form_helper
INFO - 2021-02-27 03:23:29 --> Helper loaded: my_helper
INFO - 2021-02-27 03:23:29 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:23:29 --> Controller Class Initialized
INFO - 2021-02-27 03:25:39 --> Config Class Initialized
INFO - 2021-02-27 03:25:39 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:25:39 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:25:39 --> Utf8 Class Initialized
INFO - 2021-02-27 03:25:39 --> URI Class Initialized
INFO - 2021-02-27 03:25:39 --> Router Class Initialized
INFO - 2021-02-27 03:25:39 --> Output Class Initialized
INFO - 2021-02-27 03:25:39 --> Security Class Initialized
DEBUG - 2021-02-27 03:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:25:39 --> Input Class Initialized
INFO - 2021-02-27 03:25:39 --> Language Class Initialized
INFO - 2021-02-27 03:25:39 --> Language Class Initialized
INFO - 2021-02-27 03:25:40 --> Config Class Initialized
INFO - 2021-02-27 03:25:40 --> Loader Class Initialized
INFO - 2021-02-27 03:25:40 --> Helper loaded: url_helper
INFO - 2021-02-27 03:25:40 --> Helper loaded: file_helper
INFO - 2021-02-27 03:25:40 --> Helper loaded: form_helper
INFO - 2021-02-27 03:25:40 --> Helper loaded: my_helper
INFO - 2021-02-27 03:25:40 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:25:40 --> Controller Class Initialized
DEBUG - 2021-02-27 03:25:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-02-27 03:25:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:25:40 --> Final output sent to browser
DEBUG - 2021-02-27 03:25:40 --> Total execution time: 1.0898
INFO - 2021-02-27 03:25:40 --> Config Class Initialized
INFO - 2021-02-27 03:25:40 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:25:41 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:25:41 --> Utf8 Class Initialized
INFO - 2021-02-27 03:25:41 --> URI Class Initialized
INFO - 2021-02-27 03:25:41 --> Router Class Initialized
INFO - 2021-02-27 03:25:41 --> Output Class Initialized
INFO - 2021-02-27 03:25:41 --> Security Class Initialized
DEBUG - 2021-02-27 03:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:25:41 --> Input Class Initialized
INFO - 2021-02-27 03:25:41 --> Language Class Initialized
INFO - 2021-02-27 03:25:41 --> Language Class Initialized
INFO - 2021-02-27 03:25:41 --> Config Class Initialized
INFO - 2021-02-27 03:25:41 --> Loader Class Initialized
INFO - 2021-02-27 03:25:41 --> Helper loaded: url_helper
INFO - 2021-02-27 03:25:41 --> Helper loaded: file_helper
INFO - 2021-02-27 03:25:41 --> Helper loaded: form_helper
INFO - 2021-02-27 03:25:41 --> Helper loaded: my_helper
INFO - 2021-02-27 03:25:41 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:25:41 --> Controller Class Initialized
INFO - 2021-02-27 03:25:42 --> Config Class Initialized
INFO - 2021-02-27 03:25:42 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:25:42 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:25:42 --> Utf8 Class Initialized
INFO - 2021-02-27 03:25:42 --> URI Class Initialized
INFO - 2021-02-27 03:25:42 --> Router Class Initialized
INFO - 2021-02-27 03:25:42 --> Output Class Initialized
INFO - 2021-02-27 03:25:42 --> Security Class Initialized
DEBUG - 2021-02-27 03:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:25:42 --> Input Class Initialized
INFO - 2021-02-27 03:25:42 --> Language Class Initialized
INFO - 2021-02-27 03:25:42 --> Language Class Initialized
INFO - 2021-02-27 03:25:42 --> Config Class Initialized
INFO - 2021-02-27 03:25:42 --> Loader Class Initialized
INFO - 2021-02-27 03:25:42 --> Helper loaded: url_helper
INFO - 2021-02-27 03:25:42 --> Helper loaded: file_helper
INFO - 2021-02-27 03:25:42 --> Helper loaded: form_helper
INFO - 2021-02-27 03:25:42 --> Helper loaded: my_helper
INFO - 2021-02-27 03:25:43 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:25:43 --> Controller Class Initialized
ERROR - 2021-02-27 03:25:43 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-02-27 03:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-02-27 03:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:25:43 --> Final output sent to browser
DEBUG - 2021-02-27 03:25:43 --> Total execution time: 1.4293
INFO - 2021-02-27 03:30:49 --> Config Class Initialized
INFO - 2021-02-27 03:30:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:30:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:30:49 --> Utf8 Class Initialized
INFO - 2021-02-27 03:30:49 --> URI Class Initialized
INFO - 2021-02-27 03:30:49 --> Router Class Initialized
INFO - 2021-02-27 03:30:49 --> Output Class Initialized
INFO - 2021-02-27 03:30:50 --> Security Class Initialized
DEBUG - 2021-02-27 03:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:30:50 --> Input Class Initialized
INFO - 2021-02-27 03:30:50 --> Language Class Initialized
INFO - 2021-02-27 03:30:50 --> Language Class Initialized
INFO - 2021-02-27 03:30:50 --> Config Class Initialized
INFO - 2021-02-27 03:30:50 --> Loader Class Initialized
INFO - 2021-02-27 03:30:50 --> Helper loaded: url_helper
INFO - 2021-02-27 03:30:50 --> Helper loaded: file_helper
INFO - 2021-02-27 03:30:50 --> Helper loaded: form_helper
INFO - 2021-02-27 03:30:50 --> Helper loaded: my_helper
INFO - 2021-02-27 03:30:50 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:30:50 --> Controller Class Initialized
DEBUG - 2021-02-27 03:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-02-27 03:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:30:50 --> Final output sent to browser
DEBUG - 2021-02-27 03:30:50 --> Total execution time: 0.9766
INFO - 2021-02-27 03:30:50 --> Config Class Initialized
INFO - 2021-02-27 03:30:51 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:30:51 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:30:51 --> Utf8 Class Initialized
INFO - 2021-02-27 03:30:51 --> URI Class Initialized
INFO - 2021-02-27 03:30:51 --> Router Class Initialized
INFO - 2021-02-27 03:30:51 --> Output Class Initialized
INFO - 2021-02-27 03:30:51 --> Security Class Initialized
DEBUG - 2021-02-27 03:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:30:51 --> Input Class Initialized
INFO - 2021-02-27 03:30:51 --> Language Class Initialized
INFO - 2021-02-27 03:30:51 --> Language Class Initialized
INFO - 2021-02-27 03:30:51 --> Config Class Initialized
INFO - 2021-02-27 03:30:51 --> Loader Class Initialized
INFO - 2021-02-27 03:30:51 --> Helper loaded: url_helper
INFO - 2021-02-27 03:30:51 --> Helper loaded: file_helper
INFO - 2021-02-27 03:30:51 --> Helper loaded: form_helper
INFO - 2021-02-27 03:30:51 --> Helper loaded: my_helper
INFO - 2021-02-27 03:30:51 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:30:52 --> Controller Class Initialized
INFO - 2021-02-27 03:30:52 --> Config Class Initialized
INFO - 2021-02-27 03:30:52 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:30:52 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:30:52 --> Utf8 Class Initialized
INFO - 2021-02-27 03:30:52 --> URI Class Initialized
INFO - 2021-02-27 03:30:52 --> Router Class Initialized
INFO - 2021-02-27 03:30:52 --> Output Class Initialized
INFO - 2021-02-27 03:30:52 --> Security Class Initialized
DEBUG - 2021-02-27 03:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:30:52 --> Input Class Initialized
INFO - 2021-02-27 03:30:52 --> Language Class Initialized
INFO - 2021-02-27 03:30:52 --> Language Class Initialized
INFO - 2021-02-27 03:30:52 --> Config Class Initialized
INFO - 2021-02-27 03:30:52 --> Loader Class Initialized
INFO - 2021-02-27 03:30:52 --> Helper loaded: url_helper
INFO - 2021-02-27 03:30:52 --> Helper loaded: file_helper
INFO - 2021-02-27 03:30:52 --> Helper loaded: form_helper
INFO - 2021-02-27 03:30:52 --> Helper loaded: my_helper
INFO - 2021-02-27 03:30:53 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:30:53 --> Controller Class Initialized
INFO - 2021-02-27 03:30:53 --> Final output sent to browser
DEBUG - 2021-02-27 03:30:53 --> Total execution time: 1.0014
INFO - 2021-02-27 03:31:14 --> Config Class Initialized
INFO - 2021-02-27 03:31:14 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:31:14 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:31:14 --> Utf8 Class Initialized
INFO - 2021-02-27 03:31:14 --> URI Class Initialized
INFO - 2021-02-27 03:31:14 --> Router Class Initialized
INFO - 2021-02-27 03:31:14 --> Output Class Initialized
INFO - 2021-02-27 03:31:14 --> Security Class Initialized
DEBUG - 2021-02-27 03:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:31:14 --> Input Class Initialized
INFO - 2021-02-27 03:31:14 --> Language Class Initialized
INFO - 2021-02-27 03:31:14 --> Language Class Initialized
INFO - 2021-02-27 03:31:14 --> Config Class Initialized
INFO - 2021-02-27 03:31:14 --> Loader Class Initialized
INFO - 2021-02-27 03:31:14 --> Helper loaded: url_helper
INFO - 2021-02-27 03:31:14 --> Helper loaded: file_helper
INFO - 2021-02-27 03:31:14 --> Helper loaded: form_helper
INFO - 2021-02-27 03:31:14 --> Helper loaded: my_helper
INFO - 2021-02-27 03:31:14 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:31:14 --> Controller Class Initialized
DEBUG - 2021-02-27 03:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-02-27 03:31:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:31:15 --> Final output sent to browser
DEBUG - 2021-02-27 03:31:15 --> Total execution time: 1.0717
INFO - 2021-02-27 03:31:15 --> Config Class Initialized
INFO - 2021-02-27 03:31:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:31:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:31:15 --> Utf8 Class Initialized
INFO - 2021-02-27 03:31:15 --> URI Class Initialized
INFO - 2021-02-27 03:31:15 --> Router Class Initialized
INFO - 2021-02-27 03:31:15 --> Output Class Initialized
INFO - 2021-02-27 03:31:15 --> Security Class Initialized
DEBUG - 2021-02-27 03:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:31:15 --> Input Class Initialized
INFO - 2021-02-27 03:31:15 --> Language Class Initialized
INFO - 2021-02-27 03:31:15 --> Language Class Initialized
INFO - 2021-02-27 03:31:15 --> Config Class Initialized
INFO - 2021-02-27 03:31:15 --> Loader Class Initialized
INFO - 2021-02-27 03:31:16 --> Helper loaded: url_helper
INFO - 2021-02-27 03:31:16 --> Helper loaded: file_helper
INFO - 2021-02-27 03:31:16 --> Helper loaded: form_helper
INFO - 2021-02-27 03:31:16 --> Helper loaded: my_helper
INFO - 2021-02-27 03:31:16 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:31:16 --> Controller Class Initialized
INFO - 2021-02-27 03:31:18 --> Config Class Initialized
INFO - 2021-02-27 03:31:18 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:31:18 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:31:18 --> Utf8 Class Initialized
INFO - 2021-02-27 03:31:18 --> URI Class Initialized
INFO - 2021-02-27 03:31:18 --> Router Class Initialized
INFO - 2021-02-27 03:31:18 --> Output Class Initialized
INFO - 2021-02-27 03:31:18 --> Security Class Initialized
DEBUG - 2021-02-27 03:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:31:19 --> Input Class Initialized
INFO - 2021-02-27 03:31:19 --> Language Class Initialized
INFO - 2021-02-27 03:31:19 --> Language Class Initialized
INFO - 2021-02-27 03:31:19 --> Config Class Initialized
INFO - 2021-02-27 03:31:19 --> Loader Class Initialized
INFO - 2021-02-27 03:31:19 --> Helper loaded: url_helper
INFO - 2021-02-27 03:31:19 --> Helper loaded: file_helper
INFO - 2021-02-27 03:31:19 --> Helper loaded: form_helper
INFO - 2021-02-27 03:31:19 --> Helper loaded: my_helper
INFO - 2021-02-27 03:31:19 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:31:19 --> Controller Class Initialized
INFO - 2021-02-27 03:31:19 --> Final output sent to browser
DEBUG - 2021-02-27 03:31:19 --> Total execution time: 1.0530
INFO - 2021-02-27 03:31:25 --> Config Class Initialized
INFO - 2021-02-27 03:31:25 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:31:25 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:31:25 --> Utf8 Class Initialized
INFO - 2021-02-27 03:31:25 --> URI Class Initialized
INFO - 2021-02-27 03:31:25 --> Router Class Initialized
INFO - 2021-02-27 03:31:25 --> Output Class Initialized
INFO - 2021-02-27 03:31:25 --> Security Class Initialized
DEBUG - 2021-02-27 03:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:31:25 --> Input Class Initialized
INFO - 2021-02-27 03:31:25 --> Language Class Initialized
INFO - 2021-02-27 03:31:25 --> Language Class Initialized
INFO - 2021-02-27 03:31:25 --> Config Class Initialized
INFO - 2021-02-27 03:31:25 --> Loader Class Initialized
INFO - 2021-02-27 03:31:25 --> Helper loaded: url_helper
INFO - 2021-02-27 03:31:25 --> Helper loaded: file_helper
INFO - 2021-02-27 03:31:26 --> Helper loaded: form_helper
INFO - 2021-02-27 03:31:26 --> Helper loaded: my_helper
INFO - 2021-02-27 03:31:26 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:31:26 --> Controller Class Initialized
DEBUG - 2021-02-27 03:31:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-02-27 03:31:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:31:26 --> Final output sent to browser
DEBUG - 2021-02-27 03:31:26 --> Total execution time: 0.9942
INFO - 2021-02-27 03:31:26 --> Config Class Initialized
INFO - 2021-02-27 03:31:26 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:31:26 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:31:26 --> Utf8 Class Initialized
INFO - 2021-02-27 03:31:26 --> URI Class Initialized
INFO - 2021-02-27 03:31:26 --> Router Class Initialized
INFO - 2021-02-27 03:31:26 --> Output Class Initialized
INFO - 2021-02-27 03:31:26 --> Security Class Initialized
DEBUG - 2021-02-27 03:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:31:26 --> Input Class Initialized
INFO - 2021-02-27 03:31:26 --> Language Class Initialized
INFO - 2021-02-27 03:31:27 --> Language Class Initialized
INFO - 2021-02-27 03:31:27 --> Config Class Initialized
INFO - 2021-02-27 03:31:27 --> Loader Class Initialized
INFO - 2021-02-27 03:31:27 --> Helper loaded: url_helper
INFO - 2021-02-27 03:31:27 --> Helper loaded: file_helper
INFO - 2021-02-27 03:31:27 --> Helper loaded: form_helper
INFO - 2021-02-27 03:31:27 --> Helper loaded: my_helper
INFO - 2021-02-27 03:31:27 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:31:27 --> Controller Class Initialized
INFO - 2021-02-27 03:32:14 --> Config Class Initialized
INFO - 2021-02-27 03:32:14 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:14 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:14 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:14 --> URI Class Initialized
INFO - 2021-02-27 03:32:15 --> Router Class Initialized
INFO - 2021-02-27 03:32:15 --> Output Class Initialized
INFO - 2021-02-27 03:32:15 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:15 --> Input Class Initialized
INFO - 2021-02-27 03:32:15 --> Language Class Initialized
INFO - 2021-02-27 03:32:15 --> Language Class Initialized
INFO - 2021-02-27 03:32:15 --> Config Class Initialized
INFO - 2021-02-27 03:32:15 --> Loader Class Initialized
INFO - 2021-02-27 03:32:15 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:15 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:15 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:15 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:15 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:15 --> Controller Class Initialized
DEBUG - 2021-02-27 03:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-02-27 03:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:32:15 --> Final output sent to browser
DEBUG - 2021-02-27 03:32:16 --> Total execution time: 1.1183
INFO - 2021-02-27 03:32:16 --> Config Class Initialized
INFO - 2021-02-27 03:32:16 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:16 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:16 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:16 --> URI Class Initialized
INFO - 2021-02-27 03:32:16 --> Router Class Initialized
INFO - 2021-02-27 03:32:16 --> Output Class Initialized
INFO - 2021-02-27 03:32:16 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:16 --> Input Class Initialized
INFO - 2021-02-27 03:32:16 --> Language Class Initialized
INFO - 2021-02-27 03:32:16 --> Language Class Initialized
INFO - 2021-02-27 03:32:16 --> Config Class Initialized
INFO - 2021-02-27 03:32:16 --> Loader Class Initialized
INFO - 2021-02-27 03:32:16 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:16 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:16 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:16 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:17 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:17 --> Controller Class Initialized
INFO - 2021-02-27 03:32:23 --> Config Class Initialized
INFO - 2021-02-27 03:32:23 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:23 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:23 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:23 --> URI Class Initialized
INFO - 2021-02-27 03:32:23 --> Router Class Initialized
INFO - 2021-02-27 03:32:24 --> Output Class Initialized
INFO - 2021-02-27 03:32:24 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:24 --> Input Class Initialized
INFO - 2021-02-27 03:32:24 --> Language Class Initialized
INFO - 2021-02-27 03:32:24 --> Language Class Initialized
INFO - 2021-02-27 03:32:24 --> Config Class Initialized
INFO - 2021-02-27 03:32:24 --> Loader Class Initialized
INFO - 2021-02-27 03:32:24 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:24 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:24 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:24 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:24 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:24 --> Controller Class Initialized
DEBUG - 2021-02-27 03:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-02-27 03:32:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:32:24 --> Final output sent to browser
DEBUG - 2021-02-27 03:32:24 --> Total execution time: 1.1756
INFO - 2021-02-27 03:32:25 --> Config Class Initialized
INFO - 2021-02-27 03:32:25 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:25 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:25 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:25 --> URI Class Initialized
INFO - 2021-02-27 03:32:25 --> Router Class Initialized
INFO - 2021-02-27 03:32:25 --> Output Class Initialized
INFO - 2021-02-27 03:32:25 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:25 --> Input Class Initialized
INFO - 2021-02-27 03:32:25 --> Language Class Initialized
INFO - 2021-02-27 03:32:25 --> Language Class Initialized
INFO - 2021-02-27 03:32:25 --> Config Class Initialized
INFO - 2021-02-27 03:32:25 --> Loader Class Initialized
INFO - 2021-02-27 03:32:25 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:25 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:25 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:25 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:25 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:26 --> Controller Class Initialized
INFO - 2021-02-27 03:32:27 --> Config Class Initialized
INFO - 2021-02-27 03:32:27 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:27 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:27 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:27 --> URI Class Initialized
INFO - 2021-02-27 03:32:27 --> Router Class Initialized
INFO - 2021-02-27 03:32:27 --> Output Class Initialized
INFO - 2021-02-27 03:32:27 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:28 --> Input Class Initialized
INFO - 2021-02-27 03:32:28 --> Language Class Initialized
INFO - 2021-02-27 03:32:28 --> Language Class Initialized
INFO - 2021-02-27 03:32:28 --> Config Class Initialized
INFO - 2021-02-27 03:32:28 --> Loader Class Initialized
INFO - 2021-02-27 03:32:28 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:28 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:28 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:28 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:28 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:28 --> Controller Class Initialized
DEBUG - 2021-02-27 03:32:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-02-27 03:32:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:32:28 --> Final output sent to browser
DEBUG - 2021-02-27 03:32:28 --> Total execution time: 0.9822
INFO - 2021-02-27 03:32:28 --> Config Class Initialized
INFO - 2021-02-27 03:32:28 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:29 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:29 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:29 --> URI Class Initialized
INFO - 2021-02-27 03:32:29 --> Router Class Initialized
INFO - 2021-02-27 03:32:29 --> Output Class Initialized
INFO - 2021-02-27 03:32:29 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:29 --> Input Class Initialized
INFO - 2021-02-27 03:32:29 --> Language Class Initialized
INFO - 2021-02-27 03:32:29 --> Language Class Initialized
INFO - 2021-02-27 03:32:29 --> Config Class Initialized
INFO - 2021-02-27 03:32:29 --> Loader Class Initialized
INFO - 2021-02-27 03:32:29 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:29 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:29 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:29 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:29 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:29 --> Controller Class Initialized
INFO - 2021-02-27 03:32:31 --> Config Class Initialized
INFO - 2021-02-27 03:32:31 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:31 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:31 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:31 --> URI Class Initialized
INFO - 2021-02-27 03:32:31 --> Router Class Initialized
INFO - 2021-02-27 03:32:31 --> Output Class Initialized
INFO - 2021-02-27 03:32:31 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:32 --> Input Class Initialized
INFO - 2021-02-27 03:32:32 --> Language Class Initialized
INFO - 2021-02-27 03:32:32 --> Language Class Initialized
INFO - 2021-02-27 03:32:32 --> Config Class Initialized
INFO - 2021-02-27 03:32:32 --> Loader Class Initialized
INFO - 2021-02-27 03:32:32 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:32 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:32 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:32 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:32 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:32 --> Controller Class Initialized
INFO - 2021-02-27 03:32:32 --> Final output sent to browser
DEBUG - 2021-02-27 03:32:32 --> Total execution time: 0.9673
INFO - 2021-02-27 03:32:32 --> Config Class Initialized
INFO - 2021-02-27 03:32:32 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:32 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:33 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:33 --> URI Class Initialized
INFO - 2021-02-27 03:32:33 --> Router Class Initialized
INFO - 2021-02-27 03:32:33 --> Output Class Initialized
INFO - 2021-02-27 03:32:33 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:33 --> Input Class Initialized
INFO - 2021-02-27 03:32:33 --> Language Class Initialized
INFO - 2021-02-27 03:32:33 --> Language Class Initialized
INFO - 2021-02-27 03:32:33 --> Config Class Initialized
INFO - 2021-02-27 03:32:33 --> Loader Class Initialized
INFO - 2021-02-27 03:32:33 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:33 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:33 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:33 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:33 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:33 --> Controller Class Initialized
INFO - 2021-02-27 03:32:35 --> Config Class Initialized
INFO - 2021-02-27 03:32:35 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:35 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:35 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:35 --> URI Class Initialized
INFO - 2021-02-27 03:32:35 --> Router Class Initialized
INFO - 2021-02-27 03:32:36 --> Output Class Initialized
INFO - 2021-02-27 03:32:36 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:36 --> Input Class Initialized
INFO - 2021-02-27 03:32:36 --> Language Class Initialized
INFO - 2021-02-27 03:32:36 --> Language Class Initialized
INFO - 2021-02-27 03:32:36 --> Config Class Initialized
INFO - 2021-02-27 03:32:36 --> Loader Class Initialized
INFO - 2021-02-27 03:32:36 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:36 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:36 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:36 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:36 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:36 --> Controller Class Initialized
DEBUG - 2021-02-27 03:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-02-27 03:32:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:32:37 --> Final output sent to browser
DEBUG - 2021-02-27 03:32:37 --> Total execution time: 1.2211
INFO - 2021-02-27 03:32:49 --> Config Class Initialized
INFO - 2021-02-27 03:32:49 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:49 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:49 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:49 --> URI Class Initialized
INFO - 2021-02-27 03:32:49 --> Router Class Initialized
INFO - 2021-02-27 03:32:50 --> Output Class Initialized
INFO - 2021-02-27 03:32:50 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:50 --> Input Class Initialized
INFO - 2021-02-27 03:32:50 --> Language Class Initialized
INFO - 2021-02-27 03:32:50 --> Language Class Initialized
INFO - 2021-02-27 03:32:50 --> Config Class Initialized
INFO - 2021-02-27 03:32:50 --> Loader Class Initialized
INFO - 2021-02-27 03:32:50 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:50 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:50 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:50 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:50 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:50 --> Controller Class Initialized
DEBUG - 2021-02-27 03:32:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-02-27 03:32:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:32:50 --> Final output sent to browser
DEBUG - 2021-02-27 03:32:50 --> Total execution time: 1.0128
INFO - 2021-02-27 03:32:51 --> Config Class Initialized
INFO - 2021-02-27 03:32:51 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:51 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:51 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:51 --> URI Class Initialized
INFO - 2021-02-27 03:32:51 --> Router Class Initialized
INFO - 2021-02-27 03:32:51 --> Output Class Initialized
INFO - 2021-02-27 03:32:51 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:51 --> Input Class Initialized
INFO - 2021-02-27 03:32:51 --> Language Class Initialized
INFO - 2021-02-27 03:32:51 --> Language Class Initialized
INFO - 2021-02-27 03:32:51 --> Config Class Initialized
INFO - 2021-02-27 03:32:51 --> Loader Class Initialized
INFO - 2021-02-27 03:32:51 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:51 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:51 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:51 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:52 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:52 --> Controller Class Initialized
INFO - 2021-02-27 03:32:54 --> Config Class Initialized
INFO - 2021-02-27 03:32:54 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:32:54 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:32:54 --> Utf8 Class Initialized
INFO - 2021-02-27 03:32:54 --> URI Class Initialized
INFO - 2021-02-27 03:32:54 --> Router Class Initialized
INFO - 2021-02-27 03:32:54 --> Output Class Initialized
INFO - 2021-02-27 03:32:54 --> Security Class Initialized
DEBUG - 2021-02-27 03:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:32:54 --> Input Class Initialized
INFO - 2021-02-27 03:32:54 --> Language Class Initialized
INFO - 2021-02-27 03:32:54 --> Language Class Initialized
INFO - 2021-02-27 03:32:54 --> Config Class Initialized
INFO - 2021-02-27 03:32:54 --> Loader Class Initialized
INFO - 2021-02-27 03:32:54 --> Helper loaded: url_helper
INFO - 2021-02-27 03:32:54 --> Helper loaded: file_helper
INFO - 2021-02-27 03:32:54 --> Helper loaded: form_helper
INFO - 2021-02-27 03:32:54 --> Helper loaded: my_helper
INFO - 2021-02-27 03:32:54 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:32:55 --> Controller Class Initialized
INFO - 2021-02-27 03:32:55 --> Final output sent to browser
DEBUG - 2021-02-27 03:32:55 --> Total execution time: 0.9323
INFO - 2021-02-27 03:33:37 --> Config Class Initialized
INFO - 2021-02-27 03:33:37 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:33:37 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:33:37 --> Utf8 Class Initialized
INFO - 2021-02-27 03:33:37 --> URI Class Initialized
INFO - 2021-02-27 03:33:37 --> Router Class Initialized
INFO - 2021-02-27 03:33:37 --> Output Class Initialized
INFO - 2021-02-27 03:33:37 --> Security Class Initialized
DEBUG - 2021-02-27 03:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:33:37 --> Input Class Initialized
INFO - 2021-02-27 03:33:37 --> Language Class Initialized
INFO - 2021-02-27 03:33:37 --> Language Class Initialized
INFO - 2021-02-27 03:33:37 --> Config Class Initialized
INFO - 2021-02-27 03:33:37 --> Loader Class Initialized
INFO - 2021-02-27 03:33:37 --> Helper loaded: url_helper
INFO - 2021-02-27 03:33:37 --> Helper loaded: file_helper
INFO - 2021-02-27 03:33:37 --> Helper loaded: form_helper
INFO - 2021-02-27 03:33:37 --> Helper loaded: my_helper
INFO - 2021-02-27 03:33:37 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:33:37 --> Controller Class Initialized
INFO - 2021-02-27 03:33:38 --> Final output sent to browser
DEBUG - 2021-02-27 03:33:38 --> Total execution time: 0.9568
INFO - 2021-02-27 03:33:47 --> Config Class Initialized
INFO - 2021-02-27 03:33:47 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:33:47 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:33:47 --> Utf8 Class Initialized
INFO - 2021-02-27 03:33:47 --> URI Class Initialized
INFO - 2021-02-27 03:33:47 --> Router Class Initialized
INFO - 2021-02-27 03:33:47 --> Output Class Initialized
INFO - 2021-02-27 03:33:47 --> Security Class Initialized
DEBUG - 2021-02-27 03:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:33:47 --> Input Class Initialized
INFO - 2021-02-27 03:33:47 --> Language Class Initialized
INFO - 2021-02-27 03:33:47 --> Language Class Initialized
INFO - 2021-02-27 03:33:47 --> Config Class Initialized
INFO - 2021-02-27 03:33:47 --> Loader Class Initialized
INFO - 2021-02-27 03:33:47 --> Helper loaded: url_helper
INFO - 2021-02-27 03:33:47 --> Helper loaded: file_helper
INFO - 2021-02-27 03:33:47 --> Helper loaded: form_helper
INFO - 2021-02-27 03:33:47 --> Helper loaded: my_helper
INFO - 2021-02-27 03:33:47 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:33:47 --> Controller Class Initialized
INFO - 2021-02-27 03:33:47 --> Final output sent to browser
DEBUG - 2021-02-27 03:33:48 --> Total execution time: 0.8425
INFO - 2021-02-27 03:33:48 --> Config Class Initialized
INFO - 2021-02-27 03:33:48 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:33:48 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:33:48 --> Utf8 Class Initialized
INFO - 2021-02-27 03:33:48 --> URI Class Initialized
INFO - 2021-02-27 03:33:48 --> Router Class Initialized
INFO - 2021-02-27 03:33:48 --> Output Class Initialized
INFO - 2021-02-27 03:33:48 --> Security Class Initialized
DEBUG - 2021-02-27 03:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:33:48 --> Input Class Initialized
INFO - 2021-02-27 03:33:48 --> Language Class Initialized
INFO - 2021-02-27 03:33:48 --> Language Class Initialized
INFO - 2021-02-27 03:33:48 --> Config Class Initialized
INFO - 2021-02-27 03:33:48 --> Loader Class Initialized
INFO - 2021-02-27 03:33:48 --> Helper loaded: url_helper
INFO - 2021-02-27 03:33:48 --> Helper loaded: file_helper
INFO - 2021-02-27 03:33:48 --> Helper loaded: form_helper
INFO - 2021-02-27 03:33:49 --> Helper loaded: my_helper
INFO - 2021-02-27 03:33:49 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:33:49 --> Controller Class Initialized
INFO - 2021-02-27 03:33:50 --> Config Class Initialized
INFO - 2021-02-27 03:33:50 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:33:50 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:33:50 --> Utf8 Class Initialized
INFO - 2021-02-27 03:33:50 --> URI Class Initialized
INFO - 2021-02-27 03:33:50 --> Router Class Initialized
INFO - 2021-02-27 03:33:50 --> Output Class Initialized
INFO - 2021-02-27 03:33:50 --> Security Class Initialized
DEBUG - 2021-02-27 03:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:33:50 --> Input Class Initialized
INFO - 2021-02-27 03:33:50 --> Language Class Initialized
INFO - 2021-02-27 03:33:50 --> Language Class Initialized
INFO - 2021-02-27 03:33:50 --> Config Class Initialized
INFO - 2021-02-27 03:33:50 --> Loader Class Initialized
INFO - 2021-02-27 03:33:50 --> Helper loaded: url_helper
INFO - 2021-02-27 03:33:50 --> Helper loaded: file_helper
INFO - 2021-02-27 03:33:50 --> Helper loaded: form_helper
INFO - 2021-02-27 03:33:50 --> Helper loaded: my_helper
INFO - 2021-02-27 03:33:50 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:33:51 --> Controller Class Initialized
INFO - 2021-02-27 03:33:51 --> Final output sent to browser
DEBUG - 2021-02-27 03:33:51 --> Total execution time: 0.8860
INFO - 2021-02-27 03:34:06 --> Config Class Initialized
INFO - 2021-02-27 03:34:06 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:34:06 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:34:06 --> Utf8 Class Initialized
INFO - 2021-02-27 03:34:06 --> URI Class Initialized
INFO - 2021-02-27 03:34:06 --> Router Class Initialized
INFO - 2021-02-27 03:34:06 --> Output Class Initialized
INFO - 2021-02-27 03:34:06 --> Security Class Initialized
DEBUG - 2021-02-27 03:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:34:07 --> Input Class Initialized
INFO - 2021-02-27 03:34:07 --> Language Class Initialized
INFO - 2021-02-27 03:34:07 --> Language Class Initialized
INFO - 2021-02-27 03:34:07 --> Config Class Initialized
INFO - 2021-02-27 03:34:07 --> Loader Class Initialized
INFO - 2021-02-27 03:34:07 --> Helper loaded: url_helper
INFO - 2021-02-27 03:34:07 --> Helper loaded: file_helper
INFO - 2021-02-27 03:34:07 --> Helper loaded: form_helper
INFO - 2021-02-27 03:34:07 --> Helper loaded: my_helper
INFO - 2021-02-27 03:34:07 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:34:07 --> Controller Class Initialized
INFO - 2021-02-27 03:34:07 --> Final output sent to browser
DEBUG - 2021-02-27 03:34:07 --> Total execution time: 0.9123
INFO - 2021-02-27 03:37:13 --> Config Class Initialized
INFO - 2021-02-27 03:37:13 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:37:13 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:37:13 --> Utf8 Class Initialized
INFO - 2021-02-27 03:37:13 --> URI Class Initialized
INFO - 2021-02-27 03:37:13 --> Router Class Initialized
INFO - 2021-02-27 03:37:13 --> Output Class Initialized
INFO - 2021-02-27 03:37:13 --> Security Class Initialized
DEBUG - 2021-02-27 03:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:37:13 --> Input Class Initialized
INFO - 2021-02-27 03:37:13 --> Language Class Initialized
INFO - 2021-02-27 03:37:13 --> Language Class Initialized
INFO - 2021-02-27 03:37:13 --> Config Class Initialized
INFO - 2021-02-27 03:37:13 --> Loader Class Initialized
INFO - 2021-02-27 03:37:13 --> Helper loaded: url_helper
INFO - 2021-02-27 03:37:13 --> Helper loaded: file_helper
INFO - 2021-02-27 03:37:13 --> Helper loaded: form_helper
INFO - 2021-02-27 03:37:14 --> Helper loaded: my_helper
INFO - 2021-02-27 03:37:14 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:37:14 --> Controller Class Initialized
DEBUG - 2021-02-27 03:37:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-02-27 03:37:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:37:14 --> Final output sent to browser
DEBUG - 2021-02-27 03:37:14 --> Total execution time: 1.1175
INFO - 2021-02-27 03:37:14 --> Config Class Initialized
INFO - 2021-02-27 03:37:14 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:37:14 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:37:14 --> Utf8 Class Initialized
INFO - 2021-02-27 03:37:14 --> URI Class Initialized
INFO - 2021-02-27 03:37:14 --> Router Class Initialized
INFO - 2021-02-27 03:37:14 --> Output Class Initialized
INFO - 2021-02-27 03:37:15 --> Security Class Initialized
DEBUG - 2021-02-27 03:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:37:15 --> Input Class Initialized
INFO - 2021-02-27 03:37:15 --> Language Class Initialized
INFO - 2021-02-27 03:37:15 --> Language Class Initialized
INFO - 2021-02-27 03:37:15 --> Config Class Initialized
INFO - 2021-02-27 03:37:15 --> Loader Class Initialized
INFO - 2021-02-27 03:37:15 --> Helper loaded: url_helper
INFO - 2021-02-27 03:37:15 --> Helper loaded: file_helper
INFO - 2021-02-27 03:37:15 --> Helper loaded: form_helper
INFO - 2021-02-27 03:37:15 --> Helper loaded: my_helper
INFO - 2021-02-27 03:37:15 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:37:15 --> Controller Class Initialized
INFO - 2021-02-27 03:37:15 --> Config Class Initialized
INFO - 2021-02-27 03:37:15 --> Hooks Class Initialized
DEBUG - 2021-02-27 03:37:15 --> UTF-8 Support Enabled
INFO - 2021-02-27 03:37:15 --> Utf8 Class Initialized
INFO - 2021-02-27 03:37:15 --> URI Class Initialized
INFO - 2021-02-27 03:37:15 --> Router Class Initialized
INFO - 2021-02-27 03:37:15 --> Output Class Initialized
INFO - 2021-02-27 03:37:16 --> Security Class Initialized
DEBUG - 2021-02-27 03:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-02-27 03:37:16 --> Input Class Initialized
INFO - 2021-02-27 03:37:16 --> Language Class Initialized
INFO - 2021-02-27 03:37:16 --> Language Class Initialized
INFO - 2021-02-27 03:37:16 --> Config Class Initialized
INFO - 2021-02-27 03:37:16 --> Loader Class Initialized
INFO - 2021-02-27 03:37:16 --> Helper loaded: url_helper
INFO - 2021-02-27 03:37:16 --> Helper loaded: file_helper
INFO - 2021-02-27 03:37:16 --> Helper loaded: form_helper
INFO - 2021-02-27 03:37:16 --> Helper loaded: my_helper
INFO - 2021-02-27 03:37:16 --> Database Driver Class Initialized
DEBUG - 2021-02-27 03:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-02-27 03:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-02-27 03:37:16 --> Controller Class Initialized
ERROR - 2021-02-27 03:37:16 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-02-27 03:37:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-02-27 03:37:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-02-27 03:37:16 --> Final output sent to browser
DEBUG - 2021-02-27 03:37:16 --> Total execution time: 1.1406
